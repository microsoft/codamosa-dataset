

# Generated at 2022-06-17 05:07:59.233211
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:08:06.598465
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.dict_transformations import _exclude_nones
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError

# Generated at 2022-06-17 05:08:14.148533
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:21.594670
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    # create a temporary ansible.cfg
    tmpansiblecfg = os.path.join(tmpdir, 'ansible.cfg')

    # make sure ansible.cfg is absent
    if os.path.exists(tmpansiblecfg):
        os.unlink(tmpansiblecfg)

    # create a file with some data

# Generated at 2022-06-17 05:08:24.671328
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: dest
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:33.946798
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['unsafe_writes'] = False
    contents = 'test'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    assert open(module.params['path'], 'r').read() == contents
    os.remove(module.params['path'])



# Generated at 2022-06-17 05:08:42.626853
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)



# Generated at 2022-06-17 05:08:52.033344
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:02.139462
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:09:10.277194
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:09:33.998316
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    contents = to_bytes(module.params['contents'])
    path = module.params['path']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:09:45.110256
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    if not PY2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # write some data to the temporary file

# Generated at 2022-06-17 05:09:57.431313
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    module.params = {
        'path': '/etc/hosts',
        'contents': '127.0.0.1 localhost',
        'validate': 'grep localhost %s',
    }

# Generated at 2022-06-17 05:10:05.005163
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:15.749457
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:10:26.837163
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:10:34.707119
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'root', 'serole': 'root', 'setype': 'root', 'selevel': 'root'}
    changed = False
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 05:10:46.657110
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
            encoding=dict(type='str', required=False, default='utf-8'),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
   

# Generated at 2022-06-17 05:10:57.165469
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:04.460268
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test_write_changes', 'validate': 'echo %s'})
    write_changes(module, 'test', '/tmp/test_write_changes')
    with open('/tmp/test_write_changes') as f:
        assert f.read() == 'test'


# Generated at 2022-06-17 05:11:42.511436
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = tempfile.gettempdir()
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, '', '/tmp/test')
    write_changes(module, '', '/tmp/test')
    module.run_command = lambda cmd: (1, '', '')
    try:
        write_changes(module, '', '/tmp/test')
    except SystemExit:
        pass
    else:
        raise Exception('should have failed')
    module.params['validate'] = '%s'

# Generated at 2022-06-17 05:11:48.082158
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/test_write_changes'
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:11:58.244802
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:12:08.930511
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.params['validate'] = None
    module.params['unsafe_writes'] = False
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, '', '')
    module.params['validate'] = 'echo %s'
    write_changes(module, '', '')
    module.params['validate'] = 'echo %s'
    module.run_command = lambda cmd: (1, '', '')
    try:
        write_changes(module, '', '')
    except SystemExit:
        pass
    else:
        assert False, 'Expected SystemExit'

# Generated at 2022-06-17 05:12:21.684071
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            contents = dict(type='str', required=True),
            validate = dict(type='str', required=False),
            unsafe_writes = dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.tmpdir = '/tmp'
    write_changes(module, to_bytes('test'), '/tmp/test')


# Generated at 2022-06-17 05:12:27.872576
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = "ownership, perms or SE linux context changed"
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:12:37.060624
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:12:50.079523
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:13:00.375698
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 05:13:06.539228
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']
    before = module.params['before']
    backup = module.params['backup']

# Generated at 2022-06-17 05:14:20.534460
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': False}
    changed = False
    message = "test message"
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "test message and ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:14:33.711673
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'tmp_t', 'selevel': 's0'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:44.967316
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:53.342899
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'foo', '/tmp/bar')



# Generated at 2022-06-17 05:15:07.126805
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:15:11.585410
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 05:15:21.280877
# Unit test for function main
def test_main():
    # Test with no file
    path = '/tmp/test_main_file'
    if os.path.exists(path):
        os.remove(path)
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-17 05:15:27.489913
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    write_changes(module, 'test', '/tmp/test')
    assert os.path.exists('/tmp/test')
    os.remove('/tmp/test')



# Generated at 2022-06-17 05:15:41.502642
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.file import is_special_selinux_path
    from ansible.module_utils.common.file import get_file_attributes
    from ansible.module_utils.common.file import selinux_restorecon
    from ansible.module_utils.common.file import selinux_restore_perms

# Generated at 2022-06-17 05:15:52.202941
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("This test requires Python 3")

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = %s\n" % tmpdir)

    # Create a temporary role