

# Generated at 2022-06-17 05:07:54.714083
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 05:08:05.753040
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 05:08:19.070084
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.fail_json = lambda x: None
    module.params = {'path': '/tmp/test', 'validate': 'test %s'}
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'test'}

# Generated at 2022-06-17 05:08:30.584302
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'etc_t', 'selevel': 's0'}
    module.run_command = lambda *args, **kwargs: (0, '', '')
   

# Generated at 2022-06-17 05:08:35.342215
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

   

# Generated at 2022-06-17 05:08:39.648447
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.params = {'unsafe_writes': True}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:44.198745
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = 'test'
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'test and ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 05:08:54.885388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:58.414381
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:05.265524
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_check_file_attrs',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:09:26.743363
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    contents = b'foo'
    path = '/tmp/test'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:09:36.085782
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:09:44.638816
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': False}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:52.510561
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    module.atomic_move = lambda *args, **kwargs: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'

# Generated at 2022-06-17 05:10:02.508159
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:10:16.561513
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str', 'required': False}, 'unsafe_writes': {'type': 'bool', 'default': False, 'required': False}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo %s'
    module.params['unsafe_writes'] = False
    contents = 'test_write_changes'
    write_changes(module, contents, module.params['path'])
    with open(module.params['path'], 'r') as f:
        assert f.read() == contents
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:10:25.809160
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = '/tmp'
    module.params['validate'] = 'echo %s'
    module.params['path'] = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    assert open(module.params['path']).read() == contents
    os.unlink(module.params['path'])


# Generated at 2022-06-17 05:10:31.965352
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.params = {'unsafe_writes': True}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:10:37.338725
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:46.519079
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:17.341393
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src, dest)
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', os.path.join(module.tmpdir, 'test'))
    assert os.path.exists(os.path.join(module.tmpdir, 'test'))
    os.unlink(os.path.join(module.tmpdir, 'test'))
    os.r

# Generated at 2022-06-17 05:11:26.055935
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    # Write a sample file

# Generated at 2022-06-17 05:11:34.620201
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
            validate=dict(type='str', required=False),
        ),
        supports_check_mode=True,
    )
    # Set up the test
    test_path = '/tmp/test_file'

# Generated at 2022-06-17 05:11:49.319277
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.atomic_move = lambda *args, **kwargs: True
    module.tmpdir = '/tmp'
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:11:58.685487
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']

# Generated at 2022-06-17 05:12:08.130435
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError

# Generated at 2022-06-17 05:12:16.096869
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda x, y, z: None
    module.params = {'unsafe_writes': True}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', 'test')
    assert True


# Generated at 2022-06-17 05:12:22.615868
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    module.fail_json = lambda x: False
    contents = to_bytes('test')
    path = '/tmp/test'
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:12:34.434245
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.urls import open_url

# Generated at 2022-06-17 05:12:42.954034
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:13:43.438383
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')
    assert module.atomic_move.called



# Generated at 2022-06-17 05:13:54.601931
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    module.set_file_attributes_if_different = lambda x, y: True
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:03.268501
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

   

# Generated at 2022-06-17 05:14:12.639966
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:16.447631
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = "test"
    changed = False
    result = check_file_attrs(module, changed, message)
    assert result == ("test", False)


# Generated at 2022-06-17 05:14:21.544444
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:31.428844
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import zip_longest
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter

# Generated at 2022-06-17 05:14:39.279811
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.gettempdir()
    module.atomic_move = lambda src, dest, unsafe_writes: True
    module.params = {'unsafe_writes': False}
    module.run_command = lambda cmd: (0, '', '')
    contents = b'# This is a test'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:14:54.442331
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.urls import open_url
   

# Generated at 2022-06-17 05:15:01.605997
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:17:04.137196
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    # Write data to the temporary file
    os.write(fd, to_bytes('#!/bin/sh\n'))
    os.write(fd, to_bytes('\n'))
    os.write(fd, to_bytes('# This is a comment\n'))
    os.write(fd, to_bytes('echo "Hello World"\n'))
    os.write(fd, to_bytes('\n'))

# Generated at 2022-06-17 05:17:16.086085
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:17:22.463284
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:17:34.278878
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_path