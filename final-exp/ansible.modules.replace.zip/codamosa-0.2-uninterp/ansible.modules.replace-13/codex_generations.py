

# Generated at 2022-06-17 05:07:52.366059
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import shutil
    import sys

    # Load the module source file
    module_path = os.path.join('library', 'replace.py')
    if not os.path.exists(module_path):
        module_path = os.path.join('ansible', 'modules', 'files', 'replace.py')
    if not os.path.exists(module_path):
        module_path = os.path.join('lib', 'ansible', 'modules', 'files', 'replace.py')

# Generated at 2022-06-17 05:08:03.972314
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:12.152905
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:08:19.505104
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:30.467692
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')
    assert module.params['path'] == '/tmp/test'
    assert module.params['validate'] == None
    assert module.params['unsafe_writes'] == False


# Generated at 2022-06-17 05:08:36.969912
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/path/to/file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:43.281751
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:49.793637
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:08:57.345702
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write something to the temporary file

# Generated at 2022-06-17 05:09:08.687476
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True

# Generated at 2022-06-17 05:09:31.674760
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:35.434744
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:43.583322
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:52.458229
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']
    before = module.params['before']
    backup = module.params['backup']

# Generated at 2022-06-17 05:10:00.556457
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    path = '/tmp/test_write_changes'
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:10:11.733175
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:22.063422
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'tmp_t', 'selevel': 's0'}
    module.atomic_move = lambda src, dest, unsafe_writes=False: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:10:30.047776
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:35.876280
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:10:45.220387
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:11:21.310517
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:11:33.572866
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:39.945064
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: True
    module.run_command = lambda x: (0, '', '')
    assert write_changes(module, '', '/tmp/test') == True


# Generated at 2022-06-17 05:11:51.827705
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str', 'required': False}, 'unsafe_writes': {'type': 'bool', 'required': False}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = None
    module.params['unsafe_writes'] = False
    contents = 'test_write_changes'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    with open(module.params['path'], 'r') as f:
        assert f.read() == contents
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:12:06.121792
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 05:12:14.918922
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False, 'aliases': ['unsafe']}
    })
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    module.fail_json = lambda x: True
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:24.660950
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.atomic_move = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    message, changed = check_file_attrs(module, False, "")
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 05:12:32.027741
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:12:46.237473
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            contents = dict(type='str', required=True),
            validate = dict(type='str'),
            unsafe_writes = dict(type='bool', default=False)
        )
    )
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(to_bytes(module.params['contents']))
    f.close()
    write_changes(module, to_bytes(module.params['contents']), tmpfile)
    f = open(tmpfile, 'rb')
    contents = f.read()
    f.close()

# Generated at 2022-06-17 05:12:56.408236
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs

# Generated at 2022-06-17 05:14:05.467845
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:14:13.215302
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:21.080702
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            contents = dict(required=True, type='str'),
            validate = dict(required=False, type='str'),
            unsafe_writes = dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:14:35.204054
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-17 05:14:44.355104
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:54.272318
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, 'test', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, 'test', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, 'test', '/tmp/test')

# Generated at 2022-06-17 05:15:03.798247
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:15:10.525994
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, '', '/tmp/test')


# Generated at 2022-06-17 05:15:24.820465
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
            validate=dict(type='str'),
            others=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 05:15:32.638664
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_str