

# Generated at 2022-06-17 05:07:55.461742
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
            encoding=dict(type='str', required=False, default='utf-8'),
            unsafe_writes=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert message == ""

# Generated at 2022-06-17 05:08:03.478556
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:08:10.061396
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    message = "test"
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "test and ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:08:18.475619
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:08:29.981634
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import filecmp
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temp ansible.cfg

# Generated at 2022-06-17 05:08:34.981706
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-17 05:08:41.933176
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda a, b, c: True
    module.run_command = lambda a: (0, '', '')
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:54.003591
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.run_

# Generated at 2022-06-17 05:09:01.757314
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    af = open(os.path.join(tmpdir, "ansible.cfg"), 'w')
    af.write("[defaults]\n")
    af.write("roles_path = %s\n" % tmpdir)
    af.close()

    # Create a temporary role

# Generated at 2022-06-17 05:09:11.062919
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:32.149192
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicSections
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 05:09:40.354892
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:51.969232
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_check_file_attrs',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.atomic_move = lambda *args, **kwargs: None
    module.load_file_common_arguments = lambda *args, **kwargs: module.params

    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True


# Generated at 2022-06-17 05:09:57.168688
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:05.164677
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:10:16.336412
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo "test"'
    contents = to_bytes('test_write_changes')
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == contents
    os.remove(module.params['path'])



# Generated at 2022-06-17 05:10:24.814310
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 05:10:32.783173
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:40.696371
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils import file
    from ansible.module_utils import file_common
    from ansible.module_utils import module_common
    from ansible.module_utils import module_utils_loader
    from ansible.module_utils import utils
    from ansible.module_utils import _text
    from ansible.module_utils import _collections_compat
    from ansible.module_utils import _collections_compat_v2
    from ansible.module_utils import _collections_compat_v2_ansible_collections

# Generated at 2022-06-17 05:10:54.424878
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:23.813412
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:11:33.888504
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.request import Request, urlopen
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError, SSL

# Generated at 2022-06-17 05:11:46.350773
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'seuser': 'system_u',
                     'serole': 'object_r',
                     'setype': 'tmp_t',
                     'selevel': 's0',
                     'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:11:55.593007
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.params = {'path': '/tmp/test', 'validate': 'echo %s', 'unsafe_writes': False}
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:07.483920
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo %s'
    module.params['unsafe_writes'] = True
    contents = b'This is a test'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    assert open(module.params['path'], 'rb').read() == contents
    os.unlink(module.params['path'])


# Generated at 2022-06-17 05:12:20.727821
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')
    assert module.params['path'] == '/tmp/test'


# Generated at 2022-06-17 05:12:31.112696
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test.txt', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {'path': '/tmp/test.txt', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'

# Generated at 2022-06-17 05:12:45.827635
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    # Write some content
    os.write(fd, to_bytes('Hello world'))
    # Close the file
    os.close(fd)

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    # create a temporary file
    fd, temp_path2 = tempfile.mkstemp(dir=tmpdir2)
    # Write some content

# Generated at 2022-06-17 05:12:56.278770
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url

    # Create a temporary file
    tmpfd, tmpfile = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary directory and a file inside it
    tmpdir

# Generated at 2022-06-17 05:13:03.622764
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:06.243560
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'foo', '/tmp/bar')


# Generated at 2022-06-17 05:14:19.306334
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')
    module.params['validate'] = '%s'
    write_changes(module, 'test', '/tmp/test')
    module.params['validate']

# Generated at 2022-06-17 05:14:23.244431
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:36.711797
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicSections
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 05:14:44.291886
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)
    os.rmdir(module.tmpdir)


# Generated at 2022-06-17 05:14:51.382152
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:14:58.659124
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']

    write_changes(module, contents, path)



# Generated at 2022-06-17 05:15:07.114484
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:15:14.280044
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:15:23.439295
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')
