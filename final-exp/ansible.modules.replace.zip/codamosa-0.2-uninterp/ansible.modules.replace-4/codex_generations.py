

# Generated at 2022-06-17 05:07:57.623900
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = '/tmp'
    module.params['unsafe_writes'] = True
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, b'foo', '/tmp/foo')
    module.run_command = lambda x: (1, '', '')
    module.fail_json = lambda x: None
    write_changes(module, b'foo', '/tmp/foo')
    module.fail_json = lambda x: None
    write_changes(module, b'foo', '/tmp/foo')


# Generated at 2022-06-17 05:08:07.394896
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:08:19.527126
# Unit test for function write_changes
def test_write_changes():
    import os
    import tempfile
    import shutil
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.action.replace
    import ansible.module_utils.action.files
    import ansible.module_utils.action.validate
    import ansible.module_utils.action.common_attributes
    import ansible.module_utils.action.common_attributes.files
    import ansible.module_utils.action.common_attributes.validate
    import ansible.module_utils.action.common_attributes.action_common_attributes
    import ansible.module_utils.action.common_attributes.action_common_attributes.files
    import ansible.module_utils.action.common_attributes.action_

# Generated at 2022-06-17 05:08:26.659484
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:08:34.858657
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:42.511763
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 05:08:47.654500
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    message, changed = check_file_attrs(module, False, "")
    assert changed
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-17 05:08:53.179938
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.params = {'validate': None, 'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')
    try:
        write_changes(module, 'test', '/tmp/test')
        assert False
    except Exception as e:
        assert 'failed to validate' in str(e)
    module.params['validate'] = 'test %s'

# Generated at 2022-06-17 05:09:00.975573
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params = {'path': 'test_path', 'validate': 'test_validate'}
    write_changes(module, 'test_contents', 'test_path')


# Generated at 2022-06-17 05:09:10.430593
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-17 05:09:31.861600
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:09:42.119234
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            contents = dict(required=True, type='str'),
            validate = dict(required=False, type='str'),
            unsafe_writes = dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:09:52.628225
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    message = "ownership, perms or SE linux context changed"
    changed = True
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 05:10:02.299510
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True

    contents = 'test'
    path = '/tmp/test'
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:10:12.341575
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    file_args = module.load_file_common_arguments(module.params)
    if module.set_file_attributes_if_different(file_args, False):
        if changed:
            message += " and "
        changed = True
        message += "ownership, perms or SE linux context changed"
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 05:10:18.103263
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:22.198445
# Unit test for function write_changes
def test_write_changes():
    # Test that write_changes works
    # Test that write_changes fails when validate fails
    # Test that write_changes fails when validate is not a string
    # Test that write_changes fails when validate does not contain %s
    # Test that write_changes fails when validate is not a valid command
    # Test that write_changes fails when validate is a valid command but returns non-zero
    # Test that write_changes fails when validate is a valid command but returns zero
    pass



# Generated at 2022-06-17 05:10:28.564325
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo %s'
    contents = b'contents'
    write_changes(module, contents, module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == contents
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:10:40.038935
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:54.323727
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': dict(required=True),
                                          'validate': dict(required=False),
                                          'unsafe_writes': dict(required=False, type='bool', default=False)})
    module.tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src, dest)
    module.run_command = lambda cmd: (0, '', '')
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents



# Generated at 2022-06-17 05:11:32.510013
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:42.439943
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']

# Generated at 2022-06-17 05:11:46.617006
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.params['unsafe_writes'] = False
    contents = b'hello world'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:11:57.677193
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:12:08.241881
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 05:12:18.745594
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params = {'unsafe_writes': True}
    module.tmpdir = '/tmp'
    contents = b'foo'
    path = '/tmp/bar'
    write_changes(module, contents, path)
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1


# Generated at 2022-06-17 05:12:29.998946
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.params = {'validate': None, 'unsafe_writes': False}
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.params = {'validate': 'test %s', 'unsafe_writes': False}
    write_changes(module, 'test', '/tmp/test')
    module.params = {'validate': 'test %s', 'unsafe_writes': False}
    module.run_command = lambda cmd: (1, '', '')

# Generated at 2022-06-17 05:12:44.622564
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:12:53.265695
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.atomic_move = lambda src, dest, unsafe_writes: (src, dest, unsafe_writes)
    module.run_command = lambda cmd: (0, '', '')
    module.tmpdir = '/tmp'
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, 'test', '/tmp/test')
    assert module.atomic_move.call_args[0] == ('/tmp/test', '/tmp/test', False)


# Generated at 2022-06-17 05:13:05.845032
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:18.318408
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:27.922382
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 05:14:37.169334
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:14:45.917185
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed, message = False, ''

# Generated at 2022-06-17 05:14:55.351025
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:15:01.728832
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src, dest)
    module.run_command = lambda cmd: (0, '', '')
    path = os.path.join(module.tmpdir, 'test_write_changes')
    write_changes(module, b'foo', path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f

# Generated at 2022-06-17 05:15:11.616371
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    # Write some content to the temporary file
    os.write(fd, to_bytes('#!/bin/bash\n'))
    os.write(fd, to_bytes('\n'))
    os.write(fd, to_bytes('# This is a comment\n'))
    os.write(fd, to_bytes('echo "Hello World"\n'))
    os.write(fd, to_bytes('\n'))
    os.write

# Generated at 2022-06-17 05:15:15.873520
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:15:25.918839
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_check_file_attrs',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:15:32.733843
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
