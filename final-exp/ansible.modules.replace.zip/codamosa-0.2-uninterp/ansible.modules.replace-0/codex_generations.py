

# Generated at 2022-06-17 05:07:52.972285
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 05:08:03.636551
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.params = {
        'validate': None,
        'unsafe_writes': False
    }
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')
    try:
        write_changes(module, 'test', '/tmp/test')
    except SystemExit:
        pass
    else:
        raise AssertionError('Expected SystemExit')



# Generated at 2022-06-17 05:08:07.611217
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = "test"
    result = check_file_attrs(module, changed, message)
    assert result == ("test and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 05:08:17.990694
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:08:24.316901
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_check_file_attrs',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:34.446221
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:43.182862
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:48.745353
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    write_changes(module, 'test_contents', '/tmp/test_path')


# Generated at 2022-06-17 05:08:56.474406
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:08.612861
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("The replace module does not support Python 2")

    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    with open(temp_path, 'wb') as f:
        f.write(to_bytes('#!/usr/bin/python\nprint "hello"\n'))

# Generated at 2022-06-17 05:09:30.539047
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    write_changes(module, b'abc', '/tmp/test')
    assert os.path.exists('/tmp/test')
    os.remove('/tmp/test')



# Generated at 2022-06-17 05:09:37.294264
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import json
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Write some data to the temporary file

# Generated at 2022-06-17 05:09:46.765684
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:09:57.426578
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.params = {'validate': None, 'unsafe_writes': False}
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')
    module.params = {'validate': 'echo %s', 'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')
    module.run_command = lambda x: (1, '', '')

# Generated at 2022-06-17 05:10:03.643632
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)


# Generated at 2022-06-17 05:10:15.474307
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.params = {'path': '/tmp/test', 'validate': None, 'unsafe_writes': False}
    write_changes(module, b'', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'test %s', 'unsafe_writes': False}
    write_changes(module, b'', '/tmp/test')

# Generated at 2022-06-17 05:10:26.768285
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:36.257991
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo %s'
    module.params['unsafe_writes'] = True
    contents = b'hello world'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == contents
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:10:47.514566
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:10:57.228191
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:34.167383
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:49.266851
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/test_check_file_attrs'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'var_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = False
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'

# Generated at 2022-06-17 05:11:58.328275
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:12:08.211053
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')
    write_changes(module, b'foo', '/tmp/bar')
    write_changes(module, b'foo', '/tmp/bar')


# Generated at 2022-06-17 05:12:16.082204
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False},
                                          'tmpdir': {'type': 'str', 'required': False, 'default': '/tmp'}})
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'r').read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:12:26.861690
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    contents = b'foo'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)



# Generated at 2022-06-17 05:12:35.102448
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str', required=True),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')



# Generated at 2022-06-17 05:12:45.142669
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:50.376199
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']

# Generated at 2022-06-17 05:13:00.421799
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError

# Generated at 2022-06-17 05:14:08.499205
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']

    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()

    valid = not validate

# Generated at 2022-06-17 05:14:18.616302
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:29.081275
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents



# Generated at 2022-06-17 05:14:34.275408
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.common.file import is_special
    from ansible.module_utils.common.file import is_writable
    from ansible.module_utils.common.file import path_exists
    from ansible.module_utils.common.file import remove_file
    from ansible.module_utils.common.file import set_file_attributes
    from ansible.module_utils.common.file import set_

# Generated at 2022-06-17 05:14:45.025033
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:53.975922
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = to_bytes('test_write_changes')
    write_changes(module, contents, path)
    assert os.path.exists(path)
    f = open(path, 'rb')
    assert f.read() == contents
    f.close()
    os.remove(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:15:04.508874
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:15:13.021447
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

   

# Generated at 2022-06-17 05:15:24.668004
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, False, "") == (message, True)
    assert check_file_attrs(module, True, "") == (" and " + message, True)
    assert check_file_attrs(module, False, "") == (message, True)



# Generated at 2022-06-17 05:15:32.511573
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    # Create a temporary file
    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Write some content to the temporary file
    with open(path, 'wb') as f:
        f.write(to_bytes('#!/bin/sh\n'))
        f.write(to_bytes('echo "Hello, World!"\n'))

    # Create a module