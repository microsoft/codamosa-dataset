

# Generated at 2022-06-17 05:07:52.470492
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:04.124457
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Read the test file
    test_file = os.path.join(os.path.dirname(__file__), 'test_file')
    with open(test_file, 'rb') as f:
        test_file_contents = to_bytes(f.read())

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTem

# Generated at 2022-06-17 05:08:13.430187
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True},
    })
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:08:21.060425
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("The replace module does not work with Python 2")

    # make sure we don't have any side effects from previous runs
    sys.modules.pop('ansible.module_utils.basic', None)
    sys.modules.pop('ansible.module_utils.file', None)

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

# Generated at 2022-06-17 05:08:25.550459
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)



# Generated at 2022-06-17 05:08:35.057258
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:40.845317
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = 'echo %s'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test_write_changes')


# Generated at 2022-06-17 05:08:42.626368
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, "") == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 05:08:45.334387
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ''
    assert check_file_attrs(module, changed, message) == ('ownership, perms or SE linux context changed', True)



# Generated at 2022-06-17 05:08:55.024359
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False, 'required': False},
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.fail_json = lambda *args, **kwargs: None
    module.params = {
        'path': '/tmp/test',
        'validate': None,
        'unsafe_writes': False,
    }
    write_changes(module, b'', '/tmp/test')

# Generated at 2022-06-17 05:09:28.629944
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:09:36.681361
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:09:44.463885
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:09:57.261005
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:03.850738
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:10:14.888588
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': True, 'aliases': ['unsafe']}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')
    assert module.atomic_move.called


# Generated at 2022-06-17 05:10:21.903445
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    write_changes(module, '', '/tmp/test')


# Generated at 2022-06-17 05:10:27.360434
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:10:39.100473
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.file import _atomic_move
    from ansible.module_utils.common.file import _backup_local
    from ansible.module_utils.common.file import _set_file_attributes_if_different
    from ansible.module_utils.common.file import _write_changes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to

# Generated at 2022-06-17 05:10:53.447519
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO


# Generated at 2022-06-17 05:11:32.628670
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:11:36.858610
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:11:43.540671
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-17 05:11:48.362318
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.urls
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.package_manager
   

# Generated at 2022-06-17 05:11:54.730918
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test_write_changes', 'validate': 'echo %s'})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test_write_changes')


# Generated at 2022-06-17 05:12:07.600977
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 05:12:19.137090
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:25.257153
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = "test"
    changed = False
    assert check_file_attrs(module, changed, message) == ("test", False)
    module.params['owner'] = 'root'
    assert check_file_attrs(module, changed, message) == ("test and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 05:12:32.233960
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:36.286251
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': True}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:13:38.447586
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:13:47.195289
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:00.730656
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_contents = '''
# This is a test file
# It has some lines
# And some more lines
# And even more lines
'''
    with open(test_file, 'wb') as f:
        f.write(to_bytes(test_file_contents))


# Generated at 2022-06-17 05:14:06.483509
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:14:11.520096
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.atomic_move = lambda src, dest, unsafe_writes: True
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: True
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, False, "") == (message, True)


# Generated at 2022-06-17 05:14:21.412224
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.run_command = lambda cmd: (0, '', '')
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed, message = False, ''
    message, changed = check_

# Generated at 2022-06-17 05:14:31.985334
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pycompat24 import get_exception_only
    from ansible.module_utils.pycompat24 import get_func_args
    from ansible.module_utils.pycompat24 import get_func_argspec
    from ansible.module_utils.pycompat24 import get_func_kwargs
    from ansible.module_utils.pycompat24 import get_func_defaults
    from ansible.module_utils.pycompat24 import get_func_code

# Generated at 2022-06-17 05:14:37.901648
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.atomic_move = lambda tmpfile, path, unsafe_writes: None
    module.run_command = lambda validate: (0, '', '')
    write_changes(module, '', '')


# Generated at 2022-06-17 05:14:46.018131
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, '', '/tmp/test')
    module.params = {'validate': 'test %s', 'unsafe_writes': False}
    write_changes(module, '', '/tmp/test')
    module.params = {'validate': 'test %s', 'unsafe_writes': False}
    write_changes(module, '', '/tmp/test')
    module.params = {'validate': 'test %s', 'unsafe_writes': False}


# Generated at 2022-06-17 05:14:58.227469
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params = {'unsafe_writes': False}
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1
    assert module.run_command.call_args == ((('/tmp/bar',),), {})
    assert module.atomic_move.call_args == ((('/tmp/bar', '/tmp/bar', False),), {})



# Generated at 2022-06-17 05:17:18.644846
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')



# Generated at 2022-06-17 05:17:32.198122
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to