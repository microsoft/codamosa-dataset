

# Generated at 2022-06-17 05:07:53.469852
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': False}
    changed = False
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 05:08:02.903631
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-17 05:08:11.566652
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:08:19.423406
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:31.002055
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if not PY3:
        builtin_open = '__builtin__.open'
        FileNotFoundError = IOError
    else:
        builtin_open = 'builtins.open'
        FileNotFoundError = FileNotFoundError


# Generated at 2022-06-17 05:08:36.812787
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:42.657075
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:08:49.479006
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.atomic_move = lambda src, dest, unsafe_writes: True
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True

# Generated at 2022-06-17 05:08:53.836336
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1



# Generated at 2022-06-17 05:08:59.181810
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, b'', '/tmp/test')
    assert module.params['validate'] is None


# Generated at 2022-06-17 05:09:31.739321
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.parameters import check_file_attributes
    from ansible.module_utils.common.parameters import load_file_common_arguments
    from ansible.module_utils.common.parameters import set_default_for_parameters
    from ansible.module_utils.common.parameters import fail_json

# Generated at 2022-06-17 05:09:36.637252
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    with open(path, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = %s\n" % tmpdir)

    # Create a temporary role
    os.mkdir(os.path.join(tmpdir, 'role'))

# Generated at 2022-06-17 05:09:44.201423
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:56.721743
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': False}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:04.505566
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.params['path'] = '/tmp/test_check_file_attrs'
    module.params['unsafe_writes'] = True
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == "ownership, perms or SE linux context changed"
    os.remove(module.params['path'])



# Generated at 2022-06-17 05:10:17.843592
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['path'] = '/tmp/test_check_file_attrs'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0755'
    module.params['seuser'] = 'unconfined_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'tmp_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = False
    changed = False
    message = ''

# Generated at 2022-06-17 05:10:22.945822
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:10:30.443284
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']
    before = module.params['before']
    backup = module.params['backup']

# Generated at 2022-06-17 05:10:40.183381
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:10:49.549670
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = os.getcwd()
    module.atomic_move = lambda src, dest: True
    module.run_command = lambda cmd: (0, '', '')
    module.params = {'validate': None, 'unsafe_writes': False}
    contents = 'foo'
    path = 'bar'
    write_changes(module, contents, path)
    assert True



# Generated at 2022-06-17 05:11:24.808953
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:11:33.977357
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params

# Generated at 2022-06-17 05:11:43.709882
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest: None
    module.run_command = lambda cmd: (0, '', '')
    module.params = {'validate': None, 'unsafe_writes': False}
    contents = b'abc'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:11:49.734023
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test_write_changes', 'validate': 'echo %s'})
    write_changes(module, b'foo', '/tmp/test_write_changes')
    assert os.path.exists('/tmp/test_write_changes')
    assert open('/tmp/test_write_changes').read() == 'foo'
    os.unlink('/tmp/test_write_changes')


# Generated at 2022-06-17 05:11:56.626939
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:12:07.980181
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:22.811760
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile


# Generated at 2022-06-17 05:12:34.469456
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("The replace module is not supported on Python 2")

    # Make a temporary directory to work in
    tmpdir = tempfile.mkdtemp()
    # Make a temporary file to work with
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write some data to the temporary file

# Generated at 2022-06-17 05:12:44.413122
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', required=True),
        validate=dict(type='str', required=True),
        unsafe_writes=dict(type='bool', default=False),
    ))
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.tmpdir = '/tmp'
    write_changes(module, '', '/tmp/test')


# Generated at 2022-06-17 05:12:52.524026
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:14:01.084917
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = tempfile.gettempdir()

    path = '/tmp/test_write_changes'


# Generated at 2022-06-17 05:14:15.742951
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:25.385490
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:29.941002
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents



# Generated at 2022-06-17 05:14:40.066701
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:14:54.249128
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:15:07.258160
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
            encoding=dict(type='str', required=False, default='utf-8'),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )
    path = '/tmp/test_write_changes'
    contents = b'abc'
    write

# Generated at 2022-06-17 05:15:14.344187
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import re
    import json
    import tempfile
    import os
    import sys
    import pytest
    import re


# Generated at 2022-06-17 05:15:25.022933
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 05:15:32.797302
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to