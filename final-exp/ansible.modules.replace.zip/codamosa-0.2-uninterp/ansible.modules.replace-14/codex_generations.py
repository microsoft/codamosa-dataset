

# Generated at 2022-06-17 05:07:53.470027
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': 'test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:04.846075
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 05:08:14.698047
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 05:08:22.965054
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:27.937698
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.params = {'unsafe_writes': False}
    module.run_command = lambda cmd: (0, '', '')
    contents = to_bytes('test')
    path = '/tmp/test'
    write_changes(module, contents, path)
    assert module.params['unsafe_writes'] == False


# Generated at 2022-06-17 05:08:38.955585
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:08:44.040608
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:50.610894
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src, dest)
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, b'foo', os.path.join(module.tmpdir, 'bar'))
    assert os.path.exists(os.path.join(module.tmpdir, 'bar'))
    module.run_command = lambda cmd: (1, '', '')

# Generated at 2022-06-17 05:08:57.871060
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError

# Generated at 2022-06-17 05:09:08.662720
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:09:31.743063
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    import os
    import tempfile


# Generated at 2022-06-17 05:09:37.654084
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:44.695456
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:09:52.656825
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)


# Generated at 2022-06-17 05:10:03.487807
# Unit test for function write_changes
def test_write_changes():
    # Test for atomic_move
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'unsafe_writes': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
    })
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, '', '/tmp/test')
    # Test for validate
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'unsafe_writes': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
    })

# Generated at 2022-06-17 05:10:15.798409
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:10:26.836748
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    contents = b"test"
    path = "/tmp/test"
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read

# Generated at 2022-06-17 05:10:32.017593
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:10:37.635673
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.params = {'path': '/tmp/test', 'validate': 'test %s'}
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:10:46.635910
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.common.file import is_special
    from ansible.module_utils.common.file import is_writable
    from ansible.module_utils.common.file import is_readable
    from ansible.module_utils.common.file import is_directory
    from ansible.module_utils.common.file import is_fifo
    from ansible.module_utils.common.file import is_block_device

# Generated at 2022-06-17 05:11:21.936533
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:11:33.750305
# Unit test for function main

# Generated at 2022-06-17 05:11:40.725246
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:48.895021
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda cmd: (0, '', '')
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:11:58.301419
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import zip

# Generated at 2022-06-17 05:12:07.946661
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'unconfined_u', 'serole': 'object_r', 'setype': 'tmp_t', 'selevel': 's0'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:17.657014
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    contents = to_bytes("This is a test")
    path = "/tmp/test_write_changes"
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)



# Generated at 2022-06-17 05:12:28.513671
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:34.050065
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')



# Generated at 2022-06-17 05:12:44.636175
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:13:58.882745
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:14:06.973436
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            contents = dict(type='str', required=True),
            validate = dict(type='str'),
            unsafe_writes = dict(type='bool', default=False),
        ),
    )
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path).read() == contents
    os.remove(path)
    os.rmdir(module.tmpdir)


# Generated at 2022-06-17 05:14:19.655565
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import re
    import json
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six import iteritems

# Generated at 2022-06-17 05:14:29.779888
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:38.814737
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            contents = dict(required=True, type='str'),
            validate = dict(required=False, type='str'),
            unsafe_writes = dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    contents = to_bytes(module.params['contents'])
    path = module.params['path']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:14:49.019374
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.params['unsafe_writes'] = False
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    contents = 'test'
    path = '/tmp/test'
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:14:59.749033
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False, 'aliases': ['unsafe']}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = tempfile.gettempdir()

    path = '/path/to/file'
    contents = '# This is a test file'
    write_changes(module, contents, path)

    module.run_command = lambda *args, **kwargs: (1, '', '')

# Generated at 2022-06-17 05:15:10.997351
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-17 05:15:24.990322
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.file import Filesystem
    from ansible.module_utils.common.file import TemporaryDirectory
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:15:29.139987
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test.txt', 'unsafe_writes': True}, check_invalid_arguments=False)
    module.atomic_move = lambda src, dest: None
    module.run_command = lambda cmd: (0, '', '')
    write_changes(module, 'test', '/tmp/test.txt')
