

# Generated at 2022-06-17 05:07:57.584249
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:06.192484
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

   

# Generated at 2022-06-17 05:08:13.897759
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)

# Generated at 2022-06-17 05:08:18.251990
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:28.457203
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:35.498519
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:40.448795
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 05:08:46.920196
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:08:51.508231
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:08:58.285417
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:09:20.622430
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:31.675187
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:41.436051
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            contents=dict(required=True),
            validate=dict(required=False),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:09:50.608076
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:09:54.495882
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:03.494891
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: (src, dest, unsafe_writes)
    module.run_command = lambda cmd: (0, '', '')
    module.params = {'validate': None, 'unsafe_writes': False}
    contents = to_bytes('test')
    path = '/tmp/test'
    write_changes(module, contents, path)
    assert module.atomic_move.call_args[0] == (path + '.__new__', path, False)
    module.params['validate'] = 'echo %s'
    write_changes(module, contents, path)

# Generated at 2022-06-17 05:10:08.699809
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 05:10:15.751919
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:10:24.016089
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:10:36.716062
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:11:09.834066
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:11:20.177043
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = True
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 05:11:33.099140
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:11:40.944738
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.run_command = lambda cmd: (0, '', '')
    module.fail_json = lambda msg: None
    write_changes(module, to_bytes('test'), '/tmp/test')


# Generated at 2022-06-17 05:11:47.689150
# Unit test for function main
def test_main():
    # Test with no file
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()



# Generated at 2022-06-17 05:11:55.341281
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:05.596239
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = check_file_attrs(module, False, '')
    assert changed
    assert message == 'ownership, perms or SE linux context changed'
    changed, message = check_file_attrs(module, True, 'some message')
    assert changed
    assert message == 'some message and ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:12:16.401424
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:12:22.972427
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True, 'aliases': ['unsafe']}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = tempfile.gettempdir()
    write_changes(module, b'', '/tmp/test')
    assert os.path.exists('/tmp/test')
    os.remove('/tmp/test')


# Generated at 2022-06-17 05:12:33.608612
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'', '/tmp/test')
    assert module.params['validate'] is None
    module.params['validate'] = 'test %s'
    write_changes(module, b'', '/tmp/test')
    assert module.params['validate'] == 'test %s'

# Generated at 2022-06-17 05:13:30.120922
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-17 05:13:37.508705
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:13:46.734257
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:13:56.123600
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'test', 'group': 'test', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:14:02.514104
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'foo', '/tmp/bar')



# Generated at 2022-06-17 05:14:15.074001
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'ssh_home_t'
    module.params['selevel'] = 's0'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 05:14:28.526471
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import re
    import json

    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'testfile')
    with open(path, 'wb') as f:
        f.write(to_bytes(u'foo\nbar\n'))


# Generated at 2022-06-17 05:14:36.907813
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']
    before = module.params['before']
    backup = module.params['backup']

# Generated at 2022-06-17 05:14:42.913262
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:53.224599
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.tmpdir = '/tmp'
    contents = to_bytes('test')
    path = '/tmp/test'
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:16:43.987584
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.fail_json = lambda *args, **kwargs: None

    # Test valid
    write_changes(module, b'foo', '/tmp/foo')

    # Test invalid
    module.run_command = lambda *args, **kwargs: (1, '', '')
    write_changes(module, b'foo', '/tmp/foo')

    # Test validate without %s


# Generated at 2022-06-17 05:16:52.301475
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False
    }
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.load_file_common_arguments = lambda *args, **kwargs: {'path': '/etc/hosts'}
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True


# Generated at 2022-06-17 05:17:01.457310
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:17:11.557192
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:17:20.342580
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import re
    import json
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.urls
    import ansible.module_utils.wait_for
    import ansible.module_utils.network.common.utils
    import ansible.module_utils.network.common.config
    import ansible.module_utils.network.common.utils

# Generated at 2022-06-17 05:17:31.516712
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
