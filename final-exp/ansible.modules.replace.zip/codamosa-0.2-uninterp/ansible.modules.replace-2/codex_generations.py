

# Generated at 2022-06-17 05:07:54.798939
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:05.809045
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:08:15.826475
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import NoSSLError


# Generated at 2022-06-17 05:08:27.075444
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_path
    from ansible.module_utils.common.validation import check_type_raw

# Generated at 2022-06-17 05:08:36.492066
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    write_changes(module, contents, path)


# Generated at 2022-06-17 05:08:45.587107
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/test_check_file_attrs'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'tmp_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = True
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'

# Generated at 2022-06-17 05:08:53.887263
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, b'contents', '/path')
    assert module.run_command.call_count == 0
    assert module.atomic_move.call_count == 1
    assert module.atomic_move.call_args == ((b'/tmp/tmp.XXXXXXXXXX', '/path', False), {})


# Generated at 2022-06-17 05:08:58.704821
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = '/etc/hosts'
    regexp = '(\s+)old\.host\.name(\s+.*)?$'

# Generated at 2022-06-17 05:09:07.079792
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:18.188957
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': True}
    changed = False
    message = "test message"
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "test message and ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:09:43.040223
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False, 'required': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')

# Generated at 2022-06-17 05:09:54.082996
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.atomic_move = lambda src, dest, unsafe_writes: dest
    module.params = {'unsafe_writes': False}
    module.tmpdir = '/tmp'
    module.run_command = lambda cmd: (0, '', '')
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:10:03.453714
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    fd, ansible_module = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    shutil.copyfile(path, ansible_module)

    # Create a temporary ansible module arguments file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

# Generated at 2022-06-17 05:10:16.273328
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/test_file'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'var_log_t'
    module.params['selevel'] = 's0'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:23.703924
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:10:36.334177
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 05:10:40.451678
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/test_write_changes'
    contents = b'hello world'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:10:47.213351
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:10:51.535363
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:10:56.721945
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, '', '')
    module.fail_json = lambda x: None
    write_changes(module, b'', '/tmp/test')


# Generated at 2022-06-17 05:11:28.504779
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:11:35.388512
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    contents = b"test"
    path = "/tmp/test"
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, "rb") as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:11:43.901327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:11:48.723180
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:11:58.274944
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile


# Generated at 2022-06-17 05:12:08.962428
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs

# Generated at 2022-06-17 05:12:22.909157
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import filecmp
    import ansible.module_utils.basic
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.urls
    import ansible.module_utils.json
    import ansible.module_utils.yaml
    import ansible.module_utils.hashivault
    import ansible.module_utils.hashivault_common
    import ansible.module_utils.hvac

# Generated at 2022-06-17 05:12:31.237370
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    contents = b'abcdefghijklmnopqrstuvwxyz'
    path = '/tmp/test_write_changes'

# Generated at 2022-06-17 05:12:43.099945
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:56.037690
# Unit test for function check_file_attrs

# Generated at 2022-06-17 05:13:59.849170
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:06.483999
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:19.402594
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False),
            encoding=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False),
            validate=dict(type='str', required=False),
        ),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.atomic_move = MagicMock()
    module.tmp

# Generated at 2022-06-17 05:14:32.146215
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    message = "test"
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    assert message == "test and ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 05:14:40.346219
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': False}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
    os.remove(module.params['path'])



# Generated at 2022-06-17 05:14:55.538522
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:15:03.176591
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:15:12.304505
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:15:25.220656
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:15:34.250179
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'seuser': 'system_u',
                     'serole': 'object_r',
                     'setype': 'tmp_t',
                     'selevel': 's0',
                     'unsafe_writes': True}
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
