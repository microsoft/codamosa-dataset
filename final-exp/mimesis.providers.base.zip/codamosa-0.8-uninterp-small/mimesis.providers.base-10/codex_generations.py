

# Generated at 2022-06-25 20:18:45.260805
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale():
            pass
    except Exception as e:
        print(e)
        assert type(e) == ValueError


# Generated at 2022-06-25 20:18:47.876116
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en'):
        pass
    


# Generated at 2022-06-25 20:18:54.660786
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self):
            super().__init__()
            self.locale = ''
            pass
    test = Test()
    with test.override_locale('en') as p:
        assert p.locale == 'en'
    assert test.locale != 'en'



# Generated at 2022-06-25 20:18:59.972158
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    locale = 'en_US'
    with base_data_provider.override_locale(locale) as data_provider:
        print(data_provider.locale)
    print(base_data_provider.locale)

# Generated at 2022-06-25 20:19:07.649526
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)


    dp = DataProvider()
    print(dp.locale)

    with dp.override_locale(locale='zh'):
        print(dp.locale)

    print(dp.locale)


if __name__ == '__main__':
    # test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:12.917875
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test without parameter
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        base_data_provider_0._override_locale()


# Generated at 2022-06-25 20:19:16.824606
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locale) as _:
        assert getattr(base_data_provider_0, 'locale') == locale


# Generated at 2022-06-25 20:19:19.837937
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_obj_0 = BaseDataProvider()
    base_data_provider_obj_1 = BaseDataProvider()
    with base_data_provider_obj_0.override_locale():
        pass


# Generated at 2022-06-25 20:19:27.421215
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    context_manager_0 = data_provider_0.override_locale('lt')
    assert str(data_provider_0) == 'BaseDataProvider <lt>'
    with context_manager_0:
        pass

if __name__ == "__main__":
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:30.030671
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:19:57.590734
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_case_0():
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale('xx') as base_data_provider_1:  
            pass


# Generated at 2022-06-25 20:20:06.345232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Test for the exception.
    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError:
        pass
    # Test for the exception.
    try:
        with base_data_provider_0.override_locale('en'):
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:20:08.112835
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  base_data_provider_0 = BaseDataProvider()
  with base_data_provider_0.override_locale(locale='en'):
      pass


# Generated at 2022-06-25 20:20:21.451336
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method 'override_locale' of class BaseDataProvider."""

    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_2:
            base_data_provider_2.locale = 'fr'
    with base_data_provider_1.override_locale() as base_data_provider_3:
            base_data_provider_3.locale = 'fr'
    assert base_data_provider_0.locale == 'en'
    assert base_data_provider_1.locale == 'en'


# Generated at 2022-06-25 20:20:24.023112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:20:30.115258
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert base_data_provider_0.get_current_locale() == base_data_provider_1.get_current_locale()


# Generated at 2022-06-25 20:20:40.395297
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with contextlib.suppress(ValueError):
        with base_data_provider_1.override_locale('ru') as base_data_provider:
            assert base_data_provider.get_current_locale() == 'ru'
        assert base_data_provider_1.get_current_locale() == 'ru'


# Generated at 2022-06-25 20:20:50.064795
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test case 0 for BaseDataProvider.override_locale"""
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert isinstance(base_data_provider_1, BaseDataProvider)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:53.736687
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = base_data_provider_0.override_locale("ru")
    assert base_data_provider_1.get_current_locale() == "ru"



# Generated at 2022-06-25 20:20:59.266094
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    a = BaseDataProvider(locale='en')
    a._pull = lambda: True
    a._override_locale = lambda x: True
    
    with a.override_locale():
        assert True

# Generated at 2022-06-25 20:21:46.264553
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(base_data_provider_0.locale):
        pass


# Generated at 2022-06-25 20:21:57.626054
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    from mimesis.builtins import Person
    code = Code()
    person = Person()

    with person.override_locale('en'):
        assert str(person) == 'Person <en>'
        assert person.__str__() == 'Person <en>'
    with code.override_locale('es'):
        assert str(code) == 'Code <es>'
        assert person.__repr__() == 'Person <en>'
    with person.override_locale('ru'):
        assert code.__repr__() == 'Code <es>'
        assert person.__repr__() == 'Person <ru>'



# Generated at 2022-06-25 20:22:07.964888
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider
    import pytest
    from mimesis.typing import Seed

    russia = RussiaSpecProvider(seed = Seed(0))
    with russia.override_locale(locales.RU) as ru:
        assert ru.locale == locales.RU
    assert russia.locale == locales.RU
    with pytest.raises(ValueError) as excinfo:
        with russia.override_locale(locales.RU) as ru:
            assert ru.locale == locales.RU
    assert excinfo == None



# Generated at 2022-06-25 20:22:11.932705
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        base_data_provider_0.override_locale()


if __name__ == '__main__':
    test_case_0()

    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:16.848673
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale='ru')
    try:
        with base_data_provider.override_locale(locale='en'):
            assert base_data_provider._data
    except ValueError:
        print('ValueError: «{}» has not locale dependent'.format(
            base_data_provider.__class__.__name__))


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:24.606916
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale(locale = locale) as base_data_provider_1:
        assert base_data_provider_0.get_current_locale() == base_data_provider_1.get_current_locale()


# Generated at 2022-06-25 20:22:28.091091
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Check if the method override_locale of class BaseDataProvider
    # raises exception if the class does not have attribute locale
    try:
        test_case_0().override_locale()
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 20:22:37.857036
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    case = [
        {
            'args': (True,),
            'expected': True,
            'id': 0,
        },
        {
            'args': (0,),
            'expected': 0,
            'id': 1,
        },
        {
            'args': (None,),
            'expected': None,
            'id': 2,
        },
        {
            'args': (False,),
            'expected': False,
            'id': 3,
        },
    ]
    for test in case:
        with BaseDataProvider().override_locale() as current_locale:
            assert current_locale == test['expected'], \
                'Expected: {0}, but got: {1}'.format(
                    test['expected'],
                    current_locale
                )



# Generated at 2022-06-25 20:22:39.471390
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test for wrong type of parameter
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(1) as data:
        base_data_provider_0 = data

# Generated at 2022-06-25 20:22:49.720098
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.exceptions import UnsupportedLocale

    override_locale_0 = BaseDataProvider(locale='en', seed=None)

    try:
        with override_locale_0.override_locale('en'):
            pass
    except AttributeError:
        raise ValueError('«BaseDataProvider» has not locale dependent')

    try:
        with override_locale_0.override_locale('es'):
            pass
    except AttributeError:
        raise ValueError('«BaseDataProvider» has not locale dependent')

    try:
        with override_locale_0.override_locale('en-US'):
            pass
    except AttributeError:
        raise ValueError('«BaseDataProvider» has not locale dependent')


# Generated at 2022-06-25 20:23:47.251746
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with base_data_provider.override_locale():
        assert str(base_data_provider) == 'BaseDataProvider <en>'


base_data_provider = BaseDataProvider()
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 20:23:53.106197
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Empty initialization
    base_data_provider_0 = BaseDataProvider()
    # Attribute: locale
    origin_locale = getattr(base_data_provider_0, "locale", locales.DEFAULT_LOCALE)
    with base_data_provider_0.override_locale("jp") as x:
        # Attribute: locale
        assert getattr(x, "locale", locales.DEFAULT_LOCALE) == "jp"
        assert getattr(base_data_provider_0, "locale", locales.DEFAULT_LOCALE) == "jp"

    # Attribute: locale
    assert getattr(base_data_provider_0, "locale", locales.DEFAULT_LOCALE) == origin_locale

    # Empty initialization
    base_data_provider_

# Generated at 2022-06-25 20:24:07.124772
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with contextlib.suppress(ValueError):
        test_case_0().override_locale("e-kcHGcf2jFB")
    contextlib.suppress(ValueError)



# Generated at 2022-06-25 20:24:10.900821
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en'):
        assert base_data_provider.get_current_locale() == 'en'



# Generated at 2022-06-25 20:24:16.346753
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en'):
        locale_0 = base_data_provider_0.get_current_locale()
        assert locale_0 == 'en'


# Generated at 2022-06-25 20:24:28.213211
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # testing object instance with default params
    base_data_provider_1 = BaseDataProvider()
    # testing object instance with custom params
    base_data_provider_2 = BaseDataProvider(locale = "ar")
    # test with custom params
    exception_raised = False
    try:
        with base_data_provider_2.override_locale(locale = "ar"):
            pass
    except ValueError:
        exception_raised = True
    # exception should not be raised
    assert not exception_raised
    # test without params
    exception_raised = False
    try:
        with base_data_provider_1.override_locale():
            pass
    except ValueError:
        exception_raised = True
    # exception should not be raised
    assert not exception_raised
    # test with default

# Generated at 2022-06-25 20:24:33.708552
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en') as x:
        pass

if __name__ == '__main__':
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-25 20:24:41.286624
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()

# Generated at 2022-06-25 20:24:44.794773
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider.override_locale():
            pass
    except ValueError:
        assert True
    except Exception as exception:
        assert False, exception


# Generated at 2022-06-25 20:24:51.915208
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    t = BaseDataProvider()
    assert t.locale == locales.DEFAULT_LOCALE

    with t.override_locale('ru_RU') as t_sub:
        assert t_sub.locale == 'ru_RU'

    assert t.locale == locales.DEFAULT_LOCALE



# Generated at 2022-06-25 20:25:41.553347
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from contextlib import contextmanager
    from mimesis.builtins.locales import RU

    class BaseDataProviderTest(BaseDataProvider):
        pass

    base_data_provider_test = BaseDataProviderTest()

    @contextmanager
    def override_locale():
        yield base_data_provider_test

    try:
        with base_data_provider_test.override_locale(locale=RU):
            pass

    except ValueError as e:
        assert str(e) == '«BaseDataProviderTest» has not locale dependent'

    base_data_provider_test.locale = locales.DEFAULT_LOCALE

    with base_data_provider_test.override_locale(locale=RU):
        assert base_data_provider_test.locale == RU

# Generated at 2022-06-25 20:25:48.542388
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = base_data_provider_0.override_locale('ru')
    assert base_data_provider_1.locale == 'ru'
    assert base_data_provider_0.locale == 'en'
    base_data_provider_2 = base_data_provider_1.override_locale()
    assert base_data_provider_1.locale == 'ru'
    assert base_data_provider_2.locale == 'en'


# Generated at 2022-06-25 20:25:55.996938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test case for override_locale method of class BaseDataProvider."""
    # Create an object of class BaseDataProvider
    base_data_provider_1 = BaseDataProvider()
    # Creating a context manager
    with base_data_provider_1.override_locale(locale='ru'):
        assert base_data_provider_1.get_current_locale() == 'ru'
    assert base_data_provider_1.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-25 20:25:57.158578
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    instance = BaseDataProvider()
    with instance.override_locale():
        pass

# Generated at 2022-06-25 20:26:05.956834
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()

# Generated at 2022-06-25 20:26:15.511012
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Created instance of class BaseDataProvider
    # with parameters:
    #     locale = locales.DEFAULT_LOCALE
    #     seed = None
    base_data_provider_1 = BaseDataProvider()

    # Check if method override_locale of BaseDataProvider
    # can be called without parameters
    try:
        with base_data_provider_1.override_locale():
            pass
    except TypeError:
        raise AssertionError()
    except ValueError:
        raise AssertionError()

    # Check if method override_locale of BaseDataProvider
    # can be called with parameters:
    #     locale = locales.EN
    try:
        with base_data_provider_1.override_locale():
            pass
    except TypeError:
        raise AssertionError()


# Generated at 2022-06-25 20:26:18.533666
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        assert base_data_provider_0.locale == 'ru'


# Generated at 2022-06-25 20:26:20.054569
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()

# Generated at 2022-06-25 20:26:21.796217
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en'):
        pass


# Generated at 2022-06-25 20:26:27.092843
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    try:
        with base_data_provider_1.override_locale():
            pass
    except ValueError:
        pass
    else:
        raise Exception('ValueError has not been raised.')
    try:
        with base_data_provider_1.override_locale(locale='zh_CN'):
            pass
    except ValueError:
        pass
    else:
        raise Exception('ValueError has not been raised.')


# Generated at 2022-06-25 20:28:09.337538
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.providers.address
    # Override locale in context manager:
    with BaseDataProvider.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.__str__() == 'BaseDataProvider <ru>'



# Generated at 2022-06-25 20:28:14.281918
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locales_0 = BaseDataProvider()
    with locales_0.override_locale('ru'):
        assert locales_0.get_current_locale() == 'ru'

    with locales_0.override_locale('ru'):
        assert locales_0.get_current_locale() == 'ru'
        with locales_0.override_locale('en'):
            assert locales_0.get_current_locale() == 'en'
        assert locales_0.get_current_locale() == 'ru'
    assert locales_0.get_current_locale() == 'en'

test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:28:18.425941
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Pass a parameter that isn't a string
    with base_data_provider_0.override_locale(123):
        pass

    # Pass a string that's not a valid enum item
    with base_data_provider_0.override_locale('fudge'):
        pass


# Generated at 2022-06-25 20:28:21.314386
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    with BaseDataProvider().override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:28:24.095994
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    datetime = Datetime()
    locale = 'en'
    with datetime.override_locale(locale) as dt:
        x = dt.time()
    assert x is not None


# Generated at 2022-06-25 20:28:26.880218
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:28:29.086212
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale("en"):
        # not implemented yet
        pass
