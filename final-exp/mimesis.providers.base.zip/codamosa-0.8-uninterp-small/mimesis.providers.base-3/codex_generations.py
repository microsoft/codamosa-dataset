

# Generated at 2022-06-25 20:18:45.625499
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        # Unit test for method get_current_locale of class BaseDataProvider
        assert base_data_provider_0.get_current_locale() == 'en'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:18:52.788330
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        origin_locale = base_data_provider_0.get_current_locale()
        locale = 'en'
        base_data_provider_0._override_locale(locale)
        assert base_data_provider_0.get_current_locale() == locale
        base_data_provider_0._override_locale(origin_locale)
        assert base_data_provider_0.get_current_locale() == origin_locale


# Generated at 2022-06-25 20:18:53.685050
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider() # TODO: Write proper test


# Generated at 2022-06-25 20:18:56.311176
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider().override_locale(locale='ru'):
            return
    except ValueError:
        return
    except Exception:
        assert False
assert True



# Generated at 2022-06-25 20:19:00.503904
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale(locale='en'):
        pass


# Generated at 2022-06-25 20:19:04.024957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    if hasattr(base_data_provider_1, 'override_locale'):
        assert callable(base_data_provider_1.override_locale)

# Generated at 2022-06-25 20:19:07.456587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    x = False
    try:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale("ru"):
            pass
    except Exception:
        x = True
    assert x


# Generated at 2022-06-25 20:19:09.300806
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    assert base_data_provider_0.override_locale('pt') == None


# Generated at 2022-06-25 20:19:13.452040
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_0 = BaseDataProvider()
    with provider_0.override_locale(locale=locales.EN) as arg_0:
        assert isinstance(arg_0, BaseDataProvider)



# Generated at 2022-06-25 20:19:16.824146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider(seed=None)
    try:
        with base_data_provider_1.override_locale(locale=None):
            pass
    except ValueError:
        assert False
    else:
        assert True

# Generated at 2022-06-25 20:19:28.435577
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-25 20:19:30.738623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with pytest.raises(ValueError):
        base_data_provider_2 = BaseDataProvider()
        base_data_provider_2.override_locale('')


# Generated at 2022-06-25 20:19:32.700101
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert BaseDataProvider().override_locale() is None


# Generated at 2022-06-25 20:19:38.598214
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as base_data_provider_1:
        str(base_data_provider_1)
        base_data_provider_1.get_current_locale()
        base_data_provider_1._pull()
        base_data_provider_1._setup_locale()
    # Test attribute (aspect) random after calling method override_locale
    assert base_data_provider_1.random == random


# Generated at 2022-06-25 20:19:42.936555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale="ru").override_locale(locale="en") as b:
        assert b.get_current_locale() == "en"


# Generated at 2022-06-25 20:19:49.944842
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.RU):
        pass
    base_data_provider_1 = BaseDataProvider(locale=locales.PT_BR)
    base_data_provider_1.override_locale(locale=locales.PT_BR)
    base_data_provider_2 = BaseDataProvider(locale=locales.PT_BR)
    base_data_provider_2.override_locale()


# Generated at 2022-06-25 20:19:58.745345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    obj = BaseDataProvider()
    with obj.override_locale() as item:
        assert True
    # AssertionError
    with obj.override_locale('it-IT') as item:
        assert True
    # AttributeError
    with obj.override_locale(locales.DEFAULT_LOCALE) as item:
        assert True
    # ValueError
    with obj.override_locale() as item:
        assert True
    # ValueError



# Generated at 2022-06-25 20:20:01.987679
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:20:08.231411
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider()
    with provider.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'ru-RU'

# Generated at 2022-06-25 20:20:11.025965
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    locale = locales.EN
    with base_data_provider.override_locale(locale=locale) as dp:
        assert(dp.get_current_locale(), locale)


# Generated at 2022-06-25 20:20:38.553270
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # 1. Normal case
    base_data_provider_1 = BaseDataProvider(locale='ru')

    with base_data_provider_1.override_locale('en'):
        print(base_data_provider_1)



# Generated at 2022-06-25 20:20:42.535293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    expected = 'New locale'
    new_locale = BaseDataProvider(locale=expected).override_locale()

    assert new_locale.get_current_locale() == expected


test_case = test_case_0

# Generated at 2022-06-25 20:20:47.141196
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    context_0 = base_data_provider_0.override_locale()
    assert context_0.__class__.__name__ == 'BaseProvider'

# Generated at 2022-06-25 20:20:52.013283
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('locale'):
        assert getattr(base_data_provider_0, 'locale', 'default') == 'locale'



# Generated at 2022-06-25 20:20:55.618887
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('es') as provider:
        assert provider.get_current_locale() == 'es'
    assert BaseDataProvider().get_current_locale() == 'en'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:00.350555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:21:03.791601
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with contextlib.closing(base_data_provider_0.override_locale()) as c:
        pass


# Generated at 2022-06-25 20:21:07.269533
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:21:17.750655
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    with provider.override_locale() as p:
        assert p == provider
        assert p.locale == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN) as p:
        assert p == provider
        assert p.locale == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p == provider
        assert p.locale == locales.RU

    with provider.override_locale(locales.RU + '/by') as p:
        assert p == provider
        assert p.locale == locales.RU + '/by'

    with provider.override_locale(locales.RU + '/by') as p:
        assert p == provider

# Generated at 2022-06-25 20:21:24.037188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._override_locale = lambda locale: locale
    if True:
        assert base_data_provider_0.override_locale('ru') == 'ru'
    else:
        return False
    return True


# Generated at 2022-06-25 20:22:15.609338
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'test_locale'
    base_data_provider_0 = BaseDataProvider()
    expected_result_1 = 'test_base_data_provider'
    generated_result_1 = base_data_provider_0.override_locale(locale).__str__()
    assert generated_result_1 == expected_result_1


# Generated at 2022-06-25 20:22:19.769384
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        pass


# Generated at 2022-06-25 20:22:29.614699
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.locale = 'en'
    base_data_provider_0._pull.cache_clear()
    base_data_provider_0._pull()
    base_data_provider_0._override_locale('ru')
    base_data_provider_0._pull.cache_clear()
    base_data_provider_0._pull()
    base_data_provider_0._override_locale('en')
    base_data_provider_0._pull.cache_clear()
    base_data_provider_0._pull()
    base_data_provider_0._override_locale('en')
    base_data_provider_0._pull.cache_clear()
    base_

# Generated at 2022-06-25 20:22:35.204667
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    # In case of validity of assertion
    # then this code is poorly covered.
    # According to mutation test only 13,3% of code is covered.
    # with base_data_provider.override_locale(locale='unknown_locale'):
    #     pass



# Generated at 2022-06-25 20:22:36.654366
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


# Generated at 2022-06-25 20:22:47.722967
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider
    bdp = RussiaSpecProvider()
    with bdp.override_locale('ru'):
        assert(bdp.code.postcode() == '100772')
    with bdp.override_locale('de'):
        assert(bdp.code.postcode() == '10115')

# Generated at 2022-06-25 20:22:49.906710
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale('en'):
        assert base_data_provider_1.locale == 'en'


# Generated at 2022-06-25 20:22:54.582693
# Unit test for method override_locale of class BaseDataProvider

# Generated at 2022-06-25 20:22:59.890341
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale():
        pass

if __name__ == '__main__':
    print(test_case_0.__doc__)
    test_case_0()
    print('Method «override_locale»:')
    print(test_BaseDataProvider_override_locale.__doc__)
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:23:02.912930
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locale_0 = locales.EN
    with base_data_provider_0.override_locale(locale_0) as base_data_provider_1:
        assert base_data_provider_0 == base_data_provider_1


# Generated at 2022-06-25 20:25:05.062370
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:14.272081
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    print("Test case for method override_locale of class BaseDataProvider")

    base_data_provider = BaseDataProvider()

    with base_data_provider.override_locale():
        locale = base_data_provider.locale

    print("Locale: {}".format(locale))


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:17.268350
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru-RU'):
        pass


# Generated at 2022-06-25 20:25:22.375530
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with BaseDataProvider.override_locale(bdp, locales.EN) as bdp:
        assert bdp.get_current_locale() == locales.EN

# Generated at 2022-06-25 20:25:26.068679
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        pass

# Generated at 2022-06-25 20:25:30.674739
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='ru')
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:25:40.496196
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locale_0 = ''
    locale_1 = 'ru'
    locale_2 = 'RU'
    locale_3 = 'en-US'
    locale_4 = 'ru-ru'
    locale_5 = 'zh_CN'
    locale_6 = 'zh-CN'
    locale_7 = 'zh-cn'
    locale_8 = 'zh_cn'
    locale_9 = 'pt'
    locale_10 = 'PT'
    locale_11 = 'pt-BR'
    locale_12 = 'en'
    locale_13 = 'zh'
    locale_14 = 'en-US'
    locale_15 = 'es'
    locale_16 = 'zh-cn'
    locale_17 = 'zh_CN'


# Generated at 2022-06-25 20:25:46.265132
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en', ):
        base_data_provider_0.get_current_locale()
        value_0 = base_data_provider_0.get_current_locale()
        if value_0 != 'en':
            raise Exception('Value should be en')


# Generated at 2022-06-25 20:25:50.841450
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale() as data_provider:
        assert base_data_provider.get_current_locale() == data_provider.get_current_locale()
        assert base_data_provider.get_current_locale() == locale

# Generated at 2022-06-25 20:25:55.441629
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider(locale = 'en', seed = 'Kx')
    with base_data_provider_1.override_locale(locale = 'en'):
        assert base_data_provider_1.locale == 'en'
