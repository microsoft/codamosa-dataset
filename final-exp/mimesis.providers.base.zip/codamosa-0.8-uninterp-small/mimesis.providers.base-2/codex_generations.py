

# Generated at 2022-06-25 20:18:42.869997
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert False


# Generated at 2022-06-25 20:18:49.417827
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        assert base_data_provider_0.locale == 'en'
    assert base_data_provider_0.locale == 'en'
    with base_data_provider_0.override_locale('en'):
        assert base_data_provider_0.locale == 'en'
    assert base_data_provider_0.locale == 'en'

# Generated at 2022-06-25 20:18:56.975083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale('ru-RU') as temp_provider:
        result = temp_provider.locale
    # Assert
    assert result == 'ru-RU'
    print('Tests for method override_locale of class BaseDataProvider')



# Generated at 2022-06-25 20:19:01.295744
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en_US'):
        assert bdp.get_current_locale() == "en_US"
    assert bdp.get_current_locale() == "en"

# Generated at 2022-06-25 20:19:03.398822
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale():
        pass


# Generated at 2022-06-25 20:19:06.926174
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale("  "):
        assert base_data_provider_1.get_current_locale() == "en"



# Generated at 2022-06-25 20:19:08.055146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as data_provider:
        pass

# Generated at 2022-06-25 20:19:11.688680
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale('en') as provider:
        pass


# Generated at 2022-06-25 20:19:15.482605
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # If a context manager is used in a with statement, it returns an object
    # that can be assigned to a variable in the with statement’s as clause
    with BaseDataProvider.override_locale() as base_data_provider:
        assert base_data_provider


# Generated at 2022-06-25 20:19:28.049019
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    # Test for invalid locale
    try:
        with base_data_provider.override_locale('asd'):
            pass
    except ValueError as e:
        assert e.args[0] == '«BaseDataProvider» has not locale dependent'
    else:
        assert False, 'Unexpected behaviour'

    # Test for valid locale
    with base_data_provider.override_locale('en'):
        assert base_data_provider.get_current_locale() == 'en'

    # Check if locale changed after ``with`` block
    assert base_data_provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-25 20:19:42.490641
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test if exception is raised when locale is not locale dependent
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0:
        pass


# Generated at 2022-06-25 20:19:47.304593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider(locale='en')
    with dp.override_locale('ru'):
        assert dp.locale == 'ru'
    assert dp.locale == 'en'


# Generated at 2022-06-25 20:19:55.885072
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale="ru"):
        pass
    try:
        with base_data_provider_0.override_locale(locale="ru"):
            raise Exception()
    except Exception:
        pass


# Generated at 2022-06-25 20:20:09.094069
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  from unittest import TestCase
  from mimesis.data import Address, Address
  base_data_provider_0 = BaseDataProvider()
  with TestCase().assertRaises(ValueError):
    base_data_provider_0.override_locale('en')
  class TestAddress(Address):
    def __init__(self, seed: Seed = None, locale: str = locales.DEFAULT_LOCALE):
      super().__init__(locale, seed)
      self.locale = locale
  address_0 = TestAddress()
  with address_0.override_locale('en') as test_address_0:
    test_case_0(test_address_0)

# Generated at 2022-06-25 20:20:17.922927
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    override_locale_0 = BaseDataProvider().override_locale
    try:
        with override_locale_0('en') as locale:
            for _ in range(10):
                exception_0 = None
                try:
                    foo_0 = locale
                except TypeError as exception_0:
                    pass
                assert exception_0 is None
    except ValueError:
        pass
    except TypeError:
        pass


# Generated at 2022-06-25 20:20:21.338697
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale('fr') as o:
        assert o._data['address']['country'] == 'France'



# Generated at 2022-06-25 20:20:24.821394
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data = BaseDataProvider()
    with base_data.override_locale() as l:
        l.get_current_locale()

# Generated at 2022-06-25 20:20:28.833281
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale():
        assert bdp.get_current_locale() == bdp.override_locale.__defaults__[0]


# Generated at 2022-06-25 20:20:30.659090
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()

# Generated at 2022-06-25 20:20:38.133599
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.EN):
        str_0 = str(base_data_provider_0)
        assert str_0 == 'BaseDataProvider <en>'



# Generated at 2022-06-25 20:21:03.399048
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.DEFAULT_LOCALE):
        pass
    return



# Generated at 2022-06-25 20:21:13.598032
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale(locale='en') is not None
    assert base_data_provider.override_locale(locale='ru') is not None
    assert base_data_provider.override_locale(locale='ru-RU') is not None
    assert base_data_provider.override_locale(locale='ru_RU') is not None
    assert base_data_provider.override_locale(locale='ru_ru') is not None

# Generated at 2022-06-25 20:21:17.336828
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('cs'):
        assert BaseDataProvider().locale == 'cs'


# Generated at 2022-06-25 20:21:25.743757
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    # This method is for testing purposes only.

    # Context manager which allows overriding current locale.
    #
    # Temporarily overrides current locale for
    # locale-dependent providers.
    #
    # :param locale: Locale.
    # :return: Provider with overridden locale.
    #
    #
    # with base_data_provider_0.override_locale(locale=locales.RU):
    #     pass
    #
    #
    # provider = BaseDataProvider()
    # with provider.override_locale(locale=locales.RU):
    #     assert provider.get_current_locale() == locales.RU
    # assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-25 20:21:30.655526
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import BaseDataProvider
    sample_ = BaseDataProvider('en')
    with sample_.override_locale('en') as _sample_:
        pass


# Generated at 2022-06-25 20:21:38.369373
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import NonEnumerableError
    from mimesis.enums import Gender, Person

    base_data_provider_0 = BaseDataProvider(locale='uk')
    with base_data_provider_0.override_locale(locale='ru'):
        with base_data_provider_0.override_locale(locale='uk'):
            assert base_data_provider_0.get_current_locale() == 'uk'
        assert base_data_provider_0.get_current_locale() == 'ru'
    assert base_data_provider_0.get_current_locale() == 'uk'



# Generated at 2022-06-25 20:21:48.128244
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print("test_BaseDataProvider_override_locale")
    base_data_provider_0 = BaseDataProvider()

    base_data_provider_0.locale = locales.EN
    base_data_provider_0._datafile = "regions.json"
    base_data_provider_0._pull()

    assert base_data_provider_0.get_current_locale() == "en"
    assert base_data_provider_0._data["us"]["divisions"]["states"]["name"] == "United States"

    base_data_provider_0.locale = locales.RU
    base_data_provider_0._pull()

    assert base_data_provider_0.get_current_locale() == "ru"
    assert base_data

# Generated at 2022-06-25 20:21:52.601350
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    context_manager_1 = base_data_provider_1.override_locale('en')


# Generated at 2022-06-25 20:21:56.346349
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale('ru'):
            pass
    except Exception:
        pass



# Generated at 2022-06-25 20:22:00.421737
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    b = BaseDataProvider()
    with b.override_locale('en'):
        pass     #Test passed



# Generated at 2022-06-25 20:23:00.475977
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    expected_output = '«{}» has not locale dependent'
    base_data_provider_0 = BaseDataProvider()
    # https://stackoverflow.com/questions/47825564/typeerror-object-with-buffer-protocol-required
    with base_data_provider_0.override_locale(locale='ru') as bdp0:
        if bdp0.locale == 'ru':
            assert True
        else:
            assert False
    try:
        with base_data_provider_0.override_locale(locale='ru') as bdp0:
            a = None
    except ValueError as e:
        if e.args[0] == expected_output.format(BaseDataProvider.__name__):
            assert True
        else:
            assert False

# Unit

# Generated at 2022-06-25 20:23:08.914024
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en'):
        assert bdp.get_current_locale() == 'en'
    # with bdp.override_locale('ru'):
    #     assert bdp.get_current_locale() == 'ru'

# Generated at 2022-06-25 20:23:10.157062
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en-US'):
        pass


# Generated at 2022-06-25 20:23:19.098507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.base import locales

    base_data_provider_1 = BaseDataProvider(locale = locales.EN)

    # On error the method should raise a ValueError
    try:
        with base_data_provider_1.override_locale(locale = locales.EN) as base_data_provider_2:
            pass
    except ValueError:
        return
    else:
        raise Exception()


# Generated at 2022-06-25 20:23:22.761483
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('en'):
        pass


# Generated at 2022-06-25 20:23:33.924429
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    origin_locale = 'en'
    try:
        base_data_provider_1 = BaseDataProvider()
        locale = 'en'
        try:
            base_data_provider_0._override_locale(locale)
            base_data_provider_0._pull()
        finally:
            base_data_provider_0._override_locale(origin_locale)
    finally:
        base_data_provider_0._override_locale(origin_locale)

# Generated at 2022-06-25 20:23:35.413083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    with(base_data_provider_0.override_locale('ru')):
        pass


# Generated at 2022-06-25 20:23:38.169420
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locales.RU) as data_provider:
        assert data_provider.locale == locales.RU

# Generated at 2022-06-25 20:23:45.902016
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    expected_obj = {
        'first_name': 'Иван',
        'last_name': 'Иванов',
    }
    with Person().override_locale('ru'):
        obj = Person().name()
    assert expected_obj == obj


# Generated at 2022-06-25 20:23:48.633025
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert (BaseDataProvider().override_locale('ru') is not None)
    assert (BaseDataProvider().override_locale('ru'))


# Generated at 2022-06-25 20:25:38.452070
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    base_data_provider = BaseDataProvider()
    expected = '<contextlib._GeneratorContextManager object at 0x000001B66F3F3DC8>'

    # Act
    actual = base_data_provider.override_locale()

    # Assert
    assert str(actual) == expected


# Generated at 2022-06-25 20:25:40.466914
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_0 = locales.EN
    with BaseDataProvider().override_locale(locale=locale_0) as value_0:
        assert value_0.get_current_locale() == locale_0

# Generated at 2022-06-25 20:25:45.458233
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp_0 = BaseDataProvider()
    with bdp_0.override_locale() as bdp_1:
        assert bdp_1.locale == locales.EN

    locale = locales.RU
    with bdp_0.override_locale(locale=locale) as bdp_1:
        assert bdp_1.locale == locale

# Generated at 2022-06-25 20:25:50.517428
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale="en_GB"):
        assert base_data_provider.get_current_locale() == "en_GB"
    assert base_data_provider.get_current_locale() != "en_GB"


# Generated at 2022-06-25 20:25:55.133598
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    obj = BaseDataProvider()
    with obj.override_locale() as res:
        assert obj is res
        assert obj.locale == res.locale == 'en'

    # assert obj.locale is not res.locale
    assert obj.locale == res.locale == 'en'

# Generated at 2022-06-25 20:25:57.930197
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale() as data_provider_1:
        assert data_provider_1 is data_provider_0


# Generated at 2022-06-25 20:26:11.505743
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.filesystem import FileSystem
    from mimesis.builtins.geography import Geography
    fs = FileSystem()
    geo = Geography()

    with fs.override_locale('nl'):
        assert fs.get_extension() == 'txt'

    with geo.override_locale('ru'):
        assert geo.get_city() == 'Москва'


# Generated at 2022-06-25 20:26:20.074050
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_list_0 = ['zh']
    locale_list_1 = ['ru', 'fr', 'it']
    locale_list_2 = ['ru', 'fr', 'it']
    locale_list_3 = ['ru', 'fr', 'de']
    locale_list_4 = ['ru', 'fr', 'it']
    locale_list_5 = ['ru', 'fr', 'it']
    with BaseDataProvider.override_locale():
        pass
    with BaseDataProvider.override_locale():
        pass
    with BaseDataProvider.override_locale(locale_list_0[0]):
        pass
    with BaseDataProvider.override_locale(locale_list_1[0]):
        pass

# Generated at 2022-06-25 20:26:24.809422
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Raises ValueError:
    try:
        with BaseDataProvider().override_locale():
            pass
    except ValueError as e:
        print(e)
    # Passed
    try:
        with BaseDataProvider().override_locale(locale=locales.EN):
            pass
    except ValueError as e:
        print(e)


if __name__ == "__main__":
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:26:28.364882
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    base_data_provider_1 = BaseDataProvider(locale)
    print(base_data_provider_1)
    with base_data_provider_1.override_locale(locale) as provider:
        assert provider.locale == locale
    print(base_data_provider_1)
