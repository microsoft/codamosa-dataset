

# Generated at 2022-06-25 20:18:41.289645
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_locale = ''
    test_provider = BaseDataProvider()

    with test_provider.override_locale(test_locale):
        assert test_provider.locale == test_locale



# Generated at 2022-06-25 20:18:43.418587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale():
        pass


# Generated at 2022-06-25 20:18:50.464000
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale method."""
    base_data_provider_0 = BaseDataProvider()
    # Test case with exception
    with pytest.raises(ValueError) as exception_info:
        with base_data_provider_0.override_locale() as base_data_provider_1:
            locale = getattr(base_data_provider_1, 'locale', locales.DEFAULT_LOCALE)
            assert locale == 'en'
    assert "has not locale dependent" in str(exception_info.value)


# Generated at 2022-06-25 20:18:55.112504
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale("en"):
        pass

# Generated at 2022-06-25 20:18:59.003262
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    with BaseDataProvider().override_locale(locale=locales.EN):
        base_data_provider_0 = BaseDataProvider()



# Generated at 2022-06-25 20:19:08.729312
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import FileSystem, OperatingSystem, Process
    from mimesis.enums import Locale

    locale_filesystem = FileSystem(locale=Locale.EN)
    locale_os = OperatingSystem(locale=Locale.EN)
    locale_process = Process(locale=Locale.EN)

    with locale_filesystem.override_locale(Locale.RU), \
            locale_os.override_locale(Locale.RU), \
            locale_process.override_locale(Locale.RU):
        assert locale_filesystem.get_current_locale() == Locale.RU
        assert locale_os.get_current_locale() == Locale.RU
        assert locale_process.get_current_locale() == Locale.RU



# Generated at 2022-06-25 20:19:17.423624
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    try:
        with BaseDataProvider().override_locale(locale):
            pass
    except ValueError as e:
        msg = e.args[0]
    except Exception as e:
        msg = 'Exception raised: {}: {!r}'.format(type(e).__name__, e.args)
    else:
        msg = 'No exception raised'
    assert msg == 'Exception raised: ValueError: «BaseDataProvider» has not locale dependent', msg

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:25.172868
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        base_data_provider_0.locale = ''
        assert base_data_provider_0.locale == ''
        assert base_data_provider_0.locale == base_data_provider_0.locale

# Generated at 2022-06-25 20:19:30.656884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """
    Tests method BaseDataProvider.override_locale()
    """
    fake = BaseDataProvider()

    context_manager = fake.override_locale(locale=locales.DEFAULT_LOCALE)
    with context_manager as context_manager:
        assert context_manager == fake
    # ...

    context_manager = fake.override_locale()
    with context_manager as context_manager:
        assert context_manager == fake
    # ...


# Generated at 2022-06-25 20:19:32.710058
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale() as base_data_provider:
        pass


# Generated at 2022-06-25 20:19:50.782114
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Init
    base_data_provider = BaseDataProvider()
    # Functionality
    with base_data_provider.override_locale(locales.EN):
        # () -> None
        assert callable(base_data_provider.override_locale)
        # () -> None
        assert callable(base_data_provider.get_current_locale)
    # () -> None
    assert callable(base_data_provider.override_locale)
    # () -> None
    assert callable(base_data_provider.get_current_locale)
    with base_data_provider.override_locale(locales.EN):
        assert base_data_provider.get_current_locale() == locales.EN
    # () -> None

# Generated at 2022-06-25 20:19:53.158338
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:19:58.431356
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider().override_locale
    BaseDataProvider().override_locale("ru")
    BaseDataProvider().override_locale("en")
    BaseDataProvider().override_locale("en")


# Generated at 2022-06-25 20:20:04.292187
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        base_data_provider_0.get_current_locale() == 'ru'
    # base_data_provider_0.override_locale(None)
    # base_data_provider_0.override_locale(base_data_provider_0.get_current_locale())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:20:08.146916
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale() as base_data_provider_0:
        pass

# Generated at 2022-06-25 20:20:22.036843
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en_GB', seed=42)
    base_data_provider_1 = BaseDataProvider(locale='en_GB')
    with base_data_provider_1.override_locale('en_US'):
        if 'en_US' != base_data_provider_1.locale:
            print('Unit test of method override_locale of class BaseDataProvider failed')
            return
    if 'en_GB' != base_data_provider_1.locale:
        print('Unit test of method override_locale of class BaseDataProvider failed')
        return

# Generated at 2022-06-25 20:20:28.236842
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Creating a random string
    value = 'Hello World!'

    import random
    class BaseProviderStub:
        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes.

            :param seed: Seed for random.
                When set to `None` the current system time is used.
            """
            self.seed = seed
            self.random = random

            if seed is not None:
                self.reseed(seed)


# Generated at 2022-06-25 20:20:31.042622
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_1._override_locale('ru')
    assert base_data_provider_1.locale == 'ru'



# Generated at 2022-06-25 20:20:40.520624
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        print(base_data_provider_0)
    print(base_data_provider_0)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:45.779670
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    base_data_provider_0 = BaseDataProvider()

    # Act
    with base_data_provider_0.override_locale('es'):
        # Assert
        pass


# Generated at 2022-06-25 20:21:16.839765
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    from mimesis.builtins import Locale
    with Person('pl').override_locale('en') as p:
        assert p.name() == 'Josh Tremblay'
        assert p.surname() == 'Cassin'
        assert p.username() == 'adam_deckow'
        assert p.email(domains=['example.com']) == 'erin.mante@example.com'
        assert p.telephone(mask='+XXX XX XXXXXXXX') == '+422 23 07782026'
        assert p.tax_id_number() == 'N40-667-0800'
        assert p.identifier(mask='XXXX-XXXX-XXXXX') == '4444-4444-444444'

# Generated at 2022-06-25 20:21:25.424422
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'
    base_data_provider_0 = BaseDataProvider()
    
    orig_locale = base_data_provider_0.get_current_locale()
    with base_data_provider_0.override_locale(locale) as provider:
        assert provider.get_current_locale() == locale

    assert orig_locale == base_data_provider_0.get_current_locale()


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:27.541924
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()


# Generated at 2022-06-25 20:21:33.554082
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    with BaseDataProvider.override_locale('ru'):
        assert True
    with BaseDataProvider.override_locale('ru'):
        assert True

if __name__ == '__main__':
     test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:35.848917
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method."""
    # pylint: disable=protected-access

    base_data_provider_0 = BaseDataProvider()


# Generated at 2022-06-25 20:21:40.697685
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locales.EN):
        pass

# Generated at 2022-06-25 20:21:43.912196
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass

# Generated at 2022-06-25 20:21:48.600550
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    try:
        assert isinstance(base_data_provider_1.override_locale(), type(base_data_provider_1))
    except AssertionError:
        pass


# Generated at 2022-06-25 20:21:52.258217
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    assert hasattr(bdp, 'override_locale') == True


# Generated at 2022-06-25 20:21:55.869721
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:22:23.441778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # init
    base_data_provider = BaseDataProvider()

    # execute
    with base_data_provider.override_locale():
        pass

    # verify
    assert True


# Generated at 2022-06-25 20:22:28.321889
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        assert base_data_provider_0._pull is BaseDataProvider._pull
        assert base_data_provider_0.get_current_locale() == 'en'


# Generated at 2022-06-25 20:22:33.624231
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert(base_data_provider_1.get_current_locale() == 'en')

# Generated at 2022-06-25 20:22:35.032329
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BASE_DATA_PROVIDER = BaseDataProvider()
    locale = ''
    try:
        with BASE_DATA_PROVIDER.override_locale(locale):
            pass
    except AttributeError:
        pass


# Generated at 2022-06-25 20:22:40.778136
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        return base_data_provider_0.get_current_locale() == 'en'

# Generated at 2022-06-25 20:22:50.186013
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import City
    from mimesis.enums import Gender
    from mimesis.enums import Language
    from mimesis.enums import Region
    provider = City('ru')
    _city = provider.city()
    provider.override_locale('en')
    city = provider.city()
    assert isinstance(city, str)
    assert _city is not city
    _city = provider.city()
    provider.override_locale('de')
    city = provider.city()
    assert isinstance(city, str)
    assert _city is not city
    _city = provider.city()
    provider.override_locale('es')
    city = provider.city()
    assert isinstance(city, str)
    assert _city is not city
    _city = provider.city

# Generated at 2022-06-25 20:22:52.004915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass



# Generated at 2022-06-25 20:22:54.200998
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider(locale='', seed=None)
        with base_data_provider_0.override_locale('en'):
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:22:57.020109
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    result_bool_0 = BaseDataProvider()
    with result_bool_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:23:03.002899
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    base_data_provider_0.override_locale('en')
    print(base_data_provider_0.get_current_locale())
    # Output: en


# Generated at 2022-06-25 20:24:07.124552
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_01 = BaseDataProvider()
    with base_data_provider_01.override_locale() as provider_01:
        locale_01 = provider_01.get_current_locale()

    base_data_provider_02 = BaseDataProvider()
    with base_data_provider_02.override_locale() as provider_02:
        locale_02 = provider_02.get_current_locale()

    # Test expected result
    assert locale_01 == locale_02


# Generated at 2022-06-25 20:24:11.425809
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale() as base_data_provider_0:
            assert True
    except ValueError:
        assert True


# Generated at 2022-06-25 20:24:17.334424
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale() as re:
        output_1 = re
    output_2 = re
    assert (output_1 is not output_2)

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:24:21.694507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.DEFAULT_LOCALE) as temp:
        pass


# Generated at 2022-06-25 20:24:27.422103
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    with Person('en').override_locale('ru') as ru_person:
        ru_person.first_name(gender=Gender.FEMALE)
        ru_person.first_name(gender=Gender.MALE)
        ru_person.last_name()

# Generated at 2022-06-25 20:24:38.818540
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    locale = locales.EN

    # Test of behaviour for calling BaseDataProvider.override_locale with valid string value
    base_data_provider_1 = BaseDataProvider(locale)
    base_data_provider_2 = BaseDataProvider(locale)

    test_case_0()
    test_case_1()

    # Test of behaviour for calling BaseDataProvider.override_locale with valid string value
    base_data_provider_1.override_locale(locale)
    base_data_provider_2.override_locale(locale)

    # Test of behaviour for calling BaseDataProvider.override_locale with valid string value
    base_data_provider_1.override_locale(locale)


# Generated at 2022-06-25 20:24:41.806341
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert callable(BaseDataProvider().override_locale()) is True


# Generated at 2022-06-25 20:24:44.464936
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_1.override_locale = \
        base_data_provider_1.override_locale(locale='en')


# Generated at 2022-06-25 20:24:46.373966
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale("en"):
            pass

    except ValueError:
        pass


# Generated at 2022-06-25 20:24:51.031800
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    for _ in range(0, 10):
        with base_data_provider_0.override_locale(locale='ru'):
            pass


# Generated at 2022-06-25 20:26:20.381460
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale():
            # Tests if: raise ValueError(
            # '«{}» has not locale dependent'.format(self.__class__.__name__))
            pass


# Generated at 2022-06-25 20:26:27.710532
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # 1. Normal case
    with BaseDataProvider().override_locale(locale = locales.EN):
        pass

    # 2. Normal case
    with BaseDataProvider().override_locale(locale = 'en'):
        pass

    # 3. Normal case
    with BaseDataProvider().override_locale('en'):
        pass

    # 4. Normal case
    with BaseDataProvider(locale = 'en').override_locale('en'):
        pass

    # 5. Normal case
    with BaseDataProvider().override_locale(locale = ''):
        pass

    # 6. Normal case
    with BaseDataProvider().override_locale('en-US'):
        pass

    # 7. Normal case

# Generated at 2022-06-25 20:26:29.722649
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with base_data_provider_0.override_locale('ru'):
        assert base_data_provider_0.get_current_locale() == 'ru'
    


# Generated at 2022-06-25 20:26:36.821441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.base import EN, RU

    provider = Address()
    with BaseDataProvider.override_locale(EN):
        provider.address()
    with BaseDataProvider.override_locale(RU):
        provider.address()

# Generated at 2022-06-25 20:26:39.314333
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locale = locales.EN
    with BaseDataProvider.override_locale(base_data_provider_0, locale):
        assert True


# Generated at 2022-06-25 20:26:41.073103
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider() as base_data_provider_0:
            print(base_data_provider_0.get_current_locale())
        pass
    except ValueError:
        pass
    pass



# Generated at 2022-06-25 20:26:42.977222
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Unit test for method override_locale of class BaseDataProvider
    base_data_provider_0 = BaseDataProvider()
    data = base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:26:48.997344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('fr') as base_data_provider_0:
        base_data_provider_0.get_current_locale()
        locale = 'fr'
        assert locale == base_data_provider_0.get_current_locale()


# Generated at 2022-06-25 20:26:52.511277
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()

    with bdp.override_locale(locale='en'):
        assert bdp.get_current_locale() == 'en'
    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-25 20:26:55.743080
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Case 0
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('es') as base_data_provider_1:
        assert base_data_provider_1.locale == 'es'
