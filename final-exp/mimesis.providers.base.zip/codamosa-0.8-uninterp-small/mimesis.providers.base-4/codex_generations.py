

# Generated at 2022-06-25 20:18:41.306402
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as base_data_provider_0:
        assert isinstance(base_data_provider_0, BaseDataProvider)


# Generated at 2022-06-25 20:18:45.083433
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import builtins
    from mimesis.data import countries
    with BaseDataProvider.override_locale(locale = 'uk') as provider:
        provider.get_current_locale() == 'uk'



# Generated at 2022-06-25 20:18:52.108629
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_base_data_provider_0 = BaseDataProvider(locale=locales.EN)
    locale = locales.EN
    with test_base_data_provider_0.override_locale(locale=locale) as _:
        assert (test_base_data_provider_0.locale, test_base_data_provider_0.random, test_base_data_provider_0._data, test_base_data_provider_0._data_dir) == (locale, random, {}, Path(__file__).parent.parent.joinpath('data'))


# Generated at 2022-06-25 20:18:58.541375
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    import tempfile
    import unittest

    class TestBaseDataProvider(unittest.TestCase):

        def setUp(self):
            self.b = BaseDataProvider()

        def test_override_locale(self):
            for locale in locales.SUPPORTED_LOCALES:
                with self.b.override_locale(locale) as tmp:
                    locale_ = getattr(tmp, 'locale', locales.DEFAULT_LOCALE)
                    self.assertEqual(locale_, locale)

                locale_ = getattr(self.b, 'locale', locales.DEFAULT_LOCALE)
                self.assertEqual(locale_, locales.DEFAULT_LOCALE)

    unittest.main()


# Generated at 2022-06-25 20:18:59.510223
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()

# Generated at 2022-06-25 20:19:09.099458
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Case 0
    with BaseDataProvider(locale='ru') as provider_0:
        print(provider_0.get_current_locale())
        with provider_0.override_locale('ru_RU'):
            print(provider_0.get_current_locale())

    # Case 1
    with BaseDataProvider(locale='en') as provider_1:
        print(provider_1.get_current_locale())
        with provider_1.override_locale('en_CA'):
            print(provider_1.get_current_locale())
        print(provider_1.get_current_locale())

    # Case 2
    with BaseDataProvider(locale='en') as provider_2:
        print(provider_2.get_current_locale())


# Generated at 2022-06-25 20:19:11.579849
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale="de")
    with base_data_provider.override_locale(locale="ru"):
        assert(getattr(base_data_provider, 'locale', locales.DEFAULT_LOCALE) == "ru")

# Generated at 2022-06-25 20:19:14.043570
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:19:19.514306
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._pull = lambda: None

    with base_data_provider_0.override_locale('hi-IN'):
        pass


# Call all unit tests for this class
test_case_0()
test_BaseDataProvider_override_locale()

# No output should be generated from these calls
print(base_data_provider_0)

# Generated at 2022-06-25 20:19:28.890725
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        # Create an instance of the class
        base_data_provider_1 = BaseDataProvider()

        # Create a generator of the context manager
        base_data_provider_override_locale_generator = base_data_provider_1.override_locale()

        # Create an instance of the class
        base_data_provider_2 = next(base_data_provider_override_locale_generator)

        # Tests that the context manager works as expected
        assert True
    except:
        assert False


# Generated at 2022-06-25 20:19:52.418108
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp_inst = BaseDataProvider()
    assert isinstance(bdp_inst, BaseDataProvider)


# Generated at 2022-06-25 20:20:03.053685
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # With the context manager
    with BaseDataProvider() as bdp:
        try:
            assert bdp.locale == locales.DEFAULT_LOCALE
        except UnsupportedLocale:
            assert False
        locale = 'en-gb'
        bdp.locale = locale
        try:
            assert bdp.locale == locale
        except UnsupportedLocale:
            assert False
    # Without the context manager
    bdp = BaseDataProvider()
    try:
        assert bdp.locale == locales.DEFAULT_LOCALE
    except UnsupportedLocale:
        assert False
    locale = 'en-au'
    bdp.locale = locale
    try:
        assert bdp.locale == locale
    except UnsupportedLocale:
        assert False


# Generated at 2022-06-25 20:20:09.556587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:15.871339
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    for class BaseDataProvider
    method override_locale
    '''
    base_data_provider_0 = BaseDataProvider()

    helpers_0 = base_data_provider_0.override_locale()

    helpers_0.get_current_locale()


# Generated at 2022-06-25 20:20:21.884020
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    person_0 = Person()
    person_1 = Person('es')
    with person_0.override_locale('es') as p:
        assert p.name() == person_1.name()
    with person_0.override_locale('en') as p:
        assert p.name() == person_0.name()


# Generated at 2022-06-25 20:20:28.151301
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider's override_locale method."""
    base_data_provider_9 = BaseDataProvider()
    class_str = "BaseDataProvider"
    class_func = base_data_provider_9.override_locale
    class_locale = base_data_provider_9.locale
    class_introductory = base_data_provider_9._data

    # @contextlib.contextmanager
    # def override_locale(self, locale: str = locales.EN,
    #                     ) -> Generator[BaseDataProvider, None, None]:
    #     """Context manager which allows overriding current locale.
    #
    #     Temporarily overrides current locale for
    #     locale-dependent providers.
    #
    #     :param locale: Locale.
    #     :return: Provider

# Generated at 2022-06-25 20:20:32.727981
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale() as p:
        assert (p is bdp)


if __name__ == '__main__':
    for case in [
        'test_case_0',
        'test_BaseDataProvider_override_locale',
    ]:
        func = globals()[case]
        print('Running {}'.format(func.__name__))
        func()
        print('Done.')

# Generated at 2022-06-25 20:20:36.757865
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru'):
        assert BaseDataProvider().get_current_locale() == 'ru'


# Generated at 2022-06-25 20:20:40.387989
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with base_data_provider_0.override_locale('locale'):
            pass
    except ValueError:
        pass

    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError:
        pass
 
if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:43.067765
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    for k in [0]:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale():
            continue


# Generated at 2022-06-25 20:21:07.563228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    origin_locale = 'en'
    locale = 'ru'

    # This method should have no impact when not overriding anything
    base_data_provider_0 = BaseDataProvider(origin_locale)  # test

    # This should override current locale and pull data for new locale
    with base_data_provider_0.override_locale(locale) as data_provider:
        # test
        assert data_provider.get_current_locale() == locale
        assert data_provider._pull.cache_info().hits > 0
        assert data_provider._pull.cache_info().misses > 0
        assert data_provider._pull.cache_info().currsize > 0



# Generated at 2022-06-25 20:21:13.197481
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create test object
    base_data_provider_0 = BaseDataProvider()
    # Create test context manager
    result = base_data_provider_0.override_locale()
    assert isinstance(result, contextlib.contextmanager)


# Generated at 2022-06-25 20:21:17.473355
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    with BaseDataProvider().override_locale(locale) as p:
        assert p.get_current_locale() == locale

# Generated at 2022-06-25 20:21:23.604350
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locales.LOCALE_SEPARATOR = "-"
    with base_data_provider_0.override_locale("pl-pl"):
        assert True
    
    
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:21:26.337466
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert_exception_was_raised(ValueError, test_case_0)

# Generated at 2022-06-25 20:21:31.244389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Overrides current locale with passed and pull data for new locale
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_1._override_locale('ru')


# Generated at 2022-06-25 20:21:32.685767
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 20:21:37.424791
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en'):
        assert bdp.get_current_locale() == 'en'
    with bdp.override_locale('ru'):
        assert bdp.get_current_locale() == 'ru'
    with bdp.override_locale('en'):
        assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-25 20:21:47.725518
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        assert base_data_provider_0.locale == 'ru'
    assert base_data_provider_0.locale == 'en'
    # Exception raises
    try:
       BaseProvider().override_locale('ru')
    except Exception as e:
        assert e.args[0] == "«BaseProvider» has not locale dependent"
        pass
    # Exception raises
    try:
       BaseDataProvider().override_locale(locale = 'ru')
    except Exception as e:
        assert e.args[0] == "«BaseDataProvider» has not locale dependent"
        pass


# Generated at 2022-06-25 20:21:50.394533
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print('Start of test_BaseDataProvider_override_locale')
    global base_data_provider_0
    with base_data_provider_0.override_locale('en'):
        print(base_data_provider_0.locale)
    print('End of test_BaseDataProvider_override_locale')


# Generated at 2022-06-25 20:22:36.923889
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider('ru', 175691723)
    # with BaseDataProvider.override_locale(base_data_provider_0, locale='ru',
    #                                     seed=175691723):
    #     assert base_data_provider_0.locale == 'ru'


# Generated at 2022-06-25 20:22:42.503978
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with contextlib.suppress(ValueError):
        with base_data_provider_0.override_locale() as m:
            pass



# Generated at 2022-06-25 20:22:48.424921
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    locale = locales.EN
    with base_data_provider_0.override_locale(locale) as p:
        assert p is base_data_provider_0

    with base_data_provider_0.override_locale(locale) as p:
        assert p is base_data_provider_0
    


# Generated at 2022-06-25 20:22:58.955734
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale('en')
    # print(str(base_data_provider))
    # print(base_data_provider.get_current_locale())
    assert '<en>' in str(base_data_provider)
    assert 'en' == base_data_provider.get_current_locale()

if __name__ == '__main__':
    '''
    test_case_0()
    test_BaseDataProvider_override_locale()
    '''

# Generated at 2022-06-25 20:23:08.913614
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    #   BaseDataProvider - создание экземпляра класса BaseDataProvider
    #   в качестве параметра передается строка 'en'
    base_data_provider_1 = BaseDataProvider('en')
    #   contextmanager - используется для переопределения локали провайдера
    #   в качестве параметров переда

# Generated at 2022-06-25 20:23:11.034620
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    L0 = BaseDataProvider()
    with L0.override_locale(locale='ru'):
        pass

if __name__ == "__main__":
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:23:12.798067
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass



# Generated at 2022-06-25 20:23:14.646758
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale('locale'):
            pass

# Generated at 2022-06-25 20:23:19.879473
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    my_provider_0 = BaseDataProvider()
    str_0 = ''
    expected_result_0 = 'BaseDataProvider <de>'
    # Overrides current locale with passed and pull data for new locale.
    with my_provider_0.override_locale(str_0):
        str_1 = str(my_provider_0)
        assert str_1 == expected_result_0


# Generated at 2022-06-25 20:23:24.333945
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass

# Generated at 2022-06-25 20:25:15.465239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Check for exception in the context manager
    with base_data_provider_0.override_locale() as _:
        pass
    # Check for exception in the context manager
    with base_data_provider_0.override_locale():
        pass

# Generated at 2022-06-25 20:25:17.881527
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert BaseDataProvider(locale='pt').override_locale()

# Generated at 2022-06-25 20:25:25.549608
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass
    # base_data_provider_1 = BaseDataProvider()
    # with base_data_provider_1.override_locale:
    #     pass
    #     # print("test_BaseDataProvider_override_locale contains an example of how to use"
    #           " the method «override_locale» of class «BaseDataProvider» ")



# Generated at 2022-06-25 20:25:32.394011
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import numpy as np
    base_data_provider_0 = BaseDataProvider(locale = "Haiti")
    with base_data_provider_0.override_locale('en') as base_data_provider_0:
        assert base_data_provider_0.get_current_locale() == 'en'


# Generated at 2022-06-25 20:25:38.067749
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'
    with base_data_provider_0.override_locale(locale) as base_data_provider:
        assert base_data_provider == base_data_provider_0
        assert base_data_provider.get_current_locale() == 'ru'
    assert base_data_provider_0.get_current_locale() == 'en'

# Generated at 2022-06-25 20:25:41.191476
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-25 20:25:45.316627
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale():
            pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:49.277440
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale('en') as self_0:
            pass
    except ValueError:
        pass
    except Exception:
        pass

# Generated at 2022-06-25 20:25:55.652888
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale():
        assert bdp.get_current_locale() == locales.DEFAULT_LOCALE
    with bdp.override_locale(locales.EN):
        assert bdp.get_current_locale() == locales.EN
    with bdp.override_locale(locales.RU):
        assert bdp.get_current_locale() == locales.RU

# Generated at 2022-06-25 20:26:05.957102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    base_data_provider = BaseDataProvider('en')
    with base_data_provider.override_locale('en') as b:
        assert b.get_current_locale() == locale
    assert base_data_provider.get_current_locale() == locale