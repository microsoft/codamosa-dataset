

# Generated at 2022-06-25 20:18:41.721189
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'


# Test to run after BaseDataProvider.__init__

# Generated at 2022-06-25 20:18:51.425847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import BaseDataProvider
    from mimesis.builtins import Person
    from mimesis.typing import JSON

    data_provider = BaseDataProvider(locale='ru')
    person = Person(locale='ru')

    with data_provider.override_locale(locale='en'):
        assert data_provider.get_current_locale() == 'en'
        assert person.get_current_locale() == 'en'

    assert data_provider.get_current_locale() == 'ru'
    assert person.get_current_locale() == 'ru'

    # Test context manager without `with`
    data_provider.override_locale(locale='en')

    assert data_provider.get_current_locale() == 'en'

   

# Generated at 2022-06-25 20:18:57.464471
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Cryptographic
    from mimesis.builtins import Person

    with BaseDataProvider.override_locale(locale='ru') as provider:
        person = Person('ru')
        person.full_name

    with BaseDataProvider.override_locale(locale='ru') as provider:
        # this Person instance uses a new locale (ru),
        # after executing the code block, the locale reverts to en
        person = Person()
        person.full_name

    cryptographic = Cryptographic()

    with cryptographic.override_locale(locale='ru') as provider:
        cryptographic.uuid()
    assert isinstance(cryptographic, Cryptographic)


# Generated at 2022-06-25 20:19:00.982665
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Make the assertion below
    with base_data_provider_0.override_locale(locale='en'):
        assert True


# Generated at 2022-06-25 20:19:09.331962
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_2 = base_data_provider_1.override_locale
    # test_case_0 = base_data_provider_2()
    # Unit test for method _pull of class BaseDataProvider
    # test_case_1 = base_data_provider_1._pull()
    # assert test_case_1 == json.load(open(__file__).parent.parent.joinpath('data').joinpath(base_data_provider_1.locale))
    test_case_2 = base_data_provider_1.get_current_locale()
    assert test_case_2 == base_data_provider_1.locale

# Generated at 2022-06-25 20:19:11.126519
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:19:13.893673
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    assert repr(base_data_provider_1.override_locale()) == 'ContextDecorator()'



# Generated at 2022-06-25 20:19:23.527394
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert (base_data_provider_1 is base_data_provider_0)
        assert (base_data_provider_1.locale is 'en')
        assert (base_data_provider_0.locale is 'en')
    assert (base_data_provider_0.locale is 'en')
    with base_data_provider_0.override_locale('ru') as base_data_provider_2:
        assert (base_data_provider_2 is base_data_provider_0)
        assert (base_data_provider_2.locale is 'ru')

# Generated at 2022-06-25 20:19:31.548052
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        assert base_data_provider_0.get_current_locale() == 'en'
        assert base_data_provider_0._datafile == ''
    assert base_data_provider_0.get_current_locale() == 'en'
    assert base_data_provider_0._datafile == ''
    assert base_data_provider_1.get_current_locale() == 'en'
    assert base_data_provider_1._datafile == ''

# Generated at 2022-06-25 20:19:39.833758
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_0 = BaseDataProvider(locale='de')
    base_data_provider_0.locale = 'de'
    with base_data_provider_0.override_locale(locale='de') as temp:
        assert temp.locale == 'de'
    # Unit test for method seed of class BaseProvider
    base_provider_0 = BaseProvider(seed=112)
    base_provider_0.reseed(seed=0.0)
    # Unit test for method __init__ of class BaseDataProvider
    base_data_provider_1 = BaseDataProvider(locale='de', seed=0.0)
    base_data_provider_1.locale = 'de'
    base_data_provider_1.locale = 'de'
    # Unit test

# Generated at 2022-06-25 20:20:03.791308
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider:
        assert base_data_provider == base_data_provider_0
        assert base_data_provider.locale == base_data_provider_0.locale

# Generated at 2022-06-25 20:20:10.850075
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    try:
        with base_data_provider_0.override_locale('it'):
            base_data_provider_0._pull('address.json')
            data = base_data_provider_0._data
    except Exception as e:
        assert False, f'Exception {e}'

    assert data['zh']['cities']['abbreviations']['rome'] == 'RM', \
        'Failed to override locale'

# Generated at 2022-06-25 20:20:16.019788
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale(locale='en'):
            pass

    except ValueError:
        pass



# Generated at 2022-06-25 20:20:21.376242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.providers.date_time
    with mimesis.providers.date_time.DateTime('en-US').override_locale('ar'):
        assert mimesis.providers.date_time.DateTime('en-US').get_current_locale() == 'ar'


# Generated at 2022-06-25 20:20:27.857905
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Mock object of class BaseDataProvider
    base_data_provider_0 = BaseDataProvider()
    # Use instance method _override_locale of base_data_provider_0
    base_data_provider_0._override_locale(locale=locales.EN)
    # Verify attribute locale of base_data_provider_0
    assert base_data_provider_0.locale == 'en'

# Generated at 2022-06-25 20:20:31.279092
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.EN):
        pass


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:40.198481
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_2:
        print(str(base_data_provider_2))


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:53.874703
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__(locale='ru-RU')

    provider = TestProvider()

    with provider.override_locale('en-US') as p:
        assert p.get_current_locale() == 'en-US'
    assert provider.get_current_locale() == 'ru-RU'

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'ru-RU'

    with provider.override_locale('') as p:
        assert p.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'ru-RU'



# Generated at 2022-06-25 20:21:05.924270
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from pprint import pprint

    def can_override_locale():
        class FakeProvider(BaseDataProvider):
            def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                         seed: Seed = None) -> None:
                super().__init__(locale=locale, seed=seed)

        fake_provider_0 = FakeProvider()

        try:
            with fake_provider_0.override_locale('ru') as ru_provider:
                ru_provider
        except ValueError:
            pprint('Expect an error here')

    can_override_locale()


# Generated at 2022-06-25 20:21:15.629216
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test with default locale
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as data_provider_0:
        assert data_provider_0.locale == 'en'

    # Test with custom locale
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='ru') as data_provider_0:
        assert data_provider_0.locale == 'ru'

# Test for method _setup_locale of class BaseDataProvider

# Generated at 2022-06-25 20:21:42.608886
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Setup
    base_data_provider_0 = BaseDataProvider()
    # Exercise
    with base_data_provider_0.override_locale() as base_data_provider_0:
        # Verify
        assert base_data_provider_0 is not None


# Generated at 2022-06-25 20:21:45.398562
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en'):
        pass


# Generated at 2022-06-25 20:21:53.093719
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    print('Testing method «override_locale» of class «BaseDataProvider»')

    # Testing of «override_locale» with wrong argument
    with BaseDataProvider().override_locale(1):
        raise ValueError('Test of «override_locale» of class «BaseDataProvider» failed')



# Generated at 2022-06-25 20:21:56.315160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale("locale") as data_provider:
        locale_0 = data_provider.get_current_locale()
        assert locale_0 == "locale"

# Generated at 2022-06-25 20:22:01.736961
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locale='ru_RU'):
        assert BaseDataProvider.get_current_locale(BaseDataProvider) == 'ru_RU'


# Generated at 2022-06-25 20:22:06.058831
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locale = locales.EN
    with base_data_provider_0.override_locale(locale=locale):
        pass


# Generated at 2022-06-25 20:22:13.940718
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Stationery(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            self.data = {
                'en': ['pencil', 'eraser', 'marker', 'pen'],
                'ru': ['карандаш', 'ластик', 'маркер', 'ручка']
            }
            self.locale = locale
            self.random = random

        def get_stationery(self):
            return self.random.choice(self.data[self.locale])

    provider = Stationery()
    provider

    with provider.override_locale(locales.RU):
        provider.get_stationery()
        pass


# Generated at 2022-06-25 20:22:21.145824
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Case 0
    with BaseDataProvider().override_locale(locale='en'):
        pass

    # Case 1
    # Provider doesn't have locale dependent
    try:
        with BaseDataProvider().override_locale(locale='en'):
            pass
    except ValueError:
        pass


test_case_0()

# Generated at 2022-06-25 20:22:23.962230
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('uk') as dp:
        assert dp.locale == 'uk'

# Generated at 2022-06-25 20:22:27.577285
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Check exception raise when no attribute
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale():
            pass
    

# Generated at 2022-06-25 20:22:54.565178
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    provider = BaseDataProvider()
    with provider.override_locale(locale=locales.EN):
        pass


# Generated at 2022-06-25 20:22:56.740775
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.locale = 'fr-BE'
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:23:02.490897
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Test if override_locale method is callable
    base_data_provider = BaseDataProvider()

    if type(base_data_provider.override_locale()) == BaseDataProvider:
        assert True
    else:
        assert False

# Generated at 2022-06-25 20:23:08.913822
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale="ru-UA")
    with base_data_provider_0.override_locale(locale="fr-FR"):
        pass


# Generated at 2022-06-25 20:23:13.005592
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru'):
        assert BaseDataProvider().get_current_locale() == 'ru'


# Generated at 2022-06-25 20:23:18.001727
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale():
        assert base_data_provider_0.get_current_locale() == 'en', 'Could not override locale'


# Generated at 2022-06-25 20:23:27.583559
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale=locales.EN, seed=None)
    # [override_locale.contextmanager]
    with base_data_provider_0.override_locale(locale=locales.DEFAULT_LOCALE):
        # [ValueError]
        # Does not have locale dependent.
        base_data_provider_0._override_locale(locale="")


# Generated at 2022-06-25 20:23:33.924542
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    import pytest
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider

    p0 = BaseDataProvider()

    with pytest.raises(TypeError):
        p0.override_locale(locale=locale)


# Generated at 2022-06-25 20:23:38.721568
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from contextlib import ExitStack
    base_data_provider_0 = BaseDataProvider()
    # Raise ValueError with message «<module> has not locale dependent»
    with ExitStack() as stack:
        stack.enter_context(base_data_provider_0.override_locale())

# Generated at 2022-06-25 20:23:45.040618
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with contextlib.closing(base_data_provider_0.override_locale('en')) as context_manager_0:
        print(context_manager_0)


# Generated at 2022-06-25 20:24:45.842438
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:24:53.349634
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale=locales.DEFAULT_LOCALE, seed=None)
    try:
        assert base_data_provider_0.override_locale(locales.EN) is not None
    except Exception:
        pass
    try:
        assert base_data_provider_0.override_locale() is not None
    except Exception:
        pass

# Generated at 2022-06-25 20:24:55.785289
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test raises
    try:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale():
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:24:58.499979
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    currency = BaseDataProvider.override_locale()
    assert currency.data == {}

# Generated at 2022-06-25 20:25:05.062836
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale="en"):
        assert base_data_provider_0.get_current_locale() == "en"
    assert base_data_provider_0.get_current_locale() == "en"


# Generated at 2022-06-25 20:25:10.286117
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale('ru'):
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:25:15.679365
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Arrange
    base_data_provider_test_obj = BaseDataProvider()
    locale = 'en'

    # Act
    with base_data_provider_test_obj.override_locale(locale):

        # Assert
        assert base_data_provider_test_obj.get_current_locale() == locale

# Generated at 2022-06-25 20:25:22.792950
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.geography import Geography
    with Geography().override_locale() as new_locale:
        pass
    with Geography().override_locale() as new_locale:
        pass
    return new_locale


# Generated at 2022-06-25 20:25:25.680191
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as provider:
        assert provider.get_current_locale() == 'en'


# Generated at 2022-06-25 20:25:30.747161
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale(locale="en") as result:
            pass

# Generated at 2022-06-25 20:27:06.833754
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = ''
    try:
        with BaseDataProvider().override_locale(locale) as provider:
            pass
    except Exception as e:
        assert type(e) is ValueError


# Generated at 2022-06-25 20:27:11.899411
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print('Test case for method override_locale of class BaseDataProvider')
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        print('\tOverride locale to en')
    with base_data_provider_0.override_locale('zh'):
        print('\tOverride locale to zh')
    with base_data_provider_0.override_locale():
        print('\tOverride locale to default')
    print('\tCurrent locale:', base_data_provider_0.locale)

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:27:12.781183
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()


# Generated at 2022-06-25 20:27:16.577952
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('pt-BR'):
        assert base_data_provider_0.get_current_locale() == 'pt-br'
    assert base_data_provider_0.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-25 20:27:20.612323
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    languages = locales.SUPPORTED_LOCALES
    base_data_provider_0 = BaseDataProvider()
    locale = 'it'

    overridden_locale_0 = base_data_provider_0.override_locale(locale)
    try:
        with overridden_locale_0 as overridden_locale_0:
            assert overridden_locale_0.locale == locale
    except ValueError:
        pass


# Generated at 2022-06-25 20:27:26.490723
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Prepare for test
    base_data_provider_0 = BaseDataProvider(locale='fr', seed=8)
    # Execute test
    try:
        with base_data_provider_0.override_locale('de') as returned:
            # Check returned value
            assert returned is base_data_provider_0
    except ValueError as returned:
        # Check returned value
        assert returned.args[0] == '«BaseDataProvider» has not locale dependent'
test_BaseDataProvider_override_locale()


# Generated at 2022-06-25 20:27:29.782475
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    bdp._setup_locale = lambda x: None
    bdp._override_locale = lambda x: None
    bdp.override_locale()

# Generated at 2022-06-25 20:27:31.966775
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'


# Generated at 2022-06-25 20:27:34.738444
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale='in'):
        assert base_data_provider_1


# Generated at 2022-06-25 20:27:38.234155
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create an instance of class BaseDataProvider
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale("en_GB") as p:
        assert p.get_current_locale() == "en_GB"
    assert base_data_provider.get_current_locale() != "en_GB"
