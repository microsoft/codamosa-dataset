

# Generated at 2022-06-25 20:18:44.323466
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_types = {'Hello': 'greeting'}

    class DataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(seed=seed)
            self._types = test_types

        def __getattr__(self, item):
            return self._types[item]

    dp = DataProvider(locale=locales.DEFAULT_LOCALE, seed=1234)
    with dp.override_locale(locales.EN) as dp:
        greeting = dp.greeting
        assert greeting == 'Hello'

# Generated at 2022-06-25 20:18:51.787216
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()
    base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:18:53.484597
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en') as provider:
        assert provider == base_data_provider

# Generated at 2022-06-25 20:18:55.381780
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider('en')
    with base_data_provider.override_locale('ru'):
        print(base_data_provider.get_current_locale())

# Generated at 2022-06-25 20:18:59.734225
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    assert (base_data_provider_0.override_locale
        == "Context manager which overrides current locale for locale-dependent providers.")

# Generated at 2022-06-25 20:19:04.354046
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert bdp.get_current_locale() == 'en'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:19:11.416205
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_1 = locales.DEFAULT_LOCALE
    provider_0 = BaseDataProvider(locale=locale_1)
    locale_2 = locales.DEFAULT_LOCALE
    with provider_0.override_locale(locale=locale_2):
        assert provider_0.get_current_locale() == locale_2
    with provider_0.override_locale(locale=locale_2):
        assert provider_0.get_current_locale() == locale_2
    with provider_0.override_locale(locale=locale_2):
        assert provider_0.get_current_locale() == locale_2
    with provider_0.override_locale(locale=locale_2):
        assert provider_0.get_current_locale() == locale

# Generated at 2022-06-25 20:19:15.130490
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    base_provider_0._override_locale(locales.EN)

if __name__ == "__main__":
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:16.999331
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = getattr(BaseDataProvider, 'locale', 'en')
    assert locale == 'en'



# Generated at 2022-06-25 20:19:20.606804
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError:
        pass
    else:
        raise AssertionError('Catching exception is failed')


# Generated at 2022-06-25 20:19:45.506847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    # Test for overrides current locale for locale-dependent providers
    assert isinstance(BaseDataProvider.override_locale(locale, locale),
                      BaseDataProvider)
    # Test for UnsupportedLocale
    try:
        BaseDataProvider.override_locale('test_locale')
    except UnsupportedLocale as e:
        assert e.locale == 'test_locale'
    # Test for ValueError
    try:
        BaseProvider.override_locale()
    except ValueError as e:
        assert str(e) == '«BaseProvider» has not locale dependent'


# Generated at 2022-06-25 20:19:47.489939
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    assert hasattr(base_data_provider_0, 'override_locale')

# Generated at 2022-06-25 20:20:00.022888
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='de-DE', seed=None)
    base_data_provider_1 = BaseDataProvider(locale='pt-BR', seed=None)
    base_data_provider_2 = BaseDataProvider(locale='tr-TR', seed=None)
    base_data_provider_3 = BaseDataProvider(locale='ru-RU', seed=None)
    with base_data_provider_0.override_locale() as base_data_provider_1:
        pass
    with base_data_provider_2.override_locale('en-GB') as base_data_provider_3:
        pass

# Generated at 2022-06-25 20:20:11.496458
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider(locale='ru_RU')
    base_data_provider_2 = BaseDataProvider(locale='en_US')
    with base_data_provider_1.override_locale() as base_data_provider_3:
        assert base_data_provider_3 is base_data_provider_1
        assert base_data_provider_3.locale == 'ru_RU'
    assert base_data_provider_1.locale == 'ru_RU'
    with base_data_provider_2.override_locale() as base_data_provider_4:
        assert base_data_provider_4 is base_data_provider_2
       

# Generated at 2022-06-25 20:20:22.132418
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    random.seed(1)
    g = BaseDataProvider(locale='en', seed=1)
    random.seed()
    assert g._data["occupation"]["name"] == 'Accountant'
    with g.override_locale('ru'):
        assert g._data['occupation']['name'] == 'Акушер'
    assert g._data["occupation"]["name"] == 'Accountant'
    with g.override_locale('en-US'):
        assert g._data['occupation']['name'] == 'Accountant'
    assert g._data["occupation"]["name"] == 'Accountant'

# Generated at 2022-06-25 20:20:25.099726
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._pull = test_case_0
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:20:28.164947
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()

    with base_provider_0.override_locale() as a:
        pass



# Generated at 2022-06-25 20:20:30.966805
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    contextlib.contextmanager.return_value = data_provider_0
    contextlib.contextmanager.__enter__.return_value = data_provider_0




# Generated at 2022-06-25 20:20:41.721570
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider()

    try:
        base_data_provider_0.override_locale()
    except ValueError as e:
        print(e)
    else:
        assert False
    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError as e:
        print(e)
    else:
        assert False



# Generated at 2022-06-25 20:20:54.533075
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider(locale='en', seed=0)
    print('>>> base_data_provider_0.locale:')
    print(base_data_provider_0.locale)
    print('>>> with base_data_provider_0.override_locale(locale=\'ru\') as base_data_provider_0:')
    with base_data_provider_0.override_locale(locale='ru') as base_data_provider_0:
        print('>>>     base_data_provider_0.locale:')
        print(base_data_provider_0.locale)

# Generated at 2022-06-25 20:21:40.987792
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale() as provider:
        print(provider)


# Generated at 2022-06-25 20:21:44.917395
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        pass


# Generated at 2022-06-25 20:21:55.808353
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='ru', seed=None)
    localized = 'Русский', 'en'
    #print(localized)
    #print(base_data_provider_0)
    with base_data_provider_0.override_locale(localized):
        assert(base_data_provider_0.locale=='ru')
        assert(base_data_provider_0)
        print(base_data_provider_0)


# Generated at 2022-06-25 20:22:05.019544
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    lang = BaseDataProvider()
    assert lang.locale == 'en'
    with lang.override_locale('uk'):
        assert lang.locale == 'uk'
    assert lang.locale == 'en'
    with lang.override_locale('en'):
        assert lang.locale == 'en'
    assert lang.locale == 'en'


# Generated at 2022-06-25 20:22:09.071624
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider()

        with base_data_provider_0.override_locale() as base_data_provider_1:
            assert base_data_provider_1

    except ValueError as e:
        assert str(e) == '«BaseDataProvider» has not locale dependent'



# Generated at 2022-06-25 20:22:10.876808
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'


# Generated at 2022-06-25 20:22:13.634611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0_context:
        pass

# Generated at 2022-06-25 20:22:19.301484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    base_provider_0._pull()
    with base_provider_0.override_locale('en'):
        print('in context')

    with base_provider_0.override_locale('not_supported_locale'):
        print('in context')

    with base_provider_0.override_locale('en_US'):
        print('in context')

    with base_provider_0.override_locale('ru_RU'):
        print('in context')

if __name__ == "__main__":
    test_BaseDataProvider_override_locale()
 


# Generated at 2022-06-25 20:22:23.366407
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass



# Generated at 2022-06-25 20:22:30.510587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseProvider(BaseDataProvider):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def custom_method(self):
            return self.locale
    provider_0 = TestBaseProvider(locale=locales.EN)
    try:
        locale_0 = "en"
        with provider_0.override_locale(locale=locale_0):
            locale_0 = "ar"
            locale_1 = provider_0.custom_method()
            assert locale_0 == locale_1
    except ValueError as e:
        raise e
    class TestBaseProvider(BaseDataProvider):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def custom_method(self):
            return self.loc

# Generated at 2022-06-25 20:24:27.480959
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        pass


# Generated at 2022-06-25 20:24:33.847425
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method «override_locale» of class «BaseDataProvider»"""
    with BaseDataProvider(locale='ar', seed=1).override_locale(locale='ja') as test_data_provider:
        assert test_data_provider.locale == 'ja'


# Generated at 2022-06-25 20:24:35.931880
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider('en')
    attr_1 = base_provider_0.override_locale("ru")
    # assert type of attr_1 is BaseDataProvider
    print(attr_1)


# Generated at 2022-06-25 20:24:38.097143
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        # Non locale-dependent provider doesn’t have method override_locale
        base_provider = BaseProvider()
        base_provider.override_locale()
    except AttributeError:
        pass

# Generated at 2022-06-25 20:24:40.391309
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Test for exception raised by method override_locale of class BaseDataProvider
    with pytest.raises(ValueError):
        base_data_provider_0.override_locale('fr')


# Generated at 2022-06-25 20:24:46.024774
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
    assert isinstance(base_data_provider_0, BaseDataProvider)
    assert base_data_provider_0.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-25 20:24:52.888219
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.get_current_locale()
    try:
        with base_data_provider_0.override_locale('en'):
            pass
    except ValueError as e:
        assert "«BaseDataProvider» has not locale dependent" == str(e)



# Generated at 2022-06-25 20:24:58.524078
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestBaseDataProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__(locale=locale)

    test_data_provider = TestBaseDataProvider(locale='en')
    assert test_data_provider.get_current_locale() == 'en'

    with test_data_provider.override_locale(locale='ru'):
        assert test_data_provider.get_current_locale() == 'ru'

    with test_data_provider.override_locale(locale='ja'):
        assert test_data_provider.get_current_locale() == 'ja'

    assert test_data_provider.get_current_locale() == 'en'

   

# Generated at 2022-06-25 20:25:01.861901
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    'Test BaseDataProvider.override_locale'
    base_provider = BaseDataProvider()

    base_data_provider = base_provider.override_locale(locales.DEFAULT_LOCALE)
    print('%s, %s' % (base_data_provider.get_current_locale(),
                      base_data_provider.locale))


# Generated at 2022-06-25 20:25:05.003637
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale():
        assert False


# Generated at 2022-06-25 20:26:44.845160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.enums import Gender
    from mimesis.providers.person import Person as PersonEn
    from mimesis.providers.person import Person as PersonRu

    person_en = PersonEn(seed=0)
    person_ru = PersonRu(seed=0)

    person_en.gender = Gender.MALE
    person_ru.gender = Gender.MALE

    print(person_en.full_name())
    print(person_ru.full_name())

    with person_ru.override_locale('en') as person:
        print(person.full_name())


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:26:48.677505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    result = base_data_provider_0.override_locale() # FIXME

    assert result is not None


# Generated at 2022-06-25 20:26:53.945344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('en-US'):
        assert provider.get_current_locale() == 'en-US'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:27:03.043432
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    base_data_provider_0 = BaseDataProvider(locale)
    override_locale_0 = base_data_provider_0.override_locale()
    contextmanager_override_locale_0 = contextlib.ExitStack()
    contextmanager_override_locale_0.enter_context(override_locale_0)

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:27:04.756255
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test exceptions
    with pytest.raises(ValueError):
        with BaseDataProvider().override_locale('en'):
            pass

# Generated at 2022-06-25 20:27:07.054223
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('ru') as base_data_provider:
        pass


# Generated at 2022-06-25 20:27:09.567266
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Instance of BaseProvider
    base_provider = BaseDataProvider(locale='ru')

    # Checking if override_locale returns a provider with overridden locale
    with base_provider.override_locale(locale='en') as bp:
        assert str(bp) == 'BaseDataProvider <en>'

# Generated at 2022-06-25 20:27:14.362478
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Method override_locale of class BaseDataProvider.

    Args:
        self: BaseDataProvider

    Returns:
        BaseDataProvider

    Raises:
        AttributeError: 'BaseDataProvider' object has no attribute 'locale'

    """
#     try:
#         origin_locale = self.locale
#         self._override_locale(locale)
#         try:
#             yield self
#         finally:
#             self._override_locale(origin_locale)
#     except AttributeError:
#         raise ValueError('«{}» has not locale dependent'.format(
#             self.__class__.__name__))
#     pass


# Generated at 2022-06-25 20:27:20.981312
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    numbers = Numbers()
    with numbers.override_locale(locales.RU):
        assert numbers.get_current_locale() == locales.RU
        assert numbers.generate_decimal() == 3.7
        assert numbers.generate_simple_fraction()[1] == 4
        assert numbers.generate_fraction()[1] >= 1
        assert numbers.generate_percent() == 41
        assert numbers.generate_number(12) == 5


if __name__ == '__main__':
    # Unit test for method _validate_enum of class BaseProvider
    def test_validate_enum():
        numbers = Numbers()
        # Testing is method throw NonEnumerableError

# Generated at 2022-06-25 20:27:27.459912
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    try:
        with data_provider_0.override_locale('ru'):
            pass
    except Exception:
        assert False
    try:
        with data_provider_0.override_locale('en'):
            pass
    except Exception:
        assert False
    try:
        with data_provider_0.override_locale('de'):
            pass
    except Exception:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:28:14.309136
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale():
        assert provider.locale == locales.EN


# Generated at 2022-06-25 20:28:19.184853
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print('Starting test_BaseDataProvider_override_locale')
    # Create a BaseDataProvider object
    base_data_provider_0 = BaseDataProvider()
    # Try to use method override_locale
    try:
        with base_data_provider_0.override_locale():
            pass
    except Exception as e_0:
        pass
    print('Finished test_BaseDataProvider_override_locale')


# Generated at 2022-06-25 20:28:21.459783
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    with provider.override_locale():
        assert provider.get_current_locale() == provider.locale

# Generated at 2022-06-25 20:28:27.564892
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    attrs = ['get_current_locale']
    for attr in attrs:
        getattr(base_data_provider_0, attr)()
    with base_data_provider_0.override_locale():
        pass
    base_data_provider_0.locale = 'e'
    with base_data_provider_0.override_locale():
        pass
    with base_data_provider_0.override_locale('e'):
        pass