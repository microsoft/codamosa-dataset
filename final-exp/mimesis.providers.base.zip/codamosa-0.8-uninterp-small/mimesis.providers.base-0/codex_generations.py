

# Generated at 2022-06-25 20:18:39.457146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert True


# Generated at 2022-06-25 20:18:44.180419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'adxPDW'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    # Execute function
    with base_data_provider_0.override_locale() as provider:
        result = provider
    # Check
    assert result == base_data_provider_0, 'Result of call is not equal to expected value'


# Generated at 2022-06-25 20:18:51.666429
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'f#1hAO'
    str_1 = '#eYB'
    base_data_provider_0 = BaseDataProvider(str_0)
    with base_data_provider_0.override_locale(str_1):
        with base_data_provider_0.override_locale(str_1):
            with base_data_provider_0.override_locale(str_1):
                print(base_data_provider_0.get_current_locale())


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:18:53.357576
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'ar'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)


# Generated at 2022-06-25 20:18:56.194346
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test cases
    try:
        base_data_provider_0 = BaseDataProvider('<locale>', '<seed>')
        with base_data_provider_0.override_locale('<locale>'):
            assert True
    except:
        assert False



# Generated at 2022-06-25 20:19:01.200972
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'locale'
    base_data_provider_0 = BaseDataProvider(locale)
    assert isinstance(base_data_provider_0.override_locale(locale), BaseDataProvider)


# Generated at 2022-06-25 20:19:09.942650
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '8/b/<'
    str_1 = '~Bx4H'
    base_data_provider_0 = BaseDataProvider(str_0, str_1)
    base_data_provider_1 = BaseProvider(str_0)
    base_data_provider_2 = BaseProvider(str_1)
    base_data_provider_3 = BaseDataProvider(str_0, str_1)

    with base_data_provider_0.override_locale(str_1):
        pass

    with base_data_provider_1.override_locale(str_1):
        pass

    with base_data_provider_2.override_locale(str_0):
        pass


# Generated at 2022-06-25 20:19:15.596042
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'JtKhy'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    str_1 = 'smNgB'
    base_data_provider_2 = base_data_provider_0.override_locale(str_1)


# Generated at 2022-06-25 20:19:18.886289
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert BaseDataProvider(locales.RU, None).override_locale(locales.UK).locale == locales.UK

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:26.140587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_0 = None
    try:
        base_data_provider_0 = BaseDataProvider(locale_0, locale_0)
        with base_data_provider_0.override_locale():
            pass
    except UnsupportedLocale:
        pass
    except:
        raise ValueError('BaseDataProvider.override_locale failed')


# Generated at 2022-06-25 20:19:48.027623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dataset = {
        'get_current_locale': 'en',
        'random': random,
    }

    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.__dict__.update(dataset)

    str_0 = 'DpcrA'
    with base_data_provider_0.override_locale(str_0) as provider:
        assert provider.get_current_locale() == str_0

    assert base_data_provider_0.get_current_locale() == 'en'


# Generated at 2022-06-25 20:19:57.934532
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    dict_0 = {}
    dict_0['override_locale'] = locale_0 = base_data_provider_0.override_locale()
    str_1 = base_data_provider_0.get_current_locale()
    dict_0['get_current_locale'] = str_1

# Generated at 2022-06-25 20:20:08.350374
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_BaseDataProvider = BaseDataProvider()
    test_case = test_BaseDataProvider.override_locale()
    dummy_locale = locales.EN

# Generated at 2022-06-25 20:20:13.066056
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    data_dir = base_data_provider_0._data_dir
    path_0 = Path(data_dir).joinpath('en', 'science.json')
    with open(path_0, 'r', encoding='utf8') as f:
        result = json.load(f)
    assert base_data_provider_0._pull.cache_info().hits != 0
    assert base_data_provider_0._data == result

# Generated at 2022-06-25 20:20:18.395609
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'W8CeU6'
    base_data_provider_1 = BaseDataProvider(str_0, str_0)
    base_data_provider_1.override_locale(str_0)


# Generated at 2022-06-25 20:20:26.406024
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    #__contextmanager__ = 'tWJhE'
    #with (base_data_provider_0._override_locale(__contextmanager__)):
    #    pass
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__contextmanager__ = '0bFwqn'
    #__context

# Generated at 2022-06-25 20:20:32.065925
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    str_1 = 'W8LpOksIy'
    with base_data_provider_0.override_locale(str_1) as base_data_provider_1:
        str_2 = 'xRo1tE'
        str_3 = base_data_provider_1.get_current_locale()
        assert str_3 == str_2


# Generated at 2022-06-25 20:20:36.760794
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'X'
    with BaseDataProvider(str_0).override_locale(str_0, str_0):
        pass


# Generated at 2022-06-25 20:20:44.681498
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider('cs', '0bFwqn')
        with base_data_provider_0.override_locale('fr'):
            locale = base_data_provider_0.get_current_locale()
            assert locale == 'fr'
        locale_0 = base_data_provider_0.get_current_locale()
        assert locale_0 == 'cs'
    except ValueError as e:
        assert str(e) == '«BaseDataProvider» has not locale dependent'


# Generated at 2022-06-25 20:20:48.951425
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)


# Generated at 2022-06-25 20:21:14.357303
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)

    with base_data_provider_0.override_locale():
        print('done')



# Generated at 2022-06-25 20:21:26.269827
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Create instance of class BaseDataProvider
    base_data_provider_0 = BaseDataProvider('Ykap0z', 'aeh0wB')
    # Create context manager
    with base_data_provider_0.override_locale('CfQ2Ky') as base_data_provider_1:
        # Get attribute locale from objec base_data_provider_1
        str_0 = base_data_provider_1.locale
        # Verify the type of output
        assert isinstance(str_0, str)

    # Create instance of class BaseDataProvider
    base_data_provider_2 = BaseDataProvider('e7hR0w', 'S7NEu0')
    # Create context manager

# Generated at 2022-06-25 20:21:32.900262
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'pZdDl3'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    assert base_data_provider_0.override_locale(str_0).__enter__() == base_data_provider_0

# Generated at 2022-06-25 20:21:39.520138
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    str_1 = '3lwltf'
    str_2 = 'FyV7M'
    base_data_provider_0 = BaseDataProvider(str_0, str_1)
    dict_0 = base_data_provider_0._data
    dict_1 = collections.OrderedDict()
    dict_2 = collections.OrderedDict()
    dict_2['T'] = dict_1
    dict_2['b'] = dict_0
    dict_2['C'] = dict_1
    dict_2['g'] = dict_0
    dict_2['k'] = dict_0
    dict_2['a'] = dict_1
    dict_2['F'] = dict_0
    dict_2['N'] = dict_

# Generated at 2022-06-25 20:21:47.869482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'qq'
    str_1 = '5JQL'
    base_data_provider_0 = BaseDataProvider(str_0, str_1)
    with base_data_provider_0.override_locale() as base_data_provider_1:
        str_2 = '5JQL'
        base_data_provider_1.locale = str_2
        str_3 = base_data_provider_1._datafile = 'UKuHY7p'
        str_4 = 'Yh6D'
        str_5 = str_3
        base_data_provider_1._data_dir = str_5


# Generated at 2022-06-25 20:21:49.700490
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    assert base_data_provider_0.override_locale() == expected_result_0



# Generated at 2022-06-25 20:21:55.486083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'VHWZB'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    assert str_0 == base_data_provider_0.get_current_locale()



# Generated at 2022-06-25 20:22:07.426213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print("Test method override_locale of class BaseDataProvider")
    str_0 = random.choice(['Ixjx', 'kj', '4Bs4', 'ZD'])
    try:
        base_data_provider_0 = BaseDataProvider(str_0, str_0)
        base_data_provider_0.override_locale()
    except ValueError as e:
        print("ValueError:", e)
        assert("«BaseDataProvider» has not locale dependent" in e.args[0])
    except Exception as e:
        print("Exception:", e)
        assert False



# Generated at 2022-06-25 20:22:08.270396
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-25 20:22:10.666936
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider('ru')
    with bdp.override_locale('en') as bdp:
        assert bdp.locale == 'en'
    assert bdp.locale == 'ru'

# Generated at 2022-06-25 20:23:02.143263
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert hasattr(BaseDataProvider, 'override_locale')
    assert callable(BaseDataProvider.override_locale)


# Generated at 2022-06-25 20:23:11.625324
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # save current locale to restore it later
    origin_locale = BaseDataProvider.locale


# Generated at 2022-06-25 20:23:19.743846
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import inspect, sys
    from contextlib import contextmanager
    from io import StringIO

    # Create a mock context manager
    @contextmanager
    def mock_context_manager(obj):
        try:
            yield obj
        except Exception as e:
            print("Caught exception: {}".format(e))

    class MockBaseDataProvider:
        def override_locale(self):
            return mock_context_manager(self)

    # Instantiate a mock BaseDataProvider
    base_data_provider = MockBaseDataProvider()

    # Execute the body of context manager and capture the output
    with base_data_provider.override_locale() as temp_base_data_provider:
        captured_output = sys.stdout
        sys.stdout = StringIO()
        print(temp_base_data_provider)

# Generated at 2022-06-25 20:23:28.446024
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    with base_data_provider_0.override_locale() as base_data_provider_1:
        str_1 = '0bFwqn'
        base_data_provider_1._override_locale(str_1)



# Generated at 2022-06-25 20:23:38.000686
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = ','
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    base_data_provider_0.__enter__()
    base_data_provider_0.override_locale(str_0)
    base_data_provider_0.__exit__()


if __name__ == '__main__':
    test_case_0()
    # Unit test for method override_locale of class BaseDataProvider
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:23:48.703383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'lkLlV7'
    base_data_provider_0 = BaseDataProvider(str_0)
    with base_data_provider_0.override_locale() as base_data_provider_1:
        str_1 = base_data_provider_1.get_current_locale()
        str_2 = base_data_provider_0.get_current_locale()
        assert str_1 == str_2
    print('test_BaseDataProvider_override_locale passed')


# Generated at 2022-06-25 20:24:07.124589
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    str_1 = '0bFwqn'
    str_2 = '0bFwqn'
    str_3 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_1)
    with base_data_provider_0.override_locale(str_2) as base_data_provider_1:
        base_data_provider_1
    try:
        base_data_provider_0.override_locale(str_3)
        raise ValueError
    except Exception:
        pass


# Generated at 2022-06-25 20:24:09.236830
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'CtfGpdJj'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    base_data_provider_0.override_locale()



# Generated at 2022-06-25 20:24:11.686285
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    with pytest.raises(ValueError):
        base_data_provider_0.override_locale(str_0)


# Generated at 2022-06-25 20:24:15.393745
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'ca_ES'
    i_0 = 0
    base_data_provider_0 = BaseDataProvider(locale=str_0)
    try:
        base_data_provider_0.override_locale(str_0)
    except Exception as e:
        fail()

    str_0 = 'Xq3y'
    try:
        base_data_provider_0.override_locale(str_0)
    except ValueError as e:
        pass


# Generated at 2022-06-25 20:26:05.957071
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    int_0 = 1
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    with base_data_provider_0.override_locale(int_0) as base_data_provider_1:
        assert base_data_provider_1.get_current_locale() == int_0
        assert base_data_provider_1 == base_data_provider_0


# Generated at 2022-06-25 20:26:14.951232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as provider:
        str_0 = '0bFwqn'
        get_current_locale = provider.get_current_locale
        get_current_locale()
    with BaseDataProvider().override_locale('ru') as provider:
        str_0 = '0bFwqn'
        get_current_locale = provider.get_current_locale
        get_current_locale()
    with BaseDataProvider().override_locale('ru') as provider:
        str_0 = '0bFwqn'
        get_current_locale = provider.get_current_locale
        get_current_locale()


# Generated at 2022-06-25 20:26:20.599418
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = 'PL'
    base_data_provider_0 = BaseDataProvider(str_0)
    with base_data_provider_0.override_locale() as base_data_provider_1:
        str_1 = 'xVc'
        str_2 = base_data_provider_1.get_current_locale()
        base_data_provider_0 = BaseDataProvider(str_0, str_1)
        assert str_2 == base_data_provider_0.get_current_locale()


# Generated at 2022-06-25 20:26:27.678502
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Raise ValueError when 'locale=' is missing.
    with pytest.raises(ValueError):
        BaseDataProvider().override_locale()

    # Raise ValueError when 'locale=' is missing.
    with pytest.raises(ValueError):
        BaseDataProvider().override_locale('locale=' + '')

    # Raise UnsupportedLocale when locale is unsupported.
    with pytest.raises(UnsupportedLocale):
        BaseDataProvider().override_locale('locale=' + 'unsupported-locale')

    # Raise UnsupportedLocale when locale is unsupported.
    with pytest.raises(UnsupportedLocale):
        BaseDataProvider().override_locale('locale=' + 'en_UNSUPPORTED')


# Generated at 2022-06-25 20:26:32.414108
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class BaseDataProvider"""
    str_0 = '0bFwqn'
    str_1 = 'CxNl1'
    str_2 = random.choice(['IJtO8', 'mnOUr', '5OtC1'])
    with base_data_provider_0.override_locale(str_2) as base_data_provider_0:
        base_data_provider_0._override_locale(str_1)
        assert base_data_provider_0.locale == str_1


# Generated at 2022-06-25 20:26:38.112380
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_0 = BaseDataProvider(str_0, str_0)
    with base_data_provider_0.override_locale(str_0) as base_data_provider_0:
        base_data_provider_0.get_current_locale()


# Generated at 2022-06-25 20:26:41.338778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with contextlib.suppress(Exception):
        base_data_provider_0 = BaseDataProvider('RzR0XbsJYO', '6VZU')
        base_data_provider_0.override_locale('Ll7TjpG')


# Generated at 2022-06-25 20:26:44.409439
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '-M}8;v"4'
    # Test for raise ValueError, with arg: '«{}» has not locale dependent'.format(self.__class__.__name__)
    with pytest.raises(ValueError):
        base_provider_0 = BaseProvider(str_0)
        with base_provider_0.override_locale(str_0):
            assert True


# Generated at 2022-06-25 20:26:54.669033
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    str_0 = '0bFwqn'
    base_data_provider_1 = BaseDataProvider(str_0, str_0)  # type: BaseDataProvider
    bool_0 = False
    bool_1 = False
    str_1 = 'a'
    int_0 = 0
    str_2 = 'data/providers/identity_data/'
    str_3 = 'identity_data.json'
    str_4 = 'data/providers/identity_data/'
    str_5 = 'identity_data.json'
    str_6 = '/'
    str_7 = 'data/providers/identity_data/'
    str_8 = 'identity_data.json'
    str_9 = '/'

# Generated at 2022-06-25 20:27:06.154604
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialize a BaseDataProvider with default parameters
    base_data_provider_0 = BaseDataProvider()
    # Try to use the override_locale() context manager to temporarily
    # override the current locale (Setting the context manager to a variable
    # raises an AttributeError)
    with base_data_provider_0.override_locale():
        pass
    # Verify that the exception raised by the context manager is indeed
    # an AttributeError
    assert "AttributeError" in str(ex_1)

    # Initialize a BaseDataProvider with default parameters
    base_data_provider_0 = BaseDataProvider()

    # Verify that the override_locale() context manager correctly overrides
    # the current locale