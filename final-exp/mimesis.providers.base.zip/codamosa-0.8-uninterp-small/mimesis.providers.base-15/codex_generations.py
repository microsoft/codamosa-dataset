

# Generated at 2022-06-25 20:18:42.201396
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.locale = 'ru'
    base_data_provider_0.override_locale()


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:18:45.436634
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale():
        pass

# Generated at 2022-06-25 20:18:49.549754
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.typing import JSON
    
    base_data_provider_0 = RussiaSpecProvider()
    data = base_data_provider_0._pull()
    locale = base_data_provider_0.get_current_locale()
    base_data_provider_0._override_locale('en')
    base_data_provider_0._pull()

    assert base_data_provider_0.get_current_locale() == 'en'

# Generated at 2022-06-25 20:19:00.081813
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    address_0 = Address()
    with address_0.override_locale(locale=locales.EN):
        value_0 = address_0.city()
    value_1 = address_0.city()
    value_2 = address_0.city()
    value_3 = address_0.city()
    assert value_0 != value_1 != value_2 != value_3
    with address_0.override_locale(locale=locales.EN):
        value_0 = address_0.city()
    value_1 = address_0.city()
    value_2 = address_0.city()
    value_3 = address_0.city()
    assert value_0 != value_1 != value_2 != value_3
    value_4

# Generated at 2022-06-25 20:19:06.609927
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    context_manager_0 = base_data_provider_0.override_locale(locales.EN)
    with context_manager_0 as provider:
        str_0 = str(provider)
    assert str_0 == 'BaseDataProvider <{}>'.format(locales.EN)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:19:10.054947
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.RU
    base_data_provider = BaseDataProvider(locale=locales.RU)
    assert base_data_provider.get_current_locale() == locales.RU
    base_data_provider.override_locale(locale)
    assert base_data_provider.get_current_locale() == locale

# Generated at 2022-06-25 20:19:16.236509
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # test_case_0: Calling the method override_locale of class BaseDataProvider
    # with a context manager
    if hasattr(BaseDataProvider, 'override_locale'):
        with BaseDataProvider().override_locale(locale='en'):
            pass  
    else:
        raise ValueError("«BaseDataProvider» has not attribute «override_locale»")


# Generated at 2022-06-25 20:19:21.742494
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider(locale='ru').override_locale('fr'):
            if BaseDataProvider().locale == 'fr':
                print('Test 1 passed!')
            else:
                print('Test 1 failed!')
        if BaseDataProvider().locale == 'ru':
            print('Test 2 passed!')
        else:
            print('Test 2 failed!')
    except ValueError:
        print('Test 3 passed!')


# Generated at 2022-06-25 20:19:26.441998
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Creating an instance of class BaseDataProvider
    data_provider_0 = BaseDataProvider()
    # Calling the method override_locale of class BaseDataProvider with arguments
    with data_provider_0.override_locale(locale='es'):
        pass



# Generated at 2022-06-25 20:19:31.243177
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale('en') == base_data_provider

# Generated at 2022-06-25 20:19:42.090293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale():
        pass

# Generated at 2022-06-25 20:19:50.763074
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .person import Person
    from .utils import get_seed
    from .car import Car
    from .color import Color
    from .misc import Misc
    from .financial import Financial
    from .food import Food
    from .transport import Transport
    from .code import Code
    from .text import Text
    from .address import Address
    from .internet import Internet
    from .business import Business

    provider = Person(locale='ru')
    with provider.override_locale('be'):
        assert provider.get_current_locale() == 'be'

    # Overriding locale for different providers

# Generated at 2022-06-25 20:19:56.413103
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    with base_provider_0.override_locale('en') as base_provider_1:
        pass
    assert str(base_provider_0) == 'BaseProvider <en>'


# Generated at 2022-06-25 20:19:59.685127
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_0 = BaseDataProvider()
    BaseDataProvider_0 = BaseDataProvider()
    with BaseDataProvider_0.override_locale(str):
        isinstance(BaseDataProvider_0.__new__, BaseDataProvider)



# Generated at 2022-06-25 20:20:07.476794
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locale=locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN
    assert isinstance(provider, BaseDataProvider)

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:09.517483
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_provider = BaseDataProvider()
    assert base_provider.override_locale(locale='zh') is None

# Generated at 2022-06-25 20:20:22.280286
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = base_data_provider_0.override_locale()
    # base_data_provider_1 must be a instance of BaseDataProvider
    assert isinstance(base_data_provider_1, BaseDataProvider)
    # base_data_provider_0 must be a instance of BaseDataProvider
    assert isinstance(base_data_provider_0, BaseDataProvider)
    # base_data_provider_0.override_locale() must be a instance of BaseDataProvider
    assert isinstance(base_data_provider_0.override_locale(), BaseDataProvider)
    # base_data_provider_1.override_locale() must be a instance of BaseDataProvider

# Generated at 2022-06-25 20:20:25.400887
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        print(type(base_data_provider_0))
        print(base_data_provider_0.locale)



# Generated at 2022-06-25 20:20:32.300969
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_value = {'a': 'b', 'b': [1, 2, 3]}
    def get_data(locale_name: str) -> JSON:
        return test_value
    base_provider_0 = BaseDataProvider(seed=123)
    base_provider_0._pull = get_data
    with base_provider_0.override_locale(), base_provider_0.override_locale('en'):
        assert base_provider_0._pull() == test_value
    with base_provider_0.override_locale(), base_provider_0.override_locale('en'):
        assert base_provider_0._pull() == test_value


# Generated at 2022-06-25 20:20:39.105505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    with base_provider_0.override_locale('en'):
        assert base_provider_0.locale == 'en'
    assert base_provider_0.locale == 'en'


# Generated at 2022-06-25 20:20:53.589140
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import BaseDataProvider
    bdp = BaseDataProvider()
    with bdp.override_locale('en'):
        assert bdp.get_current_locale() == 'en'
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-25 20:21:01.196463
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # BaseDataProvider.override_locale(locale)
    with BaseDataProvider().override_locale('en') as instance:
        instance.get_current_locale()
    with BaseDataProvider().override_locale() as instance:
        instance.get_current_locale()


# Generated at 2022-06-25 20:21:07.718818
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_cases_override_locale_0 = [
        {'locale': locales.EN, 'seed': None}
    ]
    for test_case_override_locale_0 in test_cases_override_locale_0:
        test_data_provider_0 = BaseDataProvider(
            locale=test_case_override_locale_0['locale'],
            seed=test_case_override_locale_0['seed']
        )
        with test_data_provider_0.override_locale() as test_data_provider_1:
            assert test_data_provider_1 is test_data_provider_0

test_case_1 = {
    'data': {}
}
test_case_1['data']['test_cases_0']

# Generated at 2022-06-25 20:21:17.913712
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider"""
    foo_provider_0 = BaseDataProvider()
    with foo_provider_0.override_locale('en'):
        try:
            assert getattr(foo_provider_0, 'locale') == 'en'
        finally:
            foo_provider_0.reseed()
            foo_provider_0.reseed(42)
            pass
    with foo_provider_0.override_locale('ru') as foo_provider_1:
        foo_provider_0 = foo_provider_1
        assert foo_provider_0.override_locale() == 'en'
        assert foo_provider_0.get_current_locale() == locales.EN


# Generated at 2022-06-25 20:21:22.214796
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass



# Generated at 2022-06-25 20:21:24.022796
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-25 20:21:27.467731
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_0 = BaseDataProvider()
    BaseDataProvider_0.override_locale('locale')

# Generated at 2022-06-25 20:21:34.718099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale='en')
    print(base_data_provider)
    with base_data_provider.override_locale('ru'):
        print(base_data_provider)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:47.077158
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Case: class BaseDataProvider, method override_locale, current locale is en
    # Expected: throw value error
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale() as p:
            raise ValueError('Failed assert')
    except ValueError:
        pass

    # Case: class BaseDataProvider, method override_locale, current locale is en, new locale is uk
    # Expected: assertion is true
    base_data_provider_1 = BaseDataProvider()
    assert base_data_provider_1.get_current_locale() == 'en'
    with base_data_provider_1.override_locale('uk') as p:
        assert base_data_provider_1.get_current_

# Generated at 2022-06-25 20:21:58.259549
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create BaseDataProvider instance w.o. arguments
    base_data_provider_0 = BaseDataProvider()
    # Get current locale
    locale_0 = base_data_provider_0.get_current_locale()
    # Override locale
    base_data_provider_0.override_locale('ru').override_locale('en')
    # Check current locale
    assert base_data_provider_0.get_current_locale() == locale_0
    # Override locale
    base_data_provider_0.override_locale('').override_locale('en')
    # Check current locale
    assert base_data_provider_0.get_current_locale() == locale_0
    # Create BaseDataProvider instance
    base_data_provider_1 = Base

# Generated at 2022-06-25 20:22:28.062325
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_0 = BaseDataProvider()
    locale = 'ru'
    with provider_0.override_locale(locale) as _p:
        assert _p.get_current_locale() == locale


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:36.946114
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Init
    base_provider_1 = BaseProvider()
    base_data_provider_0 = BaseDataProvider()
    # Calling contextmanager with parameter
    with base_data_provider_0.override_locale():
        assert False
    # Calling contextmanager with parameter
    with base_data_provider_0.override_locale("fake_arg"):
        assert False
    # Calling contextmanager with parameter
    with base_provider_1.override_locale():
        assert False
    # Calling contextmanager with parameter
    with base_provider_1.override_locale("en"):
        assert False


# Generated at 2022-06-25 20:22:38.194462
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


# Generated at 2022-06-25 20:22:47.723083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    def test_BaseDataProvider_override_locale_1():
        with base_data_provider.override_locale() as base_data_provider_2:
            base_data_provider_2
        pass
    def test_BaseDataProvider_override_locale_2():
        # Failed to grab the context manager
        try:
            base_data_provider_2
        except Exception as e:
            assert isinstance(e, NameError)


# Generated at 2022-06-25 20:22:49.064486
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider.override_locale():
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:22:55.696092
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    base_provider_0 = BaseProvider()
    test_locale = 'en'

    # Assert
    with base_provider_0.override_locale(locale=test_locale) as p:
        assert test_locale == p.locale


# Generated at 2022-06-25 20:23:08.913951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider('en')

    contextlib_contextmanager_0 = base_data_provider_0.override_locale('cs')
    with contextlib_contextmanager_0 as base_data_provider_0:
        str_0 = base_data_provider_0.get_current_locale()

    contextlib_contextmanager_1 = base_data_provider_1.override_locale()
    with contextlib_contextmanager_1 as base_data_provider_1:
        str_1 = base_data_provider_1.get_current_locale()

    print(str_0)
    print(str_1)



# Generated at 2022-06-25 20:23:15.834372
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locales.EN
    with base_data_provider_0.override_locale(locale='en') as base_data_provider_0:
        print(base_data_provider_0)
        pass


# Generated at 2022-06-25 20:23:18.569692
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = "en"
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale(locale)


# Generated at 2022-06-25 20:23:23.353055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'


# Generated at 2022-06-25 20:24:29.941601
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale='ru'):
        assert (base_data_provider.get_current_locale() == 'ru')



# Generated at 2022-06-25 20:24:36.433908
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    with Address.override_locale('en') as ad_0:
        print(ad_0.get_current_locale())
    with Address.override_locale('ru') as ad_1:
        print(ad_1.get_current_locale())


# Generated at 2022-06-25 20:24:46.219538
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    bd_provider_0 = base_data_provider_0
    base_data_provider_1 = BaseDataProvider()
    bd_provider_1 = base_data_provider_1
    #
    with base_data_provider_0.override_locale("en"):
        pass
    print("Locale of given provider after using override_locale is en")
    #
    base_data_provider_0.reseed("seed")
    print("Seed for given provider is seed")
    #
    with base_data_provider_1.override_locale("en"):
        pass
    print("Locale of given provider after using override_locale is en")
    #
    base_data_provider_1

# Generated at 2022-06-25 20:24:56.593823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()

    # Test case where locale is locale=locales.DEFAULT_LOCALE and
    # locale is locale=locales.DEFAULT_LOCALE.
    # Expected result: PASS.
    try:
        with base_data_provider_0.override_locale() as base_data_provider_0:
            base_data_provider_0.get_current_locale() == locales.DEFAULT_LOCALE
    except ValueError as e:
        assert False, 'Test fail with error: {}'.format(e)
    else:
        assert True

    # Test case where locale is locale=locales.DEFAULT_LOCALE and
    # locale is locale='en'.
    # Expected result

# Generated at 2022-06-25 20:25:03.281734
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        x = base_data_provider_0.get_current_locale()
        assert x == 'en'


# Generated at 2022-06-25 20:25:09.636206
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Case 0

    base_data_provider_0 = BaseDataProvider()

    try:
        with base_data_provider_0.override_locale():
            pass
    except:
        print("Failed...")
    else:
        print("Passed!")

    # Case 1

    base_data_provider_1 = BaseDataProvider()

    try:
        with base_data_provider_1.override_locale():
            pass
    except:
        print("Failed...")
    else:
        print("Passed!")

test_case_0()
test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:14.329611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider()
    with dp.override_locale('en'):
        assert dp.get_current_locale() == 'en'


# Generated at 2022-06-25 20:25:17.046790
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:25:18.658915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()

# Generated at 2022-06-25 20:25:24.692191
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider('ru_RU')
    with base_data_provider_0.override_locale('en'):
        pass
    assert base_data_provider_0.locale == 'ru_RU'


# Generated at 2022-06-25 20:27:00.407711
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as provider:
        locale = provider.locale
    locale == 'ru'


# Generated at 2022-06-25 20:27:07.766345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import MUNICIPALITIES
    from mimesis.enums import Gender
    from mimesis.providers.cyber import Hacker

    with Hacker().override_locale('ru') as ru_hacker:
        assert ru_hacker.get_current_locale() == 'ru'

        assert ru_hacker.gender(Gender.MALE) in MUNICIPALITIES['ru']

    assert Hacker().get_current_locale() == 'en'
    assert Hacker().gender(Gender.MALE) in MUNICIPALITIES['en']



# Generated at 2022-06-25 20:27:11.945566
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Tests for ``BaseDataProvider`` -> ``override_locale``
    locale = locales.DEFAULT_LOCALE
    base_data_provider_0 = BaseDataProvider(locale)
    with base_data_provider_0.override_locale(locale):
        assert base_data_provider_0.locale == locale

# Unit tests for class BaseDataProvider

# Generated at 2022-06-25 20:27:14.914303
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyBaseDataProvider(BaseDataProvider):
        pass

    provider = MyBaseDataProvider()
    try:
        with provider.override_locale(locales.RU):
            assert provider.get_current_locale() == locales.RU
    except ValueError:
        pass

# Generated at 2022-06-25 20:27:16.748725
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider()
    with p.override_locale('ru') as provider:
        assert provider.locale == 'ru'
    assert p.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-25 20:27:20.488614
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_0 = BaseDataProvider()
    locale = 'ru'
    with BaseDataProvider_0.override_locale(locale) as BaseDataProvider_1:
        assert BaseDataProvider_1 is BaseDataProvider_0
        assert BaseDataProvider_1.locale == locale
        assert BaseDataProvider_0.locale == BaseDataProvider_0.locale

test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:27:24.357133
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    # Check that exception is raised if you try
    # to override locale on non-locale dependent provider
    try:
        with base_provider_0.override_locale("en"):
            assert False
    except ValueError:
        assert True

# Generated at 2022-06-25 20:27:27.558949
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider(locale=locales.RU, seed=12345)
    with data_provider_0.override_locale(locale=locales.DE) as provider:
        assert provider.get_current_locale() == 'de'



# Generated at 2022-06-25 20:27:30.113399
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.RU):
        pass


# Generated at 2022-06-25 20:27:34.249027
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = "ru"
    datafile = "address.json"
    provider = BaseDataProvider(locale=locale, seed=None)
    provider._data
    provider._datafile = datafile
    provider.get_current_locale()
    with provider.override_locale(locale=locale) as temp:
        pass