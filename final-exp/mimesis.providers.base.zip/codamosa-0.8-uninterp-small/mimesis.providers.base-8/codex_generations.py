

# Generated at 2022-06-25 20:18:43.877154
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider = BaseDataProvider()
        with base_data_provider.override_locale():
            raise RuntimeError()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-25 20:18:47.564351
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Tests for method override_locale of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale="it") as data_provider:
        assert data_provider is base_data_provider_0
        assert base_data_provider_0.get_current_locale() == "it"
    assert base_data_provider_0.get_current_locale() == "en"


# Generated at 2022-06-25 20:18:49.964034
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    for locale in locales.SUPPORTED_LOCALES:
        with provider.override_locale(locale) as p:
            assert locale == p.locale



# Generated at 2022-06-25 20:18:53.770464
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Testing if AttributeError: 'BaseProvider' object has no attribute '_override_locale' is raised for the provider without locale
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:18:54.501607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider.override_locale(locale="en")

# Generated at 2022-06-25 20:18:59.391069
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale("de_de"):
        assert base_data_provider_0.get_current_locale() == "de_de"
    base_data_provider_1 = BaseDataProvider("es_es")
    with base_data_provider_1.override_locale("en_en"):
        assert base_data_provider_1.get_current_locale() == "en_en"


# Generated at 2022-06-25 20:19:01.809932
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='uk') as bd:
        assert bd.locale == 'uk'



# Generated at 2022-06-25 20:19:08.065986
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en')
    assert str(base_data_provider_0) == 'BaseDataProvider <en>'
    with base_data_provider_0.override_locale('ru') as base_data_provider_1:
        assert str(base_data_provider_1) == 'BaseDataProvider <ru>'
    assert str(base_data_provider_0) == 'BaseDataProvider <en>'


# Generated at 2022-06-25 20:19:11.842267
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Ensure we get correct result with correct input value
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale() as locale:
        assert locale.get_current_locale() == 'en'
    # Ensure we get correct result with wrong input value
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('wrong_locale') as locale:
        assert locale.get_current_locale() == 'wrong_locale'

# Generated at 2022-06-25 20:19:17.945735
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale='en')
    locale_dict = {'test_key': 'test_value'}
    base_data_provider._data = locale_dict
    with base_data_provider.override_locale(locale='en') as base_data_provider_override_locale:
        assert base_data_provider_override_locale._data == locale_dict
        base_data_provider_override_locale.get_current_locale()



# Generated at 2022-06-25 20:19:29.477230
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass



# Generated at 2022-06-25 20:19:35.081426
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    with base_provider_0.override_locale(locale='en') as b:
        base_provider_0.get_current_locale()
        assert base_provider_0
        assert b


# Generated at 2022-06-25 20:19:37.741421
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_0 = BaseDataProvider()
    locale_0 = locales.EN
    with provider_0.override_locale(locale_0) as provider_1:
        assert True


# Generated at 2022-06-25 20:19:41.964968
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()

    with data_provider.override_locale('fr'):
        assert 'fr' == data_provider.get_current_locale()

# Generated at 2022-06-25 20:19:47.658747
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test = BaseDataProvider()
    test._override_locale('en')
    try:
        test._override_locale('en')
    except UnsupportedLocale as e:
        print('UnsupportedLocale exception raised')
        assert isinstance(e, UnsupportedLocale)


# Generated at 2022-06-25 20:19:59.216500
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'pap'
    locale_0 = locales.DEFAULT_LOCALE
    locale_1 = locale
    locale_2 = 'ko-ko'

    dict_0 = {}
    dict_1 = {}
    dict_2 = {}

    dict_1[locale_1] = dict_0
    dict_2[locale_0] = dict_1

    base_data_provider_0 = BaseDataProvider(locale_1)
    base_data_provider_1 = BaseDataProvider(locale_2)

    assert base_data_provider_0.locale == locale_1
    assert base_data_provider_1.locale == locale_2

# Generated at 2022-06-25 20:20:03.637780
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    result = base_data_provider.override_locale(locale='ru')
    assert isinstance(result, BaseDataProvider)


# Generated at 2022-06-25 20:20:12.697281
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='ru', seed=5)
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_0.override_locale('fr'):
        assert base_data_provider_0.locale == 'fr'
    assert base_data_provider_0.locale == 'ru'
    with base_data_provider_0.override_locale('cy'):
        assert base_data_provider_0.locale == 'cy'
    assert base_data_provider_0.locale == 'ru'
    with base_data_provider_0.override_locale('tr'):
        assert base_data_provider_0.locale == 'tr'
    assert base_data_prov

# Generated at 2022-06-25 20:20:19.318847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale = 'en')
    base_provider_0 = BaseProvider()
    try:
        with base_provider_0.override_locale() as base_data_provider_0:
            pass
    except Exception as e:
        assert isinstance(e, ValueError)



# Generated at 2022-06-25 20:20:30.985933
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

    data_provider_0 = DataProvider()
    with data_provider_0.override_locale(locales.EN):
        pass

    with data_provider_0.override_locale(locales.EN):
        pass

    with data_provider_0.override_locale(locales.EN):
        pass

    with data_provider_0.override_locale(locales.EN):
        pass


# Generated at 2022-06-25 20:20:56.876243
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale() as base_data_provider_1:
        str_0 = base_data_provider_1.get_current_locale()
        assert str_0 == 'en'

    int_0 = len(base_provider_0.random.Seed.cache)
    assert int_0 == 2

# Generated at 2022-06-25 20:21:01.107395
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_1 = BaseDataProvider(locale="en")
    base_provider_1.override_locale(locale="ru")



# Generated at 2022-06-25 20:21:05.133741
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    str_0 = base_data_provider_0.override_locale()

    assert str_0 == 'en'

# Generated at 2022-06-25 20:21:16.809703
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    base_data_provider_2 = BaseDataProvider(locale=locales.RU)
    base_data_provider_3 = BaseDataProvider(locale=locales.RU,
                                            seed=base_provider_0.seed)
    with base_data_provider_1.override_locale(locale=locales.EN) as provider:
        assert base_data_provider_1 == provider
    locale = base_data_provider_0.get_current_locale()
    assert locale == locales.EN
    locale = base_data_provider_1

# Generated at 2022-06-25 20:21:19.981124
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale("en") == "<en>"

# Generated at 2022-06-25 20:21:25.980051
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider('en', 1)
    master_lang = base_data_provider_1.get_current_locale()
    with base_data_provider_1.override_locale('ru')as new_local_provider:
        assert new_local_provider.get_current_locale() == 'ru'
    assert base_data_provider_1.get_current_locale() == master_lang

# Generated at 2022-06-25 20:21:37.542037
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test case 1
    data_provider_1 = BaseDataProvider()
    with data_provider_1.override_locale('ru'):
        assert data_provider_1.locale == 'ru'
    assert data_provider_1.locale == locales.DEFAULT_LOCALE

    # Test case 2
    data_provider_2 = BaseDataProvider()
    with data_provider_2.override_locale('ru'):
        assert data_provider_2.locale == 'ru'
        with data_provider_2.override_locale('en'):
            assert data_provider_2.locale == 'en'
        assert data_provider_2.locale == 'ru'
    assert data_provider_2.locale == locales.DEFAULT_LOC

# Generated at 2022-06-25 20:21:45.447487
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A_BaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super(A_BaseDataProvider, self).__init__(locale)
    base_data_provider = A_BaseDataProvider()
    with base_data_provider.override_locale() as provider:
        assert isinstance(provider, A_BaseDataProvider)


# Generated at 2022-06-25 20:21:57.786097
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_provider = BaseDataProvider()
    test_provider.override_locale.__wrapped__.__name__
    import mimesis.builtins
    a = mimesis.builtins.Cryptographic()
    a.override_locale.__wrapped__.__name__
    import mimesis.builtins
    a = mimesis.builtins.Html()
    a.override_locale.__wrapped__.__name__
    a.random.__class__
    a.random.seed(None)
    a.random.__class__
    import mimesis.builtins
    a = mimesis.builtins.Html()
    a.seed
    a.locale
    a.random.seed(None)
    a == a

# Generated at 2022-06-25 20:22:02.517126
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    test_locale = "en_US"
    with base_data_provider.override_locale(test_locale):
        pass


# Generated at 2022-06-25 20:22:54.640955
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    test_locale = 'en'
    with base_data_provider.override_locale(test_locale) as base_data_provider:
        print(base_data_provider.get_current_locale())

test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:59.258395
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # AssertionError: «BaseDataProvider» has not locale dependent
    try:
        with base_data_provider_0.override_locale():
            pass
        raise AssertionError('AssertionError expected')
    except ValueError:
        pass


# Generated at 2022-06-25 20:23:03.426430
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale("sv_SE"):
        assert bdp.locale == "sv_SE"


# Generated at 2022-06-25 20:23:12.037670
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider

    p = Person('ru')
    assert p.full_name() == 'Стас Марченко'

    p = Person(locale='ru')
    assert p.full_name() == 'Лера Павлова'

    with p.override_locale():
        assert p.full_name() == 'Лера Павлова'
    
    with p.override_locale('en'):
        assert p.full_name() == 'Stephanie Wiggins'

    with p.override_locale('en'):
        assert p.full_name() == 'Stephanie Wiggins'


# Generated at 2022-06-25 20:23:12.820218
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru'):
        pass

# Generated at 2022-06-25 20:23:21.295858
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    address_0 = Address()
    with address_0.override_locale(locales.EN):
        address_0.generator.seed(77655947)
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_0.get_postal_code()
        address_

# Generated at 2022-06-25 20:23:23.386807
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ """
    base_data_provider_0 = BaseDataProvider()
    # TypeError: __init__() takes at least 2 positional arguments (1 given)
    base_data_provider_0.override_locale()


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:23:26.888365
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale():
        assert 1 #Test Pass



# Generated at 2022-06-25 20:23:29.193614
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale="en"):
        pass

# Generated at 2022-06-25 20:23:38.631544
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
    with base_data_provider_0.override_locale('en'):
        pass
    with base_data_provider_0.override_locale('eng'):
        pass
    with base_data_provider_0.override_locale('enGB'):
        pass
    with base_data_provider_0.override_locale('en-GB'):
        pass



# Generated at 2022-06-25 20:25:40.236418
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    person_0 = Person()
    with person_0.override_locale('en-US'):
        assert person_0.full_name() == 'Sara Porter'
        assert person_0.full_name() == 'Sara Porter'
        assert person_0.full_name() == 'Sara Porter'
        assert person_0.full_name() == 'Sara Porter'

    with person_0.override_locale('ru'):
        assert person_0.full_name() == 'Людмила Сергеевна Журова'

# Generated at 2022-06-25 20:25:42.540074
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    TEST_LOCALE = locales.EN
    assert BaseDataProvider().override_locale(TEST_LOCALE)

# Generated at 2022-06-25 20:25:50.181155
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_0 = locales.EN
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale(locale_0) as it:
        # AssertionError when the object it is not equal to the object
        # data_provider_0
        assert it == data_provider_0
    # AssertionError when the attribute get_current_locale(data_provider_0)
    # is not equal to the string locale_0
    assert locale_0 == data_provider_0.get_current_locale()


# Generated at 2022-06-25 20:25:55.089815
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    BaseDataProvider.override_locale()
    '''

    # __init__
    base_data_provider_0 = BaseDataProvider()

    # override_locale
    with base_data_provider_0.override_locale() as base_data_provider_1:
        pass



# Generated at 2022-06-25 20:26:05.957109
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test case for method override_locale of class BaseDataProvider without params
    # ValueError: «BaseDataProvider» has not locale dependent
    test_BaseDataProvider_override_locale_0()
    # Test case for method override_locale of class BaseDataProvider with params (locale='en')
    # context manager
    test_BaseDataProvider_override_locale_1()
    # Test case for method override_locale of class BaseDataProvider with params (locale='en')
    # context manager with yield
    test_BaseDataProvider_override_locale_2()


# Generated at 2022-06-25 20:26:15.510990
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test with :
    # - an instance of BaseDataProvider
    # Expect :
    # - a ValueError because «BaseDataProvider» has not locale dependent.
    try:
        provider = BaseDataProvider()
        with provider.override_locale():
            pass
        raise ValueError
    except ValueError:
        pass

    # Test with :
    # - an instance of BaseDataProvider
    # Expect :
    # - a ValueError because «BaseDataProvider» has not locale dependent.
    try:
        provider = BaseDataProvider()
        with provider.override_locale(locale='fr'):
            pass
        raise ValueError
    except ValueError:
        pass

    # Test with :
    # - an instance of BaseDataProvider
    # Expect :
    # - a TypeError because «BaseDataProvider» has not

# Generated at 2022-06-25 20:26:19.097115
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    try:
        with base_data_provider_0.override_locale(locales.EN):
            pass
    except ValueError as err:
        assert str(err) == '«BaseDataProvider» has not locale dependent'


# Generated at 2022-06-25 20:26:21.553816
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale="ru")
    with base_data_provider.override_locale("ru") as fake:
        assert fake.locale == "ru"
    assert base_data_provider.locale == "ru"


# Generated at 2022-06-25 20:26:23.606761
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    with base_data_provider.override_locale(locale='ru'):
        pass



# Generated at 2022-06-25 20:26:30.663911
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)
            self._datafile = ''

        def test(self, locale: str = locales.DEFAULT_LOCALE):
            return '{}/{}'.format(self.get_current_locale(), locale)

        def test_key_error(self):
            self.get_data('key_error')

    provider = TestProvider(locale='en')

    with provider.override_locale('ru') as provider_ru:
        assert provider_ru.test() == 'ru/ru'

    assert provider.test() == 'en/en'

    provider = TestProvider(locale='en-GB')
