

# Generated at 2022-06-25 20:18:40.687670
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
    locales.SUPPORTED_LOCALES[0]
    base_data_provider_1 = BaseDataProvider(locale=locales.SUPPORTED_LOCALES[0])
    with base_data_provider_1.override_locale():
        pass

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:18:47.219900
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider("en-US", "4")
    with contextlib.contextmanager as l0:
        with base_data_provider_0.override_locale("en_US"):
            l0 = base_data_provider_0
        l0 = base_data_provider_0
    assert l0 == l0


# Generated at 2022-06-25 20:18:53.864015
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale('ru') as result:
        assert result.locale == 'ru'
    with raises(ValueError):
        with base_data_provider_1.override_locale('russian'):
            pass

# Generated at 2022-06-25 20:18:54.815131
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert True


# Generated at 2022-06-25 20:19:00.982146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_en = BaseDataProvider('en')
    base_data_provider_en._pull = lambda : 'testing'
    with base_data_provider_en.override_locale(locale='en') as provider:
        provider.locale = 'en'
        assert provider.locale == 'en'


# Generated at 2022-06-25 20:19:03.804376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en'):
        pass


# Generated at 2022-06-25 20:19:11.142042
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # TestCase 0
    def test_case_0():
        base_data_provider_0 = BaseDataProvider(locale='')

    # TestCase 1
    def test_case_1():
        base_data_provider_override_locale_0_0 = BaseDataProvider(locale='ru')
        base_data_provider_override_locale_0_0._override_locale(locale='ru')
        with base_data_provider_override_locale_0_0.override_locale(locale='ru'):
            pass

    # TestCase 2
    def test_case_2():
        base_data_provider_override_locale_0_0 = BaseDataProvider(locale='ru')

# Generated at 2022-06-25 20:19:14.736310
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Base class for all data providers."""
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider(locale='en')
    base_data_provider_2 = BaseDataProvider()


# Generated at 2022-06-25 20:19:24.807907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass

    with base_data_provider_0.override_locale() as base_data_provider_0:
        assert type(base_data_provider_0).__name__ == "BaseDataProvider"
        assert base_data_provider_0.get_current_locale() == "en"



# Generated at 2022-06-25 20:19:29.730238
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en') as local_provider:
        assert str(base_data_provider_0) == 'BaseDataProvider <en>'
    assert str(base_data_provider_0) == 'BaseDataProvider <en>'


# Generated at 2022-06-25 20:19:44.131405
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()
    OverrideLocale = base_provider.override_locale()
    assert isinstance(OverrideLocale, type(base_provider))

# Generated at 2022-06-25 20:19:50.073770
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.builtins import Address
    from mimesis.enums import Gender, MaritalStatus

    with Person('ru').override_locale('uk') as p:
        assert p.locale == "uk"
        assert p.gender() == Gender.MALE
        assert p.marital_status() == MaritalStatus.WIDOWER

    assert Person('ru').locale == "ru"
    assert Person('ru').gender() == Gender.FEMALE
    assert Person('ru').marital_status() == MaritalStatus.DIVORCED

    with Address('ru').override_locale('uk') as p:
        assert p.locale == "uk"

    assert Address('ru').locale == "ru"

# Generated at 2022-06-25 20:20:01.554984
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()

    # Test case 1
    try:
        with data_provider.override_locale('en'):
            assert data_provider.get_current_locale() == 'en'
    except ValueError:
        # If locale not supported, then we must get ValueError exception
        assert True

    # Test case 2
    try:
        with data_provider.override_locale('ru'):
            assert data_provider.get_current_locale() == 'ru'
    except ValueError:
        # If locale not supported, then we must get ValueError exception
        assert True

    # Test case 3

# Generated at 2022-06-25 20:20:08.362313
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_1 = BaseDataProvider(locale=locales.EN)
    #
    # Content of method _pull of class BaseDataProvider
    # def _pull(self):
    #     locale = self.locale
    #     file_path = Path(self._data_dir).joinpath(locale, self._datafile)
    #     with open(file_path, 'r', encoding='utf8') as f:
    #         # self._data = json.load(f)
    #         self._data = dict(a=1)
    #
    # In the test we declare a variable `file_content` and initialize it
    # with dictionary `dict(a=1)`. Next, we do not call method _pull
    # of class BaseDataProvider. Next we assert that variable _data
    # of class BaseData

# Generated at 2022-06-25 20:20:13.096330
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    str_0 = str(base_data_provider_0)
    assert str_0 == 'BaseDataProvider <en>'
    str_1 = str(base_data_provider_0)
    assert str_1 == 'BaseDataProvider <en>'
    with BaseDataProvider.override_locale('en'):
        assert True # TODO: may be implement real tests here
    with BaseDataProvider.override_locale('en'):
        assert True # TODO: may be implement real tests here


# Generated at 2022-06-25 20:20:24.629823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def method_test(test_locale: str, seed: Seed, data_file_1: Any, data_file_2: Any):
        base_data_provider_1 = BaseDataProvider(seed=seed, locale=test_locale)
        base_data_provider_1._pull(data_file_1)
        data_1 = base_data_provider_1._data
        base_data_provider_2 = BaseDataProvider(seed=seed, locale=test_locale)
        base_data_provider_2._pull(data_file_2)
        data_2 = base_data_provider_2._data
        return not any(map(lambda a, b: a == b, data_1.values(), data_2.values()))

# Generated at 2022-06-25 20:20:27.834361
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    r = BaseDataProvider()
    with r.override_locale() as r:
        assert r.locale == 'en'

# Generated at 2022-06-25 20:20:34.724701
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Creating a contextmanager instance
    base_data_provider_0 = BaseDataProvider()
    # Call method override_locale
    # with arguments
    # The call None returns the value None
    base_data_provider_0.override_locale()()
    # Creating a contextmanager instance
    base_data_provider_1 = BaseDataProvider()
    # Call method override_locale
    # with arguments
    # The call None returns the value None
    base_data_provider_1.override_locale()()
    # Creating a contextmanager instance
    base_data_provider_2 = BaseDataProvider()
    # Call method override_locale
    # with arguments
    # The call None returns the value None
    base_data_provider_2.override_locale(locale='cs')()

# Generated at 2022-06-25 20:20:41.050197
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_provider = BaseDataProvider('en')
    with test_provider.override_locale('ru'):
        assert test_provider.get_current_locale() == 'ru'
    assert test_provider.get_current_locale() == 'en'

# Generated at 2022-06-25 20:20:44.200760
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider()
    with p.override_locale(locales.EN):
        assert p.locale == locales.EN


# Generated at 2022-06-25 20:21:10.958177
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale=locales.EN)
    with base_data_provider.override_locale(locale=locales.EN) as bdp:
        assert bdp.locale == locales.EN

# Generated at 2022-06-25 20:21:15.778717
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import address
    from mimesis.enums import Gender
    address_0 = address.Address(locale='ru', seed=1)
    address_1 = address.Address(locale='en', seed=1)
    address_0.geo.latitude()
    address_1.geo.latitude()
    with address_0.override_locale('en'):
        address_0.geo.latitude()
    address_0.geo.latitude()
    with address_0.override_locale('ru'):
        address_0.geo.latitude()
    address_0.geo.latitude()
    address_1.geo.latitude()

# Generated at 2022-06-25 20:21:21.585292
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN) as locale_provider:
        assert locale_provider.get_current_locale() == locales.EN

test_case_0()
test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:26.487208
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale=locales.EN):
        assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-25 20:21:30.925099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._override_locale(locales.EN)
    base_data_provider_0._data["provinces"]["common"].pop()
    base_data_provider_0._data["provinces"]["common"].pop()

# Generated at 2022-06-25 20:21:32.988033
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    num_tests = 1000
    test = False

    for _ in range(num_tests):
        base_data_provider_1 = BaseDataProvider()

        try:
            with base_data_provider_1.override_locale():
                pass
        except ValueError:
            test = True

    assert test

# Generated at 2022-06-25 20:21:34.611079
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider('en')
    with base_provider.override_locale('ru') as bp:
      return bp.random.random()


# Generated at 2022-06-25 20:21:42.047827
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

test_BaseDataProvider_override_locale()
test_case_0()

# Generated at 2022-06-25 20:21:47.104525
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create instance of BaseDataProvider with locale 'en'
    base_data_provider_0 = BaseDataProvider(locale='en')

    # Get instance of BaseDataProvider for locale 'ru'
    with base_data_provider_0.override_locale(locale='ru') as base_data_provider_0:
        assert (base_data_provider_0.get_current_locale() == 'ru')

# Generated at 2022-06-25 20:21:52.328910
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # test case 1

    base_provider_0 = BaseProvider()
    # test case 2
    with base_provider_0.override_locale('en', ):
        pass


# Generated at 2022-06-25 20:22:43.571477
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class BaseDataProviderSub(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

    base_data_provider_0 = BaseDataProviderSub()

    with base_data_provider_0.override_locale(locale=locales.EN) as ctx_0:
        pass
    pass


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:47.723123
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_override_locale_0 = BaseDataProvider()
    with base_data_provider_override_locale_0.override_locale() as result:
        assert isinstance(result, BaseDataProvider) == True


# Generated at 2022-06-25 20:22:53.499083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert not hasattr(BaseProvider, 'override_locale')

    assert not hasattr(BaseDataProvider, 'override_locale')

    with BaseDataProvider().override_locale() as provider:
        assert provider is not None


# Generated at 2022-06-25 20:22:54.501364
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-25 20:22:56.874152
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider(locale='en', seed=None)
    with base_data_provider_0.override_locale(locale='en'):
        # do something
        pass

# Generated at 2022-06-25 20:23:01.098403
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale("en"):
        assert BaseDataProvider.get_current_locale("en")

# Generated at 2022-06-25 20:23:10.034140
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    en_person = Person('en')
    ru_person = Person('ru')
    person = Person()

    # En
    with en_person.override_locale():
        assert person.full_name(gender=Gender.FEMALE) == en_person.full_name(gender=Gender.FEMALE)

    # Ru
    with ru_person.override_locale():
        assert person.full_name(gender=Gender.FEMALE) == ru_person.full_name(gender=Gender.FEMALE)

# Generated at 2022-06-25 20:23:18.569771
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    assert base_data_provider_0.get_current_locale() == locales.EN
    with base_data_provider_0.override_locale(locale=locales.RU):
        assert base_data_provider_0.get_current_locale() == locales.RU
    assert base_data_provider_0.get_current_locale() == locales.EN

# Generated at 2022-06-25 20:23:23.352393
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as p:
        pass
    with BaseDataProvider().override_locale(locales.EN) as p:
        pass

# Generated at 2022-06-25 20:23:28.139621
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_provider = BaseDataProvider()

    with test_provider.override_locale('en'):
        locale = test_provider.locale
    if locale == 'en':
        print("Success")
    else:
        print("Failure")


# Generated at 2022-06-25 20:25:24.077949
# Unit test for method override_locale of class BaseDataProvider

# Generated at 2022-06-25 20:25:30.129253
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialization
    BaseDataProvider_0 = BaseDataProvider()
    # Test execution
    with BaseDataProvider_0.override_locale() as BaseDataProvider_1:
        # Test execution
        assert BaseDataProvider_0 == BaseDataProvider_1
    # Get current func properties
    assert hasattr(BaseDataProvider_0.override_locale, '__code__')
    assert hasattr(BaseDataProvider_0.override_locale, '__annotations__')
    assert hasattr(BaseDataProvider_0.override_locale, '__defaults__')
    assert hasattr(BaseDataProvider_0.override_locale, '__globals__')
    assert hasattr(BaseDataProvider_0.override_locale, '__kwdefaults__')

# Generated at 2022-06-25 20:25:35.728549
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider('ru')
    with base_data_provider_0.override_locale() as res:
        pass


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:37.265239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()

    assert data_provider_0.override_locale()

# Generated at 2022-06-25 20:25:41.423622
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_0 = BaseDataProvider()
    with BaseDataProvider.override_locale(provider_0,locales.EN):
        assert (BaseDataProvider.get_current_locale(provider_0) == locales.EN)
    with BaseDataProvider.override_locale(provider_0,locales.DE):
        assert (BaseDataProvider.get_current_locale(provider_0) == locales.DE)


# Generated at 2022-06-25 20:25:46.647423
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    kwargs_0 = {'locale': 'ru'}
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(**kwargs_0) as base_data_provider_1:
        assert base_data_provider_1.locale == 'ru'
    assert base_data_provider_0.locale == 'en'



# Generated at 2022-06-25 20:25:53.199635
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    en_provider = BaseDataProvider(locales.EN)
    ru_provider = BaseDataProvider(locales.RU)
    with en_provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU
        assert provider == ru_provider
    assert en_provider.get_current_locale() == locales.EN
    assert en_provider != ru_provider


# Generated at 2022-06-25 20:25:55.566821
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # assert base_provider_1 = BaseDataProvider(locale=locales.EN)
    assert True

# Generated at 2022-06-25 20:26:05.957069
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with contextlib.suppress(ValueError):
        base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:26:08.677278
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        print(base_data_provider_0.locale) # en