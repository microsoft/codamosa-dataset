

# Generated at 2022-06-25 20:18:41.556138
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale():
        pass



# Generated at 2022-06-25 20:18:46.535583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # First unit test.
    base_data_provider_0 = BaseDataProvider()
    locale_0 = base_data_provider_0.get_current_locale()
    assert locale_0 == 'en'

    # Second unit test.
    p = BaseDataProvider(seed=10)
    with p.override_locale('ru') as pp:
        assert pp.get_current_locale() == 'ru'

    assert p.get_current_locale() == 'en'

# Generated at 2022-06-25 20:18:53.646434
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with base_data_provider_0.override_locale() as result_1:
            assert result_1 is None
    except ValueError as error:
        assert str(error) == '«BaseDataProvider» has not locale dependent'


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:18:56.868273
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale='en'):
        assert base_data_provider_1.get_current_locale() == 'en'


# Generated at 2022-06-25 20:19:00.890001
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_override_locale_0 = BaseDataProvider(locale='en')
    BaseDataProvider_override_locale_0.override_locale()


# Generated at 2022-06-25 20:19:05.920107
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    locale = None
    with base_data_provider_0.override_locale(locale=locale) as x:
        assert x == base_data_provider_0
    assert base_data_provider_0._override_locale(locale=locale) == None


# Generated at 2022-06-25 20:19:10.993997
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale='en'):
        base_data_provider_1.get_current_locale()



# Generated at 2022-06-25 20:19:17.189227
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        locale = base_data_provider_0.get_current_locale()
        assert locale == 'en'
    with base_data_provider_0.override_locale('ru'):
        locale = base_data_provider_0.get_current_locale()
        assert locale == 'ru'

# Generated at 2022-06-25 20:19:24.365519
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider('fr_FR')
    with base_data_provider_0.override_locale('pl_PL'):
        assert base_data_provider_0.locale == 'pl_PL'
    assert base_data_provider_0.locale == 'fr_FR'


# Generated at 2022-06-25 20:19:30.885874
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def _BaseDataProvider_override_locale(locale, target):
        with BaseDataProvider().override_locale(locale=locale) as bdp:
            assert bdp.get_current_locale() == target

    _BaseDataProvider_override_locale(locales.DEFAULT_LOCALE, locales.EN)
    _BaseDataProvider_override_locale(locales.RU, locales.RU)
    _BaseDataProvider_override_locale(locales.RU, locales.RU)



# Generated at 2022-06-25 20:19:48.969167
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    # test case 0
    try:
         BaseDataProvider.override_locale()
    except(AttributeError):
         print(AttributeError)

    # test case 1
    with BaseDataProvider.override_locale(locale=locale):
         print('BaseDataProvider.override_locale(locale=locale)')

    # test case 2
    try:
        with BaseDataProvider.override_locale() as provider:
            pass
    except(ValueError):
        print(ValueError)


# Generated at 2022-06-25 20:19:53.152644
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('en-US'):
        print(BaseDataProvider.get_current_locale())

# Generated at 2022-06-25 20:19:56.882771
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:20:09.979749
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import (
        Address, Address, Address, Person, Person, Person, Address, 
    )
    base_data_provider_0 = BaseDataProvider(locale=locales.EN)
    locale = locales.EN
    try:
        with base_data_provider_0.override_locale(locale=locale) as base_data_provider_1:
            assert base_data_provider_0 is base_data_provider_1
    except ValueError:
        pass
    else:
        assert False
    address_0 = Address()
    person_0 = Person()
    address_1 = Address(seed=0)
    person_1 = Person(seed=0)
    address_2 = Address(seed=1234567890)

# Generated at 2022-06-25 20:20:22.932959
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.base import BaseDataProvider
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    # Create a RussiaSpecProvider instance
    rus_provider = RussiaSpecProvider()

    # Test 1
    # Test overriding existent locale
    with rus_provider.override_locale(locales.DE):
        assert rus_provider.locale == locales.DE

    # Test 2
    # Test overriding not existent locale
    with pytest.raises(UnsupportedLocale):
        with rus_provider.override_locale(locales.NR):
            rus_provider.get_person(locales.NR)



# Generated at 2022-06-25 20:20:30.698585
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale():
            pass
    except ValueError as exc:
        assert str(exc) == '«BaseDataProvider» has not locale dependent'
    else:
        raise TypeError('Test of method override_locale of class BaseDataProvider is failed')



# Generated at 2022-06-25 20:20:42.536878
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDataProvider_0(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    base_data_provider_0 = BaseDataProvider_0('en')
    try:
        with base_data_provider_0.override_locale('en') as base_data_provider_0:
            base_data_provider_0.locale = 'en'
    except ValueError as e:
        assert '«BaseDataProvider_0» has not locale dependent' in str(e)


# Generated at 2022-06-25 20:20:51.865891
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('ru') as locale:
        assert locale.locale == 'ru'
        with locale.override_locale('ru-ru') as locale:
            assert locale.locale == 'ru-ru'
        assert locale.locale == 'ru-ru'
    assert bdp.locale == 'en'


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:55.177763
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    data = {}
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale(locale) == (
        base_data_provider, data, None)



# Generated at 2022-06-25 20:21:00.277247
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:21:24.316355
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en') as _bdp:
        print(_bdp)

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:34.759890
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        pass

    b = TestBaseDataProvider()
    with b.override_locale(locale='en'):
        assert b.get_current_locale() == 'en'
    assert b.get_current_locale() == 'en'

    with b.override_locale(locale='uk'):
        assert b.get_current_locale() == 'uk'
    assert b.get_current_locale() == 'en'

# Generated at 2022-06-25 20:21:39.946216
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
    str_0 = str(base_data_provider_0)

# Generated at 2022-06-25 20:21:47.419579
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale=locale) as base_data_provider_1_instance:
        assert isinstance(base_data_provider_1_instance, BaseDataProvider)
        assert base_data_provider_1_instance == base_data_provider_1
        assert base_data_provider_1.get_current_locale() == locale
    assert base_data_provider_1.get_current_locale() != locale


# Generated at 2022-06-25 20:21:50.668410
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='ru').override_locale():
        assert True

# Generated at 2022-06-25 20:21:58.457453
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    path_to_data_dir = Path(__file__).parent.parent.parent.joinpath('data')
    base_data_provider = BaseDataProvider(locale="fr")

    with base_data_provider.override_locale('de'):
        assert base_data_provider.get_current_locale() == "de"

        with base_data_provider.override_locale('ru'):
            assert base_data_provider.get_current_locale() == "ru"

        assert base_data_provider.get_current_locale() == "de"

    assert base_data_provider.get_current_locale() == "fr"

# Generated at 2022-06-25 20:22:00.063075
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()



# Generated at 2022-06-25 20:22:10.485678
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with contextlib.redirect_stdout(None):
        base_data_provider_0 = BaseDataProvider()
    with contextlib.redirect_stdout(None):
        with base_data_provider_0.override_locale('fr'):
            pass
    with contextlib.redirect_stdout(None):
        base_data_provider_1 = BaseDataProvider()
    with contextlib.redirect_stdout(None):
        with base_data_provider_1.override_locale('en'):
            pass
    with contextlib.redirect_stdout(None):
        base_data_provider_2 = BaseDataProvider(seed=10)

# Generated at 2022-06-25 20:22:13.884017
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    _locale = 'car'
    base_data_provider_1 = BaseDataProvider(locale=_locale)
    with BaseDataProvider() as base_data_provider_2:
        base_data_provider_2.locale = _locale


# Generated at 2022-06-25 20:22:18.963975
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        assert base_data_provider_0.get_current_locale() == 'en'


# Generated at 2022-06-25 20:23:08.914099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    with BaseDataProvider.override_locale() as provider:
        assert isinstance(provider, BaseDataProvider)

# Generated at 2022-06-25 20:23:14.069778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale='en')
    with base_data_provider.override_locale('ru') as provider:
        locale: str = provider.get_current_locale()
        assert locale == 'ru'
        assert [provider.get_current_locale(), base_data_provider.get_current_locale()] == ['ru', 'ru']
    assert [provider.get_current_locale(), base_data_provider.get_current_locale()] == ['ru', 'en']

    # But on the current Way, you can use only 'en' and 'ru', because other locales can not pass the test
    # with base_data_provider.override_locale('ja') as provider:
    #    locale: str = provider.get_current_loc

# Generated at 2022-06-25 20:23:20.697977
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_1 = BaseDataProvider(locale='ru', seed=42)

    with base_data_provider_1.override_locale(locale='en') as locale_provider:
        pass
        # print(locale_provider.locale) # en

    with base_data_provider_1.override_locale(locale='en') as locale_provider:
        pass
        # print(locale_provider.locale) # en

    # print(base_data_provider_1.locale) # ru


# Generated at 2022-06-25 20:23:33.924825
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesi.random import Random
    from mimesis.builtins import Datetime
    from mimesis.enums import Gender
    from mimesis.providers import DateTime
    from mimesis.builtins import Person
    dt = DateTime(seed=1234)
    with dt.override_locale('ru'):
        r = Random()
        r.seed(1234)
        d = Datetime(1234)
        d.seed(1234)
        p = Person()
        p.seed(1234)
        p.validate_enum(None, Gender) == 'male'



# Generated at 2022-06-25 20:23:39.013464
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        assert base_data_provider_0.locale == 'en'
    if base_data_provider_0.locale != 'en':
        raise Exception('Fail')
    with base_data_provider_0.override_locale() as base_data_provider_0:
        with base_data_provider_0.override_locale() as base_data_provider_0:
            assert base_data_provider_0.locale == 'en'
        if base_data_provider_0.locale != 'en':
            raise Exception('Fail')

# Generated at 2022-06-25 20:23:48.564249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        base_data_provider_1.override_locale()
    base_data_provider_2 = BaseDataProvider()
    with base_data_provider_2.override_locale() as base_data_provider_3:
        base_data_provider_3.override_locale()


# Generated at 2022-06-25 20:24:07.126812
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale(locale=locale) as obj_0:
        # Testing attribute locale of object obj_0
        assert hasattr(obj_0, "locale")
        assert getattr(obj_0, "locale") == 'en'

    # Testing attribute locale of obj_0
    assert hasattr(obj_0, "locale")
    assert getattr(obj_0, "locale") == 'en'



# Generated at 2022-06-25 20:24:17.842757
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    origin_locale = base_data_provider_0.locale
    # Test Case 1: is this function just changes the current locale?
    with base_data_provider_0.override_locale('en'):
        assert base_data_provider_0.locale == locales.EN
    assert base_data_provider_0.locale == origin_locale
    # Test Case 2: What is the effect of the first line?
    with base_data_provider_0.override_locale('ru_ru'):
        assert base_data_provider_0.locale == 'ru_ru'
    # Test Case 3: What is the effect of the first line?
    with base_data_provider_0.override_locale():
        assert base_data_provider_0.locale

# Generated at 2022-06-25 20:24:28.822081
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale():
            assert True
    except ValueError:
        assert True
    base_data_provider_1 = BaseDataProvider()
    try:
        with base_data_provider_1.override_locale('en'):
            assert True
    except ValueError:
        assert True
    # base_data_provider_2 = BaseDataProvider()
    # with base_data_provider_2.override_locale('en'):
    #     assert True
    # assert base_data_provider_2.get_current_locale() == 'en'
    # base_data_provider_3 = BaseDataProvider()
    # with base_data_provider_

# Generated at 2022-06-25 20:24:39.576160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    instance0 = BaseDataProvider()
    with instance0.override_locale('en'):
        assert instance0.__str__() == 'BaseDataProvider <en>'
    with instance0.override_locale('en-gb'):
        assert instance0.__str__() == 'BaseDataProvider <en-gb>'
    with instance0.override_locale('en-US'):
        assert instance0.__str__() == 'BaseDataProvider <en-us>'
    with instance0.override_locale('en-US'):
        assert instance0.__str__() == 'BaseDataProvider <en-us>'
    with instance0.override_locale('en-GB'):
        assert instance0.__str__() == 'BaseDataProvider <en-gb>'

# Generated at 2022-06-25 20:26:15.571490
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Test that AttributeError is raised
    try:
        with base_data_provider_0.override_locale() as base_data_provider_val_0:
            assert isinstance(base_data_provider_val_0, BaseDataProvider)
    except (AttributeError, ValueError):
        pass


# Generated at 2022-06-25 20:26:19.415516
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    # Test error
    try:
        base_data_provider_0.override_locale()
    except ValueError as error:
        __test_msg = str(error)
        assert __test_msg == '«BaseDataProvider» has not locale dependent'


# Generated at 2022-06-25 20:26:22.473317
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Unit test for override_locale with existing locale
    with BaseDataProvider().override_locale('ru'):
        assert True == True
    # Unit has not locale dependent
    try:
        with BaseDataProvider().override_locale('ru'):
            assert True == True
    except ValueError:
        assert True == True


# Generated at 2022-06-25 20:26:25.113784
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='ru'):
        pass
    base_data_provider_0.reseed()



# Generated at 2022-06-25 20:26:26.873517
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as provider:
        assert provider.locale == locales.DEFAULT_LOCALE
        assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-25 20:26:30.893708
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    locale = locales.EN
    with base_data_provider.override_locale(locale) as provider:
        test = provider.get_current_locale() == locale

    assert test, 'Not equal current locale and context manager'
    assert base_data_provider.get_current_locale() == locales.DEFAULT_LOCALE, \
           'Current locale not equal default locale'


# Generated at 2022-06-25 20:26:37.115002
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.EN) as provider:
        pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:26:42.398889
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    with BaseDataProvider.override_locale(locale='en') as data_provider:
        address = Address(data_provider)
        address.region()
        assert address.__class__.__name__ == 'Address'

    with BaseDataProvider.override_locale(locale='zh') as data_provider:
        address = Address(data_provider)
        address.region()
        assert address.__class__.__name__ == 'Address'


# Generated at 2022-06-25 20:26:48.893167
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data = {'aa': 'bb', 'cc': 'dd'}
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._data = data
    base_data_provider_0.locale = ''
    with base_data_provider_0.override_locale():
        assert base_data_provider_0._data == {'aa': 'bb', 'cc': 'dd'}


# Generated at 2022-06-25 20:26:51.160829
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as bdp:
        assert isinstance(bdp, BaseDataProvider)
