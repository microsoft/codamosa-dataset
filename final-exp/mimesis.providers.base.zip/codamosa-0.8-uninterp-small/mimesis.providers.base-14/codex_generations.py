

# Generated at 2022-06-25 20:18:44.102581
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(base_data_provider_0.locale):
        pass


# Generated at 2022-06-25 20:18:46.847355
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='en').override_locale('ru') as bdp:
        assert bdp.get_current_locale() == 'ru'
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'

# Generated at 2022-06-25 20:18:54.677567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale='en'):
        locale_1_0 = base_data_provider_1.get_current_locale()
    with base_data_provider_1.override_locale(locale='ru'):
        locale_1_1 = base_data_provider_1.get_current_locale()
    with base_data_provider_1.override_locale(locale='en'):
        locale_1_2 = base_data_provider_1.get_current_locale()
    locale_1_3 = base_data_provider_1.get_current_locale()


# Generated at 2022-06-25 20:18:57.973931
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    assert base_data_provider_1.override_locale() == True

# Generated at 2022-06-25 20:19:00.553162
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale() as provider:
        assert provider is bdp



# Generated at 2022-06-25 20:19:03.398908
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    ctx_mngr = provider.override_locale('asd')
    assert ctx_mngr


# Generated at 2022-06-25 20:19:09.436674
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru_RU'
    expected = {locale: {'name': 'Мария Кириллова'}}

    with BaseDataProvider.override_locale(locale=locale) as provider:
        actual = provider._data

    assert expected[locale]['name'] == actual['name']

# Generated at 2022-06-25 20:19:12.519344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale('en') as base_data_provider:
        assert base_data_provider.locale == 'en'

# Generated at 2022-06-25 20:19:16.369803
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.RU):
        assert base_data_provider_0.locale == locales.RU


# Generated at 2022-06-25 20:19:20.433863
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    try:
        with bdp.override_locale('en'):
            pass
    except ValueError:
        ...

# Generated at 2022-06-25 20:19:32.601724
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass


# Generated at 2022-06-25 20:19:37.019222
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        base_data_provider_1 = BaseDataProvider()
        for _ in range(10):
            with base_data_provider_1.override_locale(locale=locales.EN):
                pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:19:49.368632
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address, AddressElements

    with BaseDataProvider().override_locale(locales.JA) as provider:
        assert provider.get_current_locale() == locales.JA
        assert provider.get_postal_code() == AddressElements()._data[locales.JA]['postal_code']

    with BaseDataProvider().override_locale(locales.JA) as provider:
        assert provider.get_current_locale() == locales.JA
        assert provider.get_postal_code() == AddressElements()._data[locales.JA]['postal_code']

    with BaseDataProvider().override_locale(locales.JA) as provider:
        assert provider.get_current_locale() == locales.JA
        assert provider.get_postal_

# Generated at 2022-06-25 20:19:54.613326
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale():
            pass
    except ValueError:
        pass



# Generated at 2022-06-25 20:19:58.155580
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    value_0 = BaseDataProvider()
    assert isinstance(value_0.override_locale(), contextlib.closing)



# Generated at 2022-06-25 20:20:01.518396
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    expected_value = 'BaseProvider <ru>'
    data_provider = BaseDataProvider('ru')
    with data_provider.override_locale('en'):
        result = str(data_provider)
    assert result == expected_value

# Generated at 2022-06-25 20:20:06.727888
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = base_data_provider_0.override_locale()
    assert base_data_provider_1 is base_data_provider_0

# Generated at 2022-06-25 20:20:09.780140
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.override_locale('en').__class__.__name__ == 'BaseDataProvider'


# Generated at 2022-06-25 20:20:17.301218
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    try:
        with base_data_provider_0.override_locale('ru') as base_data_provider_1:
            pass
    except Exception as e:
        assert isinstance(e, ValueError)
    else:
        assert False # Expecting an exception from this call


# Generated at 2022-06-25 20:20:23.472480
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('es-ES'):
        pass
    # Assert that the result of a function call is equal to expected value.
    assert base_data_provider_0.get_current_locale() == 'es-ES'

# Generated at 2022-06-25 20:20:51.865382
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale='ru', seed=None)
    with base_data_provider.override_locale(locale='ru') as base_data_provider_override_locale:
        assert base_data_provider_override_locale.get_current_locale() == 'ru'
    assert base_data_provider.get_current_locale() == 'ru'


# Generated at 2022-06-25 20:20:54.015769
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider() as base_data_provider:
        pass


# Generated at 2022-06-25 20:20:59.115956
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Locale of language: English, region: UK
    with BaseDataProvider.override_locale('en-gb'):
        pass
    # Locale of language: Russian, region: Ukraine
    with BaseDataProvider.override_locale('ru-ua'):
        pass
    # Locale of language: Russian, region: Ukraine
    with BaseDataProvider.override_locale('ru_ua'):
        pass
    # Locale of language: Russian, region: Ukraine
    for _ in range(5):
        with BaseDataProvider.override_locale('ru-ua'):
            pass
    # Locale of language: English, region: US
    with BaseDataProvider.override_locale('en_us'):
        pass
    # Locale of language: English, region: US

# Generated at 2022-06-25 20:21:02.583901
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale()


# Generated at 2022-06-25 20:21:06.114421
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale():
        pass


# Generated at 2022-06-25 20:21:10.214550
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider() as base_data_provider_1:
        assert str(base_data_provider_1) == 'BaseDataProvider <en>'


# Generated at 2022-06-25 20:21:18.631100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(seed=1)
    # Test 1
    # Test normal execution
    # seed=1,locale='en'
    with provider.override_locale():
        pass
    # Test 2
    # Test raise ValueError '«» has not locale dependent'
    # seed=1,locale='en'
    try:
        with provider.override_locale('ru'):
            pass
    except ValueError:
        pass
    provider = BaseDataProvider(locale='en', seed=1)
    # Test 3
    # Test raise ValueError '«» has not locale dependent'
    # seed=1,locale='en'
    try:
        with provider.override_locale():
            pass
    except ValueError:
        pass


# Generated at 2022-06-25 20:21:26.368819
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale('en')
    base_data_provider_1 = BaseDataProvider('en')
    base_data_provider_1.override_locale('en')
    base_data_provider_2 = BaseDataProvider('en')
    base_data_provider_2.override_locale('ru')
    base_data_provider_3 = BaseDataProvider()
    base_data_provider_3.override_locale('ru')


# Generated at 2022-06-25 20:21:32.975671
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create instance of BaseDataProvider
    base_data_provider_0 = BaseDataProvider()
    # Call method override_locale of the instance base_data_provider_0
    # with arguments 'fr'
    with base_data_provider_0.override_locale('fr'):
        pass

# Generated at 2022-06-25 20:21:38.905352
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider() as provider:
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        with provider.override_locale(locale='ru') as new_provider:
            assert provider.get_current_locale() == 'ru'
            assert new_provider.get_current_locale() == 'ru'
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        assert new_provider.get_current_locale() == 'ru'

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:22:29.214785
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale='ru_RU'):
        base_data_provider._override_locale(locale='en_US')



# Generated at 2022-06-25 20:22:37.818446
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):

        def __init__(self):
            super().__init__(locale='en')

    provider = Provider()

    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale(locale='cs'):
        assert provider.get_current_locale() == 'cs'

    with provider.override_locale(locale='cs'):
        assert provider.get_current_locale() == 'cs'


# Generated at 2022-06-25 20:22:43.693344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locale) as result:
        assert result.get_current_locale() == locale


# Generated at 2022-06-25 20:22:47.723346
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale():
        pass
    base_data_provider_1._override_locale()



# Generated at 2022-06-25 20:22:49.886081
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale(locale='ru'):
        pass
    assert data_provider_0.get_current_locale() == "ru"


# Generated at 2022-06-25 20:22:57.671854
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale("ru"):
        base_data_provider_0.override_locale("ru")
    with base_data_provider_0.override_locale("ru"):
        base_data_provider_0.override_locale("ru")


# Generated at 2022-06-25 20:23:00.077841
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en') as bdp:
        assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-25 20:23:05.401911
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.DEFAULT_LOCALE) as base_data_provider_1:
        pass


# Generated at 2022-06-25 20:23:20.410066
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    datafile = Path('codelists/version.json')
    base_data_provider_0 = BaseDataProvider(locale=locale)
    assert base_data_provider_0.locale == 'en'
    with base_data_provider_0.override_locale(locale='en'):
        assert base_data_provider_0.locale == 'en'
    assert base_data_provider_0.locale == 'en'
    base_data_provider_0.locale = 'it'
    assert base_data_provider_0.locale == 'it'
    with base_data_provider_0.override_locale(locale='ru'):
        assert base_data_provider_0.locale == 'ru'


# Generated at 2022-06-25 20:23:25.618228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as val:
        pass

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:25.650274
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with contextlib.suppress(ValueError):
        base_data_provider_0 = BaseDataProvider()
        with base_data_provider_0.override_locale('ru-RU'):
            assert base_data_provider_0.locale == 'ru'
        assert base_data_provider_0.locale == 'en'


# Generated at 2022-06-25 20:25:26.918808
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()


# Generated at 2022-06-25 20:25:31.032453
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Successful call
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass



# Generated at 2022-06-25 20:25:35.931319
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en'):
        assert base_data_provider.locale == 'en'
    assert base_data_provider.locale != 'en'


# Generated at 2022-06-25 20:25:39.077501
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en') as base_data_provider:
        x = base_data_provider.get_current_locale()
    assert x in ['en']


# Generated at 2022-06-25 20:25:42.837685
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    baseDataProvider = BaseDataProvider()
    try:
        result = baseDataProvider.override_locale(locale)
    except ValueError:
        pass



# Generated at 2022-06-25 20:25:46.131970
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    base_data_provider_0 = BaseDataProvider()
    result_0 = base_data_provider_0.override_locale(locale)
    print(result_0)


# Generated at 2022-06-25 20:25:49.277861
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        try:
            pass
        finally:
            pass


# Generated at 2022-06-25 20:25:51.544858
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:25:55.178100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    Unit test for method override_locale of class BaseDataProvider
    '''
    p = BaseDataProvider()
    with p.override_locale('en'):
        print(p)
