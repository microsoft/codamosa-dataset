

# Generated at 2022-06-25 20:18:38.659967
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-25 20:18:46.995830
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        BaseDataProvider()
    except ValueError:
        print('Test case 1 passed')
    else:
        print('Test case 1 not passed')

    class A(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

    try:
        A().override_locale('ru')
    except ValueError:
        print('Test case 2 passed')
    else:
        print('Test case 2 not passed')

    class B(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self.locale

# Generated at 2022-06-25 20:18:49.071118
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test should raise 'AttributeError'
    try:
        with BaseProvider().override_locale(locale='en'):
            pass
    except AttributeError as err:
        assert True


# Generated at 2022-06-25 20:18:55.033242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale('ru_RU'):
        print(base_data_provider_0)


# Generated at 2022-06-25 20:19:01.943227
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_func():
        my_provider = BaseDataProvider(locale='en')
        with my_provider.override_locale(locale='ru') as my_provider:
            assert my_provider.get_current_locale() == 'ru'
        assert my_provider.get_current_locale() == 'en'
    test_func()


# Generated at 2022-06-25 20:19:13.521404
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Check if you can override only locale-dependent providers without
    # locale changing.

    test_provider_0 = BaseDataProvider(locale='en')

    with test_provider_0.override_locale('en'), \
            test_provider_0.override_locale('en') as provider:
        assert provider is test_provider_0, 'NOT_EQUAL'
        assert provider.get_current_locale() == 'en', 'ENGLISH_NOT_EQUAL'
        assert provider.get_current_locale() == test_provider_0.locale, \
            'NOT_EQUAL'

    assert test_provider_0.locale == 'en', 'ENGLISH_NOT_EQUAL'


# Generated at 2022-06-25 20:19:16.999514
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale=locales.EN) as bdp:
        assert bdp is base_data_provider_0

# Generated at 2022-06-25 20:19:29.887979
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_2 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        assert base_data_provider_1.get_current_locale() == 'en'
    base_data_provider_3 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        assert base_data_provider_2.get_current_locale() == 'ru'
    base_data_provider_4 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru'):
        assert base_data_provider_3.get_current_

# Generated at 2022-06-25 20:19:30.932866
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-25 20:19:34.039930
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

if __name__ == '__main__':
    test_case_0()
    test_override_locale()

# Generated at 2022-06-25 20:19:48.775127
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru-RU'):
        assert base_data_provider_0.locale == 'ru-ru'
    assert base_data_provider_0.locale == 'en'  # app is back to default locale


# Generated at 2022-06-25 20:19:53.700732
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_2 = BaseDataProvider()
    base_data_provider_3 = BaseDataProvider()
    base_data_provider_1.get_current_locale()
    base_data_provider_2.get_current_locale()
    base_data_provider_1._override_locale()
    base_data_provider_2._override_locale()
    base_data_provider_1.get_current_locale()
    base_data_provider_2.get_current_locale()
    with base_data_provider_1.override_locale():
        base_data_provider_1.get_current_loc

# Generated at 2022-06-25 20:19:57.404686
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider('ru')
    with base_data_provider_0.override_locale('ru', ):
        pass



# Generated at 2022-06-25 20:20:09.597410
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    #test for not locale dependent provider
    # for this provide class must have not attribute _data
    class NotLocaleDependentProvider(BaseDataProvider):
        def get_data(self):
            return [1,2,3]

    provider = NotLocaleDependentProvider()

    with provider.override_locale() as p:
        assert p.get_data() == [1,2,3]

    #test for locale dependent provider
    class LocaleDependentProvider(BaseDataProvider):
        def get_data(self):
            return [1,2,3]

    provider = LocaleDependentProvider()

    with provider.override_locale():
        assert provider.get_data() == [1,2,3]

# Generated at 2022-06-25 20:20:17.725364
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDataProviderMock0(BaseDataProvider):
        def __init__(self):
            pass

    base_data_provider_mock0 = BaseDataProviderMock0()

    try:
        with base_data_provider_mock0.override_locale():
            pass
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 20:20:23.625257
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check override_locale method of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider(locale='ru', seed=None)
    with base_data_provider_0.override_locale(locale='ru'):
        assert base_data_provider_0.get_current_locale() == 'ru'
    assert base_data_provider_0.get_current_locale() == 'en'
    with base_data_provider_0.override_locale(locale='en'):
        assert base_data_provider_0.get_current_locale() == 'en'
    assert base_data_provider_0.get_current_locale() == 'en'

# Generated at 2022-06-25 20:20:28.077330
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bpd = BaseDataProvider()
    assert bpd.override_locale('en') == str(bpd)

# Generated at 2022-06-25 20:20:30.273217
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._override_locale('uk_UA')


# Generated at 2022-06-25 20:20:34.046567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseDataProvider()
    with base_provider_0.override_locale():
        pass



# Generated at 2022-06-25 20:20:38.765906
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Without parameters.
    base_data_provider_0 = BaseDataProvider()
    # With parameters.
    base_data_provider_1 = BaseDataProvider()



# Generated at 2022-06-25 20:21:04.202026
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en')

    with base_data_provider_0.override_locale('um'):
        assert base_data_provider_0.get_current_locale() == 'um'
    assert base_data_provider_0.get_current_locale() == 'en'



# Generated at 2022-06-25 20:21:07.210512
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Execute
    with BaseDataProvider().override_locale('sq'):
        assert BaseDataProvider().get_current_locale() == 'sq'

# Generated at 2022-06-25 20:21:17.723404
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.finance import Currency

    data_provider_0 = BaseDataProvider()
    assert isinstance(data_provider_0, BaseDataProvider)
    assert getattr(data_provider_0, 'locale', None) is None
    unicode_0 = str(data_provider_0)
    assert unicode_0 == 'BaseDataProvider'
    bool_0 = data_provider_0._setup_locale('en')
    assert isinstance(bool_0, bool)
    assert data_provider_0.locale == 'en'
    data_provider_0 = BaseDataProvider(locale='en')

# Generated at 2022-06-25 20:21:23.457505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale('en', ) as value_0:
        pass
    assert isinstance(value_0, BaseDataProvider)
    assert value_0.seed is None


# Generated at 2022-06-25 20:21:33.689018
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.locales import EN, RU
    datetime_0 = Datetime()
    assert datetime_0.get_current_locale() == EN
    with datetime_0.override_locale(locale=RU):
        assert datetime_0.get_current_locale() == RU
    assert datetime_0.get_current_locale() == EN


# Generated at 2022-06-25 20:21:38.221593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'
        # raise ValueError('«{}» has not locale dependent'.format(self.__class__.__name__))
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

if __name__ == "__main__":
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:43.592607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert base_data_provider_1 is not None


# Generated at 2022-06-25 20:21:49.542137
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print('Running Test test_BaseDataProvider_override_locale() ...')
    base_data_provider_0 = BaseDataProvider()
    test_contextmanager_0 = base_data_provider_0.override_locale(locale='ee')
    assert str(test_contextmanager_0) == 'BaseDataProvider <ee>'
    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale(locale='ee') as base_data_provider_2:
        assert str(base_data_provider_2) == 'BaseDataProvider <ee>'
    assert str(base_data_provider_1) == 'BaseDataProvider <en>'


# Generated at 2022-06-25 20:21:52.171485
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE) -> None:
            super().__init__(locale)

    with Provider(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-25 20:21:55.632066
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('ru_RU'):
        pass


# Generated at 2022-06-25 20:22:48.853412
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.network import Network
    from mimesis.providers.text import Text
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.commerce import Commerce
    from mimesis.providers.cryptography import Cryptography
    from mimesis.providers.file import File
    from mimesis.providers.financial import Financial
    from mimesis.providers.geo import Geo

# Generated at 2022-06-25 20:22:55.017936
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    base_data_provider_0 = BaseDataProvider(locale)
    with base_data_provider_0.override_locale(locale) as data_provider:
        assert str(data_provider) == "'BaseDataProvider <en>'"

# Generated at 2022-06-25 20:22:58.921387
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    def test_value_0():
        with base_data_provider_0.override_locale('pl'):
            assert base_data_provider_0.locale == 'pl'



# Generated at 2022-06-25 20:23:08.913935
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale("ru"):
        assert base_data_provider_0.get_current_locale() == "ru"
        # Check that current locale is restored
        assert base_data_provider_0.get_current_locale() == getattr(locales, "DEFAULT_LOCALE", "en")

# Generated at 2022-06-25 20:23:20.435194
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        base_data_provider_0._pull()
    base_data_provider_1 = BaseDataProvider('ru-ru')
    with base_data_provider_1.override_locale():
        base_data_provider_1._pull()
    base_data_provider_2 = BaseDataProvider('ru-ru')
    with base_data_provider_0.override_locale('ru-ru'):
        base_data_provider_2._pull()
    base_data_provider_3 = BaseDataProvider()
    with base_data_provider_3.override_locale('en'):
        base_data_provider_3._pull()

# Generated at 2022-06-25 20:23:27.215593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    person = Person('en')
    person.full_name()
    with person.override_locale('ru'):
        person.full_name()
        # Should return last name
        assert person.full_name().split(' ').pop(-1)

# Generated at 2022-06-25 20:23:33.924435
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """
    This is the unit test of BaseDataProvider.override_locale
    """
    # Create Base DataProvider object
    base_data_provider = BaseDataProvider(locale="en")
    # Override locale
    with base_data_provider.override_locale('en') as provider:
        print(provider)

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:23:38.722198
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'
    class Foo(BaseDataProvider):
        pass
    foo_0 = Foo(locale=locale)
    with foo_0.override_locale('en') as foo_1:
        assert foo_1.locale == 'en'
    assert foo_0.locale == locale

# Generated at 2022-06-25 20:23:44.430557
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bd = BaseDataProvider()
    with bd.override_locale('en') as bdp:
        assert isinstance(bdp, BaseDataProvider)
        assert bdp.get_current_locale() == 'en'

# Generated at 2022-06-25 20:23:47.251698
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale() as x:
        assert x == BaseDataProvider()


# Generated at 2022-06-25 20:25:30.604644
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('en-US'):
        assert bdp.locale == 'en-US'

# Generated at 2022-06-25 20:25:31.890738
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp_0 = BaseDataProvider()
    with bdp_0.override_locale(locale='en'):
        assert bdp_0.locale == 'en'


# Generated at 2022-06-25 20:25:39.253878
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Personal
    from mimesis.enums import Gender

    personal = Personal()

    for gender in Gender:
        assert personal.get_gender(gender) == personal.get_gender(gender)

    with personal.override_locale('ru') as personal_ru:
        assert personal.get_gender(Gender.MALE) != \
               personal_ru.get_gender(Gender.MALE)

        assert personal_ru.get_gender(Gender.MALE) == \
               personal_ru.get_gender(Gender.MALE)

# Generated at 2022-06-25 20:25:45.317447
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp_locale_0 = BaseDataProvider(locale='ru')
    with bdp_locale_0.override_locale(locale='de'):
        assert bdp_locale_0.get_current_locale() == 'de'
    assert bdp_locale_0.get_current_locale() == 'ru'


# Generated at 2022-06-25 20:25:50.037151
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN):
        assert getattr(provider, 'locale', locales.DEFAULT_LOCALE) == locales.EN
    assert getattr(provider, 'locale', locales.DEFAULT_LOCALE) == locales.DEFAULT_LOCALE


# Generated at 2022-06-25 20:25:51.243773
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:26:05.957085
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.enums import Gender

    try:
        __test_with_none_locale = BaseDataProvider.override_locale()
        __test_with_none_locale2 = Address.override_locale(None)
        __test_with_unsupported_locale = Address.override_locale('zz')
        __test_with_object_locale = Address.override_locale(Gender.MALE)
        assert False
    except (ValueError, UnsupportedLocale):
        assert True

# Generated at 2022-06-25 20:26:09.464148
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Exception raised when locale is invalid.
    with pytest.raises(UnsupportedLocale):
        base_data_provider_0 = BaseDataProvider()
        locale = 'ru'
        with base_data_provider_0.override_locale(locale) as result:
            pass

# Generated at 2022-06-25 20:26:14.516084
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale(locale='uk') as data_provider_1:
        assert data_provider_1.get_current_locale() == 'uk'
    assert data_provider_0.get_current_locale() == 'en'

# Generated at 2022-06-25 20:26:16.637755
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass
