

# Generated at 2022-06-25 20:18:41.884378
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._override_locale()

# Testing for method get_current_locale of class BaseDataProvider

# Generated at 2022-06-25 20:18:42.711058
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    raise NotImplementedError


# Generated at 2022-06-25 20:18:43.227949
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert True

# Generated at 2022-06-25 20:18:45.983455
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    food_0 = BaseDataProvider()
    with food_0.override_locale(locale = 'ru'):
        assert food_0.get_current_locale() == 'ru'
    assert food_0.get_current_locale() == ''


# Generated at 2022-06-25 20:18:47.829299
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locales.DEFAULT_LOCALE):
        pass


# Generated at 2022-06-25 20:18:51.748201
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en')
    base_data_provider_0.override_locale(locale='en')


if __name__ == '__main__':
    test_case_0()

    test_BaseDataProvider_override_locale()

    print("Test completed")

# Generated at 2022-06-25 20:18:53.290915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('es'):
        pass

# Generated at 2022-06-25 20:18:55.636653
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en', seed=None)
    with pytest.raises(ValueError):
        base_data_provider_0.override_locale()



# Generated at 2022-06-25 20:19:04.681097
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    ru_locale = locales.RU

    class FooProvider(BaseDataProvider):
        pass

    foo_provider_0 = FooProvider()
    with foo_provider_0.override_locale(ru_locale) as overridden_locale_0:
        assert foo_provider_0.get_current_locale() == ru_locale
        assert overridden_locale_0.get_current_locale() == ru_locale

    assert foo_provider_0.get_current_locale() != ru_locale



# Generated at 2022-06-25 20:19:06.385830
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider() as provider:
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-25 20:19:21.802658
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()

    # Case: locale is not supported
    # Expected: ValueError
    try:
        with bdp.override_locale('aaaa'):
            pass
    except ValueError as e:
        assert 'is not supported' in str(e)

    # Case: locale is supported
    # Expected: BaseDataProvider
    with bdp.override_locale('en'):
        assert isinstance(bdp, BaseDataProvider)

# Generated at 2022-06-25 20:19:31.628681
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.get_current_locale() == 'en'

    new_base_data_provider = base_data_provider.override_locale(locale='en')
    assert new_base_data_provider.get_current_locale() == 'en'

    new_base_data_provider = base_data_provider.override_locale(locale='ru')
    assert new_base_data_provider.get_current_locale() == 'ru'

    new_base_data_provider = base_data_provider.override_locale(locale='uk')
    assert new_base_data_provider.get_current_locale() == 'uk'

# Generated at 2022-06-25 20:19:36.354902
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider('en')
    base_data_provider._override_locale(locale='en')
    assert base_data_provider.get_current_locale() == 'en'


# Generated at 2022-06-25 20:19:49.291690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.typing import JSON
    from mimesis.enums import Gender

    # Create an instance of Internet
    internet = Internet()

    # Check that «locale» attribute is not exists
    assert not hasattr(internet, 'locale')

    # Create an instance of Person
    person = Person()

    person_instance = None
    person_locale = None

    try:
        with person.override_locale('ru') as person_instance:
            assert person is person_instance
            person_locale = person.locale
            assert person_locale == 'ru'
    except ValueError:
        pass

    assert person_locale != 'ru'
    assert person_instance is None


# Generated at 2022-06-25 20:20:00.482988
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.numbers import Numbers
    with BaseDataProvider.override_locale('en') as provider:
        assert provider.locale == 'en'
        assert provider.get_current_locale() == 'en'
    with BaseDataProvider.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_current_locale() == 'ru'
    with BaseDataProvider.override_locale('en') as provider:
        assert provider.locale == 'en'
        assert provider.get_current_locale() == 'en'
    obj = Numbers()
    with obj.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-25 20:20:04.583236
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        
        def _validate_enum(self, item: Any, enum: Any) -> Any:
            return item
        
        def test_case_0(self):
            pass
        
        def test_case_1(self):
            pass
        
        def test_case_2(self):
            pass
        
    base_data_provider_0 = TestBaseDataProvider(
        'en',
        seed=None,
    )
    def override_locale_0():
        with base_data_provider_0.override_locale('en') as b:
            b.test_case_0()

# Generated at 2022-06-25 20:20:07.983059
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale='en'):
        pass

# Generated at 2022-06-25 20:20:18.250074
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person

    p = Person('ru')
    with p.override_locale('en'):
        assert p.full_name == 'Joshua Richardson'
        assert p.occupation() == 'Operations Manager'
    assert p.full_name == 'Александр Мамонтов'
    assert p.occupation() == 'Программист'


# Generated at 2022-06-25 20:20:24.897062
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data.personal.names import names
    from mimesis.enums import Gender

    ru = names('ru')
    ru_m = ru.get_full_name(gender=Gender.MALE)

    en = ru.override_locale('en')
    en_m = en.get_full_name(gender=Gender.MALE)

    return ru_m != en_m

if __name__ == "__main__":
    # execute only if run as a script
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:30.374186
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    base_data_provider_0 = BaseDataProvider()
    locale_0 = locales.EN
    base_data_provider_0._override_locale(locale_0)
    with base_data_provider_0.override_locale() as base_data_provider_0:
        pass

# Generated at 2022-06-25 20:20:55.065076
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_BaseDataProvider_override_locale_instance = BaseDataProvider()
    with test_BaseDataProvider_override_locale_instance.override_locale(locale='ru') as test_BaseDataProvider_override_locale_var_0:
        test_BaseDataProvider_override_locale_var_0 = test_BaseDataProvider_override_locale_var_0


# Generated at 2022-06-25 20:21:02.656880
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider('en')
    # Test for exception
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale(locale='en'):
            pass



# Generated at 2022-06-25 20:21:07.295401
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    with provider.override_locale('ru') as p:
        res = p.get_current_locale()
    assert res == 'ru'

# Generated at 2022-06-25 20:21:14.282878
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    name_base = BaseProvider.__name__
    try:
        base = BaseProvider()
        locale = base.override_locale()
        assert isinstance(locale, BaseProvider)
        result = (locale.__class__.__name__)
        if result != name_base:
            raise AssertionError
    except AssertionError:
        return False
    return True


# Generated at 2022-06-25 20:21:16.849272
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()


# Generated at 2022-06-25 20:21:20.717338
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    try:
        with bdp.override_locale():
            pass
    except ValueError:
        pass
    

# Generated at 2022-06-25 20:21:26.460109
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseProvider()
    with base_data_provider_0.override_locale() as b:
        assert isinstance(b, BaseDataProvider)


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:33.047232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='ru'):
        assert base_data_provider_0.locale == 'ru'
    assert base_data_provider_0.locale == 'en'


# Generated at 2022-06-25 20:21:36.286847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis_ru import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.full_name() == 'Станислав Саша Федоров'
    assert p.full_name() == 'Станислав Саша Федоров'


# Generated at 2022-06-25 20:21:39.222574
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    b = BaseDataProvider()
    b.override_locale()


# Generated at 2022-06-25 20:22:26.662533
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.override_locale(locales.EN)

# Generated at 2022-06-25 20:22:31.379887
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_1 = BaseDataProvider()
    base_data_provider_2 = BaseDataProvider()
    base_data_provider_3 = BaseDataProvider()

# Generated at 2022-06-25 20:22:37.570737
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''BaseDataProvider override_locale test.

    This case covered the following types of test cases:

    1. If the provider has a locale dependent.
    2. If the provider hasn`t a locale dependent.

    '''
    with BaseDataProvider().override_locale(locales.EN):
        pass
    try:
        with BaseProvider().override_locale(locales.EN):
            pass
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-25 20:22:38.998829
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    new_locale = "en"
    bdp._override_locale(new_locale)
    assert bdp.locale == new_locale

# Generated at 2022-06-25 20:22:43.045951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:22:47.723059
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider.

    """
    test_case = BaseDataProvider()
    test_case._override_locale()

# Generated at 2022-06-25 20:22:51.086992
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()

    with base_provider_0.override_locale() as provider:
        pass


# Generated at 2022-06-25 20:22:57.742905
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass
    # TODO fix test
    # print('Starting test')
    # base_data_provider_0 = BaseDataProvider('en')
    # try:
    #     with base_data_provider_0.override_locale('de',
    #                                               ):
    #         pass
    # except ValueError:
    #     pass

# Generated at 2022-06-25 20:23:00.596951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()

    base_provider.__str__()

    base_provider.get_current_locale()
    # CRITICAL: base_provider.override_locale()
    base_provider.override_locale(locale=locales.EN)

# Generated at 2022-06-25 20:23:11.007242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='ru') as b:
        assert b == base_data_provider_0
        assert b.locale == 'ru'
        assert b.get_current_locale() == 'ru'

    base_data_provider_1 = BaseDataProvider()
    with base_data_provider_1.override_locale() as b:
        assert b == base_data_provider_1
        assert b.locale == 'en'
        assert b.get_current_locale() == 'en'

    base_data_provider_2 = BaseDataProvider()

# Generated at 2022-06-25 20:25:06.601406
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale_0 = ''
    locale_1 = ''
    locale_2 = ''
    locale_3 = ''
    locale_4 = ''


# Generated at 2022-06-25 20:25:15.938014
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()
    context = base_provider.override_locale()
    try:
        value = next(context)
    except StopIteration:
        value = None

    assert value is None, "Failure: Method override_locale of BaseDataProvider should return None"

if __name__ == '__main__':
    # Unit test for method __init__ of class BaseDataProvider
    test_case_0()

    # Unit test for method override_locale of class BaseDataProvider
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:24.823886
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Fixture
    locale = locales.RU
    base_data_provider_0 = BaseDataProvider()

    # Case
    with base_data_provider_0.override_locale(locale) as base_data_provider:
        assert base_data_provider == base_data_provider_0
        assert base_data_provider.get_current_locale() == locale

# Generated at 2022-06-25 20:25:27.885692
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale() as p:
        locale = p.get_current_locale()
        assert locale == locales.EN
        s = str(p)
    s


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:32.678518
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()

    try:
        with data_provider.override_locale(locale='en'):
            pass
    except ValueError:
        assert False


# Generated at 2022-06-25 20:25:38.184492
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.locales import _DE

    provider_0 = BaseDataProvider

    with provider_0.override_locale(_DE) as provider_1:
        pass
    with provider_0.override_locale(_DE) as provider_2:
        pass

    assert not hasattr(provider_0, 'locale')
    assert not hasattr(provider_0, 'locale')

# Generated at 2022-06-25 20:25:42.346319
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider(locale='ru')
    with data_provider.override_locale('en') as tmp_provider:
        assert data_provider.get_current_locale() == 'en'
        assert tmp_provider.get_current_locale() == 'en'
    assert data_provider.get_current_locale() == 'ru'

if __name__ == "__main__":
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:49.558475
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()
    print(base_provider.get_current_locale())
    base_provider.override_locale('ro')
    print(base_provider.get_current_locale())
    base_provider.override_locale('ro')

    try:
        base_provider.override_locale('qwerty')
    except UnsupportedLocale:
        print('qwerty not in SUPPORTED_LOCALES')
    else:
        print('qwerty in SUPPORTED_LOCALES')


# Generated at 2022-06-25 20:25:51.853628
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locale='en') as data:
        result = data.get_current_locale()
        assert result == 'en'


# Generated at 2022-06-25 20:25:56.110984
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    base_data_provider_0 = BaseDataProvider()
    with pytest.raises(ValueError):
        with base_data_provider_0.override_locale() as base_data_provider_1:
            pass
