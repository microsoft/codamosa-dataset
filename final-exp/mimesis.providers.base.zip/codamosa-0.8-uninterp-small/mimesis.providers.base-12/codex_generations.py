

# Generated at 2022-06-25 20:18:47.922134
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale = 'en')
    with base_data_provider_0.override_locale():
        pass
    base_data_provider_0 = BaseDataProvider(locale = 'en')
    with base_data_provider_0.override_locale() as bdp:
        assert isinstance(bdp, BaseDataProvider)
        # Type case of parameter bdp to Dict
        assert isinstance(dict(bdp), Dict)
    base_data_provider_0 = BaseDataProvider(locale = 'en')
    with base_data_provider_0.override_locale() as bdp:
        assert isinstance(bdp, BaseDataProvider)
        # Type case of parameter bdp to Dict

# Generated at 2022-06-25 20:18:58.772598
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDataProviderTest(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            locale = self.locale
            self._data = locale
    with BaseDataProviderTest(locale='jp-jp') as bdpt:
        with bdpt.override_locale('en-US') as bdpt_overriden:
            assert bdpt_overriden.get_current_locale() == 'en-US'
            with bdpt_overriden.override_locale('ru-RU') as bdpt_overriden2:
                assert bdpt_overriden2.get_current_locale() == 'ru-RU'
            assert bdpt_overriden.get_current_locale() == 'en-US'

# Generated at 2022-06-25 20:19:01.942689
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale() as provider:
        assert isinstance(provider, BaseDataProvider)


# Generated at 2022-06-25 20:19:07.872394
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider

    provider = RussiaSpecProvider()
    # assert provider.locale == locales.DEFAULT_LOCALE
    print('DEFAULT_LOCALE', locales.DEFAULT_LOCALE)

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    assert RussiaSpecProvider().get_current_locale() == locales.RU

# Generated at 2022-06-25 20:19:10.328394
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()

    with base_data_provider.override_locale(locale="ru"):
        locale = base_data_provider.get_current_locale()
        assert locale == "ru"

# Generated at 2022-06-25 20:19:17.999701
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Setup
    base_data_provider_0 = BaseDataProvider()
    
    # Assertion 1:
    with base_data_provider_0.override_locale() as base_data_provider_0_override:
        assert base_data_provider_0 == base_data_provider_0_override
    
    # Assertion 2:
    with base_data_provider_0.override_locale('en') as base_data_provider_0_override:
        assert base_data_provider_0 == base_data_provider_0_override


# Generated at 2022-06-25 20:19:28.082531
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_1:
        assert base_data_provider_1.get_current_locale() == 'en'
    base_data_provider_2 = BaseDataProvider()
    with base_data_provider_2.override_locale(locales.EN) as base_data_provider_3:
        assert base_data_provider_3.get_current_locale() == 'en'

# Generated at 2022-06-25 20:19:34.757297
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.en import Text
    from mimesis.builtins.es import Text as SpanishText
    from mimesis.builtins.fr import Text as FrenchText
    text_0 = Text(seed=0)
    text_1 = Text(locale=locales.DEFAULT_LOCALE)
    assert text_0.__str__() == text_1.__str__()
    with text_0.override_locale(locale=locales.ES):
        assert text_0.get_current_locale() == locales.ES
        assert isinstance(text_0, SpanishText)
        assert text_0.__str__() == 'Text <es>'
    with text_0.override_locale(locale=locales.FR):
        assert text_0.get_current_

# Generated at 2022-06-25 20:19:36.930140
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('de-at', 'en-us'):
        pass



# Generated at 2022-06-25 20:19:48.259410
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seeds=seed)
    my_provider = MyDataProvider()
    try:
        with my_provider.override_locale(locales.DEFAULT_LOCALE):
            pass
        print('Success')
    except ValueError:
        print('Fail')


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:01.138538
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    cls = BaseDataProvider
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        pass

# Generated at 2022-06-25 20:20:08.065374
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='ru')
    with base_data_provider_0.override_locale('ru') as base_data_provider_1:
        pass


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:20:12.729780
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    with BaseDataProvider().override_locale('ru'):
        print(BaseDataProvider().locale)

# Generated at 2022-06-25 20:20:18.085102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()
    with base_provider.override_locale() as bp:
        assert bp.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-25 20:20:21.703971
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='ru', seed=None)

    with base_data_provider_0.override_locale('nl'):
        assert base_data_provider_0.locale == 'nl'


# Generated at 2022-06-25 20:20:26.616640
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def override_locale(locale):
        with base_data_provider_0.override_locale(locale):
            assert base_data_provider_0.get_current_locale() == locale

    base_data_provider_0 = BaseDataProvider()
    override_locale("en")
    with base_data_provider_0.override_locale("ru"):
        override_locale("en")
    assert base_data_provider_0.get_current_locale() == "en"


# Generated at 2022-06-25 20:20:28.666995
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_instance = BaseDataProvider()
    BaseDataProvider_instance.override_locale("en")


# Generated at 2022-06-25 20:20:35.242303
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)

        _datafile = 'test.json'

    test_base_data_provider = TestProvider()
    # Test of context manager
    with test_base_data_provider.override_locale(locale=locales.EN):
        # Test for method get_current_locale
        assert test_base_data_provider.get_current_locale() == locales.EN
    # Test for exception UnsupportedLocale
    with pytest.raises(UnsupportedLocale):
        with test_base_data_provider.override_locale(locale='ru'):
            pass

# Generated at 2022-06-25 20:20:41.436874
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import unittest
    test = unittest.TestCase()

    class MyBaseDataProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__('en')

    my_base_data_provider_0 = MyBaseDataProvider()
    with my_base_data_provider_0.override_locale('ru'):
        locale = my_base_data_provider_0.get_current_locale()
        test.assertEqual(locale, 'ru')
    test.assertEqual(my_base_data_provider_0.get_current_locale(), 'en')

    my_base_data_provider_2 = MyBaseDataProvider()

# Generated at 2022-06-25 20:20:46.650428
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale() as base_data_provider_0:
        print(base_data_provider_0)


# Generated at 2022-06-25 20:21:01.107116
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_1 = BaseProvider()
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._override_locale('en')


# Generated at 2022-06-25 20:21:03.826755
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    locale = 'en'
    with base_data_provider.override_locale(locale):
        pass


# Generated at 2022-06-25 20:21:16.173926
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_provider_1 = BaseProvider()
    base_provider_2 = BaseProvider()
    base_provider_0.__class__ = BaseDataProvider
    base_provider_1.__class__ = BaseDataProvider
    base_provider_2.__class__ = BaseDataProvider
    base_provider_0.locale = 'ru'
    base_provider_1.locale = 'cs'
    base_provider_2.locale = 'es'
    base_provider_0.locale = base_provider_1.locale
    base_provider_2.locale = base_provider_1.locale
    base_provider_0.locale = 'ru'

# Generated at 2022-06-25 20:21:21.389466
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider().override_locale():
            pass
    except ValueError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:25.091498
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_0 = BaseDataProvider()
    with provider_0.override_locale('en'):
        pass


# Generated at 2022-06-25 20:21:30.945911
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale():
        print(base_data_provider)
        print(base_data_provider.locale)


# Generated at 2022-06-25 20:21:33.978222
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    baseDataProvider = BaseDataProvider()
    contextManager = baseDataProvider.override_locale()
    try:
        contextManager.__enter__()
    except ValueError:
        assert True
    else:
        assert False

test_case_0()
test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:21:35.812825
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    t1 = base_data_provider_0.override_locale('en')

# Generated at 2022-06-25 20:21:42.466862
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_0 = BaseDataProvider()
    with data_provider_0.override_locale() as provider:
        str_0: str = str(provider)
        assert str_0 == 'BaseDataProvider <en>'




# Generated at 2022-06-25 20:21:44.414031
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as p:
        pass

# Generated at 2022-06-25 20:21:59.549527
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0.reseed(seed=888)
    base_data_provider_0.locale = 'ja'
    expected = base_data_provider_0.locale

    # Act
    with base_data_provider_0.override_locale(locale='en'):
        locale = base_data_provider_0.locale
        assert locale != expected
        assert base_data_provider_0.locale == 'en'

    # Assert
    current_locale = base_data_provider_0.get_current_locale()
    assert expected == current_locale
    assert expected == base_data_provider_0.locale



# Generated at 2022-06-25 20:22:04.610040
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale('en-ee'):
        base_data_provider.locale == 'en-ee'


# Generated at 2022-06-25 20:22:07.520517
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru-RU'
    provider = BaseDataProvider()
    with provider.override_locale(locale):
        assert provider.get_current_locale() == locale


# Generated at 2022-06-25 20:22:10.382315
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    imported_locale = locales.EN
    # Unit test code
    base_data_provider_0 = BaseDataProvider(locale=imported_locale)
    with base_data_provider_0.override_locale(locale=imported_locale) as base_data_provider_0:
        assert base_data_provider_0.override_locale(locale=imported_locale)

# Generated at 2022-06-25 20:22:13.764063
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale(locale='en'):
        assert str(base_data_provider_0) == 'BaseDataProvider <en>'


# Generated at 2022-06-25 20:22:19.935096
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person, Address
    with Person('ru', seed=1).override_locale('en'):
        person = Person(seed=1)
        assert person.full_name() == 'Oscar Jeff'
        assert person.full_name(formatted=True) == 'Mr Oscar Jeff'
    with Address('ru', seed=1).override_locale('en'):
        person = Address(seed=1)
        assert person.region() == 'Nevada'
        assert person.city() == 'Beaver Dam'
        assert person.country() == 'United States of America'
        assert person.state() == 'Nevada'
        assert person.street() == 'Christine Vista'
        assert person.postcode() == '77001'

# Generated at 2022-06-25 20:22:21.635552
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    assert base_data_provider_0.override_locale()

# Generated at 2022-06-25 20:22:26.225570
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    locale = locales.EN
    with base_data_provider.override_locale(locale):
        assert base_data_provider.locale == locale

# Generated at 2022-06-25 20:22:35.173352
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    person = Person('en')
    example_names = [
        person.full_name(gender=Gender.FEMALE),
        person.full_name(gender=Gender.MALE),
    ]

    with Person().override_locale('ru') as p:
        assert example_names != [
            p.full_name(gender=Gender.FEMALE),
            p.full_name(gender=Gender.MALE),
        ]

# Generated at 2022-06-25 20:22:43.551214
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    try:
        with base_data_provider.override_locale(locale=locales.EN):
            assert str(base_data_provider) == 'BaseDataProvider <en>'
    except ValueError:
        pass

# Test for method _setup_locale of class BaseDataProvider

# Generated at 2022-06-25 20:23:18.376509
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create an instance of BaseDataProvider class
    base_data_provider_1 = BaseDataProvider()
    # Make an assertion that we are inside context manager
    with base_data_provider_1.override_locale() as base_data_provider_2:
        try:
            assert base_data_provider_1 == base_data_provider_2
        except AssertionError:
            print("Test case 0 failed !")
        else:
            print("Test case 0 passed !")

# Generated at 2022-06-25 20:23:33.924491
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from typing import Callable
    from mimesis.typing import JSON

    class DataProvider(BaseDataProvider):
        def __init__(self, seed: int = None):
            super().__init__()

        def get_data(self, item: JSON = None, enum: Any = None,
                    **kwargs) -> JSON:  # noqa
            if item:
                return item
            return self._data  # type: ignore

        def __str__(self):
            return 'DataProvider'

    data_provider_0 = DataProvider()
    with data_provider_0.override_locale('sdf'):
        pass
    with data_provider_0.override_locale(locale='sdf'):
        pass
    def f1(a: DataProvider) -> DataProvider:
        return

# Generated at 2022-06-25 20:23:35.439165
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        BaseDataProvider().override_locale(locales.EN)
        assert False
    except AttributeError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 20:23:40.174120
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Define a class derived from BaseDataProvider
    class BaseDataProvider_example(BaseDataProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(locale=locales.EN, seed=seed)
        def _override_locale(self, locale: str = locales.EN):
            self.locale = locale
        def get_data(self):
            return self

    base_data_provider_0 = BaseDataProvider_example()
    try:
        with base_data_provider_0.override_locale(locale=locales.RU):
            print(base_data_provider_0.get_current_locale())
    except ValueError:
        print('Test fail')
        raise


# Generated at 2022-06-25 20:23:44.571169
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()
    with data_provider.override_locale() as provider:
        assert data_provider == provider



# Generated at 2022-06-25 20:23:48.933622
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider(locale=locales.EN)
    with base_data_provider.override_locale():
        assert base_data_provider.get_current_locale() == locales.EN



# Generated at 2022-06-25 20:24:07.124547
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider_0 = BaseProvider()
    base_data_provider_0 = BaseDataProvider(locale='en', seed=43)
    with base_data_provider_0.override_locale(locale='ru'):
        base_data_provider_0
    with pytest.raises(ValueError):
        with base_provider_0.override_locale(locale='ru'):
            base_provider_0


# Generated at 2022-06-25 20:24:08.777013
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('en') as provider:
        assert provider.locale == 'en'

# Generated at 2022-06-25 20:24:15.818454
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        assert base_data_provider_0.get_current_locale() == 'ru', 'Locale is not overridden'
    assert base_data_provider_0.get_current_locale() == 'en', 'Locale should be overridden'


# Generated at 2022-06-25 20:24:17.230745
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_case_0()

test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:07.200952
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    with base_data_provider_0.override_locale():
        assert True

# Generated at 2022-06-25 20:25:14.656970
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create instance of class BaseDataProvider
    base_provider_1 = BaseDataProvider()

    # Check method override_locale
    assert issubclass(base_provider_1.override_locale('en'),
                      BaseDataProvider)

    base_provider_1.override_locale('en')



# Generated at 2022-06-25 20:25:17.481914
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person

    with Person().override_locale('ru') as person_ru:
        assert person_ru.get_current_locale() == locales.RU

# Generated at 2022-06-25 20:25:23.534850
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider()
    base_data_provider_0._setup_locale('ru')
    locale = 'ru'
    value_0 = base_data_provider_0.override_locale(locale)



# Generated at 2022-06-25 20:25:28.240253
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_base_data_provider = BaseDataProvider()

    # Test for branch 'if locale:',
    with test_base_data_provider.override_locale(locale='uk'):
        assert 'uk' in test_base_data_provider.locale

    # Test for branch 'else',
    with test_base_data_provider.override_locale():
        assert 'uk' in test_base_data_provider.locale



# Generated at 2022-06-25 20:25:39.675566
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  #Sets the seed for random number generation.
  base_data_provider = BaseDataProvider(locale="en", seed=None)
  expected = 'en'
  actual = base_data_provider.get_current_locale()
  assert expected == actual
  expected = base_data_provider
  actual = base_data_provider.override_locale()
  assert expected == actual
  locale = 'zh'
  base_data_provider.override_locale(locale)
  expected = 'zh'
  actual = base_data_provider.get_current_locale()
  assert expected == actual

if __name__ == "__main__":
  #Test case 0 : Method test of BaseProvider constructer
  test_case_0()
  # Test case 0 : Unit test for method override

# Generated at 2022-06-25 20:25:42.962987
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Address
    from mimesis.enums import Gender
    address = Address('ru')
    for sex in Gender.__members__.values():
        with address.override_locale('en'):
            assert address.full_name(sex.value) != address.full_name(sex.value)
        with address.override_locale('ru'):
            assert address.full_name(sex.value) == address.full_name(sex.value)

# Generated at 2022-06-25 20:25:46.263815
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru-RU'):
        pass

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:25:48.588441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    baseDataProvider_0 = BaseDataProvider(locale='', seed=None)
    with baseDataProvider_0.override_locale():
        pass


# Generated at 2022-06-25 20:26:05.957689
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.ru import Person as PersonRu
    from mimesis.providers.phone_number.en import PhoneNumber
    from mimesis.providers.phone_number.ru import PhoneNumber as PhoneNumberRu

    person = Person()
    phone_number = PhoneNumber()

    with person.override_locale(locales.RU) as person_ru:
        assert isinstance(person_ru, PersonRu)
        assert person_ru.full_name() == 'Наталья Ольховская'

    with phone_number.override_locale(locales.RU):
        assert isinstance(phone_number, PhoneNumberRu)

# Generated at 2022-06-25 20:27:40.954743
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Input parameter tests
    # Test with valid parameter
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale() as base_data_provider_0_0:
        pass

    # Test with valid parameter
    base_data_provider_0 = BaseDataProvider()

    with base_data_provider_0.override_locale("ar_SA") as base_data_provider_0_0:
        pass
    # Output parameter tests
    with base_data_provider_0.override_locale("ar_SA") as base_data_provider_0_0:
        assert base_data_provider_0_0 is base_data_provider_0


# Generated at 2022-06-25 20:27:43.441432
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider._pull = lambda x: None
    base_data_provider = BaseDataProvider(locale=locales.EN, seed=SEED)
    print(base_data_provider)
    base_data_provider.override_locale(locales.RU)



# Generated at 2022-06-25 20:27:48.543194
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    with BaseDataProvider(locale).override_locale(locale) as base_data_provider:
        base_data_provider = BaseDataProvider(locale)
        pass


if __name__ == '__main__':
    # Unit Tests
    
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:27:51.213239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider_0 = BaseDataProvider(locale='en', seed=None)
    with base_data_provider_0.override_locale() as base_data_provider_0:
        assert base_data_provider_0.get_current_locale() == 'en'


# Generated at 2022-06-25 20:27:53.545283
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider()
    provider = p.override_locale('en')
    assert isinstance(provider, BaseDataProvider)


# Generated at 2022-06-25 20:27:55.263066
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_provider = BaseDataProvider()
    with base_provider.override_locale('en'):
        assert base_provider.get_current_locale() == 'en'

# Generated at 2022-06-25 20:27:57.499023
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale():
        print(provider.get_current_locale())

if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:28:02.954593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('de'):
        assert isinstance(provider, BaseDataProvider)
        assert provider.locale == 'de'


if __name__ == '__main__':
    test_case_0()
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-25 20:28:06.425688
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from mimesis.builtins import Code
    code = Code()
    with code.override_locale('ru') as code:
        assert(code.get_current_locale() == 'ru')
        assert(str(code) == 'Code <ru>')



# Generated at 2022-06-25 20:28:11.394955
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # __init_subclass__ is required for override the locale
    class TestDataProvider(BaseDataProvider):
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)

    # initializes a new instance
    test_data_provider = TestDataProvider()

    with test_data_provider.override_locale('en'):
        assert test_data_provider.get_current_locale() == 'en'
    assert test_data_provider.get_current_locale() == locales.DEFAULT_LOCALE