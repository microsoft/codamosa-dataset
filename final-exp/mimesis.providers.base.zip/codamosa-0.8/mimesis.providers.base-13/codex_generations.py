

# Generated at 2022-06-12 01:36:09.978875
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Concrete class for method override_locale of class BaseDataProvider."""

        def __str__(self) -> str:
            """Human-readable representation of locale."""
            return '{} <{}>'.format(self.__class__.__name__, self.locale)

    provider = Provider()
    provider.locale = locales.EN
    provider._data = locales.EN
    with provider.override_locale(locales.DE):
        assert provider.locale == locales.DE
        with provider.override_locale(locales.DE):
            assert provider.locale == locales.DE
        assert provider.locale == locales.DE
    assert provider.locale == local

# Generated at 2022-06-12 01:36:20.703961
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Datetime
    from events_protocol.protocols import GenericEvents

    datetime = Datetime()
    datetime.seed(0)
    generic_events = GenericEvents()
    generic_events.seed(0)
    assert generic_events.dt_data.get_current_locale() == 'en'
    assert datetime.get_current_locale() == 'en'
    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'
        assert generic_events.dt_data.get_current_locale() == 'ru'
        assert datetime.get_current_locale() == 'en'
    assert generic_events.dt_data.get_current_locale() == 'en'
    assert datetime

# Generated at 2022-06-12 01:36:23.421612
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    try:
        with provider.override_locale('pt-br'):
            pass
    except AttributeError:
        return True
    return False

# Generated at 2022-06-12 01:36:29.349101
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def foo(self, **kwargs):
            return kwargs

    tr = Test('tr')
    with tr.override_locale('ru') as ru:
        assert ru is tr
    assert tr.get_current_locale() == 'tr'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:36:36.576340
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data.get(key, {})

    p = TestDataProvider()
    assert p.get_data('test') == {}
    assert p.locale == 'en'

    with p.override_locale('ru') as locale_ru:
        assert locale_ru.locale == 'ru'
        assert locale_ru.get_data('test') == {'test': 'ok'}

    assert p.get_data('test') == {}
    assert p.locale == 'en'



# Generated at 2022-06-12 01:36:39.462055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider(locale='en')
    with dp.override_locale('ro'):
        assert dp.locale == 'ro'



# Generated at 2022-06-12 01:36:48.448362
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from collections import UserDict
    from mimesis.builtins import Localization
    from mimesis.providers import Address
    from mimesis.enums import Gender

    class TestProvider(UserDict, Localization):
        pass

    tp = TestProvider('ru')
    a = Address(tp)
    assert a.gender(Gender.MALE) == 'мужской'

    with tp.override_locale('en') as l:
        assert l.gender(Gender.MALE) == 'male'
        assert l.gender(Gender.FEMALE) == 'female'

# Generated at 2022-06-12 01:36:59.439776
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers import Currency, Names

    provider = Currency()
    assert provider.get_current_locale() == provider.locale
    assert isinstance(provider._data, dict)

    with provider.override_locale(locales.EN) as locale_en:
        assert locale_en.get_current_locale() == locales.EN
        assert locale_en.locale == locales.EN
        assert isinstance(locale_en._data, dict)

    assert provider.get_current_locale() == provider.locale
    assert provider.locale is not locales.EN

    with provider.override_locale(locales.RU) as locale_ru:
        assert locale_ru.get_current_loc

# Generated at 2022-06-12 01:37:05.520284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        pass
    foo = Foo()
    with foo.override_locale('ru') as object:
        assert foo.get_current_locale() == 'ru'
        assert foo is object
    assert foo.get_current_locale() == 'en'


# Generated at 2022-06-12 01:37:12.054856
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    ''' Unit test for method override_locale of class BaseDataProvider '''
    from mimesis.builtins import Person
    def func_override_locale(locale: str) -> str:
        ''' Test method override_locale in class Person '''
        with Person().override_locale(locale) as person:
            return person.full_name()

    assert func_override_locale('en') != func_override_locale('ru')

# Generated at 2022-06-12 01:37:24.561193
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method of class BaseDataProvider.
    """
    bdp = BaseDataProvider('es')
    with bdp.override_locale('en'):
        assert bdp.locale == 'en'

# Generated at 2022-06-12 01:37:31.696543
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import (
        Address,
        Card,
        Codes,
        Color,
        Datetime,
        File,
        Hash,
        Internet,
        Person,
        Text,
    )
    from mimesis.exceptions import NonEnumerableError, UnsupportedLocale

    # Person provider
    person = Person('en')
    with person.override_locale('ru'):
        print(person.full_name())

    # Text provider
    text = Text('en')
    with text.override_locale('ru'):
        print(text.word())

    # Codes provider
    codes = Codes('en')

# Generated at 2022-06-12 01:37:40.834293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider for test."""
        pass

    with TestProvider() as provider:
        provider.custom = "custom"

        def test_func():
            assert provider.custom == "custom"
            assert provider.locale == locales.DEFAULT_LOCALE

        test_func()

        with provider.override_locale(locales.DE):
            provider.custom = "custom_in_de"

            def test_func():
                assert provider.custom == "custom_in_de"
                assert provider.locale == locales.DE

            test_func()

        def test_func():
            assert provider.custom == "custom"
            assert provider.locale == locales.DEFAULT_LOCALE

        test_func()

# Generated at 2022-06-12 01:37:46.460134
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person()
    print("origin is " + person.get_current_locale())
    with person.override_locale('zh'):
        origin_locale = person.get_current_locale()
        assert origin_locale == 'zh'
    print("origin is " + person.get_current_locale())


# Generated at 2022-06-12 01:37:57.404810
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider()
    dp.locale = 'ru-ru'
    dp._data = {'name': 'Иван', 'last_name': 'Иванов', 'city': 'Москва'}
    locale_1 = dp.locale
    locale_2 = 'uk-ua'
    
    with dp.override_locale(locale_2) as dp_new:
        dp_new.locale = locale_2
        dp_new._data = {'name': 'Іван', 'last_name': 'Іванов', 'city': 'Москва'}
        assert dp_new.locale == locale_2
        assert dp_new.get_current_

# Generated at 2022-06-12 01:38:05.452742
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'provider.json'
            self._pull()

    p = Provider()
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert p.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:38:10.918884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get_current_locale(self):
            return self.locale

    provider = Provider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.locale == 'en'
        assert p.get_current_locale() == 'en'
    assert provider.locale == 'ru'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:38:14.634227
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    provider.locale = 'ml'
    with provider.override_locale('zh'):
        assert provider.locale == 'zh'
    assert provider.locale == 'ml'

# Generated at 2022-06-12 01:38:18.456383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    locale = locales.DEFAULT_LOCALE
    assert provider.locale == locale
    with provider.override_locale(locale) as custom_locale:
        assert custom_locale.locale == locale


# Generated at 2022-06-12 01:38:26.678647
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Tests for method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Class which has not locale dependent."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes."""
            super().__init__(locale=locale, seed=seed)
            self._data = {}
            self._datafile = 'first_names.json'
            self.locale = locale
            self._pull()

        def get_first_name(self) -> str:
            """Get first name for current locale.

            :return: First name.
            """
            return self._data['first_names']['male']

    p = Provider()

# Generated at 2022-06-12 01:38:40.605249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test context manager which allows overriding current locale."""
    c = BaseDataProvider(locale='ru')
    with c.override_locale('uk'):
        assert c.get_current_locale() == 'uk'
    assert c.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:38:50.348671
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):

        def __init__(self, locale: str = locales.EN, seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_data(self) -> JSON:
            return self._data

    provider = Provider(locale=locales.ES)

    with provider.override_locale(locale=locales.EN):
        assert provider.get_data()['a']['b'] == 'c'
    assert provider.get_data()['a']['b'] == 'd'

    with provider.override_locale(locale=locales.RU):
        assert provider.get_data()['a']['b'] == 'd'


# Generated at 2022-06-12 01:38:55.407324
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Address, Localization
    address = Address()
    assert address.locale == Localization.DEFAULT_LOCALE
    with address.override_locale('ru'):
        assert address.locale == 'ru'
    assert address.locale == Localization.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:02.449006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        """Dummy provider for testing locale overrides."""

        def foo(self) -> str:
            """Return locale name."""
            return self.get_current_locale()

    provider = DummyProvider()
    assert provider.foo() == locales.DEFAULT_LOCALE

    for locale in (locales.UA, locales.EN, locales.RU):
        with provider.override_locale(locale):
            assert provider.foo() == locale

# Generated at 2022-06-12 01:39:10.410596
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProviderFromBaseDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN):
            super().__init__(locale=locale)
            self._datafile = 'data'
        def funct(self):
            return 'test'
    provider = TestProviderFromBaseDataProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale()==locales.RU
        assert provider.funct()=='test'
    assert provider.get_current_locale()==locales.EN

# Generated at 2022-06-12 01:39:20.459376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    with Person().override_locale('tr') as tr_person:
        assert (tr_person.__str__() == 'Person <tr>')
        assert (tr_person.full_name() == 'İsmayil Baykal')

# Generated at 2022-06-12 01:39:23.518471
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        pass

    t = TestDataProvider()
    with t.override_locale('ru') as p:
        assert p.locale == 'ru'

    assert t.locale == 'en'

# Generated at 2022-06-12 01:39:35.183214
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check if working properly method ``override_locale``."""
    from mimesis.builtins import Address
    from mimesis.enums import Gender
    from mimesis.providers.address import AddressProvider
    from mimesis.providers.person import Person

    ctx = Address.override_locale('fr')
    assert ctx.__enter__().locale == 'fr'

    ctx = Address().override_locale('ru')
    assert ctx.__enter__().locale == 'ru'

    with Address().override_locale('fr'):
        assert Address().locale == 'fr'

    assert Address().locale == locales.DEFAULT_LOCALE

    with Person().override_locale('fr') as person_fr:
        assert person_fr.gender() == Gender.M

# Generated at 2022-06-12 01:39:38.904286
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Datetime
    dt = Datetime()
    with dt.override_locale('ru') as rdt:
        assert rdt.get_current_locale() == 'ru'
    assert dt.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:39:49.216066
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    def test_override_locale(provider: BaseDataProvider, locale: str) -> None:
        """Test override_locale method.

        Checks that the context manager overrides the current locale
        for locale-dependent providers.

        :param provider: Provider with locale attribute.
        :param locale: Locale.
        :return: Nothing.
        """
        with provider.override_locale(locale) as override_provider:
            assert override_provider.locale == locale
            assert override_provider.get_current_locale() == locale

        assert provider.locale != locale
        assert provider.get_current_locale() != locale


# Generated at 2022-06-12 01:40:11.593266
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    locale_trans = 'ru'
    provider = BaseDataProvider(locale=locale)
    provider.override_locale(locale_trans)
    assert provider.get_current_locale() == locale_trans
    provider.override_locale(locale)

# Generated at 2022-06-12 01:40:15.891445
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SubClass(BaseDataProvider):
        def __init__(self, locale=locales.EN):
            super().__init__(locale)

    a = SubClass()
    with a.override_locale(locales.RU):
        assert a.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:40:22.042206
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale=locales.UK)

    def get_locale(locale: str) -> str:
        with provider.override_locale(locale):
            return provider.locale

    assert get_locale(locales.UK) == locales.UK
    assert get_locale(locales.RU) == locales.RU
    assert provider.locale == locales.UK

# Generated at 2022-06-12 01:40:25.326972
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Dummy(BaseDataProvider):
        pass
    obj = Dummy()
    with obj.override_locale('en-US') as d:
        assert d.locale == 'en-US'
    assert obj.locale == 'en'

# Generated at 2022-06-12 01:40:36.048971
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.environment import Environment
    from mimesis.builtins.geography import Geography

    environment: Environment = Environment()
    geography: Geography = Geography()

    with environment.override_locale(locales.RU):
        with geography.override_locale(locales.DE):
            assert environment.get_current_locale() == locales.RU
            assert geography.get_current_locale() == locales.DE
            assert environment.get_system_locale() == locales.RU
            assert geography.get_current_locale() == locales.DE
    assert environment.get_system_locale() == locales.DE
    assert geography.get_current_locale() == locales.DE



# Generated at 2022-06-12 01:40:43.322073
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import re
    class FakeProvider(BaseDataProvider):
        pass

    provider = FakeProvider()

    with provider.override_locale('en') as override_provider:
        assert override_provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as override_provider:
        assert override_provider.get_current_locale() == 'ru'

    try:
        with provider.override_locale('xx'):
            assert False, "xx - locale is not supported"
    except UnsupportedLocale as error:
        assert re.match(r'Unsupported locale: xx', error.args[0])

    class User(object):
        def __init__(self, name):
            self.name = name

        def __enter__(self):
            return self

# Generated at 2022-06-12 01:40:52.779224
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class MockBaseDataProviderTwo(BaseDataProvider):
        """Class for mocking in tests."""

    class MockBaseDataProvider(BaseDataProvider):
        """Class for mocking in tests."""

        def get_current_locale(self) -> str:
            """Get current locale.

            :return: Current locale.
            """
            return self.locale

    # Invalid locale
    provider = MockBaseDataProvider()

    with provider.override_locale('xx'):
        assert provider.get_current_locale() == 'xx'

    assert provider.get_current_locale() != 'xx'

    # Invalid data provider
    provider = MockBaseDataProviderTwo()


# Generated at 2022-06-12 01:41:01.573435
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class OverrideLocaleProvider(BaseDataProvider):
        def __init__(self, seed: Seed = None,
                     locale: str = locales.DEFAULT_LOCALE):
            super().__init__(seed=seed, locale=locale)

    provider = OverrideLocaleProvider()
    with provider.override_locale(locales.EN) as en_provider:
        assert provider.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_current_locale() == en_provider.get_current_locale()

# Generated at 2022-06-12 01:41:07.114973
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    address = Address()
    # check that we have names in data
    assert 'locations' in address._data
    with address.override_locale(Address.locales.DE):
        # now we have de locations instead of en
        assert 'locations' in address._data
    # after exit from the context manager, we back to en locations
    assert 'locations' in address._data

# Generated at 2022-06-12 01:41:11.353126
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""
    from mimesis.data.test import TestDataProvider
    provider = TestDataProvider()

    with provider.override_locale('en') as en:
        assert en.get_current_locale() == 'en'
    assert provider.get_current_locale() != 'en'

# Generated at 2022-06-12 01:41:56.064733
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # TODO: test BaseDataProvider._override_locale
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'localization.json'
            self._pull()

        def __str__(self):
            return self.localization

    p = Provider()
    with p.override_locale(locales.EN):
        assert p.localization == 'British'

    with p.override_locale(locales.RU):
        assert p.localization == 'Russian'

    assert p.localization == 'British'

# Generated at 2022-06-12 01:42:04.625586
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class LocaleDataProvider(BaseDataProvider):
        """LocaleDataProvider."""

        class Meta:
            """Meta class."""

            locales = ('en', 'ru')


        def __init__(self, locale: str = 'ru', seed: Seed = None):
            """Construct a BaseDataProvider.

            :param seed: The seed of all random functions.
            """
            super().__init__(locale, seed=seed)

    ldp = LocaleDataProvider()
    en_ldp = LocaleDataProvider('en')

    with ldp.override_locale():
        assert ldp.get_current_locale() == 'en'

# Generated at 2022-06-12 01:42:07.430514
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    print('test_BaseDataProvider_override_locale')
    print(locales.EN)
    pass

    # TODO
    # maybe replace this method with test of another more complex method?

# Generated at 2022-06-12 01:42:12.680619
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'

    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:42:22.891560
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.internet import Internet
    from mimesis.providers.address import Address

    internet = Internet(seed=42)

    with internet.override_locale('ru') as ru_internet:
        ru_internet.user_agent()
        ru_internet.url()

    assert ru_internet.locale == 'ru'
    assert ru_internet.user_agent() == 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; de-at) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1'
    assert ru_internet.url() == 'jqnnbq.ru'


# Generated at 2022-06-12 01:42:31.144092
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Use context manager."""
    class Person(BaseDataProvider):
        """Data provider for human."""

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'person.json'
            self._pull()

        def full_name(self) -> str:
            """Get full name of a person."""
            return self.random.choice(self._data['full_name'])

        def __str__(self):
            """Human-readable representation of locale."""

# Generated at 2022-06-12 01:42:40.552501
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the method override_locale of class BaseDataProvider.

    Method override_locale is a context manager which allows overriding
    current locale.
    """
    from mimesis.providers.internet import URL
    from mimesis.providers.person import Person

    with Person(locale='ru').override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.full_name() == 'Amanda P. Horne'

    assert Person().get_current_locale() == 'ru'

    with URL().override_locale('en') as u:
        assert u.get_current_locale() == 'en'
        assert u.domain_name() == 'microsoft.com'
        assert u.subdomain() == 'www'

    # ValueError:

# Generated at 2022-06-12 01:42:47.984854
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en-US')
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.get_full_name(gender=Gender.MALE) != p.get_full_name(gender=Gender.MALE)
    assert p.get_current_locale() != ru.get_current_locale()
    assert p.get_current_locale() == 'en-US'



# Generated at 2022-06-12 01:42:49.445780
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    pass

# Generated at 2022-06-12 01:42:59.867553
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    # pylint: disable=unused-variable
    import random
    import time
    import pytest
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.base import BaseDataProvider
    from mimesis.enums import Gender, Locale

    class SubclassDataProvider(BaseDataProvider):
        """Subclass from BaseDataProvider."""

        def __init__(self, **kwargs):
            """Initialize the subclass.

            :param kwargs: Keyword arguments.
            """
            super().__init__(**kwargs)

        def get_integer(self) -> int:
            """Return random integer."""
            return self.random.randint(1, 100)


# Generated at 2022-06-12 01:44:32.682184
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Unit test for method override_locale of class BaseProvider
    class TestOverrider(BaseDataProvider):

        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self):
            return self.locale

    overrider = TestOverrider()
    assert overrider.get_current_locale() == locales.EN

    with overrider.override_locale(locales.RU) as ru:  # type: TestOverrider
        assert ru.locale == locales.RU

    assert overrider.get_current_locale() == locales.EN

    # Test error handling
    with overrider.override_locale():
        assert overrider.get_current

# Generated at 2022-06-12 01:44:39.479241
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Docstring."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.
            :param locale: Current locale.
            """
            super().__init__(locale=locale,
                             seed=seed)
            self._datafile = 'countries.json'

        def get_country(self) -> str:
            """Get country from a list."""
            return self.random.choice(self._data['countries'])

        def print_random(self) -> None:
            print(self.get_country())

    provider = TestProvider(
        locale='ru'
    )

# Generated at 2022-06-12 01:44:49.722132
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.date import Date
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    # TODO: replace it with a random list of supported locales
    target_locales = [
        locales.EN,
        locales.RU,
        locales.PT,
        locales.ES,
        locales.IT,
        locales.DE,
        locales.NL,
        locales.FR,
        locales.DA,
        locales.FI,
        locales.ID,
        locales.CZ,
        locales.TR,
    ]


# Generated at 2022-06-12 01:44:57.746779
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Mock(BaseDataProvider):
        __slots__ = (
            '_locale',
            'default_locale',
            '_initial_locale',
            'reseed',
        )

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            self.default_locale = locales.DEFAULT_LOCALE
            self._initial_locale = locale
            self._locale = None

        @property
        def locale(self) -> str:
            return self._locale or self._initial_locale

        @locale.setter
        def locale(self, value: str) -> None:
            self._locale = value

    provider = Mock('en')
    assert provider.locale == 'en'

# Generated at 2022-06-12 01:45:07.005840
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.generic import Person
    from mimesis.enums.gender import Gender as GenderType
    person = Person(seed = 0)
    m = person.get_full_name(Gender.MALE)
    f = person.get_full_name(Gender.FEMALE)
    assert m == 'Иван Медведев'
    assert f == 'Наталья Владимировская'
    try:
        with person.override_locale('es'):
            m = person.get_full_name(Gender.MALE)
            f = person.get_full_name(Gender.FEMALE)
    except AttributeError:
        pass


# Generated at 2022-06-12 01:45:08.703760
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert (BaseDataProvider().override_locale(locale='en').get_current_locale()
            == 'en')

# Generated at 2022-06-12 01:45:18.941670
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale(): # noqa
    """Test method of class BaseDataProvider."""
    class MyProvider(BaseDataProvider):
        """Test class."""

        def __init__(self, locale: str = 'en', seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale=locale, seed=seed)

    expected = ['kot', 'pes', 'zebra']
    provider = MyProvider('en_US')
    provider._data = {'animal': ['cat', 'dog', 'zebra']}
    assert provider.get_current_locale() == 'en_us'
    assert provider._data['animal'] == expected

    new_data = {'animal': ['kot', 'pes', 'zebra']}
    with provider.override_locale('ru'):
        provider._data = new_

# Generated at 2022-06-12 01:45:24.801128
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            self.locale = None
            super().__init__(locale=locale, seed=seed)

    prov = TestBaseDataProvider()
    with prov.override_locale('ru') as result:
        assert result == prov
        assert result.locale == 'ru'
    assert prov.locale is None


# Generated at 2022-06-12 01:45:32.588651
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def get_current_locale(self) -> str:
            """Get current locale."""
            return self.locale

    provider = Test()
    provider.override_locale(locales.EN)
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:45:34.486906
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale('ru') as test_override:
        assert test_override.locale == 'ru'
    assert bdp.locale == locales.DEFAULT_LOCALE