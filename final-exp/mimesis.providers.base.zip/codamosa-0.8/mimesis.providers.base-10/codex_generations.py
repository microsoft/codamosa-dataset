

# Generated at 2022-06-12 01:36:09.602198
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = '') -> None:
            super().__init__(locale)
            self.firstname = self._data['first_name']

        def __getitem__(self, key: str) -> Any:
            """Get item from _data."""
            return self._data[key]

        def __setitem__(self, key: str, value: Any) -> None:
            """Update _data with the new value."""
            self._data[key] = value

        def __str__(self) -> str:
            """Human-readable representation of locale."""
            locale = getattr(self, 'locale', locales.DEFAULT_LOCALE)

# Generated at 2022-06-12 01:36:12.652403
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    with Address().override_locale('ru') as addr:
        assert addr.get_current_locale() == 'ru'
        assert addr.get_region() == 'Киевская'

# Generated at 2022-06-12 01:36:19.611480
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()

    with person.override_locale('ru'):
        assert person.get_current_locale() == locales.RU
        assert person.name() in person._data['names']['male']

    assert person.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:36:30.318445
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender

    class Person(BaseDataProvider):
        """The class for testing."""

        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)
            self.datafile = 'person.json'

        def get_full_name(self,
                          gender: Gender,
                          middle_name: bool = False) -> str:

            """Get full name.

            :param gender: Gender.
            :param middle_name: With middle name or not.
            :return: Full name.
            """
            return self._get_formatted_value(
                'name', gender, middle_name=middle_name)


# Generated at 2022-06-12 01:36:36.165626
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        LOCALE = {'locale': 'test'}

        def _pull(self, datafile: str = '') -> None:
            self._data = self.LOCALE

    test = Test()

    assert str(test) == 'Test <en>'

    with test.override_locale('test') as t:
        assert t is test
        assert str(t) == 'Test <test>'

    assert str(test) == 'Test <en>'



# Generated at 2022-06-12 01:36:39.419893
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:36:47.757863
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.providers.internet import Internet
    from mimesis.locales import EN, JA

    internet = Internet()

    assert internet.get_current_locale() == EN

    with internet.override_locale(locale=JA) as provider:
        assert provider.get_current_locale() == JA
        assert provider.get_ipv4() == internet.get_ipv4()

    assert internet.get_current_locale() == EN

# Generated at 2022-06-12 01:36:59.302557
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for context manager which allows overriding current locale.
    """
    class TestCustom(BaseDataProvider):
        """Subclass of BaseDataProvider.
        """
        def __init__(self, *args, **kwargs):
            self.data = {
                'key': 'value',
                'key1': 'value1',
                'key2': 'value2'
            }
            super().__init__(*args, **kwargs)

    data_provider = TestCustom(locale='en')
    assert data_provider.get_current_locale() == 'en'
    with data_provider.override_locale(locale='ru') as test_custom:
        assert test_custom.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:07.802513
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.data = self._pull()
    p = Provider('en')
    with p.override_locale('ru'):
        assert p._pull()['unit']['length']['kilometre'] == 'километр'
    assert p._pull()['unit']['length']['kilometre'] == 'kilometre'


# Generated at 2022-06-12 01:37:10.941851
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = "ru_RU"
    p = BaseDataProvider(locale=locale)
    assert p.get_current_locale() == "en"
    assert isinstance(p, BaseDataProvider)



# Generated at 2022-06-12 01:37:26.452301
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Temp(BaseDataProvider):
        @classmethod
        def get_locale(cls, locale: str = locales.EN,
                       ):
            with cls().override_locale(locale):
                return cls().locale

    assert Temp.get_locale() == locales.EN
    assert Temp.get_locale('ru') == 'ru'


# Generated at 2022-06-12 01:37:35.451468
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins

    provider = mimesis.builtins.Code()

    # The locale of the ``provider`` is ``en``, but we need ``ru``.
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.code(kind=mimesis.builtins.Code.PYTHON).startswith('Р')

    assert provider.get_current_locale() == locales.EN
    assert provider.code(kind=mimesis.builtins.Code.PYTHON).startswith('d')



# Generated at 2022-06-12 01:37:41.239102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale: str = 'en') -> None:
            super().__init__(locale=locale)

    test = Test()
    with test.override_locale('ru') as t:
        assert t.locale == 'ru'
        assert t.get_current_locale() == 'ru'

    assert test.locale == 'en'
    assert test.get_current_locale() == 'en'

# Generated at 2022-06-12 01:37:47.255383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self) -> None:
            super().__init__()

        def method(self) -> str:
            return self.get_current_locale()

    provider = Provider()

    with provider.override_locale('ar') as p:
        assert p.method() == 'ar'

    with provider.override_locale('ru') as p:
        assert p.method() == 'ru'

    assert provider.method() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:37:47.886595
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert True

# Generated at 2022-06-12 01:37:58.453147
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)
            self.locale = locale

        def get_current_locale(self):
            return self.locale

    provider = Provider()
    locale_1 = locales.EN
    locale_2 = locales.RU
    locale_3 = locales.JA

    assert provider.get_current_locale() == locale_1
    with provider.override_locale(locale_2):
        assert provider.get_current_locale() == locale_2
    assert provider.get_current_locale() == locale_1

    with provider.override_locale(locale_3):
        assert provider.get_current_

# Generated at 2022-06-12 01:38:08.906697
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test function for method override_locale of class BaseDataProvider."""
    def func():
        """This is a test function."""

    class TestDataProvider(BaseDataProvider):
        """This is a test class."""

        def __init__(self):
            """Init for test class."""
            super().__init__()
            self.locale = 'ut_test_locale'

    obj = TestDataProvider()
    with obj.override_locale('en') as tmp:
        assert tmp.locale == 'en'
        with obj.override_locale('ru') as tmp2:
            assert tmp2.locale == 'ru'
            func()
        assert tmp.locale == 'en'
    assert obj.locale == 'ut_test_locale'

# Generated at 2022-06-12 01:38:13.733595
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Francais

    provider = Francais()
    default_locale = provider.locale

    with provider.override_locale(locales.EN):
        assert provider.locale == locales.EN

    assert provider.locale == default_locale

# Generated at 2022-06-12 01:38:19.040696
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from  mimesis.builtins import Person

    p = Person()
    with p.override_locale(locales.RU):
        assert p.locale == locales.RU
        assert p.full_name() == 'Иван Баранов'

    assert p.locale == locales.EN
    assert p.full_name() == 'Zack Dewitt'

# Generated at 2022-06-12 01:38:24.537926
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.JA):
        assert provider.get_current_locale() == locales.JA

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:38:51.979591
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        _datafile = 'test.json'
    provider = TestProvider()
    provider._pull()
    with provider.override_locale('ru'):
        assert provider.locale == 'ru'
        assert provider._pull.cache_info().currsize == 1
    with provider.override_locale('es'):
        assert provider.locale == 'es'
        assert provider._pull.cache_info().currsize == 2
    assert provider.locale == 'en'
    assert provider._pull.cache_info().currsize == 2


# Generated at 2022-06-12 01:38:59.002688
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    with Address().override_locale(locales.BG) as provider:
        assert provider.get_current_locale() == locales.BG
    assert Address().get_current_locale() == locales.EN
    assert isinstance(Address(), Address)
    assert not isinstance(Address(), BaseDataProvider)
    assert isinstance(Address(), BaseProvider)
test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:39:07.455371
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test class for BaseDataProvider."""

        def get_countries(self) -> Dict[str, str]:
            """Get all countries from base provider class."""
            return self._data['countries']

    tester = TestDataProvider(seed='test')
    with tester.override_locale('ru'):
        assert tester.get_countries() == {'ad': 'Андорра', 'ae': 'ОАЭ'}
    assert tester.get_countries() == {'ad': 'Andorra', 'ae': 'United Arab Emirates'}

# Generated at 2022-06-12 01:39:13.337563
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert provider.locale == 'en'
    provider.override_locale(locale='zh')
    assert provider.locale == 'zh'
    with provider.override_locale(locale='zh'):
        assert provider.locale == 'zh'
    assert provider.locale == 'en'

# Generated at 2022-06-12 01:39:17.822441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    for locale in locales.SUPPORTED_LOCALES:
        overrider = provider.override_locale(locale)
        assert str(provider) == 'TestProvider <{}>'.format(locale)


# Generated at 2022-06-12 01:39:29.879567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    qwerty = Person('ru')
    internet = Internet('ru')

    klava = Internet('en')
    address = Address('en')
    with qwerty.override_locale('en'):
        assert qwerty.full_name(gender=Gender.FEMALE) == 'Hanna Adams'
        assert internet.email() == 'leonard_williamson@gmail.com'
        assert address.city() == 'East Laura'

    assert klava != internet
    assert internet.email() == 'vla-dimirs@gmail.com'

# Generated at 2022-06-12 01:39:34.940619
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN) as data:
        assert data.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:39:38.431534
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider().override_locale('xx'):
            pass
    except ValueError as e:
        assert e.args[0] == '«BaseDataProvider» has not locale dependent'
    else:
        assert False

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:39:44.973120
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers import Address
    from mimesis.enums import Locale
    with Address().override_locale(locale=Locale.EN):
        assert Address().get_current_locale() == 'en'
        assert Address()._(Address.ENUM_FIELDS, Address().country) == 'Japan'


# Generated at 2022-06-12 01:39:51.785031
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Food
    food = Food()
    with food.override_locale('ru') as food_ru:
        # In this context food_ru is a Food provider with locale 'ru'
        assert food_ru.get_current_locale() == 'ru'
        assert food.get_current_locale() == 'en'
        assert food_ru.get_spice() == u'Кориандр'
        assert food.get_spice() == u'Coriander'

# Generated at 2022-06-12 01:40:41.602754
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person
    provider = Person()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    provider.locale = locales.EN
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:40:51.332607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    import tempfile

    from mimesis.data import Address

    from .test_base_provider import test_BaseProvider_reseed
    from .test_base_provider import test_BaseProvider_str

    test_BaseProvider_reseed(BaseDataProvider)
    test_BaseProvider_str(BaseDataProvider)

    path = os.path.dirname(__file__)
    temp_dir = path + '/temp'
    locale_data_dir = temp_dir + '/locale/locale'

    os.makedirs(locale_data_dir, exist_ok=True)


# Generated at 2022-06-12 01:40:57.405403
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):

        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def print(self):
            print(self.locale)

    foo = Foo()
    with foo.override_locale('ru-RU') as foo:
        foo.print()



# Generated at 2022-06-12 01:41:04.710137
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyDataProvider(BaseDataProvider):
        class Meta:
            name = 'test'

        def get_data(self):
            return 'data'

    provider = MyDataProvider(locale='en')

    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == 'data'

    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get_data() == 'data'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:09.157226
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider()
    with dp.override_locale():
        assert dp.locale == locales.EN

    dp = BaseDataProvider()
    with dp.override_locale('ru'):
        assert dp.locale == 'ru'



# Generated at 2022-06-12 01:41:13.718393
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):

        _datafile = 'test_data.json'

        def t1(self, item: str) -> str:
            return self._data[item]

    provider = Test(locale='en')
    with provider.override_locale('ru') as p:
        assert p.t1('test') == 'тест'
    assert provider.t1('test') == 'test'



# Generated at 2022-06-12 01:41:23.184845
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider1 = BaseDataProvider()
    provider2 = BaseDataProvider()
    provider1.locale = locales.EN
    provider2.locale = locales.RU
    provider1.data = {'a': 3}
    provider2.data = {'a': 4}

    assert provider1.locale is locales.EN
    assert provider2.locale is locales.RU
    assert provider1.data['a'] is 3
    assert provider2.data['a'] is 4

    with provider1.override_locale(locale=locales.RU):
        assert provider1.locale is locales.RU
        assert provider2.locale is locales.RU
        assert provider1.data['a'] is 4
        assert provider2.data['a'] is 4

    assert provider1.loc

# Generated at 2022-06-12 01:41:29.629806
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        pass
    my_provider = MyProvider()
    locale = locales.EN
    with my_provider.override_locale(locale) as provider:
        assert provider.locale == locale
    assert my_provider.locale != locale

# Generated at 2022-06-12 01:41:35.685611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data = [('en', ['en']), ('ru', ['ru', 'en']), ('uk', ['uk', 'ru', 'en'])]

    def check_locale(locale_name: str, locales_list: list) -> bool:
        instance = BaseDataProvider()
        with instance.override_locale(locale=locale_name):
            locale = instance.get_current_locale()
            return locale in locales_list

    return all(check_locale(locale_data[0], locale_data[1]) for locale_data in data)



# Generated at 2022-06-12 01:41:41.799847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider's override locale method."""
    provider = BaseDataProvider(locale='en')
    provider._pull = lambda : None
    provider._override_locale(locale='ru')
    with provider.override_locale('ru'):
        provider2 = BaseDataProvider(locale='ru')
        provider2._pull = lambda : None
    assert provider.locale == 'en'
    assert provider2.locale == 'ru'

# Generated at 2022-06-12 01:43:25.168088
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    provider = Person('ru')
    with provider.override_locale():
        provider.full_name(gender=Gender.FEMALE)
        provider.full_name(gender=Gender.MALE)

    with provider.override_locale(locale='en'):
        provider.full_name(gender=Gender.FEMALE)
        provider.full_name(gender=Gender.MALE)

    with provider.override_locale(locale='en-US'):
        provider.full_name(gender=Gender.FEMALE)
        provider.full_name(gender=Gender.MALE)

# Generated at 2022-06-12 01:43:30.430834
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Names
    from mimesis.enums import Gender
    names = Names('en')
    with names.override_locale('ru'):
        assert 'Ира' == names.get_first_name(gender=Gender.FEMALE)
    assert 'Ира' != names.get_first_name(gender=Gender.FEMALE)


# Generated at 2022-06-12 01:43:35.629136
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale, seed)

        def get_data(self, key: str) -> Any:
            return self._data.get(key)

    dp = TestDataProvider()
    assert dp.get_data('color') == 'color'
    with dp.override_locale(locales.RU) as p:
        assert p.get_data('color') == 'цвет'
    assert dp.get_data('color') == 'color'

# Generated at 2022-06-12 01:43:44.958232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.builtins.en import Person as EnPerson

    assert Person._datafile == EnPerson._datafile
    assert Person.get_current_locale() == EnPerson.get_current_locale()

    with Person.override_locale(locales.EN) as p:
        assert Person._datafile == p._datafile
        assert Person._data == p._data
        assert Person.get_current_locale() == p.get_current_locale()

    assert Person._datafile == EnPerson._datafile
    assert Person._data != p._data
    assert Person.get_current_locale() == EnPerson.get_current_locale()

# Generated at 2022-06-12 01:43:53.246248
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

# Generated at 2022-06-12 01:44:00.941110
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from . import cars
    from . import personal

    cars_en = cars.Vehicle(locale='en')
    cars_ru = cars.Vehicle(locale='ru')
    personal_en = personal.Personal(locale='en')
    personal_ru = personal.Personal(locale='ru')

    # car_ru is not locale dependent, so it should raise ValueError
    try:
        cars_ru.override_locale('de')
    except ValueError:
        assert True
    else:
        assert False

    with cars_en.override_locale('de'), personal_ru.override_locale('it'):
        assert cars_en.get_current_locale() == 'de'
        assert cars_ru.get_current_locale() == 'ru'
        assert personal_en.get_

# Generated at 2022-06-12 01:44:06.157210
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Test setup
    # Provider without `locale` attribute
    provider = BaseDataProvider()

    # Test
    with pytest.raises(ValueError):
        with provider.override_locale('ru'):
            pass



# Generated at 2022-06-12 01:44:08.288763
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale() as p:
        assert p.get_current_locale() != provider.get_current_locale()

# Generated at 2022-06-12 01:44:16.822557
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as p:
        assert p.locale == locales.RU

    with BaseDataProvider().override_locale() as p:
        assert p.locale == locales.EN

    with BaseDataProvider().override_locale('uk') as p:
        assert p.locale == locales.UK

    with BaseDataProvider().override_locale('ro') as p:
        assert p.locale == locales.RO

    with BaseDataProvider().override_locale('it') as p:
        assert p.locale == locales.IT

    with BaseDataProvider().override_locale('tr') as p:
        assert p.locale == locales.TR


# Generated at 2022-06-12 01:44:26.368906
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    cls_name = 'BaseDataProvider'
    locale = locales.DEFAULT_LOCALE
    data_dir = 'data/en'
    datafile = 'lorem.json'

    @functools.lru_cache(maxsize=None)
    def pull(datafile: str = '') -> Dict[str, dict]:
        """Pull the content from the JSON and memorize one.
        Opens JSON file ``file`` in the folder ``data/locale``
        and get content from the file and memorize ones using lru_cache.

        :param datafile: The name of file.
        :return: The content of the file.
        :raises UnsupportedLocale: Raises if locale is unsupported.
        """