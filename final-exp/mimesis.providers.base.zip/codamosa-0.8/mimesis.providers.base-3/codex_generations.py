

# Generated at 2022-06-12 01:36:01.843331
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test if attribute locale is not exist
    with BaseDataProvider(locale='en').override_locale('ru') as bp:
        assert bp.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:36:10.073523
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    a = Address(seed=1)
    with a.override_locale('ru') as a_ru:
        assert a_ru.get_country() == a.get_country()
        assert a_ru.get_country(Country.RUSSIA) == 'Россия'
        assert a_ru.get_country(Country.BRAZIL) == 'Бразилия'
        assert a.get_country() == 'Brazil'
        assert a.get_country(Country.BRAZIL) == 'Brazil'
        assert a.get_country(Country.RUSSIA) == 'Russia'

# Generated at 2022-06-12 01:36:20.853824
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # 1. Arrange
    from mimesis.providers.business import Business
    from mimesis.providers.finance import Finance
    from mimesis.providers.personal import Personal
    
    locale = 'jp'
    provider_1 = Business(locale=locale)
    provider_2 = Finance(locale=locale)
    provider_3 = Personal(locale=locale)
    
    # 2. Act
    with provider_1.override_locale('zh') as provider:
        data_1 = provider.currency_code()
    with provider_2.override_locale('zh') as provider:
        data_2 = provider.credit_card_number()
    with provider_3.override_locale('zh') as provider:
        data_3 = provider.prefix()
        
   

# Generated at 2022-06-12 01:36:31.820778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale."""
    from mimesis.builtins import Address, Person

    p = Person(locale='ru')
    assert p.provider.get_current_locale() == 'ru'

    with p.override_locale('es') as person:
        assert isinstance(person, Person)
        assert person.provider.get_current_locale() == 'es'
    with p.override_locale('en') as person:
        a = Address(locale='uk')
        with a.override_locale('ru'):
            assert a.provider.get_current_locale() == 'ru'
        assert a.provider.get_current_locale() == 'uk'

# Generated at 2022-06-12 01:36:38.020633
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        _datafile = 'fake.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    p = DummyProvider()
    assert p.get_data() == {
        "key": "value",
    }
    # override locale
    with p.override_locale('ru'):
        assert p.get_data() == {
            "key": "value",
            "ru-key": "ru-value",
        }
    assert p.get_data() == {
        "key": "value",
    }


# Generated at 2022-06-12 01:36:49.837464
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    Unit test for method override_locale of class BaseDataProvider.
    '''

    class Test(BaseDataProvider):
        """Class Test used to test override_locale method."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale, seed)
            self._datafile = 'useragent.json'
            self._pull()

        def get_version(self) -> str:
            """Return value of VERSION field from useragent.json."""
            return self._data['USERAGENT']['VERSION']

    test = Test('ru')


# Generated at 2022-06-12 01:37:00.542298
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    class BaseDataProviderTest(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            # pass
            return
        def _setup_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            raise UnsupportedLocale(locale)
    # in order to test override_locale() method, we need to remove @functools.lru_cache decorator
    # remove_decorator(BaseDataProviderTest, '_pull')
    # Act
    with BaseDataProviderTest(locale='en') as base_data_provider:
        actual = base_data_provider.locale
    # Assert
    assert actual == 'en'
    # with pdb.Pdb().set_trace():
    #     base_data_

# Generated at 2022-06-12 01:37:02.231608
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


# Generated at 2022-06-12 01:37:09.899623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that BaseDataProvider.override_locale() works correctly."""
    from mimesis import Person

    class OverrideProvider(Person):
        def __init__(self, seed: Seed = None, locale: str = locales.EN):
            super().__init__(seed, locale)

    provider = OverrideProvider()
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:10.474109
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-12 01:37:27.775510
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""
    BDP = BaseDataProvider()
    class SubClass(BDP):
        """Mock class for test"""
        def __init__(self):
            super(SubClass, self).__init__()
            self.locale = 'en'
    with BDP.override_locale(locale='ru') as bdp:
        assert bdp.locale == 'ru'
    with SubClass().override_locale(locale='ru') as bdp:
        assert bdp.locale == 'ru'

# Generated at 2022-06-12 01:37:31.083345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() is None
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:32.499817
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider('en_GB')
    p.get_current_locale()

# Generated at 2022-06-12 01:37:38.776856
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale."""
    bd = BaseDataProvider()
    with bd.override_locale(locales.EN):
        assert bd.get_current_locale() == locales.EN

    with bd.override_locale(locales.RU):
        assert bd.get_current_locale() == locales.RU

    with bd.override_locale(locales.DE):
        assert bd.get_current_locale() == locales.DE

# Generated at 2022-06-12 01:37:40.528412
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # TODO(ww): Create a class with method override_locale.
    #  And write a test for it.
    pass

# Generated at 2022-06-12 01:37:50.917277
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers import Address, Personal
    from mimesis.enums import Gender

    a = Address(locale='ru')
    b = Address(locale='en')
    c = Personal(locale='en')
    d = Personal(locale='ru')

    with a.override_locale('en'):
        assert a.get_current_locale() == 'en'
        assert a.get_city() in c.cities

    with b.override_locale('ru'):
        assert b.get_current_locale() == 'ru'
        assert b.get_city() in d.cities


# Generated at 2022-06-12 01:38:00.116354
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            self.locale = 'en'
            super().__init__(*args, **kwargs)
        def _pull(self):
            self._data = { 'test' : { 'en' : 'en', 'ru' : 'ru'} }

    pr = Provider()
    assert pr._data == { 'test' : { 'en' : 'en', 'ru' : 'ru'} }

    with pr.override_locale('ru'):
        assert pr._data == { 'test' : { 'en' : 'en', 'ru' : 'ru'} }

    assert pr._data == { 'test' : { 'en' : 'en', 'ru' : 'ru'} }

# Generated at 2022-06-12 01:38:09.520483
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestLocaleProvider(BaseDataProvider):

        def get_current_locale(self) -> str:
            return self.locale

    tp = TestLocaleProvider()
    assert tp.get_current_locale() == locales.DEFAULT_LOCALE
    with tp.override_locale(locales.EN) as tp:
        assert tp.get_current_locale() == locales.EN
    assert tp.get_current_locale() == locales.DEFAULT_LOCALE

    class TestNotLocaleProvider(BaseDataProvider):
        pass

    tp = TestNotLocaleProvider()
    try:
        with tp.override_locale(locales.EN) as tp:
            pass
    except ValueError:
        pass
    else:
        raise Assert

# Generated at 2022-06-12 01:38:20.197744
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.enums
    from datetime import datetime

    class TestProvider(BaseDataProvider):
        """Test provider."""

        class Meta:
            """Class for metaclass."""

            name = 'test'
            locales = (locales.EN, locales.RU)

        def __init__(self, locale: str = locales.EN):
            """Initialize attributes.

            :param locale: Locale code.
            """
            super().__init__(locale=locale)

        def timezone(self) -> str:
            """Get timezone."""
            return self.random.choice(self._data['timezones'])


# Generated at 2022-06-12 01:38:22.399336
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        pass

    dp = DataProvider()
    dp.override_locale()

# Generated at 2022-06-12 01:38:46.460112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    address = Address()
    expected_a = ['улица', 'ул.']

    with address.override_locale('ru'):
        actual_a = address.street_name()

    assert actual_a in expected_a

# Generated at 2022-06-12 01:38:52.285806
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check if method works as expected."""
    from mimesis.enums import Gender

    from .person import Person

    en = Person('en')
    ru = Person('ru')

    with ru.override_locale('en') as e:
        assert e.get_formatted_name(gender=Gender.FEMALE) == en.get_formatted_name(gender=Gender.FEMALE)
    assert ru.get_formatted_name() != en.get_formatted_name()

# Generated at 2022-06-12 01:38:58.128659
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Code

    code = Code()
    with code.override_locale('de'):
        assert code.get_current_locale() == 'de'
    assert code.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:00.325957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.geography import Geography
    assert Geography().override_locale().__class__.__name__ == 'Geography'

# Generated at 2022-06-12 01:39:06.509508
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider."""

        class Meta:
            """Meta class."""

            name = 'test'
            locales = locales.SUPPORTED_LOCALES

        def create_body(self):
            """Return mock body."""
            return {"content": "foo bar"}

    provider = TestProvider()
    with provider.override_locale('ru'):
        provider.create_body()

# Generated at 2022-06-12 01:39:11.333170
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class LocaleProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)

    locale_provider = LocaleProvider()
    locale = locale_provider.get_current_locale()
    assert locale == 'en'
    with locale_provider.override_locale(locale=locales.RU):
        current_locale = locale_provider.get_current_locale()
        assert current_locale == 'ru'
    origin_locale = locale_provider.get_current_locale()
    assert origin_locale == 'en'

# Generated at 2022-06-12 01:39:20.975197
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, datafile):
            super().__init__(locale='en', seed=None)
            self._datafile = datafile
            self._pull()

        def get_dummy(self):
            return self._data['test']['dummy']

    tests = [
        ('en', 'en_test.json', 'dummy1'),
        ('ru', 'ru_test.json', 'dummy2'),
        ('en-us', 'en_test.json', 'dummy3'),
        ('ru-ru', 'ru_test.json', 'dummy4'),
    ]
    for locale, datafile, dummy in tests:
        provider = Test(datafile=datafile)

# Generated at 2022-06-12 01:39:26.449701
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    _ = BaseDataProvider()
    assert str(_) == 'BaseDataProvider <en>'

    with _.override_locale(locale='ar') as data:
        assert str(data) == 'BaseDataProvider <ar>'
    assert str(data) == 'BaseDataProvider <en>'


# Generated at 2022-06-12 01:39:36.436724
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def _pull(self, datafile: str = '') -> None:
            self._data = {
                'number': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
            }

        def get_number(self) -> int:
            return self.random.get(self._data['number'])

    provider = TestProvider()
    with provider.override_locale(locales.RU) as test_ru:
        number = test_ru.get_number()

    assert 0 <= number <= 9

# Generated at 2022-06-12 01:39:47.575486
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override locale method of class BaseDataProvider."""
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def get_current_locale(self):
            return self.locale

    test_provider = TestDataProvider()
    with test_provider.override_locale('be') as provider:
        assert provider.get_current_locale() == 'be'
    assert test_provider.get_current_locale() == 'en'

    # Class without locale-dependent
    class TestDataProviderWithoutLocale(BaseDataProvider):
        def get_current_locale(self):
            return self.locale

    test_provider = TestDataProviderWithoutLocale()

# Generated at 2022-06-12 01:40:39.916313
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    from mimesis.exceptions import UnsupportedLocale
    p=Person()
    p.override_locale('ru')
    p.override_locale('el')
    p.override_locale('fa')
    p.override_locale('fa')
    with p.override_locale('fa'):
        p.full_name()
    with p.override_locale('ru'):
        p.full_name()
    with p.override_locale('en'):
        p.full_name()
    with p.override_locale('el'):
        p.full_name()
    with p.override_locale('en'):
        p.full_name()

# Generated at 2022-06-12 01:40:50.037990
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider method override_locale."""
    class TestProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'provider.json'
            self._pull()

        def __getitem__(self, key: str) -> Any:
            return self._data[key]

    p = TestProvider()

    with p.override_locale(locales.RU):
        assert p.get_current_locale() == locales.RU
        assert p.get_item(['RU', 'UA']) == 'RU'

    assert p.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:40:58.663379
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN):
            super().__init__(locale)

        def get_data(self) -> Dict:
            return self._data

    dp = TestDataProvider()

    with dp.override_locale(locales.RU) as _dp:
        assert _dp is dp
        assert _dp.get_current_locale() == locales.RU
        assert dp.get_data() == {'test': 'тест'}

    assert dp.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:41:08.577373
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        _datafile = 'test_data.json'

        def __init__(self, locale, seed=None):
            super().__init__(locale=locale, seed=seed)

        def _pull(self, datafile='test_data.json'):
            super()._pull(datafile='test_data.json')


# Generated at 2022-06-12 01:41:16.055209
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from provider import DayOfWeek

    with DayOfWeek(locale='en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.get_day_of_week() == 'Monday'

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get_day_of_week() == 'понедельник'

    assert provider.get_current_locale() == 'en'
    assert provider.get_day_of_week() == 'Monday'

    # Test when locale dependent provider is used as a context manager
    with DayOfWeek(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.get_day

# Generated at 2022-06-12 01:41:18.906897
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    try:
        with Provider().override_locale():
            pass
    except ValueError:
        pass
    else:
        assert False

    with Provider(locale='en').override_locale(locale='ru'):
        assert Provider.get_current_locale() == 'ru'

    assert Provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:21.400734
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SomeProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN):
            super().__init__(locale=locale)

    provider = SomeProvider()
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:41:27.456561
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.identification import Identification
    assert isinstance(Identification.__name__, str)
    ident = Identification(locale='zh')
    with ident.override_locale('ru') as id_ru:
        assert id_ru.get_full_name(gender=Gender.MALE) == 'Петров Вячеслав Сергеевич'
    assert ident.get_full_name(gender=Gender.MALE) == '林冲'
test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:41:32.169026
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Phone

    data = {}
    with Phone().override_locale('ru') as phone:
        data['ru'] = phone.phone_number()

    with Phone().override_locale('en') as phone:
        assert (
            phone.phone_number() !=
            data['ru']
        )


# Generated at 2022-06-12 01:41:38.491793
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test overrides current locale with passed and pull data for new locale."""

    class Test(BaseDataProvider):
        """Test base data provider."""

        def __init__(self, locale, datafile):
            """Initialize attributes for data providers."""
            super().__init__(locale, datafile)
            # self._data = {}
            self._datafile = ''

        def get_data(self):
            """Get data."""
            return self._data

    class Test1(Test):
        """Test1 base data provider."""

        def __init__(self, locale, datafile):
            """Initialize attributes for data providers."""
            super().__init__(locale=locale, datafile=datafile)
            # self._data = {}
            self._datafile = ''


# Generated at 2022-06-12 01:43:22.639135
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestBaseDataProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale)

        def get_current_locale(self) -> str:
            return self.get_data('locales')[self.locale]

    test_base_data_provider = TestBaseDataProvider()

    with test_base_data_provider.override_locale('en_GB') as provider:
        assert str(provider) == 'TestBaseDataProvider <en>'

    assert str(test_base_data_provider) == 'TestBaseDataProvider <en>'

# Generated at 2022-06-12 01:43:25.819317
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU
        with provider.override_locale(locales.EN):
            assert provider.locale == locales.EN
    assert provider.locale == locales.RU

# Generated at 2022-06-12 01:43:34.043224
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        _datafile = 'name.json'
        _data = {}

        def get_first_name(self, gender: str = None) -> str:
            gender = self._validate_enum(gender, Gender)
            return self._data[self.locale]['first_names'][gender].title()

        def get_last_name(self) -> str:
            return self._data[self.locale]['last_names'].title()

    Gender = TestProvider.Gender

    with TestProvider(locale='ru').override_locale('en'):
        name = TestProvider.get_first_name(gender=Gender.FEMALE)
    assert name == 'Katherine'

# Generated at 2022-06-12 01:43:34.785383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  pass


# Generated at 2022-06-12 01:43:40.002690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for the method override_locale of the class BaseDataProvider.
    """
    base = BaseDataProvider(locale='ru')
    with base.override_locale('en') as provider:
        locale = provider.get_current_locale()
        assert locale == 'en'

# Generated at 2022-06-12 01:43:44.063145
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            pass

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
    assert provider.locale == locales.EN


# Generated at 2022-06-12 01:43:48.700827
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""
    class TestProvider(BaseDataProvider):
        pass
    provider = TestProvider()
    with provider.override_locale():
        assert provider.get_current_locale() == locales.EN
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:43:55.302357
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Animal(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)
            self._datafile = 'animal.json'
            self._pull()

        def get_animal(self, animal: Any = None) -> str:
            """Get animal, or group of animals."""
            animal_data = self._data['animal']
            if animal is None:
                animal = get_animal(animal_data, self.random)
            elif animal not in animal_data:
                raise NonEnumerableError(animal_data)
            return animal_data[animal]

    cat = Animal()
    assert cat.get_animal('tiger') == 'Тигр'

# Generated at 2022-06-12 01:43:59.258027
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit
    from mimesis.providers.web import Web

    data_providers = {
        'Datetime': Datetime().datetime,
        'Identifier': Identifier().uuid,
        'Misc': Misc().constant,
        'Person': Person().occupation,
        'Text': Text().word,
        'Unit': Unit('en').temperature(unit=Unit.C),
        'Web': Web().url,
    }

    # test current locale
    locale = 'ru'

# Generated at 2022-06-12 01:44:07.165977
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Test provider."""

        def __init__(self):
            """Initialize attributes."""
            super().__init__()
            self._datafile = 'test.json'
            self._pull()

    p = Provider()
    p._override_locale()
    if p.get_current_locale() != 'ru':
        raise ValueError('Method _override_locale of class BaseDataProvider not implemented correctly.')