

# Generated at 2022-06-12 01:35:59.596964
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check method override_locale."""
    class Obj(BaseDataProvider):

        _data_file = 'names.json'

    with Obj() as obj:
        origin_locale = obj.get_current_locale()
        assert origin_locale == locales.EN
        with obj.override_locale(locales.RU):
            assert obj.get_current_locale() == locales.RU
        assert obj.get_current_locale() == origin_locale

# Generated at 2022-06-12 01:36:08.088635
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyDataProvider(BaseDataProvider):
        data = {
            'en': {
                'some': {
                    'en': 'EN',
                    'ru': 'RU',
                }
            }
        }

        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(seed=seed)
            self._data = self.data

    my_provider = MyDataProvider()
    with my_provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

    assert my_provider.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:36:16.013923
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestData(BaseDataProvider):
        _datafile = 'test.json'

        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)

        def test_method(self):
            return 'foo'

    provider = TestData()
    with provider.override_locale('en') as f:
        assert f.test_method() == 'foo'
    assert provider.locale == 'en'

    provider = TestData()
    with provider.override_locale(locales.ES) as f:
        assert f.test_method() == 'bar'
    assert provider.locale == 'es'

# Generated at 2022-06-12 01:36:20.087297
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    reset_locale = locales.DEFAULT_LOCALE
    # Testing
    provider = BaseDataProvider()
    with provider.override_locale('fr'):
        assert provider.locale == 'fr'
    assert provider.locale == reset_locale



# Generated at 2022-06-12 01:36:25.426328
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale, data):
            super().__init__(locale, None)
            self._data = data
    data = {
        "en": {"a": "a", "b": "b"},
        "ru": {"a": "а", "b": "б"},
    }

    # should work
    with TestProvider('en', data) as provider:
        assert provider.get_current_locale() == 'en'
        with provider.override_locale('ru'):
            assert provider.get_current_locale() == 'ru'
            assert provider.get_a() == 'а'
            assert provider.get_b() == 'б'
        assert provider.get_current_locale() == 'en'
        assert provider.get_

# Generated at 2022-06-12 01:36:35.595160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.providers.processors import Processors
    from mimesis.providers.structures import Structures
    locale_list = locales.SUPPORTED_LOCALES[:-2]
    bd = BaseDataProvider(locale='en')
    with bd.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p._pull.cache_info().hits == 1
    assert bd.get

# Generated at 2022-06-12 01:36:41.364174
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    bdp = BaseDataProvider() # type: BaseDataProvider
    with bdp.override_locale('ru') as test_provider:
        locale = test_provider.locale
        assert locale == 'ru'

# Generated at 2022-06-12 01:36:51.495199
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def test_method(self):
            return self.get_current_locale()

    seed = 123456789

    t = TestProvider()
    assert t.test_method() == locales.DEFAULT_LOCALE
    t = TestProvider(seed=seed)
    assert t.test_method() == locales.DEFAULT_LOCALE
    t = TestProvider(locale='ru')
    assert t.test_method() == 'ru'
    t = TestProvider(locale='ru', seed=seed)
    assert t.test_method() == 'ru'
    with t.override_locale('en'):
        assert t.test_method() == 'en'

# Generated at 2022-06-12 01:36:57.965480
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.gender() in Gender.enums
    p = Address('ru')
    with p.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.region(abbr=True) in p._data.get('regions_abbr')
        assert p.region(abbr=False) in p._data.get('regions')

# Generated at 2022-06-12 01:37:07.538284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Dummy(BaseDataProvider):

        def get_random_int(self) -> int:
            return self.random.random_int(0, 10)

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = Dummy()
    print(provider.get_random_int())

    with provider.override_locale(locale="en"):
        print(provider.get_data())

    with provider.override_locale(locale="en-US"):
        print(provider.get_data())
        print(provider.get_random_int())



# Generated at 2022-06-12 01:37:25.769907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.misc import Misc
    address = Address()
    misc = Misc()
    a = set()
    with address.override_locale(locales.DE):
        for _ in range(5):
            a.add(address.country())
    b = set()
    with misc.override_locale(locales.RU):
        for _ in range(5):
            b.add(misc.amount())
    assert len(a) == 1
    assert len(b) == 1

# Generated at 2022-06-12 01:37:29.792844
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.bindings import Person
    from mimesis.enums import Gender
    language = 'fa'
    with Person('fa').override_locale('ru') as p:
        assert p.get_current_locale() == language
        assert p.gender(Gender.MALE) == 'мужчина'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:37:31.126423
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider()
    # dp.override_locale('en')

# Generated at 2022-06-12 01:37:33.600317
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale='ru'):
        assert provider.locale == 'ru'


# Generated at 2022-06-12 01:37:43.153959
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    from mimesis.providers.date import Date
    from mimesis.enums import DayOfWeek

    address = Address(seed=9)
    date = Date(seed=9)

    with address.override_locale('ru'):
        # some test
        assert address.country(alpha2=True) == Country.RUSSIA
        assert address.country() == 'Russia'
        assert address.city() == 'Хилок'

    with date.override_locale('ru'):
        # some test
        assert date.weekday(abbr=True) == DayOfWeek.MON.value
        assert date.weekday()

# Generated at 2022-06-12 01:37:47.161713
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseProvider().override_locale('en'):
            pass
    except AttributeError:
        assert True
    except:
        assert False



if __name__ == '__main__':
    bdp = BaseDataProvider(locale='en')
    bdp._pull()
    print(bdp._data)

# Generated at 2022-06-12 01:37:53.735843
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale():
        assert provider.get_current_locale() == 'en'
        with provider.override_locale('ru'):
            assert provider.get_current_locale() == 'ru'
        assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:37:59.863374
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def _get_data(self, file: str = '') -> None:
            pass
    provider = DataProvider()
    assert provider.locale == locales.EN
    with provider.override_locale('en_US'):
        assert provider.locale == 'en_US'
        with provider.override_locale('pt_BR'):
            assert provider.locale == 'pt_BR'
        assert provider.locale == 'en_US'
    assert provider.locale == locales.EN
test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:38:09.370989
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale() as p:
        assert p.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

    with provider.override_locale('ne') as p:
        assert p.get_current_locale() == 'ne'

    with provider.override_locale('ru-RU') as p:
        assert p.get_current_locale() == 'ru-RU'

    with provider.override_locale('en-US') as p:
        assert p.get_current_locale() == 'en-US'


# Generated at 2022-06-12 01:38:19.498973
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider `override_locale` method.

    There might be two main options:
        - We pass a locale and we must get the same locale,
        - We pass None and we must get DEFAULT_LOCALE.
    """
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
    provider = Provider('ru')
    assert provider.get_current_locale() == 'ru'
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale(None):
        assert provider.get_current_locale() == local

# Generated at 2022-06-12 01:38:34.735356
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def test(self) -> str:
            return self.get_current_locale()

    provider = MyProvider()
    assert provider.test() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.ES) as provider:
        assert provider.test() == locales.ES

    assert provider.test() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:38:45.495352
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    address = Address(locale='ru')
    address.random.seed(0)

    with address.override_locale('ru') as a:
        assert a.locale == 'ru'
        a.random.seed(0)
        assert a.address.city() == 'Санкт-Петербург'
        assert a.address.region() == 'Костромская область'
        assert a.address.region().lower() == 'костромская область'

    with address.override_locale('by') as a:
        assert a.locale == 'by'

# Generated at 2022-06-12 01:38:53.804895
# Unit test for method override_locale of class BaseDataProvider

# Generated at 2022-06-12 01:39:04.901737
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super(DummyProvider, self).__init__(*args, **kwargs)

    provider = DummyProvider()
    new_locale = locales.EN

    def get_locale(provider):
        return provider.locale

    original_locale = get_locale(provider)

    with provider.override_locale(new_locale):
        locale = get_locale(provider)

    assert locale == new_locale
    assert original_locale == get_locale(provider)

    # Must raise an exception
    with provider.override_locale(new_locale) as p:
        p.locale = new_locale

# Generated at 2022-06-12 01:39:10.237567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for context manager.

    Context manager which allows overriding current locale."""
    class OverrideLocale(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize instance.

            :param locale: Current locale. Default locale is `en`.
            :param seed: Seed to all the random functions.
            """
            self.locale = locale
            self.origin_locale = locale
            self.locale1 = 'ru_ru'

        def get_current_locale(self) -> str:
            return self.locale

    prv = OverrideLocale()
    with prv.override_locale(prv.locale1):
        assert prv.get_current_locale() == prv

# Generated at 2022-06-12 01:39:12.920257
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'



# Generated at 2022-06-12 01:39:19.889872
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Foo(BaseDataProvider):

        def get_data(self):
            return self.random.choice(self._data['foo'])

    f = Foo()
    with f.override_locale(locales.EN_US) as foo:
        assert foo.get_data() == 'bar'
        assert foo.get_current_locale() == locales.EN_US
    assert f.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:39:26.966719
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):

        def __init__(self):
            super().__init__(locale='en-US')

    testprovider = TestDataProvider()
    assert testprovider.get_current_locale() == 'en-US'

    with testprovider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

    assert testprovider.get_current_locale() == 'en-US'

# Generated at 2022-06-12 01:39:36.854059
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import UnitedStatesSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Enum

    class TestDataProvider(BaseDataProvider):
        pass

    class TestProvider(BaseProvider):
        pass

    provider = TestDataProvider()
    try:
        with provider.override_locale('de'):
            assert provider.locale == 'de'
    except ValueError:
        assert True

    provider = TestProvider()
    with provider.override_locale('en'):
        assert provider.locale is None

    us_provider = UnitedStatesSpecProvider()
    gender = Gender.FEMALE

    with us_provider.override_locale('en'):
        gender_en = gender.value


# Generated at 2022-06-12 01:39:46.039473
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as ru_provider:
        assert ru_provider.get_current_locale() == 'ru'
        with ru_provider.override_locale('zh') as zh_provider:
            assert zh_provider.get_current_locale() == 'zh'
        assert ru_provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:40:15.892669
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def _test(data_provider):
        with data_provider.override_locale(locales.RU):
            assert data_provider.get_current_locale() == locales.RU
        assert data_provider.get_current_locale() != locales.RU

    from mimesis.enums import CardBrand, Currency, Gender
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payments import Payments
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    cbp = Payments(locale=locales.RU)
    cbn = Numbers(locale=locales.RU)
    cbp.as_currency = Currency.RUBLE

# Generated at 2022-06-12 01:40:26.420593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    provider = Internet()
    provider.locale = 'en'
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
    assert provider.locale == 'en'

    provider = Internet(locale = 'ru')
    with provider.override_locale('en') as p:
        assert p.locale == 'en'
    assert provider.locale == 'ru'

    provider = Person()
    provider.locale = 'en'
    with provider.override_locale('ru') as p:
        assert p.locale

# Generated at 2022-06-12 01:40:33.454342
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)
            self._data_file = 'test_data.json'
            self._pull()

        def foo(self):
            return self._data

    provider = DataProvider()
    assert provider.foo() == {"bar": "baz"}
    with provider.override_locale(locales.RU):
        assert provider.foo() == {"bar": "baz_ru"}



# Generated at 2022-06-12 01:40:42.893014
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Science, ScienceSpecifier
    from mimesis.enums import ScienceLocale
    from mimesis.providers.science import ScienceProvider

    en_provider = Science(seed=42)

    provider = ScienceProvider(locale=ScienceLocale.EN, seed=42)

    assert en_provider.override_locale(ScienceLocale.EN) == provider

    with en_provider.override_locale(ScienceLocale.EN) as p:
        assert p == provider

    assert en_provider.get_current_locale() == locales.DEFAULT_LOCALE

    with en_provider.override_locale(ScienceLocale.RU) as p:
        assert p.get_current_locale() == ScienceLocale.RU.value

    assert en_prov

# Generated at 2022-06-12 01:40:49.726823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def __init__(self, seed: Seed = None, locale: str = locales.EN):
            super().__init__(seed=seed, locale=locale)

    provider = MyProvider()

    with provider.override_locale() as locale_provider:
        locale_provider == provider
        locale_provider.get_current_locale() == locales.EN

    provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:40:59.456358
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.
            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale, seed)
            self._setup_locale(locale)

        @property
        def __locale__(self) -> str:
            return self.get_current_locale()

    provider = TestProvider()

    with provider.override_locale(locales.RU):
        assert provider.__locale__ == locales.RU
    assert provider.__locale__ == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:41:06.916902
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self) -> None:
            locale = locales.EN
            super().__init__(locale=locale)

        def _pull(self) -> None:
            pass

        def get_current_locale(self):
            return super().get_current_locale()

    provider = TestProvider()

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:41:15.243600
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    def _open_file_in_dir(dir_name: str, file_name: str) -> str:
        """Open file in folder.

        :param dir_name: The name of folder.
        :param file_name: The name of file.
        :return: The content of file.
        """
        with open(
                str(Path(__file__).parent.parent.joinpath('data', dir_name,
                                                          file_name)),
                'r',
                encoding='utf8') as f:
            return json.load(f)

    provider = BaseDataProvider(locale='en')
    provider._datafile = 'lorem.json'
    provider._pull()
    data_en = provider._data

# Generated at 2022-06-12 01:41:22.042576
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def _validate_enum(self, item, enum):
            return item
        def get_current_locale(self):
            return self.locale

    provider = TestProvider('ru')
    with TestProvider.override_locale(provider, 'ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_current_locale() == provider.locale

    assert provider.get_current_locale() != provider.locale

# Generated at 2022-06-12 01:41:33.474314
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN):
            super().__init__(locale)
            self._datafile = 'lol.json'

        def __str__(self) -> str:
            return '{} <{}>'.format(self.__class__.__name__, self.locale)

        def test_method(self) -> str:
            return self.locale

    tp = TestProvider()
    with tp.override_locale(locales.RU) as instance:
        assert isinstance(instance, TestProvider)
        assert instance.locale != tp.locale
        assert instance.test_method() == locales.RU
        assert instance.locale == tp.locale

# Generated at 2022-06-12 01:42:21.646936
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    bdp = BaseDataProvider()
    with bdp.override_locale('en'):
        assert bdp.get_current_locale() == 'en'

    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:42:25.505833
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    provider = BaseDataProvider()

    with provider.override_locale(locale) as new_provider:
        assert new_provider.get_current_locale() == locale

    assert provider.get_current_locale() != locale

# Generated at 2022-06-12 01:42:31.382453
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert not hasattr(provider, 'override_locale')
    provider = BaseDataProvider('en')
    assert hasattr(provider, 'override_locale')
    with provider.override_locale('ru'):
        locale = provider.get_current_locale()
        assert locale == 'ru'
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('de'):
        locale = provider.get_current_locale()
        assert locale == 'de'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:42:35.629865
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        pass
    data_provider = DataProvider()
    with data_provider.override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN
    assert data_provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:40.769115
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that context manager works as expected."""
    from mimesis.builtins import Address
    default_locale = Address.Meta.locale
    assert default_locale == locales.EN

    with Address().override_locale(locales.RU) as addr:
        assert addr.locale == locales.RU
        assert addr.province() != Address().province()

    assert Address.Meta.locale == default_locale

# Generated at 2022-06-12 01:42:50.372272
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.personal import Personal

    p = Personal(lang='en')
    assert p.name() == 'Jessica Clark'

    with p.override_locale('ru'):
        assert p.name(gender=Gender.FEMALE) == 'Лиана'

    with p.override_locale('en'):
        assert p.name(gender=Gender.FEMALE) == 'Jessica Clark'

    address = Address(lang='ru')
    with address.override_locale('en'):
        assert address.address() == '3467 Cheyenne Avenue'


# Generated at 2022-06-12 01:42:54.239946
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    with type(BaseDataProvider)().override_locale(locale) as p:
        assert p.get_current_locale() == locale
    #assert p.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:43:03.184951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN, seed: int = None):
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self):
            return super().get_current_locale()

    assert TestProvider(locale=locales.EN).get_current_locale() == locales.EN

    with TestProvider(locale=locales.UA) as provider:
        assert provider.get_current_locale() == locales.UA

    with TestProvider(locale=locales.UA) as provider:
        with TestProvider(locale=locales.DE) as provider:
            assert provider.get_current_locale() == locales.DE

# Generated at 2022-06-12 01:43:12.316674
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def test_locale(self):
            return self.get_current_locale()

    tdp = TestDataProvider(seed=12345)
    with tdp.override_locale('ru'):
        assert tdp.test_locale() == 'ru'
    assert tdp.test_locale() == locales.DEFAULT_LOCALE

    class TestDataProvider(BaseDataProvider):
        def test_locale(self):
            return self.get_current_locale()

    tdp = TestDataProvider(seed=12345)
    with tdp.override_locale():
        assert tdp.test_locale() == locales.DEFAULT_LOCALE
    assert tdp.test_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:43:20.831538
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method 'override_locale' of class BaseProvider."""
    from mimesis.builtins import Address

    en = Address(locale='en')
    ru = Address(locale='ru')

    # Test for valid results
    with en.override_locale('ru') as _:
        assert ru.get_current_locale() == 'ru'
    assert en.get_current_locale() == 'en'

    # Test for ValueError
    with en.override_locale('ru') as _:
        assert ru.get_current_locale() == 'ru'
    assert en.get_current_locale() == 'en'

# Generated at 2022-06-12 01:45:03.566771
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider's method override_locale."""
    test_locale = 'ru'
    ld = LocaleDependent(test_locale)
    res = ld.locale
    assert res == test_locale

    with ld.override_locale(locales.DEFAULT_LOCALE):
        assert ld.locale == locales.DEFAULT_LOCALE

    with ld.override_locale(locales.EN):
        assert ld.locale == locales.EN

    assert ld.locale == test_locale
    assert ld.get_current_locale() == test_locale



# Generated at 2022-06-12 01:45:08.458299
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en')
    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:45:18.685103
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender

    import pytest

    bp = BaseDataProvider('en')
    bp._datafile = 'personal.json'
    bp._pull()

    with pytest.raises(ValueError):
        with bp.override_locale('sb'):
            pass

    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

        def get_name(self, gender: Gender = Gender.MALE,
                     *args, **kwargs) -> str:
            return self._data['personal']['name'][gender.value]

    bp = TestProvider('en')
    bp._pull()
   

# Generated at 2022-06-12 01:45:21.793012
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    with BaseDataProvider().override_locale(locales.EN) as bdp:
        assert isinstance(bdp, BaseDataProvider)

# Generated at 2022-06-12 01:45:31.425008
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test data.

    Check override_locale of class BaseDataProvider
    """
    class TestBP(BaseDataProvider):
        """Test class."""
        _datafile = ''

    test_bp = TestBP()

    with pytest.raises(ValueError):
        with test_bp.override_locale(locales.EN):
            pass

    class LocaleProvider(BaseDataProvider):
        """Test class."""
        _datafile = ''

    locale_provider = LocaleProvider(locale=locales.EN)

    with locale_provider.override_locale(locales.RU):
        assert locale_provider.get_current_locale() == locales.RU

    assert locale_provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:45:37.976083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    # If a subclass has not attribute 'locale', then 'override_locale' raises
    # ValueError.
    with provider.override_locale(locales.EN) as provider:
        assert provider.locale == locales.EN

    # Creating a new instance with a locale, different from the default.
    provider = BaseDataProvider(locale=locales.RU)
    assert provider.locale == locales.RU

    # The 'override_locale' method returns a provider with a new locale.
    with provider.override_locale(locales.EN) as provider:
        assert provider.locale == locales.EN

    # The 'override_locale' context manager has preserved the previous locale.
    assert provider.locale == locales.RU


# Unit

# Generated at 2022-06-12 01:45:42.062112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """This is unit test for method override_locale of class BaseDataProvider."""
    def test_override_locale(self):
        """Test override_locale method."""
        pass

    prov = BaseDataProvider()
    prov.override_locale('ru')
    test_override_locale(prov)