

# Generated at 2022-06-12 01:36:03.812240
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unittest for method override_locale."""
    try:
        with BaseDataProvider().override_locale():
            pass
    except ValueError as exc:
        assert 'has not locale dependent' in str(exc)

# Generated at 2022-06-12 01:36:07.096562
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale='ru') as p:
        assert p.get_current_locale() == 'ru'



# Generated at 2022-06-12 01:36:15.899909
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestBaseDataProvider(BaseDataProvider):
        """Test class which allow to test method `_override_locale`
        of class `BaseDataProvider`.
        """
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.locale_is_override: bool = False

        def _override_locale(self, locale: str = locales.DEFAULT_LOCALE):
            self.locale_is_override = True
            super()._override_locale(locale)

        def _pull(self):
            self.data_is_pulled = True
            super()._pull()


# Generated at 2022-06-12 01:36:26.284081
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method :meth:`override_locale` of class :class:`BaseDataProvider`.

    :return: Nothing.
    """
    import mimesis.enums as enums
    import mimesis.providers.currency as currency

    provider = currency.Currency(seed=42)
    with provider.override_locale(locale=enums.Language.RUSSIAN) as p:
        russian_currency = p.currency()  #: RUB
        assert russian_currency == 'RUB'

    default_currency = provider.currency()  #: USD
    assert default_currency == 'USD'

    with provider.override_locale(locale=enums.Language.GREEK) as p:
        greek_currency = p.currency()  #: EUR
        assert greek

# Generated at 2022-06-12 01:36:35.709972
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, seed: Seed = None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test_for_override_locale.json'
            self._pull()

        def get_setting(self, key: str) -> Any:
            return self._data[key]['value']

    t = Test(locale='ru')

    assert t.get_setting("lang") == "ru"

    with t.override_locale(locale="en"):
        assert t.get_setting("lang") == "en"

    assert t.get_setting("lang") == "ru"

# Generated at 2022-06-12 01:36:47.560214
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.locales import RU, EN

    class Example(BaseDataProvider):
        """Example for BaseDataProvider."""

        def __init__(self, locale: str) -> None:
            """Initialize object.

            :param locale: Locale.
            """
            super().__init__(locale=locale)

        def get_current_locale(self) -> str:
            """Get current locale.

            :return: Current locale.
            """
            return self.locale

    example = Example(locale=EN)
    assert example.get_current_locale() == EN
    assert str(example) == 'Example <en>'


# Generated at 2022-06-12 01:36:50.558134
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test overriding locale."""
    from mimesis.builtins import Person

    with Person().override_locale('ru') as ru_person:
        ru_person.name(gender='male')



# Generated at 2022-06-12 01:36:57.560777
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Setup
    b = BaseDataProvider()
    b._pull = lambda filename: None
    b._pull.cache_clear = lambda: None
    b.locale = 'en-US'
    # Exercise
    with b.override_locale():
        result = b.locale
    # Verify
    assert result == 'en-US'
    # Cleanup - hidden

# Generated at 2022-06-12 01:37:08.479165
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method context manager override_locale.
    """
    class TestProvider(BaseDataProvider):
        """Test Provider for test unit method override_locale."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._data: JSON = {}
            self._datafile = 'people.json'
            self.name = ''

    with TestProvider() as provider:
        provider.name = provider.get_current_locale()
        assert provider.name == provider.get_current_locale()

# Generated at 2022-06-12 01:37:14.334330
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis import Person, Address

    provider = Person(seed=10)
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
    assert provider.locale == 'en'

    provider = Address(seed=10)
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
    assert provider.locale == 'en'

# Generated at 2022-06-12 01:37:28.608162
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Localization

    l = Localization()
    with l.override_locale('ru'):
        assert l.get_current_locale() == 'ru'
    assert l.get_current_locale() == 'en'

    l = Localization('ru')
    with l.override_locale('en'):
        assert l.get_current_locale() == 'en'
    assert l.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:37:30.723243
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass
    with contextlib.suppress(ValueError):
        with TestProvider() as tp:
            pass

# Generated at 2022-06-12 01:37:35.733131
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    # initialize address class
    address = Address(locale='es')
    # generate random address from first locale
    random_address1 = address.address()
    # generate random address from another locale
    with address.override_locale('ru'):
        random_address2 = address.address()
    assert random_address1 != random_address2

# Generated at 2022-06-12 01:37:41.425228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def base_provider_override_locale(locale: str) -> Mapping:
        provider = BaseDataProvider(seed=0)

        with provider.override_locale(locale):
            data = provider.get_current_locale()
        return data

    results = list(map(base_provider_override_locale,['en', 'zh']))
    expected = ['zh', 'zh']

    assert results == expected


# Generated at 2022-06-12 01:37:48.310172
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class EnglishProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)
            self._datafile = 'currency.json'

        def get_currency(self, code=None):
            return self.random.choice(
                list(self._pull().keys()),
                code
            )

    provider = EnglishProvider()

    # check that the method overrides locale
    assert provider.get_currency()
    with provider.override_locale('ru'):
        assert provider.get_currency()
    assert provider.get_currency()

    # check ValueError if locale is not locale-dependent
    class LatinProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()
            self._datafile = 'latin.json'

# Generated at 2022-06-12 01:37:55.318073
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        _datafile = 'test_data.json'
        def get_data(self):
            return self._data['test']
    dp = TestDataProvider()
    assert dp._data == {}
    with dp.override_locale(locale='en') as dp:
        dp._pull()
        assert dp._data['test'] == 'data_en'
    assert dp._data == {}

# Generated at 2022-06-12 01:38:05.552422
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # BaseDataProvider instance for testing
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            self._data = {}
            self._datafile = ''
        
        def get_current_locale(self):
            return self.locale
    
        def _pull(self, datafile):
            return None
        
        def _setup_locale(self, locale):
            return None
    
    # test instance
    provider = TestBaseDataProvider()
    
    # test incorrect provider
    with pytest.raises(ValueError):
        with provider.override_locale(locales.EN):
            pass

# Generated at 2022-06-12 01:38:16.891249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from ..registry import Registry
    from ..registry import registry as REGISTRY
    from ..providers import Address, Address as BaseAddress
    from ..providers import Identifier
    from ..providers import Person

    class Address(Address):
        """Address."""

        class Meta(BaseAddress.Meta):
            """The meta-class for Address."""

            name = 'address'

            class Providers(BaseAddress.Meta.Providers):
                """Providers."""

                address = BaseAddress

    def addresses(provider: Identifier, local: str) -> str:
        """Get addresses of provider."""
        with provider.override_locale(locale=local):
            return provider.address().address()

    provider = Person()

# Generated at 2022-06-12 01:38:21.370620
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale"""
    locale = locales.EN
    provider = BaseDataProvider(locale)
    with provider.override_locale(locale) as override_provider:
        assert override_provider.locale == locale

# Generated at 2022-06-12 01:38:24.463792
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale, seed)

    tp = TestProvider()
    with tp.override_locale(locales.EN):
        assert tp.locale == locales.EN

    with tp.override_locale('ru'):
        assert tp.locale == 'ru'



# Generated at 2022-06-12 01:38:44.381583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  from mimesis.providers import Address, Science

  def _test_func(obj, locale):
      with obj.override_locale(locale) as _obj:
          assert _obj.get_current_locale() == locale

  # Subclass of BaseDataProvider
  object_1 = Address()
  object_2 = Science()
  object_3 = object_2
  try:
      # Testing exceptions
      object_1.override_locale('ru')
  except ValueError as e:
      assert str(e) == '«Address» has not locale dependent'
  else:
      raise AssertionError

  # Unit test for method override_locale()
  for obj in (object_2, object_3):
    _test_func(obj, 'ru')

# Generated at 2022-06-12 01:38:52.751786
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestLocale(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale
    class TestData(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale
    test_locale = TestLocale()
    test_data = TestData()
    with test_locale.override_locale(locales.JA) as data:
        assert data.locale == locales.JA
        assert data.get_current_locale() == locales.JA
    with test_data.override_locale(locales.DE) as data:
        assert data.locale == locales.DE
        assert data.get_current_locale() == locales.DE


# Generated at 2022-06-12 01:39:00.980238
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass
    provider = TestProvider()
    with provider.override_locale() as prov:
        assert isinstance(prov, TestProvider)
    with provider.override_locale(locales.EN) as prov:
        assert prov.get_current_locale() == locales.EN
    # with provider.override_locale(locale='en'):
    #     assert provider.locale == locales.EN
    # assert provider.locale == locales.get_default_locale()

# Generated at 2022-06-12 01:39:03.362917
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    en_datetime = Datetime(locale='en')
    with en_datetime.override_locale('ru') as rus_datetime:
        assert rus_datetime is not None

# Generated at 2022-06-12 01:39:08.540383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    try:
        with provider.override_locale() as overridden_provider:
            assert provider is overridden_provider
    except ValueError:
        assert True
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)
    else:
        assert False, "ExpectedException not raised"


# Generated at 2022-06-12 01:39:19.403419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import random
    import re
    from mimesis.providers import Address, Address as EnAddress
    from mimesis.providers import Basic, Basic as EnBasic
    from mimesis.providers import Code, Code as EnCode
    from mimesis.providers import CC, CC as EnCC
    from mimesis.providers import Person, Person as EnPerson
    from mimesis.providers import Science, Science as EnScience
    from mimesis.providers import Business, Business as EnBusiness
    from mimesis.providers import Food, Food as EnFood
    from mimesis.providers import Payment, Payment as EnPayment
    from mimesis.providers import Datetime, Datetime as EnDatetime
    from mimesis.providers import Internet, Internet as EnInternet

# Generated at 2022-06-12 01:39:30.871000
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    random_ = Random()

    class TestSubclass(BaseDataProvider):
        def __init__(self, locale: str = 'en', seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'hello.json'
            self._pull()

        def hello(self) -> str:
            return random_.choice(list(self._data.keys()))


    # First, let's create our subclass
    subclass1 = TestSubclass('en_US')

    # Then, let's test the name of the subclass in the default locale
    assert subclass1.hello() == 'hello'

    # Next, let's override the locale and test the name of the subclass in the
    # new locale

# Generated at 2022-06-12 01:39:37.338959
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    custom_provider = BaseDataProvider()
    custom_provider.locale = 'some_locale'  # TypeError: can't set attribute
    with custom_provider.override_locale('some_locale'):
        assert custom_provider.locale == 'some_locale'

    custom_provider.locale = 'ru'  # AttributeError: 'BaseDataProvider' object has no attribute 'locale'
    with custom_provider.override_locale('ru'):
        assert custom_provider.locale == 'ru'


# Generated at 2022-06-12 01:39:45.920134
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_1: BaseDataProvider = BaseDataProvider(locale=locales.RU)
    provider_2: BaseDataProvider = BaseDataProvider(locale=locales.EN)
    with provider_1.override_locale(locales.EN) as provider:
        assert provider is provider_1
    assert provider_1.locale == locales.RU
    with provider_2.override_locale(locales.RU) as provider:
        assert provider is provider_2
    assert provider_2.locale == locales.EN

# Generated at 2022-06-12 01:39:46.405371
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-12 01:40:09.231206
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestBaseDataProvider(BaseDataProvider):
        def test(self):
            return 'locale: %s' % self.locale

    provider = TestBaseDataProvider('ru')
    with provider.override_locale('en'):
        assert provider.test() == 'locale: en'
    assert provider.test() == 'locale: ru'

# Generated at 2022-06-12 01:40:15.323832
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    with Person(locale='ru').override_locale() as p:
        assert p._datafile == 'person.json'
        assert p.locale == 'en'
        assert p.get_current_locale() == 'en'
        assert isinstance(p._pull(), dict)
test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:40:21.243099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Cryptographic
    from mimesis.typing import JSON
    from mimesis.enums import CardinalDirection
    from mimesis.enums import Language
    import mimesis.random
    import mimesis
    import math
    from pathlib import Path
    from mimesis.enums import Gender
    from mimesis.providers import Cryptographic
    from mimesis.typing import JSON
    from mimesis.enums import CardinalDirection
    from mimesis.enums import Language
    import mimesis.random
    import mimesis
    import math
    import pytest
    # @mimesis.override_locale(locale='en')

# Generated at 2022-06-12 01:40:26.495455
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method `override_locale` of class BaseDataProvider."""
    provider = BaseDataProvider()

    with provider.override_locale() as _provider:
        assert _provider.get_current_locale() == locales.EN

    
    with provider.override_locale(locales.RU) as _provider:
        assert _provider.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:40:29.761769
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass
    provider = Provider()
    with provider.override_locale(locales.RU):
        locale = provider.get_current_locale()
    assert locale == locales.RU

# Generated at 2022-06-12 01:40:40.736688
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from . import Person
    from . import Address
    person = Person(seed=123)
    address = Address()
    person.seed = 123
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Денис Антонов'
    assert person.full_name() == 'Landon Cervantes'
    with person.override_locale('ru'):
        assert person.full_name() == 'Денис Антонов'
    assert person.full_name() == 'Landon Cervantes'

# Generated at 2022-06-12 01:40:50.637846
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider.

    The method is a context manager.
    """

    # Check that the method without arguments works properly.
    # The data in the class Person should be set by the default locale
    # after leaving the context with the release of the method.
    # If the locale is not defined in the class, an exception is thrown.
    class Person(BaseDataProvider):
        def __init__(self, seed=None):
            self.locale = ""
            super().__init__(seed=seed)

    with Person() as person:
        with person.override_locale():
            assert person.locale == 'en'
        assert person.locale == ''

    # Check that the method overrides the locale when passing it.
    # If we pass the locale, the method should override it.


# Generated at 2022-06-12 01:40:56.782916
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    person1 = Person(locale='es')
    assert person1.locale == 'es'
    person1.locale = 'en'
    assert person1.locale == 'en'
    with person1.override_locale('es'):
        assert person1.locale == 'es'
    assert person1.locale == 'en'

# Generated at 2022-06-12 01:41:03.580749
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_base_provider_override_locale():
        provider = BaseProvider()
        with provider.override_locale('en') as provider_with_overridden_locale:
            assert provider_with_overridden_locale.get_current_locale() == 'en'
            assert provider.get_current_locale() == 'en'
        assert provider.get_current_locale() == None
        assert provider_with_overridden_locale.get_current_locale() == None
    test_base_provider_override_locale()

# Generated at 2022-06-12 01:41:07.075281
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:46.581058
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the method ``override_locale``."""
    class SomeDependentProvider(BaseDataProvider):
        locale = 'en'

        def get_data(self) -> str:
            return self.locale

    user = SomeDependentProvider()  # en
    with user.override_locale('ru'):
        assert user.get_data() == 'ru'

    assert user.get_data() == 'en'



# Generated at 2022-06-12 01:41:55.513669
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test context manager which allows overriding current locale."""
    from mimesis.builtins import Person

    p = Person()
    assert p.locale == locales.EN
    assert p.full_name() == 'Jose Miller'

    with p.override_locale(locale=locales.RU):
        assert p.locale == locales.RU
        assert p.full_name() == 'Александр Буйнаков'

    assert p.locale == locales.EN
    assert p.full_name() == 'Jose Miller'

# Unit tests for method reseed of class BaseProvider

# Generated at 2022-06-12 01:42:01.621232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Personal
    person = Personal('en')
    person_ru = Personal('ru')
    name_ru = person_ru.name()
    with person.override_locale('ru') as person_ru:
        assert person_ru.get_current_locale() == 'ru'
        assert person_ru.name() == name_ru

# Generated at 2022-06-12 01:42:03.753908
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    bdp = BaseDataProvider()
    with bdp.override_locale('ru'):
        pass


# Generated at 2022-06-12 01:42:07.631778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import RussiaSpecProvider
    russian = RussiaSpecProvider()
    with russian.override_locale('ru') as obj:
        assert obj.get_current_locale() == 'ru'
        assert str(obj) == 'RussiaSpecProvider <ru>'

# Generated at 2022-06-12 01:42:13.979146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def random_item(self, sequence, chance=None):
            return get_random_item(sequence, self.random)

    provider = Provider()
    assert provider.random_item([1, 2, 3]) in [1, 2, 3]
    with provider.override_locale('uk'):
        assert provider.random_item([1, 2, 3]) in [1, 2, 3]
    assert provider.random_item([1, 2, 3]) in [1, 2, 3]

# Generated at 2022-06-12 01:42:24.302183
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    class CustomPerson(Person):
        """Uses person data from providers.person."""

        class Meta:
            """Define locale and data_format."""

            locale = locales.RU
            data_format = '{gender}_{first_name}_{last_name}_{patronymic}'

    person = CustomPerson(seed=42)

    with person.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert person.get_current_locale() == locales.RU


# Generated at 2022-06-12 01:42:28.945078
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialization of BaseDataProvider and get the country
    BaseDataProvider(locale='en')

    with override_locale(locale='fr'):
        # Check if locale is equals to ru
        assert self.locale == locales.FR
        assert self._datafile == 'data.json'
    # Check if locale is equals to ru
    assert self.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:32.837132
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        with BaseDataProvider().override_locale():
            pass
    except ValueError:
        return
    raise AssertionError('ValueError did not raised')



# Generated at 2022-06-12 01:42:36.921941
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    rng = Random()
    bdp = BaseDataProvider(locale='en', seed=rng.seed())
    with bdp.override_locale('ru') as provider:
        assert provider.locale == 'ru'
    assert bdp.locale == 'en'


# Generated at 2022-06-12 01:44:10.230390
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import BaseDataProvider

    class DummyProvider(BaseDataProvider):
        _datafile = 'dummy_data.json'
        _codename = 'dummy'

    data = {'foo': 'bar', 'qux': 'baz'}

    dummy = DummyProvider()
    dummy._data = data

    with dummy.override_locale('en') as d:
        assert d._data == data

    # Change locale
    dummy._override_locale('ru')
    assert dummy._data != data



# Generated at 2022-06-12 01:44:19.357674
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    try:
        with BaseDataProvider().override_locale(locales.EN):
            pass
    except ValueError:
        pass
    else:
        raise AssertionError('Must raise ValueError')

    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self) -> None:
            """Initialize attributes."""
            self.locale = locales.DEFAULT_LOCALE
            self._data = {
                locales.DEFAULT_LOCALE: [1, 2],
                locales.EN: [1, 2, 3],
                locales.RU: [1, 2, 3, 4],
                locales.JA: [1, 2, 3, 4, 5],
            }


# Generated at 2022-06-12 01:44:22.216627
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider._override_locale()."""
    name = BaseDataProvider()
    with name.override_locale():
        assert name.get_current_locale() == 'en'


# Generated at 2022-06-12 01:44:27.766540
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Sample(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)
            self._datafile = 'sample.json'

    s = Sample()
    with s.override_locale(locales.RU):
        assert s.get_current_locale() == 'ru'
    assert s.get_current_locale() == 'en'

# Generated at 2022-06-12 01:44:33.399809
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FakeDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)

        def special_method(self) -> Any:
            return self.locale

    data = FakeDataProvider()

    assert data.special_method() == locales.DEFAULT_LOCALE

    with data.override_locale('ru'):
        assert data.special_method() == 'ru'
        pass

    assert data.special_method() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:44:37.760709
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method 'override_locale' of class 'BaseDataProvider'."""
    class DataProvider(BaseDataProvider):

        def test_method(self):
            return "test"

    provider = DataProvider()
    with provider.override_locale('ru') as data_provider:
        assert data_provider is provider
        assert data_provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() != 'ru'

# Generated at 2022-06-12 01:44:40.247482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ Unit test for method override_locale of class BaseDataProvider. """
    from mimesis.builtins import Person
    from mimesis.builtins import address

    person = Person()
    address = address()

    assert person.full_name() != address.full_name()
    with address.override_locale():
        assert person.full_name() == address.full_name()

# Generated at 2022-06-12 01:44:47.002378
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create the object of class BaseDataProvider
    bdp = BaseDataProvider()

    # Create the context manager
    with bdp.override_locale('de'):

        # Check that locale is changed
        assert bdp._data['czechoslovakia'] == 'Tschechoslowakei'

    # Check that locale is not changed
    assert bdp._data['czechoslovakia'] == 'Československo'

# Generated at 2022-06-12 01:44:50.633239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider._data == {}


# Generated at 2022-06-12 01:44:53.816711
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        from mimesis import Codec
        from mimesis.enums import CodecName
        t = Codec(locale='en')
        with t.override_locale('ru'):
            assert t.codec.codec == CodecName.HEX
    except ImportError:
        pass