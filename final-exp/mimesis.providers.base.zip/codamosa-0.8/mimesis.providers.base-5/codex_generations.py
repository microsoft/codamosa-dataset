

# Generated at 2022-06-12 01:36:08.917548
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Animal

    class AnimalWithLocale(Animal):

        def __init__(self, locale: str = locales.EN) -> None:
            super().__init__(locale=locale)

        def name(self) -> str:
            """Return the name of a random animal.

            :return: A random name of an animal.
            """
            return get_random_item(self._data['animals'], self.random)

    animal = AnimalWithLocale()
    with animal.override_locale(locale=locales.RU) as a:
        assert animal is a
        assert animal.name() == 'барсук'

    assert animal.name() == 'dog'

# Generated at 2022-06-12 01:36:16.705324
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.providers import Address, CreditCard, Person

    address = Address(locale='en')
    address.get_province()
    assert address.locale == 'en'
    with address.override_locale('ru'):
        address.get_province()
        assert address.locale == 'ru'
        with address.override_locale('en') as address_en:
            assert address_en.locale == 'en'
        assert address.locale == 'ru'
    assert address.locale == 'en'

    cc = CreditCard(locale='en')
    cc.get_issuer()
    assert cc.locale == 'en'

# Generated at 2022-06-12 01:36:27.241396
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers import Address, Person
    from mimesis.providers.person import Gender
    from mimesis.exceptions import NonEnumerableError

    a = Address()
    p = Person()

    with a.override_locale():
        assert a.get_current_locale() == locales.EN

    with p.override_locale():
        assert p.get_current_locale() == locales.EN
        assert type(p._validate_enum(p.GENDER.MALE, Gender)) == str
        assert p._validate_enum(
            p.GENDER.RATHER_NOT_SAY, Gender) == Gender.RATHER_NOT_SAY.value


# Generated at 2022-06-12 01:36:36.847505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider.
    """
    class TheRandom(BaseDataProvider):
        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes.
            """
            super().__init__(seed=seed)
            self.locale = locales.EN

        @property
        def random(self) -> Random:
            """Return random.
            """
            return self._random

        def sample(self, size: int = 10, *args, **kwargs) -> list:
            """Return a list of random numbers.
            """
            return self.random.sample(*args, size=size, **kwargs)
    the_random = TheRandom(seed=42)
    numbers_1 = the_random.with_override_locale('ru').sample()

# Generated at 2022-06-12 01:36:48.735320
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    import random
    from mimesis.providers.files import PDF
    from mimesis.enums import Gender

    random.seed(1)
    file_path = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(file_path, '..', '..', 'data', 'ru_RU')
    pdf = PDF(data_dir=data_dir)
    
    assert pdf.locale == 'ru_ru' # localization is changed
    assert pdf.get_filename(gender=Gender.MALE, suffix='.pdf') == 'документ.pdf' # localization is changed
    
    with pdf.override_locale('en'):
        assert pdf.locale == 'en' # localization is changed
       

# Generated at 2022-06-12 01:36:52.829971
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Tests method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:37:01.783830
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    with provider.override_locale(locales.DEFAULT_LOCALE):
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.ES):
        assert provider.get_current_locale() == locales.ES

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:37:10.247610
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method 'override_locale'."""
    from mimesis.data import (
        en, ru, ukrainian, ua, ru_ua, ru_ukrainian, ru_ua_ukrainian,
    )

    BASE = BaseDataProvider(en)

    assert BASE.get_current_locale() == en

    with BASE.override_locale(ru) as ru_provider:
        assert ru_provider.get_current_locale() == ru

    with BASE.override_locale(ukrainian) as provider:
        assert provider.get_current_locale() == ukrainian

    with BASE.override_locale(ua) as provider:
        assert provider.get_current_locale() == ua


# Generated at 2022-06-12 01:37:15.072383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Business
    from mimesis.enums import Gender
    from mimesis import locales

    b = Business(locale=locales.EN)

    with b.override_locale(locale='ru'):
        assert b.gender(Gender.FEMALE) == 'Феминистка'

    assert b.gender(Gender.FEMALE) == 'Female'

# Generated at 2022-06-12 01:37:19.616048
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    loc = locales.LOCALE_SET.copy()
    prov = BaseDataProvider(loc[0])
    for l in loc:
        with prov.override_locale(l) as pr:
            assert pr.locale == l

# Generated at 2022-06-12 01:37:38.224012
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import (
        Address,
        Language,
        Lorem,
        Person,
        Professional,
        Science,
        UnitSystem,
        Weather,
    )
    from mimesis.enums import LanguageCode, UnitSystemCode

    seed = 'mimesis'

    lorem = Lorem(seed=seed)
    person = Person(seed=seed)
    address = Address(seed=seed)
    language = Language(seed=seed)
    professional = Professional(seed=seed)
    science = Science(seed=seed)
    unit_system = UnitSystem(seed=seed)
    weather = Weather(seed=seed)


# Generated at 2022-06-12 01:37:46.460078
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(seed=seed)

    provider = TestProvider()

    try:
        provider._override_locale()
    except AttributeError:
        assert True
    else:
        assert False

    try:
        with provider.override_locale() as p:
            raise AssertionError(
                '«{}» has not locale field'.format(
                    provider.__class__.__name__))
    except ValueError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 01:37:54.573770
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(locale='en', seed=seed)


    provider = TestProvider()
    assert provider.locale == 'en'

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    assert provider.locale == 'en'


# Generated at 2022-06-12 01:38:00.932399
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'person.json'
            self._pull()

        def first_name(self, *args, **kwargs):
            return self.random.choice(self._data.get('first_name', ''))

    provider = BaseProvider('ru')

    with provider.override_locale('en') as overridden:
        assert provider.locale == 'ru'
        assert overridden.locale == 'en'

    assert provider.locale == 'ru'



# Generated at 2022-06-12 01:38:09.807659
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method override_locale of class BaseDataProvider."""
    
    # if provider has not locale dependent
    def test_override_locale_provider_no_locale_dependent():
        """Unit test for method override_locale of class BaseDataProvider

            if provider has not locale dependent
        """

        class TestLocalesProvider(BaseDataProvider):
            """TestLocalesProvider"""

            def __init__(self):
                """Initialize attributes."""
                super().__init__()

            def foo(self):
                """foo."""
                return 'bar'

        tlp = TestLocalesProvider()
        with tlp.override_locale():
            pass


# Generated at 2022-06-12 01:38:12.276415
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert BaseDataProvider().override_locale('en').get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:22.373320
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.typing import Seed
    from mimesis.enums import Gender

    provider = Person()
    override_person = provider.override_locale('ru').__enter__()
    provider.seed = Seed(42)
    provider.random = Random()
    seed = Seed(42)
    random = Random()
    random.seed(seed)
    override_person.seed = Seed(42)
    override_person.random = Random()
    override_person.random.seed(seed)
    name_ru = override_person.name(gender=Gender.FEMALE)
    assert name_ru == 'Анастасия'

# Generated at 2022-06-12 01:38:33.718100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class LocalizedProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.locale = locale

        def get_current_locale(self) -> str:
            """Get current locale.

            If locale is not defined then this method will always return ``en``,
            because ``en`` is default locale for all providers, excluding builtins.

            :return: Current locale.
            """
            return self.locale

    provider = LocalizedProvider()
    with provider.override_locale(locales.DEFAULT_LOCALE):
        expected = locales.DEFAULT_LOCALE
        assert provider.get_current_locale() == expected
   

# Generated at 2022-06-12 01:38:44.382332
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.builtins import RussiaSpecProvider

    address = Address(seed=123456)
    address.seed = 123456

    with address.override_locale(locales.RU) as new_address:
        assert new_address.__class__.__name__ == 'Address'
        assert new_address.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:38:47.780164
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider."""

        pass
    provider = TestProvider('en')
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:39:01.284782
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider(locale='zh')

    assert provider.get_current_locale() == 'zh'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'zh'



# Generated at 2022-06-12 01:39:11.876949
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        _datafile = 'numbers.json'
        def _count_list_of_numbers(self):
            data = self._data
            a = 0
            for i in data:
                a += len(i)
            return a

    dp = DataProvider()
    dp._pull()
    dp._count_list_of_numbers()

    with dp.override_locale('ru') as dp_ru:
        assert dp.locale == 'en'
        assert dp_ru.locale == 'ru'
        assert dp_ru._count_list_of_numbers() == dp._count_list_of_numbers()

    assert dp.locale == 'en'

# Generated at 2022-06-12 01:39:21.393389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider class."""

        def __init__(self):
            """Initialize attributes."""
            super().__init__(locale='ru')
            self._datafile = 'currency.json'

        @property
        def currency(self) -> Dict[str, str]:
            """Return data."""
            return self._data

    # pylint: disable=invalid-name
    tp = TestProvider()
    assert tp.currency['RUB'] == 'Российский рубль'
    assert tp.currency['USD'] == 'Доллар США'

# Generated at 2022-06-12 01:39:25.805114
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    print(BaseDataProvider().override_locale('uk').__enter__().locale)
    assert BaseDataProvider().override_locale('uk').__enter__().locale == 'uk'

# Generated at 2022-06-12 01:39:35.931034
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Provider class with locale-dependent props
    class Provider(BaseDataProvider):
        def prop(self):
            return self.locale
    # Create a provider instance
    provider = Provider()
    # Check a initial locale
    assert provider.locale == locales.EN
    # Check 'override_locale' method with default locale
    with provider.override_locale() as p:
        assert p.locale == locales.EN
    # Check 'override_locale' method with given locale
    with provider.override_locale(locales.RU) as p:
        assert p.locale == locales.RU
    # Check the initial locale
    assert provider.locale == locales.EN
    # Check that 'override_locale' method wasn't changed instance
    assert provider.prop() == locales

# Generated at 2022-06-12 01:39:41.271006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Testing the method override_locale of class BaseDataProvider."""
    class UnitProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN):
            super().__init__(locale)

    test_provider = UnitProvider('en')

    assert test_provider.get_current_locale() == 'en'

    # Testing with ru locale
    with test_provider.override_locale('ru') as ru_provider:
        assert ru_provider.get_current_locale() == 'ru'

    assert ru_provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:39:51.969854
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.blockchain import Bitcoin
    from mimesis.providers.network import IP
    from mimesis.providers.person import Person
    from mimesis.typing import Code


    def get_person_full_name(person_provider: Person) -> str:
        return person_provider.full_name()


    def override_person_locale(
            person_provider: Person,
            code: Code,
    ) -> Generator[Person, None, str]:
        with person_provider.override_locale(code) as person:
            yield person
            return person.full_name()



# Generated at 2022-06-12 01:39:58.036440
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN):
            super().__init__(locale=locale)

    locale_ru = locales.RU

    provider_ru = TestProvider(locale=locale_ru)
    provider_en = TestProvider()
    with provider_en.override_locale(locale=locale_ru):
        assert provider_en.locale == provider_ru.locale
    assert provider_en.locale != provider_ru.locale

# Generated at 2022-06-12 01:40:01.842648
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.providers.numbers import Numbers

    locale = 'uk'

    with Numbers().override_locale(locale=locale) as num:
        assert num.locale == locale
        assert num.random.randint(1, 20)
        assert isinstance(num._data, dict)

    assert num.locale != locale



# Generated at 2022-06-12 01:40:07.185386
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Code
    from mimesis.enums import Gender
    from mimesis.typing import Locale
    provider = Code('en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data('code.python') == 'python'
    with provider.override_locale('ru') as code:
        assert code.get_current_locale() == 'ru'
        assert code.get_data('code.python') == 'python'
    assert provider.get_current_locale() == 'en'
    assert provider.get_data('code.python') == 'python'


# Generated at 2022-06-12 01:40:19.252614
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider()
    with p.override_locale('es') as provider:
        assert provider.get_current_locale() == 'es'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:40:26.717428
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def get_name(self):
            return self.__class__.__name__

        def get_locale(self):
            return self.locale

    provider = TestProvider()

    with provider.override_locale('ru') as locale_provider:
        assert locale_provider.get_name() == "TestProvider"
        assert locale_provider.get_locale() == "ru"

    assert provider.get_name() == "TestProvider"
    assert provider.get_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:40:38.439488
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .address import Address
    from .personal import Person

    ad = Address()
    pr = Person()

    with ad.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_current_locale() == 'ru'
        assert ad.get_current_locale() == 'ru'
        assert ad.locale == 'ru'

    with pr.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_current_locale() == 'ru'
        assert pr.get_current_locale() == 'ru'
        assert pr.locale == 'ru'

    with ad.override_locale('en') as provider:
        assert provider.locale == 'en'
        assert provider.get_

# Generated at 2022-06-12 01:40:48.202567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import (Address, Datetime, Personal,
                              Person, Seed, Text)
    from mimesis.enums import Gender, Locale
    from mimesis.providers.internet import Internet
    from mimesis.providers.payment import Payment
    from mimesis.providers.programming import Programming
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport

    class TestProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed)

        def get(self):
            return self._get_data('test')

    t = TestProvider(seed=Seed())
    assert t.get_current_locale() == Locale.DEFAULT

    assert t.get() == 'test'



# Generated at 2022-06-12 01:40:52.348841
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.en import US
    with US().override_locale('ru') as rus:
        assert getattr(rus, 'locale', None) == 'ru'
        assert rus._data.get('name').get('first_name').get('male')
    assert getattr(US(), 'locale', None) == 'en-us'

# Generated at 2022-06-12 01:40:59.535606
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.EN) -> None:
            super().__init__(locale=locale)

        def get_current_locale(self) -> str:
            return self.locale
    provider = Provider()
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:41:09.475885
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the BaseDataProvider's method override_locale."""
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers

    # Without locale
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    # With locale
    provider = BaseDataProvider(locale='uk')
    assert str(provider) == 'BaseDataProvider <uk>'

    # With known locale
    provider = Internet(locale='ru')
    assert provider.get_current_locale() == 'ru'

    # With default locale
    with provider.override_locale(locales.DEFAULT_LOCALE) as p:
        assert p.get_current_locale() == 'en'



# Generated at 2022-06-12 01:41:14.980486
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale, seed)
            self._datafile = 'test.json'

    provider = TestProvider(locales.DEFAULT_LOCALE)
    with provider.override_locale(locale=locales.RU) as new_provider:
        assert new_provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:41:24.878999
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as Person2

    person = Person(seed=0)
    person2 = Person2(locale='ru', seed=0)

# Generated at 2022-06-12 01:41:34.929825
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.currency import Currency
    from mimesis.providers.person import Person

    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

        @property
        def common_currency(self) -> str:
            return self.currency.code()

        @property
        def common_name(self) -> str:
            return self.person.full_name()

    class ProviderLocale(Currency, Person, BaseProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super

# Generated at 2022-06-12 01:42:06.985144
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale(): 
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.enums import Gender

    address = Address()
    person = Person()
    internet = Internet()

    address.provider.locale = 'ru'
    person.provider.locale = 'ru'
    internet.provider.locale = 'ru'

    print(address.country())
    print(person.name(gender=Gender.FEMALE))
    print(internet.email())

    with address.provider.override_locale('en'):
        print(address.country())

    with address.provider.override_locale('en') as addr_en:
        print(addr_en.country())


# Generated at 2022-06-12 01:42:10.556938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider()
    with provider.override_locale('ru-RU') as p:
        assert p.locale == 'ru-RU'

        assert provider.locale == 'ru-RU'
    assert provider.locale == 'ru-RU'

# Generated at 2022-06-12 01:42:14.461525
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        pass

    a = A()

    origin = a.locale
    with a.override_locale('ru'):
        override = a.locale
    assert override != origin
    assert a.locale == origin


# Generated at 2022-06-12 01:42:24.738346
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Personal

    class TestProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'personal.json'
            self._pull()

        def full_name(self) -> str:
            """Return a full name.

            :return: Full name.
            """
            names = self._data['names']
            first_name = get_random_item(names['first_name'], self.random)
            last_name = get_random_item(names['last_name'], self.random)
            return '{} {}'.format(first_name, last_name)

    test = Test

# Generated at 2022-06-12 01:42:30.424456
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.enums as enums
    from mimesis.providers.person import Person

    with Person('ru').override_locale('en') as person:
        assert person.full_name() == 'John Wilson'
        assert person.gender() == enums.Gender.MALE

    with Person('ru').override_locale('ru') as person:
        assert person.full_name() == 'Джон Браун'
        assert person.gender() == enums.Gender.MALE

# Generated at 2022-06-12 01:42:39.769931
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import builtins
    try:
        builtins.ru = ru = builtins.__dict__['ru']
    except KeyError:
        import mimesis.builtins.generic
        builtins.ru = ru = mimesis.builtins.generic.RussianSpecProvider()

# Generated at 2022-06-12 01:42:40.876128
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # TODO write tests for BaseDataProvider
    assert None is None

# Generated at 2022-06-12 01:42:49.598985
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """This is a unit test for method override_locale of class BaseDataProvider.

    This is a unit test for the method override_locale of class BaseDataProvider.
    This test checks that an unknown locale will cause the ValueError to be raised.

    :return: Result unit test.
    """
    class TestProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def get_test(self):
            return 'test'

    with TestProvider().override_locale(locale='ru') as provider:
        test = provider.get_test()
    if test == 'test':
        return True
    else:
        return False

# Generated at 2022-06-12 01:43:00.073535
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person

    person = Person('en')
    person_ru = Person('ru')
    numbers = Numbers()
    datetime = Datetime()

    assert(person.full_name() == 'Jonathan Hickman')
    assert(person_ru.full_name() == 'Екатерина Калашникова')

    with person.override_locale('ru') as ru:
        assert(ru.full_name() == person_ru.full_name())
        with ru.override_locale('en') as en:
            assert(en.full_name() == person.full_name())

# Generated at 2022-06-12 01:43:10.834160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        pass

    # If we call for a provider without locale
    dp = DummyProvider()
    with dp.override_locale() as dummy:
        # We should get exception
        assert dummy is dp
    # If we call for a provider with locale
    dp = DummyProvider(locale='en')
    with dp.override_locale() as dummy:
        assert dummy is dp
        assert dp.locale == 'en'
    assert dp.locale == 'en'
    assert dummy.locale == 'en'
    # If we call for a provider with locale and override it
    dp = DummyProvider(locale='en')
    with dp.override_locale(locale='ru') as dummy:
        assert dummy is dp

# Generated at 2022-06-12 01:44:01.900324
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDataProvider(object):
        """This is a base class for all data providers."""

        def __init__(self, locale: str = '') -> None:
            """Initialize attributes for data provider."""
            self.locale = locale

        @contextlib.contextmanager
        def override_locale(self, locale: str = 'en',
                            ) -> Generator['BaseDataProvider', None, None]:
            """Context manager which allows overriding current locale."""
            try:
                origin_locale = self.locale
                self.locale = locale
                try:
                    yield self
                finally:
                    self.locale = origin_locale
            except AttributeError:
                raise ValueError('«{}» has not locale dependent'.format(
                    self.__class__.__name__))


# Generated at 2022-06-12 01:44:10.427477
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        pass
    
    locale = 'gr'
    provider = A(locale=locale)
    provider.locale = locales.DEFAULT_LOCALE
    
    assert provider.locale == locales.DEFAULT_LOCALE
    
    with provider.override_locale(locale) as p:
        res = p.locale
    assert res == locale
    assert provider.locale != locale
    
    provider.locale = locale
    
    with provider.override_locale(locale) as p:
        res = p.locale
    assert res == locale
    assert provider.locale == locale

# Generated at 2022-06-12 01:44:14.214192
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    dp = BaseDataProvider()
    with dp.override_locale('uk') as uk_data:
        assert uk_data.locale == 'uk'
    assert dp.locale == locales.EN



# Generated at 2022-06-12 01:44:23.382298
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet

    provider = BaseDataProvider()
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale('fr'):
        assert provider.get_current_locale() == 'fr'

    # There is no locale for BuiltinProvider
    with provider.override_locale('fr'):
        assert provider.get_current_locale() == 'en'

    code = Code()
    internet = Internet()

    with code.override_locale('ru'), internet.override_locale('ru'):
        assert code.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:44:29.950929
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    import mimesis.builtins.datetime as dt
    # override_locale is context manager
    with dt.DateTime.override_locale('ru') as dt:
        assert dt.get_current_locale() == 'ru'

    assert dt.get_current_locale() == 'en'

    with dt.DateTime.override_locale('ru') as dt:
        assert dt.get_current_locale() == 'ru'

    assert dt.get_current_locale() == 'en'

# Generated at 2022-06-12 01:44:33.835322
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale()."""
    try:
        with BaseDataProvider().override_locale(locales.DEFAULT_LOCALE):
            print('Success')
    except Exception as e:
        print('Failure: {}'.format(e))


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:44:40.255808
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class DataProvider(BaseDataProvider):
        """Test data for BaseDataProvider.override_locale."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes."""
            super().__init__(seed=seed)
            self._setup_locale(locale)

        def get_current_locale(self) -> str:
            """Get current locale.

            :return: Current locale.
            """
            return self.locale

    data = DataProvider(locale='uk')
    locale = data.get_current_locale()
    assert locale == 'uk'


# Generated at 2022-06-12 01:44:50.151603
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def check_equal(first: str, second: str) -> bool:
        """Chekc equality of two objects.

        :param first: First object.
        :param second: Second object.
        :return: True, if objects is equal.
        """
        return first == second

    class TestProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'provider.json'
            self._pull()

    provider = TestProvider()
    with provider.override_locale(locales.EN) as overridden:
        assert check_equal(provider.get_current_locale(), overridden.locale)



# Generated at 2022-06-12 01:44:58.501266
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class FakeProvider(BaseDataProvider):
        """Fake class to test class BaseDataProvider.

        This class is need for test method
        override_locale of class BaseDataProvider.
        """

        def __init__(self, *args, **kwargs):
            """Initialize attributes for class FakeProvider.

            :param *args: Arguments.
            :param **kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self._data = {}
            self._datafile = ''


# Generated at 2022-06-12 01:45:02.938901
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_location of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person('en')
    with p.override_locale('ru'):
        assert p.full_name() == 'Светлана Голубкина'
    assert p.full_name() == 'Pete Davidson'