

# Generated at 2022-06-12 01:36:04.858602
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Dummy(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    p = Dummy()
    assert p.get_current_locale() == locales.EN

    with p.override_locale(locales.RU):
        assert p.get_current_locale() == locales.RU

    assert p.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:36:11.729725
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import EnumEn
    from mimesis.builtins import Person

    provider = Person()

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert isinstance(provider.gender(), EnumEn)

    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:36:22.020741
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale()."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    adr = Address('en')
    dt = Datetime('en')
    for _ in range(10):
        adr_override = adr.override_locale('ru')
        assert adr.get_current_locale() == adr_override.get_current_locale()
        assert adr.get_current_locale() != adr_override.get_current_locale()
        assert dt.get_current_locale() == dt.get_current_locale()

# Generated at 2022-06-12 01:36:32.784638
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class BaseDataProvider(BaseDataProvider):

        def __init__(self, locale: str = None, seed: Seed = None) -> None:
            if locale is None:
                locale = 'en'
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = BaseDataProvider(locale='en')
    assert provider.get_data('key') == 'en'

    with provider.override_locale('en_US') as en_US:
        assert en_US.get_data('key') == 'en_US'
        assert en_US.locale == 'en_US'

# Generated at 2022-06-12 01:36:39.477365
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import LocaleDataProvider
    from mimesis.enums import Gender

    test_cases = [
        {
            'locale': 'ru',
            'gender': Gender.FEMALE,
            'expected': 'Саша Белоглазова',
        },
        {
            'locale': 'en',
            'gender': Gender.MALE,
            'expected': 'George Jones',
        },
    ]
    data_provider = LocaleDataProvider(seed=123456)
    for case in test_cases:
        locale = case.get('locale')
        gender = case.get('gender')
        expected = case.get('expected')

# Generated at 2022-06-12 01:36:50.559944
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_provider():
        class TestProvider(BaseDataProvider):
            def __init__(self, seed=None):
                super().__init__(seed=seed)
                self._datafile = 'test_data.json'
                self._pull()
            @property
            def data(self):
                return self._data
        return TestProvider(seed=42)

    tr1 = test_provider()
    assert tr1.data['foo'] == 'bar'
    assert tr1.locale == 'en'

    # override locale
    tr2 = test_provider().override_locale('ru').context
    assert tr2.data['foo'] == 'Baz'
    assert tr2.locale == 'ru'

    # check that provider with overridden locale
    # won't change locale of other provider instance
   

# Generated at 2022-06-12 01:36:51.905377
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    return True

# Generated at 2022-06-12 01:36:57.670825
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.RU
    provider = BaseDataProvider(seed=123)
    provider._pull = lambda: None
    with BaseDataProvider.override_locale(provider, locale) as provider:
        assert provider.get_current_locale() == locale
    assert provider.get_current_locale() != locale

# Generated at 2022-06-12 01:37:07.509579
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.data import Person
    from mimesis.enums import Gender

    male = Person('en').create(gender=Gender.MALE)
    female = Person('en').create(gender=Gender.FEMALE)

    person = Person(locale='ru')
    russian = person.create(gender=Gender.FEMALE)
    with person.override_locale('en'):
        english = person.create(gender=Gender.MALE)

    assert english != russian
    assert russian == male
    assert english == female

    assert person.locale == 'ru'

# Generated at 2022-06-12 01:37:15.894450
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Init."""
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'dummy.json'
            self._pull()

        def get_data(self, key: str = None) -> Dict[str, Any]:
            """Get data for given key.

            :param key: Key.
            :return: Data.
            """
            if not key:
                key = self.random.choice(self._data.keys())

            return self._data[key]

    provider = DummyProvider()

# Generated at 2022-06-12 01:37:37.341751
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.data import qwerty
    from mimesis.providers.person import Person
    from mimesis.providers.date import Datetime
    from mimesis.providers.payment import CreditCard
    from mimesis.providers.internet import Internet
    import unittest

    class TestBaseDataProvider(unittest.TestCase):
        def setUp(self):
            self.person = Person()
            self.datetime = Datetime()
            self.credit_card = CreditCard()
            self.internet = Internet()

        @unittest.skipUnless(locales.EN in locales.SUPPORTED_LOCALALES,
                             'en is not supported')
        def test_locale_dependant_provider(self):
            locale = local

# Generated at 2022-06-12 01:37:42.754757
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``BaseDataProvider._override_locale``."""
    locale = 'ru'
    provider = BaseDataProvider()
    valid_locales = provider.get_valid_locales()
    valid_locales.append(locale)
    provider.valid_locales = valid_locales

    with provider.override_locale(locale) as p:
        assert p.get_current_locale() == locale

    assert provider.gets_current_locale() != locale



# Generated at 2022-06-12 01:37:47.159363
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.agriculture import Agriculture

    seed = '123'
    prov = Agriculture(seed=seed)

    with prov.override_locale('ru'):
        ru_values = prov.get_crop()

    np_values = Agriculture(locale='np', seed=seed).get_crop()
    assert ru_values != np_values

# Generated at 2022-06-12 01:37:57.989337
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person, Address, Datetime
    from mimesis.providers.date import GenericDateTime

    class DateTime(GenericDateTime):
        def __init__(self, seed: Seed = None, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__(seed=seed)
            self._setup_locale(locale)

    class Person(Person):
        def __init__(self, seed: Seed = None, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__(seed=seed)
            self._setup_locale(locale)


# Generated at 2022-06-12 01:38:03.319849
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for overriding current locale."""
    bdp = BaseDataProvider('ru')
    with bdp.override_locale(locale='en') as bdp:
        assert bdp.locale == 'en'
    assert bdp.locale == 'ru'

# Generated at 2022-06-12 01:38:11.341788
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    # Test for prov.override_locale()
    class TestDataProvider(BaseDataProvider):
        _datafile = 'testfile.json'

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._pull()

        def get_name(self) -> str:
            return self._data.get('locale')

    prov = TestDataProvider(seed=12345)
    prov.get_name()

    with prov.override_locale('uk') as prov:
        prov.get_name()

    with prov.override_locale('ru') as prov:
        prov.get_name()

# Generated at 2022-06-12 01:38:16.390520
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            self._data = {'locale': self.get_current_locale()}
    provider = TestProvider()
    provider.override_locale('ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:38:22.910767
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address, Financial

    address = Address()
    assert address.locale == locales.EN
    with address.override_locale(locales.PT_BR) as p_address:
        assert p_address.locale == locales.PT_BR

    financial = Financial()
    with financial.override_locale(locales.RU) as f_rus:
        assert f_rus.locale == locales.RU

# Generated at 2022-06-12 01:38:33.835857
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import EN, LANGUAGES
    from mimesis.builtins import LanguageSpecProvider

    lang_spec = LanguageSpecProvider(locale=EN)
    with lang_spec.override_locale() as lang:
        lang.US = lang.US

    with lang_spec.override_locale() as lang:
        lang.US = lang.US
        # Wrong locale.
        with lang.override_locale('ru'):
            pass

        # Wrong locale (locale not in SUPPORTED_LOCALES).
        with lang.override_locale('moc'):
            pass

    # Wrong locale (locale not in SUPPORTED_LOCALES).
    with lang_spec.override_locale('fuc'):
        pass


# Generated at 2022-06-12 01:38:38.558811
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            self._data = {'hello': 'world!'}

    foo = Foo()
    with foo.override_locale('en') as f:
        assert f._data == {'hello': 'world!'}
    assert foo._data == {'hello': 'world!'}

# Generated at 2022-06-12 01:38:58.701453
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    with Person().override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.full_name()

    with Person().override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name()

    with Person().override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.full_name()

# Generated at 2022-06-12 01:39:04.729293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Simple test provider."""
        pass

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    with provider.override_locale(locales.RU) as pr:
        assert pr.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:15.548190
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider_1 = BaseDataProvider()
    assert data_provider_1.get_current_locale() == locales.EN

    with data_provider_1.override_locale(locales.RU):
        assert data_provider_1.get_current_locale() == locales.RU
        with data_provider_1.override_locale(locales.JA):
            assert data_provider_1.get_current_locale() == locales.JA

    assert data_provider_1.get_current_locale() == locales.RU

    with data_provider_1.override_locale(locales.DE):
        assert data_provider_1.get_current_locale() == locales.DE

    assert data_provider_1.get

# Generated at 2022-06-12 01:39:23.304853
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestData(BaseDataProvider):
        def __init__(self, seed: Seed = None, locale: str = locales.EN):
            super().__init__(seed, locale)
            self._datafile = 'test_data.json'
            self._pull()

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data.get('test', {}).get(key, {})

    a: BaseDataProvider = TestData()
    a_locale = a.get_current_locale()
    assert a.get_data('test').get('test_string') == 'test'

    b: BaseDataProvider = TestData(locale=locales.RU)
    b_locale = b.get_current_locale()

# Generated at 2022-06-12 01:39:35.143040
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import PROVIDER_PACKAGES
    from mimesis.enums import Gender
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science

    # locale-dependent providers
    person = Person(seed=123)
    science = Science(seed=123)

    # locale-independent providers
    coder = PROVIDER_PACKAGES.get('coding').Provider(seed=123)

    # context manager
    with person.override_locale('en-GB') as p:
        assert p.get_current_locale() == 'en-GB'
        assert p.full_name(gender=Gender.MALE) == 'Thomas Walker'

# Generated at 2022-06-12 01:39:41.547693
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Datetime, Person

    dtp = Datetime()
    person = Person()

    with dtp.override_locale('uk') as provider:
        assert provider.get_current_locale() == 'uk'
        assert person.name('uk') == 'Андрій'
        assert dtp.day_of_week() == 'неділя'

    assert provider.get_current_locale() == getattr(
        dtp, 'locale', locales.DEFAULT_LOCALE)
    assert person.name('uk') == 'Андрій'
    assert dtp.day_of_week() == 'воскресенье'

# Generated at 2022-06-12 01:39:52.236244
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""

    class TestDataProvider(BaseDataProvider):
        """Class for testing method override_locale."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'firstnames.json'

    provider = TestDataProvider(locales.RU)
    assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-12 01:40:00.413744
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import (Address, Code, Datetime, File, Hardware,
                                  Internet, Person, Text)
    from mimesis.enums import Gender, USState
    from mimesis.providers.actions import Action
    from mimesis.providers.code import CodeProvider
    from mimesis.providers.datetime import DatetimeProvider
    from mimesis.providers.file import FileProvider
    from mimesis.providers.geography import GeographyProvider
    from mimesis.providers.hardware import HardwareProvider
    from mimesis.providers.internet import InternetProvider
    from mimesis.providers.person import PersonProvider
    from mimesis.providers.science import ScienceProvider
    from mimesis.providers.text import TextProvider

# Generated at 2022-06-12 01:40:00.839482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-12 01:40:03.438784
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.personal import Person
    p = Person()
    with p.override_locale('de') as g:
        assert g.get_current_locale() == 'de'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:40:30.220957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider._override_locale() method."""
    from mimesis.providers.address import Address
    from mimesis.providers.postal import PostalCode

    address = Address('ru')
    assert address.get_current_locale() == 'ru'

    with address.override_locale('en') as addr:
        assert address.get_current_locale() == 'en'
        assert addr is address

    assert address.get_current_locale() == 'ru'

    with address.override_locale('en') as addr:
        assert address.get_current_locale() == 'en'
        assert addr is address

    assert address.get_current_locale() == 'ru'

    test_provider = Address('ru')
    postal_code = PostalCode('en')


# Generated at 2022-06-12 01:40:38.170247
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    assert Person().get_current_locale() == 'en'
    with Person().override_locale('ru'):
        assert Person().get_current_locale() == 'ru'
        assert Person().full_name() == "Ольга Селянкова"
    assert Person().get_current_locale() == 'en'
    assert Person().full_name() == "Kelley Riley"

# Generated at 2022-06-12 01:40:42.874234
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Address
    address = Address(locale='en')
    with address.override_locale('ru') as addr:
        assert addr.__str__() == 'Address <ru>'
        assert addr.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:40:52.417377
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider: test method override_locale."""
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test_provider.json'
            self._pull()

        def test(self) -> str:
            return self._data['test']

    it = TestProvider(locale='ru-RU')

    assert it.get_current_locale() == 'ru-ru'
    assert it.test() == 'Тестовый провайдер'
    with it.override_locale('en'):
        assert it.get

# Generated at 2022-06-12 01:40:58.320379
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        _datafile = 'test.json'

    provider = TestProvider()
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as test:
        assert test.locale == locales.RU

    assert provider.locale == locales.EN

# Generated at 2022-06-12 01:41:08.255682
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .address import Address
    from .code import Code
    from .datetime import Datetime
    from .text import Text
    from .person import Person

    assert Address(locale='uk').get_current_locale() == locales.UK
    assert Code(locale='uk').get_current_locale() == locales.UK
    assert Datetime(locale='uk').get_current_locale() == locales.UK
    assert Text(locale='uk').get_current_locale() == locales.UK
    assert Person(locale='uk').get_current_locale() == locales.UK

    with Address(locale='uk').override_locale(locale='en') as a:
        assert a.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:41:11.733200
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():  # noqa: D103

    class FakeProvider(BaseDataProvider):
        pass

    provider = FakeProvider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:41:15.482800
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class UnitTestProvider(BaseDataProvider):

        def get_data(self):
            return self._data

    tp = UnitTestProvider(locale='ru')

    with tp.override_locale('en'):
        assert tp.get_current_locale() == 'en'
        assert tp.get_data() == {}

    assert tp.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:41:19.245084
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    user_agent = BaseDataProvider(locale='en')
    with user_agent.override_locale('ru'):
        assert user_agent.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:41:25.337256
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of BaseDataProvider class."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person()
    with p.override_locale('en'):
        assert p.name(gender=Gender.MALE) == 'Leroy'
    with p.override_locale('ru'):
        assert p.name(gender=Gender.MALE) == 'Яков'
    assert p.name(gender=Gender.MALE) == 'Leroy'

# Generated at 2022-06-12 01:42:23.007705
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.common import Common
    from mimesis.providers.geography import Geography
    s = Common('en')
    g = Geography()
    s_ = Common()
    g_ = Geography()
    assert s.locale == 'en'
    assert g.locale == 'en'
    try:
        s_locale = s_.locale
    except AttributeError as e:
        pass
    else:
        assert False, 'Expected a ValueError to be raised'
    try:
        g_locale = g_.locale
    except AttributeError as e:
        pass
    else:
        assert False, 'Expected a ValueError to be raised'

# Generated at 2022-06-12 01:42:29.757167
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    locale = locales.EN
    with provider.override_locale(locale) as provider:
        assert provider.get_current_locale() == locale
        assert provider.locale == locale

        locale = locales.RU
        with provider.override_locale(locale) as provider:
            assert provider.get_current_locale() == locale
            assert provider.locale == locale
            locale = locales.EN
        assert provider.get_current_locale() == locale

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:39.577735
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test locale-dependent provider."""

        def __init__(self, locale: str = 'en-US', seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale, seed)
            self._datafile = "test.json"
            self._pull()

        def get_data(self) -> Dict[str, str]:
            """Get the data from locale dependent provider.

            This method returns a hardcoded Dict[str, str],
            because lru_cache is processed before calling a method
            in an overridden locale.

            :return: A hardcoded Dict[str, str].
            """

# Generated at 2022-06-12 01:42:44.830816
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import CardSystem

    from . import Payment

    p = Payment()

    # Assert if 'locale' property exists.
    assert hasattr(p, 'locale')

    with p.override_locale('ru') as provider_ru:
        assert provider_ru._validate_enum(None, CardSystem) == 'VISA'

    # Assert if local is reverted to the previous state
    assert p.locale == 'en'

# Generated at 2022-06-12 01:42:49.599334
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

    provider = TestProvider()
    assert provider.locale == 'en'

    with provider.override_locale('fa'):
        assert provider.locale == 'fa'

    assert provider.locale == 'en'

# Generated at 2022-06-12 01:42:54.094393
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    provider2 = BaseDataProvider()
    try:
        with provider.override_locale('ru'):
            pass
    except ValueError:
        return True
    try:
        with provider2.override_locale('ru'):
            pass
    except ValueError:
        return True
    return False

# Generated at 2022-06-12 01:42:59.622169
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .person import Person

    with Person().override_locale('en') as p:
        assert p.locale == 'en'
        assert p.get_current_locale() == 'en'

    p = Person(locale='en')
    assert p.locale == 'en'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:03.681389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()

    # case 1:
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'

    # case 2:
    try:
        with provider.override_locale('ru') as p:
            assert p.locale == 'ru'
            raise ValueError('Error')
    except ValueError:
        pass

# Generated at 2022-06-12 01:43:10.210538
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code

    a = Person('en')
    print(a.full_name())
    with a.override_locale('ru') as provider:
        print(provider.full_name())
    print(a.full_name())

    b = Code()
    print(b.app)
    with b.override_locale('ru') as provider:
        print(provider.app)
    print(b.app)

# Generated at 2022-06-12 01:43:19.302038
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.identifiers import Names
    from mimesis.providers.date import DateTime

    A = lambda : Names('en')
    B = lambda : Names('ru')

    C = lambda : DateTime('en')
    D = lambda : DateTime('ru')

    assert all(A().is_valid_locale(locale) for locale in locales.SUPPORTED_LOCALES)
    assert all(B().is_valid_locale(locale) for locale in locales.SUPPORTED_LOCALES)

    assert A().get_current_locale() == locales.EN
    assert B().get_current_locale() == locales.RU

    assert A().name() != B().name()
    assert A().username() != B().username()
    assert A().password() != B

# Generated at 2022-06-12 01:45:15.108124
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address

    address = Address()

    with address.override_locale('ru') as a:
        street_in_ru = a.street_name()
    with address.override_locale('de') as a:
        street_in_de = a.street_name()

    assert address.locale == 'en'
    assert street_in_ru != street_in_de
    assert street_in_ru != address.street_name()
    assert street_in_de != address.street_name()

# Generated at 2022-06-12 01:45:20.231012
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale method."""
    provider = BaseDataProvider()
    with provider.override_locale() as p:
        assert isinstance(p, BaseProvider)
        assert p.locale == locales.DEFAULT_LOCALE
        assert provider.locale == locales.DEFAULT_LOCALE
        assert p == provider
    assert p != provider
    assert p.locale is None

# Generated at 2022-06-12 01:45:22.345633
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert isinstance(BaseDataProvider.override_locale, property)

# Generated at 2022-06-12 01:45:32.547426
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class _Provider(BaseDataProvider):
        """Provider for testing"""

        _datafile = 'test.json'

        def __init__(self, locale: str = 'en', seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale, seed)
        
        def get_current_locale(self) -> str:
            """Get current locale.

            If locale is not defined then this method will always return ``en``,
            because ``en`` is default locale for all providers, excluding builtins.

            :return: Current locale.
            """
            return self.locale

    def test_case() -> None:
        """Test this method."""
        mimesis

# Generated at 2022-06-12 01:45:35.499931
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider('de')
    with provider.override_locale('nl'):
        data = provider.get_data()
        assert data == TestProvider('nl').get_data()

# Generated at 2022-06-12 01:45:42.530937
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person

    # Check whether the method works correctly with the Person class
    person = Person()
    with person.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
    assert person.get_current_locale() == 'ru'

    # Check whether the method works correctly with the Person class
    # when the locale is not defined, and an error will be raised.
    with pytest.raises(ValueError):
        with person.override_locale('en') as provider:
            assert provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:45:48.305129
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    p = Person()
    with p.override_locale() as provider:
        assert provider.locale == locales.EN
    assert p.locale == locales.RU

    with p.override_locale(locales.EN) as provider:
        assert provider.locale == locales.EN
        assert p.locale == locales.EN
    assert p.locale == locales.RU