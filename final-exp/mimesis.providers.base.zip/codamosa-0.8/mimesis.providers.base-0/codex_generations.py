

# Generated at 2022-06-12 01:36:07.010862
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider1 = TestProvider(locale='en')
    provider2 = TestProvider(locale='ru')

    test_list = ['test1', 'test2', 'test3']

    with provider1.override_locale('ru'):
        assert provider1._data['test'] == provider2._data['test']
    assert provider1._data['test'] != provider2._data['test']

    with provider1.override_locale('en'):
        assert provider1._data['test'] != provider2._data['test']



# Generated at 2022-06-12 01:36:15.811241
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.code import Code
    from mimesis.enums import HashAlgorithms
    c1 = Code(seed=7)
    with c1.override_locale('ru') as c:
        assert c1 is c
        assert c1.get_current_locale() == "ru"
        assert c1.hash().sha3(HashAlgorithms.SHA3_512) == "3a3a579a45b2e8c8a9e32686f9d3449655dfa8f8d1b1c7b2778ce06e8e0c4f2d4d4b4b4aa1edc4d2a2c7f89ccca7585a8a8a8a62ddf9b26fd3020e87966f6d65"

# Generated at 2022-06-12 01:36:18.260798
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert provider.override_locale('ru_RU') is not None


# Generated at 2022-06-12 01:36:26.374221
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        _datafile = 'test.json'

        def get_test_data(self):
            return self._data['test_data']


    provider = TestProvider()
    test_data = provider.get_test_data()
    assert test_data == "en test_data"
    with provider.override_locale("cz") as cz_p:
        test_data = cz_p.get_test_data()
        assert test_data == "cz test_data"
    test_data = provider.get_test_data()
    assert test_data == "en test_data"

# Generated at 2022-06-12 01:36:32.513497
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method ``override_locale``.

    This test check how work context manager ``override_locale``.
    It should be raised ``ValueError`` exception when data provider has
    not locale dependent.

    Code to test:

    .. code-block:: python

        >>> with BaseDataProvider() as p:
        ...    pass

    """
    with BaseDataProvider() as p:
        pass

# Generated at 2022-06-12 01:36:39.348510
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Internet
    from mimesis.providers.lorem import Lorem
    internet = Internet()
    lorem = Lorem()
    with internet.override_locale('ru') as ru_internet:
        ru_internet_url = ru_internet.url()
        ru_internet_domain_name = ru_internet.domain_name()
    with lorem.override_locale('ru'):
        ru_lorem_text = lorem.text()
    with internet.override_locale('de'):
        de_internet_url = internet.url()
        de_internet_domain_name = internet.domain_name()
    with lorem.override_locale('de'):
        de_lorem_text = lorem.text()
    # Check the Python 3.

# Generated at 2022-06-12 01:36:44.320805
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    #Given
    class MyProvider(BaseDataProvider):
        pass

    provider = MyProvider()
    # Then
    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU


# Generated at 2022-06-12 01:36:50.720746
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def test_method(self):
            return getattr(self, 'locale', locales.EN)

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.test_method() == 'ru'
        assert p.locale == 'ru'

    assert provider.locale == locales.EN
    assert provider.test_method() == locales.EN

# Generated at 2022-06-12 01:37:01.128897
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Test(BaseDataProvider):
        """Test provider."""

        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed)

    from mimesis.enums import Gender

    g = Test()
    male = 'male'
    female = 'female'
    with g.override_locale('ru'):
        assert g.get_current_locale() == 'ru'
        assert g.get_full_name(gender=Gender.MALE) == male
        assert g.get_full_name(gender=Gender.FEMALE) == female

    assert g.get_current_locale() == 'en'
    assert g.get_full_name(gender=Gender.MALE) != male

# Generated at 2022-06-12 01:37:07.331301
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale, seed=None):
            super().__init__(locale, seed)

        def __repr__(self):
            return 'Provider'

    pr = Provider(locales.EN)
    with pr.override_locale('ru'):
        assert pr.get_current_locale() == locales.RU

    assert pr.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:37:26.994982
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider's method override_locale."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    provider = Person('en')
    assert provider.get_current_locale() == locales.EN
    assert provider.get_gender(Gender.FEMALE) == 'female'

    with provider.override_locale('ru'):
        assert provider.get_gender(Gender.FEMALE) == 'женский'
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.EN
    assert provider.get_gender(Gender.FEMALE) == 'female'


# Generated at 2022-06-12 01:37:37.464411
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def test_override_locale(locale):
        assert locale is not None

    def test_override_locale_with_locale(provider):
        with provider.override_locale() as p:
            assert p.get_current_locale() != provider.get_current_locale()
            test_override_locale(p.get_current_locale())

    def test_override_locale_with_locale_and_param(provider):
        locale = locales.DA
        with provider.override_locale(locale) as p:
            assert p.get_current_locale() != provider.get_current_locale()

# Generated at 2022-06-12 01:37:41.064713
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Food
    data = Food(seed=42)
    print(data.get_current_locale())
    with food.override_locale('zh'):
        print(data.get_current_locale())
# ->
# en
# zh


# Generated at 2022-06-12 01:37:43.943086
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.locale == locales.EN
    assert provider.locale == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:37:49.999115
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Food

    provider = Food()
    assert provider.get_current_locale() == 'en'
    assert provider.get_item() in provider.data['vegetables']

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get_item() in provider.data['vegetables']
        assert provider.get_item() not in Food().data['vegetables']

    assert provider.get_current_locale() == 'en'
    assert provider.get_item() in Food().data['vegetables']
    assert provider.get_item() not in Food('ru').data['vegetables']

    assert provider.get_current_locale() == 'en'
    assert provider.get_item() in Food

# Generated at 2022-06-12 01:37:54.191108
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    dp = BaseDataProvider()
    with dp.override_locale('ru'):
        assert dp.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:56.472580
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method ``override_locale`` of class ``BaseDataProvider``."""
    from providers import Person

    with Person().override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    with Person().override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:38:01.169487
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        pass

    assert 'Foo <en>' == str(Foo())
    with Foo().override_locale('ru') as foo:
        assert 'Foo <ru>' == str(foo)

# Generated at 2022-06-12 01:38:05.993083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def _pull(self, datafile):
            self._data = {'result': 'result'}

    provider = TestProvider()
    with provider.override_locale() as locale_provider:
        assert provider is locale_provider
        assert locale_provider._data == {'result': 'result'}

# Generated at 2022-06-12 01:38:14.584249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en-US'):
            self._locale = locale

    provider = TestProvider(locale='en-US')
    with provider.override_locale('en-GB') as new_provider:
        assert new_provider._locale == 'en-GB'

    provider = TestProvider(locale='en-US')
    with provider.override_locale('fr-FR') as new_provider:
        assert new_provider._locale == 'fr-FR'

# Generated at 2022-06-12 01:38:26.206322
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from .personal import Person

    with Person().override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert Person().get_current_locale() == 'en'



# Generated at 2022-06-12 01:38:31.367381
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider(locale='uk')
    assert provider.get_current_locale() == 'uk'

    with provider.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'uk'

# Generated at 2022-06-12 01:38:36.512732
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'pl'
    locale_names = ('__call__', '__repr__', '__str__', '__unicode__', '_pull')
    provider = BaseDataProvider(locale=locale)

    with provider.override_locale(locale) as instance:
        for name in locale_names:
            assert getattr(instance, name) == getattr(provider, name)

    assert provider.get_current_locale() == locale

# Generated at 2022-06-12 01:38:47.913164
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # class using this method
    from mimesis.builtins import ENUSBuiltin
    # class with overridden locale
    from mimesis.builtins import FRFRBuiltin
    # create instance
    p = ENUSBuiltin()
    # check origin locale
    assert p.locale == 'en_US'
    # override locale
    with p.override_locale('fr_FR') as p2:
        # check origin locale
        assert p2.locale == 'fr_FR'
        # use random function of builtins
        random_hex = p2.random.hex()
        # check type of object
        assert isinstance(p2, FRFRBuiltin)
    # check locale after leaving context manager
    assert p.locale == 'en_US'
    # re-check locale after leaving context manager
    assert p

# Generated at 2022-06-12 01:38:59.326959
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method."""
    class Foo(BaseDataProvider):
        """Class Foo."""

        def __init__(self, **kwargs: Any) -> None:
            """Init method.

            :param kwargs: kwargs
            """
            self.data = kwargs
            super().__init__(**kwargs)

        def method(self) -> Dict[str, str]:
            """Method for tests."""
            return self.data

    foo = Foo()
    with foo.override_locale() as f:
        assert foo.get_current_locale() == 'en'
    assert foo.get_current_locale() is None
    assert f.get_current_locale() is None
    foo = Foo(locale='en')

# Generated at 2022-06-12 01:39:02.750151
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='zh')
    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'zh'

# Generated at 2022-06-12 01:39:06.556885
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # base_provider = BaseDataProvider(locale='en')

    # new_provider = base_provider.override_locale('ru')

    # assert str(new_provider) == 'BaseDataProvider <ru>'
    pass

# Generated at 2022-06-12 01:39:16.925849
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test class for unit test."""
        def __init__(self, locale:str = 'en', seed: Seed = None):
            """Initialize attributes for unit test."""
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'random.json'
            self._pull()

        def random_int(self) -> int:
            """Get value from data."""
            return self._data['integers']['digits'][1]
    tp = TestProvider(locale='ru')
    with tp.override_locale('en'):
        assert tp.random_int() == 9


# Generated at 2022-06-12 01:39:22.348884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.data import Science
    from mimesis.enums import Chemistry

    science = Science()
    with science.override_locale(locales.RU):
        assert science.get_current_locale() == 'ru'
        assert isinstance(science.chemical_element(), str)

    assert science.get_current_locale() == 'en'
    assert isinstance(science.chemical_element(Chemistry.ELEMENT), str)

# Generated at 2022-06-12 01:39:27.010580
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.random.randint(1, 100) == 35



# Generated at 2022-06-12 01:39:46.227692
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Name

    with Name('ru').override_locale() as name:
        assert name.locale == 'ru'

# Generated at 2022-06-12 01:39:55.362010
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    import os
    import mimesis
    from mimesis.data.locales import DEFAULT_LOCALE

    seed = os.urandom(4)
    provider = mimesis.Time(locale='en', seed=seed)
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as cur_prov:
        assert cur_prov.get_current_locale() == 'ru'

    with provider.override_locale() as cur_prov:
        assert cur_prov.get_current_locale() == DEFAULT_LOCALE

    try:
        with provider.override_locale('de'):
            pass
    except ValueError:
        pass


# Generated at 2022-06-12 01:40:02.508217
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Provider(BaseDataProvider):
        """The simplest implementation of BaseDataProvider."""

        def __init__(self, locale_code: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale_code: locale code
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale_code, seed)

        @property
        def datafile(self) -> str:
            """Path of JSON file in the folder ``data/locale``.

            :return: Path of JSON file.
            """
            return '{0}.json'.format(type(self).__name__.lower())

    new_locale = locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:40:13.140524
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    provider = Provider()

    with provider.override_locale(locales.ENUS):
        assert provider.get_current_locale() == locales.ENUS

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.DK):
        assert provider.get_current_locale() == locales.DK

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:40:20.433523
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address, Business
    addr = Address()
    bus = Business()
    provider = Business()

    with provider.override_locale(locales.RU):
        origin = ['քաղաքի համայնք','Գարուն','Սիսենտիրի վարչական խոնապատմություն']

# Generated at 2022-06-12 01:40:25.672185
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        pass

    info = DataProvider()
    assert info.get_current_locale() == 'en'
    with info.override_locale('en'):
        assert info.get_current_locale() == 'en'
    assert info.get_current_locale() == 'en'
# # Unit test for method override_locale of class BaseDataProvider


# Generated at 2022-06-12 01:40:37.438460
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    pEN = Person(locale='en')
    aEN = Address(locale='en')
    pUA = Person(locale='ua')
    aUA = Address(locale='ua')
    s = aEN.street_name()
    a = pEN.full_name(gender=Gender.FEMALE)
    ao = pUA.full_name(gender=Gender.FEMALE)
    with pEN.override_locale('ua') as provider:
        assert provider.get_current_locale() == 'ua'
        assert a != ao
        assert a == provider.full_name(gender=Gender.FEMALE)

# Generated at 2022-06-12 01:40:43.574449
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class UnLocaleDependentProvider(BaseProvider):
        pass

    class LocaleDependentProvider(BaseDataProvider):
        pass

    ulprovider = UnLocaleDependentProvider()

    with ulprovider.override_locale() as ulprovider:
        assert ulprovider.locale == locales.DEFAULT_LOCALE

    lprovider = LocaleDependentProvider()

    with lprovider.override_locale() as lprovider:
        assert lprovider.locale == locales.DEFAULT_LOCALE

    with lprovider.override_locale(locales.RU):
        assert lprovider.locale == locales.RU

    with lprovider.override_locale(locales.RU):
        pass


# Generated at 2022-06-12 01:40:45.991188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    p = Provider()
    del p.locale
    with p.override_locale():
        pass

# Generated at 2022-06-12 01:40:52.350353
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile ='test.json'

    test_provider = TestProvider(locale='ru')
    with test_provider.override_locale(locale='en'):
        assert test_provider.get_current_locale() == locales.EN
    assert test_provider.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:41:30.141409
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    bdp = BaseDataProvider()
    try:
        with bdp.override_locale():
            pass
    except ValueError:
        pass


# Generated at 2022-06-12 01:41:37.523437
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.date import Date
    from mimesis.providers.person import Person

    class MyDate(Date):
        """Customized Date Provider."""
        pass

    class MyPerson(Person):
        """Customized Person Provider."""
        pass

    # Test for Provider with locale dependent
    with MyDate.override_locale(locale='ru'):
        date_russian = MyDate().full_date()
        assert date_russian
    with MyDate.override_locale(locale='en'):
        date_english = MyDate().full_date()
        assert date_english
    with MyPerson.override_locale(locale='ru'):
        person = MyPerson()

# Generated at 2022-06-12 01:41:38.300242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    pass

# Generated at 2022-06-12 01:41:46.659684
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.builtins import USASocialSecurityNumberProvider
    from mimesis.builtins import USASocialSecurityNumber

    ssn = USASocialSecurityNumber(seed=1)
    with ssn.override_locale('ru') as en:
        assert en.get_current_locale() == 'ru'
        assert ssn.get_current_locale() == 'en'

        assert en.ssn(gender=Gender.FEMALE, hyphens=True) == '478-48-8833'

    assert ssn.get_current_locale() == 'en'
    assert ssn.ssn(gender=Gender.FEMALE, hyphens=True) == '478-48-8833'


# Generated at 2022-06-12 01:41:54.365119
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method ``BaseDataProvider.override_locale``."""
    from mimesis.providers.person import Person

    p = Person()
    assert p.get_current_locale() != 'ru'

    with p.override_locale('ru') as russian_p:
        assert russian_p.get_current_locale() == 'ru'
        # Russian name
        russian_p.name() == 'Лиана'

    assert p.get_current_locale() != 'ru'

# Generated at 2022-06-12 01:41:58.568609
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider(locale='ru')
    assert provider.locale == 'ru'

    with provider.override_locale('en'):
        assert provider.locale == 'en'

    assert provider.locale == 'ru'

    with provider.override_locale('en'):
        with provider.override_locale('en_US'):
            assert provider.locale == 'en_US'
        assert provider.locale == 'en'
    assert provider.locale == 'ru'

# Generated at 2022-06-12 01:42:07.343051
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def do_something(self):
            pass

    try:
        with TestProvider().override_locale('ru'):
            pass
    except ValueError as error:
        if error.args[0] == '«TestProvider» has not locale dependent':
            raise Exception('AttributeError: ' +
                            '«TestProvider» has not locale dependent')



# Generated at 2022-06-12 01:42:17.298567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Person

    # Check for exception
    prov = Person('en')
    with prov.override_locale(locale='pt-br'):
        assert prov.get_current_locale() == 'pt-br'

    # Check for overriding locale of provider
    prov = Person('ru')
    with prov.override_locale(locale='pt'):
        pass  # To set `locale` of `prov` to `pt`
    assert prov.get_current_locale() == 'pt'

    # Check for default locale
    prov = Person()
    assert prov.get_current_locale() == 'en'

    # Check for exception
    prov = Gender()

# Generated at 2022-06-12 01:42:26.880747
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # In this test we'll check if method override_locale of class BaseDataProvider works properly
    # First, we'll create an object of class BaseDataProvider
    provider = BaseDataProvider()
    # Then we'll instantiate it and take the current locale
    with provider.override_locale(locales.EN) as provider_EN:
        # We'll check if locale has changed
        locale = provider_EN.get_current_locale()
        assert locale == 'en'
        print(locale)
        # Then we'll set a new locale and check again
        with provider.override_locale(locales.LT) as provider_LT:
            locale = provider_LT.get_current_locale()
            assert locale == 'lt'
            print(locale)
            # Finally, we'll check if our provider is a BaseDataProvider

# Generated at 2022-06-12 01:42:29.195219
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale=locales.EN).override_locale(locales.RU) as provider:
        assert provider.locale == locales.RU


# Generated at 2022-06-12 01:43:58.763996
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale='ru'):
            super().__init__(locale=locale)


    provider = TestDataProvider()

    with provider.override_locale('en') as p:
        assert p.locale == 'en'

    assert provider._datafile == ''
    assert provider._data == {}
    assert provider.locale == 'ru'


# Generated at 2022-06-12 01:44:09.053296
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, seed, locale):
            super().__init__(seed, locale)

        def get_data(self):
            return self.data

    provider = Test(seed=12345, locale='en')
    assert provider.get_data() == {}
    provider.data = 'test'
    assert provider.get_data() == 'test'

    # Test context manager
    with provider.override_locale('ru'):
        assert provider.get_data() == 'test'
        provider.data = 'test_ru'
        assert provider.get_data() == 'test_ru'

    assert provider.get_data() == 'test'

    # Test Error for has not locale dependent provider
    del provider.locale
    assert provider.locale is None

# Generated at 2022-06-12 01:44:13.572343
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

    test_provider = TestProvider()
    with test_provider.override_locale('ru'):
        assert test_provider.get_current_locale() == 'ru'
    assert test_provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:44:22.826498
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    import mimesis.builtins
    from mimesis.locales.base import BaseLocale

    class TestClass(BaseDataProvider):
        """Test class for testing override_locale method."""

        def __init__(self, locale: str = locales.RU) -> None:
            """Initialize attributes for class TestClass.

            :param locale: locale.
            """
            super().__init__(locale=locale)
            self.test_locale = self.get_current_locale()

    prov = TestClass()
    assert prov.test_locale == locales.RU
    assert prov.get_current_locale() == locales.RU


# Generated at 2022-06-12 01:44:31.595105
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Human
    dp = Human()
    with dp.override_locale('ru') as dp_ru:
        assert dp.get_current_locale() == locales.DEFAULT_LOCALE
        assert dp_ru.get_current_locale() == 'ru'
        # Assert that current locale is not overwritten
        with dp.override_locale() as dp_en:
            assert dp.get_current_locale() == locales.DEFAULT_LOCALE
            assert dp_ru.get_current_locale() == 'ru'
            # Assert that current locale is overwritten
            with dp.override_locale('ru') as dp_ru:
                assert dp.get_current_locale() == locales.DEFAULT

# Generated at 2022-06-12 01:44:35.251527
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    sample = 'de'
    data_provider = BaseDataProvider(locale=sample)
    assert data_provider.locale == sample
    with data_provider.override_locale(locale='en'):
        assert data_provider.locale == 'en'
        assert data_provider.locale != sample
    assert data_provider.locale == sample

# Generated at 2022-06-12 01:44:41.111993
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestLocale(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                 seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def _choose_value(self, data: Dict) -> str:
            return self.random.choice(list(data.keys()))

    tl = TestLocale('en',seed=123)
    assert tl._choose_value(tl._data) == 'en_value'
    with tl.override_locale('ru'):
        assert tl._choose_value(tl._data) == 'ru_value'

# Generated at 2022-06-12 01:44:48.297642
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale=locales.EN)
    with provider.override_locale(locales.JA) as new_provider:
        assert new_provider.locale == locales.JA
    assert provider.locale == locales.EN

    class Foo(BaseDataProvider):
        pass

    foo = Foo(locale=locales.EN)
    with pytest.raises(ValueError):
        with foo.override_locale(locales.RU):
            assert True

# Generated at 2022-06-12 01:44:55.911318
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_override_locale_context_manager(data_provider, locale_code):
        with data_provider.override_locale(locale_code) as dp:
            yield dp, dp.get_current_locale()

    def test_override_locale_function(data_provider, locale_code):
        data_provider.override_locale(locale_code)
        yield data_provider

    def get_data_provider(provider_class):
        if issubclass(provider_class, BaseDataProvider):
            dp = provider_class()
            return dp

    provider_classes = [
        BaseDataProvider,
        BaseProvider
    ]

# Generated at 2022-06-12 01:45:04.226633
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, size: int = 0) -> None:
            super().__init__(locale=locale)
            self.size = size
    # First test
    # Here we check how context manager works
    with TestProvider('en-US', size=18) as locale_provider:
        assert locale_provider.size == 18
    assert locale_provider.size == 0
    # Second test
    # Here we check how using an undefined attribute raises an error
    with TestProvider('en-US', size=18) as locale_provider:
        assert locale_provider.size == 18
    assert locale_provider.size == 0