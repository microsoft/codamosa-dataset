

# Generated at 2022-06-12 01:36:05.710868
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        pass
    foo = Foo()
    with foo.override_locale('en') as f:
        assert f.get_current_locale() == 'en'
    assert foo.get_current_locale() is None
    with foo.override_locale() as f:
        assert f.get_current_locale() == 'en'
    assert foo.get_current_locale() is None

# Generated at 2022-06-12 01:36:12.246709
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)


    provider = TestProvider()
    with provider.override_locale('zh'):
        assert provider.get_current_locale() == 'zh'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:36:20.302565
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    payload = {
        'provider_name': 'Address',
        'locale': 'es',
        'test_name': 'test_BaseDataProvider_override_locale',
    }
    from mimesis.providers import Address
    with Address().override_locale('es') as address:
        assert address.get_current_locale() == 'es'
        assert address._data is not None
        assert address._data['address']['region']
    assert address.get_current_locale() == 'en'
    return payload

# Generated at 2022-06-12 01:36:26.092214
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SampleDataProvider(BaseDataProvider):
        _datafile = 'sample_data.json'
        _provides = ('sample',)

        def sample(self) -> Dict[str, Any]:
            return self._data

    sd = SampleDataProvider()
    with sd.override_locale('ru') as custom:
        assert isinstance(custom.sample(), Dict)
        assert custom.sample() == {'sample': 'sample'}

# Generated at 2022-06-12 01:36:29.349054
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('en') as p:
        assert p.locale == 'en'



# Generated at 2022-06-12 01:36:37.799049
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale of BaseDataProvider."""
    from mimesis.builtins import Person

    assert Person.__name__ == 'Person'
    with Person.override_locale('en') as p:
        assert p.full_name(gender=None) == 'Mr. John M. Wilson'
        assert p.full_name(gender='male') == 'Mr. John M. Wilson'
        assert p.full_name(gender='female') == 'Ms. Keira J. Perez'
    with Person.override_locale('ru') as p:
        assert p.full_name(gender=None) == 'г-н Николай К. Назаров'

# Generated at 2022-06-12 01:36:46.764212
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_provider(locale=locales.DEFAULT_LOCALE):
        class TestProvider(BaseDataProvider):
            def __init__(self, locale, seed):
                super().__init__(locale, seed)

            def get_current_locale(self) -> str:
                return self.locale

        return TestProvider(locale, seed=None)

    provider = test_provider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:36:49.513652
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method."""
    with BaseDataProvider().override_locale('ko'):
        assert BaseDataProvider().get_current_locale() == 'ko'

# Generated at 2022-06-12 01:36:54.627539
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

    provider = TestProvider(locale='ru')

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:03.907960
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import datetime
    from mimesis.enums.datetime import DayOfWeek, Month
    from mimesis.providers.datetime import Datetime
    
    class MyDatetime(Datetime):
        @contextlib.contextmanager
        def override_locale(self, locale: str = locales.EN,
                            ) -> Generator['BaseDatetimeProvider', None, None]:
            """Context manager which allows overriding current locale.
    
            Temporarily overrides current locale for
            locale-dependent providers.
    
            :param locale: Locale.
            :return: Provider with overridden locale.
            """

# Generated at 2022-06-12 01:37:21.553622
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, seed: Seed = None) -> None:
            super().__init__(locale, seed)

    provider = TestProvider('en')
    with provider.override_locale('ru') as override_provider:
        assert provider.locale == override_provider.locale == 'ru'
    assert provider.locale == 'en'


# Generated at 2022-06-12 01:37:26.917643
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider()
    provider._pull = lambda: setattr(provider, 'locale', 'prov_locale')

    with provider.override_locale('override_locale') as provider:
        assert provider.locale == 'override_locale'

    assert provider.locale == 'prov_locale'



# Generated at 2022-06-12 01:37:31.565838
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    address = Address('ru')
    with address.override_locale('ru') as addr:
        assert address.locale == 'ru'
    assert addr.locale != 'ru'
    assert address.locale != addr.locale


# Generated at 2022-06-12 01:37:34.592462
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale of class BaseDataProvider."""
    data_provider = BaseDataProvider()
    try:
        with data_provider.override_locale():
            pass
    except ValueError:
        assert True



# Generated at 2022-06-12 01:37:44.326924
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(locale, seed)
            self._datafile = 'test.json'
            self._pull()

        def get_dummy_one(self):
            return self._data.get('dummy_one')

    tdp = TestDataProvider()
    with tdp.override_locale('en'):
        assert tdp.get_dummy_one() == 'one'
    with tdp.override_locale('ru'):
        assert tdp.get_dummy_one() == 'один'
    with tdp.override_locale('fr'):
        assert tdp.get_dummy_one() == 'un'

# Generated at 2022-06-12 01:37:55.274032
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.RU, seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test_data.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    p = TestDataProvider()

    with p.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() != {}

# Generated at 2022-06-12 01:38:05.932405
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method `override_locale` of class `BaseDataProvider`."""
    locale = 'ru'
    assert locale in locales.SUPPORTED_LOCALES, \
            '`{}` is not supported locale'.format(locale)
    provider = BaseDataProvider(locale=locale)
    origin_locale = provider.get_current_locale()
    assert origin_locale == locale
    provider.locale = 'en'
    with provider.override_locale(locale=locale):
        assert provider.locale == locale
        assert provider.get_current_locale() == locale

    # Restore the locale
    assert provider.get_current_locale() == origin_locale

# Generated at 2022-06-12 01:38:16.974750
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    address = Address(seed=1)
    with address.override_locale('ru') as new_address:
        postal_code = new_address('postalcode')
        assert postal_code == '.+'
    with address.override_locale('ja') as new_address:
        postal_code = new_address('postalcode')

# Generated at 2022-06-12 01:38:21.828592
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test data provider."""
        pass

    provider = TestDataProvider(seed=0)

    with provider.override_locale(locales.EN) as provider:
        assert provider.locale == locales.EN

    assert provider.locale is None

# Generated at 2022-06-12 01:38:26.965719
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    p = Person()

    with p.override_locale('ru') as pp:
        assert pp.full_name() != p.full_name()

    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:53.955957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import CURRENCY_CODES, LOCALE_CODES
    from mimesis.providers.currency import Currency

    provider = Currency(seed=42)
    currency1 = get_random_item(provider._data, provider.random)
    assert currency1 not in CURRENCY_CODES.EN_US
    with provider.override_locale(locales.EN_US) as provider:
        currency2 = get_random_item(provider._data, provider.random)
    assert currency2 in CURRENCY_CODES.EN_US
    assert currency2 == provider.get_current_locale()
    assert currency2 == LOCALE_CODES.EN_US

# Generated at 2022-06-12 01:38:55.870714
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider('ja')
    bdp.override_locale('ru')

# Generated at 2022-06-12 01:39:04.256181
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._data = {self.locale: 'Test'}

        def __str__(self) -> str:
            return 'Test'

    provider = Provider()

    with provider.override_locale(locales.EN):
        assert provider.locale == locales.EN
    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:08.356507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale."""
    from mimesis.providers.address import Address
    address = Address()
    with address.override_locale(locales.EN) as address:
        assert address.locale == locales.EN
    assert address.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:16.630729
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method 'override_locale' of class BaseDataProvider"""
    class TestProvider(BaseDataProvider):
        """Test class BaseDataProvider"""
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            """Initialize attributes for data providers."""
            super().__init__(locale=locale)

    provider = TestProvider()
    with provider.override_locale(locale='ru') as test_provider:
        assert test_provider.get_current_locale() == 'ru'



# Generated at 2022-06-12 01:39:20.937738
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    # Check that provider overrides current locale
    # without error while executing code in context manager
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

# Mocked data for method _pull of class BaseDataProvider

# Generated at 2022-06-12 01:39:31.172985
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):

        def __init__(self, locale: str = locales.EN) -> None:
            super().__init__(locale)

    class B(BaseProvider):
        pass

    instance = A(locales.EN)
    assert instance.get_current_locale() == locales.EN

    with instance.override_locale(locales.RU):
        assert instance.get_current_locale() == locales.RU

    assert instance.get_current_locale() == locales.EN

    instance = B(locales.EN)
    with pytest.raises(ValueError):
        instance.override_locale()

# Generated at 2022-06-12 01:39:36.090814
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.en import Person

    p = Person()
    with p.override_locale('ru') as russian:
        assert russian is p
        assert russian.locale == 'ru'
        assert russian != 'en'
        assert russian == 'ru'
    assert p.locale == 'en'
    assert p != 'ru'
    assert p == 'en'

# Generated at 2022-06-12 01:39:44.972280
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def test_function():
        """Test function."""
        return True
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:54.516613
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    default_locale = locales.DEFAULT_LOCALE
    custom_locale = locales.EN

    class CustomProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get_current_locale(self) -> str:
            return self.locale

    # without context manager
    provider = CustomProvider(locale=custom_locale)
    assert provider.get_current_locale() == custom_locale

    # with context manager, but with default locale
    with provider.override_locale() as p:
        assert p.get_current_locale() == default_locale

    # with context manager and custom locale

# Generated at 2022-06-12 01:40:43.185820
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import random
    import pytest

    from mimesis.builtins import Code
    from mimesis.providers.social import SocialNetwork
    from mimesis.providers.datetime import Datetime

    class ProviderConfused(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

        def _override_locale(self, locale):
            pass

    with pytest.raises(ValueError):
        ProviderConfused().override_locale()

    class TestProv:
        def __init__(self, locale='en'):
            self.locale = locale

    with pytest.raises(AttributeError):
        TestProv().override_locale()


# Generated at 2022-06-12 01:40:52.664389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self):
            super().__init__(locale=locales.EN)
            self._datafile = 'testfile.json'
            self._pull()

        def get_test_data(self, key: str) -> Any:
            return self._data[key]

    p = Provider()
    assert p.get_test_data('data') == 'English data'

    with p.override_locale(locales.RU):
        assert p.get_test_data('data') == 'Russian data'
        assert p.get_current_locale() == locales.RU

    assert p.get_test_data('data') == 'English data'
    assert p.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:41:03.224226
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider: Test method override_locale."""
    class Provider(BaseDataProvider):
        def __init__(self, locale='en'):
            self._datafile = 'test.json'
            super().__init__(locale=locale)

        def get_data(self):

            return self._pull()

    provider = Provider()

    @contextlib.contextmanager
    def test_override_locale(locale='ru'):
        """Context manager which allows overriding locale."""

# Generated at 2022-06-12 01:41:09.197951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

    instance = TestDataProvider()
    assert instance.locale == 'en'

    with instance.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert instance.locale == 'ru'

    assert instance.locale == 'en'

# Generated at 2022-06-12 01:41:16.214194
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Raising an error with correct message."""
    class Reg(BaseDataProvider):
        """Reg."""

    provider = Reg()

    with provider.override_locale():
        assert provider.locale == locales.EN

    with provider.override_locale(locales.DE):
        assert provider.locale == locales.DE

    with provider.override_locale(locale=locales.RU):
        assert provider.locale == locales.RU

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    provider = Reg()
    with provider.override_locale(locale=locales.RU):
        assert provider.locale == locales.RU



# Generated at 2022-06-12 01:41:18.320695
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    t = BaseDataProvider()
    try:
        with t.override_locale():
            pass
    except ValueError:
        pass

# Generated at 2022-06-12 01:41:25.230929
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Test(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'test_{}.json'.format(self.locale)
            self._pull()

        def get_locale(self) -> str:
            return self.locale

    test_ = Test()
    with test_.override_locale(locales.EN) as provider:
        assert provider.get_locale() == locales.EN

    with test_.override_locale(locales.DEFAULT_LOCALE) as provider:
        assert provider.get_locale() == locales.EN


# Generated at 2022-06-12 01:41:31.468797
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def check_provider(provider):
        assert provider.get_current_locale() == locale

    provider = BaseDataProvider()
    locales = [locales.EN, locales.ES, locales.RU, locales.UK]
    for locale in locales:
        with provider.override_locale(locale) as p:
            check_provider(p)
            check_provider(provider)

# Generated at 2022-06-12 01:41:34.931919
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of Class BaseDataProvider."""
    locale = locales.EN
    provider = BaseDataProvider()
    with provider.override_locale(locale=locale) as i_provider:
        assert i_provider.locale == locale
    assert provider.locale != locale

# Generated at 2022-06-12 01:41:37.497427
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    locale = locales.EN
    expected_result = 'Shannon'
    with Person('en').override_locale() as provider:
        result = provider.name()
    assert result == expected_result
    assert provider.get_current_locale() == locale

# Generated at 2022-06-12 01:43:16.162823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    def show_locale(provider, locale):
        """Print locale and value."""
        with provider.override_locale(locale):
            print(provider)

    import mimesis.builtins as builtins

    provider = builtins.Linux()
    print(provider)
    show_locale(provider, locales.UK)
    show_locale(provider, locales.RU)
    show_locale(provider, locales.UA)

# Generated at 2022-06-12 01:43:25.147035
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale."""
    class TestDataProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'test_data.json'

        def test_func(self):
            return self._data

    test_provider = TestDataProvider(locale='ru')
    test_provider.test_func()
    assert test_provider._data  # pylint: disable=protected-access
    assert test_provider._data['test'] == 'тест'  # pylint: disable=protected-access

    test_provider.override_locale('en')
    test_provider.test_func()
    assert test_provider._data  # pylint: disable

# Generated at 2022-06-12 01:43:30.690992
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_fruit(self):
            return self._data['fruits']['apple']

    provider = TestProvider()
    provider.get_fruit()
    assert provider.get_fruit() == 'apple'
    with provider.override_locale('ru'):
        provider.get_fruit()
        assert provider.get_fruit() == 'яблоко'



# Generated at 2022-06-12 01:43:33.497837
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru') as loc:
        assert loc.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:34.513904
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert """test""" != """test"""
    assert """test""" != """test"""

# Generated at 2022-06-12 01:43:44.993505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.datetime import Datetime
    from mimesis.builtins.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.builtins.text import Text

    for provider in (Datetime(), Numbers(), Person(), Text()):
        print(f"\nProvider: {provider}")
        if hasattr(provider, 'locale'):
            print(f"Current locale: {provider.locale}")
            with provider.override_locale(locales.DE):
                print(f"DE locale: {provider.locale}")
            print(f"Back to current locale: {provider.locale}")
        else:
            print("Not locale dependent")


# Generated at 2022-06-12 01:43:51.759146
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    a = BaseDataProvider()
    a.get_current_locale = lambda: locales.EN

    @contextlib.contextmanager
    def OverrideLocale():
        """Context manager for code."""
        yield a
    a.override_locale = OverrideLocale

    with a.override_locale('ru'):
        locale = a.get_current_locale()
        assert locale == 'ru'

    with a.override_locale(locales.EN):
        locale = a.get_current_locale()
        assert locale == locales.EN



# Generated at 2022-06-12 01:43:53.863582
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    person = BaseDataProvider(locale='ru')
    name = person.full_name(gender='female')

    with person.override_locale('en'):
        assert name != person.full_name(gender='female')



# Generated at 2022-06-12 01:43:56.610617
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class BaseDataProvider."""
    provider = BaseDataProvider()
    with provider.override_locale('ru') as p:
        assert provider == p
        assert p.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:44:01.373304
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'