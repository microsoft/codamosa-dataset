

# Generated at 2022-06-12 01:35:59.598774
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()
    locale_value = 'en'
    with data_provider.override_locale(locale_value) as data_provider:
        assert data_provider.get_current_locale() == locale_value
    assert data_provider.get_current_locale() != locale_value
    
test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:36:05.946099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def _pull(self, datafile: str = 'data.json') -> Dict[str, str]:
            return super()._pull(datafile)

    m = MyProvider(locale='en-US')
    with m.override_locale(locale='en-GB') as m2:
        assert m2.get_current_locale() == 'en-GB'
    assert m.get_current_locale() == 'en-US'

# Generated at 2022-06-12 01:36:14.611030
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Dataset(BaseDataProvider):
        def __init__(self, locale='en'):
            self._datafile = 'dataset.json'
            super().__init__(locale=locale)

        def get_color_name(self):
            return self.random.choice(list(self._data['color_name'].keys()))

    dataset = Dataset(locale='ru')
    assert dataset.get_color_name() in list(dataset._data['color_name'])

    with dataset.override_locale('en'):
        assert dataset.get_color_name() in list(dataset._data['color_name'])

    assert dataset.get_color_name() in list(dataset._data['color_name'])

# Generated at 2022-06-12 01:36:18.405862
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider()
    with p.override_locale('en'):
        p.get_current_locale()
    with p.override_locale('ru'):
        p.get_current_locale()


# Generated at 2022-06-12 01:36:22.281772
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Override of locale for class BaseDataProvider
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('uk') as uk_person:
        assert uk_person.get_current_locale() == 'uk'
        assert person.get_current_locale() == 'en'
        assert person.full_name() != uk_person.full_name()
    assert person.full_name() != uk_person.full_name()

# Generated at 2022-06-12 01:36:33.037555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

    class B(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

    class C(BaseProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(seed=seed)

    a = A()
    b = B()
    c = C()

    assert a.locale == locales.DEFAULT_LOCALE
   

# Generated at 2022-06-12 01:36:44.459576
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__(locale='en')

        def _pull(self):
            self._data = {
                'foo': 'bar',
                'bar': 'foo',
            }

    test_provider = TestProvider()
    with test_provider.override_locale('ru') as pro:
        assert pro._pull.cache_info().misses == 1
        assert pro._pull.cache_info().hits == 0
        assert pro.get_current_locale() == 'ru'

        with pro.override_locale('en'):
            assert pro._pull.cache_info().misses == 2
            assert pro._pull.cache_info().hits == 0

# Generated at 2022-06-12 01:36:50.841873
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Localized(BaseDataProvider):
        def __init__(self, locale='en', seed=None):
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self):
            return self.locale

    l = Localized()
    assert l.get_current_locale() == 'en'

    with l.override_locale('ru') as rl:
        assert rl.get_current_locale() == 'ru'

    assert l.locale == 'en'

# Generated at 2022-06-12 01:37:00.310810
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    values = [('en', None), ('ru', 'Тестовый провайдер'), ('zh', '测试提供商')]
    class TestProvider(BaseDataProvider):
        def __str__(self):
            # test method of BaseDataProvider
            with self.override_locale('ru') as provider:
                data = provider.__str__().replace(' ', '  ')

            return data

    provider = TestProvider()

    for locale, value in values:
        provider._override_locale(locale)
        assert provider.__str__() == value

# Generated at 2022-06-12 01:37:06.845218
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDP(BaseDataProvider):
        pass
    dp = BaseDP()
    with dp.override_locale() as _:
        assert dp.locale == 'en'
    assert dp.locale == 'en'
    with dp.override_locale('ru') as _:
        assert dp.locale == 'ru'
    assert dp.locale == 'en'

# Generated at 2022-06-12 01:37:26.093826
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

    provider = TestProvider(locale=locales.DEFAULT_LOCALE, seed=42)

    with provider.override_locale(locales.DEFAULT_LOCALE):
        provider.locale = locales.DEFAULT_LOCALE

    with provider.override_locale(locales.DEFAULT_LOCALE):
        provider.locale = locales.EN

    with provider.override_locale(locales.EN):
        provider.locale = locales.EN

# Generated at 2022-06-12 01:37:31.466945
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale of class BaseDataProvider."""
    from mimesis import Person
    person = Person('zx')
    first_name = person.name()
    with person.override_locale('wz'):
        second_name = person.name()
    assert first_name != second_name

# Generated at 2022-06-12 01:37:40.934702
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        _datafile = ''
        _data: JSON = {}

    provider = TestBaseDataProvider('ru')
    with provider.override_locale('en'):
        assert provider.get_current_locale() == locales.EN
        assert provider.locale == locales.EN
    assert provider.get_current_locale() == locales.RU
    assert provider.locale == locales.RU
    with provider.override_locale('en') as p:
        assert p.get_current_locale() == locales.EN
        assert p.locale == locales.EN
    assert provider.get_current_locale() == locales.RU
    assert provider.locale == locales.RU

# Generated at 2022-06-12 01:37:46.876223
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .address import Address
    from .builtins import Builtins
    from .datetime import Datetime
    from .person import Person
    from .text import Text

    providers = (
        Address,
        Builtins,
        Datetime,
        Person,
        Text
    )

    for provider in providers:
        provider = provider()
        try:
            with provider.override_locale(locales.RU):
                assert provider.get_current_locale() == locales.RU
        except ValueError:
            assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-12 01:37:51.001886
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test locale override in BaseDataProvider.

    Expected result:
    :class:`BaseDataProvider` with the specified locale.

    """
    with BaseDataProvider().override_locale(locales.RU) as provider:
        assert provider.locale == locales.RU

# Generated at 2022-06-12 01:37:57.944583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale."""
    from mimesis.providers.address.en import Address
    from mimesis.providers.address.ru import Address

    addresses = set()
    with Address(provider='en').override_locale():
        addresses.add(Address(provider='ru').address())

    with Address(provider='ru').override_locale():
        addresses.add(Address(provider='en').address())

    assert len(addresses) == 2

# Generated at 2022-06-12 01:38:07.336377
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider."""

    provider = BaseDataProvider()
    provider._pull = lambda x: None
    provider._datafile = 'test.json'
    provider.locale = 'en'
    with provider.override_locale('fr'):
        assert provider.locale == 'fr'

    assert provider.locale == 'en'

    with provider.override_locale():
        provider.locale == 'en'

    assert provider.locale == 'en'

    provider.locale = 'fr'

    with provider.override_locale():
        provider.locale == 'fr'

    assert provider.locale == 'fr'

# Generated at 2022-06-12 01:38:09.363815
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SampleProvider(BaseDataProvider):
        pass
    sample_provider = SampleProvider()
    with sample_provider.override_locale():
        pass



# Generated at 2022-06-12 01:38:19.500826
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    dt = Datetime()
    with dt.override_locale('ru') as ru_dt:
        assert ru_dt.get_current_locale() == 'ru'
        assert ru_dt._pull.cache_info().hits == 2, 'Всегда должно кешироваться два файла, чтобы переопределить локаль'
        with ru_dt.override_locale('en') as en_dt:
            assert en_dt.get_current_locale() == 'en'
            assert ru_dt.get_current

# Generated at 2022-06-12 01:38:27.024830
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class UnitTest(BaseDataProvider):
        """Unit class BaseDataProvider."""

        def __init__(self, *args, **kwargs):
            """Init class."""
            super().__init__(*args, **kwargs)
            self.locale = locales.EN

        def get_current_locale(self) -> Dict:
            """Get current locale."""
            return self.locale

    class UnitTest2(BaseDataProvider):
        """Unit class BaseDataProvider."""

        def get_current_locale(self) -> Dict:
            """Get current locale."""
            return self.locale

    unit = UnitTest()
    unit2 = UnitTest2()
    assert unit.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:45.200639
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class _TestBaseDataProvider(BaseDataProvider):

        def __init__(self, locale='en', seed=None):
            super().__init__(locale, seed)

        def get_current_locale(self):
            return self.locale

    class _TestLocaleDependentDataProvider(_TestBaseDataProvider):

        def __init__(self, locale='en', seed=None):
            super().__init__(locale, seed)

    provider = _TestBaseDataProvider()
    locale = 'ru'
    with provider.override_locale(locale) as p:
        assert p.get_current_locale() == locale

# Generated at 2022-06-12 01:38:48.935347
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:00.981185
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import (
        Code,
        Color,
        Datetime,
        Internet,
        Person,
        Text,
    )
    from mimesis.enums import Gender
    from mimesis.utils import get_provider

    # TODO: Add tests for Code, Color, Datetime and Text after adding a
    # method get_locale in those providers.
    # https://github.com/lk-geimfari/mimesis/commit/3137cfd3e85f2bfdc3b908ad33acdda10fa7f0c1#r3137cfd3

    locale = 'ru'

    with Person('ru').override_locale(locale):
        assert get_provider(Person).get_current_locale() == locale


# Generated at 2022-06-12 01:39:11.959743
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale."""
    __tracebackhide__ = True
    from mimesis.providers.text import Text
    text_en = Text(seed=3)
    with text_en.override_locale('ru') as text_ru:
        assert text_ru.locale == 'ru'
        assert text_ru.word(seed=3) == 'постоянно'
    assert text_en.locale == 'en'

    text_ko = Text(seed=3, locale='ko')
    with text_ko.override_locale('ko') as text_ko_ko:
        assert text_ko_ko.locale == 'ko'
    assert text_ko.locale == 'ko'


# Generated at 2022-06-12 01:39:21.459105
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def get_current_locale(self):
            return self.locale

    with TestBaseDataProvider(locale='en') as test_base_data_provider:
        assert test_base_data_provider.get_current_locale() == 'en'

    with TestBaseDataProvider(locale='en') as test_base_data_provider:
        with test_base_data_provider.override_locale(locale='ru'):
            assert test_base_data_provider.get_current_locale() == 'ru'
        assert test_base_data_provider.get_current_locale() == 'en'




# Generated at 2022-06-12 01:39:28.173726
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialize object
    p = BaseDataProvider(locale='en')
    # Override a locale and get content of the file
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    # Return locale to default locale.
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:37.594039
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def get_current_locale(self):
            return self.locale
    t = Test()
    assert(t.locale == locales.EN)
    # next assert will raise KeyError because locale is not defined
    try:
        assert(t._data == {})
    except KeyError:
        pass
    # now let's check that it's impossible to change locale
    # for non-locale-dependent provider
    try:
        with t.override_locale('ru'):
            pass
        assert(False)
    except ValueError:
        assert(True)
    # base class has no any data

# Generated at 2022-06-12 01:39:41.725730
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'

    # Test with wrong locale.
    with provider.override_locale('xx') as p:
        assert p.locale == 'xx'

# Generated at 2022-06-12 01:39:52.304563
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # GIVEN
    # WHEN

    class MyProvider(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.current_locale = self.get_current_locale()

        def update_locale(self, locale: str = locales.EN):
            self.current_locale = self.get_current_locale()
            with self.override_locale(locale) as provider:
                self._override_locale(provider.locale)
                self.current_locale = self.get_current_locale()

    provider = MyProvider()

    # THEN
    assert provider.current_locale == locales.DEFAULT_LOCALE

    # WHEN
    provider.update_locale(locales.RU)



# Generated at 2022-06-12 01:39:56.226464
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    p = Person()
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'



# Generated at 2022-06-12 01:40:16.697284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale, seed)
            self._datafile = 'address.json'
            self._pull()

        def state(self):
            return self._data['state']

    provider = MyProvider(locales.RU)
    assert provider.state() == 'Воткинск'
    with provider.override_locale(locales.UK):
        assert provider.state() == 'Ненішчаний'
    assert provider.state() == 'Воткинск'

    provider = MyProvider(locales.EN, 'asd')

# Generated at 2022-06-12 01:40:22.666963
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class _TestProvider(BaseDataProvider):
        pass

    provider = _TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:40:27.654089
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale, seed)

    p = Provider('uk', 123)
    assert p.get_current_locale() == 'uk'

    with p.override_locale('us'):
        assert p.get_current_locale() == 'us'

    assert p.get_current_locale() == 'uk'

# Generated at 2022-06-12 01:40:39.396129
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""

    import unittest
    import unittest.mock
    from mimesis.builtins.geography import Geography

    class TestBaseDataProvider(BaseDataProvider):
        def test_method(self):
            return 'test'

    class TestGeography(Geography):
        def test_method(self):
            return 'test'

    class TestBaseDataProviderOverrideLocale(unittest.TestCase):

        def test_override_locale(self):
            example = TestBaseDataProvider()
            with self.assertRaises(ValueError):
                with example.override_locale('ru'):
                    pass

        def test_override_locale_context_manager(self):
            example = TestGeography()

            self.assertEqual

# Generated at 2022-06-12 01:40:49.013999
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseDataProviderTest(BaseDataProvider):
        __slots__ = ['__name']

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.__name = self.__class__.__name__

        @property
        def name(self) -> str:
            return self.__name

    provider = BaseDataProviderTest()
    with provider.override_locale('es') as es:
        assert es.locale == 'es'
        assert provider.locale == 'es'
        assert es.name == 'BaseDataProviderTest'

    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.name == 'BaseDataProviderTest'


# Generated at 2022-06-12 01:40:58.814481
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'en.json'
    
        def get_test(self, key: str) -> str:
            return self._data['test'][key]
    
    t = Test(locale=locales.EN_US)

# Generated at 2022-06-12 01:41:04.283426
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale=locale, seed=seed)

        def get_state(self):
            return self._data

    provider = MyProvider('ru', '123')

    with provider.override_locale(locale='ru') as pv:
        assert pv.get_state() == {}

    assert provider.get_state() == {}



# Generated at 2022-06-12 01:41:11.621157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class RandomDataProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(locale=locale, seed=seed)
        pass

    data_provider = RandomDataProvider('ru')

    with data_provider.override_locale() as provider:
        assert provider.get_current_locale() == 'en'

    assert data_provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:41:20.949240
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test method BaseDataProvider.override_locale."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    en_person = Person(locale=locales.EN)
    ru_person = Person(locale=locales.RU)

    en_name = en_person.full_name(gender=Gender.MALE)
    ru_name = ru_person.full_name(gender=Gender.MALE)

    assert en_name != ru_name

    with en_person.override_locale(locales.RU):
        en_ru_name = en_person.full_name(gender=Gender.MALE)
        assert en_ru_name == ru_name

# Generated at 2022-06-12 01:41:24.845136
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code

    code = Code()
    with code.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert isinstance(provider, Code)
    assert code.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:41:35.834976
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider(locale='en')
    with p.override_locale(locale='ru'):
        assert p.locale == 'ru'
    assert p.locale == 'en'

# Generated at 2022-06-12 01:41:44.459431
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        """Dummy class for testing."""

        class Meta:
            """Dummy class for testing."""

            locale = locales.EN

    provider = TestProvider(locales.RU)

    assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:41:46.380652
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='ua')

    with provider.override_locale('ua'):
        pass

    with provider.override_locale('ru'):
        pass

# Generated at 2022-06-12 01:41:51.567813
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider class, override_locale method."""
    class Provider(BaseDataProvider):
        pass

    provider = Provider()
    with provider.override_locale('en') as _:
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:41:57.488490
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass
    tp = TestProvider()

    with tp.override_locale(locales.EN):
        assert tp.locale == locales.EN

    with tp.override_locale(locales.RU):
        assert tp.locale == locales.RU

    class TestProviderLocale:
        def __init__(self, locale: str = locales.RU) -> None:
            self.locale = locale

        def get_current_locale(self) -> str:
            return self.locale

    tp_locale = TestProviderLocale()

    with tp_locale.override_locale(locales.EN):
        assert tp_locale.locale == locales.EN


# Generated at 2022-06-12 01:42:04.584723
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test Context manager which allows overriding current locale.

    Temporarily overrides current locale for
    locale-dependent providers.
    """
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person('fr')

    assert person.locale == 'fr'
    with person.override_locale('es') as provider:
        assert provider.locale == 'es'
        assert person.name() != provider.name()

    assert person.name() != provider.name()
    assert person.locale == 'fr'

# Generated at 2022-06-12 01:42:09.742733
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code

    def check_code(code: Code, check_language: str) -> None:
        for langue in code.languages:
            assert code.language == langue

            if langue == check_language:
                assert code.language == langue
                assert code.language == check_language
            else:
                assert code.language != langue
                assert code.language != check_language

    with BaseDataProvider().override_locale(locales.EN) as code:
        check_code(code, locales.EN)

    with BaseDataProvider().override_locale(locales.RU) as code:
        check_code(code, locales.RU)

# Generated at 2022-06-12 01:42:16.912319
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.datetime import Datetime
    datetime = Datetime(locale='ru')

    with datetime.override_locale('en') as dt:
        assert dt.get_current_locale() == 'en'
        assert dt._data['month_name']['01'] == 'January'

    assert datetime.get_current_locale() == 'ru'
    assert datetime._data['month_name']['01'] == 'Январь'

# Generated at 2022-06-12 01:42:26.551296
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Person(BaseDataProvider):
        """Person data provider."""

        class Meta:
            """Class Meta."""

            name = 'persons'

        def full_name(self, pattern: str = None) -> str:
            """Get full name.

            :param pattern: Pattern.
            :return: Full name.
            """
            # Needed to make it work.
            self._pull()

            pattern = self.random.choice(self._data['patterns']['full_name'])
            return pattern.format(**{
                'last_name': self.last_name(),
                'first_name': self.first_name(),
                'middle_name': self.middle_name(),
            })


# Generated at 2022-06-12 01:42:32.413923
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self):
            return self.locale

    provider = TestProvider('en')

    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:42:53.121188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender, Property
    from mimesis.providers.person import Person
    from mimesis.providers.property import Property

    person = Person()
    prop = Property(Property.DEFAULT_DATA)

    with person.override_locale('ru', seed=123456789) as person:
        gender = person.gender(gender=Gender.MALE)
        assert gender == 'Мужской'

        with prop.override_locale('ru') as prop:
            assert prop.currency() == 'RUB'

        assert person.currency() == 'USD'

        assert person.gender() == 'Мужской'

    assert person.gender() == 'Male'

   

# Generated at 2022-06-12 01:42:59.538469
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestClass(BaseDataProvider):
        def get_current_locale(self):
            return 'en'
    tc = TestClass()
    with tc.override_locale('kk') as overridden:
        assert overridden.get_current_locale() == 'kk'
        assert tc.get_current_locale() == 'en'
    assert tc.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:03.852727
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        """A simple provider."""

        def __init__(self, locale, seed=None):
            super().__init__(locale=locale, seed=seed)

        def randomize(self):
            return self.random.getrandbits(32)

    provider = Provider('uk')
    assert provider.randomize() == 1614137881

    with provider.override_locale('ru'):
        assert provider.randomize() == 1614137881

# Generated at 2022-06-12 01:43:12.866051
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """This method will test the context manager of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """This is a class for testing."""
        def __init__(self, locale: str = 'en', seed: int = None):
            super().__init__(locale=locale, seed=seed)
            self.__datafile = 'dates.json'

        @property
        def datafile(self):
            return self.__datafile

    provider = TestProvider()
    with provider.override_locale('de') as provider:
        assert provider.locale == 'de'
        assert provider.datafile == 'dates.json'
        assert provider.random.randint() != 0
    assert provider.locale == 'en'
    assert provider.random.randint() == 0


# Generated at 2022-06-12 01:43:17.168325
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test data provider."""

    p = TestDataProvider()
    with p.override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN

    assert p.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:43:21.221551
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider.override_locale('ru') as bdp:
        assert bdp.get_current_locale() == 'ru'
        assert str(bdp) == 'BaseDataProvider <ru>'

test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:43:26.176036
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override locale."""
    class Test(BaseDataProvider):
        """Test class."""
        _datafile = 'test.json'

        def get_data(self, key: str = '') -> Any:
            """Return Random data using lru_cache.

            :param key: Key of JSON.
            :return: Data.
            """
            self._pull()
            return self._data[key]

    test = Test()
    with test.override_locale('ru'):
        assert test.get_data('test') == 'Тест'

    assert test.get_data('test') != 'Тест'

# Generated at 2022-06-12 01:43:31.684710
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class SubBaseDataProvider(BaseDataProvider):

        def some_method(self):
            return 'foo'

    provider = SubBaseDataProvider()
    with provider.override_locale('en'):
        assert provider.some_method() == 'foo'
    with provider.override_locale('ru'):
        assert provider.some_method() == 'foo'


# Generated at 2022-06-12 01:43:40.172687
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Food(BaseDataProvider):
        def __init__(self):
            super().__init__(locale='en')
            self._datafile = 'food.json'

        def food(self):
            return self._data

    with Food().override_locale('ru'):
        assert Food().food()['vegetables']['баклажан'] == 'eggplant'

        with Food().override_locale('en'):
            assert Food().food()['vegetables']['баклажан'] == 'eggplant'
            assert Food().food()['vegetables']['eggplant'] == 'eggplant'

# Generated at 2022-06-12 01:43:44.812880
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='ru_RU').override_locale(locale='ru') as b:
        assert b.get_current_locale() == 'ru'

    with BaseDataProvider(locale='de').override_locale(locale='ru_RU') as b:
        assert b.get_current_locale() == 'ru_RU'

# Generated at 2022-06-12 01:43:59.969076
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import PaymentSystems
    instance = PaymentSystems(locale='ru')
    assert instance.name() == 'WebMoney'
    with instance.override_locale(locale='fr'):
        assert instance.name() == 'Klarna'
    assert instance.name() == 'WebMoney'
    # TODO: Add test for raising ValueError
    # TODO: Add test for exception NonEnumerableError

# Generated at 2022-06-12 01:44:07.364750
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass
    t = TestProvider()
    locale = getattr(t, 'locale', locales.DEFAULT_LOCALE)
    assert locale == locales.DEFAULT_LOCALE
    with t.override_locale(locale='ru') as t:
        assert t.locale == 'ru'
    assert locale == locales.DEFAULT_LOCALE
    assert t.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:44:16.019354
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Fake provider.

        This provider has locale dependent.
        """

        def __init__(self, locale='en') -> None:
            """Initialize attributes for class Provider.

            :param locale: Locale.
            """
            super().__init__(locale)

            self._datafile = 'provider.json'

        def get_foo(self) -> str:
            """Return foo from file provider.json.

            :return: The foo from provider.json.
            """
            return self._data.get('foo')

    provider = Provider('en')
    assert provider.get_foo() == 'foo'

    with provider.override_locale('ru') as fake_provider:
        assert fake_provider

# Generated at 2022-06-12 01:44:21.729869
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class test(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def get_current_locale(self):
            return self.locale

    with test() as t:
        # t.override_locale()
        assert t.get_current_locale() == t.locale, 'Unit test failed'

# Generated at 2022-06-12 01:44:30.577026
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check that provider can override locale."""
    class TestProvider(BaseDataProvider):
        """Docstring for TestProvider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = '{}.json'.format(self.__class__.__name__)
            self._pull()

    with TestProvider(locale=locales.RU).override_locale(locales.EN):
        assert TestProvider().get_current_locale() == locales.EN

    assert TestProvider().get_current

# Generated at 2022-06-12 01:44:34.442884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MockProvider(BaseDataProvider):
        """Mock class for BaseProvider"""
        pass
    mock_provider = MockProvider()
    with mock_provider.override_locale('ru') as tmp_provider:
        assert tmp_provider.locale == 'ru'
    assert mock_provider.locale == 'en'



# Generated at 2022-06-12 01:44:37.949380
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.first_name(gender=Gender.MALE) == 'Александр'
    assert person.first_name(gender=Gender.MALE) != 'Александр'


# Generated at 2022-06-12 01:44:42.672587
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)

        def __str__(self):
            locale = getattr(self, 'locale', locales.DEFAULT_LOCALE)
            return '{} <{}>'.format(self.__class__.__name__, locale)

    provider = Test()

    with provider.override_locale(locales.EN) as p:
        assert p.locale == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p.locale == locales.RU

    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:44:45.648917
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN) as provider_override:
        assert provider_override.locale == locales.EN

    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:44:47.012875
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-12 01:45:08.387553
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    _ = BaseDataProvider
    class A(_):
        def __init__(self, seed = None):
            super().__init__(seed = seed)
            self.locale = 'en'
        def func(self):
            return self.locale

    a = A()
    with a.override_locale(locale = 'de'):
        assert a.func() == 'de'
    assert a.func() == 'en'
    try:
        with a.override_locale():
            assert a.func() == 'en'
        assert a.func() == 'en'
    except ValueError as e:
        assert True
        return

    assert False


# Generated at 2022-06-12 01:45:17.354056
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Business

    with BaseDataProvider().override_locale():
        pass

    with BaseDataProvider().override_locale('ru'):
        pass

    with BaseDataProvider().override_locale('zh'):
        pass

    with Business().override_locale() as b:
        assert b.locale == 'en'

    with Business().override_locale('ru') as b:
        assert b.locale == 'ru'

    with Business().override_locale('zh') as b:
        assert b.locale == 'zh'

# Generated at 2022-06-12 01:45:21.990884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for the method override_locale of class BaseDataProvider."""
    from mimesis.data import DEFAULT_ABBREVIATIONS

    class MyDataProvider(BaseDataProvider):

        def get_abbreviation(self):
            return DEFAULT_ABBREVIATIONS.get(self.locale)

    p = MyDataProvider(locale='en')
    assert p.get_abbreviation() == 'A'

    with p.override_locale(locale='ru') as provider:
        assert provider.get_abbreviation() == 'А'

    assert p.get_abbreviation() == 'A'

# Generated at 2022-06-12 01:45:31.668116
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    addr = Address(seed=4)
    data = []
    with addr.override_locale('ru'):
        data.append(addr.region(expand=True))
        data.append(addr.region(expand=False))
    assert data[0] == 'Ставропольский край'
    assert data[1] == 'Ставропольский край'
    assert addr.region(expand=True) != 'Ставропольский край'
    data = []

# Generated at 2022-06-12 01:45:37.072904
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider."""

        class Meta:
            """Class metadata."""

            name = 'test_provider'

        def __str__(self) -> str:
            """Human-readable representation of locale."""
            return '{} <{}>'.format(
                self.__class__.__name__, self.locale)

    test = TestProvider()
    assert test.locale == 'en'
    with test.override_locale('es') as t:
        assert t.locale == 'es'
    assert test.locale == 'en'

# Generated at 2022-06-12 01:45:41.949783
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # pylint: disable=no-else-return
    fake = BaseDataProvider()
    fake._setup_locale('es')

    assert fake.locale == 'es'

    with fake.override_locale('de'):
        assert fake.locale == 'de'