

# Generated at 2022-06-12 01:36:09.636865
# Unit test for method override_locale of class BaseDataProvider

# Generated at 2022-06-12 01:36:20.219110
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__(seed = None)

        def get_data(self, key: str) -> Any:
            return self._data.get(key, None)

    provider = TestProvider()
    provider.__str__()
    provider.get_data('person')
    provider.get_current_locale()

    provider.__str__()
    provider.get_data('person')
    provider.get_current_locale()

    with provider.override_locale('ru') as provider:
        provider.__str__()
        provider.get_data('person')
        provider.get_current_locale()

    with provider.override_locale('') as provider:
        provider.__str__()
        provider.get_

# Generated at 2022-06-12 01:36:25.623089
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class BaseDataProvider method override_locale."""
    test_provider = BaseDataProvider()
    try:
        with test_provider.override_locale():
            raise ValueError('«{}» has not locale dependent'.format(
                test_provider.__class__.__name__))
    except ValueError:
        pass
    else:
        raise AssertionError('Should be raise ValueError')

# Generated at 2022-06-12 01:36:27.195526
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    pass

# Generated at 2022-06-12 01:36:32.738950
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale."""
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

    provider = TestProvider()
    locale = 'en'
    with provider.override_locale(locale):
        assert provider.get_current_locale() == locale



# Generated at 2022-06-12 01:36:34.287054
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """This is unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Business

# Generated at 2022-06-12 01:36:36.881142
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    tp = TestProvider()
    with tp.override_locale(locales.RU) as tp:
        assert tp.locale == locales.RU

# Generated at 2022-06-12 01:36:38.156156
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    #TODO: Should be done
    pass

# Generated at 2022-06-12 01:36:49.676998
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for override_locale method."""
    import random
    import string
    import time
    from mimesis import Person, addresses

    user_address = addresses.Address('en')
    user_address.seed(time.time())
    person = Person('en')
    person.seed(time.time())

    expected_result = '98, {}'.format(user_address.address())
    with user_address.override_locale():
        result = '{}, {}'.format(
            random.randint(1, 99), user_address.address(),
        )
        assert result == expected_result

    expected_result = 'Kate'
    with person.override_locale():
        result = person.name(gender='female')
        assert result == expected_result

# Generated at 2022-06-12 01:36:57.723282
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Creating an instance of class BaseDataProvider, overriding locale,
    getting locale and checking is the locale changed.

    :return: True, if locale is successfully changed, otherwise False.
    :rtype: bool.
    """
    class Test(BaseDataProvider):
        pass
    provider = Test()
    with provider.override_locale('ru'):
        locale = provider.get_current_locale()
    if locale == 'ru':
        return True
    else:
        return False

# Generated at 2022-06-12 01:37:10.126233
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    unit = BaseDataProvider()
    with unit.override_locale(locales.EN):
        assert unit.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:37:13.578938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale
    provider = TestProvider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:37:23.480122
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from json import loads

    result = {}

    class DataProvider(BaseDataProvider):
        _datafile = 'datasets.json'

        def get_data(self, key: str) -> Any:
            return self._data.get(key)

    provider = DataProvider(locale='en')
    with provider.override_locale('ru'):
        result = provider.get_data('goodbye')
        assert result == 'До свидания'

    result = provider.get_data('hello')
    assert result == 'Hello'

# Generated at 2022-06-12 01:37:28.962326
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    class TestProvider(BaseDataProvider):
        def __init__(self, locale):
            super().__init__(locale)
        def get_current_locale(self):
            return self.locale
    provider = TestProvider('en')

    # Act
    with provider.override_locale('ru') as provider:
        locale_ru = provider.get_current_locale()

    # Assert
    assert locale_ru == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:37:39.133895
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseProvider.override_locale."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, *args, **kwargs):
            self._datafile = 'country.json'
            super().__init__(*args, **kwargs)

        def get_country(self) -> str:
            """Get a country."""
            return self._data['countries']['by_alpha2_code']['RU']['name']

    test = TestProvider(locale='en')
    country = test.get_country()
    assert country == 'Russian federation'

    with test.override_locale('ru'):
        country = test.get_country()

# Generated at 2022-06-12 01:37:49.173518
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.identification import Identification
    from mimesis.providers.person.en import Person as PersonEn
    from mimesis.providers.person.ru import Person as PersonRu

    ident = Identification('en')
    ident_ru = Identification('ru')

    assert ident.get_current_locale() == 'en'
    assert ident_ru.get_current_locale() == 'ru'

    person = PersonEn(ident)
    person_ru = PersonRu(ident_ru)

    assert person.get_current_locale() == 'en'
    assert person_ru.get_current_locale() == 'ru'

    assert person.username() != person_ru.username()


# Generated at 2022-06-12 01:37:56.446641
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    provider = mimesis.builtins.SystemSpecification(seed=42)
    assert provider.locale == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU
        assert provider.get_current_locale() == locales.RU

    assert provider.locale == locales.EN
    assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-12 01:38:07.724730
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = ''):
            super().__init__(locale)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, str]:
            return self._data[key]

    provider = TestDataProvider(locales.EN)
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.RU) as data_provider:
        assert data_provider.get_current_locale() == locales.RU
        assert 'foo' in data_provider.get_data('test')
    assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:38:14.633791
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        _datafile = 'time.json'

        def __init__(self):
            super().__init__('ru')

    mdp = MyProvider()
    with mdp.override_locale('ru'):
        assert mdp.__str__() == "MyProvider <ru>"

    with mdp.override_locale('en'):
        assert mdp.__str__() == "MyProvider <en>"

# Generated at 2022-06-12 01:38:20.705305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    from mimesis.enums import Gender

    john = Person('en')
    marie = Person('fr')
    with Person().override_locale('fr') as person:
        assert person.full_name(gender=Gender.FEMALE) == marie.full_name(gender=Gender.FEMALE)
        assert person.full_name(gender=Gender.FEMALE) != john.full_name(gender=Gender.FEMALE)



# Generated at 2022-06-12 01:38:47.736439
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method of BaseDataProvider class."""
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    p = Person('en')
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.get_full_name(gender=Gender.MALE) != p.get_full_name(gender=Gender.MALE)
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:52.156465
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person, Address

    eng_person = Person(seed=42)

    address = Address()
    with address.override_locale('ru-RU'):
        address.city()
        ua_person = Person()
        assert address._data is not eng_person._data
        assert address._data is ua_person._data

# Testing attributes of class BaseDataProvider

# Generated at 2022-06-12 01:38:56.632102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Commerce

    def is_error():
        try:
            Commerce().override_locale()
            return False
        except ValueError:
            return True

    assert is_error()



# Generated at 2022-06-12 01:39:07.200144
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Checking method override_locale of class BaseDataProvider."""
    from mimesis.data import LocalizationProvider
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text

    address = Address(seed=42)
    text = Text(seed=42)
    origin = LocalizationProvider(seed=42)
    origin_country = address.country()
    origin_postcode = address.postcode()

    with address.override_locale('es') as addr:
        assert addr.country() != origin_country
        assert addr.postcode() != origin_postcode

    assert address.country() == origin_country
    assert address.postcode() == origin_postcode


# Generated at 2022-06-12 01:39:09.943053
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('pt-BR') as provider:
        assert provider.get_current_locale() == 'pt-BR'

# Generated at 2022-06-12 01:39:20.122729
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from os import environ
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    provider = Person('en', seed=environ.get('SEED'))
    provider_en = Internet(seed=environ.get('SEED'))
    assert provider.locale == 'en'
    assert provider_en.locale is None
    with provider.override_locale('cs'):
        assert provider.locale == 'cs'
        assert provider.full_name(gender=Gender.MALE) == 'Martin Voráč'
        assert provider.full_name(gender=Gender.FEMALE) == 'Anna Šafaříková'
        assert provider_en.full_name() == 'David Anderson'

# Generated at 2022-06-12 01:39:31.655407
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SomeProvider(BaseDataProvider):
        def __init__(self, locale=None, seed=None):
            super().__init__(locale, seed)
            self._datafile = 'some_data.json'

        def some_method(self):
            self._pull()
            return self._data.get('provider')


    provider = SomeProvider('en', None)
    assert provider.get_current_locale() == 'en'
    assert provider.some_method() == 'some_provider'

    provider = SomeProvider('ru', None)
    assert provider.get_current_locale() == 'ru'
    assert provider.some_method() == 'some_provider_ru'


# Generated at 2022-06-12 01:39:35.220759
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    with Person().override_locale('ru') as fake:
        assert fake.get_current_locale() == 'ru'
    assert Person().get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:38.670656
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.utils import HTML

    # Instantiate provider
    provider = HTML()

    html_tag = provider.tag()

    with provider.override_locale('ru') as html:
        tag = html.tag()

    # Check whether locale is changed or not
    assert html_tag == tag


# Generated at 2022-06-12 01:39:41.242178
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()
    with data_provider.override_locale('en') as provider:
        assert provider.locale == 'en'


# Generated at 2022-06-12 01:40:29.262927
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Builtin, Coin, Finance

    bp = Builtin(locale="en")
    assert bp.get_current_locale() == "en"
    with bp.override_locale(locale="ru"):
        assert bp.get_current_locale() == "ru"
    assert bp.get_current_locale() == "en"

    bp = Coin(locale="en")
    assert bp.get_current_locale() == "en"
    with bp.override_locale(locale="ru"):
        assert bp.get_current_locale() == "ru"
    assert bp.get_current_locale() == "en"

    bp

# Generated at 2022-06-12 01:40:39.816159
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def _setup_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            pass

    with Test().override_locale('ru') as t:
        assert 'ru' == t.get_current_locale()
    assert 'en' == Test().get_current_locale()

    class Test(BaseProvider):
        def _setup_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            pass
    try:
        with Test().override_locale('ru') as t:
            assert 'ru' == t.get_current_locale()
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-12 01:40:47.505978
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        class Meta:
            name = 'test.py'
        _data = {'a': 1, 'b': 2, 'c': 3}

        def get_data(self):
            return self._data

    provider = TestProvider(locale=locales.RU)

    with provider.override_locale(locales.DE):
        assert provider.locale == locales.DE
        assert provider.get_data() == TestProvider._data

    assert provider.locale == locales.RU
    assert provider.get_data() == TestProvider._data

# Generated at 2022-06-12 01:40:50.797168
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:40:56.651695
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class EnProvider(BaseDataProvider):
        def foo(self) -> str:
            return 'foo'

    provider = EnProvider()

    with provider.override_locale(locales.RU) as instance:
        assert instance.locale == locales.RU
        assert instance.foo() == 'foo'

    assert provider.locale == locales.EN

# Generated at 2022-06-12 01:41:06.467719
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Setup
    class SomeProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(locale, seed)


    class SomeProvider2(BaseDataProvider):
        def __init__(self, locale: str = locales.EN, seed: Seed = None):
            super().__init__(locale, seed)


    some_provider = SomeProvider()
    some_provider2 = SomeProvider2()

    with some_provider.override_locale(locales.RU) as p:
        # Exercise
        locale = p.locale

        # Verify
        assert locale == locales.RU

        # Cleanup
        del p

    # Verify
    assert some_provider.locale == locales.EN

# Generated at 2022-06-12 01:41:10.559428
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider.override_locale() - test method."""
    with BaseDataProvider().override_locale(locale='ru') as provider:
        assert provider.locale == 'ru'
        assert isinstance(provider, BaseDataProvider)

    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:41:12.574507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider('en')
    with bdp.override_locale('ru') as bdp:
        assert bdp.locale == 'ru'



# Generated at 2022-06-12 01:41:15.983482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as bp:
        assert bp.get_current_locale() == 'ru'
    assert bp.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:17.672209
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    provider.override_locale(locales.EN)
    assert(provider.get_current_locale() == locales.EN)


# Generated at 2022-06-12 01:42:56.758458
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    assert provider.locale is None

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() is None

# Generated at 2022-06-12 01:42:59.050000
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider('en')
    with p.override_locale('ru'):
        assert p.locale == 'ru'

# Generated at 2022-06-12 01:43:03.593596
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    :return: 
    '''
    import mimesis
    mimesis.seed(0)
    text = mimesis.Text()
    assert text.word() == 'час'
    with text.override_locale('uk'):
        assert text.word() == 'година'
    assert text.word() == 'час'



if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:43:11.133172
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_data = {'key': 'value'}

    class TestProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

        def _pull(self, datafile: str = '') -> Dict[str, str]:
            self._data = test_data

    provider = TestProvider()
    provider._pull()
    assert provider._data == {}
    with provider.override_locale():
        assert provider._data == {}
    assert provider._data == {}
    with provider.override_locale('ru'):
        assert provider._data == test_data
    assert provider._data == {}

# Generated at 2022-06-12 01:43:17.330678
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address

    address = Address()
    assert address.seed

    with address.override_locale(locales.RU) as new_address:
        assert new_address.seed == address.seed
        assert new_address.get_current_locale() == locales.RU

    assert address.get_current_locale() == locales.DEFAULT_LOCALE
    assert address.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:43:25.623685
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            self._datafile = '_test_data.json'

        def get_data(self):
            return self._data

    class TestProviderNonLocale(BaseDataProvider):
        def get_data(self):
            return 'No locale'

    provider = TestProvider()
    provider.locale = 'en'
    with provider.override_locale('uk') as p:
        assert p.locale == 'uk'
        assert p.get_data() == {'key': 'value'}

    assert provider.locale == 'en'
    assert provider.get_data() == {'key': 'value', 'key2': 'value2'}


# Generated at 2022-06-12 01:43:34.320580
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Location

    class _Fake(BaseDataProvider):
        """Fake provider class for test."""

        def __init__(self, locale: str = locales.EN, seed: Seed = None) -> None:
            """Initialize attributes for fake test.

            Args:
                :param str locale: Locale
                :param seed: Seed to all the random functions.
            """
            super().__init__(locale, seed)
            self._datafile = 'locale_dependent_data.json'
            self._pull()

        def get_location(self, *, region: Location = None) -> str:
            """Get a location.

            Args:
                :param region: Region.
                :return: Location.
            """
            key = self._validate_enum(region, Location)


# Generated at 2022-06-12 01:43:42.192113
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    expected = '<class \'mimesis.builtins.HerbivorousAnimal\'> <foo>'
    # AssertionError: assert False
    #assert True
    # AttributeError: 'HerbivorousAnimal' object has no attribute
    # 'locale'
    assert provider.locale != 'foobar'
    with provider.override_locale('foo'):
        assert str(provider) == expected



# Generated at 2022-06-12 01:43:50.682000
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ConcreteProvider(BaseDataProvider):
        def __init__(self, locale, *args, **kwargs):
            super().__init__(locale, *args, **kwargs)
        def get_current_locale(self):
            return self.locale

    provider = ConcreteProvider('en')
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    with provider.override_locale('de') as provider:
        assert provider.get_current_locale()

# Generated at 2022-06-12 01:43:59.021409
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Init BaseDataProvider instance
    class TestDataProvider(BaseDataProvider):
        def __init__(self):
            super(TestDataProvider, self).__init__(locale='en_EN')
            self._setup_locale(locale='en_EN')

    # Init BaseDataProvider instance
    test_data_provider = TestDataProvider()

    # Set locale for contextmanager
    locale = 'en'
    # Save value from provider
    data = test_data_provider.locale

    # Set new value for provider
    with test_data_provider.override_locale(locale):
        # Check contextmanager work
        assert test_data_provider.locale != data
        assert test_data_provider.locale == locale

    # Check value
    assert test_data_provider.locale