

# Generated at 2022-06-12 01:36:10.071533
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    from mimesis.exceptions import NonEnumerableError, UnsupportedLocale
    from mimesis.enums import Gender

    a = Address(locale='ru')
    assert a.locale == 'ru'
    with a.override_locale() as b:
        assert b.locale == 'ru'
    with a.override_locale('ja') as c:
        assert c.locale == 'ja'
        assert c.gender() == Gender.FEMALE
    assert a.locale == 'ru'
    with a.override_locale('fr') as d:
        assert d.locale == 'fr'

    def raises_func(provider, new_locale):
        with provider.override_locale(new_locale):
            pass

# Generated at 2022-06-12 01:36:13.809594
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    with Address().override_locale(locales.RU) as ru:
        locale = ru.get_current_locale()
        assert locale == locales.RU
    locale = ru.get_current_locale()
    assert locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:36:24.490402
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        def __init__(self, locale, seed):
            super(Foo, self).__init__(locale, seed)
            self.__locale = locale

        def get_locale(self):
            return self.__locale
    foo = Foo(locales.EN, seed=42)
    assert foo.get_locale() == locales.EN
    with foo.override_locale(locales.RU):
        assert foo.get_locale() == locales.RU
    assert foo.get_locale() == locales.EN
    try:
        with foo.override_locale(locales.RU):
            assert foo.get_locale() == locales.RU
            raise ValueError()
    except ValueError:
        assert foo.get

# Generated at 2022-06-12 01:36:28.459511
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class _Provider(BaseDataProvider):
        pass

    provider = _Provider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:36:32.737733
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider(locale='en')
    with p.override_locale('de') as r:
        assert p != r
        assert p.locale == 'en'
        assert r.locale == 'de'
    assert p.locale == 'en'



# Generated at 2022-06-12 01:36:41.519392
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider"""
    from mimesis.providers.person import Person

    test_person = Person('en', seed=1010)
    assert test_person.get_current_locale() == 'en'
    assert test_person.full_name() == 'Maryam Maynard'

    with test_person.override_locale('fr'):
        assert test_person.get_current_locale() == 'fr'
        assert test_person.full_name() == 'Angelo Tissier'

    assert test_person.get_current_locale() == 'en'
    assert test_person.full_name() == 'Maryam Maynard'

# Generated at 2022-06-12 01:36:46.683438
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Locales
    locale = Locales()
    locale.random = Random()
    locale.random.seed(42)

    with locale.override_locale(locale='ru'):
        assert locale.get_current_locale() == 'ru'

    assert locale.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:36:50.719802
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        pass

    provider = TestDataProvider(locale='ru')
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:36:55.740161
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE
    with provider.override_locale(locales.DE):
        assert provider.locale == locales.DE
    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:37:05.643223
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    try:
        from mimesis.providers.address import Address
        provider = Address(locale='ru')
        with provider.override_locale(locale='ua'):
            assert provider.get_current_locale() == 'ua'
    except AttributeError:
        from mimesis.providers.region import Region
        provider = Region(locale='ru')
        with provider.override_locale(locale='ua'):
            assert provider.get_current_locale() == 'ua'
    except UnsupportedLocale:
        provider = BaseDataProvider()
        with provider.override_locale(locale='en'):
            assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:37:24.602767
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class A(BaseDataProvider):

        def __init__(self, locale='ru'):
            super().__init__(locale=locale)

        def get_data(self, data_name):
            return self._data[data_name]

    a = A()

    a._pull(datafile='test.json')
    a.get_current_locale()
    with a.override_locale():
        a.get_current_locale()
        a.get_data('test_key')
    a.get_current_locale()

# Generated at 2022-06-12 01:37:28.439933
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method ``override_locale`` of class ``BaseDataProvider``."""
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    with provider.override_locale('ru') as test_provider:
        assert test_provider.locale == 'ru'

    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:37:36.355583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test overridden locale."""

    class Foo(BaseDataProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'foo.json'

        def get(self, key: str) -> Any:
            """Return a random element from the passed list."""
            return self._data[self.locale].get(key)

    foo = Foo('en')

    with foo.override_locale('ru'):
        result = foo.get('bar')
    assert result == 'baz'

    result = foo.get('bar')
    assert result == 'foo'

# Generated at 2022-06-12 01:37:39.133749
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale() as data:
        assert data.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:37:46.553047
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address as BaseAddress
    from mimesis.providers import Address as AddressProvider
    assert AddressProvider.__bases__ == (BaseDataProvider,)
    assert BaseAddress.__bases__ == (BaseProvider,)
    assert AddressProvider.get_current_locale() == 'en'
    assert BaseDataProvider(locale='ru').get_current_locale() == 'ru'
    assert BaseAddress().get_current_locale() == ''
    assert BaseDataProvider(locale='ru').override_locale() is not None
    assert BaseAddress().override_locale() is not None

# Generated at 2022-06-12 01:37:54.667900
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test unit for method override_locale."""
    bd_provider = BaseDataProvider(locale='en')
    # without context manager override_locale
    bd_provider._override_locale(locale='ru')
    assert bd_provider.get_current_locale() == 'ru'
    # with context manager override_locale
    with bd_provider.override_locale(locale='en'):
        assert bd_provider.get_current_locale() == 'en'



# Generated at 2022-06-12 01:37:58.271742
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider_ = BaseDataProvider()

    with BaseDataProvider_.override_locale(locale='fr') as BDP:
        assert BDP.get_current_locale() == 'fr'

    assert BaseDataProvider_.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:38:08.837603
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.builtins.en import English
    from mimesis.enums import Gender

    en = English('en')
    ru = English('ru')

    with pytest.raises(ValueError):
        with ru.override_locale() as p:
            pass

    with en.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.gender(Gender.MASCULINE) == 'Мужской'
        assert p.name(gender=Gender.FEMININE) == 'Елена'

    assert en.get_current_locale() == 'en'
    assert en.gender(Gender.MASCULINE) == 'Male'

# Generated at 2022-06-12 01:38:14.917020
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    A = Person('en')
    with A.override_locale('de') as B:
        assert A.locale == 'en'
        assert B.locale == 'de'
        assert A != B
        assert str(A) == 'Person <en>'
        assert str(B) == 'Person <de>'

# Generated at 2022-06-12 01:38:23.606125
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()
    with data_provider.override_locale('en'):
        assert data_provider.locale == 'en'

    with data_provider.override_locale('ru'):
        assert data_provider.locale == 'ru'

    with data_provider.override_locale('es'):
        assert data_provider.locale == 'es'

    with data_provider.override_locale():
        assert data_provider.locale == 'en'


# Generated at 2022-06-12 01:38:39.060263
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import (
        Address,
        Code,
        Datetime,
        Person,
    )
    from mimesis.enums import Gender

    default_locale = locales.DEFAULT_LOCALE
    origin_locale = locales.EN

    assert Person().gender() == Gender.MALE
    assert Address().building_number() == '98'
    assert Code().imei() == '35-83-61-84-66-09-65-87'
    assert Datetime().year() == '2015'

    with Address().override_locale(locale=default_locale) as provider:
        assert provider.building_number() == '98'

    with Address().override_locale() as provider:
        assert provider.building_number() == '98'


# Generated at 2022-06-12 01:38:49.429643
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale() of class BaseDataProvider."""
    class Simple(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__(locale=locale)
            self.provider = self.__class__.__name__

    instance = Simple()

    with instance.override_locale():
        assert instance.locale == locales.EN

    with instance.override_locale(locales.RU):
        assert instance.locale == locales.RU

    with instance.override_locale(locales.DE):
        assert instance.locale == locales.DE

    with instance.override_locale(locales.DE_AT):
        assert instance.locale == locales.DE_AT

# Generated at 2022-06-12 01:39:00.565713
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method «override_locale» of class «BaseDataProvider»."""
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.person import Person
    with Cryptographic.override_locale('de') as c:
        c.token()
    with Cryptographic.override_locale('ru') as c:
        c.token()
    with Cryptographic.override_locale('en') as c:
        c.token()
    with Cryptographic.override_locale('de') as c:
        c.token()
    with Person.override_locale('en') as p:
        p.full_name()


test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:39:03.976054
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('ru') as pp:
        assert pp.gender(Gender.MALE) == p.gender(Gender.MALE)
        assert pp.gender(Gender.FEMALE) == p.gender(Gender.FEMALE)

# Generated at 2022-06-12 01:39:05.571279
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as provider:
        assert provider.locale == 'ru'
    assert provider.locale == 'en'


# Generated at 2022-06-12 01:39:14.524641
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis import Person

    p = Person()
    with p.override_locale('ru') as russian_p:
        assert russian_p.get_current_locale() == 'ru'
    assert p.get_current_locale() == locales.EN

    assert getattr(Person, 'locale', None) is None
    with p.override_locale('ru') as russian_p:
        assert russian_p.first_name() == 'Александр'
    assert p.first_name() == 'John'

# Generated at 2022-06-12 01:39:22.889320
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.name = 'TestProvider'
            self._datafile = 'test.json'

        def get_foo(self) -> Dict[str, str]:
            self._pull()
            return self._data.get('foo')

    test_provider = TestProvider()
    with test_provider.override_locale(locales.RU):
        assert test_provider.get_current_locale() == locales.RU
        assert test_provider.get_foo() == 'Не в сети'
    assert test_provider.get_current

# Generated at 2022-06-12 01:39:35.064165
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method BaseDataProvider.override_locale."""
    social_networks = {
        'en': {
            'social_networks': {
                'twitter': 'Twitter',
                'facebook': 'Facebook',
                'instagram': 'Instagram',
            }
        },
        'ru': {
            'social_networks': {
                'tumblr': 'Tumblr',
            }
        }
    }

    class MyBaseDataProvider(BaseDataProvider):
        """Test class for BaseDataProvider.override_locale."""


# Generated at 2022-06-12 01:39:35.581928
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-12 01:39:37.877256
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MockProvider(BaseDataProvider):
        _datafile = 'mock'
    provider = MockProvider()
    with provider.override_locale('en'):
        pass


# Generated at 2022-06-12 01:39:55.518605
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Internet
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    r = RussiaSpecProvider(locale='ru')
    internet = Internet(locale='ru')
    with r.override_locale() as r_:
        assert r_.locale == 'ru'
        assert internet.random_email(domains=('ru',)) == r_.random_email(domains=('ru',))
    with r.override_locale(locale='en') as r_:
        with internet.override_locale(locale='en') as internet_:
            assert r_.locale == 'en'
            assert internet_.locale == 'en'
            assert r_.get_current

# Generated at 2022-06-12 01:40:02.635461
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""

    class TestDataProvider(BaseDataProvider):
        """Test class for method override_locale of class BaseDataProvider."""

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_locale(self) -> str:
            """Get current locale."""
            return self.locale

        def get_data(self) -> JSON:
            """Get test data."""
            return self._

# Generated at 2022-06-12 01:40:06.515091
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test that this code is not immediately raises error.
    with BaseDataProvider().override_locale(locales.EN):
        pass


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:40:09.501470
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc

    # Check that «override_locale» raises «AttributeError»
    # for built-in providers
    with Misc.override_locale() as misc:
        assert misc.get_current_locale() == Misc.get_current_locale()

    # Check that «override_locale» changes locale of
    # locale-dependent providers
    with Internet.override_locale('ru') as internet:
        assert internet.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:40:15.530636
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.services import Financial

    f = Financial()

    assert f.currency_code('RUB') == 'RUB'

    with f.override_locale('ru') as f:
        assert f.currency_code('RUB') == 'Руб'

    assert f.currency_code('RUB') == 'RUB'

# Generated at 2022-06-12 01:40:25.874432
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis import Personal, Person, Units
    from mimesis.enums import Gender

    # create randomizer
    person = Person('en')
    person_ru = Person('ru')
    personal = Personal('ru')
    unit = Units('en')

    count = 10
    names = [person.full_name(gender=Gender.FEMALE) for _ in range(count)]
    names_ru = [person_ru.full_name(gender=Gender.MALE) for _ in range(count)]
    personal_data = [personal.full_name(gender=Gender.MALE)
                     for _ in range(count)]
    units = [unit.weight() for _ in range(count)]

    # check is random values of different locales is not equal


# Generated at 2022-06-12 01:40:36.715414
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    foo = BaseDataProvider()

    with foo.override_locale('en') as bar:
        assert bar.get_current_locale() == 'en'
        with bar.override_locale('fr') as baz:
            assert baz.get_current_locale() == 'fr'
            assert isinstance(baz, BaseDataProvider)
            assert isinstance(baz, BaseProvider)

        assert bar.get_current_locale() == 'en'
        assert isinstance(bar, BaseDataProvider)
        assert isinstance(bar, BaseProvider)

    assert foo.get_current_locale() == 'en'
    assert isinstance(foo, BaseDataProvider)
    assert isinstance(foo, BaseProvider)

# Generated at 2022-06-12 01:40:40.225530
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        class Meta(BaseDataProvider.Meta):
            locales = ('en',)
            datafile = 'datafile.json'

    provider = Provider()

    with provider.override_locale('en'):
        assert provider.locale == 'en'


# Generated at 2022-06-12 01:40:48.643506
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider class."""
        def __init__(self, locale=locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)

        def some_method(self):
            return self.locale

    test_provider = TestProvider()
    with test_provider.override_locale(locale=locales.EN):
        assert test_provider.locale == locales.EN
        assert test_provider.some_method() == locales.EN
    assert test_provider.locale != locales.EN
    assert test_provider.some_method() != locales.EN

# Generated at 2022-06-12 01:40:53.878937
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    import mimesis.enums as enums

    p = Person()
    full_name = p.full_name(gender=enums.Gender.MALE)
    print(full_name)

    with p.override_locale('ru') as p_ru:
        full_name = p_ru.full_name(gender=enums.Gender.FEMALE)
        print(full_name)

    full_name = p.full_name(gender=enums.Gender.MALE)
    print(full_name)

# Generated at 2022-06-12 01:41:21.068456
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Business, person  # noqa
    provider = Business()
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU  # noqa
    assert provider.get_current_locale() == locales.EN

    provider = person.Person(person.GENDER)  # noqa
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU  # noqa
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:41:27.602452
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class InventName(BaseDataProvider):
        """Test class for override_locale method"""
        def __init__(self, locale=locales.EN):
            super().__init__(locale=locale)
            self.datafile = 'name.json'
            self._pull()

        def hello(self) -> str:
            """Test method"""
            return 'hello'

    provider = InventName(locale=locales.RU)
    provider.hello()

    with provider.override_locale(locales.EN) as provider:
        assert provider.hello() == 'hello'

    with provider.override_locale(locales.DE) as provider:
        assert provider.hello() == 'hello'


# Generated at 2022-06-12 01:41:34.896252
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = "test.json"
            self._pull()

        def get_data(self):
            return self._data

    provider = Provider(locales.EN)

    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'new': 'value'}

    assert provider.locale == locales.EN
    assert provider.get_data() == {'old': 'value'}

# Generated at 2022-06-12 01:41:42.270112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class CustomProvider(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(locale='en', **kwargs)
        def get_current_locale(self):
            return self.locale

    provider = CustomProvider()
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:48.999022
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider"""
    """
    @note: this is just an example, in order to have a test to pass
    """
    class A(BaseDataProvider):
        """Test class"""
        def __init__(self, locale: str = ''):
            super().__init__(locale=locale)

        def t(self) -> str:
            """Return locale attribute of self"""
            return self.locale

    locale = 'ru'
    a = A(locale=locale)
    assert a.locale == locale

    with a.override_locale(locale='en') as b:
        assert b.locale == 'en'
        assert b.t() == 'en'

    assert a.t() == locale

# Generated at 2022-06-12 01:41:54.968721
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    from mimesis.providers.datetime import Datetime

    p = Person(locale='it_IT')
    d = Datetime(locale='ru_RU')

    assert p.full_name() == 'Abigail Phineas'
    assert d.date() == '2019-01-05'

    with p.override_locale('ru_RU') as ru_p:
        assert ru_p.full_name() == 'Иннокентий Прокофьевич'
        assert d.date() == '2019-01-05'

    assert p.full_name() == 'Abigail Phineas'
    assert d.date() == '2019-01-05'

# Generated at 2022-06-12 01:42:00.256415
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # pylint disable=bad-super-call, protected-access
    class TestProvider(BaseDataProvider):

        def __init__(self, locale=locales.DEFAULT_LOCALE) -> None:
            self._data = {}
            self._data_dir = 'stub'
            self._locale = locale
            self._datafile = 'stub'
            self._pull()

        @property
        def locale(self) -> str:
            return self._locale

        @locale.setter
        def locale(self, value: str) -> None:
            self._locale = value

    class Stub:
        def __call__(self):
            pass

    provider = TestProvider(locales.EN)
    provider._override_locale = Stub()
    provider._override_locale()

# Generated at 2022-06-12 01:42:06.069166
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Cls(BaseDataProvider):
        pass

    cls = Cls(locale='de')

    with cls.override_locale('ru'):
        assert cls.get_current_locale() == 'ru'

    with cls.override_locale('en'):
        assert cls.get_current_locale() == 'en'

    assert cls.get_current_locale() == 'de'



# Generated at 2022-06-12 01:42:09.888336
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override locale in method override_locale."""
    provider = BaseDataProvider()

    for locale in locales.SUPPORTED_LOCALES:
        with provider.override_locale(locale):
            assert provider.get_current_locale() == locale

        assert provider.get_current_locale() != locale

# Generated at 2022-06-12 01:42:20.300583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Provider(BaseDataProvider):

        def __init__(self):
            super().__init__()
            self._default_locale = self.locale
            self._default_data = self._data

        def _pull(self, datafile: str = '') -> None:
            self._data = {'key': self.locale}

        def get_data(self) -> str:
            return self._data['key']

    provider = Provider()
    print(provider.get_current_locale())

    provider.override_locale('en_US')
    print(provider.get_current_locale())
    print(provider.get_data())

    provider.override_locale('fr')
    print(provider.get_current_locale())
    print(provider.get_data())

# Generated at 2022-06-12 01:43:11.251607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.data_file = 'person.json'
            self._pull()

        def get_first_name(self, gender: Gender) -> str:
            return self._get_data(
                'first_names', gender, formatter=self._title,
            )

        def get_last_name(self) -> str:
            return self._get_data(
                'last_names', formatter=self._title,
            )

    provider = Provider()


# Generated at 2022-06-12 01:43:14.297858
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    with Address().override_locale('ru') as provider:
        data = provider.postal_code()
    assert data
    assert isinstance(data, str)

# Generated at 2022-06-12 01:43:19.254153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

        def get_name(self):
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_name() == locales.RU

    assert provider.get_name() == locales.EN

# Generated at 2022-06-12 01:43:23.404514
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider

    with RussiaSpecProvider.override_locale(locale='ru') as rus:
        rus_locale = rus.get_current_locale()
    assert rus_locale == 'ru'

# Generated at 2022-06-12 01:43:32.750090
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

    p = Provider()
    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

    # test for wrong behavior
    with Provider().override_locale() as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'ru'

    # test for second use
    with Provider().override_locale('ru'):
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'
# test_BaseDataProvider_

# Generated at 2022-06-12 01:43:38.104857
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    # Test for method override_locale of class BaseDataProvider
    # by using of context manager
    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:47.468937
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for context manager «override_locale» of BaseDataProvider.

    The test checks that the locale is overridden.
    """
    class TestProvider(BaseDataProvider):
        _datafile = 'test.json'
        _data = {'en': {'foo': 1}}

        def __init__(self, locale: str, seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._pull()

        def generate(self) -> str:
            return self._data[self.locale]['foo']

    test_provider = TestProvider('en')
    assert test_provider.generate() == 1

    with test_provider.override_locale('uk'):
        assert test_provider.generate() == 1

# Generated at 2022-06-12 01:43:54.454350
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestClass(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale, seed)

        def _pull(self, datafile=''):
            locale = self.locale
            data_dir = self._data_dir

            if not datafile:
                datafile = self._datafile

            def get_data(locale_name: str) -> dict:
                file_path = Path(data_dir).joinpath(locale_name, datafile)
                with open(file_path, 'r', encoding='utf8') as f:
                    return json.load(f)

            separator = locales.LOCALE_SEPARATOR

            master_locale = locale.split(separator).pop(0)

# Generated at 2022-06-12 01:43:55.941278
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # TODO: Add unit tests for method override_locale of class BaseDataProvider
    assert False

# Generated at 2022-06-12 01:44:02.301340
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider_override_locale."""
    # It's important to note that the CacheClear not required,
    # because method _pull is a function with lru_cache.
    # Also it's important to note, the method is `reseed` or `seed`
    # must be called before the usage of class BaseDataProvider
    # and subclasses.
    provider1 = BaseDataProvider(locale='es', seed=0)
    provider2 = BaseDataProvider(locale='ru', seed=0)
    provider3 = BaseDataProvider(locale='en', seed=0)
    with provider1.override_locale('ru'):
        value = provider1.get_current_locale()
        assert value == 'ru'
        assert provider2.locale == 'ru'
    assert provider1.get_

# Generated at 2022-06-12 01:45:47.237623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SomeDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

    sp = SomeDataProvider()
    assert sp.locale == locales.EN

    with sp.override_locale('es') as p:
        assert p.locale == 'es'

    assert sp.locale == locales.EN