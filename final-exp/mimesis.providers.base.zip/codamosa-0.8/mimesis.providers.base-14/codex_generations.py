

# Generated at 2022-06-12 01:36:09.810202
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Currency
    from mimesis.data import CURRENCIES
    from mimesis.enums import CurrencyCode

    currency = Currency('en')
    with currency.override_locale('ru') as ru_currency:
        assert ru_currency.get_current_locale() == 'ru'

    ru_currency = currency.override_locale('ru')
    assert ru_currency.get_current_locale() == 'ru'
    assert ru_currency.get_currency_name(
        'RUB') == ru_currency._data['RUB']['name']

    assert currency.get_current_locale() == 'en'
    assert ru_currency.get_currency_name(
        'RUB')

# Generated at 2022-06-12 01:36:18.117319
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person

    class TestPerson(Person):
        def get_full_name(self) -> str:
            return self.get_name()

    person = TestPerson('en')

    expected = 'en'
    result = person.get_current_locale()
    assert result == expected

    with person.override_locale('ru') as pr:
        expected = 'ru'
        result = pr.get_current_locale()
        assert result == expected

    expected = 'en'
    result = person.get_current_locale()
    assert result == expected



# Generated at 2022-06-12 01:36:28.510141
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """

    :return: True if test is passed
    """
    class Prov(BaseDataProvider):
        """
        This is a base class for all data providers.
        """

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._data: JSON = {}
            self._datafile = ''
            self._setup_locale(locale)
            self._data_dir = Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-12 01:36:29.883607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert True


# Generated at 2022-06-12 01:36:34.884839
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ExampleProvider(BaseDataProvider):
        """Example for test provider."""
        pass

    example = ExampleProvider(locale='en')
    with example.override_locale(locale='ru') as ex:
        assert ex.locale == 'ru'

    assert example.locale == 'en'

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:36:43.785819
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Number(BaseDataProvider):
        def get_int(self):
            return self.random.randint(1, 1000)

    provider = Number(locale='foobar')
    with provider.override_locale(locale='en') as english_provider:
        result = english_provider.get_int()
        assert len(str(result)) == 4

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:36:50.317152
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Provider method should works fine with context manager
    provider = BaseDataProvider('ru')
    provider.get_current_locale() == 'ru'
    with provider.override_locale('en'):
        provider.get_current_locale() == 'en'
    provider.get_current_locale() == 'ru'
    # Provider method should raise exception when locale not set
    provider = BaseDataProvider()
    with pytest.raises(ValueError):
        with provider.override_locale('en'):
            pass



# Generated at 2022-06-12 01:36:55.588536
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.text import TextSpecification

    t = TextSpecification(seed=42)
    with t.override_locale('fr'):
        assert t.get_current_locale() == 'fr'
    assert t.get_current_locale() == 'en'

# Generated at 2022-06-12 01:36:57.086069
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    instance = BaseDataProvider()
    with instance.override_locale():
        assert instance.locale == 'en'

# Generated at 2022-06-12 01:37:05.682480
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    l1 = BaseDataProvider(seed=666)
    l2 = BaseDataProvider(seed=666, locale='ru')
    assert isinstance(l1, BaseDataProvider)
    assert isinstance(l2, BaseDataProvider)
    assert l1.get_current_locale() == l2.get_current_locale()
    with l1.override_locale(locale='ru'):
        assert l1.get_current_locale() == locales.RU
        assert 'Абакан' in l1.cities()

# Generated at 2022-06-12 01:37:22.535723
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""
    from mimesis.providers import Business
    bu = Business()
    with bu.override_locale(locale='en-US'):
        assert bu.get_current_locale() == 'en-US'
    assert bu.get_current_locale() == 'en'


# Generated at 2022-06-12 01:37:30.328231
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .personal import Name
    from .text import Text
    from .time import Time
    from . import locales
    from .typing import JSON
    from mimesis.enums import Gender
    n = 'Василий'
    t_ru = 'Василий Анатольевич успешно защитил диссертацию.'
    t_en = 'Vasily Anatolievich successfully defended the dissertation.'
    NAME = 'name'
    TIME = 'time'
    TEXT = 'text'
    LOCALE = 'locale'
    LOCALE_EN = 'en'
    LOCALE_RU = 'ru'
    DATE_

# Generated at 2022-06-12 01:37:37.861250
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str='en', seed: Seed=None, data: Dict[str, Any]={}):
            super().__init__(locale=locale, seed=seed)
            self._data = data

    provider = TestProvider(data={})
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as fr:
        assert fr.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-12 01:37:45.970895
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class SomeDataProvider(BaseDataProvider):

        def _pull(self):
            pass

        def get_current_locale(self):
            return self.locale

    data_provider = SomeDataProvider()

    with data_provider.override_locale('ru') as ru_data_provider:
        ru_locale = ru_data_provider.get_current_locale()
        assert ru_locale == locales.RU

    locale = data_provider.get_current_locale()
    assert locale == locales.EN

    data_provider = SomeDataProvider('ru')

    with data_provider.override_locale(locales.RU) as ru_data_provider:
        ru_locale = ru_data_provider.get_current_locale()

# Generated at 2022-06-12 01:37:49.451925
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.lorem import Lorem
    locale = 'ru'
    lorem = Lorem(locale)
    text = lorem.word()
    assert (lorem.word() == text)
    with lorem.override_locale(locales.EN):
        assert (lorem.word() != text)



# Generated at 2022-06-12 01:37:59.248706
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def get_current_locale(self):
            return self.locale

        def get_file_content_of_locale(self, locale):
            with self.override_locale(locale):
                return self._data

    provider = TestProvider()
    origin_locale = provider.get_current_locale()
    assert origin_locale == 'en'

    override_locale = provider.override_locale('ru')
    with override_locale as provider:
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

    # Test BaseDataProvider._pull

# Generated at 2022-06-12 01:38:05.317157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender

    provider = BaseDataProvider()
    with provider.override_locale('ru') as rp:
        assert rp.get_current_locale() == 'ru'
        assert rp.get_person_name(gender=Gender.MALE) == 'Антон'



# Generated at 2022-06-12 01:38:09.705340
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class SampleProvider(BaseDataProvider):

        def __init__(self):
            super().__init__(locale='es')

        def food(self):
            return self.random.choice(self._data['food'])

    provider = SampleProvider()
    assert provider.food() == 'ensalada'

    with provider.override_locale(locale='en'):
        assert provider.food() == 'salad'

# Generated at 2022-06-12 01:38:15.545363
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Variables(BaseDataProvider):
        pass

    with Variables() as variables:
        locale = 'ru'
        assert getattr(variables, 'locale') == locales.DEFAULT_LOCALE
        with variables.override_locale(locale) as xxx:
            assert getattr(xxx, 'locale') == locale

# Generated at 2022-06-12 01:38:23.129184
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class LocaleProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    provider = LocaleProvider(locales.EN)
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.EN_US) as p:
        assert p.get_current_locale() == locales.EN_US
    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:38:51.311070
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of BaseDataProvider."""
    from mimesis.builtins import NumericalCode
    code = NumericalCode()
    code.extend(['ABCDE'])
    with code.override_locale('es') as c:
        assert c.get_current_locale() == 'es'
        assert c.numerical_code() == 'LFJK'
        assert c._get_code() == 'ABCDE'
    assert code.get_current_locale() == 'en'
    assert code.numerical_code() == 'ABCDE'


# Generated at 2022-06-12 01:39:02.749345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method in BaseDataProvider class."""
    from mimesis.builtins import Code
    from mimesis.builtins import Programmer
    from mimesis.builtins import Transport
    from mimesis.enums import ProgrammingLanguage
    from mimesis.enums import TransportType

    language = ProgrammingLanguage.C_SHARP

    with Transport(seed=1000) as tr:
        transport = tr.transport(transport_type=TransportType.BUS)
        assert (isinstance(transport, str))

        with tr.override_locale(locales.RU):
            transport = tr.transport(transport_type=TransportType.BUS)
            assert (isinstance(transport, str))

        transport = tr.transport(transport_type=TransportType.BUS)
       

# Generated at 2022-06-12 01:39:08.272213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit tests for BaseDataProvider.

    Input:
        from mimesis.data import BaseDataProvider
        
    Output:
        pytest tests/test_data.py
    """
    provider = BaseDataProvider('en-au')

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    assert provider.locale == 'en-au'



# Generated at 2022-06-12 01:39:13.058623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:22.156307
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.enumerables import Gender
    from mimesis.builtins.person import Person
    from mimesis.exceptions import NonEnumerableError
    p = Person('en')
    with p.override_locale('ru') as ru_p:
        assert ru_p.gender(gender=Gender.MALE) == 'мужской'
        assert p.gender(gender=Gender.MALE) == 'male'
        assert ru_p.gender(gender=Gender.FEMALE) != 'male'
        assert ru_p.gender(gender=Gender.FEMALE) != 'мужской'
        assert ru_p.gender(gender=Gender.FEMALE) == 'женский'
        assert ru_p.occupation

# Generated at 2022-06-12 01:39:34.308067
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import DateTime, Person
    from mimesis.enums import Gender

    provider = Person('en')
    assert provider.get_current_locale() == 'en'
    assert provider.full_name() == 'Denise Mann'

    provider.reseed(1000)
    assert provider.full_name() == 'Adrian Powers'

    locale = 'ru'
    with provider.override_locale(locale) as provider:
        assert provider.get_current_locale() == locale
        assert provider.full_name() == 'Артур Халатов'

    assert provider.get_current_locale() == 'en'
    assert provider.full_name() == 'Denise Mann'

    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:39:37.913254
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en')

    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.get_current_locale() == 'ru'

    assert provider.locale == 'en'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:42.210637
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        __provider__ = 'test'
        __lang__ = 'en'
        def __init__(self, locale: str = 'en', seed: Seed = None):
            super().__init__(locale = locale, seed = seed)

    t = TestProvider()
    assert t.get_current_locale() == locales.EN
    with t.override_locale(locales.EN) as t:
        assert t.get_current_locale() == locales.EN
    assert t.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:39:50.003597
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method «override_locale»."""
    class Provider(BaseDataProvider):
        """Fake provider."""

        def __init__(self):
            """Initialize method."""
            super().__init__()

        def firebird(self) -> str:
            """Fake method for test."""
            return self.locale

    provider = Provider()
    assert provider.firebird() == locales.EN
    with provider.override_locale(locales.RU):
        assert provider.firebird() == locales.RU
    assert provider.firebird() == locales.EN


# Generated at 2022-06-12 01:39:58.655808
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method overwise_locale of class BaseDataProvider."""

    from mimesis.enums import Gender

    class DataProvider(BaseDataProvider):
        """Data provider for unit test."""

        class Meta:
            """Class Meta."""

            name = 'data_provider'

        def get_gender(self, gender: Gender = None) -> str:
            """Get gender.

            :param gender: Gender Enum.
            :return: Gender string.
            """
            return self._validate_enum(gender, Gender)

    provider = DataProvider()

    with provider.override_locale('ru'):
        assert provider.get_gender() == Gender.MALE.value

    with provider.override_locale(locales.EN):
        assert provider.get_gender() == Gender.MALE.value



# Generated at 2022-06-12 01:40:50.081318
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.data import Science
    provider = Science()
    with provider.override_locale(locales.RU) as provider_ru:
        locale = provider_ru.get_current_locale()
        assert locale == locales.RU
        assert provider.get_current_locale() == locales.EN

    locale = provider.get_current_locale()
    assert locale == locales.EN

    random = Random()
    provider = Science(seed=random.seed)
    with provider.override_locale(locales.RU) as provider_ru:
        locale = provider_ru.get_current_locale()
        assert locale == locales.RU
        assert provider.get_current_locale() == locales

# Generated at 2022-06-12 01:41:00.351055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def some_locale_dependent_method(self) -> str:
            return self.get_current_locale()

    provider = TestProvider(locale=locales.DEFAULT_LOCALE)
    with provider.override_locale(locales.DEFAULT_LOCALE) as locale_provider:
        assert locale_provider.locale == locales.DEFAULT_LOCALE
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        assert provider.some_locale_dependent_method() == locales.DEFAULT_LOCALE
   

# Generated at 2022-06-12 01:41:01.884793
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # get_provider().override_locale('ru')
    pass

# Generated at 2022-06-12 01:41:09.474691
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address
    ad = Address()
    print(id(ad)) #
    with ad.override_locale('en') as en:
        assert id(en) == id(ad)
        print(id(en))
        print(id(ad))
        assert en.locale == 'en'
        assert ad.locale == 'en'
    assert ad.get_current_locale() == 'ru'
    print(id(ad))
    print(id(en))
if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:41:14.748574
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import random
    import mimesis.data
    from mimesis.data import Person

    random.seed('mimesis')
    p = Person('ru')

    with p.override_locale('en') as pp:
        pass

    assert repr(p) == repr(pp)

    assert p.locale == 'ru'
    assert pp.locale == 'en'

    assert p.name() == 'Артемий Максимов'
    assert pp.name() == 'Catherine Gray'

# Generated at 2022-06-12 01:41:24.675900
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE,
                     seed=None):
            super().__init__(locale=locale,
                             seed=seed)

        def get_data(self, *args, **kwargs):
            return self._data

    dp = DataProvider(seed=0)
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE

    data = dp.get_data()

    with dp.override_locale(locales.EN) as dp:
        assert dp.get_current_locale() == locales.EN
        data_en = dp.get_data()

    assert data_en == data


# Generated at 2022-06-12 01:41:29.749296
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Email
    p = Email()
    assert str(p) == 'Email <en>'
    with p.override_locale('fr'):
        assert str(p) == 'Email <fr>'
    assert str(p) == 'Email <en>'

# Generated at 2022-06-12 01:41:37.248210
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider.
    
    See documentation for BaseDataProvider to know more about this method.
    """
    from mimesis.enums import Gender
    from mimesis.builtins import Address as Address_en
    from mimesis.providers.address.ru import Address as Address_ru
    from mimesis.providers.internet.ru import Internet as Internet_ru
    from mimesis.providers.number.ru import Number as Number_ru
    
    class Provider(object):
        """This is a fake class for test method of class BaseDataProvider."""
        
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            """Initialize attributes."""
            self.locale = locale

# Generated at 2022-06-12 01:41:41.161246
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    p = BaseDataProvider()
    with p.override_locale():
        pass
    with p.override_locale(locales.EN):
        pass
    with p.override_locale(locales.RU):
        pass

# Generated at 2022-06-12 01:41:48.546755
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, Code
    from mimesis.enums import Country

    addr = Address(locale='nl')
    code = Code()

    country = addr.country()
    with addr.override_locale(locale='en'):
        assert country != addr.country()

    assert addr.country() == country

    country = code.country()
    with code.override_locale(locale='uk'):
        assert country != code.country()

    assert code.country() == country

    country = addr.country()
    with addr.override_locale(locale='ru'):
        assert country != addr.country()

    assert addr.country() == country

    country = Country.US
    with addr.override_locale(locale='ru'):
        assert country != addr

# Generated at 2022-06-12 01:43:34.133062
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider.

    Test that override_locale method  overrides current locale and
    returns Context manager for with statement.

    :return: Nothing.
    """
    import time
    from mimesis import Person

    p = Person('ru')
    with p.override_locale('en'):
        assert p.locale == 'en'

    assert p.locale == 'ru'
    with p.override_locale('en'):
        assert p.locale == 'en'

    with pytest.raises(ValueError):
        with p.override_locale('en'):
            pass


# Generated at 2022-06-12 01:43:39.072524
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    prov = mimesis.builtins.Food

    with prov.override_locale(locales.EN):
        assert prov.locale == locales.EN
        assert prov.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:43:45.392657
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    person = Person(seed=12345)
    assert person.get_current_locale() == 'en'

    with person.override_locale('ru') as russian_person:
        assert russian_person.get_current_locale() == 'ru'

    with person.override_locale('be') as belorussian_person:
        assert belorussian_person.get_current_locale() == 'be'

    assert person.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:52.090310
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test provider."""

    class Provider(BaseDataProvider):

        def get_last_name(self) -> str:
            return '{}'.format(self.locale)

    p = Provider()
    assert p.get_last_name() == locales.DEFAULT_LOCALE
    assert p.locale == locales.DEFAULT_LOCALE

    p.locale = locales.EN
    with p.override_locale(locales.RU):
        p.get_last_name() == locales.RU

    assert p.locale == locales.EN



# Generated at 2022-06-12 01:43:59.192359
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Testing for method ``override_locale``."""
    from mimesis.providers import Business, Person
    from mimesis.enums import Currency, Gender

    b = Business()
    p = Person()
    with p.override_locale('ru') as person:
        assert person.currency() == Currency.RUBLE
        assert person.gender() == Gender.FEMALE

    with person.override_locale('en'):
        assert person.currency() == Currency.POUND
        assert person.gender() == Gender.MALE

    with b.override_locale('ru'):
        assert b.currency() == Currency.RUBLE

# Generated at 2022-06-12 01:44:07.408089
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person  # noqa: WPS433
    from mimesis.enums import Gender  # noqa: WPS433

    p = Person('en')
    assert p.locale == 'en'
    assert p.gender() == Gender.MALE

    with p.override_locale('ru') as new_p:
        assert new_p.locale == 'ru'
        assert new_p.gender() == Gender.MALE

    assert p.locale == 'en'
    assert p.gender() == Gender.MALE

# Generated at 2022-06-12 01:44:16.055139
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person, Address
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    with BaseDataProvider(locale='en') as base_data_provider_en:
        with base_data_provider_en.override_locale('ru'):
            assert base_data_provider_en.get_current_locale() == 'ru'
            person_ru = Person(locale='ru')
            gender = base_data_provider_en._validate_enum(
                Gender.MALE,
                Gender)
            assert person_ru.gender(gender=gender) == 'мужской'

# Generated at 2022-06-12 01:44:21.066208
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import datetime, time
    from mimesis.providers.computing import Computing

    with Computing('ru') as computer:
        assert computer.locale == 'ru'
        assert computer.get_timestamp() == time.time()

        with computer.override_locale('fr') as computer:
            assert computer.locale == 'fr'
            assert computer.get_timestamp() == time.time()

# Generated at 2022-06-12 01:44:28.885939
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    providers = [p for p in BaseDataProvider.__subclasses__()
                  if p.__name__.endswith('Provider')]
    for provider in providers:
        p = provider().override_locale(locale=locales.EN)
        assert p.get_current_locale() == locales.EN
        try:
            p.override_locale(locale=locales.RU)
        except AttributeError as err:
            assert "Has not locale" in str(err)
        p.override_locale(locale=locales.EN)
        assert p.get_current_locale() == locales.EN



# Generated at 2022-06-12 01:44:36.461376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.de import Address as Address_de
    from mimesis.en import Address as Address_en
    from mimesis.zh_CN import Address as Address_zh_CN

    # German locale
    provider = Address_de.de
    assert provider.get_current_locale() == locales.DE

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DE

    # English locale
    provider = Address_en.en
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.DE):
        assert provider.get_current_locale() == locales.DE

    assert provider.get_current_