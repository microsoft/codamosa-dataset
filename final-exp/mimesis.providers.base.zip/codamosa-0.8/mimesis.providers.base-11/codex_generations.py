

# Generated at 2022-06-12 01:36:06.090765
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.data import provincias
    with provincias.override_locale('es') as p:
        assert p.get_current_locale() == 'es'
        assert p.provincia() != provincias.provincia()
        assert p.provincia() == 'Málaga'

    assert provincias.get_current_locale() == 'en'
    assert provincias.provincia() == 'Almeria'

# Generated at 2022-06-12 01:36:13.248656
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import DateTime
    # Create DateTime provider for current locale
    provider = DateTime()

    assert isinstance(provider, DateTime) # check provider
    assert provider.locale == locales.DEFAULT_LOCALE # check provider locale

    new_local = locales.JA  # new locale -> Japanese locale
    with provider.override_locale(new_local) as p: # override locale
        assert p.locale == new_local # check locale in context

    assert provider.locale == locales.DEFAULT_LOCALE # check provider locale after exit context

# Generated at 2022-06-12 01:36:24.345598
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN) -> None:
            super().__init__(locale)
            self._datafile = 'dataprovider.json'
            self._pull()

        def get_data(self, key: str) -> Any:
            return self._data[key]

    data_provider = DataProvider(locale=locales.EN)
    # Test example
    with data_provider.override_locale(locales.RU):
        assert data_provider.get_current_locale() == locales.RU
        assert data_provider.get_data('name') == 'Иван Иванов'


# Generated at 2022-06-12 01:36:33.753413
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code

    code = Code()
    assert code.get_current_locale() == locales.DEFAULT_LOCALE
    with code.override_locale(locales.RU):
        assert code.get_current_locale() == locales.RU
    assert code.get_current_locale() == locales.DEFAULT_LOCALE

    code = Code(locales.RU)
    assert code.get_current_locale() == locales.RU
    with code.override_locale(locales.EN):
        assert code.get_current_locale() == locales.EN
    assert code.get_current_locale() == locales.RU

# Generated at 2022-06-12 01:36:44.894228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale()."""
    from mimesis.builtins import Address, AddressJA

    # Raise ValueError if provider does not have locale dependent
    with Address() as provider:
        provider.override_locale()

    with AddressJA() as provider:
        assert provider.get_current_locale() == locales.JA
        locale = provider.get_data('locale')
        assert locale == locales.JA
        with provider.override_locale():
            assert provider.get_current_locale() == locales.EN
            locale = provider.get_data('locale')
            assert locale == locales.EN
            assert provider.get_current_locale() == locales.JA

# Generated at 2022-06-12 01:36:55.740089
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

            self._datafile = 'testdata.json'
            self._pull()

        def get_data(self, key: str) -> str:
            """Get data from given key.

            :param key: Key of data.
            :return: Value of the key.
            """
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale('ru') as test_provider:
        assert test_provider.get_data('foo') == 'проверка'


# Generated at 2022-06-12 01:37:01.954747
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address

    provider = Address()
    result = provider.get_current_locale()
    assert result == locales.EN

    with provider.override_locale(locales.RU) as rp:
        assert rp.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:37:10.336154
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class User(BaseDataProvider):
        _datafile = 'personal.json'

        def get_data(self, **kwargs):
            return self._data['personal']

    class Address(BaseDataProvider):
        _datafile = 'address.json'

        def get_data(self, **kwargs):
            return self._data['address']

    user = User()
    address = Address()
    print (address._data)
    # print (address._pull())
    with user.override_locale('ru'):
        with address.override_locale('ru'):
            print (address._data)
            print (user)
            print (address)
            print (user.get_data())
            print (address.get_data())
            print (user.get_data())

# Generated at 2022-06-12 01:37:18.184156
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method `override_locale` of class `BaseDataProvider`."""
    RESULT = {
        'ko': {'value': 'ko-KR'},
        'en': {'value': 'en'},
        'zh': {'value': 'zh_Hant_TW'},
    }
    from mimesis import __version__ as version
    from mimesis.builtins import MetaBaseProvider
    from mimesis.builtins import Language
    TEST_DATA = {
        'ko': {'value': 'ko-KR'},
        'en': {'value': 'en'},
        'zh': {'value': 'zh_Hant_TW'},
    }

    class TestProvider(Language):
        _datafile = 'test.json'
        __version__ = version
        __author

# Generated at 2022-06-12 01:37:20.577285
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    with provider.override_locale('ru'):
        pass

# Generated at 2022-06-12 01:37:39.289143
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_data(self, data_dir: str, locale: str, datafile: str):
            locale_dir = Path(data_dir).joinpath(locale)
            file_path = locale_dir.joinpath(datafile)
            with open(file_path, 'r', encoding='utf8') as f:
                return json.load(f)

        def get_locale_data(self):
            return self.get_data(self._data_dir, self.locale, self._datafile)

    provider = TestProvider()
    with provider.override_locale('en'):
        locale_data = provider.get_locale_data()
        assert locale_data['codes']['country']['__default__'] == 'United States'

# Generated at 2022-06-12 01:37:44.615375
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Language

    lang = Language()
    langs = set(lang.get_languages())

    with lang.override_locale('es'):
        langs.update(lang.get_languages())

    assert 'english' in langs
    assert 'español' in langs

# Generated at 2022-06-12 01:37:55.582579
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DateTime(BaseDataProvider):
        pass
    date_time = DateTime('ru')
    assert date_time.locale == 'ru'
    assert date_time.get_current_locale() == 'ru'
    with date_time.override_locale('en') as dt:
        assert dt.locale == 'en'
        assert dt.get_current_locale() == 'en'
    assert date_time.locale == 'ru'
    assert date_time.get_current_locale() == 'ru'
    # Test when class don't have locale
    class Date(BaseDataProvider):
        pass
    date = Date()
    assert date.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:05.417419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    with p.override_locale('en'):
        assert p.gender() == Gender.MALE
        assert p.gender() == Gender.MALE
        assert p.gender(Gender.FEMALE) == Gender.FEMALE

        assert p.gender() == Gender.MALE
        assert p.gender() == Gender.MALE
        assert p.gender(Gender.FEMALE) == Gender.FEMALE

        assert p.name(gender=Gender.FEMALE).endswith('a')

# Generated at 2022-06-12 01:38:10.506315
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from pymimesis import Person
    with Person().override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.last_name() != ''
        assert provider.get_full_name() != ''
        assert provider.full_name() != ''
    with Person().override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.last_name() != ''
        assert provider.get_full_name() != ''
        assert provider.full_name() != ''

# Generated at 2022-06-12 01:38:21.582966
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.datetime import Datetime
    from mimesis.builtins.enums import Gender
    dt = Datetime()
    with dt.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU
        assert provider.date(pattern='DD.MM.YY') == '26.03.16'
        assert dt.get_current_locale() == locales.EN
        assert provider.date(pattern='DD.MM.YY') == '26.03.16'
        assert dt.date(pattern='DD.MM.YY') == '03/26/16'
    assert dt.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:38:30.756629
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.person import Person
    from mimesis.builtins import Person as PersonBuiltins
    from mimesis.builtins import ru as ru_builtins

    p1 = Person(locale=ru_builtins.locales.RU)
    p2 = Person(locale=ru_builtins.locales.RU)

    with p1.override_locale(PersonBuiltins.locales.EN):
        ru = p1.full_name()
        en = p1.full_name()

    assert ru != en
    assert ru == p2.full_name()

# Generated at 2022-06-12 01:38:34.045873
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def assertions(provider):
        assert provider.locale == 'zz'

    provider = BaseDataProvider(locale='zh')
    with provider.override_locale(locale='zz') as n_provider:
        assertions(n_provider)
    assert provider.locale == 'zh'
    with provider.override_locale('zz') as n_provider:
        assertions(n_provider)


# Generated at 2022-06-12 01:38:35.498535
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('ru') as pr:
        assert pr.locale == 'ru'

# Generated at 2022-06-12 01:38:41.308003
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en', seed=10)
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider, BaseDataProvider)

    with provider.override_locale(locale='ru') as p:
        assert p.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:56.091702
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test case for method override_locale of class BaseDataProvider."""
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    ge = Geo()
    inet = Internet()
    misc = Misc()
    num = Numbers()
    person = Person()
    text = Text()
    ident = Identifier()

    provs = [ge, inet, misc, num, person, text, ident]


# Generated at 2022-06-12 01:39:06.999134
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.identity import Identity
    from mimesis.providers.name import Name
    identity = Identity(seed=int(0))
    name = Name('en', seed=int(0))
    with name.override_locale('ru') as n:
        assert n.get_current_locale() == 'ru'
        assert n.full_name(gender=Gender.MALE) != name.full_name(gender=Gender.MALE)
        assert n.full_name(gender=Gender.MALE) == identity.full_name(gender=Gender.MALE)
    assert name.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:12.423612
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person

    person = Person('ru')
    person_en_us = Person(locale='en-US')

    with person.override_locale(locale='en-US') as new_person:
        assert person.get_current_locale() == 'en-US'
        assert new_person is person
        assert type(new_person) == type(person)
        assert person_en_us.full_name() == new_person.full_us_name()

    assert person.full_name() == person.full_russian_name()
    assert person.get_current_locale() == 'ru'

    with person.override_locale(locale='en-US') as new_person:
        assert person.get_current_locale() == 'en-US'

    assert person

# Generated at 2022-06-12 01:39:21.767204
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    data = {
        'a': {
            'b': {
                'c': ['d']
            }
        }
    }

    class TestDataProvider(BaseDataProvider):
        """Test class."""

        def __init__(self, data: JSON,
                     seed: int = None,
                     locale: str = 'en') -> None:
            """Initialize attributes."""
            super().__init__(seed=seed, locale=locale)
            self._data = data

        def get_data(self, *args) -> JSON:
            """Test function."""
            return self._data

    tdp = TestDataProvider(data=data.copy())
    tdp.get_data()

# Generated at 2022-06-12 01:39:25.908555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:39:36.015166
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en', seed=None):
            super().__init__(locale=locale, seed=seed)

        @property
        def foo(self):
            return getattr(self, '_foo', None)

        @foo.setter
        def foo(self, value):
            self._foo = value

        def bar(self):
            return 'bar'

    tp = TestProvider()
    with tp.override_locale('ru') as tp_ru:
        assert isinstance(tp_ru, TestProvider)
        assert tp_ru.foo is None
        tp_ru.foo = 'bar'
        assert tp_ru.foo == 'bar'
        assert tp_ru.bar() == 'bar'

# Generated at 2022-06-12 01:39:40.931536
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.providers.address import Address
    from mimesis.enums import Gender

    address = Address(locale='ru')
    with pytest.raises(ValueError):
        with address.override_locale('en'):
            pass
    address = Address(locale='uk')

    with address.override_locale('en'):
        address.full_address()
        address.street_address()
        address.postal_code()
        address.building_number()
        address.verbose_address()


# Generated at 2022-06-12 01:39:46.450333
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    with Person('ru').override_locale('ru-RU') as ru:
        assert ru.get_current_locale() == 'ru-ru'
    assert Person('ru').get_current_locale() == 'ru'


# Generated at 2022-06-12 01:39:50.874048
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    class TestProvider(BaseDataProvider):
        def get_current_locale(self):
            return self.locale
    test_provider = TestProvider()

    # Act
    with test_provider.override_locale('de'):
        locale = test_provider.get_current_locale()

    # Assert
    assert locale == 'de'

# Generated at 2022-06-12 01:39:54.049296
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    d = BaseDataProvider()
    assert d.locale == locales.DEFAULT_LOCALE
    with d.override_locale(locales.EN):
        assert d.locale == locales.EN
    assert d.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:40:19.744255
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit tests for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender

    class MyProvider(BaseDataProvider):
        """My Provider."""

        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes.

            :param seed: Seed to all the random functions.
            """
            super().__init__(seed=seed)
            self._datafile = 'gender.json'
            self._pull()

        def gender(self, gender: Gender = None) -> str:
            """Get gender label.

            :param gender: Gender.
            :return: Label for gender.
            """
            gender = self._validate_enum(gender, Gender)
            return self._data['gender'][gender]

    provider = MyProvider(seed=12)

   

# Generated at 2022-06-12 01:40:26.533642
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
    with Address() as address:
        assert address.get_current_locale() == locales.EN
        with address.override_locale(locales.RU):
            assert address.get_current_locale() == locales.RU
        assert address.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:40:30.556513
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import USAddress
    from mimesis.enums import Gender
    provider1 = USAddress()
    with provider1.override_locale('de') as provider2:
        assert provider1.locale == 'de'
        assert provider2.locale == 'de'


# Generated at 2022-06-12 01:40:40.755295
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unittest for BaseDataProvider.override_locale."""
    class DummyDataProvider(BaseDataProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.data = {}

        def _pull(self, *args, **kwargs):
            self.data = {'foo': 'bar'}

        @property
        def bar(self):
            return self.data['foo']

    dp = DummyDataProvider()
    dp._pull('test.json')

    with dp.override_locale() as locale_dp:
        locale_dp.data = {'foo': 'newbar'}

    assert dp.bar == 'bar'

# Generated at 2022-06-12 01:40:46.952157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """The class test data provider."""
        @property
        def data(self) -> JSON:
            """Get data from provider."""
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as overridden:
        assert overridden.data.get('user_agent', {}).get('chrome')
    assert not provider.data



# Generated at 2022-06-12 01:40:54.375266
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method `override_locale` of class BaseDataProvider."""
    provider = BaseDataProvider(locale='en')
    with provider.override_locale('ru') as pr:
        assert pr.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

    with provider.override_locale() as pr:
        assert pr.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider(locale='ru')
    with provider.override_locale() as pr:
        assert pr.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:41:04.164160
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import LOCALE_SUBPATHS
    from mimesis.providers.geography import Geography
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    geography = Geography()
    misc = Misc()
    person = Person()
    text = Text()

    for locale in LOCALE_SUBPATHS:
        with geography.override_locale(locale):
            geography_locale = geography.get_current_locale()
        assert geography_locale == locale

        with misc.override_locale(locale):
            misc_locale = misc.get_current_locale()
        assert misc_locale == locale


# Generated at 2022-06-12 01:41:13.514716
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    from mimesis.enums import Gender

    class Example(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None,
                     ) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'people.json'

        def __getitem__(self, item):
            return self._pull()[item]

        def name(self, gender: Gender = None) -> str:
            gender = self._validate_enum(gender, Gender)
            names = self['names'][gender]
            return get_random_item(names, self.random)

    example = Example()

# Generated at 2022-06-12 01:41:19.320386
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale='ru'):
            super().__init__(locale)

    p = Provider(locale='uk')
    with p.override_locale('en'):
        assert p.get_current_locale() == 'en'

    assert p.get_current_locale() == 'uk'


# Generated at 2022-06-12 01:41:26.924545
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):

        def __init__(self, locale, seed = None):
            super(Provider, self).__init__(locale, seed = seed)

        def __getattr__(self, item):
            return self._data[item]

    provider = Provider(locale = 'md')

    # test for correct behavior of with context manager
    def test_with():
        with provider.override_locale(locales.EN):
            assert provider.get_current_locale() == 'en'

        assert provider.get_current_locale() == 'md'

    # test for correct behavior of using the context manager

# Generated at 2022-06-12 01:42:10.517305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='ru')
    with provider.override_locale(locale='en'):
        assert provider.locale == 'en'

# Generated at 2022-06-12 01:42:15.888740
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        pass

    test_provider = TestDataProvider()

    with test_provider.override_locale('es'):
        assert test_provider.get_current_locale() == 'es'

    assert test_provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:25.712973
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Internet
    from mimesis.providers.network import URL
    provider = Internet()
    origin_locale = provider.get_current_locale()
    with provider.override_locale('ru'):
        url = provider.url(subdomain=False)
        assert url == URL.__repr__(
            'http://' + provider.domain_name())

    with provider.override_locale():
        assert provider.get_current_locale() == 'en'
        assert provider.url(subdomain=False) == URL.__repr__(
            'http://' + provider.domain_name())
        assert provider.get_current_locale() == 'en'


# Generated at 2022-06-12 01:42:32.686485
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale(): # noqa
    @functools.lru_cache(maxsize=None)
    def get_data(file_name):
        data_dir = Path(__file__).parent.parent.joinpath('data')
        file_path = Path(data_dir).joinpath(file_name)
        with open(file_path, 'r', encoding='utf8') as f:
            data = json.load(f)
        return data

    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE,
                     seed=None):
            super().__init__(locale=locale, seed=seed)
            self.locale = locale
            self._data = get_data('override_locale.json')

        def get_data(self):
            return self._data



# Generated at 2022-06-12 01:42:42.102099
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Create mock class for BaseDataProvider
    class MockDataProvider(BaseDataProvider):

        def __init__(self,  *, locale='en', seed=None):
            super().__init__(locale=locale, seed=seed)

        def pull(self, datafile: str = ''):
            return self._pull(datafile=datafile)

        def override_locale(self, locale: str = 'en') -> Generator:
            return self._override_locale(locale=locale)

    # Create instance of mock class
    provider = MockDataProvider()
    # Save locale in local variable
    origin_locale = provider.get_current_locale()
    # Test context manager
    with provider.override_locale(locale='en') as override_provider:
        assert override_provider.get

# Generated at 2022-06-12 01:42:51.637180
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test ``override_locale`` method of ``BaseDataProvider``"""
    import pytest
    from mimesis.providers.address import Address

    locale = locales.EN
    provider = BaseDataProvider(locale=locale)
    with provider.override_locale(locale=locales.RU):
        assert provider.locale == locales.RU
    assert provider.locale == locale

    provider = Address(locale=locale)
    with provider.override_locale(locale=locales.RU):
       assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locale

    provider = Address(locale=locale)

# Generated at 2022-06-12 01:42:58.192723
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    PROVIDER = BaseDataProvider()

    with PROVIDER.override_locale('ru') as dt:
        print(PROVIDER.get_current_locale())
        assert PROVIDER.get_current_locale() == 'ru'
        print(dt.get_current_locale())
        assert dt.get_current_locale() == 'ru'

    print(PROVIDER.get_current_locale())
    assert PROVIDER.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:43:04.846625
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class CustomizedDataProvider(BaseDataProvider):
        def get_data(self):
            data = self._data
            for key, value in data.items():
                yield key, value

    provider = CustomizedDataProvider(locale=locales.RU)
    data = provider.get_data()
    _data = dict(data)
    assert 'class' in _data.keys()
    assert _data['class'] == 'общество'

    with provider.override_locale(locale=locales.EN):
        data = provider.get_data()
        _data = dict(data)
        assert 'class' in _data.keys()
        assert _data['class'] == 'society'

# Generated at 2022-06-12 01:43:11.367609
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale):
            super().__init__()
            self._override_locale(locale)

        def get_current_locale(self):
            return self.locale

    provider = TestProvider('en')
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:18.874816
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    p = Person()

    # Initial locale.
    locale = getattr(p, 'locale', locales.DEFAULT_LOCALE)
    assert locale == locales.EN

    with p.override_locale(locales.RU) as provider:
        assert getattr(provider, 'locale') == locales.RU

    # Restore initial locale.
    assert getattr(p, 'locale', locales.DEFAULT_LOCALE) == locales.EN



# Generated at 2022-06-12 01:44:51.397644
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    builtin = mimesis.builtins.Food()
    with builtin.override_locale() as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.dish() == 'Pizza'
    assert builtin.get_current_locale() != 'en'
    assert builtin.dish() != 'Pizza'

# Generated at 2022-06-12 01:44:53.957960
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:45:02.939847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-tests for method ``override_locale`` of class ``BaseDataProvider``.

    :return: Nothing.
    """
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            """Initialize attributes.

            :param str locale: Locale.
            :param seed: Seed
            :return: Nothing.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def __call__(self, *args, **kwargs) -> str:
            """Get random value from ``test`` key.

            :return: Random value from ``test`` key.
            """

# Generated at 2022-06-12 01:45:08.423680
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    a1 = BaseDataProvider()
    a2 = BaseDataProvider()
    assert a1.locale == a2.locale

    with a1.override_locale('ru'):
        assert a1.locale == 'ru'
        with a2.override_locale('en'):
            assert a2.locale == 'en'
        assert a2.locale == 'ru'

    assert a1.locale == a2.locale

# Generated at 2022-06-12 01:45:13.063073
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.cities import Cities
    with Cities(locale='en').override_locale('ru') as city:
        assert city.get_current_locale() == 'ru'
    assert Cities().get_current_locale() == 'en'


# Generated at 2022-06-12 01:45:19.853768
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins.automotive import Car
    from mimesis.providers.automotive import Car

    c = Car(seed=42)
    with c.override_locale('en'):
        assert c.get_current_locale() == 'en'
        assert c.make() == 'Jaguar'

    assert c.get_current_locale() == 'en'
    assert c.make() == 'Mitsubishi'

test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:45:23.255832
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    with Person().override_locale(locales.JA) as provider:
        assert provider.get_current_locale() == locales.JA

# Generated at 2022-06-12 01:45:28.009334
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that temporarily overrides current locale with passed.
    """
    try:
        with BaseDataProvider.override_locale('ru-RU') as bdp:
            assert bdp.get_current_locale() == 'ru-RU'
        assert bdp.get_current_locale() == 'en'
    except AssertionError:
        assert False
    else:
        assert True



# Generated at 2022-06-12 01:45:36.910595
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import DateTime, Datetime
    from mimesis.providers.geo import Address
    from mimesis.providers.person import Person
    from mimesis.providers.social import SocialNetwork
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web

    base_providers = [
        Address,
        DateTime,
        Datetime,
        Person,
        SocialNetwork,
        Text,
        Web,
    ]
    class_constructors = {
        'Address': Address,
        'DateTime': DateTime,
        'Datetime': Datetime,
        'Person': Person,
        'SocialNetwork': SocialNetwork,
        'Text': Text,
        'Web': Web,
    }


# Generated at 2022-06-12 01:45:37.360379
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass