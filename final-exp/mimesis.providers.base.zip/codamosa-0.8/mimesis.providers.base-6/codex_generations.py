

# Generated at 2022-06-12 01:36:00.440173
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base = BaseDataProvider()
    assert base.override_locale()


# Generated at 2022-06-12 01:36:03.495982
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='en').override_locale('ru') as customized_provider:
        assert customized_provider.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:36:08.089167
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        _datafile = 'builtins.json'

    provider = TestProvider()

    assert provider.get_current_locale() == 'en'

    with provider.override_locale('de'):
        assert provider.get_current_locale() == 'de'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:36:16.013919
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Local(BaseDataProvider):
        pass

    local_russian = Local(locale='ru')
    local_spanish = Local(locale='es')
    local_english = Local(locale='en')

    with local_russian.override_locale(locale='es'):
        assert local_russian.get_current_locale() == 'es'

    with local_spanish.override_locale(locales.RU):
        assert local_spanish.get_current_locale() == locales.RU

    with local_english.override_locale(locales.ES):
        assert local_english.get_current_locale() == locales.ES



# Generated at 2022-06-12 01:36:23.757940
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    locale = locales.EN
    test_provider = BaseDataProvider()
    # AttributeError is raised if provider has not locale dependent
    with test_provider.override_locale(locale) as p:
        assert p.locale == locale
        assert p.get_current_locale() == locale
    # ValueError is raised if provider has not locale dependent
    try:
        with test_provider.override_locale() as p:
            pass
    except ValueError:
        pass

# Generated at 2022-06-12 01:36:28.508753
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """It should override locale when using input locale as ``jp``."""
    en = BaseDataProvider(locale=locales.EN)
    with en.override_locale(locales.JA) as provider:
        assert provider.get_current_locale() is locales.JA
        assert provider.__str__() is 'BaseDataProvider <jp>'

# Generated at 2022-06-12 01:36:36.020491
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
  class MyDataProvider(BaseDataProvider):
    def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                 seed: Seed = None) -> None:
      super().__init__(locale=locale, seed=seed)

    @property
    def data(self) -> Dict[str, Any]:
      return self._data

  dp = MyDataProvider()
  with dp.override_locale(locale='ru') as provider:
    assert(dp != provider)
    assert(dp != str(provider))

test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:36:47.561083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class BaseProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes.

            :param seed: Seed for random.
                When set to `None` the current system time is used.
            """
            super().__init__(locale=locale, seed=seed)
            self.data = {'en': {'foo': 'bar'}, 'ru': {'foo': 'baz'}}
            self._datafile = 'fake_data_file.json'

        def _pull(self, datafile: str = '') -> None:
            self._data = self.data[self.locale]

    p = BaseProvider(seed=42)

# Generated at 2022-06-12 01:36:52.163964
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    locale1 = Address().get_data('locale')
    locale2 = 'ru'

    with Address().override_locale(locale2) as provider:
        assert provider.get_data('locale') == locale2

    assert Address().get_data('locale') == locale1

# Generated at 2022-06-12 01:37:02.293815
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialize attributes for data providers.
    locale = 'en-us'
    datafile = 'address.json'
    base = BaseProvider()
    base.locale = locale
    base._datafile = datafile
    base._data_dir = Path(__file__).parent.parent.joinpath('tests', 'data_providers')
    base._pull()

    from mimesis.providers.address import Address
    address = Address(base)
    address.__str__()

    country = 'country'
    region = 'region'
    city = 'city'
    street_suffix = 'street_suffix'
    with address.override_locale(locale='ru'):
        assert address.get_current_locale() == address.locale
        # Returns data from the new locale
        assert address.ge

# Generated at 2022-06-12 01:37:21.359520
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_data(self, key: str = '') -> Dict:
            return self._data.get(key, {})

    tp = TestProvider(locale='ru')

    with tp.override_locale('en'):
        assert isinstance(tp.get_data(), dict)
        assert tp.get_current_locale() == 'en'

    assert isinstance(tp.get_data(), dict)
    assert tp.get_current_locale() == 'ru'


if __name__ == "__main__":
    import pytest

    pytest.main(['-vv', __file__])

# Generated at 2022-06-12 01:37:29.991908
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ItemProvider(BaseDataProvider):
        def __init__(self, locale: str = 'en') -> None:
            super().__init__(locale=locale)
            self._datafile = 'item.json'
    
        def get_item(self, item: Any = None, enum: Any = None) -> str:
            return self._validate_enum(item, enum)

    provider = ItemProvider()

    assert provider.locale == 'en'
    assert provider.get_item(enum=provider.Toy) == 'doll'

    with provider.override_locale('ru') as provider:
        assert provider.locale == 'ru'
        assert provider.get_item(enum=provider.Toy) == 'кукла'

    assert provider.locale == 'en'



# Generated at 2022-06-12 01:37:34.926547
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    with Person('en').override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) in p._data['names']['male']

# Generated at 2022-06-12 01:37:43.579921
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code as Code_builtin
    from mimesis.enums import Code as Code_enum

    # Test with locale-dependent provider
    provider_ = BaseDataProvider(locale='ru')
    provider_.override_locale().__enter__().locale
    assert provider_.locale == locales.EN
    provider_.override_locale(locales.RU).__enter__().locale
    assert provider_.locale == locales.RU

    # Test with locale-independent provider
    assert hasattr(Code_builtin(locale='ru'), '__slots__')

    # ValueError should be raised if class is locale-independent
    with Code_builtin(locale='ru').override_locale() as provider:
        provider.text()

# Generated at 2022-06-12 01:37:48.846190
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from .builtins import Address
    assert Address().random.choice(locales.SUPPORTED_LOCALES) == 'en'

    with Address().override_locale('ru') as provider:
        assert provider.random.choice(locales.SUPPORTED_LOCALES) == 'ru'

    assert Address().random.choice(locales.SUPPORTED_LOCALES) == 'en'

# Generated at 2022-06-12 01:37:57.164547
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'foo.json'

        def get_something(self):
            return self._data['hello']

    dp = DataProvider()
    assert dp.get_something() == 'Hello'
    with dp.override_locale(locales.RU):
        assert dp.get_something() == 'Привет'
    assert dp.get_something() == 'Hello'


# Generated at 2022-06-12 01:38:04.773956
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider._override_locale()."""
    from mimesis.providers.person import Person

    p = Person('ru')
    with p.override_locale('cs') as person:
        # Check that we have overridden the locale
        assert person.get_current_locale() == 'cs'

    # After the context was exited we should have the old locale back
    assert p.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:38:05.797678
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en')
    provider.override_locale('ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:38:15.635145
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en', seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test_provider.json'

        def get_locale(self):
            return self.locale

    with TestProvider(locale='en') as p:
        locale_en = 'en'
        locale_ru = 'ru'
        assert p.get_locale() == locale_en
    with p.override_locale(locale_ru):
        assert p.get_locale() == locale_ru
    assert p.get_locale() == locale_en

# Generated at 2022-06-12 01:38:23.136577
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # BaseDataProvider has no __init__() method
    dp = BaseDataProvider()
    # BaseDataProvider has no method get_current_locale()
    print(dp.get_current_locale())

    with dp.override_locale('en') as dp:
        print(dp.get_current_locale())

    print(dp.get_current_locale())


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:38:39.108299
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    dp = mimesis.builtins.Personal(locale='lv', seed=1)
    assert dp.get_current_locale() == 'lv'
    assert dp.full_name() == 'Лаврентий Анатолий Харитонович'

    with dp.override_locale('en'):
        assert dp.get_current_locale() == 'en'
        assert dp.full_name() == 'Aurora Lucas'
    
    assert dp.get_current_locale() == 'lv'

# Generated at 2022-06-12 01:38:49.480744
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FakeProvider(BaseDataProvider):
        _datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    p = FakeProvider('ru')
    with p.override_locale('ru_RU'):
        assert p.get_current_locale() == 'ru_RU'
        assert p.get_data() == {
            'data': {
                'ru': 'Привет, Мир!',
                'ru_RU': 'Привет, Мир!',
            }
        }
    assert p.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:39:01.333877
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the context manager override_locale."""
    from mimesis.builtins import _load_data
    import sys

    def mock_hook(data: JSON, file: str) -> None:
        """Mock hook for method load_data."""
        data['some_key'] = 'some_value'
        return data

    # Save origin hook
    origin_hook = BaseDataProvider._hook
    # Add mock hook
    BaseDataProvider._hook = mock_hook
    # Load _DEFAULT_DATA from file
    _load_data()
    # Delete mock hook
    BaseDataProvider._hook = origin_hook
    # Set up locale
    locale = sys.modules['mimesis'].locale
    # Get _DEFAULT_DATA
    data = sys.modules['mimesis'].builtins._DEFAULT_DATA


# Generated at 2022-06-12 01:39:12.250860
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    def _get_random_data(provider: BaseDataProvider) -> Dict[str, Any]:
        return {
            'numbers': provider.random.integer(0, 1000),
            'text': provider.word(),
        }

    provider_1 = BaseDataProvider(locale='ru')
    provider_2 = BaseDataProvider(locale='en')
    data_1 = _get_random_data(provider_1)
    data_2 = _get_random_data(provider_2)
    assert data_1 != data_2

    with provider_1.override_locale(locale='en'):
        data_3 = _get_random_data(provider_1)
    assert data_2 == data_3


# Generated at 2022-06-12 01:39:17.071583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Overrides current locale with passed and pull data for new locale
    with BaseDataProvider.override_locale(locale = locales.EN) as en_provider:
        print(en_provider)
        assert en_provider.locale == locales.EN
    assert en_provider.locale != locales.EN


# Generated at 2022-06-12 01:39:23.912233
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Automotive, BaseProvider

    # Create new instance of BaseProvider
    bp = BaseProvider()
    # Create new instance of Automotive
    auto = Automotive()
    # AssertionError
    with bp.override_locale('en'):
        assert 0

    with auto.override_locale('en'):
        assert auto.get_current_locale() == 'en'

    # We can't override locale for BaseProvider
    assert auto.get_current_locale() == 'en'
    with auto.override_locale('ru'):
        assert auto.get_current_locale() == 'ru'

    assert auto.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:34.616416
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale."""
    from mimesis.data import OCCUPATIONS

    locale = 'ru'
    occ = OCCUPATIONS(locale='en')
    with occ.override_locale(locale) as new_occ:
        assert occ.get_current_locale() == 'en'
        assert new_occ.get_current_locale() == locale
    assert occ.get_current_locale() == 'en'

    # Test for builtins
    from mimesis.builtins import Code

    code = Code(locale='en')
    with code.override_locale(locale):
        pass
    assert code.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:40.223140
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider(locale='ru')

    # test without context manager
    try:
        provider.override_locale()
    except Exception as error:
        assert error.__class__.__name__ == 'ValueError'

    # test with context manager
    result = {}
    with provider.override_locale() as p:
        result['locale'] = p.locale
        result['provider'] = p

    assert result == {'locale': 'en', 'provider': provider}
    assert provider.locale == 'ru'

# Generated at 2022-06-12 01:39:47.382644
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Provider(BaseDataProvider):

        class Meta:
            locales = ['en']

    p = Provider()

    with p.override_locale('en') as p:
        assert p.locale == 'en'

    with p.override_locale('ru'):
        assert p.locale == 'ru'

    assert p.locale == 'en'

    with p.override_locale('en'):
        assert p.locale == 'en'

    assert p.locale == 'en'

# Generated at 2022-06-12 01:39:56.390432
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    locales = [local for local in Person().list_available_locales()]
    locales.extend([local for local in Text().list_available_locales()])
    locales.extend([local for local in Datetime().list_available_locales()])
    locales.extend([local for local in Geo().list_available_locales()])
    locales.extend([local for local in Internet().list_available_locales()])


# Generated at 2022-06-12 01:40:19.819877
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)

    test = Test()

    with test.override_locale(locales.EN):
        assert test.locale == locales.EN

        with test.override_locale(locales.RU):
            assert test.locale == locales.RU

        assert test.locale == locales.EN

    assert test.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:40:27.139158
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider.override_locale."""
    from mimesis import Generic
    en = BaseDataProvider(locale='en')
    with en.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert en.get_current_locale() == 'en'

    generic = Generic('en')
    with generic.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert generic.get_current_locale() == 'en'



# Generated at 2022-06-12 01:40:37.932532
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():


    class Test(BaseDataProvider):

        """Test provider."""

        _datafile = 'test.json'

        def __init__(self,
                     seed: Seed = None,
                     locale: str = locales.EN,
                     **kwargs) -> None:
            super().__init__(seed=seed, locale=locale)

        def _pull(self) -> None:
            pass

        def foo(self) -> str:
            """Function.

            :return: Locale.
            """
            return self.get_current_locale()

    data = Test()
    with data.override_locale('ru'):
        assert data.foo() == 'ru'



# Generated at 2022-06-12 01:40:47.505726
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale."""
    class TestLocale(BaseDataProvider):
        _datafile = 'path.json'

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for fake data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            self._data: Dict = {}
            super().__init__(locale=locale, seed=seed)

    tl = TestLocale(locale=locales.RU)
    assert tl.locale == locales.RU


# Generated at 2022-06-12 01:40:53.182004
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def _pull(self, datafile: str = ''):
            pass

        def foo(self):
            return self.get_current_locale()

    tp = TestProvider(locale='ru')

    with tp.override_locale(locale='en') as tp1:
        assert tp1.get_current_locale() == 'en'
        assert tp1.foo() == 'en'
    assert tp.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:41:03.635201
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestClass(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale=locale, seed=seed)
            self._override_locale(locale)
        def get_data(self) -> JSON:
            return self._data

    with TestClass('es-MX', seed=0) as provider:
        assert provider.get_current_locale() == 'es-MX'
        assert provider.get_data().get('date') \
            .get('hijri_solar') == 'dd/MM/yyyy'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:41:12.212851
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        _datafile = '__init__.json'

        class Meta(object):
            locales = [locales.EN]
            provider_name = 'test_data_provider'

    provider = TestDataProvider()
    with provider.override_locale(locales.PT) as locale:
        assert locale.locale == locales.PT
    assert provider.locale == locales.DEFAULT_LOCALE

    provider = TestDataProvider()
    with provider.override_locale(locales.RU) as locale:
        assert locale.locale == locales.RU
    assert provider.locale == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:41:22.313185
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test function override_locale."""
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.transport import Transport
    from mimesis.providers.identifier import Identifier


# Generated at 2022-06-12 01:41:34.104314
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ExtDataProvider(BaseDataProvider):
        def __init__(self, datafile='datafile.json', locale='en',
                     seed=None) -> None:
            super().__init__(locale, seed)
            self._datafile = datafile

        def work(self) -> Dict[Any, Any]:
            self._pull()
            return self._data

    # In case we didn't change the locale we must get data from en.json
    # and en_US.json (for provider)
    provider = ExtDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    data1 = provider.work()
    assert isinstance(data1, dict)
    assert data1
    assert len(data1) == 2

    # In case we didn't assign the locale we must get

# Generated at 2022-06-12 01:41:42.674746
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest

    from mimesis.builtins.enums import Locale

    from .test_providers import (
        test_IntProvider,
        test_TextProvider,
    )

    def do_it(provider, locale: str = locales.EN):
        with provider.override_locale(locale) as p:
            assert p.locale == locale

    with pytest.raises(ValueError):
        do_it(test_IntProvider())

    with pytest.raises(ValueError):
        do_it(test_TextProvider())

    do_it(test_TextProvider(Locale.KAZAKH.value))

# Generated at 2022-06-12 01:42:10.214698
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.data import FileDataProvider, FileNotFoundError
    from mimesis.enums import Language
    import random

    # * Using method override_locale()
    # * with context manager
    # * must return value
    #   with overridden 'locale'
    #   equal to Language.RU
    with FileDataProvider(Language.RU) as file_data:
        assert file_data.locale == Language.RU

    # * Object of class FileDataProvider
    # * when check object with overridden 'locale'
    # * must return that
    #   'origin_locale' equal to Language.EN
    with FileDataProvider(Language.EN) as file_data:
        with file_data.override_locale(Language.RU):
            assert file_data

# Generated at 2022-06-12 01:42:20.963124
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    p = Person(locale='en')
    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
        assert p.full_name() != p.full_name()
        with p.override_locale('be'):
            assert p.get_current_locale() == 'be'
            assert p.full_name() != p.full_name()
    assert p.get_current_locale() == 'en'
    a = Address()
    assert a.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:29.736487
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import USStateCode, USStateName
    from mimesis.builtins import UKPostCode, UKCounty

    locale = locales.EN
    usn = USStateName(locale=locale)
    usc = USStateCode(locale=locale)
    ukp = UKPostCode(locale=locale)
    ukc = UKCounty(locale=locale)

    assert usn.provider.locale == locale
    assert usc.provider.locale == locale
    assert ukp.provider.locale == locale
    assert ukc.provider.locale == locale

    locale = locales.RU
    usc = USStateCode(locale=locale)
   

# Generated at 2022-06-12 01:42:32.873593
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        pass

    a = A()
    with a.override_locale('ru'):
        assert a.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:42:39.188812
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.personal import Person
    from mimesis.providers.misc import Misc
    print(Person().override_locale('uk').full_name())
    print(Person().override_locale('ru').full_name())
    with Person().override_locale('en') as person:
        print(person.full_name())
    print(Misc().override_locale('en'))

# Generated at 2022-06-12 01:42:44.151851
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    with provider.override_locale(locales.EN):
        assert provider.locale == locales.EN
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.override_locale(locales.DEFAULT_LOCALE)
    assert provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:50.189228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test that overrides current locale with passed.

    :return: True if all tests passed, otherwise False.
    """
    from mimesis.providers.person import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert p.locale == person.locale == 'ru'
        assert p.name() != person.name()
    assert p.locale == person.locale == 'en'
    return True

# Generated at 2022-06-12 01:43:00.610855
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Profession
    from mimesis.providers import Person
    person = Person('en')
    person_ru = Person('ru_RU')
    profession = person.profession
    profession_ru = person_ru.profession
    with person.override_locale('ru_RU'):
        assert person.profession() != profession()
        assert person.profession() == profession_ru()
        with person.override_locale('en'):
            assert person.profession() == profession()
            assert person.profession() != profession_ru()
        assert person.profession() != profession()
        assert person.profession() == profession_ru()
    assert person.profession() == profession()

# Generated at 2022-06-12 01:43:11.059204
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale.

    Note: This test is not intended to be included in pytest,
    it is written for Python 3.6.
    """
    import time
    class TestDataProvider(BaseDataProvider):
        def get_data(self, category: str, item: str) -> Any:
            """Get data from JSON by identifier.

            :param category: Category in JSON.
            :param item: Identifier.
            :return: Value from JSON.
            """
            return self._data[category][item]

        def get_first_name(self, gender: str = None) -> str:
            """Get first name.

            :param gender: Gender.
            :return: Random first name.
            """
            gender = self._validate_enum(gender, Gender)
            return self.get_

# Generated at 2022-06-12 01:43:16.403352
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def test_method(self):
            return {'locale': self.locale}

    provider = TestProvider()
    assert provider.test_method()['locale'] == locales.DEFAULT_LOCALE

    result_for_overrided_locale = {'locale': locales.EN}
    assert provider.override_locale(locales.EN).__enter__().test_method() == result_for_overrided_locale

# Generated at 2022-06-12 01:43:48.887541
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p._pull.cache_info().hits == 0
        x = p.full_name(gender=Gender.MALE)
        assert p._pull.cache_info().hits == 1

    with person.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p._pull.cache_info().hits == 2
        y = p.full_name(gender=Gender.MALE)
        assert p._pull.cache_info().hits == 3


# Generated at 2022-06-12 01:43:55.389523
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def __init__(self, locale=None, seed=None):
            super().__init__(locale, seed)

        def method_1(self):
            return self.locale

        def method_2(self):
            return self.get_current_locale()

    provider = TestProvider(locales.EN, seed=12345)

    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU

    with provider.override_locale(locales.DE):
        assert provider.locale == locales.DE

    assert provider.locale == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.method_1() == locales.RU
        assert provider

# Generated at 2022-06-12 01:44:01.976807
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test:
        def __init__(self):
            self.locale = locales.EN

        def get_current_locale(self) -> str:
            return self.locale

        def _override_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            self.locale = locale


# Generated at 2022-06-12 01:44:11.129773
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """TestProvider"""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

        def get_foo(self) -> str:
            """Get foo."""
            return 'foo'

        def get_bar(self) -> str:
            """Get bar."""
            return 'bar'

        def get_baz(self) -> str:
            """Get baz."""
            return 'baz'


    test_provider = TestProvider(locale=locales.EN, seed=0)
    assert test_provider.get_current_locale() == locales.EN


# Generated at 2022-06-12 01:44:20.203511
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method `override_locale` of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    a = Address()
    b = Address()
    c = Internet()
    d = Person()

    with a.override_locale('ru'):
        assert a.get_current_locale() == 'ru'

    with b.override_locale('ru') as e:
        assert e.get_current_locale() == 'ru'

    with a.override_locale('en') as f:
        assert f.get_current_locale() == 'en'


# Generated at 2022-06-12 01:44:29.279192
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # This is a demo for context manager for unit test
    class TestProvider(BaseDataProvider):
        def __init__(self, a: int = None, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.a = a

        def get_a(self) -> int:
            return self.a

        def set_a(self, val: int) -> None:
            self.a = val

    # This is the process of testing method override_locale
    # Create a test provider
    tp = TestProvider(123)
    # Test provider
    assert tp.get_a() == 123
    # Override locale as 'testing'

# Generated at 2022-06-12 01:44:36.824495
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__(locale)
            self._data = {locales.DEFAULT_LOCALE: {'it': 'origin'}}
            self._datafile = 'test.json'

        def get_current_locale(self) -> str:
            return self.locale

        def get_data(self, key: str) -> Dict:
            return self._data[self.locale]

    test_provider = TestProvider(locales.DEFAULT_LOCALE)

    with test_provider.override_locale(locales.EN):
        assert test_provider.get_current_locale() == locales.EN
        assert test_provider.get

# Generated at 2022-06-12 01:44:39.717861
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class BaseDataProvider with method override_locale."""
    # enable type hints
    provider = BaseDataProvider()
    with provider.override_locale(
            'en'):  # type: ignore
        assert provider.get_current_locale() == 'en'

    with provider.override_locale(
            'ru'):  # type: ignore
        assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-12 01:44:49.866981
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.schema import Field, Schema

    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)

        def gender(self):
            return self._validate_enum(None, self.GENDERS)

        def field(self, field_name):
            return Field(field_name, data_provider=self)

    tp = TestProvider(locale=locales.DEFAULT_LOCALE, seed='test-override')
    schema = Schema(
        {
            'gender': 'gender',
        },
        data_provider=tp,
    )
    # test_data = schema.create(iterations=1000)

# Generated at 2022-06-12 01:44:58.163726
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        """DummyProvider class."""

        def __init__(self, *args, **kwargs):
            """Init method."""
            super().__init__(*args, **kwargs)
            self._data = {'a': 1, 'b': 2}

    # locale dependent provider
    dp = DummyProvider()
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE
    assert dp._data['a'] == 1
    assert dp._data['b'] == 2
    with dp.override_locale(locales.RU) as dp_ru:
        assert dp_ru.get_current_locale() == locales.RU
        assert dp_ru._data['a'] == 1
        assert dp_