

# Generated at 2022-06-12 01:36:09.426224
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Test(BaseDataProvider):
        """Test class."""

        def __init__(self, locale: str = 'en'):
            super().__init__(locale)

        def get_data(self) -> str:
            """Get data for testing."""
            return self.locale

    test = Test(locale='en')
    assert test.get_data() == 'en'

    with test.override_locale(locale='ru') as t:
        assert t.get_data() == 'ru'
    
    assert test.get_data() == 'en'

    with test.override_locale(locale='en') as t:
        assert t.get_data() == 'en'
    

# Generated at 2022-06-12 01:36:11.770128
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''Unit test for method override_locale of class BaseDataProvider

    :return:
    '''
    # TODO: add test
    pass

# Generated at 2022-06-12 01:36:16.518195
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        pass
    provider = Test()
    with provider.override_locale(locales.EN) as p:
        assert str(p) == 'Test <en>'
    assert str(provider) == 'Test'



# Generated at 2022-06-12 01:36:23.939235
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.finance import Money
    from mimesis.enums import Currency

    m = Money('en-US')
    with m.override_locale('ru') as money:
        assert money.get_currency(Currency.EURO) == 'EUR'

    assert m.get_currency(Currency.EURO) == '€'
    assert m.get_current_locale() == 'en-US'
    assert money.get_current_locale() == 'ru'


# Generated at 2022-06-12 01:36:28.701814
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.builtins import Lorem
    expected = '<Lorem <ru>>'
    with Lorem().override_locale(locales.RU) as provider:
        result = str(provider)
    assert result == expected

# Generated at 2022-06-12 01:36:33.630153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Name
    with BaseDataProvider(locale='en').override_locale(locale='ja') as jp:
        name = jp.name()
    assert name == Name(locale='ja').name()

# Generated at 2022-06-12 01:36:45.279064
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    bdp = mimesis.builtins.BaseBuiltins(locale='ru')

    with bdp.override_locale('en') as builtin:
        assert builtin is bdp
        assert builtin.get_current_locale() == 'en'
        assert builtin.gender() == Gender.MASCULINE

    assert bdp.get_current_locale() == 'ru'
    assert bdp.gender() == Gender.MASCULINE

    bdp = mimesis.builtins.BaseBuiltins()
    with pytest.raises(ValueError):
        with bdp.override_locale('ru'):
            pass


# Generated at 2022-06-12 01:36:51.434739
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
     class TestProvider(BaseDataProvider):
         def test(self):
            return self.random.choice(self._data['test'])

     # Try override locale
     provider = TestProvider()
     with provider.override_locale('ru') as test_provider:
         result = test_provider.test()
     assert result in ['test1', 'test2']

     # Try override with unsupported locale
     with provider.override_locale('fr') as test_provider:
         result = test_provider.test()
     assert result in ['test1', 'test2']

     # Try override with wrong locale
     with provider.override_locale('fr') as test_provider:
         result = test_provider.test()
     assert result in ['test1', 'test2']

     # Try override with wrong type of

# Generated at 2022-06-12 01:36:58.378441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = 'en') -> None:
            super().__init__(seed=666, locale=locale)
            self._datafile = 'address.json'

        def get_country(self) -> str:
            return self._data['addresses']['countries']['name']

    provider = TestProvider('en')
    country = provider.get_country()
    with provider.override_locale('ru') as ru:
        ru_country = ru.get_country()
    assert ru_country == 'Россия'
    assert ru_country != country
    assert ru_country == provider.get_country()

    ru_provider = TestProvider('ru')
    ru_country = ru_provider.get_country()

# Generated at 2022-06-12 01:37:07.460528
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    provider = BaseDataProvider(locale=locale)
    locale1 = locales.EN
    locale2 = locales.RU
    with provider.override_locale(locale=locale1):
        assert provider.get_current_locale() == locale1
        with provider.override_locale(locale=locale2):
            assert provider.get_current_locale() == locale2
        assert provider.get_current_locale() == locale1
    assert provider.get_current_locale() == locale

# Generated at 2022-06-12 01:37:19.072463
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    locale = 'ru'
    provider.override_locale(locale)

    assert provider.get_current_locale() == locale

# Generated at 2022-06-12 01:37:28.837006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Localized(BaseDataProvider):
        pass

    provider = Localized(seed=1)
    d = {'a': 1, 'b': 2}

    assert provider.get_current_locale() == locales.EN
    assert provider.provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.DE):
        assert provider.get_current_locale() == locales.DE
        assert provider.provider.get_current_locale() == locales.EN

    with provider.override_locale():
        assert provider.get_current_locale() == locales.EN
        assert provider.provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.get

# Generated at 2022-06-12 01:37:32.551534
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        pass

    provider = TestBaseDataProvider(locale='es')
    with provider.override_locale(locale='ru'):
        assert provider.locale == 'ru'
    assert provider.locale == 'es'

# Generated at 2022-06-12 01:37:40.365484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super(MyProvider, self).__init__(seed)
        def foo(self):
            return self.locale
    provider=MyProvider()
    assert provider.locale=='en'
    assert provider.foo()=='en'
    with provider.override_locale('ru'):
        assert provider.foo()=='ru'
    assert provider.foo()=='en'

if __name__=='__main__':
    test_BaseDataProvider_override_locale()
    print('All test of BaseDataProvider has passed!!!')

# Generated at 2022-06-12 01:37:46.409601
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Name

    name = Name()
    name._pull()
    for locale in ('ru-RU', 'fr-FR'):
        with name.override_locale(locale):
            assert name.get_current_locale() == locale
            assert name._pull.cache_info().hits == 1
    assert name.get_current_locale() == 'en-US'
    assert name._pull.cache_info().hits == 0

# Generated at 2022-06-12 01:37:57.039715
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ Unit test for method override_locale of class BaseDataProvider. """
    import mimesis.builtins
    provider = mimesis.builtins.Person()
    with provider.override_locale('es'):
        assert provider.get_current_locale() == 'es'
    assert provider.get_current_locale() == 'en'

    try:
        with provider.override_locale('wtf'):
            assert provider.get_current_locale() == 'wtf'
    except ValueError as e:
        assert str(e) == '«Person» has not locale dependent'
    else:
        assert False, "Should not be reached"

    with provider.override_locale():
        assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:02.664675
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.system import System
    locale = locales.EN
    system = System()
    with system.override_locale(locale) as s:
        assert s.get_current_locale() == locale
    assert system.get_current_locale() != locale

# Generated at 2022-06-12 01:38:10.530237
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        __qualname__ = None
        _datafile = 'test.json'

        def __str__(self) -> str:
            locale = getattr(self, 'locale', locales.DEFAULT_LOCALE)
            return '{} <{}>'.format(self.__class__.__name__, locale)

        def get_test_data(self) -> str:
            return self._data['test']

    p = TestProvider()
    assert str(p) == 'TestProvider <en>'

    with p.override_locale('ru') as ru:
        assert ru is p
        assert ru.get_test_data() == 'ru_test'
        assert str(ru) == 'TestProvider <ru>'


# Generated at 2022-06-12 01:38:12.774642
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """It should allow overriding current locale."""
    bdp = BaseDataProvider('en')
    with bdp.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.locale == 'ru' and bdp.locale == 'en'



# Generated at 2022-06-12 01:38:21.910842
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method "override_locale" of class BaseDataProvider."""
    # Test for empty locale
    with BaseDataProvider(locale='').override_locale() as provider:
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    # Test for native locale
    with BaseDataProvider(locale='').override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN

    # Test for locale with wrong type
    with BaseDataProvider(locale='').override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-12 01:38:35.795221
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'

    class TestProvider(BaseDataProvider):
        def get_current_locale(self):
            return getattr(self, 'locale', locales.DEFAULT_LOCALE)

    provider = TestProvider()
    with provider.override_locale(locale):
        assert provider.get_current_locale() == locale

    assert provider.get_current_locale() is not locale


# Generated at 2022-06-12 01:38:46.667010
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    with Person().override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Сергей Сидорович Сергеев'
        assert p.full_name(gender=Gender.FEMALE) == 'Наталья Александровна Никитина'
        assert p.full_name(gender=Gender.NOT_APPLICABLE) == 'Кирилл Сергеевич Баранов'



# Generated at 2022-06-12 01:38:49.018385
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Name
    provider = Name
    with provider.override_locale('en') as _:
        assert Name.get_current_locale() == 'en'
    assert Name.get_current_locale() != 'en'

# Generated at 2022-06-12 01:38:53.117692
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:38:55.709419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale):
            self.locale = locale

    provider = DataProvider('en')
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-12 01:39:06.683253
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self):
            pass

        def get_data(self, key: str) -> Dict:
            return getattr(self, '_data', {}).get(key)

    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonBaseProvider

    class Person(PersonBaseProvider):
        def __init__(self, locale: str = locales.EN):
            DataProvider.__init__(self, locale)

        def get_first_name(self, gender: Gender = None) -> str:
            return self.get_data('first_names')\
                      .get(str(self._validate_enum(gender, Gender)))

    with Person() as p_en:
        name_en = p_en.get_first

# Generated at 2022-06-12 01:39:16.284351
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.numbers import Numbers
    n = Numbers('en')
    n.override_locale('ru')
    assert n.between(0, 100) == 53
    assert n.between(0, 100) == 35
    assert n.between(0, 100) == 33
    with n.override_locale('en'):
        assert n.between(0, 100) == 45
        assert n.between(0, 100) == 73
        assert n.between(0, 100) == 22
    assert n.between(0, 100) == 39
    assert n.between(0, 100) == 25
    assert n.between(0, 100) == 67


# Generated at 2022-06-12 01:39:19.484588
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    provider = mimesis.builtins.Code(locale='ru').__class__()
    with provider.override_locale('en') as _:
        assert provider.locale == 'en'

# Generated at 2022-06-12 01:39:26.153376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Thing

    provider = Thing(seed=42)
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get_random_item() == 'мазь'

    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-12 01:39:27.102896
# Unit test for method override_locale of class BaseDataProvider

# Generated at 2022-06-12 01:39:39.850467
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # test_BaseDataProvider_override_locale_with_exception
    class TestProvider(BaseDataProvider):
        def __init__(self) -> None:
            pass

        def get_locale(self) -> str:
            return self.locale

    p = TestProvider()
    
    with p.override_locale('ru') as provider:
        assert provider.get_locale() == 'ru'

    assert p.get_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:39:45.813044
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SomeProvider(BaseDataProvider):
        def _pull(self):
            self._data = {'data': 'test'}

    provider = SomeProvider()
    with provider.override_locale() as p:
        assert p.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:39:49.394088
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('EN') as new_provider:
        assert new_provider.locale == 'en'


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-12 01:39:58.072529
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        def __init__(self):
            self._data = {'_data': [{'a': 1}, {'b': 2}]}
            self._data_dir = ''
            self._datafile = 'datafile'
            self._setup_locale(locales.DEFAULT_LOCALE)

        def get_data(self, key: str = None) -> Dict[str, Any]:
            """Get data from the data provider."""
            data = self._data['_data']

            if key is not None:
                if data.get(key):
                    data = data.get(key)
                else:
                    raise KeyError(key)

            return data

    provider = DummyProvider()


# Generated at 2022-06-12 01:40:03.986590
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    import random
    import unittest
    from mimesis.providers.address import Address
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.exceptions import (
        UnsupportedLocale,
        NonEnumerableError,
        FieldDoesNotExist,
    )
    class TestBaseDataProvider(unittest.TestCase):
        def setUp(self):
            self.base = BaseDataProvider(locale='ru')
            self.locale = BaseDataProvider(locale='ru')
            self.person = Person('ru')
            self.address = Address('ru')
            self.internet = Internet('ru')


# Generated at 2022-06-12 01:40:11.543095
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Address
    from mimesis.enums import Gender

    address = Address()
    with address.override_locale('ru'):
        assert address.full_name(gender=Gender.MALE) != 'John Doe'
        assert address.full_name(gender=Gender.MALE) == 'Иван Иванов'

# Generated at 2022-06-12 01:40:15.193793
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """."""
    provider = BaseDataProvider()
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'
    assert provider.locale == locales.DEFAULT_LOCALE



# Generated at 2022-06-12 01:40:17.933139
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import PythonBuiltins
    from mimesis import locales
    with PythonBuiltins().override_locale(locales.JA):
        assert PythonBuiltins().get_current_locale() == locales.JA



# Generated at 2022-06-12 01:40:27.831035
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.geography import Geography
    from mimesis.providers.science import Science
    from mimesis.providers.identifiers import Identifiers

    address = Address()
    person = Person()
    internet = Internet()
    geography = Geography()
    science = Science()
    ids = Identifiers()

    with address.override_locale('ru') as add:
        address_ru = add
    with person.override_locale('ru') as p:
        person_ru = p
    with internet.override_locale('ru') as int:
        internet_ru = int

# Generated at 2022-06-12 01:40:36.276249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test to method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    address = Address('ru')
    assert address.get_current_locale() == 'ru'
    with address.override_locale('en') as addr:
        assert address.get_current_locale() == 'en'
        assert address.postal_code() == addr.postal_code()
    assert address.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:40:53.389953
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class LocaleProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

        def some_method(self, locale: str = locales.DEFAULT_LOCALE):
            return self.get_current_locale()

    data = Dict[str, Dict[str, str]] = {
        'ad': {'some_key': 'ad value'},
        'am': {'some_key': 'am value'},
        'ru': {'some_key': 'ru value'},
        'en': {'some_key': 'en value'}
    }


# Generated at 2022-06-12 01:41:00.351951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider(locale='ru')
    assert bdp.locale == 'ru'
    with bdp.override_locale(locale='ru') as bdp_ru:
        assert bdp_ru.locale == 'ru'
    assert bdp.locale == 'ru'
    with bdp.override_locale(locale='en') as bdp_en:
        assert bdp_en.locale == 'en'
    assert bdp.locale == 'ru'

# Generated at 2022-06-12 01:41:10.055389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale."""
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    men = ['John', 'Andrew', 'Ben', 'Johnathan', 'Chris', 'Thomas']
    women = [
        'Annie', 'Ann', 'Kate', 'Sara',
        'Amanda', 'Mary', 'Elizabeth',
    ]

    person = Person('ru')
    person.genders = (Gender.MALE, Gender.FEMALE)

    for _ in range(5):
        men_name = person.name(gender=Gender.MALE)
        assert men_name in men
        women_name = person.name(gender=Gender.FEMALE)
        assert women_name in women



# Generated at 2022-06-12 01:41:16.518942
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.food import Food
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    food = Food()
    address = Address()
    person = Person()

    locale = 'en-US'

    with food.override_locale(locale):
        assert food.locale == locale
        assert food.get_current_locale() == locale

    with address.override_locale(locale):
        assert address.locale == locale
        assert address.get_current_locale() == locale

    with person.override_locale(locale):
        assert person.locale == locale
        assert person.get_current_locale() == locale

# Generated at 2022-06-12 01:41:21.029532
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.locale == locales.RU
    assert provider.locale == locales.EN

# Generated at 2022-06-12 01:41:21.886293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


# Generated at 2022-06-12 01:41:27.875087
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class SimpleTestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self) -> None:
            """Initialize attributes."""
            self._datafile = 'simple.json'
            super().__init__(locale='ru')

        def get_test(self) -> str:
            """Get some value.

            :return: String representation.
            """
            return str(self.__class__.__name__)

    provider = SimpleTestProvider()
    with provider.override_locale(locale='en') as override:
        assert override.get_test() == 'SimpleTestProvider'

# Generated at 2022-06-12 01:41:33.362174
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class method override_locale."""
    class MyProvider(BaseDataProvider):
        """My provider for unit testing."""

        @property
        def data(self):
            """Dummy data for unit testing."""
            return self._data

    provider = MyProvider('ru')
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
        assert provider.data

# Generated at 2022-06-12 01:41:39.952803
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider"""
    class SomeProvider(BaseDataProvider):
        """Some provider."""
        pass

    provider = SomeProvider(locale='ru')
    provider._pull = functools.lru_cache()(lambda: 'new')

    assert provider._pull() == 'new'

    with provider.override_locale('en'):
        assert provider._pull() == 'new'

    assert provider._pull() == 'new'

# Generated at 2022-06-12 01:41:40.919033
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bd = BaseDataProvider()

# Generated at 2022-06-12 01:42:07.879260
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    with provider.override_locale('de'):
        assert provider.locale == 'de'

    assert provider.locale == locales.EN

# Generated at 2022-06-12 01:42:13.390176
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def foo(self, locale=locales.EN):
            with self.override_locale(locale):
                return self.get_current_locale()

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.foo(locales.RU) == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-12 01:42:18.446213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method of class BaseDataProvider"""
    bdp = BaseDataProvider(locale='ru')
    with bdp.override_locale('jp') as bdp_with_override:
        assert bdp_with_override.get_current_locale() == 'jp'

    assert bdp.get_current_locale() == 'ru'

# Generated at 2022-06-12 01:42:27.928773
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        def test(self, locale: str) -> str:
            return locale

    foo = Foo()
    with foo.override_locale() as f:
        assert f.get_current_locale() == locales.DEFAULT_LOCALE
        f.reseed(seed=locales.DEFAULT_LOCALE)
        assert f.test(locales.DEFAULT_LOCALE) == locales.DEFAULT_LOCALE

    with foo.override_locale(locales.EN) as f:
        assert f.get_current_locale() == locales.EN
        f.reseed(locales.EN)
        assert f.test(locales.EN) == locales.EN

    assert foo.test(locales.DEFAULT_LOCALE) == locales.DEFAULT_LOC

# Generated at 2022-06-12 01:42:33.966090
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.builtins import Personal, Address

    p = Personal()
    p.seed(42)

    # override locale and check that locale was changed
    with p.override_locale(locales.RU) as ru_provider:
        ru_provider.seed(42)
        assert ru_provider.get_current_locale() == locales.RU

    assert p.get_current_locale() != ru_provider.get_current_locale()
    assert ru_provider.seed == p.seed
    assert ru_provider.get_data('personal.name') == p.get_data('personal.name')

# Generated at 2022-06-12 01:42:43.463513
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.human import Human
    import sys

    if sys.version_info[:2] < (3, 7):
        data = {
                'en': Address().street_name(),
                'ru': Address().street_name(),
                'ua': Address().street_name(),
                }
        human_ua = Human('ua')
        human_ru = Human('ru')
        internet_ua = Internet('ua')
        internet_ru = Internet('ru')

        with human_ua.override_locale('ru'):
            assert human_ua.username() == human_ru.username()
            assert human_ua.username() != human_ua.username()


# Generated at 2022-06-12 01:42:49.560253
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person(seed='123')
    assert p._pull.cache_info().currsize == 0

    with p.override_locale('ru'):
        assert p._pull.cache_info().currsize == 0
        assert p.get_current_locale() == 'ru'

    assert p._pull.cache_info().currsize == 1
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:42:54.093595
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider(locale='en')
    try:
        with provider.override_locale(locale='en'):
            assert provider.get_current_locale() == 'en'
    except ValueError as e:
        raise AssertionError(e)


# Generated at 2022-06-12 01:42:59.958970
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.enums import Language
    address = Address(language = Language.EN)
    assert address.get_current_locale() == 'en'
    with address.override_locale(language=Language.RU):
        assert address.get_current_locale() == 'ru'
    assert address.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:05.327250
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    assert provider.locale == 'en'

    provider = BaseDataProvider(locale='zh')
    assert provider.locale == 'zh'

    with provider.override_locale(locale='ru') as p:
        assert p.locale == 'ru'

    assert provider.locale == 'zh'

# Generated at 2022-06-12 01:43:50.482807
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('en') as x:
        print(x)



# Generated at 2022-06-12 01:43:54.015261
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    c = Code('en')
    with c.override_locale('de'):
        assert c.get_current_locale() == 'de'
    assert c.get_current_locale() == 'en'

# Generated at 2022-06-12 01:43:57.865431
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Business

    business = Business(seed=42)

    with business.override_locale(locales.EN):
        gen_en = business.company_symbol()

    with business.override_locale(locales.RU):
        gen_ru = business.company_symbol()

    assert gen_en != gen_ru



# Generated at 2022-06-12 01:44:08.180405
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    # default_locale is en
    p = Person()
    #ensure that the default locale is 'en'
    assert p.get_current_locale() == 'en'
    # test for non-locale-dependent providers
    import mimesis.data
    with pytest.raises(ValueError) as excinfo:
        with mimesis.data.override_locale('en'):
            pass
    assert 'has not locale dependent' in str(excinfo.value)
    # test for locale-dependent providers
    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-12 01:44:16.091408
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Builtins
    b = Builtins()

    with b.override_locale('de'):
        assert b.get_locale() == 'de'
        assert b.currency_code() == 'EUR'

    assert b.get_locale() == 'en'
    assert b.currency_code() == 'USD'

    with Builtins().override_locale('de'):
        assert Builtins().get_locale() == 'de'
        assert Builtins().currency_code() == 'EUR'

    # it should raise a ValueError exception because of non-locale provider
    with Builtins().random.override_locale('de'):
        pass

# Generated at 2022-06-12 01:44:25.574957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import EnumProvider
    from mimesis.data import EnumData
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    locale = 'ru-RU'
    seed = '123123123123'
    enum = Gender

    ep = EnumProvider(locale=locale, seed=seed)
    dt = Datetime(locale=locale, seed=seed)
    ep.add_data(EnumData)

    with ep.override_locale(locale=locale) as eprovider:
        assert eprovider.locale == locale
        assert eprovider.get_random_value(enum=enum) == 'мужчина'

    assert ep.locale != locale

# Generated at 2022-06-12 01:44:31.734518
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data1 = {'name' : 'Jay'}
    data2 = {'name' : 'John'}
    class TestDataProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()
        @property
        def data(self):
            if self.locale == 'en':
                return data1
            else:
                return data2
    t = TestDataProvider()
    assert t.data == data1
    with t.override_locale('ru') as t:
        assert t.data == data2
    assert t.data == data1

# Generated at 2022-06-12 01:44:38.537101
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Address, Person
    from mimesis.enums import Gender

    person = Person('en')
    person.create_person(gender=Gender.FEMALE)

    assert person.full_name() == 'Miss Meredith Bray'
    with person.override_locale('ru') as p:
        assert p.full_name() == 'Мисс Олеся Васильева'
        assert p.gender == Gender.FEMALE

    address = Address('en')
    with address.override_locale('ru'):
        assert address.address() == '3227 Котовский Район, Чебаркульская'

# Generated at 2022-06-12 01:44:42.583798
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        pass
    language = locales.EN
    locale = TestBaseDataProvider().override_locale(language)
    assert locale.get_current_locale() == language

# Generated at 2022-06-12 01:44:45.035819
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider().override_locale('cs_CZ') as provider:
        assert provider.get_current_locale() == 'cs_CZ'
