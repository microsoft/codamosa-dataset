

# Generated at 2022-06-23 20:58:34.719005
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from . import builtins
    from .person import Person
    from .datetime import DateTime
    from .business import Business
    from .code import Code
    from .financial import Financial
    from .food import Food
    from .geo import Geo
    from .hardware import Hardware
    from .internet import Internet
    from .misc import Misc
    from .science import Science
    from .text import Text
    from .transport import Transport
    from .payment import Payment
    from .bicycle import Bicycle

    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

    provider = Person()
    assert str(provider) == 'Person'

    provider = DateTime()
    assert str(provider) == 'DateTime'

    provider = Business()
    assert str(provider) == 'Business'

    provider = Code()

# Generated at 2022-06-23 20:58:42.081102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'test.json'

    origin_locale = locales.EN

    provider = TestProvider(origin_locale, seed=42)
    assert provider.get_current_locale() == origin_locale

    with provider.override_locale(locales.RU) as test:
        assert provider.get_current_locale() == locales.RU
        assert test.get_current_locale() == locales.RU


# Generated at 2022-06-23 20:58:46.414871
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for class BaseProvider."""
    from mimesis.typing import JSON
    provider = BaseProvider()
    assert isinstance(provider.random, JSON)

    provider.reseed(100)
    assert isinstance(provider.random, JSON)


# Generated at 2022-06-23 20:58:48.520717
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    tester = BaseDataProvider()
    result = tester.get_current_locale()
    assert result == 'en'



# Generated at 2022-06-23 20:59:00.505817
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Seed
    s = 123
    
    # Provider with default seed
    provider_1 = BaseProvider()
    provider_1.random.seed(s)  # set seed for the default random generator
    expected_1 = provider_1.random.random()
    assert isinstance(expected_1, float)
    assert expected_1 == 0.16263179484502106
    
    # Provider with user-defined seed
    provider_2 = BaseProvider(seed=s)
    expected_2 = provider_2.random.random()
    assert isinstance(expected_2, float)
    assert expected_2 == 0.16263179484502106
    
    # Provider with default seed which was overridden
    provider_3 = BaseProvider()
    provider_3.reseed(seed=s)  # set seed for the per-instance

# Generated at 2022-06-23 20:59:02.283552
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'


# Generated at 2022-06-23 20:59:05.581046
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider(locale="en")
    assert str(data_provider) is 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:13.367564
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    def test_init_with_no_arguments():
        provider = BaseDataProvider()
        assert provider is not None 
        assert provider.random is not None

    def test_init_with_seed_argument():
        provider = BaseDataProvider(seed=10)
        assert provider is not None
        assert provider.random is not None

    test_init_with_no_arguments()
    test_init_with_seed_argument()


# Generated at 2022-06-23 20:59:16.431065
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp1 = BaseProvider()
    assert str(bp1) == "BaseProvider"

    bp2 = BaseProvider(seed=42)
    assert str(bp2) == "BaseProvider"



# Generated at 2022-06-23 20:59:19.909795
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '1'
    bp = BaseProvider()
    bp.reseed(seed)
    assert bp.seed == seed
    assert bp.random != random
    assert isinstance(bp.random, Random)


# Generated at 2022-06-23 20:59:21.222139
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p = BaseDataProvider(seed=None)
    p.get_current_locale()

# Generated at 2022-06-23 20:59:22.919061
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(BaseProvider())
    print(BaseProvider(seed = "Hello"))


# Generated at 2022-06-23 20:59:30.586341
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('en-US', seed=66)
    gender = Gender.FEMALE
    person.get_full_name(gender=gender)
    # print(person._pull.cache_info())
    # print(person.get_current_locale())
    # print(person.get_full_name(gender=gender))
    # print(person.get_full_name(gender=gender))
    # print(person._data)
    # print(person._pull.cache_info())
    # print(person.get_full_name(gender=gender))
    # print(person._pull.cache_info())
    # print(person.get_full_name(gender=gender))
    # print(person._pull.cache_

# Generated at 2022-06-23 20:59:31.906640
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
  from mimesis.providers.base import BaseProvider
  BaseProvider1 = BaseProvider(seed=None)
  assert str(BaseProvider1) == 'BaseProvider'


# Generated at 2022-06-23 20:59:34.743870
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    b = provider.random.random()
    provider.reseed()
    a = provider.random.random()

    assert a != b


# Generated at 2022-06-23 20:59:37.866581
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    print(type(bp))
    print(type(bp.__dict__))
    print(bp.__dict__)
    return bp


# Generated at 2022-06-23 20:59:40.213870
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 20:59:42.638128
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random


# Generated at 2022-06-23 20:59:48.863159
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    # Prepare all the locales in the supported list to be tested
    supported_locales = []
    for locale in locales.SUPPORTED_LOCALES:
        if locale is not locales.DEFAULT_LOCALE:
            supported_locales.append(locale)

    # Check that two providers with the same seed will always return the same
    # values (@functools.lru_cache)
    # Check that the class attribute locale is available and equal to DEFAULT
    # locale
    internet = Internet()
    assert internet.get_current_locale() == locales.DEFAULT_LOCALE
    ip_address

# Generated at 2022-06-23 20:59:57.997564
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import pytest
    from mimesis.builtins import Code
    from mimesis.enums import Gender

    pattern = r'[a-z]{2}|[a-z]{2}-[a-z]{2}'
    config = {
            'locale': 'kk',
            'seed': 12345678,
            'gender': Gender.FEMALE,
            }
    provider = Code(**config)
    func1 = provider.get_current_locale
    func2 = provider.get_current_locale
    result1 = provider.get_current_locale()
    result2 = provider.get_current_locale()
    assert isinstance(func1, collections.abc.Callable)
    assert isinstance(result1, str)
    assert result1 is not None

# Generated at 2022-06-23 21:00:06.391620
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)
    assert provider.seed is None

    provider = BaseProvider(seed=42)
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)
    assert provider.seed == 42

    provider.reseed(seed=41)
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)
    assert provider.seed == 41


# Generated at 2022-06-23 21:00:08.250743
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    '''Unit test for method __str__ of class BaseDataProvider.'''
    p = BaseDataProvider()
    assert str(p) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:09.913702
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:00:12.643208
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bs = BaseProvider(seed=0)
    result = bs.__str__()
    assert result == 'BaseProvider'



# Generated at 2022-06-23 21:00:15.626009
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(locales.Language()) == 'Language'
    assert str(locales.Currency()) == 'Currency'
    assert str(locales.Name()) == 'Name'

# Generated at 2022-06-23 21:00:18.216628
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(None)
    # Unit test for method _validate_enum of class BaseProvider


# Generated at 2022-06-23 21:00:25.273513
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test for Unit test for method override_locale of class BaseDataProvider
    class TempProvider(BaseDataProvider):
        pass

    provider_temp = TempProvider(locale='en')

    # If a default argument function is called, then return an empty
    # dictionary.
    assert provider_temp.override_locale().__enter__() == provider_temp
    assert provider_temp.override_locale().__exit__(None, None, None) is None

# Generated at 2022-06-23 21:00:29.380110
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed = 1)
    assert provider.reseed(seed = 2) == None
    assert provider.seed == 2
    assert hasattr(provider, 'seed') == True
    assert hasattr(provider, 'random') == True
    assert hasattr(provider, 'reseed') == True


# Generated at 2022-06-23 21:00:30.663292
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(BaseProvider.__str__())
    

# Generated at 2022-06-23 21:00:33.383635
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    obj = BaseDataProvider(locale='en')
    assert obj.get_current_locale() == 'en'



# Generated at 2022-06-23 21:00:35.680127
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-23 21:00:38.364799
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider()
    assert BaseDataProvider(locale = locales.RU,seed = 1234)
    
    
print("Class BaseDataProvider tested")

# Generated at 2022-06-23 21:00:45.096932
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.geography import Geography

    g = Geography(locale='ru')
    g.provider.set_seed(1458)
    assert g.city() == 'Калуга'
    g.provider.set_seed(1458)
    with g.provider.override_locale('en'):
        assert g.city() == 'Little Rock'
    g.provider.set_seed(1458)
    assert g.city() == 'Калуга'

# Generated at 2022-06-23 21:00:56.022685
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime

    first_locale = locales.RU
    second_locale = locales.EN

    with Address.override_locale(locale=first_locale) as a:
        a_first_locale = a.get_current_locale()
        a_first_result = a.building_number()

    with Address.override_locale(locale=second_locale) as a:
        a_second_locale = a.get_current_locale()
        a_second_result = a.building_number()

    with Datetime.override_locale(locale=first_locale) as d:
        d_first_locale = d.get_current_locale()

# Generated at 2022-06-23 21:00:57.719626
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed=42)
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:01:04.354860
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    b = BaseDataProvider()
    assert str(b.get_current_locale()) == str(locales.EN)
    b.locale = locales.RU
    assert str(b.get_current_locale()) == str(locales.RU)
    b.locale = locales.DE
    assert str(b.get_current_locale()) == str(locales.DE)
    b.locale = locales.FR
    assert str(b.get_current_locale()) == str(locales.FR)
    b.locale = locales.IT
    assert str(b.get_current_locale()) == str(locales.IT)
    b.locale = locales.ES
    assert str(b.get_current_locale()) == str(locales.ES)
    b

# Generated at 2022-06-23 21:01:07.411586
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.random == random
    assert bdp._data == {}
    assert bdp._datafile == ''
    assert bdp.locale == 'en'
    assert bdp._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:01:08.350823
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:01:12.653772
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestBase(BaseDataProvider):
        def __init__(self, locale: str = 'en', seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    base = TestBase()

    result = base.get_current_locale()

    assert result == 'en'


# Generated at 2022-06-23 21:01:19.010570
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis.utils import get_random_int
    provider = BaseProvider(seed=None)
    provider.reseed(get_random_int(100,999999))
    assert provider.seed == get_random_int(100,999999)


# Generated at 2022-06-23 21:01:20.783830
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:27.582305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method of BaseDataProvider class."""
    # * Should work
    class DataProvider(BaseDataProvider):
        """Class for testing."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            """Initialization.

            :param locale: Current locale.
            """
            BaseDataProvider.__init__(self, locale=locale)

        def return_locale(self) -> str:
            """Return self.locale."""
            return self.locale

    provider = DataProvider()
    with provider.override_locale(locales.RU) as provider:
        assert provider.return_locale(), locales.RU

    # * Should raise an exception
    class Provider(BaseProvider):
        """Class without locale attribute."""


# Generated at 2022-06-23 21:01:31.144440
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for get_current_locale method of BaseDataProvider class."""
    base_provider = BaseDataProvider()
    with base_provider.override_locale('en'):
        assert locales.EN == base_provider.get_current_locale()


# Generated at 2022-06-23 21:01:33.071247
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:01:35.040597
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Constructor of class BaseProvider."""
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random.random() != None
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:01:37.577708
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    """
    Unit test for method __str__ of class BaseProvider
    """

    provider = BaseProvider()
    assert str(provider) == "BaseProvider"


# Generated at 2022-06-23 21:01:39.556701
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p._random is None
    assert p.random == random
    assert p.seed is None


# Generated at 2022-06-23 21:01:41.776228
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestDataProvider(BaseDataProvider):
        pass
    test_data_provider = TestDataProvider()
    assert test_data_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:01:46.723819
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # file: tests/test_providers/data_providers/test_BaseProvider.py
    provider = BaseProvider()
    assert provider.__str__() == "BaseProvider"
    provider = BaseProvider(seed=0)
    assert provider.__str__() == "BaseProvider"

# Generated at 2022-06-23 21:01:50.786587
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for BaseProvider."""
    p = BaseProvider('Hello world')
    assert p.seed == 'Hello world'
    assert p.random != random
    q = BaseProvider()
    assert q.seed is not None
    assert q.random == random


# Generated at 2022-06-23 21:01:59.336705
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider, RussiaSpecification
    provider = RussiaSpecProvider()
    obj = RussiaSpecification()
    assert provider.get_current_locale() == 'ru'
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
        with provider.override_locale('uk'):
            assert provider.get_current_locale() == 'uk'
    assert provider.get_current_locale() == 'ru'
    """
    with provider.override_locale(2 + 3):
        assert provider.get_current_locale() == 5
    """
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:02:01.054207
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    try:
        assert BaseDataProvider().get_current_locale() == 'en'
    except AttributeError:
        assert True


# Generated at 2022-06-23 21:02:03.364160
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    print("Testing BaseDataProvider.__str__ ...")
    class Foo(BaseDataProvider):
        pass
    foo = Foo()
    assert foo.__str__() == 'Foo <en>'
test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:02:07.667476
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def foo(locale):
        dp = BaseDataProvider(locale)
        assert dp.locale == locale

    foo('en')
    with BaseDataProvider().override_locale('ru') as dp:
        assert dp.locale == 'ru'
    foo('en')

# Generated at 2022-06-23 21:02:15.484221
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

        def set_locale(self):
            return self.get_current_locale()

    provider = MyProvider(locale='pt')
    with provider.override_locale('es') as p:
        assert p is provider
        assert p.set_locale() == 'es'
    assert p.set_locale() == 'pt'



# Generated at 2022-06-23 21:02:23.678051
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # object = BaseDataProvider(locale='ru')
    # locale = object.get_current_locale()
    # print(locale)
    #
    # object = BaseDataProvider(locale='ru', seed=123)
    # locale = object.get_current_locale()
    # print(locale)
    #
    # object = BaseDataProvider(locale='en')
    # locale = object.get_current_locale()
    # print(locale)
    #
    with BaseDataProvider(locale='ru').override_locale('en') as obj:
        locale = obj.get_current_locale()
        print(locale)

    object = BaseDataProvider(locale='ru')
    with object.override_locale('en'):
        locale = object.get_current

# Generated at 2022-06-23 21:02:25.734765
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp is not None

# Generated at 2022-06-23 21:02:31.226332
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for BaseProvider."""
    class Test(BaseProvider):
        """Test class which will inherit from BaseProvider."""

        def __init__(self):
            """Init method."""
            super().__init__(seed=1234)

    obj = Test()
    exp = {'random': 'Random()(seed=1234)'}
    assert obj.__dict__ == exp



# Generated at 2022-06-23 21:02:40.893257
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Create a BaseProvider instance
    b1 = BaseProvider(seed=10)

    # Check the seed of instance
    assert b1.seed == 10
    assert b1.random.seed() == 10
    assert b1.random.random() == 0.5714025946899135
    assert b1.random.random() == 0.4288890546751146
    assert b1.random.random() == 0.5780913011344704
    
    b1.reseed(20)
    assert b1.seed == 20
    assert b1.random.seed() == 20
    assert b1.random.random() == 0.8182503971889781
    assert b1.random.random() == 0.6334037565104183
    assert b1.random.random() == 0.618001554905

# Generated at 2022-06-23 21:02:46.963184
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider("en")
    assert b._data == {}, "_data is empty"
    assert b._datafile == "", "_datafile is empty"
    assert b._data_dir == Path(__file__).parent.parent.joinpath('data'), "_data_dir is right"
    assert b.locale == "en", "locale is en"
    assert b.seed is None, "seed is None"
    assert b.random is random, "random is random"
    b.reseed(12)
    assert b.seed == 12, "seed is 12"
    assert b.random is not random, "random is not random"



# Generated at 2022-06-23 21:02:50.550169
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    with BaseProvider() as dataprovider:
        dataprovider.reseed(1)
        assert dataprovider.seed == 1


# Generated at 2022-06-23 21:02:51.498003
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    assert isinstance(BaseDataProvider(), BaseProvider)

# Generated at 2022-06-23 21:02:54.981834
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = 3
    Test = BaseProvider(seed=seed)
    assert Test.seed == seed
    assert Test.random is not random
    assert Test.random.generator.seed(123) == 1996008297
    Test.reseed(seed=seed)
    assert Test.random.generator.seed(123) == 1996008297


# Generated at 2022-06-23 21:02:55.488620
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass



# Generated at 2022-06-23 21:02:57.350695
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    locale = locales.EN
    seed = None
    provider = BaseDataProvider(locale, seed)
    return provider


# Generated at 2022-06-23 21:03:03.877307
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    provider.reseed(11)
    assert provider.seed == 11
    assert provider.random is not random
    provider.reseed()
    assert provider.seed is None
    assert provider.random is not random
    provider.random.seed()
    provider.reseed()
    assert provider.seed is None
    assert provider.random is not random

# Generated at 2022-06-23 21:03:13.254435
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_BaseDataProvider = BaseDataProvider()
    assert type(test_BaseDataProvider) is BaseDataProvider
    test_BaseDataProvider = BaseDataProvider('en')
    assert type(test_BaseDataProvider) is BaseDataProvider
    test_BaseDataProvider = BaseDataProvider(locale='en')
    assert type(test_BaseDataProvider) is BaseDataProvider
    from random import SystemRandom
    seed = SystemRandom()
    test_BaseDataProvider = BaseDataProvider(seed=seed)
    assert type(test_BaseDataProvider) is BaseDataProvider
    test_BaseDataProvider = BaseDataProvider('en', seed=seed)
    assert type(test_BaseDataProvider) is BaseDataProvider


# Generated at 2022-06-23 21:03:16.463129
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Code

    assert str(Code()) == 'Code <en>'

    with Code().override_locale(locales.RU) as code:
        assert str(code) == 'Code <ru>'


# Generated at 2022-06-23 21:03:25.405327
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # реализация для теста
    class Provider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)

    # контрольные значения
    class Control:
        def __init__(self, seed: Seed) -> None:
            self.random = Random()
            self.random.seed(seed)

        def random_sample(self, items: Dict[Any, Any]) -> Any:
            return get_random_item(items, self.random)

    # тесты с параметрами и контрольны

# Generated at 2022-06-23 21:03:28.417262
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert(BaseDataProvider().__str__() == 'BaseDataProvider <en>')
    assert(BaseDataProvider("cs").__str__() == 'BaseDataProvider <cs>')

# Generated at 2022-06-23 21:03:31.236598
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp= BaseProvider()
    assert bp.random.random() != bp.random.random(), "Seed is not changed"
    print(bp.random.random())
    print(bp.random.random())


# Generated at 2022-06-23 21:03:32.540327
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:03:33.648155
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:37.057250
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Test passing invalid data
    with pytest.raises(UnsupportedLocale):
        BaseDataProvider(locale="ru-ru")

    # Test passing no data
    obj = BaseDataProvider()
    assert obj.locale == "en"

    # Test passing valid data
    obj = BaseDataProvider(locale="ru")
    assert obj.locale == "ru"


# Generated at 2022-06-23 21:03:46.598356
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test override_locale of class BaseDataProvider."""

    class A(BaseDataProvider):

        def __init__(self, locale, seed):
            super().__init__(locale, seed)

    a=A("ru", 1234)
    value = a.override_locale("en")
    assert str(a) == 'A <en>'
    assert value.__class__.__name__ == 'BaseDataProvider'
    assert value.get_current_locale() == 'en'

    try:
        value = a.override_locale("en")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-23 21:03:51.221706
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    assert provider.locale == locales.EN
    assert provider._data_dir == Path(__file__).parent.parent.joinpath(
        'data'
    )
    assert provider._data == {}
    assert provider._datafile == ''


# Generated at 2022-06-23 21:03:56.948924
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class CustomData(BaseDataProvider):
        def add(self, x, y):
            return x + y
    ob_CustomData = CustomData()

    with ob_CustomData.override_locale() as custom_data:
        assert custom_data.add(1, 2) == 3


# Generated at 2022-06-23 21:03:58.992079
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:04:01.210595
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Testing method reseed of class BaseProvider."""
    x = BaseProvider(seed=None)
    x.reseed(seed=1)
    assert x.seed == 1

# Generated at 2022-06-23 21:04:05.289090
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider(locale = 'en', seed = None)
    assert dp.locale == 'en'
    assert dp.seed is None


# Generated at 2022-06-23 21:04:06.794713
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider()
    str(a) == 'BaseProvider'



# Generated at 2022-06-23 21:04:09.083374
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    a = BaseProvider(seed = 1234)
    b = BaseProvider(seed = 1234)
    assert a.random is not random
    assert b.random is not random
    assert a.random == b.random
    b.reseed(4321)
    assert a.random != b.random


# Generated at 2022-06-23 21:04:11.580274
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    with BaseProvider(seed=None) as baseProvider:
        print(baseProvider.seed)


# Generated at 2022-06-23 21:04:23.677495
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    import mimesis.enums


    class DataProviderForTest(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

        def get_some_data(self, key: str, enum: mimesis.enums.Enum) -> Any:
            return self._validate_enum(key, enum)

    provider = DataProviderForTest()
    assert isinstance(provider, BaseDataProvider)
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider, BaseProvider) is True
    assert isinstance(provider, BaseDataProvider) is True
    assert provider._datafile == ''
    assert provider._data == {}
    assert str(provider)

# Generated at 2022-06-23 21:04:32.178715
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed."""
    bp = BaseProvider()
    bp.reseed(seed=3)
    assert bp.random.randint(1, 100) == 6
    bp.reseed(seed=3)
    assert bp.random.randint(1, 100) == 6
    bp.reseed(seed=None)
    assert bp.random.randint(1, 100) == 38
    bp.reseed(seed=None)
    assert bp.random.randint(1, 100) == 38


# Generated at 2022-06-23 21:04:43.695566
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test case for method ``override_locale``.

    This test case is used to check the behavior of the method
    «override_locale» of the class «BaseDataProvider».
    """
    from mimesis.providers import Address
    # Create an object address and change locale in it
    # to the desired value and get the value of the attribute
    # Street of the new locale.
    with Address(seed=42).override_locale('ru') as addr:
        street1 = addr.street_name()
    # Create an object address on different locales
    # and get the value of the attribute Street for
    # different locales.
    address = Address(locale='en', seed=42)
    street2 = address.street_name()
    address = Address(locale='ru', seed=42)
   

# Generated at 2022-06-23 21:04:46.104069
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:04:47.473992
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:57.035555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    person = Person.get_current_locale()
    assert person == 'en'
    with Person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_name(gender=None) == person.get_name(gender=None)
    assert person.get_current_locale() == 'en'
    with Person.override_locale('cn') as person:
        assert person.get_name(gender=None) != person.get_name(gender=None)



# Generated at 2022-06-23 21:05:01.087048
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with BaseDataProvider() as p:
        assert p.get_current_locale() == 'en'
    with BaseDataProvider(locale=locales.RU) as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:05:03.168845
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # create and check the BaseDataProvider object
    base_provider = BaseDataProvider()
    assert base_provider
    assert base_provider.locale == 'en'
    assert base_provider._data_dir == Path('/home/nikita/mimesis/mimesis/data')



# Generated at 2022-06-23 21:05:05.741501
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    w = BaseProvider(seed = "")
    assert str(w) == 'BaseProvider'

# Generated at 2022-06-23 21:05:09.346833
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import UnitSystem
    with UnitSystem('ar').override_locale('ru'):
        assert UnitSystem().get_current_locale() == 'ru'
    assert UnitSystem().get_current_locale() == 'ar'

# Generated at 2022-06-23 21:05:12.103998
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    Provider = BaseProvider()

    # Test values:
    # str(Provider) -> 'BaseProvider'

test_BaseProvider()

# Generated at 2022-06-23 21:05:19.182030
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Gender
    from mimesis.enums import Gender as Gen
    from mimesis.providers.person import Person
    from mimesis.utils import random_boolean

    person = Person('en')
    person_ru = Person('ru')

    assert person.get_current_locale() == 'en'
    assert person_ru.get_current_locale() == 'ru'

    assert person.random_gender(
        {Gen.FEMALE, Gen.MALE}) in (Gen.FEMALE, Gen.MALE)

    with person.override_locale(locales.DEFAULT_LOCALE):
        assert person.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:05:26.262349
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.enums import Gender, WeightUnit
    from mimesis.providers.person import Person

    with Person().override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert isinstance(person.age(), int) is True
        assert person.gender(Gender.MALE) == 'male'
        assert isinstance(person.weight(800, WeightUnit.KILOGRAM),
                          float) is True
        assert person.occupation() in person._data['occupations']

# Generated at 2022-06-23 21:05:29.652249
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """locale-dependent providers."""
    with BaseProvider(seed='test') as test:
        assert test.random.get_state().get('randomseed') == 'test'



# Generated at 2022-06-23 21:05:33.458538
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test: BaseDataProvider: get_current_locale().

    :return: Nothing.
    """
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-23 21:05:41.157849
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def get_provider(cls):
        provider = cls()

        return provider
    from mimesis.builtins import Finance
    provider = get_provider(Finance)
    with provider.override_locale('ru'):
        assert(provider.currency_code() == 'RUB')
    assert(provider.currency_code() == 'USD')

    provider = get_provider(Finance)
    with provider.override_locale('en'):
        assert(provider.currency_code() == 'USD')

# Generated at 2022-06-23 21:05:42.822203
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    baseProvider = BaseProvider()
    assert str(baseProvider) == "BaseProvider"

# Generated at 2022-06-23 21:05:46.914574
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.providers import Person
    import os
    import time
    prov = Person()
    seed = 1234
    prov.reseed(seed)
    time.sleep(1)
    prov.reseed(seed)
    assert str(prov) == "Person"

# Generated at 2022-06-23 21:05:50.964424
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider('pl')
    assert provider.get_current_locale() == 'pl'

    provider.set_locale('ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:05:58.096169
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class MyProvider(BaseDataProvider):
        def something(self):
            return self.locale

    my_provider = MyProvider('en')

    assert my_provider.get_current_locale() == 'en'
    assert my_provider.something() == 'en'

    with my_provider.override_locale('zxx') as zxx_provider:

        assert zxx_provider.something() == 'zxx'
        assert zxx_provider.get_current_locale() == 'zxx'
        assert my_provider.get_current_locale() == 'zxx'

    assert my_provider.something() == 'en'
    assert my_provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:00.747394
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()

    assert provider.get_current_locale() == 'en'
    provider.locale = 'ru'

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:06:01.541423
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    module = BaseDataProvider()
    module.reseed()

# Generated at 2022-06-23 21:06:04.735032
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    A = BaseDataProvider()
    assert A.__str__() == 'BaseDataProvider <en>'

    B = BaseDataProvider(locale='zh')
    assert B.__str__() == 'BaseDataProvider <zh>'


# Generated at 2022-06-23 21:06:08.123259
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for BaseDataProvider.get_current_locale"""
    from mimesis.builtins import Person

    provider = Person()
    provider.locale = 'en'
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:12.769575
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import random
    rgen = Random()
    rgen.seed(1)
    num = rgen.randint(0, 100)
    assert num == 61
    b = BaseProvider(seed=1)
    b.random = rgen
    b.reseed(2)
    num = b.random.randint(0, 100)
    assert num == 77
    assert b.random != rgen


# Generated at 2022-06-23 21:06:14.492123
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:06:19.667077
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()).__eq__('BaseDataProvider <en>')
    assert str(BaseDataProvider()).__eq__(id)
    assert str(BaseDataProvider()).__eq__(locals)
    assert str(BaseDataProvider()).__eq__(object)
    assert str(BaseDataProvider()).__eq__(object)


# Generated at 2022-06-23 21:06:28.110816
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.schema import Field
    from mimesis.typing import Seed
    from mimesis.providers.base import BaseProvider

    bp = BaseProvider()
    bp2 = BaseProvider()
    seed: int = 1

    f = Field()
    assert f.random.randint(0, 100) == 29
    f._seed = seed
    assert f.random.randint(0, 100) == 48

    bp.reseed(seed)
    assert bp.random != random
    assert bp.random.randint(0, 100) == 48
    bp.reseed()
    assert bp.random != random
    assert bp.random != bp2.random
    bp.reseed(bp2.random)
    assert bp.random == bp2.random

#

# Generated at 2022-06-23 21:06:29.720878
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:06:31.645407
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider(seed=12)
    assert p.seed == 12
    assert p.random is not random

    p.reseed(seed=123)
    assert p.seed == 123



# Generated at 2022-06-23 21:06:39.786352
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Base data provider class."""
    # Test Case 1
    obj = BaseDataProvider()
    print(obj.locale) #en

    # Test Case 2
    obj = BaseDataProvider(locale='en')

    # Test Case 3
    obj = BaseDataProvider(locale='ja')

    # Test Case 4
    obj = BaseDataProvider(locale='de')

    # Test Case 5
    obj = BaseDataProvider(locale='ru')

    # Test Case 6
    obj = BaseDataProvider(locale='zh-cn')



# Generated at 2022-06-23 21:06:49.087278
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit tests for method get_current_locale of class BaseDataProvider."""
    # When call method BaseDataProvider.get_current_locale:
    #     If locale not exist:
    #         Should return en
    env_provider = BaseDataProvider()
    assert env_provider.get_current_locale() == locales.DEFAULT_LOCALE
    #     If locale exist:
    #         Should return locale
    env_provider = BaseDataProvider(locale='es')
    assert env_provider.get_current_locale() == 'es'
    #     If locale is not defined:
    #         Should return en
    env_provider = BaseDataProvider()
    assert env_provider.get_current_locale() == locales.DEFAULT_LOCALE
    #     If locale is not defined:

# Generated at 2022-06-23 21:06:55.468928
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class _Dummy(BaseDataProvider):
        """Dummy class to test method override_locale of class BaseDataProvider"""

        def get_current_locale(self):
            """Get current locale."""
            return self.locale

    dummy = _Dummy()
    dummy.locale = locales.EN
    with dummy.override_locale(locale=locales.RU):
        assert dummy.locale == locales.RU
    assert dummy.locale == locales.EN
    
    no_locale = _Dummy()
    with pytest.raises(ValueError):
        with no_locale.override_locale(locales.RU):
            assert no_locale.locale == locales.RU

# Generated at 2022-06-23 21:07:06.350952
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed of BaseProvider"""
    bp = BaseProvider(seed=1)
    assert bp.random.current_seed == 1
    bp.random.randint(1, 2) == 1
    bp.random.randint(1, 2) == 1
    bp.random.randint(1, 2) == 1
    bp.reseed()
    assert bp.random.current_seed != 1
    assert bp.random.randint(1, 2) == 2
    assert bp.random.randint(1, 2) == 1
    assert bp.random.randint(1, 2) == 2
    bp.reseed(seed=1)
    assert bp.random.current_seed == 1
    assert bp.random.randint(1, 2) == 1

# Generated at 2022-06-23 21:07:07.265062
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider


# Generated at 2022-06-23 21:07:09.746861
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.base import BaseDataProvider

    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:07:11.791145
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.base import BaseProvider as BP
    p = BP()
    assert isinstance(str(p), str)


# Generated at 2022-06-23 21:07:13.465476
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseDataProvider = BaseDataProvider()
    assert isinstance(baseDataProvider, BaseDataProvider)

# Generated at 2022-06-23 21:07:15.902621
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider()
    base_provider.reseed(seed=42)
    result = base_provider.random.randint(1000, 2000)
    assert result == 1229

# Generated at 2022-06-23 21:07:26.406828
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.random import Random
    from mimesis.builtins import Generic
    from mimesis.enums import Gender

    generic = Generic('en')
    random = Random()

    first = generic.create_identifier(gender=Gender.FEMALE)
    second = generic.create_identifier(gender=Gender.FEMALE)

    if first == second:
        raise ValueError('Values should be different, but are not.')

    generic.reseed()

    third = generic.create_identifier(gender=Gender.FEMALE)

    if generic.seed is not random.seed:
        raise ValueError('Seed is not the same')

    if third != first:
        raise ValueError('Value should be the same, but are not.')



# Generated at 2022-06-23 21:07:31.382229
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    assert base.locale == 'en'
    assert base.seed == None
    assert base.random == random
    assert base._data == {}
    assert base._datafile == ''
    base._setup_locale('en')
    base.locale == 'en'
    base = BaseDataProvider('en')

# Generated at 2022-06-23 21:07:36.989384
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1569820779.0609493
    local_random = Random()
    local_random.seed(seed)
    provider = BaseProvider()
    provider.reseed(seed)
    assert provider.seed == seed
    assert provider.random == local_random
if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:07:45.018182
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            self._data['hello'] = 'Привет'
            self._data['world'] = 'мир!'

    a = A()
    assert a.hello == 'Привет'
    assert a.world == 'мир!'

    with a.override_locale('en') as a:
        assert a.hello == 'Привет'
        assert a.world == 'мир!'

    a._pull.cache_clear()

    assert a.hello == 'Привет'
    assert a.world == 'мир!'

    a._override_locale('ru')


# Generated at 2022-06-23 21:07:46.269952
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random == random


# Generated at 2022-06-23 21:07:49.610609
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""
    provider = BaseProvider(seed=None)
    expected_result = get_random_item(locales.SUPPORTED_LOCALES, provider.random)
    assert (expected_result == provider.reseed(seed=None).random.randint(0, 10))

# Generated at 2022-06-23 21:07:52.060589
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:07:55.054765
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """BaseProvider: Value of __str__ method should return Provider name."""
    provider = BaseProvider()
    assert str(provider) == provider.__class__.__name__

# Generated at 2022-06-23 21:07:56.803475
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='ru')


# Generated at 2022-06-23 21:07:57.765203
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """."""


# Generated at 2022-06-23 21:08:01.501877
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        pass
    p = MyProvider()
    with p.override_locale('br') as provider:
        assert provider.locale == 'br'
    assert p.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:08:02.568642
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed = 'test_seed')

# Generated at 2022-06-23 21:08:10.886906
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == 'en'
    assert bdp._data == {}
    assert bdp.seed is None
    assert bdp.random is random
    assert bdp._datafile == ''
    assert bdp._pull.cache_info().currsize == 0
    assert bdp._pull.cache_info().maxsize == None

    with bdp.override_locale('es'):
        assert bdp.locale == 'es'
        assert bdp._data == {}
        assert bdp.seed is None
        assert bdp.random is random
        assert bdp._datafile == ''
        assert bdp._pull.cache_info().currsize == 0
        assert bdp._pull.cache_info().maxsize == None

# Generated at 2022-06-23 21:08:14.053742
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    test = BaseDataProvider()
    test_locale = test.get_current_locale()
    assert test_locale == 'en'



# Generated at 2022-06-23 21:08:17.564234
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en-US'
    provider = BaseDataProvider(locale=locale)
    assert provider.get_current_locale() == locale



# Generated at 2022-06-23 21:08:23.341652
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locale=locales.RU):
        assert provider.locale == locales.RU

    assert provider.locale == locales.EN