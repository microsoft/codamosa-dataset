

# Generated at 2022-06-23 20:58:28.736657
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    def assert_locale(provider: BaseDataProvider, locale: str):
        assert locale in locales.SUPPORTED_LOCALES
        assert provider.locale == locale

    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None):
            self._datafile = 'test.json'
            super().__init__(locale, seed)

        def get_data(self, key: str) -> Any:
            return self._data.get('test')

    provider = TestProvider()
    assert_locale(provider, locales.EN)

    # en
    with provider.override_locale(locales.EN):
        assert_locale(provider, locales.EN)

# Generated at 2022-06-23 20:58:32.719182
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert getattr(provider, '_data', None) == {}
    assert not hasattr(provider, '_datafile')
    assert not hasattr(provider, '_data_dir')
    assert getattr(provider, 'locale', None) == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 20:58:36.014108
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 20:58:48.521924
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""

    class LocalizedProvider(BaseDataProvider):
        """Class to test locale override."""

        def __init__(self, locale: str = locales.EN):
            """Initialise."""
            super().__init__(locale)

        def get_full_name(self) -> str:
            """Get full name."""
            return '{} {}'.format(self.name(gender='male'), self.last_name())

    class OverrideProvider(LocalizedProvider):
        """Class to test locale override."""

        def __init__(self, locale: str = locales.EN):
            """Initialise."""
            super().__init__(locale)

        def override(self) -> None:
            """Override locale."""

# Generated at 2022-06-23 20:58:49.785846
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pass

if __name__ == '__main__':
    test_BaseProvider()

# Generated at 2022-06-23 20:58:51.711041
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=123)
    assert provider.seed == 123
    assert provider.random is not random

# Generated at 2022-06-23 20:58:52.555112
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b=BaseProvider()


# Generated at 2022-06-23 20:58:55.202417
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider.__str__(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 20:58:57.284821
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    p = BaseProvider()
    seed = p.seed

    # Call the method reseed, because the previous value is None
    p.reseed(seed="foo")
    assert p.seed == "foo"
    assert p.random != random



# Generated at 2022-06-23 20:59:04.596415
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    '''
        This function is used to unittest the BaseProvider class.
    '''
    a = BaseProvider()
    assert(a.seed == None)
    assert(a.random == random)
    b = BaseProvider(seed = None)
    assert(b.seed == None)
    assert(b.random == random)
    c = BaseProvider(seed = 1)
    assert(c.seed == 1)
    assert(c.random != random)
    d = BaseProvider(seed = 1)
    assert(d.seed == 1)
#test_BaseProvider()


# Generated at 2022-06-23 20:59:08.957195
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class DummyProvider(BaseProvider):
        """Dummy class for testing."""
        def __init__(self, seed: Seed = None):
            super().__init__(seed)

    provider = DummyProvider(seed=123)
    assert provider.seed == 123

    provider.reseed()
    assert provider.seed != 123

    provider.reseed(seed=1234)
    assert provider.seed == 1234



# Generated at 2022-06-23 20:59:11.420616
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    real_person = Person()
    print(real_person, real_person.full_name())

    with real_person.override_locale('ru') as fake_person:
        print(fake_person, fake_person.full_name())

    print(real_person, real_person.full_name())

# Generated at 2022-06-23 20:59:14.873424
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for BaseDataProvider.get_current_locale() method."""
    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:18.464466
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    from mimesis.providers.base import BaseDataProvider
    p = BaseDataProvider('es-ES')
    assert p.get_current_locale() == 'es-es'

# Generated at 2022-06-23 20:59:19.960353
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    print("BaseProvider: ", provider)



# Generated at 2022-06-23 20:59:23.102333
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """This is test for method get_current_locale of class BaseDataProvider."""
    TestBaseDataProvider = BaseDataProvider()
    assert TestBaseDataProvider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:25.504808
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=0)
    assert provider.seed == 0
    provider = BaseProvider(seed=None)
    assert provider.seed != 0


# Generated at 2022-06-23 20:59:28.729266
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider.

    :return: Nothing.
    """
    a=BaseProvider()
    temp=str(a)
    temp2=type(temp)
    assert('BaseProvider')==temp
    assert(str)==temp2


# Generated at 2022-06-23 20:59:31.921487
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    t = BaseProvider()
    assert str(t) == 'BaseProvider'
    assert repr(t) == 'BaseProvider'


# Generated at 2022-06-23 20:59:36.348885
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Child(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    provider = Child(locale=locales.EN)
    print(provider.get_current_locale())
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.FR):
        print(provider.get_current_locale())
        assert provider.get_current_locale() == locales.FR

    print(provider.get_current_locale())
    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-23 20:59:38.084093
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    d = BaseDataProvider()
    assert d.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 20:59:43.434630
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p is not None
    assert p.seed is None
    assert p.random is random

    import time
    seed = int(time.time())
    p2 = BaseProvider(seed=seed)
    assert p2.seed == seed
    assert p2.random is not random

# Generated at 2022-06-23 20:59:48.138387
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis import Personal
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.base import locales
    from mimesis.typing import JSON
    from pathlib import Path
    from unittest.mock import MagicMock
    from unittest.mock import patch
    
    # Set up locale to 'en'
    locale = locales.EN
    # Set up the name of data provider
    provider = Personal
    # Set up data dir
    data_dir = Path(__file__).parent.parent.joinpath('data')
    # Set up data file to 'personal.json'
    datafile = 'personal.json'
    # Set up the expected result
    expected = 'Personal <en>'
    #

# Generated at 2022-06-23 20:59:55.713384
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    BaseProvider()
    p = Person(locale='en', seed=None)
    assert p.name() == 'James'
    assert p.surname() == 'Powers'
    assert p.username() == 'jpowers'

    Person(locale='en', seed=42)
    assert Person(locale='en', seed=42).name() == 'David'
    assert Person(locale='en', seed=42).name(gender=Gender.FEMALE) == 'Laura'

# Generated at 2022-06-23 20:59:59.009620
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().random is random
    assert BaseProvider(seed=1).random is not random


# Generated at 2022-06-23 21:00:02.374188
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b_d_p = BaseDataProvider()
    assert str(b_d_p) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:12.803042
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    import mimesis.providers.base_provider as base_provider
    from mimesis.providers.base_provider import BaseDataProvider

    def test_class():
        assert BaseDataProvider()

    def test_reseed():
        bdp = BaseDataProvider()
        assert bdp.seed is None
        bdp.reseed()
        assert bdp.seed is not None

    def test_init():
        assert BaseDataProvider().locale == locales.DEFAULT_LOCALE
        assert BaseDataProvider(locale=locales.EN).locale == locales.EN
        assert BaseDataProvider(locale=locales.RU).locale == locales.RU

    def test_update_dict():
        bdp = BaseDataProvider()

# Generated at 2022-06-23 21:00:14.963461
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:00:20.499803
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    global provider
    assert provider.get_current_locale() == locales.EN
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:00:23.470367
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Arrange

    # Act
    b = BaseDataProvider()

    # Assert
    assert b.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:00:24.346923
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:28.864635
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    '''Test get_current_locale method'''
    arg1 = 'ar'
    arg2 = 'en'

    result1 = BaseDataProvider(arg1).get_current_locale()
    result2 = BaseDataProvider(arg2).get_current_locale()
    assert (result1==arg1)
    assert (result2==arg2)


# Generated at 2022-06-23 21:00:34.993280
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of BaseProvider."""
    provider = BaseProvider(seed=int(time.time()))
    return provider

if __name__ == '__main__':
    # Unit test for constructor of class BaseProvider
    #print(test_BaseProvider())
    # Unit test for constructor of class BaseDataProvider
    print(BaseDataProvider(locale='en', seed=int(time.time())))

# Generated at 2022-06-23 21:00:36.167912
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class FakeProvider(BaseProvider):
        pass

    assert str(FakeProvider()) == 'FakeProvider'

# Generated at 2022-06-23 21:00:37.726165
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:00:43.383615
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'test_provider.json'
            self._pull()

        def test(self):
            return self._data['data']['a']['b']

    provider = TestProvider()
    with provider.override_locale('ru'):
        assert provider.test() == 'ru'
    assert provider.test() == 'en'

# Generated at 2022-06-23 21:00:45.002166
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider(seed=123).reseed(321)




# Generated at 2022-06-23 21:00:47.056337
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:52.013150
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class Provider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)

    p1 = Provider()
    p1_iterable1 = iter(p1.random.choices(range(10), k=10))
    p1.reseed()
    p1_iterable2 = iter(p1.random.choices(range(10), k=10))
    p2 = Provider()
    p2_iterable = iter(p2.random.choices(range(10), k=10))
    assert p1_iterable1 == p1_iterable2
    assert p1_iterable1 != p2_iterable
    assert p2_iterable != p1_iterable2

# Generated at 2022-06-23 21:00:54.209474
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    p = BaseProvider()
    assert p.seed is None
    p.reseed(12345)
    assert p.seed == 12345

# Generated at 2022-06-23 21:00:54.833831
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider()

# Generated at 2022-06-23 21:00:58.651195
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Food
    f = Food(seed=123)
    with f.override_locale(locales.DE):
        assert f.get_current_locale() == locales.DE

    assert f.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:01:00.192745
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = '123'
    assert BaseProvider(seed=seed).seed == seed


# Generated at 2022-06-23 21:01:02.093770
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    p = BaseProvider()
    p.reseed()
    assert p.seed is not None

# Generated at 2022-06-23 21:01:08.481071
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    try:
        print("\nRunning test_BaseDataProvider_get_current_locale...\n")
        assert BaseDataProvider(locale="en").get_current_locale() == "en", "BaseDataProvider.get_current_locale() failed"
        print("BaseDataProvider.get_current_locale() passed")
    except AssertionError as err:
        print("[{0}] {1}".format(type(err).__name__, str(err)))

# Generated at 2022-06-23 21:01:09.952925
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'

# Generated at 2022-06-23 21:01:16.341946
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    
    b = BaseDataProvider()

    b = BaseDataProvider(locale='en', seed=123)

    b = BaseDataProvider(locale='', seed=None)
    b = BaseDataProvider(locale=None, seed=None)
    b = BaseDataProvider(locale='en', seed=None)



# Generated at 2022-06-23 21:01:20.546073
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.base import BaseDataProvider
    from mimesis.builtins import Builtins
    assert BaseDataProvider().get_current_locale() == 'en'
    assert Builtins().get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:22.986796
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestDataProvider(BaseDataProvider):
        pass
    dp = TestDataProvider()
    assert dp.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:24.816019
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random

# Generated at 2022-06-23 21:01:32.595035
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.RU,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
        @property
        def some(self) -> str:
            return 'Я знаю'
        @property
        def answer(self) -> int:
            return 42

    provider = TestProvider()

    with provider.override_locale(locales.DE):
        assert provider.some == 'Ich weiß'
        assert provider.answer == 42

    assert provider.some == 'Я знаю'
    assert provider.answer == 42

# Generated at 2022-06-23 21:01:35.722495
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from  mimesis import Person
    provider=Person(seed='asd')
    print(provider.seed)
    provider.reseed(seed=1)
    print(provider.seed)


# Generated at 2022-06-23 21:01:41.746155
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import LOCALES
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.datetime import DateTime
    from mimesis.providers.number import Number
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit
    from mimesis.locales import EN
    dtp = DateTime(EN)
    np = Number(EN)
    perp = Person(EN)
    tp = Text(EN)
    up = Unit(EN)
    assert dtp.get_current_locale() == EN
    assert np.get_current_locale() == EN
    assert perp.get_current_locale() == EN
    assert tp.get

# Generated at 2022-06-23 21:01:45.903104
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bd = BaseDataProvider(locale='en', seed=420)
    assert bd.get_current_locale() == 'en'
    assert bd.seed == 420
test_BaseDataProvider()

# Generated at 2022-06-23 21:01:50.058879
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""
    obj1 = BaseProvider(seed=12345)
    assert obj1.seed == 12345

    obj1.reseed()
    assert obj1.seed is None

    obj1.reseed(seed=54321)
    assert obj1.seed == 54321


# Generated at 2022-06-23 21:01:53.057773
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider() is not None
    assert BaseProvider().seed is None
    assert BaseProvider(seed=1234) is not None
    assert BaseProvider(seed=1234).seed is not None



# Generated at 2022-06-23 21:01:57.158723
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider()
    assert str(test_provider) == 'BaseDataProvider <en>'
    test_provider.locale = 'ru'
    assert str(test_provider) == 'BaseDataProvider <ru>'
    test_provider.locale = 'en'
    assert str(test_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:59.220915
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider('en')
    result = provider.get_current_locale()
    assert result == 'en'
    assert isinstance(result, str)


# Generated at 2022-06-23 21:02:00.650534
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseProvider(seed=4)) == 'BaseProvider'
    pass


# Generated at 2022-06-23 21:02:02.508428
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    bp = BaseDataProvider(locale='ru')
    assert bp.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:02:05.073905
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=42)
    assert provider.seed == 42
    assert provider.random == random


# Generated at 2022-06-23 21:02:14.034782
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    l = c.get_current_locale()
    print("Current locale: " + l)
    with c.override_locale("en"):
        assert c.get_current_locale() == "en"
    with pytest.raises(ValueError):
        with Cryptographic().override_locale("de"):
            pass
    # Test if this bug has been fixed.
    # https://github.com/lk-geimfari/mimesis/issues/24
    with Cryptographic(locale="en").override_locale("ru"):
        assert Cryptographic(locale="en").get_current_locale() != "ru"

# Generated at 2022-06-23 21:02:17.965811
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=0)
    assert p.random.seed(0) == p.random.seed(0)
    assert p.random.seed(0) != p.random.seed(1)



# Generated at 2022-06-23 21:02:21.144618
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    class TestBaseProvider(BaseProvider):
        pass
    subclass = TestBaseProvider()
    assert subclass.__str__() == 'TestBaseProvider'


# Generated at 2022-06-23 21:02:24.524751
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider(locale='mx')
    assert str(p) == 'BaseDataProvider <mx>'
    p.locale = 'en'
    assert str(p) == 'BaseDataProvider <en>'
    assert repr(p) == "<BaseDataProvider <en>>"

# Generated at 2022-06-23 21:02:25.142741
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(seed = 0).seed == 0

# Generated at 2022-06-23 21:02:26.474653
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__."""
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:02:32.313304
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = 'RU', seed: Seed = None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'dummy.json'
            self._pull()

        def get_currency_code(self):
            return self._data['currency']['code']

    tdp = TestDataProvider()

    assert tdp.get_current_locale() == 'RU'
    assert tdp.get_currency_code() == 'RUR'

    with tdp.override_locale(locale='EN') as t:
        assert t.get_current_locale() == 'EN'
        assert t.get_currency_code() == 'USD'

    assert tdp.get_current_

# Generated at 2022-06-23 21:02:35.659061
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Create an object of BaseDataProvider
    x = BaseDataProvider()
    # Check the behaviour of method __str__
    x.locale = 'ru'
    assert str(x) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:02:37.885871
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.custom.text import Text
    t = Text()
    assert str(t) == 'Text <en>'

# Generated at 2022-06-23 21:02:45.640645
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method BaseDataProvider._override_locale."""

    from mimesis.providers.address import Address
    from mimesis.providers.text import Text

    class MyProvider(BaseDataProvider):
        """My Provider."""

        def _pull(self):
            """Mock _pull method."""
            pass

        def get_current_locale(self):
            """Mock get_current_locale method."""
            return self.locale

    p = MyProvider()
    with p.override_locale('fr'):
        assert p.locale == 'fr'

    p.locale = 'fr'
    with p.override_locale('en'):
        assert p.locale == 'en'

    address = Address(locale='fr')

# Generated at 2022-06-23 21:02:47.535226
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print(locals())
    assert True

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-23 21:02:51.955818
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
	seed = 1
	dataProvider = BaseDataProvider(seed=seed)
	assert dataProvider.seed == seed
	assert str(dataProvider) == 'BaseDataProvider'

# Generated at 2022-06-23 21:02:54.636206
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider('a')
    assert obj.seed == 'a'
    assert isinstance(obj.random, Random)
    return None


# Generated at 2022-06-23 21:02:56.306170
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Phone
    assert str(Phone()) == "Phone <{}>".format(Phone().locale)

# Generated at 2022-06-23 21:02:58.736795
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider.__str__() == 'BaseDataProvider <en>'
    baseDataProvider = BaseDataProvider('en')
    assert baseDataProvider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:01.489631
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider()
    assert data._data == {}, 'expect _data is {}'
    assert data._datafile == '', 'expect _datafile is ""'
    assert data.locale == 'en', 'expect locale is "en"'


#test for _pull()

# Generated at 2022-06-23 21:03:03.877169
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    provider.reseed(seed=10)
    assert provider.seed == 10


# Generated at 2022-06-23 21:03:06.355209
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(BaseProvider())
    print(BaseProvider(seed="1"))
    print(BaseProvider(seed=2))


# Generated at 2022-06-23 21:03:07.770034
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    str(dp)

# Generated at 2022-06-23 21:03:09.173573
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"


# Generated at 2022-06-23 21:03:11.970484
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    print(provider)
    assert(1 == 1)

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:03:14.898501
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 100
    random.seed(seed)
    bp = BaseProvider(seed)
    assert bp.random.getrandbits(10) == random.getrandbits(10)


# Generated at 2022-06-23 21:03:17.119089
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == "en"

# Generated at 2022-06-23 21:03:23.812071
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def get_data(self, key: str, value: str) -> dict:
            return value

    t = TestProvider()

    # override locale
    with t.override_locale('ru') as provider:
        assert provider.get_data('key', 'value') == 'value'

    # if invalid locale raise ValueError
    with pytest.raises(ValueError):
        with t.override_locale('invalid_locale') as provider:
            provider.get_data('key', 'value')



# Generated at 2022-06-23 21:03:26.885303
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale()=='en'

    # Run tests
test_BaseDataProvider_get_current_locale()



# Generated at 2022-06-23 21:03:32.767972
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale for class BaseDataProvider."""
    from mimesis.providers import Person

    person = Person()
    assert person.get_full_name() == 'Isaac Newton'

    with person.override_locale('ru') as per:
        assert per.get_full_name() == 'Иосиф Виссарионович Сталин'

    assert person.get_full_name() == 'Isaac Newton'



# Generated at 2022-06-23 21:03:33.293273
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()

# Generated at 2022-06-23 21:03:36.304383
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test BaseDataProvider.get_current_locale() method."""
    p = BaseDataProvider()
    assert p.get_current_locale() == locales.DEFAULT_LOCALE
    p._override_locale('ru')
    assert p.get_current_locale() == locales.RU


# Generated at 2022-06-23 21:03:39.184786
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider(locale='et')
    assert str(bdp) == '{} <{}>'.format(bdp.__class__.__name__, 'et')

# Generated at 2022-06-23 21:03:43.150036
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for __str__ method."""
    with BaseDataProvider.override_locale('ru') as russian:
        assert str(russian) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:03:45.323410
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:03:50.559789
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """
    Unit tests for method __str__ of class BaseDataProvider
    """

    result = str(BaseDataProvider(locale=locales.EN))
    assert str(result) == 'BaseDataProvider <en>'

    result_1 = str(BaseDataProvider(locale=locales.RU))
    assert str(result_1) == 'BaseDataProvider <ru>'

    result_2 = str(BaseDataProvider(locale=locales.DEFAULT_LOCALE))
    assert str(result_2) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:03:52.686008
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en-GB'
    b = BaseDataProvider(locale)
    assert b.get_current_locale() == locale

# Generated at 2022-06-23 21:04:00.421486
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    from mimesis.providers.base import BaseProvider

    provider = BaseProvider(seed=42)
    assert provider.seed == 42

    provider.reseed()
    assert provider.seed is None

    provider.reseed(seed=23)
    assert provider.seed is 23

    provider.reseed(seed=42)
    assert provider.seed == 42
    assert provider.seed is not 42


# Generated at 2022-06-23 21:04:01.865116
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pass


# Generated at 2022-06-23 21:04:04.843437
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:04:09.185724
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'it'
    base = BaseDataProvider(locale=locale)
    assert base.get_current_locale() == locale

    base = BaseDataProvider(locale='')
    assert base.get_current_locale() == 'en'

# Generated at 2022-06-23 21:04:12.149945
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    print(bdp)
    assert bdp.locale == 'en'


# Generated at 2022-06-23 21:04:14.005893
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert eval('BaseProvider().__str__()') == "BaseProvider"

# Generated at 2022-06-23 21:04:16.440795
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Data
    provider = BaseDataProvider(locale='ru', seed=1)

    # Action
    current_locale = provider.get_current_locale()

    # Assertion
    assert current_locale == 'ru'

if __name__ == '__main__':
    test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-23 21:04:28.333883
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import EnumEvent
    import pytest
    class TestProv(BaseDataProvider):

        def __init__(self, seed=None, locale=locales.DEFAULT_LOCALE):
            super().__init__(seed, locale)
            self._datafile = 'test.json'

        def get_weekend_day(self, day=None) -> EnumEvent:
            """Return the weekend day."""
            if 'weekend_days' not in self._data:
                self._pull()
            return self._validate_enum(
                day, EnumEvent
            )  # noqa

    item = EnumEvent.SUNDAY
    prov = TestProv(locale=locales.RU)

# Generated at 2022-06-23 21:04:29.693330
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    assert data_provider is not None

# Generated at 2022-06-23 21:04:32.331960
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    # It is not possible to check the result of reseed.
    provider.reseed(1234)



# Generated at 2022-06-23 21:04:40.530054
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print ("\n--- Test of BaseDataProvider class constructor ---")
    # Expected result
    result = "BaseDataProvider <en>"
    # Obtained result
    base_data_provider = BaseDataProvider()
    obtained=str(base_data_provider)
    # Test
    if result == obtained:
        print("Test OK, the constructor BaseDataProvider class works correctly.")
    else:
        print("Test FAILED. The obtained result is {}, and the expected result is {}".format(obtained, result))


# Generated at 2022-06-23 21:04:42.530480
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert p.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:47.256221
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    import pytest
    
    class TestBaseProvider(BaseProvider):
        pass

    tbp = TestBaseProvider()
    assert tbp.__str__() == 'TestBaseProvider'
    print(tbp)
    assert pytest.raises(AttributeError, lambda: (tbp.__str__('tilda')))
    
    
    

# Generated at 2022-06-23 21:04:54.297907
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method of BaseProvider class."""
    random_ = Random()
    random_.seed(69)

    BR = BaseProvider()
    assert BR.seed is None
    assert BR.random is random
    length = len(BR.__dict__)

    BR.reseed(69)
    assert BR.seed == 69
    assert BR.random == random_
    assert len(BR.__dict__) == length + 2



# Generated at 2022-06-23 21:04:56.621923
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='ru')
    assert provider.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:05:00.699243
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    a = BaseProvider()
    a.reseed(123)
    assert a.random.get_seed() == 123
    assert a.random.randint(1, 100) != BaseProvider(123).random.randint(1, 100)



# Generated at 2022-06-23 21:05:02.105518
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp is not None


# Generated at 2022-06-23 21:05:08.235673
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Code
    from mimesis import locales

    provider = Code(seed=42)
    assert str(provider) == 'Code <en>'

    provider = Code(locale=locales.DEFAULT_LOCALE, seed=42)
    assert str(provider) == 'Code <en>'

    provider = Code(locale=locales.RU, seed=42)
    assert str(provider) == 'Code <ru>'

    provider = Code(locale=locales.RU, seed=42)
    assert str(provider) == 'Code <ru>'

# Generated at 2022-06-23 21:05:10.557953
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # GIVEN
    provider_base = BaseDataProvider()
    provider_base.locale = 'ja_JP'

    # WHEN
    result = str(provider_base)

    # THEN
    assert result == 'BaseDataProvider <ja_JP>'

# Generated at 2022-06-23 21:05:17.908254
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    import mimesis.schemas as schemas
    prov = schemas.Schemas()
    prov.set_random_seed("seed")
    with prov.override_locale("en") as sch_en:
        assert sch_en.locale == "en"
        sch_en.seed = "test"
        assert sch_en.seed == "test"
    with prov.override_locale("ru") as sch_ru:
        assert sch_ru.locale == "ru"
        sch_ru.seed = "test"
        assert sch_ru.seed == "test"
    assert prov.locale == "en"

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 21:05:20.713128
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider(locale='en')
    assert data_provider.__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:05:22.786021
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
  from mimesis import Person
  
  assert str(Person('en')) == 'Person <en>'
  


# Generated at 2022-06-23 21:05:23.580777
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider.__init__

# Generated at 2022-06-23 21:05:25.178727
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    bt = BaseDataProvider()
    # Assert
    assert str(bt) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:28.249933
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale``."""
    a = BaseDataProvider('en')
    a.locale = 'ru'

    with a.override_locale('en') as b:
        assert b == '<class \'mimesis.providers.base.BaseDataProvider\'> <en>'
    assert b.locale == 'ru'

# Generated at 2022-06-23 21:05:31.389131
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Given
    provider = BaseProvider()

    # When
    result = str(provider)

    # Then
    assert result == 'BaseProvider'


# Generated at 2022-06-23 21:05:32.575071
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider(seed=12345)


# Generated at 2022-06-23 21:05:38.065557
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def get_city(self) -> str:
            return self._data['cities']['kyiv']

    provider = DataProvider()
    with provider.override_locale('en') as p:
        assert p.get_city() == 'Kyiv'


# This method was created for the example above

# Generated at 2022-06-23 21:05:39.273804
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
  assert BaseProvider(seed=1).__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:05:42.908264
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__."""
    expected_value = 'BaseProvider'
    provider = BaseProvider()
    actual_value = provider.__str__()
    assert actual_value == expected_value


# Generated at 2022-06-23 21:05:45.715875
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.base import BaseProvider as _BaseProvider

    bp = _BaseProvider()
    assert isinstance(bp.__str__(), str)

# Generated at 2022-06-23 21:05:47.028526
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.random.get_seed() == 0



# Generated at 2022-06-23 21:05:54.283909
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Testing method reseed of class BaseProvider"""
    from mimesis.builtins import Person
    from mimesis.enums import Gender


    seed = '1234'
    fake = Person(seed=seed)
    random_gender = fake.gender()
    fake2 = Person(seed=seed)
    random_gender2 = fake2.gender()
    fake.reseed()
    random_gender3 = fake.gender()
    fake2.reseed()
    random_gender4 = fake2.gender()
    assert random_gender == random_gender2
    assert random_gender3 != random_gender4


# Generated at 2022-06-23 21:05:55.844142
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider is not None


# Generated at 2022-06-23 21:05:58.589275
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    assert(base is not None)
    assert(base._validate_enum("test", "") is not None)
    return



# Generated at 2022-06-23 21:06:01.563797
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert True

# TODO: Need add tests.

# Generated at 2022-06-23 21:06:03.815345
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=123)
    assert bp.seed == 123
    assert bp.random
    bp.reseed()
    assert bp.seed



# Generated at 2022-06-23 21:06:09.300783
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Unit
    unit = Unit()
    unit_str = str(unit)
    assert unit_str == "Unit <en>"
    unit.locale = "zh-cn"
    assert str(unit) == "Unit <zh-cn>"

# Generated at 2022-06-23 21:06:17.547624
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    def test_BaseProvider_non_default_seed():
        base_provider_obj = BaseProvider(seed='4')
        assert isinstance(base_provider_obj, BaseProvider)
    def test_BaseProvider_default_seed():
        base_provider_obj = BaseProvider()
        assert isinstance(base_provider_obj, BaseProvider)
    def test_BaseProvider_reseed():
        base_provider_obj = BaseProvider(seed='4')
        base_provider_obj.reseed()
        assert isinstance(base_provider_obj.seed,int)
        base_provider_obj.reseed('5')
        assert isinstance(base_provider_obj.seed,int)

# Generated at 2022-06-23 21:06:19.064935
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseProvider().get_current_locale() == 'en'

# Generated at 2022-06-23 21:06:21.996033
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    data = BaseDataProvider()
    locale = data.get_current_locale()
    # locale = data.get_current_locale()
    assert locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:06:27.081355
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass
    p = Provider('en')
    with p.override_locale('ru'):
        assert p.locale == 'ru'

    assert p.locale == 'en'

    class Provider(BaseDataProvider):
        pass
    p = Provider()
    with p.override_locale('ru'):
        assert p.locale == 'ru'

    assert p.locale == 'en'

# Generated at 2022-06-23 21:06:28.315432
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:06:32.268075
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.person import Person

    pr = Person()
    assert str(pr) == 'Person <en>'

    pr = Person(locale='ru')
    assert str(pr) == 'Person <ru>'


# Generated at 2022-06-23 21:06:34.348451
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-23 21:06:36.794922
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import CURRENCIES

    provider = CURRENCIES()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:47.667199
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Если не передать никаких параметров то должно возвращать дефолтные значения
    data_provider = BaseDataProvider()
    assert data_provider.locale == 'en'
    assert data_provider.get_current_locale() == 'en'
    assert data_provider._data == {}
    assert data_provider._datafile == ''
    assert data_provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert data_provider.random == random
    assert data_provider.seed is None

# Generated at 2022-06-23 21:06:55.416163
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Create an object of class BaseDataProvider
    data_provider = BaseDataProvider()
    # Test the constructor of the class BaseDataProvider
    assert data_provider is not None
    # Test if the attribute _data is not empty
    assert data_provider._data != {}
    # Test if the attribute _pull is not empty
    assert data_provider._pull != None
    # Test if the attribute get_current_locale is not empty
    assert data_provider.get_current_locale != None
    # Test if the attribute _override_locale is not empty
    assert data_provider._override_locale != None
    # Test if the attribute _pull is not empty
    assert data_provider._pull != None
    # Test if the attribute _data_dir is not empty
    assert data_provider._data_

# Generated at 2022-06-23 21:07:06.316658
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test BaseDataProvider.get_current_locale()."""
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE

    bdp = BaseDataProvider(locale=locales.RU)
    assert bdp.get_current_locale() == locales.RU
    bdp.reseed(seed=0)
    assert bdp.get_current_locale() == locales.RU

    bdp = BaseDataProvider(locale=locales.EN)
    assert bdp.get_current_locale() == locales.EN
    bdp.reseed(seed=1)
    assert bdp.get_current_locale() == locales.EN

    bdp = BaseDataProvider(locale=locales.UK)
   

# Generated at 2022-06-23 21:07:12.726466
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method `__str__` of class `BaseDataProvider`."""

    class TestClass(BaseDataProvider):
        """Example of class."""

        def __init__(self, locale=locales.RU, seed=None):
            """Initialize attributes for data providers."""
            super().__init__(locale, seed)
            self._data = {
                'hello': 'Привет'
            }
            self._datafile = ''

    assert isinstance(TestClass().__str__(), str)

# Generated at 2022-06-23 21:07:14.679001
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider('en')
    result = provider.__str__()
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:19.563110
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale(locale='ru') as bdp1:
        assert bdp1.get_current_locale() == 'ru'
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-23 21:07:21.708761
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    provider.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:07:23.871013
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    x = BaseProvider()
    x.reseed(1)
    assert x.seed == 1


# Generated at 2022-06-23 21:07:29.500084
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    import random
    my_random = random.Random()

    bp = BaseProvider()
    bp.random = my_random #pylint: disable=attribute-defined-outside-init

    bp2 = BaseProvider()
    assert bp2.random is not my_random

    locale = locales.EN
    bdp = BaseDataProvider(locale = locale)

    assert str(bp) == str(BaseProvider)
    assert str(bdp) == 'BaseDataProvider <'+str(locale)+'>'

# Generated at 2022-06-23 21:07:31.110097
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj



# Generated at 2022-06-23 21:07:34.715993
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    obj = BaseDataProvider()
    assert (str(obj) == 'BaseDataProvider <en>')


# Generated at 2022-06-23 21:07:44.027898
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider_default_seed = BaseProvider()
    assert provider_default_seed.seed is None
    assert provider_default_seed.random is random
    provider = BaseProvider(seed=42)
    assert provider.seed == 42
    assert isinstance(provider.random, Random)
    assert provider.random is not random
    provider.reseed()
    assert provider.seed is None
    assert isinstance(provider.random, Random)
    assert provider.random is not random
    assert provider_default_seed.random is random
    provider_default_seed.reseed()
    assert isinstance(provider_default_seed.random, Random)
    assert provider_default_seed.random is not random


# Generated at 2022-06-23 21:07:46.590941
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_provider = BaseProvider(1)
    assert test_provider.seed == 1
    assert isinstance(test_provider.random, Random)
    assert test_provider.random.generator.getstate()[1][0] == 1


# Generated at 2022-06-23 21:07:54.382326
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.schema import Field
    from .person import Person
    assert str(Person()) == 'Person <en>'
    assert str(Person(locale='es')) == 'Person <es>'
    assert str(Person(locale='ru')) == 'Person <ru>'
    assert str(Person(locale='uk')) == 'Person <uk>'
    assert str(Person(locale='uk-ua')) == 'Person <uk-ua>'
    assert str(Field()) == 'Field'


# Generated at 2022-06-23 21:07:55.338739
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"


# Generated at 2022-06-23 21:08:01.951341
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Code
    from mimesis.providers.code import Code as CodeMeta
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.network import Network
    from mimesis.providers.person import Person

    dt = Datetime(seed=123)
    p = Person(seed=123)

    with dt.override_locale('ru') as dt_ru:
        assert isinstance(dt_ru, Datetime)
        assert dt_ru.locale == 'ru'

    with p.override_locale('ru') as p_ru:
        assert isinstance(p_ru, Person)
        assert p_ru.locale == 'ru'

    assert dt.loc

# Generated at 2022-06-23 21:08:07.283402
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    '''
    test for BaseDataProvider_override_locale
    '''
    base_data_provider = BaseDataProvider('en')
    with base_data_provider.override_locale('en') as bdp:
        str_bdp = str(bdp)
    assert str_bdp == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:08:14.363266
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:08:20.794879
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DerivedDataProvider(BaseDataProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)

        def x(self) -> str:
            return 'x'

    provider = DerivedDataProvider()
    with provider.override_locale(locales.EN) as provider:
        assert provider.x() == 'x'

# Generated at 2022-06-23 21:08:23.947081
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'ru'
    provider = BaseDataProvider(locale)
    assert str(provider) == 'BaseDataProvider <{}>'.format(locale)

