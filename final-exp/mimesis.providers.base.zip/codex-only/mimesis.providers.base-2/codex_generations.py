

# Generated at 2022-06-23 20:58:24.629161
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    custom_locale = 'ru'
    base_data_provider = BaseDataProvider(locale=custom_locale)
    result = base_data_provider.get_current_locale()

    assert result == 'ru'


# Generated at 2022-06-23 20:58:29.068498
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for BaseProvider's reseed method."""
    provider = BaseProvider()
    old_value = provider.random.random()
    provider.reseed(1)
    assert old_value != provider.random.random()



# Generated at 2022-06-23 20:58:32.133364
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider(3)
    res = obj.get_random_seed()
    assert res == 3
    assert not isinstance(BaseProvider(3), BaseDataProvider)


# Generated at 2022-06-23 20:58:42.641470
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    person_ru = Person('ru')

    with person.override_locale('ru') as person_override_ru:
        assert person_override_ru.gender() == Gender.MAN.value
        assert person_ru.gender() == Gender.MAN.value
        assert person_override_ru.formatted_name() == person_ru.formatted_name()

    assert person.gender() == Gender.MAN.value
    assert person_override_ru.gender() == Gender.MAN.value
    assert person.formatted_name() != person_ru.formatted_name()
    assert person_override_ru.formatted_name() == person_ru.formatted_name()

# Generated at 2022-06-23 20:58:48.785537
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.enums import Gender
    seed = '12345'
    provider = BaseProvider(seed=seed)
    assert provider.random.seed == seed
    assert provider.seed == seed
    with provider.override_locale('en'):
        assert provider.locale == 'en'
    provider = BaseProvider(locale='en')
    assert provider._validate_enum(None, Gender) in Gender.__members__.values()

# Generated at 2022-06-23 20:58:52.088609
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class TestProvider(BaseProvider):
        pass
    pvdr = TestProvider()
    assert str(pvdr) == 'TestProvider'



# Generated at 2022-06-23 20:58:56.801784
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    dp = BaseDataProvider(locale='ru')
    with dp.override_locale('en'):
        assert str(dp) == 'BaseDataProvider <en>'
    assert str(dp) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 20:59:05.684722
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Test creation empty instance
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE

    # Test creation instance with seed and locale
    provider = BaseDataProvider(seed=1)
    provider = BaseDataProvider(seed=1, locale='ru')
    provider = BaseDataProvider(locale='ru')
    try:
        provider = BaseDataProvider(locale='123')
    except UnsupportedLocale:
        assert True
    else:
        assert False

    # Test reseed
    provider.reseed(3)
    provider.reseed()

    # Test method _setup_locale
    provider._setup_locale()
    provider._setup_locale('ru')
    try:
        provider._setup_locale('123')
    except UnsupportedLocale:
        assert True
   

# Generated at 2022-06-23 20:59:14.162409
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.random import RandomProvider
    from mimesis.builtins import RussiaSpecProvider
    rp = RandomProvider()
    rsp = RussiaSpecProvider()

    rp_lc = rp.get_current_locale()
    assert not rp_lc
    assert rp_lc == locales.EN

    rsp_lc = rsp.get_current_locale()
    assert rsp_lc
    assert rsp_lc == locales.RU


# Generated at 2022-06-23 20:59:16.445262
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(20)
    assert bp.seed == 20 and bp.random is not random
    bp.reseed()


# Generated at 2022-06-23 20:59:25.294499
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import Person
    p=Person("zh")
    assert p.get_current_locale() == "zh" # Check for locale
    assert len(str(p)) > 0 # Check for str
    p2=Person("zh",12)
    assert p2.seed == 12 # Check for seed
    p.reseed(12)
    assert p.seed == 12 # Test reseed
    assert p._pull("person.json") == None # Check for pull
    assert p._update_dict({'s': 2}, {'b': 1}) == {'s': 2, 'b': 1} # Check for update dict
    assert p._validate_enum('m',Person.Gender) == 'm' # Check for validate enum
    assert p.override_locale("en") is not None # Check for override locale

# Generated at 2022-06-23 20:59:27.131525
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person

    assert str(BaseProvider()) == 'BaseProvider'
    assert str(Person()) == 'Person'

# Generated at 2022-06-23 20:59:36.632703
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Process
    from mimesis.enums import Locale
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale=Locale.EN)) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale=Locale.RU)) == 'BaseDataProvider <ru>'
    assert str(Process(locale=Locale.RU)) == 'Process <ru>'
    assert str(Process(locale=Locale.EN)) == 'Process <en>'

# Generated at 2022-06-23 20:59:38.348130
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 20:59:43.260414
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    try:
        provider = BaseProvider()
        print("Create the BaseProvider with no argument")
    except Exception:
        print("error")
    seed="1234"
    provider = BaseProvider(seed)
    print("Create the BaseProvider with a single argument")
    
    

# Generated at 2022-06-23 20:59:45.403738
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider
    assert provider.locale
    assert provider.seed
    assert provider.data
    assert provider.data_dir
    assert provider.random
    assert provider._data


# Generated at 2022-06-23 20:59:49.168331
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # testing simple return en locale, because en is default locale.
    bdp_obj = BaseDataProvider(locale='en', seed=None)
    test_locale = bdp_obj.get_current_locale()
    assert test_locale == 'en'


# Generated at 2022-06-23 20:59:50.921167
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=12)
    provider.reseed(seed=12)


# Generated at 2022-06-23 20:59:56.557013
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import EN, JA, JA_JP, RU
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.science import Chemistry
    c = Chemistry()
    p = Person('en')
    assert c.get_current_locale() == EN
    assert p.get_current_locale() == EN
    p._override_locale(RU)
    assert p.get_current_locale() == RU
    with p.override_locale(JA):
        assert p.get_current_locale() == JA
        assert isinstance(p.gender(), Gender)

# Generated at 2022-06-23 21:00:08.909780
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    def check_str_of_locale(seed, locale):
        provider = BaseProvider(seed=seed)
        result = provider.__str__()
        assert isinstance(result, str)
        assert result == 'BaseProvider'
        provider = BaseDataProvider(locale=locale)
        result = provider.__str__()
        assert isinstance(result, str)
        assert result == 'BaseDataProvider <{}>'.format(locale)
        with provider.override_locale(locales.ES):
            assert str(provider) == 'BaseDataProvider <{}>'.format(locales.ES)
        with provider.override_locale(locales.EN):
            assert str(provider) == 'BaseDataProvider <{}>'.format(locales.EN)

# Generated at 2022-06-23 21:00:11.852008
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Initialize a test object
    obj = BaseProvider()
    # Set seed
    obj.reseed(seed=1234)
    # Check self.random
    assert obj.random == type(Random)
    # Check self.seed
    assert obj.seed == 1234

# Generated at 2022-06-23 21:00:13.585728
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_dp = BaseDataProvider()
    assert(str(base_dp) == 'BaseDataProvider <en>')

# Generated at 2022-06-23 21:00:17.279452
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import UnitTest
    class TestBaseProvider(BaseProvider):
        pass
    u = UnitTest(TestBaseProvider)
    assert str(u) == 'TestBaseProvider'


# Generated at 2022-06-23 21:00:26.050825
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE
    assert BaseDataProvider("en").get_current_locale() == "en"
    assert BaseDataProvider("en_GB").get_current_locale() == "en_GB"
    assert BaseDataProvider("en_US").get_current_locale() == "en_US"
    assert BaseDataProvider("sv").get_current_locale() == "sv"
    assert BaseDataProvider("sv_SE").get_current_locale() == "sv_SE"


# Generated at 2022-06-23 21:00:31.585136
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    try:
        demo_base_provider = BaseProvider()
    except :
        print("Failed to initiate BaseProvider()")
    try:
        print(demo_base_provider)
    except:
        print("Failed to print demo_base_provider")
    try:
        demo_base_provider.reseed()
    except:
        print("Failed to reseed demo_base_provider")
    try:
        demo_base_provider._validate_enum("", ())
    except:
        print("Failed to validate enum demo_base_provider")


# Generated at 2022-06-23 21:00:33.954917
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-23 21:00:35.831873
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    try:
        bp = BaseProvider()
    except:
        assert False


# Generated at 2022-06-23 21:00:41.851483
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    with provider.override_locale():
        assert provider.get_current_locale() == 'en'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:00:46.624732
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit-test for method __str__ of class BaseDataProvider."""
    from .en import Address as AddressEN
    from .ru import Address as AddressRU

    assert str(AddressEN()) == 'Address <en>'
    assert str(AddressRU()) == 'Address <ru>'

# Generated at 2022-06-23 21:00:49.199132
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider() is not None
    assert BaseProvider(seed=123)[0] == -0.49170951587796685


# Generated at 2022-06-23 21:00:51.242011
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() is not None


# Generated at 2022-06-23 21:00:56.452570
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    p = Person()
    p.seed(0)
    with p.override_locale(locales.EN) as person:
        print(person.full_name())
        print(person.full_name())
    print(person.full_name())

if __name__ == "__main__":
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:01:02.746993
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    from mimesis import Base
    from mimesis.typing import Seed

    b=Base()

    assert b.seed == None
    assert b.random == random
    
    b.reseed()
    assert b.random!=random
    assert b.seed !=None

    b.reseed("seed")
    assert b.seed == "seed"

    try:
        b.reseed(["seed"])
    except TypeError:
        assert True
    except:
        assert False

    try:
        b.reseed(None, seed="new")
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-23 21:01:04.228552
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    assert base is not None

# Generated at 2022-06-23 21:01:12.628937
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Check if current locale is displayed in string representation."""
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.weather import Weather

    c = Address()
    assert str(c) == 'Address <en>'
    c.locale = 'ru'
    assert str(c) == 'Address <ru>'

    c = Internet()
    assert str(c) == 'Internet <en>'
    c

# Generated at 2022-06-23 21:01:14.637925
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:01:16.770786
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base = BaseProvider()
    base.__str__() == 'BaseProvider'



# Generated at 2022-06-23 21:01:25.834561
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis import Person
    from mimesis.base import BaseProvider
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person as Person2
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    assert isinstance(BaseProvider(seed=42), BaseProvider)
    assert isinstance(Address(), BaseProvider)
    assert isinstance(Code(), BaseProvider)

# Generated at 2022-06-23 21:01:31.454945
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    providers = [
        BaseProvider(),
        BaseProvider(seed=42),
        BaseDataProvider(),
        BaseDataProvider(locale=locales.EN_US),
        BaseDataProvider(locale=locales.RU_RU)
    ]

    has_errors = False
    for provider in providers:
        try:
            provider.__str__()
        except Exception as err:
            print(err)
            has_errors = True

    assert not has_errors

# Generated at 2022-06-23 21:01:34.134054
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    bp = BaseProvider()
    bp.reseed()
    bp.random.seed(1)
    assert bp.random.randint(1, 100) == 14



# Generated at 2022-06-23 21:01:42.725470
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print("==== BaseDataProvider ====")
    bdp = BaseDataProvider(locale="en_US", seed=123)
    assert bdp.locale == "en_us"
    assert bdp.seed == 123
    assert str(bdp) == "BaseDataProvider <en_us>"
    bdp = BaseDataProvider(seed=123)
    assert bdp.locale == "en"
    assert str(bdp) == "BaseDataProvider <en>"
    bdp = BaseDataProvider(locale="en_US")
    assert bdp.locale == "en_us"
    assert str(bdp) == "BaseDataProvider <en_us>"
    bdp = BaseDataProvider()
    assert bdp.locale == "en"
    assert str(bdp) == "BaseDataProvider <en>"
   

# Generated at 2022-06-23 21:01:45.167971
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base = BaseDataProvider()
    assert 'BaseDataProvider <en>' == str(base)

# Generated at 2022-06-23 21:01:46.302570
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()


# Generated at 2022-06-23 21:01:49.543384
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    p = BaseProvider(seed=42)
    assert p.seed == 42
    assert p.random.seed == 42
    assert p.random != random


# Generated at 2022-06-23 21:01:51.035524
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider'


# Generated at 2022-06-23 21:01:55.000265
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Address
    a = Address()
    assert str(a).startswith('Address')
    assert str(a).endswith('<en>')
    a = Address('ru')
    assert str(a).startswith('Address')
    assert str(a).endswith('<ru>')


# Generated at 2022-06-23 21:01:58.928523
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed)
            self._datafile = ''

    provider = TestBaseDataProvider()
    assert str(provider) == 'TestBaseDataProvider <en>'
    provider.locale = 'ru'
    assert str(provider) == 'TestBaseDataProvider <ru>'

# Generated at 2022-06-23 21:02:00.350755
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:02:02.810123
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'
    obj = BaseDataProvider()
    assert str(obj) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:02:05.672249
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert callable(provider.reseed)
    assert callable(provider.__str__)
    assert True


# Generated at 2022-06-23 21:02:08.078648
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    assert a.locale == 'en'


# Generated at 2022-06-23 21:02:10.961572
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    prov = BaseDataProvider()
    assert(prov.locale == locales.EN)
    prov = BaseDataProvider('ru')
    assert(prov.locale == 'ru')

# Generated at 2022-06-23 21:02:14.417384
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for BaseDataProvider."""
    assert BaseDataProvider(locale='ru')

    with pytest.raises(UnsupportedLocale):
        BaseDataProvider(locale='ru-by')

# Generated at 2022-06-23 21:02:16.777829
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random == random

# Generated at 2022-06-23 21:02:19.274336
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseDataProvider()
    print(bp.seed)
    print(bp.reseed(0))
    print(bp.seed)



# Generated at 2022-06-23 21:02:20.964506
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
    assert b.random is not None


# Generated at 2022-06-23 21:02:22.688544
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    assert isinstance(a, BaseDataProvider)
    assert isinstance(a, BaseProvider)

# Generated at 2022-06-23 21:02:25.776798
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='ru')
    provider_class_name = provider.__class__.__name__
    locale = 'ru'
    assert str(provider) == '{} <{}>'.format(provider_class_name, locale)

# Generated at 2022-06-23 21:02:35.740291
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print("Unit test for constructor of class BaseProvider")
    # Case 1: Default
    provider = BaseProvider()
    print("Case 1: provider = ", provider)
    # Case 2: When seed is a float
    print("Case 2: When seed is a float")
    seed = 1.0
    provider = BaseProvider(seed = seed)
    print("provider = ", provider)
    # Case 3: When seed is an integer
    print("Case 2: When seed is an integer")
    seed = 1
    provider = BaseProvider(seed = seed)
    print("provider = ", provider)
    # Case 4: When seed is a string
    print("Case 2: When seed is a string")
    seed = "1"
    provider = BaseProvider(seed = seed)
    print("provider = ", provider)
    # Case 5: When

# Generated at 2022-06-23 21:02:44.486233
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Address
    adr = Address()
    assert str(adr) == 'Address <en>'
    # Overriding locale
    with adr.override_locale('de'):
        assert str(adr) == 'Address <de>'
    assert str(adr) == 'Address <en>'
    adr.locale = 'de'
    assert str(adr) == 'Address <de>'
    # Check for locale insensitive provider
    from mimesis.builtins import Numeric
    num = Numeric()
    assert str(num) == 'Numeric'
    num.locale = 'kz'
    assert str(num) == 'Numeric'
    # Check for providers without locale attribute
    from mimesis.builtins import _Missing
    miss = _Missing()

# Generated at 2022-06-23 21:02:49.655563
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import Address, AddressRu
    a1 = Address()
    a2 = AddressRu()
    assert a1.get_current_locale() == Address.locale, "Locale: {}".format(Address.locale)
    assert a2.get_current_locale() == AddressRu.locale, "Locale: {}".format(AddressRu.locale)

# Generated at 2022-06-23 21:02:54.635006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.base import BaseDataProvider

    class Provider(BaseDataProvider):
        def get_random_text(self) -> str:
            return 'Text'
    provider = Provider()

    with provider.override_locale('ru'):
        res = provider.get_random_text()
        assert res == 'Text'


# Generated at 2022-06-23 21:02:57.150132
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bp = BaseDataProvider()
    assert isinstance(str(bp), str)
    bp._setup_locale('de')
    assert isinstance(str(bp), str)


# Generated at 2022-06-23 21:02:59.006836
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert(str(obj) == 'BaseProvider')


# Generated at 2022-06-23 21:02:59.430148
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-23 21:03:01.728003
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    sd = BaseDataProvider()
    assert sd.__str__() == 'BaseDataProvider <en>'
    sd._override_locale('ru')
    assert sd.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:03:05.322347
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test check reseed method of BaseProvider class."""
    provider = BaseProvider(seed=None)
    assert provider.seed == None
    provider.reseed(1234)
    assert provider.seed == 1234


# Generated at 2022-06-23 21:03:09.703526
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    bdp = BaseDataProvider()
    with bdp.override_locale() as provider:
        assert str(provider) == 'BaseDataProvider <en>'
    with bdp.override_locale(locales.RU) as provider:
        assert str(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:03:19.264753
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    bdp = BaseDataProvider("en")
    assert bdp.locale == "en"
    assert bdp._data_dir == Path("../../data")
    assert bdp._datafile == ''

    bdp1 = BaseDataProvider("en", "23")
    assert bdp1.locale == "en"
    assert bdp1._data_dir == Path("../../data")
    assert bdp1._datafile == ''
    assert bdp1.seed == "23"
    assert bdp1.random == random
    assert bdp1.random.seed() == 23

    bdp2 = BaseDataProvider("ru", "23")
    assert bdp2.locale == "ru"
    assert bdp2._data_dir == Path("../../data")


# Generated at 2022-06-23 21:03:22.028986
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert p.__str__() == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)


# Generated at 2022-06-23 21:03:24.529993
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test = BaseDataProvider()
    assert isinstance(test, BaseDataProvider)
    assert isinstance(test, BaseProvider)


# Generated at 2022-06-23 21:03:30.629682
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale."""
    from mimesis.builtins import Address

    with Address.override_locale('ru') as ru_address:
        ru_city = ru_address.city()
    with Address.override_locale('uk') as uk_address:
        uk_city = uk_address.city()

    assert uk_city != ru_city


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:03:33.224845
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    print(p.random)
    p = BaseProvider(42)
    print(p)
    print(p.random)
    p.reseed(None)
    print(p.random)


# Generated at 2022-06-23 21:03:34.754692
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj_BaseProvider = BaseProvider()
    assert obj_BaseProvider.seed is None


# Generated at 2022-06-23 21:03:41.031165
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test the method reseed of BaseProvider.

    Verify that reseeding the internal random generator sets a new seed.
    """
    print('Testing reseed')
    provider = BaseProvider()
    old_seed = provider.seed
    new_seed = 1234
    provider.reseed(new_seed)
    assert provider.seed == new_seed
    assert provider.random.seed_value == new_seed


# Generated at 2022-06-23 21:03:48.266806
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bp = BaseDataProvider(locale=locales.EN, seed=None)
    assert bp.locale == "en"
    assert repr(bp) == "<BaseDataProvider <en>>"
    assert str(bp) == "<BaseDataProvider <en>>"
    assert bp.__class__.__name__ == "BaseDataProvider"
    assert bp.seed is None
    assert bp.random is random
    assert isinstance(bp, BaseDataProvider)
    assert isinstance(bp, BaseProvider)

# Generated at 2022-06-23 21:03:48.866798
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert 1

# Generated at 2022-06-23 21:03:54.898711
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Тест для метода override_locale класса BaseDataProvider
    name_provider = BaseDataProvider()
    with name_provider.override_locale() as overridden_provider:
        assert overridden_provider.locale == 'en'
        assert overridden_provider.get_current_locale() == 'en'
    assert name_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:03:57.158800
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    test = BaseProvider(seed=None)
    actual = test.__str__()
    expected = 'BaseProvider'
    assert actual == expected


# Generated at 2022-06-23 21:03:59.880346
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, RussianAddress

    assert RussianAddress().get_current_locale() == locales.RU
    assert Address().get_current_locale() == locales.EN



# Generated at 2022-06-23 21:04:03.316769
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def get_field(self):
            return self._data['array'][0]
    provider = Provider()
    provider.get_field()
    assert provider.get_field() != 'hello'
    with provider.override_locale('ru'):
        assert provider.get_field() == 'hello'

# Generated at 2022-06-23 21:04:08.982820
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for BaseDataProvider.__str__."""
    assert 'Internet <en>' == str(BaseDataProvider())
    assert 'Internet <ru>' == str(BaseDataProvider('ru'))
    assert 'Internet <en>' == str(BaseDataProvider('fr'))

# Generated at 2022-06-23 21:04:15.106793
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()
    assert provider.seed is None
    assert provider.random is random
    assert provider is not random

    provider = BaseProvider(seed=1)
    provider.reseed()
    assert provider.seed == 1
    assert provider.random is not random
    assert provider.random is not Random()



# Generated at 2022-06-23 21:04:26.136158
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers import Person

    # Arrange
    person1 = Person()
    person2 = Person()
    first_name1 = person1.name()
    first_name2 = person2.name()

    # Assert
    assert first_name1 != first_name2

    # Act
    person1.reseed(123)
    person2.reseed(123)

    # Assert
    assert person1.name() == person2.name() or person1.name() == person2.full_name()

    # Act
    person1.reseed()
    person2.reseed()

    # Assert
    assert person1.name() != person2.name() or person1.name() != person2.full_name()

# Generated at 2022-06-23 21:04:30.711191
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class DataProvider(BaseDataProvider):
        """DataProvider for testing BaseDataProvider.override_locale."""
        def __init__(self, **kwargs: Any) -> None:
            """Initialize attributes.

            :param **kwargs: Keyword arguments.
            """
            super().__init__(**kwargs)

        def get(self) -> str:
            """Return locale."""
            return self.locale

    data_provider = DataProvider()
    assert data_provider.get() == locales.DEFAULT_LOCALE
    with data_provider.override_locale() as dp:
        assert dp.get() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:04:31.419349
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    assert base is not None



# Generated at 2022-06-23 21:04:36.452641
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that method override_locale of class BaseDataProvider
    works correctly."""
    class TestProvider(BaseDataProvider):

        class Meta:
            name = 'test_provider'
            locales = ('en', 'de')

        def get_locale(self) -> str:
            return self.get_current_locale()

    provider = TestProvider()
    assert provider.get_locale() == 'en'

    with provider.override_locale('de'):
        assert provider.get_locale() == 'de'

    assert provider.get_locale() == 'en'

    with provider.override_locale('de'):
        assert provider.get_locale() == 'de'

# Generated at 2022-06-23 21:04:44.580243
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    p1 = Person()
    p2 = Person()
    p1.reseed(seed=1)
    p2.reseed(seed=1)
    assert p1.random.get_seed() == p2.random.get_seed()
    p1.reseed(seed=2)
    p2.reseed(seed=3)
    assert p1.random.get_seed() != p2.random.get_seed()

test_BaseProvider_reseed()


# Generated at 2022-06-23 21:04:46.758884
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:51.957382
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    obj0 = BaseDataProvider(locale='EN')
    assert str(obj0) == 'BaseDataProvider <en>'
    obj1 = BaseDataProvider()
    assert str(obj1) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:04:56.884200
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    from mimesis.providers.builtins import Builtins
    b = Builtins(seed=0)
    assert str(b) == 'Builtins'

    from mimesis.providers.internet import Internet
    i = Internet(seed=0)
    assert str(i) == 'Internet <en>'

# Generated at 2022-06-23 21:04:59.921273
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.providers import Address, Person
    assert Address().locale == locales.EN
    assert Person().locale == locales.EN


# Generated at 2022-06-23 21:05:04.859433
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider._data == {}
    assert provider._datafile == ''
    assert isinstance(provider._data_dir, Path)
    assert provider._data_dir == Path(__file__).parent.parent / 'data'


# Generated at 2022-06-23 21:05:11.315232
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale='en', seed=None):
            super().__init__(locale, seed)

    provider = Provider()

    # test with default locale
    assert provider.get_current_locale() == 'en'

    # test with locale not equal to 'en'
    provider.locale = 'ru'
    assert provider.get_current_locale() == 'ru'

    # test with some unexpected locale
    provider.locale = 'some-unexpected-locale'
    assert provider.get_current_locale() == 'some-unexpected-locale'

    # test case when locale = None
    provider.locale = None
    assert provider.get_current_locale() == 'en'

    # test case when locale = ''
    provider.locale

# Generated at 2022-06-23 21:05:16.437951
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of BaseProvider class."""
    prov = BaseProvider(seed=3)
    assert prov.seed is 3
    assert prov.random is not random
    prov.reseed(seed=4)
    assert prov.seed is 4
    assert prov.random is not random
    prov.reseed(seed=2)
    assert prov.seed is 2
    assert prov.random is not random



# Generated at 2022-06-23 21:05:19.477054
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider(locale='en')
    assert isinstance(b,BaseProvider)
    b = BaseDataProvider(locale='zh')

# Generated at 2022-06-23 21:05:21.659687
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed("hello")
    assert provider.random.seed == "hello"



# Generated at 2022-06-23 21:05:29.035313
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.exceptions import NonEnumerableError
    b = BaseProvider()
    assert b.random == random
    assert b.seed == None
    b.reseed(1)
    assert b.random != random
    assert b.seed == 1
    #str(b)
    try:
        b._validate_enum(None, Gender)
    except NonEnumerableError:
        assert False
    try:
        b._validate_enum(None, 'aaa')
    except:
        assert True
    else:
        assert False
    try:
        b._validate_enum(Gender.MALE, Gender)
    except NonEnumerableError:
        assert False

# Generated at 2022-06-23 21:05:29.742556
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    pass

# Generated at 2022-06-23 21:05:33.484161
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    with Person().override_locale('ru') as p:
        assert p.locale == 'ru'
        print(p.full_name())

    assert Person().locale == 'en'

# Generated at 2022-06-23 21:05:41.963270
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a=BaseDataProvider()
    assert a.locale=='en'
    assert a.seed==None
#assert a._setup_locale('en') == None
#assert a._update_dict({'a':'a'},'b') == {'a':'a'}
#assert a._pull('a') ==None
#assert a.get_current_locale() == 'en'
#assert a._override_locale('en') == None
#assert a.override_locale('en') == None
#assert a.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:44.209903
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    provider.reseed(seed=42)
    assert provider.seed == 42
    assert provider.random is not random
    provider.reseed()
    assert provider.seed is None
    assert provider.random is not random

# Generated at 2022-06-23 21:05:46.578080
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.base import BaseDataProvider
    provider = BaseDataProvider()
    assert provider.get_current_locale() == provider.locale

# Generated at 2022-06-23 21:05:47.985311
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    obj.reseed('aa')

# Generated at 2022-06-23 21:05:49.445052
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Init BaseDataProvider."""
    assert BaseDataProvider



# Generated at 2022-06-23 21:05:57.089239
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    # is the data provider initialized?
    assert isinstance(data_provider, BaseDataProvider)
    # is the seed None?
    assert data_provider.seed is None
    # is the locale 'en'?
    assert data_provider.locale == locales.DEFAULT_LOCALE

data_provider = BaseDataProvider()
# is the random object from mimesis.random?
if data_provider.random is random:
    print(True)

# is the seed empty?
data_provider.reseed(seed=None)

test_dict0 = {
    "0": {
        "a": {"a": "0a0a"},
        "b": "0b"
    }
}

# Generated at 2022-06-23 21:05:58.994635
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test class BaseProvider."""
    assert BaseProvider().seed is None
    assert BaseProvider(seed=42).seed == 42


# Generated at 2022-06-23 21:06:04.299713
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider(seed=0)
    assert provider.seed is None
    assert provider.random is random
    provider.reseed(seed=0)
    assert provider.seed == 0
    assert provider.random is not random

# Generated at 2022-06-23 21:06:08.600108
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.base import BaseProvider

    bp = BaseProvider(seed=None)
    bp.reseed(None)
    assert bp.random != random



# Generated at 2022-06-23 21:06:10.915532
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # a: Seed = None
    test = BaseProvider(seed=1)
    assert test._BaseProvider__init__(seed=1) == None


# Generated at 2022-06-23 21:06:13.503931
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp=BaseProvider()
    bp._setup_locale()
    expected='BaseProvider'
    assert(str(bp)==expected)

# Generated at 2022-06-23 21:06:17.406618
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with BaseDataProvider() as bdp:
        assert bdp.locale == "en"
        assert bdp.seed == None
        assert bdp._data == {}
        assert bdp._datafile == ""
        assert bdp._data_dir == Path('E:/Coding/PycharmProjects/mimesis/mimesis/data')
        assert bdp.random is random

# Generated at 2022-06-23 21:06:20.221392
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider._validate_enum("1", (1,)) == 1

if __name__ == "__main__":
    test_BaseProvider()

# Generated at 2022-06-23 21:06:23.681066
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    random_obj = Random()
    test_obj = BaseProvider()
    seed = random_obj.seed()
    test_obj.reseed(seed)
    assert test_obj.seed == seed


# Generated at 2022-06-23 21:06:35.171765
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.exceptions import UnsupportedLocale
    p = Person('en')
    with p.override_locale('fr') as person:
        assert person.full_name() == 'Jean-Michel Coulomb'
    assert p.full_name() == 'John Smith'
    r = Person('ru')
    with pytest.raises(ValueError) as e:
        with r.override_locale('ru') as _:
            assert False, 'Person doesn\'t have locale dependent'
    assert str(e.value) == '«Person» has not locale dependent'
    with pytest.raises(UnsupportedLocale) as e:
        with r.override_locale('xyz') as _:
            assert False, 'Unsupported locale'

# Generated at 2022-06-23 21:06:46.321217
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    from mimesis.builtins import Address, AddressSuffix, Person
    from mimesis.builtins.general import General
    from mimesis.builtins.person import PersonSuffix
    from mimesis.builtins.personal import Personal
    from mimesis.builtins.society import Society

    address_suffix = AddressSuffix()
    assert address_suffix.__str__() == 'AddressSuffix <en>'

    address = Address()
    assert address.__str__() == 'Address <en>'

    general = General()
    assert general.__str__() == 'General <en>'

    person = Person()
    assert person.__str__() == 'Person <en>'

    person_suffix = PersonS

# Generated at 2022-06-23 21:06:51.344669
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Test to create a random object, set a seed and compare the results
    provider = BaseProvider(seed='test')
    provider.random.seed('test')
    assert provider.random.random() == 0.13436424411240122, \
        'The generated values are not the same'

# Generated at 2022-06-23 21:06:53.486476
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

if __name__ == '__main__':
    test_BaseProvider___str__()

# Generated at 2022-06-23 21:07:02.078600
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins.generic import Generic
    from mimesis.builtins.lorem import Lorem
    
    # BaseProvider is an abstract class, so we don't have an object for it.
    # Let's check the __str__ method of child classes.

    # Generic
    generic = Generic()
    assert generic.__str__() == 'Generic'

    # Lorem
    lorem = Lorem()
    assert lorem.__str__() == 'Lorem'


# Generated at 2022-06-23 21:07:03.937700
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.date import Date
    assert str(Date()) == 'Date <en>'

# Generated at 2022-06-23 21:07:10.071406
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Seed of class BaseProvider is set to 42
    test = BaseProvider(seed=42)
    # BaseProvider.random is not initilized and should be equal to Random()
    assert(test.random == random)
    # Seed of test is set to 42
    assert(test.seed == 42)
    # Class BaseProvider is initilized and BaseProvider.random and random
    # should be equals
    test.reseed()
    assert(test.seed == 42)
    assert(test.random == random)
    # Class BaseProvider is initilized with None,
    # and BaseProvider.random should be different from random
    test.reseed(None)
    assert(test.random != random)


# Generated at 2022-06-23 21:07:13.163284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test of method override_locale in class BaseDataProvider."""
    from mimesis.builtins import Building
    with Building().override_locale('ru') as building:
        assert building.locale == 'ru'

# Generated at 2022-06-23 21:07:19.116293
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider().get_current_locale() == 'en'
    assert BaseDataProvider().locale == 'en'
    assert BaseDataProvider('ar').get_current_locale() == 'ar'
    assert BaseDataProvider('ar').locale == 'ar'

# Generated at 2022-06-23 21:07:21.656368
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider()
    assert p != BaseDataProvider()
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-23 21:07:25.904370
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.random import Random

    b = BaseProvider()
    b.reseed()
    assert isinstance(b.random, Random)

    b.reseed()
    assert isinstance(b.random, Random)


# Unit tests for method _update_dict of class BaseDataProvider

# Generated at 2022-06-23 21:07:30.774236
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale=locales.EN)
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-23 21:07:33.927696
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.codec import Codec
    c = Codec()
    assert isinstance(str(c), str)


# Generated at 2022-06-23 21:07:43.684662
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.schema import FieldSet
    from mimesis.enums import Gender
    from mimesis.data import (
        US_STATES,
        US_STATE_ABBREVIATIONS,
        US_CITIES_BY_STATE,
        US_CITIES,
        US_CITIES_DICT,
        US_CITY_BY_STATE,
        US_CITY_BY_STATE_DICT,
    )

    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

    provider = FieldSet()
    assert str(provider) == 'FieldSet'

    provider = Gender()
    assert str(provider) == 'Gender'

    provider = US_STATES
    assert str(provider) == 'USStates'

    provider = US_STATE_ABBREVIATIONS
   

# Generated at 2022-06-23 21:07:44.932197
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert 'BaseDataProvider' == str(BaseDataProvider())


# Generated at 2022-06-23 21:07:49.365705
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Create an instance of BaseProvider."""
    provider = BaseProvider()
    provider.seed
    seed = 'd0ff93f0-a566-11e9-89e9-0242ac110002'
    provider_with_seed = BaseProvider(seed=seed)
    assert provider_with_seed
    provider_with_seed.reseed(seed)
    assert provider_with_seed.seed == seed
    provider_with_seed.seed = seed
    assert provider_with_seed.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:07:57.070188
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method of class BaseProvider."""
    # reseed with seed
    provider = BaseProvider()
    assert provider.seed is None
    provider.reseed('test')
    assert provider.seed == 'test'
    # reseed with default argument
    provider = BaseProvider()
    assert provider.seed is None
    provider.reseed()
    assert provider.seed is None

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:07:59.341676
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider('en')
    assert b._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:08:08.544397
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Testing of class BaseProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from random import Random

    person = Person(seed=Person.DEFAULT_SEED)
    person.reseed(Person.DEFAULT_SEED)

    # test constructor; test seeding
    assert person.seed == Person.DEFAULT_SEED
    assert person.random is not random
    assert isinstance(person.random, Random)

    # test random instance
    assert person.random.randint(0, 100) == 12
    assert person.random.uniform(0, 100) == 0.3975195218430852
    assert person.random.choice(list(Gender)) == Gender.MALE

# Generated at 2022-06-23 21:08:16.219187
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class Provider(BaseProvider):
        _datafile = 'test_data.json'

    provider = Provider(locale='en')
    assert provider.get_current_locale() == 'en'
    provider.reseed(seed=666)
    assert provider.seed == 666
    assert provider.random is not random
    provider.reseed()
    assert type(provider.seed) is int



# Generated at 2022-06-23 21:08:21.443934
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(seed=10)

    # Using the default seed we need to create a per instance
    # random generator, in this case two providers with the same
    # seed will always return the same values.
    assert bp.random.seed == 10
    assert bp.seed == 10
    assert bp.random is not random

# Generated at 2022-06-23 21:08:25.025334
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for BaseProvider constructor."""
    baseprovider = BaseProvider()
    assert baseprovider.random == random
    assert baseprovider.seed is None
    assert baseprovider.random.seed() == random.seed()

