

# Generated at 2022-06-23 20:58:24.070035
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = "Seed"
    base_provider = BaseProvider(seed=seed)
    assert base_provider.random is not random


# Generated at 2022-06-23 20:58:28.244043
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Test for the valid locale
    provider = BaseProvider(locale='en')
    assert str(provider) == 'BaseProvider'

# Test for the valid locale

# Generated at 2022-06-23 20:58:29.987057
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    a = BaseDataProvider(locale='en')
    assert a.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:58:32.262956
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert 'BaseDataProvider <en>' == str(BaseDataProvider())


# Generated at 2022-06-23 20:58:33.776979
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider()
    assert dp.get_current_locale() == 'en'


# Generated at 2022-06-23 20:58:37.884483
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    locale = locales.DEFAULT_LOCALE
    bp = BaseProvider(locale=locale)
    string = bp.__str__()
    # assertEqual
    assert string == 'BaseProvider'


# Generated at 2022-06-23 20:58:42.433142
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bp = BaseDataProvider(locale='en')
    res = bp.get_current_locale()
    assert res is not None
    assert res == 'en'


# Generated at 2022-06-23 20:58:44.418336
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'


# Generated at 2022-06-23 20:58:47.648753
# Unit test for constructor of class BaseProvider
def test_BaseProvider():

    assert BaseProvider().seed is None
    assert BaseProvider(seed=42).seed == 42
    assert BaseProvider(seed=-1).seed == -1
    assert BaseProvider(seed=0).seed == 0


# Generated at 2022-06-23 20:58:59.542520
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Address, Medicine, Text
    from mimesis.data import (
        MASTER_LOCALE,
        SUPPORTED_LOCALES,
    )
    assert str(Address()) == 'Address <{}>'.format(MASTER_LOCALE)
    assert str(Address(locale='test')) == 'Address <test>'
    medicine = Medicine()
    medicine_locale = define_medicine_locale(medicine)
    assert str(medicine) == 'Medicine <{}>'.format(medicine_locale)
    assert str(Medicine(locale='test')) == 'Medicine <test>'
    text = Text()
    text_locale = define_text_locale(text)

# Generated at 2022-06-23 20:59:02.476153
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().seed == None
    assert BaseProvider('seed').seed == 'seed'
    assert BaseProvider().random != None


# Generated at 2022-06-23 20:59:04.748815
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base_provider = BaseProvider()
    assert str(base_provider) == 'BaseProvider'


# Generated at 2022-06-23 20:59:07.073671
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    s = BaseProvider(seed=None)
    s.reseed()
    assert(s.seed is not None)

# Generated at 2022-06-23 20:59:10.896522
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='en')
    assert bdp.get_current_locale() == 'en'
test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-23 20:59:12.538484
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.base import BaseDataProvider
    bdp = BaseDataProvider()

# Generated at 2022-06-23 20:59:15.774588
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    assert str(b) == 'BaseDataProvider <en>'
    b = BaseDataProvider(locale='cs')
    assert str(b) == 'BaseDataProvider <cs>'

# Generated at 2022-06-23 20:59:25.463577
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    assert dp is not None
    assert dp.locale == locales.EN
    assert dp.get_current_locale() == locales.EN
    dp = BaseDataProvider(locale=locales.RU)
    assert dp.locale == locales.RU
    assert dp.get_current_locale() == locales.RU
    dp = BaseDataProvider(locale=locales.RU)
    assert dp.locale == locales.RU
    assert dp.get_current_locale() == locales.RU
    dp = BaseDataProvider(locale=locales.EN)
    assert dp.locale == locales.EN
    assert dp.get_current_locale() == locales.EN
   

# Generated at 2022-06-23 20:59:29.713772
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # def __str__(self):
    #     """Human-readable representation of locale."""
    #     return self.__class__.__name__
    base_provider_obj1 = BaseProvider()
    base_provider_obj2 = BaseProvider(seed=None)
    assert str(base_provider_obj1) == "BaseProvider"
    assert str(base_provider_obj2) == "BaseProvider"


# Generated at 2022-06-23 20:59:32.084806
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider.

    Create a BaseDataProvider instance and get the value of method
    __str__. Check that the value is equal to the class name.

    :return: None.
    """
    provider = BaseDataProvider('en')
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:33.593848
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == 'zh'

# Generated at 2022-06-23 20:59:36.483971
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass
    provider = Provider()
    expected = 'Provider <en>'
    actual = provider.__str__()
    assert actual == expected

# Generated at 2022-06-23 20:59:40.567849
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class MyProv(BaseDataProvider):
        _datafile = 'test.json'

        def datafile(self) -> str:
            return self._datafile

    prov = MyProv()
    with prov.override_locale('en') as p:
        asser

# Generated at 2022-06-23 20:59:50.926700
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address

    b = BaseDataProvider()
    # test with valid parameters
    with b.override_locale('en') as newb:
        assert newb.locale == 'en'
        assert b.locale == 'en'
    assert b.locale != 'en'

    a = Address()
    with a.override_locale('ru') as newa:
        assert newa.locale == 'ru'
        assert a.locale == 'ru'
    assert a.locale != 'ru'
    # test with invalid parameters
    try:
        with a.override_locale('qq') as newa:
            pass
    except UnsupportedLocale:
        pass
    else:
        raise

# Generated at 2022-06-23 20:59:54.427300
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """BaseDataProvider constructor test."""
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider.__str__() == "BaseDataProvider <en>"
    assert baseDataProvider.get_current_locale() == "en"
    assert baseDataProvider._data_dir == Path('D:/Python/Mimesis/mimesis/data')

# Generated at 2022-06-23 20:59:56.240384
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    a = BaseDataProvider()
    
    assert a.get_current_locale() == ""

# Generated at 2022-06-23 21:00:08.824887
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider.override_locale"""
    class Test(BaseDataProvider):
        def __init__(self):
            self._datafile = 'ru-RU.json'
            super().__init__('ru-ru')

        def _get_data(self) -> Dict[str, Any]:
            return self._data

    instance = Test()
    expected = {'_data': {'foo': 'en', 'bar': 'en'}, '_datafile': 'ru-RU.json'}

    with instance.override_locale('en'):
        expected['_data'] = {'foo': 'ru', 'bar': 'ru'}
        assert instance == expected


# Generated at 2022-06-23 21:00:13.458324
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    # Check exception for non-locale dependent provider
    with provider.override_locale():
        pass
    try:
        with provider.override_locale('ko'):
            pass
    except ValueError:
        pass
    provider._override_locale = lambda: None
    try:
        with provider.override_locale('ko'):
            pass
    except NameError:
        pass


# Generated at 2022-06-23 21:00:18.842842
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Base provider."""
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    assert callable(provider.random)

    provider = BaseProvider(seed=12345)
    assert provider.seed == 12345
    assert provider.random
    assert not provider.random is random

# Generated at 2022-06-23 21:00:20.668156
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()
    print('ok')


# Generated at 2022-06-23 21:00:22.369913
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"


# Generated at 2022-06-23 21:00:25.887272
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider()
    assert base_provider.seed == None
    assert base_provider.random == random
    assert str(base_provider) == 'BaseProvider'
#test_BaseProvider()


# Generated at 2022-06-23 21:00:32.066718
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider._override_locale."""
    class TestDataProvider(BaseDataProvider):

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._override_locale('en')

        def get_provider(self):
            return self

    test_data_provider = TestDataProvider()
    with test_data_provider.override_locale('ru') as provider:
        assert test_data_provider.get_current_locale() == provider.get_current_locale() == 'ru'
    assert test_data_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:00:42.533332
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider.
    Test for BaseProvider.reseed
    """
    # The following test checks whether the reseed method works correctly
    # when using the default seed
    from mimesis.enums import Gender
    random = Random()
    seed = random.current_seed()
    prov = BaseProvider(seed)
    prov.random.random()
    prov.random.random()
    prov.random.random()
    prov.reseed()
    assert prov.random.current_seed() != seed

    # The following test checks whether the reseed method works correctly
    # when using the default seed
    prov.reseed(Gender.MALE.value)
    assert prov.random.current_seed() == Gender.MALE.value
    prov.reseed(Gender.FEMALE.value)
    assert prov

# Generated at 2022-06-23 21:00:44.322279
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    BaseProvider.__str__(BaseDataProvider())

# Generated at 2022-06-23 21:00:50.022939
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.unit import BaseUnitSpecification
    def test():
        unit = BaseUnitSpecification('test')
        assert unit.get_current_locale() == 'test'
        with unit.override_locale('test_new'):
            assert unit.get_current_locale() == 'test_new'
    test()

# Generated at 2022-06-23 21:00:50.988845
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider('ru')
    str_ = str(obj)
    assert str_ == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:00:52.345907
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
        assert BaseProvider(seed=125).seed == 125


# Generated at 2022-06-23 21:00:54.924629
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    actual_result_str = BaseProvider().__str__()
    expected_result_str = 'BaseProvider'
    assert actual_result_str == expected_result_str

# Generated at 2022-06-23 21:00:57.719238
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    result = bdp.get_current_locale()
    assert result == locales.DEFAULT_LOCALE

test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-23 21:01:03.590093
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    # Set seed for random and get random string
    p1 = Person()
    p1.reseed(15)
    fullname1 = p1.full_name()

    # Set another seed for random and get random string
    p2 = Person()
    p2.reseed(16)
    fullname2 = p2.full_name()

    return fullname1 != fullname2


# Generated at 2022-06-23 21:01:10.107876
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def _pull(self):
            file_path = Path(__file__).parent.joinpath('test_data.json')
            with open(file_path, 'r', encoding='utf8') as f:
                self._data = json.load(f)
    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'
    rands = [provider.random.randint(0, 65536) for i in range(50)]
    seed = provider.seed

# Generated at 2022-06-23 21:01:16.121178
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(integers())
    def test_seed_type(random_number: Seed) -> None:
        provider = BaseProvider(seed=random_number)
        assert provider._random.seed_arg == random_number

    test_seed_type()

# Generated at 2022-06-23 21:01:25.489019
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
	assert(BaseDataProvider().locale == locales.DEFAULT_LOCALE)
	assert(BaseDataProvider(seed=42).seed == 42)
	assert(BaseDataProvider(locale='en').locale == 'en')
	assert(BaseDataProvider(locale=locales.EN).locale == 'en')
	assert(BaseDataProvider(locale=locales.RU).locale == 'ru')
	assert(BaseDataProvider(locale=locales.RU, seed=42).locale == 'ru')
	assert(BaseDataProvider(locale=locales.RU, seed=42).seed == 42)
	assert(BaseDataProvider(locale=locales.RU)._data is not dict())

# Generated at 2022-06-23 21:01:30.502741
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Provider(BaseDataProvider):
        LOCALE_DATA = 'unit_tests/data/en.json'
        def __init__(self, locale: str = locales.EN):
            super().__init__(locale=locale)

    provider = Provider(locales.EN)
    result = provider.get_current_locale()
    assert result == locales.EN



# Generated at 2022-06-23 21:01:33.349762
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #BaseDataProvider()
    BaseDataProvider(locale='en')
    BaseDataProvider(seed=1)
    BaseDataProvider(locale='en',seed=1)


# Generated at 2022-06-23 21:01:34.808498
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    ''' test for constructor and str method '''
    BaseProvider(1)
    BaseProvider()
    BaseProvider.__str__()


# Generated at 2022-06-23 21:01:36.425397
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = 1
    ob = BaseProvider(seed)
    assert ob.seed == seed
    assert type(ob.random) == type(random)


# Generated at 2022-06-23 21:01:42.276531
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address, Person

    address = Address()
    assert address.get_current_locale() == locales.EN

    person = Person()
    assert person.get_current_locale() == locales.EN

    with person.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.full_name() == 'Марина Николаевна Козлова'

    with person.override_locale(locales.UK) as p:
        assert p.get_current_locale() == locales.UK

# Generated at 2022-06-23 21:01:44.665406
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert (BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE)


# Generated at 2022-06-23 21:01:47.357675
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    b = BaseDataProvider()
    assert b.__str__() == 'BaseDataProvider <en>'
    assert b.get_current_locale() == 'en'

# Generated at 2022-06-23 21:01:50.094881
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit-test for method __str__ of class BaseProvider."""
    data_provider = BaseProvider()
    assert data_provider.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:01:52.418740
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed='seed')
    assert provider.seed == 'seed'
    assert provider.random.seed == 'seed'


# Generated at 2022-06-23 21:01:53.835371
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from . import tools
    assert tools.BaseDataProvider().override_locale(locales.DEFAULT_LOCALE)

# Generated at 2022-06-23 21:01:55.193871
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:01:56.890941
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseProvider('seed')) == 'BaseProvider'


# Generated at 2022-06-23 21:01:58.933467
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p=BaseDataProvider()
    assert p.locale == 'en'
    assert p.random is random
    assert p.seed is None
    assert p.__class__.__name__ == "BaseDataProvider"
    assert p.__str__() == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:02:02.083828
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    languages = set([
        'en',
        'es',
        'af',
        'fr',
        'de',
        'it',
        'lt',
        'pl',
        'ru',
        'uk',
        'az',
    ])
    with BaseDataProvider() as p:
        assert p.get_current_locale() in languages

# Generated at 2022-06-23 21:02:06.356919
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.EN
    try:
        provider = BaseDataProvider(locale=locale)
        assert provider.get_current_locale() == locale
    except UnsupportedLocale as e:
        assert isinstance(e, UnsupportedLocale)

# Test for method overide_locale of class BaseDataProvider

# Generated at 2022-06-23 21:02:12.798113
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider(locale='en')
    assert data._data == {}
    assert data._datafile == ''
    assert data._data_dir == Path(__file__).parent.parent.joinpath('data')

    assert data.locale == 'en'
    assert data.seed is None
    assert data.random is random

    data = BaseDataProvider(locale='en', seed=10)
    assert data.locale == 'en'
    assert data.seed == 10
    assert data.random.seed == 10

# Generated at 2022-06-23 21:02:16.106667
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print("\n=== Test for constructor of class BaseProvider ===\n")
    bp = BaseProvider()
    print("The bp is:", bp)


# Generated at 2022-06-23 21:02:18.364041
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    locale = provider.get_current_locale()
    assert locale == 'ru'


# Generated at 2022-06-23 21:02:19.715689
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    f = BaseDataProvider()
    assert len(str(f)) > 0



# Generated at 2022-06-23 21:02:22.901715
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    pr = Code()
    new_locale = 'ru'
    with pr.override_locale(new_locale) as p:
        assert p.get_current_locale() == new_locale

# Generated at 2022-06-23 21:02:29.507189
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test that instantiating different providers with the same seed
    gives the same result."""
    seed = 5
    assert BaseProvider() != BaseProvider(seed)
    bp = BaseProvider(seed)
    assert bp.seed == seed
    bp.reseed(seed)
    assert bp.seed == seed
    assert BaseProvider() != BaseProvider(seed)

test_BaseProvider_reseed()

# Generated at 2022-06-23 21:02:34.592592
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    assert (a is not None)

    # Test overridden locale
    a = BaseProvider()
    a._override_locale('en')
    print(a.get_current_locale())
    assert a.locale == 'en'
    a._override_locale('us')
    print(a.get_current_locale())
    assert a.locale == 'us'

# Generated at 2022-06-23 21:02:36.813447
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Test(BaseDataProvider):
        pass
    a = Test()
    assert a.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:38.951625
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    base_data_provider = BaseDataProvider()
    print(base_data_provider.get_current_locale())


# Generated at 2022-06-23 21:02:44.931551
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider._validate_enum_called = 0

    def validate_enum(item: Any, enum: Any) -> Any:
        provider._validate_enum_called += 1
        return item

    provider._validate_enum = validate_enum
    assert provider._validate_enum_called == 0
    provider.reseed()

    # Force reseeding
    provider.reseed('abc')
    assert provider._validate_enum_called == 0


# Generated at 2022-06-23 21:02:46.189319
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:02:47.542829
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider(seed='42')
    assert obj.seed == '42'
    assert isinstance(obj.random, Random)


# Generated at 2022-06-23 21:02:56.154634
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    """Method for reseed method is used to reset seed for random class. """

    from mimesis.random import random as random_generator

    random_generator.seed(1)
    bp = BaseProvider(seed=1)
    assert bp.seed == 1
    assert bp.random is random_generator

    random_generator.seed(2)
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random == random_generator

    bp.reseed(seed=3)
    assert bp.seed == 3
    assert bp.random is not random_generator


# Generated at 2022-06-23 21:02:58.626418
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # >>
    with BaseDataProvider.override_locale('ru') as provider:
        #assert provider.__str__() == 'BaseDataProvider <ru>'
        assert str(provider) == 'BaseDataProvider <ru>'
    # assert
    # BaseDataProvider <ru>

# Generated at 2022-06-23 21:03:04.693012
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider(locale=locales.EN, seed=123)
    assert b.locale == 'en'
    assert b.seed == 123
    assert b._data == {}
    assert b._datafile == ''
    assert b._data_dir == Path('C:/Users/admin/Desktop/mimesis/mimesis/data')


# Generated at 2022-06-23 21:03:12.431815
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Imagine that we have a provider
    class TestProvider(BaseDataProvider):
        def test(self):
            return "Hello World!"
    # with no locale
    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE, "Error - BaseDataProvider.get_current_locale()"
    # and with some locale
    provider = TestProvider(locale=locales.RU)
    assert provider.get_current_locale() == locales.RU, "Error - BaseDataProvider.get_current_locale()"

# Generated at 2022-06-23 21:03:19.083260
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)

    unit = TestBaseDataProvider(locale=locales.DEFAULT_LOCALE, seed=None)

    unit._setup_locale(locales.DEFAULT_LOCALE)
    result = unit.get_current_locale()
    unit.assertEqual(
        result,
        locales.DEFAULT_LOCALE,
    )



# Generated at 2022-06-23 21:03:27.566694
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyBaseDataProvider(BaseDataProvider):
        _datafile = 'test.json'

    provider = MyBaseDataProvider(locale='zh', seed=42)
    with provider.override_locale(locale='ru') as ru_provider:
        ru_provider.get_data('list')

    assert ru_provider.locale == 'ru'

    ru_provider.get_data('list')
    ru_provider.get_data('dict')

    ru_provider.get_data('list')
    ru_provider.get_data('dict')

    ru_provider.get_data('list')
    ru_provider.get_data('dict')

    ru_provider.get_data('list')
    ru_provider.get_data('dict')

    ru_provider

# Generated at 2022-06-23 21:03:33.068893
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import PROVIDER_NAMES, PROVIDERS
    # base_data_provider = BaseDataProvider()
    # current_locale = base_data_provider.get_current_locale()
    current_locale = BaseDataProvider.get_current_locale()
    assert current_locale == 'en'
    assert BaseDataProvider.get_current_locale() != 'en'
    assert BaseDataProvider.get_current_locale() != 'en'


# Generated at 2022-06-23 21:03:34.219166
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider."""
    test = BaseProvider()
    assert test.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:03:46.513413
# Unit test for method get_current_locale of class BaseDataProvider

# Generated at 2022-06-23 21:03:48.907800
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    d = BaseDataProvider()
    assert isinstance(d.seed, int)
    assert d.locale == 'en'


# Generated at 2022-06-23 21:03:56.348020
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seeds = [None,0,1,2]
    for seed in seeds:
        bp = BaseProvider(seed=seed)
        bp_random = bp.random.randint(1,100)
        bp.reseed(seed=seed)
        bp.random.randint(1,100)
        if bp_random == bp.random.randint(1,100):
            print("test_BaseProvider_reseed OK")
        else:
            return print("test_BaseProvider_reseed KO")
    print("test_BaseProvider_reseed OK")


# Generated at 2022-06-23 21:03:57.981611
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider('en')
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:04.725526
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class FakeProvider(BaseProvider):

        def __init__(self, seed=None):
            super().__init__(seed)

        def reseedInner(self, seed=None):
            self.reseed(seed)

        def get_random(self):
            return self.random

    fp = FakeProvider()
    assert fp.get_random() is random
    fp.reseedInner()
    assert fp.get_random() is not random
    fp.reseedInner()
    assert fp.get_random() is not random
    fp.reseedInner('fake')
    assert fp.get_random() is not random


# Generated at 2022-06-23 21:04:12.895153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    cp = Code()
    code = cp.code(locale='ru')
    assert isinstance(code, str)
    assert code.endswith(';')
    with cp.override_locale('en'):
        code = cp.code()
        assert isinstance(code, str)
        assert code.endswith(';')
    code = cp.code(locale='ru')
    assert isinstance(code, str)
    assert code.endswith(';')
    with cp.override_locale('en'):
        code = cp.code()
        assert isinstance(code, str)
        assert code.endswith(';')

# Generated at 2022-06-23 21:04:17.302204
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Setup
    provider = BaseDataProvider()

    # Exercise
    new_provider = provider.override_locale(locale='ru')

    # Verify
    assert provider.locale == locales.EN
    assert new_provider.locale == 'ru'

# Generated at 2022-06-23 21:04:19.421324
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class A(BaseProvider):
        pass
    assert str(A()) == 'A'



# Generated at 2022-06-23 21:04:20.924483
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:22.169958
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()
    assert isinstance(provider.random, Random)


# Generated at 2022-06-23 21:04:27.419384
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Case: default
    provider = BaseProvider()
    result = provider.__str__()
    assert result == 'BaseProvider'
    # Case: with seed
    provider = BaseProvider(seed=123)
    result = provider.__str__()
    assert result == 'BaseProvider'


# Generated at 2022-06-23 21:04:32.033234
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    actual = ['{}{}{}'.format(__name__, '.', x) for x in
              [
                  'BaseDataProvider.__init__',
                  'BaseDataProvider.get_current_locale',
              ]
              ]
    expected = __all__
    assert sorted(actual) == sorted(expected)

# Generated at 2022-06-23 21:04:33.673656
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""
    provider = BaseProvider()
    number = provider.random.randint()
    provider.reseed(seed=123)
    assert number != provider.random.randint()

# Generated at 2022-06-23 21:04:42.726327
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # initialize the random seed
    import time,os
    time.sleep(1)  # If you call too fast, you will get the same time stamp.
    random_seed = int(time.time())
    print("random seed:",random_seed)

    import mimesis.providers.address as address
    address_provider = address.Address(seed = random_seed)
    with address_provider.override_locale('en'):
        assert(address_provider.__str__() == 'Address <en>')
        address_provider.get_address()


# Generated at 2022-06-23 21:04:44.462402
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:04:52.742326
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    # Case 1
    # Input : locale = 'en-US',seed = None
    # Expect : BaseDataProvider(locale = 'en-US',seed = None)
    base_data_provider_one = BaseDataProvider('en-US')
    assert base_data_provider_one.locale == 'en-us'
    assert base_data_provider_one.seed == None

    # Case 2
    # Input : locale = 'en-US',seed = 'n3b3r3r'
    # Expect : BaseDataProvider(locale = 'en-US',seed = 'n3b3r3r')
    base_data_provider_one = BaseDataProvider('en-US','n3b3r3r')
    assert base_data_prov

# Generated at 2022-06-23 21:05:04.109285
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.address import Address
    from mimesis.providers.currency import Currency
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.generic import Generic
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.it import IT
    from mimesis.providers.math import Math
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.process import Process
    from mimesis.providers.scientific import Scientific

# Generated at 2022-06-23 21:05:07.758928
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='en-US')
    assert provider.get_current_locale() == 'en-us'

# Generated at 2022-06-23 21:05:13.464383
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        """Test class."""

        def get_current_locale(self) -> str:
            """Get current locale."""
            return self.locale

    provider = Test()
    with provider.override_locale('de'):
        assert provider.locale == 'de'

    assert provider.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:05:24.068725
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.enums import Gender
    from mimesis.builtins import Person as P
    """Test BaseProvider.__str__.
    
    Test BaseProvider.__str__
    
    :return: None
    
    """
    person = P(seed=123)
    # Test default locale
    result = person.full_name(gender=Gender.FEMALE)
    assert result == 'Samantha Romero'
    assert str(person) == 'Person <en>'
    # Test locale overriding
    with person.override_locale('en-GB'):
        result = person.full_name(gender=Gender.FEMALE)
        assert result == 'Amy Fisher'
        assert str(person) == 'Person <en-GB>'
        with person.override_locale('ru'):
            result

# Generated at 2022-06-23 21:05:25.113365
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:05:28.630556
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(10)
    assert provider.random.seed(10) == provider.seed


# Generated at 2022-06-23 21:05:32.406285
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    from mimesis.builtins import Personal
    from mimesis import locales

    pers = Personal('zh')
    assert pers.get_current_locale() == locales.ZH



# Generated at 2022-06-23 21:05:34.825092
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    c = BaseDataProvider()
    assert c


# Generated at 2022-06-23 21:05:40.897340
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """
    Test for method reseed of class BaseProvider
    """
    #random.seed(42)
    #r = random.randint(1,100)
    #print(r)
    p = BaseProvider(seed=42)
    #print(p.random.randint(1,100))
    r = p.random.random()
    p.reseed(42)
    assert r == p.random.random()

# Generated at 2022-06-23 21:05:44.032123
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Address
    # Initialize new instance of Address
    Address().__str__() == 'Address <en>'
    # Override locale for Address
    Address().override_locale('uk').__str__() == 'Address <uk>'




# Generated at 2022-06-23 21:05:51.119599
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    pr = BaseDataProvider()
    assert pr._data == {}
    assert pr._datafile == ''
    assert pr._setup_locale(locale="en") is None
    assert pr._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert pr._pull(datafile="address.json") is None
    assert pr.get_current_locale() == "en"
    def test_provider():
        return None
    assert pr.override_locale(locale="ru") == test_provider()

# Generated at 2022-06-23 21:05:53.800705
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        _datafile = 'test'
    t = Test()
    with t.override_locale('ru') as instance:
        assert instance is t
        assert instance.get_current_locale() == 'ru'
        assert t.get_current_locale() == 'ru'
    assert t.get_current_locale() == 'en'


# Generated at 2022-06-23 21:05:57.989181
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    t = BaseDataProvider()
    assert t.locale == locales.DEFAULT_LOCALE, "test_BaseDataProvider() test 1 failed"
    assert t.seed == None, "test_BaseDataProvider() test 2 failed"

test_BaseDataProvider()

# Generated at 2022-06-23 21:06:03.630488
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('en')
    print(p.full_name())
    p.reseed(42)
    print(p.full_name())
    p.reseed()
    print(p.full_name())

    p = Person('en')
    print(p.full_name())
    p.reseed(42)
    print(p.full_name())
    p.reseed()
    print(p.full_name())



# Generated at 2022-06-23 21:06:12.561264
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis import Time
    from mimesis.builtins import RussiaSpecProvider
    time1 = Time()
    time2 = Time()
    data1 = time1.now()
    data2 = time2.now()
    assert data1 == data2
    time2.reseed()
    data3 = time1.now()
    data4 = time2.now()
    assert (data3 != data4)
    bp = BaseProvider()
    data5 = bp.random.random()
    data6 = bp.random.random()
    assert data5 == data6
    bp.reseed()
    data7 = bp.random.random()
    data8 = bp.random.random()
    assert (data7 != data8)
   

# Generated at 2022-06-23 21:06:14.446921
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    data_provider = BaseProvider()
    assert data_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:06:17.136578
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    provider.get_current_locale()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:06:18.347259
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()



# Generated at 2022-06-23 21:06:22.749812
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Can be run with `tox -e mypy -- path/to/test_BaseProvider.py`
    # a = BaseProvider()
    # print(a)
    # a.seed = None
    # a.reseed()
    # assert a.seed is not None
    # print(a.seed)
    assert True

# Generated at 2022-06-23 21:06:24.154017
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=17)
    assert provider.seed == 17

# Generated at 2022-06-23 21:06:28.238833
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()
    assert isinstance(base_data_provider, BaseDataProvider)
    assert base_data_provider.__class__.__name__ in base_data_provider.__str__()

# Generated at 2022-06-23 21:06:30.265333
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == locales.EN
    assert provider.__str__ == 'BaseDataProvider <en>'
    assert provider._data == {}
    assert provider._pull() == None


# Generated at 2022-06-23 21:06:41.883912
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""

    from mimesis.builtins import Person as PersonProvider
    from mimesis.providers.person import Person as PersonDataProvider

    person_data_provider = PersonDataProvider(locale='ru')
    assert person_data_provider.get_current_locale() == 'ru'

    person = person_data_provider._data['full_name'].get('male')
    assert person[0] == 'Аарон'

    with person_data_provider.override_locale('en') as overridden:
        assert overridden.get_current_locale() == 'en'
        assert overridden._datafile == 'person.json'
        assert overridden._data_dir == '\\mimesis\\data'

       

# Generated at 2022-06-23 21:06:45.410625
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider, RussiaSpecProvider

    provider = RussiaSpecProvider()
    with provider.override_locale(locale=locales.RU):
        assert provider.locale == locales.RU

# Generated at 2022-06-23 21:06:50.003447
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    x = BaseDataProvider()
    assert x.locale == 'en'
    assert x._data == {}
    assert x._datafile == ''
    assert x._data_dir ==  Path('data\\en')

# Generated at 2022-06-23 21:06:52.152388
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.EN
    bdp = BaseDataProvider(locale=locale, seed=1234)
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:53.201251
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert True


# Generated at 2022-06-23 21:06:56.982291
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed(seed=42)
    assert bp.random is not random

# Generated at 2022-06-23 21:06:59.715410
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    print(base)

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-23 21:07:05.916133
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestClass(BaseDataProvider):
        def __init__(self, *args, **kwargs) -> None:
            # noinspection PyCompatibility
            super()
            self.locale = None

    test_class = TestClass()
    with TestClass.override_locale(locale='de') as test_object:
        assert test_object.get_current_locale() == 'de'
    assert test_class.get_current_locale() is None

# Generated at 2022-06-23 21:07:09.366973
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'en'
    provider = BaseDataProvider(locale=locale)
    assert provider.locale == locale

    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'

    assert provider.locale == locale

# Generated at 2022-06-23 21:07:11.455076
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp_string = str(bp)
    assert bp_string == 'BaseProvider'


# Generated at 2022-06-23 21:07:15.413434
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    # The default seed is not None
    assert provider.seed is None
    provider2 = BaseProvider(seed=1234)
    assert provider2.seed == 1234
    provider.reseed(1234)
    assert provider.seed == 1234
    # The default seed for random is not Random
    assert provider.random is random

# Generated at 2022-06-23 21:07:19.800236
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Test for the default constructor
    _seed = None
    provider = BaseProvider(seed=_seed)
    assert provider.seed == _seed

    # Test for the constructor with parameter
    seed = True
    provider = BaseProvider(seed=seed)
    assert provider.seed == seed


# Generated at 2022-06-23 21:07:25.614281
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    en_data = {'foo': 1, 'bar': 2}
    ru_data = {'foo': 3, 'bar': 4}
    provider._pull.cache_clear()
    provider._pull.cache_info()
    # assert get_current_locale of provider == 'ru'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:07:31.625894
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(str(BaseProvider()))
    print(str(BaseProvider(seed=123)))
    print(str(BaseDataProvider()))
    print(str(BaseDataProvider(locale='ja')))
    print(str(BaseDataProvider(seed=123)))
    with BaseDataProvider().override_locale(locale='ja'):
        print(str(BaseDataProvider()))


# Generated at 2022-06-23 21:07:35.546899
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test BaseDataProvider.__str__()."""
    provider = BaseDataProvider(locale='en')
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:07:39.821740
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    print('====== BaseDataProvider - test_BaseDataProvider_get_current_locale ======')
    from mimesis.providers import Person
    from mimesis.data import locales
    person = Person(locale='ru')
    for i in range(20):
        print(person.get_current_locale())


# Generated at 2022-06-23 21:07:40.985467
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale."""


# Generated at 2022-06-23 21:07:47.914938
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.enums import Gender
    from mimesis.person import Person
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()
    person_provider2 = PersonProvider()
    same_gender = [person.gender(), person_provider.gender()]
    is_same_gender = same_gender[0] == same_gender[1]
    second_gender = person_provider2.gender()

    assert person.seed == person_provider._get_seed() == person_provider2._get_seed()
    assert is_same_gender is True
    assert second_gender is not same_gender[0]

    person_provider2.reseed(345)

# Generated at 2022-06-23 21:07:50.169910
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class A(BaseProvider):
        pass

    class B(BaseProvider):
        pass

    a = A(123)
    b = B(123)
    assert a.random != b.random
    assert a.random is not random
    assert b.random is not random



# Generated at 2022-06-23 21:07:53.072829
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider()
    assert base_provider.seed == None
    assert base_provider.random == random
    base_provider_1 = BaseProvider(seed = 10)
    assert base_provider_1.seed == 10
    assert base_provider_1.random == Random()


# Generated at 2022-06-23 21:07:55.759696
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    temp = BaseDataProvider(locale='en')
    assert 'BaseDataProvider <en>' == str(temp)


# Generated at 2022-06-23 21:07:57.626454
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    _ = BaseDataProvider(locale='en')

# Generated at 2022-06-23 21:07:59.715958
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print(BaseDataProvider())

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:08:06.315201
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test method ``reseed`` of class ``BaseProvider``."""
    random_obj = Random()
    random_obj.seed(seed=42)
    base_provider_obj = BaseProvider(seed=42)

    assert base_provider_obj.random == random_obj
    base_provider_obj.reseed()
    assert base_provider_obj.random.seed != random_obj.seed
    assert base_provider_obj.random != random_obj


# Generated at 2022-06-23 21:08:12.857592
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import pytest
    from mimesis.providers.locale import Locale
    from mimesis.providers.locales import Locales

    l = Locale(seed=42)
    _l = Locales(seed=42)

    locale = l.get_current_locale()
    locale_ = _l.get_current_locale()

    with l.override_locale(locale='en'):
        locale_ = l.get_current_locale()

    with pytest.raises(AttributeError):
        with l.override_locale(locale='en'):
            l.get_current_locale()

    assert locale == 'ru'
    assert locale_ == 'en'

    locale = _l.get_current_locale()
    locale_ = _l.get_current_

# Generated at 2022-06-23 21:08:15.094205
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    x = BaseDataProvider()
    assert x.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:08:17.285796
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider()
    assert a.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:08:22.451416
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider()
    assert str(data_provider) == 'BaseDataProvider <en>'
    data_provider = BaseDataProvider('ru')
    assert str(data_provider) == 'BaseDataProvider <ru>'
    data_provider = BaseDataProvider('ru-RU')
    assert str(data_provider) == 'BaseDataProvider <ru-RU>'