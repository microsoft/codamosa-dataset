

# Generated at 2022-06-23 20:58:26.699756
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    demo = BaseDataProvider()
    assert str(demo) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:58:34.027289
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class NewProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN) -> None:
            super().__init__(locale=locale)
            self._datafile = 'test.json'

    provider = NewProvider()
    assert provider.get_current_locale() == 'en'

    with provider.override_locale(locale='ru') as new_prov:
        assert new_prov.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:58:39.362796
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.providers.person import Person

    p1 = BaseProvider()
    p2 = Person('en')
    assert p1.random is random
    assert str(p1) == 'BaseProvider'
    assert p2.random is not random
    assert str(p2) == 'Person <en>'

if __name__ == "__main__":
    test_BaseProvider()

# Generated at 2022-06-23 20:58:40.651093
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:58:43.299105
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider(locale = 'en')
    assert p.locale == 'en'
    assert p.seed is None


# Generated at 2022-06-23 20:58:44.783195
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ Unit Test for method override_locale of class BaseDataProvider. """
    assert True

# Generated at 2022-06-23 20:58:48.691438
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    _provider = BaseDataProvider(locale=locales.EN)
    with _provider.override_locale(locales.DE):
        assert _provider.locale == locales.DE
    assert _provider.locale == locales.EN

# Generated at 2022-06-23 20:58:49.278240
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    pass

# Generated at 2022-06-23 20:58:52.777683
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Given
    seed = 0
    # When
    base_provider = BaseProvider(seed)
    # Then
    assert base_provider.seed == seed
    assert base_provider.random == random
    assert base_provider.seed == seed
    assert base_provider.random == random


# Generated at 2022-06-23 20:59:03.995621
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    from mimesis.providers.metadata import Metadata
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.place import Place
    from mimesis.providers.product import Product
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit
    from mimesis.providers.useragent import UserAgent
    from mimesis.providers.website import Website

    print(Datetime())   # Datetime

# Generated at 2022-06-23 20:59:07.178771
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:11.571087
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    tbp = BaseProvider()
    s = tbp.__str__()
    assert s == 'BaseProvider'


# Generated at 2022-06-23 20:59:13.924694
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    p = Person()
    assert str(p) == 'Person'



# Generated at 2022-06-23 20:59:16.942393
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    try:
        test=BaseDataProvider()
    except Exception as e:
        assert(str(e) == "Can't instantiate abstract class BaseDataProvider with abstract methods _pull")
    else:
        assert(False)

# Generated at 2022-06-23 20:59:19.905440
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '123'
    r = Random()
    r.seed(seed)
    BaseProvider.reseed(r, seed)



# Generated at 2022-06-23 20:59:21.851217
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.base import BaseDataProvider
    bdp = BaseDataProvider()
    print(bdp.get_current_locale())



# Generated at 2022-06-23 20:59:25.377768
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider_seed = provider.seed
    provider_random = provider.random
    provider.seed = 123
    provider.reseed(200)
    assert provider.random != provider_random and provider.seed != provider_seed


# Generated at 2022-06-23 20:59:27.460161
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider(locale='en-US')
    assert dp.get_current_locale() == 'en-US'


# Generated at 2022-06-23 20:59:37.218484
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 'test'
    class TestProvider(BaseProvider):
        pass
    test_provider = TestProvider(seed=seed)
    assert test_provider.seed == seed
    assert test_provider.random == random
    test_provider.reseed()
    assert test_provider.seed == None
    assert type(test_provider.random) == mimesis.Random
    test_provider.reseed(seed)
    assert test_provider.seed == seed
    assert type(test_provider.random) == mimesis.Random

# Generated at 2022-06-23 20:59:40.232249
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    _base_data_provider = BaseDataProvider()
    _base_data_provider.locale = 'en'
    assert str(_base_data_provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:47.030939
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins.en import En
    from mimesis.builtins import address
    from mimesis.builtins import business
    from mimesis.builtins import code
    from mimesis.builtins import person
    from mimesis.builtins import science
    from mimesis.builtins import text
    assert(En.get_current_locale() == 'en')
    assert(address.Address.get_current_locale() == 'en')
    assert(business.Business.get_current_locale() == 'en')
    assert(code.Code.get_current_locale() == 'en')
    assert(person.Person.get_current_locale() == 'en')
    assert(science.Science.get_current_locale() == 'en')

# Generated at 2022-06-23 20:59:55.069531
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """
    .. versionadded:: 0.2.0
    .. versionchanged:: 0.3.0
    .. versionchanged:: 4.0.0
    """
    from random import Random
    random_number = Random(1).randint(100, 999)
    assert random_number == BaseProvider(1).random.randint(100, 999)
    assert isinstance(BaseProvider(1).random, Random)

    from random import SystemRandom
    random_number = SystemRandom(1).randint(100, 999)
    assert random_number == BaseProvider().random.randint(100, 999)
    assert isinstance(BaseProvider().random, SystemRandom)

# Generated at 2022-06-23 20:59:57.513834
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    d = BaseProvider()
    assert d.seed is None
    d = BaseProvider(seed=10)
    assert d.seed is 10
    assert d.random.seed(10) == None


# Generated at 2022-06-23 20:59:59.661337
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:00:06.308665
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    dp = BaseProvider()
    dp1 = BaseProvider()
    assert dp != dp1
    assert dp.random == dp1.random

    result = dp.random.get_state()

    dp.reseed()
    dp1.reseed()

    assert result == dp.random.get_state()
    assert dp.random != dp1.random

test_BaseProvider_reseed()

# Generated at 2022-06-23 21:00:07.631815
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class A(BaseDataProvider):
        pass
    x = A()
    assert str(x)=="A <en>"

# Generated at 2022-06-23 21:00:09.782740
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random = Random()
    random.seed(10)
    assert random.random() == 0.9865770925655745


# Generated at 2022-06-23 21:00:12.199433
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed == None
test_BaseProvider()


# Generated at 2022-06-23 21:00:13.486251
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:00:16.104720
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed is None


# Generated at 2022-06-23 21:00:20.331933
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # we are using the base class BaseDataProvider
    baseProvider = BaseDataProvider()

    # we are calling the method get_current_locale()
    assert baseProvider.get_current_locale() == "en"

# Generated at 2022-06-23 21:00:28.220653
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    with open('/var/tmp/mimesis.seed', 'w') as seedfile:
        seedfile.write('12345')

    bp = BaseProvider(seed='/var/tmp/mimesis.seed')
    assert str(bp) == 'BaseProvider'
    assert bp.seed == '/var/tmp/mimesis.seed'
    # assert bp.random is a function
    assert bp.random.seed == '/var/tmp/mimesis.seed'
    bp.reseed()
    assert bp.seed is None
    assert bp.random.seed is None



# Generated at 2022-06-23 21:00:34.992835
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale_name = "hi"
    seed = 42
    seed_string = "seed_string"
    provider = BaseDataProvider(locale=locale_name, seed=seed)
    provider_str = str(provider)
    assert provider_str == 'BaseDataProvider <hi>'
    provider = BaseDataProvider(seed=seed_string)
    provider_str = str(provider)
    assert provider_str == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:36.356718
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
	d = BaseDataProvider()
	result = d.__str__()
	assert isinstance(result,str)


# Generated at 2022-06-23 21:00:38.230200
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    base = BaseDataProvider()
    assert base.get_current_locale() == 'en'

# Generated at 2022-06-23 21:00:42.966989
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Method to test context manager override_locale."""
    class Example(BaseProvider):
        """Class for testing method override_locale."""

        def get_current_locale(self) -> str:
            """Overridden get_current_locale."""
            return 'ru'

    with Example().override_locale(locales.EN) as provider:
        assert isinstance(provider, Example)
        assert provider.locale == locales.EN

# Generated at 2022-06-23 21:00:44.367597
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()

# Generated at 2022-06-23 21:00:53.030959
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider seed change."""
    random.seed()
    get_random_item(locales.SUPPORTED_LOCALES)
    random.seed()
    get_random_item(locales.SUPPORTED_LOCALES)
    p = BaseProvider(seed='a')
    assert p.random._seed == 'a'
    p.reseed('b')
    assert p.random._seed == 'b'
    p.reseed('c')
    assert p.random._seed == 'c'
    p.reseed('d')
    assert p.random._seed == 'd'


# Generated at 2022-06-23 21:01:01.805958
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    for _ in range(4):
        my_seed = random.getrandbits(64)
        a = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        b = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        c = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        d = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        e = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        f = BaseProvider(seed=my_seed)
        my_seed = random.getrandbits(64)
        g = BaseProvider(seed=my_seed)
       

# Generated at 2022-06-23 21:01:08.224834
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert getattr(provider, '_datafile') == ''
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert getattr(provider, '_data') == {}
    assert provider.get_current_locale() == 'en'
    assert hasattr(provider, 'locale') == True
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:01:09.733166
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    x = BaseProvider()
    assert str(x) == 'BaseProvider'


# Generated at 2022-06-23 21:01:10.938287
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:01:14.225847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    locale_1 = locales.EN
    locale_2 = locales.DE
    with provider.override_locale(locale_1) as p_1:
        assert p_1.locale == locale_1
    with provider.override_locale(locale_2) as p_2:
        assert p_2.locale == locale_2


# Generated at 2022-06-23 21:01:17.247946
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.currency import Currency
    assert Currency().override_locale('en_US').get_current_locale() == 'en_US'

# Generated at 2022-06-23 21:01:21.343958
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check for operator 'with'."""
    with BaseDataProvider().override_locale(locales.EN) as over_locale:
        assert over_locale.locale == locales.EN
        assert over_locale.get_current_locale() == locales.EN

# Generated at 2022-06-23 21:01:31.455188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

        def get_current_locale(self):
            return getattr(self, 'locale', locales.DEFAULT_LOCALE)

    with TestProvider() as provider:
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        with provider.override_locale(locale = locales.RU):
            assert provider.get_current_locale() == locales.RU
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with TestProvider() as provider:
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        with provider.override_locale(locales.RU):
            assert provider

# Generated at 2022-06-23 21:01:33.372849
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    r = Random()
    r.seed(1337)
    x = r.random()
    assert x == 0.8594969092150168


# Generated at 2022-06-23 21:01:35.771928
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_data_provider = BaseDataProvider()
    print(str(test_data_provider))
    assert test_data_provider.locale == locales.DEFAULT_LOCALE
    assert str(test_data_provider) == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:01:38.540686
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider"""
    provider = BaseDataProvider() # pylint: disable=unused-variable
    assert provider is not None, "Should be BaseDataProvider"
test_BaseDataProvider()

# Generated at 2022-06-23 21:01:50.210760
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.data import US_STATES

    bp = BaseProvider()
    assert isinstance(bp, BaseProvider)
    assert bp.__str__() == 'BaseProvider'
    assert isinstance(bp._data, Dict)
    assert bp._datafile == ''
    assert bp.locale == 'en'
    assert bp.seed is None
    assert bp.random is random
    assert bp._validate_enum(US_STATES.ALABAMA, US_STATES) == 'Alabama'
    assert bp._validate_enum(None, US_STATES) != 'Alabama'
    assert not bp._validate_enum(None, US_STATES)
    assert not bp._validate_enum(US_STATES.ALABAMA, None)
    assert bp.__

# Generated at 2022-06-23 21:01:51.736120
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-23 21:01:54.630798
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    try:
        base_data_provider = BaseDataProvider(locale="en", seed=1000)
        assert base_data_provider is not None
    except UnsupportedLocale as e:
        print(e)


# Generated at 2022-06-23 21:01:59.449341
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestOverrideLocale(BaseDataProvider):
        def __init__(self, locale='en', seed=None):  # noqa: D107
            super().__init__(locale=locale, seed=seed)

    locale = 'ru'

    provider = TestOverrideLocale(locale=locale)
    with provider.override_locale() as p:
        assert p._data


if __name__ == "__main__":
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:02:01.259513
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test1 = BaseProvider()
    test2 = BaseProvider(seed=123)
    assert test1.random != test2.random
    assert test1.seed != test2.seed

# Generated at 2022-06-23 21:02:02.387348
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bs_provider = BaseProvider()

    assert bs_provider.__str__() == "BaseProvider"

# Generated at 2022-06-23 21:02:03.809349
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Tests the reseed method of class BaseProvider."""
    provider = BaseProvider(seed=42)
    assert provider.seed == 42


# Generated at 2022-06-23 21:02:05.928170
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    seed = 80
    provider = BaseProvider(seed)

    assert provider.seed == seed
    assert provider.random is random
    provider.reseed(80)
    assert provider.random is not random


# Generated at 2022-06-23 21:02:09.188460
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    current_locale = provider.get_current_locale()
    assert current_locale == locales.EN

# Generated at 2022-06-23 21:02:13.127145
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider_obj = BaseProvider()
    assert isinstance(base_provider_obj.random, Random)
    assert isinstance(base_provider_obj.seed, int)
    base_provider_obj = BaseProvider(seed=12345)
    assert isinstance(base_provider_obj.random, Random)
    assert isinstance(base_provider_obj.seed, int)


# Generated at 2022-06-23 21:02:15.896756
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FakeProvider(BaseDataProvider):
        def __str__(self):
            locale = getattr(self, 'locale', locales.DEFAULT_LOCALE)
            return '<{}>'.format(locale)

    provider = FakeProvider()
    with provider.override_locale('ru') as p:
        assert str(p) == '<ru>'


# Generated at 2022-06-23 21:02:18.208053
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:02:20.040119
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test1 = BaseProvider()
    test2 = BaseProvider("test")
    assert isinstance(test1, BaseProvider)
    assert isinstance(test2, BaseProvider)


# Generated at 2022-06-23 21:02:22.070230
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
	provider = BaseDataProvider()
	actual = str(provider)
	expected = 'BaseDataProvider <en>'
	assert actual == expected

# Generated at 2022-06-23 21:02:24.249622
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:02:26.445858
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b is not None


# Generated at 2022-06-23 21:02:28.833892
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.EN
    assert BaseDataProvider('ru').get_current_locale() == 'ru'

# Generated at 2022-06-23 21:02:38.155266
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Zero arguments, default locale
    a = BaseDataProvider()
    assert a.__str__() == 'BaseDataProvider <{0}>'.format(locales.DEFAULT_LOCALE)
    # One argument, default locale №1
    a = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    assert a.__str__() == 'BaseDataProvider <{0}>'.format(locales.DEFAULT_LOCALE)
    # One argument, default locale №2
    a = BaseDataProvider(locale='en')
    assert a.__str__() == 'BaseDataProvider <en>'
    # One argument, default locale №3
    a = BaseDataProvider(locale='en_GB')
    assert a.__str__() == 'BaseDataProvider <en>'
   

# Generated at 2022-06-23 21:02:40.665742
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:02:43.510270
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test __str__ method of BaseDataProvider."""
    bdp = BaseDataProvider(locale='en')
    assert str(bdp) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:02:47.178459
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    print('Test for method reseed of class BaseProvider.')
    provider = BaseProvider()
    provider.reseed(0)
    assert provider.random.random() == 0.5488135039273248


# Generated at 2022-06-23 21:02:49.655292
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'
# Test method __str__ of class BaseDataProvider


# Generated at 2022-06-23 21:02:52.395498
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    l = BaseDataProvider(locale = "en", seed = 234)
    assert l.locale == "en"
    assert l.seed == 234
    assert l.random == Random()


# Generated at 2022-06-23 21:02:53.456769
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert(bp)


# Generated at 2022-06-23 21:02:54.866793
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-23 21:02:56.256520
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    a = BaseDataProvider()
    assert a.get_current_locale() == 'en'



# Generated at 2022-06-23 21:02:58.272728
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-23 21:03:01.979867
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert bdp.__str__() == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)

# Generated at 2022-06-23 21:03:06.806341
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    # check default
    assert str(BaseProvider()) == 'BaseProvider'

    # check custom seed
    base_provider = BaseProvider()
    base_provider.reseed(seed=12345)
    assert str(base_provider) == 'BaseProvider'


# Generated at 2022-06-23 21:03:08.604472
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    BP = BaseProvider()
    assert 'BaseP' in str(BP)


# Generated at 2022-06-23 21:03:18.386217
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    r = BaseDataProvider()

    assert isinstance(r._data, dict)
    assert r.locale == locales.DEFAULT_LOCALE
    assert r.seed is None
    assert r.random == random

    # If we don't pass seed, then it should be equal to the current time
    r = BaseDataProvider('ru')
    assert r.locale == 'ru'
    assert r.seed is None
    assert r.random == random

    r1 = BaseDataProvider(seed=1)
    r2 = BaseDataProvider(seed=1)
    assert r1.seed == 1
    assert r2.seed == 1
    assert r1.random is not r2.random

    # The following tests are invalid because the fixture initialization time
    # is always different
    # assert r1.random is not random
    # assert r

# Generated at 2022-06-23 21:03:21.335324
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class SimpleProvider(BaseDataProvider):
        pass
    dp = SimpleProvider(locale='en')
    assert dp.get_current_locale() == 'en'
test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-23 21:03:29.074904
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.schema import Field

    class TestProvider(BaseDataProvider):

        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)
            field = Field('en')
            self.schema = field.build().__iter__()

        def get_title(self) -> str:
            return self.schema.__next__()

    provider = TestProvider()
    with provider.override_locale(locales.EN) as provider:
        assert provider.get_title() == 'laborum'

# Generated at 2022-06-23 21:03:30.265468
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider(seed=0).seed == 0
    assert BaseProvider().seed is None

# Generated at 2022-06-23 21:03:35.921739
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider('en')
    # test the __init__ method
    assert a.locale == 'en'
    assert isinstance(a, BaseDataProvider)
    # test the get_current_locale method
    assert a.get_current_locale() == 'en'
    assert isinstance(a.get_current_locale(), str)
    # test the __str__ method
    assert a.__str__() == 'BaseDataProvider <en>'
    assert isinstance(a.__str__(), str)

# unit test for reseed method of class BaseDataProvider

# Generated at 2022-06-23 21:03:43.517431
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class Provider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)

    result = Provider()
    assert result.seed is None
    assert result.random is random
    random_backup = result.random
    result.reseed(123)
    assert result.seed == 123
    assert result.random is not random
    assert result.random is not random_backup


# Generated at 2022-06-23 21:03:47.056570
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test case for BaseDataProvider"""
    data_provider = BaseDataProvider()
    data_provider.locale = locales.EN
    data_provider.seed = 'test'
    data_provider._pull()

# Generated at 2022-06-23 21:03:55.846862
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    class BaseProviderTest(BaseProvider):
        """Class BaseProvider for test."""

        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes.

            :param seed: Seed for random.
                When set to `None` the current system time is used.
            """
            super().__init__(seed=seed)

    base_provider = BaseProviderTest()
    assert base_provider.seed is None
    assert base_provider.random == random

    base_provider.reseed(seed=1)
    assert base_provider.seed == 1
    assert base_provider.random == 1


# Generated at 2022-06-23 21:04:00.920107
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class DummyDataProvider(BaseDataProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)
            self.locale = 'en'
    obj = DummyDataProvider()
    assert obj.get_current_locale() == 'en'


# Generated at 2022-06-23 21:04:12.034999
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # assert get_current_locale('en') == 'en'
    # assert get_current_locale('fr') == 'fr'
    # assert get_current_locale('en_US') == 'en_US'
    # assert get_current_locale('ar_AE') == 'ar_AE'
    # assert get_current_locale('zh_CN') == 'zh_CN'
    # assert get_current_locale('de-DE') == 'de-DE'
    # assert get_current_locale('de_DE') == 'de_DE'
    # assert get_current_locale('de_AT') == 'de_AT'
    # assert get_current_locale('ne_NP') == 'ne_NP'
    assert get_current_locale('en') is not None
    assert get

# Generated at 2022-06-23 21:04:23.986602
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.locales import Locale
    class NewProvider(BaseDataProvider):
        _datafile = 'person.json'
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                 seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(seed=seed)
            self.locale = locale
            self._data: Dict[str, Any] = {}
            self._datafile = 'person.json'
            self._setup_locale(locale)
            self

# Generated at 2022-06-23 21:04:25.915968
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None


# Generated at 2022-06-23 21:04:36.685755
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale."""
    def _test():
        with BaseProvider().override_locale() as _:
            pass
    #  Should be raise since BaseProvider has no locale attribute
    assert non_raises(_test) is False

    def _test():
        with BaseProvider().override_locale('test') as _:
            pass
    #  Should be raise since BaseProvider has no locale attribute
    assert non_raises(_test) is False

    class Test(BaseProvider):
        #  Should be raise for missing datafile
        def _pull(self, datafile: str = ''):
            if datafile == '':
                raise AttributeError
            else:
                return


# Generated at 2022-06-23 21:04:38.845051
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()
    BaseProvider(11)


# Generated at 2022-06-23 21:04:41.872065
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Should be as assertRaises
    with BaseProvider() as base_provider:
        assert isinstance(base_provider, BaseProvider)
        assert base_provider.seed != None


# Generated at 2022-06-23 21:04:43.433142
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:04:48.896074
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """BaseDataProvider."""
    # This test is for the constructor
    # instance of the class.
    provider = BaseDataProvider()

    result = provider.get_current_locale()
    expected_result = locales.EN
    assert result == expected_result

    result = provider.random
    expected_result = random
    assert result == expected_result

    result = provider.seed
    expected_result = None
    assert result == expected_result



# Generated at 2022-06-23 21:04:51.467492
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bd = BaseDataProvider()
    assert bd.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:52.883053
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider()
    assert str(obj) == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:05:04.194448
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method `override_locale` of class BaseDataProvider."""

    from mimesis.providers import Person
    from mimesis.enums import Gender
    
    # Case 1
    p1 = Person()
    p1.gender = Gender.MALE
    with p1.override_locale('ru') as person:
        assert str(person) == 'Person <ru>'
        assert person.full_name('male') == 'Владимир Рославец'
    assert str(p1) == 'Person <en>'
    assert p1.full_name() == 'Michael Brown'
    # Case 2

# Generated at 2022-06-23 21:05:07.349971
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test constructor of class BaseProvider."""
    bd = BaseProvider()
    return True


# Generated at 2022-06-23 21:05:09.976799
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    t = BaseProvider()
    assert t.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:05:15.888696
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    en_person = Person()
    ru_person = Person(locale='ru')
    seed = '12345'
    en_person.reseed(seed)
    ru_person.reseed(seed)
    assert en_person.full_name(gender=Gender.FEMALE) == ru_person.full_name(gender=Gender.FEMALE)

# Generated at 2022-06-23 21:05:23.041767
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider(seed = 4).reseed(seed = 4) == None
    assert BaseProvider().reseed(seed = 4) == None
    assert BaseProvider().reseed(seed = None)!= BaseProvider(seed = 4).reseed(seed = 4)
    assert BaseProvider(seed = None).reseed(seed = 4) == None
    assert BaseProvider(seed = 2).reseed(seed = 2) == None
    assert BaseProvider(seed = None).reseed(seed = None) != BaseProvider(seed = 4).reseed(seed = 4)

# Generated at 2022-06-23 21:05:32.043618
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.personal.person import Person
    person = Person()
    with person.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
    assert person.get_current_locale() == 'en'
    with person.override_locale('de') as provider:
        assert provider.get_current_locale() == 'de'
    assert person.get_current_locale() == 'en'

# Generated at 2022-06-23 21:05:43.949819
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    class TestProvider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)
            self.data_dir = Path(__file__).parent.parent.joinpath('data')

    locales_data = TestProvider(seed=1234)
    assert locales_data.seed == 1234
    assert locales_data.random != random
    assert locales_data.random.random() == 0.19151945

    locales_data = TestProvider(seed=1337)
    assert locales_data.seed == 1337
    assert locales_data.random != random
    assert locales_data.random.random() == 0.13788429

    locales_data = TestProvider(seed=1337)
    assert locales_data.seed == 13

# Generated at 2022-06-23 21:05:46.526361
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.data import BaseProvider
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-23 21:05:48.334083
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class MyProvider(BaseProvider):
        """Example for test unit."""

    assert str(MyProvider()) == 'MyProvider'

# Generated at 2022-06-23 21:05:51.624203
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """"Unit test for method reseed of class BaseProvider"""
    provider = BaseProvider()
    assert provider.seed == None

    provider2 = BaseProvider(seed=123)
    assert provider2.seed == 123


# Generated at 2022-06-23 21:05:56.562971
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for constructor of `BaseDataProvider` with default params.

    In this test we check that the None value of seed
    will not change anything in constructor of `BaseDataProvider`

    :returns: Nothing.
    """
    provider = BaseDataProvider()
    assert provider.seed == None and provider.random == random



# Generated at 2022-06-23 21:06:00.225267
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    class Foo(BaseDataProvider):
        pass
    f = Foo()
    # f - is instance of class Foo
    assert f.locale is not None
    assert f.get_current_locale() == 'en'
    assert isinstance(f.get_current_locale(), str)

# Generated at 2022-06-23 21:06:01.689303
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 21:06:05.212029
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(None)
    assert(bp.seed is not None)
    bp.reseed("Zoinks")
    assert(bp.seed == "Zoinks")
    assert(bp.random != random)


# Generated at 2022-06-23 21:06:12.078079
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider."""
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random
    
    provider = BaseProvider(seed = 1)
    assert provider.seed == 1
    assert provider.random != random

# Generated at 2022-06-23 21:06:13.693158
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert p.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:16.240967
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    name = provider.__class__.__name__
    result = provider.__str__()
    assert name == result


# Generated at 2022-06-23 21:06:18.627492
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
	p = BaseProvider()
	p.reseed(seed=10)
	TestBaseProvider.test_BaseProvider()

# Generated at 2022-06-23 21:06:21.221241
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    _BaseDataProvider = BaseDataProvider(locale=locales.DEFAULT_LOCALE, seed=None)
    assert _BaseDataProvider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:06:22.525821
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    print(bdp.__str__())

# Generated at 2022-06-23 21:06:24.767504
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    locale = locales.EN
    assert locale in locales.SUPPORTED_LOCALES
    assert type(BaseProvider(locale)).__name__ == 'BaseProvider'



# Generated at 2022-06-23 21:06:34.397805
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """ Unit test for class BaseDataProvider """
    provider = BaseDataProvider()
    assert provider.__class__.__name__ == "BaseDataProvider"
    provider = BaseDataProvider(locale=locales.EN,seed=42)
    assert provider.__class__.__name__ == "BaseDataProvider"
    provider = BaseDataProvider(locale=locales.RU,seed=42)
    assert provider.__class__.__name__ == "BaseDataProvider"
    provider = BaseDataProvider(locale=locales.JA,seed=42)
    assert provider.__class__.__name__ == "BaseDataProvider"


# Generated at 2022-06-23 21:06:37.022729
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    fake = BaseDataProvider('ru')
    with BaseDataProvider.override_locale(locale = 'en') as provider:
        fake._pull = provider._pull
    print(fake.get_current_locale())
    print(provider.get_current_locale())

import doctest
doctest.testmod(verbose=True)

# Generated at 2022-06-23 21:06:38.632336
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider


# Generated at 2022-06-23 21:06:40.420892
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale="en")


# Generated at 2022-06-23 21:06:46.814624
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bd = BaseDataProvider()
    assert bd.get_current_locale() == locales.DEFAULT_LOCALE

    bd_pt_br = BaseDataProvider('pt_BR')
    assert bd_pt_br.get_current_locale() == 'pt_br'

    bd_not_supported = BaseDataProvider('AA')
    assert bd_not_supported.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:06:53.647903
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider(seed=None)
    bp2 = BaseProvider(seed=None)
    bp.reseed(seed=10)
    bp2.reseed(seed=10)
    assert bp.random == bp2.random
    assert bp.random != random
    bp3 = BaseProvider(seed=None)
    bp3.reseed(seed=11)
    assert bp.random != bp3.random


# Generated at 2022-06-23 21:06:56.982704
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test of method __str__ of class BaseDataProvider."""
    result = str(BaseDataProvider())
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:00.800223
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider1 = BaseDataProvider(locale='ru')
    assert '<ru>' in str(provider1)

# Generated at 2022-06-23 21:07:07.307761
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.locales import RU
    from mimesis.providers import Code
    from mimesis.providers.code import CodeProvider
    
    ru_provider = Code(locale=RU)
    assert ru_provider.get_current_locale() == RU
    
    with ru_provider.override_locale():
        assert ru_provider.get_current_locale() == CodeProvider.DEFAULT_LOCALE
    assert ru_provider.get_current_locale() == RU
    

# Generated at 2022-06-23 21:07:09.414543
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    b=BaseDataProvider()
    b._setup_locale('en')
    assert b.get_current_locale()=='en'

# Generated at 2022-06-23 21:07:12.193346
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.personal import Personal
    from mimesis.providers.base import BaseDataProvider
    assert 'en' == Personal().get_current_locale()



# Generated at 2022-06-23 21:07:15.791604
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = locales.EN
    w_locale = locales.DEFAULT_LOCALE
    dp = BaseDataProvider(locale=w_locale)
    with dp.override_locale(locale) as d:
        assert d.locale == locale



# Generated at 2022-06-23 21:07:18.502457
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test constructor of class BaseProvider."""
    bp = BaseProvider()
    bp = BaseProvider(seed=123)



# Generated at 2022-06-23 21:07:20.782990
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed(1)
    assert bp.random.__class__.__name__ == "Random"
    assert bp.seed == 1


# Generated at 2022-06-23 21:07:25.106890
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit-test for constructor for class BaseProvider."""
    provider = BaseProvider(seed=42)
    assert provider.random is not random
    assert provider.seed is not None
    assert provider.seed == 42


# Unit tests for constructor of class BaseDataProvider

# Generated at 2022-06-23 21:07:29.932682
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    print(dir(bdp))  # get object BaseDataProvider
    print(bdp)  # get object BaseDataProvider <en>
    print(bdp.locale)
    # get object BaseDataProvider when call function __str__
    with bdp.override_locale('en'):
        print(bdp)  # get object BaseDataProvider <en>

test_BaseDataProvider()

# Generated at 2022-06-23 21:07:34.925855
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    from mimesis.providers.address import Address
    provider = Address()
    assert type(provider.__str__()) == str
    assert provider.__str__() == 'Address'


# Generated at 2022-06-23 21:07:37.560584
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Code
    assert str(Code) == "Code"
    assert str(Code(seed=1)) == "Code"


# Generated at 2022-06-23 21:07:39.016053
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'

# Generated at 2022-06-23 21:07:40.809923
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:07:42.893291
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='en')
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:07:44.517697
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert isinstance(bp,BaseProvider)


# Generated at 2022-06-23 21:07:49.218118
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Name
    name = Name()
    with name.override_locale('ru'):
        assert name.get_current_locale() == 'ru'
        assert hasattr(name, 'name')
    assert name.get_current_locale() == 'en'
    assert hasattr(name, 'name')


# Generated at 2022-06-23 21:07:52.206717
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    assert str(BaseProvider()) == 'BaseProvider'



# Generated at 2022-06-23 21:07:54.317231
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider(seed=42)
    assert "BaseProvider" == str(b)



# Generated at 2022-06-23 21:07:56.549909
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed('mimesis')
    assert provider.seed == 'mimesis'
    provider.reseed(None)
    assert provider.seed is not None


# Generated at 2022-06-23 21:07:58.808855
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Arrange
    from mimesis.providers.geography import Geography

    geography = Geography(seed=4)

    # Act
    geography_str = str(geography)

    # Assert
    assert geography_str == 'Geography'

# Generated at 2022-06-23 21:08:01.189971
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the context manager override_locale."""
    class TestProvider(BaseDataProvider):
        """Fake provider."""

    provider = TestProvider()
    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:08:09.806428
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test class BaseDataProvider."""
    # Allowed locales
    test_locale_1 = 'en'
    test_locale_2 = 'ru'
    # Reseed
    test_seed_1 = 42
    test_seed_2 = 45

    # Test the constructor
    test_object = BaseDataProvider(test_locale_1, test_seed_1)
    assert test_object.locale == test_locale_1
    assert test_object.seed == test_seed_1

    # Test get_current_locale
    test_object2 = BaseDataProvider(test_locale_2, test_seed_2)
    assert test_object2.get_current_locale() == test_locale_2

# Generated at 2022-06-23 21:08:21.579296
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for the reseed method of BaseProvider class."""
    from mimesis.enums import Gender
    bp = BaseDataProvider(locale='en')
    gender = bp.genders()
    bp.reseed(1)
    assert gender == bp.genders()
    bp.reseed('1')
    assert gender == bp.genders()
    bp.reseed(1.1)
    assert gender == bp.genders()
    bp.reseed([1, 2])
    assert gender == bp.genders()
    bp.reseed((1, 2))
    assert gender == bp.genders()
    bp.reseed(Gender.MALE)
    assert gender == bp.genders()
    bp.reseed(None)

# Generated at 2022-06-23 21:08:26.411532
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.internet import Internet
    inet = Internet(seed=1234567890)
    with inet.override_locale(locales.EN_US) as inet:
        assert inet.get_current_locale() == locales.EN_US
    assert inet.get_current_locale() == locales.DEFAULT_LOCALE

