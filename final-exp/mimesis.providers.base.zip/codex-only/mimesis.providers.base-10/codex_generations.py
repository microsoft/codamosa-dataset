

# Generated at 2022-06-23 20:58:22.958205
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 20:58:32.518665
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    #  Sometimes locale-dependent providers may need to temporarily change
    #  the locale to override the current one.
    #  For them, the method `override_locale` of class `BaseDataProvider`
    #  has been implemented.
    from mimesis.providers.address import Address
    provider = Address(locale='ru')

    with provider.override_locale('en'):
        assert provider.country_code() == 'GB'

    with provider.override_locale('it'):
        assert provider.country_code() == 'IT'

# Generated at 2022-06-23 20:58:35.746484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        provider._override_locale('en')
        assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 20:58:38.322602
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class TestProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)
    assert str(TestProvider()) == "TestProvider"


# Generated at 2022-06-23 20:58:41.628928
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert str(p) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:58:51.802100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class BaseDataProviderC(BaseDataProvider):

        def __init__(self, seed=None):
            super().__init__(seed)
            self._datafile = 'block.json'
            self._pull()

        @property
        def block(self) -> Any:
            return self._data.get('block')

    bdp = BaseDataProviderC()
    with bdp.override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN
        assert isinstance(provider.block, list)
        assert all([isinstance(x, str) for x in provider.block])

    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 20:58:56.985344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    
    p = Person('ru')
    with p.override_locale('en') as context:
        assert context.get_current_locale() == locales.EN
        assert context.full_name(gender=Gender.MALE) == 'Paul Cook'
        assert context.full_name(gender=Gender.FEMALE) == 'Elizabeth Harper'
    assert p.get_current_locale() == 'ru'


# Generated at 2022-06-23 20:59:00.811582
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from . import computers

    provider = computers.Computers(locale=locales.EN)
    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU
    assert provider.locale == locales.EN


# Generated at 2022-06-23 20:59:05.694610
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data=BaseProvider()
    assert(data.seed==None)
    assert(str(data)=='BaseProvider')
    assert(data.random == random)
    data.reseed(12345)
    assert(data.seed==12345)
    assert(data.random == Random())


# Generated at 2022-06-23 20:59:12.539039
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.food import Food
    from mimesis.enums import Locale
    f = Food(seed=0)
    with f.override_locale(Locale.EN):
        assert f.get_current_locale() == 'en'
        assert f.fruit() == 'grape'
    assert f.get_current_locale() == 'ru'

# Generated at 2022-06-23 20:59:17.118890
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    # check attr
    assert hasattr(bp, 'seed')
    assert hasattr(bp, 'random')

    # check methods
    assert callable(bp.reseed)
    assert callable(bp._validate_enum)
    assert callable(bp.__str__)


# Generated at 2022-06-23 20:59:19.791703
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert (provider.seed)


# Generated at 2022-06-23 20:59:21.132615
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'

# Generated at 2022-06-23 20:59:29.510812
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # create a new provider
    provider = BaseDataProvider(locale = 'en', seed = '123')
    assert provider.locale == 'en' 
    assert provider.seed == '123'
    assert provider.random == random
    assert provider._data == {}
    assert provider._datafile == ''
    assert provider._data_dir == r'D:\Mimesis-0.6.8\mimesis\data'
    # create a new provider
    provider = BaseDataProvider(locale = 'en-US', seed = None)
    assert provider.locale == 'en-us'
    assert provider.seed == None
    assert provider.random == random
    assert provider._data == {}
    assert provider._datafile == ''

# Generated at 2022-06-23 20:59:31.435929
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    val = str(BaseProvider())
    assert val == 'BaseProvider'



# Generated at 2022-06-23 20:59:36.533561
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.payment_systems import PaymentSystem

    provider = PaymentSystem()
    locale = provider.get_current_locale()
    assert locale == locales.DEFAULT_LOCALE

    provider = PaymentSystem(locale='ru')
    locale = provider.get_current_locale()
    assert locale == 'ru'

# Generated at 2022-06-23 20:59:38.895475
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider()
    assert base_provider.seed is None
    assert base_provider.random is random

# Test for method _validate_enum

# Generated at 2022-06-23 20:59:45.816725
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    generator_1 = BaseProvider(seed=None)
    print(generator_1.seed, generator_1.random, generator_1.__str__())
    generator_2 = BaseProvider(seed=12345)
    print(generator_2.seed, generator_2.random, generator_2.__str__())
    assert generator_1.seed is not generator_2.seed
    assert generator_1.random is not generator_2.random
test_BaseProvider()


# Generated at 2022-06-23 20:59:50.027672
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    result = provider.seed
    expected = None
    assert result == expected

    provider = BaseProvider(seed=1234)
    result = provider.random.seed(provider.seed)
    expected = 1234
    assert result == expected



# Generated at 2022-06-23 20:59:55.484985
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert(a.random is random)
    assert(a.seed is None)
    a1 = BaseProvider(2433)
    assert(a1.random is not random)
    assert(a1.seed is not None)
    a1.reseed(2433)
    assert(a1.random is not random)
    assert(a1.seed is not None)
    assert(a1.random.seed == 2433)
    a1.reseed()
    assert(a1.random is not random)
    assert(a1.seed is not None)
    assert(a1.random.seed is not None)


# Generated at 2022-06-23 20:59:56.866579
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    testProvider = BaseDataProvider('ru', seed='test')
    assert testProvider._data_dir == Path('.').parent.parent.joinpath('data')


# Generated at 2022-06-23 21:00:04.301292
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    bp.reseed('test')
    assert (bp.seed) == 'test', 'Initialization with seed is not working'
    assert (bp.random.seed == bp.seed) and isinstance(bp.random, Random),\
    'Initialization with seed is not working'
    assert (bp.__str__() == 'BaseProvider'), 'str method is not working'


# Generated at 2022-06-23 21:00:05.300258
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider().__class__ == BaseDataProvider

# Generated at 2022-06-23 21:00:07.794929
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    # Act
    provider = BaseDataProvider()
    # Assert
    assert 'BaseDataProvider <en>' == str(provider)



# Generated at 2022-06-23 21:00:12.988788
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class _TestDataProvider(BaseDataProvider):
        def __init__(self, a: Any = locales.DEFAULT_LOCALE,
                     b: Any = None) -> None:
            super().__init__(a, b)

    with _TestDataProvider(locale='en') as Provider:
        assert Provider.locale == 'en'

    with Provider.override_locale('ru') as Provider:
        assert Provider.locale == 'ru'

# Generated at 2022-06-23 21:00:15.625968
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    provider.reseed(seed=2)
    assert provider.seed == 2


# Generated at 2022-06-23 21:00:27.353650
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider."""
    test_seed = 1234
    # Case 1: default initialization
    base_provider = BaseProvider()
    assert base_provider is not None
    assert base_provider.seed is None
    assert base_provider.random == random
    # Case 2: initialized with seed
    base_provider.reseed(test_seed)
    assert base_provider.seed == test_seed
    assert base_provider.random != random
    assert base_provider.random.seed == test_seed
    # Case 3: initialized with new seed
    test_seed = 4321
    base_provider.reseed(test_seed)
    assert base_provider.seed == test_seed
    assert base_provider.random != random
    assert base_provider.random.seed == test_seed


# Generated at 2022-06-23 21:00:29.287992
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestProvider(BaseDataProvider):
        pass
    assert str(TestProvider()) == 'TestProvider <en>'

# Generated at 2022-06-23 21:00:38.044481
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.enums import Gender
    from mimesis.providers.personal import Personal

    p = Personal(seed=42)

    assert isinstance(p.seed, int)

    first_call = p.full_name(gender=Gender.FEMALE)
    assert isinstance(first_call, str)

    assert p.seed == 42

    p.reseed(21)

    assert p.seed == 21

    second_call = p.full_name(gender=Gender.FEMALE)
    assert isinstance(second_call, str)

    assert first_call != second_call



# Generated at 2022-06-23 21:00:43.351128
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        pass

    tb = TestBaseDataProvider()
    tb._override_locale('en-US')
    assert tb.locale == 'en-us'

    tb._override_locale('ru')
    assert tb.locale == 'ru'

    with tb.override_locale('uk') as tb:
        assert tb.locale == 'uk'

    assert tb.locale == 'ru'

# Generated at 2022-06-23 21:00:48.506174
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    pr = BaseDataProvider()
    assert pr
    pr = BaseDataProvider(locale='en')
    assert pr
    pr = BaseDataProvider(seed=2)
    assert pr
    pr = BaseDataProvider(locale='en', seed=2)
    assert pr
    assert pr.seed == 2


# Generated at 2022-06-23 21:00:49.918810
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    str(b)


# Generated at 2022-06-23 21:00:51.160888
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    print(bp)
    print(bp.seed)
    print(bp.random)


# Generated at 2022-06-23 21:01:00.424750
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class Provider1(BaseDataProvider):
        """Class for testing."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get_some_data(self):
            """Get some data from JSON file."""
            return self._data.get('some_data', {})

        def get_other_data(self):
            """Get some data from JSON file."""
            return self._data.get('other_data', '')

        def get_current_locale(self):
            return self.locale

    p = Provider1(locale='en_US')


# Generated at 2022-06-23 21:01:02.683080
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    print(provider.seed)
    provider.reseed(123)
    print(provider.seed)


# Generated at 2022-06-23 21:01:05.402409
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Person
    s = Person().__str__()
    assert s == 'Person <en>'

# Generated at 2022-06-23 21:01:11.703534
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # BaseDataProvider()
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    # BaseDataProvider('en')
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'
    # BaseDataProvider('ru')
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'
    # BaseDataProvider('zh-hans')
    assert str(
        BaseDataProvider(locale='zh-hans')) == 'BaseDataProvider <zh-hans>'


# Generated at 2022-06-23 21:01:15.295161
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:01:19.371414
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    p1 = Person()
    p2 = Person(seed='test')
    p1.seed = 'test'
    p1.reseed()
    assert p2._random._seed == p1._random._seed

# Generated at 2022-06-23 21:01:26.591126
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    a = Address()
    b = Address()

    with a.override_locale('en') as address:
        assert isinstance(address, BaseDataProvider)
        assert address.locale != b.locale

    data: JSON = {
        'A': {
            'male': ['John'],
            'female': ['Mary'],
        }
    }
    c = Address(data=data)

    with c.override_locale('en') as address:
        assert isinstance(address, BaseDataProvider)
        assert address.locale == c.locale


# Generated at 2022-06-23 21:01:34.725254
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'
    assert BaseDataProvider(locale='ru').get_current_locale() == 'ru'
    assert BaseDataProvider(locale='es').get_current_locale() == 'es'
    assert BaseDataProvider(locale='fr').get_current_locale() == 'fr'
    assert BaseDataProvider(locale='it').get_current_locale() == 'it'
    assert BaseDataProvider(locale='de').get_current_locale() == 'de'
    assert BaseDataProvider(locale='pt').get_current_locale() == 'pt'
    assert BaseDataProvider(locale='zh').get_current_locale() == 'zh'
    assert BaseDataProvider(locale='uk').get_current_

# Generated at 2022-06-23 21:01:35.422199
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:01:37.132968
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:44.180724
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Create an instance of BaseDataProvider and assert its locale
    try:
        bd = BaseDataProvider("en")
        assert bd.locale == "en"
    except UnsupportedLocale as e:
        print("Unsupported Locale")
    except Exception as e:
        print("Other Exception")

    # Create another instance of BaseDataProvider without specifying locale
    # and assert its locale
    try:
        bd2 = BaseDataProvider()
        assert bd2.locale == "en"
    except UnsupportedLocale as e:
        print("Unsupported Locale")
    except Exception as e:
        print("Other Exception")

    # Return an unsupported locale and an UnsupportedLocale exception
    bd3 = BaseDataProvider("zh-tw")


if __name__ == "__main__":
    test_BaseData

# Generated at 2022-06-23 21:01:46.302473
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider()
    data_provider.get_current_locale()

# Generated at 2022-06-23 21:01:49.543304
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == bdp.locale



# Generated at 2022-06-23 21:01:58.441211
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locales.DEFAULT_LOCALE)) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locales.EN)) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locales.RU)) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider(locales.ES)) == 'BaseDataProvider <es>'
    assert str(BaseDataProvider(locales.JA)) == 'BaseDataProvider <ja>'
    assert str(BaseDataProvider(locales.DE)) == 'BaseDataProvider <de>'
    assert str(BaseDataProvider(locales.FR)) == 'BaseDataProvider <fr>'

# Generated at 2022-06-23 21:02:01.378415
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    code = 'fr'
    locale = getattr(locales, code.upper())
    provider = BaseDataProvider(locale)
    assert isinstance(provider, BaseDataProvider)
    assert str(provider) == 'BaseDataProvider <fr>'


# Generated at 2022-06-23 21:02:03.781425
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BASE_DATA_PROVIDER = BaseDataProvider(locale=locales.EN, seed=None)
    assert BASE_DATA_PROVIDER is not None
    assert BASE_DATA_PROVIDER.locale is not None
    assert isinstance(BASE_DATA_PROVIDER._data, Dict)

# Generated at 2022-06-23 21:02:05.539013
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider('en')
    test_str = '<mimesis.base.BaseDataProvider <en>>'
    assert str(data_provider) == test_str

# Generated at 2022-06-23 21:02:08.357631
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    baseProvider = BaseProvider()
    baseProvider.reseed(seed = 'seed')
    assert baseProvider.seed == 'seed'


# Generated at 2022-06-23 21:02:10.420552
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert type(provider).__name__ == 'BaseProvider'


# Generated at 2022-06-23 21:02:13.430564
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:02:17.773002
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=1)
    assert bp.random.random() == 0.13436424411240122

    bp.reseed(2)
    assert bp.random.random() == 0.27796777520752864

    bp = BaseProvider()
    bp.reseed(3)
    assert bp.random.random() == 0.4138702472194922

    bp.reseed()
    assert bp.random.random() != 0.4138702472194922


# Generated at 2022-06-23 21:02:26.567909
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.data import GENDERS
    from mimesis.builtins import Person
    from mimesis.utils import Counter, randomize_locales_priority

    from random import randint

    p = Person('en')
    randomize_locales_priority()

    def base_provider_func_str(q: int):
        provider = Person()
        if q == 0:
            strings = [provider.__str__(), str(provider)]
            if not any([isinstance(x, str) for x in strings]):
                return 1
            if any([x.startswith('Person') for x in strings]):
                return 1
            if p.__str__() == provider.__str__():
                return 1
        return 0


# Generated at 2022-06-23 21:02:30.286812
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Setup
    provider = BaseProvider()
    
    # Exercise
    ret = provider.__str__()
    
    # Verify
    assert type(ret) == str
    assert ret == 'BaseProvider'
    
    # Cleanup - none necessary


# Generated at 2022-06-23 21:02:33.623487
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    locale_provider = BaseProvider(locale='En', seed='anything')
    assert locale_provider.locale == 'en'
    assert locale_provider.seed == "anything"
    assert isinstance(locale_provider.random, Random)


# Generated at 2022-06-23 21:02:37.663075
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """ Unit test for method override_locale of class BaseDataProvider. """
    p = BaseDataProvider()
    with p.override_locale() as p:
        assert p.get_current_locale() == locales.DEFAULT_LOCALE
    assert p.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:02:43.669135
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.providers import Science, Science
    provider = Science(locale='de')
    with pytest.raises(ValueError):
        with provider.override_locale('ru'):
            pass
    science = Science()
    with science.override_locale('ru'):
        assert science.get_locale() == 'ru'
        with science.override_locale('de'):
            assert science.get_locale() == 'de'
        assert science.get_locale() == 'ru'

# Generated at 2022-06-23 21:02:47.268118
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    assert base._data == {}
    assert base.locale == "en"
    assert base._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert base.get_current_locale() == "en"

# Generated at 2022-06-23 21:02:50.122456
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert isinstance(provider.random , Random)
    assert provider.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:02:51.761602
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale=locales.EN)

# Generated at 2022-06-23 21:02:53.749320
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp_str = str(bp)
    assert bp_str == 'BaseProvider'

# Generated at 2022-06-23 21:02:56.334217
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    return
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:02:58.753469
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.EN
    p = BaseDataProvider(locale=locale)
    assert str(p) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:02:59.860775
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == "BaseProvider"


# Generated at 2022-06-23 21:03:01.489965
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for the method BaseProvider.__str__"""
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:03:05.426075
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins.food import Food
    from mimesis.builtins.science import Science
    food = Food()
    science = Science()
    assert (str(food) == 'Food <en>')
    assert (str(science) == 'Science <en>')

# Generated at 2022-06-23 21:03:06.276384
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import people
    assert people().get_current_locale() == locales.EN

# Generated at 2022-06-23 21:03:09.219015
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Test for method __str__, if locale is None

    t = BaseProvider()

    assert isinstance(t.__str__(), str)
    assert t.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:03:11.140862
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert type(b.__str__()) == str


# Generated at 2022-06-23 21:03:18.429230
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale, seed)

        def get_data(self):
            return self._data

    fake = TestProvider()
    with fake.override_locale('ru') as f:
        assert f is fake
        assert f.get_data() != {}
    assert f.get_data() == {}
    assert fake._pull.cache_info().hits == 2
    assert fake._pull.cache_info().misses == 2

# Generated at 2022-06-23 21:03:26.183150
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.typing import Seed
    from mimesis.utils import set_seed
    from .datetime import Datetime
    from .internet import Internet

    provider = BaseProvider(seed=set_seed())
    provider.reseed(seed=set_seed())
    provider_1 = provider.__init__(seed=set_seed())
    provider_2 = provider.reseed(seed=set_seed())
    assert provider != provider_1 != provider_2 != provider

    provider_1 = Datetime(seed=set_seed())
    provider_2 = provider_1.__init__(seed=set_seed())
    assert provider_1 != provider_2

    provider_1 = Internet(seed=set_seed())
    provider_2 = provider_1.__init__(seed=set_seed())

# Generated at 2022-06-23 21:03:28.204830
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)

# Generated at 2022-06-23 21:03:29.448636
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:03:32.574538
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    a = BaseProvider(seed=1)
    a.reseed(2)
    b = a.random.getrandbits(64)
    assert b == 633515366176358320, 'Expected 633515366176358320, but got ' + str(b)

# Generated at 2022-06-23 21:03:36.267024
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    # Create object of class BaseProvider
    bp1 = BaseProvider(seed="Test")

    # If seed is None, the current system time is used.
    bp2 = BaseProvider()

    # Check reseed method
    bp1.reseed('Test')
    bp2.reseed()



# Generated at 2022-06-23 21:03:36.913680
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    return 'Not implemented'


# Generated at 2022-06-23 21:03:41.399391
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_obj = BaseDataProvider()
    assert test_obj.__str__() == 'BaseDataProvider <en-US>'
    test_obj.locale = 'tr_TR'
    assert test_obj.__str__() == 'BaseDataProvider <tr_TR>'


# Generated at 2022-06-23 21:03:45.630720
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    name = 'Person'
    locale = locales.EN
    provider = BaseDataProvider('providers')
    expected = 'Person <{}>'.format(locale)
    assert str(provider) == expected

# Generated at 2022-06-23 21:03:47.614813
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    f = BaseDataProvider()
    g = BaseDataProvider("en")
    assert g.locale == "en"

# Generated at 2022-06-23 21:03:52.119928
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    default_locale = 'en'
    locale = 'ru'
    provider = BaseDataProvider(locale=default_locale)

    with provider.override_locale(locale):
        assert provider.get_current_locale() == locale

    assert provider.get_current_locale() == default_locale

# Generated at 2022-06-23 21:03:57.982315
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.numbers import Numbers
    from mimesis.enums import Gender
    # Create object
    nums = Numbers()
    # Switch locale to «ru»
    with nums.override_locale('ru'):
        num = nums.random_int(1, 100, gender=Gender.M)
    assert nums.random_int(1, 100, gender=Gender.M) == num
    assert nums.locale == 'ru'


# Generated at 2022-06-23 21:04:02.398679
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # case 1:
    dp = BaseDataProvider()
    assert dp.locale == 'en'
    assert dp._data == {}
    assert dp._datafile == ''
    assert dp._data_dir == Path(__file__).parent.parent.joinpath('data')

if (__name__ == '__main__'):
    test_BaseDataProvider()

# Generated at 2022-06-23 21:04:06.482089
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider"""
    sample_data = BaseProvider()
    assert isinstance(sample_data, BaseProvider), "Is not instance of BaseProvider"


# Generated at 2022-06-23 21:04:11.533174
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale.

    :return: True.
    """
    from mimesis.providers.address import Address

    en_address = Address()
    with en_address.override_locale(locales.JA):
        assert en_address.get_current_locale() == locales.JA

    assert en_address.get_current_locale() == locales.EN

    return True

# Generated at 2022-06-23 21:04:16.603002
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Arrange
    from mimesis.data import Countries
    provider = Countries(locale='ru')
    # Act
    with provider.override_locale('en'):
        country_name = provider.country_name()
    # Assert
    assert country_name == 'Singapore'

# Generated at 2022-06-23 21:04:18.162166
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Provider(BaseProvider):
        def __init__(self):
            super().__init__()

    provider = Provider()
    result = str(provider)
    assert result == 'Provider'


# Generated at 2022-06-23 21:04:20.046793
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider"""
    BaseDataProvider().get_current_locale()

# Generated at 2022-06-23 21:04:22.119731
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider=BaseProvider(seed=100)
    assert provider.seed==100


# Generated at 2022-06-23 21:04:24.300184
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Test BaseProvider __str__ correctly
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:04:27.999865
# Unit test for method reseed of class BaseProvider

# Generated at 2022-06-23 21:04:39.747416
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        def __init__(self, locale, seed=None):
            super().__init__(locale=locale, seed=seed)
        def get_random_digit_in_range(self, _min: int = 0, _max: int = 10,
                                      ) -> int:
            if self.locale == locales.DEFAULT_LOCALE:
                return 10
            elif self.locale == locales.EN:
                return 20
            elif self.locale == locales.RU:
                return 30
            else:
                raise RuntimeError
        def get_random_letter(self) -> str:
            if self.locale == locales.DEFAULT_LOCALE:
                return 'q'

# Generated at 2022-06-23 21:04:42.531451
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method _BaseProvider___str__()."""
    from mimesis.providers import Person
    person = Person()
    assert isinstance(person.__str__(), str)

# Generated at 2022-06-23 21:04:46.215151
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    locale_name = locales.EN
    provider = BaseDataProvider(locale=locale_name)
    assert provider.get_current_locale(
    ) == locale_name


# Generated at 2022-06-23 21:04:52.884146
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    x = BaseDataProvider()
    assert str(x) == "BaseDataProvider <en>"
    assert x.__class__.__name__ == "BaseDataProvider"
    #assert x.locale == "en"
    assert x.seed == None
    assert x._data == {}
    assert x._datafile == ''
    assert x._data_dir.name == 'data'


# Test for _setup_locale function

# Generated at 2022-06-23 21:04:54.992262
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    item = BaseProvider()
    assert str(item) == "BaseProvider"



# Generated at 2022-06-23 21:04:56.638185
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:05:00.064851
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    seed = provider.seed
    provider.reseed()
    assert seed != provider.seed



# Generated at 2022-06-23 21:05:02.606595
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    dataprovider = BaseDataProvider()
    assert str(dataprovider) == 'BaseDataProvider <en>'
    with dataprovider.override_locale('uk'):
        assert str(dataprovider) == 'BaseDataProvider <uk>'

# Generated at 2022-06-23 21:05:07.570092
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method BaseProvider.__str__."""
    dp = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    assert dp.__str__() == 'BaseDataProvider'
    dp = BaseDataProvider()
    assert dp.__str__() == 'BaseDataProvider'
    dp = BaseDataProvider(locale=locales.RU)
    assert dp.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:05:10.223180
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider class."""
    from mimesis.enums import Gender
    bp = BaseProvider()
    bp._validate_enum(Gender.MALE, Gender)

# Generated at 2022-06-23 21:05:13.191356
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider()
    assert 'BaseDataProvider' == str(obj)
    assert 'BaseDataProvider <en>' == "{}".format(obj)


# Generated at 2022-06-23 21:05:16.827948
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    import mimesis.builtins
    assert str(BaseDataProvider(locales.DEFAULT_LOCALE)) == 'BaseDataProvider <en>'
    assert str(mimesis.builtins.Person('zh')) == 'Person <zh>'

# Generated at 2022-06-23 21:05:18.079400
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.datasets.locale import BASE_LOCALES

    for locale in BASE_LOCALES:
        BaseDataProvider(locale)

# Generated at 2022-06-23 21:05:19.324763
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base=BaseDataProvider()
    #assert base

# Generated at 2022-06-23 21:05:26.122218
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Code
    from mimesis.builtins import Person
    assert str(Person()) == 'Person <en>'
    assert str(Code()) == 'Code <en>'
    assert str(Person('ru')) == 'Person <ru>'
    assert str(Code('ru')) == 'Code <ru>'
    assert str(Person(locale='ru')) == 'Person <ru>'
    assert str(Code(locale='ru')) == 'Code <ru>'
    assert str(Person(locale='ru-RU')) == 'Person <ru-RU>'
    assert str(Code(locale='ru-RU')) == 'Code <ru-RU>'
    assert str(Person(locale='zh-CN')) == 'Person <zh-CN>'

# Generated at 2022-06-23 21:05:32.229173
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp_class = BaseDataProvider()
    print(dp_class.get_current_locale())  # en
    dp_class._setup_locale("ru")
    print(dp_class.locale)  # ru
    print(dp_class.get_current_locale())  # ru


# Generated at 2022-06-23 21:05:36.315506
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b1 = BaseDataProvider()
    print(b1)
    b2 = BaseDataProvider(locale='ru', seed=1234567)
    print(b2)


# Generated at 2022-06-23 21:05:36.908210
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    pass

# Generated at 2022-06-23 21:05:47.493306
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Given
    class TestProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'test-data.json'

        def get_data(self):
            return self._data

    # When
    # Then
    with TestProvider(locale='ru-RU') as provider_ru:
        assert provider_ru.get_current_locale() == 'ru-ru'

        with provider_ru.override_locale('fr-FR') as provider_fr:
            assert provider_fr.get_current_locale() == 'fr-fr'

        assert provider_ru.get_current_locale() == 'ru-ru'



# Generated at 2022-06-23 21:05:50.469619
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.datetime import Datetime
    provider = Datetime()
    assert 'Datetime' == provider.__str__(), '__str__() failed'


# Generated at 2022-06-23 21:05:54.725430
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    def assert_A_ru(provider):
        """Assert method `get_one` of `provider` has locale of `ru`."""
        assert provider.get_one('ru.A') == 'а'

    def assert_A_en(provider):
        """Assert method `get_one` of `provider` has locale of `en`."""
        assert provider.get_one('en.A') == 'A'

    class Provider(BaseDataProvider):
        """Another provider."""

        _datafile = 'alphabet.json'

        def get_one(self, key: str = '') -> str:
            """Return a letter by key.

            :return: The letter
            """
            return self._data[key]

   

# Generated at 2022-06-23 21:05:59.808901
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data1 = BaseProvider(seed=None)
    data2 = BaseProvider(seed=12345)
    print(data1)
    print(data2)
    data1.reseed(None)
    print(data1)
    print(data2)
    data1.reseed(12345)
    print(data1)
    print(data2)


# Generated at 2022-06-23 21:06:01.398262
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'



# Generated at 2022-06-23 21:06:03.158999
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='en')
    assert provider.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:06:09.388496
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code

    p = BaseDataProvider(seed=42)
    origin_locale = p.locale
    with p.override_locale('ru'):
        assert p.locale == 'ru'
    assert p.locale == origin_locale

    p = Code(seed=42)
    origin_locale = p.locale
    with p.override_locale('ru'):
        assert p.locale == 'ru'
    assert p.locale == origin_locale


# Generated at 2022-06-23 21:06:10.250408
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
	pass


# Generated at 2022-06-23 21:06:11.824875
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bp = BaseDataProvider()
    assert bp.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:19.106786
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    obj = BaseDataProvider('es',)
    result = obj._setup_locale('es')
    assert result==None
    assert obj.locale=='es'
    assert obj._data=={}
    assert obj._datafile == ''
    assert obj._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert obj.seed == None
    assert obj.random == random
    assert obj.random is random
    result = obj.reseed('hi')
    assert obj.seed == 'hi'
    assert obj.random is not random
    assert obj.random is not None
    assert obj.random.seed == 'hi'

# Generated at 2022-06-23 21:06:20.938299
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == "BaseProvider"

# Generated at 2022-06-23 21:06:26.824109
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.person import Person

    p = Person(locale='ru')

    with p.override_locale('en'):
        assert p.locale == 'en'
        assert isinstance(p.name(), str)
        assert isinstance(p.surname(Gender.MALE), str)

    assert p.locale == 'ru'
    assert isinstance(p.name(), str)
    assert isinstance(p.surname(Gender.FEMALE), str)

# Generated at 2022-06-23 21:06:28.834510
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    fp = BaseDataProvider('en')
    assert fp.get_current_locale() == 'en'
    assert fp.get_current_locale == 'en'


# Generated at 2022-06-23 21:06:35.028405
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class s(BaseDataProvider):
        pass

    seed = 'asd'
    b = s(seed=seed)
    # 1-3
    with b.override_locale('en') as x:
        assert b == x
        assert x.locale == 'en'

    # 4-6
    with b.override_locale('ru') as x:
        assert b == x
        assert x.locale == 'ru'
    assert b.locale == 'en'

    # 7-9
    with b.override_locale('zh-Hans') as x:
        assert b == x
        assert x.locale == 'zh-Hans'
    assert b.locale == 'en'

    # 10-12

# Generated at 2022-06-23 21:06:39.366621
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # NOTE: TEST FOR METHOD
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)

    provider = TestProvider(locale='ru')
    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:06:42.683316
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    target = BaseDataProvider('en')
    result = str(target)
    expected = 'BaseDataProvider <en>'
    assert result == expected



# Generated at 2022-06-23 21:06:43.767691
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider(seed=None)
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:06:47.484121
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed()
    assert bp.seed is not None
    assert bp.random is not random

# Generated at 2022-06-23 21:06:50.369540
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_BaseDataProvider.result = BaseDataProvider()
    assert BaseDataProvider.__init__(BaseDataProvider()) == None

# Generated at 2022-06-23 21:06:53.492573
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Sample(BaseDataProvider):
        def something(self) -> None:
            pass
    p = Sample()
    assert p.__str__() == 'Sample <{}>'.format(locales.DEFAULT_LOCALE)

# Generated at 2022-06-23 21:07:05.453180
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person, Language
    p = Person()
    with p.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert isinstance(p.full_name, str)
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert isinstance(p.full_name, str)
    with p.override_locale('xx') as p:
        assert p.get_current_locale() == 'xx'
        assert isinstance(p.full_name, str)
    with p.override_locale(None) as p:
        assert p.get_current_locale() == 'en'

# Generated at 2022-06-23 21:07:14.599484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE):
            super().__init__(locale)

        def custom(self):
            return self.locale.upper()

        @property
        def locale_dependent(self):
            return self.locale.lower()

    p = Provider('ja')

    assert p.custom() == 'JA'
    assert p.locale_dependent == 'ja'

    with p.override_locale('en'):
        assert p.custom() == 'EN'
        assert p.locale_dependent == 'en'

    assert p.locale == 'ja'
    assert p.custom() == 'JA'
    assert p.locale_dependent == 'ja'

    # Values of the cache have been updated

# Generated at 2022-06-23 21:07:19.935230
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Testing method reseed."""
    class ReseedProvider(BaseProvider):
        """Test class."""

    provider = ReseedProvider()
    assert provider.seed is None
    assert provider.random is random

    provider.reseed(seed=None)
    assert isinstance(provider.random, Random)



# Generated at 2022-06-23 21:07:25.064490
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test BaseDataProvider method __str__."""
    class Provider(BaseDataProvider):
        """Test subclass."""
    provider = Provider()
    d = dict()
    d['Provider <en>'] = str(provider)
    provider = Provider(locale='ru')
    d['Provider <ru>'] = str(provider)

    return d

# Generated at 2022-06-23 21:07:32.134405
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method ``__str__`` of class ``BaseDataProvider``."""
    from mimesis.enums import Gender
    from mimesis.providers import Address, Person

    p = Person()
    assert str(p) == 'Person <en>'

    p.locale = 'de'
    assert str(p) == 'Person <de>'

    p.locale = 'ru'
    assert str(p) == 'Person <ru>'

    p.locale = Gender.MALE
    with p.override_locale('de'):
        assert str(p) == 'Person <de>'

    p = Address()
    with p.override_locale('ru'):
        assert str(p) == 'Address <ru>'



# Generated at 2022-06-23 21:07:35.293297
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    f = BaseProvider()
    assert str(f) == "<class 'mimesis.base.BaseProvider'>"
    f.locale = 'ru'
    assert str(f) == "<class 'mimesis.base.BaseProvider'>"


# Generated at 2022-06-23 21:07:36.794659
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Foo(BaseProvider):
        pass
    foo = Foo()
    s = str(foo)
    assert s == 'Foo'


# Generated at 2022-06-23 21:07:39.466248
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()

    with provider.override_locale(locale=locales.RU) as data_provider:
        assert getattr(data_provider, 'locale') == locales.RU

    assert getattr(provider, 'locale') == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:07:46.582305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale, seed)

    provider = Provider()
    provider2 = Provider('ru')
    with provider.override_locale('ru'):
        assert provider.locale == 'ru'
        assert provider2.locale == 'ru'
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider2.locale == 'ru'

# Generated at 2022-06-23 21:07:48.051758
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider(locale='en')
    assert data_provider != None


# Generated at 2022-06-23 21:07:50.222052
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.seed = 42
    bp.reseed()
    assert bp.seed == 42
    assert isinstance(bp.random, Random)


# Generated at 2022-06-23 21:07:51.451543
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:08:02.119248
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    # Initialize a BaseDataProvider object and set the default value for its parameters
    print("\nExample: Initialize a BaseDataProvider object and set the default value for its parameters")
    dataprovider = BaseDataProvider()
    print("\nThe default value for parameters:")
    print("\tdata: ", dataprovider._data)
    print("\tdatafile: ", dataprovider._datafile)
    print("\tdata_dir: ", dataprovider._data_dir)
    print("\tlocale: ", dataprovider.locale)
    print("\trandom seeds: ", dataprovider.random)

    # Initialize a BaseDataProvider object and set custom value for its parameters
    print("\nExample: Initialize a BaseDataProvider object and set custom value for its parameters")
    dataprov

# Generated at 2022-06-23 21:08:10.914844
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from random import seed
    from mimesis.random import random
    from mimesis.localization import en
    from mimesis.random import random_int
    from mimesis.localization import en
    from mimesis.random import random_int

    seed(1)
    r1 = random.random()
    seed(1)
    r2 = random.random()
    assert r1 == r2
    assert r2 == 0.13436424411240122

    seed(1)
    r1 = random_int()
    seed(1)
    r2 = random_int()
    assert r1 == r2
    assert r2 == 596516649

    provider1 = en.Person()
    provider1.reseed(seed=1)

    r1 = provider1.full_name()
    r

# Generated at 2022-06-23 21:08:14.581556
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # create instance of class BaseDataProvider
    obj = BaseDataProvider()
    # check str(obj) == 'BaseDataProvider <en>'
    assert str(obj) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:08:17.609584
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    pr = BaseDataProvider(locale='en-US')
    assert str(pr) == 'BaseDataProvider <en-us>'

# Generated at 2022-06-23 21:08:23.535502
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    class SimpleDataProvider(BaseDataProvider):
        """Simple data provider."""

    dp = SimpleDataProvider()
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE, 'Class name is' \
                                                              ' not SimpleDataProvider.'

    # Override locale with new one
    dp.locale = locales.RU
    assert dp.get_current_locale() == locales.RU, 'Class name is not ' \
                                                  'SimpleDataProvider.'

