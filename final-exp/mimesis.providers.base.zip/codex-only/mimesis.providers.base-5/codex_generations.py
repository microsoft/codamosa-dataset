

# Generated at 2022-06-23 20:58:26.124968
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    seed = provider.seed
    assert seed is None
    provider.seed = 1
    assert provider.seed == 1
    assert provider.random.seed == 1
    provider.reseed(2)
    assert provider.seed == 2
    assert provider.random.seed == 2


# Generated at 2022-06-23 20:58:29.592989
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    foo = BaseDataProvider(locale='ru')
    assert foo.get_current_locale() == 'ru'



# Generated at 2022-06-23 20:58:35.602907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p1 = BaseDataProvider('en')
    res = []
    with p1.override_locale('ru') as p2:
        res.append(p1.get_current_locale())
        res.append(p2.get_current_locale())
    res.append(p1.get_current_locale())
    assert res == ['ru', 'ru', 'en']

    with p1.override_locale() as p2:
        res.append(p1.get_current_locale())
        res.append(p2.get_current_locale())
    res.append(p1.get_current_locale())
    assert res == ['ru', 'ru', 'en', 'en', 'en', 'en']



# Generated at 2022-06-23 20:58:38.428011
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class MockBaseProvider(BaseProvider):
        pass
    mbp = MockBaseProvider()
    assert mbp.__str__() == 'MockBaseProvider'



# Generated at 2022-06-23 20:58:43.051154
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
     # Test for method __str__()
     # in class BaseDataProvider 
     x = BaseDataProvider()
     assert x.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:58:52.741499
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.currency import Currency
    from mimesis.providers.date import DateTime
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    from mimesis.providers.miscellaneous import Miscellaneous
    from mimesis.providers.network import Network
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import USPerson
    from mimesis.providers.person.it import ItalianPerson

# Generated at 2022-06-23 20:59:03.995809
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # mimesis.providers.base.BaseDataProvider.
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers import Web

    # For random lib.
    seed = 123
    # For random lib.
    seed_ = 12345

    assert Web.__doc__
    assert BaseDataProvider.__doc__

    web = Web(seed)
    assert web.__class__.__name__ == 'Web'
    assert web.__module__ == 'mimesis.providers.base'
    assert web.__str__() == 'Web <en>'
    assert web.locale == 'en'
    assert web._datafile == 'web.json'
    assert isinstance(web.user_agents, dict)

    # First call.
    assert web.get_current_locale

# Generated at 2022-06-23 20:59:06.624345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person('en')
    with p.override_locale('ru'):
        assert p.get_full_name() == 'Панченко Мирослав Александрович'

# Generated at 2022-06-23 20:59:12.642999
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    code = Code()
    with code.override_locale('uk') as c:
        assert c.get_current_locale() == 'uk'
        assert code.get_current_locale() == 'en'

    assert code.get_current_locale() == 'en'

# Generated at 2022-06-23 20:59:15.821571
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    b.locale = "en-US"
    msg = "BaseDataProvider <en-US>"
    assert str(b) == msg
    assert b.__str__() == msg

# Generated at 2022-06-23 20:59:18.571041
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    with contextlib.suppress(UnsupportedLocale):
        provider = BaseProvider(locale="it_IT")
        assert provider.__str__() == "BaseProvider"


# Generated at 2022-06-23 20:59:20.450719
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == "BaseProvider"


# Generated at 2022-06-23 20:59:25.378228
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for a method override_locale of a class BaseDataProvider."""
    import mimesis.builtins
    provider = mimesis.builtins.Builtins(locale='ru')

    with provider.override_locale('en') as p:
        assert p.locale == 'en'

    # Check that current locale has not changed
    assert provider.locale == 'ru'

# Generated at 2022-06-23 20:59:27.476348
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    baseDP = BaseDataProvider()
    assert isinstance(baseDP.__str__(), str)
    assert baseDP.__str__() == "BaseDataProvider <en>"


# Generated at 2022-06-23 20:59:31.383331
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)


# Generated at 2022-06-23 20:59:33.755087
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider()
    assert str(test_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:35.695099
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider(seed=None).__str__() == 'BaseProvider'


# Generated at 2022-06-23 20:59:37.594615
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 20:59:41.530866
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import Generic

    provider = Generic('ru')
    with base.override_locale('en'):
        assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:43.487953
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(123456)
    assert bp.random.seed_value == 123456, "reseed() method is not working correctly"


# Generated at 2022-06-23 20:59:47.733683
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, EN, JP, Locale, Person

    p1 = Person(locale=EN)
    assert p1.locale == EN

    p2 = Person(locale=JP)
    assert p2.locale == JP

    with Person.override_locale(EN) as _p:
        assert _p.locale == EN

    assert p1.locale == EN
    assert p2.locale == JP

    with Address.override_locale(JP) as _a:
        assert _a.locale == JP

    with Locale.override_locale(EN) as _l:
        assert _l.locale == EN

# Generated at 2022-06-23 20:59:57.299414
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider override_locale."""
    from mimesis.providers.address import Address
    from mimesis.providers.codecategory import CodeCategory

    address = Address(seed=12345)
    codecategory = CodeCategory(seed=12345)
    with address.override_locale():
        address_code = address.get_country_code()
        address_country = address.get_country()
        address_random = address.random
    assert (address_code, address_country) == ('UA', 'Ukraine')
    assert address_random.seed == 12345

    with codecategory.override_locale():
        category_code = codecategory.get_category_code()
        category_title = codecategory.get_category_title()
        category_random = codecategory.random

# Generated at 2022-06-23 20:59:59.105352
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.builtins.datetime import Datetime
    dt = Datetime(seed=123)
    dt.seed = None
    dt.reseed()
    assert dt.seed is not None

# Generated at 2022-06-23 21:00:02.848096
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    _test = BaseDataProvider()
    assert _test.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:13.131894
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        __locale__ = 'en'

        def __init__(self, seed=None, locale=None, **kwargs):
            super().__init__(seed, locale=locale, **kwargs)

    assert A(locale='en').get_current_locale() == 'en'
    with A(locale='en').override_locale('ru') as inst:
        assert inst.get_current_locale() == 'ru'
    assert A(locale='en').get_current_locale() == 'en'
    assert A(locale='ru').get_current_locale() == 'ru'
    with A(locale='ru').override_locale('en') as inst:
        assert inst.get_current_locale() == 'en'
    assert A

# Generated at 2022-06-23 21:00:17.224620
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis import Person
    p = Person()
    assert isinstance(p.__str__(), str)
    p.__str__() == 'Person <en>'
    p.__str__() == 'Person <en>'


# Generated at 2022-06-23 21:00:24.415130
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    elem = BaseDataProvider()
    assert str(elem) == 'BaseDataProvider <en>'
    with elem.override_locale('ru') as mocked_elem:
        assert str(mocked_elem) == 'BaseDataProvider <ru>'
    assert str(elem) == 'BaseDataProvider <en>'
    del elem.locale
    assert str(elem) == 'BaseDataProvider'


# Generated at 2022-06-23 21:00:25.084233
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == 'en'


# Generated at 2022-06-23 21:00:26.169518
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
        from mimesis.providers import Cryptographic
        crypto = Cryptographic()
        assert crypto.get_current_locale() == 'en'

# Generated at 2022-06-23 21:00:29.059407
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(123)
    bp.reseed(234)
    if bp.random.getstate()[1][0] != 234:
        raise ValueError("Unit test fail: BaseProvider - reseed.")


# Generated at 2022-06-23 21:00:32.308504
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    text = BaseDataProvider()
    assert text is not None, 'BaseDataProvider is null'
    assert text is not '', 'BaseDataProvider is empty'
    assert isinstance(text, BaseDataProvider), 'is not BaseDataProvider'


# Generated at 2022-06-23 21:00:39.157686
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider()
    assert test_provider.__str__() == 'BaseDataProvider <en>'
    test_provider = BaseDataProvider(locale='ru')
    assert test_provider.__str__() == 'BaseDataProvider <ru>'
    test_provider.locale = 'ru'
    assert test_provider.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:00:44.938938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.providers.person import Person

    en_person = Person()

    with pytest.raises(ValueError) as ctx:
        with en_person.override_locale('it'):
            pass

    assert str(ctx.value) == '«Person» has not locale dependent'

    class CustomDataProvider(BaseDataProvider):
        pass

    provider = CustomDataProvider()
    with pytest.raises(AttributeError) as ctx:
        with provider.override_locale('it'):
            pass

    assert str(ctx.value) == "'CustomDataProvider' object has no attribute 'locale'"

# Generated at 2022-06-23 21:00:49.048761
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '1234567'
    b = BaseProvider()
    assert b.random is random
    b.reseed(seed)
    assert isinstance(b.random, Random)
    assert b.seed == seed



# Generated at 2022-06-23 21:00:53.418622
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    assert provider.seed is None
    provider.reseed(1)
    assert provider.seed == 1
    assert isinstance(provider.random, Random)
    provider.reseed()
    assert provider.seed is None



# Generated at 2022-06-23 21:00:56.302223
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class my_class(BaseProvider): 
        def __init__(self):
            pass
    assert 'my_class' == str(my_class())
    b = my_class()


# Generated at 2022-06-23 21:00:59.318043
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider('en_US')
    assert isinstance(bdp, BaseProvider)
    assert isinstance(bdp, BaseDataProvider)
    assert bdp.get_current_locale() == 'en_us'


# Generated at 2022-06-23 21:01:05.083287
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # 1
    prov = BaseDataProvider()
    assert prov.__str__() == 'BaseDataProvider <en>'
    assert prov.get_current_locale() == 'en'
    # 2
    prov1 = BaseDataProvider('ru')
    assert prov1.__str__() == 'BaseDataProvider <ru>'
    assert prov1.get_current_locale() == 'ru'
    # 3
    prov2 = BaseDataProvider('ru-RU')
    assert prov2.__str__() == 'BaseDataProvider <ru-ru>'
    assert prov2.get_current_locale() == 'ru-ru'
    # 4
    prov4 = BaseDataProvider('en')
    prov4._override_locale()
    assert prov4.get_current_locale() == 'en'
   

# Generated at 2022-06-23 21:01:11.043704
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.providers.person import Person

    person = Person('uk')

    with person.override_locale(locales.EN) as p:
        assert p is not person
        assert p.locale == locales.EN
        assert person.locale == locales.UK

    assert p is not person
    assert p.locale == locales.EN
    assert person.locale == locales.UK



# Generated at 2022-06-23 21:01:15.058721
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseprovider = BaseDataProvider(locale='en', seed=None)

    assert baseprovider.locale == 'en'



# Generated at 2022-06-23 21:01:19.935226
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(22)
    seed = bp.seed
    expected = 22
    assert seed == expected

    bp = BaseProvider()
    bp.reseed()
    seed = bp.seed
    assert seed is not None


# Generated at 2022-06-23 21:01:21.296380
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:01:26.031104
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    dp.__str__()
    dp.locale = 'en'
    assert dp.__str__() == "BaseDataProvider <en>"
    dp.locale = 'ru'
    assert dp.__str__() == "BaseDataProvider <ru>"

# Generated at 2022-06-23 21:01:28.431300
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert str(BaseDataProvider()) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:30.254360
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test constructor of class BaseProvider."""
    a = BaseProvider()
    assert a.seed is None


# Generated at 2022-06-23 21:01:31.418036
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dataprovider = BaseDataProvider()


# Generated at 2022-06-23 21:01:35.512769
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            self.__locale__ = 'en'
            self._datafile = ''
            self._data_dir = ''

    provider = TestProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:36.975244
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # assert BaseProvider().__init__(seed = this.reseed)
    print(BaseProvider().__init__(seed = None))


# Generated at 2022-06-23 21:01:37.901392
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    str(obj)


# Generated at 2022-06-23 21:01:39.792054
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert(bdp.__str__() == 'BaseDataProvider <en>')



# Generated at 2022-06-23 21:01:44.720828
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    obj = BaseProvider(seed=42)
    assert obj.random.seed(42) == obj.random.seed(42) == obj.random.seed(42)


# Generated at 2022-06-23 21:01:46.354470
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == "BaseProvider"

# Generated at 2022-06-23 21:01:48.380821
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:51.083296
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    for locale in locales.ALL_LOCALES:
        provider = BaseDataProvider(locale=locale)

        assert provider.get_current_locale() == locale.lower()

# Generated at 2022-06-23 21:01:52.133344
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:55.426436
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # This is a base class for all providers.
    bp = BaseProvider()
    assert bp.__str__() == "BaseProvider"
    bp = BaseProvider(seed=23432)
    assert bp.__str__() == "BaseProvider"


# Generated at 2022-06-23 21:01:58.754386
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Food

    food = Food(locale='ru')
    with food.override_locale('en') as food:
        assert food.locale == 'en'
        assert food.get_current_locale() == 'en'
    assert food.locale == 'ru'


# Generated at 2022-06-23 21:02:05.538457
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Generic
    from time import time
    with Generic(seed=time()) as en_gen:
        with Generic() as ru_gen:
            assert en_gen.seed != ru_gen.seed
            en_seed = en_gen.seed
            ru_seed = ru_gen.seed
            assert en_gen.get_current_locale() == locales.EN
            assert ru_gen.get_current_locale() == locales.RU
            en_data = en_gen.get_data()
            ru_data = ru_gen.get_data()
            assert en_data != ru_data
            en_name = en_gen.name()
            ru_name = ru_gen.name()

# Generated at 2022-06-23 21:02:14.423964
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet
    
    # Find p(x)
    def p(x):
        return int(str(x)[::-1])

    # Random numbers list
    numbers = []
    for i in range(1000):
        numbers.append(p(random.randint(0, 1000)))

    seed = random.randint(0, 1000)

    # Check reseed of lru_cache in method get_ipv4
    ip = Internet(seed=seed)
    lru_cache = ip.get_ipv4.cache_info()[1]
    assert lru_cache == 0

    # Check reseed of lru_cache in method get_uuid
    code

# Generated at 2022-06-23 21:02:19.450394
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """It tests the BaseDataProvider.override_locale method."""
    from mimesis.builtins import Person

    p = Person()
    with p.override_locale('en-GB') as _:
        assert p.get_current_locale() == 'en-GB'

    assert p.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:22.983463
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    seed = Random().randint(1, 100)
    assert seed != provider.seed
    provider.reseed(seed)
    assert seed == provider.seed


# Generated at 2022-06-23 21:02:29.997425
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._data = {
                'en': {
                    'foo': 'foo',
                    'bar': 'bar',
                },
                'en_US': {
                    'bar': 'bar',
                    'buzz': 'buzz',
                },
                'ru': {
                    'foo': 'фу',
                    'bar': 'бар',
                    'buzz': 'базз',
                },
            }
            self._datafile = 'test.json'

    provider = TestProvider('ru')

# Generated at 2022-06-23 21:02:32.898692
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = "1111111111111111"
    provider = BaseProvider(seed=seed)
    provider.reseed(seed)
    assert provider.seed == seed
    assert provider.random == Random()


# Generated at 2022-06-23 21:02:37.178415
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # base_provider = BaseProvider(seed="1234")
    print("test")
    # assert base_provider.seed == "1234", "BaseProvider constructor failed!"
    print("BaseProvider constructor passed!")

# Test for method reseed of BaseProvider

# Generated at 2022-06-23 21:02:40.531115
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import Datetime
    from mimesis.enums import StatusCode
    provider = Datetime('en')
    assert provider.get_current_locale() == StatusCode.ENGLISH.value


# Generated at 2022-06-23 21:02:45.266721
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random = Random()
    random.seed(42)
    random.seed()
    class CustomBaseProvider(BaseProvider):
        def _get_a(self):
            return self.random.getrandbits(32)
    p = CustomBaseProvider()
    a1 = p._get_a()
    p.reseed(42)
    a2 = p._get_a()
    assert a1 == a2


# Generated at 2022-06-23 21:02:54.013476
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class TestBaseProvider(BaseProvider):
        def _test_random(self):
            return self.random()
    class TestSeedTypeProvider(BaseProvider):
        def _test_random(self):
            return self.random()

    t1 = TestBaseProvider()
    assert t1._test_random() != t1._test_random()

    t1.reseed(1)
    assert t1._test_random() == t1._test_random()

    t2 = TestSeedTypeProvider(seed=1)
    assert t1._test_random() == t2._test_random()


if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:02:54.600119
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    pass

# Generated at 2022-06-23 21:02:56.119474
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:02:57.781780
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:03:04.389084
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    list_data = ['str', 'str2', 'str3']
    provider = BaseProvider(seed=list_data)
    random_str = provider.random.choice(list_data)
    assert random_str == provider.random.choice(list_data)
    provider.reseed()
    random_str2 = provider.random.choice(list_data)
    assert random_str != random_str2

# Generated at 2022-06-23 21:03:14.808043
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class BaseDataProvider(object):
        """This is a base class for all data providers."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(seed=seed)
            self.random = random

            if seed is not None:
                self.reseed(seed)

            if not locale:
                locale = locales.DEFAULT_LOCALE

            locale = locale.lower()
            if locale not in locales.SUPPORTED_LOCALES:
                raise UnsupportedLocale(locale)

            self

# Generated at 2022-06-23 21:03:17.899734
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    assert provider.random is not random
    assert provider.seed == 1

    provider = BaseProvider()
    assert provider.random is random
    assert provider.seed is None


# Generated at 2022-06-23 21:03:19.554161
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    p = BaseProvider()
    assert str(p) == "BaseProvider"

# Generated at 2022-06-23 21:03:22.994008
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    x = provider.random.randint(1, 10)
    provider.reseed(seed=None)
    y = provider.random.randint(1, 10)
    assert x != y and isinstance(x, int) and isinstance(y, int)


# Generated at 2022-06-23 21:03:30.310021
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender, Locale
    from mimesis.providers import Address
    newObj = Address(locale=Locale.EN)
    print(newObj)
    newObj.get_current_locale()
    newObj.random
    newObj.seed

    newObj.reseed(seed="password")
    print(newObj.random)
    print(newObj.seed)
    # newObj.reseed(seed="password")
    # newObj.reseed(seed="password")

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-23 21:03:33.691069
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    bp = BaseProvider(seed=5)
    assert bp.seed == 5
    assert bp.random.seed == 5

    bp.reseed(6)
    assert bp.seed == 6
    assert bp.random.seed == 6


# Generated at 2022-06-23 21:03:37.058602
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class CustomDataProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return 'cs'

    provider = CustomDataProvider()
    with provider.override_locale() as provider:
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == 'cs'



# Generated at 2022-06-23 21:03:44.708732
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test overriding locale in BaseDataProvider.

    :return: Nothing.
    """
    class Test(BaseDataProvider):
        pass

    test = Test(locale='en')
    Provider = Test
    provider = Provider(locale='en')
    with provider.override_locale('en'):
        assert provider.locale == 'en'

    with test.override_locale('ru') as test:
        assert test.locale == 'ru'

# Generated at 2022-06-23 21:03:47.140749
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-23 21:03:47.707970
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pass

# Generated at 2022-06-23 21:03:49.922698
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.base import BaseProvider

    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:03:51.623383
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    BaseProvider(seed=2)
    assert 'BaseProvider <>' in str(BaseProvider(seed=2))



# Generated at 2022-06-23 21:03:54.993753
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='ru')
    assert bdp.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:03:58.030372
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    BASE_PROVIDER = BaseProvider()
    assert BASE_PROVIDER.seed is None
    assert BASE_PROVIDER.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:04:05.239669
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit: Test override_locale method."""

    print('Unit test for **override_locale** of '
          'class **BaseDataProvider**')

    # If this code snippet fails then exception will be raised
    #   AttributeError: 'BaseDataProvider' object has no attribute 'locale'
    with BaseDataProvider().override_locale(locales.DEFAULT_LOCALE):
        pass

    # If this code snippet fails then exception will be raised
    #   ValueError: «BaseDataProvider» has not locale dependent
    prov = BaseProvider()
    try:
        with prov.override_locale(locales.DEFAULT_LOCALE):
            pass
    except ValueError as e:
        print('ValueError:', e)

# Generated at 2022-06-23 21:04:08.932004
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for constructor with default parameters.

    :return: Nothing.
    """
    D = BaseDataProvider()
    assert D.locale == "en"

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:04:12.472570
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed(seed=None)


# Generated at 2022-06-23 21:04:14.358386
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().__str__()=="BaseProvider"

# Generated at 2022-06-23 21:04:16.011165
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:04:19.024760
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:04:30.732471
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider.override_locale."""

    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = ''

        def get_data(self, key: str) -> str:
            """Get data."""
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale():
        assert provider.get_current_locale() == locales.EN

    provider.override_

# Generated at 2022-06-23 21:04:32.827438
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bd = BaseDataProvider()
    assert bd.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:04:44.259672
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # instantiating the BaseDataProvider
    bdp = BaseDataProvider()
    assert bdp is not None
    assert bdp is not ''

    # instantiate with a locale
    bdp2 = BaseDataProvider(locale="en")
    assert bdp2 is not None
    assert bdp2 is not ''
    assert bdp2.locale == "en"

    # instantiate with no locale
    bdp3 = BaseDataProvider()
    assert bdp3 is not None
    assert bdp3 is not ''
    assert bdp3.locale is not None
    assert bdp3.locale == "en"

    # instantiate with an unsupported locale
    assertRaises(UnsupportedLocale, BaseDataProvider, locale='xx')

    # instantiate with a locale, seed

# Generated at 2022-06-23 21:04:46.147920
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale='en', seed=1234)

# Generated at 2022-06-23 21:04:52.057904
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test get_current_locale method of class BaseDataProvider."""
    base = BaseDataProvider(locale='bs')
    assert base.get_current_locale() == 'bs'

    with base.override_locale('de'):
        assert base.get_current_locale() == 'de'
    assert base.get_current_locale() == 'bs'

# Generated at 2022-06-23 21:05:00.442840
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for BaseProvider constructor."""
    # Default attributes
    base_provider = BaseProvider()
    assert base_provider.seed is None

    # Manual attributes
    seed = 1
    base_provider = BaseProvider(seed=seed)
    assert base_provider.seed == seed
    assert base_provider.random is random

    seed = 0
    base_provider.reseed(seed)
    assert base_provider.seed == seed
    assert base_provider.random is not random


# Generated at 2022-06-23 21:05:04.696600
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale."""
    dummy_provider = BaseDataProvider()
    assert dummy_provider.get_current_locale() == locales.DEFAULT_LOCALE

    dummy_provider = BaseDataProvider(locale='en')
    assert dummy_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:05:08.188628
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    locale = provider.locale
    result = provider.get_current_locale()

    assert locale == result


# Generated at 2022-06-23 21:05:16.021308
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN):
            super().__init__(locale)
            self._datafile = 'phone_codes.json'
            self._pull()

        def get_phone_code(self):
            return self._data['codes']['1']

    provider = DataProvider()
    provider.get_phone_code()
    assert provider.get_phone_code() == '+1'
    with provider.override_locale(locales.RU):
        assert provider.get_phone_code() == '+7'
    assert provider.get_phone_code() == '+1'

# Generated at 2022-06-23 21:05:18.641476
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1234
    t = BaseProvider(seed)
    t.reseed(seed)
    assert t.random.seed() == seed

# Generated at 2022-06-23 21:05:27.129595
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import Food
    from mimesis.enums import Gender
    from mimesis.builtins.enums import Gender as GenderEnum
    import pytest
    from hypothesis import given
    from hypothesis import strategies as st
    @given(st.text(), st.integers())
    def test_BaseDataProvider_constructor(locale: str, seed: int):
        food = Food(locale, seed)
        # UnsupportedLocaleException
        with pytest.raises(UnsupportedLocale):
            food = Food('qq', seed)
        # Gender
        assert food.validate_enum('Male', GenderEnum) == Gender.MALE
        assert food.validate_enum('Female', GenderEnum) == Gender.FEMALE
        # NonEnumerableError

# Generated at 2022-06-23 21:05:31.028332
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test __str__ method of class BaseDataProvider."""
    eng = BaseDataProvider(locale='en')
    assert eng.__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:05:32.818014
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:05:35.242914
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b=BaseProvider()
    print(b)

# Generated at 2022-06-23 21:05:37.379063
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Person
    p = Person()
    assert str(p) == 'Person <en>'


# Generated at 2022-06-23 21:05:39.615408
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert 'BaseProvider' == str(provider)

# Generated at 2022-06-23 21:05:43.643163
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test get_current_locale() of BaseDataProvider.

    :return: Nothing.
    """
    dp = BaseDataProvider()
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:05:45.264224
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:05:48.761738
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
    assert isinstance(b.random, Random)
    assert isinstance(b, BaseProvider)
    b.reseed(51)
    assert b.seed == 51


# Generated at 2022-06-23 21:05:50.842146
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider()
    base_provider.reseed(3)
    assert base_provider.seed == 3


# Generated at 2022-06-23 21:06:01.577012
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Unit test for method override_locale of class BaseDataProvider
    class TestClass(BaseDataProvider):
        def __init__(self):
            self._datafile = 'test_data.json'
            self.locale = None
            super().__init__(locale=None)

        def _pull(self, datafile: str = ''):
            self._pull.cache_clear()
            self._pull()

    test_class = TestClass()
    with test_class.override_locale(locales.EN) as provider:
        assert provider.get_current_locale() == locales.EN

    with test_class.override_locale(locales.JA) as provider:
        assert provider.get_current_locale() == locales.JA


# Generated at 2022-06-23 21:06:06.992426
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    return BaseProvider().__str__()

# Generated at 2022-06-23 21:06:13.629622
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Simple constructor initializing the object.
    bp = BaseProvider()
    assert bp.random == random
    assert bp.seed is None
    assert str(bp) == "BaseProvider"
    bp = BaseProvider(seed=42)
    assert bp.random == random
    assert str(bp) == "BaseProvider"
    bp.reseed(seed=42)
    assert bp.random != random
    assert str(bp) == "BaseProvider"



# Generated at 2022-06-23 21:06:14.934401
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == "BaseProvider"

# Generated at 2022-06-23 21:06:18.202166
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    assert bp.random is random
    bp.reseed(42)
    assert bp.random is not random
    assert bp.random.seed == 42


# Generated at 2022-06-23 21:06:23.309469
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider(seed=42)
    assert obj.seed == 42
    assert obj.random == random
    obj.reseed()
    assert obj.seed == None
    assert obj.random == random
    assert obj.__str__() == "BaseProvider"
    obj = BaseProvider(seed=42)
    obj.reseed(seed = 84)
    assert obj.seed == 84
    assert obj.random == random

# Generated at 2022-06-23 21:06:35.081327
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class SimpleDataProvider(BaseDataProvider):
        """Test class."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            """Initialize attributes."""
            super().__init__(locale=locale)

        def method(self) -> None:
            """Simple method."""
            self._pull()
            return self.locale

    locale = 'ru'
    locale_default_separator = locales.LOCALE_SEPARATOR
    locales.LOCALE_SEPARATOR = '_'
    instance = SimpleDataProvider()
    instance_with_locale = SimpleDataProvider(locale=locale)


# Generated at 2022-06-23 21:06:36.428593
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print("Testing BaseDataProvider Class")
    pr = BaseDataProvider()


# Generated at 2022-06-23 21:06:38.422589
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    str_result = str(provider)
    assert str_result == "BaseProvider"

# Generated at 2022-06-23 21:06:42.052668
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    print(provider.__str__())
    provider = BaseDataProvider('en_US')
    print(provider.__str__())

# Generated at 2022-06-23 21:06:43.712280
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """ Test if __str__ method of class BaseDataProvider works corectly """
    base_data_provider = BaseDataProvider()
    assert str(base_data_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:51.878813
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.enums import Gender

    class DataProvider(BaseDataProvider):
        pass

    person = DataProvider(locale='en')
    assert str(person) == 'DataProvider <en>'

    d = DataProvider(locale='ru')
    d._pull()
    assert str(d) == 'DataProvider <ru>'

    gender = Gender(locale='en')
    assert str(gender) == 'Gender <en>'

# Generated at 2022-06-23 21:07:01.666325
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale."""
    from mimesis.providers.address import Address
    address = Address()
    en_addresses = []
    ru_addresses = []

    for _ in range(2):
        with address.override_locale(locales.EN):
            en_addresses.append(address.address())
        with address.override_locale(locales.RU):
            ru_addresses.append(address.address())

    # check that list of addresses in different locales are not equal
    assert en_addresses != ru_addresses

# Generated at 2022-06-23 21:07:03.508142
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:07:06.140370
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p is not None


# Generated at 2022-06-23 21:07:13.942918
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Inits(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.override_locale()

    assert Inits().locale == locales.DEFAULT_LOCALE
    with Inits().override_locale(locales.RU):
        assert Inits().locale == locales.RU
        with Inits().override_locale(locales.PT_BR):
            assert Inits().locale == locales.PT_BR
        assert Inits().locale == locales.RU
    assert Inits().locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:07:19.315003
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Testing method reseed of class BaseProvider."""

    class Provider(BaseProvider):
        """Class for testing method reseed of class BaseProvider."""

        pass

    provider = Provider(seed=1)

    provider.reseed(5)

    assert provider.seed == 5



# Generated at 2022-06-23 21:07:22.657129
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        pass

    tp = TestProvider()
    tp._override_locale('ru')

    assert tp.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:07:25.064075
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert a
    assert a.seed
    assert a.random
    assert a.__str__()


# Generated at 2022-06-23 21:07:28.442636
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider(locale='ru',seed=None)


# Generated at 2022-06-23 21:07:36.531569
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        # pylint: disable=missing-docstring
        def __init__(self, locale, seed=None):
            super().__init__(locale, seed)

        def __str__(self):
            return '{} <{}>'.format(
                self.__class__.__name__, self.get_current_locale())

        class Foo(object):
            # pylint: disable=missing-docstring
            def __init__(self):
                pass

            def fooo(self, locale):
                provider = Provider(locale)
                with provider.override_locale('au'):
                    locale = provider.get_current_locale()
                    return locale

        def foo(self, locale):
            foo_obj = self.Foo()


# Generated at 2022-06-23 21:07:39.436781
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    # BaseProvider is a base class for all providers.
    assert bp.__class__.__name__ == 'BaseProvider'
    # __init__ method should be defined and all the attributes should be initialised.
    assert bp.seed is None
    assert bp.random is random


# Generated at 2022-06-23 21:07:43.863264
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test that the __str__ method returns a string.

    Test that the __str__ method returns a string
    of the form "Class Name <Locale>"
    """
    provider = BaseDataProvider()
    assert isinstance(str(provider), str)
    assert str(provider) == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:07:46.418080
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    BP = BaseDataProvider(locale='ru')
    assert BP.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:07:51.198975
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    fp = BaseProvider(seed=0)
    assert 'BaseProvider' == repr(fp)

    assert 'BaseProvider' == str(fp)
    assert '<BaseProvider>' == fp.__repr__()





if __name__ == '__main__':
    test_BaseProvider___str__()

# Generated at 2022-06-23 21:07:53.595879
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    a = BaseDataProvider()



# Generated at 2022-06-23 21:07:54.748132
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
	pass


# Generated at 2022-06-23 21:07:57.671781
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider('en')
    assert provider.locale == 'en'
    assert hasattr(provider, '_data_dir')


# Generated at 2022-06-23 21:07:59.662865
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert isinstance(bp, BaseProvider)


# Generated at 2022-06-23 21:08:03.016024
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider().__str__() 
    BaseDataProvider(locale = locales.EN).__str__() 
    BaseDataProvider(locale = locales.RU).__str__()

# Generated at 2022-06-23 21:08:05.727824
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Method __str__ of class BaseProvider."""
    bp = BaseProvider('123')
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:08:09.164073
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    r = BaseProvider()
    assert r.seed is None
    assert r.__str__() == "BaseProvider"

    x = r.reseed(seed=1)
    assert r.seed == 1
    assert x is None

    z = r._validate_enum("bar", ["foo", "bar", "baz"])
    assert z == "bar"


# Generated at 2022-06-23 21:08:12.758288
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:08:19.168692
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    # Arrange
    locale = locales.DEFAULT_LOCALE
    provider = BaseDataProvider(locale=locale)
    expected = 'BaseDataProvider <{}>'.format(locale)

    # Act
    actual = provider.__str__()

    # Assert
    assert actual == expected

# Generated at 2022-06-23 21:08:21.339438
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    t = BaseProvider()
    t.reseed(None)
    t.__str__()

# Generated at 2022-06-23 21:08:25.940680
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class TestBaseProvider(BaseProvider):
        def __init__(self, seed):
            super().__init__(seed)

    # Case 1: seed is not None, random is not random
    seed = 20
    test_data_provider = TestBaseProvider(seed)
    assert isinstance(test_data_provider.random, Random)

