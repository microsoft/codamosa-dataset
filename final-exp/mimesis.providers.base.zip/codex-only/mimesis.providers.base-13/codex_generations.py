

# Generated at 2022-06-23 20:58:28.590635
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Testing method override_locale of BaseDataProvider."""
    provider = BaseDataProvider()
    with provider.override_locale(): # noqa
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-23 20:58:29.986870
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider.get_current_locale


# Generated at 2022-06-23 20:58:31.638320
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    a = BaseDataProvider()
    assert a.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:58:33.883702
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider(seed = '1234567')
    assert p.seed == "1234567"
    assert type(p.seed) == str


# Generated at 2022-06-23 20:58:36.936633
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider()
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-23 20:58:40.811104
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = "1234"
    provider = BaseProvider(seed=seed)
    random.seed(seed)
    assert provider.random.random() == random.random()

# Generated at 2022-06-23 20:58:42.536794
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp


# Generated at 2022-06-23 20:58:49.012721
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class EnglishProvider(BaseDataProvider):
        """Test with locale in provider."""
        class Meta:
            name = 'english'
            description = 'Test'
            locales = ['en']
    assert str(EnglishProvider()) == 'EnglishProvider <en>'
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert '<en>' in str(EnglishProvider())
    assert '<en>' in str(BaseDataProvider())


# Generated at 2022-06-23 20:58:54.880760
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider(1)
    provider_temp = BaseProvider(1)
    provider.reseed(2)
    provider_temp.reseed(2)
    assert id(provider) == id(provider_temp)


# Generated at 2022-06-23 20:58:58.499454
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=None, seed=None):
            pass

    p = TestProvider()
    assert p.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 20:59:01.353101
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    assert base.seed == None
    assert base.random == Random()
    base.reseed()
    assert base.seed == None
    assert base.random == Random()


# Generated at 2022-06-23 20:59:02.886455
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data = BaseProvider()
    assert isinstance(data, BaseProvider)


# Generated at 2022-06-23 20:59:06.497420
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class MockDataProvider(BaseDataProvider):
        pass

    data = MockDataProvider()
    data._setup_locale('tr')
    assert data.get_current_locale() == 'tr'



# Generated at 2022-06-23 20:59:09.654616
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider."""
    sbp = BaseProvider(seed=None)
    assert not sbp.seed


# Generated at 2022-06-23 20:59:12.693381
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.DEFAULT_LOCALE
    provider = BaseDataProvider(locale=locale)
    assert provider.get_current_locale() == locale


# Generated at 2022-06-23 20:59:16.210319
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider(locale=locales.EN)
    assert dp.get_current_locale() == locales.EN


if __name__ == '__main__':
    test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-23 20:59:20.063382
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider(seed = '43')
    assert str(obj) == "BaseDataProvider <en>"
    obj = BaseDataProvider(locale = 'ru', seed = '7')
    assert str(obj) == "BaseDataProvider <ru>"
    

# Generated at 2022-06-23 20:59:21.353580
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-23 20:59:28.073225
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    def test_case_0():
        """Test BaseDataProvider with default locale.

        Returns:
            Nothing.

        """
        from mimesis.builtins import Person
        person = Person()
        assert str(person) == 'Person <en>'

    def test_case_1():
        """Test BaseDataProvider with custom locale.

        Returns:
            Nothing.

        """
        from mimesis.builtins import Person
        person = Person(locale='ru')
        assert str(person) == 'Person <ru>'

    test_case_0()
    test_case_1()


# Generated at 2022-06-23 20:59:32.998787
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider()
    print(p)

    p2 = BaseDataProvider(locale=locales.EN)
    print(p2)

    # p3 = BaseDataProvider(locale='Fake')
    # print(p3)

# Generated at 2022-06-23 20:59:35.378008
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    locale = provider.get_current_locale()
    assert locale == 'ru'


# Generated at 2022-06-23 20:59:37.312249
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 20:59:45.009698
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test get_current_locale of class BaseDataProvider with getting current locale as 'ru-ru'
    obj = BaseDataProvider(locale = 'ru-ru')
    result = obj.get_current_locale()
    assert result == 'ru-ru'

    # Test get_current_locale of class BaseDataProvider with getting current locale as 'en'
    obj = BaseDataProvider(locale = 'en')
    result = obj.get_current_locale()
    assert result == 'en'

    # Test get_current_locale of class BaseDataProvider with getting current locale as 'en-us'
    obj = BaseDataProvider(locale = 'en-us')
    result = obj.get_current_locale()
    assert result == 'en-us'

    # Test get_current_locale of class BaseData

# Generated at 2022-06-23 20:59:46.878985
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        def __init__(self, locale=None):
            super().__init__(locale)

    assert Provider().__str__() == 'Provider <en>'

# Generated at 2022-06-23 20:59:49.504956
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider class."""
    print("====== test ======")
    obj = BaseDataProvider()
    assert obj.locale is not None


# Generated at 2022-06-23 20:59:53.903803
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 2000
    provider = BaseProvider(seed=seed)
    assert provider.seed == seed
    provider.reseed()
    assert provider.seed is None
    assert isinstance(provider.random, Random)
    provider.reseed()
    assert provider.seed is None
    assert isinstance(provider.random, Random)


# Generated at 2022-06-23 20:59:56.287103
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(1)
    for i in range(0, 100):
        bp.random.randint(1, 10)
    bp.reseed(1)
    assert bp.random.randint(1, 10) == 10


# Generated at 2022-06-23 20:59:59.443433
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider
    assert b.__name__ == "BaseDataProvider"


# Generated at 2022-06-23 21:00:02.572979
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    class BaseProvider_test(BaseProvider):
        pass
    test_obj = BaseProvider_test()
    assert (isinstance(test_obj.random, Random) and
            test_obj.random is not random)
    assert (isinstance(test_obj.seed, int) or
            isinstance(test_obj.seed, float))
    assert (test_obj.__str__() == "BaseProvider_test")


# Generated at 2022-06-23 21:00:05.973077
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider("en", "23")
    assert BaseDataProvider("en")
    assert BaseDataProvider()
    assert BaseDataProvider("zh")
    assert BaseDataProvider("ar")
    assert BaseDataProvider("cs")


# Generated at 2022-06-23 21:00:13.598234
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        def my_method(self):
            return str(self)
    provider = MyProvider()
    locale = locales.DEFAULT_LOCALE
    assert provider.get_current_locale() == locale
    assert provider.my_method() == 'MyProvider <{}>'.format(locale)
    with provider.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.my_method() == 'MyProvider <ru>'
    assert provider.get_current_locale() == locale
    assert provider.my_method() == 'MyProvider <{}>'.format(locale)

# Generated at 2022-06-23 21:00:19.354883
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    import unittest
    class BaseProviderTestCase(unittest.TestCase):
        def test_init(self):
            test_obj = BaseProvider()
            self.assertEqual(test_obj.__class__.__name__, "BaseProvider")
    unittest.main()
    
    

# Generated at 2022-06-23 21:00:22.844201
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == "BaseDataProvider <en>"
    assert BaseDataProvider(locale="pt").__str__() == "BaseDataProvider <pt>"


# Generated at 2022-06-23 21:00:31.218682
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    print(bdp)
    assert bdp.locale == locales.DEFAULT_LOCALE
    if not hasattr(bdp, '_data'):
        raise Exception('bdp did not create the _data attribute')
    if not hasattr(bdp, '_data_dir'):
        raise Exception('bdp did not create the _data_dir attribute')
    if not hasattr(bdp, '_datafile'):
        raise Exception('bdp did not create the _datafile attribute')
    if not hasattr(bdp, '_setup_locale'):
        raise Exception('bdp did not create the _setup_locale attribute')
    if not hasattr(bdp, '_pull'):
        raise Exception('bdp did not create the _pull attribute')

# Generated at 2022-06-23 21:00:32.955464
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:00:37.234843
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider(seed=1000)
    assert bp.seed == 1000
    bp.reseed(seed=1001)
    assert bp.seed == 1001


# Generated at 2022-06-23 21:00:40.072799
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    from mimesis.providers import Generic

    generic_data = Generic()
    print()
    print(generic_data.get_current_locale())



# Generated at 2022-06-23 21:00:46.514482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person()

    with p.override_locale(locales.EN) as p:
        assert p.full_name(gender=Gender.MALE) == \
               'Arnold Rodriguez'

    with p.override_locale(locales.RU) as p:
        assert p.full_name(gender=Gender.MALE) == \
               'Родриго Кораблев'

    with p.override_locale(locales.ES) as p:
        assert p.full_name(gender=Gender.FEMALE) == \
               'Mónica Sánchez Torres'


# Generated at 2022-06-23 21:00:48.305935
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-23 21:00:57.590549
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    with BaseDataProvider(locale='en', seed=None) as provider:
        result = provider.get_current_locale()
        assert result == 'en'
        result = provider._pull()
        assert result is None
        result = provider._update_dict(initial={}, other={'a': 1, 'b': 2})
        assert result == {'a': 1, 'b': 2}
        with provider.override_locale(locale='en') as p:
            result = p.get_current_locale()
            assert result == 'en'
    assert 'BaseDataProvider' in str(BaseDataProvider(locale='en', seed=None))
    assert 'en' in str(BaseDataProvider(locale='en', seed=None))

# Generated at 2022-06-23 21:01:04.312900
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.miscellaneous import Miscellaneous
    from mimesis.providers.structures import Structures
    from mimesis.providers.business import Business
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text
    from mimesis.providers.file import File
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.number import Number
    from mimesis.providers.scientific import Scientific

# Generated at 2022-06-23 21:01:06.459673
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    r = Random(seed=1)
    random.seed(1)
    assert r.seed == 1
    assert random.seed == 1

# Generated at 2022-06-23 21:01:08.135245
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random == random



# Generated at 2022-06-23 21:01:11.807988
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check whether the output of the method is
    the same as the example or not.
    """
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    with BaseDataProvider().override_locale(locale='ru') as instance:
        assert str(instance) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:01:23.857225
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address
    from mimesis.providers import Person, Business

    addr = Address('ru')
    person = Person('ru')
    business = Business('ru')

    with person.override_locale('en') as p:
        assert p.locale == 'en'
        assert (addr.get_default_locale() != addr.get_current_locale())
        assert (business.get_default_locale() !=
                business.get_current_locale())
        assert (person.get_default_locale() !=
                person.get_current_locale())

    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert (addr.get_default_locale() ==
                addr.get_current_locale())


# Generated at 2022-06-23 21:01:28.247572
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    default_locale = provider.get_current_locale()
    assert default_locale == 'en', 'Fail: default locale'

    provider.locale = 'ru'
    current_locale = provider.get_current_locale()
    assert current_locale == 'ru', 'Fail: current locale'


# Generated at 2022-06-23 21:01:31.066712
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:40.726361
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Car(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            self._datafile = 'car.json'
            super().__init__(locale=locale, seed=seed)
    
        def get_carmodel(self):
            return self._data['carmodel']
        
    # Creating instance of Car class
    car = Car()
    
    # Getting car model in default locale (en)
    print(car.get_carmodel())    # -> Volkswagen Golf
    
    # Getting car model in ru locale
    with car.override_locale(locales.RU) as c:
        print(c.get_carmodel())    # -> Volkswagen Golf
    # Locale of car object

# Generated at 2022-06-23 21:01:43.724453
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    b.locale = 'en'
    assert str(b) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:01:48.908478
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider._override_locale('ru')
    assert str(provider) == 'BaseDataProvider <ru>'
    provider._override_locale('de')
    assert str(provider) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:01:51.643798
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """BaseProvider.reseed()."""
    print(BaseProvider(seed=123).random.seed)
    print(BaseProvider(seed=345).random.seed)

# Generated at 2022-06-23 21:01:53.224914
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert provider.seed == None

# Generated at 2022-06-23 21:01:54.756290
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert(str(provider) == "BaseProvider")


# Generated at 2022-06-23 21:01:56.720572
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider()
    try:
        assert data.locale == "en"
    except:
        print("Test for BaseDataProvider failed!")
    else:
        print("Test for BaseDataProvider passed!")


# Generated at 2022-06-23 21:02:02.096313
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._data = {}
            self._datafile = ''


    p = TestProvider()
    assert p.locale == locales.EN
    with p.override_locale(locales.RU):
        assert p.locale == locales.RU

    assert p.locale == locales.EN

# Generated at 2022-06-23 21:02:04.160723
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1234
    provider = BaseProvider(seed)
    provider.reseed()
    assert provider.seed == seed

# Generated at 2022-06-23 21:02:08.246586
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('1')
    a_dataProvider = BaseProvider()
    print(a_dataProvider)
    # output: 1
    #         BaseProvider

# test unit for function _validate_enum() in class BaseProvider

# Generated at 2022-06-23 21:02:10.468926
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:02:13.839603
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_BaseProvider = BaseProvider(seed=None)
    assert test_BaseProvider.seed == None
    assert test_BaseProvider.random != None


# Generated at 2022-06-23 21:02:17.760457
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    class DataProvider(BaseDataProvider):
        @property
        def datafile(self):
            return 'some_provider.json'

    result = str(DataProvider('en'))
    assert result == 'DataProvider <en>'



# Generated at 2022-06-23 21:02:19.298498
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    t_p = BaseDataProvider(locale='ru')
    assert str(t_p) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:02:30.360882
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.geography import Geography
    from mimesis.providers.science import Science
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.currency import Currency
    from mimesis.providers.code import Code
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.telecommunication import Telecommunication
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-23 21:02:34.231189
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider
    """
    provider = BaseDataProvider(locale='en')

    assert provider.locale == 'en'
    assert provider.get_current_locale() == 'en'
    assert provider.seed is None


# Generated at 2022-06-23 21:02:42.678503
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Init params
    # seed
    provider = BaseDataProvider(seed=89)
    assert provider.seed == 89
    assert provider.random._seed == 89

    provider = BaseDataProvider(seed=None)
    assert provider.seed is None
    assert provider.random._seed is not None

    # locale
    provider = BaseDataProvider(locale='ru')
    assert provider.locale == 'ru'

    provider = BaseDataProvider(locale='ru-ru')
    assert provider.locale == 'ru-ru'

    provider = BaseDataProvider(locale='en-us')
    assert provider.locale == 'en-us'



# Generated at 2022-06-23 21:02:44.559265
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:02:54.370774
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        def get_foo(self):
            return 'foo'
        def get_bar(self):
            return 'bar'

    provider = A('ru-RU')
    with provider.override_locale('en') as p:
        assert p.get_foo() == 'foo'
        assert p.get_bar() == 'bar'

    # ---

    class B(BaseProvider):
        def get_foo(self):
            return 'foo'
        def get_bar(self):
            return 'bar'

    provider = B()
    try:
        with provider.override_locale('en'):
            pass
    except ValueError as e:
        assert str(e) == '«B» has not locale dependent'

# Generated at 2022-06-23 21:02:57.735444
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    assert base.random is random
    random_ = base.random
    base.reseed(12)
    assert base.random is random_
    assert base.random.seed
    assert base.random.seed() == 12
    assert base.seed == 12
    assert str(base) == 'BaseProvider'


# Generated at 2022-06-23 21:03:03.559787
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from src.mimesis.enums import Gender
    from src.mimesis.person import Person
    from src.mimesis.person import test_Person
    p = Person(locale=locales.EN)
    test_Person.test_Person(p)
    assert p.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:03:14.074190
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person, Datetime
    from mimesis.enums import Gender
    from mimesis.internal_utils import to_seed

    def check_seed(seed: Seed, obj: BaseProvider) -> None:
        '''Check that the random generator was initialized with the correct seed
        '''
        assert seed == obj._random.getstate()[1][0]
        assert seed == obj.seed

    seed: Seed = to_seed(1000)
    person = Person(seed=seed)
    assert person.seed == seed
    assert person.random.getstate()[1][0] == seed

    seed: Seed = to_seed(1050)
    person.reseed(seed)
    assert person.seed == seed
    assert person.random.getstate()[1][0] == seed
    person.seed = 1050

# Generated at 2022-06-23 21:03:18.187947
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    b = BaseProvider(seed=42)
    assert b.random.seed(21) == 0.22933044906136505
    assert b.reseed(21) == None
    assert b.random.seed(21) == 0.22933044906136505



# Generated at 2022-06-23 21:03:21.459909
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert provider.random is random
    assert provider.seed is None
    provider.reseed(123)
    assert isinstance(provider.random, Random)
    assert provider.seed == 123



# Generated at 2022-06-23 21:03:28.113585
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider(seed = 'ok')
    print(a.seed)
    print(a.random.seed)
    print(a.random.randint(0, 10))
    a.reseed('not ok')
    print(a.seed)
    print(a.random.randint(0, 10))
    print(a.random.randint(0, 10))
    print(a.random.randint(0, 10))


# Generated at 2022-06-23 21:03:29.703010
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    ob = BaseDataProvider()
    assert ob.__init__ == BaseDataProvider.__init__


# Generated at 2022-06-23 21:03:30.870307
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    result = BaseProvider().reseed()
    assert result == None


# Generated at 2022-06-23 21:03:33.016915
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider._data == {}
    data_dir = str(Path(__file__).parent.parent.joinpath('data').absolute())
    assert provider._data_dir == data_dir

# Generated at 2022-06-23 21:03:33.910273
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider()


# Generated at 2022-06-23 21:03:34.914627
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.EN

# Generated at 2022-06-23 21:03:37.681797
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pd = BaseDataProvider()
    r = pd.get_current_locale()
    assert r == locales.EN


# Generated at 2022-06-23 21:03:39.595273
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """ Unit test for method get_current_locale of class BaseDataProvider. """
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:03:43.515450
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random

    provider.reseed()
    assert provider.seed is not None
    assert provider.random is not random


# Generated at 2022-06-23 21:03:45.678631
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:48.908376
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider(seed=None)
    BaseProvider(seed=123)
    BaseProvider(seed="my_seed")
    BaseProvider(seed=b"my_seed_in_bytes")


# Generated at 2022-06-23 21:03:55.669600
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'
    provider.locale = 'fr'
    assert provider.get_current_locale() == 'fr'
    with provider.override_locale('ru-RU'):
        assert provider.get_current_locale() == 'ru-ru'
    assert provider.get_current_locale() == 'fr'
    provider.locale = ''
    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-23 21:03:57.202046
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
  bdp = BaseDataProvider()
  assert bdp.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:03:58.376063
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()


# Generated at 2022-06-23 21:04:01.905210
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for constructor of class BaseDataProvider
    """
    provider = BaseDataProvider()
    assert provider.locale == 'en'
    provider.reseed(seed=42)
    assert provider.seed == 42
    assert provider.random.seed(42)
    assert provider.random.seed() == 42

# Generated at 2022-06-23 21:04:12.612278
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'code.json'
            self._pull()

        def get_code(self) -> str:
            """Get code.

            :return: Code.
            """
            return self._data['code']

    provider = Provider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_code() == 'ru'

    assert provider.get_current_loc

# Generated at 2022-06-23 21:04:24.704611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Address
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    provider = Address(seed=42)

    with provider.override_locale('en-US') as us:
        assert us.full_address(gender=Gender.MALE) == \
            '6701 Oakwood Lane, Frankmont, VT 90661'

    with provider.override_locale('en-GB') as gb:
        assert gb.full_address(gender=Gender.FEMALE) == \
            '4715 Swallow Road, Bristol, JE14 6QP'


# Generated at 2022-06-23 21:04:30.452884
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialization and configuration provider.
    from mimesis.providers.person import Person

    p = Person('en')
    locale = 'es'
    # I call the context manager
    with p.override_locale(locale):
        assert p.locale == locale
    # The context manager ends and the original locale is restored
    assert p.locale == 'en'

# Generated at 2022-06-23 21:04:36.181389
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    old_seed = bp.seed
    bp.reseed(seed=None)
    new_seed = bp.seed
    assert old_seed != new_seed, \
        'Old seed and new seed must not be equal {} != {}'.format(
            old_seed, new_seed)


# Generated at 2022-06-23 21:04:41.892176
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p1 = BaseProvider()
    assert p1.seed is None
    assert p1.random is random
    p1.reseed(42)
    assert p1.seed == 42
    assert p1.random is not random
    p1.reseed()
    assert p1.seed is None
    assert p1.random is not random


# Generated at 2022-06-23 21:04:49.088825
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):
        def _pull(self):
            return {'foo': 'bar'}

        def get_data(self):
            return self._data

    provider = DataProvider('ru')
    assert provider.get_current_locale() == 'ru'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'foo': 'bar'}

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:04:54.852179
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for BaseDataProvider.override_locale."""
    from mimesis.providers.currency import Currency

    c_usd = Currency(locale='en')
    with c_usd.override_locale('ru') as c_rub:
        assert c_rub.code() == u'RUB'
        assert c_rub.code(end_with_number=True) == u'RUB828'
        assert c_rub.name() == u'Российский рубль'
        assert c_rub.symbol() == u'₽'

# Generated at 2022-06-23 21:05:03.222875
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of BaseDataProvider class."""
    locale1: str = 'ru'
    locale2: str = 'uk'
    with BaseDataProvider(locale1).override_locale(locale1) as provider:
        assert provider.get_current_locale() == locale1
        with provider.override_locale(locale2) as provider:
            assert provider.get_current_locale() == locale2
        assert provider.get_current_locale() == locale1
    assert provider.get_current_locale() == locale1

# Generated at 2022-06-23 21:05:06.645372
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ in class BaseProvider."""
    _bp = BaseProvider()
    _bp.__str__()


# Generated at 2022-06-23 21:05:13.845737
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    p1 = Person(seed=0)
    p2 = Person(seed=0)
    p3 = Person(seed=1)
    p4 = Person(seed=1)
    s1 = p1.full_name()
    s2 = p2.full_name()
    s3 = p3.full_name()
    s4 = p4.full_name()
    assert s1 == s2
    assert s3 == s4
    assert s1 != s3


# Generated at 2022-06-23 21:05:16.679289
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers import Internet
    cls = Internet()
    result = cls.get_current_locale()
    expected = None
    assert result == expected

# Generated at 2022-06-23 21:05:18.537590
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:05:19.834350
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale="en-US")
    return bdp


# Generated at 2022-06-23 21:05:21.105216
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from providers.generic import Generic
    assert Generic().get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:05:28.740373
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider1 = BaseProvider(seed=None)
    assert isinstance(base_provider1, BaseProvider)
    assert base_provider1.seed is None
    assert base_provider1.random is random
    assert str(base_provider1) == 'BaseProvider'
    with pytest.raises(TypeError):
        BaseProvider(seed='')
    base_provider2 = BaseProvider(seed=12345)
    assert isinstance(base_provider2, BaseProvider)
    assert isinstance(base_provider1, Random)
    assert base_provider2.seed == 12345
    assert base_provider2.random is not random
    assert base_provider2.random is not base_provider1.random
    assert str(base_provider2) == 'BaseProvider'

#

# Generated at 2022-06-23 21:05:32.139862
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # check that method of class BaseProvider return string representation
    return isinstance(BaseProvider(BaseDataProvider(locale=locales.EN).__str__()), str)

# Generated at 2022-06-23 21:05:39.015469
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestBDP(BaseDataProvider):
        """Locale dependant data provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            self._datafile = 'test.json'
            super().__init__(locale=locale, seed=seed)

    provider = TestBDP()
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:05:41.262042
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random


# Generated at 2022-06-23 21:05:44.724223
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.address import Address
    # Get locale
    locale_str = str(Address())

    # Check result
    assert locale_str == 'Address <en-US>'


# Generated at 2022-06-23 21:05:54.110081
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    from mimesis.data import BaseDataProvider
    from mimesis.typing import JSON

    class MyDataProvider(BaseDataProvider):

        def __init__(self):
            super().__init__()
            self._data = {}
            self._datafile = ''

    locale = 'ru'

    p = MyDataProvider()
    p.get_current_locale() == locales.DEFAULT_LOCALE

    p._setup_locale(locale)
    p.get_current_locale() == locale

    p._override_locale(locale)
    p.get_current_locale() == locale

    with p.override_locale(locale) as p:
        assert p.get_current_locale() == locale

    p = MyDataProvider(locale=locale)

# Generated at 2022-06-23 21:05:57.904791
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random_object = Random()
    seed = 0
    base = BaseProvider()
    base.random = random_object
    base.reseed(seed)
    result = base.random.seed
    expected = seed
    assert result == expected


# Generated at 2022-06-23 21:05:59.137045
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    return BaseDataProvider().__str__() == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:06:09.895894
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test Provider."""

        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes."""
            super().__init__(seed=seed)
            self._datafile = 'test.json'
            self._pull(self._datafile)

        def __str__(self) -> str:
            """Human-readable representation of locale."""
            return self.__class__.__name__

        def get_true(self) -> bool:
            """Get boolean value True.

            :return: Boolean value True.
            """
            return True

    provider = TestProvider()
    with provider.override_locale():
        assert provider.get_true()


# Generated at 2022-06-23 21:06:13.570673
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    with provider.override_locale(locale='ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:06:22.128075
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp._data == {}
    assert bdp._data_dir == 'F:/python/mimesis/mimesis/data'
    assert bdp._datafile == ''
    assert bdp._setup_locale == 'en'
    assert bdp.locale == 'en'
    assert bdp.random is random
    assert bdp.seed == None
    assert bdp.__str__() == 'BaseDataProvider'
    assert bdp.get_current_locale == 'en'
    assert bdp.get_current_locale() == 'en'
    assert bdp._override_locale == 'ru'

# Generated at 2022-06-23 21:06:22.711256
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    BaseProvider()

# Generated at 2022-06-23 21:06:28.388044
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale = locales.DEFAULT_LOCALE):
            super().__init__(locale = locale)
            self._data = {
                's': 'TEST'
            }
        def get_str(self, key: str = '') -> str:
            if not key:
                key = 's'
            return self._data[key]
    test = Test()
    expected = 'Test'
    result = test.get_str()
    assert result == expected, 'Method «override_locale» failed'

# Generated at 2022-06-23 21:06:29.214894
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    test = BaseDataProvider()
    assert isinstance(test, BaseDataProvider)

# Generated at 2022-06-23 21:06:40.677624
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test with get_current_locale
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person1 = Person()
    assert person1.get_current_locale() == 'en'
    person1.seed(1)
    assert person1.seed == 1
    assert person1.get_current_locale() == 'en'
    assert person1.seed == 1
    assert person1.full_name(gender=Gender.FEMALE) == 'Victoria Arias'
    assert person1.seed == 1
    assert person1.full_name(gender=Gender.FEMALE) == 'Victoria Arias'

    person2 = Person(seed=3)
    assert person2.full_name(gender=Gender.FEMALE) == 'Georgia Tate'
    person2.re

# Generated at 2022-06-23 21:06:43.146677
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:44.646759
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert str(provider) == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:06:47.597114
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale='en')
    assert bdp.locale == 'en'

# Generated at 2022-06-23 21:06:53.338683
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.data import Address, Person
    provider = Address('en')
    assert str(provider) == 'Address <en>'
    provider = Address('ru')
    assert str(provider) == 'Address <ru>'
    provider = Person('en')
    assert str(provider) == 'Person <en>'
    provider = Person('ru')
    assert str(provider) == 'Person <ru>'

# Generated at 2022-06-23 21:06:57.556516
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider(locale='en')
    assert p.get_current_locale() == 'en'


if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:07:04.878872
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    fake = BaseDataProvider()
    assert str(fake) == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)
    assert repr(fake) == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)

    fake = BaseDataProvider('en')
    assert str(fake) == 'BaseDataProvider <en>'
    assert repr(fake) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:14.479948
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Positive testing
    test = BaseProvider()
    assert test.seed is None
    assert test.random is random

    # Negative testing
    from hypothesis import given, strategies as st
    from hypothesis.stateful import rule, invariant, precondition, RuleBasedStateMachine

    class BaseProviderTest(RuleBasedStateMachine):
        def __init__(self):
            super().__init__()

        @invariant()
        def invar(self):
            assert isinstance(self.seed, int)
            assert isinstance(self.random, Random)

        @rule()
        def loop(self):
            if self.seed is None:
                self.seed = self.random.randint()
            self.reseed(self.seed)

    Test = BaseProviderTest.TestCase
    test = Test()
    test.runTest()

# Generated at 2022-06-23 21:07:26.149584
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MyProvider(BaseDataProvider):
        _datafile = "personal.json"

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)
            self._pull()

        def full_name(self) -> str:
            name = self.random.choice(self._data['name'])
            surname = self.random.choice(self._data['surname'])
            return f"{name} {surname}"

    provider = MyProvider()
    with provider.override_locale('en-US') as p:
        assert str(p) == 'MyProvider <en-US>'
        assert p.full_name() == ('Christopher', 'Thomas')


# Generated at 2022-06-23 21:07:33.069423
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider._override_locale."""
    _provider = BaseDataProvider(locale=locales.EN)

    def side_effect(locale):
        _provider._override_locale(locale)
    _provider._override_locale = side_effect

    with _provider.override_locale(locales.RU):
        assert _provider.get_current_locale() == locales.RU

    assert _provider.get_current_locale() == locales.EN

# Generated at 2022-06-23 21:07:35.546489
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    bdp.locale = 'en'
    assert bdp.get_current_locale() == 'en'

# Generated at 2022-06-23 21:07:41.696507
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender
    b = BaseDataProvider(locale='en')
    b.reseed(123)
    assert b._data == {}
    assert b._datafile == ''
    assert b.locale == 'en'
    assert b.seed == 123
    assert b.get_current_locale() == 'en'
    assert (b.get_current_locale() == 'en')
    with b.override_locale('en'):
        assert b.get_current_locale() == 'en'
        assert b._update_dict([], {}) == []
        assert b._update_dict({'a': 1}, {}) == {'a': 1}
        assert b._update_dict({}, {'a': 2}) == {'a': 2}
        assert b._update_dict

# Generated at 2022-06-23 21:07:45.096061
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider(seed=12345)
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:07:49.144857
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    instance = BaseDataProvider('')
    assert str(instance) == "BaseDataProvider <en>"
    instance = BaseDataProvider('en')
    assert str(instance) == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:07:55.262555
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    provider_str = provider.__str__()
    expected_str = 'BaseDataProvider <en>'
    print('Expected string: {}'.format(expected_str))
    print('Obtained string: {}'.format(provider_str))
    assert provider_str == expected_str

test_BaseDataProvider___str__()


# Generated at 2022-06-23 21:07:57.384491
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    from mimesis.builtins import Person
    person = Person(seed=1)

    assert str(person)[-34:] == '<Person <en> <pseudo-random>>'

# Generated at 2022-06-23 21:07:59.295126
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp1 = BaseProvider()
    bp1.reseed(3)
    assert bp1.seed == 3

# Generated at 2022-06-23 21:08:09.032740
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import (
        Address,
        Business,
        Code,
        FileSystem,
        Hardware,
        Internet,
        Person,
        Science,
        Text,
        Number,
        Payment,
        UnitSystem,
        Architecture,
        Automotive,
    )
    from mimesis.builtins import personal as personal_builtin
    from mimesis.builtins import code as code_builtin
    from mimesis.builtins import file_system as file_system_builtin
    from mimesis.builtins import hardware as hardware_builtin
    from mimesis.builtins import internet as internet_builtin
    from mimesis.builtins import science as science_builtin
    from mimesis.builtins import text as text_builtin
    from mimesis.builtins import number

# Generated at 2022-06-23 21:08:12.120655
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""

    baseProvider = BaseProvider()
    baseProvider.reseed(seed=None)


# Generated at 2022-06-23 21:08:14.685224
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    a = BaseDataProvider('en')
    assert a.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:08:15.532697
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider.seed, (float, int))

# Generated at 2022-06-23 21:08:17.663525
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class MockProvider(BaseProvider): pass
    assert str(MockProvider()) == 'MockProvider'


# Generated at 2022-06-23 21:08:20.190547
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=0)
    provider.reseed(seed=1)
    provider.reseed(seed=None)


# Generated at 2022-06-23 21:08:22.123172
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:08:24.064223
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    assert provider is not None
