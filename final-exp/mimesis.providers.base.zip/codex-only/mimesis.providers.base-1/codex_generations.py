

# Generated at 2022-06-23 20:58:28.192968
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Text
    text = Text(seed = 1234)
    assert text.__str__() == 'Text <en>'


# Generated at 2022-06-23 20:58:30.285062
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base_provider = BaseProvider()
    assert base_provider.__str__() == "BaseProvider"



# Generated at 2022-06-23 20:58:39.201547
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    assert data_provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert data_provider.random == random
    data_provider = BaseDataProvider(locale='en')
    assert data_provider.get_current_locale() == locales.EN
    data_provider = BaseDataProvider(locale='de')
    assert data_provider.get_current_locale() == locales.DE
    data_provider = BaseDataProvider(locale=None)
    assert data_provider.get_current_locale() == locales.DEFAULT_LOCALE
    data_provider = BaseDataProvider(seed=123)
    assert data_provider.random != random

# Generated at 2022-06-23 20:58:50.661464
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    import hypothesis as hy
    import hypothesis.strategies as st
    from hypothesis.strategies import composite
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    
    @composite
    def any_BaseProvider(draw):
        return BaseProvider(seed=draw(st.integers(min_value=0, max_value=1)))

    @composite
    def any_BaseDataProvider(draw):
        return BaseDataProvider(locale=draw(st.text()), seed=draw(st.integers(min_value=0, max_value=1)))

    class X(BaseProvider):
        """X."""
        pass

    class Y(BaseDataProvider):
        """Y."""
        pass


# Generated at 2022-06-23 20:58:51.926488
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale='es', seed=12345)


# Generated at 2022-06-23 20:59:02.731210
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider."""

    class Dummy(BaseDataProvider):
        pass

    d = Dummy()
    assert d._data == {}
    assert d.locale == 'en'
    assert d.seed is None
    assert d._datafile == ''
    assert d._data_dir == Path(__file__).parent.parent.joinpath('data')

    d = Dummy(locale='en')
    assert d.locale == 'en'
    assert d.seed is None

    d = Dummy(locale='ru')
    assert d.locale == 'ru'
    assert d.seed is None

    d = Dummy(locale='en_US')
    assert d.locale == 'en_US'
    assert d.seed is None


# Generated at 2022-06-23 20:59:07.477124
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Get the current locale
    class Fruit(BaseDataProvider):
        def __init__(self):
            super().__init__()
        def __str__(self):
            return 'Fruit <{}>'.format(self.locale)

    locale = Fruit().get_current_locale()
    fruit = Fruit(locale='en')
    assert str(fruit) == 'Fruit <en>'
    # Update the current locale
    fruit.locale = 'ru'
    assert str(fruit) == 'Fruit <ru>'


# Generated at 2022-06-23 20:59:09.950464
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert not hasattr(BaseDataProvider, '__init__')

# Generated at 2022-06-23 20:59:14.161921
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_pvd = BaseDataProvider()
    assert data_pvd.__str__() == "BaseDataProvider <en>"
    data_pvd = BaseDataProvider(locale="uk")
    assert data_pvd.__str__() == "BaseDataProvider <uk>"

# Generated at 2022-06-23 20:59:16.806446
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """This is a test for constructor of class BaseDataProvider."""
    en = BaseDataProvider()
    assert(str(en) == "BaseDataProvider <en>")
    print("test_BaseDataProvider ---success")

test_BaseDataProvider()

# Generated at 2022-06-23 20:59:25.630895
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    from mimesis import Person
    from mimesis import Food
    from mimesis import Datetime

    # Create 10 instances of Person with seed '0'
    persons_1 = [Person('en', '0') for i in range(10)]
    # Create 10 persons with seed '0'
    persons_2 = [Person('en', '0') for i in range(10)]
    # Create 10 instances of Food with seed '1'
    foods_1 = [Food('en', '1') for i in range(10)]
    # Create 10 instances of Datetime with default seed
    datetimes_1 = [Datetime() for i in range(10)]
    # Create 10 instances of Datetime with seed '2'
    datetimes_2 = [Datetime('en', '2') for i in range(10)]
    list_of_person_

# Generated at 2022-06-23 20:59:29.354444
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    assert bp.seed == None
    assert bp.random == random
    bp.reseed(seed=100)
    assert bp.seed == 100
    assert bp.random != random
    bp.reseed(seed=None)
    assert bp.seed == None
    assert bp.random == random


# Generated at 2022-06-23 20:59:30.433661
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='ru')
    with provider.override_locale('en'):
        assert isinstance(provider, BaseDataProvider)



# Generated at 2022-06-23 20:59:37.549205
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    from mimesis.enums import Currency

    # prepare data for test
    seed = 'b'*16
    locale = 'en'
    code = Code(seed=seed)

    with code.override_locale(locale):
        assert code.currency() == Currency.USD
        assert code.currency(Currency.RUB) == Currency.RUB

    assert code.currency() == Currency.RUB
    assert code.currency(Currency.USD) == Currency.USD

# Generated at 2022-06-23 20:59:38.717297
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # BaseDataProvider()
    pass



# Generated at 2022-06-23 20:59:41.629633
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test __str__ method of BaseProvider."""
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-23 20:59:45.633180
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def pull(self):
            return self._data

    provider = Provider()

    with provider.override_locale('fr') as p:
        assert p.get_current_locale() == 'fr'
        assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 20:59:47.069056
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale()=='en'


# Generated at 2022-06-23 20:59:51.990051
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.finance import Currency
    from mimesis.enums import Locales

    currency = Currency(seed=123)

    with currency.override_locale(Locales.RU) as ru_currency:
        assert ru_currency.get_current_locale() == Locales.RU

    assert currency.get_current_locale() == Locales.EN

# Generated at 2022-06-23 20:59:59.036941
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    # Initialize provider from superclass.
    base_provider = BaseProvider()
    # Get the name of class.
    base_provider_name = base_provider.__class__.__name__

    # Initialize provider from subclass.
    data_provider = BaseDataProvider(locale='ru')
    # Get the name of class.
    data_provider_name = data_provider.__class__.__name__

    # Check the result.
    assert base_provider.__str__() == base_provider_name
    assert data_provider.__str__() == '{} <{}>'.format(data_provider_name, 'ru')

# Generated at 2022-06-23 21:00:02.991031
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import USAddress as address

    # Test for locale
    current_locale_1 = address.get_current_locale()
    assert current_locale_1 == 'en'
    assert str(address) == 'USAddress <en>'

    # Test for locale with ru
    ru_address = address.override_locale(locale='ru')
    ru_current_locale = ru_address.get_current_locale()
    assert ru_current_locale == 'ru'
    assert str(ru_address) == 'USAddress <ru>'

# Generated at 2022-06-23 21:00:04.445433
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed=666)) == 'BaseProvider'


# Generated at 2022-06-23 21:00:07.713664
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=None)
    p.reseed(seed=None)
    print('%s, %s' % (p, p.seed))

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:00:09.323799
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale=locales.RU)) == 'BaseDataProvider <ru>'



# Generated at 2022-06-23 21:00:12.403376
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""

    class MyProvider(BaseProvider):
        pass

    assert str(MyProvider()) == 'MyProvider'


# Generated at 2022-06-23 21:00:14.860361
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider(locale = 'en')
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:26.755353
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.builtins import Localisation
    from mimesis.data import locales as locales_data

    base_provider = BaseProvider()
    assert base_provider.seed == None
    assert base_provider.random == random

    base_provider.reseed(seed=15)
    assert base_provider.random._seed == 15
    assert base_provider.seed == 15

    localisation = Localisation(seed=15)
    assert localisation.get_locale() == locales_data.DEFAULT_LOCALE
    assert localisation.get_platform() == locales_data.DEFAULT_PLATFORM
    assert localisation.get_platform(platform='iOS') == 'iOS'
    assert localisation.get_platform(platform='Android') == 'Android'

# Generated at 2022-06-23 21:00:30.520100
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.random is random, "Seed should be none"
    assert provider.seed is None, "Seed should be none"
    provider = BaseProvider(seed=123)
    assert provider.random is not random, "Seed should be 123"
    assert provider.seed == 123, "Seed should be 123"


# Generated at 2022-06-23 21:00:32.298399
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    obj = BaseDataProvider('ru')
    assert obj.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:00:35.528334
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b1 = BaseProvider()
    b2 = BaseProvider(seed = 42)

    assert b1.random.seed != b2.random.seed

# Generated at 2022-06-23 21:00:40.051635
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers import Internet
    from mimesis.providers.internet import Internet as InternetBuiltin

    # Test for BaseDataProvider subclass
    assert Internet().get_current_locale() == locales.EN

    # Test for BaseProvider subclass
    assert InternetBuiltin().get_current_locale() == locales.EN

# Generated at 2022-06-23 21:00:44.084612
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider::override_locale."""

    provider = BaseDataProvider()

    provider.locale = 'ru'

    with provider.override_locale('en'):
        assert provider.locale == 'en'

    assert provider.locale == 'ru'

# Generated at 2022-06-23 21:00:55.072434
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #Test_1
    dp = BaseDataProvider()
    if dp._data_dir == Path(__file__).parent.parent.joinpath('data'):
        test1 = True
    else:
        test1 = False
    assert test1 == True, 'Test_1 is wrong'

    #Test_2
    dp = BaseDataProvider(locale='uk')
    if dp.get_current_locale() == 'uk':
        test2 = True
    else:
        test2 = False
    assert test2 == True, 'Test_2 is wrong'

    #Test_3
    dp = BaseDataProvider(seed=1)
    if dp.seed == 1:
        test3 = True
    else:
        test3 = False
    assert test3 == True, 'Test_3 is wrong'

# Generated at 2022-06-23 21:00:59.838813
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """When we try to generate a provider 
    we should get provider class object and 
    the argument of constructor should be copied to provider
    """
    import mimesis.builtins
    test_seed = 100
    provider = mimesis.builtins.Person(seed=test_seed)
    assert provider.__class__ == mimesis.builtins.Person
    assert provider.seed == test_seed


# Generated at 2022-06-23 21:01:08.396474
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data.builtins import Builtins
    from mimesis.data import Phone, Text
    from mimesis.data import Address, Currency, Personal

    # Buildins
    b = Builtins()
    b.get_current_locale() == locales.EN

    # Other providers
    for obj in (Phone(), Text(), Address(), Currency(), Personal()):
        obj.get_current_locale() == locales.EN

    b_ru = Builtins(locale='ru')
    b_ru.get_current_locale() == 'ru'

    with b.override_locale('ru'):
        b.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:01:11.165087
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for BaseDataProvider class."""
    dp = BaseDataProvider()
    assert dp.locale == 'en'
    assert dp.seed is None
    assert dp._datafile == ''

# Generated at 2022-06-23 21:01:15.234448
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    result = provider.get_current_locale()
    assert result == 'en'


# Generated at 2022-06-23 21:01:17.297728
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():  
    x = BaseProvider()
    assert x.__str__() == 'BaseProvider'



# Generated at 2022-06-23 21:01:19.517077
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 21:01:25.507959
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import Numeric, DateTime
    bdp = BaseDataProvider(locale='en-US')
    assert bdp.get_current_locale() == 'en-us'
    assert Numeric().get_current_locale() == 'en'
    assert DateTime().get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:33.999483
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Code

    try:
        from lru import LRU
    except ImportError:
        from functools import lru_cache as LRU
    assert hasattr(LRU, 'cache_info')

    _ = Code()

    # Test with correct value

    with _.override_locale(locale='ru'):
        assert _.get_current_locale() == 'ru'

    with _.override_locale(locale='en'):
        assert _.get_current_locale() == 'en'

    # Test with wrong value

    test_exception = False

# Generated at 2022-06-23 21:01:35.721188
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:01:37.069277
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert isinstance(BaseDataProvider().get_current_locale(), str)


# Generated at 2022-06-23 21:01:38.465203
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.DEFAULT_LOCALE
    p = BaseDataProvider()
    assert p.get_current_locale() == locale


# Generated at 2022-06-23 21:01:39.729619
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed == None



# Generated at 2022-06-23 21:01:42.981149
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 'test_BaseProvider_reseed'
    provider = BaseProvider(seed = seed)
    assert seed == provider.seed


# Generated at 2022-06-23 21:01:44.885903
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider)



# Generated at 2022-06-23 21:01:46.893691
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    #TODO
    print("Unit test for class BaseProvider")
    print("TODO")


# Generated at 2022-06-23 21:01:48.499184
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:01:55.427581
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        def __init__(self):
            super().__init__()
            self.locale = 'en'
            self._data = {'en': {'key': 'value'}}

        def _pull(self):
            pass

    a = A()
    assert a.get_current_locale() == 'en'

    with a.override_locale(locale='ru'):
        assert a.get_current_locale() == 'ru'

    assert a.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:02.344964
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # test for the constructor
    assert BaseDataProvider.__init__.__doc__

    assert BaseDataProvider().locale == 'en'
    assert BaseDataProvider().seed is None
    assert BaseDataProvider('en').locale == 'en'
    assert BaseDataProvider('en').seed is None
    assert BaseDataProvider('uk').locale == 'uk'
    assert BaseDataProvider('uk').seed is None
    assert BaseDataProvider('en', 1234).locale == 'en'
    assert BaseDataProvider('en', 1234).seed == 1234
    assert BaseDataProvider('uk', 1234).locale == 'uk'
    assert BaseDataProvider('uk', 1234).seed == 1234



# Generated at 2022-06-23 21:02:10.697211
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender
    from mimesis.providers import PaymentSystem
    from mimesis.typing import JSON
    from typing import Dict, Any
    from pathlib import Path
    import json

    test_file: Path = Path(__file__).parent.joinpath('test_data.json')
    with open(test_file, 'r', encoding='utf8') as f:
        test_data: JSON = json.load(f)

    test_provider: BaseDataProvider = BaseDataProvider(
        locale='ru_RU',
        seed=2
    )

    test_provider._pull = lambda: None
    test_provider._override_locale(locale='ru_RU')


# Generated at 2022-06-23 21:02:13.004400
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert bdp.__str__() == "BaseDataProvider <en>"
    bdp.locale = locales.RU
    assert bdp.__str__() == "BaseDataProvider <ru>"

# Generated at 2022-06-23 21:02:15.258612
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-23 21:02:18.204864
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    print(a)
    start_time=str(a.seed)
    #1459131795.546714

# Generated at 2022-06-23 21:02:20.604220
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.seed is None
    assert provider.random is random
    assert provider.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:02:25.023580
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    locale = 'en'
    bdp._setup_locale(locale=locale)
    assert bdp.get_current_locale() == locale
    locale = 'ru'
    bdp._setup_locale(locale=locale)
    assert bdp.get_current_locale() == locale


# Generated at 2022-06-23 21:02:35.458530
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import unittest

    class TestClass:
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            self.locale = locale

    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            self.locale = locale
            super().__init__()

    class BaseDataProviderTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.test_obj_without_locale = TestClass()
            self.test_obj_with_locale = TestClass('uk')
            self.test_not_BaseDataProvider_obj_with_locale = TestBaseDataProvider('ru')

        def test_locale_is_none(self):
            self.assertEqual

# Generated at 2022-06-23 21:02:37.319413
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:02:40.337520
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test mimesis.providers.base.BaseProvider.__str__.
    """
    p = BaseProvider()
    assert p.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:02:43.550484
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #
    assert BaseDataProvider().locale == 'en'
    assert BaseDataProvider()._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert BaseDataProvider()._data == {}


# Generated at 2022-06-23 21:02:46.905320
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print('\nUnit test for method __str__ of class BaseProvider:')
    locale = 'en'
    with BaseProvider(locale=locale) as provider:
        result = str(provale)
    print(result)

# Generated at 2022-06-23 21:02:48.647011
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed=42)) == 'BaseProvider'



# Generated at 2022-06-23 21:02:57.856352
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo

    a1 = Address(seed=1)
    a2 = Address(seed=1)
    assert a1.address == a2.address
    a2.reseed(2)
    assert a1.address != a2.address
    a2.reseed(None)
    a1 = Datetime(seed=1)
    a2 = Datetime(seed=1)
    assert a1.date() == a2.date()
    a2.reseed(2)
    assert a1.date() != a2.date()
    a2.reseed(None)
    a1 = Geo(seed=1)

# Generated at 2022-06-23 21:02:59.053718
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
	pass


# Generated at 2022-06-23 21:03:06.959337
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p1 = BaseProvider(seed='test')
    p2 = BaseProvider(seed='test')

    assert p1.random.random() == p2.random.random()

    # Unit test for method reseed of class BaseProvider
    def test_BaseProvider_reseed():
        p1 = BaseProvider(seed='test')
        p2 = BaseProvider(seed='test2')

        assert p1.random.random() != p2.random.random()

print(test_BaseProvider_reseed())

# Generated at 2022-06-23 21:03:08.746987
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert ((BaseProvider().seed != None) or (BaseProvider(seed=123).seed == 123))


# Generated at 2022-06-23 21:03:10.620891
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider(locale="en")
    assert str(p) == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:03:12.535089
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
  b=BaseDataProvider()
  print(b.get_current_locale())


# Generated at 2022-06-23 21:03:13.913684
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__(): assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:18.974048
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    test_range = range(1,11)
    provider = BaseProvider(seed=42)
    all_reseed = []
    for i in test_range:
        if i%2 == 0:
            provider.reseed(i)
        all_reseed.append(provider.seed)
    assert all_reseed == [42, 42, 2, 2, 4, 4, 6, 6, 8, 8]



# Generated at 2022-06-23 21:03:20.917857
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider(seed = 0)
    assert base.seed == 0
    assert base.random == random


# Generated at 2022-06-23 21:03:23.494555
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed=10)
    assert bp.seed == 10


# Generated at 2022-06-23 21:03:25.828034
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    test = BaseProvider()
    test.reseed(1)
    assert test.seed == 1
    assert test.random is not None


# Generated at 2022-06-23 21:03:26.440525
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pass

# Generated at 2022-06-23 21:03:28.765123
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class DummyDataProvider(BaseDataProvider):
        pass

    assert DummyDataProvider().get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:03:36.112816
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import EnumProvider
    from mimesis.enums import Gender

    with EnumProvider(seed=2) as enum:
        with enum.override_locale(locales.RU):
            assert enum.get_current_locale() == locales.RU
            assert enum.gender(Gender.MALE) == 'Мужской'

        with enum.override_locale(locales.UA):
            assert enum.get_current_locale() == locales.UA
            assert enum.gender(Gender.MALE) == 'Чоловіча'

        assert enum.get_current_locale() == locales.EN
        assert enum.gender(Gender.MALE) == 'Male'

# Generated at 2022-06-23 21:03:39.031491
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=1)
    provider.reseed(seed=None)
    provider.__str__()
    #print(provider)


# Generated at 2022-06-23 21:03:40.887365
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='en')
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-23 21:03:48.765810
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.data import EN, RU
    from mimesis.providers.personal import Person
    p = Person()
    assert str(p) == 'Person <{}>'.format(EN)
    assert str(p.override_locale(RU)) == 'Person <{}>'.format(RU)
    from mimesis.providers.builtins import Internet
    i = Internet()
    assert str(i) == 'Internet'
    assert str(i.override_locale(RU)) == 'Internet'
test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:03:50.151197
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:03:56.194194
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Person(BaseDataProvider):
        _datafile = 'person.json'

        @property
        def name(self) -> str:
            return self.random.choice(self._data['name'])

    with Person().override_locale(locales.ES) as person:
        assert person.name in person._data['name'] == 'María'

# Generated at 2022-06-23 21:04:00.345170
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed(): # noqa: D103
    assert BaseProvider().random.get_random_int(1, 2) == BaseProvider(
        seed=None).random.get_random_int(1, 2)



# Generated at 2022-06-23 21:04:08.305207
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Test 1
    p = BaseDataProvider()
    assert str(p) == 'BaseDataProvider <en>'

    # Test 2
    p = BaseDataProvider(locale=locales.EN)
    assert str(p) == 'BaseDataProvider <en>'

    # Test 3
    p = BaseDataProvider(locale=locales.RU)
    assert str(p) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:04:10.684300
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider is not None
    assert provider.locale is None
    assert provider.seed == None
    assert provider.random is not None


# Generated at 2022-06-23 21:04:13.799764
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for get_current_locale.
    """
    assert BaseDataProvider().get_current_locale() == 'en'



# Generated at 2022-06-23 21:04:18.235825
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Person
    dp = BaseDataProvider()
    assert dp.__str__() == 'BaseDataProvider <en>'

    person = Person()
    assert person.__str__() == 'Person <en>'



# Generated at 2022-06-23 21:04:20.098879
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base_provider = BaseProvider()
    assert str(base_provider) == 'BaseProvider'


# Generated at 2022-06-23 21:04:25.424482
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert bdp.__str__() == 'BaseDataProvider <en>'
    try:
        bdp.override_locale('ru')
    except Exception:
        pass
    else:
        assert bdp.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:04:28.237236
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    locale = random.choice(locales.SUPPORTED_LOCALES)
    bdp = BaseDataProvider(locale=locale)
    assert bdp.locale == locale

# Generated at 2022-06-23 21:04:39.999175
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Address
    from mimesis.data import providers
    from mimesis.schema import Field, Schema
    from mimesis.data.providers.address import Address as BaseAddress
    from mimesis.enums import Gender
    assert Address().__str__() == 'Address <en>'
    assert BaseAddress().__str__() == 'Address'
    assert Address(locale='ru').__str__() == 'Address <ru>'
    assert Schema(None).__str__() == 'Schema'
    # test with new field
    field = Field('en', Gender.MALE, 'name')
    assert str(field) == "Field(Gender.MALE, 'name')"
    assert str(providers.Datetime(locale='ru')) == 'Datetime <ru>'

# Generated at 2022-06-23 21:04:42.822343
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider1 = BaseDataProvider(locale='ru')
    provider2 = BaseDataProvider(locale='ru', seed=12345)

test_BaseDataProvider()


# Generated at 2022-06-23 21:04:47.442582
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__ of class BaseDataProvider.

    Test checks that BaseDataProvider class has attribute locale (by default).
    """
    default_provider = BaseDataProvider()
    assert hasattr(default_provider, 'locale')
    assert str(default_provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:04:50.541497
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider(locale='en-US')
    assert b.locale == 'en-us'


# Generated at 2022-06-23 21:04:51.809813
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    pass


# Generated at 2022-06-23 21:04:53.192115
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'

# Generated at 2022-06-23 21:04:54.622376
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    actual_result = BaseProvider().__str__()
    assert isinstance(actual_result, str)
    assert actual_result == 'BaseProvider'


# Generated at 2022-06-23 21:05:00.949979
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import ProgrammingLanguage

    pl = ProgrammingLanguage()
    assert str(pl) == 'ProgrammingLanguage <en>'
    with pl.override_locale('en'):
        assert str(pl) == 'ProgrammingLanguage <en>'
    with pl.override_locale('ru'):
        assert str(pl) == 'ProgrammingLanguage <ru>'

# Generated at 2022-06-23 21:05:03.804987
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    rnd = random.Random()
    rnd.seed(None)
    provider = BaseDataProvider(locale=locales.EN, seed=None)
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:05:15.392404
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # _setup_locale()
    # This method is called by the construct of BaseProvider,
    # so no unit test is required.

    # reseed()
    # This method is called by the construct of BaseProvider,
    # so no unit test is required.

    # _validate_enum()
    class E(object):
        def __init__(self, v):
            self.value = v
        def __eq__(self, other):
            return isinstance(other, self.__class__) and \
                self.value == other.value
        def __ne__(self, other):
            return not self.__eq__(other)
        def __lt__(self, other):
            return self.value < other.value
        def __le__(self, other):
            return self.value < other.value or self

# Generated at 2022-06-23 21:05:17.724927
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    result = provider.get_current_locale()
    assert result == locales.EN


# Generated at 2022-06-23 21:05:20.196094
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='en')
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:23.812321
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    global BaseProvider
    bp = BaseProvider()
    assert bp.seed is None
    assert isinstance(bp.random, Random)
    assert isinstance(bp.random, Random)
    assert not BaseProvider.reseed.__doc__ is None


# Generated at 2022-06-23 21:05:25.264766
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    test_prov = BaseProvider()
    assert str(test_prov) == 'BaseProvider'


# Generated at 2022-06-23 21:05:29.652576
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'
    bdp.locale = 'ru'
    assert str(bdp) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:05:32.492830
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """BaseDataProvider test."""
    data = BaseDataProvider()
    assert data.locale == 'en'
    assert data.seed is None

# Generated at 2022-06-23 21:05:36.769842
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    provider = BaseDataProvider('ru')
    assert provider.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:05:41.763909
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    s = 'BaseDataProvider <{}>'.format(locales.EN)
    assert str(provider) == s
    provider = BaseDataProvider(locale='ru')
    s = 'BaseDataProvider <{}>'.format('ru')
    assert str(provider) == s


# Generated at 2022-06-23 21:05:43.370775
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
	assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:45.375386
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    br = BaseProvider()
    assert br.seed is None
    br.reseed(123)
    assert br.seed == 123


# Generated at 2022-06-23 21:05:47.689153
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)

# Generated at 2022-06-23 21:05:53.297789
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``BaseDataProvider.override_locale``."""
    provider = BaseDataProvider()

    with provider.override_locale(locale='ru'):
        assert provider.locale == 'ru'

        with provider.override_locale(locale='ko'):
            assert provider.locale == 'ko'
        assert provider.locale == 'ru'
    assert provider.locale != provider.get_current_locale()


# Generated at 2022-06-23 21:05:56.844868
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    a = BaseProvider()
    b = BaseProvider(seed=42)
    a.reseed(1234)
    assert a.seed != b.seed


# Generated at 2022-06-23 21:06:00.785445
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(1)
    if bp.random == random:
        raise AssertionError()
    elif bp.seed != 1:
        raise AssertionError()
    else:
        bp._validate_enum(None, locales.EN)


# Generated at 2022-06-23 21:06:03.169223
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method ``get_current_locale`` of class ``BaseDataProvider``."""
    BDP = BaseDataProvider()
    assert BDP.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:04.893453
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider."""
    provider = BaseDataProvider()

    assert isinstance(provider, BaseDataProvider)
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 21:06:11.024778
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with BaseDataProvider(locale='en', seed=123) as p:
        assert p.locale == 'en'
        assert p.seed == 123
        assert p.random
        assert isinstance(p.random, Random)
        assert p.random.get_seed() == 123
        assert p.random.get_seed() == 123


# Generated at 2022-06-23 21:06:12.242530
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # There is not any error
    BaseProvider().__str__()



# Generated at 2022-06-23 21:06:13.187262
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale='en', seed=None)

# Generated at 2022-06-23 21:06:15.156979
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'
    assert str(b) == 'BaseProvider'

# Generated at 2022-06-23 21:06:20.799584
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test the BaseProvider's __str__ method."""
    from mimesis.builtins import Address, Person

    provider = BaseProvider(seed=123)
    assert str(provider) == 'BaseProvider'

    provider = Address(seed=123)
    assert str(provider) == 'Address'

    provider = Person(seed=123)
    assert str(provider) == 'Person'



# Generated at 2022-06-23 21:06:25.175100
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def foo(self):
            return self._data

    provider = TestDataProvider()
    data = provider.foo()
    assert str(provider) == 'TestDataProvider <en>'
    assert data


# Generated at 2022-06-23 21:06:28.018858
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Postcode

    with Postcode().override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:06:29.061811
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test Docstring"""
    assert BaseProvider().__class__.__name__ == "BaseProvider"

# Generated at 2022-06-23 21:06:30.383880
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    str(provider)

# Generated at 2022-06-23 21:06:32.061137
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    x = BaseProvider()
    assert str(x) == 'BaseProvider'

# Generated at 2022-06-23 21:06:34.533659
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    my_provider: BaseDataProvider = BaseDataProvider()
    assert str(my_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:35.849770
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    _ = BaseProvider(seed=None)



# Generated at 2022-06-23 21:06:41.989126
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    assert dp.__str__() == "BaseDataProvider <en>"

    dp.locale = locales.EN
    assert dp.__str__() == "BaseDataProvider <en>"

    dp.locale = locales.RU
    assert dp.__str__() == "BaseDataProvider <ru>"

# Generated at 2022-06-23 21:06:43.617534
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 21:06:45.367579
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    provider.reseed(seed=1)
    assert provider.seed == 1

# Generated at 2022-06-23 21:06:47.794207
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    _str = str(BaseProvider())
    assert _str == 'BaseProvider'


# Generated at 2022-06-23 21:06:50.969078
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    my_provider = BaseProvider()
    assert my_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:06:52.238976
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'



# Generated at 2022-06-23 21:06:54.663854
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestProvider(BaseDataProvider):
        pass

    assert str(TestProvider()) == 'TestProvider <en>'

# Generated at 2022-06-23 21:06:58.019150
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    b_data_provider = BaseDataProvider()
    assert b_data_provider.get_current_locale() == b_data_provider.locale



# Generated at 2022-06-23 21:07:03.306728
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    r = Random()
    dp = BaseProvider()
    assert r.randint(1, 100) == r.randint(1, 100)
    dp = BaseProvider(seed=10)
    dp.reseed(10)
    assert r.randint(1, 100) == r.randint(1, 100)

# Generated at 2022-06-23 21:07:05.645579
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_provider = BaseDataProvider(locale='ru')
    assert test_provider.locale == 'ru' and test_provider.seed == None


# Generated at 2022-06-23 21:07:06.493837
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()


# Generated at 2022-06-23 21:07:12.198669
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test overriding locale."""
    from mimesis.builtins import Code

    field = 'base36'
    code = Code(seed=1)
    code_ru = Code(locale='ru')

    assert code.field(field) == code_ru.field(field)

    with code.override_locale('ru'):
        assert code.field(field) == code_ru.field(field)

    assert code.field(field) == code_ru.field(field)

# Generated at 2022-06-23 21:07:13.855444
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert ('bp' in str(bp))


# Generated at 2022-06-23 21:07:17.388072
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    from mimesis.enums import Gender
    p1 = Person('en')
    p2 = Person('en')
    name1 = p1.name(gender=Gender.MALE)
    p2.reseed()
    name2 = p2.name(gender=Gender.MALE)
    assert name1==name2

# Generated at 2022-06-23 21:07:21.995218
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass

    p = Provider()
    assert str(p) == 'Provider <en>'

    p.locale = 'ru'
    assert str(p) == 'Provider <ru>'


if __name__ == '__main__':
    test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:07:30.770076
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method of class BaseProvider"""
    def test_new_token():
        with open('test_config.json', 'r') as f:
            return json.load(f)['test_token']

    def test_save_new_token(new_token):
        with open('test_config.json', 'r') as f:
            config = json.load(f)
            config['test_token'] = new_token
        
        with open('test_config.json', 'w') as f:
            config = json.dump(config, f)

    def generate_random_data(seed: Seed = None) -> Seed:
        nonlocal new_token
        new_token = Random(seed).token()
        return new_token

    origin_token = test_new_token()

# Generated at 2022-06-23 21:07:34.767222
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == provider.random.get_seed()
    assert provider.random is random
    assert provider.random.get_seed() != Random().get_seed()


# Generated at 2022-06-23 21:07:39.181876
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    expected = locales.EN
    assert BaseDataProvider().get_current_locale() == expected  # noqa: WPS110
    assert BaseDataProvider(seed=1).get_current_locale() == expected  # noqa: WPS110



# Generated at 2022-06-23 21:07:44.028597
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')

    with provider.override_locale(locale='en') as p:
        assert p.get_current_locale() == 'en'
        assert str(p) == 'BaseDataProvider <en>'

    with provider.override_locale(locale='ru') as p:
        assert p.get_current_locale() == 'ru'
        assert str(p) == 'BaseDataProvider <ru>'



# Generated at 2022-06-23 21:07:45.593392
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider()
    data_provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:50.227766
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    from mimesis.builtins import Person
    provider = Person()
    provider.reseed()

    # seed is not None
    assert provider.seed is not None
    assert provider.random is not random

    # seed is None
    provider.reseed(None)
    assert provider.seed is None
    assert provider.random is random


# Generated at 2022-06-23 21:07:52.616213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider_override_locale.

    Unit test for method override_locale of class BaseDataProvider.
    """
    with BaseDataProvider(seed=123).override_locale('zh') as provider:
        assert provider.locale == 'zh'

# Generated at 2022-06-23 21:08:01.704855
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import UserAgent

    ua_ru = UserAgent(locale='ru')

    with ua_ru.override_locale('ru') as ua:
        ua_ru.browser() == ua.browser()
        ua_ru.browser() == 'Arora'

        ua_ru.operating_system() == ua.operating_system()
        ua_ru.operating_system() == 'OS'

    try:
        ua_ru.override_locale('ru')
    except ValueError as e:
        e.args[0] == "«UserAgent» has not locale dependent"


# Generated at 2022-06-23 21:08:03.901097
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Tests for constructor of the class BaseProvider."""
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 21:08:05.592836
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale is 'en'

# Generated at 2022-06-23 21:08:07.545986
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import Person
    assert Person._datafile == "person.json"
    assert Person.locale == "en"



# Generated at 2022-06-23 21:08:14.466638
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class mock_class(BaseDataProvider):
        def __init__(self):
            pass

    mock_obj = mock_class()
    mock_obj.locale = 'ru'

    assert mock_obj.get_current_locale() == 'ru'
    assert str(mock_obj) == 'mock_class <ru>'

# Generated at 2022-06-23 21:08:21.486131
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # BaseProvider
    bp = BaseProvider(seed=0)
    assert bp.seed == 0
    assert bp.random._seed == 0
    assert isinstance(bp.random, Random)
    bp = BaseProvider()
    assert isinstance(bp.random, Random)
    assert bp.seed is None
    bp.reseed(seed=0)
    assert bp.random._seed == 0
    assert bp.seed == 0


# Generated at 2022-06-23 21:08:24.139757
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider('en')
    provider.reseed()
    assert provider.random.seed == 'en'

