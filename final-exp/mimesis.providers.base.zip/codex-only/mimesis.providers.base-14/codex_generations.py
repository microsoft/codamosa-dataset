

# Generated at 2022-06-23 20:58:23.930224
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(12345678)
    assert provider.seed == 12345678
    provider.reseed(None)
    def f():
        assert provider.seed is not None
    provider.reseed()
    f()



# Generated at 2022-06-23 20:58:29.770057
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test_BaseProvider(BaseProvider):
        pass

    try:
        provider = Test_BaseProvider()
        assert str(provider) == 'Test_BaseProvider'
    except AssertionError as e:
        print('AssertionError:', e)
        raise AssertionError


# Generated at 2022-06-23 20:58:33.114224
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    _BaseDataProvider = BaseDataProvider(seed=12345)

    assert _BaseDataProvider._data == {}
    assert _BaseDataProvider._datafile == ''
    assert _BaseDataProvider.locale == 'en'
    assert _BaseDataProvider.seed == 12345
    assert isinstance(_BaseDataProvider, BaseDataProvider)



# Generated at 2022-06-23 20:58:41.768884
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    def test_default_locale(provider):
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    def test_lru_cache(provider):
        def test_cache_clear(provider):
            provider._pull()
            provider._pull.cache_clear()
            assert provider._pull.cache_info().currsize == 0

        def test_cache(provider):
            provider._pull()
            provider._pull()
            assert provider._pull.cache_info().currsize > 0

        test_cache_clear(provider)
        test_cache(provider)

    def test_override(provider):
        def test_override_origin(provider):
            with provider.override_locale(locales.RU):
                assert provider.get_current_loc

# Generated at 2022-06-23 20:58:42.387777
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    pass



# Generated at 2022-06-23 20:58:44.532961
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1234567890
    provider = BaseProvider(seed)
    assert provider.seed == seed
    provider.reseed(seed)
    assert provider.seed == seed

# Generated at 2022-06-23 20:58:47.416476
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.EN
    seed = None
    test = BaseDataProvider(locale, seed)
    assert locale == test.get_current_locale()

# Generated at 2022-06-23 20:58:53.293640
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Test provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.gender = self._pull()


    provider = Provider()
    with provider.override_locale('en'):
        assert provider.gender
    with provider.override_locale('ru'):
        assert provider.gender

# Generated at 2022-06-23 20:59:04.189520
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE, 'test_BaseDataProvider_get_current_locale_1'
    provider = BaseDataProvider('ru')
    assert provider.get_current_locale() == 'ru', 'test_BaseDataProvider_get_current_locale_2'
    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en', 'test_BaseDataProvider_get_current_locale_3'
    provider = BaseDataProvider('ru_ru')
    assert provider.get_current_locale() == 'ru_ru', 'test_BaseDataProvider_get_current_locale_4'
    provider = BaseDataProvider('en_en')
    assert provider.get_current_locale()

# Generated at 2022-06-23 20:59:07.097039
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    russian = BaseDataProvider(locale='ru')
    assert russian.get_current_locale() == locales.RU

    with russian.override_locale(locale=locales.RU_RU):
        assert russian.get_current_locale() == locales.RU_RU

    assert russian.get_current_locale() == locales.RU

# Generated at 2022-06-23 20:59:15.008136
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.builtins import random
    from mimesis.enums import SeedType

    provider = BaseProvider(SeedType.NONE)
    assert provider.seed == None
    assert provider.random == random()
    assert str(SeedType.NONE) == 'none'

    provider = BaseProvider()
    assert provider.seed != None
    assert provider.random != random()
    assert provider.seed == provider.random.get_seed()


# Generated at 2022-06-23 20:59:24.721792
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert not issubclass(BaseDataProvider, BaseProvider)
    assert BaseDataProvider.__init__.__doc__
    assert BaseDataProvider.__init__.__annotations__
    assert BaseDataProvider()._pull.cache_clear.__doc__
    assert BaseDataProvider()._pull.__annotations__
    assert BaseDataProvider()._pull.__doc__
    assert BaseDataProvider()._setup_locale.__annotations__
    assert BaseDataProvider()._setup_locale.__doc__
    assert BaseDataProvider().get_current_locale.__annotations__
    assert BaseDataProvider().get_current_locale.__doc__
    assert BaseDataProvider()._override_locale.__annotations__
    assert BaseDataProvider()._override_locale.__doc__
    assert BaseDataProvider()._update

# Generated at 2022-06-23 20:59:26.288578
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert 'BaseProvider' == str(BaseProvider())
    assert 'BaseDataProvider' == str(BaseDataProvider())

# Generated at 2022-06-23 20:59:29.015533
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    result = BaseDataProvider(locale='de').__str__()
    assert result == 'BaseDataProvider <de>'

# Generated at 2022-06-23 20:59:30.242654
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider.reseed."""
    base_provider = BaseProvider()
    base_provider.reseed(5)

    assert base_provider.seed == 5



# Generated at 2022-06-23 20:59:32.187635
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:33.705165
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None


# Generated at 2022-06-23 20:59:40.158075
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        def get_test(self):
            """Return test."""
            return self._data

    test_provider = TestProvider()
    test_provider._pull('test.json')
    assert test_provider.get_test()
    with test_provider.override_locale('en') as provider:
        assert provider.get_test()
    assert test_provider.get_test()

# Generated at 2022-06-23 20:59:43.021704
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestClass(BaseDataProvider):
        pass
    assert str(TestClass(locale='zh')) == 'TestClass <zh>'

# Generated at 2022-06-23 20:59:44.356320
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert str(p) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:46.402359
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    baseclass = BaseProvider()
    result = baseclass.__str__()
    assert result == 'BaseProvider'


# Generated at 2022-06-23 20:59:49.407782
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider('en')
    assert f'{test_provider}' == 'BaseDataProvider <en>', \
        'Method __str__ of class BaseDataProvider is wrong!'

# Generated at 2022-06-23 20:59:50.825144
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:52.908042
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.seed = 'Hello'
    provider.reseed('World')
    assert provider.seed == 'World'

# Generated at 2022-06-23 21:00:00.341269
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SimpleProvider(BaseDataProvider):
        """Simple provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = '_'.join((str(self), 'data.json'))

        def foo(self) -> str:
            """Simple method, that return random item from list."""
            return self.random.choice(self._data.get('foo'))

    provider = SimpleProvider(locale=locales.EN)

# Generated at 2022-06-23 21:00:04.201934
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test the method get_current_locale of class BaseDataProvider."""
    bp = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    assert bp.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:00:07.190146
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider('ru')
    assert provider.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:00:09.398550
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test to check method of reseed."""
    bp = BaseProvider(seed=123)
    if bp.seed != 123:
        raise AttributeError('seed not set')
    if bp.random.seed != 123:
        raise AttributeError('random.seed not set')


# Generated at 2022-06-23 21:00:14.713007
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers.base import BaseProvider
    from mimesis.typing import Seed
    from mimesis.random import get_random_item, random

    values = [0, 1]
    seed: Seed = 0
    provider = BaseProvider(seed=seed)
    new_seed: Seed = 1
    expected = get_random_item(values, random)
    provider.reseed(new_seed)
    result = provider.random.choice(values)
    assert result == expected



# Generated at 2022-06-23 21:00:20.276487
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """
    This function is to run unit test for method
    get_current_locale of class BaseDataProvider
    """
    from mimesis.providers.base import BaseDataProvider
    base_provider = BaseDataProvider()
    assert base_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:00:23.259471
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert isinstance(str(provider), str)
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:00:30.548132
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for override_locale method of class BaseDataProvider."""
    provider = BaseDataProvider()

    with provider.override_locale(locale='ru') as pr:
        assert pr.locale == 'ru'
        assert pr.get_current_locale() == 'ru'

    with provider.override_locale(locale='en') as pr:
        assert pr.locale == 'en'
        assert pr.get_current_locale() == 'en'

    with provider.override_locale() as pr:
        assert pr.locale == 'en'
        assert pr.get_current_locale() == 'en'


# Generated at 2022-06-23 21:00:33.687375
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:00:40.218288
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import datetime
    #seed = datetime.datetime.now().microsecond
    seed = None
    bp1 = BaseProvider(seed)
    bp2 = BaseProvider(seed)
    r1 = bp1.random.randint(0,20)
    r2 = bp2.random.randint(0,20)
    assert bp1.random.seed == bp2.random.seed
    assert r1 == r2


# Generated at 2022-06-23 21:00:44.894361
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    assert BaseDataProvider().get_current_locale() == locales.EN

    locale = 'ru'
    provider_ru = BaseDataProvider(locale)
    assert provider_ru.get_current_locale() == locale



# Generated at 2022-06-23 21:00:47.328898
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    result = provider.__str__()
    assert result == 'BaseProvider'

# Generated at 2022-06-23 21:00:53.319012
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.builtins import Food
    obj = Food(['en', 'de'])
    assert isinstance(obj, BaseDataProvider)
    assert obj.get_current_locale() == 'en-DE'
    obj.reseed(1)
    assert obj.get_current_locale() == 'en-DE'


# Generated at 2022-06-23 21:00:55.103562
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    d = BaseDataProvider()
    assert d is not None
    assert d.locale == 'en'


# Generated at 2022-06-23 21:00:56.807391
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-23 21:00:59.397100
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider()
    assert str(test_provider) == 'BaseDataProvider <en>'
    assert repr(test_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:00.829972
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    instance = BaseProvider()
    instance.reseed(seed=123)
    assert instance.seed == 123


# Generated at 2022-06-23 21:01:03.775499
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='ru')
    provider._pull()
    data = provider._data
    provider._override_locale(locale='en')
    assert data != provider._data


# Generated at 2022-06-23 21:01:05.424720
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale="en", seed=100)
    assert hasattr(bdp, "locale") and bdp.locale is not None


# Generated at 2022-06-23 21:01:08.811558
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    b1 = BaseDataProvider()
    assert b1.__str__() == 'BaseDataProvider <en>'
    b2 = BaseDataProvider(locale=locales.UK)
    assert b2.__str__() == 'BaseDataProvider <uk>'

# Generated at 2022-06-23 21:01:11.480833
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.random import random
    provider = BaseProvider()
    assert provider.random == random
    provider.reseed(provider.seed)
    assert provider.random != random


# Generated at 2022-06-23 21:01:15.177403
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:01:17.248335
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    random = Random()
    random.random()
    print(random.random())


# Generated at 2022-06-23 21:01:19.334003
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Geography
    from mimesis.providers.geography import DEFAULT_LOCALE_GEODATA

    with Geography().override_locale('en') as geo:
        assert geo.get_current_locale() == 'en'
    assert geo._data == DEFAULT_LOCALE_GEODATA

# Generated at 2022-06-23 21:01:22.208599
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Setup
    provider = BaseProvider()

    # Exercise
    provider.reseed()

    # Verify
    assert provider.random is not random
    assert provider.random is not None



# Generated at 2022-06-23 21:01:26.544873
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """
    Unit test for method reseed of class BaseProvider
    :return: nothings
    """
    albert = BaseProvider(seed=23)
    albert.reseed()
    stringData = albert.random.randstr()
    assert stringData == 'q3zq0'

# Generated at 2022-06-23 21:01:29.176867
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider(locale='uk')
    assert str(provider) == 'BaseDataProvider <uk>'

# Generated at 2022-06-23 21:01:39.263564
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins.internet import Internet
    from mimesis.builtins.business import Business
    from mimesis.builtins.numbers import Numbers
    net: Internet = Internet()
    busi: Business = Business()
    num: Numbers = Numbers()
    #net.seed(1)
    #busi.seed(1)
    #num.seed(1)
    print('net = ', net.ip_address())
    print('busi = ', busi.job_title())
    print('num = ', num.random_int(10))
    print('net = ', net.ip_address())
    print('busi = ', busi.job_title())
    print('num = ', num.random_int(10))
    net.reseed(1)
    busi.reseed(1)
   

# Generated at 2022-06-23 21:01:43.268571
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class TestBaseProvider(BaseProvider):
        def __init__(self):
            self.locale = ''
    assert str(TestBaseProvider()) == 'TestBaseProvider'


# Generated at 2022-06-23 21:01:49.421943
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FooProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN):
            super().__init__(locale=locale)
    foo_provider = FooProvider(locale=locales.RU)
    with foo_provider.override_locale(locales.EN) as fp:
        assert fp.locale == locales.EN
    assert foo_provider.locale == locales.RU

# Generated at 2022-06-23 21:01:51.478570
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    result = provider.get_current_locale()
    assert result == 'en'

# Generated at 2022-06-23 21:01:54.716643
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider(10)
    assert p.seed == 10
    assert p.__str__() == 'BaseProvider'

    p2 = BaseProvider()
    assert p2.seed is not None
    assert p2.__str__() == 'BaseProvider'



# Generated at 2022-06-23 21:01:56.802851
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # When I create an instance of class `BaseProvider`
    baseProvider = BaseProvider()
    # Then `_seed` equals to None
    assert baseProvider.seed == None


# Generated at 2022-06-23 21:01:57.813278
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:58.944080
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print('Running unit tests for BaseDataProvider')


# Generated at 2022-06-23 21:01:59.857320
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider(None)
    assert base is not None

#Tests for constructor of class BaseDataProvider

# Generated at 2022-06-23 21:02:00.866180
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert ('BaseProvider' == str(BaseProvider()))

# Generated at 2022-06-23 21:02:01.748046
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    provider=BaseDataProvider()
    assert provider


# Generated at 2022-06-23 21:02:04.618283
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseData = BaseDataProvider(locale='en')
    assert baseData.locale == 'en' or baseData.locale == 'zh_cn' or baseData.locale == 'ru'


# Generated at 2022-06-23 21:02:10.587843
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    locale = locales.EN
    provider = BaseDataProvider(locale=locale)
    assert provider.get_current_locale() == locale
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:02:13.432329
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p is not None

if __name__ == '__main__':
    test_BaseProvider()

# Generated at 2022-06-23 21:02:15.409437
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    A = BaseProvider
    instance = A()
    assert isinstance(instance, A)


# Generated at 2022-06-23 21:02:16.784918
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en')
    assert provider is not None
    assert provider.locale == 'en'
    assert provider.seed == None


# Generated at 2022-06-23 21:02:27.289359
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider.
    """
    from mimesis.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Locales

    locale = Locales.DATE_TIME[0]
    locale_gender = Gender.FEMALE.value

    provider = BaseDataProvider(locale=locale)
    with provider.override_locale() as datetime:
        assert datetime.get_current_locale() == locales.DEFAULT_LOCALE
        assert datetime.today().month_name == Datetime.MONTHS[1]

    with provider.override_locale(locale=locale) as datetime:
        assert datetime.get_current_locale() == locale
        assert datetime.today().month

# Generated at 2022-06-23 21:02:31.388544
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider()
    assert data_provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:02:37.867213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pandas as pd
    from mimesis.builtins import Person
    p = Person('zh_CN')
    p_en = p.override_locale('en-US')
    df = pd.DataFrame(columns = ['cn_person', 'en_person'])
    for i in range(10):
        cn_person = p.full_name()
        en_person = p_en.full_name()
        df = df.append({'cn_person':cn_person, 'en_person':en_person}, ignore_index=True)
    return df



# Generated at 2022-06-23 21:02:45.639997
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    b.reseed(seed=None)
    assert (b._data == {})
    assert (b._datafile == '')
    assert (b._data_dir == Path(__file__).parent.parent.joinpath('data'))
    assert (b.locale == 'en')
    assert (b.seed is None)
    assert (b.random is not None)

    b = BaseDataProvider(locale='zh', seed=None)
    b.reseed(seed=None)
    assert (b._data == {})
    assert (b._datafile == '')
    assert (b._data_dir == Path(__file__).parent.parent.joinpath('data'))
    assert (b.locale == 'zh')
    assert (b.seed is None)

# Generated at 2022-06-23 21:02:54.058464
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Child(BaseDataProvider):
        pass
    c1 = Child(locale=locales.EN)
    c2 = Child(locale=locales.EN_US)
    with c1.override_locale(locales.RU) as c:
        assert isinstance(c, BaseDataProvider)
        assert c.locale == locales.RU
        with c2.override_locale(locales.RU) as c:
            assert c.locale == locales.RU
        assert c1.locale == locales.RU
        assert c2.locale == locales.EN_US

# Generated at 2022-06-23 21:02:56.108265
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    for i in range(10):
        assert provider.random.randint(1, 999) == 653


# Generated at 2022-06-23 21:02:57.927900
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test(BaseProvider):
        pass

    t = Test()
    assert str(t) == 'Test'


# Generated at 2022-06-23 21:03:07.156575
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Person(BaseDataProvider):

        def __init__(self, locale: str, seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.name = 'Vinay'

        def calculate(self, a: int, b: int = 0) -> int:
            return a + b

    person = Person("en", seed=12)

    with person.override_locale('fr') as transformed:
        assert transformed.calculate(2, 3) == 5

    assert person.calculate(2, 2) == 4

# Generated at 2022-06-23 21:03:09.318070
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.person import Person
    p = Person()
    p_str = str(p)
    assert p_str == 'Person'

# Generated at 2022-06-23 21:03:12.536567
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    seed = get_random_item([i for i in range(1, 101)])
    p = BaseProvider(seed=seed)
    assert p.__class__.__name__ == 'BaseProvider'

# Generated at 2022-06-23 21:03:15.074001
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.locale == 'en'
    assert BaseDataProvider('ru').locale == 'ru'

# Generated at 2022-06-23 21:03:20.221308
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    import json

    from pathlib import Path

    from mimesis.data import BaseDataProvider

    __location__ = Path(__file__).parent.absolute()
    file = Path(__location__).joinpath('data', 'en', 'name.json')
    with open(file, 'r', encoding='utf8') as f:
        data = json.load(f)

    data_provider = BaseDataProvider()
    data_provider._pull('name.json')
    assert data == data_provider._data

# Generated at 2022-06-23 21:03:23.992848
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    import pytest
    from mimesis.typing import Seed

    seed = Seed
    base_provider = BaseProvider(seed=seed)

    assert base_provider.seed == seed



# Generated at 2022-06-23 21:03:33.032215
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    random.seed(1)
    assert random() != random()
    random.seed(1)
    assert random() == random()

    provider = BaseProvider(seed=1)
    assert provider.seed is not None
    assert provider.random() != provider.random()
    provider.reseed(1)
    assert provider.random() == provider.random()

    new_provider = BaseProvider()
    new_provider_randoms = [new_provider.random() for x in range(10)]
    new_provider.reseed(1)
    new_provider_seed_randoms = [new_provider.random() for x in range(10)]
    assert new_provider_randoms != new_provider_seed_randoms
    new_provider

# Generated at 2022-06-23 21:03:34.556116
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:03:38.681695
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider(seed=2)
    assert b.seed == 2
    assert b.random is not random
    b.reseed()
    assert b.seed is None
    assert b.random is random


# Generated at 2022-06-23 21:03:40.631218
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for BaseProvider."""
    b = BaseProvider()
    assert b.seed is None



# Generated at 2022-06-23 21:03:44.207991
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider(locale='en')
    assert base_data_provider.__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:03:47.162872
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()
    assert str(base_data_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:52.030180
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider_obj = BaseDataProvider()
    assert base_data_provider_obj._data is not None
    assert base_data_provider_obj._datafile == ""
    assert base_data_provider_obj._data_dir is not None
    assert base_data_provider_obj._pull() is None



# Generated at 2022-06-23 21:03:55.065756
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'
    bdp = BaseDataProvider(locale='ru')
    assert str(bdp) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:04:00.537637
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider(seed=1, locale='ru')
    assert provider.random.seed_value is not None
    assert provider.random.seed_value is provider.seed
    assert provider.seed is not None
    assert provider.random is not None
    assert provider.__cachenames__ == []
    assert provider.data is not None
    assert provider.locale == 'ru'


# Generated at 2022-06-23 21:04:06.169482
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Given some class which inherited from BaseDataProvider
    class DummyProvider(BaseDataProvider):
        pass

    # When call __str__
    result = str(DummyProvider())

    # Then it should return class name with current locale in brackets
    assert result == 'DummyProvider <en>'

# Generated at 2022-06-23 21:04:11.602101
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    for seed in [None, 1, 'a', (1,2,3), [1,2,3], [None, 1, 'a', (1,2,3), [1,2,3]]]:
        provider1 = BaseProvider(seed=seed)
        provider2 = BaseProvider(seed=seed)
        assert provider1.seed == provider2.seed
        assert provider1.random.getstate() == provider2.random.getstate()

# Generated at 2022-06-23 21:04:14.991123
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    print(provider)
    #assert provider.locale == 'en'

test_BaseDataProvider()


# Generated at 2022-06-23 21:04:26.441232
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale, seed)
            self._datafile = 'test.json'
            self._pull()

        def get_color(self, item: str = None) -> str:
            return self.random.choice(list(self._data['color'].values()))

    with TestProvider('en', seed=1234567890) as p:
        assert p.get_color() in ('red', 'green', 'blue')

    with TestProvider.override_locale('ru') as p:
        assert p.get_color() in ('красный', 'зеленый', 'синий')


# Generated at 2022-06-23 21:04:30.169225
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# # Unit test for method __str__ of class BaseDataProvider
# def test_BaseDataProvider___str__():
#     assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:36.291011
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that locale is properly overridden."""
    class PatchedBaseDataProvider(BaseDataProvider):
        @property
        def data(self) -> Dict[str, str]:
            return self._data
    provider = PatchedBaseDataProvider()
    with provider.override_locale('en') as overridden:
        assert overridden.get_current_locale() == 'en'
        assert overridden.data


# Generated at 2022-06-23 21:04:45.746453
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    signature_of_method = ['def reseed(self, seed: Seed = None) -> None:']
    comment_of_method = "Reseed the internal random generator."
    comment_of_return = ":return: Nothing."
    comment_of_parameter = ":param seed: Seed for random. When set to `None` the current system time is used."
    assert BaseProvider.reseed.__doc__ == "".join(
        [signature_of_method, comment_of_method, comment_of_parameter, comment_of_return])
    assert BaseProvider.__init__.__doc__ == "Initialize attributes."

# Generated at 2022-06-23 21:04:47.678783
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    assert BaseDataProvider().get_current_locale() == locales.EN

# Generated at 2022-06-23 21:04:53.350572
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    # Instantiate provider
    person = Person('ru')
    
    import pytest
    with pytest.raises(ValueError):
        assert person.override_locale()

    # Assert locale
    assert person.locale == 'ru'
    
    
    

# Generated at 2022-06-23 21:04:55.547072
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:05:01.029196
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for override_locale."""
    locale = locales.DEFAULT_LOCALE
    provider_class = BaseDataProvider
    prov = provider_class(locale=locale)

    with prov.override_locale() as pr:
        assert pr.locale == locales.DEFAULT_LOCALE

    assert prov.locale == locale

# Generated at 2022-06-23 21:05:02.387846
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert not BaseProvider.__init__.__annotations__


# Generated at 2022-06-23 21:05:09.923143
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.enums import Gender, Currency
    from mimesis.providers.financial import CurrencyCode
    from mimesis.providers.person import Person
    from mimesis.providers.payment import CardProvider

    person = Person('ru')
    person.get_current_locale() == 'ru'

    # 1. Default locale is en
    person = Person()
    assert person.get_current_locale() == 'en'

    # 2. en is the default locale
    card_provider = CardProvider('en')
    assert card_provider.get_current_locale() == 'en'

    # 3. Check with euro currency
    currency_code = CurrencyCode('ru')
    currency_code.get_current_loc

# Generated at 2022-06-23 21:05:13.883277
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    if isinstance(BaseProvider(seed=None).__str__(), str):
        print("Unit test of method __str__ of class BaseProvider: Passed")
    else:
        print("Unit test of method __str__ of class BaseProvider: Failed")


# Generated at 2022-06-23 21:05:21.048399
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

        def test_method(self, *args, **kwargs):
            return str(self)

    provider = TestProvider()
    assert provider.test_method() == 'TestProvider <en>'
    with provider.override_locale('ru'):
        assert provider.test_method() == 'TestProvider <ru>'
    assert provider.test_method() == 'TestProvider <en>'

# Generated at 2022-06-23 21:05:23.082073
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert str(b) == 'BaseProvider'
    assert not isinstance(b, str)



# Generated at 2022-06-23 21:05:24.621865
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:05:28.333294
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""

    instances = [BaseProvider(seed=None), BaseProvider(seed=324)]
    seeds = [None, 324]

    for seed, instance in zip(seeds, instances):
        assert seed == instance.seed, \
            f'Unexpected result of reseed of BaseProvider. Instance seed: {seed} ' \
            f'!= {instance.seed}'



# Generated at 2022-06-23 21:05:33.744537
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    ad = Address()
    for locale in ['en', 'ru', 'uk']:
        with ad.override_locale(locale=locale) as newprovider:
            city = newprovider.city()
            assert city not in ['New York', 'Москва']


# Generated at 2022-06-23 21:05:34.703041
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a=BaseDataProvider()
    print(a.get_current_locale())
#test_BaseDataProvider() # en


# Generated at 2022-06-23 21:05:37.250201
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    provider = BaseDataProvider(locale='ru')
    assert provider.locale == 'ru'
    assert provider.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:05:39.854446
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:05:42.372154
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    obj.reseed(32)
    result = obj.seed==32
    assert result==True

# Generated at 2022-06-23 21:05:44.770916
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test default locale
    bd = BaseDataProvider()
    assert bd.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:05:50.555257
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person
    p = Person()
    assert p.get_current_locale() == locales.EN
    with p.override_locale(locales.RU) as pp:
        assert pp.get_current_locale() == locales.RU
        assert pp.get_full_name()
    assert p.get_current_locale() == locales.EN
    assert p.get_full_name()

# Generated at 2022-06-23 21:06:00.628870
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for the reseed method of class BaseProvider

    It should create a new Random generator if random is not
    different from Random.
    """

    class TestBaseProvider(BaseProvider):
        """Test class for BaseProvider.

        Used to test BaseProvider.reseed() method
        """
        def __init__(self, seed: Seed) -> None:
            super().__init__(seed)
            self.random = Random()

        def foo(self) -> float:
            return self.random.random_float()

    tbp = TestBaseProvider(seed=123456)
    tbp.reseed()

    assert tbp.seed == 123456
    assert not isinstance(tbp.random, Random)



# Generated at 2022-06-23 21:06:07.246116
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(seed = 1)
    #print(bdp.get_current_locale())
    assert bdp.get_current_locale() == "en"
    #print(type(bdp))
    assert type(bdp) == BaseDataProvider
    #print(bool(bdp))
    assert bool(bdp)
    #bdp._pull()
    #print(bdp._data)
    #print(bdp.__str__())

test_BaseDataProvider()

# Generated at 2022-06-23 21:06:09.532515
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p is not None, "p is None"
    assert isinstance(p, BaseProvider), "p is not instance of BaseProvider"


# Generated at 2022-06-23 21:06:16.151877
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class MockProvider(BaseProvider):
        pass

    p = MockProvider()
    assert str(p) == 'MockProvider'
    p.locale = 'ru'
    assert str(p) == 'MockProvider'

    class MockDataProvider(BaseDataProvider):
        pass

    p = MockDataProvider()
    assert str(p) == 'MockDataProvider <en>'
    p.locale = 'ru'
    assert str(p) == 'MockDataProvider <ru>'

# Generated at 2022-06-23 21:06:18.921699
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p=BaseProvider(seed='q')
    p2=BaseProvider()
    p2.reseed(seed='q')
    assert p.seed==p2.seed

# Generated at 2022-06-23 21:06:21.496353
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:06:23.136092
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale="en")
    assert str(provider) == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:06:24.348494
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:06:29.296772
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider(locale='zh')) == 'BaseDataProvider <zh>'
    try:
        assert str(BaseDataProvider(locale='undefined')) == 'BaseDataProvider <undefined>'
    except UnsupportedLocale:
        return True
    return False

if __name__ == '__main__':
    test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:06:36.519764
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    dp = BaseProvider()
    assert dp.seed is None
    assert dp.random is random
    dp = BaseProvider(seed=123)
    assert dp.seed == 123
    assert dp.random is not random
    dp.reseed(456)
    assert dp.seed == 456
    assert dp.random is not random
    dp.reseed(None)
    assert dp.seed == None
    assert dp.random is not random
test_BaseProvider()


# Generated at 2022-06-23 21:06:41.883220
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Checks the correctness of the override_locale method."""
    provider = BaseDataProvider(locale='en')
    origin_locale = provider.locale
    with provider.override_locale('ru'):
        locale = provider.locale
    locale = provider.locale
    return origin_locale == locale

# Generated at 2022-06-23 21:06:46.024536
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider(locale="hi")
    b._pull()
    assert b._data["Personal"]["first_name"] == ["अमित", "अमिर", "अमीत", "अमीर", "अयोध्या", "अरुण", "अशोक", "अश्विन", "अश्विनी", "अब्दुल", "अलक"]

# Generated at 2022-06-23 21:06:50.371958
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider()
    assert base_provider.seed is None
    assert base_provider.reseed(seed=10) is None
    assert base_provider.seed == 10


# Generated at 2022-06-23 21:06:52.238712
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    provider._setup_locale()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:55.641628
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Given
    provider = BaseProvider()

    # When
    result = provider.__str__()

    # Then
    assert result == 'BaseProvider'


# Generated at 2022-06-23 21:07:00.436846
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'
    assert BaseDataProvider(locale='ja').__str__() == 'BaseDataProvider <ja>'


# Generated at 2022-06-23 21:07:04.711479
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Address
    from mimesis.exceptions import UnsupportedLocale

    assert str(Address()) == 'Address <en>'

    try:
        str(Address('ru'))
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:07:10.535958
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    p = Person('de')
    with p.override_locale('de-DE') as result:
        assert result.get_current_locale() == 'de-DE'
        assert p.get_full_name() == result.get_full_name()
    assert p.get_current_locale() == 'de'
    assert result.get_current_locale() == 'de'

# Generated at 2022-06-23 21:07:11.314442
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()
    BaseProvider("seed")


# Generated at 2022-06-23 21:07:13.511001
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider() method override_locale."""
    from mimesis.providers.personal import Person
    dp = Person()
    with dp.override_locale('ru') as p:
        assert str(p) == 'ru'
    assert str(dp) == 'en'

# Generated at 2022-06-23 21:07:20.688529
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider1 = BaseProvider(seed=1234)
    provider1.random.seed(1234)
    provider2 = BaseProvider(seed=1234)
    provider2.random.seed(1234)
    assert provider1 == provider2

    provider1 = BaseProvider(seed=None)
    assert (provider1.random).random() != (provider2.random).random()



# Generated at 2022-06-23 21:07:24.366214
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b1 = BaseProvider()
    b2 = BaseProvider(123)

    assert b1.random == b2.random
    assert b1.seed is None
    assert b2.seed == 123


# Generated at 2022-06-23 21:07:26.973608
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    obj = BaseDataProvider(locale='ru')
    with obj.override_locale('en') as test:
        assert test.locale == 'en'

    assert obj.locale == 'ru'

# Generated at 2022-06-23 21:07:30.283539
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='ru-RU', seed=1)
    assert provider.get_current_locale() == 'ru-ru'



# Generated at 2022-06-23 21:07:33.824178
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:07:35.750480
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:37.561083
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    instance = BaseProvider()
    assert str(instance) == 'BaseProvider'


# Generated at 2022-06-23 21:07:42.447823
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locales.add_supported_locale('alpha', 'Alpha', 'alpha')
    p = BaseDataProvider('alpha')
    assert p.get_current_locale() == 'alpha'
    locales.remove_supported_locale('alpha')
    p = BaseDataProvider('foo')
    assert p.get_current_locale() == 'foo'


# Generated at 2022-06-23 21:07:43.711626
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    class B(BaseProvider):
        pass

    b = B()
    assert str(b) == 'B'

# Generated at 2022-06-23 21:07:48.247933
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import LOCALES
    from mimesis.builtins import NaturalLanguage
    from mimesis.data import LOCALES

    rnd = Random()
    locale = rnd.choice(LOCALES)

    provider = NaturalLanguage(seed=123, locale=locale)
    assert provider.get_current_locale() == locale

# Generated at 2022-06-23 21:07:58.762062
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider, method override_locale
    
    Test for the context manager method override_locale.
    """
    class RomanNumber(BaseDataProvider):
        """Just a test class"""
        def _pull(self):
            """Pull the content from the JSON and memorize one."""
            self._data = {'one': 1, 'two': 2, 'three': 3}
    roman = RomanNumber('ru')
    assert roman.get_current_locale() == 'ru'
    with roman.override_locale('en') as new_roman:
        assert new_roman.get_current_locale() == 'en'
    assert roman.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:08:02.616130
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class dp(BaseDataProvider):
        pass

    pr = dp()
    assert pr.get_current_locale() == 'en'
    pr.locale = 'uk'
    assert pr.get_current_locale() == 'uk'


# Generated at 2022-06-23 21:08:03.783157
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed=42069)) == 'BaseProvider'


# Generated at 2022-06-23 21:08:08.109880
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for ``__str__`` method of class ``BaseDataProvider``."""
    sut = BaseDataProvider(locale=locales.EN)
    sut.override_locale(locale=locales.EN)
    assert str(sut) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:08:08.624444
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pass

# Generated at 2022-06-23 21:08:13.530643
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider(seed=None)
    assert a.seed is None
    assert a.random == random

    a = BaseDataProvider(seed=1)
    assert a.seed == 1
    assert isinstance(a.random, Random)


# Generated at 2022-06-23 21:08:16.045944
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider()
    assert dp.get_current_locale() == 'en'

# Generated at 2022-06-23 21:08:18.128508
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    myProvider = BaseProvider()
    assert isinstance(myProvider, BaseProvider)


# Generated at 2022-06-23 21:08:21.478990
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test without arguments
    bdp = BaseDataProvider(locale = 'ru-RU')
    res = bdp.get_current_locale()
    assert res == 'ru-ru', 'Сurrent locale is not set correctly'

