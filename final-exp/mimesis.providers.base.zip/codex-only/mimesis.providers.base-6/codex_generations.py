

# Generated at 2022-06-23 20:58:27.005060
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider(seed='1234')
    assert a.seed == '1234'


# Generated at 2022-06-23 20:58:27.779389
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert True

# Generated at 2022-06-23 20:58:36.743562
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed function."""
    random_num = [1, 2, 3, 4]

    def my_random_choice(items: list, _: Random) -> int:
        return items.pop(0)

    provider = BaseProvider()
    provider.random.choice = my_random_choice

    assert provider.random.choice(random_num) == 1
    assert provider.random.choice(random_num) == 2
    assert provider.random.choice(random_num) == 3

    provider.reseed()

    assert provider.random.choice(random_num) == 4
    assert provider.random.choice(random_num) == 1

    provider.reseed(seed=42)

    assert provider.random.choice(random_num) == 2
    assert provider.random.choice(random_num) == 3



# Generated at 2022-06-23 20:58:47.370480
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='es').__str__()
    BaseDataProvider(locale='es').__str__()
    BaseDataProvider(locale='es').__str__()
    BaseDataProvider(locale='es').__str__()
    BaseDataProvider(locale='es').__str__()

# Generated at 2022-06-23 20:58:52.077562
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.geography import Geography

    geo = Geography()

    with geo.override_locale('ru') as g:
        x = g.country_name()
        assert x is not None

    # failed localization
    with geo.override_locale('ru_RU') as g:
        x = g.country_name()
        assert x is not None

# Generated at 2022-06-23 20:58:55.928564
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    b.locale = "ro"
    assert b.__str__() == "BaseDataProvider <ro>"


# Generated at 2022-06-23 20:58:58.601565
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    try:
        test = BaseProvider()
    except Exception as e:
        print("Error in test_BaseProvider():", e)
        return 0
    return 1


# Generated at 2022-06-23 20:59:06.197518
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp1 = BaseDataProvider()
    assert dp1.get_current_locale() is 'en'
    dp2 = BaseDataProvider('ru')
    assert dp2.get_current_locale() is 'ru'
    dp3 = BaseDataProvider('zh-cn')
    assert dp3.get_current_locale() is 'zh-cn'


# Generated at 2022-06-23 20:59:07.953559
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base_provider = BaseProvider()
    assert base_provider.__str__() == 'BaseProvider'

# Generated at 2022-06-23 20:59:10.896513
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    myprovider = BaseDataProvider()
    assert isinstance(myprovider, BaseDataProvider)

# Generated at 2022-06-23 20:59:12.173586
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # assert BaseProvider().__str__() == 'BaseProvider'
    print(BaseProvider().__str__())

if __name__ == '__main__':
        test_BaseProvider()

# Generated at 2022-06-23 20:59:17.878119
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # true positive test
    a = BaseProvider()
    a.reseed()
    b = BaseProvider()
    b.reseed()
    assert a.seed == b.seed
    a.reseed(1)
    b.reseed(2)
    assert a.seed != b.seed
    # true negative test
    a.reseed()
    b.reseed(1)
    assert a.seed != b.seed


# Generated at 2022-06-23 20:59:19.960593
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()
    assert isinstance(provider.random, Random)

# Generated at 2022-06-23 20:59:21.436595
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale = 'ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 20:59:24.615080
# Unit test for constructor of class BaseProvider
def test_BaseProvider():

    provider = BaseProvider(False)
    print(provider)
    print(provider.random)
    print(provider.seed)
    print(provider.reseed())
    print(provider.random)



# Generated at 2022-06-23 20:59:35.851736
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    BaseDataProvider(locale='ru').get_current_locale()
    BaseDataProvider(locale='de-DE').get_current_locale()
    BaseDataProvider(locale='de-DE').get_current_locale()
    # BaseDataProvider(locale='en').get_current_locale()
    # BaseDataProvider(locale='en-US').get_current_locale()
    # BaseDataProvider(locale='en-US').get_current_locale()
    # BaseDataProvider(locale='en-GB').get_current_locale()
    # BaseDataProvider(locale='en-GB').get_current_locale()
    # BaseDataProvider(locale='en-AU').get_current_locale()
    # BaseDataProvider(locale='en-AU').get_current_

# Generated at 2022-06-23 20:59:44.161915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str, seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

        def get_list(self) -> list:
            return ['one', 'two', 'three']

        def get_item(self) -> str:
            return 'one'

    with TestProvider('en') as provider:
        assert provider.get_item() == 'one'
        assert provider.get_list() == ['one', 'two', 'three']
        with provider.override_locale('ru'):
            assert provider.get_item() == 'one'
            assert provider.get_list() == ['one', 'two', 'three']
        assert provider.get_item() == 'one'
        assert provider.get_list()

# Generated at 2022-06-23 20:59:54.000836
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    test_cases = [{
        'locale': None,
        'expected_locale': 'en',
    }, {
        'locale': 'ru',
        'expected_locale': 'ru',
    }, {
        'locale': 'ru-RU',
        'expected_locale': 'ru-RU',
    }]

    for test_case in test_cases:
        provider = BaseDataProvider(locale=test_case['locale'])

# Generated at 2022-06-23 21:00:00.741932
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                 seed: Seed = None) -> None:
        """Initialize attributes for data providers.

        :param locale: Current locale.
        :param seed: Seed to all the random functions.
        """
        self._data: JSON = {}
        self._datafile = ''
        self._setup_locale(locale)
        self._data_dir = Path(__file__).parent.parent.joinpath('data')

    def _setup_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
        """Set up locale after pre-check.

        :param str locale: Locale
        :raises UnsupportedLocale: When locale not supported.
        :return: Nothing.
        """

# Generated at 2022-06-23 21:00:03.362382
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base_provider = BaseProvider()
    assert base_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:00:04.782365
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed == None
    assert bp.random == random
    assert isinstance(bp, BaseProvider)


# Generated at 2022-06-23 21:00:06.100694
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == "BaseProvider"

# Generated at 2022-06-23 21:00:06.868246
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:00:08.626482
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    f = BaseDataProvider(locale = 'ru')

    assert f.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:00:09.799029
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    p.reseed(None)

# Generated at 2022-06-23 21:00:12.197242
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert isinstance(bdp, BaseDataProvider)
    assert True


# Generated at 2022-06-23 21:00:15.463699
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestData(BaseDataProvider):
        def __init__(self):
            super().__init__()
    assert TestData().get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:00:17.167554
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:00:23.950850
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'
    assert bp.seed == None

    bp = BaseProvider(seed=None)
    assert str(bp) == 'BaseProvider'
    assert bp.seed == None

    bp = BaseProvider(seed=123)
    assert str(bp) == 'BaseProvider'
    assert bp.seed == 123


# Generated at 2022-06-23 21:00:29.733714
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    '''
    test_BaseDataProvider func
    '''
    assert issubclass(BaseDataProvider, BaseProvider) == True
    obj = BaseDataProvider()
    assert isinstance(obj, BaseDataProvider) == True
    assert obj == BaseDataProvider()
    seed = 10
    obj = BaseDataProvider(seed=seed)
    assert isinstance(obj, BaseDataProvider) == True
    assert obj == BaseDataProvider()
    assert obj._data == {}
    assert obj._datafile == ''


# Generated at 2022-06-23 21:00:33.586048
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Create an instance of BaseDataProvider with en locale
    base_provider = BaseDataProvider(locale='en')

    # Check:
    assert str(base_provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:00:39.459271
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = Random().seed

    bp = BaseProvider(seed=seed)
    assert bp.seed == seed
    assert bp.random._seed == seed
    assert bp.random.seed(seed)

    bp2 = BaseProvider()
    assert bp2.seed is None
    assert bp2.random._seed is None
    assert bp2.random.seed()



# Generated at 2022-06-23 21:00:41.305167
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Test(BaseDataProvider):
        pass
    obj = Test(locale='en')
    assert str(obj) == 'Test <en>'

# Generated at 2022-06-23 21:00:46.215287
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # These lines should print `<Provider Name> <Locale>`.
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider = BaseDataProvider(locale='ru')
    assert str(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:00:54.142701
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider._data == {}
    assert baseDataProvider._datafile == ''
    _data_dir = Path(__file__).parent.parent.joinpath('data')
    assert baseDataProvider._data_dir == _data_dir
    assert baseDataProvider.locale == locales.DEFAULT_LOCALE
    assert baseDataProvider.seed is None
    assert baseDataProvider.random == random
    assert baseDataProvider.__str__() == 'BaseDataProvider'

# Unit tests for _setup_locale method of class BaseDataProvider

# Generated at 2022-06-23 21:00:58.069341
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    bp.reseed()
    assert bp.__str__() == 'BaseProvider'

    bp = BaseProvider()
    bp.seed = 0
    bp.reseed(0)
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:01:01.588959
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random is random
    bp.reseed()
    assert bp.seed is not None
    assert bp.random is not random


# Generated at 2022-06-23 21:01:04.977420
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=12345)
    provider.reseed()
    assert provider.random is not random
    assert provider.seed is None
    assert provider.random.seed is None


# Generated at 2022-06-23 21:01:08.179523
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    provider = BaseProvider(seed=12)
    assert provider.seed == 12
    provider = BaseProvider(seed=None)
    assert provider.seed is None


# Generated at 2022-06-23 21:01:14.740656
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from unittest import TestCase
    from mimesis.typing import JSON
    # pylint: disable=missing-type-doc
    class BaseProviderTest(BaseProvider):
        def __init__(self, seed: Seed = None, data: JSON = {}) -> None:
            super().__init__(seed)
            self._data = data

    class TestBaseDataProviderGetCurrentLocale(TestCase):

        def setUp(self):
            self.provider = Address(self.locale)
            self._provider = BaseProviderTest()

        def test_get_current_locale(self):
            self.assertEqual(self.provider.get_current_locale(), self.locale)


# Generated at 2022-06-23 21:01:22.691963
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    mimesis = BaseProvider(seed=123)
    assert mimesis.random.generator.randint(1, 100) == 2
    mimesis.reseed(124)
    assert mimesis.random.generator.randint(1, 100) == 11
    assert mimesis.reseed() is None
    assert mimesis.random.generator.randint(1, 100) == 97
    mimesis.reseed(123)
    assert mimesis.random.generator.randint(1, 100) == 2


# Generated at 2022-06-23 21:01:24.898315
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    final=BaseDataProvider()
    assert  final.__str__()=='BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:26.076587
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider"""
    BaseProvider(2)


# Generated at 2022-06-23 21:01:29.085020
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider = BaseDataProvider('fr')
    assert str(provider) == 'BaseDataProvider <fr>'

# Generated at 2022-06-23 21:01:30.946169
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:01:37.578488
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._set_data('test.json')
        def  show(self):
            return self.get_current_locale()
    provider = Provider(locale='ru')
    with provider.override_locale(locale='en'):
        assert provider.show() == 'en'
    assert provider.show() == 'ru'

# Generated at 2022-06-23 21:01:43.021734
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=None)
    r1 = bp.random.random()
    r2 = bp.random.random()
    r3 = bp.random.random()
    assert(r1 != r2 and r2 != r3 and r1 != r3)
    bp.reseed(seed=None)
    r1 = bp.random.random()
    r2 = bp.random.random()
    r3 = bp.random.random()
    assert(r1 != r2 and r2 != r3 and r1 != r3)
    bp.reseed(seed=None)
    r1 = bp.random.random()
    r2 = bp.random.random()
    r3 = bp.random.random()

# Generated at 2022-06-23 21:01:53.386196
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for BaseDataProvider class."""
    from mimesis.builtins import Meta
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    bdp = BaseDataProvider(locale='en')
    assert bdp.locale == 'en'
    assert bdp._datafile == ''

    bdp = BaseDataProvider(locale='ru')
    assert bdp.locale == 'ru'
    assert bdp._datafile == ''

    with bdp.override_locale('en'):
        assert bdp.locale == 'en'
        assert bdp._datafile == ''

    with bdp.override_locale('ru'):
        assert bdp.locale == 'ru'
        assert bdp._datafile == ''


# Generated at 2022-06-23 21:01:54.673622
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider is not None


# Generated at 2022-06-23 21:01:57.672784
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 123
    seed2 = 1234
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    provider.reseed(seed)
    assert provider.random is not random
    assert provider.seed == seed
    assert provider.random.seed_value == seed
    provider.reseed(seed2)
    assert provider.random.seed_value == seed2


# Generated at 2022-06-23 21:02:00.556683
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.control import Control
    instance = Control(locale=locales.EN)
    assert isinstance(instance, Control)
    assert str(instance) == 'Control'
    instance = Control(locale=locales.RU)
    assert isinstance(instance, Control)
    assert str(instance) == 'Control'



# Generated at 2022-06-23 21:02:02.482604
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test BaseDataProvider.get_current_locale()
    obj = BaseDataProvider()
    assert obj.get_current_locale() == 'en'


# Generated at 2022-06-23 21:02:10.590748
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address
    import english

    ua = Address(locale='uk')
    en = Address(locale='en')
    assert ua.get_current_locale() == 'uk' or ua.get_current_locale() == 'uk-ua'
    assert en.get_current_locale() == 'en' or en.get_current_locale() == 'en-us'

    with ua.override_locale() as ua:
        assert ua.get_current_locale() == 'en' or ua.get_current_locale() == 'en-us'

    assert ua.get_current_locale() == 'uk' or ua.get_current_locale() == 'uk-ua'

# Generated at 2022-06-23 21:02:13.429965
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__(): # type: ignore
    provider = BaseProvider(seed=None)
    expected = "BaseProvider"
    assert str(provider) == expected


# Generated at 2022-06-23 21:02:16.000129
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers.address import Address

    a = Address(seed=1234)
    assert a.random.seed() == 1234, "The seed should be 1234"

    a.reseed(4321)
    assert a.random.seed() == 4321, "The seed should be 4321"

# Generated at 2022-06-23 21:02:20.001859
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    class TestProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed)

        def get_random_value(self):
            return self.random.generator().random()

    test_provider = TestProvider()
    first_random_value = test_provider.get_random_value()
    test_provider.reseed(seed=None)
    second_random_value = test_provider.get_random_value()
    assert first_random_value != second_random_value



# Generated at 2022-06-23 21:02:24.156812
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestClass(BaseDataProvider):
        pass
    test_class = TestClass(locale='cs')
    assert str(test_class).strip() == 'TestClass <cs>'
    test_class2 = TestClass()
    assert str(test_class2).strip() == 'TestClass <en>'


# Generated at 2022-06-23 21:02:32.521471
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed == None
    assert provider._data == {}
    assert provider._datafile == ''
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')

    provider = BaseDataProvider(locale = 'en', seed = 12)
    assert provider.locale == locales.EN
    assert provider.seed == 12
    assert provider._data == {}
    assert provider._datafile == ''
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:02:36.812840
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit-test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    provider.reseed(seed=123)
    assert provider.seed is not None
    assert provider.random is not random

# Generated at 2022-06-23 21:02:39.553637
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(BaseProvider())
    print(BaseProvider(seed=123))
    print(BaseDataProvider())
    print(BaseDataProvider(seed=123))



# Generated at 2022-06-23 21:02:42.982544
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class TestBaseProvider(BaseProvider):
        pass

    seed = '1234'
    test_provider = TestBaseProvider()
    test_provider.reseed(seed)
    assert test_provider.seed == seed


# Generated at 2022-06-23 21:02:47.487582
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    data = {'name': 'James', 'surname': 'Johnson'}
    name = list(data)[0]
    surname = list(data)[1]
    res = name + ' ' + surname
    provider = BaseProvider()
    expected = 'BaseProvider'
    assert str(provider) == expected

# Generated at 2022-06-23 21:02:57.529820
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.personal import Person
    from mimesis.providers.address import Address
    from mimesis.providers.person import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.Providers import Python

    # Unit test for method __str__ of class BaseDataProvider
    assert str(Python()) == 'Python <en>'
    assert str(Person('en')) == 'Person <en>'
    assert str(Address('en')) == 'Address <en>'
    assert str(Gender()) == 'Gender <en>'
    assert str(Datetime('en')) == 'Datetime <en>'

# Generated at 2022-06-23 21:03:09.084055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class FakeProvider(BaseDataProvider):
        def _pull(self, datafile: str = ''):
            self._data = {
                'a': {
                    'b': {
                        locales.EN: 'value_en',
                        locales.RU: 'value_ru',
                        locales.NB: 'value_nb',
                        locales.JA: 'value_ja',
                    }
                }
            }

        def get_value(self):
            return self._data['a']['b'][self.locale]

    provider = FakeProvider()
    provider.get_value()
    assert provider.get_value() == 'value_en'
    with provider.override_locale(locale=locales.RU):
        provider.get_value()

# Generated at 2022-06-23 21:03:11.405426
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(1234)
    assert provider.seed == 1234
    assert provider.random == seed

# Generated at 2022-06-23 21:03:13.695200
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test __str__ of BaseProvider.
    """
    base_provider = BaseProvider()
    assert str(base_provider) == 'BaseProvider'

# Generated at 2022-06-23 21:03:15.175280
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert 'en' == provider.get_current_locale()


# Generated at 2022-06-23 21:03:20.961269
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class BaseProvider_test(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)
            self._datafile = 'test.json'
            self._pull()
    test = BaseProvider_test()
    assert isinstance(test, BaseDataProvider)
    assert test.seed == None


# Generated at 2022-06-23 21:03:23.581857
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == locales.EN
    assert isinstance(provider._data_dir, Path)
    assert isinstance(provider.random, Random)
    assert provider.seed == None


# Generated at 2022-06-23 21:03:24.942144
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass
# Round-trip test for method override_locale of class BaseDataProvider

# Generated at 2022-06-23 21:03:26.526261
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    str(provider)


# Generated at 2022-06-23 21:03:34.457158
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test get_current_locale in BaseDataProvider.

    Test get_current_locale method in class BaseDataProvider.

    Returns:
        bool: Return True if test passed else False.
    """
    from mimesis.providers import Datetime

    dt = Datetime()
    # Test by default settings
    if dt.get_current_locale() != "en":
        return False
    dt = Datetime(locale="en")
    # Test with settings locale
    if dt.get_current_locale() != "en":
        return False
    dt = Datetime(locale="ru")
    # Test with settings locale
    if dt.get_current_locale() != "ru":
        return False
    return True


# Generated at 2022-06-23 21:03:36.863318
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
  assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:39.108941
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    assert Person().get_current_locale() == 'en'
    with Person().override_locale('ru') as p:
        assert p.full_name() != Person().full_name()

# Generated at 2022-06-23 21:03:49.473531
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # test provider with direct access to data
    class Direct(BaseDataProvider):
        """Test provider which uses direct access to data."""

        class Meta:
            """Class for storing data."""

            datafile = 'test.json'

        def __init__(self, seed: Seed = None, locale: str = locales.EN) -> None:
            """Initialize attributes.

            :param seed: Seed for random.
            """
            super().__init__(seed, locale)
            self._pull()

        def __str__(self) -> str:
            """Representation of provider."""
            return self.__class__.__name__

        def get_data(self) -> Dict[str, Any]:
            """Getter for data."""
            return self._data

    # test provider with access to data through property

# Generated at 2022-06-23 21:03:50.519118
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == 'en'


# Generated at 2022-06-23 21:03:52.347879
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale = locales.EN, seed = None).locale == locales.EN


# Generated at 2022-06-23 21:03:57.077639
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    '''
    BaseDataProvider class has method __str__,
    which returns this format:
    '{Classname} <{locale}>'
    '''

    # define a class
    class Test(BaseDataProvider):
        def __init__(self):
            super().__init__()

    # create an instance
    t = Test()
    assert t.__str__() == 'Test <en>'

# Generated at 2022-06-23 21:03:59.454270
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # TODO: Make more tests.
    b = BaseDataProvider()
    s = b.__str__()
    assert isinstance(s, str)


# Generated at 2022-06-23 21:04:00.701010
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:04:04.135346
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider."""
    # When we create an instance without parameter seed, it should be random.
    bp = BaseProvider()
    assert isinstance(bp, BaseProvider)

    bp_s = BaseProvider(seed=1)
    assert isinstance(bp_s, BaseProvider)


# Generated at 2022-06-23 21:04:06.847709
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert type(p.__str__()) == str


# Generated at 2022-06-23 21:04:09.274094
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Address
    address = Address()
    assert address.__str__() == 'Address <en>'
    

# Generated at 2022-06-23 21:04:21.504132
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider.__init__.__doc__ == 'Initialize attributes for data providers.\n\n        :param locale: Current locale.\n        :param seed: Seed to all the random functions.\n        '
    assert BaseDataProvider.__init__(
        BaseDataProvider,1).__dict__ == {'_data': {}, '_datafile': '', '_data_dir': 'pathlib.PosixPath(\'/Users/yanwenqi/workspace/Github/mimesis/mimesis/data\')', 'locale': 1, '_BaseDataProvider__random': 'mimesis.random.Random()', 'seed': None}

# Generated at 2022-06-23 21:04:33.211210
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Person, Address

    test_provider = BaseDataProvider()
    person = Person(test_provider)
    address = Address(test_provider)

    try:
        test_provider.override_locale()
    except ValueError:
        if person.gender() != Gender.MALE:
            raise AssertionError(
                'Expected "Male", got "{}"'.format(person.gender()))
        if address.country() != 'Antarctica':
            raise AssertionError(
                'Expected "Antarctica", got "{}"'.format(address.country()))


# Generated at 2022-06-23 21:04:34.642206
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed=7)) == 'BaseProvider'


# Generated at 2022-06-23 21:04:37.931771
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # BaseDataProvider().get_current_locale()
    # AttributeError: 'BaseDataProvider' object has no attribute 'locale'
    pass


# Generated at 2022-06-23 21:04:43.922206
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    x = BaseDataProvider(locale=locales.EN)
    y = BaseDataProvider() # locale=locales.DEFAULT_LOCALE
    assert x.get_current_locale() == locales.EN
    assert y.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 21:04:45.705131
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider()
    assert str(a) == 'BaseProvider'

# Generated at 2022-06-23 21:04:46.958944
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert isinstance(bdp, BaseDataProvider)

# Generated at 2022-06-23 21:04:52.592858
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass

    result = False

    provider = Provider()
    if (
        str(provider) ==
        '<Provider <{}>>'.format(locales.DEFAULT_LOCALE)
    ):
        result = True

    return result
assert test_BaseDataProvider___str__()



# Generated at 2022-06-23 21:04:55.170435
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='zh')
    assert bdp.get_current_locale() == 'zh'


# Generated at 2022-06-23 21:05:01.138840
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method _override_locale of class BaseDataProvider."""
    import mimesis.builtins
    from mimesis.builtins import Verbose

    provider = mimesis.builtins.Verbose(locale='ru')
    with provider.override_locale('en'):
        assert provider._data == Verbose(locale='en')._data

# Generated at 2022-06-23 21:05:01.767449
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider('en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:03.609087
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    assert p.random is random
    p.reseed()
    assert p.random == Random(seed=None)
    assert p.seed is None

# Generated at 2022-06-23 21:05:07.349835
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp.__str__()
    BaseProvider(seed=1)
    BaseProvider("a")


# Generated at 2022-06-23 21:05:12.827997
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    t = BaseProvider()
    assert t
    assert t.random == random
    assert t.seed == None
    t.reseed(123)
    assert t.seed == 123
    assert t.random.seed_value == 123
    t1 = BaseProvider(123)
    assert t1.seed == 123
    assert random.seed_value == random.get_seed()


# Generated at 2022-06-23 21:05:14.207776
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:05:22.490123
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Start test cases
    test_data = [
        ('BaseProvider', BaseProvider ),
        ('BaseDataProvider', BaseDataProvider)
    ]

    # Test
    answers = []
    for test in test_data:
        sample = BaseProvider(seed = test[0])
        assert (sample.seed == test[0])
        assert (sample.random == random)
        sample.reseed(seed=test[1])
        assert (sample.seed == test[1])
        assert (sample.random != random)
        answers.append(str(sample))
        answers.append(repr(sample))
    
    return answers

# Generated at 2022-06-23 21:05:25.733237
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class MyProvider(BaseDataProvider):
        pass
    assert isinstance(MyProvider(), BaseDataProvider)
    assert isinstance(MyProvider('fa'), BaseDataProvider)
    assert isinstance(MyProvider(seed=42), BaseDataProvider)
    assert isinstance(MyProvider('fa', seed=42), BaseDataProvider)


# Generated at 2022-06-23 21:05:35.149575
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    assert dp
    assert dp.locale == 'en'
    assert dp._data == {}
    assert dp._datafile == ''
    assert dp._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert not dp._pull.cache_info().misses
    assert dp._update_dict({}, {}) == {}
    assert dp.get_current_locale() == 'en'
    assert not hasattr(dp, 'override_locale')
    assert dp.__str__() == 'BaseDataProvider <en>'

test_BaseDataProvider()



# Generated at 2022-06-23 21:05:36.550308
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_BaseDataProvider.BaseDataProviderTest = BaseDataProvider('en')

# Generated at 2022-06-23 21:05:42.554179
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from tests.utils import get_unique_number
    seed = get_unique_number()
    pr = BaseProvider(seed=seed)
    assert pr.seed == seed
    assert pr.random is not random
    pr.reseed(seed=seed)
    assert pr.seed == seed
    assert pr.random is not random


# Generated at 2022-06-23 21:05:47.397212
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestDataProvider(BaseDataProvider):
        pass
    test_data_provider = TestDataProvider()
    assert (str(test_data_provider)
            == 'TestDataProvider <{}>'.format(locales.DEFAULT_LOCALE))

if __name__ == '__main__':
    test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:05:49.640846
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    assert isinstance(str(b),str)
#Unit test for method __str__ of class BaseProvider

# Generated at 2022-06-23 21:05:53.567026
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Constructor test
    bp = BaseProvider()
    bp.seed = None
    assert bp.seed is None
    bp.random = random
    assert bp.random is random
    bp.reseed(1)
    assert bp.seed is 1
    # str test
    assert str(bp) == "BaseProvider"


# Generated at 2022-06-23 21:05:55.237362
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = 10000
    provider = BaseProvider(seed)
    assert provider.seed == seed


# Generated at 2022-06-23 21:05:59.012767
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test method."""
    base_provider = BaseProvider()
    assert base_provider.random is random
    assert base_provider._data == {}
    assert base_provider._datafile == ''
# Test for __init__() method



# Generated at 2022-06-23 21:06:02.063145
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    print(provider)

test_BaseDataProvider()

# Generated at 2022-06-23 21:06:04.861640
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis import Person
    BaseDataProvider(locale='en', seed=None)
    DataProvider = Person.DataProvider
    DataProvider(locale='en', seed=None)


# Generated at 2022-06-23 21:06:06.552801
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=10)
    assert p.reseed(seed=11) == None

# Generated at 2022-06-23 21:06:08.122694
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random is random


# Generated at 2022-06-23 21:06:10.752111
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider(seed=None)
    #print(str(a))
    #print(repr(a))
    print(a)
    assert str(a) == 'BaseProvider'


# Generated at 2022-06-23 21:06:12.038085
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:06:13.646970
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:14.730345
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    BaseDataProvider().get_current_locale()



# Generated at 2022-06-23 21:06:19.112864
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    master_provider = BaseDataProvider()
    assert master_provider.__str__() == 'BaseDataProvider <en>'
    locale_dependent_provider = BaseDataProvider(locale='ru')
    assert locale_dependent_provider.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:06:20.731478
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)

if __name__ == "__main__":
    provider = BaseProvider()
    print(provider.__str__())

# Generated at 2022-06-23 21:06:27.686471
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 123456
    provider = BaseProvider()
    provider.seed = seed
    provider.random = random
    provider_seed = provider.seed
    provider_random = provider.random
    provider_reseed = provider.reseed()
    provider_random_reseed = provider.random
    assert provider_random is not provider_random_reseed
    assert provider_seed is None
    assert provider_reseed is None


# Generated at 2022-06-23 21:06:30.444022
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.person import Person, Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers

    person = Person('ru')
    datetime = Datetime('fr')
    numbers = Numbers()

    assert str(person) == 'Person <ru>'
    assert str(datetime) == 'Datetime <fr>'
    assert str(numbers) == 'Numbers <en>'



# Generated at 2022-06-23 21:06:35.081310
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Initialization
    data_provider = BaseDataProvider(locale='en')
    # Expected result
    expected = 'en'

    # Current result
    current = data_provider.get_current_locale()

    # Compare expected result and current result
    assert expected == current


# Generated at 2022-06-23 21:06:46.242318
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    random = Random()
    names = {random.word() for _ in range(random.randint(3, 10))}
    city_name = random.word()

    class CityProvider(BaseDataProvider):
        _datafile = 'support/city.json'

        def cities(self, *, city_name: str = None) -> Dict[str, str]:
            """Get city from dictionary.

            :param city_name: City name to return.
            :return: City name.
            """
            city = self._pull()[self.locale]

            if city_name:
                city = city.get(city_name, city)

            return city

    with CityProvider.override_locale() as p:
        assert p.cities() == {'city': city_name}


# Generated at 2022-06-23 21:06:51.261574
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale="en")
    str(provider)
    provider = BaseDataProvider(locale="ru")
    str(provider)
    provider = BaseDataProvider(locale="test")
    str(provider)



# Generated at 2022-06-23 21:07:03.408913
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    from mimesis.providers.internet import Internet
    bd = BaseDataProvider()
    inet = Internet()
    assert str(bd) == 'BaseDataProvider <en>'
    assert str(inet) == 'Internet <en>'
    with bd.override_locale('ru'):
        assert str(bd) == 'BaseDataProvider <ru>'
        assert str(inet) == 'Internet <ru>'
    assert str(bd) == 'BaseDataProvider <en>'
    assert str(inet) == 'Internet <en>'
    with bd.override_locale('ru'):
        assert str(bd) == 'BaseDataProvider <ru>'
        assert str(inet) == 'Internet <ru>'
    assert str

# Generated at 2022-06-23 21:07:06.296315
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:08.741255
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'en'
    bdp = BaseDataProvider(locale=locale, seed=None)
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:11.234184
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Dummy(BaseDataProvider):
        pass
    dummy = Dummy()
    assert str(dummy) == 'BaseProvider <en>'


# Generated at 2022-06-23 21:07:18.718163
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address, Locales
    from mimesis.providers.address.en import Address as AddressEN
    from mimesis.providers.address.ru import Address as AddressRU

    addressEN = AddressEN()
    addressRU = AddressRU()
    address = Address()

    # Test for attribute error
    try:
        with address.override_locale():
            pass
    except ValueError as e:
        if str(e) == '«Address» has not locale dependent':
            pass
        else:
            raise

    # Test for another locale
    city_ru = address.city()
    city_en = addressEN.city()
    with address.override_locale(Locales.RU):
        city_overridden = address.city()

    assert city_ru != city_

# Generated at 2022-06-23 21:07:20.869495
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    provider.reseed(seed=1)
    assert provider.seed == 1

# Generated at 2022-06-23 21:07:21.754032
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base=BaseProvider()
    assert base.seed is None
    assert base.random is random


# Generated at 2022-06-23 21:07:26.269019
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locales = ['en', 'zh', 'ja', 'gsw', 'wo']
    # locales = ['en', 'zh', 'ja']
    # locales = ['gsw', 'wo']
    for i in locales:
        provider = BaseDataProvider(locale=i)
        assert provider.get_current_locale() == i

# Generated at 2022-06-23 21:07:30.667567
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)
    bdp = BaseDataProvider('ru')
    assert str(bdp) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:07:35.079863
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider(locale="fr")
    assert str(b) == "BaseDataProvider <fr>"
    # we dont have to test fr_FR because only the first parameter is used.
    
test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:07:44.643436
# Unit test for constructor of class BaseProvider
def test_BaseProvider():


    from mimesis import Code, Person, Random
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    
    
    assert BaseProvider().locale == 'en'
    assert BaseProvider('es').locale == 'es'
    assert BaseProvider('ru').locale == 'ru'
    
    
    p_1 = Person('ru')
    p_2 = Person('ru')
    
    assert p_1.full_name() != p_2.full_name()
    assert p_1.password() != p_2.password()
    
    seed = 'A very good seed'
    p_3 = Person('ru', seed=seed)
    p_4 = Person('ru', seed=seed)
    
    assert p_3.full_name() == p_

# Generated at 2022-06-23 21:07:45.646071
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider("en") == "BaseDataProvider <en>"

# Generated at 2022-06-23 21:07:50.042061
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Person
    from time import time
    p1 = Person()
    p2 = Person()
    t1 = time()
    p1.reseed(t1)
    t2 = time()
    p2.reseed(t2)
    assert p1.name() == p2.name() and p1.name() == p2.name()


# Generated at 2022-06-23 21:08:01.367709
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    DIR = Path(__file__).parent.parent.joinpath('data')

    def get_data(locale: str, datafile: str) -> JSON:
        file_path = DIR.joinpath(locale, datafile)
        with open(file_path, 'r') as f:
            return json.load(f)

    separate_locale = 'ru-Cyrl'
    data_file = 'builtins.json'
    master_locale = 'ru-Cyrl'.split('-').pop(0)
    default_data = get_data(locale=locales.DEFAULT_LOCALE, datafile=data_file)
    master_data = get_data(locale=master_locale, datafile=data_file)

# Generated at 2022-06-23 21:08:07.743542
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Person

    p = Person('en')
    assert str(p) == 'Person <en>'

    p = Person('en-US')
    assert str(p) == 'Person <en-US>'

    p = Person('ru')
    assert str(p) == 'Person <ru>'

    p = Person('ru-RU')
    assert str(p) == 'Person <ru-RU>'


# Generated at 2022-06-23 21:08:09.163675
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-23 21:08:15.890205
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    a = BaseProvider(123)
    assert a.seed == 123
    assert a.random != random
    a.reseed()
    assert a.seed is not None
    assert a.random != random
    a1 = BaseProvider()
    a2 = BaseProvider()
    assert a1 != a2
    assert a1.random != a2.random


# Generated at 2022-06-23 21:08:17.230805
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test that BaseDataProvider can get current locale."""
    locale = locales.EN
    data_provider = BaseDataProvider(locale)
    assert data_provider.get_current_locale() == locale

# Generated at 2022-06-23 21:08:23.029138
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    random_numbers = []
    for i in range(5):
        random_numbers.append(provider.random.randint(1, 10))
    provider.reseed(42)
    random_numbers_reseed = []
    for i in range(5):
        random_numbers_reseed.append(provider.random.randint(1, 10))
    assert random_numbers != random_numbers_reseed

