

# Generated at 2022-06-23 20:58:24.916332
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class TestBaseProvider(BaseProvider):
        pass

    bp = TestBaseProvider()
    assert str(bp) == 'TestBaseProvider'

    class TestBaseProvider(BaseProvider):
        def __init__(self):
            pass

    bp = TestBaseProvider()
    assert str(bp) == 'TestBaseProvider'



# Generated at 2022-06-23 20:58:28.070609
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Arrange
    from mimesis.providers import BaseProvider
    seed = 15
    expected_seed = 15
    # Action
    bp = BaseProvider(seed=seed)
    result = bp.random.seed
    # Assert
    assert result == expected_seed



# Generated at 2022-06-23 20:58:34.919055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = 'en') -> None:
            super().__init__(locale=locale)

        def __str__(self) -> str:
            return str(self.locale)

    test_provider = TestProvider(locale='ru')
    with test_provider.override_locale('en'):
        assert str(test_provider) == 'en'

    with test_provider.override_locale('ru'):
        assert str(test_provider) == 'ru'

# Generated at 2022-06-23 20:58:35.866218
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    provider.reseed()



# Generated at 2022-06-23 20:58:37.660969
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    assert base.random
    assert base.seed == None

# Generated at 2022-06-23 20:58:49.619358
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # This is run only when this file is called directly,
    # without executing.
    # This test should cover 100% branch and 100% condition.
    p = BaseProvider()
    print(p)
    # Should print «BaseProvider» to the stdout
    # and return nothing.
    # «BaseProvider» is name of class.
    # If branch in method __str__ not covered then
    # string «Branch not covered» will print to the stdout.
    # If condition in method __str__ not covered then
    # string «Condition not covered» will print to the stdout.

# # Unit test for method __str__ of class BaseDataProvider
# def test_BaseDataProvider___str__():
#     # This is run only when this file is called directly,
#     # without executing.
#     # This test should cover 100% branch

# Generated at 2022-06-23 20:58:51.927825
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    assert str(BaseProvider()) == "BaseProvider"


# Generated at 2022-06-23 20:58:53.814739
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider('en')
    assert provider

# Generated at 2022-06-23 20:58:58.841175
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.random == random
    assert bp.seed is None
    assert bp._validate_enum(None, bp.random) == 'e0d9f0'
    assert bp.__str__() == "BaseProvider"


# Generated at 2022-06-23 20:59:03.440900
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    provider = BaseDataProvider(locale='de')
    assert provider.get_current_locale() == 'de'



# Generated at 2022-06-23 20:59:10.797228
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins.en import Person, Address, Internet
    provider_names = ['Address', 'Internet', 'Person']
    provider_objects = [Address(seed=1000), Internet(seed=2000),
                        Person(seed=3000)]
    provider_default_locales = [locales.EN, locales.EN, locales.EN]
    cls = BaseDataProvider
    obj1 = provider_objects[0]
    obj2 = provider_objects[1]
    obj3 = provider_objects[2]
    assert isinstance(obj1, cls) is True
    assert isinstance(obj2, cls) is True
    assert isinstance(obj3, cls) is True
    assert isinstance(obj1.get_current_locale(), str) is True

# Generated at 2022-06-23 20:59:13.314979
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1
    assert BaseProvider(seed = seed).seed == seed
    assert BaseProvider(seed = seed).random.seed == seed

# Generated at 2022-06-23 20:59:14.966618
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for the constructor of the class BaseDataProvider."""
    provider=BaseDataProvider()

# Generated at 2022-06-23 20:59:21.003261
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check if BaseDataProvider.override_locale works correctly."""
    from mimesis.builtins import Person

    p1 = Person('EN')
    p2 = Person('RU')
    with p2.override_locale() as provider:
        assert provider.get_current_locale() == 'ru'
        assert p1.last_name() != p2.last_name()
    assert p1.get_current_locale() == 'en'

# Generated at 2022-06-23 20:59:28.073254
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""

    def get_locale():
        """Get current locale."""
        return self.get_current_locale()

    self = BaseDataProvider(locale='ru')
    assert getattr(self, 'locale', locales.DEFAULT_LOCALE) == 'ru'
    assert get_locale() == 'ru'

    self = BaseDataProvider(locale='en')
    assert getattr(self, 'locale', locales.DEFAULT_LOCALE) == 'en'
    assert get_locale() == 'en'


# Generated at 2022-06-23 20:59:29.354248
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider(locale='en')
    assert isinstance(p, BaseDataProvider)

# Generated at 2022-06-23 20:59:30.823324
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    unittest.main()

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_BaseProvider_reseed()

# Generated at 2022-06-23 20:59:35.379920
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import PhoneCodeProvider
    data_provider = PhoneCodeProvider()
    with data_provider.override_locale(locales.RU) as provider:
        assert provider.locale == locales.RU
    assert data_provider.locale != locales.RU

# Generated at 2022-06-23 20:59:36.928189
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=None)

    assert provider is not None

# Generated at 2022-06-23 20:59:38.896369
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider(locale='en', seed=42)
    assert data.locale == 'en'
    assert data.seed == 42

# Generated at 2022-06-23 20:59:47.028576
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider1 = BaseDataProvider()
    provider1.seed = 5
    assert provider1.seed == 5
    assert provider1.locale == 'en'
    assert provider1._data == {}
    assert provider1._datafile == ''
    assert provider1._data_dir == Path(__file__).parent.parent.joinpath('data')

    provider2 = BaseDataProvider('de')
    assert provider2.locale == 'de'

    provider3 = BaseDataProvider('en', 439230)
    assert provider3.seed == 439230


# Generated at 2022-06-23 20:59:49.268680
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test(BaseProvider):
        pass

    t = Test()
    assert t.__str__() == 'Test'


# Generated at 2022-06-23 20:59:52.873009
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test = BaseDataProvider('en')
    assert test.locale == 'en'
    assert test._data is not None
    assert test._datafile == ''
    assert test._data_dir is not None
    assert test.seed == None
    assert test.random is not None
    assert test.__class__.__name__ == 'BaseDataProvider'
    assert test.__str__() == 'BaseDataProvider <en>'
    print("BaseDataProvider is OK")


# Generated at 2022-06-23 21:00:00.321928
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = get_random_item(locales.SUPPORTED_LOCALES, random)
    provider = BaseProvider(seed)
    reseed_rn = provider.random.random()
    provider.reseed()
    reseed_rn2 = provider.random.random()
    assert reseed_rn == reseed_rn2
    provider.reseed(seed)
    reseed_rn3 = provider.random.random()
    assert reseed_rn == reseed_rn3
    provider.reseed('123')
    reseed_rn4 = provider.random.random()
    provider.reseed('123')
    reseed_rn5 = provider.random.random()
    assert reseed_rn4 == reseed_rn5
    try:
        provider.reseed(123)
    except TypeError:
        pass

#

# Generated at 2022-06-23 21:00:01.559035
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-23 21:00:05.486644
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Check type of function
    assert type(BaseProvider.__str__) == classmethod

    # Check class method
    assert BaseProvider.__str__ is BaseProvider.__str__

    # Check __str__
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:00:07.960718
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_prov = BaseDataProvider()
    assert data_prov.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:00:10.188617
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Unit tests for method get_current_locale of class BaseDataProvider
    provider = BaseDataProvider()

    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:00:13.163987
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider(seed=1)
    actual = bp.__str__()
    expected = 'BaseProvider'
    assert actual == expected


# Generated at 2022-06-23 21:00:16.820421
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider(locale='en')
    assert isinstance(bdp, BaseDataProvider)
    assert bdp.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:22.368981
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # create instance of class BaseProvider
    base_provider = BaseProvider()

    # reseed random generator
    base_provider.reseed()

    # assert that the random generator's seed is the same as current time
    assert base_provider.seed == base_provider.random.seed



# Generated at 2022-06-23 21:00:24.668570
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=None)
    assert isinstance(provider, BaseProvider), \
        'Not an instance of BaseProvider'


# Generated at 2022-06-23 21:00:25.843462
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider().random == random
    assert BaseProvider().seed is None
    assert BaseProvider(seed=100).random != random
    assert BaseProvider(seed=100).seed == 100

# Generated at 2022-06-23 21:00:27.811404
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Code
    code = Code()
    print(code)
    # Code <en>


# Generated at 2022-06-23 21:00:38.229965
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
	
	# Create a instance of class BaseProvider, and assign a seed, then reseed with another seed
	test_provider=BaseProvider(seed=1234)
	test_provider.reseed(seed=5678)
	assert test_provider.seed==5678
	
	# Create a instance of class BaseProvider, reseed with a seed
	test_provider=BaseProvider()
	test_provider.reseed(seed=12635)
	assert test_provider.seed==12635
	
	# Create a instance of class BaseProvider, reseed without seed
	test_provider=BaseProvider()
	test_provider.reseed()
	assert test_provider.seed!=None
	

# Generated at 2022-06-23 21:00:41.227847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale=locales.EN)
    with provider.override_locale(locale=locales.EN) as provider:
        assert repr(provider) == 'BaseDataProvider <en>'

    with provider.override_locale(locale=locales.DE) as provider:
        assert repr(provider) == 'BaseDataProvider <de>'

    with provider.override_locale(locale=locales.RU) as provider:
        assert repr(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:00:46.111605
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    print('\nTest for method get_current_locale of class BaseDataProvider:')

    from mimesis.builtins import Person

    p = Person('en')
    print('\n- p.get_current_locale():', p.get_current_locale())



# Generated at 2022-06-23 21:00:51.335408
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    datafile = 'all.json'
    bdp = BaseDataProvider(locale=locale, seed=1)
    assert bdp.get_current_locale() == locale
    bdp._pull(datafile)
    assert bdp.get_current_locale() == locale


# Generated at 2022-06-23 21:00:55.947404
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    print("Testing method reseed of class BaseProvider\n")
    from mimesis.providers import Person, Address
    from mimesis.random import get_random_item
    from mimesis.data import GENDERS
    man = Person('en')
    print(man.seed)
    print(man.full_name())
    print(man.gender())
    man.reseed(None)
    print(man.seed)
    print(man.full_name())
    print(man.gender())
    man.reseed(1234)
    print(man.seed)
    print(man.full_name())
    print(man.gender())
    man.reseed(1234)
    print(man.seed)

# Generated at 2022-06-23 21:01:00.249534
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    assert len(p.random.seed) == 2
    p.reseed(123)
    assert p.random.seed == 123
    p.reseed()
    assert len(p.random.seed) == 2


# Generated at 2022-06-23 21:01:01.456481
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert str(obj) == "BaseProvider"


# Generated at 2022-06-23 21:01:03.121069
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random


# Generated at 2022-06-23 21:01:06.123927
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ja')) == 'BaseDataProvider <ja>'

# Generated at 2022-06-23 21:01:07.558169
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <{}>'.format(locales.EN)


# Generated at 2022-06-23 21:01:09.776038
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    try:
        BaseDataProvider(locale='en', seed=0)
    except Exception as e:
        print('Error:', e)


# Generated at 2022-06-23 21:01:17.403631
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    provider = Person()
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_name() == 'Петр'

    assert provider.get_current_locale() == 'en'
    assert provider.get_name() == 'John'

# Generated at 2022-06-23 21:01:25.518530
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    print('BaseProvider: \n')
    print('Seed: ', provider.seed)
    print('Random value using random module: ', provider.random.random())
    print('Random value using provider: ', provider.random.generator.random())

    print('\n')
    provider.reseed(seed=1)
    print('Seed: ', provider.seed)
    print('Random value using random module: ', provider.random.random())
    print('Random value using provider: ', provider.random.generator.random())


if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:01:27.503110
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    def check():
        f = BaseDataProvider(locale='en')
        assert str(f) == "BaseDataProvider <en>"

    check()

# Generated at 2022-06-23 21:01:29.420110
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bp = BaseDataProvider()
    assert bp
    assert bp.locale == 'en'


# Generated at 2022-06-23 21:01:31.568822
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:01:33.921046
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.base import BaseDataProvider
    obj = BaseDataProvider()
    result = obj.__str__()
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:37.843045
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import Localization
    l = Localization()
    assert l.get_current_locale() == locales.DEFAULT_LOCALE
    l.set_locale('en')
    assert l.get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:42.062334
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider(locale='en').__str__()
    BaseDataProvider(locale='ru').__str__()
    with pytest.raises(UnsupportedLocale):
        BaseDataProvider(locale='en_US').__str__()
    BaseDataProvider(locale='cs').__str__()
    BaseDataProvider(locale='zh_CN').__str__()


# Generated at 2022-06-23 21:01:47.396308
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Provider(BaseProvider):
        pass

    provider = Provider()
    assert str(provider) == 'Provider'

    provider.locale = 'ru'
    assert str(provider) == 'Provider <ru>'

    provider.reseed(123)
    assert str(provider) == 'Provider <123>'


# Generated at 2022-06-23 21:01:49.820803
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # create instance of BaseDataProvider and check the default locale is en
    p = BaseDataProvider()
    assert p.get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:51.906918
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider() is not None
    assert BaseProvider(seed=420) is not None


# Generated at 2022-06-23 21:01:53.141076
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert issubclass(BaseDataProvider, BaseProvider)


# Generated at 2022-06-23 21:01:54.671381
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider_baseDataProvider = BaseDataProvider()
    assert provider_baseDataProvider is not None


# Generated at 2022-06-23 21:01:56.759591
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    foo = BaseProvider(seed=0)
    assert foo.seed==0
    foo.reseed(seed=1)
    assert foo.seed==1

# Generated at 2022-06-23 21:01:58.164280
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Get current locale."""
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:00.204316
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    word_provider = BaseDataProvider(locale='cs')
    assert str(word_provider) == 'BaseDataProvider <cs>'


# Generated at 2022-06-23 21:02:05.101657
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class DummyProvider(BaseDataProvider):
        pass

    provider = DummyProvider()

    assert provider.__str__() == "DummyProvider <en>"

    class DummyProvider2(BaseDataProvider):
        def __init__(self, locale="en"):
            super().__init__(locale=locale)
    provider1 = DummyProvider2()
    assert provider1.__str__() == "DummyProvider2 <en>"
    provider2 = DummyProvider2(locale="ru")
    assert provider2.__str__() == "DummyProvider2 <ru>"

# Generated at 2022-06-23 21:02:08.026245
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseProvider(seed=1234)) == 'BaseProvider'


# Generated at 2022-06-23 21:02:15.674418
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check behavior of override_locale method of BaseDataProvider class."""
    class MyDataProvider(BaseDataProvider):
        """Data provider for testing."""

        def __init__(self, locale: str = 'ru') -> None:
            """Initialize attributes."""
            super().__init__(locale=locale)

        def get(self) -> str:
            """Get string for testing."""
            return self.locale

    provider = MyDataProvider('en')

    assert provider.get_current_locale() == 'en'
    assert provider.get() == 'en'

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get() == 'ru'

    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:02:22.025951
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    print('[*] test BaseDataProvider.get_current_locale ...')
    from mimesis.providers.languages import Languages
    dp = Languages()
    print('[*]', dp.get_current_locale())
    dp.reseed(seed=0)
    print('[*]', dp.get_current_locale())
    dp.reseed(seed=1)
    print('[*]', dp.get_current_locale())


# Generated at 2022-06-23 21:02:26.709421
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    seed = '123'
    locale = 'ru-ru'
    base = BaseDataProvider(locale=locale, seed=seed)
    assert base.seed == seed
    assert base.locale == locale
    assert base._datafile == ''
    assert base._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert str(base) == 'BaseDataProvider <ru-ru>'


# Generated at 2022-06-23 21:02:37.900354
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    ###### Should assert that BaseDataProvider.__str__ return 'BaseDataProvider <en>' when locale is None
    a = BaseDataProvider()
    assert a.__str__() == 'BaseDataProvider <en>'

    ###### Should assert that BaseDataProvider.__str__ return 'BaseDataProvider <en>' when locale is 'en'
    a = BaseDataProvider(locale='en')
    assert a.__str__() == 'BaseDataProvider <en>'

    ###### Should assert that BaseDataProvider.__str__ return 'BaseDataProvider <fr>' when locale is 'fr'
    a = BaseDataProvider(locale='fr')
    assert a.__str__() == 'BaseDataProvider <fr>'

    ###### Should assert that BaseDataProvider.__str__ return 'BaseDataProvider <ru>' when locale is '

# Generated at 2022-06-23 21:02:45.662529
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.enums import Gender

    obj = BaseDataProvider()
    assert str(obj) == 'BaseDataProvider <en>'

    obj = BaseDataProvider('es')
    assert str(obj) == 'BaseDataProvider <es>'

    obj = BaseDataProvider(locale=locales.EN)
    assert str(obj) == 'BaseDataProvider <en>'

    obj = BaseDataProvider(locale=locales.EN)
    assert str(obj) == 'BaseDataProvider <en>'

    obj = BaseDataProvider(locale='en-US')
    assert str(obj) == 'BaseDataProvider <en-us>'

    obj = BaseDataProvider(locale='fr-CA')
    assert str(obj) == 'BaseDataProvider <fr-ca>'


# Generated at 2022-06-23 21:02:54.459994
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FooProvider(BaseDataProvider):
        _datafile = 'foo'
        data = {1: 'foo', 2: 'bar'}

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._pull()

        def foo(self) -> str:
            d = self._data
            return d.get(self.random.generate(0, 2))

    provider = FooProvider()
    with provider.override_locale() as provider:
        assert provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:55.894533
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:02:57.496817
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert 'BaseProvider' == str(obj)


# Generated at 2022-06-23 21:02:59.408086
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider() is not None
    assert BaseProvider(seed=123) is not None


# Generated at 2022-06-23 21:03:00.976127
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print("Start executing BaseProvider...")
    b = BaseProvider()
    print("End executing BaseProvider...")


# Generated at 2022-06-23 21:03:04.789382
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    t = BaseProvider()
    t.reseed(1)
    assert t.random.random() == 0.13436424411240122
    assert t.seed == 1
    assert t.random.random() == 0.8474337369372327

# Generated at 2022-06-23 21:03:11.764157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider1(BaseDataProvider):
        pass

    provider1 = Provider1()
    with provider1.override_locale():
        pass

    result = provider1.get_current_locale()
    expected = 'en'
    assert result == expected
    # Assert raises when overriding locale for non locale-dependant providers.
    class Provider2(BaseProvider):
        pass

    provider2 = Provider2()
    with pytest.raises(ValueError):
        with provider2.override_locale():
            pass

# Generated at 2022-06-23 21:03:13.202622
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp is not None


# Generated at 2022-06-23 21:03:14.898936
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    locale = provider.get_current_locale()
    assert locale == 'en'

# Generated at 2022-06-23 21:03:17.941287
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    seed = 1024
    provider = BaseDataProvider(seed=1024)
    assert provider.seed == seed
    assert not isinstance(provider.random, Random)
    assert provider.random.seed(seed) == None


# Generated at 2022-06-23 21:03:19.346803
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()).__class__.__name__ == 'BaseProvider'


# Generated at 2022-06-23 21:03:20.410438
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert eval(str(BaseProvider())) == 'BaseProvider'


# Generated at 2022-06-23 21:03:30.829861
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class SimpleProvider(BaseDataProvider):   # noqa D101
        pass

    sample_provider = SimpleProvider()
    assert sample_provider.locale == sample_provider.locale
    with sample_provider.override_locale() as provider:
        assert provider.locale == provider.locale
    assert sample_provider.locale == sample_provider.locale
    with sample_provider.override_locale('ne') as provider:
        assert provider.locale == provider.locale
    assert sample_provider.locale == sample_provider.locale
    with sample_provider.override_locale('ru') as provider:
        assert provider.locale == provider.locale
    assert sample_provider.locale == sample_provider.locale

# Generated at 2022-06-23 21:03:32.054619
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)

# Generated at 2022-06-23 21:03:36.048572
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.base import BaseDataProvider
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE):
            super().__init__(locale)

    obj = TestBaseDataProvider('ru')
    obj.get_current_locale()
    assert obj.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:03:41.502082
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    provider_1 = BaseDataProvider(locale='en')
    provider_2 = BaseDataProvider(locale='uk')
    assert provider_1.get_current_locale() == 'en'
    assert provider_2.get_current_locale() == 'uk'


# Generated at 2022-06-23 21:03:45.726432
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed(seed=1)
    assert bp.random.choice(range(5)) == 4

# Generated at 2022-06-23 21:03:50.444993
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    obj = BaseDataProvider(locale='en')
    # test for the specified case
    assert obj.get_current_locale() == 'en'
    obj = BaseDataProvider(locale='ru')
    # test for the specified case
    assert obj.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:03:51.755710
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:03:55.155896
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import regions
    provider = regions.Regions()
    assert provider.get_current_locale() == 'en'
    provider.locale = 'ru'
    assert provider.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:03:57.077627
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    expect = 'BaseProvider'
    actual = bp.__str__()
    assert actual == expect


# Generated at 2022-06-23 21:03:59.458884
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider(locale=locales.EN)
    assert isinstance(str(bdp), str)
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:04:00.741203
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:04:02.155243
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base = BaseProvider()
    assert base.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:04:08.063145
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    locale = 'en'
    b = BaseDataProvider(locale)
    assert b.locale == locale
    assert b.get_current_locale() == locale
    assert b.__str__() == 'BaseDataProvider <en>'

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-23 21:04:09.914822
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    baseDataProvider = BaseDataProvider(locale="en", seed=None)
    assert baseDataProvider.get_current_locale() == "en"

# Generated at 2022-06-23 21:04:13.096255
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for :class:`BaseProvider`."""
    result = BaseProvider()
    print(result)
    assert result is not None


# Generated at 2022-06-23 21:04:25.426189
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """ constructor of class."""
    #testing BaseProvider
    provider = BaseProvider()
    assert provider._BaseProvider__dict__

    # testing random
    assert isinstance(provider.random, Random)

    # testing seed
    provider.seed = 42
    assert provider.seed == 42
    provider.seed = '42'
    assert provider.seed == '42'
    provider.seed = None
    assert provider.seed is None

    # testing _validate_enum
    assert provider._validate_enum(None, None) is None
    assert provider._validate_enum(1, None) is 1

    from mimesis.enums import CardinalDirection
    assert provider._validate_enum(CardinalDirection.NORTH,
                                   CardinalDirection) == 'north'

# Generated at 2022-06-23 21:04:27.421121
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider class"""
    provider = BaseDataProvider()
    assert provider.locale == 'en'

# Generated at 2022-06-23 21:04:32.672791
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Address, builtins
    from mimesis.enums import Locale

    bdp = BaseDataProvider()
    with bdp.override_locale(Locale.RU):
        assert bdp.locale == Locale.RU

    bdp = builtins.Builtins(Locale.RU)
    with bdp.override_locale(Locale.EN):
        assert bdp.locale == Locale.EN

    bdp = Address()
    with bdp.override_locale(Locale.EN):
        assert bdp.locale == Locale.EN

test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:04:34.594351
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    lp = BaseDataProvider(locale='ru')

    assert lp.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:04:42.479188
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    localizacion=BaseDataProvider(locale="es")
    assert localizacion.get_current_locale()=="es"
    localizacion.locale="en"
    assert localizacion.get_current_locale()=="en"
    localizacion.locale="js"
    assert localizacion.get_current_locale()=="en"
    localizacion.locale="ru-RU"
    assert localizacion.get_current_locale()=="ru"

# Generated at 2022-06-23 21:04:49.139982
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Initialization of class 'BaseDataProvider' with default attributes
    prov = BaseDataProvider()
    # Override locale in context manager
    with prov.override_locale('es'):
        assert prov.locale == 'es'
    # Override locale in context manager
    with prov.override_locale('en'):
        assert prov.locale == 'en'
    # Checking that the main attribute not changed out of context manager
    assert prov.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:04:52.456585
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider=BaseProvider(seed=None)
    assert provider.seed==None
    assert provider.random==random
    assert str(provider)=='BaseProvider'
    assert 'BaseProvider' in repr(provider)
    assert provider.seed==None


# Generated at 2022-06-23 21:04:54.992686
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    assert dp is not None
if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:04:59.749637
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en-US')
    with provider.override_locale(locale='ja-JP'):
        assert provider.get_current_locale() == 'ja-JP'
        co = provider.__str__()
        assert co == "BaseDataProvider <ja-JP>"
    assert provider.get_current_locale() == 'en-US'
    co = provider.__str__()
    assert co == "BaseDataProvider <en-US>"


# Generated at 2022-06-23 21:05:03.672865
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider()
    assert isinstance(base_provider, BaseProvider)

    base_provider = BaseProvider(seed=123)
    assert base_provider.seed == 123
    assert isinstance(base_provider, BaseProvider)


# Generated at 2022-06-23 21:05:06.595763
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert (
        str(BaseProvider()) == 'BaseProvider'
    )

# Generated at 2022-06-23 21:05:10.072366
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    with BaseDataProvider(locale='en') as en:
        assert str(en) == 'BaseDataProvider <en>'

    with BaseDataProvider(locale='ru') as ru:
        assert str(ru) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:05:12.741557
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    data = BaseDataProvider(locale)
    assert data.get_current_locale() == locale

# Generated at 2022-06-23 21:05:16.292149
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Testing method get_current_locale of class BaseDataProvider."""
    locale = locales.EN
    provider = BaseDataProvider(locale=locale)
    assert locale == provider.get_current_locale()

# Generated at 2022-06-23 21:05:24.496656
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    import mimesis.data as data
    with data.PC.override_locale('ru'):
        assert data.PC(locale='ru').get_current_locale() == 'ru'
        with data.PC.override_locale('en'):
            assert data.PC(locale='en').get_current_locale() == 'en'
        assert data.PC(locale='ru').get_current_locale() == 'ru'
    assert data.PC().get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:05:25.623707
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider()
    # <- 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:05:35.117885
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        """Class to test context manager override_locale."""

        def __init__(self, seed=None):
            super().__init__(seed=seed)
            self._datafile = 'foo.json'

        def get_foo(self) -> str:
            """Get foo."""
            return 'foo-%s' % self.locale

        def do_something(self):
            with self.override_locale('ru'):
                self.get_foo()
                return self

    f = Foo()
    r = f.do_something()
    assert r.get_foo() == 'foo-ru'



# Generated at 2022-06-23 21:05:39.992358
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'

    provider = BaseDataProvider(locale='uk-ua')
    assert provider.get_current_locale() == 'uk-ua'



# Generated at 2022-06-23 21:05:41.777303
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='ru')
    response = provider.get_current_locale()
    answer = 'ru'
    assert response == answer

# Generated at 2022-06-23 21:05:43.370329
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'



# Generated at 2022-06-23 21:05:50.206888
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    obj = BaseDataProvider()
    assert obj._datafile == ''
    assert obj.locale == "en"
    assert obj.seed is None
    assert obj.random.randint(0,100) == obj.random.randint(0,100)
    obj.reseed()
    assert obj.random.randint(0,100) != obj.random.randint(0,100)
    assert obj._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:05:51.896017
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
    assert b.random is random


# Generated at 2022-06-23 21:06:01.876955
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    import pytest
    from mimesis.builtins import Generic
    from mimesis.exceptions import NonSupportedLanguageCodeError
    from mimesis.providers.base import BaseDataProvider

    generic = Generic('en')
    assert generic.locale == 'en'
    assert generic._datafile == 'generic.json'
    assert len(generic._data) != 0

    data_provider = BaseDataProvider(locale='ru')
    assert data_provider.locale == 'ru'
    assert data_provider._datafile == ''

    with pytest.raises(UnsupportedLocale):
        BaseDataProvider(locale='abcd')

    with pytest.raises(NonSupportedLanguageCodeError):
        BaseDataProvider(locale='en', lang_code='abcd')


# Generated at 2022-06-23 21:06:06.329830
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    # test for property locale
    assert hasattr(provider, 'locale')

    # test for method pull
    assert hasattr(provider, '_pull')

    # test for method get_current_locale
    assert hasattr(provider, 'get_current_locale')

    # test for method _override_locale
    assert hasattr(provider, '_override_locale')

    # test for method override_locale
    assert hasattr(provider, 'override_locale')

# Generated at 2022-06-23 21:06:07.917412
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bf = BaseProvider()
    assert isinstance(bf.__str__(), str)



# Generated at 2022-06-23 21:06:09.526828
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    assert 1 == 1

# Generated at 2022-06-23 21:06:11.403607
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()
    assert str(base_data_provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:06:13.544339
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    s = BaseProvider(seed=1)
    assert isinstance(s.seed, int)



# Generated at 2022-06-23 21:06:16.465065
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for BaseDataProvider.__str__()."""

    provider = BaseDataProvider()
    temp = provider.__str__()
    assert isinstance(temp, str)



# Generated at 2022-06-23 21:06:18.874386
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    # It should return str with class name and locale
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:06:22.879132
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # import random
    # random.random = lambda: 0.10105193450790906
    # r = Random()
    # r.random()
    # r.seed(1)
    # r.random()
    pass

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:06:30.104096
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # declarative test
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == locales.EN

    # declarative test
    bdp = BaseDataProvider(locales.RU)
    assert bdp.get_current_locale() == locales.RU

    # declarative test
    bdp = BaseDataProvider(locales.JAPANESE)
    assert bdp.get_current_locale() == locales.JAPANESE

    # declarative test
    bdp = BaseDataProvider(locales.DEFAULT_LOCALE)
    assert bdp.get_current_locale() == locales.EN

    # declarative test
    bdp = BaseDataProvider(locales.EN)
    assert bdp.get_current_locale() == locales

# Generated at 2022-06-23 21:06:35.125477
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check method override_locale of class BaseDataProvider.

    :return: True if test passed, False if there has been an error.
    """
    with BaseDataProvider(locale='en') as p:
        with p.override_locale(locale='ru'):
            pass
        assert p.locale == 'en'
    return True

# Generated at 2022-06-23 21:06:36.843505
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == "BaseProvider"


# Generated at 2022-06-23 21:06:47.700630
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person as Parent
    from mimesis.providers.person import Person as Child
    en_provider = Person(locale='en')
    print(en_provider.get_current_locale())

    # locale is en
    parent_locale = Person(locale='en')
    parent_name = parent_locale.full_name(gender=Gender.FEMALE)

    with parent_locale.override_locale('ru'):
        # locale is changed to ru
        child_locale = Person()
        child_name = child_locale.full_name(gender=Gender.FEMALE)

    # locale is en

# Generated at 2022-06-23 21:06:50.928540
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    DP = BaseDataProvider()
    assert DP
    assert DP.locale == locales.EN
    assert DP.seed is None


# Generated at 2022-06-23 21:06:52.607801
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider.__init__.__code__.co_argcount == 3


# Generated at 2022-06-23 21:06:54.665104
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # TODO: Add test
    pass



# Generated at 2022-06-23 21:07:03.462530
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # {}
    dp_obj = BaseDataProvider()
    assert dp_obj.get_current_locale() == locales.DEFAULT_LOCALE

    # {'locale': None}
    dp_obj = BaseDataProvider(locale=None)
    assert dp_obj.get_current_locale() == locales.DEFAULT_LOCALE

    # {'locale': <random_locale>}
    dp_obj = BaseDataProvider(locale='zz')
    assert dp_obj.get_current_locale() == 'zz'

# Generated at 2022-06-23 21:07:07.646500
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestMeta(type):
        def __str__(cls):
            return 'TestMeta'
    class Test(BaseDataProvider, metaclass=TestMeta):
        pass
    obj = Test()
    assert str(obj) == 'TestMeta <en>'
    obj = Test(locale='ru')
    assert str(obj) == 'TestMeta <ru>'


# Generated at 2022-06-23 21:07:15.033702
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    class TestBaseProvider(BaseProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)

    tbp = TestBaseProvider()
    assert isinstance(tbp.random, Random)
    assert tbp.seed is not None

    tbp2 = TestBaseProvider(seed='spam')
    assert tbp.random is not tbp2.random
    assert tbp.seed is not tbp2.seed
    assert tbp.seed is None
    # Seems that the Random constructor doesn't check the seed
    assert tbp2.seed != tbp2.random.seed


# Generated at 2022-06-23 21:07:17.983597
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None

    provider = BaseProvider(seed=42)
    assert provider.seed == 42


# Generated at 2022-06-23 21:07:21.763525
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_base_provider = BaseProvider()
    assert test_base_provider.seed is None, "seed is not None"
    assert test_base_provider.random is random, "random is not random"


# Generated at 2022-06-23 21:07:24.978523
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.providers import Person, Datetime
    p = Person()
    d = Datetime()
    print(p.full_name())
    print(d.datetime())


# Generated at 2022-06-23 21:07:32.230462
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit tests for class BaseDataProvider"""
    data_provider = BaseDataProvider()
    assert data_provider.locale == 'en'
    assert data_provider.seed == None
    assert isinstance(data_provider.random, Random)
    assert data_provider._data == {}
    assert data_provider._datafile == ''
    # TODO
    assert data_provider._data_dir == './mimesis/data'

    data_provider = BaseDataProvider(locale='en')
    assert data_provider.locale == 'en'
    assert data_provider.seed == None
    assert isinstance(data_provider.random, Random)
    assert data_provider._data == {}
    assert data_provider._datafile == ''
    # TODO
    assert data_prov

# Generated at 2022-06-23 21:07:34.456959
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    result = BaseProvider()
    result.reseed()
    assert result.seed != None


# Generated at 2022-06-23 21:07:37.847974
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider('123')
    print(b.seed)
    print(b.random)
    print(b.reseed('345'))
    print(b.seed)
    print(b.random)


# Generated at 2022-06-23 21:07:41.517720
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider
    assert provider.random is random
    assert provider.seed is None
    provider = BaseProvider(seed=123)
    assert provider.random
    assert provider.random is not random
    assert provider.seed == 123



# Generated at 2022-06-23 21:07:43.926272
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    dp = BaseProvider()
    result = dp.__str__()
    assert result == 'BaseProvider'

# Generated at 2022-06-23 21:07:51.652647
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Проверка создания контекстного менеджера «override_locale»
    # для метода «Gender.generate» класса «Provider» при отсутствии целевого атрибута.
    from mimesis.builtins import Gender

    provider = Gender()
    with provider.override_locale(locales.RU):
        assert provider.generate() == 'мужской'

    # Проверка создания контекс

# Generated at 2022-06-23 21:07:54.643602
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.base import BaseDataProvider

    bdp = BaseDataProvider('ru')
    assert str(bdp.get_current_locale()) == 'ru'

# Generated at 2022-06-23 21:07:57.580281
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method ``__str__`` of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:59.558555
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:08:02.280058
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()

    provider.reseed(seed=42)
    assert provider.seed == 42

    provider.reseed()
    assert provider.seed is None

    # Unit test for method str of class BaseProvider

# Generated at 2022-06-23 21:08:04.323821
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    a = BaseDataProvider()
    assert a.get_current_locale() == 'en'

# Generated at 2022-06-23 21:08:06.135357
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 10
    p = BaseProvider(10)
    assert p.reseed(seed) == None


# Generated at 2022-06-23 21:08:12.621769
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test."""
    def prov_with_locale(seed, default_locale):
        class TestClass(BaseDataProvider):
            def __init__(self, locale=None, seed=None):
                super().__init__(locale=locale, seed=seed)

            def test_method(self):
                return self.get_current_locale()

        return TestClass(locale=default_locale, seed=seed)

    with prov_with_locale(123, locales.EN) as prov:
        assert prov.test_method() == locales.EN
        with prov.override_locale(locale=locales.DE):
            assert prov.test_method() == locales.DE

        assert prov.test_method() == locales.EN


# Generated at 2022-06-23 21:08:19.071195
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for __str__ method in BaseDataProvider class."""
    from mimesis.builtins import Generic
    g = Generic()
    assert str(g) == "Generic <en>"

    assert str(g.override_locale('ru').__enter__()) == "Generic <ru>"
    assert str(g) == "Generic <en>"



# Generated at 2022-06-23 21:08:21.300497
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    r = BaseProvider(seed = 5)
    assert r.random.randint(1,10) == 7

if __name__ == '__main__':
    test_BaseProvider()