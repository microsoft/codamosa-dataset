

# Generated at 2022-06-23 20:58:22.355385
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider('fr')
    assert base_provider.seed == 'fr'


# Generated at 2022-06-23 20:58:28.730112
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'
    assert str(b) == 'BaseProvider'


# Generated at 2022-06-23 20:58:30.115158
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-23 20:58:33.703290
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseProvider()
    b = BaseDataProvider(locale='ru-ru')
    assert a.seed is None
    assert b.locale == 'ru-ru'
    assert b.get_current_locale() == 'ru-ru'



# Generated at 2022-06-23 20:58:35.450807
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()

    assert base_data_provider.__str__() == 'BaseDataProvider <en>'
    

# Generated at 2022-06-23 20:58:39.241017
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    in_str = provider.__str__()
    assert str(in_str) == 'BaseDataProvider <en>'
    provider.__init__(locale='ru')
    in_str = provider.__str__()
    assert str(in_str) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 20:58:44.417754
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit-test for method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider()
    result = provider.__str__()
    assert isinstance(result, str)
    # print(result)
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:58:46.550030
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    test_provider = BaseProvider()
    assert str(test_provider) == 'BaseProvider'

# Generated at 2022-06-23 20:58:48.539141
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.schema import Field
    f = Field('name')
    assert str(f) == 'Field'

# Generated at 2022-06-23 20:58:58.747415
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import pytest
    from mimesis.base import BaseProvider
    from mimesis.builtins import Code
    from mimesis.enums import Gender

    class Foo(BaseProvider):
        pass

    foo = Foo()
    code = Code()
    assert foo.get_current_locale() == locales.DEFAULT_LOCALE
    assert code.get_current_locale() == locales.DEFAULT_LOCALE
    with pytest.raises(ValueError):
        with Code().override_locale('ru'):
            pass

    gender = Gender.MALE
    assert Gender.MALE.value == 'male'

# Generated at 2022-06-23 20:59:00.423866
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider()
    assert str(data_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:06.495775
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=None)
    print(bp.reseed(seed=None))
    print(bp.reseed(seed=12345))
    print(bp.reseed(seed=12346))
    print(bp.reseed(seed=12347))
    print(bp.reseed(seed=12348))
    print(bp.reseed(seed=12345))


# Generated at 2022-06-23 20:59:07.865162
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'

# Generated at 2022-06-23 20:59:13.161705
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__(): 
    test_BaseProvider = BaseProvider(seed = None)
    assert test_BaseProvider.__str__() == "BaseProvider"
    assert test_BaseProvider.__str__() != ""
    assert test_BaseProvider.__str__() != "BaseProvider<BaseProvider>"


# Generated at 2022-06-23 20:59:22.450028
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.providers.address import Address

    address = Address(locale='de')

    assert address.locale == 'de'
    assert isinstance(address.city(), str)
    assert isinstance(address.city('en'), str)

    assert address.locale == 'de'
    with address.override_locale('en'):
        assert address.locale == 'en'
        assert isinstance(address.city(), str)
        assert isinstance(address.city('de'), str)

    assert address.locale == 'de'
    assert isinstance(address.city(), str)
    assert isinstance(address.city('en'), str)

# Generated at 2022-06-23 20:59:24.521371
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert isinstance(bdp._data, Dict)
    assert bdp._datafile == ''

# Generated at 2022-06-23 20:59:28.253731
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__ of ``BaseDataProvider`` class."""
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 20:59:39.819958
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address

    address = Address(locale='en')
    with address.override_locale() as address_ru:
        assert address_ru.get_current_locale() == 'en'
        assert address.get_current_locale() == 'en-us'
    assert address.get_current_locale() == 'en-us'

    with address.override_locale(locale='ru') as address_ru:
        assert address_ru.get_current_locale() == 'ru'

    assert address.get_current_locale() == 'en-us'


# Generated at 2022-06-23 20:59:47.401748
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # 1. BaseDataProvider.get_current_locale()
    # Should pass all test cases
    try:
        locale = 'ru'
        dataprovider = BaseDataProvider(locale=locale)
        assert dataprovider.get_current_locale() == locale
        locale = ''
        dataprovider = BaseDataProvider(locale=locale)
        assert dataprovider.get_current_locale() == locales.DEFAULT_LOCALE
        return True
    except Exception:
        return False


# Generated at 2022-06-23 20:59:49.268448
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:51.438359
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    s = bdp.__str__()
    assert s == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:58.425503
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed='test')

    assert p.random.randint(1, 100) == 24
    assert p.random.randint(1, 100) == 16
    assert p.random.randint(1, 100) == 26
    assert p.random.randint(1, 100) == 8

    p.reseed('12345')

    assert p.random.randint(1, 100) == 58
    assert p.random.randint(1, 100) == 26
    assert p.random.randint(1, 100) == 9
    assert p.random.randint(1, 100) == 29


# Generated at 2022-06-23 21:00:01.954755
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert bdp.__str__() == "BaseDataProvider <en>"


# Generated at 2022-06-23 21:00:04.670198
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    myObject = BaseDataProvider(locale='en', seed=None)
    assert myObject
    assert myObject.locale == 'en'


# Generated at 2022-06-23 21:00:06.905989
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random.seed(0)
    print(random.random())
    print(random.random())
    print(random.random())


# Generated at 2022-06-23 21:00:10.222767
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import os
    seed = os.urandom(32)
    a1 = BaseProvider(seed=seed)
    a2 = BaseProvider(seed=seed)

    assert a1.random.random() == a2.random.random()

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:00:12.238919
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider is not None


# Generated at 2022-06-23 21:00:14.652158
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_base_provider = BaseProvider()
    assert type(test_base_provider.random) == mimesis.random.Random


# Generated at 2022-06-23 21:00:16.769291
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider constructor."""
    provider = BaseDataProvider()
    assert provider.locale == 'en'

# Generated at 2022-06-23 21:00:19.473893
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(None)
    assert provider.seed is not None



# Generated at 2022-06-23 21:00:27.950308
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class BaseProviderF(BaseProvider): pass
    class BaseDataProviderF(BaseDataProvider): pass
    class BaseSpecsProviderF(BaseDataProvider): pass

    base_provider = BaseProviderF()
    base_data_provider = BaseDataProviderF()
    base_specs_provider = BaseSpecsProviderF()

    assert base_provider.__str__() == 'BaseProviderF'
    assert base_data_provider.__str__() == 'BaseDataProviderF <en>'
    assert base_specs_provider.__str__() == 'BaseSpecsProviderF <en>'


# Generated at 2022-06-23 21:00:30.245443
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """
    Check the method BaseProvider.__str__().
    """
    assert str(BaseProvider(seed = None)) == 'BaseProvider'

# Generated at 2022-06-23 21:00:33.326448
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.RU
    a = BaseDataProvider(locale)
    assert a.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:00:36.045281
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    B = BaseProvider()
    assert B.seed is None
    B.seed = 0
    assert B.seed == 0

# Generated at 2022-06-23 21:00:44.330966
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_instance = BaseDataProvider()
    assert test_instance.locale == locales.DEFAULT_LOCALE, "Get Default Locale"

    test_instance = BaseDataProvider(locale=locales.EN)
    assert test_instance.locale == locales.EN, "Get En Locale"

    assert test_instance.get_current_locale() == locales.EN, "Get En Locale"

    test_instance = BaseDataProvider(locale=locales.RU)
    assert test_instance.locale == locales.RU, "Get Ru Locale"

    assert test_instance.get_current_locale() == locales.RU, "Get Ru Locale"


# Generated at 2022-06-23 21:00:52.586252
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Create two instances of BaseProvider
    provider = BaseProvider()
    other_provider = BaseProvider()
    # Reseed the first instance with a seed
    seed = 0.98765432
    provider.reseed(seed)
    # Test whether random items of random
    # of both instances are different
    provider_random_item = get_random_item(range(1, 10), provider.random)
    other_provider_random_item = get_random_item(range(1, 10), other_provider.random)
    assert provider_random_item != other_provider_random_item

# Generated at 2022-06-23 21:00:53.611513
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    pass


# Generated at 2022-06-23 21:00:56.452606
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    provider.reseed()
    assert provider.seed is not None
    assert provider.random is not random



# Generated at 2022-06-23 21:01:01.199746
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider.
    """
    assert BaseDataProvider().get_current_locale() == locales.EN

    provider = BaseDataProvider("fr")
    provider._datafile = "lorem.json"
    provider._pull()
    assert provider.get_current_locale() == "fr"

# Generated at 2022-06-23 21:01:02.815314
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data = BaseDataProvider(seed=1)
    assert getattr(data, 'locale')



# Generated at 2022-06-23 21:01:06.271640
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obs=BaseProvider(seed=10)
    obs.reseed(seed=10)
    obs.reseed(seed=20)
    obs.reseed(seed=None)


# Generated at 2022-06-23 21:01:08.973244
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

    provider.locale = 'ru'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:01:11.206208
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:01:14.209799
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert isinstance(str(bdp), str)

# Generated at 2022-06-23 21:01:24.502995
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test that context manager works correctly"""

    class TestProvider(BaseDataProvider):
        """Test provider"""
        _datafile = 'address.json'

    with TestProvider() as p:
        assert p.locale == 'en'
    with TestProvider.override_locale('ru') as p:
        assert p.locale == 'ru'
    with TestProvider.override_locale('ru-RU') as p:
        assert p.locale == 'ru-ru'
    with TestProvider.override_locale('ru-UA') as p:
        assert p.locale == 'ru-ua'
    with TestProvider.override_locale('ru-BY') as p:
        assert p.locale == 'ru-by'

# Generated at 2022-06-23 21:01:28.614308
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    assert dp.__str__() == 'BaseDataProvider <en>'
    dp = BaseDataProvider(locale=locales.RU)
    assert dp.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:01:39.221208
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers.food import Food
    from mimesis.enums import Alignment, Gender
    food = Food()
    food.reseed(seed=123)
    assert food.random.randint(0, 100) == 37  #random.seed(seed=123)
    assert food.random.choice('123456789') == '2'
    assert food.random.choice(['1', '2', '3']) == '3'
    assert food.random.choices(['1', '2', '3'], k=1) == ['3']
    assert food.random.choices(['1', '2', '3'], [0.5, 0.25, 0.25], k=1) == ['1']

# Generated at 2022-06-23 21:01:47.987990
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    with BaseDataProvider() as pdp:
        assert str(pdp) == '<BaseDataProvider <en>>'
        assert str(pdp) == '<BaseDataProvider <en>>'

        with pdp.override_locale('ru') as p:
            assert str(p) == '<BaseDataProvider <ru>>'
            assert str(p) == '<BaseDataProvider <ru>>'

        assert str(pdp) == '<BaseDataProvider <en>>'
        assert str(pdp) == '<BaseDataProvider <en>>'

# Generated at 2022-06-23 21:01:50.995118
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:01:53.816765
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.data import __DIR__

    dp = BaseDataProvider()
    assert dp.locale == 'en'
    assert dp._data_dir == __DIR__


# Generated at 2022-06-23 21:01:56.254680
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Foo(BaseDataProvider):
        def __init__(self):
            pass

    f = Foo()
    assert f.get_current_locale() == 'en'



# Generated at 2022-06-23 21:01:57.430982
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test of method get_current_locale of class BaseDataProvider."""
    pass

# Generated at 2022-06-23 21:01:59.183069
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers import Address
    instance = Address()
    assert instance.get_current_locale() == 'en'

# Generated at 2022-06-23 21:02:03.373444
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    data = []
    for i in range(0, 10):
        bp = BaseProvider()
        data.append(bp.random())

    data_alt = []
    bp = BaseProvider()
    bp.reseed(12345)
    for i in range(0, 10):
        data_alt.append(bp.random())

    assert data_alt == data

# Generated at 2022-06-23 21:02:08.477388
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    mimesis_DefaultLocaleProvider = mimesis.builtins.DefaultLocaleProvider()
    with mimesis_DefaultLocaleProvider.override_locale(locale='ru'):
        mimesis_DefaultLocaleProvider.get_current_locale()
    # Expected to return 'en'
    mimesis_DefaultLocaleProvider.get_current_locale()

# Generated at 2022-06-23 21:02:11.487550
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.DEFAULT_LOCALE
    provider = BaseDataProvider(locale)
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    

# Generated at 2022-06-23 21:02:14.134836
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for BaseDataProvider.__str__.
    """
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:02:15.962975
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider
    assert provider.random


# Generated at 2022-06-23 21:02:18.316407
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p = BaseDataProvider('ru')
    locale = p.get_current_locale()
    assert locale == 'ru'


# Generated at 2022-06-23 21:02:20.368010
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider"""
    assert (str(BaseDataProvider()) == "BaseDataProvider <en>")

# Generated at 2022-06-23 21:02:28.413875
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test the BaseProvider class."""
    from mimesis.enums import Gender, PersonField, SocialPlatform
    from mimesis.providers.person import Person
    from mimesis.schema import Field, Schema

    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert provider.seed is None

    provider = BaseProvider(seed=1234)
    assert isinstance(provider, BaseProvider)
    assert provider.seed == 1234

    person = Person()
    assert person._validate_enum(Gender.MALE, Gender) == 'male'
    assert person._validate_enum(PersonField.NAME, PersonField) == 'name'
    assert person._validate_enum(SocialPlatform.ANY, SocialPlatform) == 'any'

    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:02:31.184121
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    result = str(provider)
    assert result == 'BaseProvider'


# Generated at 2022-06-23 21:02:41.249466
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from random import randint
    from string import ascii_letters
    from mimesis.builtins import Fashion
    from mimesis.enums import Gender

    class RandomProvider(BaseProvider):
        def __init__(self, seed=randint(1, 10 ** 8)):
            super().__init__(seed=seed)

        def __str__(self):
            return 'Random Provider'

    random_provider = RandomProvider()
    assert str(random_provider) == 'Random Provider'

    class RandomDataProvider(BaseDataProvider):
        def __init__(self, seed=randint(1, 10 ** 8)):
            super().__init__(seed=seed)

        def __str__(self):
            return 'Random Data Provider'

    random_data_provider = RandomDataProvider()
    assert str

# Generated at 2022-06-23 21:02:44.530902
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider(locale='en')
    assert bdp.__str__() == 'BaseDataProvider <en>'
    bdp_ru = BaseDataProvider(locale='ru')
    assert bdp_ru.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:02:52.221564
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            super().__init__()
            self.locale = locale

    provider = TestProvider()

    with provider.override_locale(locale=locales.RU) as provider_ru:
        assert provider_ru.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

if __name__ == "__main__":
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:02:57.511748
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider._data == {}
    assert provider._data_dir == "C:/Users/Sebastian/PycharmProjects/mimesis/mimesis/data"

    provider._setup_locale('en')
    assert provider.locale == 'en'


# Generated at 2022-06-23 21:03:04.880518
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Create BaseProvider object
    # Initialize attributes
    # Seed for random
    seed = 23456
    base_provider_object = BaseProvider(seed)
    # Check attributes of base_provider_object
    assert base_provider_object.seed == seed
    assert base_provider_object.random is not random
    assert isinstance(base_provider_object.random, Random)
    assert base_provider_object.random.seed == seed


# Generated at 2022-06-23 21:03:06.383009
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method BaseDataProvider._str_."""
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

if __name__ == '__main__':
    test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:03:07.304848
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:03:10.298843
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    provider.reseed()
    assert provider.seed is not None
    assert provider.random is not random


# Generated at 2022-06-23 21:03:16.420216
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    c = BaseDataProvider()
    class D(BaseDataProvider):
        def get_current_locale(self):
            return super().get_current_locale()

    d = D()
    with c.override_locale('ru'):
        print(c.get_current_locale())
    with d.override_locale('ru'):
        print(d.get_current_locale())

test_BaseDataProvider_override_locale()

# Generated at 2022-06-23 21:03:25.405314
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp1 = BaseProvider(seed=12345)
    assert bp1.seed == 12345, (
        "The reseed method does not change the seed value "
        "(wrong value)")
    bp2 = BaseProvider(seed=12345)
    assert bp2.seed == 12345, (
        "The reseed method does not change the seed value "
        "(wrong value)")
    assert bp1.random != bp2.random, (
        "The reseed method does not change the seed value"
        "(both Random instances are the same)")
    assert bp1.random.reseed(12345) == bp2.random.reseed(12345), (
        "The reseed method does not change the seed value"
        "(both Random instances are the same)")


# Generated at 2022-06-23 21:03:27.632741
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Enum test
    provider = BaseProvider()
    val = str(provider)
    assert val == 'BaseProvider'


# Generated at 2022-06-23 21:03:33.956939
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():  # pylint: disable=W0613,W0603
    from mimesis.providers import Generic
    import math  # pylint: disable=W0403

    seed = math.pi

    gp = Generic(seed=seed)
    assert all(gp.random.randint(0, 100) for _ in range(10))

    gp.reseed('abc')
    assert not all(gp.random.randint(0, 100) for _ in range(10))

    gp.reseed(seed)
    assert all(gp.random.randint(0, 100) for _ in range(10))

# Generated at 2022-06-23 21:03:38.724334
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)

    provider = Provider()
    with provider.override_locale('ru') as _provider:
        assert provider.get_current_locale() == 'ru'
        assert _provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == locales.EN
    assert provider == _provider



# Generated at 2022-06-23 21:03:44.651980
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    locale = locales.RU
    provider_test = BaseDataProvider(locale=locale, seed=123)
    assert provider_test.get_current_locale() != locales.EN
    assert provider_test.get_current_locale() == locale

# Generated at 2022-06-23 21:03:47.204698
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pr = BaseProvider(seed=None)
    assert pr.seed is None
    assert pr.random is random


# Generated at 2022-06-23 21:03:52.072717
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """The test method str()."""
    provider_class = BaseDataProvider
    test_data = locales.SUPPORTED_LOCALES
    for locale in test_data:
        provider = provider_class(locale=locale)
        assert str(provider) == 'BaseDataProvider <{}>'.format(locale)

# Generated at 2022-06-23 21:03:58.991835
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis import Person
    from mimesis import Lorem
    from mimesis import Internet
    pp = Person(seed=43)
    ip=Internet(seed=44)
    lr=Lorem(seed=45)
    pp.reseed(43)
    ip.reseed(44)
    lr.reseed(45)
    # seeds of pp,ip,lr are equal to 43,44,45 respectively
    pp.reseed()
    ip.reseed()
    lr.reseed()
    # seeds of pp,ip,lr are not equal to 43,44,45 respectively


# Generated at 2022-06-23 21:04:02.015010
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Person
    from mimesis.providers.enumeration import Enumeration
    p = Person()
    assert str(p) == 'Person <en>'
    e = Enumeration()
    assert str(e) == 'Enumeration'

# Generated at 2022-06-23 21:04:06.995476
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale='en', seed=None)
    assert bdp.locale == 'en'
    assert bdp.seed is None
    assert bdp._data == {}
    assert bdp._datafile == ''


# Generated at 2022-06-23 21:04:13.670066
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MockBaseDataProvider(BaseDataProvider):
        pass

    provider = MockBaseDataProvider()
    with provider.override_locale(locale='xx') as p:
        assert p.get_current_locale() == 'xx'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    provider.locale = 'xx'
    with provider.override_locale(locale='yy') as p:
        assert p.get_current_locale() == 'yy'

    assert provider.get_current_locale() == 'xx'

# Generated at 2022-06-23 21:04:14.886038
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert(str(BaseDataProvider) == 'BaseDataProvider <en>')


# Generated at 2022-06-23 21:04:23.779788
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Call init method of BaseProvider class
    provider = BaseProvider(seed='123')

    # Get value from seed attribute of provider
    print("seed value is ", provider.seed)

    # Check value of seed attribute is equal to '123'
    assert (provider.seed == '123')

    # Call reseed method of BaseProvider class
    provider.reseed()

    # Get value from seed attribute of provider
    print("seed value is ", provider.seed)

    # Check value of seed attribute is equal to provider.random.get_seed()
    assert (provider.seed == provider.random.get_seed())


# Generated at 2022-06-23 21:04:35.097970
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    sk = BaseDataProvider(locale='sk')
    en = BaseDataProvider(locale='en')
    fr = BaseDataProvider(locale='fr')
    it = BaseDataProvider(locale='it')

    # Unit test for method get_current_locale of class BaseDataProvider

    def test_BaseDataProvider_get_current_locale():
        sk = BaseDataProvider(locale='sk')
        en = BaseDataProvider(locale='en')
        fr = BaseDataProvider(locale='fr')
        it = BaseDataProvider(locale='it')

        assert sk.get_current_locale() == 'sk'
        assert en.get_current_locale() == 'en'
        assert fr.get_current_locale() == 'fr'

# Generated at 2022-06-23 21:04:39.283890
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == "BaseProvider"
    assert bp.__str__() == "BaseProvider"
    assert bp.__str__() == "BaseProvider"


# Generated at 2022-06-23 21:04:41.761156
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    global a,b
    a = BaseDataProvider(locale='en', seed=12345)
    b = BaseProvider(seed=12345)


# Generated at 2022-06-23 21:04:50.640584
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method."""
    from mimesis import Address

    provider = Address()
    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'en'

    with provider.override_locale() as p:
        assert p.get_current_locale() == 'en'
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:04:52.983149
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Create instance of BaseProvider class and pass seed."""
    assert isinstance(BaseProvider(seed=1234), BaseProvider)


# Generated at 2022-06-23 21:04:57.087669
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 10
    sample = BaseProvider(seed)
    assert sample.seed == seed
    assert sample.random is not random
    sample.reseed(seed)
    assert sample.seed == seed
    assert sample.random is not random

# Generated at 2022-06-23 21:05:00.064312
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    assert p.seed is None
    p.reseed(seed=12)
    assert p.seed == 12
    assert p.random != random


# Generated at 2022-06-23 21:05:04.701711
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.identifiers import Identifiers

    local_int = Internet(seed=12345)
    print(local_int)
    print(local_int.seed)
    local_int.url()
    local_int.url(categories=["education"])
    local_int.url(category=["education"])
    local_int.mac_address()
    local_int.ipv4()
    local_int.ipv6()

    local_iden = Identifiers(seed=12345)
    print(local_iden)
    local_iden.iban()
    local_iden.swift_bic()
    local_iden.credircard_number()

    result_seed = local_

# Generated at 2022-06-23 21:05:07.400835
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    m = BaseProvider()
    assert str(m) == 'BaseProvider'


# Generated at 2022-06-23 21:05:08.591477
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    result = BaseDataProvider().__str__()
    assert result == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:05:12.475089
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Arrange
    base = BaseDataProvider(locale=locales.EN)

    # Act
    result = base.get_current_locale()

    # Assert
    assert result == locales.EN

# Generated at 2022-06-23 21:05:14.832495
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider('ru')
    assert data_provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:05:19.816138
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider class."""
    prov = BaseDataProvider()
    assert prov.locale == 'en'
    assert prov.random is not None
    assert prov.seed is None
    prov = BaseDataProvider('en')
    assert prov.locale == 'en'
    assert prov.random is not None
    assert prov.seed is None


# Generated at 2022-06-23 21:05:26.590135
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis.builtins import Address
    from time import time

    seed_a = int(time() * 100)
    provider = Address(seed=seed_a)
    provider2 = Address(seed=seed_a)

    seed_b = int(time() * 100)
    provider3 = Address(seed=seed_b)

    assert provider.ipsum() == provider2.ipsum()
    assert provider.ipsum() != provider3.ipsum()

    seed_c = int(time() * 100)
    provider.reseed(seed=seed_c)

    assert provider.ipsum() != provider2.ipsum()
    assert provider.ipsum() != provider3.ipsum()
    assert provider3.ipsum() == provider3.ipsum()
    

# Generated at 2022-06-23 21:05:36.811599
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print('Testing BaseDataProvider...', end='')

    seed = '123'
    locale = locales.EN
    assert BaseDataProvider(seed=seed, locale=locale) is not None
    assert BaseDataProvider(locale=locale) is not None
    assert BaseDataProvider(seed=seed) is not None
    assert BaseDataProvider(seed) is not None
    assert BaseDataProvider(seed=seed, locale=locale).get_current_locale() == locale
    assert BaseDataProvider(seed, locale).get_current_locale() == locale
    assert BaseDataProvider(locale).get_current_locale() == locale
    assert BaseDataProvider(locale=locale).get_current_locale() == locale
    assert BaseDataProvider(seed=seed).get_current_locale() == locales.DEFAULT

# Generated at 2022-06-23 21:05:39.014389
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed is None
    assert obj.random == random
    assert type(obj.random) is Random


# Generated at 2022-06-23 21:05:50.072226
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider1(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale, seed)

        def __str__(self):
            return "Provider1"

    class Provider2(BaseDataProvider):
        def __init__(self, locale, seed):
            super().__init__(locale, seed)

        def __str__(self):
            return "Provider2"

    provider = Provider1("en")
    assert provider.get_current_locale() == "en"
    with provider.override_locale("zh"):
        assert provider.get_current_locale() == "zh"


# Generated at 2022-06-23 21:05:55.237559
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import RussiaSpecProvider
    p = RussiaSpecProvider()
    assert p.__str__() == 'RussiaSpecProvider <ru>'
    assert p.locale == 'ru'
    assert isinstance(p._data, Dict)


# Generated at 2022-06-23 21:05:59.341620
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    test_seed = 'test seed'
    provider = BaseProvider(seed=test_seed)

    assert provider.seed == test_seed
    assert provider is not None
    provider.reseed(seed='test seed')
    assert provider.seed == test_seed


# Generated at 2022-06-23 21:06:01.866371
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Nothing to test
    assert True


# Generated at 2022-06-23 21:06:03.263192
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale='en') != None


# Generated at 2022-06-23 21:06:08.418257
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)

    provider = TestDataProvider()
    assert str(provider) == 'TestDataProvider <en>'

    provider = TestDataProvider(locale=locales.RU)
    assert str(provider) == 'TestDataProvider <ru>'

# Generated at 2022-06-23 21:06:10.348389
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    base.seed = 1
    base.reseed(1)
    assert base.seed == 1


# Generated at 2022-06-23 21:06:12.244134
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    p = Person()
    assert str(p) == 'Person'



# Generated at 2022-06-23 21:06:13.586154
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-23 21:06:16.079328
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test ``__str__`` method of ``BaseDataProvider`` class."""
    expected = 'BaseProvider <en>'
    bp = BaseDataProvider()
    assert str(bp) == expected



# Generated at 2022-06-23 21:06:17.454425
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:06:26.713632
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    with Person('ru') as p:
        p.seed = 1234
        a = p.gender()

    with Person('ru') as p:
        p.seed = 1234
        b = p.gender()

    t = p.random.seed(1234)

    with Provider('ru') as p:
        p.seed = 1234
        a = p.random.randint(1, 2)

    with Provider('ru') as p:
        p.seed = 1234
        b = p.random.randint(1, 2)

    t = p.random.seed(1234)

    with Person('en') as p1:
        l = p1.get

# Generated at 2022-06-23 21:06:30.089158
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.locale == 'en'
    assert provider.random is not random
    

# Generated at 2022-06-23 21:06:31.314939
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # BaseDataProvider().__str__()
    pass

# Generated at 2022-06-23 21:06:32.788218
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'

# Generated at 2022-06-23 21:06:36.614864
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    assert b.locale == "en"
    assert isinstance(b.random, Random)
    assert isinstance(b._data, dict)
    assert isinstance(b._data_dir, Path)
    assert b._datafile == ""


# Generated at 2022-06-23 21:06:39.894864
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider(locale='ru')
    assert data_provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:06:42.737123
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider.__doc__
    assert BaseProvider.__init__.__doc__
    assert isinstance(BaseProvider(), BaseProvider)

# Generated at 2022-06-23 21:06:45.998891
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    BDP = BaseDataProvider(locale='ru')
    assert BDP.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:06:54.873807
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.enums import Gender
    from mimesis.enums import PersonTitle
    from mimesis.enums import Title
    from mimesis.seed import Seed
    from mimesis.builtins import Person
    from mimesis.builtins import USAFederal
    from mimesis.builtins import CanadaFederal
    dp = BaseProvider()
    assert type(dp) is BaseProvider
    assert type(dp.seed) is Seed
    assert len(str(dp)) == 17
    assert type(dp.random) is Random
    dp.reseed(123)
    assert len(str(dp.seed)) == 20
    assert len(str(dp.random)) == 13

# Generated at 2022-06-23 21:07:00.694412
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # test_no_seed
    base_provider = BaseProvider()
    assert base_provider is not None

    # test_with_seed
    test_seed = 0
    base_provider = BaseProvider(seed=test_seed)
    assert base_provider is not None
    assert base_provider.seed == test_seed


# Generated at 2022-06-23 21:07:02.672182
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    instance = BaseDataProvider(locale='en')
    assert instance.get_current_locale() == 'en'


# Generated at 2022-06-23 21:07:03.601040
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    i = BaseProvider(seed = None)
    assert i.seed == None


# Generated at 2022-06-23 21:07:14.236002
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Class for test."""

        def get_random_value_from_dict(self, data: dict) -> int:
            """Get random value from dict.

            :param data: Dict.
            :return: int.
            """
            return self.random.randint(0, len(data) - 1)

        def get_data(self, data: dict) -> Any:
            """Get data from dict.

            :param data: Data dict.
            :return: Value.
            """
            key = list(data.keys())[self.get_random_value_from_dict(data)]
            return self.random.choice(data[key])


# Generated at 2022-06-23 21:07:23.716355
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    dt = Datetime()
    with dt.override_locale('ru') as dt:
        dt_ru = dt.datetime()

    assert dt_ru.split()[0] == 'среда'

    person = Person()
    with person.override_locale('en') as person:
        person_en = person.full_name()

    assert person_en.split()[1].isalpha()

# Generated at 2022-06-23 21:07:28.455666
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class MyDataProvider(BaseDataProvider):
        pass

    my_data_provider = MyDataProvider()

    assert isinstance(my_data_provider, BaseDataProvider)
    assert isinstance(my_data_provider.seed, str)
    assert isinstance(my_data_provider.random, Random)
    assert isinstance(my_data_provider, BaseProvider)



# Generated at 2022-06-23 21:07:29.849597
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:07:37.672439
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    print("Test case for reseed")
    provider1 = BaseProvider()

    # reseed using the default seed
    provider1.reseed()
    assert provider1.seed != None
    assert provider1.random != random
    print("Successfully reseeded using default seed")

    # reseed using a seed
    provider1.reseed("1")
    assert provider1.seed == "1"
    assert provider1.random != random
    print("Successfully reseeded using a seed")


# Generated at 2022-06-23 21:07:39.275255
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider()

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-23 21:07:41.202332
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    test = BaseProvider()
    name = test.random.name
    test.reseed(1)
    assert name != test.random.name

# Generated at 2022-06-23 21:07:42.899070
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    result = str(p)
    assert result == 'BaseProvider'



# Generated at 2022-06-23 21:07:45.679330
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """ Unit test for method reseed of class BaseProvider """
    provider = BaseProvider()
    provider.reseed(1)

    assert provider.seed == 1
    assert provider.random is not random

    provider.reseed()
    assert provider.seed is None
    assert provider.random is random



# Generated at 2022-06-23 21:07:48.155231
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Arrange
    class Provider(BaseDataProvider):
        """The provider to test."""
        pass

    # Act
    provider = Provider()

    # Assert
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:07:59.710799
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # Non locale dependent provider
    assert str(Person()) == 'Person <en>'

    # Locale dependent provider
    person = Person(locale='ru')
    assert str(person) == 'Person <ru>'
    with person.override_locale('en'):
        assert str(person) == 'Person <en>'

    # Default locale is 'en'
    person = Person(locale='ru_RU')
    assert str(person) == 'Person <ru_RU>'
    with person.override_locale():
        assert str(person) == 'Person <en>'

    # Default locale is 'en'
    person = Person(locale='ru-RU')
    assert str(person)

# Generated at 2022-06-23 21:08:07.043227
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_data(self, key: str) -> Any:
            return self._data.get(key)

        def get_datafile(self) -> str:
            return self._datafile

    test = TestProvider()

    with test.override_locale('xx') as t:
        datafile = t.get_datafile()
        # assert-statement
        assert datafile == 'xx.json'

    datafile = test.get_datafile()
    # assert-statement
    assert datafile == 'en.json'



# Generated at 2022-06-23 21:08:12.174132
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider=BaseDataProvider()
    assert provider.locale=='en'
    # assert provider._pull()=={'Address': {'address_formats': [...], ...},
    # 'Internet': {'domain_suffix': [...]}, 'Lorem': {...}, 'Person': {...},
    # 'Code': {'lorem': {'letters': [...]}}, 'Cryptographic': {...}, 'Files':
    # {'extension': [...]}, 'Numbers': {'cardinal': {'_0_9': [...]}}, 'Unit':
    # {'length': {'_add': {}}}}

test_BaseDataProvider()

# Generated at 2022-06-23 21:08:22.686798
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data = {}
    data['en'] = {'en': {'foo': 'baz'}}
    data['ru'] = {'foo': 'bar'}

    class Provider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._data = data
            self._datafile = 'datafile'
            self.locale = 'en'

        @property
        def _data_dir(self):
            return ''

        def foo(self):
            return self._data[self.locale]['foo']

    provider = Provider()
    assert provider.foo() == 'baz'
    with provider.override_locale('ru') as p:
        assert p.foo() == 'bar'