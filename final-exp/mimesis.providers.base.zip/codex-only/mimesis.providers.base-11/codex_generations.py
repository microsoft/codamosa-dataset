

# Generated at 2022-06-23 20:58:23.551674
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    assert hasattr(b, '_datafile')
    assert hasattr(b, '_data_dir')

# Generated at 2022-06-23 20:58:34.860653
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Is BaseProvider.__str__() work correctly."""
    # Case 1. Default locale.
    my_base_provider = BaseProvider()
    assert str(my_base_provider) == 'BaseProvider'
    # Case 2. Seed.
    my_base_provider = BaseProvider(seed='seed')
    assert str(my_base_provider) == 'BaseProvider'
    # Case 3. Always the same results.
    my_base_provider = BaseProvider(seed='seed')
    my_base_provider2 = BaseProvider(seed='seed')
    assert str(my_base_provider) == str(my_base_provider2)
    # Case 4. Difficult locale.
    my_base_provider = BaseProvider(seed='seed')

# Generated at 2022-06-23 20:58:36.829872
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base = BaseProvider(seed=123)
    assert base.random is not None
    assert base.random.get_seed() == 123



# Generated at 2022-06-23 20:58:42.220444
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed(3)
    print(provider.seed)
    provider.reseed(3)
    print(provider.seed)
    provider.reseed()
    print(provider.seed)


# Generated at 2022-06-23 20:58:44.624411
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(123)
    p.reseed(456)
    assert p.random.seed == 456


# Generated at 2022-06-23 20:58:47.463557
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed is None
    assert obj.random is random
    assert obj.__str__() == "BaseProvider"



# Generated at 2022-06-23 20:58:48.884673
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-23 20:58:53.030113
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    assert dp.__str__() == 'BaseDataProvider <en>'

    dp.locale = 'ru'
    assert dp.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 20:58:58.793138
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    assert str(dp) == 'BaseDataProvider <en>'
    dp.locale = 'ru'
    assert str(dp) == 'BaseDataProvider <ru>'
    dp.locale = 'en'
    assert str(dp) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 20:59:03.386007
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'  # noqa: WPS221



# Generated at 2022-06-23 20:59:06.748030
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    p = BaseDataProvider()
    print(p)
    assert str(p) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 20:59:07.771732
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider(): 
    b = BaseDataProvider()


# Generated at 2022-06-23 20:59:12.201707
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers import BaseProvider as provider
    r = provider()
    assert str(r) == 'BaseProvider'

if __name__ == '__main__':
    test_BaseProvider___str__()

# Generated at 2022-06-23 20:59:20.526766
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method ``override_locale`` of class ``BaseDataProvider``."""
    from mimesis.builtins import (
        Address, Person, Business, Code, UnitSystem,
    )
    from mimesis.enums import Gender, UnitType, Currency, CodeType

    address = Address('en')
    address2 = Address('ru')
    address3 = Address('ua')
    person = Person('en')
    business = Business('en')
    code = Code('en')
    units = UnitSystem('en')

    assert address.country() == 'France'
    assert address.city() != 'Москва'

    assert person.full_name(gender=Gender.FEMALE) == 'Christina Middleton'

# Generated at 2022-06-23 20:59:21.708787
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-23 20:59:25.919800
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person
    person = Person('en')
    with person.override_locale('ru') as person:
        name = person.full_name()
    assert isinstance(name, str) and name
    assert person.locale == 'ru' and person.get_current_locale() == 'ru'



# Generated at 2022-06-23 20:59:27.091719
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert isinstance(str(BaseProvider()), str)


# Generated at 2022-06-23 20:59:29.023780
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    hd = BaseDataProvider(locale='en')
    locale = getattr(hd, 'locale', locales.DEFAULT_LOCALE)
    assert "en" == locale

# Generated at 2022-06-23 20:59:31.936946
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # TODO: Need to use assert_equal instead of ==
    from mimesis.enums import Gender
    from mimesis.providers import Trade
    assert 'BaseProvider' == str(BaseProvider())
    assert 'BaseProvider' == str(BaseProvider(seed=123))
    assert 'Person' == str(Trade())
    assert 'Person' == str(Trade(gender=Gender.MALE))

# Generated at 2022-06-23 20:59:36.975771
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        _datafile = 'test.json'
    data_provider = TestDataProvider(seed=0)
    with data_provider.override_locale('ru'):
        assert data_provider.locale == 'ru'
    assert data_provider.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 20:59:44.801925
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import Address, Person
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.typing import JSON

    class MyProvider(BaseDataProvider):
        pass

    class MyProvider2(BaseProvider):
        pass

    provider = MyProvider()

    assert provider._data == {}
    assert provider._datafile == ''
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')

    assert provider._data == {}
    assert isinstance(provider._pull(), JSON)
    assert isinstance(provider._pull(datafile='address.json'), JSON)

    locale_data = provider.get_current_locale()
    assert locale_data == 'en'
    assert provider._pull.cache_clear()

# Generated at 2022-06-23 20:59:54.609189
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test provider."""
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale)

    provider = TestDataProvider()
    with contextlib.suppress(ValueError):
        with provider.override_locale(locales.DEFAULT_LOCALE) as provider:
            assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    locale = 'en-us'
    provider = TestDataProvider(locale)
    with provider.override_locale(locales.EN_US) as provider:
        assert provider.get_current_locale() == locales.EN_US
    assert provider

# Generated at 2022-06-23 20:59:57.629751
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed == None
    assert obj.random == random
    obj = BaseProvider(seed=123)
    assert obj.seed == 123
    assert obj.random == random
    obj.reseed()
    assert obj.seed != None
    assert obj.random != random
    obj.reseed(seed=456)
    assert obj.seed == 456
    assert obj.random != random


# Generated at 2022-06-23 21:00:09.490121
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import datetime
    import mock
    from mimesis.enums import Gender

    bp = BaseProvider()
    bp.random = mock.MagicMock()
    bp.random.seed = mock.MagicMock()
    bp.reseed()
    assert bp.seed == datetime.datetime.now()
    assert bp.random == mock.MagicMock()
    assert bp.random.seed == mock.MagicMock()

    bp.reseed("123")
    assert bp.seed == datetime.datetime.now()
    assert bp.random == mock.MagicMock()
    assert bp.random.seed == mock.MagicMock()

    bp.random = random
    bp.reseed("456")
    assert bp.seed == datetime.datetime.now()

# Generated at 2022-06-23 21:00:13.433741
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class TestBaseDataProvider(BaseDataProvider):
        TEST_KEY = 'test'
        test_key = 'test'
        DATA_FILE = '{}.json'.format(TEST_KEY)

    assert TestBaseDataProvider.DATA_FILE == 'test.json'



# Generated at 2022-06-23 21:00:25.704233
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Test for initialise object of BaseProvider with different types of
    # seed.
    for _ in range(0, 40):
        seed = Random().seed(seed=None)
        test_provider_1 = BaseProvider(seed=seed)
        test_provider_2 = BaseProvider(seed=' ')
        test_provider_3 = BaseProvider(seed=None)
        assert test_provider_1.seed == seed
        assert test_provider_1.seed is not None
        assert test_provider_2.seed == 0
        assert type(test_provider_2.seed) is type(0)
        assert test_provider_3.seed is None

    #Test when initialise BaseProvider with seed, then Random
    #per instance will be created.

# Generated at 2022-06-23 21:00:27.547584
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale='en')
    assert bdp.locale == 'en'
    assert bdp.random is not None
    assert bdp.seed is None

# Generated at 2022-06-23 21:00:30.076579
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Check BaseDataProvider constructor."""
    data_provider: BaseDataProvider = BaseDataProvider()
    assert data_provider is not None
    assert data_provider._data == {}

# Generated at 2022-06-23 21:00:32.198380
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)

if __name__ == '__main__':
    test_BaseProvider()

# Generated at 2022-06-23 21:00:41.425341
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    import pytest
    from mimesis.enums import Gender, PersonPrefix
    from mimesis.providers.person import Person
    provider = Person(seed=20)
    assert provider.__str__() == 'Person'
    provider.prefix = PersonPrefix.MALE.value
    result = provider.prefix.__str__()
    assert result == 'Male'
    provider.gender = Gender.FEMALE.value
    assert provider.gender.__str__() == 'Female'
    with pytest.raises(AttributeError, match="object has no attribute \'gender\'"):
        delattr(provider, 'gender')
        provider.gender.__str__()


# Generated at 2022-06-23 21:00:43.303540
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bp = BaseDataProvider(seed=None)
    assert isinstance(bp, BaseDataProvider)


# Generated at 2022-06-23 21:00:51.089375
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a=BaseDataProvider()
    print(a)
    print(a._datafile)
    print(a._data_dir)
    print(a.locale)
    print(a.random)
    print(a.seed)
    print(a.reseed())
    print(a.random)
    print(a.__str__())
    with a.override_locale() as provider:
        print(provider)
        print(provider.locale)
test_BaseDataProvider()

# Generated at 2022-06-23 21:00:52.491955
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:00:59.318074
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider(locale='ro', seed=None)
    assert base_data_provider.locale == 'ro'
    assert base_data_provider.seed is None
    assert base_data_provider.random == random
    assert base_data_provider._data == {}
    assert base_data_provider._datafile == ''
    assert base_data_provider._data_dir == '/home/oleg/PycharmProjects/' \
                                           'mimesis/mimesis/data'



# Generated at 2022-06-23 21:01:00.192106
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()


# Generated at 2022-06-23 21:01:04.086311
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    b = BaseProvider('12345')
    assert a.seed == None
    assert b.seed == 12345
    assert a.random is random
    assert (type(b.random) == type(a.random)) == True


# Generated at 2022-06-23 21:01:07.502573
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    try:
        seed = 123
        prov = BaseProvider(seed=seed)
        prov.reseed()
        if prov.random() == prov.random():
            assert False
        prov.reseed(seed=seed)
        if prov.random() != prov.random():
            assert False
        assert True
    except Exception as exception:
        print(exception)
        assert False


# Generated at 2022-06-23 21:01:10.623627
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    vaule_reseed = BaseProvider()
    assert vaule_reseed.seed == None
    vaule_reseed.reseed(123)
    assert vaule_reseed.seed == 123
    assert vaule_reseed.random != Random()


# Generated at 2022-06-23 21:01:12.061549
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    prov = BaseProvider(seed=None)
    assert str(prov) == 'BaseProvider'


# Generated at 2022-06-23 21:01:16.401355
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = None
    m = BaseProvider(seed)
    m.reseed(seed)
    assert repr(m) == "<BaseProvider <None>>"


# Generated at 2022-06-23 21:01:19.481670
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    # Replaces a random.Random object inside the provider
    provider.reseed(123)

    assert provider.random.randint(1, 10) == 6

# Generated at 2022-06-23 21:01:21.003311
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # BaseProvider constructor
    assert isinstance(BaseProvider(), BaseProvider)


# Generated at 2022-06-23 21:01:24.018209
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:01:25.910070
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider(locale='en', seed=42)
    assert a.locale == 'en'
    assert a.seed == 42

# Generated at 2022-06-23 21:01:27.550726
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:01:30.131767
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method ``__str__`` of BaseDataProvider."""
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:32.196674
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    seed = 'custom'
    provider.reseed(seed)
    assert provider.random is not random
    assert provider.seed == seed


# Generated at 2022-06-23 21:01:33.829516
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:42.560475
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """
    :return: Test unit test of method reseed of class BaseProvider
    """
    from mimesis.builtins import Builtins
    from mimesis.enums import Gender
    from mimesis.person import Person
    from mimesis.utils import random_int

    provider = Builtins(seed=random_int(0, 9999))  # 0 == 9999
    provider_reseed = Builtins(seed=random_int(0, 9999))  # 0 == 9999

    from_str = provider.from_str('test')
    from_str_reseed = provider_reseed.from_str('test')
    assert from_str != from_str_reseed

    person_instance = Person(gender=Gender.MALE, seed=random_int(0, 9999))  # 0 == 9999
    person

# Generated at 2022-06-23 21:01:52.076500
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.finance import Currency

    pound = '£'
    for locale in {locales.NO, locales.EN, locales.RU}:
        with Currency() as c:
            c.override_locale(locale)
            assert pound in c.get_currency().values()

        no_currency = Currency(locale=locales.NO)
        override_locale = no_currency.override_locale
        with Currency(locale=locales.NO) as c:
            with override_locale(locale) as c:
                assert pound in c.get_currency().values()

        assert pound not in no_currency.get_currency().values()



# Generated at 2022-06-23 21:01:57.510879
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    internet1 = Internet()
    internet2 = Internet('ru')
    person1 = Person()
    person2 = Person('ru')

    assert internet1.get_current_locale() == 'en'
    assert internet2.get_current_locale() == 'ru'
    assert person1.get_current_locale() == 'en'
    assert person2.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:01:58.570633
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"


# Generated at 2022-06-23 21:02:00.611121
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    base_data_provider = BaseDataProvider()
    assert isinstance(base_data_provider.get_current_locale(), str)


# Generated at 2022-06-23 21:02:02.274014
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p = BaseDataProvider(locale = locales.EN)
    assert p.get_current_locale() == locales.EN

# Generated at 2022-06-23 21:02:05.753786
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test case for class BaseDataProvider.

    For method get_current_locale.
    """
    data: Any = BaseDataProvider(locale='RU')
    assert data.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:02:11.158893
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider()

    assert provider.locale == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU

    # Revert locale to en
    assert provider.locale == locales.EN

# Generated at 2022-06-23 21:02:13.430915
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p=BaseDataProvider(locale='ru', seed=1)
    print(p.locale)


# Generated at 2022-06-23 21:02:18.516178
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
	base_provider = BaseProvider()
	base_provider.seed = None
	base_provider.reseed(1)
	#print(base_provider._validate_enum(1,[1,2,3]))
	#print(base_provider._validate_enum(None,[1,2,3]))


# Generated at 2022-06-23 21:02:20.918048
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for BaseProvider.reseed."""
    x = BaseProvider()
    x.reseed(1)
    assert x.seed == 1
    assert x.random is not random

# Generated at 2022-06-23 21:02:28.765666
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    # Test that raise non-locale dependent error
    class Provider(BaseProvider):
        def func(self):
            return "return"

    p = Provider()
    try:
        with p.override_locale():
            pass
    except ValueError:
        assert True
    else:
        raise AssertionError(
            "Expected ValueError, not {}"
            .format(p.override_locale()))

    # Test that raise non-locale dependent error
    class Provider(BaseDataProvider):
        def func(self):
            return "return"
        pass
    p = Provider()
    try:
        with p.override_locale():
            pass
    except ValueError:
        assert True

# Generated at 2022-06-23 21:02:32.290813
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    # print(base.get_current_locale())
    # print(base.locale)

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:02:34.231492
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:02:37.126467
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider"""
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:02:38.014793
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()


# Generated at 2022-06-23 21:02:40.020095
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider('zh_CN').get_current_locale() == 'zh-cn'



# Generated at 2022-06-23 21:02:43.898683
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
  from mimesis.providers.base import BaseProvider
  from mimesis.exceptions import NonEnumerableError
  from io import BytesIO

  MyProvider = type('MyProvider', (BaseProvider, ), {})
  mp = MyProvider()
  assert 'MyProvider' == mp.__str__()



# Generated at 2022-06-23 21:02:54.013459
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers import Person

    person_1 = Person('es')  # initializes with seed 12345
    person_2 = Person('es')  # initializes with seed 12345

    assert person_1.seed == 12345
    assert person_2.seed == 12345
    assert person_1.username() == person_2.username()
    assert person_1.username() != person_2.username()

    person_1.reseed()  # reset seed to default system time
    person_2.reseed()  # reset seed to default system time

    assert person_1.seed != 12345
    assert person_2.seed != 12345
    assert person_1.username() != person_2.username()
    assert person_1.username() != person_2.username()


# Generated at 2022-06-23 21:02:54.830628
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass


# Generated at 2022-06-23 21:02:57.668716
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base = BaseDataProvider()
    assert base.__str__() == "BaseDataProvider <en>"

    base = BaseDataProvider(locale = "ru-RU")
    assert base.__str__() == "BaseDataProvider <ru-RU>"

# Generated at 2022-06-23 21:03:04.693378
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__."""
    bdp = BaseDataProvider()
    assert repr(bdp) == 'BaseDataProvider <en>'
    assert str(bdp) == 'BaseDataProvider <en>'
    bdp._setup_locale('ru')
    assert repr(bdp) == 'BaseDataProvider <ru>'
    assert str(bdp) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:03:08.310081
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """"Unit test for method reseed of class BaseProvider"""
    provider = BaseProvider(seed=4)
    result = provider.random.randint(0, 10000000)
    expected = 9934506
    assert result == expected


# Generated at 2022-06-23 21:03:10.084405
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=None)
    provider.reseed(42)
    assert provider.random.seed == 42

# Generated at 2022-06-23 21:03:13.695489
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider(seed=None)
    assert obj.random is random
    obj.reseed(seed=10)
    assert obj.random.seed(10)
    assert isinstance(obj.random, Random)


# Generated at 2022-06-23 21:03:14.425657
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None


# Generated at 2022-06-23 21:03:16.847941
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    result = str(BaseDataProvider(locale='en'))
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:03:17.409425
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pass

# Generated at 2022-06-23 21:03:21.378110
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider('http://example.com')
    assert str(bp).__class__ == BaseProvider.__name__, 'str(bp) should be return <class \'str\'>, but str(bp) is ' + str(str(bp))


# Generated at 2022-06-23 21:03:24.485163
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    provider = BaseProvider()
    provider.reseed(seed=1)
    assert provider.random.seed is not None


# Generated at 2022-06-23 21:03:27.545898
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """
    # >>> from mimesis.base import BaseDataProvider
    # >>> b=BaseDataProvider()
    # >>> b.get_current_locale()
    # 'en'
    """
    pass

# Generated at 2022-06-23 21:03:35.442328
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import CurrencyCode
    from mimesis.enums import Currency

    class Money(CurrencyCode):
        data_provider = BaseDataProvider(seed=0)

        def __init__(self, locale=locales.EN) -> None:
            super().__init__(locale=locale)

    money = Money(locale=locales.EN)
    assert(money.get_current_locale() == locales.EN)
    assert(money.get_currency() == Currency.RUB)

    with money.override_locale(locales.RU):
        assert(money.get_current_locale() == locales.RU)
        assert(money.get_currency() == Currency.RUB)


# Generated at 2022-06-23 21:03:40.401048
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider override_locale test."""
    class Test(BaseDataProvider):
        pass

    test = Test()
    with test.override_locale('en') as _:
        assert test.get_current_locale() == 'en'
    assert test.get_current_locale() != 'en'

# Generated at 2022-06-23 21:03:43.945706
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.base import BaseDataProvider
    bd = BaseDataProvider()
    assert bd.get_current_locale(), 'en'


# Generated at 2022-06-23 21:03:51.272645
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider()
    assert p.locale == "en"
    assert p.seed is None
    assert p.random == random
    p1 = BaseDataProvider("ru", 5)
    assert p1.locale == "ru"
    assert p1.seed == 5
    assert p1.random == random
    p1.reseed(5)
    assert p1.random != random
    with pytest.raises(UnsupportedLocale) as e_info:
        BaseDataProvider("fake")
    assert str(e_info.value) == "Unsupported locale 'fake'"
    assert str(p) == "BaseDataProvider <en>"
    assert str(p1) == "BaseDataProvider <ru>"
    # Test method ``_setup_locale``.
    p1._setup_locale("es")


# Generated at 2022-06-23 21:03:55.946792
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider1 = BaseProvider(seed=True)
    provider2 = BaseProvider(seed=True)

    provider1.reseed()
    provider2.reseed()
    assert provider1.seed != provider2.seed



# Generated at 2022-06-23 21:03:59.747052
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp.__str__() == 'BaseProvider'
    bp.__repr__() == 'BaseProvider'


# Generated at 2022-06-23 21:04:02.051149
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.datetime import Datetime
    dt=Datetime()
    assert(str(dt)=='Datetime')
    assert(dt.__str__()=='Datetime')


# Generated at 2022-06-23 21:04:07.526194
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp1 = BaseProvider(0)
    with pytest.raises(TypeError):
        print(BaseProvider('a'))
    assert str(bp) == 'BaseProvider'
    assert str(bp) != 'BaseDataProvider'


# Generated at 2022-06-23 21:04:08.381227
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b is not None


# Generated at 2022-06-23 21:04:15.245241
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class TestProvider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)
        def get_seed(self) -> Seed:
            return self.seed
        def get_random(self) -> Random:
            return self.random

    provider = TestProvider()
    assert provider.get_seed() is None
    assert provider.get_random() is random

    provider = TestProvider(seed=12)
    assert provider.get_seed() == 12
    assert isinstance(provider.get_random(), Random)
    assert provider.seed is provider.random.seed
    
test_BaseProvider_reseed()



# Generated at 2022-06-23 21:04:27.159594
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import CardExpiration
    with BaseDataProvider(locale='en') as en:
        assert en.locale == 'en'
        assert en._validate_enum(CardExpiration.TWO_YEARS, CardExpiration) == '02/{0}'
        assert en.reseed(seed=1234) is None
        assert en.__str__() == 'BaseDataProvider <en>'
    with BaseDataProvider(locale='zh-CN') as zh_CN:
        assert zh_CN.locale == 'zh-cn'
        # assert zh_CN._validate_enum(CardExpiration.TWO_YEARS, CardExpiration) == '{0}/02'
        assert zh_CN.reseed(seed=54321) is None

# Generated at 2022-06-23 21:04:33.482996
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p = BaseDataProvider()
    # p.get_current_locale() == 'en'
    assert p.get_current_locale() == 'en'
    # p = BaseDataProvider(locale='ru')
    # p.get_current_locale() == 'ru'
    p1 = BaseDataProvider(locale='ru')
    assert p1.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:04:35.344444
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 21:04:46.629333
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestBaseDataProvider(BaseDataProvider):
        pass
    assert str(TestBaseDataProvider()) == 'TestBaseDataProvider <en>'
    assert str(TestBaseDataProvider('ru')) == 'TestBaseDataProvider <ru>'
    assert str(TestBaseDataProvider('en')) == 'TestBaseDataProvider <en>'
    assert str(TestBaseDataProvider('de')) == 'TestBaseDataProvider <de>'
    assert str(TestBaseDataProvider('fr')) == 'TestBaseDataProvider <fr>'
    assert str(TestBaseDataProvider('uk')) == 'TestBaseDataProvider <uk>'
    assert str(TestBaseDataProvider('ja')) == 'TestBaseDataProvider <ja>'
    assert str(TestBaseDataProvider('br')) == 'TestBaseDataProvider <br>'
    assert str

# Generated at 2022-06-23 21:04:48.615229
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:04:52.443943
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test __str__ method of class BaseProvider."""
    bp = BaseProvider()
    # Test that method __str__ return name of class
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:04:56.158779
# Unit test for constructor of class BaseProvider

# Generated at 2022-06-23 21:04:58.046911
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    a = BaseDataProvider()
    assert 'BaseDataProvider' == str(a)



# Generated at 2022-06-23 21:05:01.671023
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    try:
        provider = BaseDataProvider()
        provider.get_current_locale()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-23 21:05:08.528147
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    class TestProvider(BaseDataProvider):
        pass

    ua = TestProvider(locale='uk_UA')
    us = TestProvider(locale='en_US')
    ru = TestProvider(locale='ru_RU')

    assert ua.get_current_locale() == 'uk_UA'
    assert us.get_current_locale() == 'en_US'
    assert ru.get_current_locale() == 'ru_RU'


# Generated at 2022-06-23 21:05:11.147490
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def some_method(self):
            return self.get_current_locale()

    provider = TestDataProvider('ru')
    with provider.override_locale('en'):
        assert provider.some_method() == 'en'
    assert provider.some_method() == 'ru'

# Generated at 2022-06-23 21:05:15.915731
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import unittest
    from mimesis.base import BaseProvider
    def _get_current_locale():
        class test_class(BaseProvider):
            def __init__(self, locale='en'):
                self.locale = locale
        return test_class()

    assert str(_get_current_locale()) == 'test_class <en>', 'Check get_current_locale method return current locale'



# Generated at 2022-06-23 21:05:19.324910
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    a = BaseDataProvider()
    assert str(a) == 'BaseDataProvider <en>'

    a = BaseDataProvider(locale='ru')
    assert str(a) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:05:19.966721
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
	pass

# Generated at 2022-06-23 21:05:24.894335
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
	# Step 1: Setup
	# Nothing to do
	
	# Step 2: Exercise
	# Create an instance of class BaseDataProvider
	# with default locale "en"
	d = BaseDataProvider()

	# Step 3: Verify
	# Expect that d.locale is "en"
	assert d.locale == "en"

	# Step 4: Teadown
	# Nothing to do

# Generated at 2022-06-23 21:05:26.198803
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=10)
    provider._reseed(seed=10)
    assert provider.seed == 10

# Generated at 2022-06-23 21:05:29.553744
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    provider = BaseDataProvider(locale=locale) # noqa
    result = provider.get_current_locale()
    assert result == locale

# Generated at 2022-06-23 21:05:38.244006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class MySillyProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def hello(self):
            return 'Hello'

    p = MySillyProvider(seed=None)
    assert p.get_current_locale() == locales.DEFAULT_LOCALE
    assert p.hello() == 'Hello'

    with p.override_locale() as s:
        assert s.get_current_locale() == locales.DEFAULT_LOCALE
        assert s.hello() == 'Hello'

    assert p.get_current_locale() == locales.DEFAULT_LOCALE
    assert p.hello() == 'Hello'

# Generated at 2022-06-23 21:05:42.660665
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    my_instance = BaseProvider(seed=1234)
    assert my_instance.seed == 1234
    assert my_instance.random != random

    my_instance.reseed(1234)
    assert my_instance.seed == 1234
    assert my_instance.random != random
    assert my_instance.random.seed == my_instance.seed

    my_instance.seed = None
    my_instance.reseed()
    assert my_instance.seed == None
    assert my_instance.random == random


# Generated at 2022-06-23 21:05:50.251539
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Function call
    print('\nMethod «override_locale» of class «BaseDataProvider»')
    test_class = BaseDataProvider(locale='en')
    def test_func(x, y):
        return x + y
    with test_class.override_locale(locale='en'):
        print(test_func(12.35, -45.68))
    # Function call
    with test_class.override_locale(locale='ru'):
        print(test_func(12.35, -45.68))


# Generated at 2022-06-23 21:05:50.744033
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().seed is None



# Generated at 2022-06-23 21:05:54.752218
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    foo = BaseDataProvider()
    assert foo.locale == locales.DEFAULT_LOCALE
    assert foo.__str__() == 'BaseDataProvider <en>'

    foo = BaseDataProvider(locale='ru')
    assert foo.locale == 'ru'
    assert foo.__str__() == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:06:02.794891
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Currency
    from mimesis.providers.data import data

    data_provider = Currency(locale='fr')
    assert str(data_provider) == 'Currency <fr>'

    assert data['en']['regions']['ar'] == 'Argentina'
    data['en']['regions']['ar'] = 0

    data_provider = Currency()
    assert str(data_provider) == 'Currency <en>'

    assert data['en']['regions']['ar'] == 0
    data['en']['regions']['ar'] = 'Argentina'


# Generated at 2022-06-23 21:06:04.473716
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider=BaseProvider()
    assert str(provider)=="BaseProvider"


# Generated at 2022-06-23 21:06:07.876517
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='CS', seed=42)
    with provider.override_locale(locale='EN'):
        assert provider.get_current_locale() == 'EN'
    assert provider.get_current_locale() == 'CS'

# Generated at 2022-06-23 21:06:16.407010
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers import Code, Faker, Person
    from mimesis.localization import Localization

    random = Random()
    seed = random.seed(42)
    _ = Localization(locale='ru')

    code = Code(seed=seed)
    faker = Faker(seed=seed)
    person = Person(seed=seed)

    with person.override_locale('ru') as p:
        gender = p.gender(Gender.MALE)
        full_name = p.full_name(gender)

    with faker.override_locale('ru') as f:
        symbol = f.code.symbol()
        username = f.person.username()

    with code.override_locale('ru') as c:
        md5

# Generated at 2022-06-23 21:06:17.704783
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:06:18.549436
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:06:20.373267
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    assert True


# Generated at 2022-06-23 21:06:27.645188
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    seed = 23948
    bp = BaseProvider(seed)
    assert bp.random.get_random_int() == 687504788541765341

    new_seed = 1234567
    bp.reseed(new_seed)
    assert bp.random.get_random_int() == -1363105384862352524


# Generated at 2022-06-23 21:06:28.596023
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print('test_BaseDataProvider')
    BaseDataProvider()

# Generated at 2022-06-23 21:06:29.723984
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.__class__.__name__ == 'BaseProvider'



# Generated at 2022-06-23 21:06:30.335414
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider('en')


# Generated at 2022-06-23 21:06:34.625279
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en', seed=42)
    assert provider.locale == 'en'
    assert provider.seed == 42
    # testing reseed
    provider.reseed(seed=None)
    assert provider.seed is not None

# Generated at 2022-06-23 21:06:35.947601
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    seed = _ = None
    provider = BaseDataProvider(seed=seed)
    return provider

# Generated at 2022-06-23 21:06:36.758472
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert 'BaseProvider' == str(BaseProvider(seed='foo'))


# Generated at 2022-06-23 21:06:40.420207
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random_provider = BaseProvider(seed=None)
    random_provider.random = None
    random_provider.reseed(seed=None)
    assert random_provider.random is not None


# Generated at 2022-06-23 21:06:42.837570
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    x = BaseDataProvider()
    assert str(x) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:06:45.748542
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis import Food
    food = Food(locale='ru')
    assert type(food) == Food
    assert (food.get_current_locale() == 'ru')


# Generated at 2022-06-23 21:06:50.277574
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    s = str(provider)
    assert s == 'BaseProvider', 's = {}'.format(s)


# Generated at 2022-06-23 21:06:57.710934
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from unittest import TestCase
    from mimesis.enums import Gender
    from mimesis.providers.person.base import Person

    class TestStr(TestCase):

        def test_get_str(self):
            expected = 'Person <en>'
            person = Person(locale='en')
            result = str(person)
            self.assertEqual(expected, result)

    test_str = TestStr()
    test_str.test_get_str()


# Generated at 2022-06-23 21:07:00.641661
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # pylint: disable=unused-argument
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:07:04.166111
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis import Generic
    gen = Generic('en')
    gen.reseed(12345)
    assert gen.seed == 12345
    assert gen.random == getattr(gen, 'random', None)


# Generated at 2022-06-23 21:07:06.140502
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base=BaseDataProvider()

# Generated at 2022-06-23 21:07:14.955700
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    def run_assertion(instance, seed):
        assert instance.seed == seed
        assert instance.random is not random
        assert isinstance(instance.random, Random)

    # Default seed
    instance = BaseProvider()
    run_assertion(instance, None)

    # Variable seed
    instance = BaseProvider(seed=123)
    run_assertion(instance, 123)

    # Reinit
    instance.reseed(345)
    run_assertion(instance, 345)

    # Reinit with default seed
    instance.reseed()
    run_assertion(instance, None)

    # Reinit with default seed again
    instance.reseed(None)
    run_assertion(instance, None)



# Generated at 2022-06-23 21:07:19.217349
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """This function check method get_current_locale of class BaseDataProvider."""
    from mimesis.builtins import Linux
    provider = Linux()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:07:21.351323
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data = BaseProvider()
    assert isinstance(data._data, dict)
    

# Generated at 2022-06-23 21:07:23.519879
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert isinstance(provider.seed, Seed)


# Generated at 2022-06-23 21:07:25.186559
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == provider.__class__.__name__


# Generated at 2022-06-23 21:07:29.428729
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    test_provider = BaseDataProvider()
    test_provider._pull = lambda x: 'some_data'

    with test_provider.override_locale('fr') as test_provider:
        assert test_provider.get_current_locale() == 'fr'

    assert test_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:07:32.962574
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    provider_str = f"{provider}"
    print(provider_str)
    assert provider_str == "BaseProvider"



# Generated at 2022-06-23 21:07:34.976279
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # global setUp
    r = BaseDataProvider()
    print(r)


# Generated at 2022-06-23 21:07:36.984468
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    _seed = 123
    _instance = BaseProvider(_seed)
    _instance.reseed(_seed)
    assert _instance.seed == _seed


# Generated at 2022-06-23 21:07:46.914964
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class OverrideDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)
            self._datafile = 'currencies.json'

        def __getattr__(self, item):
            return self._data[self.get_current_locale()].get(item)

        def __dir__(self):
            return self.__dict__.keys() | self._data.keys()

    test_fr = OverrideDataProvider('fr')
    assert test_fr.get_current_locale() == 'fr'
    assert test_fr.euro() == 'euro'
    assert test_fr.sterling() == 'livre sterling'

    with test_fr.override_locale('en'):
        assert test_

# Generated at 2022-06-23 21:07:54.490268
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.builtins import Person
    provider1 = Person(seed=2)
    provider2 = Person(seed=2)
    assert provider1._data['ru'] == provider2._data['ru']
    assert provider1.seed == provider2.seed
    assert provider1.random == provider2.random
    provider1 = Person()
    provider2 = Person()
    assert provider1._data['ru'] != provider2._data['ru']
    assert provider1.seed != provider2.seed
    assert provider1.random != provider2.random

# Generated at 2022-06-23 21:08:05.192886
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class MockBaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str = "uk") -> None:
            super().__init__(locale=locale)

        def get_current_locale(self) -> str:
            return self.locale

        def get_default_locale(self) -> str:
            return locales.EN

    with MockBaseDataProvider(locale=locales.EN) as data_:
        assert data_.get_current_locale() == locales.EN
        assert data_.get_default_locale() == locales.EN
        assert data_.locale == locales.EN
        with data_.override_locale(locale=locales.RU) as data:
            assert data.get_current_locale() == locales.RU
            assert data

# Generated at 2022-06-23 21:08:07.327741
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


"""Test for method __str__ of class BaseDataProvider"""

# Generated at 2022-06-23 21:08:10.376159
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test = BaseProvider()
    assert test is not None
    assert test.seed is None


# Generated at 2022-06-23 21:08:15.502857
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test case for method override_locale of class BaseDataProvider."""
    import mimesis.providers as providers

    with providers.Person.override_locale('ru') as person:
        assert person.locale == 'ru', 'Locale override failed.'

# Generated at 2022-06-23 21:08:18.437516
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '12345'
    obj = BaseProvider()
    obj.reseed(seed)
    assert obj.seed == seed
    assert obj.random.seed == seed


# Generated at 2022-06-23 21:08:22.093173
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    seed = 'mimesis'
    locale = locales.EN
    provider = BaseDataProvider(seed=seed, locale=locale)
    expected = 'BaseDataProvider <en>'

    # Act
    actual = str(provider)

    # Assert
    assert actual == expected