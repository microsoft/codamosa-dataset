

# Generated at 2022-06-23 20:58:28.090540
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 20:58:33.016167
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import locales
    from mimesis.providers.date import Date
    from mimesis.providers.base import BaseProvider

    assert BaseProvider().get_current_locale() == locales.DEFAULT_LOCALE
    assert Date().get_current_locale() == locales.DEFAULT_LOCALE
    assert Date(locale='ru').get_current_locale() == 'ru'

# Generated at 2022-06-23 20:58:35.716242
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'

# Generated at 2022-06-23 20:58:41.866014
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""

    class SomeProvider(BaseDataProvider):
        # A class with a locale-dependent method.
        def something(self):
            return self.locale
    
    provider = SomeProvider()
    with provider.override_locale('ru') as p:
        assert p.something() == 'ru'
    assert provider.something() == 'en'

    class SomeProvider2(BaseProvider):
        # A class without a locale-dependent method
        pass

    provider2 = SomeProvider2()
    with pytest.raises(ValueError):
        with provider2.override_locale('ru') as p:
            raise Exception()

# Generated at 2022-06-23 20:58:44.730783
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person()
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-23 20:58:47.556304
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # When I create a provider instance
    provider = BaseProvider()

    # Then provider should have string representation
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-23 20:58:56.043798
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    '''Tests of the class BaseDataProvider'''
    provider = BaseDataProvider()
    # isseed
    res = provider.seed
    assert res is None, f'unexpected seed={repr(res)}, but None expected'
    # israndom
    res = provider.random
    assert res is random, f'unexpected random={repr(res)}, but random expected'
    # islocale
    res = provider.locale
    assert res == locales.DEFAULT_LOCALE, f'unexpected locale={repr(res)}, but en expected'
    # isdict
    res = provider._data
    assert isinstance(res, dict), f'unexpected _data={repr(res)}, but dict expected'
    # isstr
    res = provider._datafile

# Generated at 2022-06-23 20:58:59.495442
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    a = BaseDataProvider()
    assert a.get_current_locale() == 'en'
    a._override_locale('de')
    assert a.get_current_locale() == 'de'


# Generated at 2022-06-23 20:59:02.939557
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider(locale="en-gb")
    assert data_provider.locale == 'en'
    assert isinstance(data_provider, BaseDataProvider)

# Generated at 2022-06-23 20:59:05.088516
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) is 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:13.617173
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Check method reseed of class BaseProvider."""
    provider = BaseProvider()
    value = provider.random.randint(1, 1000)
    assert value == provider.random.randint(1, 1000)
    provider.reseed(123)
    value = provider.random.randint(1, 1000)
    assert value == provider.random.randint(1, 1000)
    assert value != provider.random.randint(1, 1000)


# Generated at 2022-06-23 20:59:19.911123
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.full_name(gender=Gender.FEMALE) == 'Алина Шашкова'

    assert p.get_current_locale() == 'en'

# Generated at 2022-06-23 20:59:24.110690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test provider's context manager override_locale.

    Returns
    -------
    bool
        True if test passed, else False.
    """
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locale='ru') as tmp_provider:
        return tmp_provider.get_current_locale() == 'ru'


# Generated at 2022-06-23 20:59:26.832950
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment

    address = Address()
    payment = Payment()

    assert str(address) == 'Address <en>'
    assert str(payment) == 'Payment <en>'

# Generated at 2022-06-23 20:59:28.529440
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(seed=1).random.seed == 1
    assert BaseDataProvider().random.seed is not None


# Generated at 2022-06-23 20:59:31.759758
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()

    assert str(base_data_provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:33.277013
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    assert True

# Generated at 2022-06-23 20:59:35.219111
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider()
    assert data
    assert data.locale == 'en'



# Generated at 2022-06-23 20:59:38.254732
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit tests for method ``__str__`` of class BaseDataProvider."""
    import doctest
    doctest.testmod(verbose=False)

test_BaseDataProvider___str__.__test__ = False

# Generated at 2022-06-23 20:59:41.720022
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    provider = BaseDataProvider(locale=locale)
    assert provider.get_current_locale() == locale


# Generated at 2022-06-23 20:59:44.642986
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b_p = BaseProvider()
    assert b_p is not None
    assert isinstance(b_p, BaseProvider)
    return True


# Generated at 2022-06-23 20:59:46.505781
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    before_seed = obj.seed
    obj.reseed(1)
    after_seed = obj.seed
    assert before_seed is None and after_seed == 1


# Generated at 2022-06-23 20:59:49.116748
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    p = BaseDataProvider()

    # Act
    result = str(p)

    # Assert
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 20:59:51.622885
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    b.locale = 'en-us'
    assert b.__str__() == 'BaseDataProvider <en-us>'

# Generated at 2022-06-23 20:59:58.544279
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        def get_data(self, key: str = None) -> Dict[str, Any]:
            return self._data.get(key)

        def __str__(self) -> str:
            return super().__str__()

    provider = DummyProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert 'currency' in provider.get_data('monetary')

    assert provider.get_current_locale() == locales.EN
    assert 'currency' in provider.get_data('monetary')

# Generated at 2022-06-23 20:59:59.449784
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-23 21:00:00.502968
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:00:01.902404
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-23 21:00:06.913083
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.base import BaseProvider
    person = Person('en')
    person.gender = Gender.MALE
    male_name = person.full_name

    # Using context manager
    with person.override_locale('ru') as r_person:
        assert isinstance(r_person, BaseProvider)
        assert r_person.gender == Gender.MALE
        assert male_name != r_person.full_name

    # Now Русский язык is default again
    assert person.gender == Gender.MALE
    assert male_name == person.full_name

# Generated at 2022-06-23 21:00:11.268618
# Unit test for constructor of class BaseProvider
def test_BaseProvider():

    import os

    from mimesis.enums import Gender
    from mimesis.providers.usn import USNProvider

    _ = USNProvider()

    _ = USNProvider()

    _ = USNProvider(seed=os.urandom(100))

    with USNProvider.override_locale('en-US'):
        assert _.usn.ssn(gender=Gender.FEMALE) == '111-33-1111'

    data = (
        '{"code2": "GB", "code3": "GBR", "title": "Great Britain"}'
    )

    assert data == str(USNProvider().country)



# Generated at 2022-06-23 21:00:15.550702
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    class TestBaseDataProvider(BaseDataProvider):
        """Class that uses the BaseDataProvider class."""

        def get_current_locale(self):
            """Return current locale."""
            return super().get_current_locale()

    value = TestBaseDataProvider()
    locale = 'en'
    assert locale == value.get_current_locale()



# Generated at 2022-06-23 21:00:19.256521
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ for class BaseProvider."""
    obj = BaseProvider()
    assert obj.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:00:23.570957
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Test when locale is None
    a = BaseDataProvider(locale=None)
    print(a)    # BaseDataProvider <en>
    # Test when locale is not None
    b = BaseDataProvider(locale='zh')
    print(b)    # BaseDataProvider <zh>

# Generated at 2022-06-23 21:00:25.320566
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print("BaseDataProvider test")
    # __init__(self, locale: str = locales.DEFAULT_LOCALE, seed: Seed = None)
    x = BaseDataProvider()


# Generated at 2022-06-23 21:00:29.040426
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    test_seed = 123456789
    provider.reseed(test_seed)
    assert provider.random.seed_value == test_seed
    assert provider.seed == test_seed


# Generated at 2022-06-23 21:00:39.969642
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    person = Person(seed=Seed(42))
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'

    try:
        with person.override_locale('ru'):
            assert False
    except ValueError:
        assert True

    try:
        with person.override_locale('ru') as p:
            assert p.gender(Gender.FEMALE) == 'Женщина'
            raise ValueError
    except ValueError:
        assert True


#

# Generated at 2022-06-23 21:00:42.116643
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.base import BaseProvider

    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-23 21:00:43.811482
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert isinstance(BaseProvider().__str__(), str)


# Generated at 2022-06-23 21:00:45.901055
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale='en')
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:48.503514
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Create instance of class BaseProvider
    bp = BaseProvider()
    bp.reseed(seed = 'Mimesis')


# Generated at 2022-06-23 21:00:50.890183
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider()
    assert data_provider.get_current_locale() == "en"


# Generated at 2022-06-23 21:00:56.496893
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender, PersonTitle
    from mimesis.providers.person import Person

    person = Person('en')
    with person.override_locale('ru') as p:
        assert p.full_name(
            gender=Gender.MALE,
            title=PersonTitle.PREFIX_MR,
        ) in person._data['person']['male']['title']['prefix']['mr']

# Generated at 2022-06-23 21:00:59.157092
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test if method `reseed' is working properly."""
    seed = 1234
    provider = BaseProvider()
    provider.reseed(seed)

    assert provider.random.seed == seed


# Generated at 2022-06-23 21:01:01.884325
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:01:04.076503
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert isinstance(BaseProvider(seed=None).reseed(seed=None))


# Generated at 2022-06-23 21:01:12.602382
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.financial import Financial
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    import locale
    locale.setlocale(locale.LC_ALL,'en')
    p = Person('en')
    print(p)
    a = Address('en')
    print(a)
    b = Business('en')
    print(b)
    co = Code('en')
    print(co)
    f = Financial('en')
    print(f)
    i = Internet('en')
    print(i)
   

# Generated at 2022-06-23 21:01:17.401745
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    provider = BaseDataProvider(locale=locale)
    assert provider.get_current_locale(
    ) == 'en', 'provider.get_current_locale() should be "en"'


# Generated at 2022-06-23 21:01:22.605178
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert(provider.seed is None)
    assert(provider.random is random)
    provider.reseed(1)
    assert(provider.seed == 1)
    assert(provider.random is not random)
    provider.reseed()
    assert(provider.seed is None)
    assert(provider.random is not random)

# Generated at 2022-06-23 21:01:26.075963
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()
    assert BaseDataProvider(locale='ru')
    assert BaseDataProvider(seed='seed')
    assert BaseDataProvider(locale='ru', seed='seed')


# BaseDataProvider._update_dict

# Generated at 2022-06-23 21:01:29.753598
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #Calling constructor of base provider
    base_provider = BaseDataProvider()

    locale = getattr(base_provider, 'locale', locales.DEFAULT_LOCALE)
    assert locale == locales.DEFAULT_LOCALE, "locale is not properly set"

# Generated at 2022-06-23 21:01:33.804554
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    assert data_provider.locale == 'en'
    assert data_provider.seed is None
    assert data_provider.random == random
    assert data_provider._data == {}
    assert data_provider._datafile == ''
    assert data_provider._data_dir == Path(__file__).parent.parent.joinpath('data')

# Generated at 2022-06-23 21:01:39.133053
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    print(provider)
    provider.reseed(seed=666)
    print(provider)
    print(provider.seed)
    provider.reseed(seed=666)
    print(provider.seed)
    provider.reseed(seed=None)
    print(provider.seed)


# Generated at 2022-06-23 21:01:42.217872
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for reseed method of BaseProvider."""
    provider = BaseProvider(seed=None)
    assert provider.random is random
    provider.reseed(seed=1)
    assert provider.random.randrange(1, 100) == 88
    provider.random = random


# Generated at 2022-06-23 21:01:47.476010
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 42
    bp = BaseProvider(seed)
    
    def test_random():
        return bp.random.randint(1, 100)
    
    assert test_random() == test_random()
    bp.reseed(43)
    assert test_random() != test_random()


# Generated at 2022-06-23 21:01:54.434536
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # No arguments
    bdp = BaseDataProvider()
    assert bdp.__class__.__name__ == 'BaseDataProvider'
    assert bdp.locale == 'en'
    print('object: ', bdp.__str__())

    # locale and seed
    locale = 'en'
    seed = 1
    bdp = BaseDataProvider(locale, seed)
    assert bdp.locale == locale and bdp.seed == seed
    print('locale and seed: ', bdp.__str__())
    # TODO add more test cases


# Generated at 2022-06-23 21:01:58.233763
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person as PP
    with PP().override_locale('fr') as p:
        assert p.locale == 'fr'
        assert p.full_name() == 'M. Patrick Delmas'
    assert p.locale == 'en'
    assert p.full_name() == 'Mr. Robert Hansen'


# Generated at 2022-06-23 21:02:04.293120
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale = \
                                locales.EN,\
                                seed = None)
    assert hasattr(provider,'_data') and provider._data == {}
    assert hasattr(provider,'_datafile') and provider._datafile == ''
    assert hasattr(provider,'locale') and provider.locale == 'en'
    assert hasattr(provider, '_data_dir') and provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert hasattr(provider,'seed') and provider.seed == None
    assert hasattr(provider,'random') and provider.random == random


# Generated at 2022-06-23 21:02:07.227863
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    locale = 'ru-RU'
    provider = BaseProvider(locale=locale)
    assert provider.__str__() == 'BaseProvider'



# Generated at 2022-06-23 21:02:14.587745
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self._data = {'en': 'One', 'ru': 'Один'}
        def get_data(self):
            return self._data

    provider = Provider(locale='en')
    with provider.override_locale('ru') as provider:
        assert provider.get_data() == {'en': 'One', 'ru': 'Один'}, 'Provider got wrong data for locale «ru»'

    assert provider.get_data() == {'en': 'One'}, 'Provider got wrong data for locale «en»'

# Generated at 2022-06-23 21:02:18.458053
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis import Generic
    fake = Generic("en")
    fake.reseed("Suisse")
    assert fake.binary._random.seed == "Suisse"
    assert fake.seed == "Suisse"
test_BaseProvider_reseed()

# Generated at 2022-06-23 21:02:19.763285
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:02:21.454677
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:02:25.704646
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test."""
    bdp = BaseDataProvider(locale='en', seed=1234)
    ob = bdp
    assert isinstance(ob, BaseDataProvider)
    assert isinstance(ob, BaseProvider)
    assert ob.locale == 'en'
    assert ob.seed == 1234
    assert ob.random is not Random
    assert ob.random is not random

# Generated at 2022-06-23 21:02:27.066121
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    X = BaseProvider(locale='en')
    assert X.locale == 'en'

# Generated at 2022-06-23 21:02:37.934188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussiaSpecProvider, RussiaSpecPerson
    rus_person = RussiaSpecPerson()
    assert rus_person.get_current_locale() == locales.RU
    with rus_person.override_locale(locale=locales.EN) as _:
        assert rus_person.get_current_locale() == locales.EN
    assert rus_person.get_current_locale() == locales.RU
    rus_spec = RussiaSpecProvider()
    assert rus_spec.get_current_locale() == locales.RU
    with rus_spec.override_locale(locale=locales.EN) as _:
        assert rus_spec.get_current_locale() == locales.EN

# Generated at 2022-06-23 21:02:45.663746
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    def test_initialize_attributes():
        provider = BaseDataProvider()
        assert provider.random is random
        assert provider._data == {}
        assert provider._datafile == ''
        assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')

    test_initialize_attributes()

    # Unit test for method _setup_locale from class BaseDataProvider
    def test_set_up_locale():

        def test_set_up_locale_with_correct_locale():
            provider = BaseDataProvider()
            provider._setup_locale('en-GB')
            assert provider.locale == 'en-GB'

        test_set_up_locale_with_correct_locale()


# Generated at 2022-06-23 21:02:47.100527
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=5)
    assert p.seed == 5
    p.reseed(seed=10)
    assert p.seed == 10


# Generated at 2022-06-23 21:02:49.564163
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider().__str__()
    BaseDataProvider(locale="ru_RU").__str__()
    return True

# Generated at 2022-06-23 21:02:52.308904
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from . import Person
    person = Person('en')
    assert person.gender() == \
        person._validate_enum(Gender.FEMALE.value, Gender)

# Generated at 2022-06-23 21:02:54.635759
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=123)
    provider.reseed(123)
    assert provider.seed == 123


# Generated at 2022-06-23 21:02:59.952149
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        pass

    # it raises an error if the attribute does not exist
    provider = TestDataProvider()
    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    # it returns the initial value if not changed
    with provider.override_locale('en'):
        assert provider.locale == 'en'
    assert provider.locale == 'ru'

    # it returns the previous set value if not changed
    with provider.override_locale('en'):
        assert provider.locale == 'en'
    assert provider.locale == 'en'

# Generated at 2022-06-23 21:03:02.330220
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'en'
    seed = None
    provider = BaseDataProvider(locale, seed)
    result = provider.__str__()
    # Проверка
    assert result == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:03:06.310288
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    locale = 'ru'
    provider._setup_locale(locale)
    assert str(provider) == 'BaseDataProvider <ru>'



# Generated at 2022-06-23 21:03:08.508514
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    provider.get_current_locale()

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:03:11.192308
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider(locale='zh-CN').__str__()
    assert(BaseDataProvider(locale='zh-CN').__str__() == 'BaseDataProvider <zh-CN>')

# Generated at 2022-06-23 21:03:13.872615
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider."""
    provider = BaseProvider(seed=5)
    assert provider.seed == 5
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:03:17.320657
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    assert provider.random is random #check that main random is used initially
    provider.reseed(1234)
    assert provider.random is not random #after reseed random is not main random


# Generated at 2022-06-23 21:03:22.590261
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender
    test = BaseDataProvider()
    test2 = BaseDataProvider('en-US')
    test._validate_enum(Gender.MALE, Gender)
    locales.EN.suffix
    locales.get_locale_by_suffix('us')
    locales.get_locale_by_suffix('us', 'en')


# Generated at 2022-06-23 21:03:24.661917
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Foo(BaseProvider):
        pass

    foo = Foo()
    assert foo.__str__() == 'Foo'

# Generated at 2022-06-23 21:03:25.613178
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    result = BaseProvider().__str__()
    assert result == 'BaseProvider'

# Generated at 2022-06-23 21:03:34.438139
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method of BaseProvider"""

    test_provider = BaseProvider(seed=123)
    
    assert test_provider.seed == 123
    assert isinstance(test_provider.random, Random)

# Generated at 2022-06-23 21:03:45.117981
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Generic
    from mimesis.enums import Gender
    origin_locale = Generic().get_current_locale()

    assert origin_locale == locales.EN
    with Generic().override_locale(locale=locales.RU_RU) as generic:
        assert generic.get_current_locale() == locales.RU_RU
        assert generic.get_full_name(gender=Gender.FEMALE) == 'Алла Кузнецова'
    
    assert Generic().get_current_locale() == origin_locale


# Generated at 2022-06-23 21:03:48.130147
# Unit test for constructor of class BaseProvider
def test_BaseProvider():

    provider = BaseProvider(seed=1)

    assert provider.seed == 1
    assert provider.random != random
    assert provider.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:03:49.872016
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed=22)) == 'BaseProvider'


# Generated at 2022-06-23 21:03:58.991735
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('ru')
    assert p.get_current_locale() == 'ru'
    p.seed('1234')
    assert p._validate_enum(Gender.MALE, Gender) == Gender.MALE
    assert p.get_current_locale() == 'ru'
    assert p.get_full_name() == 'Антон Гайдай'
    assert p.get_full_name('vn') == 'Антон Гайдай'
    with p.override_locale('vn'):
        assert p.get_current_locale() == 'vn'

# Generated at 2022-06-23 21:04:01.162936
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed('the seed')
    assert bp.random.seed == 'the seed'


# Generated at 2022-06-23 21:04:03.854709
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        pass

    test = TestProvider()
    assert test.get_current_locale() == 'en'

# Generated at 2022-06-23 21:04:10.038664
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass
    provider = Provider()
    assert str(provider) == "Provider <en>"
    provider._setup_locale(locales.RU)
    assert str(provider) == "Provider <ru>"
    provider._setup_locale(locales.ES)
    assert provider.get_current_locale() == "es"

# Generated at 2022-06-23 21:04:12.710522
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    my_provider = BaseProvider(seed=None)
    print(my_provider)

test_BaseProvider()



# Generated at 2022-06-23 21:04:17.208222
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert (bdp._data == {})
    assert (bdp._datafile == '')
    assert (bdp._data_dir == Path(__file__).parent.parent.joinpath('data'))


# Generated at 2022-06-23 21:04:21.705383
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == 'en'
    assert not bdp._data
    assert not bdp._datafile
    assert bdp._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:04:32.929242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='ru')
    with provider.override_locale(locale='en') as p:
        assert p.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'ru'

    provider = BaseDataProvider()
    with provider.override_locale(locale='en') as p:
        assert p.get_current_locale() == 'en'
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider(locale='ru')
    with provider.override_locale(locale='zh') as p:
        assert p.get_current_locale() == 'zh'
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:04:38.274556
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.builtins import Business
    provider = BaseProvider()
    business_provider = Business()
    assert 'BaseProvider' == provider.__str__()
    assert 'Business <en>' == business_provider.__str__()


# Generated at 2022-06-23 21:04:42.268338
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale = 'en')
    assert provider.get_current_locale() == 'en'
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-23 21:04:45.304350
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for method __str__ of class BaseProvider."""
    from mimesis.providers.network import IPv4
    # IPv4 <en>
    assert str(IPv4()) == 'IPv4 <en>'

# Generated at 2022-06-23 21:04:46.589218
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print(BaseDataProvider(locale='ru').get_current_locale())

# Generated at 2022-06-23 21:04:48.116487
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider, "BaseProvider constructor is not working"


# Generated at 2022-06-23 21:04:51.615518
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        pass
    provider = TestProvider()
    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-23 21:05:03.084942
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    from mimesis.typing import Seed
    from mimesis.random import get_seed, random
    from mimesis.providers import BaseProvider

    seed = get_seed()

    bp_default = BaseProvider(seed)
    assert bp_default.seed == seed
    bp_default.reseed()
    assert bp_default.seed is None
    assert bp_default.random is random
    bp_default.reseed(seed)
    assert bp_default.seed == seed

    bp_random = BaseProvider(seed)
    assert bp_random.seed == seed
    bp_random.reseed(seed=seed)
    assert bp_random.seed == seed
    bp_random.reseed(seed=seed)


# Generated at 2022-06-23 21:05:07.810324
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p1 = BaseDataProvider(locale='ru')
    p2 = BaseDataProvider(locale='de')
    assert p1.get_current_locale() == 'ru'
    assert p2.get_current_locale() == 'de'

# Generated at 2022-06-23 21:05:13.191698
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(seed=0)
    for _ in range(10):
        with provider.override_locale(locales.EN):
            assert provider.get_current_locale() == locales.EN
        with provider.override_locale(locales.RU):
            assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-23 21:05:14.876448
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    locale = locales.DEFAULT_LOCALE
    assert isinstance(locale, str)

# Generated at 2022-06-23 21:05:24.933543
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Initialize attributes for data providers.
    gen_number1=BaseDataProvider(locale='it', seed='seed')
    # Expected result of this constructor
    assert gen_number1.locale=='it'
    assert gen_number1.seed=='seed'
    assert gen_number1.random==0.37405910476309655

    # Initialize attributes for data providers.
    gen_number2 = BaseDataProvider(locale='it', seed='seed1')
    # Expected result of this constructor
    assert gen_number2.locale == 'it'
    assert gen_number2.seed == 'seed1'
    assert gen_number2.random == 0.8582644739434033
    gen_number2.reseed('seed2')
    # Expected result of this constructor
    assert gen

# Generated at 2022-06-23 21:05:34.463006
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale(): # type: ignore
    class MyProvider(BaseDataProvider):
        def __init__(self, seed=None):
            # pylint: disable=unused-argument
            datafile = r'words/en/first_name.json'
            super().__init__(datafile=datafile)

        def get_first_name(self):
            return self._data['male']

    mp = MyProvider()
    name_en = mp.get_first_name()

    with mp.override_locale('ru'):
        name_ru = mp.get_first_name()

    assert name_en != name_ru


# Generated at 2022-06-23 21:05:36.318863
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
  prov = BaseDataProvider()
  assert prov.get_current_locale() == 'en'



# Generated at 2022-06-23 21:05:37.128442
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-23 21:05:39.382778
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale=locales.RU)) == 'BaseDataProvider <ru>'

# Unit tests for method _validate_enum of class BaseProvider

# Generated at 2022-06-23 21:05:41.086640
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    _BaseDataProvider = BaseDataProvider('en').override_locale('ru')
    assert _BaseDataProvider.locale == 'ru'

# Generated at 2022-06-23 21:05:43.434704
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en'
    provider = BaseDataProvider('ru')
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:05:50.251112
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    Mimesis_obj = BaseProvider()
    Mimesis_obj.reseed(seed='Ivan')
    a = Mimesis_obj.random.get_random_byte_sequence(10, 20)
    b = Mimesis_obj.random.get_random_byte_sequence(10, 20)
    c = Mimesis_obj.random.get_random_byte_sequence(10, 20)
    assert a == b == c, 'Failed: test_BaseProvider_reseed()'


# Generated at 2022-06-23 21:05:51.642658
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = {'a': 2, 'b': {'c': 3}}
    provider = BaseDataProvider(data)
    assert provider._data == data

# Generated at 2022-06-23 21:05:59.260590
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class FooProvider(BaseDataProvider):
        pass

    assert '<{}>'.format(locales.DEFAULT_LOCALE) in str(FooProvider())

    with FooProvider() as foo:
        assert '<{}>'.format(locales.DEFAULT_LOCALE) in str(foo)

    with FooProvider.override_locale(locales.DEFAULT_LOCALE) as foo:
        assert '<{}>'.format(locales.DEFAULT_LOCALE) in str(foo)


# Generated at 2022-06-23 21:06:03.350432
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.reseed(123) == None


if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-23 21:06:07.497298
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    print(dp)
    print(dp.get_current_locale())
    with dp.override_locale('ru') as dp:
        print(dp)
        print(dp.get_current_locale())


if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-23 21:06:10.447200
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test - __str__ method of class BaseDataProvider"""
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'


# Generated at 2022-06-23 21:06:13.395689
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert a.seed is None
    assert a.random == random
    b = BaseProvider(1)
    assert b.seed == 1
    assert b.random != random

#Unit test for str() method of class BaseProvider

# Generated at 2022-06-23 21:06:15.972182
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.AR
    provider = BaseDataProvider(locale=locale, seed=None)
    assert str(provider) == f'BaseDataProvider <{locale}>'

# Generated at 2022-06-23 21:06:21.448705
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        pass

    test = Test(locale='ru')

    assert test.override_locale() is not None
    assert test.override_locale(locale='en') is not None

    with test.override_locale(locale='uk'):
        assert test.locale == 'uk'
    assert test.locale == 'ru'



# Generated at 2022-06-23 21:06:24.430224
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    assert base.seed == None, "The seed should be empty in default"

    # Test after initialize seed
    base = BaseProvider(seed=100)
    assert base.seed == 100, "Wrong seed"


# Generated at 2022-06-23 21:06:26.218812
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 4
    bp = BaseProvider(seed=seed)
    bp.reseed(seed)
    assert bp.seed == seed


# Generated at 2022-06-23 21:06:27.597028
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:06:28.840684
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print(BaseProvider)


# Generated at 2022-06-23 21:06:33.286677
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    '''Tests for method get_current_locale of class BaseDataProvider
    '''
    test_object = BaseDataProvider(locale='uk')
    # test on uk
    assert test_object.get_current_locale() == 'uk', 'Wrong result!'

# Generated at 2022-06-23 21:06:36.706245
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'
    provider_ru = BaseDataProvider(locale='ru')
    assert provider_ru.get_current_locale() == 'ru'


# Generated at 2022-06-23 21:06:42.631376
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    
    bdp1 = BaseDataProvider('en')
    bdp2 = BaseDataProvider('fr')
    bdp3 = BaseDataProvider('not-supported')
    bdp4 = BaseDataProvider()

    # test_locale
    assert(True)

    # test_seed
    assert(True)



# Generated at 2022-06-23 21:06:45.235370
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()

    assert base.get_current_locale() == locales.EN
    assert base.locale == locales.EN


# Generated at 2022-06-23 21:06:50.421899
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base = BaseProvider()
    base1 = BaseProvider('zh')
    base2 = BaseProvider('zh')

    assert base.seed is None
    assert base1.seed == 'zh'
    assert base1.seed == base2.seed



# Generated at 2022-06-23 21:06:52.323323
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Names(BaseDataProvider):
        pass
    names = Names(locale='es')
    assert names.get_current_locale() == 'es'

# Generated at 2022-06-23 21:06:54.767493
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    c = BaseProvider(seed=1)
    assert c.__str__() == 'BaseProvider'


# Generated at 2022-06-23 21:07:03.155799
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    p.reseed('CSCI7240')
    assert p.random.randint(1, 20) == 19
    assert p.random.randint(1, 30) == 6
    assert p.random.randint(1, 40) == 6
    assert p.random.randint(1, 50) == 37
    assert p.random.randint(1, 60) == 31
    assert p.random.randint(1, 70) == 49
    assert p.random.randint(1, 80) == 65

# Generated at 2022-06-23 21:07:05.210090
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    fp = BaseDataProvider(locale="es_CO")
    assert fp.get_current_locale() == "es_CO"

# Generated at 2022-06-23 21:07:05.939730
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    pass

# Generated at 2022-06-23 21:07:07.896506
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class MyProvider(BaseDataProvider):
        pass

    provider = MyProvider("en")
    assert str(provider) == 'MyProvider <en>'

# Generated at 2022-06-23 21:07:09.751085
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class BaseDataProvider(BaseProvider):
        pass

    baseDataProvider = BaseDataProvider()
    print(baseDataProvider)
    assert baseDataProvider.__str__() == 'BaseDataProvider'

# Generated at 2022-06-23 21:07:11.070578
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    '''Unit test for constructor of class BaseProvider'''
    provider = BaseProvider()
    assert provider is not None


# Generated at 2022-06-23 21:07:12.911550
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider(seed='12345')
    assert str(obj) == "BaseProvider"
    obj = BaseProvider(seed='12345')
    assert repr(obj) == "BaseProvider <12345>"


# Generated at 2022-06-23 21:07:20.212365
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method ``reseed`` of class ``BaseProvider``."""
    test_provider = BaseProvider()
    test_provider.reseed(10)
    # re-init of random will create a new object
    assert not test_provider.random.seed_instance == None
    # overrides the random instance with a new one with seed 10
    test_provider.reseed(10)

# Generated at 2022-06-23 21:07:25.317606
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    with provider.override_locale('fr_CA'):
        assert provider.get_current_locale() == 'fr_CA'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-23 21:07:31.885539
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    with Address().override_locale('ru') as address:
        assert address.get_current_locale() == 'ru'
        assert address.get_region_name() == 'Башкортостан'
    assert Address().get_current_locale() == 'en'
    assert Address().get_region_name() == 'California'



# Generated at 2022-06-23 21:07:41.375043
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p1 = Person('en-US')
    p1.seed=1
    p1.reseed(1)
    assert p1.full_name() == 'Sean Wilkinson'
    assert p1.full_name(gender=Gender.FEMALE) == 'Jessica Mitchell'
    p1.reseed(None)
    assert p1.full_name(gender=Gender.FEMALE) == 'Laurie Frazier'
    p2 = Person('en-US')
    p2.seed=1
    assert p2.full_name(gender=Gender.FEMALE) == 'Lisa Edwards'


# Generated at 2022-06-23 21:07:44.148216
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reesed of class BaseProvider."""
    provider = BaseProvider()
    provider_reseed = BaseProvider('123')
    
    assert provider_reseed.seed == '123'



# Generated at 2022-06-23 21:07:47.380370
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    a = BaseDataProvider()
    assert a.get_current_locale() == 'en'


# Generated at 2022-06-23 21:07:49.936453
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider is not None
    provider = BaseDataProvider('en-US')
    assert provider is not None
    provider = BaseDataProvider('en-US', 123)
    assert provider is not None


# Generated at 2022-06-23 21:07:52.745720
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:07:57.949763
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test_base_data_provider = BaseDataProvider(locale="en")
    assert test_base_data_provider.locale == 'en'
    assert test_base_data_provider._data == {}
    assert test_base_data_provider._datafile == ''
    assert test_base_data_provider.seed is None

# Generated at 2022-06-23 21:08:00.993223
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    print('Testing method get_current_locale of class BaseDataProvider')
    base = BaseDataProvider(locale='en')
    assert base.get_current_locale() == 'en'



# Generated at 2022-06-23 21:08:03.163274
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unittest for class BaseProvider."""
    t = BaseProvider()
    t.reseed()
    assert True



# Generated at 2022-06-23 21:08:06.408628
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import GeneralCode

    code = GeneralCode('ar')
    assert code.get_current_locale() == 'ar'
    assert code.lazy_rules is True


# Generated at 2022-06-23 21:08:12.809967
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Generic
    from mimesis.enums import DataBits, DataSize, Locale

    provider = Generic('en')
    assert provider.get_current_locale() == 'en'
    assert provider.randomize() == 8
    assert provider.randomize(bits=DataBits.BITS_64) == 64
    assert provider.randomize(size=DataSize.BYTE) == 1
    with provider.override_locale(Locale.RUSSIAN):
        assert provider.get_current_locale() == 'ru'
        assert provider.randomize() == 8
        assert provider.randomize(bits=DataBits.BITS_64) == 64
        assert provider.randomize(size=DataSize.BYTE) == 1

# Generated at 2022-06-23 21:08:15.106804
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    f = BaseDataProvider()
    assert 'en' == f.get_current_locale()


# Generated at 2022-06-23 21:08:19.715943
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test __str__ method of BaseDataProvider class."""
    class TestBaseDataProvider(BaseDataProvider):
        """Test class for BaseDataProvider."""

    bdp = TestBaseDataProvider()
    assert str(bdp) == "TestBaseDataProvider <en>"



# Generated at 2022-06-23 21:08:21.751043
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data = BaseDataProvider()
    assert data.get_current_locale() == locales.EN


# Generated at 2022-06-23 21:08:24.646323
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    u"""Test that method __str__ of class BaseProvider works correctly."""
    bp = BaseProvider()
    assert(str(bp) == 'BaseProvider')
