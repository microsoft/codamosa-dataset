

# Generated at 2022-06-23 20:58:25.544937
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    b = BaseDataProvider(locale="ru")
    b = BaseDataProvider(seed=4)
    return b


# Generated at 2022-06-23 20:58:33.990501
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # создание провайдера и вывод его в консоль
    provider = BaseDataProvider()
    print(provider)

    # его потомок
    class ChildProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)

    provider = ChildProvider()
    print(provider)


# Generated at 2022-06-23 20:58:36.936247
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    print(Person(seed=None, gender=Gender.MALE))

# Generated at 2022-06-23 20:58:49.013303
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.other import Other
    from mimesis.providers.personal import Personal
    from mimesis.providers.system import System
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.unit import Unit
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'
    provider = Numbers()
    assert str(provider) == 'Numbers'
    provider = Unit()
    assert str(provider) == 'Unit'
    provider = System()
    assert str(provider) == 'System'
    provider = Text()

# Generated at 2022-06-23 20:58:52.363868
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Tests ``get_current_locale`` method of class ``BaseDataProvider``."""
    random.seed(None)

    locale_of_class_BaseDataProvider = BaseDataProvider.get_current_locale()
    assert locale_of_class_BaseDataProvider == 'en'

    locale_of_one_instance_of_BaseDataProvider = BaseDataProvider().get_current_locale()
    assert locale_of_one_instance_of_BaseDataProvider == 'en'


# Generated at 2022-06-23 20:58:59.858085
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person
    person = Person()
    assert person.get_current_locale() == locales.EN
    with person.override_locale(locales.RU) as p:
        assert person.get_current_locale() == locales.RU
        assert person.full_name(gender=None) == p.full_name(gender=None)
    assert person.get_current_locale() == locales.EN

# Generated at 2022-06-23 20:59:04.541727
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider._datafile == ''
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert provider.locale == 'en'
    assert provider._data == {}


# Generated at 2022-06-23 20:59:06.247045
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None


# Generated at 2022-06-23 20:59:13.873964
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import pytest
    from mimesis.providers.base import BaseDataProvider
    bdp = BaseDataProvider()

    def test_get_current_locale_returns_en():
        assert bdp.get_current_locale() == 'en'

    def test_get_current_locale_raises_unsupported_locale():
        with pytest.raises(UnsupportedLocale):
            bdp._setup_locale('no_locale')



# Generated at 2022-06-23 20:59:16.762639
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    providerSeed = BaseProvider(seed = 1)
    providerNoSeed = BaseProvider()
    assert providerSeed.seed == 1
    assert providerNoSeed.seed == None
    assert providerSeed.random != providerNoSeed.random


# Generated at 2022-06-23 20:59:22.599153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.typing import Seed
    from mimesis.providers import Person as Person2

    person = Person(seed=0)
    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'

        person = Person(seed=1)
        assert person.get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:30.415772
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    provider = Provider(seed=4)
    assert provider.locale == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU
    assert provider.locale == locales.DEFAULT_LOCALE

    provider = Provider(seed=4)
    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU

    with provider.override_locale(locales.EN):
        assert provider.locale == locales.EN

# Generated at 2022-06-23 20:59:34.957259
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    foo = BaseDataProvider(locale="en")
    assert foo.get_current_locale() == "en"

    with foo.override_locale(locale="de"):
        assert foo.get_current_locale() == "de"

    assert foo.get_current_locale() == "en"

# Generated at 2022-06-23 20:59:36.533579
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == 'en'


# Generated at 2022-06-23 20:59:42.690340
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class Foo(BaseProvider):
        """This is a test class."""
        pass

    obj1 = Foo()
    obj2 = Foo(seed=1)
    assert obj1.random != obj2.random
    assert obj1.random != random
    assert obj2.random != random
    assert obj1.seed is None
    assert obj2.seed == 1


# Generated at 2022-06-23 20:59:44.503695
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert p.__str__() == "BaseProvider"


# Generated at 2022-06-23 20:59:46.617810
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert isinstance(bdp, BaseProvider)
    assert isinstance(bdp, BaseDataProvider)

# Generated at 2022-06-23 20:59:48.470741
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random


# Generated at 2022-06-23 20:59:57.763222
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Ensure that method override_locale works correctly."""
    class TestProvider(BaseDataProvider):
        """Class TestProvider."""

        def __init__(self, locale: str) -> None:
            """Initialize attributes.

            :param locale: Locale.
            """
            super().__init__(locale)
            self._data = {}
            self._datafile = 'test.json'

    data = {
        'test_provider': 'test_provider',
    }

    Path('data/test_locale').mkdir(parents=True, exist_ok=True)

    with open('data/test_locale/test.json', 'w', encoding='utf8') as f:
        json.dump(data, f, ensure_ascii=False)


# Generated at 2022-06-23 21:00:02.059045
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale='ru'):
        assert provider.locale == 'ru'
    assert provider.locale != 'ru'

# Generated at 2022-06-23 21:00:06.552578
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed=None)
    assert bp.seed is None
    assert bp.random == random
    bp.seed = 22
    assert bp.seed == 22
    assert bp.random != random
    bp.reseed(seed = None)
    assert bp.random == random


# Generated at 2022-06-23 21:00:07.045241
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert 1==1

# Generated at 2022-06-23 21:00:08.357454
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:10.100277
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    fake = BaseDataProvider()
    assert repr(fake) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:00:12.503911
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider"""
    from . import Address
    adres = Address()
    assert adres.get_current_locale() == 'en'


# Generated at 2022-06-23 21:00:14.966656
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
   pass
   #tmp = BaseDataProvider(locale=locales.EN,seed=None)
   #tmp.__str__()

# Generated at 2022-06-23 21:00:20.558856
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = 'ru'
    dataprovider = BaseDataProvider(locale=locale)
    with dataprovider.override_locale('en') as provider:
        assert provider == dataprovider
        assert dataprovider.locale == 'en'
    assert dataprovider.locale == locale

# Generated at 2022-06-23 21:00:25.939806
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import time
    base1 = BaseProvider()
    base2 = BaseProvider(seed=5)
    base1.reseed(None)
    tmp = int(time.time())
    base1.reseed()
    assert tmp == base1.seed
    assert base1.random.seed() == base1.seed
    assert base2.random.seed() == 5

# Generated at 2022-06-23 21:00:28.589857
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.typing import Seed
    x = BaseDataProvider()
    x.reseed(seed=42)
    assert x.seed == 42, 'failed test_BaseProvider_reseed'


# Generated at 2022-06-23 21:00:37.030681
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

    provider = TestProvider(locales.EN)
    assert provider.get_current_locale() == locales.EN

    provider = TestProvider(locales.RU)
    assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-23 21:00:43.655181
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProv(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    foo = TestProv()
    bar = TestProv(locale='pl')

    with foo.override_locale('pl'), bar.override_locale('en'):
        assert foo.get_current_locale() == locales.PL
        assert bar.get_current_locale() == locales.EN

    assert foo.get_current_locale() == locales.DEFAULT_LOCALE
    assert bar.get_current_locale() == locales.PL

# Generated at 2022-06-23 21:00:54.644123
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider(locale='en')
    provider.get_current_locale() is 'en'
    with provider.override_locale('ru') as p:
        p.get_current_locale() is 'ru'
    provider.get_current_locale() is 'en'
    provider.get_current_locale() is 'en'
    with provider.override_locale('en') as p:
        p.get_current_locale() is 'en'
    provider.get_current_locale() is 'en'
    provider.get_current_locale() is 'en'
    with provider.override_locale('ru') as p:
        p.get_current_locale() is 'ru'
    provider.get_current_locale() is 'en'

# Generated at 2022-06-23 21:00:55.759918
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.base import BaseProvider
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'



# Generated at 2022-06-23 21:01:03.398704
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""

    class TestProvider(BaseDataProvider):
        """Test class for TestProvider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                    seed: Seed = NonE) -> None:
            """Init TestProvider.

            :param str locale: Parameter for BaseDataProvider.
            :param seed: Parameter for Random class.
            """
            super().__init__(locale=locale, seed=seed)
            self._data = {
                'en': {
                    'name': 'en',
                },
                'ru': {
                    'name': 'ru',
                },
            }
            self._datafile = 'test.json'


# Generated at 2022-06-23 21:01:10.629082
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test BaseProvider."""
    # Just Construct the object
    bp = BaseProvider()
    assert type(bp).__name__ == "BaseProvider"

    assert bp.seed is None
    assert bp.random is random

    bp = BaseProvider("steff")
    assert bp.seed == "steff"
    assert bp.random is not random

    bp.reseed("nase")
    assert bp.seed == "nase"
    assert bp.random is not random

    # Test the print method
    assert str(bp) == "BaseProvider"


# Generated at 2022-06-23 21:01:14.940236
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data_provider = BaseProvider(seed=12345)
    assert data_provider.seed == 12345
    assert data_provider.random is not random


# Generated at 2022-06-23 21:01:19.469045
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    bdp = BaseDataProvider()
    assert isinstance(bdp.__str__(), str)
    assert bdp.__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:01:27.042816
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person('ru')
    assert person.get_current_locale() == locales.RU
    data = person._data['personal']['firstnames'][Gender.MALE.value]
    #vladimir = [ 'Владимир', 'Владислав', 'Владислава', 'Владлен',
    #             'Владлена', 'Владимира', 'Владислава', 'Владимиром',

# Generated at 2022-06-23 21:01:30.004281
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.generic import Generic

    generic = Generic()
    assert isinstance(generic, BaseDataProvider)
    assert generic.get_current_locale() == 'en'


# Generated at 2022-06-23 21:01:32.667433
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """
    Test for __str__ method of BaseProvider class.
    """
    provider = BaseProvider()
    assert 'BaseProvider' == str(provider)

test_BaseProvider___str__.__doc__ = __doc__


# Generated at 2022-06-23 21:01:34.666645
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 0
    provider = BaseProvider()
    origin_random = provider.random
    provider.reseed(seed)
    new_random = provider.random
    assert origin_random is not new_random


# Generated at 2022-06-23 21:01:35.900297
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider().reseed() is None

# Generated at 2022-06-23 21:01:36.882171
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider())=='BaseDataProvider <en>'

# Generated at 2022-06-23 21:01:39.938049
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    address = Address()
    with address.override_locale('ru'):
        assert address.locale == 'ru'

    assert address.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-23 21:01:51.574715
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
   # Test if the constructor works fine.
   assert BaseProvider is not None
   assert BaseProvider() is not None
   assert isinstance(BaseProvider(), BaseProvider)
   try:
       assert BaseProvider(seed=None) is not None
   except:
       print("test_BaseProvider_seed not working fine")

   # Test if the reseed method works fine.
   try:
       assert BaseProvider().reseed(seed=None) is None
   except:
       print("test_BaseProvider_reseed not working fine")

   # Test if the _validate_enum method works fine.
   class E(Enum):
       EN1 = 1
       EN2 = 2
   baseProvider = BaseProvider()

# Generated at 2022-06-23 21:01:56.103196
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    Locale = 'en' # This is what we are going to test
    seed = 'Not important' # For later tests
    data = BaseDataProvider(Locale, seed)
    assert data.locale == Locale
    assert data.seed == seed
    data.reseed(seed)
    assert data.seed == seed
    assert str(data) == 'BaseDataProvider <' + Locale + '>'


# Generated at 2022-06-23 21:01:59.372500
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider(locale='en').__str__() == 'BaseDataProvider <en>'
    assert BaseDataProvider(locale='ru').__str__() == 'BaseDataProvider <ru>'
    assert BaseDataProvider(locale='uk').__str__() == 'BaseDataProvider <uk>'
    return




# Generated at 2022-06-23 21:02:01.771874
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed."""
    random.seed(12345)
    provider = BaseProvider()
    assert provider.random() == 0.9664535356921388
    provider.reseed(12345)
    assert provider.random() == 0.9664535356921388

# Generated at 2022-06-23 21:02:05.946148
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider()
    some_seed = 1
    attributes = {
        'locale': 'en',
        'seed': some_seed
    }
    base_data_provider.random.seed(some_seed)
    assert base_data_provider.__dict__ == attributes



# Generated at 2022-06-23 21:02:14.617452
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    origin_locale = 'en'
    origin_locale_data = [
        'Western Canada',
        'Northwest Territories',
        'Nunavut',
        'Ontario',
        'New Brunswick',
        'Nova Scotia',
        'Newfoundland and Labrador',
        'British Columbia',
        'Prince Edward Island',
        'Saskatchewan',
        'Quebec',
        'Manitoba',
        'Yukon',
        'Alberta'
    ]
    new_locale = 'ru'

# Generated at 2022-06-23 21:02:17.292805
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import Countries
    assert type(Countries.override_locale(locale='ru')) is Countries


# Generated at 2022-06-23 21:02:20.141375
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestBaseDataProvider(BaseDataProvider):
        def _pull(self):
            pass
    t = TestBaseDataProvider()
    assert t.__str__() == 'TestBaseDataProvider <en>'

# Generated at 2022-06-23 21:02:22.598251
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a=BaseProvider()
    print(a)
    b=BaseProvider(11)
    print(b)
    print(BaseProvider.__dict__)

# Generated at 2022-06-23 21:02:33.134678
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import os
    from mimesis.random import set_global_seed, set_global_random_state
    from mimesis.random import get_global_random_state
    from mimesis.random import get_global_seed
    from mimesis.random import get_random_item
    from mimesis.random import getrandbits
    from mimesis.random import getstate
    from mimesis.random import random
    from mimesis.random import random_integers
    from mimesis.random import random_sample
    from mimesis.random import seed
    from mimesis.random import setstate
    from mimesis.random import shuffle
    from mimesis.random import uniform
    from mimesis.random import weibullvariate
    from mimesis.random import triangular

# Generated at 2022-06-23 21:02:34.008843
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider(locale='ru')
    assert dp.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:02:44.086381
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit-test for the method get_current_locale of class BaseDataProvider."""
    from mimesis.base import BaseDataProvider
    from mimesis.enums import Locale
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.typing import Seed

    d = BaseDataProvider(Locale.RU)
    assert d.get_current_locale() == Locale.RU
    d = BaseDataProvider()
    assert d.get_current_locale() == Locale.EN
    d = BaseDataProvider(Locale.FR)
    assert d.get_current_locale() == Locale.FR
    d = BaseDataProvider('bla-bla')
    assert d.get_current_locale() == Locale.EN

# Generated at 2022-06-23 21:02:49.610716
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    data_provider = BaseDataProvider()
    assert data_provider.random == random
    assert data_provider.locale == 'pt'
    assert data_provider.reseed() is None
    assert data_provider.get_current_locale() == 'pt'
    assert 'BaseDataProvider' in str(data_provider)
    assert 'BaseDataProvider' in repr(data_provider)



# Generated at 2022-06-23 21:02:51.631106
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    TestBaseProvider = BaseProvider(seed=42)
    assert TestBaseProvider.__str__() == "BaseProvider"


# Generated at 2022-06-23 21:02:55.441879
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    data_provider = BaseDataProvider()
    assert data_provider.get_current_locale() == locales.DEFAULT_LOCALE
    data_provider = BaseDataProvider(locale='ru')
    assert data_provider.get_current_locale() == 'ru'



# Generated at 2022-06-23 21:02:58.647681
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.person import Person
    
    test_obj = Person(locale='hi')
    test_get_current_locale = test_obj.get_current_locale()
    assert str(test_get_current_locale) == "hi"
    

# Generated at 2022-06-23 21:03:02.740822
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed1 = 123
    provider1 = BaseProvider(seed1)
    rd1 = provider1.random.randint(0,100)
    assert rd1 == 4, "Wrong reseed."



# Generated at 2022-06-23 21:03:07.857628
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider1 = BaseDataProvider(locale='zh')
    provider2 = BaseDataProvider(locale='zh')
    provider3 = BaseDataProvider(locale='en')

    assert provider1.get_current_locale() == provider2.get_current_locale()
    assert provider1.get_current_locale() != provider3.get_current_locale()


# Generated at 2022-06-23 21:03:09.604223
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider(seed=seed)
    assert (b == BaseProvider(seed=seed))


# Generated at 2022-06-23 21:03:12.021915
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider('ja')) == 'BaseDataProvider <ja>'

# Generated at 2022-06-23 21:03:14.247352
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    assert provider.__class__.__name__ == "BaseDataProvider"


# Base object method test

# Generated at 2022-06-23 21:03:18.974870
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    class FakeProvider(BaseDataProvider):
        """Fake provider."""
        locale = 'ru'
        _datafile: str = ''

        def _pull(self, datafile: str = ''):
            """Mock _pull method."""

    provider = FakeProvider()

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-23 21:03:22.415540
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.EN
    provider.locale = locales.RU
    assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-23 21:03:31.440252
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        _datafile = 'personal.json'

        def get_name(self) -> str:
            return self._data['first_names'][self.random.randint(0, len(self._data['first_names']) - 1)]

    p = Provider()
    with p.override_locale(locales.EN) as provider:
        print('Test with «{}» locale:\n\t{}'.format(p.locale, provider.get_name()))

    with p.override_locale(locales.RU) as provider:
        print('Test with «{}» locale:\n\t{}'.format(p.locale, provider.get_name()))

# Generated at 2022-06-23 21:03:33.541528
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Arrange
    bdp = BaseProvider()

    # Act
    actual = str(bdp)

    # Assert
    assert actual == 'BaseProvider'


# Generated at 2022-06-23 21:03:35.323515
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    random_number = bp.random.randint(1, 100)
    assert isinstance(random_number, int)



# Generated at 2022-06-23 21:03:40.672731
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for BaseDataProvider."""
    class TestBase(BaseDataProvider):

        def __init__(self, locale='en', seed=None, **kwargs):
            super().__init__(locale=locale, seed=seed, **kwargs)

    test = TestBase()
    assert isinstance(test, BaseDataProvider)
    assert isinstance(test, TestBase)
    assert hasattr(test, 'locale')
    assert hasattr(test, 'seed')
    assert hasattr(test, 'random')
    assert isinstance(test.get_current_locale(), str)



# Generated at 2022-06-23 21:03:50.282259
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Sex, SexType, Person

    p = Person('ru')
    sex_to_str = [
        (Sex.MALE, 'Мужской'),
        (Sex.FEMALE, 'Женский'),
        (SexType.MAN, 'Мужчина'),
        (SexType.WOMAN, 'Женщина'),
    ]

# Generated at 2022-06-23 21:03:51.940158
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-23 21:03:54.639519
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    s = BaseDataProvider()
    assert str(s) == 'BaseDataProvider <en>'
    s2 = BaseDataProvider('ru')
    assert str(s2) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:03:58.089850
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider = BaseDataProvider(locale='ru')
    assert str(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:04:00.410457
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider_test = BaseDataProvider(locale='en_us')
    assert data_provider_test.get_current_locale() == 'en_us'

# Generated at 2022-06-23 21:04:09.869766
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    def provider_test(provider):
        assert isinstance(provider.get_current_locale(), str)

        if hasattr(provider, 'locale'):
            with provider.override_locale(locales.DEFAULT_LOCALE) as _:
                provider_test(_)

    import mimesis.builtins

    for provider in mimesis.builtins.__all__:
        provider_test(getattr(mimesis.builtins, provider)())

    if Path(__file__).stem == 'base_provider':
        provider_test(BaseDataProvider())

# Generated at 2022-06-23 21:04:12.095192
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-23 21:04:16.603023
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers import Person
    person = Person(locale = 'ru')
    assert person.get_current_locale() == 'ru'
    with person.override_locale('en') as person:
        assert person.get_current_locale() == 'en'

# Generated at 2022-06-23 21:04:17.582678
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None
    # Unit test for constructor of class BaseProvider


# Generated at 2022-06-23 21:04:20.525103
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    for seed in (42, 'foo', None):
        r = BaseProvider(seed=seed)
        r.reseed(seed=seed)



# Generated at 2022-06-23 21:04:21.309646
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test(BaseProvider): pass
    assert str(Test()) == 'Test'

# Generated at 2022-06-23 21:04:24.849837
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    data_provider = BaseDataProvider()
    assert isinstance(data_provider.__str__(), str)

# Generated at 2022-06-23 21:04:27.623545
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert isinstance(BaseDataProvider().__str__(), str)
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:04:33.103948
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Write test_BaseDataProvider___str__ function."""
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider.__class__.__name__ = 'Internet'
    assert str(provider) == 'Internet <en>'
    provider.locale = 'ru'
    assert str(provider) == 'Internet <ru>'

# Generated at 2022-06-23 21:04:35.391580
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    provider.reseed(seed=2)
    assert provider.seed == 2
    assert provider.random is not random

# Generated at 2022-06-23 21:04:36.836488
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

# Generated at 2022-06-23 21:04:40.097011
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider(seed=123)
    print(a)
    assert str(a) == "BaseProvider"


# Generated at 2022-06-23 21:04:45.663017
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class _TestDataProvider(BaseDataProvider):
        def test(self):
            return self.get_current_locale()

    data_provider = _TestDataProvider(locale='ru')
    with data_provider.override_locale('en'):
        assert data_provider.test() == 'en'
    assert data_provider.test() == 'ru'



# Generated at 2022-06-23 21:04:57.432276
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    import sys
    import unittest
    from operator import eq
    class TestBaseDataProvider(unittest.TestCase):
        def setUp(self):
            class TestProvider(BaseDataProvider):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    self.locale = locales.EN
                    self._data = {'en': {'key': 'value'}}
            self.provider = TestProvider()
        # This unit test is for method override_locale in BaseDataProvider class
        def test_override_locale_method(self):
            new_value = 'new_value'
            new_provider = self.provider.override_locale(locales.RU)

# Generated at 2022-06-23 21:05:02.943426
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider('ru')
    assert dp.locale == 'ru'
    assert dp.seed == None
    assert dp.random == random
    assert dp._data == {}
    assert dp._datafile == ''
    assert dp._data_dir == str(Path('BaseDataProvider.py').parent.parent.joinpath('data'))


# Generated at 2022-06-23 21:05:06.437502
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    d=BaseDataProvider()
    assert d._datafile==''
    assert d.seed==None
    assert d.random==random
    assert isinstance(d,BaseProvider)
    d=BaseDataProvider('en',123)
    assert d.seed==123
    assert d.random!=random


# Generated at 2022-06-23 21:05:08.288986
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    assert 1 == 1
    # TODO: Check if default locale is en and later change it to ru-ru

# Generated at 2022-06-23 21:05:11.869984
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    expected = 'DataProvider <en>'
    assert expected == str(BaseDataProvider())
    assert expected == str(BaseDataProvider(locale='en'))
    assert expected == str(BaseDataProvider(locale=''))

# Generated at 2022-06-23 21:05:18.222167
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code

    def test_class_has_locale_dependent():
        with Code().override_locale(locales.ES):
            # Now in Code() class, current locale is 'es'
            assert Code().get_current_locale() == locales.ES

    def test_class_has_not_locale_dependent():
        try:
            with Code().override_locale(locales.ES):
                # Now in Code() class, current locale is 'es'
                assert Code().get_current_locale() == locales.ES
        except ValueError:
            pass
        else:
            assert False

    test_class_has_locale_dependent()
    test_class_has_not_locale_dependent()

# Generated at 2022-06-23 21:05:21.311871
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    assert str(p) == 'BaseDataProvider <en>'
    p = BaseDataProvider(locale='ru')
    assert str(p) == 'BaseDataProvider <ru>'
    p = BaseDataProvider(locale='unknown')
    assert str(p) == 'BaseDataProvider <unknown>'



# Generated at 2022-06-23 21:05:25.046899
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    en_provider = BaseDataProvider(locale='en')
    assert str(en_provider) == 'BaseDataProvider <en>'
    es_provider = BaseDataProvider(locale='es')
    assert str(es_provider) == 'BaseDataProvider <es>'


# Generated at 2022-06-23 21:05:27.032540
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed is None


# Generated at 2022-06-23 21:05:29.141484
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()
    BaseDataProvider(seed='7')


# Generated at 2022-06-23 21:05:35.117910
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random
    assert provider.random is random
    assert provider.random() in range(5)
    provider.reseed(12)
    assert provider.seed == 12
    assert provider.random == random
    assert provider.random is not random
    assert provider.random() == 4
    assert provider._validate_enum("1", {"1": "test"}) == "test"


# Generated at 2022-06-23 21:05:39.363727
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for class BaseProvider."""
    from mimesis.builtins import Person

    p1 = Person()
    p2 = Person()

    # The setup of seeds are as follows
    # p1 -> random
    # p2 -> seed1

    random_value = p1.random.random()
    seed1 = '123'
    p2.reseed(seed1)
    seed1_value = p2.random.random()

    p2.reseed()
    seed2 = p2.seed
    seed2_value = p2.random.random()

    p2.reseed(seed2)
    seed3_value = p2.random.random()

    p1.reseed(seed1)
    seed1_value_2 = p1.random.random()
    p1.reseed()
    seed

# Generated at 2022-06-23 21:05:49.640897
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person, Datetime

    person = Person()
    assert person.get_current_locale() == locales.EN

    with person.override_locale(locales.DE):
        assert person.get_current_locale() == locales.DE

    person.seed = 777
    datetime = Datetime()
    datetime.seed = 777

    with person.override_locale(locales.DE):
        assert person.random.seed == 777
        assert person.get_current_locale() == locales.DE
        assert datetime.seed == 777
        assert person.get_current_locale() == locales.DE

# Generated at 2022-06-23 21:05:52.448713
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # TODO: [fix] Add test
    assert True

# Generated at 2022-06-23 21:05:56.682651
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis import Person
    from mimesis.enums import Gender
    person = Person(seed=12345)
    assert person.seed == 12345
    assert person.gender() == Gender.FEMALE
    assert person.gender(person.Gender.MALE) == Gender.MALE
    assert person.gender(person.Gender.MALE) == Gender.MALE
    try:
        person.gender('foo')
    except NonEnumerableError:
        pass

# Generated at 2022-06-23 21:06:04.893885
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestDataProvider(BaseDataProvider):

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            self._datafile = 'test.json'
            super().__init__(locale=locale, seed=seed)

        @property
        def data(self) -> Dict[str, Any]:
            return self._data

        def get_first_name(self, gender: str = None) -> str:
            return self.data['name']['first_name'][gender][0]

    def test_provider_init():
        provider = TestDataProvider(locale=locales.EN)

        assert provider.get_first_name(gender='male').lower() == 'john'

# Generated at 2022-06-23 21:06:06.600823
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    with BaseProvider() as bp:
        assert str(bp) == "BaseProvider"


# Generated at 2022-06-23 21:06:09.155721
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    random.seed(1)
    provider = BaseProvider()
    assert "BaseProvider" == str(provider)
    assert provider.seed is None
    assert random.seed.call_count == 0


# Generated at 2022-06-23 21:06:12.117167
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p = BaseDataProvider()
    print(p)
    p = BaseDataProvider(locale='ru')
    print(p)
    p = BaseDataProvider(locale='ru_RU')
    print(p)




# Generated at 2022-06-23 21:06:14.080637
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for Default constructor."""
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random == random



# Generated at 2022-06-23 21:06:16.641978
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    test = BaseProvider()
    result = test.__str__()
    assert type(result) == str
    assert result == 'BaseProvider'


# Generated at 2022-06-23 21:06:19.873698
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    GenericDataProvider = type('GenericDataProvider', (BaseDataProvider,), {})
    data_provider = GenericDataProvider()
    assert data_provider.get_current_locale() == 'en'

# Generated at 2022-06-23 21:06:23.049053
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    # Test in the case when value of current local is en
    obj = BaseDataProvider()
    assert obj.get_current_locale() == locales.EN



# Generated at 2022-06-23 21:06:26.488657
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    assert dp._data == {}
    assert dp._datafile == ''
    assert dp.locale == locales.DEFAULT_LOCALE
    assert dp._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:06:28.468436
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    result = str(provider)
    assert result == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:06:31.635338
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    print(provider.__str__())
    assert provider.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-23 21:06:33.129750
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-23 21:06:36.944839
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    from mimesis.providers.address import Address
    from mimesis.providers.code import Code

    class A(BaseProvider):
        pass

    a = A()
    assert a.__str__() == 'A'

    class B(Address):
        pass

    b = B()
    assert b.__str__() == 'B'

    class C(Code):
        pass

    c = C()
    assert c.__str__() == 'C'



# Generated at 2022-06-23 21:06:38.259298
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    k = BaseDataProvider()
    assert k._data=={}
    assert k._data_dir==Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-23 21:06:41.829959
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=1234)
    bp.reseed('abcde')
    assert bp.seed == 'abcde'


# Generated at 2022-06-23 21:06:46.360239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            pass

    provider = TestProvider()

    with provider.override_locale(locales.EN):
        provider_locale = provider.get_current_locale()
    if provider_locale is not locales.EN: raise ValueError
    

# Generated at 2022-06-23 21:06:49.307284
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider()
    base_provider.reseed()
    assert base_provider.seed is not None

# Generated at 2022-06-23 21:06:52.066725
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed"""
    r = Random()
    r.seed(0)
    Rand = r.randint(1, 10)
    assert Rand == 8


# Generated at 2022-06-23 21:06:58.019661
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def test(self):
            return self.get_current_locale()
    provider = Test()
    assert provider.test() == 'en'
    with provider.override_locale('ar') as provider:
        assert provider.test() == 'ar'
    assert provider.test() == 'en'

# Generated at 2022-06-23 21:07:04.076109
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test the functionality of method reseed of the BaseProvider class.
    """
    provider = BaseProvider()
    currentSeed = provider.seed
    assert currentSeed == None
    provider.reseed(10)
    newSeed = provider.seed
    assert newSeed == 10
    provider.reseed()
    currentSeed = provider.seed != 10
    assert currentSeed == True


# Generated at 2022-06-23 21:07:05.954071
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == 'en'
    assert provider.seed is None


# Generated at 2022-06-23 21:07:08.653323
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp.__class__.__name__ = 'Test'
    assert str(bp) == 'Test'

test_BaseProvider___str__()


# Generated at 2022-06-23 21:07:11.070557
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass
    assert str(Provider()) == 'Provider <en>'
    assert str(Provider('ru')) == 'Provider <ru>'
    assert str(Provider(locale=None)) == 'Provider <en>'
test_BaseDataProvider___str__()

# Generated at 2022-06-23 21:07:12.152755
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

test_BaseProvider___str__()


# Generated at 2022-06-23 21:07:19.752383
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    """Unit tests for method ``reseed`` of class ``BaseProvider``. """

    # Test with argument ``seed`` is not set
    provider = BaseProvider()
    new_random = provider.random
    provider.reseed()
    assert new_random is provider.random

    # Test with argument ``seed`` is not set
    provider = BaseProvider()
    new_random = provider.random
    seed = 123
    provider.reseed(seed)
    assert seed == provider.seed


# Generated at 2022-06-23 21:07:21.901386
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    date = BaseProvider()
    date.reseed()
    assert date.seed is None


# Generated at 2022-06-23 21:07:22.953790
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider is not None


# Generated at 2022-06-23 21:07:31.269315
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Person as EN_Person
    from mimesis.providers.person.ru import Person as RU_Person

    class Fake:
        pass

    russian = RU_Person(local_data=True)

    with Person(local_data=True).override_locale(locales.RU) as russian:
        assert type(russian) == EN_Person
        assert russian.locale == locales.RU
        assert russian.name(Gender.MALE) == russian.name(Gender.MALE)

    assert type(russian) == EN_Person
    assert russian.locale == locales.EN
    assert russian.name(Gender.MALE)

# Generated at 2022-06-23 21:07:38.710494
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.builtins import Person, Address

    with pytest.raises(ValueError):
        with Person().override_locale():
            pass

    with Address().override_locale('ru') as address:
        assert address.locale == 'ru'
        assert address.get_place_name() == 'Карский'
    assert address.locale == locales.DEFAULT_LOCALE
    assert address.get_place_name() == 'Manor Hill'

# Generated at 2022-06-23 21:07:40.855233
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Reseed the internal random generator."""
    r = BaseProvider(seed="1")
    assert r.random.seed("1")


# Generated at 2022-06-23 21:07:42.221250
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    pass

# Generated at 2022-06-23 21:07:44.211575
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    f = BaseDataProvider(locale='en')
    assert str(f) == 'BaseDataProvider <en>'

# Generated at 2022-06-23 21:07:47.433547
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider.locale = 'ru'
    assert str(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-23 21:07:51.885177
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.misc import Misc
    from mimesis.enums import Gender

    provider = Misc(seed=42)
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.full_name(gender=Gender.MALE) == 'Сергей Васильев'

    assert provider.get_current_locale() == 'en'
    assert provider.full_name(gender=Gender.MALE) == 'Alton Harris'

# Generated at 2022-06-23 21:07:58.258695
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""

    from mimesis.providers.geography import Geography
    Geography(locale='es')

    assert str(Geography(locale='en')) == 'Geography <en>'
    assert str(Geography(locale='fi')) == 'Geography <fi>'
    assert str(Geography()) == 'Geography <en>'


# Generated at 2022-06-23 21:08:01.284769
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p.seed is None
    assert p.random == random

    p = BaseProvider(seed=10)
    assert p.seed == 10
    assert p.random != random


# Generated at 2022-06-23 21:08:04.545931
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    base_data_provider = BaseDataProvider(locale='en')
    assert base_data_provider.locale == 'en'


# Generated at 2022-06-23 21:08:10.770105
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit-test for method override_locale of class BaseDataProvider."""
    import mimesis.providers.address

    provider = mimesis.providers.address.Address(locale='ru')  # noqa: F841

    def get_locale(p: Any) -> str:
        return p.get_current_locale()

    with provider.override_locale('en'):
        assert get_locale(provider) == locales.EN

    with provider.override_locale('ru'):
        assert get_locale(provider) == locales.RU

# Generated at 2022-06-23 21:08:14.415028
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_item = BaseProvider()
    print(test_item)
    print(test_item.seed)
    test_item.reseed(seed='5')
    print(test_item.seed)


# Generated at 2022-06-23 21:08:19.805811
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    def get_seed():
        return 4

    bp = BaseProvider(get_seed)
    assert bp.seed == get_seed()
    bp.reseed(3)
    assert bp.seed == 3
    bp.reseed()
    assert bp.seed is None



# Generated at 2022-06-23 21:08:25.320369
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    try:
        assert(BaseProvider().seed == None)
        assert(BaseProvider(None).random is random)
        assert(BaseProvider(123).random is not random)
        assert(BaseProvider(123).random.seed(123) == None)
        # Test __str__
        assert(str(BaseProvider()) == 'BaseProvider')
    except Exception as e:
        print(e)
