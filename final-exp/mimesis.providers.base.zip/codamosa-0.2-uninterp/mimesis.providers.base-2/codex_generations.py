

# Generated at 2022-06-17 22:16:26.234666
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:16:37.113907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.geography import Geography
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    address = Address()
    person = Person()

# Generated at 2022-06-17 22:16:48.283911
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:16:57.571389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == provider.get_data()

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:03.057415
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self):
            return self.locale

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:11.632061
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data('test') == 'Тест'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:21.711503
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.science import Science
    from mimesis.providers.payment import Payment
    from mimesis.providers.food import Food

# Generated at 2022-06-17 22:17:31.248591
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:17:41.043692
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.geography import Geography
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.science import Science
    from mimesis.providers.file import File
    from mimesis.providers.text import Text
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:17:50.573677
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as ru:
        assert ru.get_data() == {'test': 'тест'}

    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:18:04.650284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'


# Generated at 2022-06-17 22:18:12.832583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.gender(gender=Gender.MALE) == 'Мужской'

    assert person.get_current_locale() == 'en'
    assert person.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:18:19.631107
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'
        assert a.get_country() == 'Россия'


# Generated at 2022-06-17 22:18:30.665362
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    person = Person('en')
    address = Address('en')

    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Петрова'
        assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

    with address.override_locale('ru') as a:
        assert a.city() == 'Москва'
        assert a.country() == 'Россия'


# Generated at 2022-06-17 22:18:35.855760
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.gender(Gender.MALE) == 'Мужской'
    assert p.gender(Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:18:44.589458
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:50.807244
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.full_name(gender=Gender.MALE) == 'John Smith'

    assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

# Generated at 2022-06-17 22:19:04.798567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web

    address = Address()
    datetime = Datetime()
    person = Person()
    text = Text()
    web = Web()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Алтайский край'


# Generated at 2022-06-17 22:19:15.150930
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Московская область'

    assert address.get_current_locale() == 'en'
    assert address.get_region() == 'New York'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:25.141444
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:19:54.056996
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.web import Web

    # Test for Address
    address = Address()
    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Санкт-Петербург'
    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'New York'



# Generated at 2022-06-17 22:20:03.398367
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.RU)
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:20:10.686562
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}


# Generated at 2022-06-17 22:20:16.529641
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_data() == {'test': 'Тест'}

    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'Test'}

    assert provider.get_data() == {'test': 'Тест'}

# Generated at 2022-06-17 22:20:21.540284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:20:30.414693
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.locale = locale
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'Тест'}
    assert provider.get_data() == {'test': 'Test'}

# Generated at 2022-06-17 22:20:40.062611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'Тест'}

    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:20:46.662812
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Сергеевич Пушкин'
    assert person.get_current_locale() == 'en'
    assert person.full_name() == 'John Doe'

# Generated at 2022-06-17 22:20:52.641870
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestDataProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:21:02.494283
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.gender(gender=Gender.FEMALE) == 'женский'
    assert p.get_current_locale() == 'en'
    assert p.gender(gender=Gender.FEMALE) == 'female'

# Generated at 2022-06-17 22:21:55.218916
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() == 'Москва'
        assert ru_address.get_region() == 'Московская область'
        assert ru_address.get_country() == 'Россия'


# Generated at 2022-06-17 22:22:05.676894
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.text import Text
    from mimesis.providers.science import Science
    from mimesis.providers.code import Code
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.geography import Geography

# Generated at 2022-06-17 22:22:13.076289
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_data() == {'en': 'English'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'ru': 'Русский'}


# Generated at 2022-06-17 22:22:22.868933
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            """Get data from JSON file.

            :param key: Key of data in JSON file.
            :return: Data from JSON file.
            """
            return self._data[key]

    provider = TestProvider()

# Generated at 2022-06-17 22:22:28.336266
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    assert p.full_name(gender=Gender.MALE) == 'John Smith'

    with p.override_locale('ru'):
        assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:22:34.295374
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Александр Петров'
    assert person.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:22:42.976262
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data('test') == {'key': 'value'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_

# Generated at 2022-06-17 22:22:48.821373
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_data() == {'test': 'Тест'}

    with provider.override_locale('en'):
        assert provider.get_data() == {'test': 'Test'}

    assert provider.get_data() == {'test': 'Тест'}

# Generated at 2022-06-17 22:23:02.423757
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

# Generated at 2022-06-17 22:23:07.638673
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person

    p = Person()
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.get_full_name() == 'Антон Королев'

    assert p.get_current_locale() == 'en'
    assert p.get_full_name() == 'Anton Korolev'

# Generated at 2022-06-17 22:25:04.629105
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru'):
        assert p.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'
        assert p.full_name(gender=Gender.FEMALE) == 'Софья Александровна Евдокимова'

    with p.override_locale('en'):
        assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:25:07.658677
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:13.339802
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'en': 'English'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:25:20.353184
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.full_name(gender=Gender.MALE) == 'Александр Карпов'
        assert p.full_name(gender=Gender.MALE) == 'Александр Карпов'

    assert p.full_name(gender=Gender.MALE) == 'Alexander Carpenter'

# Generated at 2022-06-17 22:25:24.620586
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> JSON:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data() == {'test': 'тест'}



# Generated at 2022-06-17 22:25:30.540305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('en')
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Иванова'

    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.FEMALE) == 'Anna Ivanova'

# Generated at 2022-06-17 22:25:39.953802
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_data() == {'test': 'тест'}


# Generated at 2022-06-17 22:25:45.936567
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:25:54.719212
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale(locale='en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:26:04.548095
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale='ru')
    assert provider.get_data('test') == 'Тест'

    with provider.override_locale('en'):
        assert provider.get_data('test') == 'Test'

    assert provider.get_data('test') == 'Тест'