

# Generated at 2022-06-17 22:16:22.286285
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Александрович Александров'
    assert person.get_current_locale() == 'en'
    assert person.full_name() == 'John Smith'


# Generated at 2022-06-17 22:16:31.014470
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.geography import Geography
    from mimesis.providers.currency import Currency

# Generated at 2022-06-17 22:16:40.202269
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.person import Gender
    from mimesis.providers.person import PersonInfo
    from mimesis.providers.person import PersonInfoFields
    from mimesis.providers.person import PersonInfoFields as PIF
    from mimesis.providers.person import PersonInfoFields as PIF
    from mimesis.providers.person import PersonInfoFields as PIF
    from mimesis.providers.person import PersonInfoFields as PIF
    from mimesis.providers.person import PersonInfoFields as PIF
    from mimesis.providers.person import PersonInfoFields as PIF

# Generated at 2022-06-17 22:16:50.148455
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:16:57.090916
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'
        assert p.full_name(gender=Gender.MALE) == 'Alexander Pushkin'

# Generated at 2022-06-17 22:17:06.037088
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:17:13.685603
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data('key') == 'value'

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data('key') == 'значение'

# Generated at 2022-06-17 22:17:19.565823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert person.get_current_locale() == 'en'

    assert person.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:26.024689
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

        def get_current_locale(self):
            return self.locale

    provider = TestProvider()
    assert provider.get_current_locale() == 'en'
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:36.142350
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:17:56.029207
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Иванов'

    assert person

# Generated at 2022-06-17 22:18:05.483398
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:14.502677
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:18:18.816749
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person

    person = Person(locale='ru')
    with person.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.full_name() != person.full_name()

    assert person.get_current_locale() == 'ru'
    assert person.full_name() != p.full_name()

# Generated at 2022-06-17 22:18:24.816077
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.gender(gender=Gender.MALE) == 'Мужской'
    assert person.get_current_locale() == 'en'
    assert person.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:18:31.346181
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Александр Кузнецов'
    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:18:41.461942
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

# Generated at 2022-06-17 22:18:51.598128
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data('test') == {'test': 'test'}
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:04.830599
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport

    providers = [
        Address,
        Datetime,
        Geo,
        Internet,
        Person,
        Science,
        Text,
        Transport,
    ]

    for provider in providers:
        p = provider()

# Generated at 2022-06-17 22:19:15.196713
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    providers = [
        Address,
        Datetime,
        Geography,
        Internet,
        Person,
        Science,
        Text,
        Transport,
        Unit,
    ]

    for provider in providers:
        p = provider()


# Generated at 2022-06-17 22:19:42.036499
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name() == 'Анастасия Константиновна Савельева'
    assert person.locale == 'en'
    assert person.full_name() == 'Ruthie M. Hahn'

# Generated at 2022-06-17 22:19:49.997997
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.gender(gender=Gender.MALE) == 'Мужской'
    assert person.locale == 'en'
    assert person.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:20:02.591525
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('en')
    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Александр Александров'
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Аннина'

    assert person.full_name(gender=Gender.MALE) == 'John Doe'
    assert person.full_name(gender=Gender.FEMALE) == 'Jane Doe'

# Generated at 2022-06-17 22:20:11.185484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'Тест'}
    assert provider.get_data() == {'test': 'Test'}

# Generated at 2022-06-17 22:20:16.184082
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_data('test') == 'Тест'
    assert provider.get_data('test') == 'Test'

# Generated at 2022-06-17 22:20:20.499117
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale='en'):
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'test': 'test'}



# Generated at 2022-06-17 22:20:24.571929
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.gender(Gender.MALE) == 'Male'
    assert p.gender(Gender.MALE) == 'Мужской'


# Generated at 2022-06-17 22:20:35.620112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'
        assert ru_person.full_name() == 'Иван Иванов'


# Generated at 2022-06-17 22:20:42.824890
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'foo': 'bar'}

    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'foo': 'bar'}

# Generated at 2022-06-17 22:20:50.348423
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() == 'Москва'
        assert ru_address.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'


# Generated at 2022-06-17 22:21:43.294622
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_full_address() != address.get_full_address()

    assert address.get_current_locale() == 'en'

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'
        assert ru_person.full_name() != person.full_name

# Generated at 2022-06-17 22:21:48.406559
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:21:54.675242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data()['test'] == 'Тест'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data()['test']

# Generated at 2022-06-17 22:22:00.704926
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:06.606739
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:22:13.635797
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data.get(key)

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data('key') == 'value_ru'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data('key') == 'value_en'

# Generated at 2022-06-17 22:22:23.245647
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:22:30.793437
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:22:39.274145
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data() == {'test': 'test_ru'}

    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:22:46.981196
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:24:36.779327
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Александр Петров'

    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.MALE) == 'John Doe'

    with person_provider.override_locale('ru') as p:
        assert p.get

# Generated at 2022-06-17 22:24:41.069054
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:24:49.145801
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.typing import JSON

    person = Person()
    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'
        assert person.get_full_name(gender=Gender.FEMALE) == 'Анна Петрова'

    assert person.get_current_locale() == 'en'
    assert person.get_full_name(gender=Gender.FEMALE) == 'Anna Peterson'

    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:24:54.913703
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'test'}
        assert p.get_current_locale() == 'en'

    assert provider.get_data() == {'test': 'тест'}
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:25:05.573048
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.finance import Finance
    from mimesis.providers.geography import Geography
    from mimesis.providers.identifiers import Identifiers
    from mimesis.providers.payment import Payment

# Generated at 2022-06-17 22:25:10.023325
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Address
    from mimesis.enums import Gender

    address = Address()
    with address.override_locale('ru') as a:
        assert a.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'
    assert address.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:25:19.934203
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.gender(Gender.MALE) == 'мужской'
        assert person.gender(Gender.FEMALE) == 'женский'
        assert person.gender(Gender.NOT_SURE) == 'не уверен'
    assert p.gender(Gender.MALE) == 'male'
    assert p.gender(Gender.FEMALE) == 'female'
    assert p.gender(Gender.NOT_SURE) == 'not sure'

# Generated at 2022-06-17 22:25:27.866275
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('en') as person:
        assert person.gender(Gender.MALE) == 'Male'
        assert person.gender(Gender.FEMALE) == 'Female'
    assert p.gender(Gender.MALE) == 'Мужской'
    assert p.gender(Gender.FEMALE) == 'Женский'

# Generated at 2022-06-17 22:25:38.210431
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:25:45.747168
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address(locale='ru')
    person = Person(locale='ru')

    with address.override_locale('en') as a:
        assert a.locale == 'en'
        assert a.get_current_locale() == 'en'
        assert a.get_city() == 'New York'

    assert address.locale == 'ru'
    assert address.get_current_locale() == 'ru'
    assert address.get_city() == 'Москва'

    with person.override_locale('en') as p:
        assert p.locale == 'en'
        assert p.get_current_locale() == 'en'
        assert p.get