

# Generated at 2022-06-17 22:16:17.949100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Сергеевич Королев'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:16:28.793112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text

    # Test for Address
    address = Address()
    with address.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.get_current_locale() == address.get_current_locale()
    assert address.get_current_locale() == 'en'

    # Test for Datetime
    datetime = Datetime()

# Generated at 2022-06-17 22:16:36.005309
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.gender(gender=Gender.MALE) == 'Мужской'

    assert person.get_current_locale() == 'en'
    assert person.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:16:44.487938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.gender(gender=Gender.FEMALE) == 'женский'
    assert person.locale == 'en'
    assert person.gender(gender=Gender.FEMALE) == 'female'

# Generated at 2022-06-17 22:16:51.852754
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.web import Web
    from mimesis.providers.misc import Misc
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.music import Music

# Generated at 2022-06-17 22:16:58.799359
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    assert p.locale == 'en'
    assert p.gender() == Gender.MALE

    with p.override_locale('ru') as person:
        assert person.locale == 'ru'
        assert person.gender() == Gender.MALE

    assert p.locale == 'en'
    assert p.gender() == Gender.MALE

# Generated at 2022-06-17 22:17:07.369753
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Address, Person
    from mimesis.enums import Gender

    person = Person('en')
    address = Address('en')
    with person.override_locale('ru') as p:
        assert p.gender(Gender.MALE) == 'Мужской'
        assert p.gender(Gender.FEMALE) == 'Женский'
        assert p.full_name(gender=Gender.MALE) == 'Иван Сергеевич Петров'

# Generated at 2022-06-17 22:17:12.484787
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    p = Person('en')
    assert p.locale == 'en'
    assert p.get_current_locale() == 'en'

    with p.override_locale('ru') as p_ru:
        assert p_ru.locale == 'ru'
        assert p_ru.get_current_locale() == 'ru'
        assert p_ru.get_full_name(gender=Gender.MALE) == 'Александр Иванов'

    assert p.locale == 'en'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:22.488730
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            """Get data from provider.

            :return: Data from provider.
            """
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider

# Generated at 2022-06-17 22:17:33.349604
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:17:51.976680
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:18:04.493470
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text

    address = Address(seed=42)
    datetime = Datetime(seed=42)
    misc = Misc(seed=42)
    person = Person(seed=42)
    science = Science(seed=42)
    text = Text(seed=42)

    assert address.get_current_locale() == locales.EN
    assert datetime.get_current_locale() == locales.EN
    assert misc.get_current_locale() == locales.EN
    assert person.get

# Generated at 2022-06-17 22:18:15.482518
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:18:21.274542
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
        assert provider.get_data() == {'test': 'test'}



# Generated at 2022-06-17 22:18:31.259791
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.file import File
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.geography import Geography
    from mimesis.providers.transport import Transport

# Generated at 2022-06-17 22:18:41.377250
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:18:52.314050
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.geo import Geo
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport

# Generated at 2022-06-17 22:19:05.058417
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:15.449364
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data() == {'test': 'тест'}



# Generated at 2022-06-17 22:19:25.451947
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:52.836957
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.FEMALE) == 'Анастасия Савельева'
        assert person.full_name(gender=Gender.MALE) == 'Андрей Савельев'
    assert p.full_name(gender=Gender.FEMALE) == 'Sarah Smith'
    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:20:00.481461
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:20:09.009790
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name() == 'Александр Сергеевич Пушкин'
        assert p.full_name(gender='female') == 'Анна Андреевна Каренина'

    assert person.locale == 'en'
    assert person.full_name() == 'John Doe'

# Generated at 2022-06-17 22:20:19.674322
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    providers = [Address, Person, Datetime, Geography, Internet, Misc, Numbers,
                 Person, Science, Text, Transport, Unit]


# Generated at 2022-06-17 22:20:27.267994
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

    p = Person()
    assert p.full_name() == 'John Doe'

    with p.override_locale('ru') as p:
        assert p.full_name() == 'Иван Иванов'

    assert p.full_name() == 'John Doe'

    p = Person(locale='ru')
    assert p.full_name() == 'Иван Иванов'

    with p.override_locale('en') as p:
        assert p.full_name() == 'John Doe'

    assert p.full_

# Generated at 2022-06-17 22:20:37.426621
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.RU)
    assert provider.get_current_locale() == locales.RU
    assert provider.get_data() == {'test': 'Тест'}

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
        assert provider.get_data()

# Generated at 2022-06-17 22:20:46.446876
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self):
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_data() == {'test': 'Тест'}

    with provider.override_locale('en') as provider:
        assert provider.get_data() == {'test': 'Test'}

    assert provider.get_data() == {'test': 'Тест'}

# Generated at 2022-06-17 22:20:52.543887
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestDataProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_data('test') == 'test'

    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == 'тест'


# Generated at 2022-06-17 22:21:04.244837
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            """Get data."""
            return self._data

    provider = TestProvider()

# Generated at 2022-06-17 22:21:12.350255
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.person import Gender
    from mimesis.providers.person import Title
    from mimesis.providers.person import FormOfAddress

    address = Address(locale='ru')
    person = Person(locale='ru')

    with address.override_locale('en'):
        assert address.get_current_locale() == 'en'
        assert address.get_city() == 'Bartonshire'

    with person.override_locale('en'):
        assert person.get_current_locale() == 'en'

# Generated at 2022-06-17 22:22:05.794556
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'Тест'}

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:22:13.158351
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale

# Generated at 2022-06-17 22:22:22.938663
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'
        assert d.get_month_name() == 'Март'


# Generated at 2022-06-17 22:22:32.465618
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() != address.get_city()

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'
        assert ru_person.get_full_name() != person.get_full_name()


# Generated at 2022-06-17 22:22:40.681296
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:22:48.067874
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:23:00.369348
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale()

# Generated at 2022-06-17 22:23:07.606203
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> JSON:
            """Get data."""
            return self._data

    provider = TestProvider()

# Generated at 2022-06-17 22:23:13.903135
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Иван Иванов'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:23:22.731633
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    person = Person()
    address = Address()

    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

    with address.override_locale('ru') as a:
        assert a.city() == 'Москва'

    with person.override_locale('en') as p:
        assert p.full_name(gender=Gender.MALE) == 'John Doe'


# Generated at 2022-06-17 22:25:10.091708
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == 'Тест'
    assert provider.get_data('test') == 'Test'

# Generated at 2022-06-17 22:25:20.812198
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    p = Person()
    with p.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.get_current_locale() == 'ru'
        assert p.get_full_name(gender=Gender.MALE) == 'Александр Кузнецов'
        assert p.get_full_name(gender=Gender.FEMALE) == 'Анна Сидорова'
        assert p.get_full_name(gender=Gender.NOT_KNOWN) == 'Анна Сидорова'
        assert p

# Generated at 2022-06-17 22:25:30.210485
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:25:36.114975
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert provider.full_name() == 'Александр Кузьмин'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Smith'

# Generated at 2022-06-17 22:25:40.624659
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Александр Петров'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:25:47.334612
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.phone import Phone
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.system import System
    from mimesis.providers.generic import Generic
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.food import Food
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
   

# Generated at 2022-06-17 22:25:52.574902
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Александр Борисов'
    assert person.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:26:04.331597
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale(locales.RU) as ru_address:
        assert ru_address.get_current_locale() == locales.RU
        assert address.get_current_locale() == locales.EN

    assert address.get_current_locale() == locales.EN

    with person.override_locale(locales.RU) as ru_person:
        assert ru_person.get_current_locale() == locales.RU
        assert person.get_current_locale() == locales.EN

    assert person.get_current_loc