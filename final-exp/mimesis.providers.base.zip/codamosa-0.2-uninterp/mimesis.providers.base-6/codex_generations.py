

# Generated at 2022-06-17 22:16:23.129850
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:16:29.072886
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Анна Сидорова'

    assert person.get_current_locale() == 'en'
    assert person.full_name() == 'Anna Sidorova'

# Generated at 2022-06-17 22:16:33.169915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:16:42.088689
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.filesystem import FileSystem
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.geography import Geography
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.code import Code
    from mimesis.providers.identifiers import Identifiers

# Generated at 2022-06-17 22:16:51.162765
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == person.full_name(gender=Gender.MALE)

    with person_provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == person_provider.full_name(gender=Gender.MALE)

# Generated at 2022-06-17 22:16:58.895953
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'

    assert p.get_current_locale() == 'en'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:17:07.492260
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:17:10.120910
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:20.562292
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    address = Address()
    person = Person()
    misc = Misc()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Московская'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Петров'

    with misc.override_locale('ru') as m:
        assert m.get_current_locale

# Generated at 2022-06-17 22:17:26.933995
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Иван Иванов'
    assert person.get_current_locale() == 'en'
    assert person.full_name() == 'John Smith'

# Generated at 2022-06-17 22:17:41.749246
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('en') as person:
        assert person.full_name(gender=Gender.MALE) == 'John Smith'

    assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

# Generated at 2022-06-17 22:17:50.695719
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestDataProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == 'Тест'

    assert provider.get_data('test') == 'Test'

# Generated at 2022-06-17 22:17:58.714823
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Алтайский край'

    assert address.get_current_locale() == 'en'
    assert address.get_region() == 'Alabama'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:18:08.100215
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

# Generated at 2022-06-17 22:18:15.280191
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Алтайский край'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Петров'


# Generated at 2022-06-17 22:18:23.457701
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_data('test') == {'test': 'тест'}

    assert provider.get_data('test') == {'test': 'test'}

# Generated at 2022-06-17 22:18:33.023688
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'en': 'English'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:18:42.632914
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'Тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:53.641370
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    address = Address()
    person = Person()
    misc = Misc()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() != address.get_city()

    assert address.get_current_locale() == 'en'
    assert address.get_city() != ru_address.get_city()

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'
        assert ru_person.get_full_name() != person.get_full

# Generated at 2022-06-17 22:19:05.533254
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.geo import Geo
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.unit import Unit


# Generated at 2022-06-17 22:19:31.837505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, Person
    from mimesis.enums import Gender

    p = Person('en')
    a = Address('en')

    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Петров'
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Сидорова'

        with a.override_locale('ru') as address:
            assert address.street_name() == 'Советская'
            assert address.city() == 'Санкт-Петербург'

        assert person.full_

# Generated at 2022-06-17 22:19:38.714597
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Петрова'

    assert p.full_name(gender=Gender.FEMALE) == 'Anna Petrov'

# Generated at 2022-06-17 22:19:49.792607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    address = Address()
    with address.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.get_full_name(gender=Gender.MALE) == 'Иван Иванов'
        assert ru.get_full_name(gender=Gender.FEMALE) == 'Анна Иванова'

    assert address.get_current_locale() == 'en'
    assert address.get_full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:19:58.504578
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:20:06.270540
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale=locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self, key):
            return self._data[key]

    provider = TestProvider()
    assert provider.get_data('test') == 'test'

    with provider.override_locale('ru') as p:
        assert p.get_data('test') == 'тест'

    assert provider.get_data('test') == 'test'

# Generated at 2022-06-17 22:20:17.853895
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en')
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.gender(Gender.MALE) == 'мужской'
        assert ru.gender(Gender.FEMALE) == 'женский'
        assert ru.gender(Gender.UNKNOWN) == 'неизвестный'
    assert p.get_current_locale() == 'en'
    assert p.gender(Gender.MALE) == 'male'
    assert p.gender(Gender.FEMALE) == 'female'

# Generated at 2022-06-17 22:20:24.466356
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Александр Иванов'
    assert person.locale == 'en'
    assert person.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:20:35.625509
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:20:39.716170
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> JSON:
            """Get data from JSON file.

            :return: Data from JSON file.
            """
            return self._data

    provider = TestProvider()

# Generated at 2022-06-17 22:20:46.209873
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def get_current_locale(self):
            return self.locale

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:21:38.512112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.FEMALE) == 'Александра Петрова'

    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.FEMALE) == 'Alexandra Peterson'

# Generated at 2022-06-17 22:21:46.209766
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_test_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_test_data() == {'test': 'тест'}
    assert provider.get_test_data() == {'test': 'test'}

# Generated at 2022-06-17 22:21:53.385155
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.code import Code
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.geography import Geography
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:22:02.571260
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'
    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:22:08.708751
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.structures import Structures
    from mimesis.providers.system import System
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit


# Generated at 2022-06-17 22:22:14.867901
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit
    from mimesis.providers.business import Business
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person

# Generated at 2022-06-17 22:22:24.315032
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:34.051184
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Санкт-Петербург'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'
        assert d.get_

# Generated at 2022-06-17 22:22:41.172366
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:22:48.329125
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    p = Person()
    with p.override_locale('ru') as person:
        assert person.locale == 'ru'
        assert person.gender() == Gender.MALE
        assert person.gender(Gender.FEMALE) == Gender.FEMALE
        assert person.gender(Gender.UNKNOWN) == Gender.UNKNOWN
        assert person.gender(Gender.UNKNOWN) == Gender.UNKNOWN
        assert person.gender(Gender.UNKNOWN) == Gender.UNKNOWN
        assert person.gender(Gender.UNKNOWN) == Gender.UNKNOWN

# Generated at 2022-06-17 22:24:36.989104
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            """Get data from JSON file.

            :return: Data from JSON file.
            """
            return self._data

    provider = TestProvider(locale=locales.EN)

# Generated at 2022-06-17 22:24:42.925424
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'тест'}
        assert p.get_current_locale() == locales.RU

    assert provider.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == local

# Generated at 2022-06-17 22:24:50.135354
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    address = Address('en')

    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Андрей Петров'
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Сидорова'

    with address.override_locale('ru') as a:
        assert a.city() == 'Москва'
        assert a.country() == 'Россия'


# Generated at 2022-06-17 22:25:03.284250
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:25:10.181166
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'
        assert provider.get_data() == {'test': 'тест'}



# Generated at 2022-06-17 22:25:19.396159
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_data() == {'test': 'test'}
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:25:29.027341
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> JSON:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data() == {'test': 'test'}

    assert provider.get_

# Generated at 2022-06-17 22:25:38.909130
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    address = Address()
    person = Person()
    misc = Misc()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_full_name() == 'Алексей Карпов'


# Generated at 2022-06-17 22:25:46.220113
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:25:54.901393
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> JSON:
            """Get data."""
            return self._data

    provider = TestProvider()