

# Generated at 2022-06-17 22:16:23.866106
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.vehicle import Vehicle

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()
    vehicle = Vehicle()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Новосибирск'

    with datetime.override_locale('ru') as d:
        assert d.get_

# Generated at 2022-06-17 22:16:31.320387
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    p = Person()
    p_en = PersonProvider(locale='en')
    p_ru = PersonProvider(locale='ru')
    p_en_male = PersonProvider(locale='en', gender=Gender.MALE)
    p_ru_male = PersonProvider(locale='ru', gender=Gender.MALE)
    p_en_female = PersonProvider(locale='en', gender=Gender.FEMALE)
    p_ru_female = PersonProvider(locale='ru', gender=Gender.FEMALE)
    assert p.full_name() in p_en.full_name()
    assert p.full_name(gender=Gender.MALE)

# Generated at 2022-06-17 22:16:36.393354
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    p = Person('en')
    with p.override_locale('ru'):
        assert p.full_name(gender=Gender.MALE) == 'Андрей Петров'
    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:16:47.690711
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:16:58.608507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as p:
        assert p.gender(gender=Gender.MALE) == 'Мужской'
        assert p.gender(gender=Gender.FEMALE) == 'Женский'
    assert p.gender(gender=Gender.MALE) == 'Male'
    assert p.gender(gender=Gender.FEMALE) == 'Female'

    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:17:04.210940
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Петров'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:17:12.597094
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Utils

    p = Person()
    assert p.full_name() == 'John Doe'
    assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'

    with p.override_locale('ru'):
        assert p.full_name() == 'Иван Иванов'

# Generated at 2022-06-17 22:17:20.979687
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale='en')
    with provider.override_locale('ru') as p:
        assert p.get_data('test') == 'тест'

    assert provider.get_data('test') == 'test'

# Generated at 2022-06-17 22:17:31.449441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    assert provider.get_data('key') == 'value'

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data('key') == 'значение'

    assert provider.get_data('key') == 'value'


# Generated at 2022-06-17 22:17:41.151850
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.financial import Financial

# Generated at 2022-06-17 22:18:03.258084
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()
    assert person.full_name() != person_provider.full_name()

    with person_provider.override_locale(locales.EN) as provider:
        assert provider.full_name() == person.full_name()

    with person_provider.override_locale(locales.RU) as provider:
        assert provider.full_name() != person.full_name()


# Generated at 2022-06-17 22:18:11.088709
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Person as PersonEn
    from mimesis.providers.person.ru import Person as PersonRu

    person = Person()
    person_en = PersonEn()
    person_ru = PersonRu()

    assert person.get_current_locale() == locales.EN
    assert person_en.get_current_locale() == locales.EN
    assert person_ru.get_current_locale() == locales.RU

    assert person.full_name() == person_en.full_name()

# Generated at 2022-06-17 22:18:20.364009
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:18:29.175071
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:39.420715
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:18:48.025519
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Семенова'

    with person_provider.override_locale('ru') as p:
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Семенова'

# Generated at 2022-06-17 22:18:57.554970
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Санкт-Петербург'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:06.425644
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_data() == {'test': 'тест'}

    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:19:16.464610
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Иван Иванов'

    assert person.get_current_

# Generated at 2022-06-17 22:19:26.436876
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:19:55.065545
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:20:04.727928
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'Тест'}

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:20:11.565881
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            """Get data."""
            return self._data

    provider = TestProvider()

# Generated at 2022-06-17 22:20:21.970026
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Новосибирск'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'New York'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Иван Петров'

   

# Generated at 2022-06-17 22:20:30.368080
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU):
        assert provider.get_data('key') == 'ru'

    assert provider.get_data('key') == 'en'

# Generated at 2022-06-17 22:20:40.013500
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:20:48.450575
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.RU)
    assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:20:56.432812
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:21:05.473742
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.financial import Financial

# Generated at 2022-06-17 22:21:08.819421
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:22:02.983297
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'test_ru'}
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:22:09.145256
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import PersonProvider
    from mimesis.providers.address import AddressProvider
    from mimesis.providers.geography import GeographyProvider
    from mimesis.providers.internet import InternetProvider
    from mimesis.providers.misc import MiscProvider
    from mimesis.providers.numbers import NumbersProvider
    from mimesis.providers.payment import PaymentProvider
    from mimesis.providers.science import ScienceProvider
    from mimesis.providers.text import TextProvider
    from mimesis.providers.time import TimeProvider
    from mimesis.providers.unit import UnitProvider
    from mimesis.providers.vehicle import VehicleProvider

# Generated at 2022-06-17 22:22:18.511482
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:27.277523
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc

    person = Person()
    address = Address()
    internet = Internet()
    misc = Misc()

    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Александр Королев'
        assert person.full_name(gender='male') == 'Александр Королев'

# Generated at 2022-06-17 22:22:36.676813
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.file import File
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.geo import Geo
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport

# Generated at 2022-06-17 22:22:44.234412
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'проверка'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:22:51.035257
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Александр Капустин'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:23:03.551114
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-17 22:23:12.867909
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    person = Person()
    address = Address()

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Анастасия Константиновна Семенова'

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.city() == 'Москва'

    assert person.get_current_locale() == 'en'
   

# Generated at 2022-06-17 22:23:19.704520
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.RU)
    with provider.override_locale(locales.EN) as provider:
        assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:25:12.509613
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)

        def get_current_locale(self):
            return self.locale

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:20.965548
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data('test') == {'test': 'test'}

    assert provider.get_data('test') == {'test': 'тест'}

# Generated at 2022-06-17 22:25:28.864474
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.get_full_name(gender=Gender.MALE) == 'Андрей Сергеевич Петров'

    assert p.get_current_locale() == 'en'
    assert p.get_full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:25:37.498563
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'

    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:25:45.204683
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:25:53.949697
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:26:02.274363
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.full_name() == 'John Doe'
    assert p.get_current_locale() == 'ru'
    assert p.full_name() == 'Иван Иванов'