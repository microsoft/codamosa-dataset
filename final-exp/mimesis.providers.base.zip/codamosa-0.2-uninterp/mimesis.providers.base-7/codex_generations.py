

# Generated at 2022-06-17 22:16:23.459153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import JSON

    p = Person()
    with p.override_locale('ru') as person:
        assert person.locale == 'ru'
        assert person.full_name(gender=Gender.MALE) == 'Александр Кузнецов'
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Сидорова'

# Generated at 2022-06-17 22:16:31.196451
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('en'):
        assert person.get_current_locale() == 'en'

    assert person.get_current_locale() == 'en'

    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'

    assert person.get_current_locale() == 'en'

    with person.override_locale('ru'):
        assert person.get_current_locale() == 'ru'

    assert person.get_current_locale() == 'en'


# Generated at 2022-06-17 22:16:40.497340
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.base import BaseDataProvider
    from mimesis.typing import JSON

    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> JSON:
            return self._data

    provider = TestProvider()
    assert provider.get_data() == {'test': 'test'}


# Generated at 2022-06-17 22:16:50.331846
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

# Generated at 2022-06-17 22:16:58.461040
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:17:06.889693
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:17:14.207964
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:17:23.549976
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'тест'}

    with provider.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'test': 'test'}


# Generated at 2022-06-17 22:17:33.256729
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import JSON

    p = Person()
    with p.override_locale('ru') as person:
        assert person.locale == 'ru'
        assert person.get_current_locale() == 'ru'
        assert person.full_name(gender=Gender.MALE) == 'Андрей Сергеевич Сергеев'

# Generated at 2022-06-17 22:17:36.786618
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:55.877994
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'New York'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Иван Иванов'

    assert person.get_

# Generated at 2022-06-17 22:18:04.392438
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:18:15.444422
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address(locale='ru')
    datetime = Datetime(locale='ru')
    person = Person(locale='ru')
    text = Text(locale='ru')

    with address.override_locale('en') as a:
        assert a.get_current_locale() == 'en'
        assert a.get_city() != address.get_city()

    with datetime.override_locale('en') as d:
        assert d.get_current_locale() == 'en'
       

# Generated at 2022-06-17 22:18:23.810822
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, str]:
            return self._data[key]

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_data('test') == {'test': 'Тест'}
    assert provider.get_data('test') == {'test': 'Test'}

# Generated at 2022-06-17 22:18:33.173210
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Сергеевна Сидорова'
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Сергеевна Сидорова'
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Сергеевна Сидорова'

# Generated at 2022-06-17 22:18:40.898036
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:46.691148
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en')
    assert p.get_current_locale() == 'en'
    assert p.get_full_name(gender=Gender.MALE) == 'John Smith'

    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
        assert p.get_full_name(gender=Gender.MALE) == 'Иван Иванов'

    assert p.get_current_locale() == 'en'
    assert p.get_full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:18:50.567345
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert person.get_current_locale() == 'en'

# Generated at 2022-06-17 22:19:03.649258
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_data() == {'test': 'Тест'}
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:19:13.939504
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:42.508305
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.person import Person as PersonProvider

    p = Person()
    p.seed(42)
    p.gender = Gender.MALE
    assert p.full_name() == 'Mr. Johnathan'

    with p.override_locale('ru') as ru:
        assert ru.full_name() == 'Андрей Кузнецов'

    assert p.full_name() == 'Mr. Johnathan'

    p = PersonProvider()
    p.seed(42)
    p.gender = Gender.MALE
    assert p.full_name() == 'Mr. Johnathan'


# Generated at 2022-06-17 22:19:50.727493
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.get_full_name() == 'Анастасия Кузнецова'
    assert p.get_current_locale() == 'en'
    assert p.get_full_name() == 'Michele Mckay'

# Generated at 2022-06-17 22:20:03.173642
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    p = TestProvider()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_data('key') == 'value'

    assert p.get_current_locale() == locales.DEFAULT_LOCALE
    assert p.get_data('key') == 'value'

# Generated at 2022-06-17 22:20:10.659173
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, str]:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == {'key': 'value'}
        assert p.get_current_locale() == locales.RU

    assert provider.get_data('test') == {'key': 'value'}
    assert provider

# Generated at 2022-06-17 22:20:21.233942
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:20:28.705481
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:20:36.968427
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN


# Generated at 2022-06-17 22:20:43.573638
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:20:50.842159
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport

    address = Address()
    datetime = Datetime()
    geography = Geography()
    internet = Internet()
    person = Person()
    science = Science()
    text = Text()
    transport = Transport()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_full

# Generated at 2022-06-17 22:21:03.530973
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:21:51.679144
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.gender(gender=Gender.MALE) == 'Мужской'

    assert p.get_current_locale() == 'en'
    assert p.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:22:02.681389
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:22:08.824645
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:14.950153
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:22:23.494410
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestDataProvider(locale=locales.EN)
    with provider.override_locale(locales.RU):
        assert provider.get_data('test') == 'Тест'

    assert provider.get_data('test') == 'Test'

# Generated at 2022-06-17 22:22:32.130407
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'test'}

    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:22:39.802113
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestDataProvider()
    assert provider.get_data('key') == 'value'
    with provider.override_locale('ru') as p:
        assert p.get_data('key') == 'значение'
    assert provider.get_data('key') == 'value'

# Generated at 2022-06-17 22:22:47.368614
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:55.975967
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    address = Address()
    datetime = Datetime()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Московская область'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'
        assert d.get_day_of_week() == 'пятница'


# Generated at 2022-06-17 22:23:05.403074
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:24:49.329592
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('en') as p:
        assert p.full_name(gender=Gender.MALE) == 'John Doe'
        assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'
    assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'
    assert p.full_name(gender=Gender.FEMALE) == 'Иванова Ивана'

# Generated at 2022-06-17 22:24:54.980330
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': {'ru': 'Тест'}}

    assert provider.get_current_locale() == locales.EN
    assert provider.get_

# Generated at 2022-06-17 22:25:05.622651
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    address = Address()
    datetime = Datetime()
    geography = Geography()
    internet = Internet()
    person = Person()
    science = Science()
    text = Text()
    transport = Transport()
    unit = Unit()


# Generated at 2022-06-17 22:25:10.349869
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name() == 'Андрей Константинович Сидоров'
    assert person.locale == locales.DEFAULT_LOCALE
    assert person.full_name() == 'John Doe'

# Generated at 2022-06-17 22:25:16.003579
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address

    address = Address()
    with address.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'

    assert address.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:21.587507
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.gender(gender=Gender.FEMALE) == 'женский'

    assert p.get_current_locale() == 'en'
    assert p.gender(gender=Gender.FEMALE) == 'female'

# Generated at 2022-06-17 22:25:28.444774
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU):
        assert provider.locale == locales.RU
    assert provider.locale == locales.EN

# Generated at 2022-06-17 22:25:38.392131
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    address = Address()
    person = Person()
    misc = Misc()

    with address.override_locale(locales.EN):
        assert address.get_current_locale() == locales.EN
        assert address.get_city() == 'New York'

    with person.override_locale(locales.RU):
        assert person.get_current_locale() == locales.RU
        assert person.get_full_name() == 'Анастасия Сергеевна Петрова'



# Generated at 2022-06-17 22:25:41.150347
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:47.550982
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale(locales.RU) as ru_address:
        assert ru_address.get_current_locale() == locales.RU
        assert ru_address.get_city() == 'Москва'

    assert address.get_current_locale() == locales.EN
    assert address.get_city() == 'New York'

    with person.override_locale(locales.RU) as ru_person:
        assert ru_person.get_current