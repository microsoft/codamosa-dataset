

# Generated at 2022-06-17 22:16:24.707096
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale='ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:16:31.673163
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:16:40.546610
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_data() == {'test': 'test'}
    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:16:46.910634
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.file import File
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:16:57.981841
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()
    with person_provider.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name(gender=Gender.MALE) == person.full_name(
            gender=Gender.MALE, locale='ru')
    assert person_provider.locale == locales.DEFAULT_LOCALE

    with person_provider.override_locale('en') as p:
        assert p.locale == 'en'

# Generated at 2022-06-17 22:17:06.611592
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:17:14.056555
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'
        assert d.get_day_of_week() == 'понедельник'


# Generated at 2022-06-17 22:17:23.549936
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale='en') as provider:
        assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:33.256889
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
    from mimesis.providers.business import Business
    from mimesis.providers.file import File

# Generated at 2022-06-17 22:17:42.485585
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data() == {'test': 'test'}

   

# Generated at 2022-06-17 22:18:01.227591
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as russian_person:
        assert russian_person.get_current_locale() == 'ru'
        assert russian_person.full_name() == 'Андрей Куликов'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:18:09.611112
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data() == {'test': 'тест'}

    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:18:19.352630
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_data() == {'test': 'test'}
        assert p.get_current_locale() == locales.EN

    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:18:29.563386
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:18:34.910768
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.name() == 'Анастасия'
    assert p.get_current_locale() == 'en'
    assert p.name() == 'John'

# Generated at 2022-06-17 22:18:41.059032
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Сергеевич Смирнов'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:18:48.024817
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person(locale='ru')
    with p.override_locale('en') as person:
        assert person.full_name(gender=Gender.MALE) == 'John Smith'

    assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

# Generated at 2022-06-17 22:18:57.554689
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:19:06.651363
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:19:17.387961
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            super().__init__(locale=locale)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    provider = TestProvider(locale=locales.RU)
    with provider.override_locale(locale=locales.EN) as p:
        assert p.get_current_locale() == locales.EN
    assert provider.get_current

# Generated at 2022-06-17 22:19:43.143707
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Петров'

    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:19:53.289832
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.geo import Geo
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.finance import Finance
    from mimesis.providers.food import Food
    from mimesis.providers.transport import Transport

# Generated at 2022-06-17 22:20:01.301110
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:20:08.906204
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Иван Иванов'
        assert person.full_name(gender=Gender.FEMALE) == 'Ирина Иванова'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'
    assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'

# Generated at 2022-06-17 22:20:19.583928
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address(locale='ru')
    person = Person(locale='ru')
    text = Text(locale='ru')

    with address.override_locale('en'):
        assert address.get_current_locale() == 'en'
        assert address.get_full_address() == '821 W. Dorton St.'

    with person.override_locale('en'):
        assert person.get_current_locale() == 'en'
        assert person.full_name() == 'Johnathan M. Hahn'


# Generated at 2022-06-17 22:20:27.223337
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru'):
        assert address.get_current_locale() == 'ru'
        assert address.get_city() == 'Калининград'
        assert address.get_country() == 'Россия'

# Generated at 2022-06-17 22:20:37.385924
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:20:47.365761
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.transport import Transport
    from mimesis.providers.web import Web

    test_providers = [
        Address,
        Geography,
        Person,
        Science,
        Text,
        Time,
        Transport,
        Web,
    ]

    for provider in test_providers:
        p = provider(seed=42)

# Generated at 2022-06-17 22:20:54.888747
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as person_ru:
        assert person_ru.get_current_locale() == 'ru'
        assert person_ru.gender(gender=Gender.MALE) == 'Мужской'

    assert person.get_current_locale() == 'en'
    assert person.gender(gender=Gender.MALE) == 'Male'

# Generated at 2022-06-17 22:21:04.841294
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:22:04.697372
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:22:12.360717
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider
   

# Generated at 2022-06-17 22:22:17.521250
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale, seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:22:25.198739
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, str]:
            return self._data[key]

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data('test') == {'test': 'test'}

    assert provider.get_data('test') == {'test': 'тест'}

# Generated at 2022-06-17 22:22:34.538055
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:22:42.468312
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    assert person.gender(gender=Gender.MALE) == 'male'
    assert person_provider.gender(gender=Gender.MALE) == 'male'

    with person.override_locale('ru'):
        assert person.gender(gender=Gender.MALE) == 'мужской'

    with person_provider.override_locale('ru'):
        assert person_provider.gender(gender=Gender.MALE) == 'мужской'

# Generated at 2022-06-17 22:22:48.191095
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:23:00.679503
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:23:07.054281
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    class Person(PersonProvider):
        def __init__(self, seed: Seed = None, locale: str = locales.EN,
                     gender: Gender = None) -> None:
            super().__init__(seed=seed, locale=locale)
            self._gender = gender

        def get_full_name(self, gender: Gender = None) -> str:
            """Get full name.

            :param gender: Gender.
            :return: Full name.
            """
            gender = self._validate_enum(gender, Gender)
            return super().get_full_name(gender=gender)

    person = Person(seed=42, gender=Gender.FEMALE)


# Generated at 2022-06-17 22:23:13.941985
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Марина Кузнецова'
    assert person.get_current_locale() == 'en'
    assert person.full_name() == 'Marina Kuznetsova'

# Generated at 2022-06-17 22:25:09.334654
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name() == p.full_name()
    assert p.full_name() != person.full_name()

# Generated at 2022-06-17 22:25:14.351050
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Анна Петрова'


# Generated at 2022-06-17 22:25:18.867535
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:25:28.864376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:25:38.733352
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()
        def get_data(self) -> Dict[str, str]:
            return self._data
    provider = TestProvider(locale=locales.RU)
    assert provider.get_current_locale() == locales.RU
    assert provider.get_data() == {'test': 'test_ru'}
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data

# Generated at 2022-06-17 22:25:46.098406
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography

    address = Address(locale='ru')
    with address.override_locale('en') as address_en:
        assert address_en.get_current_locale() == 'en'
        assert address_en.get_city() != address.get_city()

    with address.override_locale('ru') as address_ru:
        assert address_ru.get_current_locale() == 'ru'
        assert address_ru.get_city() == address.get_city()

    with Geography().override_locale('en') as geography_en:
        assert geography_en.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:54.870645
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_full_name() == 'Алексей Карасев'


# Generated at 2022-06-17 22:26:04.444599
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data() == {'test': 'тест'}

    assert provider.get_data() == {'test': 'test'}