

# Generated at 2022-06-17 22:16:23.865703
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:16:31.319385
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:16:40.596818
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

    p = Person()
    p_en = Person(locale='en')
    p_ru = Person(locale='ru')

    with p.override_locale('en') as p_en:
        assert p_en.full_name() == 'John Doe'
        assert p_en.full_name(gender=Gender.MALE) == 'John Doe'
        assert p_en.full_name(gender=Gender.FEMALE) == 'Jane Doe'


# Generated at 2022-06-17 22:16:50.390607
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'test'}
        assert p.get_current_locale() == 'ru'

    assert provider.get_data() == {'test': 'test'}
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:16:57.287316
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:04.755344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN



# Generated at 2022-06-17 22:17:09.704640
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:17:17.906822
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:26.741235
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.full_name(gender=Gender.MALE) == 'Иван Сергеевич Сидоров'

    assert p.get_current_locale() == 'en'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

    with p.override_locale('ru') as ru:
        assert ru.get_current_locale()

# Generated at 2022-06-17 22:17:36.898449
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:17:56.140523
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport

    # Test for Address
    address = Address()
    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'


# Generated at 2022-06-17 22:18:07.320797
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_current_locale() == 'en'
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:18:17.961568
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data() == {'test': 'тест'}

   

# Generated at 2022-06-17 22:18:29.563466
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_data() == {'test': 'тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:37.892213
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:45.016731
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    with person_provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_full_name(gender=Gender.MALE) != person.get_full_name(gender=Gender.MALE)

    assert person_provider.get_current_locale() == 'en'
    assert person_provider.get_full_name(gender=Gender.MALE) == person.get_full_name(gender=Gender.MALE)

# Generated at 2022-06-17 22:18:55.583971
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text
    from mimesis.providers.file import File
    from mimesis.providers.code import Code
    from mimesis.providers.payment import Payment
    from mimesis.providers.business import Business
    from mimesis.providers.science import Science
    from mimesis.providers.geography import Geography
    from mimesis.providers.transport import Transport

# Generated at 2022-06-17 22:19:05.643714
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'test'}
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:19:16.006580
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_data() == {'en': 'English'}

    with provider.override_locale(locale='ru') as p:
        assert p.get_data() == {'en': 'English', 'ru': 'Russian'}

    assert provider.get_data() == {'en': 'English'}

# Generated at 2022-06-17 22:19:26.034726
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
        assert provider.get_data()['test'] == 'тест'

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data()['test'] == 'test'



# Generated at 2022-06-17 22:19:42.759384
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:19:47.017999
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_test_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_test_data() == {'en': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_test_data() == {'en': 'test', 'ru': 'тест'}

    assert provider.get_test_data() == {'en': 'test'}

# Generated at 2022-06-17 22:19:52.751028
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Краснодарский край'

    assert address.get_current_locale() == 'en'
    assert address.get_region() == 'New York'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:58.251955
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Андрей Петров'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:20:07.294718
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as address_ru:
        assert address_ru.get_current_locale() == 'ru'
        assert address_ru.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as person_ru:
        assert person_ru.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:20:18.671654
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:20:23.128558
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert person.get_current_locale() == 'en'

# Generated at 2022-06-17 22:20:33.397068
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:20:42.083623
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN
        assert provider.get_data() == {'test': 'test'}



# Generated at 2022-06-17 22:20:50.205732
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.phone import Phone
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.web import Web

    # Test for builtins
    p = Person()
    assert p.full_name() == 'John Doe'
    assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'

    with p.override_locale('ru'):
        assert p.full_

# Generated at 2022-06-17 22:21:12.918044
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    address = Address()
    with address.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert address.get_current_locale() == 'ru'
    assert address.get_current_locale() == 'en'

# Generated at 2022-06-17 22:21:20.993177
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-17 22:21:30.467102
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.transport import Transport
    from mimesis.providers.business import Business

    # Test for Person
    person = Person()

# Generated at 2022-06-17 22:21:37.208376
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'

# Generated at 2022-06-17 22:21:43.562070
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    address = Address()
    person = Person()
    misc = Misc()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'New York'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:21:48.281025
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:21:53.845463
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as provider:
        assert provider.get_data() == {'test': 'test'}
    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:22:05.065331
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    provider.get_data()
    assert provider.get_data() == {'en': 'English'}

    with provider.override_locale('ru'):
        assert provider.get_data() == {'ru': 'Russian'}

    assert provider.get_data() == {'en': 'English'}

# Generated at 2022-06-17 22:22:10.517499
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as PersonProvider

    person = Person()
    person_provider = PersonProvider()

    with person_provider.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name(gender=Gender.MALE) == person.full_name(gender=Gender.MALE, locale='ru')

    assert person_provider.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-17 22:22:20.645247
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web

    address = Address()
    datetime = Datetime()
    person = Person()
    text = Text()
    web = Web()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'
        assert a.get_region() == 'Московская область'

# Generated at 2022-06-17 22:23:06.434487
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test_data.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:23:15.862550
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    providers = [Address, Person, Geography, Internet, Numbers, Science, Text,
                 Time, Transport, Unit]

    for provider in providers:
        p = provider()
        with p.override_locale('ru') as p:
            assert p.get_current_

# Generated at 2022-06-17 22:23:20.699272
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Андрей Ковалев'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:23:30.111730
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address(locale='ru')
    person = Person(locale='ru')

    with address.override_locale('en') as address_en:
        with person.override_locale('en') as person_en:
            assert address_en.get_current_locale() == 'en'
            assert person_en.get_current_locale() == 'en'
            assert address_en.get_full_address() != address.get_full_address()
            assert person_en.full_name() != person.full_name()

    assert address.get_current_locale() == 'ru'
    assert person.get_

# Generated at 2022-06-17 22:23:36.137073
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:23:43.381845
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.get_data() == {'test': 'тест'}


# Generated at 2022-06-17 22:23:51.523690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc

    person = Person()
    address = Address()
    internet = Internet()
    misc = Misc()

    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name() == 'Александр Павлов'

    with address.override_locale('ru') as a:
        assert a.locale == 'ru'
        assert a.country() == 'Россия'


# Generated at 2022-06-17 22:24:04.209616
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU) as p:
        assert p.get_current_locale() == locales.RU
        assert p.get_data() == {'test': 'Тест'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_

# Generated at 2022-06-17 22:24:12.932864
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == 'Тест'
    assert provider.get_data('test') == 'Test'

# Generated at 2022-06-17 22:24:15.607323
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:25:53.633966
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:25:58.614206
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    with Person().override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert Person().get_current_locale() == 'en'