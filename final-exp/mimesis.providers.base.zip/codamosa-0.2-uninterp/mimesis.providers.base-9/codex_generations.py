

# Generated at 2022-06-17 22:16:16.896411
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() != p.full_name()

    assert p.get_current_locale() == 'en'
    assert p.full_name() != person.full_name()

# Generated at 2022-06-17 22:16:25.351759
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.full_name() == 'Александр Сергеевич Пушкин'

    assert person.locale == 'en'
    assert person.full_name() == 'John Doe'

# Generated at 2022-06-17 22:16:36.775432
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:16:48.031347
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    # Test for Address
    address = Address()
    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Санкт-Петербург'
    assert address.get_current_locale() == 'en'
   

# Generated at 2022-06-17 22:16:53.444118
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:17:00.777038
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Андрей Сергеевич Кузнецов'

    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:17:08.687824
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.RU) as provider:
        assert provider.get_data() == {'test': 'тест'}
    assert provider.get_data() == {'test': 'test'}

# Generated at 2022-06-17 22:17:19.710902
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as adr:
        assert adr.get_current_locale() == 'ru'
        assert adr.get_city() == 'Москва'

    assert address.get_current_locale() == 'en'
    assert address.get_city() == 'London'

    with person.override_locale('ru') as prs:
        assert prs.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:17:29.774915
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:17:40.178339
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:17:57.753393
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU) as ru_provider:
        assert ru_provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:18:07.835684
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'test': 'тест'}

    with provider.override_locale('en') as provider:
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'test': 'test'}


# Generated at 2022-06-17 22:18:18.322758
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self, key: str) -> Dict[str, Any]:
            return self._data[key]

    provider = TestProvider(locale=locales.EN)
    assert provider.get_data('test') == {'en': 'test'}

    with provider.override_locale(locales.RU) as p:
        assert p.get_data('test') == {'en': 'test', 'ru': 'тест'}


# Generated at 2022-06-17 22:18:29.330947
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Московская'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Максимов'

    assert address.get_current_locale() == 'en'
    assert person.get_current_locale() == 'en'

# Generated at 2022-06-17 22:18:37.118558
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:18:43.499060
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider(locale='en')
    with provider.override_locale(locale='ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-17 22:18:54.418608
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with datetime.override_locale('ru') as d:
        assert d.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:19:05.845603
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    datetime = Datetime()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru'):
        assert address.get_current_locale() == 'ru'
        assert address.get_city() == 'Калининград'
        assert address.get_street_name() == 'Карла Маркса'

   

# Generated at 2022-06-17 22:19:15.492470
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
        assert provider.get_data() == {'en': 'data'}

    assert provider.get_current_locale() == 'ru'
    assert provider.get_data() == {'ru': 'data'}

# Generated at 2022-06-17 22:19:24.304660
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'test'}
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:19:43.187701
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.geography import Geography

    address = Address()
    person = Person()
    geography = Geography()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Краснодарский край'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name() == 'Александр Иванов'


# Generated at 2022-06-17 22:19:53.326922
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.get_data()['test'] == 'Тест'

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'
        assert provider.get_data()['test'] == 'Test'

    assert provider

# Generated at 2022-06-17 22:20:03.062911
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'
        assert person.full_name(gender=Gender.FEMALE) == 'Анна Андреевна Ахматова'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'
    assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'

# Generated at 2022-06-17 22:20:13.052900
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.utils import Utils
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.financial import Financial
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code

# Generated at 2022-06-17 22:20:21.652639
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
        assert p.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'
    assert person.get_current_locale() == 'en'
    assert person.full_name(gender=Gender.MALE) == 'John Doe'

# Generated at 2022-06-17 22:20:27.218895
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Андрей Королев'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Doe'

# Generated at 2022-06-17 22:20:37.385535
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale='ru')
    with provider.override_locale('en') as p:
        assert p.get_data() == {'test': 'test'}
        assert p.locale == 'en'
        assert provider.locale == 'ru'

    assert provider.locale == 'ru'
    assert provider.get_data() == {'test': 'тест'}

# Generated at 2022-06-17 22:20:43.155898
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.get_data() == {'test': 'Тест'}
    assert provider.get_data() == {'test': 'Test'}

# Generated at 2022-06-17 22:20:48.107278
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    with p.override_locale('en') as person:
        assert person.full_name(gender=Gender.MALE) == 'John Smith'

    assert p.full_name(gender=Gender.MALE) == 'Иван Иванов'

# Generated at 2022-06-17 22:20:57.016120
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.date import Date
    from mimesis.providers.time import Time
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.geography import Geography
    from mimesis.providers.science import Science

# Generated at 2022-06-17 22:21:11.445007
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    assert p.get_current_locale() == locales.DEFAULT_LOCALE
    with p.override_locale(locales.EN):
        assert p.get_current_locale() == locales.EN
    assert p.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:21:16.653239
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    with Person('ru').override_locale('en') as p:
        assert p.full_name(gender=Gender.FEMALE) == 'Sarah Smith'
    assert p.full_name(gender=Gender.FEMALE) == 'Анна Иванова'

# Generated at 2022-06-17 22:21:21.482343
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Анна Каренина'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'John Smith'

# Generated at 2022-06-17 22:21:27.852601
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person()
    with person.override_locale('ru') as p:
        assert p.full_name(gender=Gender.MALE) == 'Александр Кузнецов'
        assert p.full_name(gender=Gender.FEMALE) == 'Анна Петрова'
        assert p.full_name(gender=Gender.NOT_APPLICABLE) == 'Анна Петрова'

    with person.override_locale('en') as p:
        assert p.full_name(gender=Gender.MALE)

# Generated at 2022-06-17 22:21:32.948944
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Москва'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:21:40.082828
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import JSON

    person = Person()
    person._pull()
    person.locale = 'en'
    person._pull()
    person.locale = 'ru'
    person._pull()

    assert person.locale == 'ru'

    with person.override_locale('en') as p:
        assert p.locale == 'en'

    assert person.locale == 'ru'

    with person.override_locale('ru') as p:
        assert p.locale == 'ru'

    assert person.locale == 'ru'

    with person.override_locale('en') as p:
        assert p.loc

# Generated at 2022-06-17 22:21:49.423891
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    internet = Internet()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_region() == 'Московская область'

    with internet.override_locale('ru') as i:
        assert i.get_current_locale() == 'ru'
        assert i.get_domain_zone() == 'рф'


# Generated at 2022-06-17 22:21:53.993814
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.get_current_locale() == 'ru'
        assert ru.full_name(gender=Gender.MALE) == 'Александр Кузнецов'

    assert p.get_current_locale() == 'en'
    assert p.full_name(gender=Gender.MALE) == 'Alexander Kuznetsov'

# Generated at 2022-06-17 22:22:05.312001
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.text import Text
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.food import Food
    from mimesis.providers.transport import Transport
    from mimesis.providers.geography import Ge

# Generated at 2022-06-17 22:22:12.826375
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.person import Gender
    from mimesis.providers.person import PersonInfo
    from mimesis.providers.person import PersonMetadata
    from mimesis.providers.person import PersonNames
    from mimesis.providers.person import PersonOccupation
    from mimesis.providers.person import PersonPatronymic
    from mimesis.providers.person import PersonSurname
    from mimesis.providers.person import PersonTitle
    from mimesis.providers.person import PersonUsername
    from mimesis.providers.person import PersonUsername
    from mimesis.providers.person import PersonUsername

# Generated at 2022-06-17 22:22:38.466282
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            """Get data from provider.

            :return: Data from provider.
            """
            return self._data

    provider = TestProvider()

# Generated at 2022-06-17 22:22:45.698700
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Иван Иванов'
        assert person.full_name(gender=Gender.FEMALE) == 'Ирина Иванова'

    assert p.full_name(gender=Gender.MALE) == 'John Doe'
    assert p.full_name(gender=Gender.FEMALE) == 'Jane Doe'

# Generated at 2022-06-17 22:22:53.723690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale(locale=locales.RU):
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-17 22:23:05.292907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:23:14.480419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    provider = TestProvider(locale=locales.EN)
    assert provider.get_current_locale() == locales.EN
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:23:20.338299
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Александр Сергеевич Пушкин'
    assert p.full_name(gender=Gender.MALE) == 'John Smith'

# Generated at 2022-06-17 22:23:29.725024
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as a:
        assert a.get_current_locale() == 'ru'
        assert a.get_city() == 'Санкт-Петербург'

    with person.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:23:37.306684
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.geography import Geography
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.unit import Unit
    from mimesis.providers.person import Person

# Generated at 2022-06-17 22:23:44.288154
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self, key: str) -> Any:
            return self._data[key]

    provider = TestProvider(locale='en')
    assert provider.get_current_locale() == 'en'
    assert provider.get_data('key') == 'value'

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'

# Generated at 2022-06-17 22:23:47.709881
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-17 22:24:40.203801
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as ru:
        assert ru.full_name(gender=Gender.FEMALE) == 'Анна Сергеевна Коробкина'

    assert p.full_name(gender=Gender.FEMALE) == 'Anna Sergeevna Korobkina'

# Generated at 2022-06-17 22:24:48.427690
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person()
    with p.override_locale('ru') as person:
        assert person.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'
    assert p.full_name(gender=Gender.MALE) == 'John Doe'

    with p.override_locale('en') as person:
        assert person.full_name(gender=Gender.MALE) == 'John Doe'
    assert p.full_name(gender=Gender.MALE) == 'Андрей Кузнецов'

# Generated at 2022-06-17 22:24:52.878028
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    p = Person()
    with p.override_locale('ru') as person:
        assert person.get_current_locale() == 'ru'
        assert person.full_name() == 'Анастасия Карасева'
    assert p.get_current_locale() == 'en'
    assert p.full_name() == 'Sophia Miller'

# Generated at 2022-06-17 22:25:04.396074
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, str]:
            return self._data

    test = Test()
    assert test.get_current_locale() == locales.DEFAULT_LOCALE
    assert test.get_data() == {'test': 'test'}

    with test.override_locale(locales.RU):
        assert test.get_current_locale() == locales.RU

# Generated at 2022-06-17 22:25:10.949688
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.geography import Geography
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.food import Food


# Generated at 2022-06-17 22:25:21.392120
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address()
    person = Person()
    text = Text()

    with address.override_locale('ru') as ru_address:
        assert ru_address.get_current_locale() == 'ru'
        assert ru_address.get_city() != address.get_city()

    with person.override_locale('ru') as ru_person:
        assert ru_person.get_current_locale() == 'ru'
        assert ru_person.get_full_name() != person.get_full_name()


# Generated at 2022-06-17 22:25:30.458225
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN
        assert p.get_data() == {'test': 'test'}

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {}

# Generated at 2022-06-17 22:25:39.896782
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.file import File
    from mimesis.providers.geography import Geography
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

# Generated at 2022-06-17 22:25:46.862400
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address(locale='en')
    person = Person(locale='en')

    with address.override_locale('ru') as a:
        assert a.locale == 'ru'
        assert a.get_current_locale() == 'ru'

    with person.override_locale('ru') as p:
        assert p.locale == 'ru'
        assert p.get_current_locale() == 'ru'

    assert address.locale == 'en'
    assert address.get_current_locale() == 'en'

    assert person.locale == 'en'
    assert person.get_current_loc

# Generated at 2022-06-17 22:25:54.942485
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = 'test.json'
            self._pull()

        def get_data(self) -> Dict[str, Any]:
            return self._data

    provider = TestProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_data() == {'test': 'test'}

    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'