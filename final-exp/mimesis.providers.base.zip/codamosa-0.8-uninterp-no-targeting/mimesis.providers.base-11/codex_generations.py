

# Generated at 2022-06-21 15:45:54.105677
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Initialize attributes for data providers.
    dp = BaseDataProvider()
    assert dp.locale == locales.EN
    assert dp.seed == None

    # Initialize attributes for data providers.
    dp1 = BaseDataProvider(locale = 'it')
    assert dp1.locale == 'it'

    # Initialize attributes for data providers.
    dp1 = BaseDataProvider(seed = 'ot')
    assert dp1.seed == 'ot'
    dp1.reseed(seed = 'it')
    assert dp1.seed == 'it'

# Testing function _validate_enum

# Generated at 2022-06-21 15:45:56.258986
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import Gender

    g = Gender()
    assert isinstance(g.get_current_locale(), str)



# Generated at 2022-06-21 15:46:03.021320
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    assert isinstance(BaseProvider, type)
    assert issubclass(BaseProvider, object)
    assert BaseProvider.__name__ == 'BaseProvider'
    assert hasattr(BaseProvider, '__str__')
    assert callable(BaseProvider.__str__)
    bp = BaseProvider()
    assert isinstance(bp.__str__(), str)
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:46:04.683192
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    base = BaseProvider()
    assert str(base) == 'BaseProvider'


# Generated at 2022-06-21 15:46:08.738756
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.numbers import Numbers

    num = Numbers(locale='ru', seed=1)
    with num.override_locale('en') as en:
        assert en.get_current_locale() == 'en'

    assert num.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:46:13.916754
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == 'en'
    assert BaseDataProvider(locale='ru').get_current_locale() == 'ru'
    assert BaseDataProvider(locale='ru-ru').get_current_locale() == 'ru'

# Generated at 2022-06-21 15:46:22.976219
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    seed_1 = '123'
    seed_2 = '456'

    provider_1 = BaseProvider(seed = seed_1)
    random_1 = provider_1.random

    provider_2 = BaseProvider(seed = seed_2)
    random_2 = provider_2.random

    assert random_1 is not random
    assert random_2 is not random

    assert random_1.seed() == seed_1
    assert random_2.seed() == seed_2

    assert random_1 is not random_2

    provider_1.reseed(seed = None)

    random_1 = provider_1.random
    assert random_1 is not random


# Generated at 2022-06-21 15:46:25.645107
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print('====== Unit test for constructor of class BaseDataProvider ======')
    provider = BaseDataProvider(locale='ru')
    assert (provider.locale == 'ru'), 'Test for constructor of class BaseDataProvider Failed'
    print('Test for constructor of class BaseDataProvider passed!')


# Generated at 2022-06-21 15:46:29.514805
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # test for attribute self._data
    a = BaseDataProvider()
    assert isinstance(a._data, dict) == True


# Generated at 2022-06-21 15:46:31.882485
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    provider = TestProvider()
    with provider.override_locale('ru'):
        assert provider.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:46:55.069421
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert repr(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:47:06.245728
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.data import City
    from mimesis.enums import Gender
    from mimesis.providers import Person

    p = Person()
    assert p.get_current_locale() == 'en'
    assert p.gender() == Gender.MALE
    assert p.full_name() == 'Benjamin Porter'
    assert p.get_current_locale() == 'en'

    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'
        assert p.gender() == Gender.MALE
        assert p.full_name() == 'Александр Игоревич'


# Generated at 2022-06-21 15:47:11.517219
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import RussianSpecProvider
    sp = RussianSpecProvider()
    assert sp.get_current_locale() == 'ru'

    with sp.override_locale('uk') as sp_uk:
        assert sp_uk.get_current_locale() == 'uk'
        assert sp.get_current_locale() == 'ru'

    assert sp.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:47:13.736613
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = locals.Geography()
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:47:17.543548
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()  # type: BaseDataProvider
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE
    dp = BaseDataProvider(locale=locales.EN)
    assert dp.get_current_locale() == locales.EN


# Generated at 2022-06-21 15:47:21.932722
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    obj = BaseDataProvider()
    assert obj.random == random
    assert obj._data_dir == '/home/mehdi/Desktop/python/mimesis/mimesis/data'

# Generated at 2022-06-21 15:47:24.563135
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    provider = BaseProvider(seed=10)
    provider.reseed()
    assert provider.random is random


# Generated at 2022-06-21 15:47:29.532074
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    provider = BaseDataProvider(locale = locales.EN)

    # Act
    result = provider.__str__()

    # Assert
    assert result == 'BaseDataProvider <en>', "Error in BaseDataProvider class, __str__ method. Functionality is wrong."

# Generated at 2022-06-21 15:47:37.880505
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider"""
    # default constructor
    provider = BaseProvider()
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)
    assert provider.seed is None
    # seed
    provider = BaseProvider(seed=42)
    assert isinstance(provider.random, Random)
    assert provider.seed == 42
    # reset seed
    provider.reseed(43)
    assert provider.seed == 43
    assert provider.random.seed_value == 43

# Generated at 2022-06-21 15:47:42.077577
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Utility
    from mimesis.providers.person.en import Person as PersonEn
    from mimesis.providers.localization import Localization

    person = Person('fr')
    person.gender.get_value(Gender.MALE)
    person.full_name

    with person.override_locale('en'):
        person.gender.get_value(Gender.MALE)
        person.full_name


# Generated at 2022-06-21 15:48:02.441793
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider is not None

test_BaseDataProvider()


# Generated at 2022-06-21 15:48:08.573795
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, seed: Seed = None):
            super().__init__(locale, seed)

    test(locale = "en-US")
    test(seed = 1)
    test(locale = "en-US", seed = 2)
    test()

# Generated at 2022-06-21 15:48:09.442550
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj=BaseProvider()
    assert obj is not None

# Generated at 2022-06-21 15:48:10.875233
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method BaseDataProvider.get_current_locale.
    """
    base_data_provider = BaseDataProvider()
    current_locale = base_data_provider.get_current_locale()

    assert current_locale == locales.EN

# Generated at 2022-06-21 15:48:13.042354
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed == None
    assert b.random == random
    assert str(b) == 'BaseProvider'


# Generated at 2022-06-21 15:48:15.150849
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    obj=BaseDataProvider()
    assert obj.locale=='en'
    assert (obj._data=={})
    assert (obj._datafile=='')
    assert (obj._data_dir==Path(__file__).parent.parent.joinpath('data'))



# Generated at 2022-06-21 15:48:17.340669
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestedProvider(BaseDataProvider):
        _datafile = 'faker/name/first_name.json'

        def __init__(self):
            super().__init__()

    provider = TestedProvider()
    with provider.override_locale(locale='kk'):
        assert provider.get_current_locale() == 'kk'

# Generated at 2022-06-21 15:48:21.375961
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # pylint: disable=line-too-long
    """Unit test for method override_locale of class BaseDataProvider._"""
    from mimesis.providers import Address

    with Address().override_locale('ru') as provider:
        assert provider.locale == 'ru'



# Generated at 2022-06-21 15:48:25.435929
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'
    assert BaseDataProvider().__class__.__name__ == 'BaseDataProvider'


# Generated at 2022-06-21 15:48:26.109480
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:48:44.616483
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    BaseProvider()


# Generated at 2022-06-21 15:48:47.202776
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    try:
        assert BaseProvider().__str__() != None
    except TypeError:
        print('test_BaseProvider___str__() failed')
        raise


# Generated at 2022-06-21 15:48:59.369104
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test ``BaseDataProvider.override_locale()``."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime

    dt = Datetime()
    with dt.override_locale('ru') as new_dt:
        assert new_dt.month() == 'март'
        assert new_dt.locale == 'ru'

    assert dt.locale == 'en'

    address = Address()
    with address.override_locale('uk') as new_address:
        assert new_address.street() == 'будді'
        assert new_address.locale == 'uk'


# Generated at 2022-06-21 15:49:01.467725
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    b._setup_locale(locales.EN)
    assert str(b) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:49:03.571173
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.base import BaseDataProvider
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:49:09.198749
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test for BaseDataProvider with support of locales
    class TestProvider(BaseDataProvider):
        def test_method(self):
            return self.get_current_locale()

    data = {"l10n": [{"name": "en", "part1": [1, 2, 3]},
                     {"name": "ru", "part1": [4, 5, 6]}]}
    locale_dependent_provider = TestProvider(seed=123)
    locale_dependent_provider.locale = 'en'
    locale_dependent_provider._data = data
    assert locale_dependent_provider.test_method() == "en"
    assert locale_dependent_provider.get_current_locale() == "en"
    locale_dependent_provider.locale = 'ru'
    assert locale_dependent_provider.test

# Generated at 2022-06-21 15:49:14.419840
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # test_BaseDataProvider___str____returns_correct_value()
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


    # test_BaseDataProvider___str____returns_correct_value_for_overridden_locale()
    with BaseDataProvider().override_locale('es-ES'):
        assert str(BaseDataProvider()) == 'BaseDataProvider <es-ES>'



# Generated at 2022-06-21 15:49:16.148937
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider."""
    instance = BaseProvider(seed='test')
    assert instance.seed == 'test'
    assert type(instance.random) == Random



# Generated at 2022-06-21 15:49:19.676932
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Code
    class MyCode(Code):
        def __init__(self, seed=None):
            super().__init__(seed=seed)
    a=MyCode()
    assert a.__str__() == 'MyCode'


# Generated at 2022-06-21 15:49:21.529599
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    dummy = BaseProvider()
    assert dummy.__str__() == "BaseProvider"


# Generated at 2022-06-21 15:49:44.302565
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.providers import BaseProvider
    x = BaseProvider()
    assert type(x) == BaseProvider
    x = BaseProvider('fr')
    assert type(x) == BaseProvider



# Generated at 2022-06-21 15:49:47.987274
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the method override_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    provider._override_locale = lambda locale: locale
    with provider.override_locale() as pr:
        assert pr.locale == ''

# Generated at 2022-06-21 15:49:53.657888
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method ``get_current_locale`` of class ``BaseDataProvider`` in 
    ``mimesis.data`` module."""
    obj = BaseDataProvider()
    assert obj.get_current_locale() == locales.DEFAULT_LOCALE

#  Unit test for method _update_dict of class BaseDataProvider

# Generated at 2022-06-21 15:49:58.711440
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

    provider.locale = 'ru'
    assert provider.get_current_locale() == provider.locale

    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:50:03.599891
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    provider = BaseDataProvider(locale = 'cn', seed = '2221')
    print('provider_locale = ',provider.locale)
    print('provider_seed = ',provider.seed)
    print(provider)

test_BaseDataProvider()


# Generated at 2022-06-21 15:50:09.522627
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider method override_locale."""
    # It can be any provider, which have locale-dependent data
    providers = ['AddressProvider', 'PersonProvider', 'BusinessProvider']
    provider = globals()[providers[0]]
    provider = provider()

    with provider.override_locale(locales.EN):
        assert provider.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:50:13.991249
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale(locale='en') as new_provider:
        assert new_provider.locale == 'en'
    assert provider.locale == 'en'

# Generated at 2022-06-21 15:50:16.656042
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.providers import BaseDataProvider as BDP
    edp=BDP()
    assert edp

# Generated at 2022-06-21 15:50:19.120789
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:50:22.412887
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    '''
    Method __str__ of class BaseProvider
    '''
    _BaseProvider = BaseProvider()
    _BaseProvider.__str__()
    return



# Generated at 2022-06-21 15:51:07.025383
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    dp = BaseProvider()
    assert isinstance(dp, BaseProvider)



# Generated at 2022-06-21 15:51:08.441035
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider_1 = BaseDataProvider(locale='en')
    assert str(provider_1) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:51:10.609488
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:51:13.857252
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    provider.reseed()

# Generated at 2022-06-21 15:51:19.535993
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_base_provider = BaseProvider()
    assert test_base_provider.seed == None
    assert test_base_provider.random == random
    test_base_provider.reseed(1045)
    assert test_base_provider.random.seed(1045)
    test_base_provider.seed = 6
    assert test_base_provider.seed == 6
    assert test_base_provider.__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:51:23.043851
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class MyBaseProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed)

        def __str__(self):
            return super().__str__()

    provider = MyBaseProvider()
    assert str(provider) == "MyBaseProvider"


# Generated at 2022-06-21 15:51:31.082705
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class TestProvider(BaseProvider):
        """Test provider of class BaseDataProvider."""

        def __init__(self):
            self.locale = 'en'

    # test with provider which has locale attribute
    provider = TestProvider()
    with provider.override_locale('ru') as overridden_provider:
        assert overridden_provider.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'

    # test with provider which has not locale attribute
    provider = BaseProvider()
    with pytest.raises(AttributeError) as error:
        with provider.override_locale('ru'):
            pass
    assert 'has not locale dependent' in str(error.value)

# Generated at 2022-06-21 15:51:33.132753
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider(seed=None)
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:51:35.118770
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """BaseProvider: Test method __str__."""
    l = str(BaseProvider())
    assert l == 'BaseProvider'


# Generated at 2022-06-21 15:51:38.250259
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    d = BaseDataProvider()
    assert d.get_current_locale() == locales.DEFAULT_LOCALE
    assert d.get_current_locale() == 'en'

# Generated at 2022-06-21 15:53:17.539023
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale='en').locale == 'en'
    assert BaseDataProvider(locale='en').seed is None
    assert BaseDataProvider(locale='en-GB').locale == 'en-gb'



# Generated at 2022-06-21 15:53:25.661176
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__ of class BaseDataProvider."""
    import pytest
    from mimesis.localization import Localization
    from mimesis.builtins import Person

    person = Person()
    localization = Localization(person)
    localization.set_locale('ru')

    russian_person = Person(locale='ru')

    assert person.__str__() == 'Person <en>'
    assert russian_person.__str__() == 'Person <ru>'

    with pytest.raises(ValueError):
        with person.override_locale('ru'):
            pass

# Generated at 2022-06-21 15:53:28.127245
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method of class BaseDataProvider.
    """
    base = BaseDataProvider()
    with base.override_locale() as provider:
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:53:31.270583
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address
    addr = Address(locale=locales.RU)
    with addr.override_locale(locales.EN):
        assert addr.get_region() == 'Illinois'
    assert addr.get_region() == 'Тюменская область'

# Generated at 2022-06-21 15:53:36.112339
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FakeProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

    provider = FakeProvider()
    locale = 'ru-RU'
    with provider.override_locale(locale) as p:
        assert p.get_current_locale() == locale
    assert not (provider.get_current_locale() == locale)



if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-21 15:53:37.046474
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:53:38.976389
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""

    bp = BaseProvider(seed=None)
    bp.reseed()
    assert bp.seed is None


# Generated at 2022-06-21 15:53:39.840996
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:53:42.401474
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data_provider = BaseProvider(seed=42)
    assert data_provider.seed == 42

    # Unit test for reseed
    data_provider.reseed(seed=12)
    assert data_provider.seed == 12

    # Unit test for __str__
    assert str(data_provider) == 'BaseProvider'



# Generated at 2022-06-21 15:53:46.268967
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    # Test __init__ method
    assert provider.seed is None
    assert provider.random is random
    # Test reseed method
    provider.reseed()
    assert provider.seed is None
    assert provider.random is not random
    assert provider.random._random.seed is None
    assert provider.random is not random
    provider.reseed('test')
    assert provider.seed == 'test'
    assert provider.random._random.seed == 'test'
    assert provider.random is not random
    provider.reseed()
    assert provider.seed is None
    assert provider.random._random.seed is None
    assert provider.random is not random

# Generated at 2022-06-21 15:55:13.776659
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for the method get_current_locale of the class BaseDataProvider."""
    bdp = BaseDataProvider('en')
    bdp.locale = 'en'
    assert bdp.get_current_locale() == 'en'

# Generated at 2022-06-21 15:55:18.987098
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def get_locale(self):
            return self.locale

        def get_master_locale(self):
            return super(TestProvider, self).get_current_locale()

    P = TestProvider()
    with P.override_locale('es') as p:
        assert p.get_locale() == 'es'
        assert p.get_master_locale() == 'en'

# Generated at 2022-06-21 15:55:19.949467
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:55:21.036163
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-21 15:55:26.774481
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    # Unit test for  public class attribue locale
    assert (provider.locale == locales.DEFAULT_LOCALE)
    # Unit test for public class attribue _data
    assert (provider._data == {})
    # Unit test for public class attribue _datafile
    assert (provider._datafile == '')
    # Unit test for public class attribue _data_dir
    assert (provider._data_dir.absolute().as_posix() ==
            "/home/stud/Desktop/mimesis/mimesis/data")

# Generated at 2022-06-21 15:55:28.163717
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert (type(provider) == BaseDataProvider)
    

# Generated at 2022-06-21 15:55:31.385865
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    d = BaseDataProvider()
    assert d.locale == 'en'

    assert str(d) == 'BaseDataProvider <en>'

    assert d._data == {}

    with d.override_locale('fr') as dr:
        assert dr is d
        assert dr.locale == 'fr'

# Generated at 2022-06-21 15:55:34.940788
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test for method get_current_locale of class BaseDataProvider."""
    dp = BaseDataProvider(locale='ru')
    assert dp.get_current_locale() == 'ru'

