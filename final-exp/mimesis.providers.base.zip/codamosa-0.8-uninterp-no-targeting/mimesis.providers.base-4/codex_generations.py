

# Generated at 2022-06-21 15:45:46.449416
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:45:52.024907
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed is None
    assert provider.random == random

    provider = BaseDataProvider(locale="en", seed=123)
    assert provider.locale == "en"
    assert provider.seed == 123
    assert provider.random.seed == 123

# Generated at 2022-06-21 15:45:53.880701
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-21 15:45:56.925463
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test of method reseed."""
    provider = BaseProvider()
    assert provider.random is random
    provider.reseed(100)
    assert isinstance(provider.random, Random)
    assert provider.seed == 100

# Generated at 2022-06-21 15:46:00.391678
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """ Test for method reseed of class BaseProvider.
    """
    seed = "test seed"
    provider = BaseProvider(seed=seed)
    assert (provider.seed == seed)


# Generated at 2022-06-21 15:46:09.250752
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.typing import DictStrAny
    base = BaseProvider()
    assert(base is not None)
    assert(isinstance(base, BaseProvider))
    assert(isinstance(base.random, Random))
    assert(base.seed is None)
    assert(isinstance(base._reseed, (type(None), functools.partial)))
    # seed
    base = BaseProvider(seed=5)
    assert(base.seed == 5)
    assert(isinstance(base.random, Random))
    assert(isinstance(base.random(5,5), int))
    assert(isinstance(base.random(5.0,5.0), float))
    assert(base.random(5,5) > 4)
    assert(base.random(0,1) > 0)

# Generated at 2022-06-21 15:46:21.171084
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.credit_card import CreditCard
    from mimesis.providers.address import Address

    misc = Misc()
    random = misc.random
    random.seed(0)
    lang = misc.random.choice(['en', 'ru', 'uk'])
    person = Person(locale = lang)
    internet = Internet(locale = lang)
    credit_card = CreditCard(locale = lang)
    address = Address(locale = lang)
    print('Person:', person.get_current_locale())
    print('Internet:', internet.get_current_locale())

# Generated at 2022-06-21 15:46:23.432103
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    dp = BaseProvider()
    assert dp.seed is None
    assert dp.random is random
    dp.reseed(123)
    assert dp.seed == 123
    assert dp.random is not random

# Generated at 2022-06-21 15:46:25.618719
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #initialize a object of class BaseDataProvider
    obj = BaseDataProvider()
    print(obj)

# Generated at 2022-06-21 15:46:29.953482
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Initialize BaseDataProvider class."""
    fake = BaseDataProvider()
    assert fake.random is random
    assert not fake._data
    assert not fake.locale


# Generated at 2022-06-21 15:46:43.787813
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    bp.__str__()
    provider_name = 'BaseProvider'
    assert str(bp) == provider_name


# Generated at 2022-06-21 15:46:45.642931
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider('123')
    assert(str(b) == 'BaseProvider')


# Generated at 2022-06-21 15:46:47.220803
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider(seed = 123)
    assert str(b) == "BaseDataProvider <'en'>", "Test: BaseDataProvider"

# Generated at 2022-06-21 15:46:50.518248
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.data import BaseDataProvider
    fake = BaseDataProvider()
    assert fake.get_current_locale() == 'en'


# Generated at 2022-06-21 15:46:55.813631
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider reseed."""
    seed = 136995142000000000
    provider = BaseProvider(seed=seed)
    provider.reseed(seed)

    first = provider.random.seed
    second = provider.seed

    assert first == second


# Generated at 2022-06-21 15:46:58.805024
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:00.212704
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    locale = getattr(provider, 'locale', locales.DEFAULT_LOCALE)
    assert locale == locales.DEFAULT_LOCALE



# Generated at 2022-06-21 15:47:02.732544
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=None)
    assert provider.seed is None
    assert provider.random is random
    provider = BaseProvider(seed=0)
    assert isinstance(provider.random, Random)
    assert provider.seed == 0


# Generated at 2022-06-21 15:47:04.548547
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:47:06.150184
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:31.735352
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Init the class
    p = BaseProvider(seed=123)
    # Calling reseed with random seed
    p.reseed()
    assert seed != p.seed
    # Calling reseed with seed=123
    p.reseed(seed=123)
    assert seed == p.seed



# Generated at 2022-06-21 15:47:34.536748
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == 'en'
    assert BaseDataProvider('en').get_current_locale() == 'en'

# Generated at 2022-06-21 15:47:37.259898
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    subject = BaseProvider(seed=0)
    expected_result = 'BaseProvider'
    assert str(subject) == expected_result


# Generated at 2022-06-21 15:47:39.719613
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseProvider(seed=12345)) == 'BaseProvider'


# Generated at 2022-06-21 15:47:47.045146
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Address
    from mimesis.enums import Locale
    provider1 = Address()
    assert provider1.__str__() == 'Address <en>'
    provider2 = Address(locale=Locale.EN)
    assert provider2.__str__() == 'Address <en>'
    provider3 = Address(locale=Locale.RU)
    assert provider3.__str__() == 'Address <ru>'



# Generated at 2022-06-21 15:47:49.324003
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bla = BaseDataProvider(locale="en", seed=None)
    assert isinstance(bla, BaseDataProvider)


# Generated at 2022-06-21 15:47:55.390077
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    l = BaseDataProvider(locale=locales.DEFAULT_LOCALE,seed=None)
    l_locale = l.get_current_locale()
    l_seed = l.seed
    assert type(l) == BaseDataProvider and type(l_locale) == str and l_locale == locales.DEFAULT_LOCALE, True
    assert type(l_seed) == type(None)



# Generated at 2022-06-21 15:47:56.308048
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() is None


# Generated at 2022-06-21 15:47:58.183753
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    x = BaseProvider()

    assert isinstance(x, BaseProvider)


# Unit test get_random_item()

# Generated at 2022-06-21 15:48:01.085876
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider('ru'))  == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider())  == 'BaseDataProvider <en>'
    assert str(BaseDataProvider('en'))  == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:48:46.058547
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    x = BaseProvider()
    print(x)
    print(x.seed)
    assert(True)
# test_BaseProvider()


# Generated at 2022-06-21 15:48:58.429694
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    p1 = BaseDataProvider()
    value_1 = p1.random.randint(0, 1e6)
    value_2 = p1.random.randint(1e6 + 1, 2e6)

    p2 = BaseDataProvider()
    value_3 = p2.random.randint(0, 1e6)
    value_4 = p2.random.randint(1e6 + 1, 2e6)

    assert value_1 == value_3 
    assert value_2 == value_4

    p2.reseed(2)
    value_5 = p2.random.randint(1e6 + 1, 2e6)
    value_6 = p2.random.randint(1e6 + 1, 2e6)

# Generated at 2022-06-21 15:49:03.774020
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    provider = BaseDataProvider(locale='ru-RU')
    assert str(provider) == 'BaseDataProvider <ru-RU>'
    provider.locale = 'de'
    assert str(provider) == 'BaseDataProvider <de>'
    provider.locale = 'en'
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:49:05.559730
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    actual = BaseProvider()
    expected = 'BaseProvider'
    assert str(actual) == expected

# Generated at 2022-06-21 15:49:07.312571
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test specific method reseed of class BaseProvider."""
    provider = BaseProvider(seed=1)
    provider.reseed(seed=2)
    assert provider.seed == 2


# Generated at 2022-06-21 15:49:14.894909
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Acceptance criteria:
    # - Current locale is en.
    def mock_get_random_item(sequence: Any, *args, **kwargs) -> str:
        return sequence[0]

    base_data_provider = BaseDataProvider(locale="en")
    base_data_provider.random.get_random_item = mock_get_random_item
    base_data_provider.override_locale(locale="ru")
    result = base_data_provider.get_current_locale()
    assert result == 'ru'
    assert base_data_provider.locale == 'ru'


# Generated at 2022-06-21 15:49:15.346900
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    pass

# Generated at 2022-06-21 15:49:24.353613
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis import Person, Generic, __version__

    p = Person('ru')
    assert p.get_current_locale() == 'ru'
    assert p.get_current_locale() != 'en'
    assert p.get_current_locale() != 'hi'
    with p.override_locale('en'):
        assert p.get_current_locale() == 'en'
        assert p.get_current_locale() != 'ru'
        assert p.get_current_locale() != 'hi'
        with p.override_locale('hi'):
            assert p.get_current_locale() == 'hi'
            assert p.get_current_locale() != 'en'
            assert p.get_current_locale() != 'ru'
        assert p.get

# Generated at 2022-06-21 15:49:27.123297
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    assert data_provider.locale == 'en'


# Generated at 2022-06-21 15:49:30.821267
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for BaseDataProvider"""
    locale_1 = "en"
    locale_2 = "ru"
    expected_1 = 'BaseDataProvider <en>'
    expected_2 = 'BaseDataProvider <ru>'
    result_1 = str(BaseDataProvider(locale_1))
    result_2 = str(BaseDataProvider(locale_2))
    assert expected_1 == result_1
    assert expected_2 == result_2


# Generated at 2022-06-21 15:50:18.553772
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    
    bdp = BaseDataProvider(locale = 'ja')
    
    assert str(bdp) == 'BaseDataProvider <ja>'

# Generated at 2022-06-21 15:50:21.979726
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    tp = BaseProvider()
    assert tp is not None
    assert tp.__class__.__name__  == "BaseProvider"

    tp = BaseProvider(seed = None)
    assert tp.__class__.__name__ == "BaseProvider"
    assert tp is not None



# Generated at 2022-06-21 15:50:27.013914
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class NewProvider(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed=seed)

    seed = 12345
    provider = NewProvider(seed)
    assert provider.__str__() == 'NewProvider'


# Generated at 2022-06-21 15:50:31.876075
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    # test for UnsupportedLocale exception
    try:
        BaseDataProvider(locale='no')
    except UnsupportedLocale:
        return True



# Generated at 2022-06-21 15:50:36.812920
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reset of class BaseProvider."""
    # Init BaseProvider
    p = BaseProvider(seed=2)
    assert p.seed == 2
    # Setup parameter seed
    p.seed = 1
    assert p.seed == 1
    p.reseed(3)
    assert p.seed == 3

# Generated at 2022-06-21 15:50:38.333694
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    tmp = BaseDataProvider()
    print(tmp)
    return

# Generated at 2022-06-21 15:50:39.879487
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    some_provider = BaseProvider()
    assert str(some_provider) == 'BaseProvider'

# Generated at 2022-06-21 15:50:42.282874
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    str_provider = provider.__str__()
    assert (str_provider == 'BaseProvider')


# Generated at 2022-06-21 15:50:44.337700
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:50:52.074208
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers import (Address, Business, Code, Datetime,
                                   Financial, Generic, Internet, Person)

    # Unit test for method get_current_locale of class Address
    assert Address().get_current_locale() == 'en'
    with Address().override_locale('de'):
        assert Address().get_current_locale() == 'de'
    assert Address().get_current_locale() == 'en'

    # Unit test for method get_current_locale of class Business
    assert Business().get_current_locale() == 'en'
    with Business().override_locale('de'):
        assert Business().get_current_locale() == 'de'
    assert Business().get_current_locale() == 'en'

    # Unit test for method get_current_locale

# Generated at 2022-06-21 15:52:47.802961
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random

    provider = BaseProvider(seed = 123)
    assert provider.seed == 123
    assert provider.random is not None
    assert provider.random != random

    provider.reseed(seed = None)
    assert provider.seed == None

    provider.reseed(seed = 123)
    assert provider.seed == 123


# Generated at 2022-06-21 15:52:55.875052
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method of class BaseDataProvider.

    When there is not attribute locale in the provider, raise ValueError exception.
    """
    class TestBaseDataProvider(BaseDataProvider):
        """Test class BaseDataProvider."""

        def __init__(self):
            """Initialize TestBaseDataProvider."""
            pass

    test_data_provider = TestBaseDataProvider()
    if test_data_provider.locale:
        raise AssertionError('Locale of TestBaseDataProvider must be None.')

    with test_data_provider.override_locale('en'):
        assert test_data_provider.locale == 'en'

    with test_data_provider.override_locale('ru'):
        assert test_data_provider.locale == 'ru'


# Generated at 2022-06-21 15:53:01.597160
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for BaseDataProvider class."""

    print(BaseDataProvider())
    print(BaseDataProvider(locale='ru'))
    print(BaseDataProvider(seed=11))
    print(BaseDataProvider(locale='zh', seed=-4))
    print(BaseDataProvider(locale='en', seed=None))


if __name__ == '__main__':
    # Test BaseDataProvider class
    test_BaseDataProvider()

# Generated at 2022-06-21 15:53:10.085671
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import mimesis.builtins
    from mimesis.enums import Gender
    datetime_patterns = ['DD.MM.YYYY', 'YYYY/DD/MM', 'DD/MM/YYYY']

    class TestProvider(BaseDataProvider):
        """Test provider."""

        class Meta(object):
            """Class for metadata."""

            name = 'test'
            locales = ('en', 'ru')

    provider = TestProvider(locale='en')

    with provider.override_locale('ru'):
        assert provider.GENDERS == mimesis.builtins.GENDERS
        assert provider.get_current_locale() == 'ru'

    with provider.override_locale('en'):
        assert provider.GENDERS == mimesis.builtins.GENDERS
        assert provider

# Generated at 2022-06-21 15:53:13.225051
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider('123')
    bp.reseed()
    assert bp.seed is not 123

    bp.reseed(123)
    assert bp.seed is 123

# Generated at 2022-06-21 15:53:23.382260
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science

    class TestClass(BaseDataProvider):
        """Test class for BaseDataProvider"""

    assert isinstance(TestClass().__str__(), str)
    assert TestClass().__str__() == 'TestClass <en>'

    assert isinstance(Address().__str__(), str)
    assert Address().__str__() == 'Address <en>'

    assert isinstance(Code().__str__(), str)
    assert Code().__str__() == 'Code <en>'

    assert isinstance(Numbers().__str__(), str)
    assert Numbers().__str__() == 'Numbers <en>'


# Generated at 2022-06-21 15:53:26.959075
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    print(b.random.generator.get_state()[1][0])

    b.reseed(1234)
    print(b.random.generator.get_state()[1][0])

# Test function set up locale

# Generated at 2022-06-21 15:53:32.709344
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the method ``override_locale`` of class ``BaseDataProvider``."""
    class TestDataProvider(BaseDataProvider):
        def __str__(self):
            return "TestDataProvider <{}>".format(
                self.get_current_locale())

    tdp = TestDataProvider()
    assert str(tdp) == "TestDataProvider <en>"

    with tdp.override_locale(locales.RU):
        assert str(tdp) == "TestDataProvider <ru>"
        with tdp.override_locale(locales.EN):
            assert str(tdp) == "TestDataProvider <en>"

    assert str(tdp) == "TestDataProvider <ru>"



# Generated at 2022-06-21 15:53:39.201254
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Test obj when locale is gb
    p1 = BaseDataProvider(locale='gb')
    p1.name = 'Some name'
    with p1.override_locale('ru') as p2:
        assert p2 is p1
        assert p2.get_current_locale() == 'ru'
    assert p1.get_current_locale() == 'gb'
    # Test obj when locale is en
    p1 = BaseDataProvider(locale='en')
    p1.name = 'Some name'
    with p1.override_locale('ru') as p2:
        assert p2 is p1
        assert p2.get_current_locale() == 'ru'
    assert p1.get_current_locale() == 'en'
    # Test obj without locale
    p1

# Generated at 2022-06-21 15:53:42.403631
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check ``override_locale`` of class ``BaseDataProvider``."""
    bdp = BaseDataProvider()
    with bdp.override_locale('ru') as provider:
        assert provider.locale == 'ru'
    assert bdp.locale == locales.DEFAULT_LOCALE

