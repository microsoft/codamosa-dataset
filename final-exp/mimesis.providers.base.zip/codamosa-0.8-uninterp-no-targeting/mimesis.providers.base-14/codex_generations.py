

# Generated at 2022-06-21 15:45:54.630964
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # Create instance of class BaseDataProvider
    provider = BaseDataProvider(seed=123)
    # Check that locale is None
    assert provider.locale is None

    # Context manager which allows overriding current locale
    with provider.override_locale(locales.RU):
        # Check that locale is ru
        assert provider.locale == locales.RU
    # Check that locale is None
    assert provider.locale is None

    try:
        # Context manager which allows overriding current locale
        with provider.override_locale(locales.RU):
            # Check that locale is ru
            assert provider.locale == locales.RU
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-21 15:45:56.301186
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    assert BaseDataProvider().override_locale()

# Generated at 2022-06-21 15:46:00.521367
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class SimpleProvider(BaseDataProvider):
        a = 1

    provider = SimpleProvider()

    with provider.override_locale('ru'):
        assert provider.a == 1

    with provider.override_locale():
        assert provider.a == 1



# Generated at 2022-06-21 15:46:03.654198
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider."""
    assert (BaseProvider().__str__() == 'BaseProvider')
    assert (BaseProvider(seed = 50).__str__() == 'BaseProvider')
    return


# Generated at 2022-06-21 15:46:05.565973
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=None)
    p.reseed(seed=None)


# Generated at 2022-06-21 15:46:09.526424
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider1 = BaseProvider()
    print(provider1)
    print(provider1.seed)
    assert provider1.seed is None
    print(provider1.random)
    assert provider1.random is random

    provider2 = BaseProvider(seed=13)
    print(provider2)
    print(provider2.seed)
    assert provider2.seed == 13


# Generated at 2022-06-21 15:46:12.598927
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider()
    assert dp.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:46:19.287316
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class testing(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
        seed: Seed = None) -> None:
            super().__init__(locale, seed)

    test = testing()
    assert test.seed is None
    assert test.random == random
    assert test._data == {}
    assert test.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:46:21.093008
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == "BaseProvider"
    assert BaseProvider(42).__str__() == "BaseProvider"


# Generated at 2022-06-21 15:46:22.766335
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(0)
    assert bp.seed is not None



# Generated at 2022-06-21 15:46:42.771503
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with contextlib.suppress(AttributeError):
        p1 = BaseDataProvider()
        assert isinstance(p1, BaseDataProvider)
        assert p1.locale == 'en'
        assert p1.seed is None
        assert not p1._data
        assert p1._datafile == ''

        p2 = BaseDataProvider(locale='ru', seed=0)
        assert isinstance(p2, BaseDataProvider)
        assert p2.locale == 'ru'
        assert p2.seed == 0
        assert not p2._data
        assert p2._datafile == ''

        p1._pull()
        assert p1._data
        p2._pull()
        assert p2._data

        assert p1.get_current_locale() == 'en'
        assert p2.get_current_locale

# Generated at 2022-06-21 15:46:45.545900
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.EN
    provider = BaseDataProvider(locale=locale)
    data = provider.get_current_locale()
    assert data == locale


# Generated at 2022-06-21 15:46:48.767974
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    provider = BaseDataProvider(locale='pl')
    assert provider.get_current_locale() == 'pl'

# Generated at 2022-06-21 15:46:52.403419
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    base_data_provider = BaseDataProvider()
    assert base_data_provider.__str__() == "BaseDataProvider <en>"
    base_data_provider.__init__("ar")
    assert base_data_provider.__str__() == "BaseDataProvider <ar>"


# Generated at 2022-06-21 15:46:55.216235
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    locale = 'en'
    a = bdp.get_current_locale()
    assert type(a) == str
    assert a == 'en'
    b = bdp._override_locale(locale)
    assert b == None
    a = bdp.get_current_locale()
    assert type(a) == str
    assert a == 'en'
    del bdp


# Generated at 2022-06-21 15:47:06.409115
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    nations = {
        'en': 'British',
        'de': 'Deutsch',
        'ru': 'Российский',
    }
    class TestProvider(BaseDataProvider):
        def nation(self) -> str:
            return nations[self.locale]
    provider = TestProvider(seed=1)
    assert provider.nation() == 'British'
    with provider.override_locale('ru'):
        assert provider.nation() == 'Российский'
    assert provider.nation() == 'British'
    with provider.override_locale():
        assert provider.nation() == 'Deutsch'

# Generated at 2022-06-21 15:47:09.038013
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider()
    assert BaseProvider(seed = 1234)


# Unit test, check how to override locale from context manager

# Generated at 2022-06-21 15:47:16.252854
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.builtins import Earth

    class Person(BaseProvider):

        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)
            self.earth = Earth(seed=seed)

        def test(self, seed):
            return self.random.seed

        def test_earth(self):
            return self.earth.seed

    person = Person(seed=123)
    assert person.seed == 123
    assert person.random.seed() == 123
    assert person.test(123) == 123
    assert person.test_earth() == 123

    person.reseed(321)
    assert person.seed == 321
    assert person.random.seed() == 321
    assert person.test(321) == 321
    assert person.test_earth() == 123


# Generated at 2022-06-21 15:47:18.210731
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed of class BaseProvider."""
    provider = BaseProvider(seed = 'abc')
    assert provider.seed == 'abc'

    provider.reseed(seed = 'def')
    assert provider.seed == 'def'

    provider.reseed()
    assert provider.seed is None


# Generated at 2022-06-21 15:47:21.684576
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    test_result = str(provider)
    expected_result = 'BaseProvider'
    assert test_result == expected_result

# Generated at 2022-06-21 15:47:43.424239
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():

    a = BaseProvider()
    assert a.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:45.889302
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider.locale == 'en'

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:47:47.979044
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:47:49.930714
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

   from mimesis.providers.numbers import Numbers
   provider = Numbers()
   assert hasattr(provider, '_pull')



# Generated at 2022-06-21 15:47:53.950751
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.food import Food
    germanFood = Food('de')
    with germanFood.override_locale('ja'):
        assert germanFood._data['bread']['loaf_of_bread'] == 'パン'



# Generated at 2022-06-21 15:47:56.761100
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider('ru')) == 'BaseDataProvider <ru>'


# Generated at 2022-06-21 15:47:59.244688
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert 'en' == ('BDP'+'('+')').get_current_locale()
    assert 'es' == ('BDP'+'('+'locale="es"'+')').get_current_locale()

# Generated at 2022-06-21 15:48:01.825060
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider._override_locale('ru')
    assert str(provider) == 'BaseDataProvider <ru>'



# Generated at 2022-06-21 15:48:05.152853
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed()
    assert bp.random.randint(0, 10) == 5

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-21 15:48:07.997267
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test(BaseProvider):
        pass
    pt = Test()
    assert str(pt) == 'Test'


# Generated at 2022-06-21 15:48:28.547830
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    # tests if default value returned is anything other than None
    assert provider.locale != None


# Generated at 2022-06-21 15:48:36.010951
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Overrider(BaseDataProvider):
        def __init__(self, seed=None):
            self.data = []
            self.locale = locales.DEFAULT_LOCALE
            super().__init__(seed=seed)
        def generate_data(self, test_value):
            self.data.append(test_value)
    overrider = Overrider()
    with overrider.override_locale(locales.RU):
        overrider.generate_data(test_value='ru')
    with overrider.override_locale(locales.EN):
        overrider.generate_data(test_value='en')
    assert overrider.data == ['ru', 'en']

# Generated at 2022-06-21 15:48:39.107031
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=42)
    assert provider.seed == 42
    assert provider.random.seed == 42


# Generated at 2022-06-21 15:48:42.377194
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:48:50.703328
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for method __str__ of class BaseProvider."""
    from .builtins import DateTime
    from .generic import Code
    from .science import Chemistry
    from .vehicles import Automotive
    from . import locales
    datetime = DateTime(locale='en')
    code = Code(locale='ru')
    chemistry = Chemistry(locale='it')
    automotive = Automotive()

    try:
        datetime.__str__()
        code.__str__()
        chemistry.__str__()
        automotive.__str__()
    except AttributeError:
        assert False

    try:
        Automotive(locale=locales.RU).__str__()
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 15:48:55.505396
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('\nConstruct a BaseProvider:')
    prv = BaseProvider(seed=None)
    print(prv)
    print('Type of prv: {}'.format(type(prv)))
    print(prv.seed)


# Generated at 2022-06-21 15:48:56.741866
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp
    assert bdp.locale == locales.EN


# Generated at 2022-06-21 15:48:59.153277
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
	test_seed = 1234
	test_provider = BaseProvider(test_seed)
	assert test_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:49:01.595194
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    r = BaseDataProvider()
    with r.override_locale('ru') as r:
        assert r.locale == 'ru'


# Generated at 2022-06-21 15:49:08.122624
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for reseed method."""
    provider = BaseProvider()
    seeds = [provider.seed for _ in range(3)]
    # try:
    #     assert all(seed is None for seed in seeds)
    # except AssertionError:
    #     print("AssertionError:",seeds)
    assert all(seed is None for seed in seeds)
    provider.reseed(1)
    assert isinstance(provider.seed, int)
    assert provider.seed == 1
    # print("OK:",provider.seed)
    assert isinstance(provider.random, Random)
    seeds = [provider.random.seed for _ in range(3)]
    # try:
    #     assert all(seed == 1 for seed in seeds)
    # except AssertionError:
    #     print("

# Generated at 2022-06-21 15:49:52.700715
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    new_seed = 42
    assert provider.random is random
    provider.reseed(seed=new_seed)
    assert provider.random is not random
    assert provider.seed == new_seed

# Generated at 2022-06-21 15:49:54.041380
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp

# Generated at 2022-06-21 15:49:56.582347
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider"""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:49:58.490987
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis import Address

    address = Address(locale=locales.EN)
    assert address.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:50:00.172628
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:50:10.156438
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    bdp = BaseDataProvider()

    # Default locale.
    assert bdp.get_current_locale() == locales.EN

    # Use locale parameter.
    bdp = BaseDataProvider(locale='ru')
    assert bdp.get_current_locale() == locales.RU

    # Use overriden locale.
    bdp = BaseDataProvider()
    with bdp.override_locale('ru'):
        assert bdp.get_current_locale() == locales.RU
    # After the context manager is finished.
    assert bdp.get_current_locale() == locales.EN


# Generated at 2022-06-21 15:50:20.472505
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ExampleProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN) -> None:
            super().__init__(locale)

        def get_current_locale(self) -> str:
            return self.locale

    provider = ExampleProvider()
    expected_locale = locales.EN
    dumped_provider = str(provider)
    actual_locale = provider.get_current_locale()
    with provider.override_locale(locale=locales.RU) as ru:
        ru_expected_locale = locales.RU
        ru_actual_locale = ru.get_current_locale()
        ru_dumped_provider = str(ru)

    assert expected_locale == actual_locale
    assert ru_expected_locale

# Generated at 2022-06-21 15:50:26.680221
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider._setup_locale('ru')
    assert str(provider) == 'BaseDataProvider <ru>'

    provider.locale = 'en'
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:50:32.232733
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    r = BaseProvider()
    assert isinstance(r.seed, type(None))
    assert isinstance(r.random, Random)
    assert isinstance(r.random.seed, type(None))
    r_ = BaseProvider('seed')
    assert isinstance(r_.seed, str)
    assert isinstance(r_.random, Random)
    assert isinstance(r_.random.seed, str)


# Generated at 2022-06-21 15:50:36.857616
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # BaseDataProvider with locale
    bp = BaseDataProvider(locale='kk')
    assert str(bp) == 'BaseDataProvider <kk>'

    # BaseDataProvider without locale
    bp = BaseDataProvider()
    assert str(bp) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:52:17.760946
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:52:26.121848
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    result = BaseProvider(seed=1000)
    assert [result.random.random() for _ in range(10)] == [
        0.3753975729942322, 0.914142215128525, 0.6700098759825265,
        0.7712705105820111, 0.2555826481907958, 0.7356336688932831,
        0.37525355974439284, 0.2778363215960262, 0.30063890908660734,
        0.24608325825189873]
    assert result.seed == 1000



# Generated at 2022-06-21 15:52:31.502086
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    my_provider = BaseDataProvider()
    assert my_provider is not None
    assert my_provider.seed is None
    assert my_provider._data == {}
    assert my_provider._datafile == ''
    assert my_provider._setup_locale() is None
    assert my_provider._data_dir is not None
    assert my_provider.locale == locales.DEFAULT_LOCALE
test_BaseDataProvider()

# Generated at 2022-06-21 15:52:33.483285
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert p.seed is None
    assert p.random is not None


# Generated at 2022-06-21 15:52:36.187721
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for initialize attributes for data providers."""
    from mimesis.providers.numbers import Numbers

    numbers = Numbers()
    assert numbers.locale == 'en'
    assert numbers.seed is None


# Generated at 2022-06-21 15:52:47.153437
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.system import System
    from mimesis.providers.filesystem import FileSystem
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person

    print('Test method __str__ of class BaseDataProvider')
    provider = BaseDataProvider()
    lorem = Lorem()
    internet = Internet()
    numbers = Numbers()
    system = System()
    filesystem = FileSystem()
    datetime = Datetime()
    generic = Generic()
    person = Person()
    print('provider = BaseDataProvider()')


# Generated at 2022-06-21 15:52:51.688698
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Test(BaseDataProvider):
        pass

    obj = Test()
    get_current_locale = obj.get_current_locale
    assert get_current_locale() == 'en', 'BaseDataProvider.get_current_locale works incorrectly'


# Generated at 2022-06-21 15:52:56.635488
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Create object and check that attributes is correct."""
    from providers import Person

    provider = Person(seed=42)
    assert provider.__str__() == "Person <en>"

    provider = Person(locale="ru")
    assert provider.__str__() == "Person <ru>"

    provider = Person(locale="de-AT", seed=57)
    assert provider.__str__() == "Person <de-AT>"

    provider = Person(locale="sk")
    assert provider.__str__() == "Person <sk>"

    provider = Person(locale="sk", seed=42)
    assert provider.__str__() == "Person <sk>"

# Generated at 2022-06-21 15:53:01.124642
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider: BaseDataProvider = BaseDataProvider()
    provider.locale = "en_US"
    assert provider.get_current_locale() == "en_US"

    provider2: BaseDataProvider = BaseDataProvider(locale="en_US")
    assert provider2.get_current_locale() == "en_US"


# Generated at 2022-06-21 15:53:09.884094
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person as p
    p1 = p(seed=1)
    p2 = p(seed=2)

    assert p1.get_full_name() == 'Roy Harvey'
    assert p1.get_full_name(gender='female') == 'Naomi Mcdonald'

    with p1.override_locale('ru') as p:
        assert p.get_full_name() == 'Сергей Александров'
        assert p.get_full_name(gender='female') == 'Жаклин Мельникова'
    assert p1.get_full_name() == 'Roy Harvey'

# Generated at 2022-06-21 15:54:34.938023
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider(seed=1)
    p.reseed(seed=1)
    assert p.random.randint(0, 10) == 6
    p.reseed(seed=2)
    assert p.random.randint(0, 10) == 1


# Generated at 2022-06-21 15:54:40.223465
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class FakeProvider(BaseProvider):
        def test_method(self):
            return self.random.seed()

    fp = FakeProvider(seed='123465789')
    assert fp.seed == fp.random.seed()
    assert fp.seed != random.seed()



# Generated at 2022-06-21 15:54:44.314116
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'en'
    seed = 42
    bdp = BaseDataProvider(locale=locale, seed=seed)
    assert bdp.__str__() == 'BaseDataProvider <{}>'.format(locale)
    assert bdp.random.seed == seed


# Generated at 2022-06-21 15:54:45.917102
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    ru = BaseDataProvider('ru')
    assert ru.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:54:47.484542
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    locale = BaseProvider.init(locale="en")
    assert locale.locale == "en"


# Generated at 2022-06-21 15:54:52.309643
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider(seed=2345).reseed(seed=2345).seed == 2345
    assert BaseProvider(seed=2345).reseed(seed=1234).seed == 1234
    assert BaseProvider(seed=2345).reseed(seed=2345).random is not random
    BaseProvider(seed=2345).reseed(seed=2345).random = random

# Generated at 2022-06-21 15:54:53.272973
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert (provider.seed == None)


# Generated at 2022-06-21 15:54:54.427601
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pass
test_BaseProvider()

# unit test for constructor of class BaseDataProvider

# Generated at 2022-06-21 15:54:56.303735
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

# Generated at 2022-06-21 15:55:00.175921
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from io import StringIO
    from contextlib import redirect_stdout
    from mimesis.providers import Vehicle
    from mimesis.typing import Locale

    vehicle = Vehicle(locale=Locale('en'))
    stream = StringIO()
    with redirect_stdout(stream):
        print(vehicle)
    assert stream.getvalue().rstrip() == 'Vehicle <en>'


