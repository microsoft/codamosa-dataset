

# Generated at 2022-06-21 15:45:45.777207
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()
    assert provider.random() == 0.8840049337984607


# Generated at 2022-06-21 15:45:47.514752
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    help(BaseProvider.reseed)
    return None

# Generated at 2022-06-21 15:45:57.050965
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():


    new_data = BaseDataProvider()
    assert new_data._datafile == "global.json"
    assert new_data.seed is None
    assert new_data.locale == "en"
    assert "data" in new_data._data_dir
    assert new_data.random.seed == None
    assert new_data.random.__class__ == Random
    assert new_data.random.random().__class__ == float

    new_data = BaseDataProvider(locale="ja")
    assert new_data.locale == "ja"
    assert new_data.random.seed == None
    assert new_data.random.__class__ == Random
    assert new_data.random.random().__class__ == float

    new_data = BaseDataProvider(seed=123)
    assert new_data.seed == 123


# Generated at 2022-06-21 15:45:59.397971
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    result = provider.__str__()
    assert result == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:46:04.573900
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dataprovider = BaseDataProvider('en')
    assert dataprovider.locale == 'en'
    assert dataprovider.seed == None
    assert dataprovider.random == random
    assert dataprovider._data == {}
    assert dataprovider._datafile == ''
    assert dataprovider._data_dir == Path('data')



# Generated at 2022-06-21 15:46:09.415756
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Check BaseDataProvider constructor."""

    class A(BaseDataProvider):
        pass

    a1 = A()
    a2 = A(locale='ru')

    assert a1.locale != a2.locale
    assert isinstance(a1.locale, str)
    assert isinstance(a2.locale, str)


# Generated at 2022-06-21 15:46:12.532035
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    dp = BaseProvider()
    dp.reseed(seed=1)
    assert dp.seed == 1

# Generated at 2022-06-21 15:46:16.580057
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider.

    :param Any type of DataProvider which inherits BaseProvider.
    :return: Checked __str__ method.
    """
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-21 15:46:23.538166
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random_ = Random()

    random_.seed(123)
    provider = BaseProvider()
    provider.reseed(123)
    assert random_.randint(0, 100) == provider.random.randint(0, 100) == 49  # 49 is random number

    random_.seed(123)
    provider = BaseProvider(123)
    assert random_.randint(0, 100) == provider.random.randint(0, 100) == 49  # 49 is random number

    random_.seed(456)
    provider = BaseProvider()
    assert random_.randint(0, 100) != provider.random.randint(0, 100)


# Generated at 2022-06-21 15:46:25.946713
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    new_seed = 'b'*16
    base_provider = BaseProvider(seed=new_seed)
    assert base_provider.seed == new_seed
    base_provider.seed = None
    assert base_provider.seed is None


# Generated at 2022-06-21 15:46:36.028262
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale='en',seed=4)

# Generated at 2022-06-21 15:46:38.257926
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    instance = BaseDataProvider('en')
    assert instance.get_current_locale() == 'en'
    print(instance)

# Generated at 2022-06-21 15:46:41.756647
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider()
    assert(base_provider is not None)
    assert(base_provider.random is random)


# Generated at 2022-06-21 15:46:44.530562
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random_number = BaseProvider()._random

    BaseProvider(seed=1).reseed()

    assert random_number.randint(0, 100000) == 50757

# Generated at 2022-06-21 15:46:52.981384
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider."""
    class Provider(BaseDataProvider):
        """Test class for test_BaseDataProvider_override_locale."""

        def __init__(self, *, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Test method for test_BaseDataProvider_override_locale."""
            super().__init__(locale=locale, seed=seed)

        def get_current_locale(self) -> str:
            """Override method for test_BaseDataProvider_override_locale."""
            return self.locale

    # Create a provider
    provider = Provider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:46:54.547554
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    from mimesis.providers.base.base import BaseDataProvider

    data = BaseDataProvider()
    assert type(data) == BaseDataProvider
    assert data.locale == 'en'


# Generated at 2022-06-21 15:47:00.746304
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    def get_current_locale(self):
        return self.locale

    provider = BaseDataProvider(locale='en_US', seed=1)
    provider.__class__.get_current_locale = get_current_locale

    assert provider.get_current_locale() == 'en_US'


# Generated at 2022-06-21 15:47:06.059240
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TempProvider(BaseDataProvider):

        @property
        def data(self) -> Dict:
            return self._data

    provider = TempProvider()
    result = provider.__str__()
    expected = '<class \'__main__.TestBaseDataProvider.test_BaseDataProvider___str__.<locals>.TempProvider\'> <en>'
    assert result == expected, 'Got: {0}, expected: {1}'.format(result, expected)

# Generated at 2022-06-21 15:47:07.872459
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test __str__ method of class BaseDataProvider.

    :return: Nothing.
    """
    BaseDataProvider()

# Generated at 2022-06-21 15:47:08.444862
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider()

# Generated at 2022-06-21 15:47:21.850054
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    b.reseed(123)
    b.get_random_int(0, 1)
    # unit test for method __str__ of class BaseProvider


# Generated at 2022-06-21 15:47:24.804497
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit Test for method __str__ of class BaseProvider."""
    test_BaseProvider_instance = BaseProvider()

    result = test_BaseProvider_instance.__str__()
    assert result == 'BaseProvider'

# Generated at 2022-06-21 15:47:27.241153
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider('ru')
    assert str(bdp) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:47:29.942283
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    base = BaseDataProvider(locale="en")
    expected = "en"
    assert base.get_current_locale() == expected


# Generated at 2022-06-21 15:47:33.234430
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Base data provider."""
    test_object = BaseProvider()
    test_object.seed = "1234"
    test_object.reseed('1234')

# Generated at 2022-06-21 15:47:35.871230
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    blu = BaseProvider('23')
    bluu = BaseProvider('22')
    assert blu.random is not bluu.random


# Generated at 2022-06-21 15:47:39.607454
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider.override_locale()
    This method should return provider with overridden locale."""
    from mimesis.providers import lorem
    en_provider = lorem.Lorem(locale='en')
    ru_provider = lorem.Lorem(locale='ru')

    en_provider_en = en_provider.get_current_locale()
    ru_provider_en = ru_provider.get_current_locale()
    assert en_provider_en == 'en'
    assert ru_provider_en == 'ru'


# Generated at 2022-06-21 15:47:41.577685
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()

    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:47:44.149733
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert p.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:51.907805
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test data provider which has only method to test."""

        def method(self) -> str:
            """Data.

            :return: Data.
            """
            return self.get_current_locale()

    provider = TestDataProvider()
    locale = provider.get_current_locale()
    assert provider.method() == locale
    with provider.override_locale(locales.CS) as provider:
        assert provider.method() == locales.CS
    assert provider.method() == locale


# Generated at 2022-06-21 15:48:09.964119
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pass


# Generated at 2022-06-21 15:48:17.631231
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Person as PersonEn

    assert PersonEn('en').get_current_locale() == 'en' == \
        Person('en').get_current_locale()
    assert Person('ru').get_current_locale() == 'ru' == \
        Person('ru').get_current_locale()
    assert Address('ru').get_current_locale() == 'ru'
    with Person('ru').override_locale('en'):
        assert Person('ru').get_current_locale() == 'en'
        with Person('ru').override_locale('ru'):
            assert Person('ru').get_current

# Generated at 2022-06-21 15:48:19.471837
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:48:22.860087
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test __str__ method from BaseProvider class."""
    from mimesis.providers.person import Person

    assert str(Person()) == 'Person'


# Generated at 2022-06-21 15:48:30.956694
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = None
    class TestClass(BaseProvider):
        def __init__(self, seed = None):
            super().__init__(seed = seed)
        def to_reseed(self, seed = None):
            self.reseed(seed)
        def get_random(self):
            return self.random
    test_object = TestClass()
    assert test_object.get_random() is random
    test_object.to_reseed(seed)
    assert test_object.get_random() is not random


# Generated at 2022-06-21 15:48:32.164705
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert 'BaseProvider' == p.__str__()

# Generated at 2022-06-21 15:48:35.034396
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Test(BaseProvider):
        def __init__(self, seed: Seed = None) -> None:
            super().__init__(seed)
    
    test = Test()
    assert test.__str__() == "Test"
    
    

# Generated at 2022-06-21 15:48:42.891132
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('en')
    assert str(p) == 'Person <en>'
    assert str(Person()) == 'Person <en>'
    p.__class__.__name__ = Gender.MALE.value
    assert str(p) == 'MALE <en>'
    assert str(Person()) == 'Person <en>'

# Generated at 2022-06-21 15:48:51.088339
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('\n' + '-'*40 + '\n' + 'Unit test for constructor of class BaseProvider')
    print('Test 1:')
    provider = BaseProvider()
    print('provider = BaseProvider()')
    print('provider.seed:', provider.seed)
    print('provider.random:', provider.random)

    provider = BaseProvider(seed=42)
    print('\n' + '-'*40 + '\n' + 'Test 2:')
    print('provider = BaseProvider(seed=42)')
    print('provider.seed:', provider.seed)
    print('provider.random:', provider.random)

    print('\n' + '-'*40 + '\n' + 'Test 3:')
    provider.reseed(seed=42)

# Generated at 2022-06-21 15:48:52.719726
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
	provider = BaseProvider()
	assert provider is not None


# Generated at 2022-06-21 15:49:11.405003
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    BaseProvider().reseed(None)



# Generated at 2022-06-21 15:49:13.501020
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test."""
    quote = BaseProvider()
    print(quote)
if __name__ == '__main__':
    test_BaseProvider()

# Generated at 2022-06-21 15:49:15.053463
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider(seed=1)
    assert str(b) == 'BaseProvider'


# Generated at 2022-06-21 15:49:16.799816
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().seed == None
    assert BaseProvider(seed = '123456789').seed == '123456789'


# Generated at 2022-06-21 15:49:23.489204
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    test_seed = 42
    b_provider = BaseProvider(seed=test_seed)
    assert b_provider
    assert b_provider.seed == test_seed
    assert b_provider.random
    assert isinstance(b_provider.random, Random)
    assert b_provider.random.random() == 0.6394267984578837
    assert b_provider.reseed(test_seed) is None
    assert b_provider.random.random() == 0.6394267984578837
    assert b_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:49:25.673149
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    test = BaseDataProvider(locale='en')
    assert test.get_current_locale() == 'en'

# Generated at 2022-06-21 15:49:27.418308
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    b.reseed(None)


# Generated at 2022-06-21 15:49:31.096300
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    '''
    Unit test for constructor.
    '''
    
    provider = BaseProvider(seed=None)
    assert provider.seed is None, "Error: seed is not None!"

    provider = BaseProvider(seed=345)
    assert provider.seed is 345, "Error: seed is not 345!"
    

# Generated at 2022-06-21 15:49:37.194429
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class __Test(BaseDataProvider):
        pass
    assert __Test().__str__() == '__Test <en>'
    assert __Test(locale='en').__str__() == '__Test <en>'
    assert __Test(locale='ru').__str__() == '__Test <ru>'

# Generated at 2022-06-21 15:49:43.245383
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    from mimesis.enums import Gender
    from mimesis.random import Random

    bp = BaseProvider()
    bp.random = Random()

    g1 = bp.random.choice(list(Gender))
    bp.reseed(10)
    bp.random = Random()
    g2 = bp.random.choice(list(Gender))

    assert g1 != g2



# Generated at 2022-06-21 15:50:22.889887
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    t = BaseProvider().__str__()
    assert t == "BaseProvider"


# Generated at 2022-06-21 15:50:29.046718
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert (provider.locale == "en" and provider._data == {}
            and provider._datafile == ""
            and provider.seed == None and provider.random == random)
    assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    

# Generated at 2022-06-21 15:50:39.183789
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ProviderA(BaseDataProvider):
        _datafile = 'test_data.json'

    class ProviderB(BaseDataProvider):
        pass

    a = ProviderA()
    b = ProviderB()
    test_value = 'test'
    with a.override_locale('en'):
        assert a.locale == 'en'
        with a.override_locale('ru'):
            assert a.locale == 'ru'
        assert a.locale == 'en'

    with a.override_locale('en'):
        assert a.locale == 'en'

        with a.override_locale('ru'):
            assert a.locale == 'ru'
            with a.override_locale('uk'):
                assert a.locale == 'uk'

# Generated at 2022-06-21 15:50:41.445257
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method ``__str__`` of class BaseProvider."""
    provider_instance = BaseProvider()
    assert str(provider_instance) == "BaseProvider"

# Generated at 2022-06-21 15:50:46.064687
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    r = BaseProvider(seed=5)
    assert r.random.randint(0, 10) == 3
    r.reseed(seed=6)
    assert r.random.randint(0, 10) == 5


# Generated at 2022-06-21 15:50:49.479099
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    import pytest
    with pytest.raises(AttributeError):
        BaseDataProvider('zh-zh')
    with pytest.raises(UnsupportedLocale):
        BaseDataProvider('zh-cn', 'zh-cn')

# Generated at 2022-06-21 15:50:50.847417
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider()
    assert base_data_provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:50:56.672447
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    dp = BaseDataProvider()
    assert dp.locale == 'en'
    assert not dp._data
    assert dp._datafile == ''
    assert dp._pull.cache_info().hits == 0
    return dp


# Generated at 2022-06-21 15:50:58.838104
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    rnd = random.Random()
    provider = BaseDataProvider()
    # BaseDataProvider <en>
    assert str(provider)=='BaseDataProvider <en>'
    # BaseProvider <None>
    assert str(BaseProvider())=='BaseProvider <None>'


# Generated at 2022-06-21 15:51:01.208999
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    provider1 = BaseProvider(seed=5)
    assert provider.seed is None
    assert provider1.seed == 5


# Generated at 2022-06-21 15:52:38.812191
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    p1 = BaseDataProvider()
    p2 = BaseDataProvider('en')
    p3 = BaseDataProvider('ru')
    return (
        (p1, 'BaseDataProvider <en>'),
        (p2, 'BaseDataProvider <en>'),
        (p3, 'BaseDataProvider <ru>'),
    )


# Generated at 2022-06-21 15:52:40.972664
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed=0)
    assert str(bp) == "BaseProvider"



# Generated at 2022-06-21 15:52:51.809434
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    provider.reseed()
    provider.random.seed(1)
    assert provider.seed == 1
    assert provider.random.seed(provider.seed)
    assert provider.random.random() == 0.13436424411240122
    result = provider.random.random()
    assert result == 0.13436424411240122
    def validate_enum(item: Any, enum: Any) -> Any:
        if item is None:
            result = get_random_item(enum, provider.random)
        elif item and isinstance(item, enum):
            result = item
        else:
            raise NonEnumerableError(enum)
        return result.value
    assert provider.random.getstate() == provider.random.getstate()

# Generated at 2022-06-21 15:52:52.998049
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider('en')
    assert p.locale == 'en'

# Generated at 2022-06-21 15:52:54.045613
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert isinstance(BaseProvider(), BaseProvider)



# Generated at 2022-06-21 15:53:03.445499
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.geography import Geography

    obj = Geography(locale='ru')
    obj.random.seed(5)
    with obj.override_locale('en') as geog:
        assert geog.random.get_state() == obj.random.get_state()
        print(geog.region())
        print(geog.province())
        print(geog.city())
        print(geog.address())
        print(geog.latitude())
        print(geog.longitude())
        assert geog.random.get_state() == obj.random.get_state()

        assert obj.locale == 'ru'
        assert geog.locale == 'en'


# Generated at 2022-06-21 15:53:05.502099
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed = 10)
    provider.reseed(15)
    assert provider.seed is not None
    assert provider.seed == 15


# Generated at 2022-06-21 15:53:07.981133
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider != BaseProvider
    assert BaseDataProvider().locale != BaseDataProvider("en").locale


# Generated at 2022-06-21 15:53:10.301611
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('BaseProvider:')
    provider = BaseProvider(seed=1)
    print(provider.reseed())

# Generated at 2022-06-21 15:53:13.449779
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('BaseProvider')
    provider = BaseProvider()
    print(provider)
    provider = BaseProvider(seed=123)
    print(provider)
