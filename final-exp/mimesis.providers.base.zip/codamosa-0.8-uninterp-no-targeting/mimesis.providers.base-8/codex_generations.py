

# Generated at 2022-06-21 15:45:46.398361
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = "en"
    provider = BaseDataProvider(locale, seed=666)

    assert str(provider) == "BaseDataProvider <{}>".format(locale)

# Generated at 2022-06-21 15:45:53.687479
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Case: default locale
    default_locale = BaseDataProvider()
    assert default_locale.get_current_locale() == 'en'

    # Case: custom locale
    custom_locale = BaseDataProvider('uk')
    assert custom_locale.get_current_locale() == 'uk'

    with custom_locale.override_locale('en_US'):
        assert custom_locale.get_current_locale() == 'en_US'

# Generated at 2022-06-21 15:45:55.814342
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    print(b.random.seed(1))


# Generated at 2022-06-21 15:46:00.762993
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert isinstance(BaseDataProvider(), BaseDataProvider)
    assert isinstance(BaseDataProvider(locale='es'), BaseDataProvider)
    assert isinstance(BaseDataProvider(locale='en', seed=1234), BaseDataProvider)
    assert isinstance(BaseDataProvider(locale='en', seed=None), BaseDataProvider)


# Generated at 2022-06-21 15:46:07.980948
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """ """
    from mimesis.builtins import (
        Address,
        Code,
        DateTime,
        FileSystem,
        Hardware,
        Internet,
        Person,
        Science,
        Text,
    )
    providers = (
        Address(),
        Code(),
        DateTime(),
        FileSystem(),
        Hardware(),
        Internet(),
        Person(),
        Science(),
        Text(),
    )

    expected = 'en'
    for provider in providers:
        result = provider.get_current_locale()
        assert result == expected



# Generated at 2022-06-21 15:46:13.222286
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__."""
    b = BaseDataProvider()
    assert str(b) == 'BaseDataProvider <en>'
    with b.override_locale('ru'):
        assert str(b) == 'BaseDataProvider <ru>'


# Generated at 2022-06-21 15:46:19.782102
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():

    # Подготовка объекта класса BaseDataProvider
    provider = BaseDataProvider()

    # Проверка возвращаемого результата
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:46:26.554783
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print("\n\nUnit test for constructor of class BaseDataProvider")
    def_dataprov = BaseDataProvider()
    print("Default dataprovider (en): \n\t{}".format(def_dataprov))
    assert(def_dataprov.get_current_locale() == 'en')
    ru_dataprov = BaseDataProvider('ru')
    print("dataprovider with locale ru: \n\t{}".format(ru_dataprov))
    assert(ru_dataprov.get_current_locale() == 'ru')
    with ru_dataprov.override_locale('en') as ru_en_dataprov:
        print("dataprovider with overridden locale en: \n\t{}".format(ru_en_dataprov))

# Generated at 2022-06-21 15:46:29.774938
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    b = BaseDataProvider(locale="en")
    assert b.get_current_locale() == "en"


# Generated at 2022-06-21 15:46:33.044440
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bd = BaseDataProvider()
    assert bd.get_current_locale() == 'en'
    assert bd.__locale is None


# Generated at 2022-06-21 15:46:47.220356
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.generic import Generic
    provider = Generic()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    with provider.override_locale(locale='en-AU') as new_provider:
        assert new_provider is provider
        assert provider.get_current_locale() == 'en-AU'
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:46:50.214029
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    b = BaseDataProvider()
    assert isinstance(b, BaseProvider)

# Generated at 2022-06-21 15:46:52.103175
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp=BaseDataProvider()
    assert isinstance(bdp,BaseDataProvider)


# Generated at 2022-06-21 15:46:55.276124
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):

        @classmethod
        def test(cls, locale=locales.EN):
            with cls.override_locale(locale) as provider:
                return provider.get_current_locale()

    provider = TestProvider(locales.ES_ES)
    assert provider.test() == locales.ES_ES
    assert provider.test(locales.RU) == locales.RU
    assert provider.test() == locales.ES_ES

# Generated at 2022-06-21 15:47:00.596426
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """
    This is unit test for method __init__ of class BaseDataProvider.
    """
    provider = BaseDataProvider(locale='en')
    result = provider.get_current_locale()
    expected = 'en'
    assert result == expected


# Generated at 2022-06-21 15:47:06.681053
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(seed=42)
    assert provider.__str__() == 'BaseDataProvider <en>'
    provider_strict_locale = BaseDataProvider(seed=42, locale='ru')
    assert provider_strict_locale.__str__() == 'BaseDataProvider <ru>'
    provider_strict_locale.override_locale('ru-RU')
    assert provider_strict_locale.__str__() == 'BaseDataProvider <ru-RU>'

# Generated at 2022-06-21 15:47:10.591636
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method BaseProvider.reseed."""
    r = Random()
    r.seed(1)
    x = [r.random() for _ in range(10)]
    r.seed(1)
    y = [r.random() for _ in range(10)]

    assert x == y



# Generated at 2022-06-21 15:47:12.709060
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider constructor"""
    bdp = BaseDataProvider(seed=555)
    assert bdp

# Generated at 2022-06-21 15:47:14.417110
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with BaseDataProvider() as provider:
        assert provider.locale != ""

# Generated at 2022-06-21 15:47:17.532299
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method BaseProvider.__str__(self)."""
    base = BaseProvider(seed=12345)
    assert str(base) == 'BaseProvider'

# Unit tests for methods _setup_locale and _validate_enum

# Generated at 2022-06-21 15:47:39.176441
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Dictionary(BaseDataProvider):
        data_file = 'dictionary.json'

        def get_word(self, item: str = None) -> str:
            data = self._data['words']
            return self.random.choice(data[item]) if item else self.random.choice(data)

    item = 'first_name'
    dictionary = Dictionary(locale='cs')
    dictionary._pull(datafile='dictionary.json')

    with dictionary.override_locale(locale='es'):
        assert getattr(dictionary, 'locale', 'en') == 'es'
        assert hasattr(dictionary, 'data')
        assert isinstance(dictionary.data, dict)
        assert dictionary.get_word() in dictionary.data['words']
        assert dictionary.get_word(item) in dictionary.data

# Generated at 2022-06-21 15:47:44.772398
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """"Test for method __str__ of class BaseDataProvider."""
    locale_ = "ru"
    bdp = BaseDataProvider(locale=locale_)
    assert isinstance(bdp, BaseDataProvider)
    assert isinstance(bdp, BaseProvider)
    assert str(bdp) == "BaseDataProvider <ru>"

# Generated at 2022-06-21 15:47:46.292460
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # TODO: add unit tests for method __str__ of class BaseDataProvider
    pass

# Generated at 2022-06-21 15:47:48.299417
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert type(provider) == BaseDataProvider


# Generated at 2022-06-21 15:47:49.894338
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:52.222379
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    x = BaseDataProvider("de")
    assert x.__str__() == "BaseDataProvider <de>"

# Generated at 2022-06-21 15:47:54.478788
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider."""
    provider = BaseProvider('Seed')
    assert provider.seed == 'Seed'
    assert provider.random is not random



# Generated at 2022-06-21 15:47:57.241149
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'
    provider = BaseDataProvider('ru')
    assert str(provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:47:59.126845
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        pass
    with Test().override_locale('uk') as t:
        assert t.locale == 'uk'

# Generated at 2022-06-21 15:48:00.469825
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed == None
    assert provider.random == random

# Generated at 2022-06-21 15:48:31.733861
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.schema import Field, Schema
    from mimesis.data import (
        HASHES,
        LANGUAGES,
    )

    hashes_en = Field('hashes')
    hashes_ru = Field('hashes', locale='ru')
    assert hashes_en.create() in HASHES.ALL
    assert hashes_ru.create() in HASHES.ALL
    assert 'майкл' in hashes_ru.create()

    schema_en = Schema(locale='en')
    schema_ru = Schema(locale='ru')
    assert schema_en.create(LANGUAGES.EN)['name'] in LANGUAGES.EN
    assert schema_ru.create(LANGUAGES.RU)['name'] in LANGUAGES.RU

# Generated at 2022-06-21 15:48:34.175695
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # arrange
    class _Provider(BaseProvider):
        pass

    provider = _Provider(locale='en')

    # act
    actual = str(provider)

    # assert
    assert actual == '_Provider'

# Generated at 2022-06-21 15:48:36.541029
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider('seed')
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:48:40.258075
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    baseProv = BaseProvider(seed=12345)
    assert baseProv.seed == 12345
    assert baseProv.random.seed_instance == 12345


# Generated at 2022-06-21 15:48:42.616460
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-21 15:48:44.949720
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()


if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generated at 2022-06-21 15:48:49.220544
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider('en-US')) == 'BaseDataProvider <en-us>'
    assert str(BaseDataProvider('uk')) == 'BaseDataProvider <uk>'
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider('ru')) == 'BaseDataProvider <ru>'


# Generated at 2022-06-21 15:48:57.898735
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    # 1. class BaseDataProvider(object):
    # 1.1. def __init__(self, locale: str = locales.DEFAULT_LOCALE,
    #                   seed: Seed = None) -> None:
    # 1.1.1. self._data: JSON = {}
    instance = BaseDataProvider()
    # print(instance)
    # _datafile_
    # data_dir_
    # locale_
    # seed_
    # random_

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:48:59.520276
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import doctest
    doctest.testmod(raise_on_error=True, verbose=False)

# Generated at 2022-06-21 15:49:02.572930
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    person = Person(seed=None)
    person.__str__()
    person.__str__()
    person.__repr__()
    person.__repr__()


# Generated at 2022-06-21 15:49:44.818015
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=42)

    assert str(provider) == "BaseProvider"
    assert provider.seed == 42


# Generated at 2022-06-21 15:49:49.048254
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    try:
        b = BaseDataProvider()
        print ('test_BaseDataProvider: create instance of BaseDataProvider')
    except:
        print ('test_BaseDataProvider: cannot create instance of BaseDataProvider')

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:49:59.814628
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('en')
    assert p.gender() != p.gender()
    with p.override_locale('ru') as ru:
        assert ru.gender() != ru.gender()
        assert ru.gender() == ru.gender()
    assert p.gender() != p.gender()
    with p.override_locale('ru') as ru:
        assert ru.gender() != ru.gender()
        assert ru.gender() != ru.gender()
        assert ru.gender() == ru.gender()
    with p.override_locale('ru') as ru:
        assert ru.gender() != ru.gender()
        assert ru.gender() == ru

# Generated at 2022-06-21 15:50:04.547315
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # BaseProvider.reseed with default parameter
    default_item = BaseProvider()
    default_item.reseed()
    # BaseProvider.reseed with parameter
    seed = 'seed'
    item = BaseProvider(seed)
    item.reseed(seed)


# Generated at 2022-06-21 15:50:07.406577
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    base = BaseDataProvider(locale=locale)
    assert base.get_current_locale() == locale



# Generated at 2022-06-21 15:50:09.810140
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider."""
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'



# Generated at 2022-06-21 15:50:11.569563
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    test_instance = BaseProvider()
    assert str(test_instance) == 'BaseProvider'


# Generated at 2022-06-21 15:50:13.991270
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import datetime
    assert datetime().get_current_locale() == 'en'


# Generated at 2022-06-21 15:50:21.502298
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en')
    assert provider.locale == locales.DEFAULT_LOCALE
    assert getattr(provider,'_data',None) is None
    assert provider._datafile == ''

    provider = BaseDataProvider(locale='en',seed=1234)
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed == 1234

    file = 'address.json'

    provider.locale = 'de'
    provider._datafile = file
    provider._pull()

    assert isinstance(provider._data,dict)


# Generated at 2022-06-21 15:50:23.341905
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider(locale = 'uk')
    assert base.locale == 'uk'

# Generated at 2022-06-21 15:51:58.058767
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.builtins import Person
    person = Person('zh')
    person2 = Person('zh')
    assert type(person) == type(person2)


# Generated at 2022-06-21 15:52:11.027304
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    test_provider = TestProvider(locale='en')
    assert test_provider.get_current_locale() == 'en'

    with test_provider.override_locale(locale='ru'):
        assert test_provider.get_current_locale() == 'ru'
        with test_provider.override_locale(locale='de'):
            assert test_provider.get_current_locale() == 'de'
        assert test_provider.get_current_locale() == 'ru'

    assert test_provider.get_current_

# Generated at 2022-06-21 15:52:12.530186
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider(locale='en')
    current_locale = data_provider.get_current_locale()
    assert current_locale == 'en'


# Generated at 2022-06-21 15:52:13.994058
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == provider.__class__.__name__


# Generated at 2022-06-21 15:52:15.689897
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
        # check initialisation of BaseProvider
        assert isinstance(BaseProvider(seed=1234), BaseProvider) == True


# Generated at 2022-06-21 15:52:21.555289
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test if locale is changed inside the context manager."""
    class FakeProvider(BaseDataProvider):
        pass

    p = FakeProvider()
    with p.override_locale(locales.RU):
        assert p.get_current_locale() == locales.RU
    assert p.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:52:27.061547
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.providers.baseprovider import BaseProvider
    from mimesis.enums import Seed
    base_provider = BaseProvider(seed=Seed.CUSTOM)
    assert isinstance(base_provider,BaseProvider)
    assert isinstance(base_provider.random, Random)
    assert base_provider is not None
    assert base_provider.seed == base_provider.random.__seed


# Generated at 2022-06-21 15:52:28.713314
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print("test_BaseProvider()")
    provider = BaseProvider()
    assert provider


# Generated at 2022-06-21 15:52:31.358769
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Data
    d = Data('en')
    assert BaseProvider('en').__str__() == 'BaseProvider'
    assert d.__str__() == 'Data <en>'

# Generated at 2022-06-21 15:52:34.056347
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1337)
    provider.reseed(seed=1337)
    provider.reseed(seed=None)
    provider = BaseProvider(seed=1337)
    provider.reseed(seed=None)
