

# Generated at 2022-06-21 15:45:49.699826
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """ BaseProvider.__str__ - string representation of locale."""
    locale = 'en'
    baseProvider = BaseProvider(locale)
    classname = baseProvider.__class__.__name__
    result = baseProvider.__str__()
    expected = classname
    assert result == expected

# Generated at 2022-06-21 15:45:52.820615
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import PolandSpecProvider
    with PolandSpecProvider().override_locale(locales.EN) as a:
        print(a.locale)

# Generated at 2022-06-21 15:45:53.786137
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-21 15:46:01.703145
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.providers.address import Address
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    a1 = Address()
    logger.debug("a1: {}".format(a1))
    a1.reseed(3)
    logger.debug("a1: {}".format(a1))
    a2 = Address()
    logger.debug("a2: {}".format(a2))
    logger.debug("a1 and a2 are not equal")
    print()


# Generated at 2022-06-21 15:46:07.323823
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Unit test for method reseed of class BaseProvider
    test_data = [
        (123, ),
        ('abc', ),
        (None, ),
    ]
    for data in test_data:
        b = BaseProvider(data)
        assert b.random.seed(data) is b.random
        b.reseed(data)
        assert b.random.seed(data) is b.random

# Generated at 2022-06-21 15:46:11.420451
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider."""
    b = BaseDataProvider()
    b._setup_locale(locales.EN)
    s = str(b)
    assert s == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:46:14.409430
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    # TODO: use assert_warns
    provider.reseed('foo')



# Generated at 2022-06-21 15:46:16.825709
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    str(BaseProvider()) == "BaseProvider"
    assert str(BaseProvider()) == "BaseProvider"

# Generated at 2022-06-21 15:46:18.035797
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-21 15:46:24.005615
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None
    assert bp.random is random
    assert bp.random.seed not in [0, None]
    assert bp.random.seed_instance is None
    assert bp.random.get_randbits(64) >= 0
    assert bp.random.get_randbits(64) < 2 ** 64
    assert bp.random.getrandbits(64) >= 0
    assert bp.random.getrandbits(64) < 2 ** 64
    assert str(bp) == "BaseProvider"


# Generated at 2022-06-21 15:46:51.940953
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unittest for BaseProvider.reseed() method."""
    # Check that random number was generated
    from random import randint
    bp = BaseProvider()
    bp_rs_value = bp.random.randint(0, 10000)
    bp.reseed(1)
    bp_rs_value_after_seed = bp.random.randint(0, 10000)
    assert bp_rs_value_after_seed == bp_rs_value
    # Check that reseed without seed argument
    # works after first reseed with seed argument
    bp_rs_value_after_res = bp.random.randint(0, 10000)
    bp.reseed()
    bp_rs_value_after_res2 = bp.random.randint(0, 10000)
    assert b

# Generated at 2022-06-21 15:47:02.679693
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DataProvider(BaseDataProvider):

        def get_current_locale(self) -> str:
            """Get current locale.

            If locale is not defined then this method will always return ``en``,
            because ``en`` is default locale for all providers, excluding builtins.

            :return: Current locale.
            """
            return self.locale

    data_provider = DataProvider()

    with data_provider.override_locale(locales.EN):
        assert data_provider.locale == locales.EN
    assert data_provider.locale == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:47:08.950679
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p1 = BaseDataProvider(locale='zh')
    print(p1.get_current_locale())  # zh
    p1._pull()
    p1.reseed(None)
    p2 = BaseDataProvider(locale='fr')
    print(p2.get_current_locale())  # fr
    p2._pull()
    p3 = BaseDataProvider()
    print(p3.get_current_locale())  # en
    p3._pull()


# Generated at 2022-06-21 15:47:12.124410
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider.
    """
    try:
        def foo(provider):
            provider.override_locale()

        foo(BaseDataProvider())
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 15:47:16.160563
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'ru'
    provider = BaseDataProvider(locale=locale)
    assert 'BaseDataProvider <ru>' == provider.__str__()
    provider = BaseDataProvider(locale=locale)
    assert 'BaseDataProvider <ru>' == str(provider)

# Generated at 2022-06-21 15:47:18.978965
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    print(a)
    a._setup_locale('zh')
    a._override_locale('zh')
    
if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-21 15:47:24.520778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale)
        def get_current_locale(self):
            return self.locale
    # with self.assertRaises(ValueError):
        # with Test().override_locale(locale='ru'):
            pass
    with Test().override_locale(locale='ru') as instance:
        assert instance.locale=='ru'
    assert Test().get_current_locale()=='en'

# Generated at 2022-06-21 15:47:26.560429
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    _ = BaseDataProvider()
    assert str(_) == 'BaseDataProvider <en>'
    _.locale = 'ru'
    assert str(_) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:47:33.282773
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """The unit test for constructor of class BaseProvider."""
    class Test(BaseProvider):
        """Testing BaseProvider constructor."""

        def __init__(self, seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param seed: Seed to all the random functions.
            """
            super().__init__(seed=seed)

    return Test(seed=None)


# Generated at 2022-06-21 15:47:33.977247
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider


# Generated at 2022-06-21 15:48:19.852755
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = '123'
    base = BaseProvider(seed)
    assert base.random.seed == seed


# Generated at 2022-06-21 15:48:23.909559
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    seed = "123"
    bp.reseed(seed=seed)
    assert bp.seed == seed
    assert bp.random.seed == seed


# Generated at 2022-06-21 15:48:27.959787
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider(locale=locales.EN, seed=12)
    assert bdp._datafile == ''
    assert bdp.locale == 'en'
if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-21 15:48:31.128283
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    _instance = BaseDataProvider()
    _result = _instance.get_current_locale()
    _expected = locales.DEFAULT_LOCALE
    assert _result == _expected


# Generated at 2022-06-21 15:48:32.772516
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider is not None and provider.__class__ == BaseProvider


# Generated at 2022-06-21 15:48:36.425362
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider('zh')
    assert isinstance(data_provider, BaseDataProvider)
    assert data_provider.locale == 'zh'
    assert data_provider._datafile == ''
    assert data_provider._data_dir == Path('C:/Users/Mr.python/PycharmProjects/Mimesis/mimesis/data')


# Generated at 2022-06-21 15:48:40.138324
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import Text
    result = Text(seed=123).get_current_locale()
    assert result == locales.DEFAULT_LOCALE



# Generated at 2022-06-21 15:48:49.661872
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale='en'):
            super().__init__(locale=locale)

        def pull(self):
            return self._pull(datafile=self._datafile)

        def get_data(self):
            return self._data

    provider = TestProvider()
    provider.pull()
    assert provider.get_data() == {}

    provider = TestProvider(locale='ru')
    provider.pull()
    assert provider.get_data() == {'Locale': 'ru'}

    with provider.override_locale('de') as p:
        assert p.get_data() == {'Locale': 'de'}

    assert provider.get_data() == {'Locale': 'ru'}

# Generated at 2022-06-21 15:48:55.698175
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass
    provider = TestProvider(locale='en')
    provider.__test = "test"
    with provider.override_locale('ru'):
        assert provider.__test == "test"
        assert provider.locale == "ru"
    assert provider.locale == "en"

# Generated at 2022-06-21 15:48:57.571763
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    def get_current_locale():
        return 'en'
    assert BaseDataProvider.get_current_locale == get_current_locale

test_BaseDataProvider_get_current_locale()


# Generated at 2022-06-21 15:49:48.178193
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider)=='BaseDataProvider <en>'
    provider.locale = 'en'
    assert str(provider)=='BaseDataProvider <en>'

# Generated at 2022-06-21 15:49:54.552240
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    base = BaseDataProvider()
    with base.override_locale(locale=locales.RU) as provider:
        assert provider.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:49:55.741068
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert (provider.seed == None)
    assert (provider.random == random)
    assert (str(provider) == 'BaseProvider')


# Generated at 2022-06-21 15:49:57.351124
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.address import Address

    object_ = Address()
    str(object_)

# Generated at 2022-06-21 15:49:58.858091
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    prv = BaseProvider()
    assert str(prv) == 'BaseProvider'

# Generated at 2022-06-21 15:50:00.800033
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # Arrange
    bdp = BaseDataProvider()

    # Assert
    assert str(bdp) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:50:10.651813
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    obj = TestProvider()
    obj._data = {
        'en': {'name': 'Max'},
        'ru': {'name': 'Максим'},
    }

    with obj.override_locale(locales.RU) as obj:
        assert obj.get_current_locale() == locales.RU
        assert obj.get_data('name') == 'Максим'

    assert obj.get_current_locale() == locales.EN
    assert obj.get_data('name') == 'Max'

# Generated at 2022-06-21 15:50:14.059553
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider = BaseDataProvider(locale='ru')
    assert str(provider) == 'BaseDataProvider <ru>'


# Generated at 2022-06-21 15:50:15.134810
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider('en')
    assert provider.locale == 'en'
    assert provider.data_dir == '../mimesis/data'

# Generated at 2022-06-21 15:50:16.512988
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj
test_BaseProvider()


# Generated at 2022-06-21 15:52:16.671585
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """
    Testing for __str__ method of class BaseDataProvider.
    """
    result = str(BaseDataProvider())
    assert result == 'BaseDataProvider <en>'
    result = str(BaseDataProvider('ru'))
    assert result == 'BaseDataProvider <ru>'
    result = str(BaseDataProvider(locale='ru'))
    assert result == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:52:18.558949
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:52:28.606926
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    '''
    Test for `BaseDataProvider().get_current_locale()`.
    '''
    print('Case 1')
    # Case 1
    _locale = locales.DEFAULT_LOCALE
    _seed = 1
    provider = BaseDataProvider(_locale, _seed)
    print(provider.get_current_locale())
    # expect {'en'}

    print('Case 2')
    # Case 2
    _locale = locales.DEFAULT_LOCALE
    _seed = 1
    provider = BaseDataProvider(_locale, _seed)
    # print(provider.get_current_locale())
    # expect {'en'}

    print('Case 3')
    # Case 3
    _locale = locales.RU
    _seed = 1
    provider = BaseDataProvider

# Generated at 2022-06-21 15:52:30.205476
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:52:32.099321
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    expected = 'BaseProvider'
    actual = str(bp)
    assert expected == actual


# Generated at 2022-06-21 15:52:35.199264
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    s = BaseProvider()
    assert s.seed == s.random.seed_value
    assert s.random != Random()
    s.reseed(47)
    assert s.seed == s.random.seed_value
    assert s.random != Random()


# Generated at 2022-06-21 15:52:36.502675
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=None)
    assert provider.seed is None


# Generated at 2022-06-21 15:52:38.665121
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # test init
    base_provider = BaseProvider()
    base_provider_seed = BaseProvider(seed=123)
    # test seed
    assert base_provider.seed is None
    assert base_provider_seed.seed == 123



# Generated at 2022-06-21 15:52:40.453671
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='mn')


# Generated at 2022-06-21 15:52:42.723504
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp=BaseProvider()
    bp.reseed(seed='some seed')
    assert bp.seed == 'some seed'
    assert bp.random != random
