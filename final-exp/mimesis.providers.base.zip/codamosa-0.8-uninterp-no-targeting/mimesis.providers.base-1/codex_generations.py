

# Generated at 2022-06-21 15:45:43.062176
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()


# Generated at 2022-06-21 15:45:46.897103
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    assert b.locale == locales.DEFAULT_LOCALE
    assert b._datafile == ''
    assert b.random == random
    assert b._data == {}

# Generated at 2022-06-21 15:45:48.877687
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    pass

# Generated at 2022-06-21 15:45:49.496838
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()

# Generated at 2022-06-21 15:45:55.867304
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestClass(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes for data providers.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)

    assert not TestClass(locale=locales.DEFAULT_LOCALE).override_locale.__wrapped__

# Generated at 2022-06-21 15:46:02.299275
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class A(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE):
            self._data = {'a': 123}
            self._datafile = 'a.json'
            super().__init__(locale=locale)

        def __str__(self):
            return self._data['a']

    with A().override_locale('ru') as a:
        assert isinstance(a, A)

# Generated at 2022-06-21 15:46:05.324463
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    d1 = BaseDataProvider(locale="RU", seed=2)
    print(d1)
    d2 = BaseDataProvider(locale="EN", seed=4)
    print(d2)

# Generated at 2022-06-21 15:46:07.902221
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider"""
    baseDataProvider = BaseDataProvider()
    assert type(baseDataProvider) == BaseDataProvider


# Generated at 2022-06-21 15:46:13.122045
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Business

    b = Business()
    print(b)
    """
    Business <en>
    """
    with b.override_locale("de"):
        print(b)
        """
        Business <de>
        """

# Generated at 2022-06-21 15:46:19.369165
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='fr').get_current_locale() == 'fr'
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'
    assert BaseDataProvider(locale='de').get_current_locale() == 'de'
    assert BaseDataProvider(locale='ru').get_current_locale() == 'ru'


# Generated at 2022-06-21 15:46:40.969292
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == "BaseProvider"
    

# Generated at 2022-06-21 15:46:50.707154
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # We need to create a dummy class which inherits from BaseDataProvider
    class DummyDataProvider(BaseDataProvider):
        _data_file = 'addresses.json'
        # We need to create a method to check if locale changed in the context manager
        def get_current_locale(self):
            return self.locale
    # We need to create a instance
    provider = DummyDataProvider()
    # We need to get current locale of provider
    origin_locale = provider.get_current_locale()
    # We need to check if origin locale is equal to default locale
    assert origin_locale == 'en'
    with provider.override_locale('ru'):
        # We need to check if locale changed
        assert provider.get_current_locale() == 'ru'
    # We need to check if locale changed

# Generated at 2022-06-21 15:46:54.756759
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    base_data_provider = BaseDataProvider(locale)

    assert base_data_provider.get_current_locale() is locale


# Generated at 2022-06-21 15:46:56.936830
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed = '-seed')

    assert bp.seed == '-seed'


# Generated at 2022-06-21 15:47:02.823219
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person

    provider = Person()
    with provider.override_locale(locales.RU) as pr:
        assert pr.get_current_locale() == locales.RU
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:47:05.603453
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider()
    assert BaseDataProvider(locale=locales.RU)
    assert BaseDataProvider(seed=10)
    assert BaseDataProvider(locale=locales.RU, seed=10)


# Generated at 2022-06-21 15:47:08.486173
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed()
    assert bp.random is not random
    assert bp.seed is not None

# Generated at 2022-06-21 15:47:10.466734
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test method __str__ of class BaseProvider."""
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:47:16.274511
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.builtins import Builtins
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.locales import English
    assert str(Address()) == 'Address <en>'
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(Builtins()) == 'Builtins'
    assert str(Generic()) == 'Generic'
    assert str(Internet()) == 'Internet'
    assert str(English()) == 'English'

# Generated at 2022-06-21 15:47:17.069519
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:47:48.851814
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale=locales.RU)) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider(locale=locales.EN)) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale=locales.DEFAULT_LOCALE)) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='')) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='en-GB')) == 'BaseDataProvider <en-gb>'

# Generated at 2022-06-21 15:47:55.064157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class FancyProvider(BaseDataProvider):
        def __init__(self, locale, value):
            super().__init__(locale, seed=None)
            self._value = value

        def get_value(self):
            return self._value

    provider = FancyProvider('en', 'value')
    assert provider.get_value() == 'value'
    with provider.override_locale('ru') as provider:
        assert provider.get_value() == 'value_ru'
        with provider.override_locale('en'):
            assert provider.get_value() == 'value'
    assert provider.get_value() == 'value_ru'



# Generated at 2022-06-21 15:48:02.700813
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    # get_current_locale()
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.EN

    provider = BaseDataProvider(locale=locales.DEFAULT_LOCALE)
    assert provider.get_current_locale() == locales.EN

    provider = BaseDataProvider(locale=locales.LV)
    assert provider.get_current_locale() == locales.LV

    # override_locale()
    provider = BaseDataProvider()
    with provider.override_locale(locales.LV) as _:
        assert str(_) == 'BaseDataProvider <lv>'

    provider = BaseDataProvider()

# Generated at 2022-06-21 15:48:04.770024
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bsp = BaseDataProvider(locale='zh')
    assert (str(bsp) == 'BaseDataProvider <zh>')

# Generated at 2022-06-21 15:48:14.491484
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider.
    """
    from mimesis.providers.code import Code
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.phone import Phone
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.web import Web

    providers = [Code, Geography, Person, Payment, Phone, Science, Text,
                 Transport, Web]


# Generated at 2022-06-21 15:48:15.530119
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='en')
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-21 15:48:22.614330
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider('en')
    assert provider.__str__() == 'BaseDataProvider <en>'
    
    # create another provider with locale different from 'en'
    provider = BaseDataProvider('vn')
    assert provider.__str__() == 'BaseDataProvider <vn>'
    
    # use default for locale
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'
    

# Generated at 2022-06-21 15:48:26.066478
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider()
    assert str(provider) == 'TestProvider <en>'



# Generated at 2022-06-21 15:48:32.033243
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == 'en'
    assert bdp.random is random
    assert bdp.seed is None
    assert bdp._data == {}
    assert bdp._datafile == ''
    path = str(__file__).replace('__init__.py', '')
    assert bdp._data_dir == Path(path).joinpath('data')

# Generated at 2022-06-21 15:48:33.547303
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.__class__.__name__ == 'BaseProvider'


# Generated at 2022-06-21 15:49:03.188567
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'
    assert str(BaseDataProvider(locale='fr')) == 'BaseDataProvider <fr>'
    assert str(BaseDataProvider(locale='en_US')) == 'BaseDataProvider <en_us>'
    assert str(BaseDataProvider(locale='en_US_NEWYORK')) == 'BaseDataProvider <en_us_newyork>'
    assert str(BaseDataProvider(locale='en_UK')) == 'BaseDataProvider <en_uk>'

# Generated at 2022-06-21 15:49:04.690410
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()

# Test_Test_BaseProvider()

# Generated at 2022-06-21 15:49:06.480020
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider('ru')) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:49:16.413678
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from .person import Person
    from .address import Address
    from .numbers import Numbers
    from .food import Food
    from .personal import Personal
    from .science import Science
    from .vehicle import Vehicle
    from .misc import Misc
    from .art import Art
    from .finance import Finance
    from .social_network import SocialNetwork
    from .hardware import Hardware
    from .internet import Internet
    from .computer import Computer
    from .payment import Payment
    from .telecom import Telecom
    from .files import Files
    from .datetime import Datetime
    from .text import Text
    from .business import Business
    from .code import Code
    from .cryptography import Cryptography
    from .science import Science
    from .telecom import Telecom
    from .shakespeare import Shakespeare
    from .manufacturer import Manufacturer

# Generated at 2022-06-21 15:49:18.342565
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_provider = BaseDataProvider()
    assert isinstance(str(test_provider), str)

# Generated at 2022-06-21 15:49:20.196819
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider"""
    instance = BaseDataProvider()
    assert instance._current_locale == "en"


# Generated at 2022-06-21 15:49:23.572977
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # The method `get_current_locale` is not supported for this provider
    simple_provider = BaseProvider()
    with pytest.raises(ValueError):
        simple_provider.get_current_locale()

# Generated at 2022-06-21 15:49:26.347454
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en-us')
    assert provider
    assert provider.locale == 'en-us'


# Generated at 2022-06-21 15:49:33.218423
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()     # Default constructor with default values
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider, BaseDataProvider)

    assert provider.locale == 'en'
    assert provider._datafile == ''

    assert provider.seed is None
    assert provider.random is random
    provider.reseed()
    assert provider.random is not random
    assert provider.seed is not None

    provider = BaseDataProvider(locale='uk')
    assert provider.locale == 'uk'

    provider = BaseDataProvider(seed=10)
    assert provider.seed == 10
    assert provider.random is not random
    provider.reseed(seed=None)
    assert provider.random is not random
    assert provider.seed is not None


# Generated at 2022-06-21 15:49:35.565794
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider(locale='ru')
    assert(str(dp) == 'BaseDataProvider <ru>')

# Generated at 2022-06-21 15:50:01.091574
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base_data_provider = BaseDataProvider()
    with base_data_provider.override_locale(locales.EN) as new_base_data_provider:
        assert new_base_data_provider == base_data_provider
        assert new_base_data_provider.locale == 'en'
    assert base_data_provider.locale is None

# Generated at 2022-06-21 15:50:03.300002
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    x = BaseDataProvider()
    assert str(x) == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:50:06.777057
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Function to test method reseed of class BaseProvider."""
    base_provider = BaseProvider(seed="Hello")
    base_provider.reseed()
    assert base_provider.seed is None

# Generated at 2022-06-21 15:50:11.525618
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale_class_instance = BaseDataProvider("cs")
    # print("locale_class_instance:",locale_class_instance)
    current_locale = locale_class_instance.get_current_locale()
    # Expected output: cs
    print("current_locale:", current_locale)


# Generated at 2022-06-21 15:50:16.691588
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    case = BaseDataProvider(locale='en')
    print(case.get_current_locale())
    print(case)
    case = BaseDataProvider(locale='zh')
    print(case.get_current_locale())
    print(case)

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:50:18.058988
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'



# Generated at 2022-06-21 15:50:22.578643
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    def test_is_locale_supported_case():
        assert BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE
    def test_is_locale_unsupported_case():
        assert BaseDataProvider(locale='es').get_current_locale() == 'es'
    test_is_locale_supported_case()
    test_is_locale_unsupported_case()


# Generated at 2022-06-21 15:50:25.297234
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    BaseProvider(seed=0).reseed()

    assert BaseProvider(seed=0).seed == 0
    assert BaseProvider().seed == BaseProvider().seed


# Generated at 2022-06-21 15:50:29.169859
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider(seed=2)
    assert obj is not None
    assert obj.random is not None
    assert obj.seed == 2


# Generated at 2022-06-21 15:50:35.260635
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def get_default_locale(self):
            return u'en'

    p = TestDataProvider(locale=locales.EN)
    assert p.get_current_locale() == locales.EN

    with p.override_locale(locales.RU):
        assert p.get_current_locale() == locales.RU

    assert p.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:51:26.414863
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale_list = [locales.EN, locales.RU]
    
    # To make sure the data is loaded, even if on the previous tests some provider
    # has already been called
    [BaseDataProvider()._pull() for _ in range(10)]

    for locale in locale_list:
        # Create an instance of BaseDataProvider with a specified locale
        base_provider_instance_1 = BaseDataProvider(locale)
        
        # Get current locale
        current_locale = base_provider_instance_1.get_current_locale()
        
        assert locale == current_locale


# Generated at 2022-06-21 15:51:29.992958
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class TestProvider(BaseDataProvider):
        def __init__(self, locale):
            self.locale = locale

    p = TestProvider('ru')
    with p.override_locale('en') as tp:
        assert tp.locale == 'en'



# Generated at 2022-06-21 15:51:31.207596
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    x = BaseProvider()
    assert x.__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:51:33.001927
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider(seed=123)
    BaseProvider(seed=123).reseed()



# Generated at 2022-06-21 15:51:34.640853
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale ='af')) == 'BaseDataProvider <af>'


# Generated at 2022-06-21 15:51:37.732519
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Address as addr

    assert (str(BaseDataProvider()) == 'BaseDataProvider <en>')
    assert (str(addr()) == 'Address <en>')



# Generated at 2022-06-21 15:51:43.528460
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    d = Person('en')
    with d.override_locale('zh'):
        assert d.__str__() == 'Person <zh>'
        assert d.name(gender=Gender.FEMALE) != 'Joanne'
    assert d.__str__() == 'Person <en>'
    assert d.name(gender=Gender.FEMALE) == 'Joanne'


# Generated at 2022-06-21 15:51:47.915493
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class test_class(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    provider = test_class()
    for i in range(5):
        with provider.override_locale(locale='no') as new_provider:
            assert provider.locale == 'no'
            assert provider.locale == new_provider.locale

# Generated at 2022-06-21 15:51:53.443357
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str, seed: Seed = None):
            self._data: JSON = {
                'test': {
                    'test': 'test'
                }
            }
            super().__init__(locale, seed)

    arg1 = {}
    arg2 = {}

    with TestBaseDataProvider('en').override_locale(locale='ru') as test:
        arg1 = test._data
        arg2 = test.get_current_locale()

    assert isinstance(arg1, dict)
    assert isinstance(arg2, str)


# Generated at 2022-06-21 15:51:57.623404
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class BaseDataProvider(object):

        def __init__(self, locale):
            self.locale = locale
    dp = BaseDataProvider(locales.DEFAULT_LOCALE)
    assert 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE) == str(dp)



# Generated at 2022-06-21 15:53:34.733349
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Gender, Person
    from mimesis.providers import Person as P
    assert P(person=Gender.MALE).get_current_locale() == locales.EN
    assert P(person=Gender.MALE, locale=locales.RU).get_current_locale() == locales.RU


# Generated at 2022-06-21 15:53:36.830469
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed = 23)
    provider.reseed(43)
    assert provider.seed == 43
    assert isinstance(provider.random, Random)
    assert provider.random.get_seed() == 43


# Generated at 2022-06-21 15:53:38.072010
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:53:39.423744
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from . import generators
    test = generators.Person
    assert test.get_current_locale() == 'en'

# Generated at 2022-06-21 15:53:43.165933
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.base import BaseProvider
    from mimesis.typing import JSON
    assert BaseProvider().__str__() == 'BaseProvider'
    assert BaseProvider(seed='123').__str__() == 'BaseProvider'
    assert BaseProvider(seed='123').__str__() == 'BaseProvider'
    assert BaseProvider(seed='123').__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:53:52.268578
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    import mimesis.builtins
    f = mimesis.builtins.Food()
    print(f)
    # Result:
    # Food <en>
    # Я задал случайное число, используя определенную семя и данное число
    # выдал мне случайное число.
    f2 = mimesis.builtins.Food(seed=4321)
    print(f2)
    # Result:
    # Food <en>
    # Я зада

# Generated at 2022-06-21 15:53:57.835309
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test for method __str__ of class BaseDataProvider."""
    class BaseDataProvider(BaseDataProvider):  # noqa
        pass

    class BaseProvider(BaseProvider):  # noqa
        pass

    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

    provider2 = BaseDataProvider('ru')
    assert str(provider2) == 'BaseDataProvider <ru>'

    provider3 = BaseProvider()
    assert str(provider3) == 'BaseProvider'



# Generated at 2022-06-21 15:54:02.491146
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj1 = BaseProvider()
    obj1_seed = obj1.random.seed
    obj2 = BaseProvider(seed=0.5)
    obj2_seed = obj2.random.seed

    assert obj1_seed == obj2_seed
    assert isinstance(obj1.random, Random)
    assert isinstance(obj2.random, Random)


# Generated at 2022-06-21 15:54:04.412537
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method BaseDataProvider.__str__."""
    p = BaseDataProvider(locale='some locale')

    assert p.__str__() == 'BaseDataProvider <some locale>'


# Generated at 2022-06-21 15:54:08.487242
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """BaseDataProvider.override_locale(locale=locales.EN)
        -> Generator['BaseDataProvider', None, None]
    """
    bdp = BaseDataProvider(locale='en')
    with bdp.override_locale(locales.EN) as provider:
        assert bdp.get_current_locale() == locales.EN
    assert bdp.get_current_locale() == 'en'