

# Generated at 2022-06-21 15:45:50.438196
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.random.seed(123)
    assert bp.random.randint(1, 10) == bp.random.randint(1, 10)
    bp.reseed(321)
    assert bp.random.randint(1, 10) != bp.random.randint(1, 10)


# Generated at 2022-06-21 15:45:53.928071
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale='en')
    assert provider.locale == 'en'
    provider = BaseDataProvider(locale='ru')
    assert provider.locale == 'ru'


# Generated at 2022-06-21 15:46:03.142059
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, seed=None):
            super().__init__(locale=locale, seed=seed)

        def get_data(self) -> dict:
            return self._data

    provider = Test(locale='en')
    provider.get_data()
    assert provider.locale == 'en'
    assert len(provider.get_data()) > 0

    with provider.override_locale(locale='ru'):
        assert provider.locale == 'ru'
        assert len(provider.get_data()) > 0

    assert provider.locale == 'en'

# Generated at 2022-06-21 15:46:04.445189
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='uk').get_current_locale() == 'uk'

# Generated at 2022-06-21 15:46:09.233216
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class FakeProvider(BaseDataProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    f = FakeProvider(locale='ru')
    assert f.get_current_locale() == 'ru'

    f = FakeProvider()
    assert f.get_current_locale() == 'en'


# Generated at 2022-06-21 15:46:14.195714
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""
    provider = BaseProvider()
    provider_reseed = BaseProvider(None)
    assert provider != provider_reseed
    provider.reseed(None)
    assert provider == provider_reseed

# Generated at 2022-06-21 15:46:15.665159
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert provider is not None, 'Cannot be none'

# Generated at 2022-06-21 15:46:24.488185
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test1 = BaseDataProvider()
    assert test1._datafile == '', "The value is not set up properly"
    assert test1._data == {}, "The data is not empty"
    assert test1.locale == locales.DEFAULT_LOCALE, "The locale is not set up properly"
    assert test1.seed == None, "The value is not set up properly"

    test2 = BaseDataProvider(locale = "ru", seed = 1)
    assert test2._datafile == '', "The value is not set up properly"
    assert test2._data == {}, "The data is not empty"
    assert test2.locale == "ru", "The locale is not set up properly"
    assert test2.seed == 1, "The value is not set up properly"


# Generated at 2022-06-21 15:46:32.064815
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test for default locale
    assert BaseDataProvider().get_current_locale() == locales.EN
    # Test for valid locale
    assert BaseDataProvider(locale=locales.EN).get_current_locale() == locales.EN
    # Test for invalid locale
    assert BaseDataProvider(locale='jv').get_current_locale() == locales.EN

# Generated at 2022-06-21 15:46:34.677113
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'ru'
    provider_str = str(BaseDataProvider(locale=locale))
    assert provider_str == 'BaseDataProvider <ru>'


# Generated at 2022-06-21 15:47:06.416823
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # create an instance of BaseDataProvider
    obj = BaseDataProvider()

    # Seed is not set and locale is not set
    assert obj.seed is None
    assert obj.locale == 'en'

    # set a seed
    obj.reseed('test_seed')
    assert obj.seed == 'test_seed'
    assert obj.random.seed_value == 'test_seed'

    # reset the seed
    obj.reseed()
    assert obj.seed is None
    assert obj.random.seed_value == 'test_seed'

    # not set locale and override the locale without raise error
    obj._setup_locale()

    # set locale 'ar'
    obj._setup_locale('ar')

    # set locale '' and it is not allowed

# Generated at 2022-06-21 15:47:09.399155
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    reseed_val = 10
    assert provider.reseed(reseed_val), None
    assert provider.random.seed(reseed_val), None


# Generated at 2022-06-21 15:47:11.003143
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider(locale = 'zh')
    assert str(obj) == 'BaseDataProvider <zh>'

# Generated at 2022-06-21 15:47:13.433054
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Person(BaseProvider):
        pass
    person = Person()
    assert str(person) == 'Person'

# Generated at 2022-06-21 15:47:19.650789
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.builtins import Token
    from mimesis.typing import Seed
    seed = Seed(1)
    token1 = Token(seed=seed)
    token2 = Token(seed=seed)
    assert token1._get_token() == token2._get_token()

    token2.reseed()
    assert token1._get_token() != token2._get_token()

    token2.reseed(seed)
    assert token1._get_token() == token2._get_token()



# Generated at 2022-06-21 15:47:22.716188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Person
    provider = Person()
    with provider.override_locale('es') as mocked_provider:
        assert mocked_provider.locale == 'es'



# Generated at 2022-06-21 15:47:25.869330
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert isinstance(a, BaseProvider)
    assert isinstance(a, BaseProvider)
    assert 'BaseProvider object' == str(a)
    a.reseed(seed="seed")
    a.reseed(seed=None)


# Generated at 2022-06-21 15:47:31.963189
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    assert a.seed is None
    assert a.random is random
    assert a._data == {}
    assert a._datafile == ''
    assert a._data_dir.absolute() == Path('C:\GitHub\Mimesis\src\data').absolute()
    #assert a.locale == 'en'


# Generated at 2022-06-21 15:47:34.169145
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # BaseDataProvider()
    print(BaseDataProvider(seed=123))


# Generated at 2022-06-21 15:47:36.363551
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'


# Generated at 2022-06-21 15:47:59.616424
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert 'BaseDataProvider <en>' == str(provider)

    provider = BaseDataProvider('ru_RU')
    assert 'BaseDataProvider <ru_ru>' == str(provider)

# Generated at 2022-06-21 15:48:05.105116
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # generate random
    random = Random()
    assert random
    # initialize attributes for data providers
    locale = 'en'
    seed = random.seed()
    test_BaseDataProvider = BaseDataProvider(locale, seed)
    assert test_BaseDataProvider.random
    assert test_BaseDataProvider.locale == 'en'
    assert test_BaseDataProvider.seed == seed
    # get current locale
    assert test_BaseDataProvider.get_current_locale() == 'en'
    # clear all caches
    test_BaseDataProvider._pull.cache_clear()
    test_BaseDataProvider._pull()
    # override locale with passed and pull data for new locale
    locale = 'it_IT'
    test_BaseDataProvider._override_locale(locale)

# Generated at 2022-06-21 15:48:07.653400
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == 'en'


# Generated at 2022-06-21 15:48:11.464099
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'
    assert str(BaseProvider(seed=42)) == 'BaseProvider'
    assert str(BaseProvider(seed=42)) == 'BaseProvider'

if __name__ == "__main__":
    test_BaseProvider()

# Generated at 2022-06-21 15:48:14.483023
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
    assert b.random is random
    assert str(b) == 'BaseProvider'
    b.reseed(seed=42)
    assert b.seed == 42
    assert not b.random is random


# Generated at 2022-06-21 15:48:18.062688
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    test_cases = [
        {'locale': 'cs-cz', 'expected': 'BaseDataProvider <cs-cz>'},
        {'locale': 'en', 'expected': 'BaseDataProvider <en>'},
        {'locale': 'de-DE', 'expected': 'BaseDataProvider <de-DE>'},
    ]
    for test_case in test_cases:
        test_locale = test_case['locale']
        expected = test_case['expected']
        result = BaseDataProvider(test_locale)
        assert str(result) == expected, 'Unexpected result'

# Generated at 2022-06-21 15:48:20.667748
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__.

    :return: Nothing.
    """
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:48:32.648325
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Class for testing locale override."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            """Initialize attributes.

            :param locale: Current locale.
            :param seed: Seed to all the random functions.
            """
            super().__init__(locale=locale, seed=seed)

        def get_value(self) -> str:
            """Get data from JSON file.

            :return: Value from JSON file.
            """
            if self._data['values']['value'] == 'True value':
                return self._data['values']['value']
            else:
                raise NonEnumerableError(self._data['values']['value'])
    # -------------------------------
    test_

# Generated at 2022-06-21 15:48:34.651414
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with BaseDataProvider(locale='en') as prov:
        assert prov.locale == 'en'

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:48:37.994932
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider()
    assert(str(provider) == 'BaseProvider')

# Generated at 2022-06-21 15:49:02.092190
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider_0 = BaseDataProvider()
    assert provider_0.locale == 'en'
    provider_1 = BaseDataProvider(locale='ru')
    assert provider_1.locale == 'ru'



# Generated at 2022-06-21 15:49:06.852155
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Code
    code = Code()
    print(code)
    print(code.__str__())
    print(str(code))
    assert code.__str__() == str(code) == 'Code <en>'

    locale = 'ru'
    code = Code(locale=locale)
    print(code)
    print(code.__str__())
    print(str(code))
    assert code.__str__() == str(code) == 'Code <ru>'



# Generated at 2022-06-21 15:49:09.885650
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale."""
    bdp = BaseDataProvider(locale='en')
    assert bdp.get_current_locale() == bdp.locale

# Generated at 2022-06-21 15:49:16.896873
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider(locale='en', seed=1)
    assert base_data_provider
    assert base_data_provider.locale == 'en'
    assert base_data_provider.seed == 1
    assert base_data_provider._data == {}
    assert base_data_provider._datafile == ''
    assert base_data_provider._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert base_data_provider.random == Random()
    assert base_data_provider.random.seed(base_data_provider.seed)


# Generated at 2022-06-21 15:49:18.248277
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:49:19.775361
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider', 'ERROR: Method returned unexpected value'


# Generated at 2022-06-21 15:49:27.298722
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    seed = 56465465465 # Seed number
    locale = 'ru' # Current locale
    provider = BaseDataProvider(seed = seed)
    provider._data = {}
    provider._pull = lambda a : provider._data.update({'a': 55, 'b': 'QQQ'})
    with provider.override_locale(locale) as p:
        p._data.update({'a': 454, 'b': 'WWW'})
    assert provider._data == {'a': 454, 'b': 'WWW'}
    return True

# Generated at 2022-06-21 15:49:30.225832
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale='en', seed=20200308)
    if BaseDataProvider(locale='en', seed=20200308).locale == 'en' :
        print(1)

# Generated at 2022-06-21 15:49:33.308311
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()

    assert(bdp != None)


import unittest


# Generated at 2022-06-21 15:49:42.111773
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, Numbers

    address = Address()
    with address.override_locale('en'):
        assert address.get_current_locale() == 'en'

    with address.override_locale('ru'):
        assert address.get_current_locale() == 'ru'

    with address.override_locale('ru-ru'):
        assert address.get_current_locale() == 'ru-ru'

    numbers = Numbers()
    try:
        with numbers.override_locale('ru'):
            pass
    except ValueError:
        assert True


# Generated at 2022-06-21 15:50:30.721416
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    a = BaseProvider(seed=None)
    a.reseed(2)
    result = a.seed
    assert result == 2


# Generated at 2022-06-21 15:50:35.719756
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseProvider()
    assert p
    assert p.random is random
    assert p.seed is None

    p = BaseProvider(seed=42)
    assert p
    assert p.random is not random
    assert p.seed == 42

    p = BaseProvider()
    assert p
    assert p.random is random
    assert p.seed is None


# Generated at 2022-06-21 15:50:40.958056
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.data import BaseProvider
    from mimesis.providers.date import Date

    seed = 1
    bp = BaseProvider(seed)
    assert bp.random.seed == seed

    bp = BaseProvider()
    assert bp.random.seed == None

    date = Date(seed)

    assert not date.seed == bp.random.seed


# Generated at 2022-06-21 15:50:43.278114
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == '<BaseDataProvider: BaseDataProvider <en>>'

# Generated at 2022-06-21 15:50:45.077181
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider()
    base_provider.reseed(seed=None)



# Generated at 2022-06-21 15:50:46.920677
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider('en')
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:50:49.685665
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method BaseProvider.__str__."""
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'
    assert repr(provider) == '<BaseProvider>'



# Generated at 2022-06-21 15:50:51.434836
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=20)
    assert provider.seed == 20
    assert provider.random is not None


# Generated at 2022-06-21 15:50:56.931013
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    from mimesis.providers.person import Person as Person_

    assert str(Person()) == str(Person())
    assert str(Person_()) == str(Person_())
    

# Generated at 2022-06-21 15:50:57.962367
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()

# Generated at 2022-06-21 15:52:52.570131
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Test: initialize an object of class BaseProvider
    bp = BaseProvider()
    print(bp)

    # Test: set seed
    bp.reseed(seed=12345)
    print(bp.seed)

    # Test: check type of object
    assert isinstance(bp, BaseProvider)


# Generated at 2022-06-21 15:52:55.780057
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class ConcreteProvider(BaseDataProvider):
        _datafile = ''

    provider = ConcreteProvider(locale='uk')
    assert str(provider) == 'ConcreteProvider <uk>'


# Generated at 2022-06-21 15:52:59.760111
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider.

    Testing that reseed produce different results then initial seed.
    """
    provider = BaseProvider()
    init_seed = provider.seed

    provider.reseed()
    reseed_seed = provider.seed

    assert init_seed != reseed_seed, 'Different results'

# Generated at 2022-06-21 15:53:02.130408
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    data_provider = BaseProvider()
    assert data_provider.__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:53:02.895799
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:53:05.541307
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    my_provider = BaseProvider()
    assert isinstance(my_provider, BaseProvider)
    assert isinstance(my_provider, BaseDataProvider)
    assert my_provider.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:53:10.019577
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    def assert_str(provider, expected):
        assert str(provider) == expected

    provider = BaseDataProvider()
    assert_str(provider, 'BaseDataProvider <en>')

    provider = BaseDataProvider(locale='en')
    assert_str(provider, 'BaseDataProvider <en>')

    provider = BaseDataProvider(locale='en_US')
    assert_str(provider, 'BaseDataProvider <en_US>')

# Generated at 2022-06-21 15:53:13.187332
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale="hi")
    assert provider._data == {}
    assert provider._datafile == ""
    assert provider.locale == "hi"


# Generated at 2022-06-21 15:53:20.090417
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test class BaseDataProvider"""
    provider = BaseDataProvider(seed=100)

    assert provider.seed == 100
    assert provider.random == Random()
    assert provider.get_current_locale() == locales.EN
    assert str(provider) == 'BaseDataProvider <en>'

    provider = BaseDataProvider()
    assert provider.get_current_locale() is None
    assert provider.seed is None
    assert provider.random == Random()
    assert str(provider) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:53:23.487629
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    random_data = Random()
    random_data.seed(random_data.seed())
    random_data.seed()
    seed = 1
    random_data.seed(seed)
    assert random_data.seed() == seed
