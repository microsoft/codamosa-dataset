

# Generated at 2022-06-21 15:45:54.071757
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    a = BaseProvider()
    print(a.random)  # <mimesis.random.SystemRandom object at 0x7f5d5a5c5a90>

    b = BaseProvider('dasda')
    print(b.random)  # <mimesis.random.Random object at 0x7f5d5a5c57d0>

    b.reseed()
    print(b.random)  # <mimesis.random.SystemRandom object at 0x7f5d5a5c5a90>

if __name__ == '__main__':
    test_BaseProvider_reseed()

# Generate a random branch:
#   random_branch = bs.random.choice(bs.branch.branches, seed=seed)
#
# # Randomly generate a tree based on the

# Generated at 2022-06-21 15:45:56.259577
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    obj = BaseDataProvider()
    result = obj.get_current_locale()
    assert result == 'en'


# Generated at 2022-06-21 15:46:00.062594
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    old_seed = obj.seed
    new_seed = 'Some new seed'
    obj.reseed(new_seed)
    assert obj.seed == new_seed
    assert old_seed != new_seed

# Generated at 2022-06-21 15:46:03.221854
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider()
    with provider.override_locale('ru'):
        assert provider.locale == 'ru'

    with provider.override_locale(locales.DEFAULT):
        assert provider.locale == locales.DEFAULT

# Generated at 2022-06-21 15:46:06.367791
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(123)
    assert bp.seed == 123
    assert bp.random != random
    assert bp.random.seed == 123
    assert bp.random != bp.random


# Generated at 2022-06-21 15:46:08.088554
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # SHOULD return class name as string
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:46:09.704342
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:46:18.115802
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    fake = BaseDataProvider()
    locale = fake.get_current_locale()
    assert type(locale) == str, "Тип данных - string"
    assert len(locale) == 2, "Длина строки - 2 символа"
    assert locale == 'en', "Значение - 'en'"

# Generated at 2022-06-21 15:46:20.353961
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider(seed=123)
    print(a.random.int())
if __name__ == '__main__' :
    test_BaseProvider()

# Generated at 2022-06-21 15:46:22.977703
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__."""
    provider = BaseDataProvider()
    provider.locale = locales.DEFAULT_LOCALE
    assert (str(provider) == 'BaseDataProvider <en>')
    del provider


# Generated at 2022-06-21 15:46:47.359155
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'
    assert BaseDataProvider(locale='ru').get_current_locale() == 'ru'



# Generated at 2022-06-21 15:46:51.159156
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    import unittest
    class FakeProvider(BaseProvider):
        ''' Fake class for test '''
    class BaseProvider___str__TestCase(unittest.TestCase):
        ''' Test methods of class BaseProvider '''
        def test_str(self):
            # Unit test for method __str__ of class BaseProvider
            fake_provider = FakeProvider()
            self.assertEqual(str(fake_provider), 'FakeProvider')
    return BaseProvider___str__TestCase


# Generated at 2022-06-21 15:46:54.025166
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    test = BaseProvider()
    test.reseed()
    assert test.random is not random

# Generated at 2022-06-21 15:46:55.701063
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider()
    assert data, data


# Generated at 2022-06-21 15:47:00.028358
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Given
    seed = '1234'
    provider = BaseProvider(seed)

    # When

    # Then
    assert provider.random is not random  # noqa: WPS442



# Generated at 2022-06-21 15:47:02.822236
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.person import Person

    person = Person(locale='ru')

    assert ('{} <ru>'.format(person.__class__.__name__) == str(person))

# Generated at 2022-06-21 15:47:07.144637
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        pass

    provider = Provider()

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'
    assert provider.locale == 'en'

    provider.locale = 'fr'
    assert provider.locale == 'fr'

    with provider.override_locale('ru'):
        assert provider.locale == 'ru'
    assert provider.locale == 'fr'

# Generated at 2022-06-21 15:47:08.908443
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-21 15:47:11.158757
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    c = BaseDataProvider()
    print(c)  # <class 'mimesis.base.BaseDataProvider'> <en>

test_BaseDataProvider()

# Generated at 2022-06-21 15:47:14.811405
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Test for reseed method
    test_seed = 12345
    provider = BaseProvider(seed=test_seed)
    assert provider.seed == test_seed
    assert provider.random.seed(test_seed)


# Generated at 2022-06-21 15:47:35.105733
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # TODO: Write unit test
    pass

# Generated at 2022-06-21 15:47:37.008239
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """ Unit test for method get_current_locale of class BaseDataProvider """
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == 'en'


# Generated at 2022-06-21 15:47:40.749281
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    unit_test_BaseDataProvider_get_current_locale = provider.get_current_locale()
    assert unit_test_BaseDataProvider_get_current_locale == 'en'


# Generated at 2022-06-21 15:47:44.669326
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider(seed="Hello")
    base_provider.random = Random()
    assert base_provider
    base_provider.reseed()
    assert base_provider

# Generated at 2022-06-21 15:47:45.786801
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    _ = BaseDataProvider()

# Generated at 2022-06-21 15:47:52.618395
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Tire

    t = Tire()
    with t.override_locale(locales.EN):
        assert t.locale == locales.EN
        assert t.tire_brand() in t._data['tire']['brands']

    with t.override_locale(locales.RU):
        assert t.locale == locales.RU
        assert t.tire_brand() in t._data['tire']['brands']

    assert t.locale == locales.RU

# Generated at 2022-06-21 15:47:53.249789
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    BaseDataProvider().__str__()


# Generated at 2022-06-21 15:47:55.388651
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert isinstance(bdp, BaseDataProvider)

if __name__ == '__main__':
    test_BaseDataProvider()

# Generated at 2022-06-21 15:47:56.945864
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale = 'en')
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-21 15:48:07.203287
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    from unittest.mock import patch
    from unittest import TestCase

    class TestBaseProvider(BaseProvider):
        """Class for unit tests."""

    with patch('mimesis.base.random') as mock:
        data = {"seed": 123}
        base_provider = TestBaseProvider(**data)
        mock.seed.assert_called_with(123)

        base_provider = TestBaseProvider()
        mock.assert_not_called()

        mock.seed = BaseProvider.reseed
        base_provider.reseed()
        mock.assert_called_with(base_provider.seed)

    class TestBaseProvider(BaseProvider):
        """Class for unit tests."""


# Generated at 2022-06-21 15:48:30.045607
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b1 = BaseProvider()
    b2 = BaseProvider(seed=42)
    assert b1.seed is None
    assert b2.seed == 42
    b2.reseed(24)
    assert b2.seed == 24
    b1.reseed(14)
    assert b1.seed == 14
    assert b2.seed == 24


# Generated at 2022-06-21 15:48:31.775159
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random


# Generated at 2022-06-21 15:48:32.692396
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"

# Generated at 2022-06-21 15:48:34.755371
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:48:36.437492
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    print(provider)



# Generated at 2022-06-21 15:48:39.105057
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    provider.reseed()
    assert provider.seed is not None


# Generated at 2022-06-21 15:48:41.953360
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider().random is random
    assert BaseProvider().reseed().random is not random

# Test for method _pull of class BaseDataProvider

# Generated at 2022-06-21 15:48:45.324813
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Create instance of class BaseProvider
    # with all parameters using constructor
    provider = BaseProvider(seed=2)
    # Check all attributes of instance
    assert provider.seed == 2
    assert provider.random == random
    assert isinstance(provider.random, Random)


# Generated at 2022-06-21 15:48:50.617578
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Testing method BaseDataProvider.override_locale()"""

    dp = BaseDataProvider()

    if hasattr(dp, 'locale'):
        with dp.override_locale(locale=locales.EN):
            assert dp.locale == locales.EN

        assert dp.locale != locales.EN
    else:
        try:
            with dp.override_locale(locale=locales.EN):
                pass
        except ValueError:
            assert True
        else:
            assert False

# Generated at 2022-06-21 15:49:01.969753
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider.__init__.__doc__ == """\
        Initialize attributes for data providers.

        :param locale: Current locale.
        :param seed: Seed to all the random functions.
        """
    assert BaseProvider.__str__.__doc__ == """\
        Human-readable representation of locale."""
    assert BaseProvider._validate_enum.__doc__ == """\
        Validate enum parameter of method in subclasses of BaseProvider.

        :param item: Item of enum object.
        :param enum: Enum object.
        :return: Value of item.
        :raises NonEnumerableError: if ``item`` not in ``enum``.
        """

# Generated at 2022-06-21 15:49:48.482512
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    assert provider.random.randint(0, 100) > 0

provider = BaseDataProvider()


# Generated at 2022-06-21 15:49:52.568721
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(seed=10)
    assert bp.seed == 10
    assert bp.random._randrange.__self__.seed == 10


# Generated at 2022-06-21 15:49:56.240844
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    x = BaseDataProvider()
    assert x is not None
    x.locale = locales.DEFAULT_LOCALE
    res = x.__str__()
    assert res == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:49:58.182153
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    '''Test the constructor of class BaseProvider'''
    Base_Provider = BaseProvider()
    print(Base_Provider.seed)


# Generated at 2022-06-21 15:50:00.437270
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(locale=locales.EN, seed=0)
    assert provider.locale == locales.EN
    assert provider.seed == 0


# Generated at 2022-06-21 15:50:03.791155
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:50:05.661459
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-21 15:50:08.818012
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestDataProvider(BaseDataProvider):
        pass

    provider = TestDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:50:17.091304
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

        def item(self) -> str:
            return getattr(self, 'locale', locales.EN)

    tp = TestProvider()
    assert tp.item() == locales.EN

    with tp.override_locale(locales.RU):
        assert tp.item() == locales.RU

    assert tp.item() == locales.EN

# Generated at 2022-06-21 15:50:20.366536
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    # This is a simple unit test for method __str__ of class BaseDataProvider
    _BaseDataProvider = BaseDataProvider()
    __str__ = _BaseDataProvider.__str__()
    assert __str__ == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:51:53.556031
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Base Provider reseed test.

    :return: None.
    """
    p = BaseProvider(seed=1)
    p.reseed(seed=None)



# Generated at 2022-06-21 15:51:55.455430
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert repr(b) == "BaseProvider()"
    assert str(b) == 'BaseProvider'


# Generated at 2022-06-21 15:52:11.027096
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Provider(BaseDataProvider):
        pass
    provider = Provider()
    expected = '{} <{}>'.format(Provider.__name__, locales.DEFAULT_LOCALE)
    assert provider.__str__() == expected

    expected = '{} <en>'.format(BaseDataProvider.__name__)
    assert BaseDataProvider.__str__(provider) == expected

# Generated at 2022-06-21 15:52:11.971354
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    print(provider.get_current_locale())


# Generated at 2022-06-21 15:52:17.878206
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class DummyBaseDataProvider(BaseDataProvider):
        def __init__(self):
            super().__init__()

    item = DummyBaseDataProvider()
    # BaseDataProvider.locale is a property
    # Test with default value
    assert item.get_current_locale() == locales.DEFAULT_LOCALE
    # Test with defined value
    item.locale = 'en_US'
    assert item.get_current_locale() == 'en_US'


# Generated at 2022-06-21 15:52:19.903296
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider(seed=42)
    assert bp.__str__() == str(type(bp))


# Generated at 2022-06-21 15:52:21.940247
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:52:28.090626
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for method override_locale
    of class BaseDataProvider.
    """
    from mimesis.builtins import Code

    code = Code(seed=0xFF)

    with code.override_locale():
        assert code.get_current_locale() == 'ru'
        assert code.password(length=4, digits=4) == '3377'

    assert code.get_current_locale() == 'en'
    assert code.password(length=4, digits=4) == '8495'

# Generated at 2022-06-21 15:52:31.146867
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Arrange
    p = BaseDataProvider()

    # Act
    actual = p.get_current_locale()

    # Assert
    assert actual == locales.EN, "Locale should be 'en'"


# Generated at 2022-06-21 15:52:32.672629
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    d = BaseDataProvider()
    assert 'en' == d.get_current_locale()
