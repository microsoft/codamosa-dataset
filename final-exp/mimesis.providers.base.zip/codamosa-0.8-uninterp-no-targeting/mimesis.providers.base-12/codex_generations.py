

# Generated at 2022-06-21 15:45:45.277296
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    tmp = BaseDataProvider(locale='en')
    assert tmp.get_current_locale() == 'en'


# Generated at 2022-06-21 15:45:49.394874
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider class with method reseed."""
    prov = BaseProvider()
    prov.reseed()
    prov.reseed(seed=None)
    prov.reseed(seed=12345)
    prov.reseed(seed='123456')

# Generated at 2022-06-21 15:45:54.019395
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.providers.base import BaseDataProvider
    test = BaseDataProvider()
    test.locale = 'en'
    assert test.get_current_locale() == 'en'


# Generated at 2022-06-21 15:45:56.602730
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider(seed=None)
    assert bp.seed is None
    assert bp.random is random
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-21 15:46:00.469006
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of clas BaseProvider."""
    provider = BaseProvider(seed=2)
    assert provider.random.seed == 2
    provider.reseed(seed=3)
    assert provider.random.seed == 3



# Generated at 2022-06-21 15:46:03.230425
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    for _ in range(100):
        bdp = BaseDataProvider()
        if isinstance(bdp, BaseDataProvider):
            assert type(str(bdp)).__name__ == 'str'


# Generated at 2022-06-21 15:46:13.272157
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test for BaseDataProvider._override_locale."""
    provider = BaseDataProvider()
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.override_locale.cache_info().hits == 1
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == locales.RU
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.override_locale.cache_info().hits == 1

# Generated at 2022-06-21 15:46:14.924562
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider('en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:46:17.980315
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    data = provider.get_current_locale()
    assert data == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:46:21.811525
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en_GB')
    assert provider.get_current_locale() == 'en_gb'

    with provider.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'

    assert provider.get_current_locale() == 'en_gb'

# Generated at 2022-06-21 15:46:32.388022
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider

# Generated at 2022-06-21 15:46:38.456186
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    locale = BaseDataProvider(locale='ru_ru')
    data = locale._pull(datafile='addresses.json')
    assert data.get('municipalities')['city']['city_name'], ['Самара']
    with locale.override_locale(locale='en'):
        data = locale._pull(datafile='addresses.json')
        assert data.get('municipalities')['city']['city_name'], ['New York']

# Generated at 2022-06-21 15:46:48.289906
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, Geography, Person
    address = Address()
    geography = Geography()

    with address.override_locale(locales.RU):
        assert address.locale == locales.RU
        assert 'георгийевка' in address.city()
        assert 'белгородская' in address.region()
        assert 'георгийевка' in geography.city()

    assert address.locale == locales.EN

    with Person().override_locale(locales.IT):
        assert Person().locale == locales.IT

# Generated at 2022-06-21 15:46:49.869913
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base_provider = BaseProvider(seed=1234)
    assert base_provider.seed == 1234

# Generated at 2022-06-21 15:46:55.360005
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from custom_provider import CustomProvider

    base_provider = BaseProvider()
    custom_provider = CustomProvider(locale='en')

    assert str(base_provider) == 'BaseProvider'
    assert str(custom_provider) == 'CustomProvider <en>'


# Generated at 2022-06-21 15:46:58.389139
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print("Test_BaseProvider")
    a=BaseProvider()
    print(a)


# Generated at 2022-06-21 15:47:00.453755
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == "BaseProvider"

assert str(BaseProvider()) == "BaseProvider"

# Generated at 2022-06-21 15:47:02.122677
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider(locale="de", seed=123)

# Example of how to use method _validate_enum

# Generated at 2022-06-21 15:47:05.099350
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider(seed=None, locale='')
    assert provider._data == {}
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.random == random
    assert provider.seed is None



# Generated at 2022-06-21 15:47:07.317090
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider(locale='en')
    assert bdp.get_current_locale() == 'en'



# Generated at 2022-06-21 15:47:21.482210
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for the ``BaseDataProvider`` constructor."""
    bd = BaseDataProvider('en')
    assert bd is not None
    assert bd.locale == 'en'
    assert bd.seed

    bd = BaseDataProvider('ru', seed='defaultseed')
    assert bd is not None
    assert bd.locale == 'ru'
    assert bd.seed == 'defaultseed'



# Generated at 2022-06-21 15:47:23.682967
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider()
    assert isinstance(p, BaseProvider)
    assert p.seed is None
    assert p.random is random

# Generated at 2022-06-21 15:47:24.962829
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert isinstance(BaseDataProvider(), BaseDataProvider)


# Generated at 2022-06-21 15:47:29.097093
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider(seed=1)
    locale = provider.get_current_locale()
    assert locale == locales.RU

# Generated at 2022-06-21 15:47:31.962712
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    sr = BaseProvider()
    assert (sr.random.seed() == 0)
    sr.reseed(1)
    assert (sr.random.seed() == 1)

# Generated at 2022-06-21 15:47:34.168460
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Tests that the constructor of BaseProvider executes without error."""
    BaseProvider()


# Generated at 2022-06-21 15:47:36.413855
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    p = BaseDataProvider()
    print(p.get_current_locale())



# Generated at 2022-06-21 15:47:39.176062
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-21 15:47:42.928558
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider."""
    BDP = BaseDataProvider(locale=locales.EN)
    assert str(BDP) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:47:44.976667
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert 'Profile <en>' == str(BaseProvider())
    return True


# Generated at 2022-06-21 15:48:08.649978
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_provider = BaseDataProvider()
    name = base_provider.__class__.__name__
    actual = str(base_provider)
    expected = f'{name} <{locales.EN}>'
    assert actual == expected


# Generated at 2022-06-21 15:48:10.348090
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.base import BaseDataProvider
    assert BaseDataProvider() is not None


# Generated at 2022-06-21 15:48:13.770150
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed = 100)
    assert provider.random.randint(0,100) == 70
    assert provider.random.choices([1, 2, 3, 4, 5]) == [3]
    assert provider.random.choice([1, 2, 3, 4, 5]) == 5


# Generated at 2022-06-21 15:48:19.858807
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins.date import DateTime
    from mimesis.builtins.numbers import Digit
    from mimesis.builtins.text import Text
    assert BaseDataProvider()
    assert BaseDataProvider(locale='ru')
    assert BaseDataProvider(seed=1234)
    
    #BaseDataProvider._setup_locale()
    assert BaseDataProvider._setup_locale('ru')
    assert BaseDataProvider._setup_locale(locales.DEFAULT_LOCALE) == None
    
    #BaseDataProvider._update_dict()
    d1 = {'a':1,'b':2}
    d2 = {'c':3,'d':4}

# Generated at 2022-06-21 15:48:24.399473
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method ``reseed`` in class ``BaseProvider``."""
    provider = BaseProvider()
    random_number = provider.random.randint(0, 1000)
    assert random_number > 0, 'Seed is not working!'

# Generated at 2022-06-21 15:48:26.375962
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    prov = BaseProvider(seed=42)
    assert prov


# Generated at 2022-06-21 15:48:29.656428
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    assert(isinstance(b, BaseDataProvider))
    assert(hasattr(b, 'locale'))
    assert(b.locale == 'en')



# Generated at 2022-06-21 15:48:37.197772
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of BaseDataProvider."""
    provider = BaseDataProvider(locale='en', seed=324235)
    lst = ['en', 'ru', 'uk', 'es', 'fr']

    with provider.override_locale() as prov:  # noqa
        assert prov.get_current_locale() == 'en'
        assert prov.locale == 'en'

    with provider.override_locale('ru') as prov:
        assert prov.get_current_locale() == 'ru'
        assert prov.locale == 'ru'

    with provider.override_locale('fr') as prov:
        assert prov.get_current_locale() == 'fr'
        assert prov.locale == 'fr'


# Generated at 2022-06-21 15:48:42.940757
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    random_1 = provider.random
    random_2 = Random()
    provider.reseed(1_000)
    random_1.seed(1_000)
    assert random_1.random() == random_2.random()
    assert provider.seed == 1_000

# Generated at 2022-06-21 15:48:48.950027
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    locale = locales.EN
    assert locale in locales.SUPPORTED_LOCALES
    processor = BaseDataProvider(locale=locale)
    assert processor.locale == locale
    processor = BaseDataProvider(locale=locale, seed='abc')
    assert processor.locale == locale
    with pytest.raises(TypeError):
        processor = BaseDataProvider()
    with pytest.raises(UnsupportedLocale):
        processor = BaseDataProvider(locale='zh-CN')


# Generated at 2022-06-21 15:49:34.020654
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class DataProvider(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            pass

    obj = DataProvider()
    assert obj.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:49:38.117385
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    '''test_BaseProvider___str__ function'''

    def _test():
        '''test function'''

        p = BaseProvider()
        assert str(p) == 'BaseProvider'

    _test()



# Generated at 2022-06-21 15:49:41.204869
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.base import BaseDataProvider
    data = BaseDataProvider(seed=42)
    data.get_current_locale() == data.locale == locales.EN


# Generated at 2022-06-21 15:49:43.697086
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    seed = 25513
    locale = locales.RU
    provider_class = BaseDataProvider(locale=locale, seed=seed)
    assert provider_class.get_current_locale() == locale

# Generated at 2022-06-21 15:49:46.842102
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestCaseProvider(BaseDataProvider):
        pass
    assert str(TestCaseProvider()) == 'TestCaseProvider <en>'
    assert str(TestCaseProvider(locale='ru')) == 'TestCaseProvider <ru>'


# Generated at 2022-06-21 15:49:49.257302
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for method __str__ of class BaseDataProvider.
    """
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:49:52.612381
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    prov = BaseDataProvider(locale="ru")
    assert prov.get_current_locale() == "ru"


# Generated at 2022-06-21 15:49:55.200390
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    locale = provider.get_current_locale()
    assert locale == 'en'


# Generated at 2022-06-21 15:49:59.704481
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj1 = BaseProvider()
    assert obj1.seed is None
    assert obj1.random is random
    obj2 = BaseProvider(seed=10)
    assert obj2.seed == 10
    assert not obj2.random is random
    assert obj2.random._seed == obj2.seed
    obj2.random.seed(20)
    assert obj2.random._seed == obj2.seed



# Generated at 2022-06-21 15:50:01.028736
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider(seed = 12).seed == 12
    assert BaseProvider().seed is None


# Generated at 2022-06-21 15:51:35.119058
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    t = BaseProvider()
    assert t.seed == None
    assert t.random == random


# Generated at 2022-06-21 15:51:37.902102
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = 42
    provider = BaseProvider(seed)
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.random, Random)


# Generated at 2022-06-21 15:51:40.210152
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    lu = locales.LocaleUnifier()
    cl = lu.get('sr-CYRL')
    dp = BaseDataProvider(cl)
    assert dp.get_current_locale() == cl



# Generated at 2022-06-21 15:51:42.499346
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider()
    assert data_provider.__str__() == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:51:47.944082
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    provider = TestProvider('fr')

    with provider.override_locale('en'):
        assert provider.get_current_locale() == 'en'

    assert provider.get_current_locale() == 'fr'
    assert provider.__repr__() == "TestProvider <fr>"
    provider.__repr__()
    assert str(provider) == "TestProvider <fr>"
    assert repr(provider) == "TestProvider <fr>"


# Generated at 2022-06-21 15:51:49.471995
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    c = BaseDataProvider('ru')
    assert str(c) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:51:50.802440
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == "BaseProvider"


# Generated at 2022-06-21 15:52:10.471851
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.enums import Gender

    # Test for constructor
    t = BaseDataProvider("en")
    assert t.locale == "en"
    assert t.seed is None
    assert t.random is random

    # Test for reseed
    t.reseed(29)
    assert t.seed == 29

    # Test for __str__
    assert str(t) == "BaseDataProvider <en>"

    # Test for _validate_enum
    assert t._validate_enum(None, Gender) == "Male"
    assert t._validate_enum(Gender.FEMALE, Gender) == "Female"
    assert t._validate_enum(Gender.NOT_DEFINED, Gender) == "NotDefined"
    assert t._validate_enum(Gender.MALE, Gender) == "Male"
   

# Generated at 2022-06-21 15:52:13.678644
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseDataProvider()
    provider.reseed(5)
    seed = provider.seed
    assert seed == 5

    # test with another data
    provider.reseed(6)
    seed = provider.seed
    assert seed == 6


# Generated at 2022-06-21 15:52:15.156986
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert 'en' == BaseProvider(seed=0).get_current_locale()


# Generated at 2022-06-21 15:55:23.420356
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed="Hello")
    assert provider.reseed("Test") is None


# Generated at 2022-06-21 15:55:26.153832
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    result = provider.__str__()
    assert result == 'BaseDataProvider <en>',\
        'This method has to return: BaseDataProvider <en>'



# Generated at 2022-06-21 15:55:27.392671
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
