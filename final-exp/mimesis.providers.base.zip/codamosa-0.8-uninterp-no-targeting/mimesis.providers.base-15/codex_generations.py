

# Generated at 2022-06-21 15:45:53.179962
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test method __str__ of class BaseDataProvider."""
    locale = locales.EN
    base_data_provider = BaseDataProvider(locale)
    assert isinstance(base_data_provider, BaseDataProvider)
    name_class = base_data_provider.__class__.__name__
    assert isinstance(name_class, str)
    str_base_data_provider = str(base_data_provider)
    assert isinstance(str_base_data_provider, str)
    assert str_base_data_provider == name_class + ' <' + locale + '>'

# Generated at 2022-06-21 15:45:55.079758
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale = 'ru')
    assert provider.get_current_locale() == 'ru'


# Generated at 2022-06-21 15:45:56.344611
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class test(BaseDataProvider):
        pass
    x = test()

# Generated at 2022-06-21 15:46:03.818279
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
  # init with valid locale
  BaseDataProvider(locale='en')

  # init without locale
  BaseDataProvider()

  # init with invalid locale
  try:
    BaseDataProvider(locale='invalid_locale')
  except UnsupportedLocale:
    pass
  
  # init with valid seed
  BaseDataProvider(seed=1)
  
  # init with invalid seed (must be integer or 'random' or None)
  try:
    BaseDataProvider(seed='invalid_seed')
  except ValueError:
    pass


# Generated at 2022-06-21 15:46:05.693410
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:46:07.218441
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider()


# Generated at 2022-06-21 15:46:19.580043
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    class DataProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed)

    # Check if BaseDataProvider init successfully
    dp = DataProvider()
    assert dp

    # Check if BaseDataProvider has locale attribute
    assert hasattr(dp, 'locale')
    # Check if BaseDataProvider has _data attribute
    assert hasattr(dp, '_data')
    # Check if BaseDataProvider has _datafile attribute
    assert hasattr(dp, '_datafile')
    # Check if BaseDataProvider has _data_dir attribute
    assert hasattr(dp, '_data_dir')

    # Check if BaseDataProvider has get_current_locale method
    assert hasattr(dp, 'get_current_locale')
    # Check if BaseDataProvider has locale dependent

# Generated at 2022-06-21 15:46:25.801890
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # For BaseProvider
    BP = BaseProvider(seed=5)
    assert BP.random.randint(0, 100) == 71
    BP.reseed(seed=10)
    assert BP.random.randint(0, 100) == 32

    BP = BaseProvider(seed=10)
    assert BP.random.randint(0, 100) == 32
    BP.reseed(seed=None)
    assert BP.random.randint(0, 100) != 32


# Generated at 2022-06-21 15:46:28.443019
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:46:29.660551
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=None)
    bp.reseed(None)
    assert True


# Generated at 2022-06-21 15:46:45.397835
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider()
    assert base_data_provider
    assert base_data_provider._data == {}
    assert base_data_provider._datafile == ''
    assert base_data_provider.locale == 'en'
    assert base_data_provider.seed is None
    assert base_data_provider.random is random



# Generated at 2022-06-21 15:46:47.220131
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    dp = BaseProvider()
    old_seed = dp.seed
    dp.reseed(2)
    assert dp.seed != old_seed


# Generated at 2022-06-21 15:46:48.523131
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj = BaseProvider()
    assert obj.seed is None
    assert obj.random == random


# Generated at 2022-06-21 15:46:50.635403
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """ Constructor Test."""
    provider = BaseProvider()
    print(provider.seed)
    assert provider is not None, 'Constructor test for BaseProvider failed'


# Generated at 2022-06-21 15:46:53.383532
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    x = BaseDataProvider()
    assert x.get_current_locale() == locales.EN


# Generated at 2022-06-21 15:46:58.490118
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed."""
    seed = 'test'
    provider = BaseProvider(seed=seed)
    random_ = provider.random
    provider.reseed(seed)
    assert random_ is not provider.random

# Generated at 2022-06-21 15:47:00.545365
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().seed is None
    assert BaseProvider(7777).seed == 7777


# Generated at 2022-06-21 15:47:01.926457
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    res = obj.__str__()
    assert res == 'BaseProvider'


# Generated at 2022-06-21 15:47:02.817283
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider(seed=1)

# Generated at 2022-06-21 15:47:05.101771
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test = BaseDataProvider()
    print('Test: ')
    print(test)
    print()

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-21 15:47:30.471243
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins.faker import faker
    from mimesis.builtins.numbers import numbers
    from mimesis.builtins.text import text
    assert 'Faker' == str(faker)
    assert 'Numbers' == str(numbers)
    assert 'Text' == str(text)


# Generated at 2022-06-21 15:47:33.851110
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    prov = BaseProvider()
    assert prov._data == {}
    assert prov._datafile == ''
    assert prov.locale == ''

# Unit test class BaseDataProvider

# Generated at 2022-06-21 15:47:37.949079
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    try:
        BaseDataProvider(locale="fake", seed=0)
        raise Exception("Should have raised an exception")
    except Exception:
        pass

    BaseDataProvider(locale="en", seed=0)


# Generated at 2022-06-21 15:47:41.314419
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # Test for the correct initialization of the class attributes.
    provider = BaseDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    assert provider.random is random

# Generated at 2022-06-21 15:47:48.670581
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
    assert b.random is random
    assert b.__str__() is 'BaseProvider'
    assert b.reseed(123) is None
    assert b.seed == 123
    assert b.random is not random

    b2 = BaseProvider(123)
    assert b2.seed == 123
    assert b2.random is not random
    assert b2.__str__() is 'BaseProvider'



# Generated at 2022-06-21 15:47:52.101113
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    seed = 0
    locale = 'ru'
    x = BaseDataProvider(locale=locale, seed=seed)
    print(x)

    expected = 'BaseDataProvider <ru>'
    assert str(x) == expected


# Generated at 2022-06-21 15:47:56.646146
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    locale = 'ru'
    seed = 25
    bdp = BaseDataProvider(locale, seed)
    assert str(bdp) == 'BaseDataProvider <ru>'
    bdp2 = BaseDataProvider()
    assert str(bdp2) == 'BaseDataProvider <en>'
    assert bdp._setup_locale('en') == None
    assert bdp.random == random


# Generated at 2022-06-21 15:47:58.768740
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = 'en'
    provider = BaseDataProvider(locale=locale)
    result = provider.get_current_locale()

    assert result == locale

# Generated at 2022-06-21 15:48:00.395106
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    my_provider = BaseProvider()
    assert str(my_provider) == 'BaseProvider'



# Generated at 2022-06-21 15:48:06.127266
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider(locale='ru')
    assert provider.locale == 'ru'
    assert provider.get_current_locale() == 'ru'

    provider = BaseDataProvider()
    assert provider.locale == 'en'
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:48:48.435187
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:48:51.246695
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method ``__str__`` of class ``BaseProvider``."""
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'


# Generated at 2022-06-21 15:48:56.558949
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Test(BaseDataProvider):
        pass
    
    assert str(Test()) == 'Test <en>'
    assert str(Test('ru')) == 'Test <ru>'
    assert str(Test('zz')) == 'Test <zz>'


# Generated at 2022-06-21 15:49:01.931944
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
  """Testing constructor."""
  assert BaseDataProvider().locale == 'en'

  obj = BaseDataProvider(locale='ru')
  assert obj.locale == obj.get_current_locale() == 'ru'

  obj.reseed(seed=10)
  assert obj.random.seed_value == 10

  obj2 = BaseDataProvider(seed=100)
  assert obj2.random.seed_value == 100



# Generated at 2022-06-21 15:49:08.308799
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins.science import Science
    from mimesis.builtins.government import Government
    from mimesis.builtins.cryptography import Cryptography
    from mimesis.builtins.names import Names
    from mimesis.builtins.internet import Internet
    from mimesis.builtins.politics import Politics

    sci = Science()
    gov = Government()
    crypt = Cryptography()
    names = Names()
    internet = Internet()
    politics = Politics()

    with sci.override_locale('ru'):
        sci_ru = sci.get_current_locale()
        sci_en = sci.get_current_locale()

    with gov.override_locale('ru'):
        gov_ru = gov.get_current_locale()
        gov_en

# Generated at 2022-06-21 15:49:10.719767
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(100)
    assert  bp.seed == 100
    assert bp.random is not random


# Generated at 2022-06-21 15:49:15.843069
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.schema import Field as SchemaField
    from mimesis.builtins import Person as SchemaPerson

    locale = 'ru'
    provider = SchemaPerson(locale=locale)
    assert provider.__str__() == 'SchemaPerson <{}>'.format(locale)

    field = SchemaField(provider)
    assert field.__str__() == 'SchemaField <{}>'.format(locale)

# Generated at 2022-06-21 15:49:25.929487
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class User(object):
        pass
    class MyProvider(BaseDataProvider):
        def __init__(self, locale = locales.EN):
            super().__init__(locale = locale)

        def name(self):
            return "name {}".format(self.locale)

    p1 = MyProvider(locale = locales.DEFAULT_LOCALE)
    assert p1.name() == "name en"

    p2 = MyProvider(locale = locales.RU)
    assert p2.name() == "name ru"

    p3 = MyProvider(locale = locales.via)

    # override locale
    with p3.override_locale(locale = locales.DEFAULT_LOCALE) as p:
        result = p.name()
    assert result == "name en"

   

# Generated at 2022-06-21 15:49:28.791567
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp1 = BaseDataProvider()
    assert str(bdp1) == 'BaseDataProvider <en>'
    assert bdp1.get_current_locale() == 'en'

# Generated at 2022-06-21 15:49:30.189044
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:51:03.873074
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # This test is for method __str__ of class BaseProvider
    printed = print(BaseProvider())
    assert printed is None


# Generated at 2022-06-21 15:51:05.713090
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Unit test for __str__ method of BaseDataProvider class."""
    bdp = BaseDataProvider()
    assert str(bdp) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:51:07.115291
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    provider.get_current_locale()


# Generated at 2022-06-21 15:51:11.191755
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    # Test normal case, create a object and get its locale
    obj = BaseDataProvider(locale='he')
    assert obj.locale == 'he'
    # Test the case with UnsupportedLocale
    try:
        obj = BaseDataProvider(locale='He')
    except UnsupportedLocale:
        pass
    # Test the case with None
    obj = BaseDataProvider(locale=None)
    assert obj.locale == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:51:20.195497
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Init class
    class TestProvider(BaseProvider):
        def __init__(self, seed=None):
            super(TestProvider, self).__init__(seed)

        def get_int(self, minimum, maximum):
            return self.random.randint(minimum, maximum)

    provider = TestProvider()

    # Check randomness of numbers
    num1 = provider.get_int(0, 1000)
    num2 = provider.get_int(0, 1000)
    assert num1 != num2

    # Check randomness of numbers with reseeding
    provider.reseed('seed1')
    num3 = provider.get_int(0, 1000)
    num4 = provider.get_int(0, 1000)
    assert num3 == num4
    assert num1 != num3
    assert num2 != num3

    #

# Generated at 2022-06-21 15:51:21.077230
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:51:22.594034
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Environment
    assert Environment().__str__() == 'Environment <en>'

# Generated at 2022-06-21 15:51:24.593709
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    oi = BaseProvider()
    txt = str(oi)
    assert txt == 'BaseProvider'


# Generated at 2022-06-21 15:51:27.167870
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider()
    assert str(a) == a.__class__.__name__
    assert 'BaseProvider' == a.__class__.__name__
    assert 'BaseProvider' == str(a)

# Generated at 2022-06-21 15:51:29.993043
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:54:57.282685
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Init a provider
    provider = BaseProvider(seed=1)
    # Check if it is initialized correctly
    assert provider.seed == 1
    # Check if the object is packed correctly
    assert str(provider) == 'BaseProvider'
    # Change the seed and check if it's done correctly
    provider.reseed(2)
    assert provider.seed == 2


# Generated at 2022-06-21 15:55:02.010162
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider.reseed method."""
    provider_1 = BaseProvider()
    provider_2 = BaseProvider()
    assert provider_1.seed != provider_2.seed
    assert provider_1.random != provider_2.random
    provider_1.seed = 'test'
    assert provider_1.seed == provider_2.seed
    assert provider_1.random != provider_2.random
    provider_1.reseed('test-reseed')
    assert 'test' != provider_1.seed
    assert provider_1.random != provider_2.random


# Generated at 2022-06-21 15:55:03.088603
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    b = BaseDataProvider()
    print(b.get_current_locale())

# Generated at 2022-06-21 15:55:04.274616
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert type(provider.random) == Random


# Generated at 2022-06-21 15:55:11.298973
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=54398)
    rand_number_1 = provider.random.randint()
    rand_number_2 = provider.random.randint()
    provider.reseed()
    rand_number_3 = provider.random.randint()
    rand_number_4 = provider.random.randint()
    assert rand_number_1 == rand_number_3
    assert rand_number_2 == rand_number_4


# Generated at 2022-06-21 15:55:13.739158
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    '''
    Check that the current locale is returned without errors
    '''
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == 'en'

# Generated at 2022-06-21 15:55:16.906481
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Tests reseed method of BaseProvider class."""
    base = BaseProvider()
    base.reseed()
    origin_seed = base.seed
    base.reseed()
    assert origin_seed == base.seed
    base.reseed('foo')
    assert 'foo' == base.seed


# Generated at 2022-06-21 15:55:21.063418
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    class _BaseDataProvider(BaseDataProvider):

        class Meta(object):

            locale = 'es'

    provider = _BaseDataProvider()
    assert provider.get_current_locale() == provider.Meta.locale
    with provider.override_locale(locale=locales.DEFAULT_LOCALE):
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
    assert provider.get_current_locale() == provider.Meta.locale

# Generated at 2022-06-21 15:55:22.791971
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bp = BaseDataProvider()
    assert bp.__str__() == 'BaseDataProvider <{}>'.format(locales.DEFAULT_LOCALE)

# Generated at 2022-06-21 15:55:23.668831
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    x = BaseProvider(seed = '123')
    print(x)
