

# Generated at 2022-06-21 15:45:45.121380
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None
test_BaseProvider()


# Generated at 2022-06-21 15:45:47.061057
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    foo = BaseProvider()
    foo.reseed('aaa')
    assert foo.seed == 'aaa'


# Generated at 2022-06-21 15:45:55.332563
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method ``override_locale`` of class ``BaseDataProvider``.

    This method is a context manager which allows overriding
    current locale for locale-dependent providers.

    Example of usage::

        with datetime.override_locale('ru'):
            datetime.build_time()

    :raises ValueError: if provider has not locale dependent.
    """
    import mimesis.builtins.datetime
    with mimesis.builtins.datetime.override_locale('ru'):
        mimesis.builtins.datetime.build_time()



# Generated at 2022-06-21 15:46:00.614920
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    assert str(bdp) == "BaseDataProvider <en>"
    bdp.locale = "uk_UA"
    assert str(bdp) == "BaseDataProvider <uk_ua>"
    bdp.locale = "ru_RU"
    assert str(bdp) == "BaseDataProvider <ru>"



# Generated at 2022-06-21 15:46:02.299309
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p = BaseProvider()
    assert str(p) == 'BaseProvider'


# Generated at 2022-06-21 15:46:04.967865
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data = BaseDataProvider()
    assert isinstance(data, BaseDataProvider)

if __name__ == "__main__":
    test_BaseDataProvider()

# Generated at 2022-06-21 15:46:14.665469
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Code

    code = Code()

    # Normal usage
    with code.override_locale('ru') as c:
        assert c.locale == 'ru'
        assert c.get_current_locale() == 'ru'

    # Exception
    code.locale = 'de'

    try:
        with code.override_locale('ru') as c:
            assert c.locale == 'ru'
            assert c.get_current_locale() == 'ru'
    except ValueError:
        pass

# Generated at 2022-06-21 15:46:17.688341
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class A(BaseDataProvider):
        pass
    a = A()
    assert a.__str__() == 'A <en>'



# Generated at 2022-06-21 15:46:18.365640
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()
    BaseDataProvider(locale='en', seed=111222)

# Generated at 2022-06-21 15:46:20.557656
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    pr = BaseProvider()
    assert pr.seed == None
    assert pr.random == random
    pr.reseed(20)
    assert pr.random != random


# Generated at 2022-06-21 15:46:35.490124
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    assert obj.seed is None

    obj.reseed('3')
    obj2 = BaseProvider('3')
    assert obj.random is not random
    assert obj.random.seed == obj2.random.seed

    obj.reseed()
    obj2 = BaseProvider()
    assert obj.random.seed != obj2.random.seed

# Generated at 2022-06-21 15:46:37.254408
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert 'BaseProvider' == str(provider)


# Generated at 2022-06-21 15:46:47.172790
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def get_current_locale(self) -> str:
            return self.locale

    p = Provider(locale='en')
    assert p.get_current_locale() == 'en'

    with p.override_locale('ru') as provider:
        assert provider.get_current_locale() == 'ru'
        assert p.get_current_locale() == 'en'

    assert p.get_current_locale() == 'en'

    with p.override_locale('ru'):
        assert p.get_current_locale() == 'ru'

    assert p.get_current_locale() == 'en'


# Generated at 2022-06-21 15:46:48.455889
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider"""
    provider = BaseProvider()
    assert provider



# Generated at 2022-06-21 15:46:50.012882
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class Foo(BaseProvider):
        pass
    BaseProvider.reseed()
    Foo.reseed()

# Generated at 2022-06-21 15:46:52.567757
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    obj=BaseProvider(seed=None)
    assert obj.seed == None
    assert obj.random == random


# Generated at 2022-06-21 15:46:54.643614
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:47:05.917805
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis.builtins import Code, Lorem
    from mimesis.enums import Language
    from mimesis.typing import Seed

    code = Code('en')
    lorem = Lorem('en')
    code_en = Code()
    lorem_en = Lorem()

    seed: Seed = 23
    code.reseed(seed)
    code_en.reseed(seed)
    lorem.reseed(seed)
    lorem_en.reseed(seed)

    assert code.language.get_code(Language.EN) == \
        code_en.language.get_code(Language.EN)
    assert lorem.text.word(quantity=2) == lorem_en.text.word(
        quantity=2)

# Generated at 2022-06-21 15:47:07.690497
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='en')) == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:47:10.413628
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.person import Person

    p = Person('ru')
    assert str(p) == 'Person <ru>'

    p = Person()
    assert str(p) == 'Person <en>'

# Generated at 2022-06-21 15:47:21.774534
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    print('\n==== Unit test for constructor of class BaseProvider ====')
    print('==== nothing to test now ====')


# Generated at 2022-06-21 15:47:25.868164
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider()
    assert p.locale == "en"
    assert p.seed is None
    assert p.random == random
    assert p._data == {}
    assert p._datafile == ""
    assert p._data_dir == Path(__file__).parent.parent.joinpath('data')



# Generated at 2022-06-21 15:47:35.501611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Testing context manager override_locale of class BaseDataProvider."""
    from mimesis.builtins import Builder
    provider = Builder()
    locale = locales.UK
    locale_ = locales.DEFAULT_LOCALE

    with provider.override_locale(locale) as data:
        assert data.locale == locale

        with provider.override_locale(locale_) as inner:
            assert inner.locale == locale_

            with inner.override_locale(locale) as _inner:
                assert _inner.locale == locale

    assert provider.locale == locale

# Generated at 2022-06-21 15:47:37.614090
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
   baseDataProvider = BaseDataProvider()
   assert (baseDataProvider != None)


# Generated at 2022-06-21 15:47:49.237171
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test for method reseed."""
    def test_ExternalRandom():
        """Test for ExternalRandom."""
        provider = BaseProvider()
        assert provider.seed == None
        assert provider.random == random
        provider.reseed(seed=42)

        assert provider.seed == 42
        assert provider.random != random
        return provider

    provider = test_ExternalRandom()
    def test_reseed_without_param():
        provider.reseed()
        assert provider.seed == None
        assert provider.random == random
    def test_reseed_with_default_param():
        default_param = BaseProvider(seed=24)

        provider.reseed(seed=default_param)
        assert provider.seed == 24
        assert provider.random != random
    def test_reseed_with_Random():
        r = Random()


# Generated at 2022-06-21 15:47:51.974450
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(1234)
    assert bp.seed == 1234
test_BaseProvider_reseed()


# Generated at 2022-06-21 15:47:55.190999
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """
    Test for method __str__ of class BaseDataProvider.
    """
    provider = BaseDataProvider()
    assert isinstance(provider, BaseDataProvider) == True
    assert provider.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:47:56.723238
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    data = BaseProvider()
    assert data is not None # We are using this to suppress the IDE warning
    

# Generated at 2022-06-21 15:48:03.702501
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Code
    from mimesis.exceptions import UnsupportedLocale
    c = Code(locale='ru')
    l = c.get_current_locale()
    assert l == 'ru'
    with c.override_locale('locale_that_not_exists'):
        pass
    l = c.get_current_locale()
    assert l == 'ru'
    try:
        with c.override_locale('locale_that_really_not_exists'):
            l = c.get_current_locale()
            assert l == 'locale_that_really_not_exists'
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-21 15:48:08.855352
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    assert BaseProvider().seed is None

    test_seed = 1234
    test_random = Random(test_seed)
    assert BaseProvider(test_seed).seed == test_seed
    assert BaseProvider(test_seed).random.random() == test_random.random()

test_BaseProvider()

# Generated at 2022-06-21 15:48:25.371169
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.builtins import USState
    from mimesis.random import random
    import time
    x = USState(seed=123456789)
    # now when random() and x.random() return the same values we know that
    # x.reseed() works.
    time.sleep(1)
    x.reseed()
    assert random() == x.random()

# Generated at 2022-06-21 15:48:27.406545
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    bp.reseed(1)
    assert bp.seed

# Generated at 2022-06-21 15:48:32.771306
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.enums import Locale

    a = BaseDataProvider(seed=100)
    a._override_locale('en')
    assert a.get_current_locale() == 'en'

    b = BaseDataProvider(
        locale=Locale.ENGLISH_UNITED_STATES,
        seed=100)
    assert b.get_current_locale() == 'en-us'

# Generated at 2022-06-21 15:48:41.900089
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    baseprovider = BaseProvider(seed="Hello")
    assert baseprovider.seed == "Hello"
    assert baseprovider.random is not Random
    assert baseprovider.random.seed == "Hello"
    assert baseprovider.reseed("World") is None
    assert baseprovider.random.seed == "World"
    assert baseprovider.__str__() == "BaseProvider"
    baseprovider.reseed()
    assert baseprovider.seed is None
    baseprovider.__init__()
    assert baseprovider.random is not Random


# Generated at 2022-06-21 15:48:45.350710
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

    provider = BaseDataProvider('ru')
    assert provider.get_current_locale() == 'ru'



# Generated at 2022-06-21 15:48:47.469308
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=1)
    assert provider.seed == 1
    provider.reseed(seed=2)
    assert provider.seed == 2

# Generated at 2022-06-21 15:48:51.018960
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    from mimesis.providers import BaseProvider
    obj = BaseProvider('1234567')
    assert obj is not None


# Generated at 2022-06-21 15:49:02.215904
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """

    :return:
    """
    class Test(BaseProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(seed=seed)

        def test_method(self):
            return self.random.randint(0, 100)

    test = Test(seed=None)
    test_result = test.test_method()

    test_new = Test(seed=None)
    test_new_result = test_new.test_method()
    assert test_result == test_new_result, \
        f'After reseed method of class BaseProvider ' \
        f'random generator must became same'

    test = Test(seed=None)
    test_result = test.test_method()

    test.reseed(seed=None)

# Generated at 2022-06-21 15:49:03.912924
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider()
    assert isinstance(base_data_provider, BaseDataProvider)


# Generated at 2022-06-21 15:49:06.358682
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    TestBaseProvider = BaseProvider()
    TestBaseProvider.random
    TestBaseProvider.reseed(123)
    TestBaseProvider.__str__()


# Generated at 2022-06-21 15:49:32.147066
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """
    Unit test for method reseed of class BaseProvider

    Test for the following attributes of class BaseProvider:

        - self.random: The instance of class random.Random
        - self.seed
    """
    class SubBaseProvider(BaseProvider):
        """Subclass from BaseProvider for testing."""
        pass

    seed = 10
    base_provider = SubBaseProvider(seed=seed)
    assert isinstance(base_provider.random, Random)

    seed = 20
    base_provider.reseed(seed=seed)
    assert base_provider.seed == seed


# Generated at 2022-06-21 15:49:35.564813
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    loc = BaseProvider()
    name = loc.__class__.__name__
    assert str(loc) == name


# Generated at 2022-06-21 15:49:37.589819
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    prov = BaseDataProvider('en')
    assert prov.get_current_locale() == 'en'

# Generated at 2022-06-21 15:49:41.378633
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for constructor of class BaseDataProvider."""
    __provider = BaseDataProvider()
    assert __provider.locale == 'en'


if __name__ == '__main__':
    """Run doctests."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 15:49:43.245981
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Provider(BaseDataProvider):
        pass
    p = Provider()
    assert p.get_current_locale() == 'en'


# Generated at 2022-06-21 15:49:54.687684
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    def test_str_default_locale(self):
        assert self.__str__() == 'Country <en>'

        with self.override_locale('en'):
            assert self.__str__() == 'Country <en>'

        with self.override_locale('de'):
            assert self.__str__() == 'Country <de>'

        with self.override_locale('ru'):
            assert self.__str__() == 'Country <ru>'

    def test_str_arbitrary_locale(self):
        provider = Country(locale='de')
        assert provider.__str__() == 'Country <de>'

        provider = Country(locale='ru')
        assert provider.__str__() == 'Country <ru>'

    return test_str_default_loc

# Generated at 2022-06-21 15:49:56.709829
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method ``__str__`` of class ``BaseProvider``."""
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:50:02.110391
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    import time
    p1 = BaseProvider()
    p2 = BaseProvider()
    # p1.reseed()
    # p2.reseed()
    key1 = p1._next_key()
    key2 = p2._next_key()
    assert key1 == key2
    key1 = p1._next_key()
    key2 = p2._next_key()
    assert key1 == key2
    key1 = p1._next_key()
    key2 = p2._next_key()
    assert key1 == key2


# Generated at 2022-06-21 15:50:03.649060
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:50:08.064376
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test BaseDataProvider._get_current_locale()."""
    
    locale = 'en'
    bdp = BaseDataProvider(locale)
    current_locale = bdp.get_current_locale()

    assert current_locale == locale



# Generated at 2022-06-21 15:51:02.155203
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.data import personal
    from mimesis.enums import Gender

    # Using default seed
    a = personal.Personal('en')
    b = personal.Personal('en')
    assert a.seed == b.seed
    assert a.seed is None
    assert a.uid() != b.uid()

    # Reseed with None
    a.reseed(None)
    assert a.seed == b.seed
    assert a.seed is None
    assert a.uid() != b.uid()

    # Reseed with int
    seed = 1
    a.reseed(seed)
    assert a.seed == seed
    assert a.uid() == b.uid()
    b.reseed(seed)
    assert b.uid() == a.uid()

    # Reseed with str

# Generated at 2022-06-21 15:51:02.821557
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:51:04.727768
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    locale = locales.DEFAULT_LOCALE
    data = BaseDataProvider(locale)
    assert data.get_current_locale() == locale



# Generated at 2022-06-21 15:51:13.928634
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data = {
        'text': {
            'en': {
                'words': ['foo', 'bar', 'baz'],
                'text': 'foo bar baz'
            },
            'ru': {
                'words': ['привет', 'мир', 'пока'],
                'text': 'привет мир пока'
            },
            'fr': {
                'words': ['bonjour', 'le', 'monde'],
                'text': 'bonjour le monde'
            }
        }
    }

    class DummyProvider(BaseDataProvider):
        def _pull(self, datafile: str = '') -> None:
            self._data = data[datafile]


# Generated at 2022-06-21 15:51:15.867201
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    p1 = BaseProvider()
    assert p1.__str__() == "BaseProvider"

# Generated at 2022-06-21 15:51:17.351224
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:51:26.169547
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    locale = 'ru'
    locale_mapping = {'ru': 'Russian',
                      'en': 'English'}

    with Address().override_locale(locale) as address:
        with Person().override_locale(locale) as person:
            output_person = [person.street_prefix(), person.full_name(
                gender=Gender.FEMALE), person.full_name(gender=Gender.MALE),
                             person.full_name(gender=Gender.NEUTRAL)]


# Generated at 2022-06-21 15:51:28.040360
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider(seed=1)
    assert a.seed == 1
    assert a.random == random



# Generated at 2022-06-21 15:51:36.144293
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider):
        def return_locale(self) -> str:
            return self.locale

    test = Test()
    with test.override_locale(locales.RU):
        assert test.return_locale() == locales.RU
    assert test.return_locale() == locales.EN
    with test.override_locale(locales.RU):
        with test.override_locale(locales.UK):
            assert test.return_locale() == locales.UK
        assert test.return_locale() == locales.RU
    assert test.return_locale() == locales.EN

# Generated at 2022-06-21 15:51:38.435115
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Person
    assert str(Person(locale="es")) == "Person <es>"

# Generated at 2022-06-21 15:52:34.349659
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    base = BaseDataProvider(locale='ru')
    with base.override_locale('en'):
        assert base._data['hello'] == 'Hello'
    assert base._data['hello'] == 'Привет'


# Generated at 2022-06-21 15:52:35.924545
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider('en')
    assert str(b) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:52:40.798007
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the method override_locale of class BaseDataProvider."""
    class TestProvider(BaseDataProvider):
        """Test provider for a method override_locale."""

        def get_current_locale(self) -> str:
            """Get current locale in the context manager."""
            return self.locale

    locale = 'ru'
    test_provider = TestProvider(locale=locale)
    assert test_provider.get_current_locale() == locale
    with test_provider.override_locale() as provider:
        assert provider.locale == locales.DEFAULT_LOCALE
        assert provider.get_current_locale() == locales.DEFAULT_LOCALE
        assert provider.get_current_locale() == provider.locale
    assert test_provider.get_current_locale

# Generated at 2022-06-21 15:52:46.730482
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestDataProvider(BaseDataProvider):
        def get_current_locale(self):
            return self.locale
    assert 'en' == TestDataProvider().get_current_locale()
    assert 'ru' == TestDataProvider('ru').get_current_locale()
    assert 'en-US' == TestDataProvider('en-US').get_current_locale()

# Test the method _override_locale of class BaseDataProvider

# Generated at 2022-06-21 15:52:51.882966
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test method override_locale of class BaseDataProvider.

    Expected:
    The locale of the object must be changed,
    without exception.
    """
    provider = BaseDataProvider()
    with provider.override_locale() as p:
        assert p.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:52:54.924366
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider('ru')
    obj._pull('test')
    assert obj.__str__() == "BaseDataProvider <ru>", "__str__() method test failed"


# Generated at 2022-06-21 15:52:57.919951
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Initialize attributes."""
    provider = BaseProvider()

    assert provider.seed is None
    assert provider.random is random
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-21 15:52:58.848652
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()


# Generated at 2022-06-21 15:53:02.325414
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        pass

    locale = "en"

    test = TestProvider()
    with test.override_locale(locale):
        assert test.locale == locale

# Generated at 2022-06-21 15:53:04.525785
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.__str__() == 'Cryptographic'


# Generated at 2022-06-21 15:54:35.545983
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.random import random
    from mimesis.providers import Person, Address
    p1 = Person('en-GB', seed=0)
    p2 = Person('en-GB', seed=0)
    p3 = Person('en-GB', seed=1)
    a1 = Address('en-GB', seed=0)
    a2 = Address('en-GB', seed=0)
    a3 = Address('en-GB', seed=1)

    assert p1.name() == 'Bobby Lehmann'
    assert p1.full_name() == 'Bobby Lehmann'
    assert p2.name() == 'Bobby Lehmann'
    assert p2.full_name() == 'Bobby Lehmann'
    assert p3.name() == 'Edna Glover'
    assert p3.full_name

# Generated at 2022-06-21 15:54:39.222064
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    bp = BaseProvider()
    bp.reseed()
    assert bp.random is not random

# Generated at 2022-06-21 15:54:42.534386
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class BaseDataProviderChild(BaseDataProvider):
        pass

    bdp = BaseDataProviderChild(locale='en')
    assert bdp.__str__() == 'BaseDataProviderChild <en>'

# Generated at 2022-06-21 15:54:44.385705
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Provider(BaseDataProvider):
        pass
    p = Provider()
    assert p.get_current_locale() == 'en'

# Generated at 2022-06-21 15:54:45.691937
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-21 15:54:49.312463
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.providers.clothes import ShoeSize
    a = ShoeSize('en')
    assert a.get_current_locale() == 'en'


# Generated at 2022-06-21 15:54:53.872380
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Address, AddressEN, AddressRU
    providers = [
        Address,
        AddressEN,
        AddressRU
    ]

    for provider in providers:
        with provider().override_locale(locales.RU) as p:
            assert isinstance(p, BaseDataProvider)
            assert p.locale == locales.RU


# Generated at 2022-06-21 15:54:59.531907
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)
            self.datafile = 'myfile.json'
            self._pull()

        def get_data(self) -> Dict:
            return self._data

    provider = Provider()
    assert provider.locale == locales.EN
    with provider.override_locale(locale=locales.RU) as p:
        p.get_data()
    assert provider.locale == locales.EN

# Generated at 2022-06-21 15:55:02.100134
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test = BaseDataProvider(locale='en')
    assert test.locale == 'en'
    test.reseed(seed=42)
    assert test.seed == 42
    assert test.random != 'random'

if __name__ == "__main__":
    # Unit test
    test_BaseDataProvider()

# Generated at 2022-06-21 15:55:11.734448
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider_with_locale = BaseDataProvider(locale='ru')
    provider_without_locale = BaseProvider()

    try:
        provider_with_locale.override_locale()
    except AttributeError:
        assert False, 'Provider with locale failed!'

    try:
        provider_without_locale.override_locale()
    except ValueError:
        assert True, 'Provider without locale failed!'

    # Override locale and use overridden locale
    with provider_with_locale.override_locale(locale='fr'):
        assert provider_with_locale.locale == 'fr'

    # Check if locale is overridden
    assert provider_with_locale.locale == 'ru'
