

# Generated at 2022-06-21 15:45:46.615709
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    # Test constructor with seed
    test = BaseProvider(seed=0)
    assert test.seed == 0
    assert test.random == Random()


# Generated at 2022-06-21 15:45:51.318955
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    for provider in BaseDataProvider._subclasses:
        provider = provider()
        try:
            with provider.override_locale('ru'):
                assert provider.locale == 'ru'
        except ValueError:
            continue
        assert provider.locale == 'en'

# Generated at 2022-06-21 15:45:58.806210
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = 'ru'
    # Initialize attributes
    class BaseDataProvider(BaseProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                 seed: Seed = None) -> None:
            # Initialize attributes for data providers.
            super().__init__(seed=seed)
            self._data: JSON = {}
            self._datafile = ''
            self._setup_locale(locale)
            self._data_dir = Path(__file__).parent.parent.joinpath('data')
    # Calling __str__ of class BaseDataProvider and get result
    result = BaseDataProvider(locale=locale).__str__()
    # Check that result is equal to expected result
    expected_result = 'BaseDataProvider <ru>'
    assert result == expected_result

# Generated at 2022-06-21 15:46:00.203187
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider != None


# Generated at 2022-06-21 15:46:05.728938
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test class."""

        class Meta:
            """Providers meta."""

            name = 'test_provider'

    provider = TestProvider()
    assert provider.locale == locales.EN
    with provider.override_locale(locale='de_de') as prov:
        assert prov.locale == 'de_de'

    assert provider.locale == locales.EN

# Generated at 2022-06-21 15:46:08.049329
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    l = BaseDataProvider()
    l.__str__()
    l2 = BaseDataProvider(locale='en')
    l2.__str__()

# Generated at 2022-06-21 15:46:10.056837
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    BP = BaseProvider()
    BP.reseed(1)
    assert BP.seed == 1

# Generated at 2022-06-21 15:46:14.820993
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """BaseProvider.__str__ is ok."""
    # Arrange
    provider = BaseProvider()

    # Act
    got = str(provider)

    # Assert
    assert got == 'BaseProvider'


# Generated at 2022-06-21 15:46:20.548012
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    try:
        from mimesis.providers.address import Address
        provider = Address()
        assert isinstance(provider._data, Dict)
    except ValueError:
        print("Country data provider is not locale dependent")
    finally:
        provider = BaseDataProvider(locale="en")
        assert provider._data_dir == Path(__file__).parent.parent.joinpath('data')


# Generated at 2022-06-21 15:46:21.395525
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider() is not None

# Generated at 2022-06-21 15:46:34.222321
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider"""
    from mimesis.data import __version__
    assert BaseProvider(seed=None).seed != BaseProvider(seed=__version__).seed



# Generated at 2022-06-21 15:46:35.667036
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp is not None


# Generated at 2022-06-21 15:46:38.197075
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    print(BaseDataProvider())
    print(BaseDataProvider(locale='ru'))
    print(BaseDataProvider(seed=0))

# test_BaseDataProvider()

# Generated at 2022-06-21 15:46:42.518650
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for reseed method of class BaseProvider."""
    p = BaseProvider()
    p.reseed(seed=1)
    assert p.seed == 1
    assert p.random.seed == 1


# Generated at 2022-06-21 15:46:43.634286
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.seed is None


# Generated at 2022-06-21 15:46:52.315338
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.business import Business
    from mimesis.enums import BusinessIndustryType

    # With context manager
    b = Business(locale='en')
    with b.override_locale('de') as provider:
        assert provider.get_current_locale() == 'de'
    assert b.get_current_locale() == 'en'

    # Without context manager
    b = Business(locale='en')
    assert b.override_locale('de') is None
    assert b.get_current_locale() == 'en'

    # Without context manager, with builtin provider
    b = Business(locale='en')
    b.bank_account_details.__self__.locale = 'de'

    assert b.override_locale('de') is None

# Generated at 2022-06-21 15:46:53.514133
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    lc1 = "dz"
    bdp1 = BaseDataProvider(lc1)
    assert bdp1.locale == lc1

# Generated at 2022-06-21 15:46:54.478138
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    a = BaseDataProvider()
    assert a != BaseDataProvider(), "BaseDataProvider's constructor is wrong"

# Generated at 2022-06-21 15:46:57.162022
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """BaseProvider.__str__()"""
    bp = BaseProvider()
    assert bp.__str__() == "BaseProvider"



# Generated at 2022-06-21 15:47:01.585346
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    class DummyProvider(BaseDataProvider):
        pass
    assert str(DummyProvider()) == 'DummyProvider <en>'
    assert str(DummyProvider(locale='es')) == 'DummyProvider <es>'

# Generated at 2022-06-21 15:47:14.892895
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_p = BaseProvider()
    assert base_p.seed is None

    seed = "abcdefghijklmnopqrstuvwxyz"
    base_p = BaseProvider(seed=seed)
    assert base_p.seed == seed



# Generated at 2022-06-21 15:47:17.702764
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test for constructor of class BaseDataProvider."""
    test_data = BaseDataProvider(locale='en')
    assert test_data.locale == 'en'
    return True


# Generated at 2022-06-21 15:47:20.353780
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    BaseDataProvider()

# Generated at 2022-06-21 15:47:21.329744
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
	a = BaseDataProvider(locale = 'en')


# Generated at 2022-06-21 15:47:23.882591
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test __str__ method of BaseDataProvider class."""
    bdp = BaseDataProvider()
    assert (str(bdp) == 'BaseDataProvider <en>')



# Generated at 2022-06-21 15:47:29.732050
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # BaseDataProvider.__init__
    # test case
    BaseDataProvider()

    # BaseDataProvider.reseed
    # test case
    BaseDataProvider(seed=12345).reseed()

    # test case
    BaseDataProvider(seed=12345).reseed(12345)

    # BaseDataProvider._validate_enum
    # test case
    class EnumTest(object):
        def __init__(self):
            self.value = 1

    BaseDataProvider(seed=12345)._validate_enum(EnumTest(), EnumTest)

    # test case
    BaseDataProvider(seed=12345)._validate_enum(None, EnumTest)

    # test case

# Generated at 2022-06-21 15:47:41.751749
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider()
    # 同一种 seed 的随机数序列
    bp.reseed(seed=1234)
    v = []
    for _ in range(10):
        v.append(bp.random.randint(1,100))
    assert v == [98, 56, 48, 78, 27, 79, 36, 46, 66, 37]
    # 不同 seed 的随机数序列
    bp.reseed(seed=12345)
    v = []
    for _ in range(10):
        v.append(bp.random.randint(1,100))
    assert v == [75, 55, 73, 24, 67, 98, 51, 20, 98, 98]


# Generated at 2022-06-21 15:47:52.311355
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # Check seed is none
    assert BaseProvider().seed is None
    # Check seed is none
    assert BaseProvider(seed=None).seed is None
    # Check seed is 0
    assert BaseProvider(seed=0).seed == 0
    # Check seed is 1
    assert BaseProvider(seed=1).seed == 1
    # Check seed is 1
    bp = BaseProvider()
    bp.reseed(seed=None)
    assert bp.seed is None
    # Check seed is 1
    bp = BaseProvider()
    bp.reseed(seed=0)
    assert bp.seed == 0
    # Check seed is 1
    bp = BaseProvider()
    bp.reseed(seed=1)
    assert bp.seed == 1


# Generated at 2022-06-21 15:47:54.279815
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class DataProvider(BaseProvider):
        pass

    dp = DataProvider()
    assert str(dp) == 'DataProvider'



# Generated at 2022-06-21 15:47:58.233405
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale=locales.RU).locale == locales.RU
    assert BaseDataProvider(locale=locales.US).locale == locales.US
    assert BaseDataProvider(locale=locales.ES).locale == locales.ES
    assert BaseDataProvider(locale="zh-CN").locale == "zh-CN"

# Generated at 2022-06-21 15:48:20.233583
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider"""
    bdp = BaseDataProvider()
    assert bdp.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:48:22.951730
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-21 15:48:30.641284
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test the BaseDataProvider class and the override_locale method."""
    from mimesis.providers.base import BaseDataProvider

    class MockProvider(BaseDataProvider):
        pass

    p = MockProvider(locale='en_UA')
    assert p.locale == 'en_ua'

    with p.override_locale('uk_UA') as uk_p:
        assert uk_p.locale == 'uk_ua'
    assert p.locale == 'en_ua'

# Generated at 2022-06-21 15:48:33.885143
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Given
    l = 'test'
    b = BaseProvider(seed=0)
    b.__class__.__name__ = l
    # When
    result = str(b)
    # Then
    assert result == 'BaseProvider'


# Generated at 2022-06-21 15:48:39.057147
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 123
    provider = BaseProvider(123)
    random = provider.random
    random.random()
    provider.reseed(seed)
    random = provider.random
    assert random.random() == 0.131275845060443



# Generated at 2022-06-21 15:48:41.217119
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider("en")
    assert dp.__str__() == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:48:46.529755
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.builtins import Person

    person = Person()
    with person.override_locale('ru') as p:
        assert str(p) == 'Person <ru>'

    assert str(person) == 'Person <en>'



# Generated at 2022-06-21 15:48:49.996273
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en' # Возврат локали по умолчанию

# Generated at 2022-06-21 15:48:54.662042
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    myprovider = BaseDataProvider(locale='en', seed=17)
    assert myprovider.locale == 'en'
    assert myprovider.seed == 17
    assert myprovider._datafile == ''


# Generated at 2022-06-21 15:48:56.360443
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:49:18.123638
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    assert b.seed is None


# Generated at 2022-06-21 15:49:19.416056
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:49:21.568135
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    obj = BaseProvider()
    obj.reseed(1)
    assert obj.seed is 1
    assert isinstance(obj.random, Random)



# Generated at 2022-06-21 15:49:25.033651
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bs = BaseProvider(seed=1)
    print(bs.random.__class__.__name__)
    print(bs.random.seed)
    bs.reseed(seed=2)
    print(bs.random.seed)
    print(bs.__str__())

# Generated at 2022-06-21 15:49:26.646364
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider


# Generated at 2022-06-21 15:49:29.029943
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.data_providers import Address
    p = Address()
    assert p.__str__() == 'Address <en>'

# Generated at 2022-06-21 15:49:31.851754
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.random is random
    provider.reseed(seed=42)
    assert provider.random.randint == 42

# Generated at 2022-06-21 15:49:35.355765
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'
test_BaseProvider___str__()


# Generated at 2022-06-21 15:49:36.891051
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == "BaseDataProvider <en>"


# Generated at 2022-06-21 15:49:40.588527
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.internet import Internet
    internet = Internet()

    assert str(internet) == 'Internet <en>'

    with internet.override_locale('ru'):
        assert str(internet) == 'Internet <ru>'

# Generated at 2022-06-21 15:50:03.599068
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    b = BaseDataProvider()
    assert str(b) == "BaseDataProvider <en>"
    b.locale = 'ru'
    assert str(b) == "BaseDataProvider <ru>"

# Generated at 2022-06-21 15:50:05.451066
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    dp = BaseDataProvider()
    assert str(dp) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:50:16.767565
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Test method get_current_locale of class BaseDataProvider."""
    assert (_b := BaseDataProvider()).get_current_locale() == locales.DEFAULT_LOCALE
    assert _b.get_current_locale() == locales.DEFAULT_LOCALE
    assert _b.get_current_locale() == locales.DEFAULT_LOCALE

    class SimpleDataProvider(BaseDataProvider):
        """Inherits from BaseDataProvider."""
    assert (_b := SimpleDataProvider()).get_current_locale() == locales.DEFAULT_LOCALE
    assert _b.get_current_locale() == locales.DEFAULT_LOCALE
    assert _b.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:50:24.318611
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        """Test class."""

        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale=locale, seed=seed)


    instance = TestProvider(locale=locales.DEFAULT_LOCALE)
    assert instance.locale == locales.DEFAULT_LOCALE

    with instance.override_locale(locales.EN) as provider:
        assert provider.locale == locales.EN
    assert instance.locale == locales.DEFAULT_LOCALE

    with instance.override_locale(locales.RU) as provider:
        assert provider.locale == locales.RU

# Generated at 2022-06-21 15:50:29.002461
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from . import address
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(BaseProvider(seed=42)) == 'BaseProvider'
    assert str(address.Address(locale='en', seed=42)) == 'Address <en>'

# Generated at 2022-06-21 15:50:36.166249
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.random import Random
    from mimesis.data import BaseProvider
    from mimesis.exceptions import NonEnumerableError

    seed = 123
    bp = BaseProvider(seed=seed)
    assert bp.seed == seed
    assert isinstance(bp.random, Random)
    assert isinstance(bp, BaseProvider)

    try:
        bp._validate_enum('foo', int)
        assert False
    except NonEnumerableError:
        assert True

    assert bp._validate_enum(None, int)



# Generated at 2022-06-21 15:50:38.654387
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    class Child(BaseProvider):
        pass
    child = Child()
    assert str(child) == 'Child'
    

# Generated at 2022-06-21 15:50:48.986237
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    class TestBaseProvider(BaseProvider):
        def __init__(self, seed1: Seed = None, seed2: Seed = None) -> None:
            self.seed1 = seed1
            self.seed2 = seed2
            self.random1 = random
            self.random2 = random
            super().__init__(seed = seed1)
            if seed2 is not None:
                self.reseed(seed2)
        def reseed(self, seed: Seed = None) -> None:
            if self.random1 is random:
                self.random1 = Random()
            if self.random2 is random:
                self.random2 = Random()
            self.seed1 = seed
            self.random1.seed(self.seed1)
            self.seed2 = seed

# Generated at 2022-06-21 15:50:50.987169
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bp = BaseDataProvider()
    locale = getattr(bp, 'locale', locales.DEFAULT_LOCALE)
    assert 'BaseDataProvider <{}>'.format(locale) == str(bp)

# Generated at 2022-06-21 15:50:57.962475
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestBaseDataProvider(BaseDataProvider):
        pass
    locale = 'en'
    test = TestBaseDataProvider(locale=locale)
    with test.override_locale(locale=locale) as t:
        assert t.get_current_locale() == locale
    assert test.get_current_locale() == locale
    return True


# Generated at 2022-06-21 15:51:43.890888
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers import Address
    address = Address(seed=123456)
    assert str(address) == 'Address <en-US>'


# Generated at 2022-06-21 15:51:45.748470
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bep = BaseProvider()
    print(bep)
    # Output: 1. BaseProvider <en>
    #         2. BaseProvider <None>


# Generated at 2022-06-21 15:51:48.279311
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test BaseDataProvider.__str__."""
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:51:54.402454
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        """Dummy provider for unit tests."""

        class Meta:
            """Metaclass for DummyProvider."""

            locales = {locales.EN, locals.RU}

        def method(self, text: str = None) -> str:
            """Dummy method to test override_locale."""
            if text:
                return text
            return self.random.choice(['a', 'b', 'c'])

    dummy = DummyProvider(locales.EN)
    text = 'foo'
    with dummy.override_locale(locales.RU) as provider:
        assert provider.method(text) == text
        assert dummy.method(text) != text

# Generated at 2022-06-21 15:51:55.670655
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-21 15:52:11.027964
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for method reseed of class BaseProvider."""
    from mimesis.builtins import CardinalDirection
    provider = BaseProvider()
    assert provider.seed is None
    assert provider.random is random

    provider.reseed(seed=1)
    assert provider.seed == 1
    assert provider.random.seed(provider.seed)

    current_random = provider.random.randint(1, 100)
    provider.reseed(seed=1)
    assert provider.random.randint(1, 100) == current_random

    provider.reseed()
    assert provider.seed is None
    assert provider.random is random

    assert isinstance(provider._validate_enum(None, CardinalDirection), str)


# Generated at 2022-06-21 15:52:17.928296
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import BaseDataProviderBuiltIn

    bdpb = BaseDataProviderBuiltIn()
    assert bdpb.get_current_locale() == locales.DEFAULT_LOCALE

    assert str(bdpb) == "BaseDataProviderBuiltIn <{}>".format(locales.DEFAULT_LOCALE)

    with bdpb.override_locale(locales.EN):
        assert str(bdpb) == "BaseDataProviderBuiltIn <en>"
    assert bdpb.get_current_locale() == locales.DEFAULT_LOCALE



# Generated at 2022-06-21 15:52:19.605448
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    expected = 'BaseProvider'
    result = str(BaseProvider())
    assert (expected == result)



# Generated at 2022-06-21 15:52:23.725331
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from .meta import MetaProvider
    from .person import Person
    assert str(BaseProvider()) == 'BaseProvider'
    assert str(Person()) == 'Person <en>'
    assert str(Person('ru')) == 'Person <ru>'
    assert str(MetaProvider()) == 'Meta'

# Generated at 2022-06-21 15:52:29.528778
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    p = BaseDataProvider(locale=locales.EN, seed=11)
    assert p.get_current_locale() == locales.EN
    assert p.locale == locales.EN
    with p.override_locale(locales.RU):
        assert p.get_current_locale() == locales.RU
        assert p.locale == locales.RU
    assert p.locale == locales.EN


# Generated at 2022-06-21 15:53:53.171783
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'



# Generated at 2022-06-21 15:53:56.659705
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    base_provider = BaseProvider(seed=1)
    # test for creation of object
    assert base_provider is not None
    # test for seed attribute
    assert base_provider.seed == 1
    # test for random attribute
    assert base_provider.random is not None


# Generated at 2022-06-21 15:54:00.614139
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    print('\nClass BaseProvider\nTest: reseed (default seed)')
    p = BaseProvider()
    a = p.seed
    b = p.reseed()
    c = p.seed
    print('a: {}, b: {}, c: {}'.format(a, b, c))


# Generated at 2022-06-21 15:54:03.155346
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():

    bdp = BaseDataProvider()
    assert bdp.__str__() == 'BaseDataProvider <en>'

    with bdp.override_locale('ru') as p:
        assert p.__str__() == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:54:04.313818
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='tt').get_current_locale() == 'tt'



# Generated at 2022-06-21 15:54:06.449329
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'
    assert str(bp) == 'BaseProvider'


# Generated at 2022-06-21 15:54:14.010241
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for BaseProvider.reseed() method."""
    class MyProvider(BaseProvider):
        """Provider for base test."""

        def test_func(self) -> int:
            """Test function."""
            return self.random.randint(0, 10)

    provider = MyProvider()

    list_of_numbers = set()
    for _ in range(1000):
        list_of_numbers.add(provider.test_func())

    provider.reseed(4444)

    list_of_numbers_orig = list_of_numbers.copy()

    for _ in range(1000):
        list_of_numbers.add(provider.test_func())

    assert len(list_of_numbers) == len(list_of_numbers_orig)

# Generated at 2022-06-21 15:54:18.492056
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    assert BaseDataProvider().get_current_locale() == 'en'
    assert BaseDataProvider(locale='es').get_current_locale() == 'es'



# Generated at 2022-06-21 15:54:19.855309
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    l = BaseDataProvider()
    assert str(l) == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:54:21.846027
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    base_data_provider = BaseDataProvider(locale="en")
    print(base_data_provider)
