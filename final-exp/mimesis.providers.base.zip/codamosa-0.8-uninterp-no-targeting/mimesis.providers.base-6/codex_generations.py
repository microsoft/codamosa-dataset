

# Generated at 2022-06-21 15:45:49.344998
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """ Constructor should take in a seed

    """
    # BaseProvider is abstract, so we need to build a subclass
    # to test.
    class Provider(BaseProvider):
        pass

    # Verify that the constructor takes a seed
    provider = Provider(seed=1)
    assert provider.seed is not None

    # Make sure the seed is ignored if not provided
    provider = Provider()
    assert provider.seed is None


# Generated at 2022-06-21 15:45:52.464664
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

if __name__ == '__main__':
    test_BaseProvider()

# Generated at 2022-06-21 15:45:53.786270
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='ru')) == "BaseDataProvider <ru>"

# Generated at 2022-06-21 15:45:56.310011
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    base = BaseProvider()
    assert base.seed is None
    base.reseed()
    assert base.seed is None
    new_seed = 2345123
    base.reseed(new_seed)
    assert base.seed == new_seed

# Generated at 2022-06-21 15:46:02.389653
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    # Проверка результата работы метода reseed
    provider = BaseProvider()
    def check_res(obj):
        return obj is not None

    assert check_res(provider.random) == True

    provider = BaseProvider('1')
    assert check_res(provider.random) == True

# Generated at 2022-06-21 15:46:04.363190
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:46:08.304279
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider.__doc__
    assert BaseProvider.__init__.__doc__

    bp = BaseProvider()
    assert bp
    assert bp.seed
    assert bp.random
    assert bp.random is not random
    assert bp.__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:46:13.465207
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test for constructor of class BaseProvider."""
    a = BaseProvider()
    b = BaseProvider(seed=3)
    assert isinstance(a, BaseProvider)
    assert isinstance(b, BaseProvider)
    assert a.random != b.random


# Generated at 2022-06-21 15:46:14.717168
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    BaseDataProvider()


# Generated at 2022-06-21 15:46:17.133490
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    class Test(BaseProvider):
        """Test class."""
        pass

    return Test()


# Generated at 2022-06-21 15:46:35.667458
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Numeric
    from mimesis.providers import UnitSystem
    assert 'BaseDataProvider' == BaseDataProvider.__name__
    us = UnitSystem()
    systype = us.measurement_system()
    n = Numeric()
    assert ' Imperial (UK)' in n.measurement_system()
    with us.override_locale('ru'):
        assert ' Метрическая' == n.measurement_system()
    assert ' Imperial (UK)' in n.measurement_system()

# Generated at 2022-06-21 15:46:39.248442
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    BaseDataProvider._setup_locale.cache_clear()
    BaseDataProvider()._pull.cache_clear()
    instance = BaseDataProvider('es')
    assert instance.get_current_locale() == 'es'


# Generated at 2022-06-21 15:46:42.526744
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    assert BaseDataProvider(locale='en')
    assert BaseDataProvider(seed=1234)
    assert BaseDataProvider(locale='en', seed=1234)

# Generated at 2022-06-21 15:46:51.686180
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test BaseProvider reseed"""
    import mimesis.enums

    print('test_BaseProvider_reseed')
    if mimesis.enums.Locale.EN not in mimesis.enums.Locale:
        raise AssertionError('Locale is not enum')
    if mimesis.enums.Locale.EN.value != 'en':
        raise AssertionError('Locale value is not en')
    if mimesis.enums.GrammaticalGender.MALE not in mimesis.enums.GrammaticalGender:
        raise AssertionError('GrammaticalGender is not enum')
    if mimesis.enums.GrammaticalGender.MALE.value != 'Male':
        raise AssertionError('GrammaticalGender value is not Male')

# Generated at 2022-06-21 15:46:58.709709
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Test with default locale
    provider = BaseDataProvider()
    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

    # Test with specific locale
    provider = BaseDataProvider(locale='fr')
    assert provider.get_current_locale() == 'fr'



# Generated at 2022-06-21 15:47:02.906115
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p1 = BaseProvider()
    p1.reseed(42)
    assert p1.random.getstate() == Random(seed=42).getstate()
    p1.reseed()
    p2 = BaseProvider()
    assert p1.random.getstate() != p2.random.getstate()

# Generated at 2022-06-21 15:47:05.334047
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider()
    curr_locale = dp.get_current_locale()
    assert curr_locale == locales.EN

# Generated at 2022-06-21 15:47:06.735251
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider
    base_data = base()
    assert (base_data)

# Generated at 2022-06-21 15:47:10.209414
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    data_provider = BaseDataProvider()
    assert 'BaseDataProvider <en>' == str(data_provider)

    data_provider._override_locale('ru')
    assert 'BaseDataProvider <ru>' == str(data_provider)

# Generated at 2022-06-21 15:47:14.417317
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider()
    assert data_provider
    assert data_provider.locale == locales.DEFAULT_LOCALE
    assert data_provider._datafile == ''
    assert data_provider.random
    assert data_provider.seed is None

# Generated at 2022-06-21 15:47:45.427897
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    from mimesis.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.person import Person

    person = Person()
    datetime = Datetime()

    n = person.full_name(gender=Gender.FEMALE)
    m = person.full_name(gender=Gender.FEMALE)
    date = datetime.datetime(timezone='UTC')

    person.reseed(12345)
    o = person.full_name(gender=Gender.FEMALE)
    f = datetime.datetime(timezone='UTC')

    assert n != m
    assert o == "Amanda Terry"
    assert date != f

    person.reseed(12346)
    o = person.full_name(gender=Gender.FEMALE)
    f = datetime.datetime

# Generated at 2022-06-21 15:47:47.713797
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()

    seed = b.seed
    print('seed = {0}'.format(seed))



# Generated at 2022-06-21 15:47:51.704471
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider._data == {}
    assert baseDataProvider._datafile == ''
    assert baseDataProvider.locale == 'en'
    assert baseDataProvider.random == random
    assert baseDataProvider.seed is None


# Generated at 2022-06-21 15:47:55.346894
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    random.seed(None)
    assert random.random() != random.random()
    provider = BaseProvider(seed=1)
    assert provider.random.random() == provider.random.random()

    provider.reseed()
    assert provider.random.random() != provider.random.random()


# Generated at 2022-06-21 15:47:58.863163
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseDataProvider(locale='ru')
    provider.__str__()
    # Test for BaseDataProvider._override_locale
    provider._override_locale(locale='ru')
    # Test for BaseDataProvider.override_locale
    provider.override_locale(locale='ru')

# Generated at 2022-06-21 15:48:01.304479
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""

    from test_providers import country_provider
    c = country_provider('en')
    print(c.get_current_locale())

# Generated at 2022-06-21 15:48:11.726777
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person()
    person2 = Person(seed=None)

    person.seed = 42
    person.reseed()
    person.seed = None
    person.reseed()

    assert person.seed is None
    assert person2.seed is not None
    assert person.seed != person2.seed

    person.seed = 42
    person.reseed()
    person.seed = None
    person.reseed()

    assert person.seed is None
    assert person2.seed is not None
    assert person.seed != person2.seed
    assert person.full_name() == 'Jorgé Martino'
    assert person.gender() == Gender.MALE

# Generated at 2022-06-21 15:48:13.854013
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():  # noqa: D103
    message = "Hello, {0}!".format(BaseDataProvider('ja'))
    assert message == 'Hello, BaseDataProvider <ja>!'

# Generated at 2022-06-21 15:48:16.723429
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # BaseProvider
    b = BaseProvider()
    old_seed = b.seed
    new_seed = 100
    b.reseed(new_seed)
    assert old_seed != b.seed
    assert b.seed == new_seed


# Generated at 2022-06-21 15:48:18.286498
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

# Generated at 2022-06-21 15:48:39.102930
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    result = BaseProvider()
    assert result.__str__()=='BaseProvider'


# Generated at 2022-06-21 15:48:43.897890
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    data_provider = BaseDataProvider()
    with data_provider.override_locale(locale='de') as dp:
        assert dp.get_current_locale == 'de'
    assert data_provider.get_current_locale == 'en'

# Generated at 2022-06-21 15:48:51.591599
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    baseDataProvider = BaseDataProvider()
    assert baseDataProvider.locale == 'en', \
    "Object doesn't have default locale."
    assert baseDataProvider.seed == None, \
    "Object doesn't have default value for seed."
    assert baseDataProvider.random == random, \
    "Object doesn't have default value for random."
    assert baseDataProvider._data == {}, \
    "Object doesn't have default value for _data."
    assert baseDataProvider._datafile == '', \
    "Object doesn't have default value for _datafile."
    assert baseDataProvider._data_dir == \
    Path(__file__).parent.parent.joinpath('data'), \
    "Object doesn't have default value for _data_dir."

    baseDataProvider = BaseDataProvider(locale = 'es', seed = 'seed')

# Generated at 2022-06-21 15:48:58.115572
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    from mimesis.providers.base import BaseDataProvider as Base

    b = Base()
    assert b.get_current_locale() == locales.DEFAULT_LOCALE

    b = Base('ru')
    assert b.get_current_locale() == 'ru'


# Generated at 2022-06-21 15:48:59.771243
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:49:03.910491
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.address import Address

    locale='es'
    with Address(locale=locale).override_locale(locale=locale) as provider:
        assert provider.get_current_locale() == locale

    with Address().override_locale(locale=locale) as provider:
        assert provider.get_current_locale() == locale

# Generated at 2022-06-21 15:49:09.236337
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    instantiated = BaseProvider()
    assert instantiated._seed is None
    assert instantiated._random is random
    instantiated.reseed(8356)
    assert instantiated._seed == 8356
    instantiated.reseed(None)
    assert instantiated._seed is not None
    assert instantiated._random is not random


# Generated at 2022-06-21 15:49:17.811813
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender
    from mimesis.personal import Personal

    class Person(Schema):
        """Person schema."""

        first_name = Field('first_name', formatter='title')
        last_name = Field('last_name', formatter='title')
        gender = Field('gender', g=Gender.FEMALE)
        age = Field('age')

    p = Person()
    assert p.get_current_locale() == 'en'

    s = Person(seed=1)
    assert s.get_current_locale() == 'en'
    assert s.get_current_locale() == 'en'

    r = Person(seed=19)
    r.first_name
    assert r.get_current_locale

# Generated at 2022-06-21 15:49:21.267051
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self):
            super().__init__(locale='de_DE')

    provider = TestBaseDataProvider()

    assert provider.get_current_locale() == 'de_DE'

    provider.reseed(None)
    provider.override_locale(locales.EN)
    assert provider.get_current_locale() == 'en_US'


# Generated at 2022-06-21 15:49:27.932416
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    #class BaseDataProvider:
    #    def _get_current_locale(self) -> str:
    #        """Get the current locale.

    base_data_provider = BaseDataProvider()
    assert base_data_provider.get_current_locale() == locales.DEFAULT_LOCALE

    base_data_provider.locale = 'ru'
    assert base_data_provider.get_current_locale() == 'ru'
    pass


# Generated at 2022-06-21 15:49:50.125576
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp is not None


# Generated at 2022-06-21 15:49:57.914118
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    # test with default argument
    bp = BaseProvider()
    bp.reseed()

    # test with a number as seed
    seed = 10
    bp = BaseProvider()
    bp.reseed(seed)

    # test with string as seed
    seed = 'hello world'
    bp = BaseProvider()
    bp.reseed(seed)

    # test with tuple as seed
    seed = (1, 2, 3, 4, 5)
    bp = BaseProvider()
    bp.reseed(seed)


# Generated at 2022-06-21 15:49:59.392675
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    dp = BaseDataProvider()
    assert dp.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:50:03.791543
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class CustomDataProvider(BaseDataProvider):
        pass
    provider = CustomDataProvider(locale='ru')
    assert provider.get_current_locale() == 'ru'
    provider.get_current_locale() == 'ru'



# Generated at 2022-06-21 15:50:08.232692
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    '''
    :return: Test result
    :rtype: bool
    '''
    provider = BaseDataProvider()
    message = '{} <{}>'.format(provider.__class__.__name__, locales.EN)
    return provider.__str__() == message

# Generated at 2022-06-21 15:50:13.991331
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(seed=123)
    seed_ = provider.random.seed()
    assert seed_ == 123
    provider.reseed(123)
    seed_ = provider.random.seed()
    assert seed_ == 123
    provider.reseed()
    seed_ = provider.random.seed()
    assert seed_ != 123


# Generated at 2022-06-21 15:50:15.134533
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'
    assert BaseProvider().__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:50:18.078923
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    '''
        Case 1:
            >>> provider = BaseDataProvider(locale='ru')
            >>> print(str(provider))
            BaseDataProvider <ru>
            >>> str(provider)
            'BaseDataProvider <ru>'
            >>> provider = BaseDataProvider(locale='en')
            >>> print(str(provider))
            BaseDataProvider <en>
            >>> str(provider)
            'BaseDataProvider <en>'
    '''

# Generated at 2022-06-21 15:50:20.256237
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """Test BaseDataProvider.__str__()."""
    provider = BaseDataProvider()
    assert str(provider) == "BaseDataProvider <en>"

# Generated at 2022-06-21 15:50:32.353008
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locale=locales.EN, seed=None):
            super().__init__(locale=locale, seed=seed)
            self.data = {
                'a': 1,
                'b': 2,
            }

        @property
        def a(self):
            return self.data['a']

        @property
        def b(self):
            return self.data['b']

    tdp = TestDataProvider()
    assert tdp.a == 1
    assert tdp.b == 2
    with tdp.override_locale(locales.RU):
        tdp.data = {
            'a': 'а',
            'b': 'б',
        }
        assert tdp.a == 'а'

# Generated at 2022-06-21 15:51:00.866824
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    def func1():
        print(random())

    def func2():
        print(random())

    a = BaseProvider()
    assert a.reseed() is None
    assert a.reseed() is None
    assert a.random is not random
    assert func1() is None
    assert func2() is None

    b = BaseProvider(a.seed)
    assert b.random is random
    assert func1() is None
    assert func2() is None



# Generated at 2022-06-21 15:51:06.395707
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        class Meta:
            locales = ('ru', 'en')

    data = TestDataProvider()
    with data.override_locale('ru'):
        assert data.get_current_locale() == 'ru'
    with data.override_locale('en'):
        assert data.get_current_locale() == 'en'

    with data.override_locale():
        assert data.get_current_locale() == 'en'
    locale = getattr(data, 'locale', locales.DEFAULT_LOCALE)
    assert locale == 'en'



# Generated at 2022-06-21 15:51:09.928072
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1
    random.seed(seed)
    test_integer = random.randint()
    bp = BaseProvider(seed)
    test_integer_bp = bp.random.randint()
    assert test_integer_bp == test_integer

if __name__ == "__main__":
    test_BaseProvider_reseed()

# Generated at 2022-06-21 15:51:18.741165
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Check overriding locale of provider."""
    provider = BaseDataProvider(locale=locales.RU)
    assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.EN) as en:
        assert en.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.RU

    with provider.override_locale(locales.EN) as en:
        assert en.get_current_locale() == locales.EN

    with provider.override_locale(locales.RU):
        assert provider.get_current_locale() == locales.RU

    assert provider.get_current_locale() == locales.RU


# Generated at 2022-06-21 15:51:24.334033
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    assert BaseProvider().__class__ == BaseProvider
    # Assert Random is the default random generator
    assert BaseProvider().random is random
    assert BaseProvider(seed=42).seed is not None
    assert BaseProvider().seed is None
    assert BaseProvider(seed=42).seed == 42
    assert BaseProvider(seed=None).seed is None
    assert BaseProvider().random() != BaseProvider(seed=42).random()


# Generated at 2022-06-21 15:51:26.376531
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert BaseProvider().random.seed == None
    assert BaseProvider(seed=300).random.seed == 300
    assert BaseProvider(seed=300).random.seed == 300


# Generated at 2022-06-21 15:51:30.841367
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    random_seed = random.seed
    random_seed(provider.seed)
    provider.reseed()
    assert provider.random.seed is not random.seed
    provider.reseed(None)
    assert provider.seed is not None
    provider = BaseProvider(seed=1001)
    provider.reseed()
    assert provider.random.seed is not random.seed
    assert provider.seed is not None


# Generated at 2022-06-21 15:51:35.507967
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider """
    provider1 = BaseDataProvider(locale='zh_CN')
    provider2 = BaseDataProvider()
    assert isinstance(provider1, BaseDataProvider)
    assert provider1.get_current_locale() == 'zh_CN'
    assert provider2.get_current_locale() == 'en'


# Generated at 2022-06-21 15:51:44.106706
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # test implementation of BaseDataProvider class
    # BaseDataProvider constructor
    provider = BaseDataProvider()
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed is None
    assert provider._data == {}
    assert provider._datafile == ''

    provider = BaseDataProvider(locale = 'ru')
    assert provider.locale == "ru"
    assert provider.seed is None
    assert provider._data == {}
    assert provider._datafile == ''

    provider = BaseDataProvider(seed = 'seed')
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider.seed == "seed"
    assert provider._data == {}
    assert provider._datafile == ''


# Generated at 2022-06-21 15:51:45.839577
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=1)
    assert provider.seed == 1
    provider2 = BaseProvider()
    assert provider2.seed != provider.seed



# Generated at 2022-06-21 15:52:21.899627
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'



# Generated at 2022-06-21 15:52:26.718447
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('en')
    p.gender = p._validate_enum(Gender.MALE, Gender)
    assert p.gender == 'male'
    with p.override_locale('ru'):
        assert p.gender == 'мужчина'

# Generated at 2022-06-21 15:52:27.908151
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:52:29.490226
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    assert str(obj) == 'BaseProvider'



# Generated at 2022-06-21 15:52:31.503709
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base = BaseDataProvider()
    assert base.locale == locales.DEFAULT_LOCALE
    assert isinstance(base._data, Mapping) == True

# Generated at 2022-06-21 15:52:37.395621
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class DummyProvider(BaseDataProvider):
        def __init__(self, locale):
            self.locale = locale

    provider = DummyProvider('en_US')
    provider_en = None
    provider_ru = None

    # test with overridden locale
    with provider.override_locale('en') as p:
        provider_en = p

    assert provider_en.locale == 'en'

    # test with overridden locale
    with provider.override_locale('ru') as p:
        provider_ru = p

    assert provider_ru.locale == 'ru'

# Generated at 2022-06-21 15:52:40.726038
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # BaseProvider.__init__()
    bp = BaseProvider()
    assert bp.__str__() == 'BaseProvider'

    # BaseProvider.__str__()
    assert str(bp) == 'BaseProvider'

# Generated at 2022-06-21 15:52:47.260655
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None) -> None:
            super().__init__(locale=locale, seed=seed)

    provider = TestProvider()

    with provider.override_locale(locales.EN) as p:
        assert p.get_current_locale() == locales.EN

    assert provider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:52:49.514085
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    print(bp)


# Generated at 2022-06-21 15:52:52.835827
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider()
    assert provider.seed is None
    provider.reseed(123)
    assert provider.seed == 123
    assert isinstance(provider.random, Random)
    provider.reseed(321)
    assert provider.seed == 321


# Generated at 2022-06-21 15:53:14.670155
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    prov = BaseDataProvider()
    assert prov.get_current_locale() == locales.EN
    assert prov.locale == 'en'
    prov._pull.cache_clear()
    assert prov._pull(locales.DEFAULT_LOCALE) == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:53:21.704785
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Unit test for method get_current_locale() of class BaseDataProvider
    class FakeProvider(BaseDataProvider):
        pass
    # Case 1. No locale
    fp = FakeProvider()
    assert fp.get_current_locale() == locales.DEFAULT_LOCALE
    # Case 2. With locale
    fp = FakeProvider(locale=locales.RU)
    assert fp.get_current_locale() == locales.RU

# Generated at 2022-06-21 15:53:24.282448
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider().get_current_locale() == locales.DEFAULT_LOCALE
    assert BaseDataProvider(locale=locales.ES).get_current_locale() == locales.ES

# Generated at 2022-06-21 15:53:26.500027
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test BaseDataProvider"""
    provider = BaseDataProvider(locale='en')
    assert provider.locale == 'en'


# Generated at 2022-06-21 15:53:30.911448
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    with open(r'data/en/address.json') as f:
        json_data = json.loads(f.read())
    address = BaseDataProvider()
    assert address._datafile == 'address.json'
    assert address._data_dir == Path(__file__).parent.parent.joinpath('data')
    assert address._data == json_data
    assert address.locale == 'en'
    assert address._data_dir == Path(__file__).parent.parent.joinpath('data')

# Generated at 2022-06-21 15:53:34.179398
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class DPMock(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE, seed = None):
            self.locale = locale
    dp = DPMock()
    assert dp.get_current_locale() == locales.EN

# Generated at 2022-06-21 15:53:37.523464
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Testing method for constructor of class BaseDateProvider"""
    from mimesis.builtins import Transport

    instance = Transport()
    assert instance.locale == locales.EN

    instance = Transport(locale='ru')
    assert instance.locale == 'ru'

    instance = Transport(locale='en_US')
    assert instance.locale == 'en_us'

# Generated at 2022-06-21 15:53:39.643740
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Unit test for method __str__ of class BaseProvider."""
    provider = BaseProvider(seed=123)
    assert str(provider) == "BaseProvider"
    assert provider.__str__() == "BaseProvider"


# Generated at 2022-06-21 15:53:41.187330
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == 'en'
    return bdp

bdp = test_BaseDataProvider()
print(bdp)

# Generated at 2022-06-21 15:53:42.919384
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    baseDataProvider = BaseDataProvider()
    baseDataProvider._setup_locale()
    assert baseDataProvider.get_current_locale() == locales.DEFAULT_LOCALE

# Generated at 2022-06-21 15:54:28.722852
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test override_locale method."""
    from mimesis.builtins import Language

    language = Language()
    language.override_locale('ru')
    assert language.get_current_locale() == 'ru'

    origin_locale = language.get_current_locale()
    with language.override_locale('en'):
        assert language.get_current_locale() == 'en'

    assert language.get_current_locale() == origin_locale

# Generated at 2022-06-21 15:54:31.642913
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider('ru', 42)
    assert p.locale == 'ru'
    assert p.random is not random
    assert p.seed == 42


# Generated at 2022-06-21 15:54:33.564811
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # assert BaseDataProvider().get_current_locale() == getattr(self, 'locale', locales.DEFAULT_LOCALE)
    pass

# Generated at 2022-06-21 15:54:36.947920
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Create instance of class BaseDataProvider
    bdp = BaseDataProvider()
    # Execute the method get_current_locale of class BaseDataProvider
    # and get result
    result = bdp.get_current_locale()
    # Check the result
    assert result == locales.EN


# Generated at 2022-06-21 15:54:39.836969
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Test(BaseDataProvider): pass
    provider = Test()
    with provider.override_locale('ru') as p:
        assert p.locale == 'ru'

# Generated at 2022-06-21 15:54:42.294136
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    bdp = BaseDataProvider()
    ans = bdp.__str__()
    assert ans == 'BaseProvider <en>'


# Generated at 2022-06-21 15:54:51.279562
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    from mimesis.locales import en, ru

    p1 = Person(en)
    p2 = Person(locale=ru)

    assert p1.get_current_locale() == en
    assert p2.get_current_locale() == ru

    a1 = Address(en)
    a2 = Address(locale=ru)

    assert a1.get_current_locale() == en
    assert a2.get_current_locale() == ru

    assert p1.get_full_name(gender=Gender.FEMALE) == 'Amanda Wilson'

# Generated at 2022-06-21 15:54:53.157599
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider"""
    provider = BaseProvider()
    assert provider.__str__() == 'BaseProvider'



# Generated at 2022-06-21 15:54:54.639151
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    provider = BaseProvider(5)
    assert provider.seed == 5
    assert provider.random is not random


# Generated at 2022-06-21 15:54:55.598012
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    o = BaseProvider()
    o.reseed()