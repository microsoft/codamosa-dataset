

# Generated at 2022-06-21 15:45:54.148327
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()

    assert provider.seed is None
    assert provider.random == random
    assert provider.locale == locales.DEFAULT_LOCALE
    assert provider._data == {}
    assert provider._datafile == ''
    assert provider._data_dir.exists()

    provider_with_seed = BaseDataProvider(seed=123)

    assert provider_with_seed.random._seed == 123
    assert provider_with_seed.seed == 123

    with provider.override_locale():
        assert provider.locale == locales.DEFAULT_LOCALE

    provider.reseed(123)

    assert provider.random._seed == 123
    assert provider.seed == 123

    provider.locale = 'en'

    assert provider._data == {}
    assert provider._datafile == ''


# Generated at 2022-06-21 15:45:55.554333
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    print(BaseProvider())
    print(BaseProvider(seed=42))

# Generated at 2022-06-21 15:46:03.336878
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.schema import Fields

    class TestProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.field = Fields(seed=self.seed)

    provider = TestProvider(locale='ru')
    with provider.override_locale('en'):
        assert provider.field.name() == 'Brock'
    with provider.override_locale('ru'):
        assert provider.field.name() == 'Николай'



# Generated at 2022-06-21 15:46:05.321966
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    locale = provider.get_current_locale()
    assert locale == 'en'


# Generated at 2022-06-21 15:46:15.467218
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    from mimesis.CustomDataProvider import DataProvider as CustomDataProvider
    from mimesis.builtins import Person
    import time
    seed = '1'
    provider = CustomDataProvider(seed=seed)
    result1 = [provider() for _ in range(0,10)]
    time.sleep(1)
    result2 = [provider() for _ in range(0,10)]
    assert(result1 == result2)
    newseed = '2'
    provider.reseed(newseed)
    result3 = [provider() for _ in range(0,10)]
    assert(result1 == result2)
    assert(result1 != result3)

# Generated at 2022-06-21 15:46:20.107773
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # # Test without parameters.
    # provider = BaseDataProvider()
    # assert provider.get_current_locale() == 'en'

    # Test with parameters.
    provider = BaseDataProvider(locale='en')
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:46:21.244250
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Test 'test_BaseDataProvider'."""
    BaseDataProvider('en')

# Generated at 2022-06-21 15:46:23.284820
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp = BaseProvider(seed=None)
    assert bp.random.get_seed()==bp.seed

# Generated at 2022-06-21 15:46:29.202238
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    A = BaseProvider()
    B = BaseProvider()
    assert A.seed == None
    assert B.seed == None
    A.reseed(10)
    assert A.random == A._random

test_BaseProvider_reseed()


# Generated at 2022-06-21 15:46:35.622133
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Provider(BaseDataProvider):
        def __init__(self, locale, seed=None):
            super().__init__(locale=locale, seed=seed)

        def something(self):
            return self.locale

    provider = Provider('ru')

    with provider.override_locale('it'):
        locale = provider.something()

    assert locale == 'it'
    assert provider.something() == 'ru'

# Generated at 2022-06-21 15:46:46.696176
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # When using BaseProvider, it should return the class name
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'


# Generated at 2022-06-21 15:46:49.074509
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """This is a unit test for method reseed of class BaseProvider."""
    provider = BaseProvider()
    result = provider.reseed()
    assert provider.seed == result


# Generated at 2022-06-21 15:46:51.022886
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Person
    p: BaseDataProvider = Person()
    assert p.__str__() == "Person <en>"


# Generated at 2022-06-21 15:46:53.684840
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    t = BaseProvider()
    assert str(t) == "BaseProvider"

# Generated at 2022-06-21 15:47:00.545978
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '9d5e5e5d5e5c5e5e5e5d5e5e5e5c5e5e5e5d5e5e5e5c5e5e5e5'
    provider = BaseProvider(seed=seed)
    assert provider.seed == seed, "Fails BaseProvider method test_reseed"



# Generated at 2022-06-21 15:47:04.656989
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test constructor of class BaseProvider."""
    # test default constructor
    foo = BaseProvider()
    assert foo
    assert isinstance(foo, BaseProvider)

    # test constructor with seed
    foo = BaseProvider(seed='foo_bar')
    assert foo
    assert isinstance(foo, BaseProvider)
    assert foo.seed == 'foo_bar'



# Generated at 2022-06-21 15:47:09.426490
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class Foo(BaseDataProvider):
        pass

    foo = Foo()
    foo._override_locale('en')
    assert foo.get_current_locale() == 'en'

    with foo.override_locale('ru'):
        assert foo.get_current_locale() == 'ru'

    assert foo.get_current_locale() == 'en'

    foo2 = Foo('ru')
    assert foo2.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:47:11.353945
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    """
    Unit test for method __str__ of class BaseDataProvider.

    .. todo:: write unit test.
    """
    pass

# Generated at 2022-06-21 15:47:14.892394
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = 1111
    p1 = BaseProvider(seed)
    p2 = BaseProvider(seed)
    assert p1.random.randint(1, 100) == p2.random.randint(1, 100)



# Generated at 2022-06-21 15:47:22.684100
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import os
    class MyProvider(BaseDataProvider):
        _datafile = 'test.json'
        def get_name(self)->str:
            return self._data['name']
        def get_value(self)->str:
            return self._data['value']

    provider = MyProvider('ru')
    assert provider.get_name() == 'Вася'
    assert provider.get_value() == 'Значение'

    with provider.override_locale('en'):
        assert provider.get_name() == 'Vasya'
        assert provider.get_value() == 'Value'

    assert provider.get_name() == 'Вася'
    assert provider.get_value() == 'Значение'

    # with

# Generated at 2022-06-21 15:47:43.844834
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from .person import Person
    person = Person()
    assert str(person) == 'Person <en>'
    from .address import Address
    address = Address()
    assert str(address) == 'Address <en>'
    from mimesis import Food
    food = Food()
    assert str(food) == 'Food <en>'
    from mimesis import Currency
    currency = Currency()
    assert str(currency) == 'Currency <en>'
    from mimesis import Code
    code = Code()
    assert str(code) == 'Code <en>'
    from mimesis import Datetime
    datetime = Datetime()
    assert str(datetime) == 'Datetime <en>'
    from mimesis import Person as BuiltinPerson
    builtin_person = BuiltinPerson()

# Generated at 2022-06-21 15:47:45.836622
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    a = BaseProvider()
    b = str(a)
    assert b == 'BaseProvider'


# Generated at 2022-06-21 15:47:49.025277
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    assert b.random is random
    assert b.seed is None
    b.reseed(0)
    assert b.random is not random
    assert b.seed == 0

# Generated at 2022-06-21 15:47:52.310363
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'
    provider = BaseDataProvider(locale='es')
    assert provider.__str__() == 'BaseDataProvider <es>'


# Generated at 2022-06-21 15:47:56.976415
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    class Test(BaseDataProvider):
        """Test class."""

        def get_current_locale(self) -> str:
            """Get current locale.

            :return: Current locale.
            """
            return self.locale

    test = Test()
    # test unspecific locale
    with test.override_locale() as t:
        assert t.get_current_locale() == locales.EN
    assert test.get_current_locale() != locales.EN
    # test specific locale
    with test.override_locale(locales.EN_DASH) as t:
        assert t.get_current_locale() == locales.EN_DASH
    assert test.get_current_locale() == locales.DE

# Generated at 2022-06-21 15:47:58.690590
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    with contextlib.suppress(UnsupportedLocale):
        BaseProvider(seed=None)


# Generated at 2022-06-21 15:48:02.524518
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Check the return value when locale is defined
    p = BaseDataProvider(locale=locales.EN)
    assert p.get_current_locale() == locales.EN

    # Check the return value when locale is not defined
    p = BaseDataProvider()
    assert p.get_current_locale() == locales.DEFAULT_LOCALE


test_BaseDataProvider_get_current_locale()

# Generated at 2022-06-21 15:48:06.711537
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    with BaseDataProvider(locale='en-US').override_locale() as pr:
        assert pr._pull.cache_info().hits == 0
        assert pr._data
        

# Generated at 2022-06-21 15:48:11.260994
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Get a string representation of the locale."""
    locale = 'de'
    seed = 1234
    provider = BaseDataProvider(locale, seed)

    assert getattr(provider, 'locale', locales.DEFAULT_LOCALE) == locale
    assert provider.seed == seed
    assert str(provider) == 'BaseDataProvider <de>'



# Generated at 2022-06-21 15:48:12.464423
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert BaseProvider().__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:48:29.046257
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')

    with p.override_locale('en') as en:
        assert en.gender(Gender.MALE) == 'Male'

    assert isinstance(p.gender(Gender.MALE), str)


if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-21 15:48:37.948277
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    import unittest
    import unittest.mock
    from mimesis.providers.base import BaseProvider
    from mimesis.typing import Seed

    class TestBaseProvider(unittest.TestCase):

        def setUp(self) -> None:
            seed = Seed(42)
            self.provider = BaseProvider(seed=seed)

        def test_initialization(self) -> None:
            self.assertTrue(hasattr(self.provider, 'random'))
            self.assertTrue(hasattr(self.provider, 'seed'))

        def test_init_seed(self) -> None:
            seed = Seed(42)
            provider = BaseProvider(seed=seed)

            self.assertTrue(hasattr(provider, 'seed'))

# Generated at 2022-06-21 15:48:40.404680
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    obj = BaseProvider()
    obj_str = str(obj)
    assert obj_str == "BaseProvider"
    return


# Generated at 2022-06-21 15:48:50.057514
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test class BaseProvider."""
    from mimesis.builtins import Person
    import mimesis.enums
    p = Person('en')
    with p.override_locale('de'):
        assert p.gender() == mimesis.enums.Gender.MALE

    # class Person(BaseDataProvider):
    #     data_file = 'person.json'
    #     data = {}
    #
    #     def __init__(self, locale: str = locales.EN, seed: Seed = None) -> None:
    #         """Initialize attributes.
    #
    #         :param locale: The locale to use.
    #         :param seed: Seed.
    #         """
    #         super().__init__(locale=locale, seed=seed)
    #         self.load_

# Generated at 2022-06-21 15:48:56.043953
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed='2019')
    assert isinstance(provider, BaseProvider)
    assert provider.seed == '2019'
    assert isinstance(provider.random, Random)
    
    provider.reseed('2020')
    assert provider.seed == '2020'
    assert isinstance(provider.random, Random)


# Generated at 2022-06-21 15:48:57.188666
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    result = BaseProvider().__str__()
    assert result == "BaseProvider"


# Generated at 2022-06-21 15:48:58.808182
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider()
    assert (bp.__str__() == "BaseProvider")


# Generated at 2022-06-21 15:49:00.556789
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test BaseProvider.__str__."""
    assert str(BaseProvider()) == 'BaseProvider'



# Generated at 2022-06-21 15:49:03.398940
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    class Sub_BaseProvider(BaseProvider):
        def __init__(self):
            super().__init__()
    sub_BaseProvider=Sub_BaseProvider()
    assert str(sub_BaseProvider) == 'Sub_BaseProvider'


# Generated at 2022-06-21 15:49:08.445043
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def __init__(self):
            self.locale = 'en'
        def get_data(self, key: str = None, locale: str = None) -> Any:
            if locale is None:
                locale = self.locale
            key = str(key)
            return '{}:{}'.format(locale, key)
    provider = TestProvider()
    assert provider.get_data('foo') == 'en:foo'
    with provider.override_locale('ru'):
        assert provider.get_data('foo') == 'ru:foo'
    assert provider.get_data('foo') == 'en:foo'

# Generated at 2022-06-21 15:49:32.238857
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    assert provider.get_current_locale() == 'en'

    with provider.override_locale('fr'):
        assert provider.get_current_locale() == 'fr'

    assert provider.get_current_locale() == 'en'

if __name__ == '__main__':
    test_BaseDataProvider_override_locale()

# Generated at 2022-06-21 15:49:43.364019
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.geography import Geography
    #: Create instance of 'mimesis.providers.geography.Geography'
    geography = Geography()
    #: Create instance of 'mimesis.providers.geography.Geography'
    geography_uk = Geography(locale='uk')
    #: Create instance of 'mimesis.providers.geography.Geography'
    geography_ru = Geography(locale='ru')
    #: Override the current locale with 'uk'
    with geography.override_locale(locale='uk') as geo:
        assert geo.get_current_locale() == 'uk'
        assert geography.get_current_locale() == locales.DEFAULT_LOCALE
        assert geography_ru.get_current_locale() == 'ru'

# Generated at 2022-06-21 15:49:45.560044
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    r = BaseProvider()
    assert str(r) == 'BaseProvider'

if __name__ == '__main__':
    test_BaseProvider___str__()

# Generated at 2022-06-21 15:49:47.761275
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    assert hasattr(BaseProvider, 'reseed')
    assert callable(BaseProvider.reseed)


# Generated at 2022-06-21 15:49:51.827490
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.EN
    dp = BaseDataProvider(locale) 
    assert dp.__str__() == 'BaseDataProvider <en>' # 'BaseDataProvider' is name of class.

# Generated at 2022-06-21 15:49:54.267107
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    # call constructor with no seed
    assert b.seed is None
    assert b.random is random


# Generated at 2022-06-21 15:50:02.188688
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
	"""Test __str__ method"""
	data = BaseDataProvider()
	assert 'en' == data.__str__()
	data2 = BaseDataProvider(locale='ru')
	assert 'ru' == data2.__str__()
	data3 = BaseDataProvider(locale='es')
	assert 'es' == data3.__str__()
	data4 = BaseDataProvider(locale='de')
	assert 'de' == data4.__str__()
	data5 = BaseDataProvider(locale='fr')
	assert 'fr' == data5.__str__()
	data6 = BaseDataProvider(locale='pt')
	assert 'pt' == data6.__str__()
	data7 = BaseDataProvider(locale='it')
	assert 'it' == data7.__str__()
	

# Generated at 2022-06-21 15:50:03.699108
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    s='BaseProvider'
    assert s == BaseProvider().__str__()

# Generated at 2022-06-21 15:50:06.777177
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    loc = locales.EN
    prov = BaseDataProvider(loc)
    res = prov.get_current_locale()
    assert loc == res


# Generated at 2022-06-21 15:50:10.813110
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    obj = BaseDataProvider(locale = 'en-us', seed = 10)
    assert obj.seed == 10
    with obj.override_locale(locale = 'en-us'):
        assert obj.locale == 'en-us'


# Generated at 2022-06-21 15:50:37.890044
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Test for BaseProvider Class."""
    # Test if BaseProvider has method __str__
    assert hasattr(BaseProvider, "__str__")
    # Test if BaseProvider method __str__ is callable
    assert callable(getattr(BaseProvider, "__str__", None))
    # Test if method __str__ returns a string
    assert isinstance(BaseProvider().__str__(), str)
    # Test __str__ if no arguments are passed to it
    assert BaseProvider().__str__() == "BaseProvider"


# Generated at 2022-06-21 15:50:48.455105
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    #test_seed = 'c1d8a40a-dbb2-4d2e-94cd-a6e651844864'
    test_seed = 'seed_test'
    seed = test_seed
    #locale = locales.DEFAULT_LOCALE
    locale = locales.EN
    test_data_file = 'test.json'

    provider = BaseDataProvider(locale=locale, seed=seed)
    assert provider.seed == seed

    provider = BaseDataProvider(locale=locale)
    assert provider.seed is None

    provider = BaseDataProvider(seed=seed)
    assert provider.seed == seed
    assert provider.locale == locales.DEFAULT_LOCALE

    provider = BaseDataProvider()
    assert provider.seed is None

# Generated at 2022-06-21 15:50:58.519570
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    from mimesis.builtins import MetaDataProvider as builtin
    from mimesis.builtins.en import MetaDataProvider as english
    from mimesis.builtins.ru import MetaDataProvider as russian

    provider = BaseDataProvider()
    assert isinstance(provider, builtin)
    assert isinstance(provider, BaseDataProvider)
    assert hasattr(provider, '_data')
    assert isinstance(provider._data, dict)
    assert hasattr(provider, '_datafile')
    assert isinstance(provider._datafile, str)
    assert hasattr(provider, '_data_dir')
    assert isinstance(provider._data_dir, Path)
    assert hasattr(provider, 'locale')
    assert isinstance(provider.locale, str)

# Generated at 2022-06-21 15:51:00.018504
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider('LOCALE')
    assert b.seed is None


# Generated at 2022-06-21 15:51:00.831711
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider()
    assert provider.random != None

# Generated at 2022-06-21 15:51:02.153616
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    t = BaseDataProvider()
    assert t.__str__() == 'BaseDataProvider <en>'


# Generated at 2022-06-21 15:51:03.722670
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    bp = BaseProvider(seed=None)
    assert bp.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:51:04.827416
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    x = BaseProvider()

    assert x is not None


# Generated at 2022-06-21 15:51:07.399564
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider()) == 'BaseDataProvider <en>'
    assert str(BaseDataProvider(locale='ru')) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:51:08.611045
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Person
    assert str(Person()) == "Person <en>"


# Generated at 2022-06-21 15:51:57.130596
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    import pytest

    test_cases = [
        ('en', ('en', 'en')),
        ('en_US', ('en', 'en')),
        ('en_US_POSIX', ('en', 'en')),
        ('zh_CN', ('zh', 'zh')),
        ('zh_Hans', ('zh', 'zh')),
        ('zh_Hans_CN', ('zh', 'zh')),
    ]

    for case in test_cases:
        provider = BaseDataProvider(locale=case[0])
        assert provider.get_current_locale() == case[1][0]
        assert str(provider) == case[1][1]


# Generated at 2022-06-21 15:52:11.027129
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider(seed='123')

    assert str(provider) == 'BaseProvider'



# Generated at 2022-06-21 15:52:11.814126
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider()
    print(b.random)



# Generated at 2022-06-21 15:52:14.005894
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    base_data_provider = BaseDataProvider()
    assert base_data_provider._data == {}
    assert base_data_provider._datafile == ''


# Generated at 2022-06-21 15:52:20.191305
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    # print(BaseDataProvider)

    # import timeit
    # print(timeit.timeit("BaseDataProvider(seed=123456789)"))

    provider = BaseDataProvider(seed=123456789)
    # print(provider.seed)
    # print(provider.random)

    provider = BaseDataProvider(seed=123456789)
    # print(provider.seed)
    # print(provider.random)

    # print(provider.reseed)



# Generated at 2022-06-21 15:52:22.949278
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    current_locale = BaseDataProvider(locale='de').get_current_locale()
    assert current_locale == 'de'


# Generated at 2022-06-21 15:52:32.182156
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    with Person(locale='ru') as person_ru:
        with person_ru.override_locale(locale='en') as person_en:
            assert person_en.get_current_locale() is locales.EN
            assert person_en.name(gender=Gender.MALE) != person_en.name(gender=Gender.FEMALE)

        with person_ru.override_locale(locale='cs') as person_cs:
            assert person_cs.get_current_locale() is locales.CS

        assert person_ru.get_current_locale() is locales.RU
        assert person_ru.name

# Generated at 2022-06-21 15:52:36.156765
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.base import BaseDataProvider
    provider = BaseProvider()
    assert str(provider) == 'BaseProvider'

    provider_ = BaseDataProvider()
    assert str(provider_) == 'BaseDataProvider <en>'

    provider__ = BaseDataProvider(locale='ru')
    assert str(provider__) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:52:37.382819
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():

    x = BaseDataProvider()
    assert str(x) == 'en'



# Generated at 2022-06-21 15:52:39.113724
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis import Person
    assert str(Person()) == 'Person <en>'


# Generated at 2022-06-21 15:54:03.693189
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class TestBaseDataProvider(BaseDataProvider):
        def _setup_locale(self, locale: str = locales.DEFAULT_LOCALE) -> None:
            self.locale = locale
    a = TestBaseDataProvider()
    assert str(a) == 'TestBaseDataProvider <en>'


# Generated at 2022-06-21 15:54:07.971139
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test reseed method."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Person as PersonEn
    from mimesis.providers.person.ru import Person as PersonRu

    seed = 1234567

    dt = Datetime(seed=seed)
    misc = Misc(seed=seed)
    numbers = Numbers(seed=seed)
    person = Person()

    dt.reseed(seed)
    dt.reseed(seed)
    misc.reseed(seed)
    misc.reseed(seed)
    numbers.reseed(seed)

# Generated at 2022-06-21 15:54:10.541177
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    bp1 = BaseProvider()
    bp2 = BaseProvider()
    bp1.reseed(1)
    bp2.reseed(1)
    assert bp1.random != random
    assert bp1.random == bp2.random


# Generated at 2022-06-21 15:54:12.851628
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.providers.datetime import Datetime
    provider = Datetime(seed=42)

    assert str(provider) == 'Datetime <en>'

# Generated at 2022-06-21 15:54:14.802390
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    p = BaseDataProvider()
    print(p)


# Generated at 2022-06-21 15:54:23.754323
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.builtins import Card, Person, Address
    from mimesis.enums import Gender, CardType

    p = Person()
    c = Card()
    a = Address()

    # Builtins providers
    with p.override_locale('ru') as p_ru:
        assert p_ru.locale == 'ru'

        with p.override_locale('en') as p_en:
            assert p_en.locale == 'en'

            with c.override_locale('en') as c_en:
                assert c_en.locale == 'en'

                with c.override_locale('ru') as c_ru:
                    assert c_ru.locale == 'ru'

                    with a.override_locale('ru') as a_ru:
                        assert a_

# Generated at 2022-06-21 15:54:26.664911
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    # Define a new provider and run __str__, check if it is equal to class name
    # and if it is a string
    from mimesis.providers import Address
    provider = Address(locale='en')
    assert provider.__str__() == 'Address'
    assert type(provider.__str__()) is str



# Generated at 2022-06-21 15:54:28.576134
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    assert provider.__str__() == "BaseProvider"


# Generated at 2022-06-21 15:54:29.843834
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider = BaseProvider(seed=1)
    assert provider



# Generated at 2022-06-21 15:54:32.076211
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    p = BaseProvider()
    p.reseed(1)
    assert p.random is not random
