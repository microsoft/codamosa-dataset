

# Generated at 2022-06-21 15:45:54.434436
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Unit test for BaseProvider reseed method."""
    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider
    p1 = Person('en')
    p2 = Person('en')
    p3 = Person('en')
    assert p1.full_name() == p2.full_name()
    assert p1.full_name() == p3.full_name()

    p1.reseed()
    assert p1.full_name() == p2.full_name()

    adr = RussiaSpecProvider('en')
    adr_random = adr.random
    adr.reseed()
    assert adr.random is not adr_random

# Generated at 2022-06-21 15:45:55.728148
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p = BaseProvider(seed=42)
    assert p.seed == 42

# Generated at 2022-06-21 15:45:59.105558
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    """Testing method __str__ of class BaseProvider."""
    from mimesis.builtins import Person
    provider = Person()
    assert provider.__str__() == 'Person'



# Generated at 2022-06-21 15:46:00.902648
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    obj = BaseDataProvider()
    assert obj.__str__()=='BaseDataProvider <en>'


# Generated at 2022-06-21 15:46:02.937318
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Test a constructor of BaseProvider."""
    from test_constructors import test_BaseDataProvider
    test_BaseDataProvider()


# Generated at 2022-06-21 15:46:04.280155
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert a


# Generated at 2022-06-21 15:46:05.988631
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    """Unit test for constructor of class BaseDataProvider."""
    instance = BaseDataProvider()
    assert instance


# Generated at 2022-06-21 15:46:10.982917
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.enums import Gender
    from mimesis.providers.personal.us import USPerson

    p = USPerson()
    assert str(p) == 'USPerson'

    p.sex(Gender.FEMALE)
    assert str(p) == 'USPerson'

    assert str(USPerson(seed=None)) == 'USPerson'

# Generated at 2022-06-21 15:46:13.662538
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    local=BaseProvider()
    assert local.__str__() == 'BaseProvider'
    

# Generated at 2022-06-21 15:46:19.452352
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Dummy(BaseDataProvider):
        def _pull(self):
            self._data = {}

    obj = Dummy()
    assert str(obj) == 'Dummy <en>'

    obj.locale = 'ru'
    assert str(obj) == 'Dummy <ru>'


# Unit tests for method _update_dict of class BaseDataProvider

# Generated at 2022-06-21 15:46:31.299919
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    assert provider.get_current_locale() == 'en'

# Generated at 2022-06-21 15:46:34.775598
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Foo(BaseDataProvider):
        pass

    foo = Foo(locale='en')

    with foo.override_locale('ru') as _:
        pass

    assert getattr(foo, 'locale') == 'en'

# Generated at 2022-06-21 15:46:36.508751
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    result = BaseDataProvider().get_current_locale()
    assert result == 'en'


# Generated at 2022-06-21 15:46:38.309026
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    provider_two = BaseDataProvider('es')


# Generated at 2022-06-21 15:46:49.243342
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    """Unit test for constructor of class BaseProvider."""
    provider = BaseProvider(seed=100)
    # __init__
    assert isinstance(provider.seed, int)
    assert isinstance(provider.seed, Seed)
    assert provider.seed == 100
    assert provider.random != random
    assert isinstance(provider.random, Random)
    assert provider.random.seed(100) is None

    # reseed
    provider.reseed(seed=101)
    assert provider.seed == 101
    provider.reseed()
    assert provider.seed != 101

    # _validate_enum
    enum = None
    assert provider._validate_enum(item=1, enum=2) == 2
    assert provider._validate_enum(item=enum, enum=enum) == enum

# Generated at 2022-06-21 15:46:49.726982
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()

# Generated at 2022-06-21 15:46:52.839753
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers._datetime import DateTime
    actual = str(DateTime(seed=10))
    assert actual == 'DateTime <en>'


# Generated at 2022-06-21 15:46:56.831901
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    seed = 1578177509.3714185
    provider = BaseProvider(seed=seed)
    assert provider.seed == seed
    assert type(provider.random) == type(Random())



# Generated at 2022-06-21 15:47:00.962562
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    # Arrange
    provider = BaseDataProvider()
    # Act
    actual = provider.get_current_locale()
    # Assert
    assert actual == locales.DEFAULT_LOCALE


# Generated at 2022-06-21 15:47:05.917983
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    """Test method reseed of class BaseProvider."""
    class TestBaseProvider(BaseProvider):
        """Test class BaseProvider."""
        pass

    obj = TestBaseProvider()
    old_seed = obj.seed
    assert (obj.random.seed_obj == old_seed)
    obj.reseed()
    assert (obj.random.seed_obj != old_seed)


# Generated at 2022-06-21 15:47:22.517847
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Test BaseDataProvider context manager which overrides current locale."""
    class TestDP(BaseDataProvider):
        """Test provider."""

        def __init__(self, locale: str = locales.EN,
                     seed: Seed = None,
                     datafile: str = '') -> None:
            super().__init__(locale=locale, seed=seed)
            self._datafile = datafile
            self._pull(datafile=datafile)

    with TestDP(locale=locales.EN) as p:
        assert p.locale == locales.EN
        assert p.get_current_locale() == locales.EN
        assert isinstance(p._data, Dict)
        assert p._data['datafile'] == 'test.json'

# Generated at 2022-06-21 15:47:26.057363
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    random_number = BaseProvider(seed=None)
    assert random_number.seed == None
    assert random_number.random == random
    random_number = BaseProvider(seed=12345)
    assert random_number.seed == 12345
    assert random_number.random != random


# Generated at 2022-06-21 15:47:27.782426
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'


# Generated at 2022-06-21 15:47:36.311227
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.file import File
    InfoDict = {
        'directory': '/tmp',
        'filename': 'hello.txt',
        'suffix': 'txt',
        'name': 'hello',
    }
    with File().override_locale(locale='ru'):
        assert InfoDict == {'directory': '/tmp',
                            'filename': 'привет.txt',
                            'suffix': 'txt',
                            'name': 'привет',
                            }

# Generated at 2022-06-21 15:47:38.399621
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    prov = BaseDataProvider()
    assert prov.get_current_locale() == 'en'

# Generated at 2022-06-21 15:47:49.894735
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class Text(BaseDataProvider):
        """Randomly generates text of specified type.

        It generates text of specified type. Supported classes are
        :class:`.Text` and :class:`.Internet`.

        :keyword locale: Current locale.
        """

        class Meta(object):
            """Class for meta information."""

            name = 'text'

            class Fields(object):
                """Class for fields."""

                TITLE = 'title'
                """Title."""

                DESCRIPTION = 'description'
                """Description."""


# Generated at 2022-06-21 15:47:54.596188
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    """Unit test for method override_locale of class BaseDataProvider."""
    assert not hasattr(BaseDataProvider(), '_override_locale')
    provider = BaseDataProvider()
    with provider.override_locale():
        assert provider.locale == locales.EN
    assert provider.locale == locales.EN

# Generated at 2022-06-21 15:47:56.062895
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseDataProvider()
    assert str(provider) == 'BaseDataProvider'



# Generated at 2022-06-21 15:47:58.912966
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from mimesis.providers.code import Code

    code = Code(seed=42)
    with code.override_locale():
        assert code.locale == 'ru'
        assert code._pull.cache_info().currsize == 1

# Generated at 2022-06-21 15:48:00.241993
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b_dp = BaseProvider()
    assert isinstance(b_dp, BaseProvider)

# Generated at 2022-06-21 15:48:13.267586
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    p1 = BaseProvider()
    p2 = BaseProvider(123)
    assert p1.random is not p2.random

    # Re-seed the random generator
    p1.reseed(123)
    assert p1.random is p2.random



# Generated at 2022-06-21 15:48:14.640891
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    class Animal(BaseDataProvider):
        pass
    assert str(Animal) == 'Animal <en>'

# Generated at 2022-06-21 15:48:16.162712
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider("en")
    assert provider.get_current_locale() == "en"


# Generated at 2022-06-21 15:48:18.209008
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    provider = BaseDataProvider('en')
    with provider.override_locale('ru') as p:
        assert p.get_current_locale() == 'ru'
    assert provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:48:30.419743
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    import pytest
    from mimesis.builtins import Vegetable, Food

    seed = 123
    locale = "en"
    provider = Vegetable(locale=locale, seed=seed)

    def get_random_vegetable():
        return provider.vegetable_by_country(locale)

    def get_random_food():
        return provider.food(locale, "vegetables")

    assert get_random_vegetable() == "chinese cabbage"
    assert get_random_food() == "corn"

    with provider.override_locale("ru"):
        assert get_random_vegetable() == "каштан"
        assert get_random_food() == "лук"

    assert get_random_vegetable() == "chinese cabbage"
    assert get

# Generated at 2022-06-21 15:48:31.074694
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider()) == 'BaseProvider'

# Generated at 2022-06-21 15:48:37.974919
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class ParentClass(BaseDataProvider):
        def get_data(self) -> Dict[str, Any]:
            return self._data

    class ChildClass(ParentClass):
        def get_data(self) -> Dict[str, Any]:
            data = super().get_data()
            return data

    child = ChildClass()
    parent = ParentClass()

    assert child.get_current_locale() == parent.get_current_locale()

    with child.override_locale(locales.UK) as override_child:
        assert override_child.get_current_locale() == locales.UK

    assert override_child.get_current_locale() == locales.UK
    assert child.get_current_locale() == locales.EN


# Generated at 2022-06-21 15:48:40.872187
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    test = BaseDataProvider(locale='cs_CZ', seed=10)
    assert test.get_current_locale() == 'cs_cz'


# Generated at 2022-06-21 15:48:43.744532
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    data_provider = BaseDataProvider('en')
    assert data_provider.get_current_locale() == 'en'


# Generated at 2022-06-21 15:48:48.103034
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestProvider(BaseDataProvider):
        def fruits(self):
            return self._data['fruits'][self.locale]

    provider = TestProvider()
    with provider.override_locale('ru') as p:
        assert p.fruits() == 'яблоко'
    assert provider.fruits() == 'apple'

# Generated at 2022-06-21 15:49:06.325230
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider()
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:49:11.525261
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    seed = '1'
    bp = BaseProvider(seed)
    random_num = bp.random.randint(1, 100)
    assert random_num == 30
    bp = BaseProvider()
    random_num = bp.random.randint(1, 100)
    assert random_num != 30


# Generated at 2022-06-21 15:49:14.284876
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import Text
    t = Text()
    assert str(t) == 'Text <en>'
    assert t.__str__() == 'Text <en>'


# Generated at 2022-06-21 15:49:15.452866
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider(locale="en")
    assert str(provider) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:49:17.401357
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    a = BaseProvider()
    assert a.seed is None
    assert a.random is random


# Generated at 2022-06-21 15:49:19.851166
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider(locale='en').get_current_locale() == 'en'
    assert BaseDataProvider().get_current_locale() == 'en'
    assert BaseDataProvider(locale='').get_current_locale() == 'en'



# Generated at 2022-06-21 15:49:30.445917
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    from utils import BaseTestCase
    from utils import ProviderTesterFactory

    class BaseDataProviderTestCase(BaseTestCase):
        def setUp(self):
            self.provider = self.PROVIDER()

        def test_with_locale_required(self):
            self.assertIsNotNone(self.provider.locale)

        def test_with_locale_different_locales(self):
            with self.provider.override_locale('ru'):
                self.assertEqual(self.provider.locale, 'ru')

            self.assertNotEqual(self.provider.locale, 'ru')


# Generated at 2022-06-21 15:49:33.568540
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    b = BaseProvider(seed=12)
    assert isinstance(b, BaseProvider)


# Generated at 2022-06-21 15:49:35.458376
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed = 1)) == "BaseProvider"


# Generated at 2022-06-21 15:49:36.939444
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    assert BaseDataProvider.get_current_locale() == BaseDataProvider.locale

# Generated at 2022-06-21 15:50:16.439578
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    assert str(BaseProvider(seed='s')) == 'BaseProvider'


# Generated at 2022-06-21 15:50:17.049011
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider(): 
    BaseDataProvider()

# Generated at 2022-06-21 15:50:19.119996
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.providers.address import Address
    
    address=Address()
    assert address.__str__() == "Address"

# Generated at 2022-06-21 15:50:21.059097
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    provider = BaseDataProvider()
    data = provider.get_current_locale()
    assert data == locales.EN


# Generated at 2022-06-21 15:50:24.744823
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    from mimesis.builtins import Seed
    seed = Seed

    assert BaseProvider(seed=None)
    assert BaseProvider(seed=seed)

    with pytest.raises(RuntimeError):
        BaseProvider(seed='123')



# Generated at 2022-06-21 15:50:36.046368
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        """Test class for test_BaseDataProvider_override_locale."""

        def get_data(self) -> JSON:
            """Return data."""
            return self._data

    tdp = TestDataProvider()
    with tdp.override_locale('en'):
        assert tdp.get_current_locale() == 'en'
        assert tdp.get_data()
    with tdp.override_locale('ru'):
        assert tdp.get_current_locale() == 'ru'
        assert tdp.get_data()
    assert tdp.get_current_locale() != 'ru'
    assert tdp.get_current_locale() == 'en'
    assert tdp.get_data()

# Generated at 2022-06-21 15:50:40.601951
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    bdp = BaseDataProvider()
    assert bdp.locale == locales.EN
    bdp = BaseDataProvider(locale='ru')
    assert bdp.locale == 'ru'
    bdp = BaseDataProvider(locale='en-US')
    assert bdp.locale == 'en-us'



# Generated at 2022-06-21 15:50:44.034356
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    base_data_provider = BaseDataProvider(locale='en')
    locale = base_data_provider.get_current_locale()
    assert locale == 'en'


# Generated at 2022-06-21 15:50:45.571349
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    provider = BaseProvider()
    result = str(provider)
    assert result == 'BaseProvider'


# Generated at 2022-06-21 15:50:49.567259
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    locale = locales.RUSSIAN
    seed = 'Mimesis'
    x = BaseDataProvider(locale, seed)
    y = BaseProvider(seed)
    assert str(x) == 'BaseDataProvider <{}>'.format(locale)
    assert str(y) == 'BaseProvider'

# Generated at 2022-06-21 15:52:33.375629
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    from mimesis.builtins import locale as locale_builtins
    from mimesis.builtins import Person
    from mimesis.builtins import get_locale
    from mimesis.builtins import set_locale

    person = Person()
    locale = person.get_current_locale()
    assert str(person) == 'Person <{}>'.format(locale) # First assert

    person.set_locale(locale_builtins.EN)
    assert str(person) == 'Person <en>'

    person.set_locale(locale_builtins.RU)
    assert str(person) == 'Person <ru>'

    with person.override_locale(locale_builtins.DE):
        assert str(person) == 'Person <de>'


# Generated at 2022-06-21 15:52:35.893129
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    from mimesis.builtins import Global
    a = Global()
    b = Global()
    result = str(a)
    expect = 'Global'
    assert result == expect


# Generated at 2022-06-21 15:52:37.117014
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    provider_base = BaseProvider()
    assert(provider_base is not None)


# Generated at 2022-06-21 15:52:39.346900
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    data_provider = BaseDataProvider(locale='ru')
    assert str(data_provider) == 'BaseDataProvider <ru>'

# Generated at 2022-06-21 15:52:46.153740
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    from mimesis.providers.base import BaseDataProvider
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale

    locale = locales.EN

    bdp = BaseDataProvider(locale=locale)
    assert bdp.get_current_locale() == locale

    bdp._override_locale(locale=locales.JA)
    assert bdp.get_current_locale() == locales.JA


# Generated at 2022-06-21 15:52:50.538913
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
  assert BaseDataProvider.get_current_locale.__doc__ == "Get current locale.\n\nIf locale is not defined then this method will always return ``en``,\nbecause ``en`` is default locale for all providers, excluding builtins.\n"


# Generated at 2022-06-21 15:52:52.765038
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    sp = BaseProvider()
    sp.reseed(seed=None)
    sp.reseed(seed=10)
    assert sp.reseed(seed=10) is None

# Generated at 2022-06-21 15:52:55.844638
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert BaseDataProvider().__str__() == 'BaseDataProvider <en>'
    assert BaseDataProvider(locale='ru').__str__() == 'BaseDataProvider <ru>'



# Generated at 2022-06-21 15:52:59.503269
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    bp = BaseProvider()
    bp2 = BaseProvider(seed=10)
    assert bp.seed == None
    assert bp2.seed == 10
    assert bp.reseed() == None
    assert bp.random() != bp2.random()


# Generated at 2022-06-21 15:53:08.377156
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    class TestBaseDataProvider(BaseDataProvider):
        def __init__(self, locale: str = locales.DEFAULT_LOCALE,
                     seed: Seed = None):
            super().__init__(locale=locale, seed=seed)
            self._data = None
            self._datafile = 'mimesis_data.json'
            self._pull()
    # Simplest case
    provider1 = TestBaseDataProvider()
    assert(provider1.get_current_locale() == 'en')
    # More complicated
    provider2 = TestBaseDataProvider(locale = 'ru')
    assert(provider2.get_current_locale() == 'ru')


# Generated at 2022-06-21 15:54:39.129083
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    """Unit test for method get_current_locale of class BaseDataProvider."""
    pass

# Generated at 2022-06-21 15:54:40.749421
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    b = BaseDataProvider()
    assert isinstance(b, BaseDataProvider)


# Generated at 2022-06-21 15:54:44.021052
# Unit test for constructor of class BaseDataProvider
def test_BaseDataProvider():
    provider = BaseDataProvider()
    assert isinstance(provider,BaseDataProvider)
    assert provider._data == {}
    assert isinstance(provider.__dict__['_data'],dict)


# Generated at 2022-06-21 15:54:45.572396
# Unit test for method __str__ of class BaseProvider
def test_BaseProvider___str__():
    b = BaseProvider('en')
    assert b.__str__() == 'BaseProvider'


# Generated at 2022-06-21 15:54:48.289272
# Unit test for method reseed of class BaseProvider
def test_BaseProvider_reseed():
    b = BaseProvider()
    assert b.random is random

    b.reseed(10)
    assert isinstance(b.random, Random)

    b.reseed()
    assert isinstance(b.random, Random)

# Generated at 2022-06-21 15:54:50.306820
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    provider = BaseDataProvider()
    assert provider.__str__() == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:54:52.521701
# Unit test for method get_current_locale of class BaseDataProvider
def test_BaseDataProvider_get_current_locale():
    test_locale = 'ru'
    provider = BaseDataProvider(locale=test_locale)
    assert provider.get_current_locale() == test_locale

# Generated at 2022-06-21 15:54:56.416419
# Unit test for method override_locale of class BaseDataProvider
def test_BaseDataProvider_override_locale():
    class TestDataProvider(BaseDataProvider):
        def __init__(self, locality: str = locales.EN) -> None:
            super().__init__()
            self.locality = locality

        def __getitem__(self, item: str) -> Dict:
            return {
                'locality': self.locality,
                'item': item
            }

    provider = TestDataProvider()
    with provider.override_locale(locales.RU):
        data1 = provider['123']
        assert data1['locality'] == locales.RU

    data2 = provider['123']
    assert data2['locality'] == locales.EN

# Generated at 2022-06-21 15:54:57.659965
# Unit test for method __str__ of class BaseDataProvider
def test_BaseDataProvider___str__():
    assert str(BaseDataProvider('en')) == 'BaseDataProvider <en>'

# Generated at 2022-06-21 15:54:58.157737
# Unit test for constructor of class BaseProvider
def test_BaseProvider():
    BaseProvider()