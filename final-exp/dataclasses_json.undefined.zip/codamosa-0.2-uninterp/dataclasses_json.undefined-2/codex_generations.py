

# Generated at 2022-06-17 17:56:17.139144
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}
    test_class.catch_all = {"a": 1}
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-17 17:56:23.261556
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: str):
            pass

    kvs = {"a": "a", "b": 1, "c": "c", "d": "d"}
    expected_result = {"a": "a", "b": 1, "c": "c"}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == expected_result



# Generated at 2022-06-17 17:56:32.702356
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:56:43.747946
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: str
        d: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    test_obj = TestClass(1, 2, "3", {"a": 4})
    init(test_obj, 1, 2, "3", {"a": 4})
    assert test_obj.d == {"a": 4}

    test_obj = TestClass(1, 2, "3", {"a": 4})
    init(test_obj, 1, 2, "3", {"a": 4, "b": 5})
    assert test_obj.d == {"a": 4, "b": 5}


# Generated at 2022-06-17 17:56:55.600723
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    kvs = {"a": 1, "b": "2", "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": "2"}
    assert unknown_parameters == {"c": 3}

    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": "2"}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters

# Generated at 2022-06-17 17:56:57.228310
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:57:03.934142
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int = 5, e: int = 6,
                     f: int = 7, g: int = 8, h: int = 9, i: int = 10,
                     j: int = 11, k: int = 12, l: int = 13, m: int = 14,
                     n: int = 15, o: int = 16, p: int = 17, q: int = 18,
                     r: int = 19, s: int = 20, t: int = 21, u: int = 22,
                     v: int = 23, w: int = 24, x: int = 25, y: int = 26,
                     z: int = 27, catch_all: Optional[CatchAllVar] = None):
            pass

    init = _C

# Generated at 2022-06-17 17:57:13.877542
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}

    kvs = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 17:57:18.695477
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_instance = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_instance, kvs) == kvs



# Generated at 2022-06-17 17:57:25.134725
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__
    assert _IgnoreUndefinedParameters.create_init(TestClass) != TestClass.__init__
    assert _CatchAllUndefinedParameters.create_init(TestClass) != TestClass.__init__

# Generated at 2022-06-17 17:57:43.232610
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:57:49.682353
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-17 17:58:01.702726
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    init_method = _UndefinedParameterAction.create_init(test_class)
    assert init_method(test_class, 1, 2, 3) is None
    assert init_method(test_class, 1, 2) is None
    assert init_method(test_class, 1) is None
    assert init_method(test_class) is None
    assert init_method(test_class, 1, 2, 3, 4) is None
    assert init_method(test_class, 1, 2, 3, 4, 5) is None
    assert init_method(test_class, 1, 2, 3, 4, 5, 6) is None
   

# Generated at 2022-06-17 17:58:09.393705
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"d": 3}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:15.983474
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test with no undefined parameters
    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2, "c": {}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    # Test with undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    expected = {"a": 1, "b": 2, "c": {"d": 3}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    # Test

# Generated at 2022-06-17 17:58:28.561208
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"x": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"x": 3}}
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {}}) == {"a": 1, "b": 2, "c": {}}

# Generated at 2022-06-17 17:58:36.316808
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == kvs



# Generated at 2022-06-17 17:58:42.977467
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 17:58:55.905023
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    class B:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    class C:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    class D:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    class E:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass


# Generated at 2022-06-17 17:59:05.055953
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == {
        "a": 1, "b": 2, "c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "d": 3}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == {
        "a": 1, "b": 2, "c": {"d": 3}}


# Generated at 2022-06-17 17:59:42.688770
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    def test_case(kvs: Dict[str, Any], expected: Dict[str, Any]):
        result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert result == expected

    test_case(kvs={"a": 1, "b": 2, "c": 3}, expected={"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-17 17:59:51.169429
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_object = TestClass(1, 2, 3, 4, 5, catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "catch_all": {"a": 1, "b": 2}}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)

# Generated at 2022-06-17 17:59:52.774838
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 18:00:04.052779
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, "2")
    init = _CatchAllUndefinedParameters.create_init(obj)
    obj2 = init(1, "2", c={"d": 3})
    assert obj2.a == 1
    assert obj2.b == "2"
    assert obj2.c == {"d": 3}

    obj3 = init(1, "2", "3")
    assert obj3.a == 1
    assert obj3.b == "2"

# Generated at 2022-06-17 18:00:10.648278
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:00:19.539516
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    kvs_

# Generated at 2022-06-17 18:00:27.194719
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: str, b: str, c: str):
            pass

    kvs = {"a": "a", "b": "b", "c": "c", "d": "d"}
    expected = {"a": "a", "b": "b", "c": "c"}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == \
           expected



# Generated at 2022-06-17 18:00:34.695963
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:00:40.826031
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:00:45.950771
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.config import Config

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    config = Config(undefined=Undefined.INCLUDE)

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": "2"}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2", "c": {}}

    # Test 2: Some undefined parameters
    kvs = {"a": 1, "b": "2", "d": "3"}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)


# Generated at 2022-06-17 18:01:41.609994
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:54.331244
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:02:00.321822
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}



# Generated at 2022-06-17 18:02:11.802268
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 18:02:22.050490
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = Test(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:02:27.636693
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "d": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"d": 3}

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)

# Generated at 2022-06-17 18:02:29.521044
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:39.403474
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": "2", "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": "2", "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 18:02:45.610730
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)



# Generated at 2022-06-17 18:02:57.614683
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-17 18:05:10.896258
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:05:18.913912
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {"a": 1, "b": 2}) == {
               "a": 1, "b": 2}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                   {"a": 1, "b": 2, "c": 3})
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-17 18:05:29.806615
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, d=5)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)

# Generated at 2022-06-17 18:05:41.684613
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    new_init = _UndefinedParameterAction.create_init(TestClass)
    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
   

# Generated at 2022-06-17 18:05:46.753405
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, c=5, d=6)
    init(TestClass, 1, 2, 3, 4, b=5, c=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6, c=7, d=8)
   

# Generated at 2022-06-17 18:05:56.756280
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass(1, 2, 3), 4, 5, 6) == TestClass(1, 2, 3)
    assert init(TestClass(1, 2, 3), 4, 5, 6, d=7) == TestClass(1, 2, 3)
    assert init(TestClass(1, 2, 3), 4, 5, 6, d=7, e=8) == TestClass(1, 2, 3)
