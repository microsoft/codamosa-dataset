

# Generated at 2022-06-17 17:56:20.268517
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int = 1):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 17:56:21.624926
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:28.889396
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, 4, 5, catch_all={"f": 6, "g": 7})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)

# Generated at 2022-06-17 17:56:35.567306
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_instance = TestClass(1, 2, 3, 4, 5, catch_all={"f": 6, "g": 7})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

# Generated at 2022-06-17 17:56:45.561896
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9) is None

# Generated at 2022-06-17 17:56:47.186749
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:56:57.485643
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == {
               "a": 1, "b": 2}

    kvs = {"a": 1, "b": 2}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == {
               "a": 1, "b": 2}

    kvs = {"a": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-17 17:57:01.683335
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 17:57:11.788585
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 17:57:19.984877
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 17:57:40.775908
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 17:57:42.403182
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 17:57:43.742909
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:44.843175
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:52.136433
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    assert _UndefinedParameterAction.handle_dump(obj) == {}



# Generated at 2022-06-17 17:58:03.317295
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    test_obj = Test

# Generated at 2022-06-17 17:58:04.578620
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:15.394908
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    original_init = TestClass.__init__
    init_signature = inspect.signature(original_init)

    def _test_init(self, *args, **kwargs):
        bound_parameters = init_signature.bind_partial(self, *args, **kwargs)
        bound_parameters.apply_defaults()
        arguments = bound_parameters.arguments
        arguments.pop("self", None)
        original_init(self, **arguments)

    TestClass.__init__ = _UndefinedParameterAction.create_init(TestClass)
    TestClass(1, 2, 3)
    TestClass(1, 2, c=3)
    TestClass(1, 2)
    TestClass

# Generated at 2022-06-17 17:58:22.131294
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    def test_function(a: int, b: int, c: int):
        pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__
    assert _UndefinedParameterAction.create_init(test_function) == test_function



# Generated at 2022-06-17 17:58:23.644906
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:45.732621
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:58:48.021175
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:57.781760
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: typing.Optional[dataclasses_json.CatchAllVar] = None

        def __init__(self, a: int, b: int, c: typing.Optional[dict] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    test_obj = TestClass(1, 2)
    assert test_obj.a == 1
    assert test_obj.b == 2
    assert test_obj.c is None

    test_obj = TestClass(1, 2, c={"a": 1})
    assert test

# Generated at 2022-06-17 17:59:03.160837
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:59:14.685905
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:59:25.354630
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_class = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4}

# Generated at 2022-06-17 17:59:32.415473
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = 4
        e: int = 5
        f: int = 6
        g: CatchAllVar = CatchAll

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": {},
           "h": 7, "i": 8, "j": 9}
    expected_result = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6,
                       "g": {"h": 7, "i": 8, "j": 9}}
    result = _

# Generated at 2022-06-17 17:59:40.183670
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int

    kvs = {"a": 1, "b": 2, "c": 3}
    expected_result = {"a": 1, "b": 2}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == expected_result



# Generated at 2022-06-17 17:59:55.433290
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)

# Generated at 2022-06-17 18:00:05.767509
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": {"load_only": True}})

    init = _CatchAllUndefinedParameters

# Generated at 2022-06-17 18:00:41.883328
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(1, 2, 3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4
    }



# Generated at 2022-06-17 18:00:54.214784
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0):
            pass

    init_method = _UndefinedParameterAction.create_init(TestClass)
    assert init_method(TestClass, 1, 2) == TestClass(1, 2)
    assert init_method(TestClass, 1, 2, 3) == TestClass(1, 2, 3)
    assert init_method(TestClass, 1, 2, c=3) == TestClass(1, 2, 3)
    assert init_method(TestClass, 1, 2, c=3, d=4) == TestClass(1, 2, 3)
    assert init_method(TestClass, 1, 2, d=4) == TestClass(1, 2)

# Generated at 2022-06-17 18:01:04.011910
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=test_class, kvs=kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=test_class, kvs=kvs)
    except UndefinedParameterError:
        pass

# Generated at 2022-06-17 18:01:10.933686
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:01:12.817373
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:01:15.977222
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 18:01:17.348479
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:01:24.760349
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(1, 2, 3, {"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 18:01:35.752578
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:45.582790
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    test_class_init = _UndefinedParameterAction.create_init(TestClass)
    test_class_init(TestClass, 1, 2, 3, 4)
    test_class_init(TestClass, 1, 2, 3, 4, 5)
    test_class_init(TestClass, 1, 2, 3, 4, 5, 6)
    test_class_init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    test_class_init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    test_class_init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)


# Generated at 2022-06-17 18:02:43.411907
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 18:02:50.503225
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    init_method = _UndefinedParameterAction.create_init(test_class)
    assert init_method(test_class, 1, 2, 3) is None

# Generated at 2022-06-17 18:02:52.030543
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:03:03.266328
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     e: int = 5, f: int = 6, g: int = 7,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 18:03:13.486346
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:03:18.315675
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:03:26.847432
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int, m: int,
                     n: int, o: int, p: int, q: int, r: int, s: int, t: int,
                     u: int, v: int, w: int, x: int, y: int, z: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:03:34.986054
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 18:03:43.747715
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: int = dataclasses.field(default=1)
        d: str = dataclasses.field(default="d")

        def __init__(self, a: int, b: str, c: int = 1, d: str = "d"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_instance = TestClass(1, "b")
    assert test_instance.a == 1
    assert test_instance.b == "b"
    assert test_instance.c == 1
    assert test_instance.d == "d"

    test_instance = TestClass(1, "b", 2, "e")
    assert test_instance

# Generated at 2022-06-17 18:03:54.597632
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: str
        b: int
        c: str

        def __init__(self, a: str, b: int, c: str = "default"):
            self.a = a
            self.b = b
            self.c = c

    config(undefined=Undefined.EXCLUDE).register_class(TestClass)
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    instance = init("a", 1, c="c")
    assert instance.a == "a"
    assert instance.b == 1
    assert instance.c == "c"

    instance = init("a", 1)
    assert instance.a == "a"