

# Generated at 2022-06-17 17:56:17.139931
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: str = dataclasses.field(default="c")
        d: str = dataclasses.field(default_factory=lambda: "d")
        e: CatchAll = dataclasses.field(default=None)

    # Test 1: No undefined parameters
    kvs = {"a": "a", "b": "b"}
    expected = {"a": "a", "b": "b", "c": "c", "d": "d", "e": {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == expected

    # Test 2: Undefined parameters

# Generated at 2022-06-17 17:56:25.328766
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyTypeChecker
    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # noinspection PyTypeChecker
    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 17:56:28.964017
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 17:56:35.135678
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 17:56:45.272749
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = init(TestClass, 1, 2, 3, 4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4

    obj = init(TestClass, 1, 2, 3, 4, 5)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4

# Generated at 2022-06-17 17:56:53.334636
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_class, kvs) == kvs



# Generated at 2022-06-17 17:56:58.567754
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:57:03.885742
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c, d):
            pass

    test_class = TestClass(1, 2, 3, 4)
    init = _UndefinedParameterAction.create_init(test_class)
    assert init(test_class, 1, 2, 3, 4) is None
    assert init(test_class, 1, 2, 3) is None
    assert init(test_class, 1, 2) is None
    assert init(test_class, 1) is None
    assert init(test_class) is None
    assert init(test_class, 1, 2, 3, 4, 5) is None
    assert init(test_class, 1, 2, 3, 4, 5, 6) is None

# Generated at 2022-06-17 17:57:14.040522
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: typing.Optional[dataclasses_json.CatchAllVar] = None

        def __init__(self, a: int, b: int, c: typing.Optional[dict] = None):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c is None

    test_class = TestClass(1, 2, {'a': 3})
    assert test_class.a == 1
    assert test_class.b == 2
    assert test

# Generated at 2022-06-17 17:57:18.807359
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"test": "test"}

# Generated at 2022-06-17 17:57:53.593305
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:58:04.455368
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_instance = TestClass(1, 2, 3)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

    test_instance = TestClass(1, 2, 3, 4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

    test_instance = TestClass(1, 2, 3, d=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

    test_instance = TestClass(1, 2, 3, d=4, e=5)
    assert test_instance

# Generated at 2022-06-17 17:58:10.910137
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 17:58:12.318249
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:19.328125
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c={"d": 3, "e": 4})
    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert kvs == {"a": 1, "b": 2, "d": 3, "e": 4}

# Generated at 2022-06-17 17:58:20.583001
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:31.521492
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:58:42.406143
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

        def __init__(self, a: int, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:58:55.659906
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 17:59:01.174403
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:59:43.517120
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass2:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)
        d: Optional[CatchAllVar] = dataclasses.field(default=None)

    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass3:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)
       

# Generated at 2022-06-17 17:59:54.445604
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = init(1, 2, 3, d=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3



# Generated at 2022-06-17 18:00:05.113585
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(a=1, b=2, c=3, d=4)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == kvs

    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            self.c = c
           

# Generated at 2022-06-17 18:00:15.873496
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(a=1, b=2, c=3, d={"e": 4, "f": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": {"e": 4, "f": 5}}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "e": 4, "f": 5}



# Generated at 2022-06-17 18:00:28.458250
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 18:00:34.696662
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 18:00:42.965196
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = dataclasses.field(default=1)
        e: int = dataclasses.field(default=2)
        f: int = dataclasses.field(default=3)
        g: int = dataclasses.field(default=4)
        h: int = dataclasses.field(default=5)
        i: int = dataclasses.field(default=6)
        j: int = dataclasses.field(default=7)
        k: int = dataclasses.field(default=8)
        l: int = dataclasses.field(default=9)
        m: int = dataclasses.field(default=10)
        n: int = dataclasses

# Generated at 2022-06-17 18:00:45.753942
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 18:00:49.090727
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:01:00.147002
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    expected = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected

    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}, "f": 5}

# Generated at 2022-06-17 18:01:44.511382
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_instance = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_instance) == {}

    test_instance = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(test_instance) == {"a": 1}



# Generated at 2022-06-17 18:01:55.368958
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    known_given_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}


# Generated at 2022-06-17 18:01:56.739201
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:08.624000
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(1, 2, 3, 4)
    init = _IgnoreUndefinedParameters.create_init(obj)
    obj2 = TestClass(1, 2, 3, 4)
    obj3 = TestClass(1, 2, 3, 4)
    obj4 = TestClass(1, 2, 3, 4)
    obj5 = TestClass(1, 2, 3, 4)
    obj6 = TestClass(1, 2, 3, 4)


# Generated at 2022-06-17 18:02:09.920717
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:17.794809
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3


# Generated at 2022-06-17 18:02:23.006822
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:02:33.016128
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            TestClass, kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-17 18:02:41.169506
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 18:02:54.664454
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": "2", "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": "2"}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": "2", "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 18:04:38.361834
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass,
        kvs={"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass,
        kvs={"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2}

# Generated at 2022-06-17 18:04:43.599913
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert kvs_actual == kvs_expected



# Generated at 2022-06-17 18:04:52.456112
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0, d: int = 0):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)



# Generated at 2022-06-17 18:04:55.026896
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)

# Generated at 2022-06-17 18:05:03.618261
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__

    class TestClass:
        def __init__(self, a: int, b: int, c: int, **kwargs):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__

    class TestClass:
        def __init__(self, a: int, b: int, c: int, *args, **kwargs):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__


# Generated at 2022-06-17 18:05:08.074613
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs



# Generated at 2022-06-17 18:05:16.269603
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class TestClass(DataClassJsonMixin):
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    obj = TestClass(a=1, b=2, c={"d": 3, "e": 4})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"d": 3, "e": 4}

# Generated at 2022-06-17 18:05:18.705989
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args == ("test",)

# Generated at 2022-06-17 18:05:26.536333
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:05:33.593155
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    test_class = TestClass()
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)
    assert kvs_actual == kvs_expected

    test_class = TestClass(catch_all={"a": 1, "b": 2, "c": 3})
    kvs = {"a": 1, "b": 2, "c": 3}