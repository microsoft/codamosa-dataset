

# Generated at 2022-06-17 17:56:10.431228
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:15.312001
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:56:25.078797
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    new_init = _IgnoreUndefinedParameters.create_init(obj)
    obj = TestClass(1, 2, 3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = TestClass(1, 2, 3, d=4, e=5)
    assert obj.a == 1

# Generated at 2022-06-17 17:56:33.522376
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     f: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = TestClass(1, 2, 3, 4, 5)
    init(obj, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4

# Generated at 2022-06-17 17:56:36.481759
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:56:42.929865
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"test": "test"}

# Generated at 2022-06-17 17:56:49.418486
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=test_class, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=test_class, kvs=kvs)




# Generated at 2022-06-17 17:56:58.140989
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # Test 1: no undefined parameters
    kvs = {"a": 1, "b": "b"}
    expected = {"a": 1, "b": "b", "c": {}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == expected

    # Test 2: undefined parameters
    kvs = {"a": 1, "b": "b", "d": "d"}
    expected = {"a": 1, "b": "b", "c": {"d": "d"}}

# Generated at 2022-06-17 17:57:02.296067
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:57:12.476148
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None, d=None):
            pass

    test_class_init = _UndefinedParameterAction.create_init(TestClass)
    assert test_class_init(TestClass, 1, 2, 3, 4) is None
    assert test_class_init(TestClass, 1, 2, 3) is None
    assert test_class_init(TestClass, 1, 2) is None
    assert test_class_init(TestClass, 1, 2, d=4) is None
    assert test_class_init(TestClass, 1, 2, c=3) is None
    assert test_class_init(TestClass, 1, 2, c=3, d=4) is None

# Generated at 2022-06-17 17:57:33.774759
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init_method = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = TestClass(1, "a", {"c": 3})
    init_method(obj, 2, "b", {"c": 4})
    assert obj.a == 2
    assert obj.b == "b"
    assert obj.c == {"c": 4}

# Generated at 2022-06-17 17:57:43.472780
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 17:57:48.014018
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}

# Generated at 2022-06-17 17:57:50.283573
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:00.031846
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

        def __init__(self, a: int, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = init(TestClass, 1, "b", c={"c": 3})
    assert obj.a == 1
    assert obj.b == "b"
    assert obj.c == {"c": 3}

# Generated at 2022-06-17 17:58:08.449767
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    # noinspection PyTypeChecker
    assert _RaiseUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": "b"}) == {"a": 1, "b": "b"}

    # noinspection PyTypeChecker
    assert _RaiseUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": "b", "c": "c"}) == {"a": 1, "b": "b"}

    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:17.821814
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:29.706915
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:41.287045
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == \
           {"a": 1, "b": 2, "c": {"d": 3}}
    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "d": 3}) == \
           {"a": 1, "b": 2, "c": {"d": 3}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:55.132655
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

        def __init__(self, a: int, b: str, c: CatchAll = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, "2", 3, 4, 5, 6, 7)
    init(TestClass, 1, "2", c={3: 4, 5: 6, 7: 8})
    init(TestClass, 1, "2", c={3: 4, 5: 6, 7: 8}, a=9)

# Generated at 2022-06-17 17:59:30.295422
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

    known_given_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}

    kvs = {"a": 1, "b": 2}
    known_given_parameters = _RaiseUndefined

# Generated at 2022-06-17 17:59:35.561848
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int = 1
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:59:36.610861
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test")

# Generated at 2022-06-17 17:59:43.219448
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: CatchAll = dataclasses.field(
            default_factory=dict)

    test_object = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_object) == {}

    test_object.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(test_object) == {
        "test": "test"}

# Generated at 2022-06-17 17:59:45.366990
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:59:56.791283
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs


# Unit test

# Generated at 2022-06-17 17:59:58.165473
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:00:07.253260
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {"a": 1,
                                                                     "b": 2,
                                                                     "c": 3,
                                                                     "d": 4}


# Generated at 2022-06-17 18:00:12.699666
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:00:20.692569
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"d": 3}}
    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": None}) == {"a": 1, "b": 2, "c": {}}
    # noinspection PyTypeChecker
    assert _C

# Generated at 2022-06-17 18:01:03.011979
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert kvs_actual == kvs_expected

# Generated at 2022-06-17 18:01:14.071719
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, 4, {"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    kvs_without_catch_all = _CatchAllUndefinedParameters.handle_to_dict(
        test_obj, kvs)

# Generated at 2022-06-17 18:01:23.840652
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c is None

    obj = TestClass(1, 2, 3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = TestClass(1, 2, c=3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

# Generated at 2022-06-17 18:01:26.599182
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:29.676223
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:01:38.370899
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)

# Generated at 2022-06-17 18:01:44.512117
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": "2", "c": 3}
    known_given_parameters, _ = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": "2"}



# Generated at 2022-06-17 18:01:54.509329
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    # Test that an error is raised when undefined parameters are given
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)



# Generated at 2022-06-17 18:02:02.692514
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": "b"}
    expected = {"a": 1, "b": "b", "c": {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           expected

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": "b", "d": "d"}
    expected = {"a": 1, "b": "b", "c": {"d": "d"}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           expected

    # Test

# Generated at 2022-06-17 18:02:12.966427
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 18:03:28.865409
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 18:03:39.716880
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     f: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f

    test_obj = TestClass(1, 2, 3, 4, 5, {"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": {"a": 1, "b": 2}}

# Generated at 2022-06-17 18:03:42.869493
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:03:52.915228
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__module__ == TestClass.__init__.__module__
    assert init.__qualname__ == TestClass.__init__.__qualname__
    assert init.__annotations__ == TestClass.__init__.__annotations__



# Generated at 2022-06-17 18:03:53.724110
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:03:56.360354
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:01.971064
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}

# Generated at 2022-06-17 18:04:09.905385
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})

    init = _CatchAllUndefinedParameters.create_init

# Generated at 2022-06-17 18:04:14.585251
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs



# Generated at 2022-06-17 18:04:21.115006
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str, c: str = "default"):
            pass

    kvs = {"a": 1, "b": "2", "c": "3", "d": "4"}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": "2", "c": "3"}
    assert unknown == {"d": "4"}

