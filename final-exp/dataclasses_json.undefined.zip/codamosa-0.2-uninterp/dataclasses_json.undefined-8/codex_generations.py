

# Generated at 2022-06-17 17:56:15.704978
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 17:56:22.025651
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}

# Generated at 2022-06-17 17:56:23.927848
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:56:30.981374
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"test": "test"}



# Generated at 2022-06-17 17:56:37.748440
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:56:46.954840
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    kvs_without_catch_all = _CatchAllUndefinedParameters.handle_to_dict(
        test_object, kvs)
    assert kvs_

# Generated at 2022-06-17 17:56:50.932840
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, _ = \
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 17:57:00.019234
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2, "c": {}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    expected = {"a": 1, "b": 2, "c": {"d": 3}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 17:57:03.851980
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_class, kvs) == kvs

# Generated at 2022-06-17 17:57:13.805286
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": "2", "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2", "c": {"d": 3}}

    kvs = {"a": 1, "b": "2", "c": {"d": 3}, "e": 4}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2", "c": {"d": 3, "e": 4}}


# Generated at 2022-06-17 17:57:46.039399
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_class = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4}

    test_class = TestClass(a=1, b=2, c=3)


# Generated at 2022-06-17 17:57:56.404920
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = TestClass(1, 2)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == {}

    obj = TestClass(1, 2, c={"a": 1})
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == {"a": 1}

    obj = TestClass(1, 2, {"a": 1})


# Generated at 2022-06-17 17:58:06.295054
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 17:58:16.216651
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)

# Generated at 2022-06-17 17:58:28.781726
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2}) == {
               "a": 1, "b": 2, "c": {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2,
                                                          "c": {}}) == {
               "a": 1, "b": 2, "c": {}}

# Generated at 2022-06-17 17:58:36.423019
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_object = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_object, kvs) == kvs



# Generated at 2022-06-17 17:58:42.514150
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 17:58:49.242393
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 1
        d: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": 3, "d": {"e": 4}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": {"e": 4}}

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": {}}

    k

# Generated at 2022-06-17 17:58:53.879276
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int):
            pass

    def _test_create_init(init_function: Callable,
                          args: Tuple,
                          kwargs: Dict,
                          expected_args: Tuple,
                          expected_kwargs: Dict):
        init_signature = inspect.signature(init_function)
        bound_parameters = init_signature.bind(*args, **kwargs)
        bound_parameters.apply_defaults()
        arguments = bound_parameters.arguments
        arguments.pop("self", None)
        assert arguments == expected_args, \
            f"Expected args: {expected_args}, got {arguments}"
        assert kw

# Generated at 2022-06-17 17:59:03.863531
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     f: int = 1, g: int = 2, h: int = 3, i: int = 4,
                     j: int = 5, k: int = 6, l: int = 7, m: int = 8,
                     n: int = 9, o: int = 10, p: int = 11, q: int = 12,
                     r: int = 13, s: int = 14, t: int = 15, u: int = 16,
                     v: int = 17, w: int = 18, x: int = 19, y: int = 20,
                     z: int = 21, catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefined

# Generated at 2022-06-17 17:59:43.408527
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)


# Generated at 2022-06-17 17:59:56.057444
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "catch_all": {}}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _C

# Generated at 2022-06-17 18:00:06.081573
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    init = _IgnoreUndefinedParameters.create_init(obj)
    obj = TestClass(1, 2, 3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    init = _IgnoreUndefinedParameters.create_init(obj)

# Generated at 2022-06-17 18:00:16.934250
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    @dataclass
    class TestClass2:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __post_init__(self):
            self.c = {'a': 1}

    @dataclass
    class TestClass3:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __post_init__(self):
            self.c = {'a': 1}

    @dataclass
    class TestClass4:
        a: int
        b: str

# Generated at 2022-06-17 18:00:29.365975
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = TestClass(1, 2, 3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = TestClass(1, 2, 3, d=4, e=5)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3


# Generated at 2022-06-17 18:00:40.569397
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:00:54.001223
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    obj = TestClass(1, 2, 3)
    init(obj, 1, 2, 3)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    init(obj, 1, 2, 3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3


# Generated at 2022-06-17 18:01:00.812797
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:01:07.384003
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 1
        d: Optional[CatchAllVar] = None


# Generated at 2022-06-17 18:01:16.393617
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 3):
            pass

    init_function = _IgnoreUndefinedParameters.create_init(TestClass)
    init_function(TestClass, 1, 2, 3, 4, 5)
    init_function(TestClass, 1, 2, 3, 4, 5, d=6)
    init_function(TestClass, 1, 2, 3, 4, 5, d=6, e=7)
    init_function(TestClass, 1, 2, 3, 4, 5, d=6, e=7, f=8)
    init_function(TestClass, 1, 2, 3, 4, 5, d=6, e=7, f=8, g=9)

# Generated at 2022-06-17 18:02:16.230409
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__module__ == TestClass.__init__.__module__
    assert init.__annotations__ == TestClass.__init__.__annotations__

    # Test that the init function works as expected
    class TestClass2:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a

# Generated at 2022-06-17 18:02:24.911226
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 3):
            pass

    kvs = {"a": 1, "b": 2, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"d": 4}

    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False, "Expected to raise UndefinedParameterError"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-17 18:02:26.308990
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:37.429205
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=test_class, kvs={"a": 1, "b": 2, "c": 3})
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=test_class, kvs={"a": 1, "b": 2})
    assert known_param

# Generated at 2022-06-17 18:02:41.674799
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2) is None
    assert init(TestClass, 1) is None
    assert init(TestClass) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None

# Generated at 2022-06-17 18:02:49.354394
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:02:55.083003
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:03:06.489950
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect
    import dataclasses

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)


# Generated at 2022-06-17 18:03:13.047873
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:03:23.413862
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2,
                                                          "c": 3}) == {"a": 1,
                                                                       "b": 2,
                                                                       "c": 3,
                                                                       "catch_all": {}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 18:05:43.413456
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
   