

# Generated at 2022-06-17 17:56:16.049480
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == kvs

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-17 17:56:23.774207
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=3, d=4):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3)
    init(TestClass, 1, 2)
    init(TestClass, 1, 2, d=4)
    init(TestClass, 1, 2, c=3)
    init(TestClass, 1, 2, c=3, d=4)
    init(TestClass, 1, 2, d=4, c=3)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, 6)

# Generated at 2022-06-17 17:56:33.425923
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "catch_all": {"a": 1, "b": 2}}

# Generated at 2022-06-17 17:56:35.471421
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:43.876246
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(1, 2, 3, 4)
    kvs = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    kvs_without_d = {'a': 1, 'b': 2, 'c': 3}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == kvs_without_d

# Generated at 2022-06-17 17:56:55.665109
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = dataclasses.field(default=1)
        e: int = dataclasses.field(default=2)
        f: int = dataclasses.field(default=3)
        g: int = dataclasses.field(default=4)
        h: int = dataclasses.field(default=5)
        i: int = dataclasses.field(default=6)
        j: int = dataclasses.field(default=7)
        k: int = dataclasses.field(default=8)
        l: int = dataclasses.field(default=9)
        m: int = dataclasses.field(default=10)
        n: int = dataclasses

# Generated at 2022-06-17 17:56:59.440584
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:57:05.480417
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all


# Generated at 2022-06-17 17:57:15.372737
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test with no undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {}}

    # Test with undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # Test with undefined parameters and default value

# Generated at 2022-06-17 17:57:21.404454
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"a": 1}

# Generated at 2022-06-17 17:57:38.293497
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:57:42.439335
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:57:48.107686
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:57:57.285771
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Generated at 2022-06-17 17:58:03.404503
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int = 1):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 17:58:13.917670
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 17:58:19.837288
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    class B:
        def __init__(self, a: int, b: int, c: int, d: int,
                     e: int = 5):
            pass

    class C:
        def __init__(self, a: int, b: int, c: int, d: int,
                     e: int = 5, f: int = 6):
            pass

    class D:
        def __init__(self, a: int, b: int, c: int, d: int,
                     e: int = 5, f: int = 6, g: int = 7):
            pass


# Generated at 2022-06-17 17:58:27.963495
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"a": 1}



# Generated at 2022-06-17 17:58:36.766256
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = init(1, 2, 3, d=4, e=5)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

# Generated at 2022-06-17 17:58:45.680699
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    known_given_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}


# Generated at 2022-06-17 17:59:17.492144
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:59:23.044561
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all

    test_class = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-17 17:59:25.761558
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:59:30.773002
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Generated at 2022-06-17 17:59:42.600510
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int, m: int,
                     n: int, o: int, p: int, q: int, r: int, s: int, t: int,
                     u: int, v: int, w: int, x: int, y: int, z: int):
            pass

    init_function = _UndefinedParameterAction.create_init(TestClass)
    assert init_function.__name__ == "__init__"
    assert init_function.__doc__ == TestClass.__init__.__doc__
    assert init_function.__module__ == TestClass.__init

# Generated at 2022-06-17 17:59:48.335117
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 17:59:57.813478
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = None

    @dataclass
    class TestClassWithDefault:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    @dataclass
    class TestClassWithDefaultValue:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dict())


# Generated at 2022-06-17 18:00:06.591905
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert _UndefinedParameterAction.handle_from_dict(test_class,
                                                      {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(test_class,
                                                      {"a": 1, "b": 2, "c": 3, "d": 4}) == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:00:12.657255
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    obj = init(1, 2, 3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = init(1, 2, 3, d=4, e=5)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    obj = init(1, 2, 3, d=4, e=5, f=6)


# Generated at 2022-06-17 18:00:14.118468
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:05.621472
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_object = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_object, kvs) == kvs



# Generated at 2022-06-17 18:01:12.249703
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:01:18.932803
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "catch_all": {"a": 1, "b": 2}}
    result = _CatchAllUndefinedParameters.handle_to

# Generated at 2022-06-17 18:01:20.211440
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}

# Generated at 2022-06-17 18:01:23.254025
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}



# Generated at 2022-06-17 18:01:35.433762
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:39.220876
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected = {"a": 1, "b": 2, "c": 3}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 18:01:53.597525
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: CatchAll = None):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
    known, unknown = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert unknown == {"f": 6, "g": 7}


# Generated at 2022-06-17 18:02:05.630525
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init_function = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init_function.__name__ == "__init__"
    assert init_function.__doc__ == TestClass.__init__.__doc__

    # Test that the function is callable
    init_function(TestClass(1, 2, 3, 4, 5))

    # Test that the function is callable with keyword arguments
    init_function(TestClass(1, 2, 3, 4, 5, catch_all=None))

    # Test that the function is callable with keyword arguments

# Generated at 2022-06-17 18:02:08.167041
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 18:04:10.976075
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    kvs = {"a": "a", "b": "b", "c": "c"}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": "a", "b": "b"}
    assert unknown == {"c": "c"}

    kvs = {"a": "a", "b": "b", "c": {"c": "c"}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 18:04:21.298639
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    # Test 1: no undefined parameters
    kvs = {"a": 1, "b": "2"}
    expected = {"a": 1, "b": "2", "c": {}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    # Test 2: undefined parameters
    kvs = {"a": 1, "b": "2", "d": 3}
    expected = {"a": 1, "b": "2", "c": {"d": 3}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    # Test

# Generated at 2022-06-17 18:04:22.309722
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("test")
    assert error.messages == ["test"]

# Generated at 2022-06-17 18:04:34.009152
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(default=3)
        d: int = dataclasses.field(default_factory=lambda: 4)
        e: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": {"f": 5}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3, "d": 4}
    assert unknown == {"e": {"f": 5}}


# Generated at 2022-06-17 18:04:42.994356
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class TestClass(DataClassJsonMixin):
        a: int
        b: int
        c: int
        d: int = config(undefined=Undefined.INCLUDE)

    obj = TestClass(a=1, b=2, c=3)
    kvs = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": {
            "e": 4,
            "f": 5
        }
    }

# Generated at 2022-06-17 18:04:50.516069
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)



# Generated at 2022-06-17 18:04:59.765400
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 18:05:06.811638
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = None

    config.undefined = Undefined.INCLUDE
    test_object = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)

# Generated at 2022-06-17 18:05:14.676663
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}



# Generated at 2022-06-17 18:05:23.243240
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_kvs, unknown_kvs = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known_kvs == {"a": 1, "b": 2}
    assert unknown_kvs == {"c": 3}

    known_kvs, unknown_kvs = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, {})
    assert known_kvs == {}
    assert unknown_kvs == {}
