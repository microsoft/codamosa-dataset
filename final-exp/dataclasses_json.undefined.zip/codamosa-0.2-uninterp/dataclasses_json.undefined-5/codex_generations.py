

# Generated at 2022-06-17 17:56:13.999832
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {}}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # Test 3: Undefined parameters and catch-all field
    k

# Generated at 2022-06-17 17:56:20.083566
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 17:56:28.020958
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test = Test(1, 2, 3, 4)
    init = _IgnoreUndefinedParameters.create_init(Test)
    test2 = Test(1, 2, 3, 4)
    assert test.a == test2.a
    assert test.b == test2.b
    assert test.c == test2.c
    assert test.d == test2.d

    test3 = init(1, 2, 3, 4, e=5, f=6)
    assert test.a == test3.a
    assert test.b == test3.b
    assert test.c == test3.c

# Generated at 2022-06-17 17:56:34.749001
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 17:56:45.087505
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 17:56:51.160715
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: Optional[CatchAllVar] = None

        def __init__(self, a, b, c, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) == TestClass(1, 2, 3, None)
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3, 4)
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3, 4)

# Generated at 2022-06-17 17:56:53.538393
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:56:56.212329
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    test_dict = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, test_dict)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:56:56.971415
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 17:56:58.557726
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:57:20.210440
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

    kvs = {"a": 1, "b": 2}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {}

    kvs = {"a": 1}
    known, unknown = _Undefined

# Generated at 2022-06-17 17:57:25.043701
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    obj = TestClass(a=1, b=2)
    assert _UndefinedParameterAction.handle_dump(obj) == {}



# Generated at 2022-06-17 17:57:27.242397
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 17:57:38.166223
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, d=5)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, d=5, e=6, f=7)
    init(TestClass, 1, 2, 3, 4, d=5, e=6, f=7, g=8)

# Generated at 2022-06-17 17:57:53.016138
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
   

# Generated at 2022-06-17 17:58:04.026594
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, c=3, d=4, e=5) is None
    assert init(TestClass, 1, 2, 3, c=4, d=5) is None
    assert init(TestClass, 1, 2, 3, 4, c=5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, c=6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, c=6, d=7) is None

# Generated at 2022-06-17 17:58:06.205942
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:12.124655
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_object = TestClass(a=1, b=2, c=3)
    kvs = {'a': 1, 'b': 2, 'c': 3}
    assert _UndefinedParameterAction.handle_to_dict(test_object, kvs) == kvs

# Generated at 2022-06-17 17:58:20.180512
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__module__ == TestClass.__init__.__module__

    # noinspection PyTypeChecker
    init(TestClass(1, 2), 3, 4)
    # noinspection PyTypeChecker
    init(TestClass(1, 2), 3, 4, d=5)
    # noinspection PyTypeChecker
    init(TestClass(1, 2), 3, 4, d=5, e=6)
    #

# Generated at 2022-06-17 17:58:23.212033
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:58:54.537511
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 3, d: int = 4):
            pass

    test_class = TestClass(1, 2)
    assert _UndefinedParameterAction.create_init(test_class)(test_class, 1, 2)
    assert _UndefinedParameterAction.create_init(test_class)(test_class, 1, 2,
                                                             3)
    assert _UndefinedParameterAction.create_init(test_class)(test_class, 1, 2,
                                                             3, 4)
    assert _UndefinedParameterAction.create_init(test_class)(test_class, 1, 2,
                                                             d=4)

# Generated at 2022-06-17 17:59:04.360266
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
         18, 19, 20, 21, 22, 23, 24, 25)

# Generated at 2022-06-17 17:59:12.849370
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 17:59:16.741355
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 17:59:27.796008
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}, "f": 5}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 17:59:33.037881
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected

    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 17:59:45.535364
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, a=1, b=2, c=3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, a=1, b=2, c=3, d=4, e=5, f=6,
         g=7, h=8, i=9)

# Generated at 2022-06-17 17:59:56.419582
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = init(TestClass, 1, "b", "c", d=1, e=2)
    assert obj.a == 1
    assert obj.b == "b"
    assert obj.c == {"_UNKNOWN0": "c", "d": 1, "e": 2}

# Generated at 2022-06-17 18:00:06.324483
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.undefined import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 0
        d: Optional[CatchAllVar] = None


# Generated at 2022-06-17 18:00:16.934053
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 18:00:40.822937
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_obj = TestClass(a=1, b=2, c=3, d=4)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:00:45.928546
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8, i=9, j=10, k=11, l=12)

# Generated at 2022-06-17 18:00:55.704140
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = 1
        e: int = 2
        f: int = 3
        g: int = 4
        catch_all: Optional[CatchAllVar] = None

    # Test that the default value is used if no value is given
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 18:01:01.602221
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    def test_function(a: int, b: int, c: int):
        pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__
    assert _UndefinedParameterAction.create_init(test_function) == test_function

# Generated at 2022-06-17 18:01:07.616788
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3)



# Generated at 2022-06-17 18:01:16.606878
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"

# Generated at 2022-06-17 18:01:24.609766
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, c=5, d=6)
    init(TestClass, 1, 2, 3, 4, b=5, c=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6, c=7, d=8)
   

# Generated at 2022-06-17 18:01:26.648184
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:36.741595
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(default=10)
        d: int = dataclasses.field(default=20)
        e: int = dataclasses.field(default=30)
        f: int = dataclasses.field(default=40)
        g: int = dataclasses.field(default=50)
        h: int = dataclasses.field(default=60)
        i: int = dataclasses.field(default=70)
        j: int = dataclasses.field(default=80)
        k: int = dataclasses.field(default=90)
        l: int = dataclasses.field(default=100)

# Generated at 2022-06-17 18:01:37.505599
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 18:02:18.039718
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 18:02:27.185766
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int, m: int,
                     n: int, o: int, p: int, q: int, r: int, s: int, t: int,
                     u: int, v: int, w: int, x: int, y: int, z: int):
            pass

    test_class = TestClass(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                           16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26)
    init_method = _Und

# Generated at 2022-06-17 18:02:36.959492
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 18:02:38.189579
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:42.091589
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 18:02:55.119297
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    # Test _IgnoreUndefinedParameters
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    # Test _CatchAllUndefinedParameters
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass


# Generated at 2022-06-17 18:03:06.490706
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test if default value is used when no undefined parameters are given
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": None}

    # Test if undefined parameters are written to the catch-all field
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 18:03:15.477837
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: CatchAll = dataclasses.field(default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
   

# Generated at 2022-06-17 18:03:16.585628
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:03:26.278957
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"d": 3}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 18:04:57.197457
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:02.173502
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:05:08.278481
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 18:05:18.493275
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_class = TestClass(a=1, b=2, c=3, d=4)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _UndefinedParameterAction.handle_to_dict(test_class, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4}



# Generated at 2022-06-17 18:05:25.320826
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:05:30.480704
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}

    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:05:37.546124
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    init = _UndefinedParameterAction.create_init(test_class)
    assert init(test_class, 1, 2, 3) is None



# Generated at 2022-06-17 18:05:43.418780
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 18:05:55.449046
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=None):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2) is None
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, c=3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, c=4) is None
    assert init(TestClass, 1, 2, c=3, d=4) is None
    assert init(TestClass, 1, 2, 3, c=4, d=5) is None

    init = _IgnoreUndefinedParameters.create_init(TestClass)