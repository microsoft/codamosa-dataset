

# Generated at 2022-06-17 17:56:09.086949
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:17.518656
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_cases = [
        ({"a": 1, "b": 2, "c": 3}, {"a": 1, "b": 2, "c": 3}),
        ({"a": 1, "b": 2, "c": 3, "d": 4}, {"a": 1, "b": 2, "c": 3}),
        ({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}, {"a": 1, "b": 2, "c": 3})
    ]

    for kvs, expected_result in test_cases:
        result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
        assert result == expected_result

# Generated at 2022-06-17 17:56:18.851004
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 17:56:27.059617
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_class = TestClass(a=1, b=2, d={"e": 3, "f": 4})
    kvs = {"a": 1, "b": 2, "d": {"e": 3, "f": 4}}
    kvs_without_d = {"a": 1, "b": 2}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs) == \
           kvs_without_d



# Generated at 2022-06-17 17:56:36.274489
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:56:40.538903
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)

# Generated at 2022-06-17 17:56:50.323973
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 17:56:59.957629
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3, 4, 5)
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3, 4, e=None)
    assert init(TestClass, 1, 2, 3) == TestClass(1, 2, 3, d=None, e=None)
    assert init(TestClass, 1, 2) == TestClass(1, 2, c=None, d=None, e=None)

# Generated at 2022-06-17 17:57:05.816618
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json
    import datetime
    import pytest
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: typing.Optional[datetime.datetime]
        d: typing.Optional[dataclasses_json.CatchAllVar]

    test_class = TestClass(1, "2", datetime.datetime.now(), {})
    init = _CatchAllUndefinedParameters.create_init(test_class)
    init(test_class, 1, "2", datetime.datetime.now(), {})

    with pytest.raises(UndefinedParameterError):
        init(test_class, 1, "2", datetime.datetime.now(), {}, e=1)


# Generated at 2022-06-17 17:57:11.691153
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 17:57:33.953013
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_class = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    test_class = Test

# Generated at 2022-06-17 17:57:37.214923
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:57:40.781977
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    assert _UndefinedParameterAction.handle_dump(obj) == {}

# Generated at 2022-06-17 17:57:50.756281
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:58:02.829311
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:58:09.908260
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}



# Generated at 2022-06-17 17:58:18.792506
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2,
                                                          "c": 3}) == {"a": 1,
                                                                       "b": 2,
                                                                       "c": 3,
                                                                       "catch_all": {}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:27.697970
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"a": 1, "b": 2})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:58:39.293661
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9) is None

# Generated at 2022-06-17 17:58:49.888946
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_object = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_object, kvs) == kvs



# Generated at 2022-06-17 17:59:28.385479
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4}

    test_object = TestClass(a=1, b=2, c=3)


# Generated at 2022-06-17 17:59:34.411925
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:59:45.693103
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
   

# Generated at 2022-06-17 17:59:56.863757
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__annotations__ == TestClass.__init__.__annotations__
    assert init.__module__ == TestClass.__init__.__module__
    assert init.__qualname__ == TestClass.__init__.__qualname__
    assert init.__defaults__ == TestClass.__init__.__defaults__
    assert init.__kwdefaults__ == TestClass.__init__.__kwdefaults__
    assert init.__code__ == TestClass.__init__.__code__
   

# Generated at 2022-06-17 18:00:04.304354
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"f": 6, "g": 7})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

# Generated at 2022-06-17 18:00:15.700600
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    test_class = TestClass(1, 2, 3, 4)
    init_function = _CatchAllUndefinedParameters.create_init(test_class)
    init_function(test_class, 1, 2, 3, 4, e=5, f=6)
    assert test_class.catch_all == {"e": 5, "f": 6}

    init

# Generated at 2022-06-17 18:00:26.356498
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 18:00:30.909503
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}
    test_class.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-17 18:00:41.096943
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "catch_all": {"d": 4, "e": 5}}
    expected_result = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

# Generated at 2022-06-17 18:00:42.069658
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:51.219825
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, d=6, e=7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-17 18:01:56.740027
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 1}

# Generated at 2022-06-17 18:02:08.624505
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = dataclasses.field(default=1)
        e: int = dataclasses.field(default=2)
        f: int = dataclasses.field(default=3)
        g: int = dataclasses.field(default=4)
        h: int = dataclasses.field(default=5)
        i: int = dataclasses.field(default=6)
        j: int = dataclasses.field(default=7)
        k: int = dataclasses.field(default=8)
        l: int = dataclasses.field(default=9)
        m: int = dataclasses.field(default=10)
        n: int = dataclasses

# Generated at 2022-06-17 18:02:17.018903
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:02:18.245962
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:02:27.330127
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow
    from dataclasses_json.utils import CatchAllVar


# Generated at 2022-06-17 18:02:32.400952
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)


# Generated at 2022-06-17 18:02:40.810980
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: str, b: str, c: str, d: str, e: str,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_class = TestClass("a", "b", "c", "d", "e")
    init = _CatchAllUndefinedParameters.create_init(test_class)
    init(test_class, "a", "b", "c", "d", "e")
    assert test_class.a == "a"
    assert test_class.b == "b"
    assert test_class.c == "c"


# Generated at 2022-06-17 18:02:50.015720
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Generated at 2022-06-17 18:03:00.760876
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, 1, 2, 3) is None
    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, 1, 2, 3, 4) is None
    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, 1, 2, 3, 4, 5) is None
    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, 1, 2, 3, 4, 5, 6) is None
    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert _Und

# Generated at 2022-06-17 18:04:34.441006
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args == ("test",)

# Generated at 2022-06-17 18:04:40.740095
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

# Generated at 2022-06-17 18:04:54.805152
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2}) == {
               "a": 1, "b": 2, "c": {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                         {"a": 1, "b": 2,
                                                          "c": {}}) == {
               "a": 1, "b": 2, "c": {}}

# Generated at 2022-06-17 18:05:03.396168
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    assert test_class.a == 1
    assert test_class.b == 2

    # Test that the method raises an error when it encounters an undefined
    # parameter
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                   {"a": 1, "b": 2, "c": 3})

    # Test that the method does not raise an error when it does not encounter
    # an undefined parameter
    _RaiseUndefinedParameters.handle_from_dict(TestClass, {"a": 1, "b": 2})



# Generated at 2022-06-17 18:05:06.340405
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(Foo)
    init(Foo, 1, 2, 3, d=4, e=5)

# Generated at 2022-06-17 18:05:18.277747
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    def test_function(a: int, b: int, c: int, d: int, e: int):
        pass

    for cls in [TestClass, test_function]:
        init = _UndefinedParameterAction.create_init(cls)
        assert init(cls, 1, 2, 3, 4, 5) is None
        assert init(cls, 1, 2, 3, 4, 5, 6) is None
        assert init(cls, 1, 2, 3, 4, 5, 6, 7) is None
        assert init(cls, 1, 2, 3, 4, 5, 6, 7, 8) is None

# Generated at 2022-06-17 18:05:29.728878
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    test_instance = Test

# Generated at 2022-06-17 18:05:41.651722
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _RaiseUndefinedParameters._separate_defined_undefined_kvs(
            TestClass, kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           {"a": 1, "b": 2}

    kvs = {"a": 1, "b": 2}

# Generated at 2022-06-17 18:05:46.704755
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(Test)
    init(Test, 1, 2, 3, 4, e=5)
    init(Test, 1, 2, 3, 4, e=5, f=6)
    init(Test, 1, 2, 3, 4, e=5, f=6, g=7)
    init(Test, 1, 2, 3, 4, e=5, f=6, g=7, h=8)
    init(Test, 1, 2, 3, 4, e=5, f=6, g=7, h=8, i=9)