

# Generated at 2022-06-17 17:56:13.873835
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a: int, b: int, c: typing.Optional[CatchAllVar] =
        None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:56:17.463299
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__



# Generated at 2022-06-17 17:56:25.406279
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all


# Generated at 2022-06-17 17:56:36.327563
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init_function = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

# Generated at 2022-06-17 17:56:43.146779
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}

# Generated at 2022-06-17 17:56:45.577531
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:56:51.962516
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3, "d": 4}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 17:57:00.572815
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8, i=9)

# Generated at 2022-06-17 17:57:10.982329
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}

    # Test that the method raises the correct error
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-17 17:57:12.555769
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:33.869787
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses
    import inspect

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_class = TestClass(1, 2, 3, 4)
    init_signature = inspect.signature(test_class.__init__)
    init_signature_params = list(init_signature.parameters.keys())
    assert init_signature_params == ["self", "a", "b", "c", "d"]

    test_class_init = _IgnoreUndefinedParameters.create_init

# Generated at 2022-06-17 17:57:40.260308
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual



# Generated at 2022-06-17 17:57:54.269781
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_class = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 17:58:04.996561
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init_function = _UndefinedParameterAction.create_init(TestClass)
    assert init_function(TestClass, 1, 2, 3, 4, 5) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9) is None

# Generated at 2022-06-17 17:58:11.363094
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = MyClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:58:17.297736
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}

# Generated at 2022-06-17 17:58:29.255373
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, "b")
    assert test_class.a == 1
    assert test_class.b == "b"
    assert test_class.c is None

    test_class = TestClass(1, "b", {"c": "c"})
    assert test_class.a == 1
    assert test_class.b == "b"
    assert test_class.c == {"c": "c"}



# Generated at 2022-06-17 17:58:41.004207
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str, c: str,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": "b", "c": "c"}) == {"a": 1, "b": "b", "c": "c",
                                                     "catch_all": {}}

    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:45.766051
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {'a': 1, 'b': 2, 'c': 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs

# Generated at 2022-06-17 17:58:51.354003
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Unit test

# Generated at 2022-06-17 17:59:17.728263
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs

# Generated at 2022-06-17 17:59:24.123074
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int):
            pass

    init_func = _IgnoreUndefinedParameters.create_init(TestClass)
    init_func(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 17:59:29.829304
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs={"a": 1, "b": 2, "c": 3, "d": 4})
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:59:35.313049
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 1
        d: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 1, "d": None}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "e": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 17:59:46.073686
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:59:46.854455
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:59:48.694433
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a, b, c, d):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 17:59:49.612825
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:00:01.090737
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Unit test

# Generated at 2022-06-17 18:00:03.446986
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 18:00:49.473758
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:00.461313
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"d": 3}}
    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "d": 3}) == {"a": 1, "b": 2, "c": {"d": 3}}
    # noinspection PyTypeChecker
    assert _C

# Generated at 2022-06-17 18:01:05.023343
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 3
        d: int = 4
        e: CatchAll = None


# Generated at 2022-06-17 18:01:14.440541
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1}

# Generated at 2022-06-17 18:01:23.842859
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class TestClass(DataClassJsonMixin):
        a: int
        b: int
        c: Optional[CatchAllVar] = field(default=None)

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefined

# Generated at 2022-06-17 18:01:26.599786
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-17 18:01:34.860867
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 18:01:41.549143
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:01:54.308056
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_obj = TestClass(catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
        "a": 1, "b": 2}

    test_obj = TestClass(catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 18:01:59.730005
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:03:44.768826
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class = TestClass(1, 2, 3)
    init = _UndefinedParameterAction.create_init(test_class)
    init(test_class, 1, 2, 3)

    init = _RaiseUndefinedParameters.create_init(test_class)
    init(test_class, 1, 2, 3)

    init = _IgnoreUndefinedParameters.create_init(test_class)
    init(test_class, 1, 2, 3)

    init = _CatchAllUndefinedParameters.create_init(test_class)
    init(test_class, 1, 2, 3)

# Generated at 2022-06-17 18:03:52.411215
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == expected



# Generated at 2022-06-17 18:04:00.641066
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    kvs = {"a": 1, "b": "b", "c": "c"}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": "b"}
    assert unknown == {"c": "c"}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)



# Generated at 2022-06-17 18:04:06.023755
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:04:11.786477
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 18:04:13.453604
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:15.287234
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:16.554013
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:21.997003
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, _ = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:04:28.080063
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": "2", "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2", "c": {"d": 3}}

    kvs = {"a": 1, "b": "2", "c": {"d": 3}, "e": 4}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2", "c": {"d": 3, "e": 4}}
