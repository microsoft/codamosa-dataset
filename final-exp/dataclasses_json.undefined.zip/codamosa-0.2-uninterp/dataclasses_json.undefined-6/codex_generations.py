

# Generated at 2022-06-17 17:56:17.141739
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None

# Generated at 2022-06-17 17:56:17.818219
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 17:56:24.528290
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected_result = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == expected_result



# Generated at 2022-06-17 17:56:29.827779
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    test_dict = {"a": 1, "b": 2, "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, test_dict)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:56:41.644759
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}


# Generated at 2022-06-17 17:56:46.402392
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:56:53.245973
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c, d=1, e=2, f=3):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__module__ == TestClass.__module__



# Generated at 2022-06-17 17:56:54.679082
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:02.866292
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all


# Generated at 2022-06-17 17:57:10.272435
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _UndefinedParameterAction.handle_to_dict(test_obj, kvs)
    assert kvs_actual == kvs_expected



# Generated at 2022-06-17 17:57:32.304989
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass


# Generated at 2022-06-17 17:57:33.866691
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:43.544459
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 17:57:49.814460
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, d=4) is None

    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int


# Generated at 2022-06-17 17:58:01.887543
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3


# Generated at 2022-06-17 17:58:08.995029
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_class = TestClass(1, 2)
    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        test_class, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

# Generated at 2022-06-17 17:58:18.249771
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    test_object = init(TestClass, 1, "a", "b", c={"d": "e"})
    assert test_object.a == 1
    assert test_object.b == "a"
    assert test_object.c == {"_UNKNOWN0": "b", "d": "e"}


# Generated at 2022-06-17 17:58:29.979235
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:58:40.272644
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 17:58:44.420726
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("This is a test")
    except UndefinedParameterError as e:
        assert e.args[0] == "This is a test"

# Generated at 2022-06-17 17:59:13.595185
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": "b", "c": "c"}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": "b"}
    assert unknown == {"c": "c"}



# Generated at 2022-06-17 17:59:19.374985
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"

    # Test that the init function is called correctly
    # with the correct number of arguments
    init(TestClass(1, 2, 3, 4, 5))
    init(TestClass(1, 2, 3, 4, 5, catch_all={}))
    init(TestClass(1, 2, 3, 4, 5, catch_all={"a": 1}))

    # Test that the init function is called correctly
    # with the correct number of arguments

# Generated at 2022-06-17 17:59:28.738209
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.undefined import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 3
        d: int = 4
        e: int = 5
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:59:34.632829
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:59:45.768256
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, {"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert kvs_actual == kvs_expected



# Generated at 2022-06-17 17:59:51.494818
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == kvs

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-17 18:00:03.492786
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int, m: int,
                     n: int, o: int, p: int, q: int, r: int, s: int, t: int,
                     u: int, v: int, w: int, x: int, y: int, z: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass


# Generated at 2022-06-17 18:00:14.960363
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)


# Generated at 2022-06-17 18:00:18.973914
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)

# Generated at 2022-06-17 18:00:27.106795
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:01:14.582617
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args == ("Test",)

# Generated at 2022-06-17 18:01:23.839893
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    kvs = {"a": 1, "b": 2}

# Generated at 2022-06-17 18:01:35.671499
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=3):
            pass

    def _test(action: _UndefinedParameterAction,
              kvs: Dict[str, Any],
              expected: Dict[str, Any]):
        result = action.handle_from_dict(TestClass, kvs)
        assert result == expected

    _test(action=_RaiseUndefinedParameters,
          kvs={"a": 1, "b": 2, "c": 3},
          expected={"a": 1, "b": 2, "c": 3})

    _test(action=_RaiseUndefinedParameters,
          kvs={"a": 1, "b": 2, "c": 3, "d": 4},
          expected={"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-17 18:01:45.457583
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    @dataclass
    class TestClass2:
        a: int
        b: int
        c: Optional[CatchAllVar] = None
        d: int = 1

    @dataclass
    class TestClass3:
        a: int
        b: int
        c: Optional[CatchAllVar] = None
        d: int = 1

        def __post_init__(self):
            self.d = self.d + 1

    @dataclass
    class TestClass4:
        a: int
        b: int
        c: Optional[CatchAllVar] = None
        d: int = 1


# Generated at 2022-06-17 18:01:52.893090
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}
    test_class.catch_all = {"a": 1}
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-17 18:01:58.053351
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:02:00.450473
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:02:11.843447
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    test_dict = {"a": 1, "b": "2", "c": {"d": 3}, "e": 4}

    # Test that the default value is not overwritten if no undefined
    # parameters are given
    default_value = {"d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                           {"a": 1, "b": "2",
                                                            "c": default_value})
    assert result["c"] == default_value

    # Test that the default value is

# Generated at 2022-06-17 18:02:16.896612
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, a=1, b=2, c=3, d=4)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-17 18:02:26.340661
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"

# Generated at 2022-06-17 18:04:22.638174
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:34.147775
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, c=5, d=6)
    init(TestClass, 1, 2, 3, 4, b=5, c=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6)
    init(TestClass, 1, 2, 3, 4, a=5, b=6, c=7, d=8)
   

# Generated at 2022-06-17 18:04:35.987858
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 18:04:44.536735
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        def __init__(self, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r,
                     s, t, u, v, w, x, y, z, catch_all: Optional[CatchAllVar] =
                     None):
            pass

    init = _UndefinedParameterAction.create_init(Test)

# Generated at 2022-06-17 18:04:55.971928
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:04:57.028518
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 18:05:05.021448
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4}

    test_obj = TestClass(a=1, b=2, c=3)


# Generated at 2022-06-17 18:05:16.177956
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2, "c": {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           expected

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    expected = {"a": 1, "b": 2, "c": {"d": 3}}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           expected

    # Test 3: Undefined parameters and default

# Generated at 2022-06-17 18:05:22.549481
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int = 1):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 18:05:24.283142
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}