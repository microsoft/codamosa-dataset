

# Generated at 2022-06-17 17:56:16.012362
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a, b, c, d=None):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:56:25.573690
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: Optional[CatchAllVar] = None

        def __init__(self, a, b, c, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = init(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

# Generated at 2022-06-17 17:56:33.549939
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 17:56:38.933419
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}


# Generated at 2022-06-17 17:56:43.718031
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 17:56:52.441918
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

    test_class.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}



# Generated at 2022-06-17 17:56:58.064287
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = init(1, 2, 3, d=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3



# Generated at 2022-06-17 17:57:03.711955
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": {"a": 1, "b": 2}}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    expected = {"a": 1, "b": 2, "a": 1, "b": 2}
    assert result == expected



# Generated at 2022-06-17 17:57:13.263001
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 17:57:20.842177
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init_function = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:57:56.252932
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)

# Generated at 2022-06-17 17:58:05.989862
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    tc = TestClass(1, 2, 3)
    assert tc.a == 1
    assert tc.b == 2
    assert tc.c == 3

    tc = TestClass(1, 2, 3, d=4)
    assert tc.a == 1
    assert tc.b == 2
    assert tc.c == 3

    tc = TestClass(1, 2, 3, d=4, e=5)
    assert tc.a == 1
    assert tc.b == 2
    assert tc.c == 3


# Generated at 2022-06-17 17:58:15.935398
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:58:28.516990
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import dataclasses_json
    import dataclasses_json.config
    import dataclasses_json.undefined

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: dataclasses_json.undefined.CatchAll

    test_instance = TestClass(a=1, b=2, c={"x": "y"})
    config = dataclasses_json.config.Config()
    config.undefined = dataclasses_json.undefined.Undefined.EXCLUDE
    config.letter_case = dataclasses_json.config.LetterCase.CAMEL
    schema = dataclasses_json.config.schema_from_dataclass(
        dataclass=TestClass, config=config)

# Generated at 2022-06-17 17:58:35.425635
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == kvs

# Generated at 2022-06-17 17:58:44.548411
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses
    import dataclasses_json
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: typing.Optional[dataclasses_json.CatchAllVar]

    test_class = TestClass(1, "a", None)
    test_class_init = _UndefinedParameterAction.create_init(test_class)
    assert test_class_init(test_class, 1, "a") is None
    assert test_class_init(test_class, 1, "a", c={}) is None
    assert test_class_init(test_class, 1, "a", c={"d": 1}) is None
    assert test_class_init(test_class, 1, "a", d=1) is None
    assert test_

# Generated at 2022-06-17 17:58:56.634929
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: CatchAll = dataclasses.field(
            default_factory=dict)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:59:02.862919
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:59:14.369038
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass(1, 2, 3), 4, 5, 6, d=7) == TestClass(1, 2, 3)
    assert init(TestClass(1, 2, 3), 4, 5, 6, d=7, e=8) == TestClass(1, 2, 3)

# Generated at 2022-06-17 17:59:18.781551
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class Test(DataClassJsonMixin):
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    t = Test(1, 2, {"d": 3, "e": 4})
    assert config.undefined.handle_to_dict(t, {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}) == {"a": 1, "b": 2, "d": 3, "e": 4}

# Generated at 2022-06-17 18:00:14.173274
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})

    init = _CatchAllUndefinedParameters.create_init

# Generated at 2022-06-17 18:00:21.414337
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8, i=9)

# Generated at 2022-06-17 18:00:26.591107
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0, d: int = 0):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 18:00:32.978419
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3


# Generated at 2022-06-17 18:00:42.460310
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Generated at 2022-06-17 18:00:47.141921
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(Test)
    init(Test, 1, 2, 3, d=4, e=5)
    init(Test, 1, 2, 3, 4, 5)
    init(Test, 1, 2, 3, 4, 5, d=6, e=7)
    init(Test, 1, 2, 3, 4, 5, 6, 7)
    init(Test, 1, 2, 3, 4, 5, 6, 7, d=8, e=9)
    init(Test, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 18:00:56.131575
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:01.970388
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=3, d=4):
            pass

    assert _UndefinedParameterAction.create_init(TestClass) == TestClass.__init__
    assert _IgnoreUndefinedParameters.create_init(TestClass) != TestClass.__init__
    assert _CatchAllUndefinedParameters.create_init(TestClass) != TestClass.__init__

# Generated at 2022-06-17 18:01:09.211679
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(a=1, b=2, c=3, d=4)
    assert _UndefinedParameterAction.handle_dump(obj) == {}



# Generated at 2022-06-17 18:01:17.518336
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, e=5)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 18:02:46.640516
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 18:02:50.041422
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:02:55.428753
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init_with_undefined_parameters = \
        _IgnoreUndefinedParameters.create_init(TestClass)
    test_class_with_undefined_parameters = \
        init_with_undefined_parameters(1, 2, 3, d=4, e=5)
    assert test_class_with_undefined_

# Generated at 2022-06-17 18:03:01.119936
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

# Generated at 2022-06-17 18:03:09.076862
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 3,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_object = TestClass(a=1, b=2, d={"e": 5})
    assert _CatchAllUndefinedParameters.handle_dump(test_object) == {"e": 5}

# Generated at 2022-06-17 18:03:15.940732
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    test_obj = TestClass(1, 2, 3, 4, 5)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 18:03:17.424575
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:03:20.202155
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 18:03:24.018466
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs



# Generated at 2022-06-17 18:03:30.443512
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 18:05:42.057374
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_kvs = {"a": 1, "b": 2, "c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == \
           known_kvs


# Generated at 2022-06-17 18:05:54.144577
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect

    class Test:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(Test)
    assert inspect.signature(init) == inspect.signature(Test.__init__)

    t = Test(1, 2, 3)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3

    t = Test(1, 2, 3, d=4)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3

    t = Test(1, 2, 3, d=4, e=5)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3
