

# Generated at 2022-06-17 17:56:16.697431
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.config import Config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    config = Config(undefined=Undefined.INCLUDE)

    # No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs

    # One undefined parameter
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-17 17:56:26.061924
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, d=4) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, d=4, e=5) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, d=4, e=5, f=6) == TestClass(1, 2, 3)


# Generated at 2022-06-17 17:56:37.310240
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3


# Generated at 2022-06-17 17:56:38.782887
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:39.910539
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 17:56:53.680041
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}
    assert _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs) == \
           {"a": 1, "b": 2}

    kvs = {"a": 1, "b": 2}
    assert _

# Generated at 2022-06-17 17:56:58.949573
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, a=1, b=2, c=3, d=4, e=5)
    init(TestClass, 1, 2, 3, 4, 5, a=1, b=2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-17 17:57:05.152536
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    test_class = TestClass(1, 2)
    assert test_class.c == {}

    test_class = TestClass(1, 2, {"d": 3})
    assert test_class.c == {"d": 3}

    test_class = TestClass(1, 2, c={"d": 3})
    assert test_class.c == {"d": 3}

    test_class = TestClass(1, 2, c={"d": 3, "e": 4})
    assert test_class.c == {"d": 3, "e": 4}

    test_class = TestClass(1, 2, {"d": 3, "e": 4})
    assert test_

# Generated at 2022-06-17 17:57:13.302177
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-17 17:57:18.504519
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs

# Generated at 2022-06-17 17:57:42.610807
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        _catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:57:49.452903
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    def test_case(kvs: Dict[str, Any], expected: Dict[str, Any]):
        result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert result == expected

    test_case(kvs={"a": 1, "b": 2, "c": 3}, expected={"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-17 17:58:01.419055
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, d=5)
    init(TestClass, 1, 2, 3, 4, d=5, e=6)
    init(TestClass, 1, 2, 3, 4, d=5, e=6, f=7)
    init(TestClass, 1, 2, 3, 4, d=5, e=6, f=7, g=8)

# Generated at 2022-06-17 17:58:09.231182
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:58:14.956570
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a=1, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

    test_instance = TestClass()
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_instance, kvs) == kvs



# Generated at 2022-06-17 17:58:28.063429
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": {"d": 3}}) == {"a": 1, "b": 2,
                                                        "c": {"d": 3}}
    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:58:40.028677
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}

# Generated at 2022-06-17 17:58:54.546646
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    kvs_after = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)

# Generated at 2022-06-17 17:59:01.175430
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

    test_class.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {
        "test": "test"}

# Generated at 2022-06-17 17:59:12.085130
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, d=4) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4, 5, d=6) == TestClass(1, 2, 3)



# Generated at 2022-06-17 17:59:35.751291
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    test_dict = {"a": 1, "b": 2, "c": 3}
    expected_dict = {"a": 1, "b": 2}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, test_dict)
    assert result == expected_dict



# Generated at 2022-06-17 17:59:46.358139
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     _undefined: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self._undefined = _undefined

    test_class = TestClass(1, 2, 3, _undefined={"a": "b"})
    kvs = {"a": 1, "b": 2, "c": 3, "_undefined": {"a": "b"}}
    kvs_after = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)
    assert kvs_after == {"a": 1, "b": 2, "c": 3, "a": "b"}



# Generated at 2022-06-17 17:59:49.450876
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 17:59:58.108454
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: str, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    obj = TestClass("a", 1, "c", 2, catch_all={"e": 3, "f": 4})
    kvs = {"a": "a", "b": 1, "c": "c", "d": 2, "e": 3, "f": 4}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

# Generated at 2022-06-17 17:59:59.776683
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:00:08.301157
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnresolvedReferences
    from dataclasses_json.undefined import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

   

# Generated at 2022-06-17 18:00:14.648860
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:00:19.235180
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:00:27.151077
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:00:39.262140
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"f": 6, "g": 7})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

# Generated at 2022-06-17 18:01:16.739360
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:01:24.662078
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str, c: str = "default"):
            pass

    kvs = {"a": 1, "b": "b"}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == kvs

    kvs = {"a": 1, "b": "b", "c": "c"}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == kvs

    kvs = {"a": 1, "b": "b", "c": "c", "d": "d"}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == kvs



# Generated at 2022-06-17 18:01:35.753022
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3)
    init(TestClass, 1, 2, 3, d=4)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 18:01:41.971306
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    obj = TestClass(a=1, b=2)
    kvs = {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:01:52.693635
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, _ = \
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:02:01.687516
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9) is None

# Generated at 2022-06-17 18:02:12.593437
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

    # noinspection PyTypeChecker

# Generated at 2022-06-17 18:02:18.810740
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected_result = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, kvs)
    assert result == expected_result



# Generated at 2022-06-17 18:02:27.707536
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = None

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "catch_all": {"d": 4, "e": 5}}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    assert _UndefinedParameterAction.handle_to_dict(test_object, kvs) == kvs_expected
    assert _Ign

# Generated at 2022-06-17 18:02:32.921189
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)

# Generated at 2022-06-17 18:03:53.653689
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected = {"a": 1, "b": 2, "c": 3}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 18:03:58.533320
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})

    init = _CatchAllUndefinedParameters.create_init

# Generated at 2022-06-17 18:04:02.396228
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)



# Generated at 2022-06-17 18:04:08.460983
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}



# Generated at 2022-06-17 18:04:11.375617
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj.catch_all["test"] = "test"
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"test": "test"}



# Generated at 2022-06-17 18:04:14.380790
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 18:04:15.841816
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:19.844882
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {"a": 1, "c": 2})



# Generated at 2022-06-17 18:04:26.608418
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"c": 3}}

    kvs = {"a": 1, "b": 2, "c": {"c": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"c": 3}}


# Generated at 2022-06-17 18:04:33.510149
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters = _RaiseUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}

