

# Generated at 2022-06-17 17:56:08.542939
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test")

# Generated at 2022-06-17 17:56:14.577376
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: str, c: str):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass("a", "b", "c")
    kvs = {"a": "a", "b": "b", "c": "c"}
    assert _UndefinedParameterAction.handle_to_dict(test_class, kvs) == kvs



# Generated at 2022-06-17 17:56:24.693357
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 0
        d: Optional[CatchAllVar] = None

    def test_case(kvs: Dict[str, Any], expected: Dict[str, Any]):
        actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert actual == expected

    test_case(kvs={"a": 1, "b": 2, "c": 3},
              expected={"a": 1, "b": 2, "c": 3, "d": {}})

# Generated at 2022-06-17 17:56:32.164753
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    known_parameters, unknown_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(test_class,
                                                    {"a": 1, "b": 2, "c": 3,
                                                     "d": 4})
    assert known_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_parameters == {"d": 4}



# Generated at 2022-06-17 17:56:43.278665
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    expected = {"a": 1, "b": 2, "c": {"d": 3}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1, "b": 2, "d": 3}
    expected = {"a": 1, "b": 2, "c": {"d": 3}}
    actual = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual


# Generated at 2022-06-17 17:56:44.108475
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:56:55.759395
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)


# Generated at 2022-06-17 17:57:02.162511
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4}

# Generated at 2022-06-17 17:57:06.118315
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {"a": 1, "c": 2})



# Generated at 2022-06-17 17:57:12.557046
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

    test_class.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-17 17:57:26.044371
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:37.036025
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar]

    test_class = TestClass(a=1, b="test", c={})
    assert test_class.c == {}

    test_class = TestClass(a=1, b="test", c={"a": 1})
    assert test_class.c == {"a": 1}

    test_class = TestClass(a=1, b="test", c={"a": 1, "b": 2})
    assert test_class.c == {"a": 1, "b": 2}

    test_class = TestClass(a=1, b="test", c={"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-17 17:57:45.212042
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int):
            pass

    init_func = _IgnoreUndefinedParameters.create_init(TestClass)
    init_func(TestClass, 1, 2, 3, 4, 5)
    init_func(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    init_func(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, a=1, b=2, c=3, d=4,
              e=5)
    init_func(TestClass, 1, 2, 3, 4, 5, a=1, b=2, c=3, d=4, e=5)
    init_

# Generated at 2022-06-17 17:57:56.096724
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int, m: int,
                     n: int, o: int, p: int, q: int, r: int, s: int, t: int,
                     u: int, v: int, w: int, x: int, y: int, z: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)

# Generated at 2022-06-17 17:57:58.552380
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:58:03.360695
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    obj = TestClass({"a": 1, "b": 2})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 1, "b": 2}

# Generated at 2022-06-17 17:58:14.200753
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, a=4, b=5, c=6)
    init(TestClass, 1, 2, 3, a=4, b=5, c=6, d=7)
    init(TestClass, 1, 2, 3, a=4, b=5, c=6, d=7, e=8)
    init(TestClass, 1, 2, 3, a=4, b=5, c=6, d=7, e=8, f=9)

# Generated at 2022-06-17 17:58:21.397997
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass


# Generated at 2022-06-17 17:58:23.265783
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:32.894589
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    # Test that the method raises an error if there are unknown parameters
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)

    # Test that the method does not raise an error if there are no unknown
    # parameters

# Generated at 2022-06-17 17:59:04.791225
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_class = TestClass(1, 2, 3, 4)
    init = _IgnoreUndefinedParameters.create_init(test_class)
    init(test_class, 1, 2, 3, 4)
    init(test_class, 1, 2, 3, 4, e=5)
    init(test_class, 1, 2, 3, 4, e=5, f=6)

# Generated at 2022-06-17 17:59:13.400458
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar]

    test_object = TestClass(a=1, b=2, c={"d": 3, "e": 4})
    kvs = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
               "a": 1, "b": 2, "d": 3, "e": 4}

# Generated at 2022-06-17 17:59:16.169249
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    obj = TestClass(1, 2)
    assert _UndefinedParameterAction.handle_dump(obj) == {}

# Generated at 2022-06-17 17:59:19.442129
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 17:59:28.771765
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert kvs_actual == kvs_expected

    test_obj = TestClass(1, 2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 17:59:30.326525
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:59:31.153576
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:59:43.089087
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, a=1, b=2, c=3, d=4, e=5)
    init(TestClass, 1, 2, 3, 4, 5, a=1, b=2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-17 17:59:55.935060
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters = _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                                  kvs)
    assert known_parameters == {"a": 1, "b": 2}

    kvs = {"a": 1, "b": 2}
    known_parameters = _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                                  kvs)
    assert known_parameters == {"a": 1, "b": 2}

    kvs = {"a": 1}

# Generated at 2022-06-17 18:00:05.217518
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    config.undefined = Undefined.EXCLUDE
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = init(TestClass, 1, 2, 3, d=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

# Generated at 2022-06-17 18:00:59.986937
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class TestClass:
        a: int
        b: Optional[CatchAllVar] = None

    @dataclass
    class TestClassWithDefault:
        a: int
        b: Optional[CatchAllVar] = None
        c: int = 1

    @dataclass
    class TestClassWithDefaultFactory:
        a: int
        b: Optional[CatchAllVar] = None
        c: int = dataclasses.field(default_factory=lambda: 1)

    @dataclass
    class TestClassWithDefaultAndDefaultFactory:
        a: int
        b: Optional[CatchAllVar] = None
        c: int = 1

# Generated at 2022-06-17 18:01:06.937934
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, *,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    @dataclasses.dataclass
    class TestDataclass:
        a: int
        b: int
        c: int
        catch_all: Optional[CatchAllVar] = None

    for cls in [TestClass, TestDataclass]:
        # Test that the default value is used if no undefined parameters are
        # given
        kvs = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 18:01:16.012767
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}


# Generated at 2022-06-17 18:01:18.465825
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args == ("test",)

# Generated at 2022-06-17 18:01:25.414231
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, a=1, b=2, c=3, d=4)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, a=1, b=2, c=3, d=4, e=5, f=6, g=7,
         h=8)

# Generated at 2022-06-17 18:01:36.040911
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Generated at 2022-06-17 18:01:36.812982
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 18:01:47.096130
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: float

        def __init__(self, a: int, b: str, c: float):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert init.__doc__ == TestClass.__init__.__doc__
    assert init.__signature__ == TestClass.__init__.__signature__
    assert init.__annotations__ == TestClass.__init__.__annotations__

    # noinspection PyArgumentList
    instance = TestClass(1, "2", 3.0)
    assert instance.a == 1

# Generated at 2022-06-17 18:01:53.568249
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:02:05.631090
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)

# Generated at 2022-06-17 18:03:53.156048
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 18:04:01.286731
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_expected = {"a": 1, "b": 2, "c": 3}
    kvs_actual = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert kvs_actual == kvs_expected



# Generated at 2022-06-17 18:04:06.683343
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    kvs = {"a": 1, "b": "2", "c": 3}
    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known_parameters == {"a": 1, "b": "2"}



# Generated at 2022-06-17 18:04:17.100725
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:04:24.935041
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    known, unknown = _UndefinedParameterAction.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3, "d": 4})
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {}

    known, unknown = _UndefinedParameterAction.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5})
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4, "e": 5}



# Generated at 2022-06-17 18:04:35.334942
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:04:36.692032
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:04:44.750667
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {}}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # Test 3: Undefined parameters and default value

# Generated at 2022-06-17 18:04:48.857643
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 18:04:58.975020
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)
        assert False
    except UndefinedParameterError:
        pass

    kvs = {"a": 1, "b": 2}
    known_parameters, unknown_parameters = \
        _