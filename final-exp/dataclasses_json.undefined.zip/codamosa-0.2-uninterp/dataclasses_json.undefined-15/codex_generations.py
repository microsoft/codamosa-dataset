

# Generated at 2022-06-17 17:56:22.614811
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a, b, c):
            pass

    class B:
        def __init__(self, a, b, c, **kwargs):
            pass

    class C:
        def __init__(self, a, b, c, *args):
            pass

    class D:
        def __init__(self, a, b, c, *args, **kwargs):
            pass

    class E:
        def __init__(self, a, b, c, *, d):
            pass

    class F:
        def __init__(self, a, b, c, *, d, **kwargs):
            pass

    class G:
        def __init__(self, a, b, c, *args, d):
            pass


# Generated at 2022-06-17 17:56:31.567220
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs_actual == kvs

# Generated at 2022-06-17 17:56:42.973405
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    known, unknown = _UndefinedParameterAction.handle_from_dict(
        TestClass, {"a": 1, "b": 2, "c": 3})
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

    known, unknown = _UndefinedParameterAction.handle_from_dict(
        TestClass, {"a": 1, "b": 2})
    assert known == {"a": 1, "b": 2}
    assert unknown == {}

    known, unknown = _UndefinedParameterAction.handle_from_dict(
        TestClass, {"a": 1})
    assert known == {"a": 1}
    assert unknown == {}

    known, unknown = _UndefinedParameterAction.handle

# Generated at 2022-06-17 17:56:49.501219
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker

# Generated at 2022-06-17 17:56:58.184216
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:57:03.549343
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c, d, e):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    # Test that the original init is returned if no action is specified
    init = _UndefinedParameterAction.create_init(TestClass)
    assert init.__name__ == "__init__"

    # Test that the original init is returned if action is set to RAISE
    init = _RaiseUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"

    # Test that the original init is returned if action is set to EXCLUDE
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init.__name__

# Generated at 2022-06-17 17:57:04.873183
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:57:14.748116
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test that the default value is used if no undefined parameters are given
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": None}

    # Test that the default value is used if no undefined parameters are given
    # and the default value is not None
    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = {}

    kvs = {"a": 1, "b": 2}

# Generated at 2022-06-17 17:57:21.581650
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)

# Generated at 2022-06-17 17:57:28.071840
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    test_dict = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, test_dict)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 17:57:48.559316
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 17:58:00.421840
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, d=4, catch_all={"e": 5, "f": 6})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)

# Generated at 2022-06-17 17:58:05.240954
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-17 17:58:09.856257
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-17 17:58:14.335089
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)



# Generated at 2022-06-17 17:58:15.824629
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:58:28.383617
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)

# Generated at 2022-06-17 17:58:40.507236
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None

# Generated at 2022-06-17 17:58:54.822408
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3, 4)
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3, 4)
    assert init(TestClass, 1, 2, 3, 4, 5, 6) == TestClass(1, 2, 3, 4)

# Generated at 2022-06-17 17:59:04.434899
# Unit test for method create_init of class _CatchAllUndefinedParameters

# Generated at 2022-06-17 17:59:30.981614
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_class = TestClass(catch_all={'a': 1, 'b': 2})
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {'a': 1,
                                                                    'b': 2}
    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

# Generated at 2022-06-17 17:59:38.542500
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_instance = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_instance, kvs) == kvs



# Generated at 2022-06-17 17:59:45.038175
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 17:59:56.664880
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3)
    init(TestClass, 1, 2, 3, d=4)
    init(TestClass, 1, 2, 3, d=4, e=5)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, d=4, e=5, f=6, g=7, h=8)

# Generated at 2022-06-17 18:00:06.503787
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, {"a": 1,
                                                                     "b": 2}) == {
               "a": 1, "b": 2, "c": None}
    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, {"a": 1,
                                                                     "b": 2,
                                                                     "c": None}) == {
               "a": 1, "b": 2, "c": None}
    # noinspection PyTypeChecker
    assert _

# Generated at 2022-06-17 18:00:09.173106
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 18:00:10.231226
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 18:00:19.300404
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.undefined import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 1
        d: CatchAllVar = None

    # Test 1:
    # Test that the default value is returned if no other value is given
    # and no other parameters are given
    kvs = {}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": None, "b": None, "c": 1, "d": None}

    # Test 2:
    # Test that the default value is returned if no other value is given
    # and other parameters are given
    kvs = {"a": 1, "b": 2}
    result = _C

# Generated at 2022-06-17 18:00:26.650663
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj = TestClass(a=1, b=2)
    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2}
    actual = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert expected == actual



# Generated at 2022-06-17 18:00:31.021531
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    # noinspection PyTypeChecker
    _UndefinedParameterAction.create_init(TestClass)(TestClass, 1, 2, 3, 4)
    # noinspection PyTypeChecker
    _UndefinedParameterAction.create_init(TestClass)(TestClass, 1, 2, 3, 4, 5)
    # noinspection PyTypeChecker
    _UndefinedParameterAction.create_init(TestClass)(TestClass, 1, 2, 3, 4, 5,
                                                     6)
    # noinspection PyTypeChecker
    _UndefinedParameterAction.create_init(TestClass)(TestClass, 1, 2, 3, 4, 5,
                                                     6, 7)
   

# Generated at 2022-06-17 18:01:24.583165
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        aa: int
        ab: int
        ac: int
        ad: int
        ae: int
        af: int
        ag: int
        ah: int
        ai: int
        aj: int

# Generated at 2022-06-17 18:01:35.712202
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})

    init = _CatchAllUndefinedParameters.create_init

# Generated at 2022-06-17 18:01:45.498934
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:53.421579
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}



# Generated at 2022-06-17 18:01:59.354448
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(test_class, kvs) == kvs



# Generated at 2022-06-17 18:02:06.615284
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:02:17.304010
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:02:26.694070
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, 5)
    init(TestClass, 1, 2, 3, 4, 5, 6)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-17 18:02:37.130868
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_kvs, unknown_kvs = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_kvs == {"a": 1, "b": 2}
    assert unknown_kvs == {"c": 3}

    known_kvs = _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                            kvs=kvs)
    assert known_kvs == {"a": 1, "b": 2}



# Generated at 2022-06-17 18:02:45.965271
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0, d: int = 0):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:04:52.414965
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:04:59.308820
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    init_signature = inspect.signature(TestClass.__init__)
    init_signature_params = list(init_signature.parameters.keys())
    assert init_signature_params == ["self", "a", "b", "c"]

    init_function = _IgnoreUndefinedParameters.create_init(TestClass)
    init_function_signature = inspect.signature(init_function)
    init_function_signature_params = list(
        init_function_signature.parameters.keys())
   

# Generated at 2022-06-17 18:05:03.182781
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    kvs = {"a": 1, "b": "2", "c": 3}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": "2"}



# Generated at 2022-06-17 18:05:12.937810
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all


# Generated at 2022-06-17 18:05:22.640262
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:05:30.133035
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2, 3, 4) == None
    assert init(TestClass, 1, 2, 3, 4, 5) == None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) == None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) == None



# Generated at 2022-06-17 18:05:41.839981
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == kvs
    assert unknown == {}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"d": 3}

    # Test

# Generated at 2022-06-17 18:05:43.845217
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:55.676639
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: CatchAll = dataclasses.field(default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
   