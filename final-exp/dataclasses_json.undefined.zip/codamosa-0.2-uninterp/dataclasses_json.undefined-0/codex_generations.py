

# Generated at 2022-06-17 17:56:22.572065
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: typing.Optional[CatchAllVar]

        def __init__(self, a: int, b: str, c: typing.Optional[CatchAllVar] =
        None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:56:31.527737
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4, e=5, f=6)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8)
    init(TestClass, 1, 2, 3, 4, e=5, f=6, g=7, h=8, i=9)

# Generated at 2022-06-17 17:56:42.929872
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses
    from typing import Optional

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        aa: int
        bb: int
        cc: int
        dd: int
        ee: int
        ff: int
        gg: int
        h

# Generated at 2022-06-17 17:56:48.370475
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-17 17:56:49.891307
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-17 17:56:59.628463
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, kvs) == {
        "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 17:57:05.605025
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})

        def __init__(self, a, b, c, d, e, catch_all=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:57:16.163450
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, d=4, e=5,
                              catch_all={"f": 6, "g": 7})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

# Generated at 2022-06-17 17:57:27.114737
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_kvs, unknown_kvs = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_kvs == {"a": 1, "b": 2, "c": 3}
    assert unknown_kvs == {"d": 4}

    kvs = {"a": 1, "b": 2, "c": 3}
    known_kvs, unknown_kvs = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)

# Generated at 2022-06-17 17:57:38.036485
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    test_class = TestClass(1, 2, 3, d=4, e=5)
    assert test_class.a == 1

# Generated at 2022-06-17 17:58:02.694271
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    test_instance = init(TestClass, 1, "a", "b", "c", d=1, e=2)
    assert test_instance.a == 1
    assert test_instance.b == "a"
    assert test_instance.c == {"_UNKNOWN0": "b", "_UNKNOWN1": "c", "d": 1,
                               "e": 2}

# Generated at 2022-06-17 17:58:13.629892
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}


# Generated at 2022-06-17 17:58:14.956547
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:58:28.062407
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_obj = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}



# Generated at 2022-06-17 17:58:30.823526
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 17:58:41.966887
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import dataclasses_json
    import dataclasses_json.config

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: dataclasses_json.CatchAll = dataclasses.field(
            default_factory=dict)

    test_obj = TestClass(a=1, b=2, c={"d": 3})
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"d": 3}

    test_obj = TestClass(a=1, b=2)
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj = TestClass(a=1, b=2, c={"d": 3}, e=4)
    assert _Catch

# Generated at 2022-06-17 17:58:52.176064
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}

# Generated at 2022-06-17 17:59:03.119446
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

    known_given_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2}


# Generated at 2022-06-17 17:59:14.595258
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1, "b": 2}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    kvs = {"a": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False
    except UndefinedParameterError:
        pass

    k

# Generated at 2022-06-17 17:59:25.878263
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

    kvs = {"a": 1, "b": "2", "c": {"d": 3}}
    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert known == {"a": 1, "b": "2", "c": {"d": 3}}
    assert unknown == {}

    kvs = {"a": 1, "b": "2", "c": {"d": 3}, "e": 4}
    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, kvs)

# Generated at 2022-06-17 17:59:52.904079
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-17 18:00:04.177245
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(1, 2, 3)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    test_class = TestClass(1, 2, 3, d=4)
    assert test_class.a == 1
    assert test_class.b == 2
    assert test_class.c == 3

    test_class = TestClass(1, 2, 3, d=4, e=5)
    assert test

# Generated at 2022-06-17 18:00:12.901275
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a: int, b: int, c: typing.Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    init(TestClass(1, 2, 3), 4, 5, 6)

# Generated at 2022-06-17 18:00:20.799728
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # noinspection PyTypeChecker

# Generated at 2022-06-17 18:00:28.144873
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: str, c: str):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass("a", "b", "c")
    kvs = {"a": "a", "b": "b", "c": "c"}
    result = _UndefinedParameterAction.handle_to_dict(test_class, kvs)
    assert result == kvs



# Generated at 2022-06-17 18:00:35.254980
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == {
               "a": 1, "b": 2}



# Generated at 2022-06-17 18:00:42.007549
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_given_parameters == {"a": 1, "b": 2, "c": 3}
    assert unknown_given_parameters == {"d": 4}



# Generated at 2022-06-17 18:00:47.325679
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b, c):
            pass

    init = _IgnoreUndefinedParameters.create_init(Test)
    init(Test, 1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-17 18:00:55.711563
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}



# Generated at 2022-06-17 18:00:57.778550
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:01:56.365617
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: str, c: str = "c", d: str = "d"):
            pass

    init_func = _UndefinedParameterAction.create_init(TestClass)
    assert init_func.__name__ == "__init__"
    assert init_func.__qualname__ == "TestClass.__init__"
    assert init_func.__doc__ == TestClass.__init__.__doc__
    assert init_func.__module__ == TestClass.__module__
    assert init_func.__annotations__ == TestClass.__init__.__annotations__

    # Test that the function works as expected
    instance = TestClass(1, "b")
    assert instance.a == 1
    assert instance.b == "b"

# Generated at 2022-06-17 18:02:03.419067
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(1, 2, 3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:02:13.543729
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {}}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # Test 3: Undefined parameters and catch

# Generated at 2022-06-17 18:02:20.955508
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_instance = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_instance, kvs) == {
               "a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 18:02:28.974201
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:02:38.993514
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": "2", "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": "2"}
    assert unknown_parameters == {"c": 3}

    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": "2"}


# Generated at 2022-06-17 18:02:49.728741
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "c": 3}
    kvs_out = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert kvs_out == kvs



# Generated at 2022-06-17 18:03:00.611273
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_obj = TestClass(a=1, b=2, c=3, d=4)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    kvs_expected = {"a": 1, "b": 2, "c": 3, "d": 4}
    kvs_actual = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    assert kvs_actual == kvs_expected


# Generated at 2022-06-17 18:03:11.976925
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
   

# Generated at 2022-06-17 18:03:17.724485
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_instance = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:05:21.710225
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:24.097965
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 18:05:32.470697
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r,
                     s, t, u, v, w, x, y, z):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:05:42.939860
# Unit test for method create_init of class _UndefinedParameterAction

# Generated at 2022-06-17 18:05:44.992102
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:56.202581
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)