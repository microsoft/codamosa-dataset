

# Generated at 2022-06-17 17:56:18.825711
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, 2, 3) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3)
    assert init(TestClass, 1, 2, 3, 4, 5, 6) == TestClass(1, 2, 3)

# Generated at 2022-06-17 17:56:27.272436
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 17:56:29.647169
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-17 17:56:35.079730
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == kvs



# Generated at 2022-06-17 17:56:41.821506
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all

    test_class = TestClass(catch_all={"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)
    assert result == {"a": 1, "b": 2}

# Generated at 2022-06-17 17:56:49.267843
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {}}

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": {"d": 3}}

    # Test 3: Undefined parameters and default

# Generated at 2022-06-17 17:56:57.286429
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {}



# Generated at 2022-06-17 17:57:03.985641
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class Test:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    config.undefined = Undefined.EXCLUDE
    init = _IgnoreUndefinedParameters.create_init(Test)
    t = Test(1, 2, 3)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3

    t = Test(1, 2, 3, d=4)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3


# Generated at 2022-06-17 17:57:09.818477
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-17 17:57:21.279595
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None


# Generated at 2022-06-17 17:57:42.851728
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    test_class = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"x": "y"})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "x": "y"}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)

# Generated at 2022-06-17 17:57:55.282464
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Test 1: No catch-all field
    class TestClassNoCatchAll:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    # Test 2: Catch-all field with default

# Generated at 2022-06-17 17:58:05.662027
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert init(TestClass, 1, 2) is None
    assert init(TestClass, 1, 2, 3) is None
    assert init(TestClass, 1, 2, 3, 4) is None
    assert init(TestClass, 1, 2, 3, 4, 5) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None

# Generated at 2022-06-17 17:58:11.648426
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}
    obj.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 1}

# Generated at 2022-06-17 17:58:16.900730
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == kvs



# Generated at 2022-06-17 17:58:20.737438
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, 3, d=4)

# Generated at 2022-06-17 17:58:22.538796
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test")

# Generated at 2022-06-17 17:58:32.491987
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # Test 1: No undefined parameters
    kvs = {"a": 1, "b": 2}
    expected_result = {"a": 1, "b": 2, "c": {}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == expected_result

    # Test 2: Undefined parameters
    kvs = {"a": 1, "b": 2, "d": 3}
    expected_result = {"a": 1, "b": 2, "c": {"d": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)


# Generated at 2022-06-17 17:58:42.882065
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init_function = _UndefinedParameterAction.create_init(TestClass)
    assert init_function(TestClass, 1, 2, 3) is None
    assert init_function(TestClass, 1, 2, 3, 4) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6, 7) is None
    assert init_function(TestClass, 1, 2, 3, 4, 5, 6, 7, 8) is None

# Generated at 2022-06-17 17:58:46.725204
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 17:59:14.965820
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert expected == actual

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs={"c": 3})



# Generated at 2022-06-17 17:59:26.414769
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init_method = _UndefinedParameterAction.create_init(TestClass)
    assert init_method(TestClass, 1, 2, 3) is None
    assert init_method(TestClass, 1, 2, 3, 4) is None
    assert init_method(TestClass, 1, 2, 3, 4, 5) is None
    assert init_method(TestClass, 1, 2, 3, 4, 5, 6) is None
    assert init_method(TestClass, 1, 2, 3, 4, 5, 6, 7) is None

    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init_method(TestClass, 1, 2, 3) is None

# Generated at 2022-06-17 17:59:31.074541
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int = 1, c: int = 2):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}



# Generated at 2022-06-17 17:59:42.599479
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_object = TestClass(1, 2, 3, {'a': 1, 'b': 2})
    kvs = {'a': 1, 'b': 2, 'c': 3, 'd': {'a': 1, 'b': 2}}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
               'a': 1, 'b': 2, 'c': 3, 'a': 1, 'b': 2}



# Generated at 2022-06-17 17:59:44.491810
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 17:59:56.453669
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:00:06.359616
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all

    test_class = TestClass({"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)
    assert result == {"a": 1, "b": 2}

    test_class = TestClass({"a": 1, "b": 2})
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_class, kvs)
    assert result == {"a": 1, "b": 2, "c": 3}

    test_class = Test

# Generated at 2022-06-17 18:00:10.163612
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}
    assert _UndefinedParameterAction.handle_to_dict(test_obj, kvs) == kvs



# Generated at 2022-06-17 18:00:19.267501
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs) == {
               "a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-17 18:00:30.049775
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: CatchAll = dataclasses.field(default=None)

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
   

# Generated at 2022-06-17 18:01:21.905099
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init(TestClass, 1, "2", 3, 4, 5) == TestClass(1, "2", {3: 4, 5: 6})

# Generated at 2022-06-17 18:01:32.903493
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    test_object = TestClass(a=1, b=2, c=3, catch_all={"d": 4, "e": 5})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_object, kvs)
    assert result == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}


# Unit test

# Generated at 2022-06-17 18:01:40.553195
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int
        i: int
        j: int
        k: int
        l: int
        m: int
        n: int
        o: int
        p: int
        q: int
        r: int
        s: int
        t: int
        u: int
        v: int
        w: int
        x: int
        y: int
        z: int
        catch_all: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:01:52.926744
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)



# Generated at 2022-06-17 18:01:55.368219
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert str(e) == "Test"

# Generated at 2022-06-17 18:02:05.963885
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    test_dict = {"a": 1, "b": 2, "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=test_dict)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3}

    known_parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=test_dict)
    assert known_parameters == {"a": 1, "b": 2}


# Generated at 2022-06-17 18:02:13.608144
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    test_class_instance = TestClass(1, 2, 3)
    assert test_class_instance.a == 1
    assert test_class_instance.b == 2
    assert test_class_instance.c == 3

    # noinspection PyTypeChecker
    test_class_instance = _UndefinedParameterAction.create_init(
        TestClass)(1, 2, 3)
    assert test_class_instance.a == 1
    assert test_class_instance.b == 2
    assert test_class_instance.c == 3

# Generated at 2022-06-17 18:02:23.811126
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    obj = TestClass(a=1, b=2, c=3, d=4, e=5, catch_all={"x": 1, "y": 2})
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "x": 1, "y": 2}

# Generated at 2022-06-17 18:02:29.067318
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    init(TestClass, 1, 2, 3, 4)
    init(TestClass, 1, 2, 3, 4, 5, 6, 7, 8)

# Generated at 2022-06-17 18:02:39.064949
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-17 18:04:41.286123
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 1}

# Generated at 2022-06-17 18:04:51.773084
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == expected



# Generated at 2022-06-17 18:04:53.514091
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-17 18:04:57.577815
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    obj = TestClass(a=1, b=2, c={"x": "y"})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"x": "y"}

# Generated at 2022-06-17 18:05:00.023957
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs



# Generated at 2022-06-17 18:05:01.353867
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:07.740996
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int = 0
        e: int = 0
        catch_all: Optional[CatchAllVar] = None

    # Test with no undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == kvs

    # Test with undefined parameters
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

# Generated at 2022-06-17 18:05:15.061917
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b=2):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {"a": 1, "b": 2}
    assert unknown == {"c": 3}



# Generated at 2022-06-17 18:05:16.534397
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-17 18:05:22.017571
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = init(1, 2, 3, d=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

