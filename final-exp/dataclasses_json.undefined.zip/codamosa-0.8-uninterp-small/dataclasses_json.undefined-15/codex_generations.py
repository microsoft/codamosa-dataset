

# Generated at 2022-06-25 16:13:01.607020
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    kwargs = dict()
    args = dict()
    args['num_possible_undefined_parameters'] = 1
    args['num_undefined_parameters'] = 1
    dict1 = dict()
    dict1["key"] = "value"
    args['undefined_parameters'] = dict1
    kwargs['undefined_parameters'] = dict1
    catch_all_field = Field('catch_all', type=CatchAllVar)
    catch_all_field.name = "catch_all"
    catch_all_field.default = dict()
    catch_all_field.default_factory = dict

# Generated at 2022-06-25 16:13:05.844465
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    methods = inspect.getmembers(_UndefinedParameterAction,
                                 predicate=inspect.ismethod)
    for method_name, method in methods:
        if method_name == "create_init":
            assert inspect.signature(method) == inspect.signature(
                _UndefinedParameterAction.create_init)



# Generated at 2022-06-25 16:13:11.468910
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self):
            pass

    undefined_action_base = _UndefinedParameterAction()
    reference_init = TestClass.__init__
    init_method = undefined_action_base.create_init(TestClass)

    try:
        assert init_method == reference_init
    except AssertionError:
        raise AssertionError(
            "Method create_init of _UndefinedParameterAction does not work "
            "(returns a different method that the standard __init__ method)")



# Generated at 2022-06-25 16:13:19.697540
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a, b=4, **_catch_all):
            self.a = a
            self.b = b
            self._catch_all = _catch_all

    x = TestClass(1, _undefined=0)
    expected_result = {"a": 1, "b": 4, "_undefined": 0}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj=x, kvs={"a": 1,
                                                                      "b": 4,
                                                                      "_catch_all": {"_undefined": 0}})
    assert result == expected_result

    x = TestClass(1, _undefined=0)

# Generated at 2022-06-25 16:13:28.218530
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undef_param_instance = _RaiseUndefinedParameters()
    defined_parameters, undefined_parameters = \
        undef_param_instance.handle_from_dict(cls=Person,
                                              kvs={'first_name': 'jane',
                                                   'last_name': "doe",
                                                   'address':
                                                       {'street': "rue de la",
                                                        'city': "Bruxelles"}})
    assert defined_parameters == {'first_name': 'jane', 'last_name': "doe",
                                  'address':
                                      {'street': "rue de la",
                                       'city': "Bruxelles"}}
    assert undefined_parameters == {}



# Generated at 2022-06-25 16:13:31.247739
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err_msg = "This is a test error message"
    tup = (UndefinedParameterError(err_msg),)
    assert tup[0].message == err_msg



# Generated at 2022-06-25 16:13:43.586667
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    class A:
        def __init__(self, a: int, b: int, c: int):
            pass

    __IgnoreUndefinedParameters_create_init: Callable[[A], A]
    __IgnoreUndefinedParameters_create_init = \
        _IgnoreUndefinedParameters.create_init(A)
    a = A(a=1, b=2, c=3)
    __IgnoreUndefinedParameters_create_init(a)
    with pytest.raises(TypeError):
        __IgnoreUndefinedParameters_create_init(a, d=4)
    with pytest.raises(TypeError):
        __IgnoreUndefinedParameters_create_init(a, 1, 2, 3, d=4)
    with pytest.raises(TypeError):
        __IgnoreUndefinedParameters_

# Generated at 2022-06-25 16:13:51.355584
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    cls_name = "TestClass"

    def test_init_method(self, a, b, c=1, d=None, e=None,
                         **other_parameters: CatchAllVar):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.e = e
        self.other_parameters = other_parameters

    test_class = type(cls_name, (), {
        "__init__": test_init_method
    })

    # Instantiate with positional arguments
    catch_all_init = _CatchAllUndefinedParameters.create_init(
        test_class)
    obj = test_class(1, 2, 3, 4, **{"c": 5, "_UNKNOWN0": 10, "_UNKNOWN1": 11})
   

# Generated at 2022-06-25 16:13:53.223994
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()



# Generated at 2022-06-25 16:13:59.643477
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():

    class TestClass:
        pass

    kvs = {'key1': 1}
    expected = {'key1': 1}

    assert _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs) == expected
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs) == expected
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs) == expected



# Generated at 2022-06-25 16:14:30.809448
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # Initialize a dummy error message
    err = UndefinedParameterError("dummy")

    # Check whether the error message is successfully get from
    # the raise exception
    assert str(err) == "dummy"



# Generated at 2022-06-25 16:14:35.261428
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    _ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    """
    create_init generates a new init to replace the standard one.
    """
    class A:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b
    replace_init = _IgnoreUndefinedParameters.create_init(A)
    instance = A(1, 2)
    assert instance.a == 1
    assert instance.b == 2
    instance = A(1, 2, 3)
    assert instance.a == 1
    assert instance.b == 2
    instance = A(1, 2, b=3)
    assert instance.a == 1
    assert instance.b == 2
    instance = A(1, b=2, a=3)
    assert instance

# Generated at 2022-06-25 16:14:37.795479
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("Ran into an undefined parameter")
    assert str(err) == "Ran into an undefined parameter"

# Generated at 2022-06-25 16:14:42.948473
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        test_case_0()
    except UndefinedParameterError as e:
        assert isinstance(e, UndefinedParameterError), f"Second raised Exception is not of Type UndefinedParameterError"

# Generated at 2022-06-25 16:14:52.944215
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

        def __init__(self, x: int, y: int, z: int, a: int):
            self.x = x
            self.y = y
            self.z = z
            self.a = a

        def __init__(self, x: int, y: int, z: int, a: int, b: int):
            self.x = x
            self.y = y
            self.z = z
            self.a = a
            self.b = b

        # args only
        init_with

# Generated at 2022-06-25 16:15:05.884913
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Unit test for method create_init of class _IgnoreUndefinedParameters
    class DummyClass:
        def __init__(self, a, b, c):
            pass

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    dummy_class_instance = DummyClass("a", "b", "c")
    assert dummy_class_instance.a == "a"
    assert dummy_class_instance.b == "b"
    assert dummy_class_instance.c == "c"
    updated_class = _IgnoreUndefinedParameters.create_init(obj=DummyClass)
    dummy_class_instance = updated_class("a", "b", "c", d="d")
    assert dummy_class_instance.a == "a"

# Generated at 2022-06-25 16:15:15.249027
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Arrange
    @dataclasses.dataclass
    class CatchAllTest:
        not_catch_all: str
        catch_all: CatchAll = None

    # Test 0
    decoder = dataclasses_json.DataClassJsonMixin
    test_obj = decoder.from_dict(CatchAllTest, {"not_catch_all": "foo"})
    assert test_obj.not_catch_all == "foo"
    assert test_obj.catch_all == {}

    # Test 1
    test_obj = decoder.from_dict(CatchAllTest,
                                 {"not_catch_all": "foo", "catch_all": {}})
    assert test_obj.not_catch_all == "foo"
    assert test_obj.catch_all == {}

    # Test 2
    test

# Generated at 2022-06-25 16:15:26.378325
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Tests whether the init method of a class is modified correctly by the
    _IgnoreUndefinedParameters action.
    """
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import config
    import functools

    @dataclass
    class Holder:
        items: List[str] = dataclasses.field(default_factory=list)

        def __post_init__(self):
            self.items = ["A", "B"]

    assert Holder().items == ["A", "B"]

    # The action under test:
    action = _IgnoreUndefinedParameters()

    @dataclass
    class UndefinedEntry:
        items: List[str] = dataclasses.field(default_factory=list)
        config: config.Config = config()


# Generated at 2022-06-25 16:15:37.787908
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    kvs = {"a": 1, "b": 2, "c": 3}
    expected_kvs = {"a": 1, "b": 2}

    class Class0:
        a: int
        b: int

    class Class1:
        a: int
        b: int
        c: int

    class Class2:
        a: int
        b: int
        c: int
        d: int

    expected_error_message = \
        "Received undefined initialization arguments {'c': 3}"
    # Test with a class that has too many parameters
    with pytest.raises(UndefinedParameterError) as exception_info:
        # noinspection PyTypeChecker
        _RaiseUndefinedParameters.handle_from_dict(
            cls=Class2, kvs=kvs)

# Generated at 2022-06-25 16:15:44.666423
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Example_1():
        def __init__(self, *, name: str, age: int, unknown: CatchAll = None):
            pass

    class Example_2():
        def __init__(self, *, name: str, age: int, unknown: CatchAll = {}):
            pass

    class Example_3():
        def __init__(self, *, name: str, age: int, unknown: CatchAll = lambda: {}):
            pass

    class Example_4():
        def __init__(self, *, name: str, age: int):
            pass

    def test(example):
        created_init = _CatchAllUndefinedParameters.create_init(example)
        assert type(created_init) is type(example.__init__)

# Generated at 2022-06-25 16:16:27.510878
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0._CatchAllUndefinedParameters__get_default = print
    dict_0 = {catch_all_undefined_parameters_0: catch_all_undefined_parameters_0, catch_all_undefined_parameters_0: catch_all_undefined_parameters_0, catch_all_undefined_parameters_0: catch_all_undefined_parameters_0}
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(catch_all_undefined_parameters_0, dict_0)

# Generated at 2022-06-25 16:16:29.108283
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 16:16:37.135230
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    raise_undefined_parameters_0.handle_dump(raise_undefined_parameters_0)
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_dump(raise_undefined_parameters_0)
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.handle_dump(raise_undefined_parameters_0)


# Generated at 2022-06-25 16:16:40.530590
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2


# Generated at 2022-06-25 16:16:43.832985
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.create_init(catch_all_undefined_parameters_0)


# Generated at 2022-06-25 16:16:46.636428
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    _UndefinedParameterAction.handle_dump(CatchAllVar)
    _UndefinedParameterAction.handle_dump(CatchAll[CatchAllVar])
    _UndefinedParameterAction.handle_dump(CatchAll[CatchAll])


# Generated at 2022-06-25 16:16:59.579499
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    This test checks that the method _IgnoreUndefinedParameters.create_init
    replaces the __init__ method of the class with a wrapper that behaves
    as desired.

    More precisely: create_init is called on the class, and its __init__
    should be replaced by the output of create_init.
    The __init__ method should ignore all parameters that the original __init__
    does not accept, and it should not pass them to the original __init__.
    """

    # create a dummy class that has an __init__ method that receives exactly
    # the parameters given in the list desired_params as keyword arguments
    # The dummy class also has a dummy_param which is not included in this list
    # This dummy_param should be ignored by the new __init__ method.
    dummy_param = "dummy"

# Generated at 2022-06-25 16:17:10.846872
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    capture__UndefinedParameterAction_handle_from_dict = []
    expected__UndefinedParameterAction_handle_from_dict = []
    capture__UndefinedParameterAction_handle_from_dict += [UndefinedParameterError("Received undefined initialization arguments {'AA12': 42}")]
    expected__UndefinedParameterAction_handle_from_dict += [UndefinedParameterError("Received undefined initialization arguments {'AA12': 42}")]
    unknown_parameter_0 = {'AA12': 42}
    known_parameter_0 = {'unknown_parameter': 'AA12'}
    capture__UndefinedParameterAction_handle_from_dict += [known_parameter_0]
    expected__UndefinedParameterAction_handle_from_dict += [{'unknown_parameter': 'AA12'}]
    assert capture__UndefinedParameterAction

# Generated at 2022-06-25 16:17:17.144263
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # Return the parameters to initialize the class with.
    _ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_0 = {'None': [dict_0, _ignore_undefined_parameters_0], 'None': [dict_0, _ignore_undefined_parameters_0], 'None': {_ignore_undefined_parameters_0: dict_0}}
    dict_1 = _ignore_undefined_parameters_0.handle_from_dict(dict_0, dict_0)
    assert dict_1 == dict_0



# Generated at 2022-06-25 16:17:22.248800
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class_0 = _UndefinedParameterAction
    obj_0 = _UndefinedParameterAction()
    kvs_0 = {obj_0: obj_0, obj_0: obj_0}
    result_0 = _UndefinedParameterAction.handle_to_dict(obj_0, kvs_0)
    assert result_0 == kvs_0


# Generated at 2022-06-25 16:18:01.960347
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Parameters
    cls = _RaiseUndefinedParameters()
    kvs = {'arg_0': 0, 'arg_1': '1', '_UNKNOWN_0': '_UNKNOWN_0', '_UNKNOWN_1': '_UNKNOWN_1'}

    # Code under test
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    result_0 = catch_all_undefined_parameters_0.handle_to_dict(cls, kvs)

    # Test for return types
    assert isinstance(result_0, dict)


# Generated at 2022-06-25 16:18:08.462781
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = {}
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(catch_all_undefined_parameters_0, dict_0)
    dict_2 = {}
    dict_3 = catch_all_undefined_parameters_0.handle_from_dict(catch_all_undefined_parameters_0, dict_2)
    dict_4 = {}
    dict_5 = catch_all_undefined_parameters_0.handle_from_dict(catch_all_undefined_parameters_0, dict_4)
    dict_6 = {}

# Generated at 2022-06-25 16:18:10.054284
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass



# Generated at 2022-06-25 16:18:20.893383
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = {raise_undefined_parameters_0: catch_all_undefined_parameters_0, catch_all_undefined_parameters_0: catch_all_undefined_parameters_0, catch_all_undefined_parameters_0: catch_all_undefined_parameters_0, catch_all_undefined_parameters_0: catch_all_undefined_parameters_0}
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(catch_all_undefined_parameters_0, dict_0)


# Generated at 2022-06-25 16:18:31.786915
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = {'_UNKNOWN1': 1}
    dict_1 = {'_UNKNOWN0': 0}
    # Test with single positional argument
    _CatchAllUndefinedParameters_create_init = catch_all_undefined_parameters_0.create_init(0)
    _CatchAllUndefinedParameters_create_init(0, **dict_0)
    # Test with named argument
    _CatchAllUndefinedParameters_create_init = catch_all_undefined_parameters_0.create_init(raise_undefined_parameters_0=0)
    _CatchAllUndefinedParameters_create_init(0, **dict_1)
    # Test with both
    _CatchAllUndefinedParameters_create

# Generated at 2022-06-25 16:18:38.123504
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameter_action_0 = _UndefinedParameterAction()
    count_0 = 0
    for i in range(1000):
        count_0 += i
    assert count_0 == 499500
    count_1 = 0
    for i in range(1000):
        count_1 += i
    assert count_1 == 499500
    count_2 = 0
    for i in range(1000):
        count_2 += i
    assert count_2 == 499500


# Generated at 2022-06-25 16:18:41.380070
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    undefined_0 = _CatchAllUndefinedParameters()
    dict_0 = {'a': 'b', 'c': 'd'}
    dict_1 = undefined_0.handle_from_dict(object, dict_0)
    assert dict_1 == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-25 16:18:53.092410
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test case 0
    try:
        raise_undefined_parameters_0 = _RaiseUndefinedParameters()
        dict_0 = {raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0}
        catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
        catch_all_undefined_parameters_0.handle_from_dict(raise_undefined_parameters_0, dict_0)
    except UndefinedParameterError as e:
        pass


# Generated at 2022-06-25 16:19:05.746219
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
#
    dict_0 = {raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(raise_undefined_parameters_0, dict_0)
#
    dict_2 = dict_0
    dict_3 = dict_2.copy()


# Generated at 2022-06-25 16:19:10.818877
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    undefined_parameters_0 = _UndefinedParameterAction()
    class SampleClass_0:
        def __init__(self, a_0, b_0):
            self.a_0 = a_0
            self.b_0 = b_0

    sample_class_0 = SampleClass_0(1, 1)
    obj_0 = undefined_parameters_0.create_init(sample_class_0)


# Generated at 2022-06-25 16:20:27.034085
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Test case 0
    # run test
    test_case_0()


# Generated at 2022-06-25 16:20:30.742808
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters_1 = _RaiseUndefinedParameters()
    dict_0 = {'0': '0', '1': '1'}
    try:
        dict_1 = raise_undefined_parameters_1.handle_from_dict(dict_0)
    except UndefinedParameterError:
        pass
    else:
        assert False, "Unreachable"


# Generated at 2022-06-25 16:20:32.799505
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    test_class_0 = type("", (), {})
    undefined_parameter_action_0 = _UndefinedParameterAction()
    kvs_0 = undefined_parameter_action_0.handle_from_dict(test_class_0, kvs_0)

# Generated at 2022-06-25 16:20:34.395186
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    _ignore_undefined_parameters = _IgnoreUndefinedParameters()
    dict_0 = {}
    dict_1 = _ignore_undefined_parameters.create_init(dict_0)



# Generated at 2022-06-25 16:20:42.361804
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = {raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0}
    dict_1 = raise_undefined_parameters_0.handle_from_dict(raise_undefined_parameters_0, dict_0)
    assert dict_1 == {raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0}


# Generated at 2022-06-25 16:20:46.304929
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    assert raise_undefined_parameters_0.handle_from_dict(catch_all_undefined_parameters_0, catch_all_undefined_parameters_0) == catch_all_undefined_parameters_0


# Generated at 2022-06-25 16:20:49.877054
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _IgnoreUndefinedParameters()
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 16:20:55.078110
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses_json._UndefinedParameters
    obj_0 = object()
    kvs_0 = {}
    val_0 = dataclasses_json._UndefinedParameters._CatchAllUndefinedParameters.handle_to_dict(obj_0, kvs_0)
    assert isinstance(val_0, dict)


# Generated at 2022-06-25 16:21:00.761921
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:21:02.952232
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_message = "This is an error message"
    undefinedParameterError_obj = UndefinedParameterError(error_message)
    assert(undefinedParameterError_obj.message == error_message)