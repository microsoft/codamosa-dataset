

# Generated at 2022-06-25 16:13:03.396028
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_parameter_actions = [Undefined.INCLUDE, Undefined.EXCLUDE,
                                   Undefined.RAISE]
    for undefined_parameter_action in undefined_parameter_actions:
        try:
            _CatchAllUndefinedParameters._get_catch_all_field(
                undefined_parameter_action)
        except UndefinedParameterError:
            pass
        else:
            assert True


# Generated at 2022-06-25 16:13:08.377295
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Given
    kvs = {"a": "blah"}
    undefined_parameter_action_0: _UndefinedParameterAction = \
        _UndefinedParameterAction()

    # When
    result = undefined_parameter_action_0.handle_to_dict(obj=object, kvs=kvs)

    # Then
    assert result == {"a": "blah"}



# Generated at 2022-06-25 16:13:16.949023
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Define empty mock dataclass
    @dataclasses.dataclass
    class MockDataClass:
        a: str
        pass

    # Should be able to call the init method of the mock dataclass with
    # the parameters it defines
    defined_params = {"a": "string"}
    _RaiseUndefinedParameters.handle_from_dict(MockDataClass, defined_params)

    # Should raise UndefinedParameterError when called with undefined parameters
    with pytest.raises(UndefinedParameterError):
        undefined_params = {"b": "string"}
        _RaiseUndefinedParameters.handle_from_dict(MockDataClass,
                                                   undefined_params)



# Generated at 2022-06-25 16:13:20.594338
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo(object):

        def __init__(self, arb, _arb=0, **kwargs):
            pass

    dic = {"arb": 1, "two": 2, "three": 3}
    expected_output = {"arb": 1}
    output = _IgnoreUndefinedParameters.create_init(Foo)(None, **dic)
    assert output == expected_output



# Generated at 2022-06-25 16:13:28.897103
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass0:
        def __init__(self, param0: int,
                     param1: int,
                     catchall: CatchAll = None):
            pass

    kvs = {}
    assert TestClass0(**_CatchAllUndefinedParameters.
                      handle_from_dict(TestClass0, kvs)) is not None

    kvs = {
        "param0": 1,
        "param1": 2,
    }
    assert TestClass0(**_CatchAllUndefinedParameters.
                      handle_from_dict(TestClass0, kvs)) is not None

    kvs = {
        "param0": 1,
        "param1": 2,
        "catchall": {
            "param1": 2,
        },
    }

# Generated at 2022-06-25 16:13:38.985595
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            # Unit test for create_init
            assert a == 1
            assert b == 2
            assert c == 3

    init = _IgnoreUndefinedParameters.create_init(TestClass)

    init(TestClass(1, 2, 3, **{}))
    init(TestClass(1, 2, 3, **{"a": 1, "b": 2, "c": 3}))
    init(TestClass(1, 2, 3, **{"a": 1, "b": 2, "c": 3, "d": 4}))



# Generated at 2022-06-25 16:13:49.622109
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Thing(metaclass=dataclasses.dataclass):
        a: int
        b: int
        c: int

    init = _IgnoreUndefinedParameters.create_init(Thing)

    # Test case #1
    thing = Thing(1, 2, 3)
    assert thing.a == 1
    assert thing.b == 2
    assert thing.c == 3

    # Test case #2
    thing = Thing(1, 2, 3, d=4)
    assert thing.a == 1
    assert thing.b == 2
    assert thing.c == 3
    # The 4th parameter is ignored because it is undefined

    # Test case #3
    thing = Thing(1, 2, d=4)
    assert thing.a == 1
    assert thing.b == 2
    # The 3rd parameter gets default value

# Generated at 2022-06-25 16:13:54.931890
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses_json.undefined import _CatchAllUndefinedParameters
    from dataclasses_json.undefined import _SentinelNoDefault

    class Foo:
        def __init__(self, x=3):
            print(f"init with {x}")

    class FooCatchAll(Foo):
        def __init__(self, x=3, ca: CatchAll = None):
            self.x = x
            self.ca = ca

        @_CatchAllUndefinedParameters.create_init(FooCatchAll)
        def _init(self, x=3, ca: CatchAll = None):
            super().__init__(x)

    # 1. Test to see if the correct number of arguments are passed on
    # Test that no arguments are passed on
    obj = FooCatchAll()

# Generated at 2022-06-25 16:13:59.896316
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int

    test = TestClass(a=10)
    kvs = {
        "a": 10
    }

    kvs_expected = {
        "a": 10
    }
    kvs_actual = _UndefinedParameterAction.handle_to_dict(obj=test, kvs=kvs)
    assert kvs_actual == kvs_expected


# Generated at 2022-06-25 16:14:06.257017
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from marshmallow import Schema, fields, post_load
    from dataclasses_json.api import load
    from typing import Dict, Any

    # Define a class that has no default for its catch-all field
    class TestClass0(object):
        def __init__(self, a: str, _a: Dict[str, Any] = {}):
            self.a = a
            self._a = _a

    # Define the marshmallow-schema
    class TestSchema0(Schema):
        a = fields.Str()

        @post_load
        def make_object(self, data: Dict[str, Any], **kwargs):
            return TestClass0(**data)

    # Test that it works without catch-all-field
    schema = TestSchema0()

# Generated at 2022-06-25 16:14:39.699269
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

    test_instance = TestClass(x=1, y=2, z=3)
    result = _UndefinedParameterAction.handle_to_dict(test_instance,
                                                      {'x': 1, 'y': 2, 'z': 3})
    assert(result == {'x': 1, 'y': 2, 'z': 3})



# Generated at 2022-06-25 16:14:48.172904
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class T:
        def __init__(self, a: int, b: int, c: int):
            pass

    assert (_UndefinedParameterAction.create_init(T) is T.__init__)
    assert (_RaiseUndefinedParameters.create_init(T) is T.__init__)
    assert (_IgnoreUndefinedParameters.create_init(T) is not T.__init__)
    assert (_CatchAllUndefinedParameters.create_init(T) is not T.__init__)



# Generated at 2022-06-25 16:14:49.738904
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test(object):
        pass

    result = _IgnoreUndefinedParameters.handle_from_dict(Test, dict(test=1))
    assert result == dict()


# Generated at 2022-06-25 16:14:55.825780
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameter_action_0 = _UndefinedParameterAction()

    @dataclasses.dataclass
    class Test0:
        a: str
        b: int
        c: float

    test_0 = Test0(a="a", b=1, c=1.5)
    dictionary_0 = {"a": "a", "b": 1, "c": 1.5}

    assert undefined_parameter_action_0.handle_to_dict(test_0, dictionary_0) == {"a": "a", "b": 1, "c": 1.5}



# Generated at 2022-06-25 16:15:03.090253
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_parameter_action_0 = _CatchAllUndefinedParameters()
    unknown_parameter = {"_UNKNOWN0": 2}
    kvs = {"a": 1, "_UNKNOWN1": 3}
    result = undefined_parameter_action_0.handle_to_dict(unknown_parameter, kvs)
    expected = {"a": 1, "_UNKNOWN1": 3}
    assert(result == expected)



# Generated at 2022-06-25 16:15:06.085187
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # this does not work as long as the class is an abstract class
    # undefined_parameter_action_0 = _UndefinedParameterAction()
    pass



# Generated at 2022-06-25 16:15:10.120103
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # If this test still fails, you most likely changed the constructor
    # signature of the class

    # noinspection PyProtectedMember
    field_names = [field.name for field in fields(A0)]
    field_names.remove("a_0")  # a_0 is ignored in this test

    # Class with one parameter
    class A1:
        def __init__(self, a_1: str = "Default") -> None:
            pass

    # noinspection PyProtectedMember
    field_names.append([field.name for field in fields(A1)][0])

    # Class with two parameters
    class A2:
        def __init__(self, a_2: str = "Default", a_3: str = "Default") -> None:
            pass

    # noinspection PyProtectedMember
    field

# Generated at 2022-06-25 16:15:19.676364
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class CatchAllInitTestCase:
        def __init__(self, a: int, b: str, c: str = "c", catch_all: CatchAll =
        None):
            pass

    init_from_class = CatchAllInitTestCase.__init__
    init_from_catch_all = _CatchAllUndefinedParameters \
        .create_init(CatchAllInitTestCase)

    init_from_class(CatchAllInitTestCase(1, "b"), x=2, y=3)  # No error
    init_from_class(CatchAllInitTestCase(1, "b"), c="c", x=2, y=3)  # No error
    init_from_catch_all(CatchAllInitTestCase(1, "b"), x=2, y=3)  # No error
   

# Generated at 2022-06-25 16:15:30.714973
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    input_kvs = {"x": 1, "y": 2}
    class_fields = [Field("x", type=int, default=None)]

    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            class_fields, input_kvs)
    final_parameters = _IgnoreUndefinedParameters.handle_from_dict(
        class_fields, input_kvs)
    assert known_parameters == final_parameters
    assert len(unknown_parameters) == 0

    input_kvs = {"x": 1, "y": 2}
    class_fields = []


# Generated at 2022-06-25 16:15:31.666716
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass



# Generated at 2022-06-25 16:16:04.828363
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    list_0 = []
    list_1 = [list_0, list_0]
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    # Test with an empty dictionary
    kvs = {}
    kvs = catch_all_undefined_parameters_0.handle_to_dict(list_0, kvs)
    # Test with a dictionary that contains no undefined parameter
    kvs = {"a": 1, "b": 2}
    kvs = catch_all_undefined_parameters_0.handle_to_dict(list_0, kvs)
    # Test with a dictionary that contains undefined parameters
    kvs = {"a": 1, "b": 2, "c": {"foo": "bar"}}
    kvs = catch_all_undefined_parameters_0.handle_

# Generated at 2022-06-25 16:16:15.535454
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    dict_0 = dict()
    dict_1 = dict(dict_0)
    dict_2 = dict(dict_1)
    dict_3 = dict(dict_2)
    dict_4 = dict(dict_3)
    dict_5 = dict(dict_4)
    dict_6 = dict(dict_5)
    dict_7 = dict(dict_6)
    dict_8 = dict(dict_7)
    dict_9 = dict(dict_8)
    dict_10 = dict(dict_9)
    dict_11 = dict(dict_10)
    dict_12 = dict(dict_11)
    dict_13 = dict(dict_12)
    dict_14 = dict(dict_13)
    dict_15 = dict(dict_14)
    dict_16 = dict(dict_15)

# Generated at 2022-06-25 16:16:24.302700
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    field_0 = Field(name="test_0", type=Dict[str, str])
    fields_0 = [field_0]
    dataclass_0 = type("test_0", (object,), dict(_fields=fields_0))
    dict_0 = {}
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(dataclass_0, dict_0)
    print(dict_0)
    print(dict_1)
    print(field_0.default)

test__CatchAllUndefinedParameters_handle_to_dict()

# Generated at 2022-06-25 16:16:31.785140
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def test_case(a: bool, b: bool) -> bool:
        if a:
            if b:
                return True
            else:
                return False
        else:
            if b:
                return True
            else:
                return False

    @dataclasses.dataclass
    class ClassB:
        unknown: int
        b: int = dataclasses.field(default=42)
        y: int = dataclasses.field(default=14, metadata={'marshmallow_field': True })
        z: int = dataclasses.field(default=1, metadata={'marshmallow_field': 'z' })

    classB_0 = ClassB(12, b=14, m=16)
    classA_0 = _UndefinedParameterAction()

# Generated at 2022-06-25 16:16:43.916306
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    _undefined_parameter_action = _UndefinedParameterAction()
    _raise_undefined_parameters = _RaiseUndefinedParameters()
    ignore_undefined_parameters = Undefined.EXCLUDE.value
    _catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    undefined_parameter_action = Undefined.INCLUDE.value
    list_0 = []
    list_1 = [list_0, list_0]
    undefined_parameter_error_0 = UndefinedParameterError(list_0, list_1)
    str_0 = str(undefined_parameter_error_0)
    instance_to_dict_0 = _CatchAllUndefinedParameters.handle_to_dict(
        undefined_parameter_error_0, list_0)
    catch_

# Generated at 2022-06-25 16:16:51.214791
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_3['a'] = dict_1
    dict_1['a'] = dict_0
    dict_4 = dict()
    dict_4['a'] = dict_2
    dict_2['a'] = dict_3
    dict_1['b'] = dict_0
    dict_2['b'] = dict_0
    dict_3['b'] = dict_0
    dict_5 = dict(b=dict_4['a']['a'])
    dict_6 = dict(a=dict_4['a']['a'])
    dict_4['a']['a']['c'] = dict_0
    dict_5['c'] = dict_0
   

# Generated at 2022-06-25 16:16:58.228600
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    method_of_class_0 = _UndefinedParameterAction
    list_0 = []
    list_1 = [list_0, list_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(method_of_class_0)
    dict_0 = method_of_class_0.handle_to_dict(callable_0, list_1)



# Generated at 2022-06-25 16:17:03.010605
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test for constructor of class UndefinedParameterError.
    """
    class_object_0 = UndefinedParameterError("Undefined Parameter Error")
    assert isinstance(class_object_0.detail, tuple)
    assert class_object_0.detail == ("Undefined Parameter Error",)
    assert class_object_0.status == "error"


# Generated at 2022-06-25 16:17:08.809694
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_0['f'] = dict_1
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_0 = ignore_undefined_parameters_0.handle_to_dict(dict_0, dict_0)


# Generated at 2022-06-25 16:17:12.289667
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_parameter_action_0 = _UndefinedParameterAction()
    bool_0 = undefined_parameter_action_0.handle_dump(str())
    bool_1 = undefined_parameter_action_0.handle_dump(str())


# Generated at 2022-06-25 16:17:43.902132
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from fractions import Fraction as _Fraction
    from datetime import datetime as _datetime

    class _DictLogger:
        def __init__(self, *args, **kwargs):
            self.arguments = {"args": args, "kwargs": kwargs}

    dict_logger_0 = _DictLogger
    dict_logger_1 = _CatchAllUndefinedParameters.create_init(dict_logger_0)
    str_0 = "abc"
    str_1 = "def"
    dict_logger_2 = dict_logger_1(str_0, str_1, dict_logger_0=str_1, _UNKNOWN0=str_0)
    dict_0 = dict_logger_2.arguments
    dict_1 = dict_0["kwargs"]

# Generated at 2022-06-25 16:17:53.204386
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    list_0 = []
    list_1 = [list_0, list_0]
    undefined_parameter_error_0 = UndefinedParameterError(list_0, list_1)
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(undefined_parameter_error_0)
    assert not callable_0 == undefined_parameter_error_0
    #
    # Unit test has finished
    #


# Generated at 2022-06-25 16:18:02.397511
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    test__CatchAllUndefinedParameters_handle_from_dict_num = 0
    # default arguments
    kvs_0 = {}

    __CatchAllUndefinedParameters_handle_from_dict_0 = _CatchAllUndefinedParameters.handle_from_dict(kvs_0)
    assert __CatchAllUndefinedParameters_handle_from_dict_0 == kvs_0

    # default arguments
    kvs_0 = {'key_0': 'key_0_value_0'}

    __CatchAllUndefinedParameters_handle_from_dict_0 = _CatchAllUndefinedParameters.handle_from_dict(kvs_0)
    assert __CatchAllUndefinedParameters_handle_from_dict_0 == kvs_0

    # default arguments

# Generated at 2022-06-25 16:18:14.645156
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    try:
        str_0 = str()
        str_1 = str()
        dict_0 = {str_1: str_0}
        _RaiseUndefinedParameters.handle_from_dict(str(), dict_0)
        str_2 = str()
        undefined_parameter_error_0 = UndefinedParameterError(str_0, str_2)
        ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
        catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
        raise_undefined_parameters_0 = _RaiseUndefinedParameters()
        raise_undefined_parameters_0.handle_from_dict(undefined_parameter_error_0,
                                                       dict_0)
    except UndefinedParameterError as e:
        print(e)

# Generated at 2022-06-25 16:18:23.654047
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import asdict
    from dataclasses_json import dataclass_json
    from dataclasses_json.utils import CatchAllVar

    @dataclass_json
    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class _TestClass:
        field_a: int
        field_b: str
        catch_all: CatchAllVar

    obj = _TestClass(field_a=1, field_b="2", catch_all={})
    all_kw = asdict(obj)
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        obj, all_kw)
    result = _CatchAllUndefinedParameters.handle_from_dict(obj, all_kw)
    assert result == all

# Generated at 2022-06-25 16:18:32.187334
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses_json.api import encode
    from dataclasses_json.api import decode

    @dataclasses.dataclass(undecorated=True,
                           undefined=Undefined.EXCLUDE)
    class Car:
        doors: int

    def main():
        car_0 = Car(3, _extra_={"color": "blue"})
        car_1 = decode(encode(car_0), Car)
        assert car_0.doors == car_1.doors

    main()



# Generated at 2022-06-25 16:18:41.172879
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Provided values are both in the keyword arguments and in the
    # positional arguments
    class TestA:
        def __init__(self, a: str, b: str = 'b'):
            self.a = a
            self.b = b

    test_a = TestA("aa", b="bb")
    assert test_a.a == "aa"
    assert test_a.b == "bb"

    # Too many positional arguments
    try:
        test_a = TestA("aa", "bb")
    except TypeError:
        # TypeError: __init__() takes from 1 to 2 positional arguments but 3 were given
        pass
    else:
        assert False

    # Too many positional arguments

# Generated at 2022-06-25 16:18:53.926597
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters.handle_to_dict
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_2 = catch_all_undefined_parameters_1.handle_to_dict
    catch_all_undefined_parameters_3 = _CatchAllUndefinedParameters.handle_to_dict(catch_all_undefined_parameters_1)
    dict_0 = dict_1 = {}
    dict_0 = _UndefinedParameterAction.handle_to_dict(catch_all_undefined_parameters_1, dict_1)
    dict_0 = UndefinedParameterError.handle_to_dict(catch_all_undefined_parameters_1, dict_1)
   

# Generated at 2022-06-25 16:19:06.322973
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_parameter_error_0 = UndefinedParameterError("abc", "abc")
    assert undefined_parameter_error_0._reasons == "abc" and \
           undefined_parameter_error_0.field_name == "abc"
    undefined_parameter_error_1 = UndefinedParameterError("abc")
    assert undefined_parameter_error_1._reasons == "abc" and \
           undefined_parameter_error_1.field_name == "Undefined parameter(s): abc"
    undefined_parameter_error_2 = UndefinedParameterError(str_0="abc")
    assert undefined_parameter_error_2._reasons == "abc" and \
           undefined_parameter_error_2.field_name == "Undefined parameter(s): abc"

# Generated at 2022-06-25 16:19:13.191462
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    list_0 = ["c'est la vie", 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3]
    list_1 = [2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3, 2.3]
    dict_0 = dict(zip(list_0, list_1))
    dict_1 = dict(zip(list_1, list_0))
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_2 = _CatchAllUndefinedParameters()


# Generated at 2022-06-25 16:20:16.931411
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    errors_0: Dict[Any, Any] = {}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    assert raise_undefined_parameters_0.handle_to_dict(errors_0, errors_0) == errors_0, "expected erros_0, got {0}".format(raise_undefined_parameters_0.handle_to_dict(errors_0, errors_0))

# Generated at 2022-06-25 16:20:30.621642
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    type_0 = type
    def function_0(cls, kvs):
        return kvs
    dict_0 = dict()
    dict_1 = dict_0
    dict_0.update({'a':1,'b':2,'c':3,'d':4})
    dict_2 = dict_1
    dict_1 = dict_2.copy()
    dict_2 = None
    dict_3 = dict_0
    dict_0 = dict_3.copy()
    str_0 = 'a'
    int_0 = 1
    dict_0.update({'a':1})
    dict_4 = dict_0
    dict_0 = dict_4.copy()
    dict_4 = None
    dict_0.update({'a':1,'b':2,'c':3,'d':4})
   

# Generated at 2022-06-25 16:20:34.658749
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    list_0 = []
    list_1 = [list_0, list_0]
    undefined_parameter_error_0 = UndefinedParameterError(list_0, list_1)
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(undefined_parameter_error_0)
    undefined_parameter_action_0 = _UndefinedParameterAction()
    dict_0 = undefined_parameter_action_0.handle_dump(callable_0)
    assert dict_0 == {}


# Generated at 2022-06-25 16:20:41.532955
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_2 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    int_0 = catch_all_undefined_parameters_1.handle_to_dict(catch_all_undefined_parameters_2, catch_all_undefined_parameters_0)

if __name__ == "__main__":
    test_case_0()
    test__CatchAllUndefinedParameters_handle_to_dict()

    raise ValidationError('test')


# Generated at 2022-06-25 16:20:49.101289
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
  list_0 = []
  list_1 = [list_0, list_0]
  undefined_parameter_error_0 = UndefinedParameterError(list_0, list_1)
  ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
  callable_0 = ignore_undefined_parameters_0.create_init(undefined_parameter_error_0)
  undefined_parameter_action_0 = _UndefinedParameterAction()
  dict_0 = undefined_parameter_action_0.handle_dump(callable_0)


# Generated at 2022-06-25 16:20:58.045308
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    _UndefinedParameterAction._separate_defined_undefined_kvs(list, dict())
    _CatchAllUndefinedParameters._separate_defined_undefined_kvs(list, dict())
    _UndefinedParameterAction._get_catch_all_field(list)
    _CatchAllUndefinedParameters._get_catch_all_field(list)
    _UndefinedParameterAction._get_default(Field(default=None, default_factory=None))
    _CatchAllUndefinedParameters._get_default(Field(default=None, default_factory=None))
    _UndefinedParameterAction._get_default(Field(default=None, default_factory=list))
    _CatchAllUndefinedParameters._get_default(Field(default=None, default_factory=list))
    _UndefinedParameterAction._get_

# Generated at 2022-06-25 16:21:03.124823
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    undefined_parameter_error_0 = UndefinedParameterError()
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(undefined_parameter_error_0)
    dict_0 = {"args": [], "msg": ""}


# Generated at 2022-06-25 16:21:13.094481
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test(object):
        def __init__(self, a:int, b:str, c:bool, d:Dict=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    t = Test(1, '2', True, {'x' : '9'})
    # The 'd' field is a catch-all
    # we need to tell _CatchAllUndefinedParameters to remove it from the dump
    # and add it to the returned dict
    kvs = {'a': t.a, 'b': t.b, 'c': t.c, 'd': t.d}
    expected = {'a': t.a, 'b': t.b, 'c': t.c, 'x': '9'}
    actual = _

# Generated at 2022-06-25 16:21:22.919477
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Test 1
    list_0 = []
    list_1 = [list_0, list_0]
    undefined_parameter_error_0 = UndefinedParameterError(list_0, list_1)
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(undefined_parameter_error_0)
    callable_1 = callable_0
    assert callable_1(callable_0, __name__) == callable_1()



# Generated at 2022-06-25 16:21:28.602010
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    str_0 = str()
    list_0 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
