

# Generated at 2022-06-25 16:13:04.965691
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class _RaiseDummy:
        pass

    class _RaiseDummySubclass(_RaiseDummy):
        def __init__(self, foo):
            self.foo = foo

    rdp = _RaiseUndefinedParameters()

    known, unknown = \
        rdp._separate_defined_undefined_kvs(cls=_RaiseDummy,
                                             kvs={"known": "known"})
    assert known == {"known": "known"}
    assert unknown == {}

    known, unknown = \
        rdp._separate_defined_undefined_kvs(cls=_RaiseDummy,
                                             kvs={"unknown": "unknown"})
    assert known == {}
    assert unknown == {"unknown": "unknown"}

    known, unknown = \
        rdp._separate_defined

# Generated at 2022-06-25 16:13:12.974669
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    ignore_undefined_parameters = _IgnoreUndefinedParameters
    # Given
    cls_0 = object

    def expected(kvs):
        return kvs

    # When
    kvs_0 = {}
    actual_0 = ignore_undefined_parameters.handle_from_dict(cls=cls_0, kvs=kvs_0)

    kvs_1 = {"a": 0}
    actual_1 = ignore_undefined_parameters.handle_from_dict(cls=cls_0, kvs=kvs_1)

    kvs_2 = {"a": 0, "b": 1}
    actual_2 = ignore_undefined_parameters.handle_from_dict(cls=cls_0, kvs=kvs_2)

    # Then
    assert actual_0

# Generated at 2022-06-25 16:13:24.856114
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a=0):
            self.a = a

        def __eq__(self, other):
            return self.a == other.a

        def __repr__(self):
            return f"A(a={self.a})"

    init = _CatchAllUndefinedParameters.create_init(A)
    a = A(0)

    assert init(a, 0) == a
    assert init(a, 1) == A(1)
    assert init(a, a=1) == A(1)
    assert init(a, a=0) == a
    assert init(a) == a
    assert init(a, b=1) == a
    assert init(a, b=1, c=3) == a

# Generated at 2022-06-25 16:13:33.381141
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    kvs = dict(a=1, b=2, c=3)
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=CatchAll, kvs=kvs)
    result = raise_undefined_parameters.handle_from_dict(cls=CatchAll, kvs=kvs)
    assert result == known_given_parameters



# Generated at 2022-06-25 16:13:37.905977
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass(frozen=True)
    class Test0:
        name: str
        i: int

    assert _UndefinedParameterAction.handle_dump(Test0("A", 4)) == {}



# Generated at 2022-06-25 16:13:48.455546
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # create class
    @dataclasses.dataclass
    class TestClass:
        def __init__(self, a: int, b: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b

    # test _CatchAllUndefinedParameters
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_init_0 = catch_all_undefined_parameters_0.create_init(
        obj=TestClass)
    test_instance_0 = catch_all_init_0(1, 2, c=3, d=4)

    # test _IgnoreUndefinedParameters
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    catch_all_init_1 = ignore_undefined_parameters

# Generated at 2022-06-25 16:13:54.294430
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo:
        def __init__(self, some_field: str, other_field: str,
                     *args, **kwargs):
            self.some_field = some_field
            self.other_field = other_field

    foo = Foo("foo", "bar")
    assert foo.some_field == "foo"
    assert foo.other_field == "bar"

    ignore_init = _IgnoreUndefinedParameters \
        .create_init(Foo)
    foo = Foo("foo", "bar", ignore_me=None)
    assert foo.some_field == "foo"
    assert foo.other_field == "bar"

    ignore_init = _IgnoreUndefinedParameters \
        .create_init(Foo)

# Generated at 2022-06-25 16:14:03.051778
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class A:
        a: int
        b: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    cases = [
        # Case 0:
        [
            A(a=1, b="a", catch_all={"c": 4}),
            {"a": 1, "b": "a", "c": 4}
        ],
        # Case 1:
        [
            A(a=1, b="a"),
            {"a": 1, "b": "a"}
        ],
        # Case 2:
        [
            A(),
            {}
        ]
    ]

    for case in cases:
        input_0, expected_output = case

# Generated at 2022-06-25 16:14:13.479116
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    class TestClass:
        def __init__(self, a: str, b: str, c: Optional[str] = None,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
    kvs = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e', 'f': 'f'}
    defined, undefined = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            TestClass, kvs)
    defined_new, undefined_new = \
        catch_all_undefined_parameters_0.handle_

# Generated at 2022-06-25 16:14:25.042563
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    instance_0 = type("", (object,), {"undefined":{}, "defined":{}})
    instance_0.__dict__ = {"a": 3, "b": 4, "c": 5, "defined": {3,4,5},
                           "undefined":{6,7,8}}
    # Call to method handle_to_dict of class _CatchAllUndefinedParameters
    kvs = {"a": 3, "b": 4, "c": 5, "undefined": {6, 7, 8}}
    result = catch_all_undefined_parameters_0.handle_to_dict(instance_0, kvs)

# Generated at 2022-06-25 16:14:53.261552
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow
    from marshmallow import Schema, fields

    class TestClass:
        def __init__(self, a: str, b: str, c: str=None,
                     d: int = 10):
            pass

        def __eq__(self, other):
            return isinstance(other, TestClass)

    schema = Schema()
    class_schema = marshmallow.fields.Nested(schema,
                                             unknown=marshmallow.EXCLUDE)


    class_dict = class_schema.dump(TestClass)
    assert class_dict == {'a': 'a',
                          'b': None,
                          'c': None,
                          'd': 10}


# Generated at 2022-06-25 16:14:59.212126
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    with raises(UndefinedParameterError):
        raise_undefined_parameters.handle_from_dict(
            cls=UndefinedParameters,
            kvs={"abc": 123, "not_known": 456})



# Generated at 2022-06-25 16:15:06.040950
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestingClass:
        def __init__(self, **kwargs):
            pass

    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    known = catch_all_undefined_parameters.handle_from_dict(TestingClass, {
        "abc": "def",
        "ghi": "jkl"
    })
    assert known == {"abc": "def", "ghi": "jkl"}



# Generated at 2022-06-25 16:15:16.963156
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    instance_0 = _RaiseUndefinedParameters()
    example_dict_0 = {}
    result_0 = raise_undefined_parameters.handle_from_dict(
        instance_0, example_dict_0)
    assert result_0 == {}
    example_dict_1 = {}
    call_0 = Callable()
    instance_1 = _RaiseUndefinedParameters()
    result_1 = raise_undefined_parameters.handle_from_dict(
        instance_1, example_dict_1)
    assert result_1 == {}
    example_dict_2 = {"example_key_0": 0}
    instance_2 = _RaiseUndefinedParameters()

# Generated at 2022-06-25 16:15:26.220161
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass0:
        pass
    test_instance0 = TestClass0()
    init_signature = inspect.signature(test_instance0.__init__)
    bound_parameters = init_signature.bind_partial()
    bound_parameters.apply_defaults()
    if bound_parameters.arguments != {'self': test_instance0}:
        raise AssertionError('Something else than the implicit self argument '
                             'is returned by inspect.signature')
    assert _UndefinedParameterAction.create_init(
        test_instance0) == test_instance0.__init__



# Generated at 2022-06-25 16:15:37.620712
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class _TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    original_init = _TestClass.__init__
    catch_all_init = _CatchAllUndefinedParameters.create_init(_TestClass)

    _TestClass.__init__ = original_init
    _TestClass(1, 2, 3, 4)  # Should raise TypeError
    _TestClass.__init__ = catch_all_init

    _TestClass(1, 2, 3, 4)  # Should be fine
    _TestClass(1, 2, 3, 4, 5)  # Should be fine

    _TestClass(1, 2, 3, b=4)  # Should be fine
    _TestClass(1, 2, 3, b=4, a=5)  # Should raise

# Generated at 2022-06-25 16:15:44.539957
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # noinspection PyTypeChecker
    ignore_undefined_parameter_action = _IgnoreUndefinedParameters()

    # noinspection PyUnusedLocal
    class ClassWithIgnoreUndefinedParameters:
        def __init__(self, a: int): pass

    # noinspection PyUnusedLocal
    class ClassWithIgnoreUndefinedParametersAndCatchAll:
        def __init__(self, a: int, catch_all: Optional[CatchAllVar]): pass

    # noinspection PyUnusedLocal
    class ClassWithIgnoreUndefinedParametersAndDefaultCatchAll:
        def __init__(self, a: int, catch_all: Optional[CatchAllVar] = {}):
            pass


# Generated at 2022-06-25 16:15:54.891778
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class DummyClass:
        def __init__(self, a: int, b: int, c: int=1, **kwargs):
            pass

    dummy_class_init = _CatchAllUndefinedParameters.create_init(DummyClass())
    dummy_class_init(DummyClass(), 1, 2, 3, d=4, e=5)
    dummy_class_init(DummyClass(), 1, 2, 3, e=5)
    dummy_class_init(DummyClass(), 1, 2, 3, d=4)
    dummy_class_init(DummyClass(), 1, 2, 3)



# Generated at 2022-06-25 16:15:59.056867
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_dump(obj="")


# Generated at 2022-06-25 16:16:04.142550
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    param_name = "x"
    setattr(test__UndefinedParameterAction_handle_to_dict, param_name,
            0)

    def test_case_0():
        assert _UndefinedParameterAction.handle_to_dict(
            test__UndefinedParameterAction_handle_to_dict,
            {
                param_name: 0
            }
        ) == {
            "x": 0
        }

    test_case_0()



# Generated at 2022-06-25 16:16:44.905345
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    class TestClass:
        def __init__(self, field_a, field_b: Optional[CatchAllVar] = None):
            self.field_a = field_a
            self.field_b = field_b


# Generated at 2022-06-25 16:16:50.956826
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        pass

    undefined_parameter_action = _UndefinedParameterAction()
    kvs = {
        "test_key": "test_value"
    }

    # case 0 - UnboundLocalError: local variable 'cls' referenced before assignment
    with pytest.raises(ValidationError) as info:
        undefined_parameter_action.handle_from_dict(kvs)
    assert "local variable 'cls' referenced before assignment" in str(info.value)

    # case 1 - expecting empty dict {}
    result = undefined_parameter_action.handle_from_dict(DummyClass, kvs)
    assert result == {}


# Generated at 2022-06-25 16:16:57.568162
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    test_case = {'some_key': 'some_value'}
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    assert catch_all_undefined_parameters.handle_to_dict(
        None, test_case) == test_case



# Generated at 2022-06-25 16:17:09.231696
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestCase:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

        @classmethod
        def _json_post_init(cls, args: Dict, kwargs: Dict):
            pass

        @classmethod
        def _json_ignore_undefined_parameters(
                cls, args: Dict, kwargs: Dict):
            pass

        @classmethod
        def _json_catch_all_undefined_parameters(
                cls, args: Dict, kwargs: Dict):
            pass

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b


# Generated at 2022-06-25 16:17:19.362346
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class CatchAllClass:
        def __init__(self, defined_parameter: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.defined_parameter = defined_parameter
            self.catch_all = catch_all

    class WrongCatchAllTypeClass:
        def __init__(self, defined_paramater: int,
                     catch_all: Optional[bool] = None):
            self.defined_parameter = defined_paramater
            self.catch_all = catch_all

    defined_parameter = 42
    undefined_parameter = "baz"
    class_instance = CatchAllClass(defined_parameter=defined_parameter,
                                   catch_all={undefined_parameter:
                                                  undefined_parameter})


# Generated at 2022-06-25 16:17:26.838219
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class MyClass:
        a: int
        b: str

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class MyOtherClass:
        a: int
        b: str
        my_class: MyClass

    my_class_init = _CatchAllUndefinedParameters.create_init(MyClass)
    try:
        my_class_init(MyClass(), 1, 2)
        assert False, "Should have raised an exception, because too many " \
                      "arguments were passed."
    except TypeError:
        pass

    my_class_init(MyClass(), 1, "b")


# Generated at 2022-06-25 16:17:32.503436
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class A:
        def __init__(self, a: int, b: str, c: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            self.c = c

    a = A(10, "Hello", {"a": 12})
    result = _CatchAllUndefinedParameters.handle_dump(a)
    assert result == {"a": 12}



# Generated at 2022-06-25 16:17:42.706904
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, x: str, y: int = 3, *args, **kwargs) -> None:
            self.x = x
            self.y = y
            self.args = args
            self.kwargs = kwargs

        def __eq__(self, other):
            return self.x == other.x and self.y == other.y and \
                   self.args == other.args and self.kwargs == other.kwargs

        def __repr__(self):
            return f"Test(x={self.x}, y={self.y}, args={self.args}, " \
                   f"kwargs={self.kwargs})"

    test_function = _IgnoreUndefinedParameters._create_init(Test)
    assert test_function.__name__ == "__init__"

# Generated at 2022-06-25 16:17:54.470969
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class HasNoCatchAll:
        def __init__(self, a: str, b: str, c: str):
            pass

    class HasCatchAll:
        def __init__(self, a: str, b: Optional[CatchAllVar]):
            pass

    class HasCatchAllWithDefault:
        def __init__(self, a: str, b: Optional[CatchAllVar] = None):
            pass

    class HasCatchAllWithDefaultFactory:
        def __init__(self, a: str,
                     b: Optional[CatchAllVar] = dataclasses.field(
                         default_factory=dict)):
            pass

    def check(cls):
        catch_all_undefined_parameters = _CatchAllUndefinedParameters()
        new_init = catch_all_undefined

# Generated at 2022-06-25 16:18:03.200432
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    class _Class():
        def __init__(self, field1, catch_all=None):
            self.field1 = field1
            self.catch_all = catch_all

    cls = _Class
    kvs = {"field1": "value1", "key2": "value2"}
    param = kvs
    class_fields = fields(cls)
    field_names = ["field1"]
    known_given_parameters = {k: v for k, v in class_fields.items() if
                              k in field_names}
    unknown_given_parameters = {k: v for k, v in class_fields.items() if
                                k not in field_names}
    number_of_catchall_fields

# Generated at 2022-06-25 16:18:49.553977
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def __init__(self, x: int, y: int, z: int,
                 catch_all: CatchAllVar = None):
        pass

    def __init__(self, x: int, y: int, z: int, self2: str,
                 catch_all: CatchAllVar = None):
        pass
    x_0 = _CatchAllUndefinedParameters._get_catch_all_field(__init__)
    x_1 = inspect.signature(__init__)



# Generated at 2022-06-25 16:18:54.174173
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    known_given_parameters_0 = {}
    kvs = {}
    cls = Undefined.INCLUDE
    assert undefined_parameter_action_0._separate_defined_undefined_kvs(
        cls, kvs) == (known_given_parameters_0, {})


# Generated at 2022-06-25 16:19:06.514973
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test case with undefined parameters
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    catch_all = "catch-all"
    dict_dict_1: Dict
    dict_dict_1 = {"parameter-dict": "dict"}
    field_field_1 = Field(name="parameter-dict", type=Optional[CatchAllVar])
    dict_kvs_1: Dict
    dict_kvs_1 = {"parameter-parameter": "parameter", "parameter-dict": "dict",
                  "dict": "dict"}
    dict_known_1: Dict
    dict_known_1 = {"parameter-parameter": "parameter"}
    dict_unknown_1: Dict

# Generated at 2022-06-25 16:19:12.193011
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    test__CatchAllUndefinedParameters_handle_from_dict_0 = _CatchAllUndefinedParameters()
    test__CatchAllUndefinedParameters_handle_from_dict_1: Dict[Any, Any] = {"attr_0": "a", "attr_1": "b", "attr_2": "c"}

    result = test__CatchAllUndefinedParameters_handle_from_dict_0.handle_from_dict(test__CatchAllUndefinedParameters_handle_from_dict_1)
    assert result == {"attr_0": "a", "attr_1": "b", "attr_2": "c"}


test_case_0()
test__CatchAllUndefinedParameters_handle_from_dict()

# Generated at 2022-06-25 16:19:22.550951
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # static function for this test
    def test_function(arg1: CatchAll, arg2: int, arg3: str, arg4: int=0):
        pass

    @functools.wraps(test_function)
    def new_function(self, *args, **kwargs):
        test_function(self, *args, **kwargs)

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    undefined_0 = _CatchAllUndefinedParameters()
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(undefined_0)
    new_callable_0 = catch_all_undefined_parameters_0.create_init(test_function)
    new_

# Generated at 2022-06-25 16:19:34.262503
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Special test case for mypy type checker, to get it to understand the 
    correct return type of _CatchAllUndefinedParameters.handle_from_dict
    """
    class Foo:
        def __init__(self, a: int, b: int, c: int) -> None:
            self.a = a
            self.b = b
            self.c = c
    kvs: Dict[str, Any] = {'a': 1, 'b': 2, 'c': 3}
    kvs = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs)
    assert(kvs['a'] == 1)
    assert(kvs['b'] == 2)
    assert(kvs['c'] == 3)

# Generated at 2022-06-25 16:19:39.556986
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class _TestCatchAll():
        def __init__(self, a: str, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
    
    class _TestRaise():
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b

    catch_all_init = _CatchAllUndefinedParameters.create_init(_TestCatchAll)
    with pytest.raises(UndefinedParameterError) as e:
        catch_all_init(d=8)
        assert "Received undefined initialization arguments {'d': 8}" in str(
            e)
    catch_all_init(8, 8)
    catch_all_init(8, 8, d=8)


# Generated at 2022-06-25 16:19:46.354641
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()

    test_case_0()
    # Test case containing all the tested methods
    try:
        catch_all_undefined_parameters_0.handle_to_dict("NoArguments", {"x": 4})
    except UndefinedParameterError:
        print("UndefinedParameterError raised unexpectedly.\n")
    # Test case containing all the tested methods
    try:
        catch_all_undefined_parameters_0.handle_to_dict("NoArguments", "x")
    except UndefinedParameterError:
        print("UndefinedParameterError raised unexpectedly.\n")
    # Test case containing all the tested methods

# Generated at 2022-06-25 16:19:52.206958
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    v1_0 = {}
    cls_0 = _RaiseUndefinedParameters
    v1_1 = cls_0.handle_from_dict(cls=cls_0,kvs=v1_0)
    v1_2 = {}
    assert v1_1 == v1_2


# Generated at 2022-06-25 16:20:00.843002
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.RAISE)
    @dataclasses.dataclass
    class Class0:
        f0: str
        f1: int
        f2: bool
        f3: "Class0"

    class0 = Class0("str", int(), bool(), None)
    assert class0 != None

    instance0 = _IgnoreUndefinedParameters()
    assert instance0 != None

    assert callable(callable_0)
    assert callable_0(class0) == None



# Generated at 2022-06-25 16:21:48.330448
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class CatchAllTest0:
        def __init__(self, a=1, b=2, c=3):
            pass

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_0 = catch_all_undefined_parameters_0.create_init(CatchAllTest0)
    assert callable(callable_0)
    callable_0(CatchAllTest0())


# Generated at 2022-06-25 16:21:53.394905
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(ValidationError):
        raise UndefinedParameterError()
    try:
        raise UndefinedParameterError()
    except ValidationError:
        pass

#Unit test for default factory of enum Undefined

# Generated at 2022-06-25 16:22:06.825664
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    kvs_0 = {}; kvs_1 = {}; kvs_2 = {}; kvs_3 = {}; kvs_4 = {}; kvs_5 = {}; kvs_6 = {}; kvs_7 = {}; kvs_8 = {}; kvs_9 = {}; kvs_10 = {}; kvs_11 = {}; kvs_12 = {}
    kvs_13 = {}; kvs_14 = {}; kvs_15 = {}; kvs_16 = {}; kvs_17 = {}; kvs_18 = {}; kvs_19 = {};

    cls_0 = lambda : None

    ret_0 = _CatchAllUndefinedParameters.handle_from_dict(cls_0, kvs_0)

    assert(True)


# Generated at 2022-06-25 16:22:08.625728
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_parameter_error_0 = UndefinedParameterError("")


# Generated at 2022-06-25 16:22:18.840904
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    undefined_0 = _UndefinedParameterAction()
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()

    class ClassWithCatchAll:

        def __init__(self, **kwargs):
            pass

    catch_all_field_0 = catch_all_undefined_parameters_1._get_catch_all_field(
        ClassWithCatchAll)

    kv_0 = {catch_all_field_0.name: {}}
    undefined_parameter_action_0 = catch_all_undefined_parameters_1.handle_from_dict(
        ClassWithCatchAll, kv_0)


# Generated at 2022-06-25 16:22:25.715468
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class CatchAllUndefinedParameters_handle_from_dict_class_0:
        def __init__(self, a: str, b: str, c: int) -> None:
            self.a = a
            self.b = b
            self.c = c
            pass

    # Test default case
    kvs = {}
    expected_value = {'a': None, 'b': None, 'c': 0}
    actual_value = _CatchAllUndefinedParameters.handle_from_dict(CatchAllUndefinedParameters_handle_from_dict_class_0, kvs)
    assert expected_value == actual_value

    # Test default case
    kvs = {'a': 'str', 'b': 'str'}
    expected_value = {'a': 'str', 'b': 'str', 'c': 0}

# Generated at 2022-06-25 16:22:36.147400
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a: str, b: int, c: bool = True, d: int = 10):
            self._a = a
            self._b = b
            self._c = c
            self._d = d

    def create_init(obj) -> Callable:
        original_init = obj.__init__
        init_signature = inspect.signature(original_init)

        @functools.wraps(obj.__init__)
        def _ignore_init(self, *args, **kwargs):
            known_kwargs, _ = \
                _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
                    obj, kwargs)
            num_params_takeable = len(
                init_signature.parameters) - 1  # don

# Generated at 2022-06-25 16:22:45.579362
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs_0 = {'a': 3, 'b': '3'}
    class_fields_0 = fields({'a': 3, 'b': '3'})
    field_names_0 = [field.name for field in class_fields_0]
    unknown_given_parameters_0 = {k: v for k, v in kvs_0.items() if k not in field_names_0}
    known_given_parameters_0 = {k: v for k, v in kvs_0.items() if k in field_names_0}
    # Test for an exception
    try:
        _IgnoreUndefinedParameters.handle_from_dict({'a': 3, 'b': '3'}, kvs_0)
    except UndefinedParameterError as e:
        print(e)

# Unit test