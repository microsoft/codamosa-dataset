

# Generated at 2022-06-25 16:12:55.385162
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Some error happened")
    except UndefinedParameterError as err:
        assert type(err).__name__ == "UndefinedParameterError"


# Generated at 2022-06-25 16:12:59.479909
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err_msg = "test"
    UndefinedParameterError(err_msg)

# Generated at 2022-06-25 16:13:03.641650
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    given = {'a': '1', 'b': '2', 'd': '3'}
    expected = {'a': '1', 'b': '2'}
    result = _UndefinedParameterAction.handle_from_dict(None, given)
    assert result == expected, "Test fail"

# Generated at 2022-06-25 16:13:12.161711
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Test 0: CatchAll field is not in kvs
    class C0(object):
        pass
    kvs = {}
    actual = _CatchAllUndefinedParameters.handle_to_dict(C0, kvs)
    assert actual == kvs

    # Test 1: CatchAll field is in kvs but no undefined parameters were
    # supplied
    # This is the case when the user gave a different value for the
    # catch_all_field.
    class C1(object):
        isCatchAllField = CatchAll

    kvs = {"isCatchAllField": {"a": 2}}
    actual = _CatchAllUndefinedParameters.handle_to_dict(C1, kvs)
    assert actual == kvs

    # Test 2: CatchAll field is in kvs and so are undefined parameters

# Generated at 2022-06-25 16:13:24.516851
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    def prepare(cls, kvs: Dict[Any, Any]) -> UnknownParameters:
        known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=cls, kvs=kvs)
        return unknown

    class TestClass0:
        def __init__(self, arg: int):
            self.a = arg

    class TestClass1:
        def __init__(self, arg: int, arg2: str):
            self.a = arg
            self.b = arg2

    unknown_arguments_0 = prepare(TestClass0, {"arg": "42",
                                               "unknown": "bla"})

# Generated at 2022-06-25 16:13:31.805863
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a, b=None, c=None,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    # Create instance with all fields defined
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)
    instance = TestClass(1, 2, 3)
    new_init(instance, 1, 2, 3)
    assert instance.a == 1
    assert instance.b == 2
    assert instance.c == 3
    assert instance.catch_all == {}

    # Create instance with all fields defined
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)
    instance = TestClass

# Generated at 2022-06-25 16:13:36.471154
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        undefined_parameter_action_0 = _UndefinedParameterAction()
    except UndefinedParameterError as undefined_parameter_error:
        assert str(undefined_parameter_error)=="Can not instantiate abstract class"



# Generated at 2022-06-25 16:13:39.636675
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class X:
        a: str

    _RaiseUndefinedParameters.handle_from_dict(cls=X, kvs={"a": "b"})
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=X, kvs={"a": "b",
                                                                "c": 3})
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError("No exception raised")



# Generated at 2022-06-25 16:13:49.371267
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestObj:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     f: str="Foo") -> None:
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
    t = TestObj(1, 2, 3, 4, 5)
    p = _IgnoreUndefinedParameters()
    init_replacement = p.create_init(t)
    t_prime = TestObj(1, 2, 3, 4, 5, 6, 7, 8, 9, f="foo")
    init_replacement(t_prime, 1, 2, 3, 4, 5, 6, 7, 8)
    assert t_prime.a == 1

# Generated at 2022-06-25 16:13:51.714696
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass0:
        def __init__(self, arg1: int, arg2: str):
            pass
    assert "self" in getattr(_IgnoreUndefinedParameters.create_init(
        TestClass0), "__code__").co_varnames



# Generated at 2022-06-25 16:14:07.990436
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_parameter_action = _UndefinedParameterAction()
    assert undefined_parameter_action.handle_dump(None) == {}



# Generated at 2022-06-25 16:14:12.384170
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    dump_data = {"foo": "bar"}

    # Don't care about the class, just need a class instance that has a
    # dictionary attribute "dump_data"
    @dataclasses.dataclass
    class DummyClass:
        dump_data: Dict[Any, Any]
        catch_all: Optional[CatchAllVar] = None

    dummy_class = DummyClass(dump_data={})
    from_to_dict_data = {}
    assert _CatchAllUndefinedParameters.handle_dump(obj=dummy_class) == \
           from_to_dict_data

    dummy_class = DummyClass(dump_data=dump_data)
    assert _CatchAllUndefinedParameters.handle_dump(obj=dummy_class) == \
           dump_data



# Generated at 2022-06-25 16:14:13.309750
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # This function does nothing
    pass


# Generated at 2022-06-25 16:14:18.688468
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    action = _UndefinedParameterAction()
    kvs = {"stuff": [], "more_stuff": {}}
    with pytest.raises(NotImplementedError):
        action.handle_from_dict(object, kvs)



# Generated at 2022-06-25 16:14:22.639753
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class MyClass:
        a = 'a'

        def __init__(self, a: str, catch_all: Optional[CatchAll] = {}):
            self.a = a
            self.catch_all = catch_all

    # case 1: no input arguments
    arg_dict = {}
    output_dict = _CatchAllUndefinedParameters.handle_from_dict(cls=MyClass,
                                                                kvs=arg_dict)
    assert {} == output_dict

    # case 2: normal initialization
    arg_dict = {'a': 'xyz'}
    output_dict = _CatchAllUndefinedParameters.handle_from_dict(cls=MyClass,
                                                                kvs=arg_dict)
    assert {'a': 'xyz', 'catch_all': {}} == output

# Generated at 2022-06-25 16:14:34.678227
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    def _test(test_action: _UndefinedParameterAction,
              error_expected: bool = False):
        class MyClass:
            def __init__(self, a, b=None, c: CatchAll = None) -> None:
                pass

        params = test_action.handle_from_dict(MyClass, {"a": 3, "b": 1,
                                                         "d": 5})
        assert params == {"a": 3, "b": 1}
        if error_expected:
            try:
                test_action.handle_from_dict(MyClass, {"a": 3, "d": 5})
                assert False
            except UndefinedParameterError:
                pass

# Generated at 2022-06-25 16:14:35.532941
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    pass


# Generated at 2022-06-25 16:14:45.402743
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    import typing

    @dataclass
    class TestClass:
        catch_all: typing.Optional[CatchAllVar]
        x: int
        y: int

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = TestClass(1, 2, catch_all={'a': 5})
    obj.x = 5
    init(obj, 1, 2, x=5)
    assert obj.x == 1
    assert obj.y == 2
    assert obj.catch_all == {'x': 5}



# Generated at 2022-06-25 16:14:49.844260
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    obj = CatchAllModel(**{"catch_all": {"hello": "world"}, "hello": "world"})
    kvs = {"hello": "world"}
    caught_kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert(caught_kvs == {"hello": "world"})



# Generated at 2022-06-25 16:14:57.007670
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _Test:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    for input_dictionary in [{"a": 10, "c": {}, "b": 20, "not_used": "a"},
                             {"c": {}, "a": 10, "b": 20}]:
        output_dictionary = _CatchAllUndefinedParameters.handle_from_dict(
            _Test, input_dictionary)
        assert output_dictionary["a"] == 10
        assert output_dictionary["b"] == 20
        assert isinstance(output_dictionary["c"], dict)
        assert len(output_dictionary["c"]) == 1



# Generated at 2022-06-25 16:15:20.077355
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Default behavior
    expect_0 = {'_UNKNOWN0': '0.0'}
    actual_0 = _CatchAllUndefinedParameters.handle_from_dict(None, {'_UNKNOWN0': '0.0'})
    assert actual_0 == expect_0

    expect_1 = {'_UNKNOWN0': '0.0'}
    actual_1 = _CatchAllUndefinedParameters.handle_from_dict(None, {'_UNKNOWN0': '0.0'})
    assert actual_1 == expect_1

    expect_2 = {'_UNKNOWN0': '0.0'}
    actual_2 = _CatchAllUndefinedParameters.handle_from_dict(None, {'_UNKNOWN0': '0.0'})
    assert actual_2 == expect_2

    expect

# Generated at 2022-06-25 16:15:22.468542
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_message_0 = 'UndefinedParameterError'
    undefined_parameter_error_0 = UndefinedParameterError(
        error_message_0)

# Generated at 2022-06-25 16:15:33.033723
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters

# Generated at 2022-06-25 16:15:39.639765
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    string_0 = "e"
    str_1 = str(string_0)
    dict_0 = {str_1: str_1}
    list_0 = []
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    result = ignore_undefined_parameters_0.handle_from_dict(dict_0, dict_0)
    assert result == {str_1: str_1}



# Generated at 2022-06-25 16:15:48.908083
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Arrange
    str_0 = "5"
    undefined_parameter_action_0 = _UndefinedParameterAction()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*[])

    # Act
    result = catch_all_undefined_parameters_0.handle_to_dict(undefined_parameter_action_0, str_0)

    # Assert
    assert result is str_0


# Generated at 2022-06-25 16:15:52.926672
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    float_0 = -943.09
    dict_0 = {float_0: float_0}
    list_0 = [False]
    list_1 = [float_0, float_0]
    callable_0 = _UndefinedParameterAction._separate_defined_undefined_kvs
    callable_1 = _RaiseUndefinedParameters.handle_from_dict
    callable_2 = callable_0(dict_0, list_0)
    callable_3 = callable_1(dict_0, list_1)
    callable_0 = callable_2.update(callable_3)
    callable_2 = _RaiseUndefinedParameters()

# Generated at 2022-06-25 16:15:59.197994
# Unit test for method create_init of class _UndefinedParameterAction

# Generated at 2022-06-25 16:16:01.329400
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        UndefinedParameterError('error message')
    except Exception as e:
        assert isinstance(e, UndefinedParameterError)



# Generated at 2022-06-25 16:16:03.943166
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    list_0 = []
    undefined_parameter_action_0 = _UndefinedParameterAction(*list_0)
    assert undefined_parameter_action_0.handle_from_dict(dict_0) == dict_0


# Generated at 2022-06-25 16:16:05.698996
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # Write code here to test method _UndefinedParameterAction.create_init
    pass



# Generated at 2022-06-25 16:16:44.984419
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class_0 = _RaiseUndefinedParameters
    list_0 = []
    set_0 = set(list_0)
    float_0 = -915.14
    float_1 = -539.7
    float_2 = -739.79
    float_3 = -906.8
    float_4 = 717.41
    float_5 = -854.29
    float_6 = -673.3
    float_7 = 291.59
    float_8 = -839.56
    float_9 = -354.68
    float_10 = -927.38
    float_11 = 971.44
    float_12 = -729.93
    float_13 = -927.97
    float_14 = -853.53
    float_15 = -166.61
   

# Generated at 2022-06-25 16:16:51.899086
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'parameter'
    field_0 = Field(field_name=str_0, type_=str_0, default=str_0)
    list_0 = [field_0]
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    str_1 = 'parameter'
    field_1 = Field(field_name=str_1, type_=str_1, default=str_1)
    list_1 = [field_1]
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters(*list_1)
    str_2 = 'custom_schema'
    dict_0 = {str_2: str_2}
    dict_1 = dict_0

# Generated at 2022-06-25 16:16:58.117541
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    list_0 = []
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)

    float_0 = -943.09
    dict_0 = {float_0: float_0}
    callable_0 = ignore_undefined_parameters_0.create_init(dict_0)
    # ensure the returned function does not raise an exception
    callable_0()


# Generated at 2022-06-25 16:17:06.703498
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    float_0 = -366.62
    dict_0 = {float_0: float_0}
    list_0 = []
    undefined_parameter_action_0 = _UndefinedParameterAction(*list_0)
    print(undefined_parameter_action_0.handle_dump(dict_0))
    # Test error cases
    catch_0 = UndefinedParameterError
    try:
        undefined_parameter_action_0.handle_dump(dict_0, dict_0)
    except catch_0 as caught_exc_0:
        print(caught_exc_0)


# Generated at 2022-06-25 16:17:16.410403
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = dict()
    dict_0["dict_0"] = dict_0

    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    params_0 = ignore_undefined_parameters_0.handle_to_dict(
        dict_0, dict_0)

    assert params_0 == dict()

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    params_1 = catch_all_undefined_parameters_0.handle_to_dict(
        dict_0, dict_0)

    expected_params_1 = dict()
    expected_params_1['dict_0'] = dict_0

    assert params_1 == expected_params_1
    assert dict_0 == dict()

    raise_undefined_parameters_0 = _Raise

# Generated at 2022-06-25 16:17:25.384244
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    list_0 = []
    class_0 = _CatchAllUndefinedParameters(*list_0)
    float_0 = -838.46
    tuple_0 = (float_0, float_0)
    float_1 = -612.47
    float_2 = float_0
    list_1 = []
    list_1.append(float_1)
    list_1.append(float_2)
    tuple_1 = tuple(list_1)
    str_0 = None
    set_0 = set()
    list_2 = []
    list_2.append(str_0)
    list_2.append(None)
    tuple_2 = tuple(list_2)
    list_3 = []
    list_3.append(set_0)
    list_3.append(set_0)

# Generated at 2022-06-25 16:17:31.901563
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    float_0 = -943.09
    dict_0 = {float_0: float_0}
    list_0 = []
    is_instance_0 = isinstance(_UndefinedParameterAction(),
                               _UndefinedParameterAction)
    if is_instance_0:
        try:
            _UndefinedParameterAction.handle_dump(dict_0)
        except TypeError:
            pass
    else:
        assert True


# Generated at 2022-06-25 16:17:42.375618
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # dict_0 and dict_1 are empty
    dict_0 = {}
    dict_1 = {}
    float_0 = 267.8661
    float_1 = -538.7506
    list_0 = [float_0, float_0, float_1]
    # dict_2 and dict_3 are empty, dict_2 and dict_3 are not instances of dict
    list_1 = [dict_0, dict_0, dict_0]
    _CatchAllUndefinedParameters._get_catch_all_field(dict_0)
    dict_4 = dict_0.copy()
    dict_4[float_0] = float_1
    dict_4[float_1] = dict_0
    dict_4[float_1] = float_1
    dict_4[float_1] = float_0

# Generated at 2022-06-25 16:17:48.686810
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    with pytest.raises(ValidationError) as raised_exception_0:
        undefined_parameter_action_0._UndefinedParameterAction__handle_to_dict()
    raised_exception_0.match(r'"UndefinedParameterAction" is not callable')


# Generated at 2022-06-25 16:17:54.640003
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Arrange
    _CatchAllUndefinedParameters = _CatchAllUndefinedParameters()

    # Act
    #_CatchAllUndefinedParameters.handle_from_dict(cls, kvs)

    # Assert
    pass



# Generated at 2022-06-25 16:18:59.061342
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    float_0 = -943.09
    dict_0 = {float_0: float_0}
    list_0 = []
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    assert ignore_undefined_parameters_0.handle_dump(dict_0) == {}
    raise NotImplementedError()


# Generated at 2022-06-25 16:19:01.200774
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    assert False, "unimplemented"


# Generated at 2022-06-25 16:19:05.919103
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    dict_0 = {None: None, "}e`4": "}e`4"}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_from_dict(dict_0, dict_0)



# Generated at 2022-06-25 16:19:10.495309
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    float_0 = -943.09
    dict_0 = {float_0: float_0}
    list_0 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    callable_0 = catch_all_undefined_parameters_0.create_init(dict_0)



# Generated at 2022-06-25 16:19:19.286866
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test using a defined parameter
    catch_all_field = CatchAllVar("catch_all", default={}, repr=True,
                                  compare=False, hash=None, init=True,
                                  metadata=None)
    float_0 = -943.09
    dict_0 = {float_0: float_0}
    list_0 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    assert \
        catch_all_undefined_parameters_0.handle_from_dict(dict_0,
                                                          catch_all_field) == {
                                                             float_0: float_0,
                                                             "catch_all": {}}

    # Test using the default value

# Generated at 2022-06-25 16:19:22.433498
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    float_0 = -841.5
    dict_0 = {float_0: float_0}
    undefined_parameter_action_0 = _CatchAllUndefinedParameters()
    dict_1 = undefined_parameter_action_0.handle_to_dict(dict_0, dict_0)
    assert dict_0 == dict_1


# Generated at 2022-06-25 16:19:34.160604
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'zQf.kxhJ?QP+'
    str_1 = 'p9X]FOUJ}/'
    str_2 = 'l]NLwI'
    str_3 = '}v$?X'
    float_0 = -23.519
    float_1 = -869.545
    float_2 = -977.131
    float_3 = -109.899
    dict_0 = {str_0: float_0, str_1: float_1, str_2: float_2, str_3: float_3}
    list_0 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(
        *list_0)
    dict_1 = {}
    dict_1.update(dict_0)


# Generated at 2022-06-25 16:19:44.251492
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = {}
    dict_1 = {1: 1}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}

# Generated at 2022-06-25 16:19:54.768911
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    list_0 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    undefined_parameter_action_0 = _UndefinedParameterAction()
    # Test raise
    try:
        catch_all_undefined_parameters_0.handle_from_dict(undefined_parameter_action_0, undefined_parameter_action_0)
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError("Expected Exception to be raised")



# Generated at 2022-06-25 16:19:59.951063
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class_0 = UndefinedParameterError
    dict_0 = dict()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*dict_0)
    callable_0 = catch_all_undefined_parameters_0.create_init(class_0)

