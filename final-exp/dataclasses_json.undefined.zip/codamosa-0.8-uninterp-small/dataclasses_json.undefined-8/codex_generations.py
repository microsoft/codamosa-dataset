

# Generated at 2022-06-25 16:13:06.273213
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    undefined_1 = Undefined.INCLUDE

    # Define dataclass
    @dataclasses.dataclass(frozen=True)
    class A:
        a: int
        b: int

    # Define a subclass with a catch-all field
    @dataclasses.dataclass(frozen=True,
                           undefined=undefined_1)
    class B(A):
        c: Optional[CatchAllVar] = dataclasses.field(default_factory=dict,
                                                      init=False)

    # Instantiate
    b1 = B(a=1, b=2, d=3, e=4)
    assert b1.a == 1
    assert b1.b == 2
    assert b1.c == {'d': 3, 'e': 4}



# Generated at 2022-06-25 16:13:13.719458
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestData:
        field_1: str
        field_2: Optional[str]
        field_3: Optional[CatchAllVar]

    def test_func(test_data: TestData, kvs: Dict, expected_output: Dict):
        assert _CatchAllUndefinedParameters.handle_from_dict(
            TestData, kvs) == expected_output

    test_func(
        TestData,
        kvs={"field_1": "aaa"},
        expected_output={
            "field_1": "aaa",
            "field_2": None,
            "field_3": {}
        }
    )

# Generated at 2022-06-25 16:13:16.601162
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow.schema import Schema

    undefined = Undefined.EXCLUDE

    # Get the duck typed class
    result = undefined._value_.create_init(Schema)
    assert isinstance(result, Callable)



# Generated at 2022-06-25 16:13:27.298991
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Dummy:
        x: str
        y: int

    dummy = Dummy("x", 1)
    new_init = _IgnoreUndefinedParameters.create_init(Dummy)

    # Using the new init function is the same as using the old one
    dummy_new = new_init(dummy, "x", 1, z=2)
    dummy_old = Dummy.__init__(dummy, "x", 1, z=2)
    runtime_error_message = "Using the new init method should be the same as " \
                            "using the old one"
    assert dummy_new == dummy_old, runtime_error_message



# Generated at 2022-06-25 16:13:30.166701
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = object()
    kvs = {}
    returned_value = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert returned_value is kvs


# Generated at 2022-06-25 16:13:41.257246
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import marshmallow

    @dataclasses.dataclass
    class Foo:
        bar: int
        baz: int
        catch_all: Optional[CatchAll] = None

    foo_original = Foo(bar=1, baz=2)
    foo_ignore = Foo(1, 2)
    schema = marshmallow.Schema.from_dataclass(Foo)
    assert foo_original.bar == foo_ignore.bar
    assert foo_original.baz == foo_ignore.baz
    assert foo_original.catch_all == foo_ignore.catch_all
    assert int(schema.dumps(foo_original)) == int(schema.dumps(foo_ignore))

# Generated at 2022-06-25 16:13:48.346932
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()
    UndefinedParameterError(
        message="This is the message",
        field_names="field1,field2,field3")
    UndefinedParameterError(
        message="This is the message with a code",
        field_names="field1,field2,field3", code=500)
    UndefinedParameterError(message="This is the message with no field names")
    UndefinedParameterError(code=500)
    UndefinedParameterError(code=500,
                    message="This is the message with a code but no field names")

# Generated at 2022-06-25 16:13:49.748480
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}


# Generated at 2022-06-25 16:14:01.356302
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class_fields = fields(undefined_init(Undefined.INCLUDE))
    field_names = [field.name for field in class_fields]

    class_0 = undefined_init(Undefined.INCLUDE)
    test_params_0 = {"test_param_0": "test value 0",
                     "test_param_1": "test value 1",
                     "test_param_2": "test value 2",
                     "test_param_3": "test value 3"}
    class_0 = class_0(**test_params_0)


# Generated at 2022-06-25 16:14:06.553498
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    method = _UndefinedParameterAction.handle_to_dict
    result = method(obj=None, kvs={})
    assert result == {}
    result = method(obj=None, kvs={'a': 1, 'b': 2})
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-25 16:14:33.173295
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

    catch_all_dict = {"d": 1, "e": 2}
    kvs = {"a": 1, "b": 2, "c": catch_all_dict.copy(), "d": 3, "e": 4}
    TestClass(**kvs)
    TestClass(**{"a": 1, "b": 2, "c": kvs["c"]})
    TestClass(**kvs, **dict(d=1, e=2))

    kvs = {"a": 1, "b": 2, "c": catch_all_dict.copy(), "d": 3}

# Generated at 2022-06-25 16:14:36.456765
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Not yet implemented
    pass



# Generated at 2022-06-25 16:14:39.616103
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    kvs = {"a": 1, "b": 2, "undefined": {"c": 1, "d": 2}}
    expected = {"a": 1, "b": 2, "c": 1, "d": 2}
    actual = _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs=kvs)
    assert actual == expected

# Generated at 2022-06-25 16:14:42.703700
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_parameter_error = UndefinedParameterError("hello")
    assert(undefined_parameter_error)



# Generated at 2022-06-25 16:14:44.706356
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    a = _UndefinedParameterAction()
    assert a.handle_dump(obj = None) == {}



# Generated at 2022-06-25 16:14:45.724608
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    action = _UndefinedParameterAction



# Generated at 2022-06-25 16:14:50.724629
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    input_dict = {"A": 1, "B": 2, "C": 3}
    kvs = {"C": 3, "catch_all_field": {"A": 1, "B": 2}}
    returned_dict = \
        _CatchAllUndefinedParameters.handle_to_dict(None, kvs)
    assert returned_dict == input_dict



# Generated at 2022-06-25 16:14:55.623186
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_0 = Undefined.EXCLUDE
    undefined_1 = Undefined.INCLUDE
    undefined_2 = Undefined.RAISE
    _UndefinedParameterAction.handle_to_dict(undefined_0, Dict[Any, Any])
    _UndefinedParameterAction.handle_to_dict(undefined_1, Dict[Any, Any])
    _UndefinedParameterAction.handle_to_dict(undefined_2, Dict[Any, Any])
    pass



# Generated at 2022-06-25 16:15:07.582157
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    _ = _CatchAllUndefinedParameters  # Just to make PyCharm happy
    # Type: <class '__main__._UndefinedParameterAction'>
    undefined_parameter_action = Undefined.INCLUDE
    cls = _CatchAllUndefinedParameters
    _ = cls
    # Type: <class '__main__._CatchAllUndefinedParameters'>
    # noinspection PyProtectedMember
    assert cls._separate_defined_undefined_kvs(cls=cls, kvs={}) == ({}, {})
    assert cls._separate_defined_undefined_kvs(cls=cls, kvs={"a": 1}) == (
        {"a": 1}, {})

# Generated at 2022-06-25 16:15:18.331183
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # We will override the __init__ method of no_catch_all_class to get access
    # to the arguments it gets.
    class NoCatchAll:
        def __init__(self, a, b):
            self._a = a
            self._b = b

    no_catch_all_class = NoCatchAll(a=1, b=2)
    # noinspection PyProtectedMember
    assert _CatchAllUndefinedParameters.create_init(no_catch_all_class)(
        no_catch_all_class, a=3, b=4) == (3, 4)

    @dataclasses.dataclass
    class WithCatchAll:
        a: int = 0
        b: int = 1
        # noinspection PyTypeChecker

# Generated at 2022-06-25 16:15:39.639939
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters__0 = _CatchAllUndefinedParameters()
    class_0 = type(catch_all_undefined_parameters__0)
    kvs_0: Dict = {'a': 1}
    result = _CatchAllUndefinedParameters.handle_from_dict(class_0, kvs_0)
    print(result)



# Generated at 2022-06-25 16:15:43.147188
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test case where kvs has an unknown attribute
    expected = {'unknown': 'test'}
    test = _CatchAllUndefinedParameters()
    actual = test.handle_from_dict(None, expected)
    assert actual == expected


# Generated at 2022-06-25 16:15:48.312423
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'\x9e\xeb+\xc8'
    list_0 = [bytes_0, bytes_0, bytes_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(list_0)
    dict_0 = {callable_0: list_0, callable_0: callable_0}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    str_0 = raise_undefined_parameters_0.handle_from_dict(dict_0, bytes_0)
    assert str_0 is None


# Generated at 2022-06-25 16:16:00.353137
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18 = dict_17
    dict_19 = dict_18
    dict_20 = dict_19
    dict_21 = dict_20
    dict_

# Generated at 2022-06-25 16:16:05.283200
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    bytes_0 = b'w\x84\xf1\x89'
    list_0 = [bytes_0, bytes_0, bytes_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    dict_0 = ignore_undefined_parameters_0.handle_dump(list_0)
    dict_0 = dict_0
    # self.assertIsInstance(dict_0, dict)
    # self.assertEqual(len(dict_0), 0)


# Generated at 2022-06-25 16:16:15.825554
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    list_7 = []
    list_8 = []
    list_9 = []
    list_10 = []
    list_11 = []
    list_12 = []
    list_13 = []
    list_14 = []
    list_15 = []
    list_16 = []
    list_17 = []
    list_18 = []
    list_19 = []
    list_20 = []
    list_21 = []
    list_22 = []
    list_23 = []
    list_24 = []
    list_25 = []
    list_26 = []
    list_27 = []
    list_

# Generated at 2022-06-25 16:16:18.253613
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    obj = {}  # type: Any
    subj = _CatchAllUndefinedParameters()
    expected = object.__init__
    actual = subj.create_init(obj)
    assert actual == expected


# Generated at 2022-06-25 16:16:19.339805
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    test_case_0()

# Generated at 2022-06-25 16:16:29.657036
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # should not raise an exception

    @dataclasses.dataclass
    class Data:
        id: int
        foo: str
        undefined_parameters: Optional[CatchAllVar] = \
            dataclasses.field(default=None)

    # initialization with undefined parameters
    obj = Data(123, "hello world", undefined_parameters={"bar": "baz"})

    # test calling the method
    @functools.wraps(Data.__init__)
    def _catch_all_init(self, *args, **kwargs):
        known_kwargs, unknown_kwargs = \
            _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
                Data, kwargs)

# Generated at 2022-06-25 16:16:36.671226
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    bytes_0 = b'\xd3\x99N^\x18\xac\xd8'
    bytes_1 = b'\x9c\xc0\x93'
    list_0 = [bytes_0, bytes_1]
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    known_parameters, unknown_parameters = \
        catch_all_undefined_parameters_0.handle_from_dict(list_0)



# Generated at 2022-06-25 16:17:23.643681
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    dict_0 = {}
    dict_1 = {"_UNKNOWN0": "{}"}
    dict_2 = {"_UNKNOWN0": "{}", "_UNKNOWN1": "{}"}
    dict_3 = {"_UNKNOWN0": "{}", "_UNKNOWN1": "{}", "_UNKNOWN2": "{}"}
    dict_4 = {"_UNKNOWN0": "{}", "{}": "{}"}
    dict_5 = {"_UNKNOWN0": "{}", "{}": "{}", "_UNKNOWN1": "{}"}
    dict_6 = {"_UNKNOWN0": "{}", "{}": "{}", "_UNKNOWN1": "{}",
              "_UNKNOWN2": "{}"}

# Generated at 2022-06-25 16:17:32.964374
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    list_0 = [None, '\x9e', '\x9e\xeb+\xc8', '\xeb', '\xeb+\xc8']
    bytes_0 = b'\x9e\xeb+\xc8'
    list_1 = [bytes_0, bytes_0, bytes_0]
    dict_0 = {'\x9e\xeb+\xc8': list_1, '\x9e': None, '\xeb+\xc8': None}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.handle_to_dict(list_0, dict_0)


# Generated at 2022-06-25 16:17:41.704153
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'\x9e\xeb+\xc8'
    list_0 = [bytes_0, bytes_0, bytes_0]
    dict_2 = {list_0: bytes_0}
    list_2 = [bytes_0, bytes_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(
        list_2, dict_2)
    dict_0 = {dict_1: dict_1}
    assert dict_0 == {dict_1: dict_1}


# Generated at 2022-06-25 16:17:49.712216
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    str_0 = 'p0'
    str_1 = 'p1'
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = {str_0: str_1}
    dict_1 = raise_undefined_parameters_0.handle_to_dict(dict_0, dict_0)
    assert dict_1 == dict_0



# Generated at 2022-06-25 16:18:01.062732
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:18:06.649809
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = {}
    dict_1 = {_CatchAllUndefinedParameters: dict_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(
        **dict_1)
    dict_2 = {_CatchAllUndefinedParameters: dict_0}
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters(
        **dict_2)
    dict_3 = {
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            catch_all_undefined_parameters_0, dict_0): dict_0}
    catch_all_undefined_parameters_1._CatchAllUndefinedParameters__get_catch_all_field(
        **dict_3)
    dict_4 = {}
    catch_all_

# Generated at 2022-06-25 16:18:11.352691
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    callable_0 = _CatchAllUndefinedParameters.handle_to_dict
    list_0 = list()
    unknown_undefined_parameters_0 = callable_0(list_0, {'a': 'b'})
    assert unknown_undefined_parameters_0 == dict({'a': 'b'})



# Generated at 2022-06-25 16:18:12.397050
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    test_case_0()


# Generated at 2022-06-25 16:18:22.822690
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class_0 = _CatchAllUndefinedParameters()
    dict_0 = dict()
    dict_0["dict_0"] = dict()
    dict_0["dict_1"] = dict()
    dict_1 = dict()
    dict_1["dict_0"] = dict_0
    dict_1["dict_1"] = dict_0
    dict_1["dict_2"] = dict_0
    dict_1["dict_3"] = dict_0
    dict_1["dict_4"] = dict_0
    dict_1["dict_5"] = dict_0
    dict_2 = dict()
    dict_2["dict_0"] = dict_1
    dict_2["dict_1"] = dict_1
    dict_2["dict_2"] = dict_1
    dict_2["dict_3"]

# Generated at 2022-06-25 16:18:27.718301
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # catch_all_field = _CatchAllUndefinedParameters._get_catch_all_field(
    #     cls=obj)
    dict_0 = {'\x9e\xeb+\xc8': _CatchAllUndefinedParameters.handle_from_dict}
    _CatchAllUndefinedParameters.handle_from_dict(**dict_0)



# Generated at 2022-06-25 16:19:09.910200
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # _CatchAllUndefinedParameters.handle_from_dict should return a dict with
    # all kvs in cls but undefined parameters
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    cls_0 = list_0

# Generated at 2022-06-25 16:19:19.268728
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # For the tested method to work, an instance of type CatchAllUndefinedParameters must be created before
    catchAllUndefinedParameters_instance = _CatchAllUndefinedParameters
    data_dict = {}
    data_dict['catch_all_field'] = 'test_catch_all_field'

    list_of_inputs = [{}, {'test': 1}, {'test': 1, 'test2': 2, 'test3': 3}]

    output_list = [{'catch_all_field': 'test_catch_all_field'},
                   {'test':1,'catch_all_field': 'test_catch_all_field'},
                   {'test':1,'test2':2,'test3':3,'catch_all_field': 'test_catch_all_field'}]


# Generated at 2022-06-25 16:19:31.232061
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class_0 = dataclasses.make_dataclass('class_0', [('one', int)])

    bytes_0 = b'\x9e\xeb+\xc8'
    list_0 = [bytes_0, bytes_0, bytes_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(list_0)
    dict_0 = {callable_0: list_0, callable_0: callable_0}
    list_1 = [dict_0]
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    callable_2 = raise_undefined_parameters_0.handle_from_dict(list_1)

# Generated at 2022-06-25 16:19:32.553160
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert _UndefinedParameterAction.handle_from_dict(list(), dict()) == dict()



# Generated at 2022-06-25 16:19:34.156800
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    obj_0 = _CatchAllUndefinedParameters()
    obj_0.handle_to_dict()


# Generated at 2022-06-25 16:19:39.458099
# Unit test for method create_init of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:19:46.304831
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    dict_0: Dict[str, Any] = {}
    list_0 = [dict_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(list_0)
    dict_1 = {callable_0: list_0, callable_0: callable_0}
    list_1 = [dict_1]
    ignore_undefined_parameters_1 = _IgnoreUndefinedParameters()
    callable_1 = ignore_undefined_parameters_1.create_init(list_1)
    dict_2 = {callable_1: list_1, callable_1: callable_0}
    list_2 = [dict_2]
    catch_all_undefined_parameters_

# Generated at 2022-06-25 16:19:55.496580
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    list_0 = [2, 3]
    bytes_0 = b'\x9e\xeb+\xc8'
    dict_0 = {bytes_0: bytes_0, bytes_0: list_0}
    unknown_given_parameters_0 = dict_0
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    try:
        known_given_parameters = \
            raise_undefined_parameters_0.handle_from_dict(unknown_given_parameters_0)
        raise Exception()
    except UndefinedParameterError:
        pass


# Generated at 2022-06-25 16:20:00.367662
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    dict_0 = {}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*())
    _RaiseUndefinedParameters.handle_from_dict(catch_all_undefined_parameters_0, dict_0)


# Generated at 2022-06-25 16:20:03.950216
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    bytes_0 = b'go\x10\xed\xe2\x88\x7f\x870\xcc\xb9\xd4\xcc\xcf'
    list_0 = [bytes_0]
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_0)
    raise_undefined_parameters_0.handle_from_dict(list_0)


# Generated at 2022-06-25 16:21:41.100543
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = str()
    str_1 = str()
    dict_0 = {str_0: str_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(str_1, dict_0)

    assert dict_1 is dict_0

    dict_0 = {str_0: str_1}
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(str_1, dict_0)

    assert dict_1 is dict_0

    bytes_0 = b'\xe2\xca\x8e*\x94'
    dict_0 = {bytes_0: bytes_0}
    dict_1 = catch_all_

# Generated at 2022-06-25 16:21:44.856056
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    obj = _CatchAllUndefinedParameters()
    cls = test_case_0.__class__
    kvs = {'a': 5, 'b': 8}
    result = obj.handle_from_dict(cls=cls, kvs=kvs)
    expected = {'a': 5, 'b': 8}
    assert result == expected


# Generated at 2022-06-25 16:21:54.278889
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from typing import List, Tuple

    # Create an object of class List with two arguments
    # Create an object of class List with two arguments
    list_0 = List[Tuple[List[Callable], List[Callable]]]([])
    # Create an object of class _CatchAllUndefinedParameters
    _catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    # Call method create_init of object _catch_all_undefined_parameters_0
    # with arguments list_0
    callable_0 = _catch_all_undefined_parameters_0.create_init(list_0)
    # Compare result with expected result
    assert callable_0 == list_0.__init__



# Generated at 2022-06-25 16:22:06.878403
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters

# Generated at 2022-06-25 16:22:15.099419
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    list_0 = ['abc', 'abc', 'abc']
    dict_0 = {'abc': list_0, 'abc': list_0, 'abc': list_0, 'abc': list_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_dump(list_0)
    catch_all_undefined_parameters_0.handle_dump(dict_0)


# Generated at 2022-06-25 16:22:22.585455
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import datetime
    import marshmallow
    import json
    from enum import Enum
    from typing import Dict
    from dataclasses_json.utils import CatchAllVar


    class Undefined(Enum):
        INCLUDE = _CatchAllUndefinedParameters
        RAISE = _RaiseUndefinedParameters
        EXCLUDE = _IgnoreUndefinedParameters


    class _RaiseUndefinedParameters(_UndefinedParameterAction):
        """
        This action raises UndefinedParameterError if it encounters an
        undefined parameter during initialization.
        """


# Generated at 2022-06-25 16:22:33.725585
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # test cases
    tuple_0 = (bytearray(b'\xe39\xd9\xdf\x98\xdf\xf1+'), False)
    dict_0 = {None: tuple_0}
    def function_0(x: bool=False) -> None: return None
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = {catch_all_undefined_parameters_0: function_0}

    test_raise_0 = _UndefinedParameterAction.handle_from_dict(dict_0)
    test_raise_1 = _UndefinedParameterAction.handle_from_dict(dict_1)

    assert test_raise_0 == {None: tuple_0}

# Generated at 2022-06-25 16:22:36.534372
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # Implementation of test __IgnoreUndefinedParameters_handle_from_dict
    assert True



# Generated at 2022-06-25 16:22:45.731429
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    list_0 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_0)
    list_1 = []
    list_1.append(list_0)
    bytes_0 = b'\x9e\xeb+\xc8'
    list_2 = [bytes_0, bytes_0, bytes_0]
    str_0 = str(list_1)
    list_3 = []
    list_3.append(str_0)
    bytes_1 = b'\x9e\xeb+\xc8'
    list_4 = [bytes_1, bytes_1, bytes_1]
    list_3.append(list_2)
    list_3.append(list_4)
    list_3.append(list_1)