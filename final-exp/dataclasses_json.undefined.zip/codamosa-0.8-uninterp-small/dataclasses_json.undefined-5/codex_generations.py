

# Generated at 2022-06-25 16:12:59.047554
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    expected_result = {}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs={})
    assert result == expected_result

    expected_result = {1: 2}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs={1: 2})
    assert result == expected_result



# Generated at 2022-06-25 16:13:03.917853
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class C:
        def __init__(self, a, b):
            pass
    new_init = _IgnoreUndefinedParameters.create_init(C)
    assert new_init != C.__init__
    assert new_init.__name__ == C.__init__.__name__
    assert new_init.__doc__ == C.__init__.__doc__
    assert new_init.__module__ == C.__init__.__module__



# Generated at 2022-06-25 16:13:12.926882
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def _create_init(class_, superclass):
        return _UndefinedParameterAction.create_init(class_)

    def _create_super_init(class_, superclass):
        return _UndefinedParameterAction.create_init(superclass)

    class SuperClass:
        def __init__(self, foo):
            pass

    class ClassNoArgs(SuperClass):
        pass

    class ClassWithArgs(SuperClass):
        def __init__(self, foo, bar):
            pass

    for class_ in [ClassNoArgs, ClassWithArgs]:
        init_method = _create_init(class_, SuperClass)
        assert isinstance(init_method, Callable)
        assert init_method.__name__ == "__init__"

# Generated at 2022-06-25 16:13:24.856657
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    known_given_parameters = {
        "parameter_1": "value_1"
    }
    unknown_given_parameters = {
        "parameter_2": "value_2"
    }
    class_fields = fields(type("Test", (), {}))
    results_without_catch_all = \
        _CatchAllUndefinedParameters.handle_from_dict(
            cls=type("Test", (), {}), kvs=known_given_parameters)
    assert results_without_catch_all == known_given_parameters

    catch_all_field = Field(
        "_catch_all", default=None, default_factory=dict)
    class_fields.append(catch_all_field)
    results_with_catch_all = \
        _CatchAllUndefinedParameters.handle_from_

# Generated at 2022-06-25 16:13:37.700744
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    assert \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=None, kvs={"a": 3, "b": 2, "c": 1, "d": 5}) == (
        {"a": 3, "b": 2}, {"c": 1, "d": 5})

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_from_dict(cls=None, kvs={})

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_from_dict(cls=None,
                                                      kvs={"unknown": "bla"})


# Generated at 2022-06-25 16:13:46.215686
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=None,
        kvs={}
    ) == {}
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=None,
        kvs={"a": 1,
             UndefinedParameterError: 2}
    ) == {"a": 1}
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=None,
        kvs={"a": 1,
             "extra": {1, 2, 3},
             UndefinedParameterError: 2}
    ) == {"a": 1}

# Generated at 2022-06-25 16:13:53.762736
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test without undefined parameters
    kvs_0 = {"a": 1, "b": 2}
    result_0 = _CatchAllUndefinedParameters.handle_from_dict(kvs=kvs_0)
    assert result_0 == kvs_0

    # Test with undefined parameters
    kvs_1 = {"a": 1, "b": 2, "c": 3}
    result_1 = _CatchAllUndefinedParameters.handle_from_dict(kvs=kvs_1)
    assert result_1 == {"a": 1, "b": 2, "_UNKNOWN0": 3}

    # Test with multiple undefined parameters
    kvs_2 = {"a": 1, "b": 2, "c": 3, "d": 4}

# Generated at 2022-06-25 16:13:59.028961
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    kvs = {"a": 0, "b": 1, "c": "test"}
    assert raise_undefined_parameters.handle_from_dict(object, kvs) == kvs
    kvs = {"a": 0, "b": 1, "c": "test", "d": "unknown"}
    try:
        raise_undefined_parameters.handle_from_dict(object, kvs)
        assert False, "Expected error to be raised"
    except UndefinedParameterError:
        assert True, "Catching expected error"



# Generated at 2022-06-25 16:14:11.701593
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ExampleUndefined(object):
        def __init__(self,
                     a: int,
                     b: int,
                     c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    ExampleUndefined._UNDEFINED_PARAMETER_HANDLER = \
        _CatchAllUndefinedParameters()

    # test a variety of inputs
    _CatchAllUndefinedParameters.handle_from_dict(ExampleUndefined,
                                                  {"a": 1, "b": 2})
    _CatchAllUndefinedParameters.handle_from_dict(
        ExampleUndefined, {"a": 1, "b": 2, "c": {}})

# Generated at 2022-06-25 16:14:13.645053
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():

    obj = object()
    kvs = {}

    _UndefinedParameterAction.handle_dump(obj) == kvs



# Generated at 2022-06-25 16:14:36.687975
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    test_input = {"key": "value"}
    expected_output = {}
    actual_output = _UndefinedParameterAction.handle_dump(test_input)
    assert actual_output == expected_output



# Generated at 2022-06-25 16:14:40.247521
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert str(e) == "test"



# Generated at 2022-06-25 16:14:51.940510
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    # test 0: new dictionary is created with the given dictionary
    initial_dict = {"str_key": "str_val",
                    "int_key": 3,
                    "undefined_key": "undefined_val",
                    "catch_all_key": "catch_all_val"}
    expected_result = {**initial_dict,
                       "catch_all_key": {"undefined_key": "undefined_val"}}
    result = catch_all_undefined_parameters.handle_from_dict(
        cls=None, kvs=initial_dict)
    assert result == expected_result

    # test 1: modify the given dictionary

# Generated at 2022-06-25 16:15:04.930063
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    get_skeleton_class = _get_skeleton_class()
    test_class = get_skeleton_class(name="foo", undefined_parameter_action=
    raise_undefined_parameters)

    given_parameters = {
        "name": "foo",
        "age": 12,
    }
    expected_parameters = {
        "name": "foo",
        "age": 12,
    }

    returned_parameters = raise_undefined_parameters.handle_from_dict(
        test_class,
        given_parameters)

    assert returned_parameters == expected_parameters


# Generated at 2022-06-25 16:15:15.259468
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Test that all known parameters and first n positional arguments can be
    passed in,
    but all other positional arguments are ignored.
    """

    class TestClass:
        foo: int
        bar: str = "default"
        catch_all: CatchAll = None

        def __init__(self, foo: int, bar: str = "default",
                     catch_all: CatchAll = None):
            self.foo = foo
            self.bar = bar
            self.catch_all = catch_all

    init = _IgnoreUndefinedParameters.create_init(
        obj=TestClass)
    a = TestClass(1, "test", {"a": 5, "b": 7})
    b = init(a, 1, "test", {"a": 5, "b": 7})

    c = TestClass(1, "test")

# Generated at 2022-06-25 16:15:22.260347
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class AWithIgnoredUndefinedVars:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    obj = AWithIgnoredUndefinedVars(1, "2")
    _IgnoreUndefinedParameters.create_init(obj)(obj, a=1, b="2")
    _IgnoreUndefinedParameters.create_init(obj)(obj, a=1, b="2", d=3)
    _IgnoreUndefinedParameters.create_init(obj)(obj, a=1, b="2", d=3, c=4)
    _IgnoreUndefinedParameters.create_init(obj)(obj, a=1, b="2", d=3, c=4,
                                                q=6)
    _IgnoreUndefinedParameters.create_

# Generated at 2022-06-25 16:15:32.921245
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()

    a = A(1, 2, 3)

    func = catch_all_undefined_parameters_0.create_init(a)
    assert func(a, 1, 2, 3) == None
    assert a.x == 1
    assert a.y == 2
    assert a.z == 3

    func = catch_all_undefined_parameters_0.create_init(a)
    assert func(a, 1, 2) == None
    assert a.x == 1
    assert a.y == 2

# Generated at 2022-06-25 16:15:42.152476
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # if no catch-all field is defined, raise an error
    class A0:
        def __init__(self, a: int):
            pass

    try:
        _CatchAllUndefinedParameters.create_init(A0)
    except UndefinedParameterError:
        pass
    else:
        raise Exception("Expected an UndefinedParameterError but did not "
                        "receive one.")

    # if multiple catch-all fields are defined, raise an error
    class A1:
        def __init__(self, a: int, ca: Optional[CatchAllVar] = None,
                     ca2: Optional[CatchAllVar] = None):
            pass

    try:
        _CatchAllUndefinedParameters.create_init(A1)
    except UndefinedParameterError:
        pass
    else:
        raise Exception

# Generated at 2022-06-25 16:15:50.760635
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    kvs = {"a": 1, "_UNKNOWN0": 7}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        object, kvs)
    assert unknown == {"_UNKNOWN0": 7}
    kvs = catch_all_undefined_parameters_0.handle_to_dict(object, kvs)
    assert kvs == {"a": 1, "_UNKNOWN0": 7}



# Generated at 2022-06-25 16:16:02.746333
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    Test if the handle_to_dict method of _CatchAllUndefinedParameters works
    correctly.
    """
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    kvs: Dict[Any, Any] = {"a": "a", "b": "b",
                           "_UNKNOWN0": "unknown", "_UNKNOWN1": "unknown",
                           "c": "c"}
    result: Dict[Any, Any] = catch_all_undefined_parameters_0.handle_to_dict(
        str, kvs=kvs)
    assert result == {"a": "a", "b": "b", "_UNKNOWN0": "unknown",
                      "_UNKNOWN1": "unknown", "c": "c"}
    assert kvs == {}



# Generated at 2022-06-25 16:16:50.986798
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class TestCase0:
        a: str
        _UNKNOWN0: str = field(init=False)
        b: Optional[int] = None
        _UNKNOWN1: str = field(init=False)
        c: CatchAll = field(default_factory=dict)

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
            self._UNKNOWN0 = ""
            self._UNKNOWN1 = ""

    @dataclass
    class TestCase1:
        a: str
        _UNKNOWN0: str = field(init=False)
        b: Optional[int] = None
        _UNKNOWN1: str = field(init=False)
       

# Generated at 2022-06-25 16:16:57.341724
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
  class _Test_class:
    pass

  test_input_0 = _Test_class()
  test_input_1 = {}
  _RaiseUndefinedParameters.handle_from_dict(test_input_0, test_input_1)



# Generated at 2022-06-25 16:17:03.060254
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from types import MethodType

    class _TestClass:

        def __init__(self, one: int, two: str, three: str,
                     four=None, five=None):
            pass

    original_init = _TestClass.__init__
    _TestClass.__init__ = _UndefinedParameterAction.create_init(_TestClass)

    # Create a class instance with only the known parameters
    x = _TestClass(1, "zwei", "drei")

    # Make sure the methods are equal
    assert _TestClass.__init__ == original_init
    assert _TestClass.__init__.__code__ == original_init.__code__

    # Create another instance with an added fourth argument
    _TestClass(1, "zwei", "drei", four=4)

    # Create another instance with an

# Generated at 2022-06-25 16:17:14.254673
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test the error case
    class TestClass0:
        def __init__(self, foo: int, bar: int,
                     **catch_all: CatchAllVar):
            pass

    kwargs_0 = {"foo": 1, "CatchAll": 2}
    expected_0 = {"foo": 1, "CatchAll": 2}
    result_0 = _CatchAllUndefinedParameters.handle_from_dict(TestClass0,
                                                             kwargs_0)
    assert result_0 == expected_0

    # Test the merge case
    kwargs_1 = {"foo": 1, "CatchAll": {"baz": "baz"}, "bar": 2}
    expected_1 = {"foo": 1, "CatchAll": {"baz": "baz"}, "bar": 2}
    result_1

# Generated at 2022-06-25 16:17:23.675144
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b

    class B(A):
        def __init__(self, a: str, b: str, c: str):
            super().__init__(a, b)
            self.c = c


# Generated at 2022-06-25 16:17:25.391241
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError:
        return

# Generated at 2022-06-25 16:17:34.138618
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class DummyBasicDataclass:

        def __init__(self, field_0, field_1):
            self.field_0 = field_0
            self.field_1 = field_1

    dummy_basic_dataclass = DummyBasicDataclass("A", "B")
    values = {"field_0": "A",
              "field_1": "B",
              "field_2": "C"}
    values_zero = _UndefinedParameterAction.handle_from_dict(
        cls=DummyBasicDataclass,
        kvs=values)
    assert values_zero == {"field_0": "A", "field_1": "B"}

    dummy_basic_new_init = _UndefinedParameterAction.create_init(
        DummyBasicDataclass)
    dummy_basic_new_

# Generated at 2022-06-25 16:17:38.962586
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # Mock a class
    class TestClass:
        def __init__(self, a, v1, v2):
            pass

    # Create a partial function that removes the first parameter
    def my_init(self, b, c, d):
        pass

    test_obj = TestClass(3, 4, 5)
    test_obj.__init__ = my_init
    a_init = _UndefinedParameterAction.create_init(test_obj)

    assert a_init(test_obj, 1, 2, 3) is not None



# Generated at 2022-06-25 16:17:45.210683
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    _CatchAllUndefinedParameters.handle_to_dict
    """
    def test_for_different_values():
        """
        _CatchAllUndefinedParameters.handle_to_dict for different values
        """
        # test_case_0
        from dataclasses_json.undefined import Undefined
        from dataclasses_json.utils import CatchAllVar
        import dataclasses
        import typing
        @dataclasses.dataclass(undefined=Undefined.RAISE)
        class TestClass0:
            my_int: int = dataclasses.field(default=0)
            my_string: str = dataclasses.field(default="a")
            my_bool: bool = dataclasses.field(default=True)

# Generated at 2022-06-25 16:17:52.676584
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    d = {'a': 1, 'b': 1, 'c': 1}
    assert \
        _UndefinedParameterAction.handle_to_dict('self', d) == \
        _CatchAllUndefinedParameters.handle_to_dict('self', d) == \
        _IgnoreUndefinedParameters.handle_to_dict('self', d) == \
        _RaiseUndefinedParameters.handle_to_dict('self', d) == \
        d


# Generated at 2022-06-25 16:18:54.769131
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    class_0 = Dict[float, int]
    kvs_0 = {float(0):float(0), str(0):int(0), int(0):float(0), chr(0):chr(0), bool(0):int(0), complex(0):bool(0), 1j:str(0)}
    known_given_parameters_0, unknown_given_parameters_0 = _UndefinedParameterAction._separate_defined_undefined_kvs(class_0, kvs_0)

# Generated at 2022-06-25 16:19:02.198608
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        pass

    test_dict_0 = {'a': 1, 'b': 2}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    result = raise_undefined_parameters_0.handle_from_dict(test_dict_0,
                                                           TestClass)
    assert result == {'a': 1, 'b': 2}



# Generated at 2022-06-25 16:19:10.570833
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    for i in range(0, 10):
        dict_0 = {"+}aOc%{we*-": -1925.74, "D+": "{", "U2J6}3h6": 193811, "]y": 8, "~": 1925.74, "T": "!Z6", "F@[l": "8n<x"}
        dict_1 = dict_0.copy()
        dict_2 = dict_0.copy()
        dict_2["D+"] = "+}aOc%{we*-"
        dict_2["U2J6}3h6"] = "~"
        dict_2["]y"] = "D+"
        dict_2["~"] = "U2J6}3h6"
        dict_2["T"] = "]"

# Generated at 2022-06-25 16:19:17.102111
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    float_0 = -1925.74
    dict_0 = {float_0: float_0}
    catch_all_undefined_parameters_0.handle_dump(dict_0)


# Generated at 2022-06-25 16:19:18.933551
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-25 16:19:26.554899
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    instance_0 = CatchAllVar()
    str_0 = ""
    class_0 = type(str_0, (), {})
    dict_0 = {class_0: instance_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_0)
    assert dict_1 == {}



# Generated at 2022-06-25 16:19:38.309468
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # This test uses example from
    # https://dev.to/enkura/python-3-67-dataclasses-and-marshmallow-a-quick-guide-1nmm
    # TODO: Add more tests.
    import enum
    import dataclasses
    import marshmallow


    class AddressType(enum.Enum):
        HOME = "home"
        WORK = "work"


    @dataclasses.dataclass
    class Address:
        city: str
        country: str
        type: AddressType
        phone: Optional[str]


    class AddressSchema(marshmallow.Schema):
        city = marshmallow.fields.Str()
        country = marshmallow.fields.Str()
        type = marshmallow.fields.Str(attribute="type.value")

# Generated at 2022-06-25 16:19:45.586413
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class_0 = _CatchAllUndefinedParameters()
    class_1 = Dict[Any, Any]
    function_0 = class_0.create_init(class_1)
    float_1 = 1877.10
    float_2 = -1835.82
    float_0 = -1925.74
    dict_0 = {float_0: float_1, float_2: float_0}
    function_0(dict_0, float_1, float_2)
    float_3 = -862.01
    # assert that the catch all field has been initialized with the
    # unknown parameters
    # noinspection PyTypeChecker
    assert dict_0["_UNKNOWN0"] == float_3



# Generated at 2022-06-25 16:19:50.134630
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    dict_0 = {}
    test_class_0 = _UndefinedParameterAction.handle_from_dict(dict_0, dict_0)



# Generated at 2022-06-25 16:20:01.438271
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    obj_0 = _RaiseUndefinedParameters()
    list_0 = ["2%-", "7", "TM2\"+C[XaOq]HV7\"hG", "", "`b(L-", "U>|6<+[1{*!nX,&"]
    list_1 = []
    list_2 = []
    list_2.append(None)
    list_3 = []
    list_3.append(list_0)
    list_3.append(list_1)
    list_3.append(list_2)
    list_3.append(list_3)
    list_4 = []
    list_4.append(True)
    list_4.append(False)
    list_4.append(False)
    list_4.append(True)
    set

# Generated at 2022-06-25 16:22:44.340932
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def func_gen():
        def func():
            a = 2
            return a 
        return func

    class A:
        def __init__(self, a=2):
            pass

    instance = _IgnoreUndefinedParameters()
    result = instance.create_init(A)
    assert result() == 2
    
    result = instance.create_init(func_gen())
    assert result() == 2

    class A:
        def __init__(self, g=2, a=2):
            pass

    instance = _IgnoreUndefinedParameters()
    result = instance.create_init(A)
    assert result(2) == 2

    class A:
        def __init__(self, g=2, a=8, b=78):
            pass

    instance = _IgnoreUndefinedParameters()
    result