

# Generated at 2022-06-25 16:13:03.512115
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class A0:
        def __init__(self, a: int, b: str, c: int = 17):
            self.a = a
            self.b = b
            self.c = c

    class A1:
        def __init__(self, a: int, b: str, c: int = 17, *, d: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    class A2:
        def __init__(self, a: int, b: str, c: int = 17, *, d: CatchAll = {}):
            self.a = a
            self.b = b
            self.c = c
            self.d = d


# Generated at 2022-06-25 16:13:08.221363
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    unknown_parameters = {"foo": 1}
    kvs_in = {"bar": 2}
    kvs_out = {"bar": 2, "foo": 1}
    undefined_parameter_action = _CatchAllUndefinedParameters()
    assert undefined_parameter_action.handle_to_dict(
        None, kvs_in) == kvs_out

# Generated at 2022-06-25 16:13:09.247122
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    pass



# Generated at 2022-06-25 16:13:18.582902
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from tests.utils.fixtures import TestClass

    tc = TestClass("foo", "bar", "baz", x=1, y=2)
    tc_catch_all = TestClass("foo", "bar", "baz", x=1, y=2,
                             _UNKNOWN0="extra_arg_0", _UNKNOWN1="extra_arg_1",
                             _UNKNOWN2="extra_arg_2")

    rec_args, rec_kwargs = inspect.getcallargs(
        TestClass.__init__, tc, "foo", "bar", "baz", x=1, y=2)

# Generated at 2022-06-25 16:13:20.536053
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    undefined_parameter_action_0 = _CatchAllUndefinedParameters()



# Generated at 2022-06-25 16:13:28.870868
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():

    class TestClass:
        def __init__(self, test_1: int, catch_all: Optional[CatchAllVar]):
            self.test_1 = test_1
            self.catch_all = catch_all

    test_object = TestClass(1, {"test_2": 2, "test_3": 3})
    known_keys_vals = {"test_1": 1}
    kvs: Dict[Any, Any] = {"test_1": 1, "test_2": 2, "test_3": 3}

    received: Dict[str, int] =\
        _CatchAllUndefinedParameters.handle_to_dict(test_class=test_object,
                                                    kvs = kvs)

# Generated at 2022-06-25 16:13:41.257457
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, a: int, b: str, c: str = "c", **undefined_parameters: Any):
            self.a = a
            self.b = b
            self.c = c
            if undefined_parameters:
                self.undefined_parameters = undefined_parameters
            else:
                self.undefined_parameters = {}

    a = A(0, "b", "c", custom="custom")
    kvs = {"a": a.a, "b": a.b, "c": a.c, "custom": a.undefined_parameters["custom"]}
    result = _CatchAllUndefinedParameters.handle_to_dict(a=a, kvs=kvs)
    assert "a" in result
    assert "b" in result
   

# Generated at 2022-06-25 16:13:50.252873
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    ignore_parameters = _IgnoreUndefinedParameters()
    isinstance(ignore_parameters, _UndefinedParameterAction)

    class TestClass:
        def __init__(self, one: int, two: int):
            self.one = one
            self.two = two

    test_class = TestClass(one=1, two=2)
    assert (1, 1) == \
           ignore_parameters.handle_from_dict(test_class, {"one": 1})

    # test_class = TestClass(one=1, two=2, **{"hello": "world", "bye": "moon"})
    # assert (1, 1) == \
    #        ignore_parameters.handle_from_dict(test_class,
    #                                           {"one": 1, "hello": "world"})


# Unit

# Generated at 2022-06-25 16:13:59.790589
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        x: int
        def __init__(self, x: int):
            self.x = x

    kvs = {"x": 1}
    output = _RaiseUndefinedParameters.handle_from_dict(A, kvs)
    assert output == kvs

    kvs = {"x": 1, "y": 2}
    with pytest.raises(UndefinedParameterError) as excinfo:
        _RaiseUndefinedParameters.handle_from_dict(A, kvs)
    assert "Received undefined initialization arguments {'y': 2}" == str(
        excinfo.value)



# Generated at 2022-06-25 16:14:04.750637
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def __init__(self, a: str, b: str):
        pass

    class TestClass:
        __init__ = __init__

    assert _UndefinedParameterAction.create_init(
        TestClass) == __init__



# Generated at 2022-06-25 16:14:22.650035
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj_ = _UndefinedParameterAction()
    dict_0 = {obj_: obj_, obj_: obj_, obj_: obj_}
    dict_1 = obj_.handle_to_dict(obj_, dict_0)



# Generated at 2022-06-25 16:14:34.676445
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    known_given_parameters_0 = {}
    unknown_given_parameters_0 = {}
    __dict___0 = {}

    def _CatchAllUndefinedParameters_handle_from_dict_0():
        # This is the corner case.
        # The default is created and the given value is none.
        # This is intentionally not tested by the ordinary unit tests.
        _CatchAllUndefinedParameters_handle_from_dict_0.__annotations__ = {'cls': object, 'kvs': object}
        kvs = {'a': 'a', 'b': 'b'}
        unknown_given_parameters_0.update(kvs)


# Generated at 2022-06-25 16:14:37.041849
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # Raise exception to pass this test
    # Call the constructor
    try:
        raise UndefinedParameterError('parameter name', 'parameter value')
        assert False
    except UndefinedParameterError as e:
        assert True

# Generated at 2022-06-25 16:14:46.339475
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_0 = {ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0}
    dict_1 = _UndefinedParameterAction.handle_from_dict(ignore_undefined_parameters_0, dict_0)
    assert dict_0 == dict_1


# Generated at 2022-06-25 16:14:49.533018
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    test_obj = _IgnoreUndefinedParameters()
    test_class = 3
    test_result = test_obj.create_init(test_class)
    assert isinstance(test_result, Callable)


# Generated at 2022-06-25 16:14:55.923053
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    p1 = _CatchAllUndefinedParameters
    p2 = _RaiseUndefinedParameters()
    f1 = p1._get_catch_all_field
    p3 = p1._CatchAllUndefinedParameters__SentinelNoDefault
    f2 = p1.handle_from_dict
    p4 = p1._get_default
    callable_0 = p1.create_init
    f3 = p1._separate_defined_undefined_kvs
    p5 = p2.handle_from_dict
    p6 = p1._separate_defined_undefined_kvs(Undefined, p3)


# Generated at 2022-06-25 16:15:07.257979
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test case 0
    catch_all = Optional[CatchAllVar]

    class Class0:
        def __init__(self):
            self.foo = 'bar'
            self.quiet = None
            self.catch_all = None

    kvs_0 = {'foo': 'foo', 'catch_all': {'baz': 'qux'}}
    expected_0 = {'foo': 'foo', 'catch_all': {'baz': 'qux'}}
    actual_0 = _CatchAllUndefinedParameters.handle_from_dict(Class0, kvs_0)

    if actual_0 != expected_0:
        print(f"Error in test_case_0: expected {expected_0} but got {actual_0}")



# Generated at 2022-06-25 16:15:18.039208
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    method_to_test = _CatchAllUndefinedParameters._get_catch_all_field
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    int_0 = catch_all_undefined_parameters_0.handle_dump(method_to_test)
    list_0 = [method_to_test, catch_all_undefined_parameters_0]
    dict_0 = catch_all_undefined_parameters_0.handle_to_dict(method_to_test, dict_0)
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(method_to_test, dict_0)
    dict_2 = catch_all_undefined_parameters_0.handle_to_dict(method_to_test, dict_0)

# Generated at 2022-06-25 16:15:25.748586
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    list_0 = [ignore_undefined_parameters_0, ignore_undefined_parameters_0, ignore_undefined_parameters_0]
    callable_0 = _UndefinedParameterAction.create_init(list_0)
    callable_1 = ignore_undefined_parameters_0.create_init(catch_all_undefined_parameters_0)


# Generated at 2022-06-25 16:15:37.156360
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _Test_class:
        def __init__(self, test_param, __UNDEFINED__=None):
            self.test_param = test_param
            self.__UNDEFINED__ = __UNDEFINED__
    instance_0 = _Test_class("test_param_2")
    instance_0.test_param = "test_param_2"
    instance_0.__UNDEFINED__ = "test_param_3"
    kvs_0 = {"test_param": "test_param_2", "__UNDEFINED__": "test_param_3"}
    kvs_1 = _IgnoreUndefinedParameters.handle_to_dict(instance_0, kvs_0)

# Generated at 2022-06-25 16:16:13.523592
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = {'w3#P': 'wi7+', ')J/4': 'vb}_', 'p)': '=WG', 'd': '', '$+': '0', 'W>Xd': '|', '+s': ';', '#0%m': '', '{/': 'F)_'}
    callable_0 = catch_all_undefined_parameters_0.create_init(dict_0)
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    callable_1 = catch_all_undefined_parameters_1.create_init(callable_0)
    assert_equal(callable_1, callable_1)

# Generated at 2022-06-25 16:16:14.603599
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    _UndefinedParameterAction.create_init(object)

# Generated at 2022-06-25 16:16:21.827755
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_0 = {ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(ignore_undefined_parameters_0, dict_0)


# Generated at 2022-06-25 16:16:29.218957
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    dict_0 = {}
    list_0 = []
    expected_result_0 = list_0.__init__
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    method_0 = catch_all_undefined_parameters_0.create_init(list_0)
    if not callable(method_0):
        raise Exception("Method _CatchAllUndefinedParameters.create_init is not callable")
    if method_0.__qualname__ != "list.__init__":
        raise Exception("Method _CatchAllUndefinedParameters.create_init does not produce the expected result")


# Generated at 2022-06-25 16:16:32.357628
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = {'dict_0': raise_undefined_parameters_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(dict_0, dict_0)


# Generated at 2022-06-25 16:16:41.521573
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    ignore_undefined_parameters_0 = test_case_0()
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.handle_from_dict(ignore_undefined_parameters_0, {ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0, ignore_undefined_parameters_0: ignore_undefined_parameters_0})


# Generated at 2022-06-25 16:16:44.347325
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    list_0 = [raise_undefined_parameters_0, raise_undefined_parameters_0]
    dict_0 = catch_all_undefined_parameters_0.handle_dump(raise_undefined_parameters_0)
    dict_1 = raise_undefined_parameters_0.handle_dump(raise_undefined_parameters_0)


# Generated at 2022-06-25 16:16:50.071205
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = {raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0, raise_undefined_parameters_0: raise_undefined_parameters_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(raise_undefined_parameters_0, dict_0)


# Generated at 2022-06-25 16:16:53.770359
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()
    obj_0 = ignore_undefined_parameters
    callable_0 = ignore_undefined_parameters.create_init(obj_0)


# Generated at 2022-06-25 16:16:58.284500
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    dict_0 = {catch_all_undefined_parameters: catch_all_undefined_parameters}
    dict_1 = catch_all_undefined_parameters.handle_from_dict(catch_all_undefined_parameters, dict_0)
    assert dict_1 == dict_0


# Generated at 2022-06-25 16:17:32.155946
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = '9b'
    dict_0 = dict()
    dict_1 = dict()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1[str_0] = dict_0
    dict_2 = catch_all_undefined_parameters_0.handle_to_dict(str_0, dict_1)
    dict_3 = dict_2.pop(str_0)
    dict_2.update(dict_3)
    dict_4 = dict_2.pop(str_0)



# Generated at 2022-06-25 16:17:40.558609
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestUndefinedParameters(object):
        float_0: float
        str_0: str

        def __init__(self, float_0: float, str_0: str):
            self.float_0 = float_0
            self.str_0 = str_0

    new_init = _IgnoreUndefinedParameters.create_init(
        TestUndefinedParameters)
    test_undefined_parameters_0 = new_init(TestUndefinedParameters, 5.55,
                                           'TD')



# Generated at 2022-06-25 16:17:53.239851
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    Calling the method create_init of class _CatchAllUndefinedParameters
    raises a TypeError in the following conditions:
     - There is no parameter of type utils.CatchAll
     - There is more than one parameter of type utils.CatchAll
    """
    float_0 = -554.341
    dict_0 = dict()
    dict_0['r'] = 0.0
    dict_0['s'] = 1.0
    str_0 = 'ZH'
    dict_1 = dict()
    dict_1['abc'] = 'abc'
    dict_1['cba'] = 'cba'
    dict_1['xyz'] = 'xyz'
    dict_2 = dict()
    dict_2['a'] = dict_0
    dict_2['b'] = dict_1
   

# Generated at 2022-06-25 16:18:02.429856
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    float_0 = -554.341
    str_0 = 'ZH'
    float_1 = 2022.8025
    class_0 = dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=True, frozen=False)
    class_1 = dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=True, frozen=False)
    class_2 = dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=True, frozen=False)
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()

# Generated at 2022-06-25 16:18:08.650772
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class sample_ignore():
        def __init__(self, sample_ignore_param_0, sample_ignore_param_1,
                     sample_ignore_param_2):
            self.sample_ignore_param_0 = sample_ignore_param_0
            self.sample_ignore_param_1 = sample_ignore_param_1
            self.sample_ignore_param_2 = sample_ignore_param_2
    float_0 = float('inf')
    float_1 = float('nan')
    str_1 = 'UmF'
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    obj_0 = sample_ignore
    function_0 = ignore_undefined_parameters_0.create_init(obj=obj_0)
    assert function_0.__init__ != sample_ignore.__init

# Generated at 2022-06-25 16:18:20.539176
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_2['b'] = dict_3
    dict_1['a'] = dict_2
    dict_0['c'] = dict_1
    dict_5 = dict_0.copy()
    dict_6 = dict()
    dict_6['a'] = dict_5
    dict_7 = dict()
    dict_7['c'] = dict_6
    dict_8 = dict()
    dict_9 = dict()
    dict_9['b'] = dict_8
    dict_7['a'] = dict_9
    dict_4 = dict_7.copy()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['b'] = dict_1

# Generated at 2022-06-25 16:18:31.493280
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    int_0 = -1567
    str_0 = 'XQ'
    int_1 = -1546
    str_1 = 'CZ'
    str_2 = 'PW'
    int_2 = -1546
    class_0 = _CatchAllUndefinedParameters
    dict_0 = dict()
    dict_1 = dict()
    dict_0[str_0] = int_0
    dict_1[int_1] = str_1
    dict_0[str_2] = int_2
    dict_2 = dict_0
    dict_2.update(dict_1)
    dict_3 = dict()
    dict_3[str_0] = int_0
    dict_3[str_1] = int_1
    dict_3[str_2] = int_2


# Generated at 2022-06-25 16:18:36.916853
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    float_0 = -554.341
    str_0 = 'ZH'
    float_1 = 2022.8025
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = {'foo': 'bar'}
    dict_1 = raise_undefined_parameters_0.handle_to_dict(float_1, dict_0)


# Generated at 2022-06-25 16:18:43.544939
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    float_1 = 5.855897
    dict_0 = {'y': 4.555055, 'z': 536.35, 'x': 5.855897}
    dict_1 = {'z': 536.35, 'x': 5.855897}
    dict_2 = {'x': 5.855897}
    dict_3 = {'y': 4.555055, 'x': 5.855897}
    dict_4 = {'y': 4.555055, 'z': 536.35}
    dict_5 = {'a': 'U6', 'b': 'A0', 'x': 5.855897, 'c': 'C9'}
    dict_6 = {'x': 5.855897, 'c': 'C9'}
    dict_7

# Generated at 2022-06-25 16:18:45.733374
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert isinstance(UndefinedParameterError(), UndefinedParameterError)


# Generated at 2022-06-25 16:19:54.522125
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    float_0 = -554.341
    str_0 = 'ZH'
    float_1 = 2022.8025
    test__UndefinedParameterAction_create_init_0 = _UndefinedParameterAction()
    test__UndefinedParameterAction_create_init_1 = test__UndefinedParameterAction_create_init_0.create_init(float_1)
    test__UndefinedParameterAction_create_init_1(float_0, str_0)


# Generated at 2022-06-25 16:20:04.657333
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    supplied_dict: Dict[str, Any] = {}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = catch_all_undefined_parameters_0.handle_from_dict(float,
                                                               supplied_dict)
    assert dict_0 == {}
    supplied_dict: Dict[str, Any] = {}
    float_0 = -554.341
    float_1 = 2022.8025
    float_2 = float(173.878)
    str_0 = 'ZH'
    supplied_dict[(float_2 + float_1)] = str_0
    supplied_dict['undefined_parameter'] = float_0
    dict_0 = catch_

# Generated at 2022-06-25 16:20:14.140093
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # tests/tests_undefined_parameters.py:354
    def fp_0(_CatchAllUndefinedParameters_instance):
        str_0 = 'ZH'
        float_0 = -554.341
        float_1 = 2022.8025
        unknown_0 = {}
        str_1 = 'CE'
        float_2 = 2099.6
        float_3 = -241.4
        return
    # tests/tests_undefined_parameters.py:354
    def fp_1():
        str_0 = 'ZH'
        float_0 = -554.341
        float_1 = 2022.8025
        unknown_0 = {}
        str_1 = 'CE'
        float_2 = 2099.6
        float_3 = -241.4
        return
    # tests/

# Generated at 2022-06-25 16:20:21.759058
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    float_0 = -554.341
    str_0 = 'ZH'
    float_1 = 2022.8025
    dict_0 = dict({'a': str_0, 'b': float_1})
    float_2 = _CatchAllUndefinedParameters.handle_to_dict(str_0, dict_0)
    float_3 = _CatchAllUndefinedParameters.handle_to_dict(float_1, dict_0)


# Generated at 2022-06-25 16:20:32.394402
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # First test, no undefined parameters given
    undefined_parameters_are_allowed = True
    given_key_value_pairs = {'float_0': -554.341, 'str_0': 'ZH'}
    expected_key_value_pairs = {'float_0': -554.341, 'str_0': 'ZH'}
    # _CatchAllUndefinedParameters has a dictionary type field with the name
    # undefined_parameters, which contains all undefined parameters.
    key_value_pairs = {'undefined_parameters': {}, 'float_0': -554.341,
                       'str_0': 'ZH'}
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()

    # Function to test
    result = catch_all_undefined_parameters.handle

# Generated at 2022-06-25 16:20:37.085082
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    float_0 = -554.341
    str_0 = 'ZH'
    float_1 = 2022.8025
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_0 = raise_undefined_parameters_0.handle_dump(float_1)
    try:
        raise_undefined_parameters_0.handle_from_dict(int, dict_0)
    except UndefinedParameterError as e:
        str_1 = e.args[0]
        raise_undefined_parameters_0 = _RaiseUndefinedParameters()
        boolean_0 = str_1 == str_0
        #assert(boolean_0)


# Generated at 2022-06-25 16:20:45.117291
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'ZH'
    str_1 = 'fsDxQymGI'
    str_2 = 'jF7z8T'
    str_3 = 'Cpaq3'
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = catch_all_undefined_parameters_0.handle_from_dict(str_3,
                                                               {str_0: str_1,
                                                                str_2: {}})
    assert dict_0 == {str_0: str_1, 'CatchAll': {}}


# Generated at 2022-06-25 16:20:56.175460
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    str_0 = 'RJc'
    float_4 = -331.37
    float_2 = -475.7
    int_1 = 34
    int_3 = -15
    kvs = {'str_0': str_0, 'float_2': float_2, 'int_1': int_1, 'float_4': float_4, 'int_3': int_3}
    _IgnoreUndefinedParameters_handle_from_dict_ret_val_0 = \
        _IgnoreUndefinedParameters.handle_from_dict(ignore_undefined_parameters_0,
                                                    kvs)
    print(
        _IgnoreUndefinedParameters_handle_from_dict_ret_val_0)  # {'int_3': -15, 'float_2': -475.7}

# Generated at 2022-06-25 16:21:07.713728
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    float_2 = 3.4028234663852886e+38
    str_1 = 'HlQ2m'
    float_3 = 1.17549435e-38
    def _CatchAllUndefinedParameters_handle_from_dict_f(cls, kvs):
        float_0 = -191.26
        float_1 = -15.1
        float_2 = 1.711387750784079
        float_3 = 1.9
        str_0 = 'E#'
        dict_0 = dict()
        dict_1 = dict()
        dict_1['0'] = float_0
        dict_1['1'] = float_1
        dict_1['2'] = float_2
        dict_1['3'] = float_3
        dict_1['4'] = str_

# Generated at 2022-06-25 16:21:23.400911
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def _init(self, a, b, c, d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d

    def _inner(self, a, b, c, d, my_catch_all="default"):
        _init(self, a, b, c, d)
        self.my_catch_all = my_catch_all

    class A:
        a: int = dataclasses.field(default=1)
        b: int = dataclasses.field(default=3)
        c: int = dataclasses.field(default=4)
        my_catch_all: CatchAll = dataclasses.field(default="default")
