

# Generated at 2022-06-25 16:12:58.905595
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Example:
        pass

    assert _UndefinedParameterAction.handle_to_dict(Example, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(Example, {"a": "b"}) == {
               "a": "b"}



# Generated at 2022-06-25 16:13:06.549944
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(frozen=True)
    class Foo:
        a: int

    @dataclasses.dataclass(frozen=True)
    class Bar:
        a: int
        b: int

    f = _IgnoreUndefinedParameters()
    try:
        f.handle_from_dict(Foo, dict(a=0, b=0))
        # Expected error not raised
        assert 0
    except UndefinedParameterError:
        pass

    f.handle_from_dict(Bar, dict(a=0, b=0))



# Generated at 2022-06-25 16:13:15.920089
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():

    catch_all_fields = [Field(name="catch_me", type=CatchAll)]
    known_fields = [Field(name="known", type=str)]

    class T:
        @classmethod
        def _make_fields(cls, *args: Any, **kwargs: Any) -> Tuple[Field, ...]:
            return tuple(catch_all_fields + known_fields)

    t = T()

    known_given_parameters = {"known": "yes"}
    undefined_given_parameters = {"undefined": "no"}
    given_parameters = {**known_given_parameters,
                        **undefined_given_parameters}
    known_given_parameters["catch_me"] = undefined_given_parameters
    # Apply letter case

# Generated at 2022-06-25 16:13:27.462807
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: float
        d: None

    obj = TestClass(**{'a': 1, 'b': '2', 'c': 3, 'd': None})
    original_init = obj.__init__
    ignore_init = _IgnoreUndefinedParameters.create_init(obj)

    num_takes_original_init = len(inspect.signature(original_init).parameters)
    num_takes_ignore_init = len(inspect.signature(ignore_init).parameters)
    assert num_takes_original_init == num_takes_ignore_init + 1
    assert ignore_init.__name__ == original_init.__name__
    assert ignore_init.__doc__ == original

# Generated at 2022-06-25 16:13:37.230812
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def dummy_init(self, *args, **kwargs):
        pass

    catch_all_field = Field(name="undefined_parameters",
                            type=CatchAllVar,
                            default={})
    obj = dataclasses.make_dataclass("obj",
                                     fields={catch_all_field.name: catch_all_field},
                                     init=dummy_init)
    init = _CatchAllUndefinedParameters.create_init(obj)

    assert callable(init)
    assert init.__name__ == "obj"
    assert init.__qualname__ == "obj"



# Generated at 2022-06-25 16:13:40.531474
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {'key': 'value'}
    obj = object()
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == kvs


# Generated at 2022-06-25 16:13:50.455901
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, a, b=2, *args, c: CatchAll = None, **kwargs):
            self.a = a
            self.b = b
            self.c = c

    my_class = TestClass(a=1, b=2, x=3, y="yz")
    assert type(my_class.c) == dict
    assert my_class.c == {"x": 3, "y": "yz"}
    assert _CatchAllUndefinedParameters.handle_dump(obj=my_class) == \
           {"x": 3, "y": "yz"}

    my_class = TestClass(a=1, b=2, c={"z": 4})
    assert my_class.c == {"z": 4}
    assert _CatchAllUndefinedParameters.handle

# Generated at 2022-06-25 16:14:01.444539
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    class ExampleClass():
        pass

    class ExampleClassWithDefault():
        def __init__(self, example_field: str,
                     example_field_with_default: Optional[str] = None):
            self.example_field = example_field
            self.example_field_with_default = example_field_with_default

    class BadExampleClass():
        def __init__(self, catch_all: CatchAllVar):
            self.catch_all = catch_all

    # Test 0: should not receive any undefined parameters
    try:
        _CatchAllUndefinedParameters.handle_from_dict(ExampleClass,
                                                      {"the_answer": 42})
    except UndefinedParameterError:
        assert False, "Can handle undefined parameters"

    # Test 1: should receive undefined parameters
    result = _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:14:03.841379
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    unused_parameter = _UndefinedParameterAction()
    result = _UndefinedParameterAction.handle_dump({})
    assert result == {}


# Generated at 2022-06-25 16:14:08.347952
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class _UndefParsTestClass:
        def __init__(self):
            pass

    target = _IgnoreUndefinedParameters()
    actual = target.handle_dump(_UndefParsTestClass)
    assert actual == {}



# Generated at 2022-06-25 16:14:32.174210
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class DummyClass(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def foo(self, a: int, b: int, c: int) -> int:
            raise NotImplementedError()

    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    raise_undefined_parameters_1 = _RaiseUndefinedParameters()

    assert raise_undefined_parameters_0.handle_from_dict(
        DummyClass,
        {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-25 16:14:37.773387
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    kvs_0: Dict[str, Any] = {"hello": "world"}
    kvs_1: Dict[str, Any] = {"hello": "world", "b": "c"}
    leet_0 = raise_undefined_parameters_0.handle_from_dict(Leet, kvs_0)
    assert leet_0 == {"number": 1337, "hello": "world"}
    with pytest.raises(UndefinedParameterError):
        _ = raise_undefined_parameters_0.handle_from_dict(Leet, kvs_1)



# Generated at 2022-06-25 16:14:46.977403
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_0 = _CatchAllUndefinedParameters()
    test_object = {1:2, 3:4}
    assert undefined_0.handle_to_dict(test_object, kvs={}) == {1:2, 3:4}
    assert undefined_0.handle_to_dict(test_object, kvs={1:2}) == {1:2, 3:4}
    assert undefined_0.handle_to_dict(test_object, kvs={3:4}) == {1:2, 3:4}


# Generated at 2022-06-25 16:14:53.534674
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class _TestClassCatchAll:
        pass

    caught_error = False
    try:
        _CatchAllUndefinedParameters.create_init(_TestClassCatchAll)
    except UndefinedParameterError:
        caught_error = True

    assert caught_error, "Did not catch TypeError."

    class _TestClassCatchAll:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            pass

    _CatchAllUndefinedParameters.create_init(_TestClassCatchAll)



# Generated at 2022-06-25 16:15:06.267386
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Given
    class CatchAllClass:
        def __init__(self, a: str, b: str, c: int,
                     # type: ignore
                     **unknown: CatchAllVar):
            self.a = a
            self.b = b
            self.c = c
            self.unknown = unknown

    data = {
        "a": "1",
        "b": "2",
        "c": 3,
        "unknown.a": "4",
        "unknown.b": "5"
    }
    catch_all_class = CatchAllClass(**data)

    # When
    written_data = _CatchAllUndefinedParameters.handle_to_dict(
        obj=catch_all_class, kvs=data)

    # Then
    assert written_data["a"] == "1"

# Generated at 2022-06-25 16:15:14.071672
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def test_func(self, a: int, b: str, c: float = 3.4, d: bool = True,
                  e: CatchAll = None):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.e = e

    test_func_0 = \
        _CatchAllUndefinedParameters.create_init(test_func)
    test_func_0(None, 1, "a", e={"x": 1, "y": 2})



# Generated at 2022-06-25 16:15:21.626362
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()

    class Needles(metaclass=dataclasses.dataclass):

        @dataclasses.dataclass_json(undefined=Undefined.EXCLUDE)
        class Inner:

            blue: str = "blue"
            red: str = "red"

            def __init__(self, **kwargs):
                pass
            # enddef
        # endclass

        thread: Inner = Inner()
        needles: int = 1
    # endclass

    created_init = ignore_undefined_parameters.create_init(Needles)
    assert isinstance(created_init, Callable)

    instance = Needles(needles=2)

# Generated at 2022-06-25 16:15:24.875218
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    kvs = {"hello": "42", "world": "lel"}
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=None, kvs=kvs) == kvs



# Generated at 2022-06-25 16:15:27.013569
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    """
    This method is actually tested via other methods/classes, but this is still
    useful
    """
    pass

# Generated at 2022-06-25 16:15:30.153970
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    _UndefinedParameterAction.handle_from_dict(cls, kvs)
    raise NotImplementedError()


# Generated at 2022-06-25 16:15:53.946902
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Dummy:
        def __init__(self, a: int,
                     b: Optional[CatchAllVar] = None,
                     c: str = "huhu"):
            self.a = a
            self.b = b
            self.c = c

    d = Dummy(a=1, c="haha", not_parsed={"x": "y"})

    assert d.a == 1
    assert d.b == {"not_parsed": {"x": "y"}}
    assert d.c == "haha"



# Generated at 2022-06-25 16:16:00.772502
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def init(self, a, b):
        self.a = a
        self.b = b

    instance = _IgnoreUndefinedParameters()
    init = inspect.signature(init)

    def _init(self, a, b, c, d, e, f):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.e = e
        self.f = f

    init_dict = inspect.signature(_init)
    new_init = instance.create_init(obj=init_dict)
    class Dummy:
        def __init__(self, a, b, c, d, e, f):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e

# Generated at 2022-06-25 16:16:07.054512
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Base:
        def __init__(self, a, b, c, d, e, f=7, g=8, h=9, i=10, j=11, k=12,
                     l=13, m=14, n=15, o=16, p=17, q=18, r=19, s=20, t=21,
                     u=22, v=23, w=24, x=25, y=26, z=27):  # noqa: E501
            pass

    class Child(_CatchAllUndefinedParameters.create_init(Base)):
        pass

    Child(1, 2, 3, 4, 5, 6)
    Child(1, 2, 3, 4, 5, 6, catch_all={"a": "b"})

# Generated at 2022-06-25 16:16:11.069651
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_under_test = _CatchAllUndefinedParameters()
    input_dict = {"a": 1, "b": 2}
    result = catch_all_under_test.handle_to_dict(obj=None, kvs=input_dict)
    assert input_dict == result


# Generated at 2022-06-25 16:16:19.642416
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self,
                     number: int,
                     boolean: bool = False,
                     name: str = "tester",
                     **undefined_parameters):
            pass

    test_class = TestClass(1)
    assert test_class.__init__ == _UndefinedParameterAction.create_init(
        test_class)

    test_class_2 = TestClass(1, name="too_many")

    with pytest.raises(TypeError) as excinfo0:
        test_class_2.__init__(1)
    assert "__init__" in str(excinfo0.value)

    with pytest.raises(TypeError) as excinfo1:
        test_class_2.__init__(1, name="another_one")

# Generated at 2022-06-25 16:16:29.798639
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow import Schema
    import marshmallow_dataclass
    from .utils import CatchAllVar
    from .utils import dataclass_json

    @dataclass_json(undefined=Undefined.EXCLUDE)
    class TestClass:
        field_1: str = "test_1"
        field_2: str = "test_2"
        field_3: CatchAllVar = CatchAll(str)

    schema = marshmallow_dataclass.class_schema(TestClass)

    try:
        TestClass(field_1="peter")
    except TypeError:
        pass
    else:
        assert False

    @dataclass_json(undefined=Undefined.EXCLUDE)
    class TestClass:
        field_1: str = "test_1"
        field_2

# Generated at 2022-06-25 16:16:37.181205
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Dummy(object):
        x: float
        y: float
        z: float
        _UNDEFINED_PARAMETER_ACTION = ignore_undefined_parameters = \
            _IgnoreUndefinedParameters()

        def __init__(self, x: float, y: float, z: float,
                     **kwargs) -> None:
            self.x = x
            self.y = y
            self.z = z

    dummy = Dummy(1, 2, 3)



# Generated at 2022-06-25 16:16:47.583394
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    cls = _CatchAllUndefinedParameters()
    obj = object()

    # Test 0
    # No catch-all field
    with pytest.raises(UndefinedParameterError):
        cls.handle_dump(obj)

    # Test 1
    # With catch-all field
    class Foo:
        def __init__(self):
            pass
        def __eq__(self, other):
            return True

    class _CatchAllFoo(Foo):
        def __init__(self, catch_all=None):
            self.catch_all = catch_all

        unknown1 = "Some value"
        unknown2 = dict(
            parameter1=1,
            parameter2=2,
            parameter3=3,
        )

    # Test 1.1
    # Without unknown parameters

# Generated at 2022-06-25 16:16:59.633783
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    def _check(t, expected, data):
        def _do(cls):
            init = t.create_init(cls)
            actual = init(*data)
            assert actual == expected

        return _do

    def _check_exception(t, expected, data):
        def _do(cls):
            init = t.create_init(cls)
            try:
                init(*data)
                raise Exception("expected exception not raised")
            except UndefinedParameterError as e:
                actual = str(e)
                assert actual == expected

        return _do

    class TestCase:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-25 16:17:10.837091
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0_call = functools.partial(
        ignore_undefined_parameters_0.handle_from_dict, cls=None)

    ignore_undefined_parameters_0_expected_result = {}
    assert ignore_undefined_parameters_0_call(kvs=ignore_undefined_parameters_0_expected_result) == ignore_undefined_parameters_0_expected_result
    ignore_undefined_parameters_0_expected_result = {'a': 'b'}
    assert ignore_undefined_parameters_0_call(kvs=ignore_undefined_parameters_0_expected_result) == ignore_undefined_parameters_0_expected_result
    ignore_und

# Generated at 2022-06-25 16:17:37.944529
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = {'undefined': Undefined.RAISE, 'value': 2}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_to_dict(Undefined.RAISE, dict_0)
    assert dict_1['undefined'] == Undefined.RAISE
    assert dict_1['value'] == 2



# Generated at 2022-06-25 16:17:40.905291
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 0, **undefined_parameter):
            pass
    _UndefinedParameterAction.handle_from_dict(TestClass, {})

# Generated at 2022-06-25 16:17:43.539064
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    assert _IgnoreUndefinedParameters.handle_from_dict(Undefined.RAISE,{Undefined.RAISE : Undefined.INCLUDE})=={}


# Generated at 2022-06-25 16:17:54.898005
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Define a class which has a CatchAll parameter
    class TestClass:
        def __init__(self, x, y=0, z: CatchAll = None):
            pass

    # We need to create an instance of the class to make sure of
    # the default implementations existence
    test_obj = TestClass(1, 2)

    # Make a copy of the original __init__ method
    original_init = test_obj.__init__

    # Create a new __init__ method by letting class
    # _CatchAllUndefinedParameters take care of it
    new_init = _CatchAllUndefinedParameters.create_init(test_obj)

    # Check that the original and the new __init__ methods are different
    assert original_init != new_init

    # Run the new __init__ method with all parameters explicitly set
    # and

# Generated at 2022-06-25 16:17:59.510036
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    undefined_0 = Undefined.RAISE
    dict_0 = {undefined_0: undefined_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(undefined_0, dict_0)


# Generated at 2022-06-25 16:18:12.525823
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    obj = _IgnoreUndefinedParameters()
    cls = _IgnoreUndefinedParameters
    dict_input = {"_name_field": "name", "field0": 0}
    #isinstance(obj, _UndefinedParameterAction)

    # Test case 0
    # cls = None (type)
    cls_0 = None
    dict_0 = dict_input
    dict_output = dict_input
    dict_out = obj.handle_from_dict(cls_0, dict_0)
    assert dict_out == dict_output

    # Test case 1
    # cls = _UndefinedParameterAction (type)
    # dict_0 = {} (dict)
    cls_1 = abc.ABC  # _UndefinedParameterAction (type)
    dict_1 = {}
    dict_output = {}
   

# Generated at 2022-06-25 16:18:17.004471
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    class_0 = Undefined
    create_init_0 = catch_all_undefined_parameters_0.create_init(class_0)


# Generated at 2022-06-25 16:18:23.134327
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class B: pass
    b = B()
    undefined_0 = Undefined.RAISE
    dict_0 = {undefined_0: undefined_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_to_dict(b, dict_0)
    # The method handle_to_dict of class _UndefinedParameterAction returns dict_0
    dict_2 = dict_0
    assert dict_1 == dict_2


# Generated at 2022-06-25 16:18:24.209231
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass


# Generated at 2022-06-25 16:18:34.177644
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    import pytest

    @dataclass
    class A:
        field_0: str

        def __init__(self, field_0 = "test_0") -> None:
            pass

    schema_0 = Schema()

    data_0 = {"field_0": "test_1"}
    data_1 = {}
    with pytest.raises(ValidationError):
        A.__init__(data_0)
        schema_0.load(data_0)
    schema_0.load(data_1)

if __name__ == "__main__":
    print("Object made")

# Generated at 2022-06-25 16:19:22.550494
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_field = Field(name="_catch_all",
                            type=Optional[CatchAllVar], default=None)
    undefined_class = dataclasses.make_dataclass("undefined_class",
                                                 [catch_all_field])
    dict_0 = {"a": 1}
    dict_1 = _CatchAllUndefinedParameters.handle_from_dict(undefined_class,
                                                           dict_0)
    dict_2 = {"a": 1, "_catch_all": {"a": 2}}
    dict_3 = _CatchAllUndefinedParameters.handle_from_dict(undefined_class,
                                                           dict_2)
    dict_4 = {"a": 1, "_catch_all": {"a": 2, "b": 3}}
    dict_5 = _Catch

# Generated at 2022-06-25 16:19:31.184356
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class test_class_0:
        def __init__(self, a_0, **kwargs):
            pass

    undefined_0 = Undefined.RAISE
    test_object_0 = test_class_0(a_0=1, b_0=2)
    dict_0 = {undefined_0: undefined_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(test_object_0, dict_0)



# Generated at 2022-06-25 16:19:42.355130
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    undefined_0 = Undefined.RAISE
    # The class is just mocked. It doesn't need to make sense.
    class_with_ignore_undefined_parameters_0 = lambda undefined_1: \
        ignore_undefined_parameters_0

    # Create a mocked instance method
    ignore_undefined_parameters_0 = lambda self_0, undefined_1: \
        None
    # Get the signature of the mocked instance method
    init_signature_0 = inspect.signature(ignore_undefined_parameters_0)
    # The mocked class has only one instance method
    _IgnoreUndefinedParameters.create_init(
        class_with_ignore_undefined_parameters_0)()
    # Mocked instance method that defines the parameters of the mocked class



# Generated at 2022-06-25 16:19:53.887686
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined_parameters = Undefined.RAISE
    data = {undefined_parameters: undefined_parameters}
    error_message = "Received undefined initialization arguments {}"
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            undefined_parameters, data)
    except UndefinedParameterError as e:
        assert str(e) == error_message.format(data)
    else:
        raise AssertionError("Test case failed")

# Generated at 2022-06-25 16:20:04.209604
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Example(object):
        def __init__(self, a: int, b: int, c: bool, **kwargs):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            if isinstance(other, Example):
                return self.a == other.a and self.b == other.b \
                       and self.c == other.c
            else:
                return False

    test_dict_1 = {
        'a': 1,
        'b': 2,
        'c': True
    }
    test_dict_2 = {
        'a': 2,
        'b': 2,
        'c': False,
        'd': 1,
        'e': 2
    }

# Generated at 2022-06-25 16:20:06.504397
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    undefined_0 = Undefined.RAISE
    dict_0 = {undefined_0: undefined_0}
    dict_1 = _UndefinedParameterAction.handle_from_dict(undefined_0, dict_0)


# Generated at 2022-06-25 16:20:12.820887
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    test_class_0 = TestClass("alpha", "bravo")
    test_class_1 = TestClass("charley", undefined_parameter_action=Undefined.RAISE)
    ignore_undefined_parameters_0.create_init(test_class_0)
    ignore_undefined_parameters_0.create_init(test_class_1)


# Generated at 2022-06-25 16:20:21.973205
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_0 = Undefined.EXCLUDE
    dict_0 = {"camelCase": undefined_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(undefined_0, dict_0)
    # assert(dict_1 == {"camelCase": undefined_0})
    # The following assertion is valid but the previous one is not?
    assert(dict_1 == {"camelCase": undefined_0})


# Generated at 2022-06-25 16:20:28.476472
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class InnerClass:
        def __init__(self, a: int, b: int = 1, **kwargs):
            self.a = a
            self.b = b

    object_unsafe = {
        InnerClass: InnerClass(a=17, c=11),
    }

    # test case 0: no undefined parameters
    dict_0 = {'a': 17, 'b': 11}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_1 = \
        raise_undefined_parameters_0.handle_from_dict(InnerClass, dict_0)
    assert dict_1 == dict_0

    # test case 1: one undefined parameter
    dict_2 = {'a': 17, 'b': 11, 'c': 11}

# Generated at 2022-06-25 16:20:33.365932
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class C(abc.ABC):
        @abc.abstractmethod
        def handle_to_dict(self, obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            pass

    cls_catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    cls_raise_undefined_parameters = _RaiseUndefinedParameters()
    cls_ignore_undefined_parameters = _IgnoreUndefinedParameters()


# Generated at 2022-06-25 16:22:16.188316
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    undefined_0 = Undefined.INCLUDE
    dict_0 = {undefined_0: undefined_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(undefined_0,
                                                               dict_0)



# Generated at 2022-06-25 16:22:17.919990
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError('message')
    assert err.args[0] == 'message'
    assert err.message == 'message'

# Generated at 2022-06-25 16:22:24.169764
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ignored_parameters = {
        "a": 1,
        "b": 2,
        "c": 3,
    }

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class TestClass:
        a: int
        b: int
        c: int

    test_class = TestClass(*(), **{})
    assert (test_class.a, test_class.b, test_class.c) == (None, None, None)

    test_class = TestClass(*(), **ignored_parameters)
    assert (test_class.a, test_class.b, test_class.c) == (1, 2, 3)



# Generated at 2022-06-25 16:22:32.902579
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Example:
        def __init__(self, test: str, catch: CatchAll = None):
            self.test = test
            self.catch = catch

    example = Example("Test", {undefined: undefined for undefined in
                               Undefined})
    result = _CatchAllUndefinedParameters.handle_dump(example)
    expected = {Undefined.RAISE: Undefined.RAISE,
                Undefined.INCLUDE: Undefined.INCLUDE,
                Undefined.EXCLUDE: Undefined.EXCLUDE}
    assert result == expected

# Generated at 2022-06-25 16:22:41.076098
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    a = 3
    b = 4

    class TestClass:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = {}):
            self.a = a

    test_init = _CatchAllUndefinedParameters.create_init(TestClass)
    tc1 = test_init(TestClass(a, b), c={2: 3})
    tc2 = test_init(TestClass(a, b), 2, 3)

