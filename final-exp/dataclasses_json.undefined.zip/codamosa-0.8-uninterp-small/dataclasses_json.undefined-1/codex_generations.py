

# Generated at 2022-06-25 16:12:51.721869
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a, b, c=None, d=None):
            pass

    init = _UndefinedParameterAction.create_init(obj=A)
    assert init is A.__init__



# Generated at 2022-06-25 16:13:03.334959
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def some_init(self, a: int = 1, b: str = "aha") -> None:
        pass

    class Test:
        def __init__(self, a: int = 1, b: str = "aha"):
            pass

    some_init = Test.__init__
    Test.__init__ = _IgnoreUndefinedParameters.create_init(Test)

    # Some example code to directly jump to the condition that we want to test
    # for
    kwargs = {"a": 1, "b": "aha", "c": "nope"}
    original_init_signature = inspect.signature(some_init)
    original_init_signature.parameters["c"] = \
        inspect.Parameter("c", inspect.Parameter.VAR_KEYWORD)

# Generated at 2022-06-25 16:13:11.921497
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from unittest.mock import Mock

    class _AddElement:
        def __init__(self, *, a, b=1, c="default"):
            self.c = c
            self.a = a
            self.b = b

    _AddElement.__init__ = Mock(_AddElement.__init__)

    # noinspection PyUnusedLocal
    class _AddElement2:
        def __init__(self, *, a, b=1, c="default", catch_all: Optional[CatchAllVar] = None):
            self.c = c
            self.a = a
            self.b = b
            self.catch_all = catch_all

    _AddElement2.__init__ = Mock(_AddElement2.__init__)


# Generated at 2022-06-25 16:13:13.603354
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    msg = "test message"
    err = UndefinedParameterError(msg)
    assert err.messages == msg

# Generated at 2022-06-25 16:13:17.406372
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int = 5
        b: str = "aa"

        def __init__(self, a: int, b: str, *args, **kwargs):
            pass

    obj = A(1, "a", "c", a="d", d=3)



# Generated at 2022-06-25 16:13:20.878194
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    input_field1 = "field1"
    input_field2 = "field2"
    test_class = type("TestClass", (object,),  {})
    input_dict = {input_field1: 1, input_field2: 2}
    result = _RaiseUndefinedParameters.handle_from_dict(test_class, input_dict)
    assert result == input_dict


# Generated at 2022-06-25 16:13:25.818540
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    kwargs = {"a": "b"}

    assert _UndefinedParameterAction.handle_dump(None) == {}

    assert _RaiseUndefinedParameters.handle_dump(
        None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(
        None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(
        None) == {}



# Generated at 2022-06-25 16:13:33.726664
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    input_dict = {
        "key": "value",
        "_unknownKey": "unknownValue",
        "_unknownKey2": "unknownValue2"
    }
    catch_all = CatchAll(input_dict)
    assert catch_all._CatchAll__kvs == input_dict
    output_dict = _CatchAllUndefinedParameters \
        .handle_to_dict(catch_all, input_dict)
    assert output_dict == {"key": "value"}


if __name__ == "__main__":
    pass

# Generated at 2022-06-25 16:13:44.188384
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def test_helper():
        class A:
            def __init__(self, a, b, _a):
                self.a = a
                self.b = b
                self._a = _a

        a = A(a=1, b=2, _a={"_a": 3})
        kvs = {
            "a": 1,
            "b": 2,
            "_a": {"_a": 3}
        }
        assert _UndefinedParameterAction.handle_to_dict(a, kvs) == {
            "a": 1,
            "b": 2,
            "_a": {"_a": 3}
        }
    test_helper()


# Generated at 2022-06-25 16:13:51.642359
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    undefined_0 = Undefined.INCLUDE
    unknown_init_parameter_0 = "test"

    @undefined(undefined_0)
    class TestClass0:
        def __init__(self) -> None:
            pass

    with pytest.raises(UndefinedParameterError, match=r"multiple catch-all"):
        TestClass0()

    with pytest.raises(UndefinedParameterError, match=r"no catch-all"):
        undefined(undefined_0)(TestClass0)()

    @undefined(undefined_0)
    class TestClass1:
        def __init__(self, test: str) -> None:
            pass

    TestClass1(test="")

    TestClass1(test="", unknown_init_parameter=unknown_init_parameter_0)



# Generated at 2022-06-25 16:14:23.619799
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    catch_all_parameter = \
        _CatchAllUndefinedParameters._get_catch_all_field.__func__
    get_default = _CatchAllUndefinedParameters._get_default.__func__

    class CatchAllTest:
        def __init__(self, a: str, b: str, c: str,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    class TestCase:
        @dataclasses.dataclass
        class TestCase:
            name: str
            undefined_class: _CatchAllUndefinedParameters
            cls: Any
            given_parameters: Dict[Any, Any]
            expected_result: Dict[str, Any]
            expected_catch

# Generated at 2022-06-25 16:14:35.109571
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test:
        def __init__(self, a: int = 0, b: int = 0, c: int = 0):
            self.a = a
            self.b = b
            self.c = c

        def to_dict(self):
            return {
                "a": self.a,
                "b": self.b,
                "c": self.c
            }
    t = Test(1, 2, 3)
    assert _UndefinedParameterAction.handle_to_dict(t, {
        "a": 1,
        "b": 2,
        "c": 3
    }) == {
        "a": 1,
        "b": 2,
        "c": 3
    }

# Generated at 2022-06-25 16:14:47.161239
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined = Undefined.RAISE
    assert issubclass(undefined.value, _UndefinedParameterAction)

    fixed_arguments = {"a": 1, "b": 2}
    undefined_action = undefined.value

    def test_(cls, kvs):
        return undefined_action.handle_from_dict(cls, kvs)

    # Test 0:
    # No undefined parameters
    @dataclasses.dataclass
    class Test0:
        a: int
        b: int

    result = test_(Test0, fixed_arguments)
    assert result == fixed_arguments

    # Test 1:
    # 1 undefined parameter
    @dataclasses.dataclass
    class Test1:
        a: int
        b: int

    undefined_parameters = {"c": 3}

# Generated at 2022-06-25 16:14:53.097001
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=undefined_0)
    class TestCase0:
        a: int
        b: int = 10

    obj = TestCase0(42, b=43)

    assert obj.a == 42
    assert obj.b == 43
    assert obj.__class__.__init__ != _CatchAllUndefinedParameters.create_init(
        TestCase0)  # The real init is overwritten in test_case_0



# Generated at 2022-06-25 16:15:06.040550
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Scenario: "Normal" class with catch-all kwarg:
    class A:
        def __init__(self, a_0: str, catch_all: CatchAll = {}):
            self.a_0: str = a_0
            self.catch_all: CatchAllVar = catch_all

    # Arrange
    a_0 = "a_0"
    unknown_0 = "unknown_0"
    unknown_1 = "unknown_1"
    expected_args_0 = {
        "a_0": a_0,
        unknown_0: unknown_0,
        unknown_1: unknown_1,
    }
    expected_args_1 = {
        "a_0": a_0,
        "catch_all": expected_args_0,
    }
    func = _CatchAll

# Generated at 2022-06-25 16:15:14.656963
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    test_case = {"a": 2, "b": "test"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, test_case)
    test_case = {"a": 2, "b": 2, "c": 3}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, test_case)

    test_case = {"a": 2, "b": "3"}
    _RaiseUndefinedParameters.handle_from_dict(TestClass, test_case)



# Generated at 2022-06-25 16:15:20.015639
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test whether the method return value is the same as the argument
    if the argument is not a dictionary.
    """
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(None, []) == []
    assert _UndefinedParameterAction.handle_to_dict(None, "foo") == "foo"
    assert _UndefinedParameterAction.handle_to_dict(None, 1) == 1


# Generated at 2022-06-25 16:15:31.056998
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from unittest.mock import Mock
    # noinspection PyUnresolvedReferences
    from dataclasses import dataclass
    from dataclasses_json.config import Config

    dataclass_patcher = Mock()

    _dataclasses_dataclass = dataclasses.dataclass
    dataclasses.dataclass = dataclass_patcher

# Generated at 2022-06-25 16:15:35.744550
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class _TestClass:
        catch_all: CatchAllVar = None


    arguments = {"catch_all": {"a": 1}}
    _CatchAllUndefinedParameters.handle_from_dict(_TestClass, arguments)



# Generated at 2022-06-25 16:15:40.494864
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, catch_all: CatchAll = None, **kwargs):
            from dataclasses_json.utils import _CatchAllUndefinedParameters

            _CatchAllUndefinedParameters.handle_from_dict(TestClass, kwargs)

    input_parameters = {"catch_all": {"a": "b"}}
    TestClass(**input_parameters)



# Generated at 2022-06-25 16:16:29.903691
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class DummyClass:
        a: str
        b: str
        c: float
        d: bool
        e: float

        def __init__(self, a: str, b: str, d: bool,
                     e: float = 1.2):
            self.a = a
            self.b = b
            self.d = d
            self.e = e
            self.c = 1.3  # Has a default, but should be set during initialization

        def __eq__(self, other):
            return self.a == other.a \
                   and self.b == other.b \
                   and self.c == other.c \
                   and self.d == other.d \
                   and self.e == other.e


# Generated at 2022-06-25 16:16:37.983904
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined = _RaiseUndefinedParameters()
    test_class = dataclasses.make_dataclass("test_class", [("a", str), ("b",
                                                                           str)])
    known_kvs = {"a": "x", "b": "y"}
    unknown_kvs = {"c": "z"}
    kvs = {**known_kvs, **unknown_kvs}

    expected_result = known_kvs
    assert undefined.handle_from_dict(cls=test_class, kvs=kvs) == \
           expected_result



# Generated at 2022-06-25 16:16:45.842796
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undef = _RaiseUndefinedParameters
    defined_parameters = undef.handle_from_dict(Foo, {"z": 3, "y": 2})
    assert defined_parameters == {"z": 3, "y": 2}
    try:
        undef.handle_from_dict(Foo, {"z": 3, "y": 2, "x": 1})
        assert False
    except UndefinedParameterError:
        assert True


# Unit tests for method handle_from_dict of class _IgnoreUndefinedParameters

# Generated at 2022-06-25 16:16:54.727889
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, undefined_parameters: CatchAll):
            self.undefined_parameters = undefined_parameters

    test_instance = TestClass(undefined_parameters={"hello": "world"})
    result = _CatchAllUndefinedParameters.handle_to_dict(
        test_instance,
        {"undefined_parameters": {"hello": "world"}}
    )
    assert result == {"hello": "world"}

# Generated at 2022-06-25 16:17:02.460464
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    assert(_IgnoreUndefinedParameters.handle_from_dict(
        type("notAnInstance", (object, ), {}), {}) == {})

    assert(_IgnoreUndefinedParameters.handle_from_dict(
        type("notAnInstance", (object, ), {
            'a': 1}), {'a': 1, 'b': 2}) == {'a': 1})

    assert(_IgnoreUndefinedParameters.handle_from_dict(
        type("notAnInstance", (object, ), {
            'a': 1}), {'a': 1, 'b': 2, 'c': 3}) == {'a': 1})


# Generated at 2022-06-25 16:17:05.974014
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_action = _UndefinedParameterAction
    obj = object
    dumped_object = undefined_action.handle_dump(obj)
    assert isinstance(dumped_object, dict)


# Generated at 2022-06-25 16:17:13.000210
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    handler = _CatchAllUndefinedParameters()
    class TestClass:
        def __init__(self, my_prop:str, catch_all:Optional[CatchAll]):
            self.my_prop = my_prop
            self.catch_all = catch_all

    test_instance = TestClass("abc", {"abc":1,"def":2})
    dict = handler.handle_dump(test_instance)
    assert dict == {"abc":1,"def":2}


# Generated at 2022-06-25 16:17:22.409868
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Test case 0, undefined parameters
    undefined_0 = Undefined.INCLUDE
    class Inner:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    instance = Inner(a=1, b=2, c=3)
    expected = {"a": 1, "b": 2}
    actual = undefined_0._UndefinedParameterAction.handle_to_dict(
        obj=Inner, kvs={"a": 1, "b": 2, "c": 3})
    assert expected == actual

    # Test case 1, inner class
    class Inner:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c



# Generated at 2022-06-25 16:17:28.557613
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():

    class _TestClass:
        def __init__(self, one: str, two: str):
            self.one = one
            self.two = two

        def to_dict(self):
            return _UndefinedParameterAction.handle_to_dict(self,
                                                            {'one': self.one,
                                                             'two': self.two})

    class TestClassInclude(_TestClass):
        def __init__(self, three: str = None, **kwargs):
            self.three = three
            super(TestClassInclude, self).__init__(**kwargs)

        def to_dict(self):
            return _CatchAllUndefinedParameters.handle_to_dict(self,
                                                               super().to_dict())


# Generated at 2022-06-25 16:17:41.527377
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    caup = _CatchAllUndefinedParameters()
    class A:
        other_field = 1
        catch_all: Optional[CatchAllVar] = None
    kvs1 = {
        "other_field": 1,
        "catch_all": {"test": 1}
    }
    kvs2 = {
        "other_field": 1,
        "catch_all": {}
    }
    kvs3 = {
        "other_field": 1,
        "catch_all": None
    }

    # Test 1: clean-up case
    assert kvs1 == caup.handle_to_dict(A, kvs1)
    # Test 2: empty case
    assert kvs2 == caup.handle_to_dict(A, kvs2)
    # Test 3: None case
   

# Generated at 2022-06-25 16:18:37.779338
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]
    _CatchAllUndefinedParameters.handle_to_dict(dict_0, dict_0)


# Generated at 2022-06-25 16:18:40.453658
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    print("Unit test for constructor of class UndefinedParameterError")

    error = UndefinedParameterError("Wrong type given")
    assert isinstance(error, ValidationError)
    assert isinstance(error, Exception)
    assert isinstance(error, BaseException)

# Generated at 2022-06-25 16:18:53.429703
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    list_0 = ['\n            DataClassJsonMixin is an ABC that functions as a Mixin.\n\n            As with other ABCs, it should not be instantiated directly.\n            ', '\n            DataClassJsonMixin is an ABC that functions as a Mixin.\n\n            As with other ABCs, it should not be instantiated directly.\n            ']
    int_0 = list_0
    int_0 = list_0[0]
    int_0 = list_0[1]
    callable_0 = _CatchAllUndefinedParameters.create_init(int_0)

if __name__ == '__main__':
    test_case_0()
    test__CatchAllUndefinedParameters_create_init()

# Generated at 2022-06-25 16:19:05.958734
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    type_0 = _IgnoreUndefinedParameters.handle_from_dict
    parameter = list
    try:
        type_0(parameter, dict())
    except UndefinedParameterError:
        pass
    finally:
        local_host = dict_0
        local_host.clear()
        local_host = dict_0
        local_host.clear()
        local_host.popitem()
        local_host = dict_1
        local_host.clear()
        local_host.popitem()
        local_host = dict_1
        local_host.clear()
        local_host.popitem()
        local_host = dict_0
        local_host.clear()
        local_host = dict_0
        local_host.clear()
        local_host = dict_1
        local_host.clear()


# Generated at 2022-06-25 16:19:14.217339
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    str_0 = '\x99'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]
    list_0_clone_0 = {str_1: str_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_dump(list_0)
    assert list_0_clone_0 == {str_1: str_1}


# Generated at 2022-06-25 16:19:22.981073
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    _ = ignore_undefined_parameters_0.create_init(list_0)


# Generated at 2022-06-25 16:19:34.562695
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_0 = catch_all_undefined_parameters_0.create_init(list_0)
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(list_0, dict_0)

# Generated at 2022-06-25 16:19:38.381301
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    callable_0 = raise_undefined_parameters_0.handle_from_dict(dict_0)
    callable_0



# Generated at 2022-06-25 16:19:41.902556
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises((SystemExit, ValueError)):
        UndefinedParameterError('The unittest driver was called.')
    try:
        raise UndefinedParameterError('The unittest driver was called.')
    except UndefinedParameterError as e_instance:
        assert isinstance(e_instance, UndefinedParameterError)
        assert 'The unittest driver was called.' in str(e_instance)


# Generated at 2022-06-25 16:19:46.954783
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_0 = catch_all_undefined_parameters_0.create_init(list_0)


# Generated at 2022-06-25 16:22:04.024415
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = '\x0bN'
    str_1 = 'o<b'
    str_2 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_1: str_1, str_2: str_2}
    kvs_0 = dict_0
    cls_0 = dict_0
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_from_dict(cls_0, kvs_0)


# Generated at 2022-06-25 16:22:07.097729
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.undefined_parameters import _CatchAllUndefinedParameters
    class DummyClass:
        def __init__(self):
            pass
    dummy_class = DummyClass()
    _CatchAllUndefinedParameters.handle_from_dict(dummy_class , {})


# Generated at 2022-06-25 16:22:17.931760
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # from python_test_case import PythonTestCase, run_tests
    # from dataclasses_json.undefined import _IgnoreUndefinedParameters

    class TestCase(unittest.TestCase):

        def test_case_0(self):
            str_0 = '\x0bN'
            str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
            dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
            list_0 = [dict_0, dict_0, dict_0]
            ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
            callable_0 = ignore_

# Generated at 2022-06-25 16:22:20.186339
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Test that the method can be called
    try:
        test_case_0()
    except TypeError as e:
        print(e)
        assert False


# Generated at 2022-06-25 16:22:26.806935
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0, dict_0]

    str_2 = '\x0bN'
    str_3 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '

# Generated at 2022-06-25 16:22:36.806113
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = '\x0bN'
    str_1 = '\n    DataClassJsonMixin is an ABC that functions as a Mixin.\n\n    As with other ABCs, it should not be instantiated directly.\n    '
    list_0 = [str_0]
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    tuple_0 = catch_all_undefined_parameters_0.handle_from_dict(dict_0,
                                                                {str_1: list_0,
                                                                 str_0: str_0})
    assert tuple_0 == (dict_0, dict_0)

#