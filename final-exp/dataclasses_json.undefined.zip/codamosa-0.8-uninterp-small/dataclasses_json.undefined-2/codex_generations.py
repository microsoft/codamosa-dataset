

# Generated at 2022-06-25 16:13:01.689873
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Obj:
        def __init__(self, a: str,
                     b: int = 1,
                     c: bool = True,
                     d_: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d_

    obj = Obj("a", b=1, d_={"a": "b", "c": "d"})
    catch_all_kv = {"a": "b", "c": "d"}

    kv_to_dict = {"a": "a", "b": 1, "c": True, "d": catch_all_kv}
    obj_to_dict = {"a": "a", "b": 1, "c": True, "a": "b", "c": "d"}

    # Make sure the method

# Generated at 2022-06-25 16:13:10.551966
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    x_val = 1

    @dataclasses.dataclass
    class MyClass0:
        x: int
        y: int
        z: int
        catch_all_field: Optional[CatchAllVar] = dataclasses.field(
            default=None)

        def __init__(self, x: int, y: int, z: int,
                     catch_all_field: Optional[CatchAllVar] = None):
            self.x = x
            self.y = y
            self.z = z
            self.catch_all_field = catch_all_field

    # noinspection PyProtectedMember
    assert _CatchAllUndefinedParameters._get_catch_all_field(MyClass0) == \
           MyClass0.__dataclass_fields__["catch_all_field"]

    #

# Generated at 2022-06-25 16:13:13.250782
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('test message')
    except Exception as e:
        assert e.args == ('test message',)
        assert str(e) == 'test message'

# Generated at 2022-06-25 16:13:16.796595
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()
    _UndefinedParameterAction \
        .handle_to_dict(ignore_undefined_parameters,
                        {"test_key1": "test_value1", "test_key2": "test_value2"})


# Generated at 2022-06-25 16:13:20.689977
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undef_param_action = _UndefinedParameterAction()
    undef_param_action.handle_dump(None)



# Generated at 2022-06-25 16:13:25.971794
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    known_parameters = {"a": 42, "b": 43}
    input_dict = dict(known_parameters)
    input_dict.update({"c": 44, "d": 45})
    output = raise_undefined_parameters.handle_from_dict(int, input_dict)
    assert output == known_parameters



# Generated at 2022-06-25 16:13:38.153775
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    defined_params = {"first_name": "John", "last_name": "Doe"}
    undefined_params = {"email": "john@doe.com"}
    undefined_params_2 = {"age": 42}
    all_params = dict(defined_params)
    all_params.update(undefined_params)

    action = _RaiseUndefinedParameters()

    class DummyClass:
        _UNDEFINED_PARAMETER_ACTION = action

        first_name: str
        last_name: str

    dummy_class = DummyClass()

    expected_parameters = {**defined_params, **undefined_params_2}
    result_parameters = action.handle_from_dict(dummy_class, all_params)
    assert expected_parameters == result_parameters



# Generated at 2022-06-25 16:13:41.122252
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses_json.utils import _IgnoreUndefinedParameters
    _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        int, {})



# Generated at 2022-06-25 16:13:43.090043
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(message="Test Message")
    assert error.args == ("Test Message",)



# Generated at 2022-06-25 16:13:44.867532
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()



# Generated at 2022-06-25 16:14:11.657150
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    test_ignored_parameter_0 = {
        "a": "a",
        "b": "b",
        "c": "c",
        "d": "d"
    }

    class TestClass_0(metaclass=abc.ABCMeta):
        a = Field(repr=True)
        b = Field(repr=True)
        c = Field(repr=True)

    parameters_to_init_with_0 = \
        _IgnoreUndefinedParameters.handle_from_dict(TestClass_0,
                                                    kvs=test_ignored_parameter_0.copy())

    assert len(parameters_to_init_with_0) == 3
    assert "a" in parameters_to_init_with_0
    assert "b" in parameters_to_init_with_0

# Generated at 2022-06-25 16:14:23.513753
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined_parameters_action = _RaiseUndefinedParameters()
    # test class has fields "a" and "b"
    defined_parameters = {"a": 1, "b": 2}
    kvs = {"a": 1, "b": 2, "c": 3}
    result = undefined_parameters_action.handle_from_dict(
        defined_parameters, kvs)
    assert result == {"a": 1, "b": 2}

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    with pytest.raises(UndefinedParameterError):
        result = undefined_parameters_action.handle_from_dict(
            defined_parameters, kvs)



# Generated at 2022-06-25 16:14:35.521329
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    from datetime import datetime
    from typing import List
    from marshmallow.fields import Nested

    @dataclasses.dataclass()
    class TestClass0:
        x: int
        y: str
        z: List[int]

    @dataclasses.dataclass
    class TestClass1:
        x: int
        y: str

    # Test cases:
    # * dataclass with a simple field
    # * dataclass with a list field
    # * dataclass with a nested field
    # * dataclass without an undefined field
    # * dataclass with an undefined field
    test_cases = [TestClass0(x=1, y="hello", z=[1, 2, 3]), TestClass1(x=1, y="hello")]

# Generated at 2022-06-25 16:14:45.768361
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()
    known_given_parameters = {"foo": "bar", "baz": 1}
    unknown_given_parameters = {"a": 1, "b": 2, "c": 3}

    class TestDataClass:
        test_field: str

    input_kvs = {**known_given_parameters, **unknown_given_parameters}

    expected = known_given_parameters
    actual = ignore_undefined_parameters.handle_from_dict(TestDataClass,
                                                          input_kvs)
    assert actual == expected



# Generated at 2022-06-25 16:14:53.532822
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined_parameters_raise = _RaiseUndefinedParameters()
    defined_fields = {"a_field": "is_defined"}
    undefined_fields = {"not_defined": "is not defined"}
    unknown_fields = dict(defined_fields)
    unknown_fields.update(undefined_fields)

    result: KnownParameters = undefined_parameters_raise.handle_from_dict(
        cls=None, kvs=defined_fields)
    assert result == defined_fields

    with pytest.raises(UndefinedParameterError):
        undefined_parameters_raise.handle_from_dict(cls=None, kvs=unknown_fields)



# Generated at 2022-06-25 16:15:00.722648
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    test = _IgnoreUndefinedParameters()
    assert test._separate_defined_undefined_kvs(
        TestDataClass, {"a": 1}) == ({"a": 1}, {})
    assert test._separate_defined_undefined_kvs(TestDataClass,
                                                {"a": 1, "b": 2}) == (
                                               {"a": 1}, {"b": 2})



# Generated at 2022-06-25 16:15:12.332341
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # This class has undefined parameters which will be ignored
    @dataclasses.dataclass
    class DummyClass:
        a: int
        b: str

        def __init__(self, a: int, b: str, c: int) -> None:
            pass

    dummy_class_instance = DummyClass(1, "abc", 3)
    init_signature = inspect.signature(DummyClass.__init__)

    # Any name is fine
    dummy_class_instance_1 = dummy_class_instance.__init__(a=1, b=2, c=3)

    # Check whether the right parameters were passed on
    dummy_class_instance_2 = dummy_class_instance.__init__(a=1, b=2, c=3,
                                                           d=4, e=5)

# Generated at 2022-06-25 16:15:20.756627
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class NonCatchable:
        def __init__(self, x: int, y: str):
            pass

    class Catchable:
        foo: CatchAll

        def __init__(self, x: int, y: str, **kwargs):
            pass

    non_catchable_instance = NonCatchable(1, "abc")
    catchable_instance = Catchable(1, "abc")

    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_1 = _IgnoreUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()


# Generated at 2022-06-25 16:15:31.797058
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest

    # Receive default
    @dataclasses.dataclass(frozen=True)
    class DummyCatchAll(object):
        a: int
        ca: Optional[CatchAllVar] = dataclasses.field(default=dict())

    # Receive default
    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(
        cls=DummyCatchAll, kvs={"a": 1, "ca": dict()}
    )
    assert known == {"a": 1, "ca": {}}
    assert unknown == {}

    # Receive non-default value
    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(
        cls=DummyCatchAll, kvs={"a": 1, "ca": {"b": 2}}
    )


# Generated at 2022-06-25 16:15:33.311183
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError):
        raise UndefinedParameterError("Test if exception is raised")

# Generated at 2022-06-25 16:16:07.722792
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()
    raise_undefined_parameters = _RaiseUndefinedParameters()
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()



# Generated at 2022-06-25 16:16:16.664776
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass(unsafe_hash=True, frozen=True)
    class _SimpleClass:
        field1: int
        field2: str

    defined_parameters = {'field1': 5, 'field2': 'abc'}
    undefined_parameters = {'field3': 'def'}
    kvs = {**defined_parameters, **undefined_parameters}

    # check that all input parameters are properly handled:
    _RaiseUndefinedParameters.handle_from_dict(_SimpleClass, kvs)

    # check that undefined parameters raise an exception
    error_message = "Received undefined initialization arguments"

# Generated at 2022-06-25 16:16:27.221612
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _TestClass:
        # noinspection PyUnusedLocal
        def __init__(self, field_a: int, field_b: float, undefined_0: CatchAll):
            pass  # pragma: no cover

    catch_all_field = _CatchAllUndefinedParameters._get_catch_all_field(
        _TestClass)
    catch_all_field_name = catch_all_field.name

    # input parameters are empty
    assert _CatchAllUndefinedParameters \
               .handle_from_dict(_TestClass, {}) \
               == {catch_all_field_name: {}}

    # input parameters are empty except undefined_0 parameter is set to
    # {'a': 'b'}. This case is not possible because the undefined_0 field is
    # handled at the end of the method, so it

# Generated at 2022-06-25 16:16:33.253053
# Unit test for method create_init of class _UndefinedParameterAction

# Generated at 2022-06-25 16:16:45.100531
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    cls = dataclasses.make_dataclass("TestClass",
                                     [("test_field", str)])

    object_0 = cls("test string")
    object_1 = cls("test string")
    object_2 = cls("test string")

    dict_0 = {"test_field": "test string",
              "_CatchAllUndefinedParameters": {}}
    dict_1 = {"test_field": "test string",
              "_CatchAllUndefinedParameters": {}}
    dict_2 = {"test_field": "test string",
              "_CatchAllUndefinedParameters": {"another_field": "other string"}}

    assert _CatchAllUndefinedParameters.handle_to_dict(object_0, dict_0) == {"test_field": "test string"}
    assert _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:16:48.832723
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TestClass0:
        pass

    obj = TestClass0()
    kvs = {"key": "value"}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == kvs



# Generated at 2022-06-25 16:16:57.209275
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Class0:
        def __init__(self, a: int, d: int, *args, **kwargs):
            self.a = a
            self.d = d

    for _ in range(100):
        _catch_all_init = _CatchAllUndefinedParameters.create_init(Class0)
        _catch_all_init(Class0, 1, 2, 3, 4, 5, f=6, g=7)



# Generated at 2022-06-25 16:16:59.138691
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    _IgnoreUndefinedParameters.handle_from_dict(TestC,
                                                {"a": 3, "e": 42, "f": 23})



# Generated at 2022-06-25 16:17:01.757911
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # check for normal operation
    def_0 = _UndefinedParameterAction()
    # check for correct return type
    def_0.handle_to_dict


# Generated at 2022-06-25 16:17:13.040900
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    Note: The following test code is *NOT* executed when the tests are run,
    because in the tests,
    _CatchAllUndefinedParameters._get_catch_all_field() is mocked to return
    catch_all_field.
    """


    @dataclasses.dataclass
    class TestClass:
        a: str = "a_default"
        b: int = dataclasses.field(default=42)
        c: Optional[CatchAllVar] = None

    catch_all_field = \
        _CatchAllUndefinedParameters._get_catch_all_field(obj=TestClass)
    parameters_without_catch_all_field = {
        "a": "a_value"
    }

# Generated at 2022-06-25 16:18:16.328388
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert {'a': 1,
            'b': 2} == _UndefinedParameterAction.handle_from_dict(None,
                                                                  {'a': 1,
                                                                   'b': 2})



# Generated at 2022-06-25 16:18:24.300964
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # Test 1
    class TestClass1():
        def __init__(self, color: str, size: int):
            pass

    undefined_parameter_action = _UndefinedParameterAction()
    kvs = {'color': 'red', 'size': 3}
    with pytest.raises(TypeError):
        undefined_parameter_action.handle_from_dict(TestClass1, kvs)

    # Test 2
    class TestClass2():
        def __init__(self, color: str, size: int):
            pass

    undefined_parameter_action = _RaiseUndefinedParameters()
    kvs = {'color': 'red', 'size': 3}
    expected = {'color': 'red', 'size': 3}

# Generated at 2022-06-25 16:18:27.247010
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    expected_result = {"parameter_0": "value_0"}
    actual_result = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"parameter_0": "value_0"})
    assert expected_result == actual_result



# Generated at 2022-06-25 16:18:28.351598
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()



# Generated at 2022-06-25 16:18:33.205788
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    a = UndefinedParameterError(
        'Received undefined initialization arguments {\'a\': 1}')
    assert (a.__str__()
            == 'Received undefined initialization arguments {\'a\': 1}')

# Generated at 2022-06-25 16:18:41.740864
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    foo_dict = {'a': 'a_value_0', 'c': 'c_value_0'}
    foo_exp_dict = {'a': 'a_value_exp', 'b': 'b_value', 'c': 'c_value_exp'}

    foo_dict_ret = _UndefinedParameterAction.handle_to_dict(foo_dict,
                                                            foo_exp_dict)
    assert foo_dict_ret == {'a': 'a_value_0', 'b': 'b_value',
                            'c': 'c_value_0'}

    # test the default behavior
    foo_dict_ret = _UndefinedParameterAction.handle_to_dict(None,
                                                            foo_exp_dict)
    assert foo_dict_ret == foo_exp_dict


#

# Generated at 2022-06-25 16:18:54.208658
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Create Mock Object to be passed to handle_to_dict
    obj = dataclasses.make_dataclass('obj', [
        ('field', str, dataclasses.field(default=None)),
        ('catch_all', Optional[CatchAllVar], dataclasses.field(default=None))
    ])
    # Create Mock Object to be passed to handle_to_dict
    obj_2 = dataclasses.make_dataclass('obj_2', [
        ('field', str, dataclasses.field(default=None)),
        ('field_2', str, dataclasses.field(default=None))
    ])

    # Create the test case data
    test_kvs = {'field': 'string', 'field_3': 'string_3'}

# Generated at 2022-06-25 16:19:06.515926
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Default factory test
    kvs = {}
    cls = dataclasses.make_dataclass("bla",
                                     [("catch_all", Optional[CatchAllVar],
                                       dataclasses.field(default_factory=list))])
    # Default factory
    result = _CatchAllUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
    assert result == {}
    # Validate that the default factory has been called
    assert isinstance(cls.catch_all, list)

    # Test that a dict is returned
    kvs = {"catch_all": {}}
    cls = dataclasses.make_dataclass("bla",
                                     [("catch_all", Optional[CatchAllVar],
                                       dataclasses.field(default=dict))])

# Generated at 2022-06-25 16:19:15.748608
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class MyClass:
        a: int
        b: int = 0
        c: Optional[int] = None

        def __init__(self, a: int, b: int = 0, c: Optional[int] = None):
            self.a = a
            self.b = b
            self.c = c

    MyClass2 = _UndefinedParameterAction.create_init(MyClass)
    test1 = MyClass(1, 2, 3)
    test2 = MyClass2(1, 2, 3)
    test3 = MyClass2(1, 2, 3, d=4, e=5)

# Generated at 2022-06-25 16:19:30.115588
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Create a dummy class that we can test create_init for
    class Dummy:
        def __init__(self, a, b, c=None, *args, **kwargs):
            pass


# Generated at 2022-06-25 16:21:06.227090
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    input_0 = Undefined.RAISE
    call_0 = _UndefinedParameterAction.create_init(input_0)

    assert call_0 == _RaiseUndefinedParameters.create_init(input_0)

    input_1 = Undefined.EXCLUDE
    call_1 = _UndefinedParameterAction.create_init(input_1)

    assert call_1 == _IgnoreUndefinedParameters.create_init(input_1)

    input_2 = Undefined.INCLUDE
    call_2 = _UndefinedParameterAction.create_init(input_2)

    assert call_2 == _CatchAllUndefinedParameters.create_init(input_2)

# Generated at 2022-06-25 16:21:11.703915
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Meta(_UndefinedParameterAction):
        pass

    def test_case_0():
        meta_0 = Meta()
        undefined_0 = Undefined.INCLUDE
        dump_0 = meta_0.handle_dump(undefined_0)
        assert class_var_0 == undefined_0
        assert dump_0 == {}


# Generated at 2022-06-25 16:21:12.898128
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    test_case_0()

# Generated at 2022-06-25 16:21:23.100888
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    undefined_0 = Undefined.INCLUDE
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    parameters_0 = {"param_0": "param_value_0", "param_1": "param_value_1",
                    "param_2": "param_value_2", "param_3": "param_value_3"}
    caught_parameters_0 = catch_all_undefined_parameters_0.handle_from_dict(
        undefined_0, parameters_0)

    assert caught_parameters_0 == {}


# Generated at 2022-06-25 16:21:28.198988
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()

    @dataclass
    class TestDataClass:
        test_number: int
        catch_all: CatchAll = dataclasses.field(default=dict)

    test_data_class = TestDataClass(test_number=0, catch_all={"a": "b"})
    kvs = {"test_number": 0, "catch_all": {"a": "b"}}
    output = catch_all_undefined_parameters.handle_to_dict(test_data_class, kvs)
    assert output == {"test_number": 0, "a": "b"}



# Generated at 2022-06-25 16:21:37.479109
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    undefined_0 = Undefined.RAISE

    # Test 0:
    class_0 = dataclasses.make_dataclass('class_0', [('a', int), ('b', int)])

    # Test 1:
    class_1 = dataclasses.make_dataclass('class_1', [('a', int)])

    # Test 2:
    class_2 = dataclasses.make_dataclass('class_2', [('a', int), ('b', int), ('c', int)])

    # Test 3:
    class_3 = dataclasses.make_dataclass('class_3', [('a', int), ('b', int), (
        'c', int), ('d', int), ('e', int)])

    # Test 0:
    init_0 = _UndefinedParameterAction.create

# Generated at 2022-06-25 16:21:41.393023
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_0 = Undefined.RAISE
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = catch_all_undefined_parameters_0.handle_dump(undefined_0)


# Generated at 2022-06-25 16:21:48.683658
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    # Undefined param should not be written if default value is defined
    with pytest.raises(UndefinedParameterError):
        undefined_0 = Undefined.RAISE
        catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
        dict_0 = catch_all_undefined_parameters_0.handle_from_dict(undefined_0, dict_0)

    # Catch-all field is given: default should be replaced with undefined
    # parameters
    @dataclasses.dataclass
    class Class0:
        catch_all: CatchAll

    catch_all_field = catch_all_undefined_parameters_0._get_catch_all_field(Class0)
    assert catch_all_field.name == "catch_all"

    # Parameter with same name as catch-all field should

# Generated at 2022-06-25 16:21:57.699796
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_0 = Undefined.RAISE
    undefined_1 = Undefined.INCLUDE
    undefined_2 = Undefined.EXCLUDE
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()

# Generated at 2022-06-25 16:22:03.963943
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_0 = Undefined.RAISE
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = catch_all_undefined_parameters_0.handle_dump(undefined_0)

