

# Generated at 2022-06-25 16:12:54.490021
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Test for _RaiseUndefinedParameters
    kvs = {"a": 1, "b": 2}
    _RaiseUndefinedParameters.handle_to_dict(None, kvs)
    assert kvs == {"a": 1, "b": 2}

    # Test for _IgnoreUndefinedParameters
    kvs = {"a": 1, "b": 2}
    _IgnoreUndefinedParameters.handle_to_dict(None, kvs)
    assert kvs == {"a": 1, "b": 2}



# Generated at 2022-06-25 16:13:04.854189
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect
    import types

    class Klass1():
        def __init__(self, foo: int, bar: str):
            pass

    klass1 = Klass1(1, "bar")
    original_init, created_init = \
        _CatchAllUndefinedParameters.create_init(klass1), klass1.__init__

    signature_original_init = inspect.signature(original_init)
    signature_created_init = inspect.signature(created_init)
    assert signature_original_init == signature_created_init

    dict_original_init = dict(signature_original_init.parameters)
    dict_created_init = dict(signature_created_init.parameters)
    assert dict_original_init == dict_created_init

# Generated at 2022-06-25 16:13:14.001363
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass0:
        def __init__(self, a, b, c):
            pass

    class TestClass1:
        a: str
        b: str
        def __init__(self, a, b, c):
            pass

    # If we receive no unknown parameters, but the catch-all was specified,
    # we should get the default value
    catch_all_param_0 = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass0,
        {
            "a": "a",
            "b": "b",
            "c": {}
        })
    assert catch_all_param_0 == {
        "a": "a",
        "b": "b",
        "c": {}
    }

    # If we do receive unknown parameters, but the catch-all was specified,

# Generated at 2022-06-25 16:13:16.356438
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err1 = UndefinedParameterError("test")
    err2 = UndefinedParameterError("test", 1)
    err3 = UndefinedParameterError("test", 1, 2)

# Generated at 2022-06-25 16:13:25.759865
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ClassWithCatchAll:
        catch_all: CatchAll = None
        param1: str = "param1"

    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    result = catch_all_undefined_parameters.handle_from_dict(ClassWithCatchAll, {"param1": "param1"})
    assert result == {"param1": "param1"}



# Generated at 2022-06-25 16:13:38.008258
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # Counting on `dataclasses_json.utils.CatchAll` to
    # be the same as `dataclasses_json.CatchAll` we
    # use a different import here:
    from dataclasses_json import CatchAll

    unknown = {"a": 1, "b": 2}

    class _MockClass:
        def __init__(self, x: int, y: int, z: int, **kwargs: CatchAll):
            self.x = x
            self.y = y
            self.z = z
            self.kwargs = kwargs

    args = {"a": 1, "b": 2, "x": 3, "y": 4, "z": 5}


# Generated at 2022-06-25 16:13:40.530828
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Check that empty arrays can be handled
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}



# Generated at 2022-06-25 16:13:42.239736
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(cls=None) == {}



# Generated at 2022-06-25 16:13:44.277610
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}



# Generated at 2022-06-25 16:13:51.687805
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass0:
        a: int

    @dataclasses.dataclass
    class TestClass1:
        a: int = dataclasses.field(default=1)

    @dataclasses.dataclass
    class TestClass2:
        a: int
        b: int = dataclasses.field(default=1)

    @dataclasses.dataclass
    class TestClass3:
        a: int = dataclasses.field(default=1)
        b: int = dataclasses.field(default=2)

    @dataclasses.dataclass
    class TestClass4:
        a: dataclasses.field(default_factory=list)

    @dataclasses.dataclass
    class TestClass5:
        a: int
       

# Generated at 2022-06-25 16:14:09.822674
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Calls the method
    _RaiseUndefinedParameters.handle_from_dict(
        '\x0f#\x8d\xbf\xd4\x07\xfb\x02\xaa\xe6\xec\xdc\xee\xc9\x89\xf2\x03\t',
        dict())

    # Calls the method
    _RaiseUndefinedParameters.handle_from_dict(str(), dict())



# Generated at 2022-06-25 16:14:14.935117
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'\xb0\x13'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    assert type(dict_1) == dict


# Generated at 2022-06-25 16:14:25.819990
# Unit test for method create_init of class _IgnoreUndefinedParameters

# Generated at 2022-06-25 16:14:27.696362
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    pass



# Generated at 2022-06-25 16:14:36.598328
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    print('Testing _UndefinedParameterAction.handle_from_dict()')
    bytes_0 = b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)

# Generated at 2022-06-25 16:14:46.484099
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    bytes_0 = b'\x8e\xb2\n\xcb\xfc\xcb\x12\x1d\xb5\x80\xc5\x8a'
    # bytes_0: bytearray(b'\x8e\xb2\n\xcb\xfc\xcb\x12\x1d\xb5\x80\xc5\x8a')
    class_0 = _CatchAllUndefinedParameters()
    class_1 = class_0.create_init(bytes_0)


# Generated at 2022-06-25 16:14:49.792518
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def function_0(arg_0: int) -> int:
        return arg_0
    result_0 = _UndefinedParameterAction.create_init(function_0)
    assert result_0 == function_0


# Generated at 2022-06-25 16:14:52.115810
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefinedParam = UndefinedParameterError()
    assert undefinedParam.__class__.__name__ == 'UndefinedParameterError'


# Generated at 2022-06-25 16:15:00.395607
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    bytes_0 = b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)


# Generated at 2022-06-25 16:15:07.621185
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # This function tests the function create_init of class
    # _IgnoreUndefinedParameters
    class SomeDataClass:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    init_0 = SomeDataClass.__init__
    init_1 = ignore_undefined_parameters_0.create_init(SomeDataClass)
    assert (init_0 != init_1)


# Generated at 2022-06-25 16:15:33.997698
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = '5_5'
    dict_0 = {str_0: str_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(str_0, dict_0)



# Generated at 2022-06-25 16:15:39.228259
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Foo:
        bar: str
        baz: CatchAll
    foo = Foo("bar", {"baz": "baz"})
    _CatchAllUndefinedParameters.handle_to_dict(foo, {"bar": "bar", "baz": {"baz": "baz"}})


# Generated at 2022-06-25 16:15:50.570237
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    class UninitializedClass():
        def __init__(self, *args, **kwargs):
            pass

    class CatchAllInitializedClass():

        def __init__(self, *args, CatchAll=None, **kwargs):
            pass

        def __repr__(self):
            return "CatchAllInitializedClass()"

    args = _CatchAllUndefinedParameters.create_init(
        CatchAllInitializedClass)
    args(CatchAllInitializedClass())

    args = _CatchAllUndefinedParameters.create_init(
        UninitializedClass)
    args(UninitializedClass())


# Generated at 2022-06-25 16:15:59.793763
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    bytes_0 = b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    assert dict_1 == dict_0


# Generated at 2022-06-25 16:16:01.799143
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        test_case_0()
    except UndefinedParameterError as e:
        assert type(e) == UndefinedParameterError


# Generated at 2022-06-25 16:16:13.816940
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Class0(object):
        def __init__(self, arg0: bytes, arg1: bytes = b'\x00', arg2: bytes = b'\x00'):
            self.arg0 = arg0
            self.arg1 = arg1
            self.arg2 = arg2

    class0 = Class0(bytes())
    bytes_0 = b'\x00'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0, bytes_0: bytes_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_param

# Generated at 2022-06-25 16:16:20.324156
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    expected_dict_1 = {}
    bytes_0 = b'\x10\x9d\xe7\x98\x92\x1a3\x1e\xc3\x10\xa7\xed\x14\x97j'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_1 = raise_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    assert expected_dict_1 == dict_1


# Generated at 2022-06-25 16:16:30.090825
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    bytes_0 = b'\xd7h\xbb\xad\x16\x85\xdc\xfb\xe1\xca\xe0\xcc\xc6\x8b'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}

# Generated at 2022-06-25 16:16:42.007122
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    if True:
        bytes_0 = b'\x1f\x8d\x1b\xdf\xbf\xa8\x8al\xafDJ\x0b\xa4\x8e\xea\x9f'
        bytes_1 = b'\x1a'

# Generated at 2022-06-25 16:16:46.361650
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined_parameters = Dict[bytes, bytes]
    dict_0 = {"a": 0j, "a": 0j, "a": 0j}
    raise_undefined_parameters_0 = Undefined.RAISE
    dict_1 = raise_undefined_parameters_0.value.handle_from_dict(
        undefined_parameters, dict_0)


# Generated at 2022-06-25 16:17:32.887534
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyUnresolvedReferences
    assert(_UndefinedParameterAction.create_init(list)
           == list.__init__)


# Generated at 2022-06-25 16:17:42.926128
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    bytes_0 = b'\x0b\x91'
    bytes_1 = b'\x99\xfe\xfa\x9e\xbe\xd8\xab\x1e\xb1\xbb\xcaJL\xae\xb0\x1d\xa7\x8d\x0b\x0e\x01\xa4'
    bytes_1 = b'\x99\xfe\xfa\x9e\xbe\xd8\xab\x1e\xb1\xbb\xcaJL\xae\xb0\x1d\xa7\x8d\x0b\x0e\x01\xa4'

# Generated at 2022-06-25 16:17:53.249813
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'\xf7\x1c\xf4K\xd4u\x93\x8ap\xcb\xd6\x9a\x90m\xdb*'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    assert () == (dict_0, dict_1)


# Generated at 2022-06-25 16:17:57.453252
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    empty_dict: Dict[Any, Any] = {}
    obj_0 = test__UndefinedParameterAction()
    obj_1 = _UndefinedParameterAction.handle_dump(obj_0)
    assert obj_1 == empty_dict


# Generated at 2022-06-25 16:18:03.207365
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    dict_0 = {}
    dict_1 = _CatchAllUndefinedParameters.handle_dump(dict_0)


# Generated at 2022-06-25 16:18:04.733373
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    dummyVar = UndefinedParameterError


# Generated at 2022-06-25 16:18:16.747901
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class C:
        def __init__(self, a: str, b: int, c: str = "") -> None:
            self.a = a
            self.b = b
            self.c = c

    c = C(
        "a",
        2,
        c="c"
    )
    assert c.a == "a"
    assert c.b == 2
    assert c.c == "c"

    class C:
        def __init__(self, a: str, b: int, c: str = "") -> None:
            self.a = a
            self.b = b
            self.c = c

    catch_all = Optional[CatchAllVar]

    class D(C):
        UNDEFINED_PARAMETERS: catch_all = None


# Generated at 2022-06-25 16:18:24.531254
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    bytes_0 = b'\xfc\x13\xda\x0f\xeb\x11\x0e\xce\x12\xe8\xbe\x9e\x1b\xdd&\x85\n\x16\xa5\xfb\x8c\x10(\xcd\x98\x87\x8a\x97\x0c\x16\x01\xdc\xea\x0f\xaa\x83'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_1 = raise_undefined_parameters_0.handle_dump(bytes_0)

# Generated at 2022-06-25 16:18:25.410974
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    pass


# Generated at 2022-06-25 16:18:28.561183
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    bytes_0 = b'L\xec\x8b\x04\xb6\xfc6\x9b\x8e\x0f\xe2'
    dict_0 = {bytes_0: bytes_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(bytes_0, dict_0)

# Generated at 2022-06-25 16:20:23.883854
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """Test if create_init() of UndefinedParameterAction generates a function
    that accepts more keyword arguments than the original init function."""
    # Create mock object to test
    class MockObj:
        def __init__(self, a: int, b: str):
            pass

    mock_obj = MockObj(a=1, b='hello')

    # Get the number of keyword arguments that the original init function
    # accepts
    original_init_kwargs = set(inspect.signature(mock_obj.__init__).parameters.keys())
    # First element in original_init_kwargs is 'self'
    original_init_kwargs.remove('self')
    original_init_arg_count = len(original_init_kwargs)

    # Test and assert whether the original init function and the generated
    # function accept the same

# Generated at 2022-06-25 16:20:29.779309
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)


# Generated at 2022-06-25 16:20:35.103474
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    bytes_0 = b'\x12\xfb\xbe\xf3\x19\xb8\x15\xec\xeb\x9d\x09'
    raise_undefined_parameters_0 = _UndefinedParameterAction()
    class_0 = _RaiseUndefinedParameters()
    dict_0 = dict()
    dict_0[bytes_0] = class_0
    dict_0[bytes_0] = raise_undefined_parameters_0
    dict_0[bytes_0] = bytes_0
    dict_0[bytes_0] = class_0
    dict_0[bytes_0] = dict_0
    dict_0[bytes_0] = dict_0
    dict_0[bytes_0] = raise_undefined_parameters_0

# Generated at 2022-06-25 16:20:37.010401
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    a = _UndefinedParameterAction()
    b = a.create_init(str)
    assert str(b.__class__) == "<class 'method'>"
    assert b.__name__ == "__init__"


# Generated at 2022-06-25 16:20:46.000390
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    bytes_0 = b'<\x05-s\xa6\x0f\x08\xca\xf7\x1c\x93\xb2'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)
    print("TEST", bytes_0)
    print("TEST", dict_0)
    print("TEST", dict_1)
    assert dict_1 is None


# Generated at 2022-06-25 16:20:49.208789
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    instance_0 = _UndefinedParameterAction()
    class_0 = None # type: Any
    str_0 = instance_0.create_init(class_0)


# Generated at 2022-06-25 16:20:58.124126
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    bytes_0 = b'\xdd'

# Generated at 2022-06-25 16:20:59.978230
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    func_var = _UndefinedParameterAction.create_init(bytes_0)


# Generated at 2022-06-25 16:21:07.191223
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    bytes_0 = b'=0\x93\xf8g\xe9\x9c\xa7\x1d\x8d\xce\xc4\x13\x8f\xdcj'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_1 = ignore_undefined_parameters_0.handle_from_dict(bytes_0, dict_0)


# Generated at 2022-06-25 16:21:11.474656
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert test_case_0() == {b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce': b'Qp\xb2\xe7)<[\xa1\xecUo6x\xce'}