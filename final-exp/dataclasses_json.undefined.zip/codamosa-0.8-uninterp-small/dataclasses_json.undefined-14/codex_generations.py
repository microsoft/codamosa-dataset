

# Generated at 2022-06-25 16:13:01.956129
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    test_cls = dataclasses.make_dataclass("test_cls", [("a", int), ("b", str)])
    x_0 = _IgnoreUndefinedParameters.handle_from_dict(test_cls, {"a": 3})
    assert x_0 == {"a": 3}

    x_1 = _IgnoreUndefinedParameters.handle_from_dict(test_cls, {"a": 3, "b":
                                                                  "test"})
    assert x_1 == {"a": 3, "b": "test"}

    x_2 = _IgnoreUndefinedParameters.handle_from_dict(test_cls, {"b": "test"})
    assert x_2 == {"b": "test"}


# Generated at 2022-06-25 16:13:07.606459
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a: int, b: int = 0, c: int = 0):
            pass

    A.__init__ = _IgnoreUndefinedParameters.create_init(A)
    A(1, 2, d=3)
    A(1, 2, 3)
    A(1, b=2, d=3)
    A(1, d=3)
    A(b=2, c=3, d=4)

# Generated at 2022-06-25 16:13:14.346496
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: str, b: int, ca: Optional[CatchAll] = None,
                     *args, **kwargs):
            ca = ca
            d = {1: 2, **ca}
            print(d)


# Generated at 2022-06-25 16:13:21.356776
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        pass

    class TestClassWithCatchAll(TestClass):
        undefined: Optional[CatchAllVar] = None

    class TestClassWithCatchAllAndDefault(TestClass):
        undefined: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    kvs_1 = {"undefined": {"a": 1, "b": 2}}
    result_1 = _CatchAllUndefinedParameters.handle_from_dict(
        TestClassWithCatchAll, kvs_1)
    assert (result_1 == kvs_1)

    kvs_2 = {"undefined": {"a": 1, "b": 2}, "_UNDEFINED1": 3}

# Generated at 2022-06-25 16:13:28.922689
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class CatchAllExample:
        def __init__(self, a: int, b: int, **kwargs):
            self._a = a
            self._b = b
            self.__dict__.update(kwargs)

        @property
        def a(self):
            return self._a

        @property
        def b(self):
            return self._b

        def to_dict(self):
            return {
                "a": self.a,
                "b": self.b
            }

    output = _CatchAllUndefinedParameters.handle_dump(
        CatchAllExample(
            a=10,
            b=20,
            c=30
        )
    )
    assert output == {"c": 30}



# Generated at 2022-06-25 16:13:40.974512
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestRaiseUndefinedParameters:
        undefined_parameter_action = _RaiseUndefinedParameters
        def __init__(self, defined_parameter: int):
            pass

    test_case_0 = TestRaiseUndefinedParameters(42)
    test_case_0_dict = {'defined_parameter': 42, 'undefined_parameter': 1337}
    test_case_1 = TestRaiseUndefinedParameters(42)
    test_case_1_dict = {'defined_parameter': 42}
    try:
        _ = TestRaiseUndefinedParameters(**test_case_0_dict)
    except UndefinedParameterError:
        pass
    else:
        assert False

    _ = TestRaiseUndefinedParameters(**test_case_1_dict)

# Generated at 2022-06-25 16:13:50.099234
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: str
        b: str

    a: A = A("a", "b")
    init = _CatchAllUndefinedParameters.create_init(a)
    init(a, "a", "b")
    from dataclasses_json.config import LetterCase
    from dataclasses_json.schema import DefaultSchema
    a = DefaultSchema.from_dict(
        data={
            "a": "a",
            "b": "b",
            "c": "c",
        },
        obj_type=A,
        letter_case=LetterCase.CAMEL,
        undefined=Undefined.INCLUDE,
    )

# Generated at 2022-06-25 16:13:57.261660
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Example:
        def __init__(self,
                     a: int,
                     b: int,
                     c: Optional[CatchAllVar] = None):
            pass

    new_init = _CatchAllUndefinedParameters.create_init(obj=Example)
    example = Example(a=1, b=2, d=3)
    example.c == {"d": 3}

# Generated at 2022-06-25 16:14:02.473049
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    mock_obj = type('mock_obj', (object,), {'catch_all': {'a': 1, 'b': 2}})
    mock_obj.__module__ = "tests"
    mock_obj.__qualname__ = "mock_obj"

    result = _CatchAllUndefinedParameters.handle_to_dict(mock_obj, {'c': 3})

    assert result == {'c': 3, 'a': 1, 'b': 2}



# Generated at 2022-06-25 16:14:08.222389
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    undefined_parameter_action = _IgnoreUndefinedParameters()
    kvs = {"A": 1, "B": 2, "C": 3}
    defined = {"A": 1, "B": 2}
    result = undefined_parameter_action.handle_from_dict(defined, kvs)
    assert result == defined



# Generated at 2022-06-25 16:14:25.042336
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = 'rK'
    bool_0 = bool(0)
    _catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    result = _catch_all_undefined_parameters_0.handle_to_dict(bool_0, {str_0: bool(
        0)})
    print(result)


# Generated at 2022-06-25 16:14:36.044982
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()

    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_1 = _IgnoreUndefinedParameters()

    ignore_undefined_parameters_0.handle_dump(bool_0)
    ignore_undefined_parameters_0.handle_dump(bool_1, bool_1)
    ignore_undefined_parameters_0.handle_dump(bool_1, bool_2, bool_3)

# Generated at 2022-06-25 16:14:48.443076
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    message_0 = 'i4:6jdq'
    message_1 = ';^H5A5&'
    undef_param_err_1 = UndefinedParameterError(message_1)
    assert undef_param_err_1.message == message_1
    message_2 = ':8yT`T}>)'
    undef_param_err_2 = UndefinedParameterError(message_2)
    assert undef_param_err_2.message == message_2
    message = 'G%c@!<H'
    message_3 = 'YT%T'
    undef_param_err_3 = UndefinedParameterError(message_3)
    assert undef_param_err_3.message == message_3
    message_4 = 'i4:6jdq'
    undef_

# Generated at 2022-06-25 16:14:56.349410
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_0 = '/dP{:b^T&yR6(sUO;sU+'
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    callable_0 = catch_all_undefined_parameters_0.create_init(bool_0)
    # Unit test for method create_init of class _IgnoreUndefinedParameters
    def test__IgnoreUndefinedParameters_create_init():
        str_0 = 'jFISAN9GQ}Z#c)4AJ4(_'
        list_0 = [str_0, str_0, str_0, str_0]
        bool_0 = None
       

# Generated at 2022-06-25 16:15:04.608582
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Foo(object):
        def __init__(self, bar, baz):
            self.bar = bar
            self.baz = baz

    foo_0 = Foo(str_0, bool_0)

    # Call _UndefinedParameterAction.handle_to_dict(obj, kvs)
    kvs = {'bar': 'baz', 'baz': False}
    result = _UndefinedParameterAction.handle_to_dict(foo_0, kvs)
    assert result == kvs


# Generated at 2022-06-25 16:15:12.987987
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = '7Xu@fw!Hp[V&%4GnA'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0]
    list_1 = [str_0]
    dict_0 = {str_0: list_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(list_0, dict_0)



# Generated at 2022-06-25 16:15:21.093423
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    str_0 = '1>!P3*3O{U6`+E='
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)
    assert callable(callable_0) == True
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_0)
    callable_1 = raise_undefined_parameters_0.create_init(bool_0)
    assert callable(callable_1) == True

# Generated at 2022-06-25 16:15:32.218749
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():  # -> None
    str_0 = '3Z<'
    list_0 = [str_0, str_0, str_0, str_0]
    list_1 = ['Z_N', 'X)N', str_0, list_0, list_0, str_0]
    list_2 = ['tHv', '9', 'I@)Y`', list_1, list_0, list_1, str_0, list_1,
              list_1, '<?_F8W']
    int_0 = -742
    str_1 = 'ZU6-i2'
    str_2 = '_qyU$'
    str_3 = 'C.=,LE'
    str_4 = '0'

# Generated at 2022-06-25 16:15:36.562651
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Arrange
    cls_0 : Any = _RaiseUndefinedParameters
    kvs = {}

    # Act
    cls_0.handle_from_dict(cls_0, kvs)


# Generated at 2022-06-25 16:15:43.786550
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    str_0 = '7K%?Mw'
    list_0 = ['K', ';`o', '97X7Z', 'I', str_0, 'pOx,C']
    bool_0 = True
    not_0 = True
    undefined_0 = Undefined.INCLUDE
    callable_0 = undefined_0.value.create_init(not_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0.update(("Y_I&)Z=9G", "!@r]FsEi"))
    dict_0.update(("N8?Y;", None))
    dict_0.update(("8}t", "`*cxOy"))
    dict_0.update((None, "m.iZ(1"))
    dict_0

# Generated at 2022-06-25 16:16:29.586886
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()

# Generated at 2022-06-25 16:16:41.520416
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'w7jWU'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = float('inf')
    dict_0 = {str_0: float_0}
    bool_0 = bool(True)
    str_1 = 'xWs!G'
    dict_1 = {str_1: dict_0}
    dict_0.update(dict_1)

    with pytest.raises(UndefinedParameterError):
        ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
        ignore_undefined_parameters_0.handle_from_dict(bool_0, dict_0)
    with pytest.raises(UndefinedParameterError):
        raise_undefined_parameters_0 = _RaiseUndefined

# Generated at 2022-06-25 16:16:49.599070
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    args_0 = {'default': None, 'metadata': None, 'repr': True, 'hash': None, 'init': True, 'compare': True, 'type': CatchAll, 'default_factory': None, 'init': True, 'repr': True, 'order': None, 'metadata': None}
    args_1 = {'default': None, 'metadata': None, 'repr': True, 'hash': None, 'init': True, 'compare': True, 'type': CatchAll, 'default_factory': None, 'init': True, 'repr': True, 'order': None, 'metadata': None}

# Generated at 2022-06-25 16:16:57.391612
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    str_0 = '1>!P3*3O{U6`+E='
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)
    ignore_undefined_parameters_0.handle_from_dict(list_0, list_0)


# Generated at 2022-06-25 16:17:03.078840
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = '|'
    bool_0 = False
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    str_1 = '1r)2Iy8|1_w^'
    field_0 = Field(type=None, default=bool_0, default_factory=None,
                    init=bool_0, repr=bool_0, hash=None, compare=bool_0,
                    metadata=None, name=str_1)
    str_2 = '|'
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    unknown_0 = {str_2: str_2}
    str_3 = '|'
    bool_1 = False

# Generated at 2022-06-25 16:17:14.254168
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = dict()
    dict_0['str_1'] = 'TNFn$r@U6)1U6`+E=XN~It'
    dict_0['str_0'] = 'Ywj(a|iM;<>&y2E{I.q'
    dict_0['dict_0'] = dict()
    dict_0['dict_0']['int_1'] = -13
    dict_0['dict_0']['int_0'] = -12
    dict_0['dict_0']['int_2'] = -11
    dict_0['dict_0']['dict_0'] = dict()
    dict_0['dict_0']['dict_0']['str_0'] = '<:8Gp'

# Generated at 2022-06-25 16:17:23.676717
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = '_X9!1'
    str_1 = '_X9!0'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()

# Generated at 2022-06-25 16:17:33.538532
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = '1>!P3*3O{U6`+E='
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_0)
    class_0 = Field
    field_0 = class_0(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 16:17:42.160356
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = 'P!#7P^X9]4q3+/Z&'
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_0)
    str_1 = 'hCSLOi'
    list_1 = [str_1, str_1, str_1, str_1]
    int_0 = None
    obj_0 = catch_all_undefined_parameters_0.handle_to_dict(bool_0, *list_1)


# Generated at 2022-06-25 16:17:54.177262
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # str -> float
    str_0 = random_ascii_letters(10)
    # float -> str
    float_0 = random_float_0_1()
    # float -> bool
    bool_0 = random.choice([True, False])
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(str_0)

    def function_0(str_0):
        return math.sin(str_0)

    # float -> float
    float_1 = catch_all_undefined_parameters_0.create_init(float_0)
    # bool -> None
    none_0 = catch_all_undefined_parameters_0.create_init(bool_0)

    # float -> float
    assert_equal(float_1, math.sin(float_0))
   

# Generated at 2022-06-25 16:18:43.966637
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert True


# Generated at 2022-06-25 16:18:55.355550
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    dict_0 = dict()
    dict_0[7] = 3
    dict_1 = dict()
    dict_1[8] = dict_0
    dict_1[9] = dict_0
    dict_0[4] = dict_1
    dict_0[5] = dict_1
    dict_1[8] = dict_0
    dict_1[9] = dict_0
    # Create an instance of class with decorated __init__
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.create_init(dict_0)
    # Check if the num_args_takeable was correctly calculated
    assert(dict_0 == dict())
    # Check if the callable correctly initializes the class

# Generated at 2022-06-25 16:19:04.769822
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = '1>!P3*3O{U6`+E='
    list_0 = [str_0, str_0, str_0, str_0]
    bool_0 = None
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)


# Generated at 2022-06-25 16:19:12.835042
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Check arguments have the expected types
    obj = None
    kvs = {}

    # Local variables at time of test

# Generated at 2022-06-25 16:19:15.558665
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    try:
        pass
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 16:19:23.853501
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    str_0 = '9(uV&3yE.VaG;1?Y(a*vZ`3q@Q('
    int_0 = -9223372036854775808
    int_1 = -2147483648
    int_2 = 131072
    list_0 = [None, False, int_1, 1, 1, int_2, 1, str_0, str_0, int_1, 1,
              1, int_2, 1, int_2, int_2, False, int_2, int_1, 1, str_0,
              int_2, int_1, 1, int_1, 1, int_2, False, int_2, int_2, False,
              False, False, int_1, 1, False, int_1]
    dict_0

# Generated at 2022-06-25 16:19:35.341976
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict(): # type: ignore
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class MyClass_1:
        a: int
        b: str

        _config = config.Config(unknown=Undefined.INCLUDE)

    @dataclass
    class MyClass_2:
        a: int
        b: str

        _config = config.Config(unknown=Undefined.EXCLUDE)

    my_instance_1 = MyClass_1(1, "hello")
    my_instance_2 = MyClass_2(1, "hello")
    # _CatchAllUndefinedParameters._handle_to_dict(
    # my_instance_1, {"c": "world", "d": "!"})

    # _CatchAllUndefinedParameters._handle_to_dict

# Generated at 2022-06-25 16:19:44.659784
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    print('\nUNIT TEST: _CatchAllUndefinedParameters_create_init')
    str_0 = 's9d!4{4TFo84Pk0G'
    list_0 = [None, str_0, str_0]
    int_0 = 6
    bool_0 = True
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(
        *list_0)
    callable_0 = catch_all_undefined_parameters_0.create_init(int_0)
    callable_1 = catch_all_undefined_parameters_0.create_init(
        int_0)
    int_1 = callable_1(bool_0, 1)
    int_2 = callable_0(int_1, 3)

# Generated at 2022-06-25 16:19:58.915733
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = dict()
    dict_0['c'] = dict_0
    dict_0['a'] = dict_0['b']
    dict_0['b'] = dict_0
    dict_0['b'] = dict_0
    dict_v = dict_0
    dict_1 = dict()
    dict_1['c'] = dict_1['b']
    dict_1['a'] = dict_1['c']
    dict_1['b'] = dict_1
    dict_1['b'] = dict_1['c']
    dict_w = dict_1
    dict_2 = dict()
    dict_2['c'] = dict_2['c']
    dict_2['a'] = dict_2['c']
    dict_2['b'] = dict_2['a']
    dict_2

# Generated at 2022-06-25 16:20:05.124787
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = '2h4kK4'
    str_1 = '1^eK}*s@f,Y'
    list_0 = [str_0, str_1, str_1, str_1, '6]+y:Dw3!6W8"x\x1fF']
    bool_0 = None
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    callable_0 = ignore_undefined_parameters_0.create_init(bool_0)


# Generated at 2022-06-25 16:22:36.452789
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    dict_0 = dict()
    dict_0['A'] = 'F'
    dict_0['C'] = 'J'
    dict_0['D'] = 'O'
    dict_0['H'] = 'W'
    dict_0['K'] = 'Z'
    dict_0['Q'] = 'M'
    dict_0['R'] = 'U'
    dict_0['S'] = 'L'
    dict_0['V'] = 'P'
    dict_0['X'] = 'V'
    dict_0['Y'] = 'Q'

    dict_1 = dict()
    dict_1['D'] = 'V'
    dict_1['K'] = 'H'
    dict_1['S'] = 'F'
    dict_1['V'] = 'A'
    dict_

# Generated at 2022-06-25 16:22:45.677824
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_0 = 'cIgtMC_!J(b"f]T#Tm'
    list_0 = [str_0, str_0, str_0, str_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    dict_0 = dict()
    dict_1 = dict()
    dict_1['JvYg[~:2,BcU|8b+A>Q'] = dict_0
    dict_1[ignore_undefined_parameters_0] = dict_0
    dict_1['][ru/A>$*x?n<8]vKk'] = dict_0
    dict_1['z_t}R1;BCB~K&<?#C{'] = dict_0