

# Generated at 2022-06-25 16:13:04.853749
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    class TestClass:
        def __init__(self,
                     a: int,
                     b: int = 0,
                     c: int = 0,
                     undefined_parameters: CatchAll = None
                     ):
            self.a = a
            self.b = b
            self.c = c
            self.undefined_parameters = undefined_parameters

    class TestClass2:
        def __init__(self,
                     a: int, b: int, c: int
                     ):
            pass

    def get_init_from_instance(obj):
        return obj.__init__

    original_init = TestClass.__init__
    init_from_instance = get_init_from_instance(TestClass())
    assert original_init != init_from_instance

# Generated at 2022-06-25 16:13:12.919085
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    test_cases = {
        _CatchAllUndefinedParameters: _CatchAllUndefinedParameters.create_init,
        _RaiseUndefinedParameters: _RaiseUndefinedParameters.create_init,
        _IgnoreUndefinedParameters: _IgnoreUndefinedParameters.create_init,
    }

    for undefined_action, create_init in test_cases.items():
        cls = dataclasses.make_dataclass("_TestCase", [])
        init = create_init(cls)

        # Test that a calling init without parameters results in no errors
        init(None)

        # Test that without a catch-all parameter, parameters that are
        # not defined in the dataclass will cause errors
        if undefined_action == Undefined.EXCLUDE:
            init(None, **{'a': 'b'})


# Generated at 2022-06-25 16:13:20.567823
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    test_object_0 = object()
    test_object_1 = object()
    test_dict_0 = dict()
    test_dict_1 = dict()
    test_dict_2 = dict()
    test_dict_3 = dict()
    test_dict_4 = dict()
    test_dict_5 = dict()

    # Test for method handle_to_dict of class _UndefinedParameterAction
    assert _IgnoreUndefinedParameters.handle_to_dict(
        test_object_0, test_dict_0) == test_dict_1
    # Test for method handle_to_dict of class _UndefinedParameterAction
    assert _CatchAllUndefinedParameters.handle_to_dict(
        test_object_1, test_dict_0) == test_dict_2


# Generated at 2022-06-25 16:13:25.540145
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class ClassA:
        def __init__(self, a: int = 2, b: int = 4, c: int = 2, d: int = 4):
            pass

    class_a_closure: Callable = _IgnoreUndefinedParameters.create_init(ClassA)
    class InstanceA(ClassA):
        pass

    instance_a = InstanceA()



# Generated at 2022-06-25 16:13:28.895480
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_parameters = _UndefinedParameterAction()
    result = undefined_parameters.handle_dump(None)
    assert result == {}
    assert type(result) == dict


# Generated at 2022-06-25 16:13:31.682195
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    _CatchAllUndefinedParameters.handle_to_dict(
        None, kvs=dict(known_parameter=123, unknown_parameter=456))



# Generated at 2022-06-25 16:13:34.957025
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("something has gone wrong")
    except UndefinedParameterError as e:
        assert str(e) == "something has gone wrong"

# Generated at 2022-06-25 16:13:39.584470
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test: pass
    kvs = {"5": "a"}
    expected_result = {"5": "a"}
    result = _UndefinedParameterAction.handle_from_dict(Test, kvs)
    assert result == expected_result


# Generated at 2022-06-25 16:13:41.803531
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('')
    except UndefinedParameterError as undefined_parameter_error:
        pass

# Generated at 2022-06-25 16:13:44.187501
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_parameter_action = _UndefinedParameterAction()
    assert undefined_parameter_action.handle_dump("obj") == {}

# Generated at 2022-06-25 16:14:11.943198
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # I can't think of any test in this case as the method only serves to
    # modify the function signature.
    # Just running it once is a guarantee that it will not crash here.
    test_class = dataclasses.make_dataclass("Test", [("field_1", int)])
    # noinspection PyUnusedLocal
    test_instance = test_class(42)

# Generated at 2022-06-25 16:14:24.007316
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    Test the special init method created by _CatchAllUndefinedParameters
    """
    case_0_catch_all_field_name = "_UNKNOWN"
    # noinspection PyTypeChecker

# Generated at 2022-06-25 16:14:34.749150
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            assert a == 1
            assert b == 2
    # Test correct input
    test_input = {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, test_input) == test_input
    # Test incorrect input
    test_input = {"a": 1, "b": 2, "c": 3}
    try:
        _UndefinedParameterAction.handle_from_dict(TestClass, test_input)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-25 16:14:46.717442
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()

    class A:
        def __init__(self, a: int, b: str, c: CatchAll = None):
            pass

    a = A(1, "b")
    # If a parameter is `CatchAll` we need to bind it to the original init.
    # Otherwise dataclasses will consider the parameter as having a default
    # value, even if we didn't specify a default here.
    # See https://github.com/michaelb/dataclass-abc/issues/3

    assert _CatchAllUndefinedParameters.create_init(a).__defaults__[2] \
           is None  # type: ignore
    assert _CatchAllUndefinedParameters.create_init(a).__defaults__[
               2]

# Generated at 2022-06-25 16:14:55.399075
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    ################################################
    # Positional parameters before catch-all
    ################################################

    @dataclass
    class _MyDataClass0:
        foo: str
        bar: int
        baz: CatchAll = None

        def __init__(self, foo, bar, baz=None):
            pass

    _MyDataClass0_init = _CatchAllUndefinedParameters.create_init(
        _MyDataClass0)

# Generated at 2022-06-25 16:15:07.581585
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ClassA:
        def __init__(self, x, y, **kwargs):
            catch_all: CatchAll = kwargs.pop("catch_all", {})
            self.x = x
            self.y = y
            self.catch_all = catch_all

    class_fields = fields(ClassA)
    assert len(class_fields) == 3
    assert class_fields[0].name == "x"
    assert class_fields[1].name == "y"
    assert class_fields[2].name == "catch_all"

    kvs = {"x": 1, "z": 1, "y": 2, "catch_all": {"a": 1}}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        ClassA, kvs)
   

# Generated at 2022-06-25 16:15:09.396388
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    _UndefinedParameterAction.handle_from_dict(None, None)



# Generated at 2022-06-25 16:15:16.098880
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClassA:
        def __init__(self, a: int) -> None:
            pass

    class TestClassB:
        def __init__(self, a: int, b: int = 2) -> None:
            pass

    class TestClassC:
        def __init__(self, a: int, b: int = 2, c: int = 1) -> None:
            pass

    class TestClassD:
        def __init__(self, a: int, b: int, c: int = 1, d: int = 2) -> None:
            pass

    for klass in [TestClassA, TestClassB, TestClassC, TestClassD]:
        init = _UndefinedParameterAction.create_init(klass)
        # error because not enough arguments are provided
        # noinspection PyTypeChecker
       

# Generated at 2022-06-25 16:15:22.469436
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    with pytest.raises(UndefinedParameterError):
        raise_undefined_parameters.handle_from_dict(
            cls=dict,
            kvs={"x": 1, "y": 2, "not_a_field": 3})



# Generated at 2022-06-25 16:15:23.948767
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("@UndefinedParameterError: Undefined parameter found")

# Generated at 2022-06-25 16:15:58.551586
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {'k1': 'v1', 'k2': 'v2'}
    ufh = _UndefinedParameterAction()
    assert ufh.handle_to_dict(None, kvs) == kvs


# Generated at 2022-06-25 16:16:05.413126
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class_fields = [Field("name1", str),
                    Field("name2", int)]
    catch_all_field = Field("catch_all", Optional[CatchAllVar], default=None)
    class_fields.append(catch_all_field)
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            class_fields, {"name1": "value1", "name2": 1, "name3": "value3"})
    assert known_given_parameters == {"name1": "value1", "name2": 1}
    assert unknown_given_parameters == {"name3": "value3"}



# Generated at 2022-06-25 16:16:15.886346
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Handle no undefined parameters
    class DummyClass1:
        def __init__(self, a: int):
            self.a = a

    dummy_class1 = DummyClass1(42)
    kvs1 = {"a": 42}
    known_kvs1, unknown_kvs1 = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            dummy_class1, kvs1)
    assert(len(unknown_kvs1) == 0)
    assert(known_kvs1 == {"a": 42})

    # Handle undefined parameters
    class DummyClass2:
        def __init__(self, a: int, *, b: str):
            self.a = a
            self.b = b


# Generated at 2022-06-25 16:16:18.288567
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _RaiseUndefinedParameters.handle_dump(None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}



# Generated at 2022-06-25 16:16:21.725016
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    try:
        _UndefinedParameterAction.create_init(None)
    except AttributeError as e:
        assert(True)



# Generated at 2022-06-25 16:16:28.239129
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class DummyClass:

        a: str
        b: int
        c: float

        def __init__(self, a: str, b: int, c: float):
            pass

    dummy_class = DummyClass(a="a", b=1, c=2.0)
    catch_all_init = _CatchAllUndefinedParameters.create_init(
        DummyClass)
    catch_all_init(dummy_class, 1, 2, 3)



# Generated at 2022-06-25 16:16:37.593638
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    class_data = {"a": 1, "b": 2}
    kvs_0 = {}
    kvs_1 = {"a": 3}
    kvs_2 = {"c": 3}

    assert (raise_undefined_parameters.handle_from_dict(class_data, kvs_0) == {})
    assert (raise_undefined_parameters.handle_from_dict(class_data, kvs_1) ==
            {"a": 3})
    try:
        raise_undefined_parameters.handle_from_dict(class_data, kvs_2)
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-25 16:16:38.964937
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}


# Generated at 2022-06-25 16:16:48.834599
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    class TestType:
        def __init__(self, a: str, b: str, c: str):
            pass

    generated_init = _IgnoreUndefinedParameters.create_init(TestType)
    assert generated_init(None, "a", "b", "c") is None
    assert generated_init(None, "a", "b") is None
    assert generated_init(None, "a") is None
    assert generated_init(None) is None
    assert generated_init(None, "a", d="d") is None
    assert generated_init(None, "a", c="c", d="d") is None
    assert generated_init(None, "a", b="b", c="c", d="d") is None
    assert generated_init(None, a="a", d="d") is None

# Generated at 2022-06-25 16:16:57.918618
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    result_0_0 = raise_undefined_parameters_0.handle_from_dict(cls=str,
                                                               kvs={})
    result_0_1 = raise_undefined_parameters_0.handle_from_dict(cls=str,
                                                               kvs={"b": 1})

    assert result_0_0 == {}
    assert result_0_1 == {}

    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    result_1_0 = ignore_undefined_parameters_0.handle_from_dict(cls=str,
                                                                kvs={})

# Generated at 2022-06-25 16:18:04.777116
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_parameter_error_0 = UndefinedParameterError("foo")


if __name__ == "__main__":
    import sys
    import doctest

    if len(sys.argv) > 1:
        import pytest
        pytest.main(args=["undefined_parameters_test"])
    else:
        num_failures, num_tests = doctest.testmod(report=False)
        print("{} / {} tests failed".format(num_failures, num_tests))

# Generated at 2022-06-25 16:18:16.788179
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def assert_undefined_params(
            undefined_parameters_action: _UndefinedParameterAction,
            cls, kvs: Dict[Any, Any], expected_params: Dict[Any, Any]):
        expected_params = expected_params.copy()
        params = undefined_parameters_action.handle_from_dict(cls, kvs)
        assert params == expected_params, f"{params} != {expected_params}"

    from dataclasses_json.undefined import _CatchAllUndefinedParameters, \
        CatchAllVar

    class Class1:
        def __init__(self, foo: int, bar: int,
                     a: str = "a",
                     b: str = "b",
                     catch_all: CatchAll = None):
            pass

        # Unit test:
        args = {}


# Generated at 2022-06-25 16:18:18.007343
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Test case 0
    _CatchAllUndefinedParameters()



# Generated at 2022-06-25 16:18:27.612599
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    param_values = dict(a=1, b=2, c=3)

    class Example:
        def __init__(self, **kwargs):
            self.one = kwargs.get("a", "default")
            self.two = kwargs.get("b", "default")

    example = Example(**param_values)
    assert example.one == param_values["a"]
    assert example.two == param_values["b"]

    example = Example(**param_values)
    assert example.one == param_values["a"]
    assert example.two == param_values["b"]

    example = Example(a=param_values["a"], b=param_values["b"], d="extra")
    assert example.one == param_values["a"]
    assert example.two == param_values["b"]




# Generated at 2022-06-25 16:18:34.902457
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    test_class_init = TestClass.__init__
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)

    assert new_init.__name__ == "_catch_all_init"
    assert inspect.getsource(new_init) == inspect.getsource(test_class_init)



# Generated at 2022-06-25 16:18:41.949688
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class SampleData:
        def __init__(self, x: int, y: int, z: str):
            self.x = x
            self.y = y
            self.z = z

    sample_data_0 = SampleData(
        x=1,
        y=2,
        z="c")

    new_x = 3

    # given:
    kvs = {
        "x": new_x
    }

    # when
    known_kvs = _RaiseUndefinedParameters.handle_from_dict(
        cls=SampleData,
        kvs=kvs
    )

    # then
    assert known_kvs == kvs



# Generated at 2022-06-25 16:18:46.299357
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert \
        _CatchAllUndefinedParameters.handle_to_dict(object, {"a": 1, "b": 2}) \
        == {"a": 1, "b": 2}



# Generated at 2022-06-25 16:18:48.180362
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError:
        pass


# Generated at 2022-06-25 16:18:57.080164
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    str_3 = str()
    str_4 = str()
    int_5 = int()
    dict_0['test'] = dict_1
    dict_1['test1'] = dict_2
    dict_2['test2'] = str_3
    dict_2['test3'] = int_5
    dict_2['test4'] = str_4
    dict_2['test5'] = str_4
    dict_2['test6'] = str_3
    dict_2['test7'] = dict_0
    dict_1['test8'] = str_3
    dict_1['test9'] = str_3


# Generated at 2022-06-25 16:18:59.154421
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("Yeah, man.")
    assert isinstance(error, ValidationError)

# Generated at 2022-06-25 16:20:27.808450
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    kvs = dict(a=1, b=2, c=3)
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    result = catch_all_undefined_parameters_0.handle_to_dict(
        obj=None, kvs=kvs)
    assert result == dict(a=1, b=2, c=3)
    assert kvs == dict(a=1, b=2, c=3)



# Generated at 2022-06-25 16:20:33.252805
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json.api import from_dict, config
    from dataclasses_json.undefined import Undefined, UndefinedParameterError

    import inspect

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class TestDataClass:
        x: int
        y: int = 0

    d = {
        "x": 1,
        "y": 2,
        "z": 3
    }

    with pytest.raises(TypeError):
        TestDataClass(**d)

    ignored_init = _IgnoreUndefinedParameters.create_init(TestDataClass)

    tdc1 = TestDataClass(3, 4)
    tdc2 = TestDataClass
    tdc2.__init__ = ignored_init
    tdc

# Generated at 2022-06-25 16:20:35.805271
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Setup
    class_fields = {"a": 123}
    given_parameters = {"a": 321}
    expected_result = {"a": 321}

    # Call
    result = _CatchAllUndefinedParameters.handle_from_dict(
        class_fields, given_parameters)

    # Check
    assert result == expected_result



# Generated at 2022-06-25 16:20:42.474014
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    assert catch_all_undefined_parameters_1.handle_dump(
        obj=CatchAllVarTest()) == {}
    assert catch_all_undefined_parameters_1.handle_dump(
        obj=Test0(
            my_field_0="foo", my_field_1=0, my_field_2=1)) == {"my_field_0": "foo", "my_field_1": 0, "my_field_2": 1}


# Generated at 2022-06-25 16:20:51.108143
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()

    class C1:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

    known_parameters = {"x": 1, "y": 2}
    undefined_parameters = {"a": 1, "b": 2}
    kvs = {**known_parameters, **undefined_parameters}
    with pytest.raises(UndefinedParameterError):
        raise_undefined_parameters.handle_from_dict(C1, kvs)



# Generated at 2022-06-25 16:20:59.008720
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses_json import config
    config.undefined = Undefined.EXCLUDE

    @dataclasses.dataclass
    class Dummy:
        x: int
        y: str
        z: int = dataclasses.field(default=0)

        def __init__(self, **kws):
            pass

    init = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(Dummy,
                                                                       {})
    assert init == ({}, {})

    init = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        Dummy, dict(x=3))
    assert init == ({"x": 3}, {})


# Generated at 2022-06-25 16:21:09.793130
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:21:17.107991
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    defined_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=None, kvs={"a": 1, "b": 2, "c": 3, "d": 4})
    assert defined_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3, "d": 4}



# Generated at 2022-06-25 16:21:19.864723
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    my_action = _IgnoreUndefinedParameters()
    assert my_action.handle_dump() == {}

# Generated at 2022-06-25 16:21:33.825263
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    kvs = dict(a=1, b=2, c=3, d=4)

    default_value_0 = _CatchAllUndefinedParameters._SentinelNoDefault

    class _Class0(CatchAllVar):
        def __init__(self, a: int, b: int, c: int, d: int,
                     catch_all: CatchAll = default_value_0):
            pass

    class_name = _Class0.__name__

    # Test if a CatchAll field is present in the class
    with pytest.raises(UndefinedParameterError, match="No field of type"):
        catch_all_undefined_parameters.handle_to_dict(_Class0, kvs)
