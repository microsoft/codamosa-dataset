

# Generated at 2022-06-25 16:13:01.988478
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    test_obj = TestClass(a=3, b=4, c=5)
    new_init = _IgnoreUndefinedParameters.create_init(test_obj)
    init_signature = inspect.signature(new_init)
    num_positional_args = len(init_signature.parameters) - 1  # don't count self
    assert num_positional_args == 3
    new_test_obj = TestClass(1, 2)
    test_obj_copy = TestClass(a=3, b=4, c=5)
    assert test_obj == test_obj_copy
    new_test_obj.__init__(new_test_obj, 1, 2)


# Generated at 2022-06-25 16:13:06.228290
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameter_action = _UndefinedParameterAction()
    kvs = {1: 2, 3: 4}
    result = undefined_parameter_action.handle_to_dict(obj=None, kvs=kvs)
    assert result is kvs, \
        "_UndefinedParameterAction.handle_to_dict has a problem"


# Generated at 2022-06-25 16:13:11.502715
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    def test_case_0():
        undefined_parameter_action_0 = \
            _UndefinedParameterAction()

    def test_case_1():
        undefined_parameter_action_1 = \
            _RaiseUndefinedParameters()

    def test_case_2():
        undefined_parameter_action_2 = \
            _IgnoreUndefinedParameters()

    def test_case_3():
        undefined_parameter_action_3 = \
            _CatchAllUndefinedParameters()



# Generated at 2022-06-25 16:13:14.313761
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class C:
        def __init__(self):
            pass

    func = _UndefinedParameterAction.create_init(C)
    assert func == C.__init__



# Generated at 2022-06-25 16:13:15.688585
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError:
        pass


# Generated at 2022-06-25 16:13:27.244869
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Dummy:
        a: str = "test"
        b: int = 3

    # Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
    def test__IgnoreUndefinedParameters_handle_from_dict():
        dummy = Dummy()
        assert type(_UndefinedParameterAction) \
                    .handle_from_dict(Dummy, {"c": "test"}) == {}

    test__IgnoreUndefinedParameters_handle_from_dict()

    # Unit test for method handle_from_dict of class _RaiseUndefinedParameters

# Generated at 2022-06-25 16:13:39.339943
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _SomeDataClass:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            self.c = c

    class _SomeDataClass2:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    class _SomeDataClass3:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = {}):
            self.a = a
            self.b = b
            self.c = c

    # Scenario: Not all parameters are given

# Generated at 2022-06-25 16:13:48.121862
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from collections import OrderedDict

    target_class = type("_catch_all_init_test", (object,), {
        "__init__": lambda self, a1, a2, a3="hello world", a4=2, **kwargs: None
    })

    # Data
    num_args = 2
    num_kwargs = 2
    kwargs = OrderedDict([('a2', 2), ('a1', 1)])
    args = (1, 2)

    # Test
    init_function = _IgnoreUndefinedParameters.create_init(target_class)
    init_function(target_class, *args, **kwargs)



# Generated at 2022-06-25 16:13:50.104344
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {"a": 2}
    output = _UndefinedParameterAction.handle_to_dict(None, kvs)
    assert output == {"a": 2}



# Generated at 2022-06-25 16:14:01.434040
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    class Foo:
        my_dict: Dict[int, int] = field(default_factory=dict)


    # Case 1
    try:
        _CatchAllUndefinedParameters.handle_from_dict(Foo, {
            "my_dict": {1: 5}, "catch_all": {1: 5}})
        assert False
    except UndefinedParameterError:
        pass

    # Case 2

    def catch_all_factory() -> Dict[int, str]:
        return {1: "A"}


    class Bar:
        my_dict: Dict[int, int] = field(default_factory=dict)
        catch_all: CatchAll = field(default_factory=catch_all_factory)



# Generated at 2022-06-25 16:14:24.379265
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    str_0 = '!+t.;"h{'
    dict_0 = {}
    List_0 = []
    dict_1 = {str_0: str_0}
    list_0 = [List_0, dict_1]
    list_1 = []
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters.handle_from_dict(list_0, dict_0)
    ignore_undefined_parameters_1 = _IgnoreUndefinedParameters.handle_from_dict(str_0, list_1)


# Generated at 2022-06-25 16:14:34.183686
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Test 1, an attempt was made to define an argument that is not a valid
    # parameter.
    # This is an example of a typical users error
    try:
        test = _IgnoreUndefinedParameters()
        test.create_init()
        assert False
    except TypeError:
        assert True
    # Test 2, an attempt was made to define too many arguments.
    # This is an example of a typical users error
    try:
        test = _IgnoreUndefinedParameters()
        test.create_init()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 16:14:46.152971
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'z;&I'
    dict_0 = {str_0: str_0}
    dict_1 = {str_0: str_0}
    dict_2 = {str_0: str_0}
    dict_3 = {str_0: str_0}
    dict_4 = {str_0: str_0}
    dict_5 = {str_0: str_0}
    dict_6 = {str_0: str_0}
    dict_7 = {str_0: str_0}
    dict_8 = {str_0: str_0}
    dict_9 = {str_0: str_0}
    dict_10 = {str_0: str_0}

# Generated at 2022-06-25 16:14:55.044665
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    dict_0 = {'!n': '!n'}
    str_0 = 'n@%'
    dict_1 = 'n@%'
    dict_2 = {'n@%': 'n@%'}
    str_1 = 'n@%'
    list_0 = []
    str_2 = 'n@%'
    dict_3 = '!n'
    str_3 = {'!n': '!n'}
    str_4 = {}
    dict_4 = None
    dict_5 = {'n@%': 'n@%'}
    str_5 = 'n@%'
    str_6 = 'n@%'
    dict_6 = 'n@%'
    dict_7 = 'n@%'
    dict_8 = 'n@%'
   

# Generated at 2022-06-25 16:15:04.501391
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = '3tq4g4_vp8WxM&jv'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    str_1 = 'N<X.&'
    dict_1 = {str_1: str_1}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_1)
    catch_all_undefined_parameters_0.handle_from_dict(list_0, dict_1)


# Generated at 2022-06-25 16:15:15.247878
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    list_0 = ['fkuhh7`r', 'vz8WZ+D?']
    str_0 = 'ppb'
    dict_0 = {str_0: list_0}
    dict_1 = dict_0
    list_1 = []
    str_1 = 'b+E'
    str_2 = 'C~h'
    dict_2 = {str_1: str_2}
    dict_3 = dict_2
    list_2 = []
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_2)
    int_0 = catch_all_undefined_parameters_0.create

# Generated at 2022-06-25 16:15:20.399899
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)


# Generated at 2022-06-25 16:15:31.048888
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    __CatchAllUndefinedParameters_handle_to_dict_variable_0 = _CatchAllUndefinedParameters()
    str_0 = '\x0c\x12\x15\x0b\t\x04\x06\x16\x02\x0f\n\x01\x13\x17\x14\x18'
    int_0 = 0
    dict_0 = {str_0: int_0}
    __CatchAllUndefinedParameters_handle_to_dict_variable_1 = __CatchAllUndefinedParameters_handle_to_dict_variable_0.handle_to_dict(dict_0, dict_0)
    assert __CatchAllUndefinedParameters_handle_to_dict_variable_1 is not None


# Generated at 2022-06-25 16:15:38.212433
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)


# Generated at 2022-06-25 16:15:49.445293
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)



# Generated at 2022-06-25 16:16:17.076084
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Testing the existence of the class _RaiseUndefinedParameters
    assert hasattr(_RaiseUndefinedParameters, 'handle_from_dict')
    # Testing the call of the method handle_from_dict of class
    # _RaiseUndefinedParameters
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:16:24.962045
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'r]!?(yIpJxz{D*Tp'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(
        *list_1)
    dict_2 = catch_all_undefined_parameters_0.handle_from_dict(list_0, dict_1)


# Generated at 2022-06-25 16:16:31.348972
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = '_Ddl-C#x`'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_0)
    bool_0 = False
    bool_1 = True
    int_0 = 0
    dict_1 = {True: bool_1, False: bool_0}
    list_1 = [0]
    ignore_undefined_parameters_0.create_init(list_0, bool_0, bool_1, int_0,
                                              dict_1, list_1)


# Generated at 2022-06-25 16:16:41.920801
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    str_0 = 'aje4x7Yf27+9`HT='
    str_1 = '\x95\x8b\xfc\xe3\x95\x02\x8d\x1c'
    dict_0 = {str_0: str_0, str_1: str_1}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)




# Generated at 2022-06-25 16:16:49.887351
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    str_0 = 'm\'R^6@Hp*d\'hg`'
    list_0 = [str_0, str_0]
    int_0 = -3989
    int_1 = int_0
    float_0 = -99.47
    float_1 = float_0
    dict_0 = {str_0: float_0, str_1: float_1}
    list_1 = [list_0, list_0, list_0]
    list_2 = [int_0, float_0, float_1]
    str_1 = 'Y\'o=jX9Nh-l!I!'
    int_2 = -865
    int_3 = int_2
    int_4 = -9113
    float_2 = float_0

# Generated at 2022-06-25 16:16:56.526116
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_2 = list_0
    dict_2 = _CatchAllUndefinedParameters.handle_to_dict(list_2, dict_1)


# Generated at 2022-06-25 16:17:02.686471
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    list_0 = []
    list_0.append((list_0.append((list_0.append('obj'), True)), True))
    str_0 = 'cb4o!HA'
    str_1 = '[bs%fO'
    str_2 = '>'
    str_3 = '\x19'
    str_4 = '@'
    str_5 = 'R'
    str_6 = '\x02'
    str_7 = 'Y'
    str_8 = '\x02'
    str_9 = '\x02'
    str_10 = '\x1f'
    str_11 = '\x02'
    str_12 = 'dj@f'
    str_13 = '\x02'
    str_14 = '\x0e'
    str_15

# Generated at 2022-06-25 16:17:10.713094
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    str_0 = 'A'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)
    assert dict_2 == dict_1


# Generated at 2022-06-25 16:17:16.798124
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters._get_default == Undefined.INCLUDE
    class_name_0 = 'A{1n.yq3h'
    function_name_0 = 'handle_to_dict'
    obj_0 = DateTime
    field_name_0 = 'str_0'
    tuple_0 = {}
    tuple_1 = _CatchAllUndefinedParameters.handle_to_dict(obj_0, tuple_0)
    assert type(tuple_1) == dict



# Generated at 2022-06-25 16:17:25.690249
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    str_0 = 'Bhn{#sQH}vM*q3qx'
    tuple_0 = (-0.15, -1)
    tuple_1 = (0.0, 0.0)
    tuple_2 = (tuple_0, tuple_1)
    tuple_3 = (tuple_1, tuple_0)
    tuple_4 = (tuple_2, tuple_3)
    list_0 = [tuple_2, tuple_2, tuple_4]
    dict_0 = {str_0: list_0}
    list_1 = [dict_0, dict_0]
    class_0 = list
    list_2 = [class_0]
    dict_1 = {}
    class_1 = list
    catch_all_undefined_parameters_0 = _CatchAll

# Generated at 2022-06-25 16:18:24.938849
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = 'z~nk5'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_1)
    catchall_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_1)
    dict_1 = None
    list_1 = []
    dict_2 = {str_0: str_0}
    list_2 = [dict_2, dict_2]
    dict_3 = {str_0: str_0}
    dict_4 = {}
    dict_5 = dict_1
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}

# Generated at 2022-06-25 16:18:32.483458
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class_0 = _CatchAllUndefinedParameters
    str_0 = 'HwF=-\'/,W!z9>U}N6U'
    dict_0 = {str_0: str_0}
    list_0 = [class_0, dict_0]
    dict_1 = None
    list_1 = []
    callable_0 = class_0.create_init(list_0)
    dict_2 = callable_0(list_1, dict_1)


# Generated at 2022-06-25 16:18:41.409550
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    dict_0 = dict()
    dict_0['j4c4a8Bs'] = 'GNzxej2C'
    dict_0['d'] = 'suDDFjKH'
    dict_0['RaEI6Ngs'] = 'AhpNjXfD'
    dict_0[6] = '6'
    dict_0['PVmZfLrY'] = 'q3sxjnUl'
    dict_0[0.0] = 0.0
    dict_0['cdlkiACb'] = 'xGkr6O'
    dict_0['QzJwRbtI'] = 'YrLr3q9X'
    dict_0['I'] = 'M3Cq8zp'

# Generated at 2022-06-25 16:18:54.034187
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Initialize all variables

    class _Test_Class_0:
        def __init__(self, _CatchAllUndefinedParameters_0 = None, test = None,
                     _UNKNOWN0 = None):
            self._CatchAllUndefinedParameters_0 = _CatchAllUndefinedParameters_0
            self.test = test
            self._UNKNOWN0 = _UNKNOWN0


    # Call method
    method_result_0 = _CatchAllUndefinedParameters.create_init(_Test_Class_0)
    # Assert the expected a result.
    output_1 = method_result_0(
        _Test_Class_0(),
        _CatchAllUndefinedParameters_0={},
        test=None,
        _UNKNOWN0=[])
    # Assert the expected a result.
    output_2 = method_

# Generated at 2022-06-25 16:19:00.554920
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dict_0 = {'Hb~4h4': {'1Fj?_H': '', 'rL{f?x': ''}}
    dict_1 = {}
    undefined_parameters_0 = _UndefinedParameterAction()
    dict_2 = undefined_parameters_0.handle_dump(dict_0)
    assert dict_2 == dict_1


# Generated at 2022-06-25 16:19:07.671352
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.create_init(list_0)
    ignore_undefined_parameters_0.create_init(list_1)


# Generated at 2022-06-25 16:19:10.987732
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    str_0 = '@1N'
    dict_0 = {str_0: str_0}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*dict_0)
    catch_all_undefined_parameters_0.handle_dump(dict_0)


# Generated at 2022-06-25 16:19:19.468769
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    raise_undefined_parameters_0 = \
        _UndefinedParameterAction(*list_1)
    dict_2 = raise_undefined_parameters_0.handle_from_dict(list_0, dict_1)
    raise_undefined_parameters_0_1 = \
        _UndefinedParameterAction(*list_1)
    dict_2 = raise_undefined_parameters_0_1.handle_from_dict(list_0, dict_1)

# Generated at 2022-06-25 16:19:20.266042
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    pass


# Generated at 2022-06-25 16:19:32.465200
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    str_0 = 'Ow&l8@I?+Q9zJd`='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    str_1 = 'DXa[&r,T@}6d^|6'
    dict_1 = {str_1: str_1}
    dict_2 = dict_1
    # ERROR: 'str' object cannot be interpreted as an integer
    # dict_2 = dict(dict_1, **dict_0)
    list_1 = list_0
    # ERROR: 'str' object cannot be interpreted as an integer
    # list_1 = list(dict_0)
    UndefinedParameterError(*list_1, **dict_2)

if __name__ == '__main__':
    test

# Generated at 2022-06-25 16:22:03.870337
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_0 = 'aje4x7Yf27+9`HT='
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, dict_0]
    dict_1 = None
    list_1 = []
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(*list_1)
    catch_all_undefined_parameters_0.create_init(list_0)


# Generated at 2022-06-25 16:22:09.579418
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    str_0 = '!n_g.X9Q>xv?KW-n4'
    list_0 = [str_0, str_0]
    dict_0 = {str_0: list_0}
    str_1 = '_CatchAllUndefinedParameters'
    dict_1 = {str_0: str_1}
    str_2 = 'RaiseUndefinedParameters'
    dict_2 = {str_0: str_2}
    str_3 = 'IgnoreUndefinedParameters'
    dict_3 = {str_0: str_3}
    str_4 = 'INCLUDE'
    dict_4 = {str_0: str_4}
    str_5 = 'RAISE'
    dict_5 = {str_0: str_5}

# Generated at 2022-06-25 16:22:19.211404
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_0 = 'G'
    str_1 = 'r*r^ZF@wDP7`'
    dict_0 = {str_0: str_1}
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_5 = dict_0
    dict_6 = dict_0
    dict_7 = dict_0
    dict_8 = dict_0
    dict_9 = dict_0
    dict_10 = dict_0
    dict_11 = dict_0
    dict_12 = dict_0
    dict_13 = dict_0
    dict_14 = dict_0
    dict_15 = dict_0
    dict_16 = dict_0
    dict_17 = dict_0
    dict_

# Generated at 2022-06-25 16:22:26.007674
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    str_0 = 'J+TvMZRwWHL'
    list_0 = [None, [None], 0]
    dict_1 = {}
    list_1 = [dict_1]
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters(*list_1)
    return_value_0 = ignore_undefined_parameters_0.handle_dump(
        str_0)  # type: ignore
    assert return_value_0 == dict_1
    assert return_value_0 == dict_1
    raise_undefined_parameters_0 = _RaiseUndefinedParameters(*list_0)
    return_value_1 = raise_undefined_parameters_0.handle_dump(str_0)
    assert return_value_1 == dict_1

# Generated at 2022-06-25 16:22:31.494874
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    str_2 = 'zJnj*+tFnP/o5'
    list_56_0 = [str_2]
    dict_5 = None
    dict_6 = {str_2: str_2}
    dict_7 = {str_2: str_2}
    list_56_1 = [dict_7, dict_6]
    str_3 = ':+b,a)>_6%G7oU2'


# Generated at 2022-06-25 16:22:38.163394
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    list_0 = []