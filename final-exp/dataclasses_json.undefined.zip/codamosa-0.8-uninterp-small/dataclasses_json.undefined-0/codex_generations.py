

# Generated at 2022-06-25 16:13:02.728010
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: CatchAll = None):
            pass

    class TestClass_0:
        def __init__(self, a: int = 4, b: CatchAll = None):
            pass

    # No catch-all field
    ignore_undefined_parameters_0 = _CatchAllUndefinedParameters()
    with pytest.raises(UndefinedParameterError):
        ignore_undefined_parameters_0.handle_from_dict(TestClass, {})

    # No default
    handle_from_dict_0 = \
        _CatchAllUndefinedParameters.handle_from_dict(TestClass, {})
    assert handle_from_dict_0 == {"a": 4, "b": {}}

    # Default

# Generated at 2022-06-25 16:13:04.536582
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test method _UndefinedParameterAction.handle_to_dict
    """
    assert True



# Generated at 2022-06-25 16:13:12.729966
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ignore_undefined_parameters = _IgnoreUndefinedParameters()

    @dataclasses.dataclass
    class Dummy:
        x: int
        y: int = 0
        z: str = dataclasses.field(default="dummy text")

        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

        def __eq__(self, other):
            return self.x == other.x and self.y == other.y and self.z == other.z

    init_func = ignore_undefined_parameters.create_init(Dummy)
    assert init_func is not Dummy.__init__

    dummy_0 = init_func(Dummy, 1, 2, 3, boo=5)

# Generated at 2022-06-25 16:13:18.512697
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    test_data = [
        ({"age": 3, "_UNKNOWN2": 4, "_UNKNOWN1": 2}, {"age": 3}),
        ({"age": 3, "_UNKNOWN2": 4, "_UNKNOWN1": 2, "_UNKNOWN3": "abc"},
         {"age": 3, "_UNKNOWN3": "abc"})
    ]
    for test_datum in test_data:
        kvs, expected = test_datum
        assert _UndefinedParameterAction.handle_to_dict(1, kvs) == expected

# Generated at 2022-06-25 16:13:27.856457
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Create data class with CatchAll parameter defined
    @dataclasses.dataclass
    class A:
        f_1: int = 0
        f_2: int = dataclasses.field(default=1)
        f_3: int = 1
        f_4: int = dataclasses.field(default=1)
        f_5: int = dataclasses.field(default=2)
        f_6: int = dataclasses.field(default=3)
        f_7: int = dataclasses.field(default=4)
        f_8: CatchAll = None

    # Parameter names in kvs
    # f_1, f_2, f_3, f_4, f_5, f_6, f_7, f_8
    # Keys:
    # 0: All given are

# Generated at 2022-06-25 16:13:32.527010
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test the method ``handle_from_dict``
    of class ``_CatchAllUndefinedParameters``.
    """
    class ObjectWithCatchAll:
        def __init__(self, a: int, b: int, c: int,
                     d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    # Test input parameters
    known_given_parameters = {"a": 1, "b": 2}
    undefined_given_parameters = {"c": 3, "d": 4}

    # Expected output parameters
    expected_parameters = {"a": 1, "b": 2, "c": 3, "d": {"c": 3, "d": 4}}

    output_parameters = _Catch

# Generated at 2022-06-25 16:13:35.593052
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = object()
    expected_dict = {}
    output = _UndefinedParameterAction.handle_dump(obj)
    assert expected_dict == output


# Generated at 2022-06-25 16:13:44.683301
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    @dataclasses.dataclass
    class IgnoreInput:
        name: str
        age: int

        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    ignore_input = IgnoreInput(name="bob", age=1)
    constructed_input = \
        _IgnoreUndefinedParameters.create_init(IgnoreInput)(
            ignore_input, name="bob", age=1, some_other_attribute="age")
    assert ignore_input.__dict__ == constructed_input.__dict__



# Generated at 2022-06-25 16:13:49.225531
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raise_undefined_parameters = _RaiseUndefinedParameters()
    try:
        raise_undefined_parameters.handle_from_dict(cls=None, kvs={"a": 1})
        assert False
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'a': 1}"



# Generated at 2022-06-25 16:13:54.563747
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from typing import Any, Optional

    @dataclasses.dataclass
    class _TestClass:
        ignore_me: Optional[Any] = None
        catch_me: Optional[CatchAll] = None
        ignore_me_too: Optional[Any] = None

    inst = _TestClass()
    # noinspection PyProtectedMember
    inst.__init__ = _CatchAllUndefinedParameters.create_init(
        obj=_TestClass)
    ignorable_value = 1
    catch_all = {"caught": "all"}
    inst.__init__(ignore_me=ignorable_value, catch_me=catch_all,
                  unknown_param=1)
    assert inst.ignore_me == ignorable_value
    assert inst.catch_me == catch_all

# Generated at 2022-06-25 16:14:18.541063
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test_CatchAllUndefinedParameters():
        class_0 = None

        def __init__(self, a, b: Optional[CatchAllVar] = None):
            Test_CatchAllUndefinedParameters.class_0 = self
            self.a = a
            self.b = b

        def __str__(self):
            return "Test_CatchAllUndefinedParameters{a: " + str(self.a) + ", b: " + str(self.b) + "}"


    obj_0 = Test_CatchAllUndefinedParameters
    callable_0 = obj_0(a = 1)

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_1 = catch_all_undefined_parameters_0.create_init(obj_0)
   

# Generated at 2022-06-25 16:14:24.319258
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    
    val_error = ValidationError()
    try:
        raise UndefinedParameterError('Error string', val_error)
    except UndefinedParameterError as ex:
        assert ex.message == 'Error string'
        assert ex.field_names is None
        assert ex.fields == {}
        assert ex.field_names_tree is None
        assert ex.parent == val_error
        assert hasattr(ex, '__cause__')

# Generated at 2022-06-25 16:14:31.155695
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    def check_equal(input_0, input_1, input_2):
        assert input_0 == input_1
        assert input_0 != input_2
        assert input_1 != input_2

    check_equal(input_0={}, input_1={}, input_2={1: 2})



# Generated at 2022-06-25 16:14:32.143480
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    pass


# Generated at 2022-06-25 16:14:35.845481
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo:
        def __init__(self, a, b, c, d):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(Foo)
    # This raises if the new init does not have the correct arguments
    new_init(Foo, 1, 2, 3, 4, 5)



# Generated at 2022-06-25 16:14:48.172891
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    # Test return of basic CatchAllField
    @dataclasses.dataclass(init=True)
    class TestClass_0(object):
        x: int
        z: int
        something: CatchAll = None

    input_0 = TestClass_0(x=1, z=2)
    out_0 = _CatchAllUndefinedParameters.handle_from_dict(input_0, dict())

    assert isinstance(out_0, dict)
    assert isinstance(out_0['something'], dict)
    assert out_0['something'] == {}

    # Test return of parameter in CatchAllField
    @dataclasses.dataclass(init=True)
    class TestClass_1(object):
        x: int
        z: int
        something: Optional[CatchAllVar] = None

    input_1

# Generated at 2022-06-25 16:14:56.204467
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Define the parameters of the test
    test_name = "_CatchAllUndefinedParameters_create_init"
    name_0 = "_CatchAllUndefinedParameters"
    name_1 = "test__CatchAllUndefinedParameters_create_init"
    name_2 = "test__CatchAllUndefinedParameters_create_init"
    # Set up the tested class
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    # Define the set up of the test
    set_0 = {"name": name_1}
    # Define the expected results
    expected_result_0 = "{'name': 'test__CatchAllUndefinedParameters_create_init'}"
    # Define the actual results

# Generated at 2022-06-25 16:14:57.529329
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass


# Generated at 2022-06-25 16:15:02.474054
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # Test when no error message is provided.
    error = UndefinedParameterError()
    assert error.message == ""
    # Test with error message is provided.
    error_message = "This is an error"
    error = UndefinedParameterError(error_message)
    assert error.message == error_message
    

# Generated at 2022-06-25 16:15:13.881043
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0.handle_dump(set)
    ignore_undefined_parameters_0.handle_dump(int)
    ignore_undefined_parameters_0.handle_dump(float)
    ignore_undefined_parameters_0.handle_dump(None)
    ignore_undefined_parameters_0.handle_dump(bool)
    ignore_undefined_parameters_0.handle_dump(frozenset)
    set_0 = {None, None, None, int}
    set_1 = {int, int, str, None}
    set_2 = {int, float, float, float}
    set_3 = {None, None, int, None}
    ignore_undefined_parameters_

# Generated at 2022-06-25 16:15:31.499447
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_msg = "Undefined Parameter"
    undefined_parameter_error_0 = UndefinedParameterError(error_msg)
    str_0 = str(undefined_parameter_error_0)
    assert str_0 == "Undefined Parameter"


# Generated at 2022-06-25 16:15:32.803549
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert isinstance(UndefinedParameterError, ValidationError)


# Generated at 2022-06-25 16:15:42.062001
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import unittest
    from dataclasses import dataclass
    from typing import Optional

    from dataclasses_json import config
    from dataclasses_json import LetterCase, dataclass_json
    from dataclasses_json.utils import CatchAllVar

    @dataclass(frozen=True)
    class TestDataClass:
        a: str
        b: Optional[int]
        c: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)
        d: Optional[int] = 3

        def __post_init__(self):
            self.a = self.a.upper()
            if self.b is None:
                self.b = 4


# Generated at 2022-06-25 16:15:48.677754
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    empty_dict_0 = dict()
    dict_0 = dict()
    dict_1 = dict()
    value_0 = _UndefinedParameterAction.handle_to_dict(empty_dict_0, dict_0)
    value_1 = _UndefinedParameterAction.handle_to_dict(dict_1, dict_1)


# Generated at 2022-06-25 16:15:56.939019
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    dct = dict([])
    cls = dict([])
    value_0 = _IgnoreUndefinedParameters.handle_from_dict(cls, dct)
    value_1 = _IgnoreUndefinedParameters.handle_from_dict(dct, cls)
    value_2 = _IgnoreUndefinedParameters.handle_from_dict(dct, dct)
    value_3 = _IgnoreUndefinedParameters.handle_from_dict(cls, cls)


# Generated at 2022-06-25 16:16:05.257448
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from hashlib import md5, sha1
    from _io import BytesIO
    from datetime import date, time

    class Foo:
        @property
        def double(self) -> int:
            return self.value * 2

    obj = Foo()
    obj.value = 4

    class Test1:
        val1: str
        val2: Dict[str, int]


# Generated at 2022-06-25 16:16:10.217170
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    kvs = {}
    assert catch_all_undefined_parameters_0.handle_to_dict(
        None, kvs) == ({},)


# Generated at 2022-06-25 16:16:15.719620
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    example_0 = _UndefinedParameterAction()
    example_1 = _IgnoreUndefinedParameters()
    example_1.create_init({})
    example_2 = _CatchAllUndefinedParameters()
    example_2.create_init({})
    example_3 = _RaiseUndefinedParameters()
    example_3.create_init({})
    example_4 = Undefined.EXCLUDE
    example_4.value.create_init({})


# Generated at 2022-06-25 16:16:25.845084
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    common_parameter = "common_parameter"
    special_parameter = "special_parameter"
    undefined_parameter = "undefined_parameter"
    common_value = "common_value"
    special_value = "special_value"
    undefined_value = "undefined_value"

    def from_dict(obj, kvs: Dict):
        return kvs

    def to_dict(obj, kvs: Dict):
        return kvs

    def dump(obj):
        return {}

    class Class_0():
        def __init__(self, common_parameter, special_parameter):
            self.common_parameter = common_parameter
            self.special_parameter = special_parameter


# Generated at 2022-06-25 16:16:32.263102
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class _TestClass:
        def __init__(self, *args, **kwargs):
            pass

    _test_obj = _TestClass()
    original_init = _test_obj.__init__
    ignore_undefined_parameters_2 = _IgnoreUndefinedParameters()
    new_init = ignore_undefined_parameters_2.create_init(_test_obj)

    assert original_init != new_init, \
        "Should have created a new init method"
    assert inspect.signature(original_init) == inspect.signature(new_init), \
        "Signatures of functions should match"
    assert callable(new_init), \
        "Should have created a callable"


# Generated at 2022-06-25 16:16:50.410938
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    set_0 = {_UndefinedParameterAction._separate_defined_undefined_kvs}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_0 = catch_all_undefined_parameters_0.handle_dump(set_0)
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_1 = dict_7
    dict_8 = dict_1



# Generated at 2022-06-25 16:17:00.118629
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    list_0 = [0, 1, 2, 3, 4]
    list_0.extend(range(4))

    for i in range(4, 0, -1):
        list_0.insert(i, i)

    for i in range(4):
        list_0.append(i)

    for i in range(4):
        list_0.append(i)

    set_0 = {catch_all_undefined_parameters_0, catch_all_undefined_parameters_0, catch_all_undefined_parameters_0, catch_all_undefined_parameters_0}

# Generated at 2022-06-25 16:17:08.936370
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class obj:
        x: int
        y: int
        _undefined_parameter_action: _UndefinedParameterAction = \
            _IgnoreUndefinedParameters()

    called_0 = obj.__init__
    obj.__init__ = 1
    callable_0 = obj._undefined_parameter_action.create_init(obj)
    obj.__init__ = called_0
    called_1 = False
    value_1 = callable_0(1, 2)
    assert called_1 == True

# Test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:17:19.073035
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    assert_equal = True
    assert_equal = set(['__repr__', '__reduce_ex__', '__ge__', '__lt__', '__bool__', '__ne__', '__reduce__', '__class__', '__delattr__', '__sizeof__', '__getattribute__', '__gt__', '__format__', '__hash__', '__str__', '__setattr__', '__eq__', '__le__'])
    assert_equal = _CatchAllUndefinedParameters()
    assert_equal = False
    assert_equal = _CatchAllUndefinedParameters()

# Generated at 2022-06-25 16:17:26.617247
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    print("\n")
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    set_0 = {catch_all_undefined_parameters_0, raise_undefined_parameters_0, ignore_undefined_parameters_0}
    known_0, unknown_0 = _UndefinedParameterAction._separate_defined_undefined_kvs(set_0, {'e': 23, 'b': 'a', 'c': 'a', 'a': 'a'})

# Generated at 2022-06-25 16:17:32.564152
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    str_dict_0 = {'fjffb': '', 'pkeiio': -14, 'sjfh': 30, 'hfh': -4}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(str_dict_0, str_dict_0)


# Generated at 2022-06-25 16:17:35.380401
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # TODO: Create test case
    pass


# Generated at 2022-06-25 16:17:39.725938
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclass_json
    @dataclass
    class TestClass0:
        field_a0 : int
        field_c0 : str

    TestClass0.handle_undefined_parameters_from_dict(
        TestClass0, {"field_a0" : 0, "field_c0" : "", })


# Generated at 2022-06-25 16:17:40.597581
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass


# Generated at 2022-06-25 16:17:53.274215
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    _CatchAllUndefinedParameters.handle_to_dict(bytearray,
                                                {'arg_0': bytearray()})
    _CatchAllUndefinedParameters.handle_to_dict(bytearray,
                                                {'arg_0': bytearray()})

# Generated at 2022-06-25 16:18:27.718504
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from importlib.util import module_from_spec, spec_from_file_location
    from shutil import rmtree
    import tempfile
    from collections import namedtuple
    from dataclasses_json.utils import CatchAllVar
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Any

    spec = spec_from_file_location(
        "module.name",
        "/home/benjamin/Devel/uw-class/capstone/CatchAll_schema.py"
    )
    Foo = module_from_spec(spec)
    spec.loader.exec_module(Foo)

    class CatchAll_schema:
        class Schema:
            class Meta:
                unknown = Undefined.INCLUDE
                ordered = True
                dataclass_fields = {}

# Generated at 2022-06-25 16:18:35.951906
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Object_1:
        def __init__(self, param_0: int, param_1: int, param_2: int) -> None:
            pass
    obj_1 = Object_1
    expected_result_0 = Object_1.__init__
    actual_result_0 = _CatchAllUndefinedParameters.create_init(obj_1)
    assert expected_result_0 == actual_result_0, \
        f'Expected: {expected_result_0}; Actual: {actual_result_0}'


# Generated at 2022-06-25 16:18:43.374575
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Employee:
        id: str
        name: str
        title: str
        number_of_lives: bool
        number_of_employees: int

    input_0 = {'name': 'John', 'title': 'Senior Engineer', 'id': '123', 'number_of_employees': 5, 'number_of_lives': False}

    employee_0 = Employee(id='123', name='John', title='Senior Engineer', number_of_lives=False, number_of_employees=5)
    actual_output_0 = _IgnoreUndefinedParameters.handle_from_dict(Employee, input_0)

# Generated at 2022-06-25 16:18:52.185085
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses_json
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    expected_0 = "__init__"
    actual_0 = TestClass.__name__.lower()
    assert expected_0 == actual_0
    expected_0 = _IgnoreUndefinedParameters.create_init(TestClass)
    actual_0 = TestClass.__init__.__name__.lower()
    assert expected_0 == actual_0



# Generated at 2022-06-25 16:19:04.335617
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from typing import Union
    from dataclasses import dataclass
    from dataclasses_json.config import Undefined

    @dataclass
    class UndefinedParameters0:
        catch_all: Optional[CatchAllVar] = Undefined(Undefined.INCLUDE)

        def __init__(self, catch_all=None):
            self.catch_all = catch_all

    _UndefinedParameterAction_handle_to_dict_0 = UndefinedParameters0()
    _UndefinedParameterAction_handle_to_dict_1 = dict()
    _UndefinedParameterAction_handle_to_dict_2 = dict()

# Generated at 2022-06-25 16:19:05.340545
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()


# Generated at 2022-06-25 16:19:09.882684
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        foo: int
        bar: str
        undefined: Optional[CatchAll] = None

    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_0 = catch_all_undefined_parameters_0.create_init(Foo(1, "bar"))
    assert ('foo', 'bar', 'undefined') == callable_0.__code__.co_varnames


# Generated at 2022-06-25 16:19:15.384073
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    known_parameters_0 = {}
    unknown_parameters_0 = {}
    pass

# Generated at 2022-06-25 16:19:30.114960
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_set_0(self, str_0: str, str_1: str) -> None:
        pass

    set_0 = set()
    _IgnoreUndefinedParameters_0 = _IgnoreUndefinedParameters()
    callable_0 = _IgnoreUndefinedParameters_0.create_init(set_0)
    callable_0(set(), '', str_1='')
    callable_0(set(), str_0='', str_1='')
    callable_0(set(), str_0='', str_1='', _UNKNOWN0='')
    callable_0(set(), str_0='', str_1='', _UNKNOWN0='', _UNKNOWN1='')
    _IgnoreUndefinedParameters_0.create_init(set_0)


# Generated at 2022-06-25 16:19:41.829014
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # {}
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    ignore_undefined_parameters_0._CatchAllUndefinedParameters._get_default(set_0)
    ignore_undefined_parameters_0._CatchAllUndefinedParameters.handle_from_dict(set_0, set_0)
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_0.handle_dump(set_0)
    catch_all_undefined_parameters_0._CatchAllUndefinedParameters._get_catch_all_field(set_0)
    catch_all_undefined_parameters_0._CatchAllUndefinedParameters._get_default(set_0)
    catch_all_undefined_parameters

# Generated at 2022-06-25 16:20:45.802002
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    callable_0 = catch_all_undefined_parameters_0.create_init()


# Generated at 2022-06-25 16:20:56.427194
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Case 0
    # Undefined parameters are not handled
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    kvs_0 = dict()
    dict_0 = dict()
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, kvs_0)
    print(dict_1)

    # Case 1
    # Undefined parameters are handled
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    kvs_0 = dict()
    dict_0 = dict()
    kvs_0['a'] = 2
    dict_1 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, kvs_0)
    print(dict_1)




# Generated at 2022-06-25 16:21:07.756058
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters

# Generated at 2022-06-25 16:21:23.400169
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_1 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_2 = _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_3 = _CatchAllUndefinedParameters()
    set_0 = {catch_all_undefined_parameters_0, catch_all_undefined_parameters_1, catch_all_undefined_parameters_2, catch_all_undefined_parameters_3}
    string_0 = catch_all_undefined_parameters_0.handle_to_dict(set_0, {'key': 'value'})
    string_1 = catch_all_undefined_parameters_1.handle_to

# Generated at 2022-06-25 16:21:34.650915
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    int_0 = ignore_undefined_parameters_0.handle_from_dict(int, {'hoary_0': int})
    assert int_0 == {'hoary_0': int}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    bool_0 = catch_all_undefined_parameters_0.handle_from_dict(bool, {'hoary_0': bool})
    assert bool_0 == {'hoary_0': bool}
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    str_1 = raise_undefined_parameters_0.handle_from_dict(str, {'hoary_0': str})

# Generated at 2022-06-25 16:21:41.506759
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: int, b: int, c: str, d: str,
                     e: Optional[CatchAllVar] = None) -> None:
            pass

    _CatchAllUndefinedParameters.create_init(A)(0,0,0,0)
    _CatchAllUndefinedParameters.create_init(A)(0, 0, 0, 0, b=1)
    _CatchAllUndefinedParameters.create_init(A)(0, 0, a='a', d=None)
    _CatchAllUndefinedParameters.create_init(A)(0, 0, a='a', d=None)
    _CatchAllUndefinedParameters.create_init(A)(0, 0, a='a', d=None)

# Generated at 2022-06-25 16:21:46.485785
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    def test_class(a: int, b: int, c: int, d: int) -> tuple:
        return (a, b, c, d)
    test_class_init = catch_all_undefined_parameters.create_init(test_class)
    assert test_class_init(test_class, 1, 2, 3, 4) == (1, 2, 3, 4)


# Generated at 2022-06-25 16:21:47.239014
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    pass


# Generated at 2022-06-25 16:21:50.488678
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(set(), {"a": 1, "b": 1})
    _RaiseUndefinedParameters.handle_from_dict(set(), {"a": 1})


# Generated at 2022-06-25 16:21:57.876451
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ignore_undefined_parameters_0 = _IgnoreUndefinedParameters()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    set_0 = {ignore_undefined_parameters_0, ignore_undefined_parameters_0, ignore_undefined_parameters_0, ignore_undefined_parameters_0}
    str_0 = _UndefinedParameterAction.handle_from_dict(set_0, ignore_undefined_parameters_0)
