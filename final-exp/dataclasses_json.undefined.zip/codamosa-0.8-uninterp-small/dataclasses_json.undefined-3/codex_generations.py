

# Generated at 2022-06-25 16:12:52.357555
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = {"a": 1, "b": 2}
    obj_0 = Undefined.RAISE.value()
    _UndefinedParameterAction.handle_to_dict(obj_0, dict_0)
    # dict_0={'a': 1, 'b': 2}


# Generated at 2022-06-25 16:13:02.441583
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class DummyClass:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    dummy_class = DummyClass(catch_all={"other_key": "other_value"},
                             some_other_key="some_other_value")
    kv_dict = {"some_key": "some_value",
               "catch_all": {"other_key": "other_value"}}

    expected_output = {"some_key": "some_value", "other_key": "other_value"}
    output = _CatchAllUndefinedParameters.handle_to_dict(dummy_class, kv_dict)

    assert expected_output == output, "Getter failed"



# Generated at 2022-06-25 16:13:06.018826
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=1):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    assert inspect.signature(init) == inspect.signature(TestClass.__init__)



# Generated at 2022-06-25 16:13:13.617728
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        included: int
        data: Optional[CatchAllVar] = dataclasses.field(default=None)

        def __init__(self, included: int, data: Optional[CatchAllVar] = None):
            self.included = included
            self.data = data

    initial_data = dict(
        random="random_value",
        another_unknown_field=42,
        included=1,
    )

    test_class = TestClass(**initial_data)

    # Check that the dump contains the expected data
    target_data = dict(
        random="random_value",
        another_unknown_field=42,
    )
    assert test_class.data == target_data

    # Check that the dump does not include the included field
    dump

# Generated at 2022-06-25 16:13:15.052185
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict({}, {}) == {}


# Generated at 2022-06-25 16:13:16.075585
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump('a') == {}


# Generated at 2022-06-25 16:13:22.255296
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class SimpleClass:
        x: int

        def __init__(self, x: int):
            self.x = x

    @dataclasses.dataclass
    class MyClass:
        name: str
        x: int
        unknown: Optional[CatchAllVar] = None

        def __init__(self, x: int, name: str = None, unknown: Optional[
            CatchAllVar] = None):
            self.x = x
            self.name = name
            self.unknown = unknown

    @dataclasses.dataclass
    class MyEmptyClass:
        name: str
        x: int
        unknown: Optional[CatchAllVar] = None


# Generated at 2022-06-25 16:13:29.625289
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    unknown_key = "unknown_key"
    unknown_value = "unknown_value"

    class Test0:
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all

    class Test1:
        def __init__(self, catch_all: CatchAll = {}):
            self.catch_all = catch_all

    class Test2:
        def __init__(self, catch_all: CatchAll = {}):
            self.catch_all = catch_all

    class Test3:
        def __init__(self, catch_all: CatchAll = {unknown_key: unknown_value}):
            self.catch_all = catch_all

    class Test4:
        def __init__(self, catch_all: CatchAll = None):
            self.catch_

# Generated at 2022-06-25 16:13:41.804015
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        @dataclasses.dataclass
        class B(abc.ABC):
            a: int
            b: float = 0.0
            catch_all: Optional[CatchAllVar] = dataclasses.field(
                default_factory=dict)

            def __init__(self, **kwargs):
                a = kwargs.pop("a")
                b = kwargs.pop("b")
                self.a = a
                self.b = b
                self.catch_all = kwargs

            def __eq__(self, other: Any) -> bool:
                if not isinstance(other, A.B):
                    return False

# Generated at 2022-06-25 16:13:49.093782
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class _TestClass:
        def __init__(self, x: str=None, y: str=None,
                     ignored: Optional[CatchAllVar]=None):
            self.x = x
            self.y = y
            self.ignored = ignored

    obj = _TestClass("abc", "def", {"something": 123})
    dump = _CatchAllUndefinedParameters.handle_dump(obj)
    assert dump == {"something": 123}



# Generated at 2022-06-25 16:14:12.185893
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, *, a: int, b: Optional[CatchAllVar] = None) -> None:
            self.a = a
            self.b = b

    a_value = 3
    kvs1 = {
        "a": a_value,
        "z": "ignored"
    }
    out1 = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs1)
    assert out1 == {
           "a": a_value,
           "b": {"z": "ignored"}
    }

    a_value = 3
    kvs2 = {
        "a": a_value,
        "z": "ignored",
        "b": {}
    }
    out2 = _CatchAllUndefinedParameters.handle_from_dict

# Generated at 2022-06-25 16:14:19.441885
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(frozen=True)
    class TestClassA:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a, b, c, d):
            pass

    assert _CatchAllUndefinedParameters.create_init(TestClassA)(
        TestClassA) == TestClassA.__init__



# Generated at 2022-06-25 16:14:22.649189
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 16:14:33.743426
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = {}
    dict_1 = {}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_2 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_1)
    additional_parameter = "Additional parameter"
    dict_1[additional_parameter] = additional_parameter
    dict_3 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_1)
    assert dict_3[additional_parameter] == additional_parameter
    assert dict_3 == dict_1
    assert dict_2 == dict_0


# Generated at 2022-06-25 16:14:37.049166
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}


# Generated at 2022-06-25 16:14:49.303338
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    dict_0 = {'a': 'b'}
    dict_1 = {'c': 'd'}
    dict_2 = {'a': 'b', 'c': 'd'}
    assert dict_2 == dict_0.copy()
    dict_0.update(dict_1)
    assert dict_2 == dict_0.copy()
    dict_2['e'] = 'f'
    dict_0.update(dict_2)
    assert dict_0 == {'a': 'b', 'c': 'd', 'e': 'f'}
    dict_0['g'] = {}
    dict_0['g']['h'] = 'i'
    assert dict_0['g'] == {'h': 'i'}
    dict_0.clear()
    dict_2.clear()

#

# Generated at 2022-06-25 16:14:55.004045
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:15:03.194903
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    """
    Verifies that method handle_from_dict of class _UndefinedParameterAction
    returns a dictionary with only known fields
    :return:
    """
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=None, kvs=None)
    assert known_given_parameters is None
    assert unknown_given_parameters is None



# Generated at 2022-06-25 16:15:14.514761
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = {}
    dict_1 = {}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_2 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_1)
    assert dict_2 == dict_1
    dict_0 = {'To': '2', 'From': '1', 'MessageBody': 'Hello World!'}
    dict_1 = {}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_2 = catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_1)
    assert dict_2 == dict_1

# Generated at 2022-06-25 16:15:15.833652
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    _ = _CatchAllUndefinedParameters.create_init(_IgnoreUndefinedParameters)


# Generated at 2022-06-25 16:15:54.216301
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    dict_0 = {}
    dict_0["a"] = 1
    dict_0["b"] = 2
    dict_0["c"] = 3
    dict_1 = {}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    dict_1 = catch_all_undefined_parameters_0.handle_from_dict(dict_1, dict_0)
    dict_2 = {}
    dict_2["a"] = 1
    dict_2["b"] = 2
    dict_2["c"] = 3
    dict_3 = {}
    dict_3["a"] = "1"
    dict_3["b"] = "2"
    dict_4 = {}
    dict_4["a"] = "1"
    dict_4["b"] = "2"
    dict

# Generated at 2022-06-25 16:16:04.202606
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class ParentClass(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def _method_to_call(self):
            pass

    class ChildClass(ParentClass):
        def _method_to_call(self):
            pass

    child_class = ChildClass()
    old_method_to_call = child_class._method_to_call
    for undefined_parameter_type in Undefined:
        if undefined_parameter_type == Undefined.EXCLUDE:
            new_create_init_method = _UndefinedParameterAction.create_init(
                child_class)

            # noinspection PyCallingNonCallable
            ChildClass = new_create_init_method(child_class)
            new_method_to_call = ChildClass._method_to_call
        else:
            new

# Generated at 2022-06-25 16:16:08.628982
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Case 1: Given an empty dict, return an empty dict.
    dict_0 = {}
    dict_1 = _CatchAllUndefinedParameters.handle_from_dict(dict_0)
    assert dict_1 == {}



# Generated at 2022-06-25 16:16:17.241607
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    Expect the correct behavior for method handle_to_dict of
    class _CatchAllUndefinedParameters
    """
    dict_1 = {"key_0": "value_0", "key_1": "value_1"}
    dict_2 = {"key_2": "value_2", "key_3": "value_3"}
    expected_result_0 = {"key_2": "value_2", "key_3": "value_3"}
    catch_all_undefined_parameters_1 = \
        _CatchAllUndefinedParameters()
    catch_all_undefined_parameters_2 = \
        _CatchAllUndefinedParameters()
    result_0 = catch_all_undefined_parameters_1.handle_to_dict(dict_1, dict_2)
    result_1 = catch_

# Generated at 2022-06-25 16:16:24.515417
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Define input
    kvs_0 = {}
    # Define the class that is used to test the method
    class A:
        pass
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    try:
        raise_undefined_parameters_0.handle_from_dict(A, kvs=kvs_0)
    except UndefinedParameterError:
        pass
    else:
        raise Exception("Expected UndefinedParameterError")

# Generated at 2022-06-25 16:16:31.907964
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict_23 = dict()
    dict_24 = dict()

# Generated at 2022-06-25 16:16:33.308912
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    _IgnoreUndefinedParameters.create_init(list)



# Generated at 2022-06-25 16:16:44.442798
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    MockClass = type("MockClass", (), {})
    MockClass.__annotations__ = {}
    MockClass.__init__ = Mock(return_value=None, spec_set=True)
    mock_new_init = _IgnoreUndefinedParameters.create_init(MockClass)
    assert mock_new_init.__name__ == "MockClass.__init__"
    assert mock_new_init.__qualname__ == "MockClass.__init__"
    assert mock_new_init.__doc__ == MockClass.__init__.__doc__
    mock_new_init(None, 10, 20, 30)
    MockClass.__init__.assert_called_with(None, 10, 20)



# Generated at 2022-06-25 16:16:51.542017
# Unit test for method create_init of class _CatchAllUndefinedParameters

# Generated at 2022-06-25 16:17:00.473607
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        def __init__(self, foo: str = "", bar: str = "") -> None:
            self.foo = foo
            self.bar = bar

    dict_0 = {}
    dict_1 = {"foo": "foo", "bar": "bar"}
    dict_2 = {"foo": "foo"}
    dict_3 = {"bar": "bar"}
    dict_4 = {"baz": "baz"}
    dict_5 = {"baz": "baz", "foo": "foo"}
    dict_6 = {"baz": "baz", "foo": "foo", "bar": "bar"}

    dummy_class_0 = DummyClass()
    dummy_class_1 = DummyClass()
    dummy_class_2 = DummyClass()
    dummy_class_3 = Dummy

# Generated at 2022-06-25 16:18:01.028180
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Obj:
        def __init__(self, a, b, *args, **kwargs):
            pass

    obj = Obj(1, 2, 3, 4, 5)

    def _number_of_args(*args):
        return len(args)

    callable_0 = functools.partial(
        _CatchAllUndefinedParameters.create_init, obj)
    number_of_args_0 = callable_0(obj, 1, 2, 3, 4, 5)
    number_of_args_1 = callable_0(obj, 1, 2, 3, 4)
    number_of_args_2 = callable_0(obj, 1, 2, 3)
    number_of_args_3 = callable_0(obj, 1, 2)
    number_of_args_4 = callable

# Generated at 2022-06-25 16:18:06.699248
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = {}
    dict_1 = {"key": "value"}
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters(0)
    catch_all_undefined_parameters_0.handle_to_dict(dict_0, dict_1)


# Generated at 2022-06-25 16:18:17.718201
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters = _CatchAllUndefinedParameters()
    assert catch_all_undefined_parameters.handle_from_dict(CatchAllVar, {}) == {}

    dict_0 = {'_UNKNOWN0': 2, '_UNKNOWN1': 1}
    dict_1 = {}
    dict_2 = {'_UNKNOWN0': 2, '_UNKNOWN1': 1, '_UNKNOWN2': 3, '_UNKNOWN3': 4}
    dict_3 = {'_UNKNOWN0': 2, '_UNKNOWN1': 1, '_UNKNOWN4': 5}

    # Test case 0
    dict_4 = catch_all_undefined_parameters.handle_from_dict(
        CatchAllVar, dict_0)
    assert dict_4 == dict_1 == {}

   

# Generated at 2022-06-25 16:18:21.948553
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dict_0 = {}
    dict_1 = {}
    undefined_parameter_raise = _RaiseUndefinedParameters()
    dict_2 = undefined_parameter_raise.handle_to_dict(dict_0, dict_1)
    assert dict_2 == dict_1


# Generated at 2022-06-25 16:18:33.294625
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # set up inputs for function
    class MyTestClass:
        def __init__(self, test_parameter_1: str,
                     test_parameter_2: str,
                     test_parameter_3: Optional[CatchAllVar]):
            self.test_parameter_1 = test_parameter_1
            self.test_parameter_2 = test_parameter_2
            self.test_parameter_3 = test_parameter_3

    test_parameter_1 = "test_string_1"
    test_parameter_2 = "test_string_2"
    test_parameter_3 = "illicit_test_string"

# Generated at 2022-06-25 16:18:41.793820
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=1, d=2, **kwargs):
            self.a: int = a
            self.b: int = b
            self.c: int = c
            self.d: int = d
            self.kwargs = kwargs

    # None of the allowed parameters are given.
    tc_0 = TestClass(1, 2, 3, 4)
    dummy_instance = TestClass(1, 2)
    tc_0_init = _UndefinedParameterAction.create_init(dummy_instance)
    tc_0_init(1, 2, 3, 4)
    tc_0_init(a=1, b=2, c=3, d=4)

    # All parameters are given

# Generated at 2022-06-25 16:18:47.855223
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    dict_0 = {}
    dict_1 = {}
    dict_2 = dict()
    raise_undefined_parameters_0 = _RaiseUndefinedParameters()
    dict_3 = raise_undefined_parameters_0.handle_from_dict(dict_0, dict_1)
    assert dict_3 == dict_2



# Generated at 2022-06-25 16:18:54.079246
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, x: int = 3, bar=CatchAll):
            self.x = x
            self.bar = bar

    foo = Foo()
    assert foo.x == 3
    assert foo.bar == {}

    foo = Foo(x=4, baz=5)
    assert foo.x == 4
    assert foo.bar == {"baz": 5}



# Generated at 2022-06-25 16:19:06.439344
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def old_init(self, name: str, age: int):
        self.name = name
        self.age = age

    import functools

    new_init = _IgnoreUndefinedParameters.create_init(old_init)
    @functools.wraps(old_init)
    def _ignore_init(self, name, age, *args, **kwargs):
        known_kwargs, _ = \
            _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
                old_init, kwargs)
        num_params_takeable = len(
            inspect.signature(old_init).parameters) - 1  # don't count self
        num_args_takeable = num_params_takeable - len(known_kwargs)


# Generated at 2022-06-25 16:19:12.734330
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class CatchAllClass:
        def __init__(self, x: float = 0, y: float = 0,
                     z: float = 0,
                     undefined_parameters: Optional[CatchAllVar] = None):
            self.x: float = x
            self.y: float = y
            self.z: float = z
            self.undefined_parameters: Optional[CatchAllVar] = \
                undefined_parameters

    dict_0 = {"y": 5, "c": 3, "a": 1, "b": 2}

    catch_all_tester = CatchAllClass()
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()

# Generated at 2022-06-25 16:21:27.240985
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    test_0 = {"test": "test"}
    class test_class_0:
        test_field: str

    assert {"test_field": "test"} \
           == _RaiseUndefinedParameters.handle_from_dict(test_class_0, test_0)

    test_1 = {"test": "test", "test2": "test"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(test_class_0, test_1)



# Generated at 2022-06-25 16:21:29.997266
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError) as error:
        raise(UndefinedParameterError('Error occurred.'))
    assert str(error.value) == 'Error occurred.'


# Generated at 2022-06-25 16:21:40.535276
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class ClassWithUndefinedParameters(_IgnoreUndefinedParameters):
        def __init__(self, arg_1, arg_2, arg_3):
            pass
    catch_all_0 = _IgnoreUndefinedParameters()
    init_0 = catch_all_0.create_init(ClassWithUndefinedParameters)

    class_0 = ClassWithUndefinedParameters(1, 2, 3)
    class_1 = ClassWithUndefinedParameters(1, 2)
    class_2 = ClassWithUndefinedParameters(1, 2, 3, arg_4=4)
    class_3 = ClassWithUndefinedParameters(1, 2, 3, arg_4=4, arg_5=5)


# Generated at 2022-06-25 16:21:41.431571
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test string")

# Generated at 2022-06-25 16:21:48.750443
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class IgnoreInitTest:
        def __init__(self, a, b: str, c: str = "c", d: Optional[int] = 3,
                     e: Optional[float] = 4):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    iit = IgnoreInitTest(1, 2)
    assert iit.a == 1
    assert iit.b == 2
    assert iit.c == "c"
    assert iit.d == 3
    assert iit.e == 4

    ignore_init = _IgnoreUndefinedParameters.create_init(IgnoreInitTest)

    # Test with positional arguments
    with pytest.raises(TypeError):
        ignore_init(5, 6, 7, 8)



# Generated at 2022-06-25 16:21:57.426262
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    given_dict = {"a": "a", "b": "b", "c": "c"}

    class TestClass:
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b

    undefined_parameters_action = _RaiseUndefinedParameters()
    actual_dict = \
        undefined_parameters_action.handle_from_dict(cls=TestClass,
                                                     kvs=given_dict)
    expected_dict = {"a": "a", "b": "b"}
    assert actual_dict == expected_dict



# Generated at 2022-06-25 16:22:01.800569
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError:
        pass


# Generated at 2022-06-25 16:22:06.355544
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_undefined_parameters_0 = _CatchAllUndefinedParameters()
    #dict_0 = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(dict_0, dict_1)
    #dict_1 = catch_all_undefined_parameters_0.handle_from_dict(dict_0, dict_1)


# Generated at 2022-06-25 16:22:17.774041
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    raiseUndefinedParametersObject = _RaiseUndefinedParameters()
    # known_given_parameters should be empty
    known_given_parameters, unknown_given_parameters = \
        raiseUndefinedParametersObject.handle_from_dict(dict(), {})
    assert len(known_given_parameters) == 0
    assert len(unknown_given_parameters) == 0

    # known_given_parameters should contain key1:value1
    known_given_parameters, unknown_given_parameters = \
        raiseUndefinedParametersObject.handle_from_dict(dict(), {"key1":
                                                                     "value1"})
    assert len(known_given_parameters) == 1
    assert len(unknown_given_parameters) == 0
    assert known_given_parameters["key1"] == "value1"



# Generated at 2022-06-25 16:22:24.784726
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.utils import CatchAllVar

    @dataclass_json
    class TestClass0:
        test_field: str
        catch_all_field: Optional[CatchAllVar] = None

    kvs = {'test_field': 'test', 'unknown_field': 'test'}

    # Test with test_field
    kvs_2 = _CatchAllUndefinedParameters.handle_from_dict(TestClass0, kvs)
    assert isinstance(kvs_2['test_field'], str)
    assert isinstance(kvs_2['catch_all_field'], dict)

    # Test without test_field
    kvs = {'unknown_field': 'test'}
    k