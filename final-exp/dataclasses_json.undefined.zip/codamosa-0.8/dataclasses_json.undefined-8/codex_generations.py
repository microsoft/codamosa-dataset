

# Generated at 2022-06-11 21:05:38.141691
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class SomeClass:
        def __init__(self, a: int, b: str = "test") -> None:
            self.a = a
            self.b = b

    expected_a = 134
    expected_b = "abc"
    # because the default parameter is neglected,
    # the value of b will always be "test".
    given_parameters = {"a": expected_a,
                        "b": expected_b,
                        "c": "xyz"}

    expected_parameters = {"a": expected_a}
    actual_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(kvs=given_parameters, cls=
                                                   SomeClass)
    assert actual_parameters == expected_parameters


# Unit tests for method handle_from_dict of class _IgnoreUndefined

# Generated at 2022-06-11 21:05:48.965141
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Setup
    import dataclasses

    @dataclasses.dataclass
    class TestClass():
        a: int = 0
        b: str = ''
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: CatchAll = None,
                     *args, **kwargs):
            pass

    test_class = TestClass

# Generated at 2022-06-11 21:06:01.531370
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import unittest.mock as mock

    # noinspection PyUnusedLocal
    def init(self, a, b, c=42):
        pass

    @dataclasses.dataclass
    class UndefHandlingExample:
        a: int
        b: int
        c: int = 42

    # noinspection PyArgumentList
    @mock.patch("dataclasses_json.undefined_action._UndefinedParameterAction.create_init",
                wraps=_UndefinedParameterAction.create_init)
    def test_normal_init(mock_create_init):
        u = UndefHandlingExample(1, 2)
        mock_create_init.assert_called_once()

    # noinspection PyArgumentList

# Generated at 2022-06-11 21:06:13.806194
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class SomeClass:
        field1: str
        field2: str

        @classmethod
        def _raise_init(cls, *args, **kwargs):
            _UndefinedParameterAction.handle_from_dict(SomeClass, kwargs)

        @classmethod
        def _ignore_init(cls, *args, **kwargs):
            _UndefinedParameterAction._separate_defined_undefined_kvs(
                cls, kwargs)

    # Ignored parameters
    SomeClass._ignore_init(field1="abc", field2="efg", field3=123)

    # Valid
    instance = SomeClass("abc", "efg")
    # Empty
    instance = SomeClass("", "")

    # Invalid

# Generated at 2022-06-11 21:06:17.322919
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, *args, **kwargs):
            pass

    import marshmallow
    class TestSchema(marshmallow.Schema):
        test = marshmallow.fields.Str()

    TestSchema().load({"test": "test"})

# Generated at 2022-06-11 21:06:29.898117
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a, b, c):
            pass


# Generated at 2022-06-11 21:06:39.258931
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test default value is that CatchAllDictionary will be empty
    class ClassWithEmptyCatchAll:
        def __init__(self, *, CatchAllDictionary: Optional[CatchAllVar] = None):
            self.CatchAllDictionary = CatchAllDictionary
            """ :type CatchAllDictionary: Optional[CatchAllVar]"""

    kvs = {}
    result = _CatchAllUndefinedParameters.handle_from_dict(
        cls=ClassWithEmptyCatchAll, kvs=kvs)
    assert len(result) == 1
    assert result["CatchAllDictionary"] == {}

    # Test default value is that CatchAllDictionary will be empty
    # Test that input is used even if empty

# Generated at 2022-06-11 21:06:49.615618
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    from dataclasses import dataclass

    from dataclasses_json import Undefined

    @dataclass
    class TestClass:
        a: int
        b: str

        def __init__(self, a: int, b: str, *args, this_is_ignored=100,
                     **kwargs):
            self.a = a
            self.b = b

    # Test 1
    init_func: Callable = _CatchAllUndefinedParameters.create_init(
        TestClass)
    new_init_signature = inspect.signature(init_func)

    try:
        new_parameters = new_init_signature.parameters
    except Exception as e:
        raise Exception(
            f"Could not inspect new init function: {e}") from e


# Generated at 2022-06-11 21:06:53.238230
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}
    assert _RaiseUndefinedParameters.handle_dump(None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}

# Generated at 2022-06-11 21:07:05.095077
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    caught_exc_info = None
    exc_class = ValueError
    exc_msg = "expected exception"

    class ClassToInitialize():
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     catch_all: Optional[CatchAllVar] = None):
            if a + b == 0:
                raise exc_class(exc_msg)
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.catch_all = catch_all

    init = _CatchAllUndefinedParameters.create_init(ClassToInitialize)

# Generated at 2022-06-11 21:07:26.134149
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    def assert_params(cls, kvs, expected):
        result = _CatchAllUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
        assert result == expected, f"{result} != {expected}"


# Generated at 2022-06-11 21:07:34.347967
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def _create_schema(cls):
        @dataclasses_json.dataclass_json(
            unknown=_CatchAllUndefinedParameters)
        @dataclasses.dataclass
        class _schema:
            a: int
            b: int
            c: dataclasses_json.utils.CatchAll

        return _schema(**cls.__dict__)

    @dataclasses.dataclass
    class _cls:
        a: int = 1
        b: int = 1
        c: dataclasses_json.utils.CatchAll = \
            dataclasses_json.utils.CatchAll.no_default


# Generated at 2022-06-11 21:07:42.578763
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    _UndefinedParameterAction.handle_from_dict(None, {})
    _UndefinedParameterAction.handle_to_dict(None, {})
    _UndefinedParameterAction.handle_dump(None)

    _CatchAllUndefinedParameters.handle_from_dict(None, {})
    _CatchAllUndefinedParameters.handle_to_dict(None, {})
    _CatchAllUndefinedParameters.handle_dump(None)

    _RaiseUndefinedParameters.handle_from_dict(None, {})

    _IgnoreUndefinedParameters.handle_from_dict(None, {})

# Generated at 2022-06-11 21:07:49.246543
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: str
        u: int = dataclasses.field(metadata={'marshmallow_field': True})
        def __post_init__(self):
            self.c = self.a*self.u


    my_class: MyClass = dataclasses.replace(MyClass(a=5,b="hallo",c=4),
                                            u=4)
    assert my_class.a == 5
    assert my_class.b == "hallo"
    assert my_class.c == 20
    assert my_class.u == 4

# Generated at 2022-06-11 21:07:58.764495
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    try:
        _IgnoreUndefinedParameters.create_init(TestClass)(1, 2, 3)
        assert False, "should raise TypeError"
    except TypeError:
        pass

    _IgnoreUndefinedParameters.create_init(TestClass)(1, 2)

# Generated at 2022-06-11 21:08:03.851212
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.undefined = {}

    class MyClass2:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    assert MyClass(a=1, b=2).__dict__ == MyClass2(a=1, b=2).__dict__

# Generated at 2022-06-11 21:08:13.303462
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self,
                     defined_parameter: str,
                     undefined_parameter: str = "ignored"):
            self.defined_parameter = defined_parameter
            self.undefined_parameter = undefined_parameter

    result = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {"defined_parameter": "test", "undefined_parameter": "test"})
    assert result == {"defined_parameter": "test"}

# Generated at 2022-06-11 21:08:24.212259
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class Params1:
        p1: str
        p2: str

    @dataclasses.dataclass
    class Params2:
        p1: str
        p2: str
        p3: Optional[str]

    @dataclasses.dataclass
    class Params3:
        p1: str
        p2: str
        p3: Optional[CatchAllVar]

    kvs = {"p1": "v1", "p2": "v2", "p3": "v3", "p4": "v4"}

    def _handle_from_dict(kvs, cls):
        """
        Internal test method to test the actions
        """

# Generated at 2022-06-11 21:08:36.623571
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self,
                     catch_all: CatchAll = None):
            self.catch_all = catch_all


    test_obj = TestClass(
        {"known_parameter": "known_parameter_value"})
    kvs = test_obj.__dict__
    final_kvs = _CatchAllUndefinedParameters.handle_to_dict(
        test_obj, kvs)
    assert final_kvs == {"known_parameter": "known_parameter_value"}

    test_obj_with_default = TestClass()
    test_obj_with_default.catch_all = {"known_parameter":
                                           "known_parameter_value"}
    kvs = test_obj_with_default.__dict__
    final_kvs = _CatchAll

# Generated at 2022-06-11 21:08:43.600483
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int
        c: str
        _UNKNOWN: CatchAll

    test = TestClass("foo", 123, "bar", {"hello": "world"})
    undefined_behavior = _CatchAllUndefinedParameters()
    assert {
        "a": "foo",
        "b": 123,
        "c": "bar",
        "hello": "world"
    } == undefined_behavior.handle_to_dict(test,
                                            {"a": "foo", "b": 123, "c": "bar",
                                             "_UNKNOWN": {"hello": "world"}})



# Generated at 2022-06-11 21:09:17.924030
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(default_factory=dict)
        d: int = dataclasses.field(default=5)

    obj = TestClass(a=2, b=3)

    # Default construction (d,c)
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'d': 5}
    # c replaced by dict
    obj.c = {1: 2, 3: 4}
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'d': 5, 1: 2, 3: 4}
    # d not default so not included
    obj.d = 6

# Generated at 2022-06-11 21:09:20.613080
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    undefined_parameter_action = _UndefinedParameterAction()
    assert undefined_parameter_action.handle_dump(None) == {}

# Generated at 2022-06-11 21:09:22.131318
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(1)

    assert error.messages == 1



# Generated at 2022-06-11 21:09:30.384833
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Tmp:
        def __init__(self, **kwargs):
            self._kwargs = kwargs
            self.a = 1

        def to_dict(self, **kwargs) -> dict:
            kwargs = _CatchAllUndefinedParameters.handle_to_dict(self, kwargs)
            return dict(self._kwargs, **kwargs)

    t = Tmp(catch_all={"b": 2, "c": 3}, d="x")
    assert t.to_dict(a=1) == {'a': 1, 'b': 2, 'c': 3, 'd': "x"}
    assert t.to_dict(a=1, b=5) == {'a': 1, 'b': 5, 'c': 3, 'd': "x"}
    assert t.to_

# Generated at 2022-06-11 21:09:37.634086
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    _IgnoreUndefinedParameters.handle_from_dict(cls=TestClass,
                                                kvs={"a": 1, "b": 2})
    _IgnoreUndefinedParameters.handle_from_dict(cls=TestClass,
                                                kvs={"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-11 21:09:42.599723
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        x: int
        y: str

    input_dict = {"x": 0, "y": "y"}
    output_dict = _UndefinedParameterAction.handle_from_dict(cls=DummyClass,
                                                             kvs=input_dict)
    assert input_dict == output_dict



# Generated at 2022-06-11 21:09:53.824632
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow import Schema, fields

    class AnObject:
        def __init__(self, a: int, b: str, c: float = float("nan"),
                     d: Optional[int] = None):
            pass

    @dataclasses_json.dataclass_json(undefined=Undefined.EXCLUDE)
    class MyObject(AnObject):
        a: int
        b: str
        c: float = fields.Float(missing=float("nan"))
        d: Optional[int] = None

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.a = 42

    original_init = MyObject.__init__
    init_method = _IgnoreUndefinedParameters.create_init(MyObject)

    assert init_

# Generated at 2022-06-11 21:09:55.339134
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError:
        assert True

# Generated at 2022-06-11 21:10:06.726152
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses

    class SomeClass:
        def __init__(self, a: int, b: int, c: int, d: int) -> None:
            pass

    class SomeOtherClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int) -> None:
            pass


    create_init = _IgnoreUndefinedParameters.create_init
    init = create_init(SomeClass)

    # noinspection PyUnusedLocal
    @dataclasses.dataclass(init=init)
    class ShouldPass:
        a: int
        b: int
        c: int
        d: int

    ShouldPass(1, 2, 3, 4)

# Generated at 2022-06-11 21:10:09.923703
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("test")
    assert err.args[0] == "test"

# Generated at 2022-06-11 21:11:14.131733
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, x: str, catch_all: Optional[CatchAllVar] = None):
            self.x = x
            self.catch_all = catch_all

    obj = TestClass("x", {"unknown": "unknown"})
    kvs = {"x": obj.x}
    kvs_new = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs == kvs_new
    kvs_new = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs_new)
    assert kvs != kvs_new

# Generated at 2022-06-11 21:11:23.871927
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: str, b: str = "defb",
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    class B:
        def __init__(self, a: str, b: str = "defb",
                     catch_all: Optional[CatchAllVar] = None,
                     catch_all2: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all
            self.catch_all2 = catch_all2


# Generated at 2022-06-11 21:11:29.277388
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, u: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.u = u

    obj = TestClass(a=3, b=4, u={})
    assert {'a': 3, 'b': 4, 'u': {}} == _UndefinedParameterAction.handle_dump(
        obj)



# Generated at 2022-06-11 21:11:38.274334
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestDataClassCatchAllInit:
        a: int
        b: int
        c: int = dataclasses.field(
            metadata=dataclasses_json.config(
                undefined=Undefined.INCLUDE,
                unknown=CatchAll,
                allow_unset=True
            ))

    @dataclasses.dataclass
    class TestDataClassCatchAllMissingType:
        a: int
        b: int
        c: CatchAll = dataclasses.field(
            default=None, metadata=dataclasses_json.config(
                undefined=Undefined.INCLUDE,
                unknown=CatchAll,
                allow_unset=True
            ))

    obj = TestDataClassCatchAllInit(1, 2, 3)
    TestData

# Generated at 2022-06-11 21:11:39.706708
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # This test is run as part of test_utils.UnitTests_handle_undefined
    pass

# Generated at 2022-06-11 21:11:41.959103
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dump_result = _UndefinedParameterAction.handle_dump({})
    assert dump_result == {}

# Generated at 2022-06-11 21:11:48.796302
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses

    @dataclasses.dataclass
    class TestObject:
        d: Dict[str, Any]
        c: Optional[CatchAllVar] = None

    assert _CatchAllUndefinedParameters.handle_dump(
        TestObject(d={"a": 1, "b": "asd"}, c={"z": True}
                   )) == {"z": True}
    assert _CatchAllUndefinedParameters.handle_dump(
        TestObject(d={"a": 1, "b": "asd"})) == {}


# Generated at 2022-06-11 21:11:55.207792
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass(unsafe_hash=True)
    class Test:
        a: int
        b: float

        def __init__(self, a, b, c=1):
            pass

    init_function = _IgnoreUndefinedParameters.create_init(Test)

    assert init_function.__name__ == "__init__"
    assert inspect.signature(Test.__init__) == inspect.signature(init_function)

    assert not hasattr(Test(), "c")
    assert Test(1, 2).__dict__ == dict()

    assert Test(1, 2, 3).__dict__ == dict()

# Generated at 2022-06-11 21:12:00.022188
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # noinspection PyAbstractClass
    class A:
        a: int = dataclasses.field(default=0)
        b: str = dataclasses.field(default="")
        c: str = dataclasses.field(default="")

        def __init__(self, a: int, b: str, c: str):
            pass

        def __eq__(self, other):
            if isinstance(other, A):
                return self.a == other.a and self.b == other.b
            return False

    init = _IgnoreUndefinedParameters.create_init(obj=A)
    a = A(1, "b", "c")
    b = A(**init(a, a=1, b="b", c="c", d="d"))

# Generated at 2022-06-11 21:12:02.567957
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("ERROR MESSAGE")
    except UndefinedParameterError as e:
        assert str(e) == "ERROR MESSAGE"

# Generated at 2022-06-11 21:14:21.234207
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Test if catch-all parameter is handled correctly
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class A:
        foo: int
        bar: int
        baz: int
        bye: int
        catch_all: CatchAll = None

        def __init__(self, foo: int, bar: int, baz: int, bye: int,
                     catch_all: CatchAll = None):
            pass

    new_init = _CatchAllUndefinedParameters.create_init(A)
    assert len(inspect.signature(new_init).parameters) == 6
    assert new_init.__name__ == "A"

    a = A(foo=1, bar=2, baz=3)  # Should implicitly set catch_all to {}

# Generated at 2022-06-11 21:14:29.297342
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyPep8Naming
    class ExampleClass:
        # noinspection PyMissingConstructor
        def __init__(self, a: int, foo="bar", *, catch_all: CatchAll = None):
            self.a = a
            self.foo = foo
            self.catch_all = catch_all
            self.dummy = "dummy"

    example = ExampleClass(1, dummy="yay")
    assert example.a == 1
    assert example.foo == "bar"
    assert example.dummy == "yay"
    assert not hasattr(example, "catch_all")

    example = ExampleClass(1, dummy="yay", catch_all="woah")
    assert example.a == 1
    assert example.foo == "bar"

# Generated at 2022-06-11 21:14:30.046059
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    pass

# Generated at 2022-06-11 21:14:35.017769
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    try:
        _UndefinedParameterAction.handle_from_dict()
    except TypeError as exc:
        assert str(exc) == "Can't instantiate abstract class " \
                           "UndefinedParameterAction with " \
                           "abstract methods handle_from_dict"
    else:
        assert False, "Expected TypeError"

# Generated at 2022-06-11 21:14:41.159353
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, arg1: int, arg2: str, arg3: int,
                     u: Optional[CatchAllVar] = None):
            pass

    init_method = _CatchAllUndefinedParameters.create_init(TestClass)
    init_method(self=TestClass, arg1=1, arg2="2", arg3=3)
    init_method(self=TestClass, arg1=1, arg2="2", arg3=3, u=None)
    with pytest.raises(UndefinedParameterError):
        init_method(self=TestClass, arg1=1, arg2="2", arg3=3, u=4)

# Generated at 2022-06-11 21:14:48.024444
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class _DummyClass:
        foo: str
        bar: str

    known, unknown = \
        _UndefinedParameterAction. \
            _separate_defined_undefined_kvs(_DummyClass, {"foo": "i",
                                                           "bar": "j"})
    assert known == {"foo": "i",
                     "bar": "j"}
    assert unknown == {}

# Generated at 2022-06-11 21:14:54.848908
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        def __init__(self, a: Optional[CatchAllVar] = None):
            self.a = a

    instance = TestClass({
        "b": "b",
        "c": "c"
    })
    assert instance.a == {"b": "b", "c": "c"}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj=instance,
                                                       kvs={}) == {"b": "b",
                                                                   "c": "c"}

# Generated at 2022-06-11 21:15:04.417914
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from typing import Tuple

    @dataclass
    class A:
        field1: int
        field2: Tuple
        field3: str
        field4: str
        field5: str
        field6: dict = dataclasses.field(default_factory=dict)
        field7: dict = dataclasses.field(default_factory=dict)

    init = _CatchAllUndefinedParameters.create_init(A)

    # Check with default args:
    a = A(1, (2, 3, 4), "5", "6", "7")
    assert a.field1 == 1
    assert a.field2 == (2, 3, 4)
    assert a.field3 == "5"
    assert a.field4 == "6"

# Generated at 2022-06-11 21:15:05.268892
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    pass

# Generated at 2022-06-11 21:15:17.250450
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Person:
        """ An example class Person"""

        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    class Employee(Person):
        """ An example class Employee extending Person"""

        def __init__(self, name: str, age: int, salary: float):
            super().__init__(name, age)
            self.salary = salary

    class Animal:
        """ An example class Animal"""

        def __init__(self, name: str, age: int, color=None):
            self.name = name
            self.age = age
            self.color = color
