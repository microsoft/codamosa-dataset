

# Generated at 2022-06-11 21:05:35.551623
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass(
        init=False)
    class _TestClass:
        f1: int
        f2: str

    params = {'f1': 34, 'f2': "ab", 'f3': 11}
    assert _IgnoreUndefinedParameters.handle_from_dict(_TestClass, params) == \
           {'f1': 34, 'f2': "ab"}



# Generated at 2022-06-11 21:05:42.834574
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def retval():
        pass

    class _FakeInitable(abc.ABC):
        def __init__(self):
            pass
        __init__.__name__ = "__init__"

    _UndefinedParameterAction.create_init.__get__(_FakeInitable)(retval)

    assert retval.__name__ == "__init__"
    assert retval.__qualname__ == "_FakeInitable.__init__"
    assert retval.__module__ == "_FakeInitable"



# Generated at 2022-06-11 21:05:43.459847
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    pass

# Generated at 2022-06-11 21:05:45.923449
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Foo:
        def __init__(self):
            pass

    assert {} == _UndefinedParameterAction.handle_dump(obj=Foo())



# Generated at 2022-06-11 21:05:59.433463
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    cls = dataclasses.make_dataclass("test", [
        ("test", str)
    ])

# Generated at 2022-06-11 21:06:06.471916
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():

    class IgnoreClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    input_kvs = {"a": 1, "b": 2, "c": 3}
    assert _CatchAllUndefinedParameters.handle_from_dict(IgnoreClass, input_kvs) == {"a": 1, "b": 2, "_UNKNOWN0": 3}

# Generated at 2022-06-11 21:06:10.955140
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {'a': 3, 'b': 5}
    known_kvs = {'a': 42}
    unknown_kvs = {'b': None}

    assert _UndefinedParameterAction.handle_to_dict(None, kvs) == kvs


# Generated at 2022-06-11 21:06:13.770714
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass(init=_UndefinedParameterAction.create_init(_RaiseUndefinedParameters))
    class Test:
        x: int

        def __init__(self, x: int):
            self.x = x

    assert Test(x=3).x == 3

# Generated at 2022-06-11 21:06:20.453443
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined, UndefinedParameterError
    from dataclasses_json.utils import CatchAllVar


    class TestClass:
        def __init__(self, a: int, b: int, c: int,
                     d: Optional[CatchAllVar] = None) -> None:
            pass


    test_class_init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class_init(TestClass(1, 2, 3))
    try:
        test_class_init(TestClass(1, 2, 3, {"x": 1, "y": 4}))
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'x': 1, 'y': 4}"
       

# Generated at 2022-06-11 21:06:27.366342
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    class Test:
        def __init__(self, a, b, c):
            """
            :param a:
            :param b:
            :param c:
            """
            self.a = a
            self.b = b
            self.c = c

    init = _CatchAllUndefinedParameters.create_init(Test)
    assert init.__name__ == "__init__"

# Generated at 2022-06-11 21:06:50.186701
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestCatchAll(metaclass=DataclassJSON):
        thing: str
        other: str
        number: int = field(hash=False)
        more: Optional[CatchAllVar] = field(hash=False)

    obj = TestCatchAll("a", "b", 1, {"x": "y",
                                     "z": 1})
    assert _CatchAllUndefinedParameters.handle_to_dict(obj,
                                                       {'thing': 'a',
                                                        'other': 'b',
                                                        'number': 1,
                                                        'more': {'x': 'y',
                                                                 'z': 1}}) == {
               'thing': 'a', 'other': 'b', 'number': 1, 'x': 'y', 'z': 1}

# Generated at 2022-06-11 21:06:58.681992
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import pytest
    import marshmallow.fields as fields
    from marshmallow import Schema

    class A:
        def __init__(self, field1: str, field2: str):
            self.field1 = field1
            self.field2 = field2

    class ASchema(Schema):
        field1 = fields.Str()
        field2 = fields.Str()

    class B:
        def __init__(self, field1: str, field2: str = "default_value"):
            self.field1 = field1
            self.field2 = field2

    class BSchema(Schema):
        field1 = fields.Str()
        field2 = fields.Str()

    class C:
        def __init__(self, field1: str, field2: str = None):
            self.field1

# Generated at 2022-06-11 21:07:10.024045
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class ClassWithUndefinedParams:
        pass

    class ClassWithCatchAllUndefinedParams:
        catch_all_field = CatchAll(CatchAllVar)

    # noinspection PyTypeChecker
    def test_case(cls, kvs, expected):
        actual = _UndefinedParameterAction._UndefinedParameterAction \
            .handle_from_dict(cls, kvs)
        assert actual == expected

    test_case(ClassWithUndefinedParams, {"no_params": 3, "one_param": 3},
              {"one_param": 3})
    test_case(ClassWithCatchAllUndefinedParams,
              {"catch_all_field": "{}", "one_param": 3},
              {"catch_all_field": {}, "one_param": 3})


# Generated at 2022-06-11 21:07:13.259607
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class ErrorClass:
        foo: int

    kvs = {"foo": 1, "bar": 2}
    result = _RaiseUndefinedParameters.handle_from_dict(ErrorClass, kvs)
    expected = {"foo": 1}
    assert result == expected



# Generated at 2022-06-11 21:07:26.305426
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection DuplicatedCode
    class A:
        def __init__(self, a, b, c=3, *, d, e="eggs", **kwargs):
            pass

    @dataclasses.dataclass
    class D:
        a: int
        b: int
        c: int = dataclasses.field(default=3)
        d: int
        e: str = dataclasses.field(default="eggs")
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAll(),
            metadata={'dataclasses_json': {'undefined': Undefined.INCLUDE}})

    # Given
    # input_parameters: the parameters that are to be passed to the constructor
    # catch_all_field_name: the name of the

# Generated at 2022-06-11 21:07:26.991794
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass

# Generated at 2022-06-11 21:07:27.634712
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-11 21:07:34.696983
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b, c=None):
            pass

    obj = Test("a", "b")
    param_length = len(inspect.signature(obj.__init__).parameters)

    ignore_init = _IgnoreUndefinedParameters.create_init(obj)
    ignore_init(obj, *("a" * (param_length)))
    ignore_init(obj, *("a" * (param_length - 1)))

    with pytest.raises(TypeError):
        ignore_init(obj, *("a" * (param_length + 1)))

    with pytest.raises(TypeError):
        ignore_init(obj, *("a" * (param_length - 2)))

# Generated at 2022-06-11 21:07:45.772938
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses_json.api

    @dataclasses.dataclass
    class FooClass:
        foo: str
        bar: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __init__(self, *args, **kwargs):
            pass

    FooClass.__init__ = _CatchAllUndefinedParameters.create_init(FooClass)
    correct_result: Any = FooClass("foo", 1, catch_all={"undefined_value": 5})
    to_dict = dataclasses_json.api.as_dict
    assert to_dict(correct_result) == {
        "foo": "foo",
        "bar": 1,
        "undefined_value": 5
    }

# Generated at 2022-06-11 21:07:55.959843
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class ClassWithParameters:
        field1: int

    # Defined parameters
    defined_parameters = _RaiseUndefinedParameters.handle_from_dict(
        ClassWithParameters,
        {"field1": 1})
    assert defined_parameters == {"field1": 1}

    # Undefined parameters
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            ClassWithParameters,
            {"field1": 1, "field2": 2})
        assert False, "Expected exception!"
    except UndefinedParameterError:
        assert True

    # Undefined parameters should not be returned
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            ClassWithParameters,
            {"field2": 2})
        assert False, "Expected exception!"
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-11 21:08:27.156235
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError as e:
        assert e.args == ()
    try:
        raise UndefinedParameterError("foo")
    except UndefinedParameterError as e:
        assert e.args == ("foo",)
    try:
        raise UndefinedParameterError("foo", 1, 2)
    except UndefinedParameterError as e:
        assert e.args == ("foo", 1, 2)

# Generated at 2022-06-11 21:08:38.249238
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from .common_testing import (
        prepare_dataclass_with_ignore_undef_parameters, check_case_is_applied)

    def _to_dict(obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
        return _UndefinedParameterAction.handle_to_dict(obj, kvs)

    @prepare_dataclass_with_ignore_undef_parameters
    class TestClass:
        values: dict
        ignore: dict

    test_kvs = {
        "name": "this",
        "age": 5
    }
    test_obj = TestClass(ignore=test_kvs)
    assert _to_dict(test_obj,
                    {"name": "this", "age": 5, "ignore": test_kvs}
                    ) == test_k

# Generated at 2022-06-11 21:08:44.849166
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        var1: str
        var2: str
        var3: int
        var4: int = 10
        catchall: Optional[CatchAllVar] = CatchAll

    test_case = TestClass(**{"var1": "test", "var2": "bla"})
    assert set(TestClass.__init__.__code__.co_varnames) == {"self", "var1",
                                                            "var2", "var3",
                                                            "var4"}

    # Test with no undefined parameters

# Generated at 2022-06-11 21:08:51.974654
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Dummy:
        x: int

    d = Dummy(x=1)

    d2 = Dummy(**_RaiseUndefinedParameters.handle_from_dict(
        Dummy, {"x": 1}))
    d3 = Dummy(**_RaiseUndefinedParameters.handle_from_dict(
        Dummy, {"x": 1, "y": 1}))  # should raise error



# Generated at 2022-06-11 21:08:59.939750
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """Test if the created init method of dataclasses_json.IgnoreUndefined
    Parameters works as expected.
    """
    import random
    import string
    from typing import Dict, List, Set
    from dataclasses import dataclass

    @dataclass
    class SomeClass:
        a: int
        b: str
        c: float
        catchall: Optional[CatchAllVar] = None

        def __init__(self, a, b, c=1.0):
            self.a = a
            self.b = b
            self.c = c

    # This can not be monkey patched,
    # hence we have to patch the method in the class directly
    original_create_init = _UndefinedParameterAction.create_init
    _UndefinedParameterAction.create_init = _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:09:05.879612
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class C:
        x: str
        y: int
        z: CatchAll = None

    c = C("a", 23, {"foo": 4, "baz": ["a", 23]})
    c_dict = _CatchAllUndefinedParameters.handle_dump(c)
    assert c_dict == {"foo": 4, "baz": ["a", 23]}


# Generated at 2022-06-11 21:09:15.772761
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass(unsafe_hash=True,
                           init=True,
                           frozen=True,
                           frozen_by_default=True,
                           unsafe_hash=True)
    class Foo:
        a: int
        b: float = 1.1
        c: bool

        @classmethod
        def create_init(cls) -> Callable:
            return _IgnoreUndefinedParameters.create_init(cls)

    # default parameter
    foo = Foo(1, c=True)
    assert foo.a == 1
    assert foo.b == 1.1
    assert foo.c
    # extra parameter but no catch-all field

# Generated at 2022-06-11 21:09:26.912962
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # type: () -> None
    class MockedClass:
        @staticmethod
        def __init__(arg1: str, arg2: str):
            pass

    @dataclasses.dataclass
    class KnownParameter:
        arg1: str

    @dataclasses.dataclass
    class UnknownParameter:
        arg2: str

    @dataclasses.dataclass
    class KnownAndUnknownParameter:
        arg1: str
        arg2: str

    known_parameter_kvs = {'arg1': 1}
    unknown_parameter_kvs = {'arg2': 1}


# Generated at 2022-06-11 21:09:38.955702
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int
        baz: str

    foo = Foo(1, "2")
    assert foo.bar == 1
    assert foo.baz == "2"
    foo.bar = 2
    assert foo.bar == 2
    assert foo.baz == "2"

    # Create a new object without the original init
    ignore_init = _IgnoreUndefinedParameters.create_init(foo)
    new_foo = type(foo)(bar=2, baz="2", origin=ignore_init)
    assert new_foo.bar == 2
    assert new_foo.baz == "2"


# Generated at 2022-06-11 21:09:45.895167
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class SomeClass:
        some_field: str

        def __init__(self, some_field: str):
            self.some_field = some_field

    my_class = SomeClass("test")
    init_kwargs = _RaiseUndefinedParameters.handle_from_dict(
        cls=my_class.__class__,
        kvs={"some_field": "test", "undefined": "undefined"})
    assert init_kwargs == {"some_field": "test"}



# Generated at 2022-06-11 21:10:44.824060
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def __init__(self, a: int, b: int):
        print(a, b)

    class C:
        __init__ = _UndefinedParameterAction.create_init(__init__)

    assert hasattr(C, '__init__')

# Generated at 2022-06-11 21:10:54.281446
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test:
        def __init__(self, a,
                     b):
            self.a = a
            self.b = b

    test = Test(b=2, a=1)
    kvs = {
        "b": 1,
        "a": 2
    }
    assert (
        _UndefinedParameterAction.handle_to_dict(obj=test,
                                                  kvs=kvs) == {"b": 1, "a": 2})



# Generated at 2022-06-11 21:11:03.270906
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Base:
        def __init__(self, a: str, b: str = "b"):
            pass

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Base2(Base):
        a: str
        f: CatchAll = None

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Child:
        a: str
        b: str = "child-b"
        f: CatchAll = None

    test_classes = [Base, Base2, Child]

    for cls in test_classes:
        # Test that Cases 1-4 work untransformed:
        # 1. No args given, use default
        cls()
        # 2. All args given, no catch-all used

# Generated at 2022-06-11 21:11:14.524630
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: str
        b: str

    tc = TestClass("a", "b")

    # Given a dictionary that matches the class
    known, unknown = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {"a": "a", "b": "b"})
    assert known == {"a": "a", "b": "b"}
    assert unknown == {}
    assert dataclasses.asdict(tc) == {"a": "a", "b": "b"}

    # Given a dictionary that does not match the class
    known, unknown = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {"a": "a", "b": "b", "c": "c"})

# Generated at 2022-06-11 21:11:22.244046
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    expected_output = {1: 2, 3: 4}
    @dataclasses.dataclass(init=True)
    class TestClass:
        a: int
        b: int
        c: CatchAll
        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    tc = TestClass(1, 2, expected_output)
    actual_output = _UndefinedParameterAction.handle_to_dict(tc, tc.__dict__)
    actual_output.pop('c')

    assert actual_output == expected_output



# Generated at 2022-06-11 21:11:24.673396
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError("this is a test")
    assert str(e) == "this is a test"

# Generated at 2022-06-11 21:11:35.762554
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class Dc:
        a: int
        b: str
        c: int
        d: str
        e: int
        f: str

        def __init__(self, a: int, b: str, c: int, d: str, e: int, f: str):
            pass

    @dataclasses.dataclass
    class Dc2:
        a: int
        b: str
        c: int
        d: str
        e: int
        f: str
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-11 21:11:38.777396
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    message = "A message"
    UndefinedParameterError(message)

# Generated at 2022-06-11 21:11:49.144819
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class T:
        def __init__(self, a, b: CatchAll = None):
            self.a = a
            self.b = b

    t = T(12, {3: 4})
    tt = T(12, None)
    ttt = T(12)

    assert _CatchAllUndefinedParameters.handle_from_dict(T, {'a': 10}) == {
        'a': 10}
    assert _CatchAllUndefinedParameters.handle_from_dict(T, {'a': 10,
                                                              'b': {2: 3}}) == {
        'a': 10, 'b': {2: 3}}

# Generated at 2022-06-11 21:11:56.465548
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from mypy_extensions import TypedDict
    import marshmallow as ma
    from dataclasses_json.utils import _UndefinedParameterAction

    class _MyModel(TypedDict):
        a: str
        b: str

    class MySchema(ma.Schema):
        a = ma.fields.Str()
        b = ma.fields.Str()

    MyModel = _MyModel
    schema = MySchema()

    """
    Tests if the original handle_to_dict produces the same result as the original one.
    """
    obj = {"a": "a", "b": "b"}
    kvs = {"a": "a", "b": "b"}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)

# Generated at 2022-06-11 21:14:21.451040
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        value: str
        catch_all: CatchAll

        def __init__(self, **kwargs):
            dataclasses.dataclass_init(self, kwargs)

    assert TestClass(value="1", catch_all={}).value == "1"
    assert TestClass(value="1", catch_all={}).catch_all == {}

    assert TestClass(value="1", catch_all={},
                     key="2").value == "1"
    assert TestClass(value="1", catch_all={},
                     key="2").catch_all == {"key": "2"}
    assert TestClass(value="1", key="2",
                     catch_all={}).value == "1"

# Generated at 2022-06-11 21:14:26.188876
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    schema = Schema.of(TestDataClass, unknown=Undefined.INCLUDE)
    tdc = TestDataClass(a="a", catch_all={"b": "b"})
    dump = schema.dump(tdc)
    assert dump["catch_all"]["b"] == "b"



# Generated at 2022-06-11 21:14:35.330614
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class _TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

        def asdict(self):
            return _UndefinedParameterAction.handle_to_dict(self,
                                                            {'catch_all':
                                                                 self.catch_all})

    test_obj = _TestClass()
    assert test_obj.asdict() == {}

    test_obj = _TestClass(catch_all={'a': 'b'})
    assert test_obj.asdict() == {'a': 'b'}

# Generated at 2022-06-11 21:14:48.867955
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config, LetterCase
    from dataclasses_json.utils import CatchAllVar

    config.undefined = Undefined.INCLUDE

    # noinspection SpellCheckingInspection
    @dataclass
    class Student:
        first_name: str
        last_name: str
        catch_all: Optional[CatchAllVar] = {}
        age: int = 18
        gender: str = "male"

        def __post_init__(self):
            print("post_init")

    assert hasattr(Student, "__init__")
    Student(first_name="Foo", last_name="Bar", age=13, gender="female",
            catch_all="",
            PostInitValue=7,
            pre_init_value=None)

# Generated at 2022-06-11 21:14:49.913653
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-11 21:15:01.628415
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int
        h: int

    def func(self, a, b, c, d, e, f, g, h):
        pass

    # For signature of this function, the first is arg is self
    # and the last two are the variable arguments *args and **kwargs
    my_func_sig = inspect.signature(func)
    my_func = _IgnoreUndefinedParameters.create_init(A)
    my_func_sig_created = inspect.signature(my_func)
    assert my_func_sig == my_func_sig_created

# Generated at 2022-06-11 21:15:09.503452
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass, field

    @dataclass
    class CatchAllTest:
        a: str
        b: str
        c: CatchAll = field(default_factory=dict)

    kvs = {
        "a": "a_value",
        "b": "b_value",
        "c": CatchAll({"a": "a_value"})
    }
    obj = CatchAllTest(**kvs)
    assert kvs == _CatchAllUndefinedParameters.handle_to_dict(obj, kvs.copy())