

# Generated at 2022-06-11 21:05:43.170424
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # check subclasses
    assert isinstance(_RaiseUndefinedParameters, _UndefinedParameterAction)
    assert issubclass(_CatchAllUndefinedParameters, _UndefinedParameterAction)

    # check defaults
    init = _UndefinedParameterAction.create_init(int)
    assert hasattr(init, "__wrapped__")
    assert init.__wrapped__ == int.__init__

    # check wrapping
    class Dummy_CatchAllUndefinedParameters:
        pass

    dummy_field = Field(CatchAllVar, CatchAllVar)
    Dummy_CatchAllUndefinedParameters.dummy_field = dummy_field
    Dummy_CatchAllUndefinedParameters.__init__ = lambda self, a, b, c=0: None

    # noinspection PyProtectedMember
    init = \
        _Undefined

# Generated at 2022-06-11 21:05:56.284872
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import os
    import tempfile
    from dataclasses import dataclass
    import dataclasses_json

    @dataclass
    class SomeClass(_UndefinedParameterAction):
        i: int

    obj = SomeClass(i=12)

    # Make sure we're working with a new path
    dirname = tempfile.mkdtemp()
    full_path = os.path.join(dirname, "test.json")

    # Store object
    dataclasses_json.dump(obj, full_path)

    # Retrieve object, this should raise an error
    try:
        obj2 = dataclasses_json.load(full_path, SomeClass)
        assert False
    except UndefinedParameterError:
        assert True

    # Now try with a class with a validated init

# Generated at 2022-06-11 21:06:01.946262
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dummy_cls = type('Dummy', (object,), {"attr1": 5})
    dummy_instance = dummy_cls()
    dummy_instance.attr2 = 23
    dump1 = _UndefinedParameterAction.handle_dump(dummy_instance)
    dump2 = _CatchAllUndefinedParameters.handle_dump(dummy_instance)
    assert dump1 == {}
    assert dump2 == {"attr2": 23}



# Generated at 2022-06-11 21:06:03.702903
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-11 21:06:15.444271
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class Test1:
        field1: Any

    # Check that that the undefined parameters are handled and removed
    assert Test1.__init__.__annotations__ == {"field1": Any}
    assert Test1.__dataclass_fields__.get("field1").type == Any
    assert _CatchAllUndefinedParameters.handle_from_dict(
        Test1, {"field1": 1, "undefined_field": 2}) == {"field1": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        Test1, {"field1": 1, "undefined_field": 2}) == {"field1": 1}

# Generated at 2022-06-11 21:06:18.126697
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Test that no exception is raised
    kvs = {"field1": 1, "field2": 2}
    _UndefinedParameterAction.handle_to_dict(object, kvs)

# Generated at 2022-06-11 21:06:28.167848
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses_json import dataclass_json, config
    @dataclass_json()
    class TestClass:
        test_1: float
        test_2: float
        test_3: float = 3.0

    result = _UndefinedParameterAction.handle_to_dict(
        obj=TestClass, kvs={"test_1": 1.0, "test_2": 2.0, "test_3": 3.0})
    assert result == {"test_1": 1.0, "test_2": 2.0, "test_3": 3.0}



# Generated at 2022-06-11 21:06:28.570842
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-11 21:06:34.050971
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a, b=None, c=None):
            pass

    def assert_instantiation_succeeds(function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except TypeError:
            raise AssertionError(
                f"Instantiation failed with arguments {args} {kwargs}")

    def assert_instantiation_fails(function, *args, **kwargs):
        try:
            function(*args, **kwargs)
            raise AssertionError("Instantiation did not fail.")
        except TypeError:
            pass

    def test_a(*, a: int, b: int, c: int, catch_all: CatchAll = None):
        pass


# Generated at 2022-06-11 21:06:42.155960
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: Optional[CatchAllVar] = None
        b: int = 1
        c: Optional[str] = None

        def __init__(self, a: Dict[Any, Any], b: int,
                     c: Optional[str] = None):
            pass

    expected_args = {"a": {}, "b": 1, "c": None}
    init = _CatchAllUndefinedParameters.create_init(Test)

    init(Test, **expected_args)
    init(Test, 1, **expected_args)

# Generated at 2022-06-11 21:07:05.670528
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import marshmallow
    import dataclasses_json

    class ClassToTest(metaclass=dataclasses_json.LetterCaseMeta):

        class Undefined(Enum):
            INCLUDE = dataclasses_json.Undefined.INCLUDE

        def __init__(self, a: int, b: str, c: int, c2: int,
                     catch_all: dataclasses_json.CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.c2 = c2

        @classmethod
        def schema(cls) -> 'ClassToTestSchema':
            return ClassToTestSchema

    class ClassToTestSchema(marshmallow.Schema):
        a = marshmallow.fields.Integer()

# Generated at 2022-06-11 21:07:13.882021
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from datetime import datetime

    from .dataclass_encoder import (
        dataclass_encoder, LetterCase)

    @dataclass_encoder(undefined=Undefined.INCLUDE,
                       letter_case=LetterCase.CAMEL)
    @dataclasses.dataclass
    class Example:
        name: str
        birth_date: datetime
        catch_all: Optional[CatchAllVar] = None

        def __post_init__(self):
            self.name = self.name.upper()

    example_data = {
        "name": "max",
        "birthDate": "21.12.1987",
        "catchAll": {
            "foo": 1,
            "bar": "baz"
        }
    }

    example = Example(**example_data)

# Generated at 2022-06-11 21:07:26.932893
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            pass
    init_a_with_catch_all = _CatchAllUndefinedParameters.create_init(A)
    init_a_with_catch_all(A, 1, 2, 3, 4, c={"a", "b"})

    def init_a_without_catch_all(self, a: int, b: int):
        pass

    init_a_without_catch_all = _CatchAllUndefinedParameters.create_init(
        A)
    init_a_without_catch_all(A, 1, 2, 3, 4, c={"a", "b"})


# Unit tests for method separate_defined_undefined_kvs

# Generated at 2022-06-11 21:07:33.656235
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestCase:
        known: str

    class_under_test = _RaiseUndefinedParameters

    tests = [
        # unknown_parameters,
        ({"known": "foo", "undefined": "test"}, {"known": "foo"}),
        ({"known": "foo"}, {"known": "foo"}),
        ({"unknown": "test"}, {}),
        ({}, {})
    ]

    for test, expected_result in tests:
        assert class_under_test.handle_from_dict(TestCase, test) == \
               expected_result



# Generated at 2022-06-11 21:07:44.462143
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    DUMMY_DICT = {"a_field": "dummy"}

    @dataclasses.dataclass
    class DummyClass:
        _UNKNOWN_PARAMS: CatchAll

    @dataclasses.dataclass
    class DummyClass1:
        _UNKNOWN_PARAMS: CatchAll = dataclasses.field(default_factory=dict)

    @dataclasses.dataclass
    class DummyClass2:
        _UNKNOWN_PARAMS: CatchAll = dataclasses.field(default=DUMMY_DICT)

    @dataclasses.dataclass
    class DummyClass3:
        _UNKNOWN_PARAMS: CatchAll = dataclasses.field(default=DUMMY_DICT)
        a_field: str


# Generated at 2022-06-11 21:07:54.112771
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import dataclasses
    import dataclasses_json

    # noinspection PyDataclass
    @dataclasses.dataclass(frozen=True)
    class MyClass:
        field: str = dataclasses.field(repr=True, compare=True,
                                       metadata=dataclasses_json.config(
                                           undefined=Undefined.RAISE))

    # noinspection PyArgumentList
    my_class = MyClass()

    try:
        # noinspection PyArgumentList
        # noinspection PyTypeChecker
        MyClass(field="foo", undefined="bar")
    except UndefinedParameterError:
        pass
    else:
        assert False, "Expecting UndefinedParameterError"



# Generated at 2022-06-11 21:08:04.065397
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field


    @dataclass
    class _TestClass:
        first_name: str = field(metadata={"default": "John"})
        last_name: str = field(metadata={"default": "Doe"})
        age: int = field(metadata={"default": 0})
        undefined: Optional[CatchAllVar] = None


    defined_parameters, undefined_parameters = _CatchAllUndefinedParameters \
        ._separate_defined_undefined_kvs(_TestClass,
                                          {'first_name': 'John',
                                           'last_name': 'Doe',
                                           'age': 23,
                                           'height': 175})

# Generated at 2022-06-11 21:08:06.663277
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    ret_val = _UndefinedParameterAction.handle_dump({})
    assert ret_val == {}

# Generated at 2022-06-11 21:08:11.872674
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, parameter1: str, parameter2: int,
                     catch_all: CatchAll = None):
            pass

    _CatchAllUndefinedParameters.create_init(TestClass)()

# Generated at 2022-06-11 21:08:14.575056
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    Dummy = dataclasses.dataclass(
        frozen=True, order=True,
        init=_IgnoreUndefinedParameters.create_init(Dummy))
    pass

# Generated at 2022-06-11 21:08:44.691442
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from typing import Optional

    assert _CatchAllUndefinedParameters._SentinelNoDefault

    class Fixture:
        def __init__(self, x: int, y: int, z: int,
                     a: Optional[int] = None,
                     b: Optional[CatchAllVar] = None):
            self.x = x
            self.y = y
            self.z = z
            self.a = a
            self.b = b

        def __eq__(self, other):
            return self.x == other.x and \
                   self.y == other.y and \
                   self.z == other.z and \
                   self.a == other.a and \
                   self.b == other.b


# Generated at 2022-06-11 21:08:54.162804
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: str = "a"
        b: str = "b"

    kvs_1 = {"a": "b", "c": "d"}
    kvs_2 = {"a": "b"}

    action = _RaiseUndefinedParameters
    for kvs in [kvs_1, kvs_2]:
        assert action.handle_from_dict(Foo, kvs) == kvs_2

    kvs = {"a": "b", "c": "d", "d": "e"}
    try:
        action.handle_from_dict(Foo, kvs)
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:08:59.565073
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a):
            pass

    TestClass(a=1)
    try:
        TestClass(a=1, b="foo")
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:09:09.339213
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self,
                     a: str,
                     b: str,
                     c: str,
                     d: Optional[CatchAllVar] = None):
            pass

    @dataclasses.dataclass
    class D:
        a: str
        b: str
        c: str
        d: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: {})


# Generated at 2022-06-11 21:09:14.069313
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a: str, b: str):
            pass
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test,
                                                   {"a": "a", "b": "b", "c": 3})



# Generated at 2022-06-11 21:09:21.562075
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass():
        defined1: int
        defined2: int

        def __init__(self, *args, **kwargs):
            pass

    test_class_instance = TestClass(1, 1, a=1)
    catch_all_init = _CatchAllUndefinedParameters.create_init(
        test_class_instance)
    catch_all_init(test_class_instance, "1", 1, 1, a=1)

# Generated at 2022-06-11 21:09:30.164564
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(
        undefined=Undefined.INCLUDE)
    class MyClass:
        a: int
        b: str
        c: Optional[CatchAll] = dataclasses.field(default=None)

    # All parameters defined and an empty catch-all:
    kvs = {"a": 42, "b": "hello"}
    converted_kvs = _CatchAllUndefinedParameters.handle_from_dict(MyClass, kvs)
    assert set(converted_kvs) == {"a", "b", "c"}
    assert converted_kvs["a"] == 42
    assert converted_kvs["b"] == "hello"
    assert isinstance(converted_kvs["c"], dict)
    assert len(converted_kvs["c"]) == 0

    # All parameters

# Generated at 2022-06-11 21:09:39.679533
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert (_UndefinedParameterAction.handle_to_dict({}, {}) == {})
    assert (_UndefinedParameterAction.handle_to_dict({"a": 1}, {}) == {})
    assert (_UndefinedParameterAction.handle_to_dict({}, {"a": 1}) ==
            {"a": 1})
    assert (_UndefinedParameterAction.handle_to_dict({"a": 1}, {"a": 1}) ==
            {"a": 1})
    assert (_UndefinedParameterAction.handle_to_dict({"a": 1}, {"b": 1}) ==
            {"a": 1, "b": 1})



# Generated at 2022-06-11 21:09:42.385623
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    input = {}
    expected_output = {}
    actual_output = _UndefinedParameterAction.handle_dump(input)
    assert actual_output == expected_output

# Generated at 2022-06-11 21:09:53.824944
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        field_1: str = "default_1"
        field_2: Any = "default_2"

    class DummyClassExclude:
        field_1: str = "default_1"
        field_2: Any = "default_2"

        @dataclasses.dataclass_json(undefined=Undefined.EXCLUDE)
        class _Config:
            pass

    class DummyClassInclude:
        field_1: str = "default_1"
        field_2: Any = "default_2"
        catch_all: CatchAll = dataclasses.field(metadata={"marshmallow_field": {"load_from": "catch_all"}})


# Generated at 2022-06-11 21:10:52.049606
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, x: int, y: int, z: int = 1):
            pass

    test_input = {"x": 4, "y": 3, "z": 2, "t": 3}
    expected_output = {"x": 4, "y": 3, "z": 2}
    actual_output = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, test_input)
    assert actual_output == expected_output



# Generated at 2022-06-11 21:11:02.334083
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from marshmallow import Schema, fields

    @dataclasses.dataclass
    class A(_UndefinedParameterAction):
        a: str
        b: int
        c: int

        __init__ = _UndefinedParameterAction.create_init(A)

    assert A(a='a', b=5).c == dataclasses.MISSING
    assert A(a='a', b=5, c=3).c == 3
    assert A(a='a', b=5, c=3, d=5).c == 3

    assert A(1, 2, 3).__init__ is not A.__init__

    class ASchema(Schema):
        a = fields.Str()
        b = fields.Int()
        c = fields.Int(missing=5)


# Generated at 2022-06-11 21:11:14.131378
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        field1: str = dataclasses.field(metadata={"required": True})
        field2: str = "Hallo"
        field3: int = dataclasses.field(metadata={"required": True})
        field4: CatchAll = dataclasses.field(default_factory=dict)

    # test undefined field
    test_kvs = {"field1": "bla", "undefined": "blubb"}
    try:
        _UndefinedParameterAction.handle_from_dict(TestClass, test_kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False, "Expected an undefined parameter error."

    # test catch all field

# Generated at 2022-06-11 21:11:22.530012
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def fake_constructor(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    # noinspection PyUnusedLocal
    class FakeClass:
        def __init__(self, **kwargs):
            pass

        def not_constructor(self):
            pass

    class FakeClass2:
        def __init__(self, **kwargs):
            pass

        # noinspection PyRedundantParentheses, PyMethodMayBeStatic
        def __init__(self, *args):
            pass

        def not_constructor(self):
            pass

    class FakeClass3:
        def __init__(self, **kwargs):
            pass

        def not_constructor(self):
            pass

    assert _UndefinedParameterAction.handle_dump

# Generated at 2022-06-11 21:11:26.977580
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self):
            self.foo = "foo"

    obj = TestClass()
    kvs = {"foo": "foo"}
    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert result == kvs


# Generated at 2022-06-11 21:11:34.071037
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.api import configure_dataclass, dataclass_json

    class Thingy:
        pass

    @dataclass_json
    @configure_dataclass(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass(frozen=True)
    class ThingyWithCatchAll:
        a: int
        b: int
        c: int = 1
        d: str = "str"
        e: Optional[str] = "str"
        f: Optional[Thingy] = Thingy
        g: CatchAll = None

    @dataclass_json
    @configure_dataclass(undefined=Undefined.RAISE)
    @dataclasses.dataclass(frozen=True)
    class ThingyWithRaise:
        a

# Generated at 2022-06-11 21:11:45.929011
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect

    @dataclasses.dataclass(init=True, repr=True,
                           undefined=_IgnoreUndefinedParameters)
    class A:
        a: int
        b: str

    cls = A
    init = inspect.getsource(cls.__init__)
    assert " *args, **kwargs):\n" in init

# Generated at 2022-06-11 21:11:54.744778
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import typing
    import unittest

    """
    This tests the method handle_from_dict of the class
    _CatchAllUndefinedParameters.
    """

    # All test cases are contained here

# Generated at 2022-06-11 21:12:05.795139
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass


    @dataclass
    class Test:
        a: int
        b: str = "default"

        def __init__(self, a: int, b: str = "default"):
            self.a = a
            self.b = b


    Test.__init__ = _IgnoreUndefinedParameters.create_init(Test)

    def assert_resulting_object(obj):
        assert obj.a == 1
        assert obj.b == "default"

    def assert_resulting_object_with_kwargs(obj):
        assert obj.a == 1
        assert obj.b == "b"

    test = Test(a=1)
    assert_resulting_object(test)

    test = Test(a=1, b="b")
    assert_resulting_

# Generated at 2022-06-11 21:12:15.729421
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: Optional[int] = None

    class_fields = list(filter(lambda f: f.name in ["a", "b"],
                               fields(MyClass)))

    def _make_kvs_dict() -> Dict[str, Any]:
        kvs = dict()
        for field in class_fields:
            name = field.name
            value = getattr(MyClass, name)
            kvs[name] = value
        return kvs

    kvs = _make_kvs_dict()
    expected_known_parameters, expected_unknown_parameters = dict(
        a=MyClass.a), dict(b=MyClass.b)
    known_parameters, unknown_parameters = \
        _IgnoreUndefinedParameters

# Generated at 2022-06-11 21:14:39.144177
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: int
        _undefined: Optional[CatchAllVar]

    undefined_arguments = {
        "test": "test",
        "test2": "test2"
    }

    test_object_with_catch_all = TestClass(a="a", b="b", c=1,
                                           _undefined=undefined_arguments)
    test_object_without_catch_all = TestClass(a="a", b="b", c=1,
                                              _undefined=None)


# Generated at 2022-06-11 21:14:48.687459
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:

        def __init__(self, a: str, b: str, c: str):
            pass

    kvs = {"a": "a", "b": "b", "c": "c", "d": "d"}
    known, unknown = _IgnoreUndefinedParameters \
        ._separate_defined_undefined_kvs(cls=TestClass, kvs=kvs)
    assert known == {"a": "a", "b": "b", "c": "c"}
    assert unknown == {"d": "d"}



# Generated at 2022-06-11 21:15:01.005048
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass(frozen=True)
    class FrozenWithCatchAll:
        x: int
        y: int
        z: int = dataclasses.field(default=3)
        catch_all: Optional[CatchAllVar] = None

    @dataclasses.dataclass(frozen=True)
    class FrozenWithoutCatchAll:
        x: int
        y: int
        z: int = dataclasses.field(default=3)

    @dataclasses.dataclass
    class WithCatchAll:
        x: int
        y: int
        z: int = 3
        catch_all: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class WithoutCatchAll:
        x: int

# Generated at 2022-06-11 21:15:13.159713
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        field: str
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, field: str, catch_all: Optional[CatchAllVar] = None):
            self.field = field
            self.catch_all = catch_all

    # noinspection PyProtectedMember
    assert Test("field").__dict__ == Test("field", {}).__dict__
    assert Test("field", {"a": 1}).catch_all == {"a": 1}
    assert Test("field", catch_all={"a": 1}).catch_all == {"a": 1}

    with pytest.raises(UndefinedParameterError):
        Test("field", {"a": 1, "b": 2})
