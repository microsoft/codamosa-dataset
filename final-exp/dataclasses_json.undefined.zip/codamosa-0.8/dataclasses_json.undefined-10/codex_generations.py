

# Generated at 2022-06-11 21:05:38.516143
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Test:
        def __init__(self):
            self.a = 0
            self.b = 0

    assert _UndefinedParameterAction.handle_dump(Test()) == {}

# Generated at 2022-06-11 21:05:49.398454
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    assert _IgnoreUndefinedParameters.handle_from_dict(None, {"b": 1, "c": 2}) == {"b":1, "c": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(None, {"a": 1, "b": 2}) == {"a":1, "b": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(None, {"a": 1, "b": 2, "c": 3}) == {"a":1, "b": 2, "c": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(None, {"b": 1, "c": 2, "d": 4}) == {"b": 1, "c": 2, "d": 4}

# Generated at 2022-06-11 21:06:01.910639
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Class:
        @property
        def a(self) -> int:
            pass

        @property
        def b(self) -> int:
            pass

    obj = Class()
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    class _DummyUndefinedAction(_UndefinedParameterAction):
        @staticmethod
        def handle_to_dict(obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            return {"d": kvs.pop("d"), "b": kvs.pop("b")}

    # test _UndefinedParameterAction.handle_to_dict

# Generated at 2022-06-11 21:06:03.093733
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("abc")

# Generated at 2022-06-11 21:06:15.037545
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from .utils import CatchAllVar
    import dataclasses
    from typing import Optional

    @dataclasses.dataclass
    class DummyClass:
        a: int
        b: int
        c: str
        d: Optional[CatchAllVar]
        __UNDEFINED__: Undefined = Undefined.INCLUDE

        def __init__(self, a: int, b: int, c: str, d: dict = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d


    dummy_class = DummyClass(1, 2, "c", dict(d="d", e="e"))

    actual = _CatchAllUndefinedParameters.create_init(DummyClass)

# Generated at 2022-06-11 21:06:15.971812
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test")

# Generated at 2022-06-11 21:06:28.523255
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    ######################################################################
    # Tests are based on following schema:
    #
    #   @dataclass
    #   class Example(Object):
    #       a: str
    #       b: str
    #       c: str
    #       d: str
    #
    #   Schema:
    #   {
    #     "a": "a",
    #     "b": "b",
    #     "c": "c",
    #     "d": "d"
    #   }


    @dataclass
    class Example:
        a: str
        b: str
        c: str
        d: str


    init_signature = inspect.signature(Example.__init__)

    no_args_cases = [{}, {}, {}, {}]
    one_args_cases

# Generated at 2022-06-11 21:06:33.992479
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # noinspection PyProtectedMember
    import dataclasses
    import dataclasses_json.undefined

    class TestClass:
        def __init__(self):
            self._catch_all = {}

        @property
        def _catch_all(self) -> dataclasses_json.undefined.CatchAll:
            return self.__catch_all

        @_catch_all.setter
        def _catch_all(self, value: dataclasses_json.undefined.CatchAll):
            self.__catch_all = value

    TestClass = dataclasses.dataclass(frozen=True)(TestClass)

    test_class = TestClass()

    action = dataclasses_json.undefined.Undefined.INCLUDE.value


# Generated at 2022-06-11 21:06:42.897751
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b=None, *, c=None, **kwargs):
            pass

    created_init = _CatchAllUndefinedParameters.create_init(Test)
    assert Test.__init__ != created_init
    created_init(Test(1, 2, 3, c=3, d=4, e=5))  # Tests args
    created_init(Test(1, b=2, c=3, d=4, e=5))  # Tests kwargs
    created_init(Test(1, b=2, c=3, d=4, e=5, a=9))  # Tests args and kwargs

# Generated at 2022-06-11 21:06:55.076526
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class B:
        def __init__(self, a: int = 0, b: int = 1, c: int = 2):
            self.a = a
            self.b = b
            self.c = c

    class C:
        def __init__(self, a: int, b: int = 1, c: int = 2):
            self.a = a
            self.b = b
            self.c = c

    class D:
        def __init__(self, a: int = 0, b: int = 1, c: int = 2,
                     **kwargs: Any):
            self.a = a
            self.b = b


# Generated at 2022-06-11 21:07:14.933476
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class MissingField:
        pass

    class Foo:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
        def __eq__(self, other):
            return (isinstance(other, Foo) and self.a == other.a
                    and self.b == other.b and self.c == other.c
                    and self.d == other.d)

    @dataclasses.dataclass
    class Bar:
        a: int
        b: int
        c: int
        d: int

    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: Optional[int]
        d: int



# Generated at 2022-06-11 21:07:21.104958
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, x: int):
            self.x = x

    kvs = {"x": 1, "y": 2}
    params = _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)
    assert params == {"x": 1}



# Generated at 2022-06-11 21:07:31.660558
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        def __init__(self, a: int, b: int, c: int):
            pass

    assert _UndefinedParameterAction.handle_from_dict(cls=Test, kvs={}) == {}
    assert _UndefinedParameterAction.handle_from_dict(cls=Test, kvs={"a": 1}) \
           == {"a": 1}
    assert _UndefinedParameterAction.handle_from_dict(cls=Test, kvs={"a": 1,
                                                                      "b": 1}) \
           == {"a": 1, "b": 1}

# Generated at 2022-06-11 21:07:42.235322
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import marshmallow_dataclass

    @dataclasses.dataclass(
        init=True,
        repr=False,
        eq=True,
        frozen=False,
        order=False,
        unsafe_hash=False)
    class ExampleClass:
        field1: str
        field2: int
        _catch_all: Optional[CatchAllVar] = \
            dataclasses.field(
                repr=False,
                default=dataclasses.field(
                    init=True,
                    default=None)
            )

    obj = ExampleClass("foo", 1, {"field3": "bar", "field4": 2})
    result = _CatchAllUndefinedParameters.handle_dump(obj)
    assert result == {"field3": "bar", "field4": 2}

# Generated at 2022-06-11 21:07:43.133426
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test error")

# Generated at 2022-06-11 21:07:50.635335
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def create_init(cls) -> Callable:
        return _CatchAllUndefinedParameters.create_init(cls)


    @dataclasses.dataclass
    class _TestClass1:
        x: Optional[int] = None  # noqa

        def __init__(self, x: int = 4):
            self.x = x


    @dataclasses.dataclass
    class _TestClass2:
        x: Optional[int] = None
        y: Optional[int] = None

        def __init__(self, *args, x: int = None, **kwargs):
            self.x = x
            self.y = kwargs.get("y", "3")



# Generated at 2022-06-11 21:08:02.638639
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import inspect
    from dataclasses_json.config import Mapper

    @dataclasses.dataclass(frozen=True)
    class X:
        x: str

    init_signature = inspect.signature(X.__init__)
    init_signature_params = list(init_signature.parameters.values())
    assert len(init_signature_params) == 2

    assert init_signature_params[0].kind == inspect.Parameter.VAR_POSITIONAL
    assert init_signature_params[1].kind == inspect.Parameter.VAR_KEYWORD
    assert init_signature_params[0].name == "self"
    assert init_signature_params[1].name == "kwargs"

    def validate_signature_equals(new_init):
        new_init_

# Generated at 2022-06-11 21:08:11.758611
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Test input
    obj = "object"
    kvs = {"key_1": "val_1", "key_2": "val_2"}

    # Expected result
    expected_result = {"key_1": "val_1", "key_2": "val_2"}

    # Actual result
    actual_result = _UndefinedParameterAction.handle_to_dict(obj, kvs)

    # Test
    assert actual_result == expected_result


# Generated at 2022-06-11 21:08:22.659135
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_function(some_arg: str, some_kwarg: str = "default"):
        return (some_arg, some_kwarg)

    init_function = _IgnoreUndefinedParameters.create_init(test_function)
    assert init_function(None, "argument") == ("argument", "default")
    assert init_function(None, "argument", "kwarg") == ("argument", "kwarg")
    # mypy gives false positive error here
    assert init_function(None, "argument", some_kwarg="kwarg") == (
        "argument", "kwarg")
    assert init_function(None, "argument", some_kwarg="kwarg") == (
        "argument", "kwarg")

# Generated at 2022-06-11 21:08:30.522042
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # type: () -> None
    class TestClass:
        def __init__(self, a: int = 0, b: int = 0):
            self.a = a
            self.b = b

    obj = TestClass(a=0, b=1)
    kvs = {'a': 0, 'b': 1, 'c': 2}

    action = _UndefinedParameterAction()
    assert {'a': 0, 'b': 1} == action.handle_to_dict(obj, kvs)

# Generated at 2022-06-11 21:08:56.059270
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-11 21:09:07.745879
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: int, _UNKNOWN: CatchAll = None):
            self.a = a
            self.b = b
            self._UNKNOWN = _UNKNOWN


    instance = TestClass(a = "hallo", b = 42, c = "foo", d = "bar")

    kvs = {
        "a": "hallo",
        "b": 42,
        "_UNKNOWN": {"c": "foo", "d": "bar"}
    }

    assert _CatchAllUndefinedParameters.handle_to_dict(obj=TestClass,
                                                       kvs=kvs) == {"a": "hallo", "b": 42, "c": "foo", "d": "bar"}

# Generated at 2022-06-11 21:09:15.943755
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Example:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    e = Example(a=1, b=2, c={"my_key": "my_value"})

    assert e.c == {}
    assert e == Example(a=1, b=2, c={"my_key": "my_value"})
    assert e == Example(1, 2, {"my_key": "my_value"})
    assert e == Example(1, 2, my_key="my_value")

# Generated at 2022-06-11 21:09:27.080504
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from marshmallow import fields
    from string import ascii_lowercase as lowercase

    @dataclasses.dataclass
    class TestClass(object):
        a: str
        b: int
        c: float
        d: List[str]
        e: str = dataclasses.field(default="default")
        f: Optional[str] = None
        g: Dict[str, str] = dataclasses.field(
            default_factory=dict)
        h: int = dataclasses.field(
            default=2, metadata={"marshmallow_field": fields.Int()})
        i: Optional[CatchAllVar] = dataclasses.field(
            default=None)

        def __init__(self, a, b, c, d):
            self.a = a
            self.b

# Generated at 2022-06-11 21:09:39.059425
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class CatchAllTest:
        param1: str
        param2: int = 3
        param3: CatchAll = None

    known_1, unknown_1 = _CatchAllUndefinedParameters.handle_from_dict(
        CatchAllTest, {"param1": "...."})
    assert known_1 == {"param1": "....", "param2": 3, "param3": {"param1": "...."}}
    assert unknown_1 == {}

    known_2, unknown_2 = _CatchAllUndefinedParameters.handle_from_dict(
        CatchAllTest, {"param1": "....", "param3": {"param4": "...."}})
    assert known_2 == {"param1": "....", "param2": 3, "param3": {"param4": "...."}}

# Generated at 2022-06-11 21:09:48.144458
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def __eq__(self, other):
            return type(self) == type(other) and self.a == other.a and self.b == \
            other.b


    class D:
        def __init__(self, a, b, **unknown):
            self.a = a
            self.b = b
            self.unknown = unknown

        def __eq__(self, other):
            return type(self) == type(other) and self.a == other.a and self.b == \
            other.b and self.unknown == other.unknown


# Generated at 2022-06-11 21:09:56.848427
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass

    @dataclass(undefined=Undefined.INCLUDE)
    class Test:
        a: str
        b: str = "default"
        c: str

    t = Test(a="a", c="c", d="d", e="e")

    assert t.d == "d"
    assert t.e == "e"


# Generated at 2022-06-11 21:10:02.844782
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: str

    cls = A
    init = Undefined.EXCLUDE.value.create_init(cls)
    instance = init("bla", _UNKNOWN1=1, _UNKNOWN2=2)

    assert instance.a == "bla"



# Generated at 2022-06-11 21:10:04.712006
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
  test = UndefinedParameterError()
  assert str(test) == "Unknown undefined parameter error"


# Generated at 2022-06-11 21:10:16.778382
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test the handling of undefined parameters by
    mappings.Undefined.INCLUDE.handle_from_dict
    """
    def _compare_known_unknown_parameters(cls,
                                          passed_parameters: KnownParameters,
                                          expected_known: KnownParameters,
                                          expected_unknown: UnknownParameters
                                          ):
        result_known, result_unknown = \
            _CatchAllUndefinedParameters.handle_from_dict(cls,
                                                          passed_parameters)
        assert result_known == expected_known
        assert result_unknown == expected_unknown

    class SimpleClass:
        def __init__(self, param0, param1=None, param2=None):
            self.param0 = param0
            self.param1 = param1
            self.param2

# Generated at 2022-06-11 21:11:15.305179
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("x")

# Generated at 2022-06-11 21:11:21.922344
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        ignore: int

    input_dictionary = {"ignore": 2, "ignore_not": 3}
    parameter_list = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, input_dictionary
    )
    assert parameter_list == {"ignore": 2}

    input_dictionary = {"ignore": 2}
    parameter_list = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, input_dictionary
    )
    assert parameter_list == {"ignore": 2}



# Generated at 2022-06-11 21:11:31.164327
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from typing import Dict, Optional

    class DummyTestedClass:
        def __init__(self, a: int, b: int, c: int, d: str = "default"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    old_init = DummyTestedClass.__init__
    cls = DummyTestedClass

    new_init = _UndefinedParameterAction.create_init(obj=cls)
    assert new_init is not old_init

    new_inst: DummyTestedClass = new_init(1, 2, 3)
    assert new_inst.a == 1
    assert new_inst.b == 2
    assert new_inst.c == 3
    assert new_inst.d == "default"

    new_

# Generated at 2022-06-11 21:11:38.677789
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class First:
        def __init__(self, first_element) -> None:
            self.first_element = first_element

    class Second:
        def __init__(self, second_element) -> None:
            self.second_element = second_element

    class Third:
        def __init__(self, third_element) -> None:
            self.third_element = third_element

    class Fourth:
        def __init__(self, fourth_element) -> None:
            self.fourth_element = fourth_element

    class Fifth:
        def __init__(self, fifth_element) -> None:
            self.fifth_element = fifth_element

    assert _UndefinedParameterAction.handle_to_dict(First(1), {}) == {}

# Generated at 2022-06-11 21:11:47.849556
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    def current_test(obj, expected_result):
        actual_result = _CatchAllUndefinedParameters.handle_dump(obj)
        assert actual_result == expected_result

    class A:
        def __init__(self, a: str = "a", catch_all: CatchAll = None):
            self.a = a
            self.catch_all = catch_all

    current_test(A(a="a", catch_all={"b": "b"}), {"b": "b"})

    class B:
        def __init__(self, b: str = "b", catch_all: CatchAll = {}):
            self.b = b
            self.catch_all = catch_all

    current_test(B(b="b", catch_all={"c": "c"}), {"c": "c"})

# Generated at 2022-06-11 21:11:55.908337
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b="abc", c: int = 3):
            pass

    def equal(a, b):
        assert (a == b)

    equal(_IgnoreUndefinedParameters.handle_from_dict(TestClass, {'a': 1,
                                                                  'b': "def"}),
          {'a': 1, 'b': "def"})

    equal(_IgnoreUndefinedParameters.handle_from_dict(TestClass, {'a': 1,
                                                                  'c': 3.0}),
          {'a': 1, 'c': 3.0})


# Generated at 2022-06-11 21:12:06.257639
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Test:
        first: str
        second: str
        third: str = dataclasses.field(default=None, init=False)
        # noinspection PyArgumentList
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

    # The original init takes 3 positional arguments.
    # The create_init function generated another init function which takes
    # arbitrary arguments and keyword arguments and then separates
    # the known arguments and keyword arguments from the unknown ones.
    # The unknown ones must be passed to catch_all.

    # Testing behavior when only known arguments are passed
    t1 = Test("first", "second")
    assert t1.first == "first"
    assert t1.second == "second"
   

# Generated at 2022-06-11 21:12:15.994679
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # type: (...) -> None
    class Foo:
        def __init__(self, a, b):
            self._a = a
            self._b = b

    class Bar(Foo):
        def __init__(self, a, b, c):
            super().__init__(a, b)
            self._c = c

    # Check with optional fields
    arg_dict = {
        'a': 0,
        'b': 1
    }
    assert _RaiseUndefinedParameters.handle_from_dict(Foo, arg_dict) == arg_dict

    # Check with mandatory fields
    arg_dict = {
        'a': 0,
        'b': 1,
        'c': 2
    }

# Generated at 2022-06-11 21:12:27.430284
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # noinspection PyUnresolvedReferences
    from dataclasses_json.core import UndefinedParameterError

    @dataclasses.dataclass
    class TestClass:
        x: float
        y: float
        z: Optional[str]

    # Test that valid parameters are returned
    assert TestClass.__init__.__annotations__ == {"x": float,
                                                  "y": float,
                                                  "z": Optional[str]}
    assert _RaiseUndefinedParameters.handle_from_dict(
        TestClass, {"x": 2.0, "y": 5.0, "z": None}) == {"x": 2.0, "y": 5.0,
                                                         "z": None}

    # Test that invalid parameters raise an error
    with pytest.raises(UndefinedParameterError):
        _

# Generated at 2022-06-11 21:12:36.769665
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass(frozen=True)
    class Test:
        a: int
        b: int

    known, undefined = _UndefinedParameterAction.handle_from_dict(
        Test, {"a": 4, "b": 4, "c": 5})
    assert len(undefined) == 1
    assert len(known) == 2
    assert known["a"] == 4
    assert known["b"] == 4
    assert undefined["c"] == 5

    try:
        _UndefinedParameterAction.handle_from_dict(Test, {"a": 4, "c": 5})
    except UndefinedParameterError:
        pass
    else:
        assert False, "Should have received an exception."



# Generated at 2022-06-11 21:14:54.139433
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass, fields
    from unittest import mock, TestCase

    from .convert import _get_class_by_name, _process_class

    class _TestBaseClass:
        def __init__(self, a=1, b=2, c=3):
            pass

    @dataclass
    class _TestClassA(_TestBaseClass):
        d: int = 4
        e: int = 5
        f: int = 6

    @dataclass
    class _TestClassB(_TestBaseClass):
        d: int = 4
        e: int = 5
        f: int = 6

    @dataclass
    class _TestClassC(_TestBaseClass):
        d: int = 4
        e: int = 5
        f: int = 6


# Generated at 2022-06-11 21:14:56.677991
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError as e:
        assert str(e) == "UndefinedParameterError"



# Generated at 2022-06-11 21:14:59.937410
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    from unittest.mock import Mock
    exc = UndefinedParameterError("bla", valid_data=Mock())
    assert exc.valid_data is not None

# Generated at 2022-06-11 21:15:01.947795
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert isinstance(_UndefinedParameterAction.handle_dump({}), dict)



# Generated at 2022-06-11 21:15:07.101231
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass(frozen=True)
    class ClassA:
        def __init__(self, *args, **kwargs):
            pass

    assert _UndefinedParameterAction.handle_dump(ClassA) == {}


# Unit tests for method handle_dump of class _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:15:10.992501
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # noinspection PyStatementEffect
    UndefinedParameterError()
    UndefinedParameterError(f"some message")
    UndefinedParameterError(f"some message", field_names=["a", "b"])

# Generated at 2022-06-11 21:15:17.122539
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(None, {}) == {}
    assert _CatchAllUndefinedParameters.handle_to_dict(None, {"a": 1}) == {
        "a": 1}
    assert _CatchAllUndefinedParameters.handle_to_dict(None, {"a": 1, "b": 2,
                                                              "c": 3}) == {
        "a": 1, "b": 2}