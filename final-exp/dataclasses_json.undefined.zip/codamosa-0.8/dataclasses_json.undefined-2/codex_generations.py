

# Generated at 2022-06-11 21:05:45.288991
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Given
    class Example:
        def __init__(self, *,
                     a: int,
                     b: int,
                     c: Optional[CatchAllVar] = {}):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            return (self.a == other.a) and (self.b == other.b) and (
                    self.c == other.c)

    # When
    test_input = {
        "a": 1,
        "b": 2,
    }
    expected = Example(a=1, b=2, c={})
    actual = Example(**_CatchAllUndefinedParameters.handle_from_dict(
        cls=Example,
        kvs=test_input))

    # Then
   

# Generated at 2022-06-11 21:05:58.892310
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass
    from dataclasses_json import DataclassJsonMixin, config

    @dataclass
    class Test(DataclassJsonMixin):
        a: int
        b: int
        c: int

    args = [1, 2, 3]
    kwargs = {"b": 22, "c": 23}

    def _test(init):
        obj = Test(*args, **kwargs)
        assert (1, 22, 23) == (obj.a, obj.b, obj.c)

    _test(Test.__init__)

    def _test2(init):
        params = init_signature.bind(None, *args, **kwargs).arguments
        params.pop("self", None)
        params = _UndefinedParameterAction.handle_from_dict

# Generated at 2022-06-11 21:06:06.969198
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    dummy_cls = DummyClass()
    # this call should raise an error,
    # because the class doesn't have a field called unused
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=dummy_cls,
                                                   kvs={"unused": "unused"})
        assert False, "Failed to raise UndefinedParameterError when it should"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:06:15.666523
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass()
    class _TestClass:
        def __init__(self, a: int = None, b: int = None):
            pass

        @staticmethod
        def _test_init_signature(a: int = None, b: int = None):
            pass

    assert _UndefinedParameterAction.create_init(_TestClass) == \
           _TestClass.__init__
    assert _IgnoreUndefinedParameters.create_init(_TestClass) != \
           _TestClass.__init__
    assert _IgnoreUndefinedParameters.create_init(_TestClass) == \
           _TestClass._test_init_signature

# Generated at 2022-06-11 21:06:18.452464
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test message")
    UndefinedParameterError("Test message", "Test field", "Test value")
    UndefinedParameterError("Test message", {"Test key": "Test value"})

# Generated at 2022-06-11 21:06:30.624042
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, params: dict):
            pass

        def __eq__(self, other):
            return self.params == other.params

    class Bar:
        def __init__(self, _c: Optional[CatchAllVar] = None, **params):
            self._c = _c

        def __eq__(self, other):
            return self._c == other._c and self.params == other.params

        @property
        def params(self):
            return {k: v for k, v in self.__dict__.items() if
                    not k.startswith("_c")}

    @dataclasses.dataclass
    class Baz:
        a: int
        b: str
        c: dict
        _c: Optional[CatchAllVar] = None

       

# Generated at 2022-06-11 21:06:39.840339
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Testing:
        a: int
        b: int
        _UNDEFINED_PARAMETER_ACTION = _IgnoreUndefinedParameters

        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    testing = Testing(1, 2)
    assert testing.a == 1
    assert testing.b == 2
    kvs = _IgnoreUndefinedParameters.handle_from_dict(cls=Testing,
                                                      kvs={"a": 1})
    assert kvs["a"] == 1

    with pytest.raises(UndefinedParameterError):
        _IgnoreUndefinedParameters.handle_from_dict(cls=Testing,
                                                    kvs={"a": 1, "b": 2,
                                                         "c": 3})




# Generated at 2022-06-11 21:06:49.941246
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # pylint: disable=function-redefined,no-value-for-parameter, unused-argument
    @dataclasses.dataclass
    class Foo:
        test: int

        def __init__(self, test: int, **kwargs):
            super().__init__(**kwargs)
            self.test = test

    @dataclasses.dataclass
    class Bar:
        test: int
        excluded: str
        included: CatchAll

        def __init__(self, test: int, excluded: str, **kwargs):
            super().__init__(**kwargs)
            self.test = test
            self.excluded = excluded

    @dataclasses.dataclass
    class Baz:
        test: int
        included: CatchAll


# Generated at 2022-06-11 21:06:57.449799
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class MyDummyClass:
        field: int
        catch_all: CatchAll = None

    kvs = {"field": 40, "field2": 20}
    known, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        MyDummyClass, kvs)
    try:
        new_kvs = _RaiseUndefinedParameters.handle_from_dict(MyDummyClass, kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False, "handle_from_dict did not raise UndefinedParameterError"



# Generated at 2022-06-11 21:07:08.677392
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        prop: str = "A"
        _undefined_parameters: Optional[CatchAll] = None


    class B(A):
        _undefined_parameters: Optional[CatchAll] = None


    class C(A):
        x: int = 5


    class D(B):
        _undefined_parameters: Optional[CatchAll] = None
        x: int = 5


    class E(A):
        x: int = 5
        _undefined_parameters: Optional[CatchAll] = None

    class F(A):
        x: int = 5

        class DefaultFactory:
            @classmethod
            def create(cls):
                return {"b": "B"}


# Generated at 2022-06-11 21:07:32.203226
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: Optional[str] = None):
            self.a = a

    result = _RaiseUndefinedParameters.handle_from_dict(cls=A, kvs={"a": "1"})
    assert result["a"] == "1"

    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=A, kvs={
                "a": "1", "b": 3})
        assert False, "Should have raised an error"
    except UndefinedParameterError:
        pass

    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=A, kvs={
            "a": "1", "b": 3,
            "c": 3})["a"] == "1"


# Generated at 2022-06-11 21:07:43.007388
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class _TestClass:
        field1: int
        field2: str
        field3: CatchAll = dataclasses.field(default=None)

    assert _CatchAllUndefinedParameters.handle_from_dict(
        cls=_TestClass, kvs={
            "field1": 42,
            "field2": "hello",
            "field3": 1234
        }) == {"field1": 42, "field2": "hello", "field3": {}}


# Generated at 2022-06-11 21:07:50.196108
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import dataclasses
    from typing import Optional

    from dataclasses_json.reserved import Undefined

    # Test that we do not get an error when no undefined parameters are given:
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class TestClass:
        field1: Optional[str]

    instance = TestClass.from_dict({"field1": "value"})
    assert instance.field1 == "value"

    try:
        TestClass.from_dict({"field1": "value", "field2": "value"})
    except UndefinedParameterError:
        pass
    else:
        assert False


# Unit tests for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:08:02.602958
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    # Default behavior
    init_function_default = _UndefinedParameterAction.create_init(
        TestClass)
    new_function_init_default = init_function_default(1, 2, 3)
    assert new_function_init_default == (1, 2, 3)
    new_function_init_default = init_function_default(1, 2, 3, 4)
    assert new_function_init_default == (1, 2, 3)

    # CatchAll
    init_function = _CatchAllUndefinedParameters.create_init(TestClass)
    new_function_init = init_function(1, 2, 3)
    assert new_function_init == (1, 2, 3)
    new_function_

# Generated at 2022-06-11 21:08:12.979444
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int = 0
        b: str = ""

    @dataclasses.dataclass
    class B(A):
        pass

    assert A(1, "hello").a == 1

    init_B = _CatchAllUndefinedParameters \
        .create_init(B)
    assert init_B(B(), 0, "hello").a == 0

    init_A = _CatchAllUndefinedParameters \
        .create_init(A)
    assert init_A(A(), 1, "hello").a == 1

# Generated at 2022-06-11 21:08:19.322044
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class ClassA:
        def __init__(self, a, b, c, d=4):
            pass
    for cls in [ClassA]:
        class_fields = fields(cls)
        field_names = [field.name for field in class_fields]
        kvs = {"a": 1, "b": 2, "c": 3}
        assert _UndefinedParameterAction.handle_to_dict(cls, kvs
                                                         ) == kvs
        kvs = {"a": 1, "b": 2, "c": 3, "d": 4,
               "_undefined_parameter_1": 1, "_undefined_parameter_2": 2}

# Generated at 2022-06-11 21:08:32.070654
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from marshmallow import Schema
    from dataclasses_json.schema import SchemaABC, Schema
    from typing import Tuple, Dict

    import datetime


# Generated at 2022-06-11 21:08:41.484052
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    from typing import List

    from marshmallow import Schema
    from dataclasses_json import config, dataclass_json, Undefined

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclasses.dataclass
    class MyClass:
        name: str
        age: int

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class MyClassWithCatchAll:
        name: str
        age: int
        _undefined: CatchAll

    def define_init_with_catch_all(cls):
        _CatchAllUndefinedParameters.create_init(cls)

    def define_init_without_catch_all(cls):
        _IgnoreUndefinedParameters

# Generated at 2022-06-11 21:08:43.501497
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(1) == {}



# Generated at 2022-06-11 21:08:53.755200
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dict_comparator import DictComparator, DictComparatorException

    class MyClass:
        @dataclasses.dataclass(undefined=Undefined.INCLUDE)
        class MyInnerClass:
            a: int
            b: int
            _catch_all: CatchAll = dataclasses.field(default=None)

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class MyClass2:
        x: int
        y: int
        inner_class: MyClass.MyInnerClass

    mc2 = MyClass2(
        1, 2, MyClass.MyInnerClass(3, 4, _catch_all={'a': 5}))

# Generated at 2022-06-11 21:09:29.058610
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from typing import List
    import marshmallow
    from dataclasses_json import dataclass_json, config
    from dataclasses_json.utils import CatchAll

    @dataclass_json
    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass_json(letter_case=config.LetterCase.CAMEL)
    class TestClass:
        field_1: str
        field_2: int
        field_3: List[int]
        catch_all: Optional[CatchAllVar] = CatchAll()


# Generated at 2022-06-11 21:09:41.185282
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        a: int = 100
        b: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: Optional[CatchAllVar] = None):
            super().__init__()
            self.a = a
            self.b = b

    obj = Test(10, {"c": "d"})
    new_obj = Test._CatchAllUndefinedParameters.create_init(obj)(
        obj, "a", "b", "c", "d")()
    assert new_obj.a == "a"
    assert new_obj.b == {"c": "d"}

    new_obj = Test._CatchAllUndefinedParameters.create_init(obj)(
        obj, "a", "c", "d")()

# Generated at 2022-06-11 21:09:53.460440
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass(undefined=dataclasses_json.Undefined.INCLUDE)
    class MyClass():
        field1: str
        field2: str
        field3: dataclasses_json.CatchAll = None

    MyClass = _CatchAllUndefinedParameters.create_init(MyClass)

    assert MyClass.__init__ != object.__init__

    c = MyClass("field1", "field2")

    assert c.field1 == "field1"
    assert c.field2 == "field2"
    assert c.field3 == {}

    c = MyClass("field1", "field2", field3="field3")

    assert c.field1 == "field1"
    assert c.field2 == "field2"
    assert c.field

# Generated at 2022-06-11 21:10:05.153811
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    from dataclasses import dataclass
    from marshmallow.exceptions import ValidationError
    from marshmallow.fields import String
    from marshmallow_dataclass import class_schema
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json.undefined import _UndefinedParameterAction, Undefined

    @dataclass
    class Simple(DataClassJsonMixin):
        a: str

    @dataclass
    class WithUndefParam(Simple):
        b: str
        c: Optional[str]

    with config(undefined=Undefined.RAISE):
        Simple(a="a")
        WithUndefParam(a="a", b="b")


# Generated at 2022-06-11 21:10:16.722969
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():

    class TestClass:
        dict: dict

        def __init__(self, **kv):
            self.dict = kv

    test_cases = [
        {},
        {"dict": {"a": "b"}},
        {"dict": {"a": "b"}, "q": "w"},
        {"dict": {"a": "b"}, "_UNKNOWN_0": "5"}
    ]
    for test_dict in test_cases:
        inst = TestClass(**test_dict)
        expected = {k: v for k, v in test_dict.items() if not k.startswith(
            "_UNKNOWN")}
        result_dict = _CatchAllUndefinedParameters.handle_to_dict(inst, test_dict)
        assert expected == result_dict



# Generated at 2022-06-11 21:10:27.376049
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Convert these tests to pytest tests

    class Foo:
        def __init__(self, a: int, b: Optional[int] = None):
            self.a = a
            self.b = b

        def get_init(self) -> Callable:
            return self.__init__

    class Bar:
        def __init__(self, a: int, b: Optional[int] = None, **other):
            self.a = a
            self.b = b
            self.other = other

        def get_init(self) -> Callable:
            return self.__init__

    def _assert_error_message(obj, *args, **kwargs):
        created_init = _IgnoreUndefinedParameters.create_init(obj)
        with pytest.raises(TypeError) as exception:
            created

# Generated at 2022-06-11 21:10:36.752973
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import functools


    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class DataClass:
        name: str = "default_name"
        optional: Optional[int] = None


    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class DataClass2:
        name: str = "default_name"
        optional: Optional[int] = None
        _catch_all: Optional[CatchAll] = None


    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class DataClass3:
        name: str = "default_name"
        optional: Optional[int] = None
        _catch_all: Optional[CatchAll] = None

# Generated at 2022-06-11 21:10:39.501177
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def _create_dict_with_undef(**kvargs):
        catch_all = CatchAllVar()
        return kvargs, catch_all
    dict, _ = _create_dict_with_undef(a=1, b=2)
    assert dict == _UndefinedParameterAction.handle_dump(_create_dict_with_undef)

# Generated at 2022-06-11 21:10:52.920389
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyTestClass:
        a: str
        b: str
        c: str
        d: str
        e: str

    def test_init_method(self, a: str, b: str, c: str, d: str, e: str):
        pass

    MyTestClass.__init__ = test_init_method
    MyTestClass.__init__ = _IgnoreUndefinedParameters.create_init(
        MyTestClass)

    test = MyTestClass("a", "b", "c", "d", "e")
    MyTestClass("a", "b", "c", "d", "e", a="a", b="b", c="c", d="d", e="e")

# Generated at 2022-06-11 21:10:58.486759
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    example_dict = {"foo": "bar", "_catch_all": {"1": 1, "2": "2"}}
    result = _CatchAllUndefinedParameters.handle_to_dict(None, example_dict)
    expected_result = {"foo": "bar", "1": 1, "2": "2"}

    assert expected_result == result

# Generated at 2022-06-11 21:11:50.963091
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _UndefinedParameterAction().handle_dump(None) == {}

# Generated at 2022-06-11 21:11:56.929806
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class BuggyDump():
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all
    b = BuggyDump(1)
    assert _CatchAllUndefinedParameters.handle_to_dict(BuggyDump, dict(catch_all=1)) == dict()

# Generated at 2022-06-11 21:12:06.611102
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class CatchAllExample:
        """
        Used to test _CatchAllUndefinedParameters.create_init
        """
        a: str
        b: str
        c: str
        catch_all: Optional[CatchAllVar] = \
            dataclasses.field(default=None,
                              metadata=dataclasses_json.config(
                                  undefined=Undefined.INCLUDE))

    a, b, c = "a", "b", "c"
    args = (a, b, c)
    non_existent_arg_1 = "random_string_1"
    non_existent_arg_2 = "random_string_2"

# Generated at 2022-06-11 21:12:12.148257
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Atest:
        def __init__(self, a, b, c):
            pass

    class Btest:
        def __init__(self, a, b, c=2):
            pass

    class Ctest:
        def __init__(self, a, b, c=2, d=3):
            pass

    class Dtest:
        def __init__(self, a, b, c=2, d=3, **kwargs):
            pass

    for cls in [Atest, Btest, Ctest, Dtest]:
        init = _IgnoreUndefinedParameters.create_init(cls)
        init_signature = inspect.signature(init)
        bound_parameters = init_signature.bind_partial(cls, 1, 2, 3, 4)
        bound_parameters.apply

# Generated at 2022-06-11 21:12:25.824461
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        test_attr: str
        test_attr2: str
        test_attr_none: Optional[str]
        test_attr_default: str = "test"
        test_attr_call: str = lambda: "test"
        test_attr_cf: Optional[CatchAllVar]

    T = TestClass
    # noinspection PyTypeChecker

# Generated at 2022-06-11 21:12:31.981542
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class A:
        a1: int
        a2: int
        unknown_parameters: Optional[CatchAllVar] = Undefined.INCLUDE  # type: ignore

    x = A(a1=1, a2=2, c1=3, c2=4)
    assert x.unknown_parameters == {"c1": 3, "c2": 4}
    dict_x = dict(x)
    assert dict_x == {'a1': 1, 'a2': 2}

# Generated at 2022-06-11 21:12:41.601794
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    @dataclasses.dataclass
    class CatchAllExample:
        name: str
        catch_all: CatchAll = dataclasses.field(
            default=CatchAllVar())

        def __init__(self, name, catch_all, age=20):
            self.name = name
            self.age = age
            self.catch_all = catch_all

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    undef_params = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    init = _CatchAllUndefinedParameters.create_init(CatchAllExample)
    cae = init(name="Peter", **undef_params)

# Generated at 2022-06-11 21:12:52.262824
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}
    test_class = TestClass(catch_all={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}
    test_class = TestClass(catch_all=CatchAll())
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}
    test_class.catch_all["a"] = 1
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {"a": 1}

# Generated at 2022-06-11 21:12:54.957097
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {'foo': 'bar', 'baz': 'buzz'}
    new_kvs = _UndefinedParameterAction.handle_to_dict(None, kvs)
    assert new_kvs == kvs

# Generated at 2022-06-11 21:13:01.090934
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Setup
    class ClassWithLongInit:
        def __init__(self, one: int, two: int, three: int, four: int,
                     five: int, six: int, seven: int, eight: int,
                     nine: int, ten: int, eleven: int, twelve: int,
                     thirteen: int, fourteen: int, fifteen: int,
                     sixteen: int, seventeen: int, eighteen: int,
                     nineteen: int, twenty: int, twenty_one: int,
                     twenty_two: int, twenty_three: int, twenty_four: int,
                     twenty_five: int, twenty_six: int, twenty_seven: int,
                     twenty_eight: int, twenty_nine: int, thirty: int): ...
