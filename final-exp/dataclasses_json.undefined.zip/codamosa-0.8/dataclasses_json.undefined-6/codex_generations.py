

# Generated at 2022-06-11 21:05:45.923449
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        defined_field: str = "a"
        catch_all: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class TestClassWithDefault:
        defined_field: str = "a"
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=None)

    @dataclasses.dataclass
    class TestClassWithDefaultFactory:
        defined_field: str = "a"
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=functools.partial(dict))

    @dataclasses.dataclass
    class TestClassWithDefaultFunction:
        defined_field: str = "a"
        catch_all_fieldname: str

# Generated at 2022-06-11 21:05:59.475106
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClass():
        a: int = 0
        b: int = 0
        c: int = 0

    original_init = TestClass.__init__
    _ignore_init = _UndefinedParameterAction.create_init(TestClass)
    assert id(original_init) != id(_ignore_init)

    @dataclasses.dataclass
    class TestClass():
        a: int = 0
        b: int = 0
        c: int = 0
        _catch_all: CatchAll = dataclasses.field(default_factory=dict)

    original_init = TestClass.__init__
    _ignore_init = _UndefinedParameterAction.create_init(TestClass)
    assert id(original_init) == id(_ignore_init)

# Generated at 2022-06-11 21:06:11.956120
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class MyClass:
        known: str
        unknown: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __post_init__(self):
            if not isinstance(self.unknown, dict):
                raise ValidationError("Invalid type for field 'unknown'")

    default_instance = MyClass("asdf")

    assert default_instance.known == "asdf"
    assert default_instance.unknown == {}

    another_known = "qwer"
    unknown = {"1": 2, "3": "4"}

# Generated at 2022-06-11 21:06:13.660660
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(obj) == {}
    assert obj.handle_dump(object()) == {}

# Generated at 2022-06-11 21:06:19.144322
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class Foo:
        a: str
        b: int
        c: str

    f = Foo("1", 2, "3")
    d = {
        "a": "1",
        "b": 2,
        "c": "3",
        "d": "4"
    }
    d_expected = {
        "a": "1",
        "b": 2,
        "c": "3",
        "d": "4"
    }
    assert d_expected == _UndefinedParameterAction.handle_to_dict(f, d)

# Generated at 2022-06-11 21:06:29.249681
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        x: int
        y: int
        z: CatchAll = None

    test_class = TestClass(1, 2, 3)
    assert test_class.z is None

    # No undefined parameters
    test_class = TestClass(1, 2)
    assert test_class.z is None

    # Undefined parameters
    test_class = TestClass(1, 2, z={"a": 1, "b": 2, "c": 3})
    assert test_class.z == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-11 21:06:40.628245
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, field
    from dataclasses_json import config

    @dataclass
    class TestClass:
        a: int = 10
        b: str = "hello"
        c: dict = field(default_factory=dict)
        d: int = field(default=42)
        e: Optional[CatchAllVar] = None

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    cls = TestClass
    config.undefined = Undefined.INCLUDE
    init_factory = _CatchAllUndefinedParameters.create_init(cls)
    init = init_factory(cls)

# Generated at 2022-06-11 21:06:50.237124
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    import inspect


    @dataclass
    class Foo:
        x: str
        y: str
        z: str
        catch_all: "dataclasses_json.CatchAll" = None

    cls = Foo
    kwargs = dict(x="x", y="y", z="z", cat="cat")
    ignore_init = \
        _CatchAllUndefinedParameters.create_init(obj=cls)

# Generated at 2022-06-11 21:06:58.773765
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    # noinspection PyMissingOrEmptyDocstring
    @dataclasses.dataclass(
        _undefined_parameter_action=_IgnoreUndefinedParameters)
    class TestClass:
        a: str
        b: int

    cls = TestClass

    # Every combination of arguments which could be given should be testable
    # The definition of the parameter lengths should be kept up to date
    min_params = 0
    max_params = len(inspect.signature(cls.__init__).parameters) - 1
    # max_params = 2  # The number of defined parameters - 1 (self)

    # This is a very simplified version of what is currently valid
    # (and we don't want to use the real mypy here, because it is complicated)

# Generated at 2022-06-11 21:07:10.108300
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import marshmallow as mm

    # Catch all init
    @dataclasses.dataclass
    class CatchAllClass:
        a: int
        b: int
        undefined: CatchAll

    @mm.post_load
    def init_class(data, **kwargs):
        return CatchAllClass(**data)

    _CatchAllUndefinedParameters.create_init(CatchAllClass)
    schema = mm.Schema.from_dataclass(CatchAllClass,
                                      unknown=Undefined.INCLUDE)
    received = schema.load({"a": 1, "b": 2, "other": 3})
    expected = CatchAllClass(a=1, b=2, undefined={'other': 3})
    assert received == expected

    # Ignore init

# Generated at 2022-06-11 21:07:26.823813
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class X:
        def __init__(self, a: int, b: int):
            pass


assert hasattr(_IgnoreUndefinedParameters.create_init(X)(), "_ignore_init")

# Generated at 2022-06-11 21:07:28.167181
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-11 21:07:35.930435
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: int
        d: Any = dataclasses.field(default="default value")
        e: Optional[CatchAllVar] = None

    assert _CatchAllUndefinedParameters.handle_from_dict(
        Test, {"a": 1, "b": 2, "e": {"x": "y", "z": 3}}) == {
               "a": 1, "b": 2, "e": {"x": "y", "z": 3}}

# Generated at 2022-06-11 21:07:46.976373
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int
        b: int = 0
        c: bool = False
        d: float = 1.00

    c = MyClass(1, b=2)
    kvs = {"a": 1.0, "b": 2}
    known, unknown = _RaiseUndefinedParameters.handle_from_dict(
        cls=MyClass, kvs=kvs)
    assert known == kvs
    assert unknown == {}

    kvs = {"a": 1.0, "b": 2, "c": "c"}

# Generated at 2022-06-11 21:07:54.597681
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    from dataclasses_json.config import config

    @dataclasses.dataclass
    class Dummy:
        a: str
        b: str
        catch_all: CatchAll

    d = Dummy("a", "b", catch_all={"c": 1})
    d_schema = config._from_dict(d, [], None,
                                 undefined=Undefined.EXCLUDE)
    d_schema_parameters = d_schema.__dict__
    assert d_schema_parameters == {"a": "a", "b": "b", "catch_all": {"c": 1}}

# Generated at 2022-06-11 21:08:04.841749
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass
    from typing import Dict
    from dataclasses_json import config

    @dataclass
    class A:
        a: int
        b: str
        c: Dict

    @dataclass
    class B:
        a: int
        b: str
        c: Dict
        d: Optional[CatchAllVar]

    @dataclass
    class C:
        a: int
        b: str
        c: Dict
        d: Optional[CatchAllVar] = None

    @dataclass
    class D:
        a: int
        b: str
        c: Dict
        d: Optional[CatchAllVar] = field(default_factory=dict)

    # test RaiseUndefinedParameters
    config.undefined = Undefined.RAISE

# Generated at 2022-06-11 21:08:13.559775
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    undefined_parameters_behavior = Undefined.RAISE
    @dataclasses.dataclass(undefined=undefined_parameters_behavior)
    class Test:
        a: int
        b: int

    with pytest.raises(UndefinedParameterError):
        dictionary_with_undefined_parameters = {"a": 3, "b": 5, "c": 7}
        Test(**dictionary_with_undefined_parameters)



# Generated at 2022-06-11 21:08:17.879936
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    new_class=UndefinedParameterError()
    assert new_class.args == ()
    assert new_class.message is None
    assert new_class.field_name is None
    assert new_class.valid_data is None
    assert new_class.status_code == 400
    assert new_class.kwargs == {}

# Generated at 2022-06-11 21:08:29.449233
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_field = Field(name="catch_all", type=CatchAll)

    @dataclasses.dataclass
    class TestClass:
        name: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None,
            metadata={
                "dataclasses_json": {
                    "undefined": Undefined.INCLUDE
                }
            })

        def __init__(self, name, catch_all=None):
            self.name = name
            self.catch_all = catch_all

    actual_init = _CatchAllUndefinedParameters.create_init(TestClass)

    test_class = TestClass("default", {})

    # Test that undefined parameters are passed correctly
    actual_init(test_class, undefined_parameter="value")
   

# Generated at 2022-06-11 21:08:39.495488
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(eq=True, init=True, repr=True)
    class Test:
        values: CatchAll
        _hidden: str = "_hidden"

    t = Test("_hidden", {"a": 1, "b": 2})
    assert t.values == {"a": 1, "b": 2}
    assert t._hidden == "_hidden"

    t2 = Test("_hidden", {"a": 1, "_hidden": "CHANGED", "b": 2})
    assert t2.values == {"a": 1, "b": 2}
    assert t2._hidden == "_hidden"

    @dataclasses.dataclass(eq=True, init=True, repr=True)
    class Test2:
        a: str
        values: CatchAll
        _hidden: str = "_hidden"

    t

# Generated at 2022-06-11 21:09:15.897100
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, name: str, age: int,
                     extra: Optional[CatchAllVar] = None):
            self.name = name
            self.age = age
            self.extra = extra

    # undefined parameters
    kvs: Dict = {"name": "Max", "age": 42, "extra": "some extra thing"}
    expected_output: Dict = {"name": "Max", "age": 42,
                             "extra": {"extra": "some extra thing"}}
    assert \
        _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                       kvs) == expected_output

    # conflict with catch-all field

# Generated at 2022-06-11 21:09:27.038253
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(default=None)

    def test_case(given_parameters: Dict[str, Any], expected_result: Dict[str, Any]):
        result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, given_parameters)
        assert result == expected_result

    test_case(given_parameters={}, expected_result={'a': None, 'b': None})
    test_case(given_parameters={'a': 1}, expected_result={'a': 1, 'b': None})

# Generated at 2022-06-11 21:09:36.362531
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Foo:
        def __init__(self, a, b, **kwargs):
            self.a = a
            self.b = b
            self.catch_all = kwargs

        def as_dict(self) -> Dict:
            return _CatchAllUndefinedParameters.handle_to_dict(self,
                                                                self.__dict__)


    f = Foo(a=1, b=2, x=3, y=4)
    f_expected = {"a": 1, "b": 2, "x": 3, "y": 4}
    assert f.as_dict() == f_expected

# Generated at 2022-06-11 21:09:47.010804
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class CatchAllTestClass:
        def __init__(self, p1: str, p2: int, p3: str = "test",
                     p4: Optional[CatchAllVar] = None):
            ...

    def test_handle_from_dict(initialization_parameters: Dict[Any, Any],
                              expected_parameters: Dict[Any, Any]):
        result = _CatchAllUndefinedParameters.handle_from_dict(
            cls=CatchAllTestClass, kvs=initialization_parameters)
        assert result == expected_parameters


# Generated at 2022-06-11 21:09:48.219463
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("some_error")

# Generated at 2022-06-11 21:09:56.875025
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: str
        d: CatchAllVar

    def assert_known_parameters(kvs, known_parameters):
        result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert result == known_parameters

    def assert_unknown_parameters(kvs, unknown_parameters):
        _, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            TestClass, kvs)
        assert unknown == unknown_parameters

    def assert_both(kvs, known_parameters, unknown_parameters):
        assert_known_parameters(kvs, known_parameters)

# Generated at 2022-06-11 21:10:08.161996
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: int
        b: int

    @dataclasses.dataclass
    class B(A):
        c: int
        d: int

    @dataclasses.dataclass
    class C(B):
        e: int
        f: int

    @dataclasses.dataclass
    class D(C):
        g: int
        h: int

    args = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8,
            "i": 9, "j": 10}
    handled_args = _IgnoreUndefinedParameters.handle_from_dict(D, args)

# Generated at 2022-06-11 21:10:17.685514
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class SuperObject:
        a: str
        b: int
        c: bool

    # noinspection PyClassHasNoInit
    def __init__(self, a: str, b: int, c: bool):
        # The implementation of the actual class initialization
        try:
            object.__setattr__(self, "a", a)
            object.__setattr__(self, "b", b)
            object.__setattr__(self, "c", c)
        except TypeError:
            raise TypeError(
                f"{self.__class__.__name__}.__init__ only accepts keyword "
                f"arguments, got {inspect.signature(self.__init__)}.")

    # Replace __init__ with a function with the same signature that raises a
   

# Generated at 2022-06-11 21:10:22.757314
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    from dataclasses_json import dataclass_json, Undefined
    @dataclass_json
    @dataclasses.dataclass
    class Test:
        foo: str
        bar: int
        baz: CatchAll = None

    test = Test(foo="foo", bar=1, baz={})
    _CatchAllUndefinedParameters.create_init(Test)(test)

# Generated at 2022-06-11 21:10:25.577643
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("test_message")
    assert error.messages == "test_message"

# Generated at 2022-06-11 21:11:31.262700
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        known1: str
        known2: str

        def __init__(self,
                     *args,
                     **kwargs):
            kwargs.pop("not_defined")
            super(Test, self).__init__(*args, **kwargs)


    init = _IgnoreUndefinedParameters.create_init(Test)
    assert init("a", "b", not_defined="c")

# Generated at 2022-06-11 21:11:44.093226
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class SomeClass:
        pass

    class SomeClassWithCatchAll(SomeClass):
        catch_all: Optional[CatchAllVar] = None

    class SomeSubClass(SomeClassWithCatchAll):
        pass

    class SomeSubSubClass(SomeSubClass):
        pass

    class SomeSubSubSubClass(SomeSubSubClass):
        pass

    # Test everything when nothing is given:
    from_dict_result = _IgnoreUndefinedParameters.handle_from_dict(SomeClass,
                                                                   {})
    assert isinstance(from_dict_result, dict) and len(
        from_dict_result) == 0

    # Test everything when nothing is given:
    from_dict_result = _IgnoreUndefinedParameters.handle_from_dict(
        SomeClassWithCatchAll,
        {})
   

# Generated at 2022-06-11 21:11:53.534839
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyClass:
        name: str = dataclasses.field(default="default_name")
        surname: str = dataclasses.field()

    obj = MyClass()
    init_signature = inspect.signature(obj.__init__)
    init_signature.parameters["self"] = inspect.Parameter("self",
                                                          inspect.Parameter.POSITIONAL_OR_KEYWORD)
    bound_parameters = init_signature.bind_partial(obj)
    bound_parameters.apply_defaults()
    bound_parameters.arguments["name"] = "new_name"
    bound_parameters.arguments["surname"] = "surname"
    bound_parameters.arguments["new_argument"] = "new_argument"

    _

# Generated at 2022-06-11 21:11:57.464439
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test message")
    except UndefinedParameterError as e:
        assert str(e) == "Test message"



# Generated at 2022-06-11 21:12:05.073328
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, ignore_this, **catch_all):
            self.ignore_this = ignore_this
            self.catch_all = catch_all

    obj = TestClass(ignore_this=True, a=1, b=2, c=3)

    kvs = {"ignore_this": True, "a": 1, "b": 2, "c": 3}
    after = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

    assert after == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-11 21:12:15.237606
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, existing_field_a, existing_field_b,
                     catch_all: CatchAll = None):
            self.existing_field_a = existing_field_a
            self.existing_field_b = existing_field_b
            self.catch_all = catch_all

    test_instance = TestClass(existing_field_a=1, existing_field_b=2,
                              catch_all=None)

    new_init = _CatchAllUndefinedParameters.create_init(test_instance)
    test_instance.__init__ = new_init

    test_instance.__init__(test_instance, 3, unknown_field_a=4,
                           unknown_field_b=5)
    assert test_instance.existing_field_a == 3

# Generated at 2022-06-11 21:12:25.658505
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import sys

    @dataclasses.dataclass
    class TestClass:
        a: Any = dataclasses.field(default=None)

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                        kvs={"a": "myA", "b": "myB"})
    if sys.version_info >= (3, 7):
        with pytest.raises(TypeError):
            _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                       kvs={"a": "myA", "b":
                                                            "myB"})



# Generated at 2022-06-11 21:12:33.022059
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class MockClass:
        pass

    mock_obj = MockClass()
    q = {'x': 1}
    result = _CatchAllUndefinedParameters.handle_to_dict(
        mock_obj, {'x': 1, 'catch_all': 'q'})
    assert result == q
    result = _CatchAllUndefinedParameters.handle_to_dict(
        mock_obj, {'x': 1, 'catch_all': {'y': 1}})
    assert result == {'x': 1, 'y': 1}
    result = _CatchAllUndefinedParameters.handle_to_dict(
        mock_obj, {'x': 1, 'catch_all': dict()})
    assert result == q

# Generated at 2022-06-11 21:12:42.582997
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, x: int, y=0, z: Optional[CatchAllVar] = None):
            self.x = x
            self.y = y
            self.z = z

    foo_with_catch_all_init = _CatchAllUndefinedParameters.create_init(Foo)

    foo = foo_with_catch_all_init(1, 2, 3)
    assert foo.x == 1
    assert foo.y == 2
    assert isinstance(foo.z, dict)
    assert len(foo.z.items()) == 1
    assert list(foo.z.keys()) == ["_UNKNOWN0"]
    assert list(foo.z.values()) == [3]


# Generated at 2022-06-11 21:12:53.277766
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        a: int
        b: int = 1
        c: int = dataclasses.field(default=dataclasses.MISSING)

    def check_handle_from_dict(handler, kvs, expected_result):
        result = handler.handle_from_dict(TestClass, kvs)
        assert result == expected_result

    check_handle_from_dict(Undefined.RAISE, {"a": 3}, {"a": 3})
    check_handle_from_dict(Undefined.RAISE, {"a": 3, "f": 5}, {"a": 3})
    check_handle_from_dict(Undefined.RAISE, {"a": 3, "a": 5}, {"a": 3})

# Generated at 2022-06-11 21:15:08.788286
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        pass

    kvs = {}
    TestClass.__init__ = lambda self: None
    _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)



# Generated at 2022-06-11 21:15:19.156598
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import marshmallow

    from dataclasses_json import Config
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.undefined import CatchAllVar


    @dataclasses.dataclass
    class TestDataClass(DataClassJsonMixin):
        a: str
        b: str
        c: str = "c"
        d: int
        catch: Optional[CatchAllVar] = None


    # It is confirmed that create_init() works correctly by comparing its
    # source code with
    # the actual source code of the class. This relies on the fact that the
    # result of create_init()
    # is exactly the same as the source code of the class.
    #
    # This makes sure that create_init() works as expected.
    # It