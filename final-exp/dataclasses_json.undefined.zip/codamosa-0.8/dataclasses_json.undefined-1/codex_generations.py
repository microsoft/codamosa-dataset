

# Generated at 2022-06-11 21:05:37.454173
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert not _UndefinedParameterAction.handle_dump(None)["foo"]
    assert not _IgnoreUndefinedParameters.handle_dump(None)["foo"]
    assert _CatchAllUndefinedParameters.handle_dump(None)["foo"] == {}
    assert _RaiseUndefinedParameters.handle_dump(None)["foo"]

# Generated at 2022-06-11 21:05:48.133195
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # Define a test class
    class DummyClass:
        def __init__(self, foo: int, bar: int = 0,
                     n: str = "default"):
            self.foo = foo
            self.bar = bar
            self.n = n
            self.baz = 2 * foo
            self.qux = self.baz + self.bar

    # Invoke the method under test
    cls = DummyClass(0)
    init = _UndefinedParameterAction.create_init(cls)
    assertinit = _UndefinedParameterAction.create_init(cls)
    assert init(cls, foo=1, bar=2, qux=7, n=None) is None
    assert cls.foo == 1
    assert cls.bar == 2
    assert cls.n is None


# Generated at 2022-06-11 21:06:00.887489
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.config import Config
    from dataclasses_json.api import DataclassJSONMixin

    config = Config(undefined=Undefined.RAISE)

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class TestClass(DataclassJSONMixin):
        foo: str
        bar: int
        defined_field_01: str
        defined_field_02: str
        catch_all: CatchAll = None

        def __post_init__(self):
            self.dict_of_undefined_params = \
                _CatchAllUndefinedParameters._get_catch_all_field(self.__class__).name


# Generated at 2022-06-11 21:06:13.392552
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        pass

    a_field_names = [f.name for f in fields(A)]
    # noinspection PyTypeChecker,PyUnresolvedReferences
    assert len(
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            cls=A, kvs={"a": 1})
    ) == (1, 0)
    assert len(
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            cls=A, kvs={})
    ) == (0, 0)
    assert len(
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            cls=A, kvs={"a": 1, "b": 1})
    ) == (1, 1)

# Generated at 2022-06-11 21:06:19.793180
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        x: int

    kv_dict = {"x": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=A, kvs=kv_dict) == kv_dict

    kv_dict = {"x": 1, "y": 2}
    expected_error_message = \
        "Received undefined initialization arguments {'y': 2}"
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=A, kvs=kv_dict)
    except UndefinedParameterError as e:
        assert str(e) == expected_error_message
    else:
        assert False



# Generated at 2022-06-11 21:06:31.252808
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestDataClass1:
        i: int
        s: str

    assert _IgnoreUndefinedParameters.handle_from_dict(TestDataClass1,
                                                       {'i': 1, 's': 'a',
                                                        'j': 2}) == {'i': 1,
                                                                     's': 'a'}
    assert _IgnoreUndefinedParameters.handle_from_dict(TestDataClass1,
                                                       {'i': 1, 's': 'a',
                                                        'j': 2}) == {'i': 1,
                                                                     's': 'a'}

# Generated at 2022-06-11 21:06:40.216380
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test method _CatchAllUndefinedParameters.handle_from_dict
    """
    import pytest
    from dataclasses import dataclass, field
    from dataclasses_json.conf import LetterCase

    @dataclass
    class TestClass:
        """
        Test Class that can contain a catch-all field
        """
        str_data: str
        catch_all_field: Optional[CatchAllVar] = field(
            default=CatchAllVar(),
            metadata={"undefined": Undefined.INCLUDE})

    # basic
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                           {"str_data": "foo"})
    assert result == {"str_data": "foo", "catch_all_field": {}}

    # basic with additional

# Generated at 2022-06-11 21:06:44.502983
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    result = _IgnoreUndefinedParameters.handle_from_dict(
        MyClass, {"a": 1, "b": 2, "c": 3})
    assert result == {"a": 1, "b": 2}


# Generated at 2022-06-11 21:06:48.343125
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    with raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={"x": 1})

# Generated at 2022-06-11 21:06:57.767433
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import enum

    @enum.unique
    class Color(enum.Enum):
        RED = 0
        GREEN = 1
        BLUE = 2

    @dataclasses.dataclass
    class TestData:
        name: Optional[str] = "default name"
        color: Color = Color.RED
        unknown_parameters: Optional[CatchAllVar] = None

        def __init__(self, **kwargs):
            args = []
            for k, v in kwargs.items():
                setattr(self, k, v)

    TestData._customize(c_undefined_parameter_action=
                        _CatchAllUndefinedParameters)

    x = TestData(name="joe", color=Color.BLUE, x=1, y=2)
    assert x.unknown_

# Generated at 2022-06-11 21:07:30.487024
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class ExampleDataClass(dataclasses.dataclass):
        foo: int
        bar: float

    dataclass_data = ExampleDataClass(1, 2.0)
    kvs = ExampleDataClass.__dataclass_fields__
    catch_all_field_name = CatchAll.__name__

    def _handle_to_dict_check(undefined_parameters: Dict[str, Any]) -> Dict[
        Any, Any]:
        kvs[catch_all_field_name] = undefined_parameters
        return _CatchAllUndefinedParameters.handle_to_dict(
            dataclass_data, kvs)

    # check remove with single unknown parameter
    kvs_converted = _handle_to_dict_check({'baz': 'baz'})

# Generated at 2022-06-11 21:07:41.788482
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class ClassA:
        def __init__(self, a: str):
            self.a = a

    class ClassB:
        def __init__(self, **kwargs):
            return ClassA(**kwargs)

    class ClassC:
        def __init__(self, a=None, b=None):
            pass

    assert {"a": "hello"} == \
           _RaiseUndefinedParameters.handle_from_dict(ClassA, {"a": "hello"})

    try:
        _RaiseUndefinedParameters.handle_from_dict(ClassA, {"b": "hello"})
        assert False
    except UndefinedParameterError:
        assert True

    assert {"a": "hello"} == \
           _RaiseUndefinedParameters.handle_from_dict(ClassB, {"a": "hello"})

   

# Generated at 2022-06-11 21:07:52.550669
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    class Test:
        @dataclass
        class TestClass:

            field1: int
            field2: str

        @dataclass_json(undefined=Undefined.RAISE)
        class TestClass2:

            field1: int
            field2: str

    @dataclass
    class TestClass3:

        field1: int
        field2: str

    @dataclass_json(undefined=Undefined.RAISE)
    class TestClass4:

        field1: int
        field2: str

    class Test:
        test_class = TestClass
        test_class_json = TestClass2
        test_class_dataclass_json_metadata = TestClass3
        test_class_dataclass_json_metadata_json = TestClass4

   

# Generated at 2022-06-11 21:08:01.855679
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, x, y, catch_all: CatchAll = None):
            self.x = x
            self.y = y
            self.catch_all = catch_all

    action = _CatchAllUndefinedParameters()

    # All fields given, no undefined parameter
    kvs = {"x": 1, "y": 2}
    parameters = action.handle_from_dict(Example, kvs)
    assert len(parameters) == 3
    assert parameters["x"] == 1
    assert parameters["y"] == 2
    assert "catch_all" in parameters
    assert isinstance(parameters["catch_all"], dict)
    assert len(parameters["catch_all"]) == 0

    # All fields given, undefined parameter given

# Generated at 2022-06-11 21:08:03.506323
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-11 21:08:13.708043
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, a: str, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    instance = TestClass("a", "b", {"d": "d", "e": "e"})
    output = _CatchAllUndefinedParameters.handle_dump(instance)
    assert output == {"d": "d", "e": "e"}

    assert _CatchAllUndefinedParameters.handle_dump(TestClass("a", "b")) \
           == {}

# Generated at 2022-06-11 21:08:17.055850
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_message = "My custom error message"
    try:
        raise UndefinedParameterError(error_message)
    except Exception as e:
        if e.args[0] != error_message:
            raise AssertionError("Wrong exception message")

# Generated at 2022-06-11 21:08:28.728512
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class A:
        x: int
        y: int

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class B:
        x: int
        y: int
        catch_all: Optional[CatchAll] = None

    a = A(3, 4)
    b = B(3, 4)

    assert _UndefinedParameterAction.handle_to_dict(a, {"x": 3, "y": 4, "z": 5}) == {"x": 3, "y": 4}
    assert _UndefinedParameterAction.handle_to_dict(a, {"x": 3, "y": 4}) == {"x": 3, "y": 4}
    assert _UndefinedParameterAction.handle_

# Generated at 2022-06-11 21:08:31.550420
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    u = UndefinedParameterError(detail="Hallo")
    assert u.detail == "Hallo"

# Generated at 2022-06-11 21:08:40.472803
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, *, a: int, b: CatchAll = None):
            pass

    mock_cls = A()
    init_method = _CatchAllUndefinedParameters.create_init(mock_cls)

    class B:
        def __init__(self, *args, **kwargs):
            pass

    mock_cls = B()
    init_method_no_catch_all_field = _CatchAllUndefinedParameters.create_init(
        mock_cls)

    class C:
        def __init__(self, *, a: CatchAll = None, b: str = None):
            pass

    mock_cls = C()
    init_method_catch_all_field_with_default = \
        _CatchAllUndefinedParameters.create_init

# Generated at 2022-06-11 21:09:15.314841
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs={"a": 1, "b": 2, "c": 3})
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}



# Generated at 2022-06-11 21:09:26.522311
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class D:
        a: int = 3
        b: str = "b"
        _catch_all: Optional[CatchAllVar] = dataclasses.field(
            default={})

    d = D(a=3)
    kvs = dataclasses.asdict(d)
    kvs = _CatchAllUndefinedParameters.handle_to_dict(D, kvs)
    assert len(kvs) == 2, kvs

    d = D(a=3, b="b", _catch_all={"c": 4})
    kvs = dataclasses.asdict(d)
    kvs = _CatchAllUndefinedParameters.handle_to_dict(D, kvs)
    assert len(kvs) == 3, kvs



# Generated at 2022-06-11 21:09:38.332965
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():  # pragma: no cover
    class TestClass:
        def __init__(self, foo: CatchAll = None):
            self.foo = foo

    # Test _CatchAllUndefinedParameters
    original_init = TestClass.__init__
    init = _CatchAllUndefinedParameters.create_init(TestClass)
    TestClass.__init__ = init
    obj = TestClass("bar")
    assert obj.foo == {"_UNKNOWN0": "bar"}

    # Test _IgnoreUndefinedParameters
    original_init = TestClass.__init__
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    TestClass.__init__ = init
    obj = TestClass("bar")
    assert obj.foo == None

    # Restore original init
    TestClass.__init__ = original_init

# Generated at 2022-06-11 21:09:46.945759
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: str
        b: int

    kvs = {"a": "foo", "b": 1, "c": "foobar"}

    known_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs=kvs)
    assert known_given_parameters == {"a": "foo", "b": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs={})
    except UndefinedParameterError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 21:09:56.263901
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: str):
            pass

    @dataclasses.dataclass
    class Bar:
        """
        Similar data class as Foo with different field order
        """
        b: str
        a: int

    foo_input = {"a": 1, "b": "hi", "c": "bye"}
    expected = {"a": 1, "b": "hi"}
    result = _RaiseUndefinedParameters.handle_from_dict(Foo, foo_input)
    assert expected == result

    bar_input = {"b": "hi", "a": 1, "c": "bye"}
    expected = {"b": "hi", "a": 1}
    result = _RaiseUndefinedParameters.handle_from_dict(Bar, bar_input)
    assert expected

# Generated at 2022-06-11 21:10:07.652525
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class MyTestClass:
        def __init__(self, a: str, b: str, c: str, ca: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            self.c = c
            self.ca = ca if ca is not None else {}

    c = MyTestClass("a", "b", "c", {"_UNKNOWN0": "first", "_UNKNOWN1": "second"})
    kvs = _CatchAllUndefinedParameters.handle_to_dict(c,
                                                      {'a': 'a', 'b': 'b',
                                                       'c': 'c',
                                                       '_UNKNOWN0': 'first',
                                                       '_UNKNOWN1': 'second'})

# Generated at 2022-06-11 21:10:15.921712
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Test(object):
        test: int
        some: Optional[CatchAllVar] = dataclasses.field(default=None,
                                                        metadata={"marshmallow_field": {"load_only": True}})

    obj = Test(42, some={"a": 1, "b": 2})
    kvs = _CatchAllUndefinedParameters.handle_dump(obj)
    assert obj.some == kvs
    assert obj.some == {"a": 1, "b": 2}

# Generated at 2022-06-11 21:10:25.364387
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_parameters = {"undefined": "param"}

    class ClassWithCatchAll:
        def __init__(self):
            self._CATCH_ALL = undefined_parameters

    obj = ClassWithCatchAll()
    kvs = {
        "_CATCH_ALL": undefined_parameters
    }

    actual = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert actual == {"undefined": "param"}
    actual = _CatchAllUndefinedParameters.handle_dump(obj)
    assert actual == {"undefined": "param"}



# Generated at 2022-06-11 21:10:33.314952
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self, a, b, c):
            pass

    class B(A):
        def __init__(self, a, b, c, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
            super().__init__(a, b, c)

    init_method = inspect.getclosurevars(B(1, 2, 3).__init__).nonlocals["f"]
    assert init_method == _IgnoreUndefinedParameters.create_init(B)

# Generated at 2022-06-11 21:10:40.048651
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        a: int
        b: int
        c: int
        d: int
        follow_up: str
        follow_up_default: Optional[str] = None
        no_default: str
        _catch_all: Optional[CatchAllVar]

    @dataclasses.dataclass
    class Bar:
        a: int
        b: int
        c: int
        d: int
        follow_up: str
        follow_up_default: Optional[str] = None
        _catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: {})

    foo_init = _CatchAllUndefinedParameters.create_init(Foo)

# Generated at 2022-06-11 21:11:27.291413
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from unittest import TestCase
    import typing
       
    class A:
        b: Any
        c: typing.Optional[dataclasses_json.CatchAllVar]

    class Test_handle_from_dict(_CatchAllUndefinedParameters, TestCase):

        def test_final_parameters_given_default_received_default(self):
            class A:
                b: Any
                c: typing.Optional[dataclasses_json.CatchAllVar] = {}

            final_parameters = \
                self.handle_from_dict(cls=A, kvs={'b': 1, 'c': {}})
            expected_final_parameters = {'b': 1, 'c': {}}
            self.assertEqual(final_parameters, expected_final_parameters)


# Generated at 2022-06-11 21:11:34.291980
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():

    class TestCase:
        def __init__(self, a: Any, b: Any, c: Any, d: Any):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    try:
        _UndefinedParameterAction.handle_from_dict(TestCase, {})
        raise Exception("Should have thrown an error")
    except UndefinedParameterError:
        pass


# Generated at 2022-06-11 21:11:45.942963
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect
    import types

    class B:
        pass

    class A(B):
        def __init__(self, a: int, b: int = 1, *args, **kwargs):
            self.a = a
            self.b = b

    assert A.__init__ is not B.__init__
    a = A(1, 2, 3, 4, 5)
    assert isinstance(a, A)
    assert isinstance(a, B)
    assert a.b == 2
    assert a.a == 1

    new_init = _IgnoreUndefinedParameters.create_init(A)

    assert isinstance(new_init, types.FunctionType)
    assert A.__init__ is not new_init


# Generated at 2022-06-11 21:11:54.773677
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import unittest
    from dataclasses import dataclass

    @dataclass
    class A:
        a: str = "a_default"
        catch_all: Optional[CatchAllVar] = None

    assert _CatchAllUndefinedParameters.handle_from_dict(A, {"a": "a_new"}) == \
           {"a": "a_new"}
    assert _CatchAllUndefinedParameters.handle_from_dict(A,
                                                         {"a": "a_new",
                                                          "catch_all": {
                                                              "a": "a_in_ca"}}) == \
           {"a": "a_new", "catch_all": {"a": "a_in_ca"}}

# Generated at 2022-06-11 21:11:59.718850
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        ca: int
        cb: int

        def __init__(self, a: int, b: int, ca: int, cb: int):
            self.a = a
            self.b = b
            self.ca = ca
            self.cb = cb

    @dataclasses.dataclass
    class B:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3, 4)
    b = B(1, 2, 3)


# Generated at 2022-06-11 21:12:01.189854
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, None) == {}

# Generated at 2022-06-11 21:12:07.354802
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    given = {"a": 1, "b": 2, "c": 3, "_catch_all": {"d": 4, "e": 5}}

    expected = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    result = _CatchAllUndefinedParameters.handle_to_dict(
        obj=None, kvs=given)

    assert expected == result

# Generated at 2022-06-11 21:12:16.514635
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        bar: str
        baz: str
        _undefined: Optional[CatchAllVar] = dataclasses.field(
            default=None)

        def __init__(self, bar: str, baz: str, _undefined: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(Foo)
    foo = Foo("hello", "world")
    init(foo, "hello", "world")

    bar = Foo("hello", "world", _undefined={"meaning_of_life": 42})
    init(bar, "hello", "world", _undefined={"meaning_of_life": 42})

    with pytest.raises(TypeError):
        init(foo, "hello")



# Generated at 2022-06-11 21:12:23.728416
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c):
            pass
    assert inspect.getsource(_UndefinedParameterAction.create_init(TestClass)) == \
        inspect.getsource(TestClass.__init__)

    class TestClass:
        def __init__(self, **kwargs):
            pass
    assert inspect.getsource(
        _UndefinedParameterAction.create_init(TestClass)) == \
           inspect.getsource(TestClass.__init__)



# Generated at 2022-06-11 21:12:32.223376
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass(frozen=True)
    class TestCatchAll:
        a: int
        b: str
        c: CatchAll = dataclasses.field(default=None)

    input = {"a": 1, "b": "a", "d": "e"}
    expected = {"a": 1, "b": "a", "d": "e"}
    obj = TestCatchAll(a=1, b="a", c={"d": "e"})
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, input) == expected

    input = {"a": 1, "b": "a"}
    obj = TestCatchAll(a=1, b="a")
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, input) == input

#

# Generated at 2022-06-11 21:14:25.628545
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        pass

    TestClass.__init__ = lambda self: None
    result = _UndefinedParameterAction.create_init(TestClass)
    assert result is TestClass.__init__



# Generated at 2022-06-11 21:14:36.604042
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a, **kwargs):
            self.a = a
            self.kwargs = kwargs

    a = A(a=5, b=3)

    def test(kwargs: dict) -> dict:
        known, _ = _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=A, kvs=kwargs)
        return known

    assert test({"a": 0, "b": 10}) == {"a": 0}
    assert test({"a": 0, "b": 10, "c": 3}) == {"a": 0}
    assert test({"a": 0, "b": 10, "c": 3, "d": 2}) == {"a": 0}

# Generated at 2022-06-11 21:14:49.563204
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a, b, c, catch_all=dataclasses.MISSING):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all


    a = _CatchAllUndefinedParameters.create_init(A)(None, 1, 2, 3, 4, 5)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    assert a.catch_all == {"_UNKNOWN0": 4, "_UNKNOWN1": 5}

    a = _CatchAllUndefinedParameters.create_init(A)(None, 1, 2, 3, 4, a=5, b=6)
    assert a.a == 1
    assert a.b == 2

# Generated at 2022-06-11 21:14:59.353684
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses
    from typing import Optional

    from dataclasses_json.config import Undefined


    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class Dummy:
        fieldA: int = dataclasses.field(default=42)
        fieldB: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.field(default=None))


    dummy = Dummy(fieldA=1, fieldB=3)

    assert dummy.fieldB is None
    assert dummy.fieldA == 1

# Generated at 2022-06-11 21:15:03.861433
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Example:
        a: int
        b: int

    init_with_default: Callable = \
        _IgnoreUndefinedParameters.create_init(Example)
    example_obj = init_with_default(Example(1, 2), 3, 4, 5, c=6, d=7)
    assert example_obj.a == 1
    assert example_obj.b == 2



# Generated at 2022-06-11 21:15:16.100518
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Person:
        def __init__(self, first_name: str, last_name: str, age: int,
                     catch_all: Optional[CatchAllVar] = None,
                     undefined_param: str = "foo"):
            self.first_name = first_name
            self.last_name = last_name
            self.age = age
            self.catch_all = catch_all
            self.undefined_param = undefined_param

        @classmethod
        def from_dict(cls, kvs: Dict):
            known, unknown = \
                _UndefinedParameterAction._separate_defined_undefined_kvs(
                    cls=cls, kvs=kvs)