

# Generated at 2022-06-11 21:05:32.114764
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-11 21:05:39.009675
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses
    import dataclasses_json
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        a: int = 0

    for init_args in [dict(), dict(a=1), dict(b=2)]:
        test_class = dataclasses_json.cfg(
            object_hook=_CatchAllUndefinedParameters.handle_from_dict
        ).load(init_args, TestClass)
        assert isinstance(test_class, TestClass)
        assert test_class.a == init_args.get("a", 0)

    @dataclasses.dataclass
    class TestClass2:
        b: int = 0


# Generated at 2022-06-11 21:05:50.171237
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int

    test_dict = {'c': 12}
    parse_fn = _RaiseUndefinedParameters.handle_from_dict
    assert {'a': 'a', 'b': 4} == parse_fn(TestClass, {'a': 'a', 'b': 4})
    assert {'a': 'a', 'b': 4} == parse_fn(TestClass, {'a': 'a', 'b': 4, 'c': 12})
    assert {'a': 'a', 'b': 4} == parse_fn(TestClass, {'a': 'a', 'b': 4, 'c': [1,2,3]})

# Generated at 2022-06-11 21:05:55.924315
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: int, b: int, c: int):
            ...

    class B:
        def __init__(self, a: int, b: int, *args, **kwargs):
            ...


# Generated at 2022-06-11 21:06:04.127017
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int
        c: str

    tc = TestClass("hello", 42, "world")
    assert tc.a == "hello"
    assert tc.b == 42
    assert tc.c == "world"

    def new_init(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    _IgnoreUndefinedParameters.create_init.__get__(tc, TestClass)(new_init)

    tc = TestClass("hello", 42, "world")
    assert tc.a == "hello"
    assert tc.b == 42
    assert tc.c == "world"

# Generated at 2022-06-11 21:06:12.217550
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():

    @dataclasses.dataclass
    class Example:
        catch_all: CatchAllVar = None

    example = Example()
    dictionary = _CatchAllUndefinedParameters.handle_dump(example)
    assert isinstance(dictionary, dict)
    assert dictionary == {}

    example = Example(catch_all={"a": 1})
    dictionary = _CatchAllUndefinedParameters.handle_dump(example)
    assert isinstance(dictionary, dict)
    assert dictionary == {"a": 1}



# Generated at 2022-06-11 21:06:14.209109
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(None, {1: 2, 3: 4}) == {1: 2, 3: 4}



# Generated at 2022-06-11 21:06:19.087217
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    values = {
        "a": "aaa",
        "b": "bbb",
        "catch_all": {
            "c": "ccc",
            "d": "ddd"
        }
    }

    schema = CatchAllSchema(CatchAll)

    result = schema.load(values)

    assert result.data == {
        "a": "aaa",
        "b": "bbb",
        "c": "ccc",
        "d": "ddd"
    }


# class to test handling of undefined parameters

# Generated at 2022-06-11 21:06:23.792458
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a: str, b: str, c: str):
            self.a, self.b, self.c = a, b, c

    class B(A):
        pass

    kvs = {'a': 'aaa', 'b': 'bbb', 'c': 'ccc', 'd': 'ddd'}

    # Test _RaiseUndefinedParameters
    assert kvs == _RaiseUndefinedParameters.handle_from_dict(A, kvs)
    try:
        _RaiseUndefinedParameters.handle_from_dict(B, kvs)
    except UndefinedParameterError:
        pass

    # Test _IgnoreUndefinedParameters
    assert kvs == _IgnoreUndefinedParameters.handle_from_dict(A, kvs)
    assert kvs == _Ign

# Generated at 2022-06-11 21:06:35.051968
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    defined_kvs = dict(a=1, b=2)
    undefined_kvs = dict(c=3)
    kvs = {**defined_kvs, **undefined_kvs}
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs) == (defined_kvs, undefined_kvs)

    # Check if correct arguments are returned when no undefined parameters are
    # present
    actual = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert actual == defined_kvs

    # Check if error is raised when undefined parameters are present

# Generated at 2022-06-11 21:06:54.913893
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    def get_default_dict() -> Dict[str, Any]:
        return {"field1": "value1"}

    @dataclasses.dataclass(frozen=True)
    class TestClass(object):
        field1: str
        field2: Optional[CatchAllVar] = dataclasses.field(
            default_factory=get_default_dict)

    assert dataclasses.is_dataclass(TestClass)

    # Case 1: No extra parameters given
    testobject = dataclasses.asdict(TestClass(field1="value1",
                                              field2={"field2": "value2"}))
    correct = {"field1": "value1", "field2": {"field2": "value2"}}
    assert testobject == correct

    # Case 2: No extra parameters given (case sensitive)


# Generated at 2022-06-11 21:07:03.142336
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert isinstance(_UndefinedParameterAction, abc.ABC)

    class UndefinedClass:
        def __init__(self, *args, **kwargs):
            pass

        def __setattr__(self, arg1, arg2):
            pass

    assert UndefinedClass.__init__ is not UndefinedClass.__setattr__
    instance = UndefinedClass()
    assert UndefinedClass.__init__ is instance.__setattr__

    instance = _UndefinedParameterAction.create_init(instance)()
    assert UndefinedClass.__init__ is instance.__setattr__



# Generated at 2022-06-11 21:07:12.832769
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class TestClass:
        field1: int
        field2: int = 5
        catch_all: Optional[dataclasses_json.CatchAllVar] = None

        def __init__(self, field1: int, field2: Optional[int] = None,
                     catch_all: Optional[dataclasses_json.CatchAllVar] = None):
            self.field1 = field1
            self.field2 = field2

    empty_kvs = {}
    assert _CatchAllUndefinedParameters.handle_from_dict(TestClass, empty_kvs) \
           == {"field1": 5}

    kvs_with_one_defined_parameter = {"field1": 1}
    assert _CatchAllUnd

# Generated at 2022-06-11 21:07:25.155232
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from collections import namedtuple

    Tuple = namedtuple('Tuple', ['a', 'b', 'c'])

    from dataclasses_json.core import get_default_encoder
    encoder = get_default_encoder(undefined=Undefined.INCLUDE)

    Tuple_to_dict = encoder.encoders[Tuple]

    _CatchAllUndefinedParameters.handle_to_dict(Tuple(1, 2, 3), {'a': 1, 'b': 2, 'c': 3}) \
        == {'a': 1, 'b': 2, 'c': 3}
    Tuple_to_dict(Tuple(1, 2, 3)) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 21:07:33.861737
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: float

    class _MockUndefinedParameterAction(_UndefinedParameterAction):
        @staticmethod
        def handle_from_dict(cls, kvs: Dict) -> Dict[str, Any]:
            return kvs

    class_parameters = {"x": 0, "y": 1.0}
    assert class_parameters == \
           _UndefinedParameterAction._separate_defined_undefined_kvs(
               cls=TestClass, kvs=class_parameters)[0]

    extra_parameters = {"z": 2.0}

# Generated at 2022-06-11 21:07:44.655148
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass
    class ChildCatchAll:
        catch_all: CatchAllVar = dataclasses.field(default=dict)

    @dataclasses.dataclass
    class ChildIgnore:
        ignore: str = dataclasses.field(default="")

    @dataclasses.dataclass
    class ChildRaise:
        ignore: str = dataclasses.field(default="")

    @dataclasses.dataclass
    class ParentCatchAll:
        catch_all: CatchAllVar = dataclasses.field(default=dict)
        child1: ChildCatchAll = dataclasses.field(default=ChildCatchAll())
        child2: ChildIgnore = dataclasses.field(default=ChildIgnore())

# Generated at 2022-06-11 21:07:47.526230
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert repr(UndefinedParameterError("foo")) == \
        "UndefinedParameterError(message='foo', field=None, fields={})"

# Generated at 2022-06-11 21:07:48.871449
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("_test_")

# Generated at 2022-06-11 21:07:51.407468
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-11 21:08:03.058687
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(unsafe_hash=True, frozen=False)
    class TestIgnoreUndefinedParameters:
        field1: str
        field2: str
        field3: str = "field3"
        field4: str = dataclasses.field(default_factory=lambda: "field4")
        field5: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    testobj = TestIgnoreUndefinedParameters

    init_function = _CatchAllUndefinedParameters.create_init(testobj)
    test1 = init_function(testobj("a", "b"), "", "other", "third", a="b",
                          c=3, d=4)
    assert test1.field1 == "a"

# Generated at 2022-06-11 21:08:32.561287
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class C:
        pass

    kvs = {"a": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(C, kvs)
    except UndefinedParameterError as error:
        assert str(error) == "Received undefined initialization arguments {'a': 1}"
        return
    raise AssertionError("Expected exception to be raised")



# Generated at 2022-06-11 21:08:37.263104
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def dummy_handle_dump(obj):
        return {"k": "v"}

    class Dummy(_UndefinedParameterAction):
        @staticmethod
        def handle_dump(obj) -> Dict[Any, Any]:
            return dummy_handle_dump(obj)

    assert Dummy.handle_dump(None) == {"k": "v"}

# Generated at 2022-06-11 21:08:44.451219
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass(object):

        int_field: int
        str_field: str
        optional_field: Optional[int] = None

        def __init__(self, int_field: int, str_field: str,
                     optional_field: Optional[int] = None):
            self.int_field = int_field
            self.str_field = str_field
            self.optional_field = optional_field

    testclass_init = TestClass.__init__
    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    testclass = TestClass(int_field=1, str_field="strvalue",
                          optional_field=None)

# Generated at 2022-06-11 21:08:54.286100
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Example:
        def __init__(self, a, b=2, *args, **kwargs):
            self.a = a
            self.b = b
            self.args = args
            self.kwargs = kwargs

    obj = Example(1, 2, 3, c=4)
    new_init = _CatchAllUndefinedParameters.create_init(obj=Example)

    obj2 = Example(a=1, b=2, c=4, d=5)
    obj3 = Example(a=1)
    obj4 = Example(a=1, b=2, c=4, d=5, _UNKNOWN0=3)

    print(obj)
    print(obj2)
    print(obj3)
    print(obj4)

# Generated at 2022-06-11 21:08:54.844283
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-11 21:08:57.326479
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError('empty')
    assert error.messages == ['empty']

# Generated at 2022-06-11 21:08:59.430290
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-11 21:09:08.429915
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, x: int):
            self.x = x

    _RaiseUndefinedParameters.handle_from_dict(Example, {})
    _RaiseUndefinedParameters.handle_from_dict(Example, {"x": 42})
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Example,
                                                   {"y": 42})

    class Example2:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

    _RaiseUndefinedParameters.handle_from_dict(Example2, {"x": 42})
    _RaiseUndefinedParameters.handle_from_dict(Example2, {"x": 42, "y": 42})

# Generated at 2022-06-11 21:09:17.585151
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class DataclassWithCatchAll:
        x: float
        y: float
        z: float = 6.0
        _UNDEFINED: CatchAllVar = dataclasses.field(default_factory=dict)

    class DataclassWithCatchAllSubclass(DataclassWithCatchAll):
        # noinspection PyUnusedLocal,PyShadowingBuiltins
        def __init__(self, x: float, y: float = 2.0, z: float = 4.0,
                     **kwargs):
            # noinspection PyArgumentList
            super().__init__(x=x, y=y, z=z)

    class DataclassWithoutCatchAll:
        x: float
        y: float

# Generated at 2022-06-11 21:09:19.086883
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    _UndefinedParameterAction.handle_dump(cls=None)

# Generated at 2022-06-11 21:10:16.020096
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def foo(self, hello: str, world: str = None,
            **kwargs) -> None:
        pass


# Generated at 2022-06-11 21:10:20.483397
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():

    # Unit test for the __init__ method of class UndefinedParameterError.
    exception = UndefinedParameterError("Test Message")
    assert exception.message == "Test Message"
    assert exception.__str__() == "Test Message"


# Generated at 2022-06-11 21:10:27.925598
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class SomeClass:
        def __init__(self, a: int, b: str, c: str,
                     catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    @dataclasses.dataclass
    class SomeDataclass(object):
        a: int
        b: str
        c: str
        catch_all: CatchAll = None

    @dataclasses.dataclass
    class SomeDataclassWithDefault(object):
        a: int
        b: str
        c: str = "default value"
        catch_all: CatchAll = None

    @dataclasses.dataclass
    class SomeDataclassWithDefaultFactory(object):
        a: int
        b: str

# Generated at 2022-06-11 21:10:29.323001
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-11 21:10:38.198973
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    kvs = {"foo": "bar"}
    actual = _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs=kvs)
    assert actual == kvs, "Return should be the same"

    obj = object()
    kvs = {"foo": "bar", "_UNKNOWN0": "spam"}
    expected = {"foo": "bar"}
    actual = _CatchAllUndefinedParameters.handle_to_dict(obj=obj, kvs=kvs)
    assert actual == expected, "Remove unknown param. in return"

    kvs = {"foo": "bar", "_UNKNOWN1": "spam"}
    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_to_dict(obj=obj, kvs=kvs)


# Generated at 2022-06-11 21:10:48.544410
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c=1, d=2):  # type: ignore
            self.a = a
            self.b = b
            self.c = c

    original_init = Test.__init__
    init_signature = inspect.signature(Test.__init__)

    replacement_init = _UndefinedParameterAction.create_init(Test)
    replacement_init_signature = inspect.signature(replacement_init)

    assert init_signature==replacement_init_signature

# Generated at 2022-06-11 21:10:59.971874
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class CatchAllTest:
        def __init__(self, **kvs):
            assert isinstance(kvs, dict)
            self.__dict__.update(kvs)

        catch_all = CatchAll(default_factory=dict)

    obj = CatchAllTest(**{
        "a": 1,
        "b": 2,
        "c": 3
    })

    # Check that no error occurs
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, {
        "a": 1,
        "b": 2,
        "catch_all": {"c": 3}
    })

# Generated at 2022-06-11 21:11:01.138968
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError(msg="any_message")

# Generated at 2022-06-11 21:11:13.645212
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass(unsafe_hash=True)
    class TestClass:
        a: str
        b: bool

        def __init__(self, a: str, b: bool = False) -> None:
            pass

    assert TestClass.__init__ != _IgnoreUndefinedParameters.create_init(
        TestClass)()

    # noinspection PyUnusedLocal
    @dataclasses.dataclass(unsafe_hash=True)
    class TestClass:
        a: str
        b: bool

        def __init__(self, a: str, b: bool = False,
                     c: str = "C") -> None:
            pass

    assert TestClass.__init__ != _IgnoreUndefinedParameters.create_init(
        TestClass)

# Generated at 2022-06-11 21:11:23.204522
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnresolvedReferences
    class Test:
        def __init__(self, a: str, b: str, c: str = "def_c",
                     d: CatchAll = None):
            pass

        def __init__(self, a: str, b: str, d: CatchAll = None,
                     c: str = "def_c"):
            pass

        def __init__(self, a: str, b: str, c: str = "def_c"):
            pass

    import pytest
    # noinspection PyProtectedMember

# Generated at 2022-06-11 21:13:15.592431
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class EmptyDataclass:
        pass

    class DataclassWithFields:
        a: str
        b: str
        c: str


# Generated at 2022-06-11 21:13:22.683125
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        x: int
        x2: int = 10

    kvs = {
        "x": 5,
        "x2": 5,
    }

    parameters = _RaiseUndefinedParameters \
        .handle_from_dict(TestClass, kvs)

    assert "x" in parameters
    assert parameters["x"] == 5
    assert "x2" in parameters
    assert parameters["x2"] == 5

    kvs = {
        "x": 5,
        "x2": 5,
        "x3": "hello",
    }

# Generated at 2022-06-11 21:13:28.480809
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: float
        c: str

    initializer = _RaiseUndefinedParameters.handle_from_dict
    assert initializer(MyClass, {"a": 1}) == {"a": 1}
    assert initializer(MyClass, {"a": 1, "b": 1.1}) == {"a": 1, "b": 1.1}
    assert initializer(MyClass, {"a": 1, "b": 1.1, "c": "asdf"}) == \
           {"a": 1, "b": 1.1, "c": "asdf"}

# Generated at 2022-06-11 21:13:40.542371
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Example:
        def __init__(self, *, catch_all: CatchAll = None):
            self.catch_all = catch_all

    passed_values = {"first": 1, "second": 2, "third": 3}
    ex = Example(**passed_values)
    handled = _CatchAllUndefinedParameters.handle_to_dict(
        ex, passed_values)
    assert handled == {"first": 1, "second": 2, "third": 3}

    failed_values = {"first": 1, "second": 2, "third": 3,
                     "catch_all": {}}
    ex = Example(**failed_values)
    handled = _CatchAllUndefinedParameters.handle_to_dict(
        ex, failed_values)

# Generated at 2022-06-11 21:13:45.494455
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    parameters = {"a": "test", "b": 1, "d": True}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, parameters)
    assert result == {"a": "test", "b": 1, "c": 0}



# Generated at 2022-06-11 21:13:52.421047
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class DummyDataclass(object):
        def __init__(self, a: str):
            pass

    kvs: Dict = {"a": "hello"}
    # should not raise error
    _RaiseUndefinedParameters.handle_from_dict(DummyDataclass, kvs=kvs)

    kvs: Dict = {"a": "hello", "b": "world"}
    # should raise error
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(DummyDataclass, kvs=kvs)



# Generated at 2022-06-11 21:13:59.424673
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import inspect
    from dataclasses import dataclass
    from typing import Optional

    class _UndefinedParameterActionTest(_UndefinedParameterAction):
        pass

    @dataclass(frozen=False)
    class ClassTest1(object):
        a: Optional[str] = None
        b: Optional[str] = None

        def __init__(self, a, b):
            self.a = a
            self.b = b

    @dataclass(frozen=False)
    class ClassTest2(object):
        a: Optional[str] = None
        b: Optional[str] = None

        def __init__(self, a, b=None):
            self.a = a
            self.b = b


# Generated at 2022-06-11 21:14:00.576731
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError:
        pass

# Generated at 2022-06-11 21:14:11.029432
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Base:
        def __init__(self, a, b, *args, **kwargs):
            self.a = a
            self.b = b

    class IgnoreClass(Base):
        _undefined_parameters = _IgnoreUndefinedParameters

    class CatchAllClass(Base):
        _undefined_parameters = _CatchAllUndefinedParameters
        _ = CatchAllVar

    class RaiseClass(Base):
        _undefined_parameters = _CatchAllUndefinedParameters

    class MyClass(IgnoreClass, RaiseClass):
        _undefined_parameters = _IgnoreUndefinedParameters

    # Test for IgnoreClass:
    ignore_class = MyClass(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8, j=10)



# Generated at 2022-06-11 21:14:21.524504
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    import dataclasses_json as dcj
    @dcj.dataclass_json(undefined=dcj.Undefined.RAISE, letter_case=dcj.LetterCase.CAMEL)
    class A:
        a: int
        def __init__(self, a: int, **kwargs):
            super().__init__()
            self.a = a

    with pytest.raises(UndefinedParameterError):
        A.schema().load({"a": 1, "b": 2})

    @dcj.dataclass_json(undefined=dcj.Undefined.INCLUDE, letter_case=dcj.LetterCase.CAMEL)
    class B:
        a: int
        # CatchAll will be used to write all unkown data
        _unknown: dcj.CatchAll