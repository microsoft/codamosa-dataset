

# Generated at 2022-06-11 21:05:38.290924
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

            self.undefined: Dict[str, Any] = {}

    # Test case 1
    kvs = {"a": 1, "b": 2, "c": 3, "undefined": {"a": 2}}
    assert _UndefinedParameterAction.handle_to_dict(TestClass, kvs) == \
           {"a": 1, "b": 2, "c": 3}

    # Test case 2
    kvs = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-11 21:05:44.524515
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[int]

    result = _UndefinedParameterAction.handle_dump(TestClass(a=1, b=2, c=3))
    assert result == {}

    result = _CatchAllUndefinedParameters.handle_dump(TestClass(a=1, b=2, c=3))
    assert result == {}

# Generated at 2022-06-11 21:05:46.292093
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError, match="test message"):
        raise UndefinedParameterError("test message")

# Generated at 2022-06-11 21:05:52.108035
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    test_kv_pairs = {"a": 1,
                     "b": 2,
                     "c": 3}
    test_handler = _UndefinedParameterAction()
    assert test_handler.handle_dump(test_kv_pairs) == {}



# Generated at 2022-06-11 21:06:02.808612
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # pylint: disable=import-outside-toplevel
    from dataclasses import dataclass
    from dataclasses_json import Undefined

    @dataclass
    class Class:
        a: str
        b: Optional[int] = None
        c: Optional[Undefined.CatchAll] = Undefined.CatchAll()

    obj = Class(a="test", b=2, c={"a": 2, "b": 2})
    params: Dict[str, Any] = {"a": "test", "b": 2, "c": {"a": 2, "b": 2}}

    assert _CatchAllUndefinedParameters.handle_to_dict(obj, params) \
           == {"a": "test", "b": 2, "a": 2, "b": 2}



# Generated at 2022-06-11 21:06:07.600744
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(
        None,
        {
            "foo": "bar",
            "catch_all_field_name": {}
        }
    ) == {
        "foo": "bar",
    }

    assert _CatchAllUndefinedParameters.handle_to_dict(
        None,
        {
            "foo": "bar",
            "catch_all_field_name": {
                "extra_field": "extra_value"
            }
        }
    ) == {
        "foo": "bar",
        "extra_field": "extra_value"
    }



# Generated at 2022-06-11 21:06:18.218161
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses

    @dataclasses.dataclass
    class MyClass(UndefinedParameterHandlerMixin):
        a: int
        b: str
        c: int = 5
        d: int = dataclasses.field(default=6)
        e: int = dataclasses.field(default_factory=lambda: 7)
        _undefined: Optional[CatchAllVar] = \
            dataclasses.field(default_factory=dict)

    kvs = dict()
    kvs["a"] = 1
    kvs["b"] = "2"
    kvs["c"] = 3
    kvs["d"] = 4
    kvs["e"] = 5
    kvs["f"] = 6
    kvs["g"] = 7

# Generated at 2022-06-11 21:06:26.373175
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test instantiating the class :py:class:`UndefinedParameterError`.
    """
    error_messages = [
        "Received undefined initialization arguments {'one': 1, 'two': 2}",
        "No field of type dataclasses_json.CatchAll defined",
        "Multiple catch-all fields supplied: 1."
    ]
    for error_message in error_messages:
        UndefinedParameterError(error_message)
    return True

# Generated at 2022-06-11 21:06:38.202496
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    def _create_class(fields):
        @dataclasses.dataclass
        class Target:
            pass
        for field in fields:
            setattr(Target, field.name, field.default)
        return Target

    # Given
    field_1 = dataclasses.field(default=1)
    field_2 = dataclasses.field(default=2)
    field_3 = dataclasses.field(default=3)

    class_fields = [field_1, field_2, field_3]
    unknown_parameters = {
        "x": "X",
        "y": "Y"
    }
    kvs = {
        **{f.name: f.default for f in class_fields},
        **unknown_parameters
    }

# Generated at 2022-06-11 21:06:49.705124
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, x, y, z=True, w=False):
            self.x = x
            self.y = y
            self.z = z
            self.w = w

    init = _UndefinedParameterAction.create_init(TestClass)

    @functools.wraps(TestClass.__init__)
    def test_init(self, x, y, z=True, w=False):
        init(self, x, y, z=z, w=w)

    test_init(TestClass(1, 'a'), 1, 'a', z=True, w=False)
    test_init(TestClass(1, 'a'), 1, 'a')
    test_init(TestClass(1, 'a'), 1, 'a', w=False)
    test

# Generated at 2022-06-11 21:07:11.943780
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class SimpleClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kwargs1 = dict(a=1, b=2)
    kwargs2 = dict(a=2, b=2)
    kwargs3 = dict(a=1, b=2, c=3)
    kwargs4 = dict(a=1, b=2, c=3, d=4)
    kwargs5 = dict(a=1, b=2, c=3, d=4, e=5)
    kwargs6 = dict(a=1, b=2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-11 21:07:23.949850
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from typing import Optional

    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    with config(enforce_optional=False):
        @dataclass
        class Test:
            s: str
            i: int

        @dataclass
        class OptionalTest:
            s: Optional[str]
            i: int

        @dataclass
        class OptionalCatchAllTest:
            s: Optional[str] = None
            i: int
            c: Optional[CatchAllVar] = None

    test = Test("foo", 3)
    optional_test = OptionalTest("foo", 3)
    optional_catch_all_test = OptionalCatchAllTest("foo", 3)

    # Test without any unknown fields

# Generated at 2022-06-11 21:07:31.061825
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class foo:
        def __init__(self, catch_all: catchAll = None):
            self.catch_all = catch_all
    c = foo()
    d = {"a": 1}
    r = _UndefinedParameterAction.handle_to_dict(c, d)
    assert r == {"a": 1}
    c.catch_all = d
    r = _UndefinedParameterAction.handle_to_dict(c, d)
    assert r == {}
    assert c.catch_all == {"a": 1}

# Generated at 2022-06-11 21:07:42.323082
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    kvs = {"k1": "v1", "k2": "v2"}


    def get_class(field_names):
        class TestClass:
            pass

        for field_name in field_names:
            setattr(TestClass, field_name, "not defined")
        return TestClass

    TestClass = get_class(field_names=["k1"])
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"k1": "v1"}
    assert unknown == {"k2": "v2"}

    TestClass = get_class(field_names=["k1", "k2"])

# Generated at 2022-06-11 21:07:53.031885
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo:

        def __init__(self, a: str, b: int):
            self.a = a
            self.b = b

    @dataclasses.dataclass
    class Bar:

        a: int
        b: str
        c: int = dataclasses.field(default=3)

    # None given
    for obj in [Foo, Bar]:
        result = _IgnoreUndefinedParameters.handle_from_dict(obj, {})
        assert len(result) == 0

    # One given
    for obj in [Foo, Bar]:
        result = _IgnoreUndefinedParameters.handle_from_dict(obj,
                                                             {"a": "b"})
        assert len(result) == 1
        assert result["a"] == "b"

    # Two given

# Generated at 2022-06-11 21:08:03.975589
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        number_field: int = dataclasses.field(default=7)
        name_field: str = dataclasses.field(default="default name")
        catch_all_field: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAllVar())

        def __init__(self, *args, **kwargs):
            return


    tc = TestClass()
    init_method = _CatchAllUndefinedParameters.create_init(tc)
    kv_parameters = {
        "number_field": 1,
        "name_field": "Name",
    }

# Generated at 2022-06-11 21:08:14.530933
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    data = {"a": 3.14, "b": "undefined", "c": {"a": 1}}
    field_names = ["a", "c"]
    known_parameters, undefined_parameters = _RaiseUndefinedParameters.handle_from_dict(field_names, data)
    assert known_parameters["a"] == 3.14
    assert known_parameters["c"]["a"] == 1
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(field_names, data, raise_on_error=True)


# Generated at 2022-06-11 21:08:25.564791
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class X:
        a: str
        b: int

    x = X(a="a", b=0)
    x2 = X(**_CatchAllUndefinedParameters.handle_from_dict(
        X, {"a": "a", "b": 0}))
    x3 = X(**_CatchAllUndefinedParameters.handle_from_dict(
        X, {"a": "a", "b": 0, "c": 0}))
    assert x == x2
    assert x == x3

    with pytest.raises(UndefinedParameterError):
        X(**_RaiseUndefinedParameters.handle_from_dict(
            X, {"a": "a", "b": 0, "c": 0}))


# Generated at 2022-06-11 21:08:28.544233
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError as e:
        assert type(e) == UndefinedParameterError
        assert e.args == ("",)

# Generated at 2022-06-11 21:08:39.058427
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, x: Any, y: Any, *, c: Dict[str, Any]):
            pass

    given_params = {"x": 1, "y": 2, "c": {"d": 3, "e": 4}}
    catch_all_params = _CatchAllUndefinedParameters.handle_from_dict(
        cls=A, kvs=given_params)
    assert catch_all_params == {"x": 1, "y": 2, "c": {"d": 3, "e": 4}}

    given_params = {"y": 2, "c": {"d": 3}, "x": 1}
    catch_all_params = _CatchAllUndefinedParameters.handle_from_dict(
        cls=A, kvs=given_params)
    assert catch_all

# Generated at 2022-06-11 21:09:03.514924
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dic = {"a": {"a": 1}}
    assert _UndefinedParameterAction.handle_dump(dic) == {}
    # assert _IgnoreUndefinedParameters.handle_to_dict(dic, {"a": {"a": 1}}) == {"a": {"a": 1}}
    # assert _IgnoreUndefinedParameters.handle_to_dict(dic, {"b": {"a": 1}}) == {"b": {"a": 1}}


# Generated at 2022-06-11 21:09:13.801218
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class WithInit:
        def __init__(self, a: int, b: int, c: int, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    class WithoutInit:
        pass

    for our_class in [WithInit, WithoutInit]:
        init_func = _IgnoreUndefinedParameters.create_init(obj=our_class)

        our_instance = init_func(our_class, 1, 2, 3, 4, e=5)
        assert our_instance.a == 1
        assert our_instance.b == 2
        assert our_instance.c == 3
        assert our_instance.d == 4

        our_instance = init_func(our_class, 1, 2, 3, e=5)
        assert our_

# Generated at 2022-06-11 21:09:26.035351
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def assert_error(kvs: Dict, msg: str):
        try:
            class Dummy:
                def __init__(self, foo=None, *, bar=None, **kwargs):
                    pass

            Dummy(**kvs)
        except UndefinedParameterError as error:
            assert str(error) == msg
        else:
            assert False

    assert_error(kvs={}, msg="")
    assert_error(kvs={"foo": 1}, msg="")
    assert_error(kvs={"bar": 1}, msg="")
    assert_error(kvs={"foo": 1, "bar": 2}, msg="")
    assert_error(kvs={"foo": 1, "bar": 2, "baz": 3},
                 msg="Received undefined initialization arguments {'baz': 3}")

# Generated at 2022-06-11 21:09:37.479448
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import Undefined

    @dataclass(undefined=Undefined.INCLUDE)
    class C:
        x: str = "test"
        catch_all: CatchAll = None

    assert(C._UndefinedParameterAction.handle_from_dict(C, {
        "x": "test", "catch_all": {}}) == {"x": "test", "catch_all": {}})

    assert(C._UndefinedParameterAction.handle_from_dict(C, {
        "x": "test", "catch_all": {}, "something": "else"}) == {"x": "test",
                                                                "catch_all": {
                                                                    "something": "else"}})


# Generated at 2022-06-11 21:09:39.572709
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("a message")
    assert "a message" in str(error)

# Generated at 2022-06-11 21:09:48.406428
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Model:
        a: int
        b: str

        def __init__(self, a, b, *args, **kwargs):  # noqa: D107
            pass

    # Create a class that looks like the real class
    new_init = _IgnoreUndefinedParameters.create_init(Model)

    # We know that the original init accepts 4 arguments,
    # but 2 of them are positional, so we can only
    # supply one extra argument
    obj = Model(1, 2, 3, 4)
    new_obj = new_init(obj, 3, b=4)
    assert new_obj is obj
    assert new_obj.a == 1
    assert new_obj.b == "4"

    # We can supply the extra argument through a kwarg though
    obj

# Generated at 2022-06-11 21:09:54.984689
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a, b, c):
            pass

    call = _RaiseUndefinedParameters.handle_from_dict
    assert ("a", "b", "c") == call(Test, {"a": "a", "b": "b", "c": "c"}).keys()
    try:
        call(Test, {"a": "a", "b": "b", "c": "c", "d": "d"})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:10:06.336373
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int
        baz: int

    class Baz:
        pass

    kvs = {
        "bar": 1,
        "baz": 2,
        "undef": 3
    }
    defined, undefined = _UndefinedParameterAction._separate_defined_undefined_kvs(
        Foo, kvs)
    assert defined == {
        "bar": 1,
        "baz": 2
    }
    assert undefined == {
        "undef": 3
    }
    try:
        _RaiseUndefinedParameters.handle_from_dict(Foo, kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False

    # Even if we have a class that cannot be initialized,
   

# Generated at 2022-06-11 21:10:14.218463
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        a: int

    kvs = {"a": 3, "b": 4}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        Test, kvs)
    out = _RaiseUndefinedParameters.handle_from_dict(Test, kvs)
    assert out == known
    assert unknown == {"b": 4}



# Generated at 2022-06-11 21:10:26.383981
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # case 1: catch-all field is default value
    class Test(metaclass=ABCMeta):
        catch_all: CatchAll = CatchAllVar()

    class TestSubclass(Test):
        a = Field(default="a")
        b = Field(default="b")
        c = Field(default="c")

    input = {
        "b": "changedB",
        "d": "extraD",
        "e": "extraE"
    }
    wanted_output = {
        "a": "a",
        "b": "changedB",
        "c": "c",
        "catch_all": {
            "d": "extraD",
            "e": "extraE"
        }
    }

    result = _CatchAllUndefinedParameters.handle_from_dict(TestSubclass, input)

# Generated at 2022-06-11 21:11:09.751290
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=None, kvs={"a": 1, 2: 1, "c": 1})
    assert known == {"a": 1, "c": 1}
    assert unknown == {2: 1}



# Generated at 2022-06-11 21:11:16.130855
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(init=False)
    class A:
        a: int = dataclasses.field(default=1)
        b: str = dataclasses.field(default="B")

    a = A(a=2, b="b")
    assert a.a == 2
    assert a.b == "b"

    init = _CatchAllUndefinedParameters.create_init(A)
    a = A(a=1)
    init(a, "b", c="c")
    assert a.a == 1
    assert a.b == "B"

    with pytest.raises(TypeError):
        init(a, "b", c="c", d=5)

# Generated at 2022-06-11 21:11:23.032720
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    obj = _RaiseUndefinedParameters()

    @dataclasses.dataclass
    class _DummyClass:
        def __init__(self, b: int):
            self.b = b

    assert obj.handle_from_dict(_DummyClass, {}) == {}
    assert obj.handle_from_dict(_DummyClass, {"b": 2}) == {"b": 2}

    with pytest.raises(UndefinedParameterError):
        obj.handle_from_dict(_DummyClass, {"b": 2, "c": 3})



# Generated at 2022-06-11 21:11:31.955770
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, x, **kwargs):
            self.x = x
            self.y = kwargs.get("y", 0)
            self.z = kwargs.get("z", 10)

    a = A(x=1, z=2)
    output = _CatchAllUndefinedParameters.handle_to_dict(obj=A,
                                                         kvs=vars(a))
    assert output == {"x": 1, "y": 0, "z": 2}

# Generated at 2022-06-11 21:11:44.630942
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.unknown_parameters = c

    test_class = TestClass(a=1, b="test", c={"c": 1})

    result = _CatchAllUndefinedParameters.handle_to_dict(obj=test_class,
                                                         kvs={"a": 1,
                                                              "b": "test",
                                                              "c": {
                                                                  "c": 1}})
    assert result == {"a": 1, "b": "test"}

    dump = _CatchAllUndefinedParameters.handle_dump(obj=test_class)
    assert dump == {"c": 1}

    dump = _Catch

# Generated at 2022-06-11 21:11:53.892718
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, *, catch_all: CatchAll = None, **kwargs):
            self.catch_all = catch_all

    test = TestClass(catch_all={"a": 1, "b": 2})

    out = {"a": 1, "b": 2, "c": 2}
    result = _UndefinedParameterAction.handle_to_dict(test, out)
    assert result == {"a": 1, "b": 2, "c": 2}

    out = {"a": 1, "b": 2, "c": 2, CatchAllVar.__name__: {"a": 3}}
    result = _UndefinedParameterAction.handle_to_dict(test, out)
    assert result == {"a": 1, "b": 2, "c": 2}

# Generated at 2022-06-11 21:12:05.318585
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, bar: CatchAll = None):
            self.bar = bar

    obj = Foo()
    parameters = {
        "_UNKNOWN0": "test1",
        "_UNKNOWN1": "test2",
    }
    assert obj.bar is None
    assert _CatchAllUndefinedParameters.handle_from_dict(obj, parameters) \
           == {'bar': {'_UNKNOWN0': 'test1', '_UNKNOWN1': 'test2'}}

    parameters = {
        "_UNKNOWN0": "test1",
        "_UNKNOWN1": "test2",
        "bar": None
    }
    assert obj.bar is None

# Generated at 2022-06-11 21:12:15.397185
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Example:
        def __init__(self,
                     a: int = 1,
                     b: str = "b",
                     *,
                     catch_all=None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    replaced_init = _CatchAllUndefinedParameters.create_init(Example)
    ex = Example(a=2, b="bbb", c=3)
    replaced_ex = Example(a=2, b="bbb", c=3)

    assert ex.a == replaced_ex.a
    assert ex.b == replaced_ex.b
    assert ex.catch_all == replaced_ex.catch_all
    assert ex.__init__ != replaced_ex.__init__

# Generated at 2022-06-11 21:12:26.917854
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class C:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

        def __getitem__(self, item):
            return getattr(self, item)

    c = C(1, 2, 3)
    kvs = {"a": 1, "b": 2, "c": 3}

    # CatchAllUndefinedParameters
    ca_kvs = _CatchAllUndefinedParameters.handle_to_dict(c, kvs)
    assert ca_kvs["a"] == 1
    assert ca_kvs["b"] == 2
    assert ca_kvs["c"] == 3

    # IgnoreUndefinedParameters

# Generated at 2022-06-11 21:12:33.611967
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    given_parameters = {"a": "a",
                        "b": "b",
                        "c": "c",
                        "undefined_parameter": "z"}

    known_parameters = _RaiseUndefinedParameters \
        .handle_from_dict(TestClass, given_parameters)

    assert known_parameters == {"a": "a", "b": "b", "c": "c"}

    given_parameters = {"a": "a",
                        "b": "b"}

    known_parameters = _RaiseUndefinedParameters \
        .handle_from_dict(TestClass, given_parameters)

    assert known_param

# Generated at 2022-06-11 21:14:03.540728
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    m = dict(a=1, b=2)
    u = dict(x=9, y=10)
    k = dict(a=1, b=2, c=u)
    k_out = dict(a=1, b=2, c=u)
    assert _UndefinedParameterAction.handle_to_dict(k, k) == k_out



# Generated at 2022-06-11 21:14:13.639346
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class ClassA:
        def __init__(self, a=None, b=None, c=None, d=None, e=None):
            pass

    class ClassB:
        def __init__(self, a=None, b=None, c=None, catch_all: CatchAll = None):
            pass

    class ClassC:
        def __init__(self, a=None, b=None, c=None, d=None, e=None,
                     catch_all: CatchAll = None):
            pass

    modified_init = _IgnoreUndefinedParameters.create_init(ClassA)
    modified_init(ClassA(), a=1, b=2, c=3)
    modified_init(ClassA(), a=1, b=2, c=3, e=4)

# Generated at 2022-06-11 21:14:23.352459
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class C:
        a: int = 0
        b: int = 0
        _catch_all_dict: Optional[CatchAllVar] = None

    c = C.__new__(C)
    c.a = 1
    c.b = 2
    c._catch_all_dict = {
        3: 3}

    # noinspection PyProtectedMember
    assert _CatchAllUndefinedParameters.handle_to_dict(c, kvs={
        'a': 1,
        'b': 2,
        '_catch_all_dict': {3: 3}
    }) == {'a': 1,
           'b': 2,
           3: 3}

# Generated at 2022-06-11 21:14:29.618198
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    defined_kvs = _RaiseUndefinedParameters.handle_from_dict(A, {"x": 1,
                                                                  "y": 2})

    assert defined_kvs == {"x": 1, "y": 2}

    ok = False
    try:
        defined_kvs = _RaiseUndefinedParameters.handle_from_dict(A, {"x": 1,
                                                                      "y": 2,
                                                                      "z": 3})
    except UndefinedParameterError as e:
        ok = True
    finally:
        assert ok is True



# Generated at 2022-06-11 21:14:38.506436
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import List, Union
    from dataclasses import dataclass

    from marshmallow.exceptions import ValidationError

    @dataclass
    class Test:
        x: int
        y: int = 3

        def __init__(self, x: int, y: int = 3, **kwargs):
            self.x = x
            self.y = y
            super(Test, self).__init__(**kwargs)

    test = Test(1, 2)
    assert test.x == 1
    assert test.y == 2

    test = Test(1)
    assert test.x == 1

    # with unknown arguments
    with pytest.raises(ValidationError):
        Test(1, 2, undefined_argument_please_raise=3)

    # with unknown arguments and given default overridden

# Generated at 2022-06-11 21:14:42.510106
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        pass
    parameters = {"foo": "bar"}
    assert _UndefinedParameterAction.handle_dump(TestClass) == {}



# Generated at 2022-06-11 21:14:52.218394
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import datetime
    from dataclasses_json import config
    from inspect import signature


    @dataclasses.dataclass
    class Example:
        foo: str
        bar: int = 0
        baz: datetime.date = datetime.date(2345, 5, 6)
        undef: dict = dataclasses.field(default_factory=dict)


    # noinspection PyProtectedMember
    init_signature = signature(Example.__init__)

# Generated at 2022-06-11 21:15:03.079186
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _TestClass:

        def __init__(self, a: int, b: str = "default value",
                     undefined: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.undefined = undefined

    test_class = _TestClass

# Generated at 2022-06-11 21:15:09.501537
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DefinedParameterOnly:
        a: int

    with pytest.raises(UndefinedParameterError) as e:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=DefinedParameterOnly,
            kvs={"a": 1,
                 "b": 2})
    assert "Received undefined initialization arguments" in str(e.value)

