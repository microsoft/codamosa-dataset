

# Generated at 2022-06-11 21:05:37.595928
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = Undefined.EXCLUDE
    kvs = {'a': 1, 'b': 2}
    obj._UndefinedParameterAction.handle_to_dict(obj, kvs)



# Generated at 2022-06-11 21:05:48.294925
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    This test exercises init methods of the dataclasses_json.Undefined class in
    the context of a unit test.
    """
    @dataclasses.dataclass()
    class Foo:
        foo: str

    orig_init = Foo.__init__
    with pytest.raises(UndefinedParameterError):
        Undefined.IGNORE.value.create_init(Foo)()
    # assert that original init method has not changed
    assert orig_init == Foo.__init__

    @dataclasses.dataclass()
    class Bar:
        bar: str = dataclasses.field(default=None)

    with pytest.raises(UndefinedParameterError):
        Undefined.IGNORE.value.create_init(Bar)()


# Generated at 2022-06-11 21:05:53.753430
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str

    kvs = {"a": 1, "b": 2}
    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-11 21:06:03.718577
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar, Undefined

    class Test:
        catch_all: Optional[CatchAllVar] = Undefined.INCLUDE

    class Test2:
        catch_all: Optional[CatchAllVar]

    class Test3:
        catch_all: Optional[CatchAllVar] = Undefined.INCLUDE
        catch_all_2: Optional[CatchAllVar] = Undefined.INCLUDE

    class Test4:
        catch_all: Optional[CatchAllVar] = Undefined.INCLUDE

        def __init__(self, catch_all: Optional[CatchAllVar] = None,
                     **kwargs):
            self.catch_all = kwargs


# Generated at 2022-06-11 21:06:06.469677
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class EmptyClass:
        pass

    assert _CatchAllUndefinedParameters.create_init(EmptyClass)



# Generated at 2022-06-11 21:06:17.189913
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import dataclasses_json

    class Example(object):
        def __init__(self, field1: str, field2: str,
                     field3: str):
            self.field1 = field1
            self.field2 = field2
            self.field3 = field3


    @dataclasses_json.dataclass_json(undefined=Undefined.RAISE)
    class Example2(Example):
        pass


    kvs = {"field1": "value1", "field2": "value2",
           "field3": "value3", "field4": "value4"}
    result = Example2.from_dict(kvs)
    assert result.field1 == "value1"
    assert result.field2 == "value2"
    assert result.field3 == "value3"

    import pytest


# Generated at 2022-06-11 21:06:19.350620
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=None, kvs={})

# Generated at 2022-06-11 21:06:31.146624
# Unit test for method handle_from_dict of class _UndefinedParameterAction

# Generated at 2022-06-11 21:06:40.162489
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import Undefined

    @dataclass
    class _TestClass:
        a: int
        b: int

    _test_class = _TestClass(a=1, b=2)
    _test_class_dict = {"a": 1, "b": 2}

    result = _RaiseUndefinedParameters.handle_from_dict(_TestClass, _test_class_dict)
    assert result == _test_class_dict

    # test raise
    _test_class_dict_with_undefined = {"a": 1, "b": 2, "c": 3}
    try:
        _RaiseUndefinedParameters.handle_from_dict(_TestClass, _test_class_dict_with_undefined)
    except:
        pass

# Generated at 2022-06-11 21:06:46.529439
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import dataclass

    @dataclass
    class CatchAllUndefinedParametersTest:
        # noinspection PyTypeChecker
        cat_all: CatchAllVar
        a: int

    obj = CatchAllUndefinedParametersTest(cat_all={}, a=5)

    res = _CatchAllUndefinedParameters.handle_to_dict(obj, {**obj.__dict__})
    assert res == {"a": 5}

# Generated at 2022-06-11 21:07:00.759576
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # TODO: unit test

    pass

# Generated at 2022-06-11 21:07:11.028472
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    cls = dataclasses.make_dataclass("Class", [('x', int), ('y', float)])

    case_no_extra_parameters = dict(x=2)
    case_unexpected_parameter = dict(x=2, y=1.0, z=3)
    case_expected_parameter_not_found = dict(y=2.0)

    known, unexpected = _UndefinedParameterAction._separate_defined_undefined_kvs(cls=cls, kvs=case_unexpected_parameter)

    assert known == dict(x=2, y=1.0)
    assert unexpected == dict(z=3)

# Generated at 2022-06-11 21:07:22.632991
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    def assert_raises_undefined_parameter_error(cls, kvs: Dict):
        """
        Since we cannot instantiate an object of type Undefined,
        we check the behavior indirectly by checking
        if an UndefinedParameterError was raised.
        """
        _UndefinedParameterAction.handle_from_dict(cls=cls, kvs=kvs)

    class MyClassWithCatchAll:
        just_a_known_parameter: int
        catch_all: Optional[CatchAllVar] = None

    class MyClass:
        just_a_known_parameter: int

    class MyClassWithMultipleCatchAll(MyClassWithCatchAll):
        another_catch_all: Optional[CatchAllVar] = None

    # Tests for RaiseUndefinedParameters
    assert_raises_undefined_

# Generated at 2022-06-11 21:07:28.849385
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

    expected = Test(1, 2)
    t = Test(1, 2)
    t.__init__ = _IgnoreUndefinedParameters.create_init(Test)
    t.__init__(x=-1, c=3, a=1, b=2)
    assert expected == t



# Generated at 2022-06-11 21:07:36.272545
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    _UndefinedParameterAction.handle_to_dict is expected to return a
    dictionary that is the same
    but without the optional field 'opt_field'.
    """
    kvs = {"opt_field": "opt_val", "other": "other_val"}
    expected = {"other": "other_val"}
    assert _UndefinedParameterAction.handle_to_dict(None, kvs) == expected

# Generated at 2022-06-11 21:07:37.382613
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError(False)

# Generated at 2022-06-11 21:07:48.189489
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Sample:
        def __init__(self, value, **undefined):
            self.value = value
            self.undefined = undefined

        def for_json(self):
            return dict(
                value=self.value,
                undefined=self.undefined,
            )

        @classmethod
        def from_json(cls, json_dict):
            return cls(**json_dict)


    s = Sample(
        value=123,
        is_valid=True,
        name="Justin",
    )
    output = _UndefinedParameterAction.handle_to_dict(obj=Sample, kvs=s.for_json())
    assert output == dict(
        value=123,
        is_valid=True,
        name="Justin",
    )



# Generated at 2022-06-11 21:08:01.537616
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestData:
        pass

    @dataclasses.dataclass
    class Example:
        foo: str
        bar: int

        __UNDEFINED__ = _RaiseUndefinedParameters

    kvs = {"foo": "hello", "bar": 9}

    assert \
        _RaiseUndefinedParameters.handle_from_dict(Example, kvs) == kvs

    kvs_with_undefined_parameter = {"foo": "hello", "bar": 9, "fizz": "buzz"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(Example,
                                                   kvs_with_undefined_parameter)
        raise AssertionError(
            "This should have thrown an exception, but didn't")
    except UndefinedParameterError:
        pass  # This is the expected behaviour

# Generated at 2022-06-11 21:08:08.557265
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import Optional, Dict, Any

    from dataclasses import dataclass

    from dataclasses_json import DataClassJsonMixin


    @dataclass
    class CatchAllTest(DataClassJsonMixin):
        """
        Test class for class _CatchAllUndefinedParameters
        """
        a: int
        b: int
        c: Optional[int] = None

        def __post_init__(self):
            if self.a == self.b:
                raise Exception("a and b parameters need to have different "
                                "values")

        _undefined: CatchAllVar = _CatchAllUndefinedParameters

    test_kwargs_ignored_parameters = dict(a=1, b=2, d=3)
    kvs = _CatchAllUndefinedParameters.handle_from_dict

# Generated at 2022-06-11 21:08:19.542625
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestObject:
        def __init__(self, a: int, b: Optional[int] = None):
            self.a = a
            self.b = b

    test_object_1 = TestObject(a=1, b=2)
    params_1 = test_object_1.__dict__
    assert params_1 == _RaiseUndefinedParameters.handle_from_dict(
        cls=TestObject, kvs=params_1)
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestObject,
                                                   kvs={"c": 3})
    params_3 = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-11 21:08:45.302327
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError('testing')
    assert 'testing' in str(err)

# Generated at 2022-06-11 21:08:54.096675
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        def __init__(self, a: int, b: int):
            pass

    assert _UndefinedParameterAction.handle_from_dict(Test, {"a": 1, "b": 2}) \
           == {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_from_dict(Test, {"a": 1}) == {"a": 1}
    assert _UndefinedParameterAction.handle_from_dict(Test, {"b": 2}) == {"b": 2}
    assert _UndefinedParameterAction.handle_from_dict(Test, {}) == {}


# Unit tests for method handle_from_dict of class _RaiseUndefinedParameters

# Generated at 2022-06-11 21:08:55.266948
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-11 21:09:06.395536
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class DummyClass:
        def __init__(self, a: int, catch_all: CatchAll = None):
            self.a = a
            self.catch_all = catch_all

    dummy_class = DummyClass(a=1,  b=2, c=3)
    output = _CatchAllUndefinedParameters.handle_to_dict(obj=dummy_class,
                                                         kvs={'a': 1,
                                                         'b': 2,
                                                         'c': 3,
                                                         '_UNKNOWN0': 4,
                                                         '_UNKNOWN1': 5,
                                                         '_UNKNOWN2': 6})
    assert output == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 21:09:15.976230
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Tests the following method:
    _CatchAllUndefinedParameters.handle_from_dict(cls, kvs: Dict) -> Dict
    """

    @dataclasses.dataclass
    class A:
        fields = dataclasses.field(default_factory=dict)

    @dataclasses.dataclass
    class B:
        fields = dataclasses.field(default_factory=dict)
        undefined = CatchAll

    @dataclasses.dataclass
    class C:
        undefined = CatchAll
        fields = dataclasses.field(default_factory=dict)

    @dataclasses.dataclass
    class D:
        fields = dataclasses.field(default_factory=dict)
        undefined = CatchAll

# Generated at 2022-06-11 21:09:27.120766
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    kvs = {"firstname": "john", "lastname": "doe", "age": 42}

    @dataclasses.dataclass
    class TestClass:
        firstname: str
        lastname: str
        age: int
        # optionally there could be more fields
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)
        undefined_parameter_action: _UndefinedParameterAction = \
            _CatchAllUndefinedParameters

    @dataclasses.dataclass
    class TestClassTooLittleArguments:
        firstname: str
        lastname: str
        age: int
        # optionally there could be more fields
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)
        undefined_

# Generated at 2022-06-11 21:09:36.466275
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    D = _CatchAllUndefinedParameters._get_catch_all_field
    from dataclasses import dataclass

    @dataclass
    class Obj:
        x: int
        y: int
        z: int = 42
        _catch_all: Optional[CatchAllVar]


    obj = Obj(x="Hello", y="World", _catch_all={'extra': 'data'})
    obj_dict = dataclasses.asdict(obj)
    assert obj_dict == {'x': 'Hello', 'y': 'World', 'z': 42,
                        'extra': 'data'}, obj_dict

# Generated at 2022-06-11 21:09:38.953883
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError):
        raise UndefinedParameterError("test")

# Generated at 2022-06-11 21:09:42.811858
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = [1, 2, 3, 4]
    assert _UndefinedParameterAction.handle_to_dict(obj=obj, kvs={"a": 42,
                                                                  "b": 3}) == {
               "a": 42, "b": 3}

# Generated at 2022-06-11 21:09:53.865516
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: str, b: str, c: int):
            self.a = a
            self.b = b
            self.c = c

    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, "a", "b", 2).a == "a"

    assert _IgnoreUndefinedParameters.create_init(TestClass)(
        TestClass, "a", "b", 2).c == 2

    assert _CatchAllUndefinedParameters.create_init(TestClass)(
        TestClass, "a", "b", 2).c == 2

    assert _UndefinedParameterAction.create_init(TestClass)(
        TestClass, "a", "b", 2).c == 2


# Generated at 2022-06-11 21:10:59.357494
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Create a class with allowed and unknown initialization parameters
    # and a __init__ that takes these parameters.

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class Test:
        min: int
        max: int

        def __init__(self, min, max, *args, **kwargs):
            pass

    # If the number of allowed parameters is smaller than the number of
    # arguments, ignore the additional arguments
    Test(1, 2, 3, 4, 5)

    # If the number of allowed parameters is larger than the number of
    # arguments, raise TypeError
    with pytest.raises(TypeError):
        Test(1)

    # If all allowed parameters are passed, but unknown parameters,
    # ignore the unknown
    Test(1, 2, other=3)

# Generated at 2022-06-11 21:11:12.384781
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(frozen=True,
                           init=True,
                           repr=True,
                           eq=True,
                           order=True,
                           unsafe_hash=False,
                           frozen=False)
    class C:
        a: int
        b: str
        # noinspection PyTypeChecker
        c: CatchAll = CatchAllVar(default_factory=dict)

    init_method = _CatchAllUndefinedParameters.create_init(C)

    @dataclasses.dataclass(frozen=True,
                           init=True,
                           repr=True,
                           eq=True,
                           order=True,
                           unsafe_hash=False,
                           frozen=False)
    class D:
        x: int
        y: int = 5

# Generated at 2022-06-11 21:11:22.853197
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin, dataclass_json
    from dataclasses_json.config import Config
    from typing import Type

    class _CustomConfig(Config):
        def __init__(self,
                     obj_hook: Optional[Callable[[Any], Any]] = None,
                     undefined: Type[Undefined] = Undefined.EXCLUDE,
                     **kwargs) -> None:
            super().__init__(obj_hook=obj_hook, undefined=undefined, **kwargs)

    @dataclass
    class _CatchAllTestClass(DataClassJsonMixin):
        x: int
        y: Optional[CatchAll] = dataclasses.field(default_factory=dict)


# Generated at 2022-06-11 21:11:29.760523
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    # noinspection PyUnusedLocal
    @dataclass
    class DummyClass:
        a: int
        b: int

        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    expected = {'a': 1, 'b': 2}
    result = _CatchAllUndefinedParameters.create_init(DummyClass)(
        None, 1, 2, 3, 4, 5)
    result = result.__dict__
    assert expected == result



# Generated at 2022-06-11 21:11:34.449656
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from pydantic import BaseModel

    class Test(BaseModel):
        a: int
        b: str

    def _check_that_init_takes_undefined_parameters(init_method):
        instance = Test(a=1, b="value", undefinedparameter=0)
        instance.__init__(**{"a": 1, "b": "value", "undefinedparameter": 0})

    new_init = _IgnoreUndefinedParameters.create_init(Test)
    _check_that_init_takes_undefined_parameters(new_init)

# Generated at 2022-06-11 21:11:46.067530
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def assert_handle_dump_returns_empty_dict(undefined: Undefined):
        class TestObject:
            pass

        class TestObjectSchema:
            def dump(self, obj: TestObject) -> dict:
                return {"type": "test", **getattr(
                    obj.__class__, "__dataclasses_json__")[
                                      "undefined"].handle_dump(obj)}

        class __dataclasses_json__:
            pass

        __dataclasses_json__.undefined = undefined
        TestObject.__dataclasses_json__ = __dataclasses_json__
        result = TestObjectSchema().dump(TestObject())
        assert result == {"type": "test"}

    assert_handle_dump_returns_empty_dict(undefined=Undefined.RAISE)
    assert_

# Generated at 2022-06-11 21:11:52.478177
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Foo:
        a: int
        b: CatchAll = None

    assert {'a': 1} == _CatchAllUndefinedParameters.handle_dump(
        Foo(a=1))

    assert {'a': 1, 'b': {'c': 2}} == _CatchAllUndefinedParameters.handle_dump(
        Foo(a=1, b={'c': 2}))

# Generated at 2022-06-11 21:12:04.674364
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class MyClass:
        def __init__(self, field_a: str, field_b: str):
            self.field_a = field_a
            self.field_b = field_b

    kvs = {"field_a": 1, "field_c": 2}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=MyClass, kvs=kvs)
    assert known == {"field_a": 1}
    assert unknown == {"field_c": 2}

    kvs = {"field_a": 1, "field_b": 2}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=MyClass, kvs=kvs)

# Generated at 2022-06-11 21:12:07.355025
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test_UndefinedParameterError")
    except UndefinedParameterError as e:
        assert e.message == "test_UndefinedParameterError"

# Generated at 2022-06-11 21:12:09.845200
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    expected = {}
    assert expected == _UndefinedParameterAction.handle_dump("foo")



# Generated at 2022-06-11 21:14:27.567804
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        bar: str
        baz: str
        qux: str
        def __init__(self, bar, baz, qux=None):
            pass
    init = _IgnoreUndefinedParameters.create_init(Foo)
    init(Foo("bar", "baz"), **{"qux": "qux", "abc": "abc"})

    @dataclasses.dataclass
    class Bar:
        bar: str
        baz: str
        qux: str=None
        def __init__(self, bar, baz, qux=None):
            pass
    init = _IgnoreUndefinedParameters.create_init(Bar)

# Generated at 2022-06-11 21:14:37.856409
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c=None, _catch_all=None):
            self.a = a
            self.b = b
            self.c = c

            if _catch_all is None:
                _catch_all = {}
            self._catch_all = _catch_all

    input_dict = {TestClass.__name__: {"a": 1, "b": 2, "c": 3, "d": 4}}
    obj = TestClass(1, 2, 3, {"d": 4})

    expected_out = {
        TestClass.__name__: {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": 4,
        }
    }

# Generated at 2022-06-11 21:14:47.294707
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class C:
        def __init__(self, name: str, age: int, extra: Any = {}):
            self.name = name
            self.age = age
            self.extra = extra

    init = _IgnoreUndefinedParameters.create_init(C)
    assert init(C(), "s", 1) is None
    assert init(C(), "s", 1, address="1234") is None
    assert init(C(), "s", 1, address="1234", phone="234234234") is None



# Generated at 2022-06-11 21:14:54.547092
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class Test(object):
        a: int
        b: str = "default"
        c: CatchAllVar = None

        def __init__(self, *args, **kwargs):
            self.d = kwargs.pop("d")
            self.e = kwargs.pop("e")
            self._catch_all = kwargs

    initial_params = Test(1, "string", 2, d=3, e=4, v=5, w=6)
    dump = config.dump_class(initial_params, sort_keys=False)

# Generated at 2022-06-11 21:15:04.274203
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # pylint: disable=missing-param-doc
    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        info: Optional[CatchAllVar]

    p = Person("John", 38, {})
    assert p.info == {}

    p = Person("John", 38)
    assert p.info is None

    p = Person("John", 38, info=dict(other_info="Some info"))
    assert p.info["other_info"] == "Some info"

    p = Person("John", 38, other_info="Some info")
    assert p.info["other_info"] == "Some info"

    # Let's break some stuff

# Generated at 2022-06-11 21:15:12.554195
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

        def __post_init__(self):
            pass

    test_dict = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert _RaiseUndefinedParameters.handle_from_dict(Test, test_dict) == \
           {"a": 1, "b": 2}

