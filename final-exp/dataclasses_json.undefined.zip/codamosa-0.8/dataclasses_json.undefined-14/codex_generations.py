

# Generated at 2022-06-11 21:05:44.571466
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Car:
        make: str
        model: str
        year: int = dataclasses.field(default=0)
        undefined_parameters: Dict = dataclasses.field(
            default_factory=dict)

        def __init__(self, *args, **kwargs):
            print("Making a car")

    instance_original_init = Car("Nissan", "Skyline", 2000)
    instance_modified_init = Car("Nissan", "Skyline", 2000)

    assert instance_modified_init.make == "Nissan"
    assert instance_modified_init.model == "Skyline"
    assert instance_modified_init.undefined_parameters == {}


# Generated at 2022-06-11 21:05:57.232318
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        unknown_dict: Optional[CatchAllVar] = None

        def __post_init__(self):
            print("post_init")

    t = TestClass()
    res = _CatchAllUndefinedParameters.handle_dump(t)
    assert isinstance(res, dict)

    @dataclasses.dataclass
    class TestClass_2:
        unknown_dict: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __post_init__(self): pass

    t = TestClass_2()
    res = _CatchAllUndefinedParameters.handle_dump(t)
    assert isinstance(res, dict)

# Generated at 2022-06-11 21:05:59.789792
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # This method is abstract and only calls super().handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}


# Generated at 2022-06-11 21:06:12.130854
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    dict_for_field_a = {"a": 1, "b": 2, "c": 3}
    dict_for_field_b = {"a": 2, "b": 2}
    dict_for_catch_all = {"a": 3, "b": 2, "c": 3}

    @dataclasses.dataclass(init=True,
                           repr=False,
                           frozen=False,
                           )
    class Test:
        a: dict = dict_for_field_a
        b: dict = dict_for_field_b
        unknown = _IgnoreUndefinedParameters.create_init(Test)

    obj = Test({"a": dict_for_field_b, "b": dict_for_field_a, "c": {}})
    assert obj.b == dict_for_field_a


# Generated at 2022-06-11 21:06:16.843438
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class ClassA:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    given_kwargs = {"a": 1, "b": 2, "c": 3, "d": 4}
    received_kwargs = _IgnoreUndefinedParameters.handle_from_dict(ClassA,
                                                                  given_kwargs)

    assert received_kwargs == {"a": 1, "b": 2}



# Generated at 2022-06-11 21:06:18.809835
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    message = "message"
    err = UndefinedParameterError(message)
    assert err.messages[0] == message

# Generated at 2022-06-11 21:06:30.886397
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses as dc
    import dataclasses_json as dcj

    @dc.dataclass
    class Test:
        field1: str
        catch_all: dcj.CatchAll = dc.field(default_factory=list)

        def __init__(self, field1: str, field2: str, **kwargs):
            self.field1 = field1
            self.catch_all = kwargs

    class MockDictionary:
        def update(self, new_dictionary):
            self.dict_received = new_dictionary

    @dcj.dataclass_json(undefined=dcj.Undefined.INCLUDE)
    class Test2:
        field1: str
        field2: str

# Generated at 2022-06-11 21:06:38.164279
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Constructed manually because it is a dataclass, so
    # the dataclasses framework is not able to construct it automatically
    @dataclasses.dataclass
    class CatchAllTestClass:
        a: str
        b: str
        c: Optional[CatchAllVar]

        def __init__(self, *args, **kwargs):
            pass

    _CatchAllUndefinedParameters.create_init(CatchAllTestClass)(
        CatchAllTestClass, 1, 2, a="A", b="B", c=None, d=4, e=5)

# Generated at 2022-06-11 21:06:49.664998
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class Foo:
        foo: float
        bar: Optional[int]
        catch_all: Optional[CatchAllVar]

    # init objects
    foo_1 = Foo(1.1, 10, None)
    foo_2 = Foo(1.1, 10, {})

    # check that CatchAll is not included
    kvs_1 = _CatchAllUndefinedParameters.handle_to_dict(foo_1, {"foo": 1.1,
                                                                 "bar": 10,
                                                                 "baz": 12})
    assert "catch_all" not in kvs_1


# Generated at 2022-06-11 21:06:57.768859
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class _TestClass:
        a: int
        b: int

        def __init__(self, **kwargs):
            self._undefined_parameters = kwargs

    defined_parameters = {"a": 1, "b": 2}
    parameters = {"a": 1, "b": 2, "c": 3}
    result = _RaiseUndefinedParameters.handle_from_dict(_TestClass, parameters)
    assert result == defined_parameters

    with pytest.raises(UndefinedParameterError):
        parameters = {"a": 1, "b": 2, "c": 3, "d": 4}
        _RaiseUndefinedParameters.handle_from_dict(_TestClass, parameters)



# Generated at 2022-06-11 21:07:14.974900
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test the constructor of UndefinedParameterError to see if the message
    is constructed as expected.
    """

    message = "Testmessage"
    error = UndefinedParameterError(message)

    assert message in str(error)

# Generated at 2022-06-11 21:07:27.717500
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: int, b: CatchAll = None):
            pass

    a_instance = A(1, b={"undefined_parameter": "foo"})
    assert a_instance.b == {"undefined_parameter": "foo"}

    create_init = _CatchAllUndefinedParameters.create_init(A)
    a_instance = create_init(1, b={"undefined_parameter": "foo"})
    assert a_instance.b == {"undefined_parameter": "foo"}

    class B:
        def __init__(self, a: int, b: CatchAll = None, c: int = 2):
            pass

    b_instance = B(1, b={"undefined_parameter": "foo"})

# Generated at 2022-06-11 21:07:33.188577
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        field1: str = "field1"
        field2: str = "field2"

    assert _UndefinedParameterAction.handle_to_dict(
        obj=TestClass, kvs={TestClass.field1.name: "value1",
                            TestClass.field2.name: "value2"}) == {
               TestClass.field1.name: "value1", TestClass.field2.name: "value2"}


# Generated at 2022-06-11 21:07:42.709325
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from marshmallow import Schema
    from dataclasses_json import DataClassJsonMixin

    class TestClass(DataClassJsonMixin):
        a: int
        b: str
        c: dict

    class TestSchema(Schema):
        a = 1
        b = "test"

    instance = TestClass(a=1, b="test", c={'c': 42})
    schema = TestSchema()
    kvs = schema.dump(instance)
    assert kvs == {'a': 1, 'b': 'test'}
    assert _UndefinedParameterAction.handle_to_dict(TestClass, kvs) == \
           {'c': {'c': 42}}



# Generated at 2022-06-11 21:07:43.932907
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    namespace = {}

# Generated at 2022-06-11 21:07:47.964644
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _RaiseUndefinedParameters.handle_dump(None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(
        None) == dict()  # type: ignore

# Generated at 2022-06-11 21:07:59.168891
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    TestClass = dataclasses.make_dataclass("TestClass", [("a", int)])
    from_dict = _RaiseUndefinedParameters.handle_from_dict
    assert from_dict(TestClass, dict(a=1)) == dict(a=1)
    try:
        from_dict(TestClass, dict(a=1, b=2))
    except UndefinedParameterError as e:
        assert "Received undefined initialization arguments {'b': 2}" == \
               str(e)
    else:
        raise AssertionError("Expected an UndefinedParameterError")



# Generated at 2022-06-11 21:08:07.065188
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_obj = Test(1, 2)
    assert _IgnoreUndefinedParameters.handle_from_dict(test_obj, {}) == {}

    assert _IgnoreUndefinedParameters.handle_from_dict(test_obj,
                                                       {"a": 3, "b": 4}) == {
                                                          "a": 3, "b": 4}
    assert _IgnoreUndefinedParameters.handle_from_dict(test_obj,
                                                       {"b": 5, "c": 3}) == {
                                                          "b": 5}

    class Test:
        def __init__(self, a, *args):
            self.a = a
            self.b = args

   

# Generated at 2022-06-11 21:08:18.810413
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Parameters that do not match a field name of the class should be caught in
    the catch-all field
    """
    def _separate_known_unknown_dicts(cls, kvs: Dict) -> \
            Tuple[KnownParameters, UnknownParameters]:
        # Noinspection PyProtectedMember
        class_fields = fields(cls)
        field_names = [field.name for field in class_fields]
        unknown_given_parameters = {k: v for k, v in kvs.items() if
                                    k not in field_names}
        known_given_parameters = {k: v for k, v in kvs.items() if
                                  k in field_names}
        return known_given_parameters, unknown_given_parameters

    from dataclasses import dataclass

# Generated at 2022-06-11 21:08:31.357562
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class ClassWithUndefinedParameters:

        def __init__(self, a: int,
                     b: int,
                     c: str = "c",
                     undefined: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.undefined = undefined

    assert isinstance(ClassWithUndefinedParameters.undefined, Field)
    assert ClassWithUndefinedParameters.undefined.type == Optional[CatchAllVar]

    obj = ClassWithUndefinedParameters(a=1, b=2, undefined={"d": "d"})
    assert obj.c == "c"
    kvs = {"a": 1, "b": 2, "undefined": {"d": "d"}}
    expected = {"a": 1, "b": 2, "d": "d"}

# Generated at 2022-06-11 21:09:08.226331
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self,
                     a,
                     b,
                     c=_IgnoreUndefinedParameters._SentinelNoDefault,
                     d=_IgnoreUndefinedParameters._SentinelNoDefault,
                     e=_IgnoreUndefinedParameters._SentinelNoDefault):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(Test)
    # If a new function is created, it will not be the same instance as
    # the original function, but it has the same name
    assert new_init.__name__ == Test.__init__.__name__

    try:
        new_init(Test(1, 2), 1, 2, 3, 4, 5)
        raise AssertionError("Should have raised an exception")
    except TypeError:
        pass


# Generated at 2022-06-11 21:09:17.459795
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from typing import Any

    @dataclasses.dataclass
    class DummyClass:
        foo: str
        bar: int

        @staticmethod
        def __init__(foo: str, bar: int):
            pass

    dummy_class = DummyClass
    init_method = _UndefinedParameterAction.create_init(dummy_class)

    # Common class init method
    assert init_method('foobar', 1) == None

    # modified init taking additional positional args
    init_method_catch_all = \
        _CatchAllUndefinedParameters.create_init(dummy_class)
    assert init_method_catch_all('foobar', 1,
                                 _UNKNOWN0='ignored positional argument',
                                 _UNKNOWN1='another ignored positional argument') == None

    # modified init taking additional positional args


# Generated at 2022-06-11 21:09:28.254702
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: int = dataclasses.field(init=False)

    # noinspection PyArgumentList
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs=kvs)
        assert False, "Expected UndefinedParameterError."
    except UndefinedParameterError:
        pass
    except Exception:
        assert False, "Unexpected Exception."

    # noinspection PyArgumentList
    kvs = {"a": 1, "b": 2, "d": 4}

# Generated at 2022-06-11 21:09:29.240954
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass



# Generated at 2022-06-11 21:09:41.367109
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, a, b):
            pass

    class Example2:
        def __init__(self, a, b, c=5, d=5):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(cls=Example, kvs={
        "a": 3,
        "b": 5,
    }) == {
        "a": 3,
        "b": 5,
    }
    assert _RaiseUndefinedParameters.handle_from_dict(cls=Example2, kvs={
        "a": 3,
        "b": 5,
        "c": 99,
        "d": 99,
    }) == {
        "a": 3,
        "b": 5,
        "c": 99,
        "d": 99,
    }

# Generated at 2022-06-11 21:09:45.564618
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Test:
        my_dict: Dict = dataclasses.field(metadata=dict(
            mapper="field1"))
        catch_all: CatchAll = dataclasses.field(default=dict)

    test = Test(my_dict=dict(field1="value1", field2="value2"))
    kvs = dict(my_dict="value1")
    kvs = _CatchAllUndefinedParameters.handle_to_dict(test, kvs)
    assert kvs == dict(field1="value1", field2="value2")
    kvs = _CatchAllUndefinedParameters.handle_to_dict(test, dict())
    assert kvs == dict(my_dict=dict(field1="value1", field2="value2"))


# Generated at 2022-06-11 21:09:55.340432
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class MyClass(metaclass=dataclasses.dataclass):
        a: str
        b: int = 5
        c: CatchAll = None

    tc_1_1 = {
        "a": "a",
        "b": 5,
        "c": dict(x=1, y=2),
    }
    tc_1_2 = {
        "a": "a",
        "b": 5,
    }

# Generated at 2022-06-11 21:09:55.892104
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass

# Generated at 2022-06-11 21:10:03.096555
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestCase:
        __init__ = _RaiseUndefinedParameters.handle_from_dict

    try:
        TestCase.__init__(TestCase, {"a": 1, "b": 2, "c": 3})
        assert False, "Expected an exception"
    except UndefinedParameterError:
        pass

    assert TestCase.__init__(TestCase, {"a": 1}) == {"a": 1}



# Generated at 2022-06-11 21:10:08.223926
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        b: int
        c: str
        d: str = dataclasses.field(metadata={"marshmallow_field": "e"})

    assert A.__init__ is _IgnoreUndefinedParameters.create_init(A)
    assert inspect.signature(A.__init__) == inspect.signature(A.__init__)

# Generated at 2022-06-11 21:11:14.925851
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    class _IgnoreUndefinedParametersTestClass:
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

        @staticmethod
        def create_init(_):
            return _IgnoreUndefinedParametersTestClass.__init__

        @staticmethod
        def get_fields():
            return [
                Field(name='a', type=int, default=None),
                Field(name='b', type=int, default=None)]

    test_class = _IgnoreUndefinedParametersTestClass()

    @dataclass
    class _TestData:
        kvs: Dict[str, Any]
        expected: Dict[str, Any]


# Generated at 2022-06-11 21:11:16.700367
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test message")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-11 21:11:23.451364
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json import DataClassJsonMixin, config

    class TestObj(DataClassJsonMixin):
        x: int

        @classmethod
        def schema(cls):
            from marshmallow import fields, Schema
            return Schema.from_dataclass(cls)

    parameters = {'x': 1, 'y': 2}
    handler = _IgnoreUndefinedParameters()
    expected = {'x': 1}
    result = handler.handle_from_dict(TestObj, parameters)

    assert result == expected
    assert result != parameters



# Generated at 2022-06-11 21:11:24.658213
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    pass

# Generated at 2022-06-11 21:11:29.695299
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    input_dict = {"a": 1, "b": 2}
    expected_dict = {"a": 1, "b": 2}

    output_dict = _CatchAllUndefinedParameters.handle_to_dict(None, input_dict)

    assert output_dict == expected_dict



# Generated at 2022-06-11 21:11:38.394198
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass(frozen=True,
                           undefined=Undefined.INCLUDE)
    class TestClass1:
        key1: str
        key2: int
        key3: Optional[CatchAll] = None

    @dataclasses.dataclass(frozen=True,
                           undefined=Undefined.EXCLUDE)
    class TestClass2:
        key1: str
        key2: int

    # Class with undefined parameters
    t1 = TestClass1(key1="foo", key2=4, key3={}, undefined_key="bar")
    foo, bar = t1.key1, t1.undefined_key
    assert foo == "foo"
    assert bar == "bar"

    # Class without undefined parameters

# Generated at 2022-06-11 21:11:47.346900
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: str
        c: float = 1.0
        z: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)  # Unused but needed for type signature
        _undefined_parameters = _CatchAllUndefinedParameters

    @dataclasses.dataclass
    class B:
        x: Dict
        y: str

    a = A(1, "b", 3.0, x=1, y=2, z=3, n="n")
    b = A(1, "b", 3.0, x=1, y=2, z=3, n="n", x_=2)

# Generated at 2022-06-11 21:11:54.061834
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from datetime import datetime
    from decimal import Decimal

    kvs = {"x": "1", "y": 1, "z": Decimal("1"), "datetime": datetime.today(),
           "d": {"an": "apple"}}
    from dataclasses_json.api import _CatchAllUndefinedParameters
    assert _CatchAllUndefinedParameters.handle_to_dict(None, kvs) == kvs

# Generated at 2022-06-11 21:11:59.797329
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: list
        d: dict
        f: CatchAll = None

        def __init__(self, a, b, c, d, f=None):
            pass

# Generated at 2022-06-11 21:12:07.762276
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, value: str, _unknown: dict):
            self.value = value
            self.unknown = _unknown
        pass

    test_obj = TestClass("value", {"a": 1, "b": 2})
    defined_kvs = {"value": test_obj.value}
    undefined_kvs = test_obj.unknown
    input_kvs = defined_kvs.copy()
    input_kvs.update(undefined_kvs)
    output_kvs = _UndefinedParameterAction.handle_to_dict(test_obj, input_kvs)
    assert output_kvs == defined_kvs
    assert output_kvs != input_kvs



# Generated at 2022-06-11 21:14:31.166213
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyProtectedMember
    from dataclasses import _MISSING_TYPE
    # noinspection PyProtectedMember
    from dataclasses import _is_default_member_factory

    @dataclasses.dataclass
    class _TestClass:
        arg1 = dataclasses.field(default=_MISSING_TYPE)
        arg2 = dataclasses.field(default=None)
        arg3 = dataclasses.field(default=_MISSING_TYPE)
        catch_all = dataclasses.field(default_factory=dict)

        def __init__(self, arg1, arg2=None, arg3=None, **kwargs):
            if kwargs:
                raise UndefinedParameterError("unwanted keyword in kwargs")


# Generated at 2022-06-11 21:14:38.505305
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        undefined: CatchAll

    class TestSubclass(TestClass):
        pass

    test_object = TestClass(undefined={'mykey': 'myvalue'})
    test_subclass_object = TestSubclass(undefined={'mykey': 'myvalue',
                                                   'mykey2': 'myvalue2'})
    assert _UndefinedParameterAction.handle_to_dict(test_object, {
        'a': 'value'}) == {'a': 'value'}
    assert _UndefinedParameterAction.handle_to_dict(test_subclass_object, {
        'a': 'value'}) == {'a': 'value'}



# Generated at 2022-06-11 21:14:50.599158
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Tests if the method _RaiseUndefinedParameters.handle_from_dict handles
    undefined parameters correctly.
    """
    attribs = {"a": 1, "b": 2, "c": 3, "d": 4}

    class SomeClass(metaclass=dataclasses.dataclass):
        a: int
        b: int
        c: int = dataclasses.field(default=3)

    known, unknown = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            SomeClass, attribs)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"d": 4}

    _UndefinedParameterAction._separate_defined_undefined_kvs(
        SomeClass, attribs)

# Generated at 2022-06-11 21:15:02.296893
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from marshmallow import Schema, fields

    @dataclasses.dataclass
    class CatchAllTest:
        some_value: str = "test"
        some_dynamic_value: str = dataclasses.field(
            default_factory=lambda: "dynamic_test")

# Generated at 2022-06-11 21:15:07.597260
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class TestClass:
        a: int
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(TestClass, {"a": 1, "b": "asd"})
    assert len(unknown) == 1



# Generated at 2022-06-11 21:15:17.055247
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    old_dict = {"a": 1, "b": 2}
    new_dict = {"c": 3, "d": 4}
    class D:
        x: CatchAllVar

    obj = D(x=old_dict)
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, old_dict)
    assert kvs == old_dict
    assert obj.x == old_dict

    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, new_dict)
    assert kvs == new_dict
    assert obj.x == old_dict  # old_dict should be unaffected!

