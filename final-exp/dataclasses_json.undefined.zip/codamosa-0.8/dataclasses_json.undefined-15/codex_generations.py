

# Generated at 2022-06-11 21:05:37.038360
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field_a: str = "field a"
        field_b: str = "field b"
        field_c: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAllVar())

        def __init__(self, field_a: str, field_b: str, field_c: CatchAllVar):
            pass

    class_instance = TestClass(field_a="a")
    # Make sure default value is correct
    assert class_instance.field_b == "field b"
    assert class_instance.field_c == {}

# Generated at 2022-06-11 21:05:47.461448
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from typing import NamedTuple

    input_dict = {
        "theQuickBrownFox": "jumps over the lazy",
        "theSecond": "name"
    }
    expected_dict = {
        "theQuickBrownFox": "jumps over the lazy",
        "theSecond": "name",
        "catchAll": {
            "rest": "is written in here"
        }
    }

    class MyNamedTuple(NamedTuple):
        theQuickBrownFox: str
        theSecond: str
        catchAll: Optional[CatchAllVar] = None


# Generated at 2022-06-11 21:05:51.206340
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a, b, c):
            pass

    AInit = _UndefinedParameterAction.create_init(A)
    AInit()

# Generated at 2022-06-11 21:06:01.238319
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: str, b: int):
            self.a = a
            self.b = b

    assert _RaiseUndefinedParameters.handle_from_dict(cls=Foo, kvs={
        "a": "foo",
        "b": 42,
        "c": "not allowed"
    }) == {"a": "foo", "b": 42}

    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=Foo, kvs={
            "a": "foo",
            "unknown": "not allowed"
        })
        assert False
    except UndefinedParameterError:
        pass

# Generated at 2022-06-11 21:06:13.557621
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from .utils import _CatchAllUndefinedParameters as _CAP
    assert _CAP.handle_from_dict(None, {1: 2}) == {1: 2}
    assert _CAP.handle_from_dict(None, {"1": 2}) == {"1": 2}

    assert _CAP.handle_from_dict(None, {1: 2}) == {1: 2}
    assert _CAP.handle_from_dict(None, {"1": 2}) == {"1": 2}

    assert _CAP.handle_from_dict(None, {1: [1, 2]}) == {1: [1, 2]}
    assert _CAP.handle_from_dict(None, {"1": [1, 2]}) == {"1": [1, 2]}


# Generated at 2022-06-11 21:06:15.841162
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    kvs = {'a': 'b'}
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(obj) == {}



# Generated at 2022-06-11 21:06:23.072206
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyMissingConstructor
    @dataclasses.dataclass
    class _TestCatchAllUndefinedParameters:
        f1: str
        f2: str = "default"
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

    _CatchAllUndefinedParameters.create_init(_TestCatchAllUndefinedParameters)



# Generated at 2022-06-11 21:06:34.115029
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():

    class TestClass:
        def __init__(self, a: int, b: int = 0, **undefined_parameters):
            self.a = a
            self.b = b
            self.undefined_parameters = undefined_parameters

    # Check expected behavior of handle_from_dict (for all 3 combinations
    # of unknown/known parameters)

        # Check handle_from_dict when only known parameters are given
    class_instance = TestClass(**{'a': 1, 'b': 2})
    assert class_instance.a == 1
    assert class_instance.b == 2
    assert class_instance.undefined_parameters == {}

        # Check handle_from_dict when only unknown parameters are given
    class_instance = TestClass(**{'c': 1, 'd': 2})
    assert class_instance.a

# Generated at 2022-06-11 21:06:44.348147
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyClass:
        _UNDEFINED_PARAMETERS_ACTION = Undefined.EXCLUDE

        attr1: int = dataclasses.field(default=1)
        attr2: str = dataclasses.field(default="bar")

        def __init__(self, attr1: int, attr2: str,
                     attr3: Optional[CatchAllVar]):
            self.attr1 = attr1
            self.attr2 = attr2
            self.attr3 = attr3

    my_class = MyClass(attr1=2, attr2="foo", attr3={"baz": "qux"})
    assert my_class.attr1 == 2
    assert my_class.attr2 == "foo"
    assert my

# Generated at 2022-06-11 21:06:56.298714
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class C(abc.ABC):
        def __init__(self, a: int, b: int, c: int):
            pass

    class D(C):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @staticmethod
        def _create_init():
            return _UndefinedParameterAction.create_init(D)

    class E(C):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @staticmethod
        def _create_init():
            return _UndefinedParameterAction.create_init(D)()


if __name__ == "__main__":
    import doctest


# Generated at 2022-06-11 21:07:15.467453
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def add_params(x: int, y: int, z: int):
        return x + y + z

    # Remove all parameters
    assert func_has_same_parameters(original_func=add_params,
                                    new_func=_IgnoreUndefinedParameters.create_init(
                                        add_params),
                                    num_expected_parameters=0,
                                    num_expected_args=0)

    def add_params_with_default(x: int, y: int = 3, z: int = -2):
        return x + y + z

    # The last parameter has a default. The
    # parameter is removed from parameters but still
    # has to be passed as an argument.

# Generated at 2022-06-11 21:07:17.801352
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError as e:
        assert e.messages == []

# Generated at 2022-06-11 21:07:29.681655
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestObj:
        a: str
        b: Optional[int]
        c: str = "c"

    init_with_known_parameters = _IgnoreUndefinedParameters.create_init(
        TestObj)

    obj1 = init_with_known_parameters(TestObj(), "a", 1, c="c")
    assert obj1 == TestObj("a", 1, "c")

    obj2 = init_with_known_parameters(TestObj(), "a", 1, "c")
    assert obj2 == TestObj("a", 1, "c")

    init_with_unknown_parameters = _IgnoreUndefinedParameters.create_init(
        TestObj)


# Generated at 2022-06-11 21:07:41.449184
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DataClass:
        a: int
        b: int
        c: int = dataclasses.field(default=3)
        catch_all: catch_all = dataclasses.field(
            default_factory=dict)

    cls = DataClass

    class TestCase:
        in_kvs: KnownParameters
        out_known_kvs: KnownParameters
        out_all_kvs: KnownParameters
        should_raise: bool


# Generated at 2022-06-11 21:07:50.100043
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.config import ValidationError
    from dataclasses_json.utils import CatchAll
    import pytest

    @dataclass
    class A:
        a: int
        b: int = 1
        c: int = 2
        d: CatchAll = None

        def __post_init__(self):
            assert self.a == 1
            assert self.b == 2
            assert self.c == 3
            assert self.d[0] == 4
            assert self.d[1] == 5
            assert self.d[2] == 6
            assert len(self.d) == 3


    A._undefined_parameter_behavior = _CatchAllUndefinedParameters

    obj = A(1, 2, 3, 4, 5, 6)

    expected

# Generated at 2022-06-11 21:07:53.706462
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses_json._underscore_attrs import UnderscoreInit

    class CatchAllMissing(_UnderscoreInit,
                          _CatchAllUndefinedParameters):
        pass
    CatchAllMissing()  # should not raise exception

# Generated at 2022-06-11 21:07:55.914998
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _CatchAllUndefinedParameters()
    assert type(obj.handle_dump()) is dict

# Generated at 2022-06-11 21:07:58.778028
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(
            UndefinedParameterError,
            match="Received undefined initialization arguments {'a': 'b'}"):
        raise UndefinedParameterError("", {'a': 'b'})

# Generated at 2022-06-11 21:08:04.288152
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class A:
        a: int
        b: str
        c: int

    assert _UndefinedParameterAction.handle_to_dict(A, {"a": 1, "b": 2, "c": 3})
    assert _UndefinedParameterAction.handle_to_dict(A, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}


# Generated at 2022-06-11 21:08:17.146253
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from marshmallow import Schema
    from marshmallow.fields import Nested

    class TestObj:
        data: str

        def __init__(self, data: str):
            self.data = data

    class TestObjSchema(Schema):
        data = Schema.fields.Str()

    test_obj_schema = TestObjSchema()
    new_init = _UndefinedParameterAction.create_init(TestObj)
    instance = TestObj("Test")
    dumped = test_obj_schema.dump(instance)
    new_instance = new_init(data="Test")
    new_dumped = test_obj_schema.dump(new_instance)
    assert dumped == new_dumped

    class NestedObj:
        data: str


# Generated at 2022-06-11 21:08:52.477980
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar
    from .utils import letter_case_to_value

    class LetterCase(Enum):
        LOWER_CAMEL = auto()
        UPPER_CAMEL = auto()
        PASCAL = auto()
        SNAKE = auto()
        KEBAB = auto()
        ORIGINAL = auto()
        LOWER_WITH_UNDERSCORES = auto()

    class LetterCaseConfig(config.Config):
        letter_case = LetterCase.LOWER_WITH_UNDERSCORES
        undefined = Undefined.INCLUDE

    @dataclass(config=LetterCaseConfig)
    class MyClass:
        name: str
        value: int
        optional

# Generated at 2022-06-11 21:08:57.405426
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class DummyClass:
        def __init__(self, a=1, b=2, c=3):
            pass

    dummy_object = DummyClass()
    kvs = {"a":3, "b":2, "c":1, "d":0}
    result = _UndefinedParameterAction.handle_to_dict(dummy_object, kvs)
    assert result == {"a":3, "b":2, "c":1}



# Generated at 2022-06-11 21:09:04.547895
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Test that _RaiseUndefinedParameters.handle_from_dict raises an exception
    if the dictionary contains an undefined parameter
    """
    class TestClass:
        def __init__(self, a, b):
            pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                   kvs={"a": 1, "c": 2})



# Generated at 2022-06-11 21:09:14.463593
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except UndefinedParameterError as e:
        assert e.messages is None
        assert e.field_names is None
        assert str(e) == "None"
    try:
        raise UndefinedParameterError("message")
    except UndefinedParameterError as e:
        assert e.messages == "message"
        assert e.field_names is None
        assert str(e) == "message"

    try:
        raise UndefinedParameterError(["m1", "m2"])
    except UndefinedParameterError as e:
        assert e.messages == ["m1", "m2"]
        assert e.field_names is None
        assert str(e) == "['m1', 'm2']"


# Generated at 2022-06-11 21:09:23.758333
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestObject:
        catch_all: CatchAll = None

    obj = TestObject()
    obj.catch_all = {"a": 1, "b": 1}
    known_parameters = {"a": 1, "b": 2}

    parameters_after_dump = _CatchAllUndefinedParameters.handle_to_dict(
        obj=obj, kvs=known_parameters)

    assert "a" in parameters_after_dump
    assert "a" in obj.catch_all
    assert parameters_after_dump["b"] == 2
    assert obj.catch_all["b"] == 1

# Generated at 2022-06-11 21:09:30.902149
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(default=0)

        def __init__(self, a: int, b: int, c: int = None):
            self.a = a
            self.b = b
            self.c = c

        @classmethod
        def create_init(cls) -> Callable:
            return _IgnoreUndefinedParameters.create_init(cls)

    TestClass.create_init()(TestClass)(1, 2)
    TestClass.create_init()(TestClass)(1, 2)
    TestClass.create_init()(TestClass)(1, 2, 3)
    TestClass.create_init()(TestClass)(1, 2, c=3)
    TestClass

# Generated at 2022-06-11 21:09:33.903965
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('test')
    except Exception as e:
        assert str(e) == 'test'

# Generated at 2022-06-11 21:09:41.239946
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int

    assert _IgnoreUndefinedParameters.create_init(A)(A(1, 2, 3), 4, 5, d=6) == \
           A(1, 2, 3)

    assert _IgnoreUndefinedParameters.create_init(A)(A(1, 2, 3), 4, 5) == A(
        1, 2, 3)

# Generated at 2022-06-11 21:09:49.188718
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # init takes 5 parameters: self, two_pos_args, two_kwargs, catch_all
    @dataclasses.dataclass(init=_CatchAllUndefinedParameters.create_init)
    class MyObj:
        two_pos_args: str
        two_kwargs: str = dataclasses.field(default="TWO_KWARGS")
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

        def __init__(self, two_pos_args, two_kwargs="TWO_KWARGS",
                     catch_all=None):
            pass

    # first, test normal initialization
    x = MyObj("lorem_ipsum", "spam", {"a": "b"})
    assert x.two_pos_args == "lorem_ipsum"
   

# Generated at 2022-06-11 21:09:55.983608
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class Test(object):
        a: int
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str = "b", catch_all: Optional[
            CatchAllVar] = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    schema = Schema(unknown=Undefined.EXCLUDE)
    schema.load(dict(a=1, b=3))

# Generated at 2022-06-11 21:11:03.317792
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    _dict = {"a": 1, "b": 2, "_UNKNOWN": {"c": 3, "d": 4}}
    _CatchAllUndefinedParameters.handle_to_dict(None, _dict) == {"a": 1,
                                                                 "b": 2,
                                                                 "c": 3,
                                                                 "d": 4}
    _dict = {"a": 1, "_UNKNOWN": {"c": 3, "d": 4}}
    _CatchAllUndefinedParameters.handle_to_dict(None, _dict) == {"a": 1,
                                                                 "c": 3,
                                                                 "d": 4}
    _dict = {"a": 1, "_UNKNOWN": {}}
    _CatchAllUndefinedParameters.handle_to_dict(None, _dict) == {"a": 1}

# Generated at 2022-06-11 21:11:12.996225
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect
    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class TestClass:
        one: int
        two: str
        three: int
        four: str
        five: int

        def __init__(self, **kwargs):
            pass

    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    # noinspection PyProtectedMember
    num_params = len(inspect.signature(init_method).parameters) - 1
    assert num_params == 2, "Number of params do not match"



# Generated at 2022-06-11 21:11:23.070436
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class _TestClass():
        a: int
        b: int
        c: str
        d: int
        undefined_parameters: Optional[CatchAllVar] = Undefined.INCLUDE

    test_obj = _TestClass()

    kvs = {"a": 1,
           "b": 2,
           "c": "3",
           "d": 4,
           "undefined_parameters": {}  # will be overwritten
           }
    expected_result = {"a": 1,
                       "b": 2,
                       "c": "3",
                       "d": 4,
                       "undefined_parameters": {"undefined_parameters": {}}}

# Generated at 2022-06-11 21:11:34.911264
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, field1: str, field2: str,
                     field3: Optional[CatchAllVar]):
            self.field1: str = field1
            self.field2: str = field2
            self.field3: Optional[CatchAllVar] = field3

    obj = TestClass(field1="val1", field2="val2",
                    field3={"hello": "world"})
    input_dict = {"field1": "val1", "field2": "val2",
                  "field3": {"hello": "world"}}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, input_dict)
    expected_result = {"field1": "val1", "field2": "val2",
                       "hello": "world"}

# Generated at 2022-06-11 21:11:44.978856
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Test:
        name: str = "a"
        undefined_parameters: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    test = Test()
    kvs = {
        "undefined_parameters": {"a": 1, "b": 2},
        "name": "a"
    }
    result = _CatchAllUndefinedParameters.handle_to_dict(test, kvs)
    expected = {
        "a": 1,
        "b": 2,
        "name": "a"
    }
    assert result == expected

# Generated at 2022-06-11 21:11:53.275741
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, defined, undefined=None):
            self.defined = defined
            self.undefined = undefined

    for name, kvs in [
        ("no undefined", {"defined": 1}),
        ("1 undefined", {"defined": 2, "undefined": "value"}),
        ("2 undefined", {"defined": 2, "undefined": "value",
                         "undefined2": "value2"}),
    ]:
        kvs_actual = _IgnoreUndefinedParameters.handle_from_dict(
            TestClass, kvs)
        assert isinstance(kvs_actual, dict)
        assert kvs_actual == {"defined": kvs["defined"]}, name



# Generated at 2022-06-11 21:11:59.742252
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test whether handle_to_dict works as expected.
    """
    input_data = {"a": 1, "b": 2, "c": 3}

    output_data = _UndefinedParameterAction.handle_to_dict(None, input_data)
    assert output_data == input_data



# Generated at 2022-06-11 21:12:06.224489
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b=2):
            pass

    assert _UndefinedParameterAction.handle_from_dict(TestClass, {}) == {}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, {"a": 1}) \
           == {"a": 1}
    assert _UndefinedParameterAction.handle_from_dict(TestClass,
                                                      {"a": 1, "x": 2}) \
           == {"a": 1}



# Generated at 2022-06-11 21:12:14.721436
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Test method _RaiseUndefinedParameters.handle_from_dict
    """
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: int
        z: int

    test_input = {"x": 1, "y": 2, "z": 3, "a": 4, "b": 5}
    expected_output = {"x": 1, "y": 2, "z": 3}
    decision_maker = _RaiseUndefinedParameters()
    actual_output = decision_maker.handle_from_dict(TestClass, test_input)
    assert actual_output == expected_output



# Generated at 2022-06-11 21:12:26.590450
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: str, b: str, c: str,
                     catch_all: Optional[CatchAllVar] = {}):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass("a", "b", "c")
    assert obj.a == "a"
    assert obj.b == "b"
    assert obj.c == "c"

    # Test that default is returned if nothing is given
    kvs = {}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                           kvs=kvs)
    assert result == {"a": "a", "b": "b", "c": "c"}

    # Test that default is

# Generated at 2022-06-11 21:14:51.245652
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestDataClass:
        a: str
        b: str = dataclasses.field(metadata={"marshmallow_field": fields.Date()})
        c: CatchAll = dataclasses.field(default_factory=dict)

    ret = _CatchAllUndefinedParameters.handle_from_dict(TestDataClass,
                                                        {"a": "a",
                                                         "c": {}})
    assert ret == {"a": "a", "b": None, "c": {}}

    ret = _CatchAllUndefinedParameters.handle_from_dict(TestDataClass,
                                                        {"a": "a",
                                                         "b": "b",
                                                         "c": {},
                                                         "d": "d"})

# Generated at 2022-06-11 21:15:02.738141
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # noinspection PyUnresolvedReferences
    class TestClass:
        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    class_object = TestClass(a=5, b="abcde", c={"ignoreme": 123})
    result = _CatchAllUndefinedParameters.handle_to_dict(class_object,
                                                         kvs={"a": 5,
                                                              "b": "abcde",
                                                              "c":
                                                                  {"ignoreme":
                                                                       123}})
    assert result == {}

# Generated at 2022-06-11 21:15:04.573720
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("test message")
    assert error.args[0] == "test message"



# Generated at 2022-06-11 21:15:16.914548
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest

    class A:
        def __init__(self, a, b=None, catch_all=None):
            pass

    class B:
        def __init__(self, a, b=None, c=None, catch_all=None):
            pass

    class C:
        def __init__(self, a=None, b=None, c=None, catch_all=None):
            pass

    class D:
        def __init__(self, a=None, b=None, c=None, catch_all=None):
            pass

    @dataclasses.dataclass
    class E:
        a: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class F:
        a: Optional[CatchAllVar] = None
