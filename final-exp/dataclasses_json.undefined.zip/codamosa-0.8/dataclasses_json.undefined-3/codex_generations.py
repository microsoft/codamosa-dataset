

# Generated at 2022-06-11 21:05:44.617572
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class SomeClass:

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(SomeClass)
    instance = init(None, 1, 2, 3, d=4)
    assert instance.a == 1
    assert instance.b == 2
    assert instance.c == 3



# Generated at 2022-06-11 21:05:58.110631
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, param1: int, param2: Optional[int]) -> None:
            self.param1 = param1
            self.param2 = param2

    kvs_undefined_parameter_error = {"param1": 1, "unknown": True}
    kvs_undefined_with_catch_all = {"param1": 1, "param3": True}
    kvs_defined = {"param1": 1}
    kvs_defined_with_catch_all = {"param1": 1, "unknown": True}
    catch_all_field_name = "catchAll"


    # Assert that undefined parameters raise an error if the correct flag is
    # passed

# Generated at 2022-06-11 21:06:03.018007
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict({}, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict({}, {"a": 1, "b": 2}) == {
        "a": 1,
        "b": 2
    }



# Generated at 2022-06-11 21:06:14.994936
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from enum import Enum
    from typing import List, Dict

    @dataclasses.dataclass(frozen=True)
    class SimpleClassToSerialize(object):
        foo: int
        bar: str

    @dataclasses.dataclass(frozen=True)
    class ComplexClassToSerialize(object):
        x: List[int] = dataclasses.field(default_factory=lambda: [])
        y: SimpleClassToSerialize
        z: float = dataclasses.field(default=1.0)

    dict_with_extra_fields = dict(foo=3, bar="test", extra_field="test_extra")
    dict_without_extra_fields = dict(foo=3, bar="test")

# Generated at 2022-06-11 21:06:27.257861
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # noinspection PyAbstractClass
    class _TestClass(_UndefinedParameterAction):
        pass

    class _TestClass1:

        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all
            # type: Optional[CatchAllVar]

    test_class_without_catch_all = _TestClass1

    def _test_case(cls, kvs, expected_result):
        actual_result = _UndefinedParameterAction.handle_from_dict(cls, kvs)
        assert actual_result == expected_result

    _test_case(cls=test_class_without_catch_all, kvs={"a": 1, "b": 2},
               expected_result={"a": 1, "b": 2})

    # Create mock class which has 2 fields

# Generated at 2022-06-11 21:06:36.679044
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, *, known_field,
                     unknown_field_after_known_field):
            self.known_field = known_field
            self.unknown_field_after_known_field = \
                unknown_field_after_known_field

    kvs = {
        "known_field": 2,
        "unknown_field_before_known_field": 3,
        "unknown_field_after_known_field": 4
    }

    known = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known == {"known_field": 2}



# Generated at 2022-06-11 21:06:47.771004
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        x: int = 0
        y: int = 0

        @classmethod
        def handle_undefined(cls, kvs):
            return _RaiseUndefinedParameters.handle_from_dict(cls, kvs)

    test_input = {}
    result = A.handle_undefined(test_input)
    assert result == {}

    test_input = {"x": 1}
    result = A.handle_undefined(test_input)
    assert result == {"x": 1}

    test_input = {"x": 1, "z": 3}
    try:
        A.handle_undefined(test_input)
        pytest.fail("Expected exception")
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:06:48.944332
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-11 21:06:52.267878
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError()
    assert error  # needed to fool pytest. It believes that this function
                  # is not used.

# Generated at 2022-06-11 21:07:03.011798
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a, b):
            pass

    class B:
        def __init__(self, a, b):
            pass

    class C:
        def __init__(self, a: int, b: int):
            pass

    a_original_init = A.__init__

    a_new_init = _UndefinedParameterAction.create_init(A)
    b_new_init = _UndefinedParameterAction.create_init(B)
    c_new_init = _UndefinedParameterAction.create_init(C)

    assert a_new_init != a_original_init
    assert b_new_init != B.__init__
    assert c_new_init == C.__init__

# Generated at 2022-06-11 21:07:27.574841
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    class TestClass:
        @dataclasses.dataclass
        class SubObject:
            attr1: str

        sub_object: SubObject
        catch_all: Optional[CatchAllVar] = None

    # Test 1. Default value for catch-all field, no undefined parameters
    # given
    expected_default = {}
    kvs = {"sub_object": {"attr1": "hello"}}

    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

    assert catch_all_field_name in result
    assert result[catch_all_field_name] == expected_default

    # Test 2. Default value for catch-all field, undefined parameters given
    # given
    given_default = {}

# Generated at 2022-06-11 21:07:35.924103
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Test all UndefinedParameterActions.
    """
    class TestDataClass:
        @classmethod
        def __init__(cls, x, y=2):
            cls.x = x
            cls.y = y

    assert _IgnoreUndefinedParameters.create_init(TestDataClass)(
        TestDataClass, 3, 4) == TestDataClass(3)
    assert _RaiseUndefinedParameters.create_init(TestDataClass)(
        TestDataClass, 3, 4) == TestDataClass(3)


# Generated at 2022-06-11 21:07:46.976026
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # CatchAll should be empty if no unknown parameters were given
    obj_empty = Exception()
    assert _UndefinedParameterAction.handle_to_dict(
        obj_empty, {'__dict__': {}}) == {'__dict__': {}}
    # CatchAll should contain unknown parameters
    obj_known = Exception()
    obj_known.__dict__.update({'__dict__': {}, 'UNKNOWN': 4})
    assert _UndefinedParameterAction.handle_to_dict(
        obj_known, {'__dict__': {}, 'UNKNOWN': 4}) == {'__dict__': {}}
    # CatchAll should be empty if no catch-all was given
    obj_no_dict = Exception()

# Generated at 2022-06-11 21:07:57.133938
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass


    @dataclass(unsafe_hash=True)
    class TestClass:
        a: str
        b: int = 1
        c: CatchAll = None

        def __init__(self, a, b, c=None):
            self.a, self.b, self.c = a, b, c


    init = _CatchAllUndefinedParameters.create_init(TestClass)
    c = TestClass("a", 1)
    assert c.c == {}

    c = TestClass("a", 1, {"c": 3, "d": 4})
    assert c.c == {"c": 3, "d": 4}

    c = TestClass("a", 2, {"c": 3})
    assert c.c == {"c": 3}


# Generated at 2022-06-11 21:08:02.042778
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        x: int

    foo = Foo(**_RaiseUndefinedParameters.handle_from_dict(Foo,
                                                           {"x": 1, "y": 2}))
    assert foo.x == 1
    assert hasattr(foo, "y") is False

    # Test with empty dict
    foo = Foo(**_RaiseUndefinedParameters.handle_from_dict(Foo, {}))
    assert foo.x is None

# Generated at 2022-06-11 21:08:03.669376
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-11 21:08:16.741806
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass(unsafe_hash=True,
                          init=False)
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a, b, c):
            pass

        def __eq__(self, other):
            return (self.a, self.b, self.c) == (other.a, other.b, other.c)

    ignore_init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_instance = TestClass(1, 2, 3)
    assert test_instance == ignore_init(TestClass, 1, 2, 3)
    assert test_instance == ignore_init(TestClass, 1, 2, 3, a=4, b=5, c=6)
    assert test_instance == ignore

# Generated at 2022-06-11 21:08:28.196941
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # type: () -> None

    catch_all_field = Field(type=Optional[CatchAllVar], default=None)
    field_b = Field(type=str, default="no explicit default")
    field_c = Field(type=str, default_factory=lambda: "factory default")
    field_d = Field(type=int, default=5)

    @dataclasses.dataclass
    class _TestClass(object):
        a: Optional[CatchAllVar] = catch_all_field
        b: str = field_b
        c: str = field_c
        d: int = field_d

    test_class = _TestClass()

# Generated at 2022-06-11 21:08:38.641426
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, dataclass_json

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass
    class TestClass(DataClassJsonMixin):
        name: str
        age: int

    test_object = TestClass(name="John", age=42, other="hello")
    assert test_object._undefined == {}

    @dataclass_json()
    @dataclass
    class TestClass(DataClassJsonMixin):
        name: str
        age: int

    test_object = TestClass(name="John", age=42, other="hello")
    assert test_object._undefined == {}



# Generated at 2022-06-11 21:08:42.709472
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    test_dict = {"defined": "defined", "undefined": "undefined"}

    @dataclasses.dataclass
    class TestDataClass:
        defined: str

    TestDataClass(**test_dict)

    with pytest.raises(UndefinedParameterError):
        TestDataClass.from_dict(test_dict,
                                undefined_parameters=Undefined.RAISE)



# Generated at 2022-06-11 21:09:09.266743
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():

    # Method _UndefinedParameterAction.create_init might not be tested in
    # a unit test because it is not called directly.
    # Therefore it is explicitly tested here.
    class _UndefinedParameterActionTestClass:
        def __init__(self) -> None:
            pass

    class _UndefinedParameterActionTestSubclass(
            _UndefinedParameterActionTestClass):
        def __init__(self) -> None:
            super().__init__()

    class _IgnoreUndefinedParametersTestClass:
        def __init__(self, a: Optional[int] = None,
                     b: Optional[int] = None, **kwargs) -> None:
            pass



# Generated at 2022-06-11 21:09:18.141042
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b=None, **undefined):
            pass

    original_init = TestClass.__init__

    # Test Ignore
    TestClass.__init__ = _UndefinedParameterAction.create_init(TestClass)
    TestClass(a=1)
    TestClass(a=1, b=2)
    TestClass(a=1, b=2, c=3)
    TestClass(a=1, c=3)

    # Test CatchAll
    TestClass.__init__ = _CatchAllUndefinedParameters.create_init(TestClass)
    TestClass(a=1)
    TestClass(a=1, b=2)
    TestClass(a=1, b=2, c=3)

# Generated at 2022-06-11 21:09:28.215828
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs = {"a": "value_of_a", "b": "value_of_b", "c": "value_of_c"}
    known, _ = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": "value_of_a", "b": "value_of_b"}

# Unit tests for class _IgnoreUndefinedParameters. See
# https://github.com/sdispater/dataclasses/issues/25 for a discussion of why
# this works.



# Generated at 2022-06-11 21:09:30.770550
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dict_ = dict(a=1, b=2)
    assert dict_ == _UndefinedParameterAction.handle_dump(obj=dict_)

# Generated at 2022-06-11 21:09:33.764149
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('Test Error')
    except UndefinedParameterError as e:
        assert str(e) == 'Test Error'

# Generated at 2022-06-11 21:09:37.478305
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_param_error = UndefinedParameterError("this is a test")
    expected_message = "this is a test"
    message = undefined_param_error.message
    assert message == expected_message

# Generated at 2022-06-11 21:09:45.855815
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    _UndefinedParameterAction.handle_dump(TestClass)
    # _UndefinedParameterAction.handle_dump(string) -> AttributeError
    # _UndefinedParameterAction.handle_dump(dict) -> AttributeError
    # _UndefinedParameterAction.handle_dump(object) -> AttributeError
    # _UndefinedParameterAction.handle_dump(list) -> AttributeError
    # _UndefinedParameterAction.handle_dump(1) -> AttributeError
    assert True



# Generated at 2022-06-11 21:09:55.491595
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():

    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: CatchAllVar = None

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {"a": 1, "b": 2}) == {
        "a": 1, "b": 2}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {"a": 1, "b": 2,
                                                       "c": {"x": 5}}) == {
        "a": 1, "b": 2, "c": {"x": 5}}


# Generated at 2022-06-11 21:10:06.894322
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import dataclasses
    from dataclasses_json.undefined import Undefined, _RaiseUndefinedParameters

    @dataclasses.dataclass
    class TestClass:
        foo: str

    testcase: Dict[Dict[str, str], Dict[str, str]] = {
        {"foo": "bar"}: {"foo": "bar"},
        {"foo": "bar", "bar": "baz"}: {"foo": "bar"}
    }
    for given, expected in testcase.items():
        assert _RaiseUndefinedParameters.handle_from_dict(
            TestClass, given) == expected

    @dataclasses.dataclass
    class TestClass2(TestClass):
        pass


# Generated at 2022-06-11 21:10:14.040245
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Example:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    example = Example(k1=1, k2=2)

    # Expected: same result as input
    assert example.__dict__ == _UndefinedParameterAction.handle_to_dict(
        example, example.__dict__)

# Generated at 2022-06-11 21:10:39.995264
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        defined_field: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dict())

    dummy_data = dict(
        defined_field="foo",
        other_field="bar"
    )
    expected_value = dict(
        defined_field="foo",
        catch_all=dict(
            other_field="bar"
        )
    )

    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, dummy_data) == expected_value

    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, dummy_data)
        assert False
    except UndefinedParameterError:
        assert True

    assert _IgnoreUndefinedParameters.handle_from_

# Generated at 2022-06-11 21:10:53.232649
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test that handle_from_dict of _CatchAllUndefinedParameters returns a dictionary
    with a matching CatchAllVar field if the field name is not part of the
    input dictionary.
    """
    @dataclasses.dataclass
    class TestClass:
        # type: Optional[CatchAllVar]
        _UNKNOWN: CatchAll = None

    class_fields = fields(TestClass)
    field_names = [field.name for field in class_fields]
    field_name = "_UNKNOWN"
    _ = field_names.pop(field_names.index(field_name))
    other_field_names = field_names

# Generated at 2022-06-11 21:10:55.905977
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert list(Undefined) == [Undefined.INCLUDE, Undefined.RAISE,
                               Undefined.EXCLUDE]

# Generated at 2022-06-11 21:11:03.861050
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    @dataclass(undefined=Undefined.INCLUDE)
    class A:
        x: int

    a = A(1)
    assert a.x == 1
    assert a.__vars__ == {}

    a = A(1, a=2)
    assert a.x == 1
    assert a.__vars__ == {"a": 2}

    @dataclass(undefined=Undefined.EXCLUDE)
    class B:
        x: int

    b = B(1)
    assert b.x == 1

    b = B(1, a=2)
    assert b.x == 1

    @dataclass(undefined=Undefined.RAISE)
    class C:
        x: int

    c = C(1)
   

# Generated at 2022-06-11 21:11:05.449122
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    pass

# Generated at 2022-06-11 21:11:09.945601
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _RaiseUndefinedParameters.handle_dump(None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}

# Generated at 2022-06-11 21:11:21.395464
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import typing

    @dataclasses.dataclass
    class CatchAll1:
        pass

    @dataclasses.dataclass
    class CatchAll2:
        pass

    @dataclasses.dataclass
    class Foo(metaclass=dataclasses_json.dataclass_json):
        a: typing.List[int]
        _catch_all: dataclasses_json.CatchAll = dataclasses.field(
            default_factory=dict)

    @dataclasses.dataclass
    class Bar(metaclass=dataclasses_json.dataclass_json):
        a: typing.List[int]
        _catch_all: typing.Optional[CatchAll1] = None


# Generated at 2022-06-11 21:11:30.789669
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: str

    @dataclasses.dataclass
    class B:
        a: int
        b: str

        def __init__(self, a: int):
            self.a = a

    @dataclasses.dataclass
    class C:
        a: int
        b: str

        def __init__(self, a: int, b: str = "default", *args, **kwargs):
            print(f"B has been initialized with args: {args} and kwargs: {kwargs}")
            self.a = a
            self.b = b

    def _test_init(cls, a: int, b: str = None, **kwargs) -> None:
        init = _IgnoreUndefinedParameters

# Generated at 2022-06-11 21:11:38.590330
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:11:47.700129
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from unittest import mock
    from marshmallow_dataclass import class_schema

    class Foo:
        def __init__(self, a, b, c=None, d=None, catch_all: Optional[CatchAllVar] = None):
            pass
        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    FooSchema = class_schema(Foo)

    def fake_init(self, a, b, c=None, d=None, catch_all: Optional[CatchAllVar] = None):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.catch_all = catch_all
    mocked_init = mock.MagicMock(side_effect=fake_init)
   

# Generated at 2022-06-11 21:12:27.616076
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class ClsWithCatchAll:
        @dataclasses.dataclass
        class Inner:
            a: str
            b: int
            c: CatchAllVar = dataclasses.field(default_factory=dict)
        inner: Inner
        catch_all: CatchAllVar

    kvs_with_all_defined_parameters = {
        "a": "test",
        "b": 1,
        "inner": {"a": "test", "b": 1},
        "catch_all": {"a": "test", "b": 1}
    }


# Generated at 2022-06-11 21:12:32.842430
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:

        def __init__(self, *args, **kwargs):
            pass

    init_func = _UndefinedParameterAction.create_init(TestClass)
    init_signature = inspect.signature(init_func)

    assert str(init_signature) == "(self, *args, **kwargs)", \
        "TestClass.__init__ signature should not be changed"

# Generated at 2022-06-11 21:12:36.848517
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dc_unexpected_undefined_parameter_error = dataclasses.dataclass(
        eq=False)
    dc_unexpected_undefined_parameter_error(
        unexpected=1)  # pylint: disable=E0001
    assert True

# Generated at 2022-06-11 21:12:47.879353
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.undefined import CatchAll, Undefined

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Data:
        a: int
        b: CatchAll

    # No catch-all is given as parameter, use implicitly generated default
    # (empty dict)
    # noinspection PyArgumentList
    assert Data(  # type: ignore
        a=7
    ) == Data(a=7, b={})

    # No catch-all is given as parameter, use implicitly generated default
    # (empty dict)
    # noinspection PyArgumentList
    assert Data(  # type: ignore
        a=7,
        # noinspection PyTypeHints
        c=8
    ) == Data(a=7, b={'c': 8})

    #

# Generated at 2022-06-11 21:12:56.434477
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from marshmallow import Schema, fields

    from dataclasses_json._UndefinedParameterAction import \
        _UndefinedParameterAction

    class TestSchema(Schema):
        field1 = fields.Boolean()
        field2: Optional[bool] = fields.Boolean()

    schema = TestSchema()
    # noinspection PyTypeChecker
    assert schema.loads({"field1": True}) == {"field1": True}
    assert schema.loads({"field2": True}) == {"field2": True}
    assert schema.loads({"field1": True, "field2": True}) == {
        "field1": True, "field2": True}

    class TestClass(object):

        def __init__(self, field1: bool, field2: Optional[bool] = None):
            self.field1 = field

# Generated at 2022-06-11 21:13:02.036702
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a=None, b=None, c=None):
            self.a = a
            self.b = b
            self.c = c
        a = 0
        b = 1
        c = 2

    class TestClass2:
        def __init__(self, a=None, b=None, c=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
        a = 0
        b = 1
        c = 2

    test_class = TestClass


# Generated at 2022-06-11 21:13:11.416209
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    test_instance = TestClass(a=1, b=2, c=3, d=4)

    original_init = test_instance.__init__
    ignore_init = _IgnoreUndefinedParameters.create_init(obj=TestClass)
    init_signature = inspect.signature(ignore_init)

    expected_parameters = {"b": 2, "a": 1, "c": 3}
    actual_parameters = None

    def new_init(*args, **kwargs):
        nonlocal actual_parameters
        actual_parameters = {k: v for k, v in kwargs.items() if k in
                             expected_parameters}

    test_instance.__init__

# Generated at 2022-06-11 21:13:20.859282
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # TODO: This test is a bit of a hack.
    #       We might want to change it to not use a random class but rather
    #       use a Mock class or something similar.
    #       This test depends on the existence of a class 'MyClass'
    class MyClass:
        def __init__(self, a, b):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_kvs, unknown_kvs = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=MyClass, kvs=kvs)
    assert known_kvs == {"a": 1, "b": 2}
    assert unknown_kvs == {"c": 3}


# Generated at 2022-06-11 21:13:25.786202
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from unittest.mock import Mock

    obj = Mock()
    catch_all_field = Mock()
    catch_all_field.name = "catch_all"
    input_dict = {"a": "a", "b": "b", "catch_all": {"c": "c"}}
    expected_dict = {
        "a": "a",
        "b": "b",
        "c": "c"
    }
    obj.__dataclass_fields__ = {"catch_all": catch_all_field}
    output = _CatchAllUndefinedParameters.handle_to_dict(obj, input_dict)
    assert output == expected_dict

    input_dict = {"a": "a", "b": "b", "catch_all": ["c", "d"]}

# Generated at 2022-06-11 21:13:36.289119
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class _UndefinedParameterActionTestCase(Enum):
        __init__ = _UndefinedParameterAction

    @dataclasses.dataclass
    class A:
        a: str
        b: int
        _UNDEFINED_PARAMETER_ACTION_HANDLING = \
            _UndefinedParameterActionTestCase.EXCLUDE

    @dataclasses.dataclass
    class B:
        a: str
        b: int
        _UNDEFINED_PARAMETER_ACTION_HANDLING = \
            _UndefinedParameterActionTestCase.RAISE

    @dataclasses.dataclass
    class C:
        a: str
        b: int
        c: Optional[CatchAllVar]

# Generated at 2022-06-11 21:14:55.336660
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    try:
        _UndefinedParameterAction.handle_from_dict(cls=None, kvs={})
        assert False
    except NotImplementedError:
        pass

# Generated at 2022-06-11 21:15:04.578133
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # prepare test object
    class Foo:
        def __init__(self, a: str, b: str = "B"):
            pass

    # test correct init arguments
    correct_parameters = {"a": "A"}
    assert _RaiseUndefinedParameters \
           .handle_from_dict(cls=Foo, kvs=correct_parameters) == \
           correct_parameters

    # test wrong init arguments
    wrong_parameters = {"c": "C"}
    try:
        _RaiseUndefinedParameters \
            .handle_from_dict(cls=Foo, kvs=wrong_parameters)
        assert False  # this line should not be reached
    except UndefinedParameterError as e:
        assert isinstance(e, UndefinedParameterError)


# Unit tests for method handle_to_dict of

# Generated at 2022-06-11 21:15:08.008334
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("dummy_message")
    except UndefinedParameterError as e:
        assert e.messages == ["dummy_message"]

# Generated at 2022-06-11 21:15:18.646779
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: str
        zz: int
        catch_all: Optional[CatchAllVar]

    init_signature = inspect.signature(TestClass.__init__)
    init_signature_parameters = init_signature.parameters

    _Init = _CatchAllUndefinedParameters.create_init(TestClass)

    class TestClassWrapper:
        x: int
        y: str
        zz: int
        catch_all: Dict[Any, Any]

        def __init__(self, foo, bar, baz):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    obj = TestClassWrapper(1, 2, 3)