

# Generated at 2022-06-11 21:05:45.288329
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal
    def _create_dataclass(*args, **kwargs):
        @dataclasses.dataclass(frozen=True)
        class Dataclass:
            arg1: str = dataclasses.field(default="arg1")
            arg2: CatchAllVar = dataclasses.field(default_factory=dict)

            def __init__(self, arg1: str, arg2: CatchAllVar,
                         **undefined_kwargs):
                self.arg1 = arg1
                self.arg2 = arg2
                self.undefined_kwargs = undefined_kwargs

        return Dataclass

    obj = _create_dataclass()
    func = _CatchAllUndefinedParameters.create_init(obj)

# Generated at 2022-06-11 21:05:53.820842
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:

        def __init__(self, foo: str, bar: str, _UNKNOWN=None):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)
    foo = "foo"
    bar = "bar"
    unknown = "unknown"

    init(TestClass, foo, bar, unknown)  # should not raise an error
    init(TestClass, foo, bar, _UNKNOWN=unknown)  # should not raise an error

# Generated at 2022-06-11 21:06:03.749490
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined
    from typing import Optional


    @dataclass
    class DummyClass:
        field_a: str
        field_b: Optional[CatchAllVar] = None


        def __init__(self, field_a: str, field_b: CatchAllVar = None):
            pass


    kwargs = {"field_a": "text", "field_b": {"a": "b"}}
    final_params = \
        _IgnoreUndefinedParameters.handle_from_dict(cls=DummyClass,
                                                    kvs=kwargs)
    assert final_params == kwargs

    dummy = DummyClass(**final_params)


# Generated at 2022-06-11 21:06:06.018476
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: str, **kwargs):
            pass

    _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 1, "b": "hello"})



# Generated at 2022-06-11 21:06:16.961357
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Unit test creation
    class Foo:
        def __init__(self, a: int, b: int = 42):
            pass


    assert isinstance(_IgnoreUndefinedParameters.create_init(Foo), Callable)
    # Special case: no initializers
    class Bar:
        pass

    assert isinstance(_IgnoreUndefinedParameters.create_init(Bar), Callable)
    # Special case: No positional arguments
    class B:
        def __init__(self, a: int = 42):
            pass

    assert isinstance(_IgnoreUndefinedParameters.create_init(B), Callable)
    # Special case: No positional arguments, no default values
    class D:
        def __init__(self, a: int):
            pass



# Generated at 2022-06-11 21:06:21.221525
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("dummy message")
    except UndefinedParameterError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, ValidationError)

# Generated at 2022-06-11 21:06:31.826882
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    _CatchAllUndefinedParameters.handle_from_dict(
        object(), {"a": 1, "unknown": 2,
                   "_UNKNOWN0": 3}) == {"a": 1, "unknown": 2}
    _CatchAllUndefinedParameters.handle_from_dict(
        object(), {"a": 1, "unknown": None,
                   "_UNKNOWN0": 3}) == {"a": 1, "unknown": {"_UNKNOWN0": 3}}
    _CatchAllUndefinedParameters.handle_from_dict(
        object(), {"a": 1, "unknown": None,
                   "_UNKNOWN0": 3, "unknown":
                       {"_UNKNOWN1": 4}}) == {"a": 1, "unknown":
                                              {"_UNKNOWN0": 3,
                                               "_UNKNOWN1": 4}}

# Generated at 2022-06-11 21:06:34.174643
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Something went wrong")
    except UndefinedParameterError as e:
        assert "Something went wrong", e.messages

# Generated at 2022-06-11 21:06:44.384773
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow
    import typing
    import datetime
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int
        c: datetime.datetime
        d: typing.Optional[str] = None

    schema = marshmallow.Schema.from_dataclass(TestClass)

    deserialized = schema.load({"a": "asdf", "b": 123, "c": "2020-01-02",
                                "d": "abc", "e": "extra"})


# Generated at 2022-06-11 21:06:52.261345
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump({}) == {}
    assert _UndefinedParameterAction.handle_dump(1) == {}
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _UndefinedParameterAction.handle_dump(()) == {}


# Unit tests for method handle_from_dict of class
# _RaiseUndefinedParameters

# Generated at 2022-06-11 21:07:25.040215
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():

    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)

    assert _UndefinedParameterAction.handle_to_dict(test_obj, {"a": 1, "b": 2,
                                                                "c": 3}) \
           == {"a": 1, "b": 2, "c": 3}, \
        "handle_to_dict should return an unmodified dictionary"



# Generated at 2022-06-11 21:07:33.833857
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from typing import Dict
    from dataclasses import dataclass

    @dataclass
    class NoCatchAll:
        thing: int

        def to_dict(self):
            return _CatchAllUndefinedParameters.handle_to_dict(self, {
                "thing": self.thing
            })

    assert NoCatchAll(thing=5).to_dict() == {
        "thing": 5
    }

    @dataclass
    class WithCatchAll:
        thing: int
        undefined: Optional[CatchAllVar] = None

        def to_dict(self):
            return _CatchAllUndefinedParameters.handle_to_dict(self, {
                "thing": self.thing,
                "undefined": self.undefined
            })

    assert WithCatchAll(thing=5).to_

# Generated at 2022-06-11 21:07:44.656405
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a, b=2, c=None):
            setattr(self, "a", a)
            setattr(self, "b", b)
            setattr(self, "c", c)

    @dataclasses_json.dataclass_json
    class Bar:
        pass

    assert _IgnoreUndefinedParameters.handle_from_dict(Foo, {}) == {}
    assert _IgnoreUndefinedParameters.handle_from_dict(Foo, {"a": 1}) == {
        "a": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(Foo, {"a": 1, "b": 2}) \
           == {"a": 1, "b": 2}

# Generated at 2022-06-11 21:07:51.813005
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class _TestClass:
        testint: int

    known_given_parameters = {"testint": 10}
    unknown_given_parameters = {"testint2": 20}

    expected_result = {"testint": 10, "testint2": 20}

    result = _UndefinedParameterAction.handle_to_dict(
        _TestClass,
        kvs={"testint": 10, "testint2": 20})

    assert result == expected_result


# Generated at 2022-06-11 21:08:00.471016
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: dataclasses_json.utils.CatchAll

    # On empty class
    assert len(_CatchAllUndefinedParameters.handle_dump(
        TestClass)) == 0

    # On class with some attributes
    obj = TestClass(catch_all={"first": "some", "second": "thing"})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == obj.catch_all

# Generated at 2022-06-11 21:08:06.803317
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:08:16.021972
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class DummyClass:
        x: int = 0

        def __init__(self, y) -> None:
            self.y = y

    assert _UndefinedParameterAction.create_init(DummyClass)(
        DummyClass, y=5).y == 5
    config.undefined = Undefined.INCLUDE
    assert _UndefinedParameterAction.create_init(DummyClass)(
        DummyClass, y=5).y == 5



# Generated at 2022-06-11 21:08:26.515832
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        def __init__(self, x, y=None, z=None):
            pass

        def __eq__(self, other):
            return isinstance(other, DummyClass)

    _UndefinedParameterAction.handle_from_dict(DummyClass, {})

    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction.handle_from_dict(DummyClass, {"a": 1})

    _UndefinedParameterAction.handle_from_dict(DummyClass, {"x": 1})

    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction.handle_from_dict(DummyClass, {"x": 1, "a": 1})


# Generated at 2022-06-11 21:08:37.903244
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    u = Undefined.INCLUDE.value

    class Tester:
        def __init__(self, a="a", a2="a2",
                     catch_all: Optional[CatchAllVar] = None):
            pass


    tester = Tester()
    new_init = u.create_init(tester)
    new_tester = Tester()
    new_init(new_tester, "a")

    class Tester2:
        def __init__(self, a, b):
            pass


    tester2 = Tester2()
    new_init2 = u.create_init(tester2)
    new_tester2 = Tester2()
    new_init2(new_tester2, "a", "b")


# Generated at 2022-06-11 21:08:41.450522
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class C(_UndefinedParameterAction):
        pass

    assert C.handle_to_dict(C, {}) == {}
    assert C.handle_to_dict(C, {'a': 'b'}) == {'a': 'b'}



# Generated at 2022-06-11 21:09:14.509760
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    def throws():
        raise UndefinedParameterError("test")
    throws()

# Generated at 2022-06-11 21:09:18.026556
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Unit test (parameterized): Raises UndefinedParameterError with
    the given parameter when called.
    """
    for error_message in ["message", "", None]:
        UndefinedParameterError(error_message)

# Generated at 2022-06-11 21:09:19.811162
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError()
    assert error.messages == {}

# Generated at 2022-06-11 21:09:29.228138
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a: int, b: int = 1):
            pass

        @classmethod
        def from_dict(cls, kvs: Dict[Any, Any]):
            pass

    Test.from_dict = \
        _RaiseUndefinedParameters.handle_from_dict(Test, kvs={})

    assert Test.from_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    with pytest.raises(UndefinedParameterError):
        Test.from_dict({'b': 1, 'c': 1})

    with pytest.raises(UndefinedParameterError):
        Test.from_dict({'a': 1, 'b': 1, 'c': 1})



# Generated at 2022-06-11 21:09:32.321890
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(
        obj=None, kvs={"a": 1, "b": 2}) == {"a": 1, "b": 2}



# Generated at 2022-06-11 21:09:35.946835
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('foo')
    except UndefinedParameterError as error:
        assert error.args[0] == 'foo'

# Generated at 2022-06-11 21:09:46.757569
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Check if inputs are correctly checked and split into defined and
    undefined parameters and then correctly handled.
    """
    # define a dataclass
    @dataclasses.dataclass
    class TestClass:
        a: int

    # Inputs
    # all defined
    input_kv_dict_all_defined = {"a": 1}
    # one defined, one undefined
    input_kv_dict_one_defined = {"a": 1, "b": 2}
    # all undefined
    input_kv_dict_all_undefined = {"b": 2, "c": 3}

    # test
    result_kv_dict = _RaiseUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=input_kv_dict_all_defined)
    assert result_kv

# Generated at 2022-06-11 21:09:55.127675
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class T:
        def __init__(self, a, b):
            pass
    t = T(1, 2)
    initial = {"a": 3, "b": 4, "c": 5}
    try:
        _RaiseUndefinedParameters.handle_from_dict(t, initial)
        assert False, "Expected to raise UndefinedParameterError"
    except UndefinedParameterError:
        pass
    initial = {"a": 3, "b": 4}
    try:
        _RaiseUndefinedParameters.handle_from_dict(t, initial)
    except UndefinedParameterError:
        assert False, "Did not expect to raise UndefinedParameterError"


# Generated at 2022-06-11 21:10:06.510362
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # init signature is not touched
    def init(self, hello: str, world: int):
        return  # pragma: no cover

    class Obj:
        def __init__(self, hello: str, world: int):
            return  # pragma: no cover

    args_minimal = {"hello": "a", "world": 42}
    args_wrong_type = {"hello": "a", "world": "error"}
    args_undefined = {"hello": "a", "world": 42, "foo": "bar"}

    ret = _RaiseUndefinedParameters.handle_from_dict(cls=Obj, kvs=args_minimal)
    assert ret == args_minimal


# Generated at 2022-06-11 21:10:09.503475
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-11 21:10:55.088497
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

    dict_kvs = {"x": 5, "z": 6}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, dict_kvs)
    assert (result == {"x": 5})



# Generated at 2022-06-11 21:11:01.453082
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, defined):
            self.defined = defined

    from_dict = _RaiseUndefinedParameters.handle_from_dict
    assert from_dict(Example, {"defined": 0}) == {"defined": 0}
    assert from_dict(Example, {"defined": 0, "undefined": 0}) == \
           {"defined": 0}
    assert from_dict(Example, {"undefined": 0}) == {}



# Generated at 2022-06-11 21:11:11.656493
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    m = MyClass(a=1, b=2, c=3)
    kvs = dict(a=1, b=2, c=3)
    result = _UndefinedParameterAction.handle_to_dict(obj=m, kvs=kvs)
    assert result == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-11 21:11:20.012463
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        known_field: str
        catch_all: CatchAll

        def __init__(self, known_field: Optional[str] = None,
                     catch_all: Optional[CatchAll] = None):
            self.known_field = known_field or "known value"
            self.catch_all = catch_all or {}

    # noinspection PyProtectedMember
    assert TestClass.__init__ == _CatchAllUndefinedParameters.create_init(
        TestClass)

# Generated at 2022-06-11 21:11:29.834477
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses import dataclass

    # Create dataclass
    @dataclass
    class MyClass(DataClassJsonMixin):
        a: int
        b: str

    # Create test cases
    test_cases: Dict[str, Dict[str, Any]] = {
        "empty": {},
        "a": {"a": 1},
        "a.b": {"a": 1, "b": 2},
        "empty.b": {"b": 2},
        "empty, b = catch-all": {"b": CatchAllVar},
    }

    # Run tests
    for name, test_dict in test_cases.items():
        # Get the kvs to write to the schema
        kvs = _CatchAllUndefinedParameters

# Generated at 2022-06-11 21:11:34.373088
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # pylint: disable=unused-variable

    class TestClass:
        def __init__(self, a: int, b: int, **kwargs):
            self.a = a
            self.b = b

    import inspect

    init = _IgnoreUndefinedParameters.create_init(TestClass)(
        1, 2, c=3, d=4)

    assert inspect.signature(init).parameters.keys() == {"self", "a", "b"}

# Generated at 2022-06-11 21:11:46.005618
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # noinspection PyUnresolvedReferences
    from tests.test_utils import UndefinedParameterClass

    class SpecifiedClass:
        def __init__(self, *, defined_field, defined_field_two):
            pass

    def check_function_for_class(cls: type, *, kvs: dict, expected: dict):
        result = _IgnoreUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
        assert result == expected

    # Test 1: no undefined parameters
    check_function_for_class(SpecifiedClass, kvs={"defined_field": "hi"},
                             expected={"defined_field": "hi"})

    # Test 2: with undefined parameters

# Generated at 2022-06-11 21:11:52.669766
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class CatchAllSubclass(CatchAll):
        pass

    class ExampleClass:
        def __init__(self, name: str, catch_all: CatchAll = None):
            self.name = name
            self.catch_all = catch_all

    new_init = _UndefinedParameterAction.create_init(ExampleClass)

    obj = new_init(ExampleClass, "Awesome", catch_all=CatchAllSubclass())
    assert hasattr(obj, "catch_all")
    assert isinstance(obj.catch_all, CatchAll)

# Generated at 2022-06-11 21:12:01.995238
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # type: () -> None
    class TestClass:

        def __init__(self):
            # type: () -> None
            self.foo = "bar"
            self.zoo = "zar"

    class SubclassIgnore(_IgnoreUndefinedParameters):
        pass

    class SubclassRaise(_RaiseUndefinedParameters):
        pass

    for subclass in [SubclassIgnore, SubclassRaise]:
        assert subclass.handle_dump(TestClass()) == {"foo": "bar",
                                                     "zoo": "zar"}

# Generated at 2022-06-11 21:12:07.711815
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DummyClass(_CatchAllUndefinedParameters):
        a: int
        b: int
        _unknown: Optional[CatchAllVar] = None

    data = {"a": 1, "b": 2, "c": 3}

    kvs = _CatchAllUndefinedParameters.handle_from_dict(DummyClass, data)
    assert kvs["a"] == 1
    assert kvs["b"] == 2
    assert kvs["_unknown"] == {"c": 3}



# Generated at 2022-06-11 21:13:45.953951
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class _CatchAll:
        f1: int
        f2: int = 1
        catch_all: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    _CatchAllUndefinedParameters.create_init(obj=_CatchAll)
    assert True

# Generated at 2022-06-11 21:13:54.817364
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import marshmallow
    import dataclasses_json
    import pytest
    from dataclasses_json.utils import CatchAll

    @dataclasses.dataclass(undefined=dataclasses_json.Undefined.INCLUDE)
    class CatchAllTest:
        a: str
        b: str
        undefined_parameters: Optional[CatchAll] = None

        @classmethod
        def __init_subclass__(cls, **kwargs):
            from marshmallow_dataclass import dataclass

            super().__init_subclass__(**kwargs)
            dataclass(cls, **kwargs)

    kvs_with_undefined = {"a": "hello", "b": "world", "c": "!"}

# Generated at 2022-06-11 21:14:02.041615
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class SimpleObject:
        a: str
        b: int
        bb: int = dataclasses.field(default=2)

    simple_object = SimpleObject("a", 1, bb=3)
    init = _CatchAllUndefinedParameters.create_init(simple_object)
    assert init(simple_object, "c") == simple_object
    init(simple_object, "c", b=2) == simple_object


if __name__ == "__main__":
    test__CatchAllUndefinedParameters_create_init()

# Generated at 2022-06-11 21:14:12.379805
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class DummyClass:
        a: int
        b: int

        def __init__(self, a, b=None, **kwargs):
            self.a = a
            self.b = b

    obj = DummyClass(1, 2)
    assert obj.a == 1
    assert obj.b == 2

    init_under_test = _IgnoreUndefinedParameters.create_init(DummyClass)
    obj = DummyClass(1, b=2, c=3)
    assert obj.a == 1
    assert obj.b == 2

    init_under_test(obj, 1, b=2, c=3)
    assert obj.a == 1
    assert obj.b == 2


# Generated at 2022-06-11 21:14:23.461916
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    import dataclasses_json as d_j
    import dataclasses

    @d_j.dataclass_json(undefined=Undefined.EXCLUDE)
    # noinspection PyShadowingNames
    @dataclasses.dataclass
    class A:
        a: int
        b: int

    assert _IgnoreUndefinedParameters.handle_from_dict(A, dict(a=1, b=2, c=3)) \
           == dict(a=1, b=2)
    assert _IgnoreUndefinedParameters.handle_from_dict(A, dict(a=1, b=2)) \
           == dict(a=1, b=2)

# Generated at 2022-06-11 21:14:33.544054
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    CatchAll = Optional[CatchAllVar]

    # noinspection DuplicatedCode
    @dataclasses.dataclass
    class _TestClass1:
        num: int
        boolean: bool
        name: str
        catch_all: CatchAll = dataclasses.field(default=None)

    # TEST 1: no undefined parameters
    kvs = {"num": 1, "boolean": True, "name": "John"}
    expected = kvs.copy()
    output = _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass1, kvs)
    assert expected == output

    # TEST 2: one undefined parameter
    kvs = {"num": 1, "boolean": True, "name": "John", "undefined": "thing"}
    expected = kvs.copy()

# Generated at 2022-06-11 21:14:36.606817
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # prepare
    kvs = {'hello': 'world', 'one': 1}


    # execute
    ret = _CatchAllUndefinedParameters.handle_from_dict(_CatchAllUndefinedParameters, kvs)

    # assert
    assert ret == kvs

# Generated at 2022-06-11 21:14:48.128700
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class MockClass:
        a: str
        b: int

    assert _UndefinedParameterAction.handle_from_dict(MockClass,
                                                      {"a": "value"}) \
           == {"a": "value"}

    assert _UndefinedParameterAction.handle_from_dict(MockClass,
                                                      {"b": "value"}) \
           == {"b": "value"}

    assert _UndefinedParameterAction.handle_from_dict(MockClass,
                                                      {"a": "value",
                                                       "b": "value"}) \
           == {"a": "value", "b": "value"}


# Generated at 2022-06-11 21:14:54.079865
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        a: str
        b: str

    test_class = TestClass()

    assert _RaiseUndefinedParameters.handle_from_dict(
        test_class, {"a": "a1", "b": "b1"}
    ) == {"a": "a1", "b": "b1"}

    try:
        _RaiseUndefinedParameters.handle_from_dict(test_class, {"a": "a1",
                                                                 "b": "b1",
                                                                 "c": "c1"})
        assert False, "Expected exception"
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-11 21:15:03.948380
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, var1, var2, *, var3=None, var4=None,
                     **catch_all: CatchAll):
            self.var1 = var1
            self.var2 = var2
            self.var3 = var3
            self.var4 = var4
            self.catch_all = catch_all

    obj = Foo(1, 1, var3=3, var4=4, var5=5, var6=6)
    init = _CatchAllUndefinedParameters.create_init(obj)
    obj2 = init(1, 1, var3=3, var4=4, var5=5, var6=6)
    assert obj.var1 == obj2.var1
    assert obj.var2 == obj2.var2
    assert obj.var