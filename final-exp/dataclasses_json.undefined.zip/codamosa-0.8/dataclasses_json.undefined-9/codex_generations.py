

# Generated at 2022-06-11 21:05:38.745462
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, a, b: CatchAll = None):
            self.a = a
            self.b = b

    assert _CatchAllUndefinedParameters.handle_to_dict(A,
                                                       {"a": 1, "x": "y",
                                                        "b": {"x": 5}}) == \
           {"a": 1, "x": 5}

    assert _CatchAllUndefinedParameters.handle_to_dict(A, {"a": 1, "x": "y"}) == \
           {"a": 1, "x": "y"}


if __name__ == "__main__":
    test__CatchAllUndefinedParameters_handle_to_dict()

# Generated at 2022-06-11 21:05:49.611500
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def assert_raises_error(inp, expected_remaining_kvs, error_message):
        try:
            _CatchAllUndefinedParameters.handle_from_dict(
                cls=None, k=inp)
        except UndefinedParameterError as err:
            assert error_message in str(err)
        else:
            assert False, "Error not raised."

    def assert_output_matches(inp, expected_remaining_kvs):
        # type: (Dict, Dict) -> None
        out = _CatchAllUndefinedParameters.handle_from_dict(cls=None, k=inp)
        assert out == expected_remaining_kvs


# Generated at 2022-06-11 21:05:58.428379
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Foo:
        baz: str
        catchall: Optional[CatchAllVar] = None

    foo = Foo("baz")
    empty_dict = {}

    assert _CatchAllUndefinedParameters.handle_dump(foo) == empty_dict

    foo.catchall = {"foo": "bar"}
    assert _CatchAllUndefinedParameters.handle_dump(foo) == {"foo": "bar"}



# Generated at 2022-06-11 21:06:11.343490
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import pytest

    def test_init(self, a_, b_, c_=1, d_=2):
        self.a = a_
        self.b = b_
        self.c = c_
        self.d = d_

    class Test:
        def __init__(self, a, b, c=1, d=2):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    Test.__init__ = test_init
    Test = _IgnoreUndefinedParameters.create_init(Test)
    test = Test(1, 2, c=3, d=4,
                ex1=5, ex2=6)
    assert hasattr(test, "ex1") and hasattr(test, "ex2")


# Generated at 2022-06-11 21:06:18.637848
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={"a": 1})
    except Exception as e:
        assert type(e) == TypeError and str(e) == "cls must be a class"
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=_RaiseUndefinedParameters, kvs=None)
    except Exception as e:
        assert type(e) == TypeError and str(e) == "kvs must be a dictionary"

# Generated at 2022-06-11 21:06:29.812435
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: int, b: str = "b"):
            self.a = a
            self.b = b

    kvs = {"a": 1, "c": 2}
    known_given_parameters = _RaiseUndefinedParameters \
        .handle_from_dict(A, kvs)
    assert kvs == known_given_parameters
    try:
        known_given_parameters = _RaiseUndefinedParameters \
            .handle_from_dict(A, {"a": 1, "c": 2, "d": 3})
        assert kvs == known_given_parameters
    except UndefinedParameterError:
        pass


# Generated at 2022-06-11 21:06:35.015449
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class ClassWithCatchAll(object):
        field1: str = "default1"
        field2: int = 1
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-11 21:06:44.543280
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    test_dict = {"key1": "value1", "key2": 2,
                 "key3": "value3"}

    def test_func(self, key1: str, key2: int):
        return key1, key2

    bound_test_func = test_func.__get__(None, object)
    bound_test_func_signature = inspect.signature(bound_test_func)
    known_args, _ = \
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
            object, test_dict)

    bound_parameters = bound_test_func_signature.bind_partial(**known_args)
    param_kwargs = bound_parameters.arguments
    print(param_kwargs)

# Generated at 2022-06-11 21:06:56.428976
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class A1:
        name: str
        age: int
        country: str

# Generated at 2022-06-11 21:07:07.591834
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from ..utils import CatchAllVar


    @dataclass
    class Hello:
        what: str
        when: int
        where: Optional[CatchAllVar] = None


    def _call_and_compare(given_params: Dict[Any, Any]):
        _result = _CatchAllUndefinedParameters.handle_from_dict(Hello,
                                                                given_params)

        if given_params.get("where", None) is None:
            expected = given_params
        else:
            expected = given_params.copy()
            expected["where"] = {}

        assert _result == expected


    _call_and_compare({})
    _call_and_compare({"what": "world"})

# Generated at 2022-06-11 21:07:31.103680
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class C:
        no_default: int = None
        a: int = 0
        b: Optional[int] = None
        catch_all: Optional[CatchAllVar] = None
        ignore: IgnoreUndefinedParameters = _IgnoreUndefinedParameters()

    c = C(1, 2, 3, 4, 5, 6)
    assert c.a == 1, "invalid init"
    assert c.b == 2, "invalid init"
    assert c.no_default == 7, "invalid init"

    assert isinstance(c.catch_all, dict), "Invalid catch-all type"
    assert len(c.catch_all) == 1, "Invalid length of catch-all"
    assert c.catch_all[6] == 4, "Invalid catch-all init"




# Generated at 2022-06-11 21:07:36.639913
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Dummy:
        def __init__(self, a: int, b: int, *, c: float,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catchall = catch_all

    def init(self, a: int, b: int, c: float,
             catch_all: Optional[CatchAllVar] = None):
        self.a = a
        self.b = b
        self.c = c
        self.catchall = catch_all

    Dummy.__init__ = init
    Dummy.__dataclass_params__ = dataclasses.dataclass_params(
        undefined=Undefined.INCLUDE)

    class_fields = fields(Dummy)
   

# Generated at 2022-06-11 21:07:45.140473
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class DummyClass:
        a: str
        b: str

    dummy_cls = DummyClass("a", "b")

    def new_init(self, a, b, **kwargs):
        assert len(kwargs) == 0
        self.a = a
        self.b = b

    dummy_cls.__init__ = new_init

    new_init = _IgnoreUndefinedParameters.create_init(dummy_cls)
    dummy_cls.__init__ = new_init
    dummy = DummyClass("a", "b", c="c")

# Generated at 2022-06-11 21:07:46.975837
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    instance = _UndefinedParameterAction
    assert instance.handle_dump(dict) == {}

# Generated at 2022-06-11 21:07:49.523203
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class C:
        a: int

    assert _UndefinedParameterAction.handle_from_dict(C, {"a": 1, "b": 2}) == {
        "a": 1}



# Generated at 2022-06-11 21:07:53.899609
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class Test:
        a: int
        b: int

    Test(a=1, b=2)



# Generated at 2022-06-11 21:08:04.504222
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    class A:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, catch_all: Optional[CatchAllVar] = None):
            pass

    create_init = _CatchAllUndefinedParameters.create_init(A)

    def assert_init_works(expected: Dict[str, Any], kwargs: Dict[str, Any]):
        d = create_init(None, **kwargs)
        assert d == expected

    # Test that all arguments are ok

# Generated at 2022-06-11 21:08:17.280001
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow import fields, Schema
    from dataclasses import dataclass
    import dataclasses_json

    # noinspection PyUnusedLocal
    @dataclass
    class TestClass(dict):

        a: int
        b: float
        c: Optional[str] = "default"

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @staticmethod
        def _should_never_be_called():
            raise Exception("This method was called")

    _IgnoreUndefinedParameters.create_init(TestClass)

    class TestSchema(Schema):
        a = fields.Int(required=True)
        b = fields.Float(required=True)
        c = fields.String(required=False)

    test_instance = Test

# Generated at 2022-06-11 21:08:27.104030
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import datetime

    class Foo:
        started: datetime.datetime = datetime.datetime(1, 1, 1)
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

    foo = Foo(started=datetime.datetime.now(), catch_all={"hello": "world"})

    result = _CatchAllUndefinedParameters.handle_to_dict(
        foo, {"started": foo.started,
              "catch_all": foo.catch_all})
    expected = {"started": foo.started, "hello": "world"}

    assert result == expected, \
        f"Expected {expected}, got {result}"

# Generated at 2022-06-11 21:08:32.741950
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestObject:
        _catch_all: CatchAll = dict()

    obj = TestObject()
    obj._catch_all["test_key"] = "test_value"
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {
        "test_key": "test_value"}

# Generated at 2022-06-11 21:09:08.562897
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, x: int, y: int = 2, **kwargs: CatchAllVar):
            self.x = x
            self.y = y
            self.undefined_parameters = kwargs


    test_object = TestClass(1)
    returned_dict = _CatchAllUndefinedParameters.handle_to_dict(
        test_object, {"x": 2, "z": 3})
    assert returned_dict == {"x": 2, "z": 3}
    returned_dict = _CatchAllUndefinedParameters.handle_to_dict(
        test_object, {"y": 2, "z": 3})
    assert returned_dict == {"y": 2, "z": 3}

# Generated at 2022-06-11 21:09:10.727371
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # type: () -> None
    x = _UndefinedParameterAction.handle_dump("hi")
    assert x == {}

# Generated at 2022-06-11 21:09:18.784237
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field
    import typing
    import unittest

    @dataclass
    class A:
        catch_all: typing.Optional[CatchAllVar] = field(
            default_factory=dict)
        a: str

    @dataclass
    class B:
        b: str
        catch_all: typing.Optional[CatchAllVar] = field(
            default_factory=dict)

    @dataclass
    class C:
        c: str
        catch_all: typing.Optional[CatchAllVar] = field(
            default_factory=None)


# Generated at 2022-06-11 21:09:28.402189
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Test:
        one: str
        two: str
        three: Optional[CatchAllVar] = None

    # input data
    test_input_data = {
        "one": "first",
        "two": "second",
        "_UNKNOWN1": "third"
    }

    t = Test(**test_input_data)
    # do something to make sure the dump is done after an instance is
    # created
    # noinspection PyUnresolvedReferences
    t.one
    output = _CatchAllUndefinedParameters.handle_dump(t)

    assert {'_UNKNOWN1': "third"} == output


# Generated at 2022-06-11 21:09:40.791903
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.api import dataclass_json
    # noinspection PyUnresolvedReferences
    from tests.test_utils.test_lettercase import TestCamelCase
    json_str = """
        {
            "myInt": 1,
            "myFloat": 1.1,
            "myStr": "str",
            "myBool": false,
            "myNone": null,
            "myCamelCase": {
                "myInt": 1
            }
        }
    """
    # noinspection PyUnresolvedReferences
    @dataclass_json
    @dataclasses.dataclass
    class Test:
        my_int: int
        my_float: float
        my_str: str
        my_bool: bool
        my_none: None
        my_camel_

# Generated at 2022-06-11 21:09:53.378734
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _TestClass:
        catch_all: CatchAll = None

        def __init__(self, **kwargs):
            raise NotImplementedError


# Generated at 2022-06-11 21:10:01.841381
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction().handle_dump(None) == {}


if __name__ == "__main__":
    from dataclasses import dataclass
    from typing import Optional


    @dataclass
    class UndefinedParameterExample:
        a: Optional[str] = "a"
        b: int = 0
        c: float = 0


    kv_pairs = dict(a=1, b=2)
    print(Undefined.RAISE.value.handle_from_dict(UndefinedParameterExample,
                                                 kv_pairs))

# Generated at 2022-06-11 21:10:10.916908
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyTestClass:
        first_field: int
        second_field: int
        third_field: Optional[CatchAllVar]

    test_object = MyTestClass(1, 2, third_field={"Beep": 1})
    known_given_parameters, unknown_given_parameters = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            test_object, {"third_field": {"boop": 3}, "not_known": "asdf"})
    result = _CatchAllUndefinedParameters.handle_from_dict(test_object,
                                                           known_given_parameters)

# Generated at 2022-06-11 21:10:16.525478
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass
    @dataclass
    class E:
        a: int
        b: int
        c: int

    # Test with a class where no undefined parameters are present
    positives = [
        dict(a=0, b=1, c=2),
        dict(a=1),
        dict(b=0),
    ]
    for positive in positives:
        assert _UndefinedParameterAction.handle_from_dict(cls=E, kvs=positive) \
               == positive

    # Test with a class where undefined parameters are present
    negatives = [
        dict(d=3, a=0, b=1, c=2),
        dict(a=0, b=1, d=3, c=2),
    ]

# Generated at 2022-06-11 21:10:26.610434
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def get_func(obj, kvs):
        return _UndefinedParameterAction.handle_to_dict(obj, kvs)

    class KnownClass:
        name: str
        number: int
        def __init__(self, name: str, number: int): pass

    kt = KnownClass("name", 0)

    assert get_func(kt, {"name" : "name", "number" : 0}) == \
           {"name" : "name", "number" : 0}
    assert get_func(kt, {"name" : "name", "number" : 0, "extra" : 42}) == \
           {"name" : "name", "number" : 0, "extra" : 42}


# Generated at 2022-06-11 21:11:29.794787
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test:
        def __init__(self,
                     a,
                     b=0,
                     c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    new_init = _CatchAllUndefinedParameters.create_init(Test)
    t = Test(a=1, b=2, d=3)
    t2 = Test(a=1, b=2, d=3, c={})
    t3 = Test(a=1, b=2, d=3, c=4)


if __name__ == "__main__":
    test__CatchAllUndefinedParameters_create_init()

# Generated at 2022-06-11 21:11:38.412881
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import marshmallow.exceptions
    import pytest

    @dataclasses.dataclass
    class TestClass:
        catch_all: dataclasses_json.CatchAll

    obj = TestClass(catch_all={'a': 1})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'a': 1}

    # Test that method works on classes without catch-all field
    @dataclasses.dataclass
    class TestClass2:
        hello = 'world'

    obj = TestClass2()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    # Test that method works on classes with multiple catch-all fields
    @dataclasses.dataclass
    class TestClass3:
        catch_all: dataclasses_json.C

# Generated at 2022-06-11 21:11:46.989931
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Test for no undefined parameters
    class TestClassBasic:
        def __init__(self, something, something_else):
            self.something = something
            self.something_else = something_else

    correct_input = {"something": 1, "something_else": 2}
    correct_output = correct_input

    assert correct_output == \
           _RaiseUndefinedParameters.handle_from_dict(
               TestClassBasic, correct_input)

    # Test for undefined parameters
    incorrect_input = {"something": 1, "something_else": 2,
                       "undefined_parameter": 3}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(
            TestClassBasic, incorrect_input)



# Generated at 2022-06-11 21:11:55.207839
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from marshmallow import Schema, fields

    class _InnerTest(object):
        def __init__(self, a: int, b: str, **kwargs: Any):
            self.a = a
            self.b = b
            self.kwargs = kwargs

        def to_dict(self) -> dict:
            return {"a": self.a,
                    "b": self.b}

    class _Test(object):
        def __init__(self, a: int, b: str, c: _InnerTest, d: str = None,
                     __undefined: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.__undefined = __undefined


# Generated at 2022-06-11 21:12:05.975211
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import List


    class A:
        def __init__(self, x: int, y: int, z: List[int]) -> None:
            pass


    assert _IgnoreUndefinedParameters.create_init(A)(None, 1, 2, 3, 4) \
        == A(1, 2, [3, 4])

    assert _IgnoreUndefinedParameters.create_init(A)(None, 1, 2, 3, 4, 5, 6) \
        == A(1, 2, [3, 4])

    assert _IgnoreUndefinedParameters.create_init(A)(None, x=1, y=2, z=[3, 4],
                                                     a=5) == A(1, 2, [3, 4])


# Generated at 2022-06-11 21:12:15.830679
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init = _CatchAllUndefinedParameters.create_init
    CatchAll = Optional[CatchAllVar]

    class TestDataClass1:

        def __init__(self, x, y, z=42, *, a: int = None, b: Optional[str] = None,
                     _catch_all: CatchAll = None):
            self.x = x
            self.y = y
            self.z = z
            self.a = a
            self.b = b
            self._catch_all = _catch_all

    new_init = init(TestDataClass1)
    a_value = 5
    b_value = "Hello"
    unknown_parameter_name = "A"
    unknown_parameter_value = "world"

# Generated at 2022-06-11 21:12:24.680243
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestData:
        a: int
        b: str = "hello"

        def __init__(self, a: int, b: str = "hello") -> None:
            self.a = a
            self.b = b

        @classmethod
        def from_dict(cls, kvs: dict) -> 'TestData':
            return cls(**kvs)

    kvs = {"a": 1, "c": "hello"}
    instance = TestData.from_dict(kvs)
    assert instance.a == 1 and instance.b == "hello"

# Generated at 2022-06-11 21:12:32.614343
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class ClassWithNoInit(object):
        def __init__(self):
            pass

    class ClassWithInit(object):
        def __init__(self):
            pass

    class ClassWithInitWithArgs(object):
        def __init__(self, a: str, b: int):
            pass

    class ClassWithInitWithOnlyOptionalArgs(object):
        def __init__(self, a: str = "", b: int = 0):
            pass

    a0 = ClassWithNoInit()
    a1 = ClassWithNoInit()
    a0_modified = _UndefinedParameterAction.create_init(a0)
    a1_modified = _UndefinedParameterAction.create_init(a1)
    assert a0_modified.__name__ == "__init__"

# Generated at 2022-06-11 21:12:36.653529
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        pass

    params = {"a": 1, "b": 2}
    try:
        _RaiseUndefinedParameters.handle_from_dict(A, params)
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-11 21:12:47.279455
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import unittest
    import numpy as np

    @dataclasses.dataclass(frozen=True)
    class Model:
        foo: int
        bar_str: str = dataclasses.field(default_factory=str)
        bar_int: int = dataclasses.field(default_factory=int)
        bar_float: float = dataclasses.field(default_factory=float)
        bar_bool: bool = dataclasses.field(default_factory=bool)
        _unknown: Optional[CatchAllVar]

    @dataclasses.dataclass(frozen=True)
    class ComplexModel:
        foo: str
        bar_numpy: np.ndarray = dataclasses.field(default_factory=np.array)
        bar_class: Model = dataclasses

# Generated at 2022-06-11 21:15:15.268935
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, a: int = 0, **kwargs: Any):
            self.a = a
            self._UNDEFINED_FIELDS = kwargs  # type: Dict[str, Any]

        @property
        def catch_all(self) -> Dict[str, Any]:
            return self._UNDEFINED_FIELDS

    a = A(a=1, b=2)
    kvs = {
        "a": a.a,
        "catch_all": a.catch_all,
    }
    kvs_to_dump = _CatchAllUndefinedParameters.handle_to_dict(a, kvs)
    assert kvs_to_dump == {
        "a": a.a,
        "b": 2,
    }