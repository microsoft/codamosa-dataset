

# Generated at 2022-06-11 21:05:45.055985
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import config
    from dataclasses_json._undefined import _CatchAllUndefinedParameters, \
        Undefined

    class Example:
        """
        These configurations should work:
        """
        config.undefined = Undefined.EXCLUDE
        undefined = config.undefined()

    class Example:
        config.undefined = Undefined.RAISE
        undefined = config.undefined()

    class Example:
        config.undefined = Undefined.INCLUDE
        undefined = config.undefined()


    # This depends on a private function, so this test might fail if the
    # behaviour of
    # handle_to_dict changes.

    class Example:
        config.undefined = Undefined.INCLUDE
        undefined = config.undefined()


# Generated at 2022-06-11 21:05:47.759219
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = object()
    expected = {}
    actual = _UndefinedParameterAction.handle_dump(obj)
    assert expected == actual


# Generated at 2022-06-11 21:05:59.165228
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Test 1
    obj = TestClassWithCatchAll(a = 'a', catch_all = {'b': 'b'})
    kvs = {'a': 'a'}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == {'a': 'a', 'b': 'b'}

    # Test 2
    obj = TestClassWithCatchAll(a = 'a')
    kvs = {'a': 'a'}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == {'a': 'a'}



# Generated at 2022-06-11 21:06:11.780041
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from marshmallow.fields import String
    from marshmallow_dataclass import class_schema

    class Foo:
        def __init__(self, *, a: str, b: str):
            self.a = a
            self.b = b

    def f(self, a: str, b: str):
        self.a = a
        self.b = b

    Foo.__init__ = f
    FooSchema = class_schema(Foo)

    foo = Foo("hallo", "peter")
    foo_dumped = FooSchema().dump(foo)
    assert foo_dumped == {"a": "hallo", "b": "peter"}

    foo = Foo("hallo", "peter", c="paul")
    foo_dumped = FooSchema().dump(foo)
    assert foo

# Generated at 2022-06-11 21:06:19.059112
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class CatchAllClass:
        a: int
        b: str
        c: Optional[CatchAllVar]  # type: ignore

    assert CatchAllClass.__init__.__name__ == "__init__"

    # No catch-all defined --> UndefinedParameterError
    @dataclasses.dataclass
    class NoCatchAllClass:
        a: int

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_from_dict(
            cls=NoCatchAllClass, kvs={"a": 1, "b": 2})

    # Multiple catch-all defined --> UndefinedParameterError
    @dataclasses.dataclass
    class MultipleCatchAllClass:
        a: int

# Generated at 2022-06-11 21:06:26.726986
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test to handle_to_dict.
    Test that the given parameters are returned unchanged
    """
    some_parameters = {
        "some": "parameters",
        "to": "test",
        "undefined": "parameter handling"
    }
    returned_parameters = \
        _UndefinedParameterAction.handle_to_dict(None, some_parameters)
    assert some_parameters == returned_parameters



# Generated at 2022-06-11 21:06:30.876224
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("testing")
    except UndefinedParameterError as e:
        assert str(e) == "testing"
        str(e)

# Generated at 2022-06-11 21:06:40.011023
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from typing import Type
    from dataclasses import dataclass
    from marshmallow_dataclass import dataclass as marshmallow_dataclass

    @dataclass
    class A:
        a: int
        b: str

    @marshmallow_dataclass
    class B:
        a: int
        b: str

    @dataclass
    class C:
        a: int
        b: str
        c: int = 4
        d: str = "d"

    @dataclass
    class D:
        a: int
        b: str
        c: int = 4
        d: str = "d"
        e: int = 5


# Generated at 2022-06-11 21:06:49.796640
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # test that _CatchAllUndefinedParameters.handle_to_dict removes
    # the CatchAll from the output without affecting LetterCase
    class Foo:
        def __init__(self, catch_all: CatchAll, a: str):
            self.catch_all = catch_all
            self.a = a

    foo = Foo(catch_all={"b": 1}, a="2")
    kvs_before = {"a": foo.a, "b": foo.catch_all["b"],
                  "C": "3"}
    kvs_after = _CatchAllUndefinedParameters.handle_to_dict(
        obj=Foo, kvs=kvs_before)
    assert kvs_after == {"a": foo.a, "C": "3"}



# Generated at 2022-06-11 21:06:58.254367
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int = 1, c: int = 2):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-11 21:07:13.083998
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}

# Generated at 2022-06-11 21:07:22.736990
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    kvs = {"field1": "one", "field2": {"field2_1": "two", "field2_2": "three"},
           "__CATCH_ALL__": {"catch_all1": "four", "catch_all2": "five"}}
    result = _CatchAllUndefinedParameters.handle_to_dict(None, kvs);
    assert kvs == {"field1": "one", "field2": {"field2_1": "two", "field2_2": "three"},
                   "catch_all1": "four", "catch_all2": "five"}
    assert kvs == result

# Generated at 2022-06-11 21:07:32.828803
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class MyClass:
        """
        A test class.
        """

        def __init__(self,
                     first: str = "first",
                     second: int = 17,
                     third: Optional[CatchAllVar] = None):
            self.first = first
            self.second = second
            self.third = third

    def dict_from_object(obj) -> Dict[str, Any]:
        return {f.name: getattr(obj, f.name) for f in fields(obj)}

    def assert_dict_from_object_equal(obj, expected):
        dict_from_obj = dict_from_object(obj)
        assert dict_from_obj == expected

    # Ensure that no catch-all field is supplied if no catch-all parameter
    # is in the __init__

# Generated at 2022-06-11 21:07:42.753020
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import NamedTuple


    class TestNamedTuple(NamedTuple):
        a: int = 1


    class TestClass:
        def __init__(self, a: int, b: int):
            pass


    init_method = _IgnoreUndefinedParameters.create_init(TestClass)

    old_init = TestClass.__init__
    TestClass.__init__ = init_method
    TestClass(1, 2, 3, 4, 5)
    assert (1, 2, 3, 4, 5) == TestClass.__init__.__wrapped__.__wraps__(
        *(1, 2, 3, 4, 5), **{})

    TestClass.__init__ = old_init

# Generated at 2022-06-11 21:07:48.354200
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Class:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    obj = Class()
    assert _UndefinedParameterAction.handle_dump(obj) == {}
    obj.catch_all = {}
    assert _UndefinedParameterAction.handle_dump(obj) == {}
    obj.catch_all = {"hello": 1}
    assert _UndefinedParameterAction.handle_dump(obj) == {"hello": 1}

# Generated at 2022-06-11 21:08:01.706549
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo:
        def __init__(self,
                     a: int,
                     b: int,
                     c: int = None,
                     d: str = "hello"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d


    # Test with two unnamed parameters
    f = Foo(a=1, b=2)
    result = _IgnoreUndefinedParameters.create_init(Foo)(f, a=1, b=2, e=3)
    assert result is not None
    assert result.c is None
    assert result.d == "hello"

    # Test with one unnamed parameter and one named parameter
    f = Foo(1, b=2)

# Generated at 2022-06-11 21:08:07.831660
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class C:
        v1: int
        v2: str
        v3: int

    # All parameters are given
    kvs = dict(v1=1, v2="hallo", v3=3)
    kvs = _UndefinedParameterAction.handle_from_dict(C, kvs)
    assert kvs == dict(v1=1, v2="hallo", v3=3)

    # Some parameters are not given
    kvs = dict(v1=1)
    try:
        _UndefinedParameterAction.handle_from_dict(C, kvs)
        assert 0, "Expected an exception"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:08:14.574359
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        test: str = "a"

        def __init__(self, test: str, **_) -> None:
            self.test = test

    undef = _IgnoreUndefinedParameters

    kvs = {"test": "a"}
    expected = {"test": "a"}
    assert undef.handle_from_dict(Test, kvs) == expected



# Generated at 2022-06-11 21:08:18.767119
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=object, kvs={"a": 1, "b": 2})
    assert known == {"a": 1, "b": 2}
    assert len(unknown) == 0


# Generated at 2022-06-11 21:08:31.123086
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    global CatchAll

    import dataclasses_json
    import unittest
    import json

    @dataclasses.dataclass(frozen=True)
    class _CatchAllParamTest(object):
        a: int = 2
        b: str = "other"
        c: CatchAll = dataclasses_json.CatchAll(factory=dict)

    @dataclasses.dataclass(frozen=True)
    class _CatchAllParamTestDefaults(object):
        a: int = 2
        b: str = "other"
        c: CatchAll = dataclasses_json.CatchAll()

    class TestCatchAll(unittest.TestCase):
        def test_from_dict_equal_as_params(self):
            a = 1

# Generated at 2022-06-11 21:09:08.954739
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class SomeClass:
        def __init__(self, a: int, b: str, c: str="test"):
            pass
    assert SomeClass.__init__.__name__ == "__init__"

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class SomeClass:
        a: int
        b: str
        c: str = "test"

        def __init__(self, a: int, b: str, c: str="test"):
            self.a = a
            self.b = b
            self.c = c
    assert SomeClass.__init__.__name__ == "__init__"


# Generated at 2022-06-11 21:09:16.667939
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    parameters = _RaiseUndefinedParameters.handle_from_dict(C,
                                                            {"a": 1, "b": 2})
    assert "a" in parameters
    assert "b" in parameters
    assert parameters["a"] == 1
    assert parameters["b"] == 2

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(C, {"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-11 21:09:23.915699
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        a: int
        b: int
        c: int

    test_dict = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected_return = {"a": 1, "b": 2, "c": 3}

    test_result = _UndefinedParameterAction.handle_from_dict(TestClass,
                                                             test_dict)
    assert test_result == expected_return


# Generated at 2022-06-11 21:09:30.958299
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def id(x):
        return x



# Generated at 2022-06-11 21:09:43.423266
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class SimpleClass:
        _catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None,
            metadata={"marshmallow_field": dataclasses_json.config.Url(
                relative=True,
                load_from="_catch_all",
                dump_to="catch_all")}
        )
        _include: str = dataclasses.field(
            default="include",
            metadata={"marshmallow_field": dataclasses_json.config.Url(
                relative=True,
                load_from="_include",
                dump_to="include")}
        )

    x = SimpleClass()

# Generated at 2022-06-11 21:09:54.099752
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from marshmallow import Schema, fields
    import datetime
    import pytest
    import operator
    import copy


    def get_default_parameters(obj):
        parameters = {}
        for f in fields(obj):
            # noinspection PyProtectedMember
            if f.default != dataclasses._MISSING:
                parameters[f.name] = f.default
        return parameters


    def apply_init_function(obj, init_function, parameters={}):
        object_copy = copy.copy(obj)
        all_parameters = get_default_parameters(obj)
        all_parameters.update(parameters)
        init_function(object_copy, **all_parameters)
        return object_copy


    def get_init_function(obj, ignore_undefined):
        init_func

# Generated at 2022-06-11 21:09:55.515749
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump({}) == {}

# Generated at 2022-06-11 21:10:04.661829
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class _TestClass:
        val: int

    defined_kvs = {
        "val": 1,
    }

    unknown_kvs = {
        "foo": "bar",
    }

    assert _RaiseUndefinedParameters.handle_from_dict(
        _TestClass,
        defined_kvs
    ) == defined_kvs

    try:
        _RaiseUndefinedParameters.handle_from_dict(
            _TestClass,
            {**defined_kvs, **unknown_kvs}
        )
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-11 21:10:08.626325
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # arrange
    class TestClass():
        pass

    # act
    _UndefinedParameterAction.handle_dump(TestClass())



# Generated at 2022-06-11 21:10:16.172451
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class DummyClass:
        x: int

        def __init__(self, *args, **kwargs):
            self.__init__(*args, **kwargs)
            pass

    new_init = _IgnoreUndefinedParameters.create_init(DummyClass)
    # Make sure that the signature of the new method is identical to the
    # signature of the original method
    assert new_init.__signature__ == DummyClass.__init__.__signature__



# Generated at 2022-06-11 21:11:23.032385
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(init=False)
    class _Tester:
        """
        This class is instantiated with as many numbers as one wants,
        all numbers which can not be passed to the constructor are
        inserted into the catch-all variable.
        """
        x: int
        y: int
        _catch_all: CatchAll

        def __init__(self, x, y, _catch_all: CatchAll[str, int] = {}):
            self.x = x
            self.y = y
            self._catch_all = _catch_all

    tester = _Tester
    _CatchAllUndefinedParameters.create_init(tester)
    _tester = tester(1, 2, z=3)
    assert _tester.x == 1

# Generated at 2022-06-11 21:11:26.631867
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a=None):
            self.a = a

    data = {"b": "c"}
    result = _UndefinedParameterAction.handle_from_dict(TestClass, data)
    assert result == {}

# Generated at 2022-06-11 21:11:29.054113
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(object, {"a": "b"}) == {"a": "b"}



# Generated at 2022-06-11 21:11:35.425095
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    catch_all_field = Field(
        name="_CATCH_ALL",
        type=Optional[dataclasses_json.CatchAllVar],
        default=None,
        default_factory=None,
        init=True,
        repr=True,
        hash=None,
        compare=True,
        metadata=None,
    )

    @dataclasses.dataclass(frozen=True,
                           repr=False,
                           order=False)
    class TestClass:
        name: str
        age: int
        _CATCH_ALL: Optional[dataclasses_json.CatchAllVar] = catch_all_field


# Generated at 2022-06-11 21:11:44.939511
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Person:
        def __init__(self, name: str, age: int, **undefined):
            self.name = name
            self.age = age
            self.undefined = undefined

    params = {
        "name": "John",
        "age": 30,
        "size": "medium",
        "dynamic": True
    }
    expected = {"name": "John",
                "age": 30,
                "size": "medium",
                "dynamic": True}
    assert _CatchAllUndefinedParameters.handle_to_dict(
        Person, params) == expected



# Generated at 2022-06-11 21:11:54.081838
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        defined: str
        catch_all: CatchAllVar = dataclasses.field(
            default_factory=dict)
        defined_with_default: str = "default"

    # Test that catch_all is not created with default
    no_catch_all = _CatchAllUndefinedParameters.handle_from_dict(TestClass, {})
    assert no_catch_all == {}

    # Test that catch_all is not created with default if  defined parameters
    # are given
    no_catch_all = \
        _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                      {"defined": "test"})
    assert no_catch_all == {"defined": "test"}

    # Test that catch_all is created with default if a default

# Generated at 2022-06-11 21:12:05.447872
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, x: int, y: int = 7, *, _catch_all: Optional[CatchAll] = None):
            self.x = x
            self.y = y
            self._catch_all = _catch_all

    @dataclasses.dataclass
    class B:
        x: int
        y: int = 7
        _catch_all: Optional[CatchAll] = None

    parameters = {
        "x": 2,
        "a": 1,
    }

    def assert_handle_from_dict_params(kvs: Dict[str, Any],
                                       expected_params: Dict[str, Any]) -> None:
        assert _CatchAllUndefinedParameters.handle_from_dict(A, kvs) == expected_params
        assert _

# Generated at 2022-06-11 21:12:15.489096
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Test:
        foo: str
        bar: str
        catch_all: Optional[CatchAll] = None

        def __init__(self, foo: str, bar: str, catch_all: Dict[str, Any] = {}):
            self.foo = foo
            self.bar = bar
            self.catch_all = catch_all

    def test_correct_init(expected_parameters: Dict[str, Any]):
        init = _CatchAllUndefinedParameters.create_init(Test)
        init(Test, **expected_parameters)

    test_correct_init({"foo": "a", "bar": "b"})

# Generated at 2022-06-11 21:12:18.409245
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError(message='foo')
    except UndefinedParameterError as upe:
        assert upe.message == 'foo'

# Generated at 2022-06-11 21:12:19.920191
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyTypeChecker
    assert True == False

# Generated at 2022-06-11 21:14:39.145090
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses_json.dataclass_json(undefined=Undefined.EXCLUDE)
    class TestIgnoreUndefinedParameters:
        x: int
        y: str
        z: float

    obj = TestIgnoreUndefinedParameters(1, "a", 1.0)

    assert obj.x == 1
    assert obj.y == "a"
    assert obj.z == 1.0
    assert isinstance(obj.__init__, Callable)



# Generated at 2022-06-11 21:14:50.673019
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self, x: int, catch_all: CatchAll = None):
            self.x = x
            self.catch_all = catch_all

    c = C(x=1, catch_all={"y": 2})

    kvs = _CatchAllUndefinedParameters.handle_from_dict(C,
                                                        {"x": 1,
                                                         "catch_all": {"y": 2}})
    assert (c.x, c.catch_all) == (kvs["x"], kvs["catch_all"])

    kvs = _CatchAllUndefinedParameters.handle_from_dict(C,
                                                        {"x": 1,
                                                         "catch_all": "wrong"})

# Generated at 2022-06-11 21:14:53.943222
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    expected_output = {}
    result = _UndefinedParameterAction.handle_dump(None)
    assert expected_output == result


# Generated at 2022-06-11 21:15:03.832318
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        pass

    @dataclasses.dataclass
    class TestWithoutParams(Test):
        pass

    @dataclasses.dataclass
    class TestWithParams(Test):
        a: int
        b: str

    @dataclasses.dataclass
    class TestWithCatchAll(Test):
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    @dataclasses.dataclass
    class TestWithDefaultCatchAll(Test):
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: {1: 0})


# Generated at 2022-06-11 21:15:06.668136
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    action = _IgnoreUndefinedParameters
    assert action.handle_dump({}) == {}
    assert action.handle_dump(object()) == {}

# Generated at 2022-06-11 21:15:17.947692
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses_json.utils import CatchAllVar
    import marshmallow

    @dataclasses.dataclass
    class _MyDataclass:
        a: int
        b: str
        c: Optional[CatchAllVar]=None

        def __init__(self, a, b, c=None):
            pass

    init = _CatchAllUndefinedParameters.create_init(_MyDataclass)
    init(None, 1, "b", field=3)
    init(None, 1, "b", field=3, field2=4)
    init(None, 1, "b", field=3, field2=4, d=5)
    init(None, 1, "b", field=3, field2=4, d=5, e=6)