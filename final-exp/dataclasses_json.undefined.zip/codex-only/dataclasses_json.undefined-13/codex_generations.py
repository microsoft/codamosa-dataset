

# Generated at 2022-06-23 16:55:39.084203
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class C(object):
        a: int
        b: int
        c: int = dataclasses.field(metadata={"data_key": "cc"})

        def __init__(self, *, a: int, b: int, c: int = None,  # type: ignore
                     **kwargs: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            if c is None:
                self.cc = 0
            self.cc = c
            self.unknown = kwargs

    obj = C(a=10, b=20, c=30)
    kvs = {"a": obj.a, "b": obj.b, "cc": obj.cc, **(obj.unknown)}

# Generated at 2022-06-23 16:55:41.034150
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    assert str(_IgnoreUndefinedParameters) == "IgnoreUndefinedParameters"

# Generated at 2022-06-23 16:55:52.548529
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses_json

    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    input_ = {"a": "b", "something": "else"}
    assert _CatchAllUndefinedParameters.handle_from_dict(A, kvs=input_) \
           == {"a": "b", "c": {"something": "else"}}

    input_ = {"a": "b", "c": {"something": "else"}}
    assert _CatchAllUndefinedParameters.handle_from_dict(A, kvs=input_) \
           == {"a": "b", "c": {"something": "else"}}


# Generated at 2022-06-23 16:56:00.164679
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a, b, c: int = 0):
            self.a = a
            self.c = c
            self.b = b

    a = A("a", "b", c=1)
    init = _IgnoreUndefinedParameters.create_init(A)
    init(a, "a", "b", c=1, d=2)
    assert a.a == "a"
    assert a.b == "b"
    assert a.c == 1

# Generated at 2022-06-23 16:56:07.037986
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class DummyClass:
        def __init__(self, first_name: str, last_name: str):
            self.first_name = first_name
            self.last_name = last_name

    test_dicts = [
        {"first_name": "John", "last_name": "Doe"},
        {"first_name": "John", "last_name": "Doe", "undefined": "undefined"},
        {"first_name": "John", "last_name": "Doe",
         "undefined": "undefined", "even_more_undefined": "even_more_undefined"},
        {"undefined": "undefined", "even_more_undefined": "even_more_undefined"}
    ]

    for test_dict in test_dicts:
        init_dict = \
            _

# Generated at 2022-06-23 16:56:11.756404
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class _TestClass:
        def __init__(self, a, b, c='c', d='d', e='e'):
            pass

    init = _IgnoreUndefinedParameters.create_init(_TestClass)
    init(_TestClass(1, 2, 3, 4, 5), a=6)

# Generated at 2022-06-23 16:56:18.118518
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Example:
        no_default: str
        has_default: str = "default"

    known, unknown = _IgnoreUndefinedParameters.handle_from_dict(
        cls=Example,
        kvs={"no_default": "value", "has_default": "ignore",
             "undefined": "value"})
    assert {"no_default": "value", "has_default": "default"} == known
    assert {} == unknown



# Generated at 2022-06-23 16:56:24.655237
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # noinspection PyUnusedLocal
    class Foo:
        def __init__(self, a, b, c, **kwargs):
            pass

    constructor = _IgnoreUndefinedParameters.create_init(Foo)

    # noinspection PyRedundantParentheses
    # noinspection PyArgumentList
    assert Foo(a=1, b=1, c=1, **{
        "d": 1,
        "e": 1
    }) == constructor(Foo, **{
        "a": 1,
        "b": 1,
        "c": 1,
        "d": 1,
        "e": 1
    })


# Generated at 2022-06-23 16:56:28.690460
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class MyClass:
        def __init__(self, field1, field2):
            self.field1 = field1
            self.field2 = field2

    parameters = {
        "field1": "value1",
        "undefined_field": "value_undefined_field"  # this field is ignored
    }
    resulting_parameters = _IgnoreUndefinedParameters.handle_from_dict(
        cls=MyClass, kvs=parameters)
    assert parameters == resulting_parameters



# Generated at 2022-06-23 16:56:39.727856
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: CatchAll = None

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            print("__init")

    obj = TestClass.__new__(TestClass)

    # The enclosed function we want to inspect is highly dependant on the code
    # we want to test.
    # Cleanup code is needed to make sure we do not get duplicated or unneeded
    # annotations, or
    # wrong annotations.

    def _cleanup(function: Callable, *,
                 remove_self: bool = True) -> Callable:
        """
        Remove annotations and defaults and possible extra self parameter.
        """
        signature = inspect

# Generated at 2022-06-23 16:56:48.325559
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    import dataclasses
    import unittest

    # noinspection PyUnusedLocal,PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        attr1: Any

    class UnitTest(unittest.TestCase):
        def test_handle_from_dict_no_undefined_parameters(self):
            dict_to_convert = {
                "attr1": "baz"
            }
            expected_output = dict_to_convert

            output = _RaiseUndefinedParameters.handle_from_dict(
                cls=TestClass, kvs=dict_to_convert)

            self.assertEqual(expected_output, output)


# Generated at 2022-06-23 16:56:53.251795
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        a: int
        b: int
        c: CatchAll

        def __init__(self, a: int, b: int, c: Optional[CatchAll] = None):
            pass

    _UndefinedParameterAction.create_init(TestClass)(
        TestClass(1, 2, c={"test_field": True}))

# Generated at 2022-06-23 16:57:02.695055
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass()
    class NoDefaults:
        catch_all: CatchAll
        a: str
        b: int

    @dataclasses.dataclass()
    class OneDefault:
        catch_all: CatchAll
        a: str
        b: int = 1

    @dataclasses.dataclass()
    class OneDefaultFactory:
        catch_all: CatchAll
        a: str
        b: int = dataclasses.field(default_factory=dict)

    @dataclasses.dataclass()
    class OneDefaultFactory2:
        catch_all: CatchAll
        a: str
        b: int = dataclasses.field(default_factory=dict)

    def test_no_kwargs_given(cls):
        generated_init = _CatchAllUnd

# Generated at 2022-06-23 16:57:08.902894
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Test:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

    test = Test()
    assert test.catch_all == {}

    test = Test(catch_all={"unknown": 42})
    assert test.catch_all == {"unknown": 42}

# Generated at 2022-06-23 16:57:10.057120
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    d = _UndefinedParameterAction.handle_dump
    assert d({}) == {}

# Generated at 2022-06-23 16:57:13.009338
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={"hello": "world"})
    except UndefinedParameterError:
        assert True
    else:
        assert False, "UndefinedParameterError not raised"



# Generated at 2022-06-23 16:57:20.003753
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class TestUndefinedRaise:
        prop1: str
        prop2: int
        undefined: _RaiseUndefinedParameters
    with pytest.raises(UndefinedParameterError) as e:
        TestUndefinedRaise(prop1="hello", prop2=3, undefined="foo")
    assert e.value.message == "Received undefined initialization arguments {'undefined': 'foo'}"



# Generated at 2022-06-23 16:57:28.599699
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    kvs1 = {"a": 1, "b": 2, "c": 3}
    kvs2 = {"a": 1, "b": 2}
    kvs3 = {"a": 1, "c": 3}

    res1 = _IgnoreUndefinedParameters.handle_from_dict(Foo, kvs1)
    res2 = _IgnoreUndefinedParameters.handle_from_dict(Foo, kvs2)
    res3 = _IgnoreUndefinedParameters.handle_from_dict(Foo, kvs3)

    assert res1 == res2
    assert res1 == res3
    assert res2 == res3


# Generated at 2022-06-23 16:57:39.073446
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _TestClass:
        def __init__(self, a: str, b: str, catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    instance = _TestClass("1", "2", {"c": 1, "d": 2})
    assert _CatchAllUndefinedParameters.handle_to_dict(instance,
                                                       {"a": 1, "b": 2,
                                                        "c": 3, "d": 4}) == {
        "a": 1, "b": 2, "c": 3, "d": 4}
    assert _CatchAllUndefinedParameters.handle_to_dict(instance,
                                                       {"a": 1, "b": 2}) == {
        "a": 1, "b": 2}

# Generated at 2022-06-23 16:57:45.906835
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Dummy:
        def __init__(self, a=1, b: int = 2) -> None:
            pass

    # Tests
    res = _IgnoreUndefinedParameters.handle_from_dict(
        cls=Dummy, kvs={"a": 1, "b": 2, "unknown": "UNKNOWN"})
    assert res == {"a": 1, "b": 2}



# Generated at 2022-06-23 16:57:47.164849
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A:
        def __init__(self, **kwargs):
            pass
    _RaiseUndefinedParameters.handle_from_dict(cls=A,
                                               kvs={})

# Generated at 2022-06-23 16:57:54.355425
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            pass

    instance = Test(1, 2)
    catch_all_parameters = _CatchAllUndefinedParameters.handle_dump(instance)
    assert catch_all_parameters == {}
    instance = Test(1, 2, {"test": 42})
    catch_all_parameters = _CatchAllUndefinedParameters.handle_dump(instance)
    assert catch_all_parameters == {"test": 42}

# Generated at 2022-06-23 16:57:56.249607
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: Any = 3

    TestClass(None)

# Generated at 2022-06-23 16:57:57.675912
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # noinspection PyUnresolvedReferences
    from dataclasses_json import _CatchAllUndefinedParameters, Undefined
    from dataclasses_json.config import Config

    _CatchAllUndefinedParameters.create_init(Config)

# Generated at 2022-06-23 16:58:08.013266
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:

        @dataclasses.dataclass
        class _TestClass(object):
            catch_all: Optional[CatchAllVar] = None

        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all

        def to_dict(self):
            kvs = {
                "catch_all": self.catch_all
            }
            return _CatchAllUndefinedParameters.handle_to_dict(
                self, kvs)

    test_class = TestClass._TestClass()
    result = test_class.to_dict()
    assert not result["catch_all"]

    test_class = TestClass._TestClass(catch_all={"x": "y"})
    result = test_class.to_dict()

# Generated at 2022-06-23 16:58:10.384783
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert isinstance(_RaiseUndefinedParameters, object)
    assert isinstance(_RaiseUndefinedParameters.handle_from_dict,
                      staticmethod)
    assert isinstance(_RaiseUndefinedParameters.create_init, staticmethod)



# Generated at 2022-06-23 16:58:14.229653
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    from dataclasses import dataclass

    @dataclass
    class SomeClass(_UndefinedParameterAction):
        a: int
        b: int

    assert _UndefinedParameterAction.create_init(SomeClass)(
        SomeClass, a=1, b=2) is None

# Generated at 2022-06-23 16:58:23.303227
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from collections import OrderedDict
    from dataclasses import dataclass

    from dataclasses_json.undefined import Undefined, CatchAll

    @dataclass
    class DataClass:
        a: str
        b: str
        c: str = 'c'
        d: Optional[CatchAll] = None

    input_dict = {'a': 'a', 'b': 'b', 't': 't'}
    data_class = DataClass(**input_dict)
    assert data_class.a == 'a'
    assert data_class.b == 'b'
    assert data_class.c == 'c'
    assert data_class.d == {'t': 't'}



# Generated at 2022-06-23 16:58:28.929260
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, test: str = "test") -> None:
            self.test = test

        def __eq__(self, other):
            return self.test == other.test

    test_parameters = {"not_a_field": "test1", "test": "test2"}
    actual_parameters = _CatchAllUndefinedParameters.handle_to_dict(
        TestClass, test_parameters)
    assert actual_parameters == {"test": "test2"}



# Generated at 2022-06-23 16:58:39.851454
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class C(object):
        def __init__(self, a: int, b: int):
            pass

    _RaiseUndefinedParameters.handle_from_dict(C, {"a": 1, "b": 2, "c": 3})
    _RaiseUndefinedParameters.handle_from_dict(C, {"c": 3, "a": 1, "b": 2})
    _RaiseUndefinedParameters.handle_from_dict(C, {"a": 1, "b": 2})
    try:
        _RaiseUndefinedParameters.handle_from_dict(C, {"a": 1})
    except UndefinedParameterError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:58:42.937942
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        pass

    expect_exception = tuple("Raised exception")
    try:
        _UndefinedParameterAction.handle_from_dict(
            TestClass, {})
        expect_exception = None
    except TypeError as e:
        assert "abstract method" in str(e)
        pass

    if expect_exception is not None:
        raise expect_exception

# Generated at 2022-06-23 16:58:49.449836
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class CatchAllTest:
        catch_all: CatchAll

    init = _CatchAllUndefinedParameters.create_init(CatchAllTest)
    test_value = CatchAllTest(**{'a': 1, 'b': 2})
    init(test_value, 3, 4)
    assert test_value.catch_all == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:59:01.655006
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # create a dummy class
    class dummy_class:
        def __init__(self, a=1, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            if isinstance(other, dummy_class):
                return self.__dict__ == other.__dict__
            else:
                return False

    # test initialization without undefined parameters
    dummy1 = dummy_class()
    dummy2 = dummy_class(a=1, b=2, c=3)
    dummy3 = dummy_class(a=1, c=3)
    assert dummy1 == dummy2
    assert dummy1 == dummy3


# Generated at 2022-06-23 16:59:02.495315
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    pass

# Generated at 2022-06-23 16:59:12.571457
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    Tests that the init method is correctly modified.

    :return:
    """
    class TestClass:
        def __init__(self, first: str, second: int, third: int,
                     fourth: Optional[str] = None,
                     unknown: Optional[CatchAllVar] = None,
                     ):
            pass

    class TestClass_OverrideInit:
        def __init__(self, first: str, second: int, third: int = 0,
                     fourth: Optional[str] = None,
                     unknown: Optional[CatchAllVar] = None,
                     ):
            pass

    init_method = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init_method.__name__ == "__init__"

# Generated at 2022-06-23 16:59:14.011379
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump({}) == {}

# Generated at 2022-06-23 16:59:21.215628
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    obj = CatchAllClass(a_dict={"foo": 42},
                        b_dict={"bar": 4711},
                        _a_catch_all={"baz": 17})
    assert (_CatchAllUndefinedParameters.handle_dump(obj) ==
            _CatchAllUndefinedParameters._get_catch_all_field(obj).default)



# Generated at 2022-06-23 16:59:33.980661
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        letter_case = Undefined.RAISE
        x: int

    class_fields = fields(TestClass)
    field_names = [field.name for field in class_fields]

    # Everything as expected
    try:
        _UndefinedParameterAction.handle_from_dict(TestClass,
                                                   dict(x=1))
    except Exception:
        assert False

    # Invalid field
    try:
        _UndefinedParameterAction.handle_from_dict(TestClass,
                                                   dict(y=1))
        assert False
    except UndefinedParameterError:
        pass
    except Exception:
        assert False

    # Mixed fields

# Generated at 2022-06-23 16:59:36.729069
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Obj:
        def __init__(self):
            pass

    init_function = _CatchAllUndefinedParameters.create_init(obj=Obj)
    assert init_function.__name__ == "Obj"

# Generated at 2022-06-23 16:59:43.753641
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass(undefined=_RaiseUndefinedParameters)
    class Class:
        defined_param: str
        undefined_param: str

    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=Class,
        kvs={"defined_param": "bar"}) == {"defined_param": "bar"}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(
            cls=Class,
            kvs={"defined_param": "bar", "undefined_param": "foo"})



# Generated at 2022-06-23 16:59:55.049800
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class ExampleClass:
        a: str
        b: str

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class ExampleClass2:
        a: str
        b: str

    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class ExampleClass3:
        a: str
        b: str

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class ExampleClass4:
        a: str
        b: str
        kwargs: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    # Test ignore
    assert "_IgnoreUndefinedParameters" in str(ExampleClass2.undefined)
    assert ExampleClass

# Generated at 2022-06-23 17:00:04.185227
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Temp:
        def __init__(self, a=1, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

    new_init = _IgnoreUndefinedParameters.create_init(Temp)
    t = new_init(Temp, 1, 2, c=3, d=4, e=5)
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3

# Generated at 2022-06-23 17:00:13.444777
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from marshmallow_dataclass import M

    class A:
        def __init__(self, a: str = "a"):
            pass

    class B:
        def __init__(self, a: str = "a", b: str = "b"):
            pass

    class C:
        def __init__(self, a: str = "a", a2: str = "a2"):
            pass

    class D:
        def __init__(self, a: str = "a", b: str = "b", c: str = "c"):
            pass

    class E:
        def __init__(self, a: str = "a", b: str = "b", c: str = "c",
                     catch_all: CatchAll = None):
            pass


# Generated at 2022-06-23 17:00:17.952748
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Foo:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)


    foo = Foo()
    assert _CatchAllUndefinedParameters.handle_dump(foo) == {}

    foo.catch_all['cow'] = "moo"
    assert _CatchAllUndefinedParameters.handle_dump(foo) == {'cow': 'moo'}

# Generated at 2022-06-23 17:00:29.357828
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Class:
        x: int = 0
        _undefined: CatchAll = None
        y: int = 1

    # noinspection PyArgumentList
    kv = {"x": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(Class, kv)
    assert result == {"x": 2, "_undefined": {}}

    # noinspection PyArgumentList
    kv = {"_undefined": {"a": 1}}
    result = _CatchAllUndefinedParameters.handle_from_dict(Class, kv)
    assert result == {"x": 0, "_undefined": {"a": 1}}

    # noinspection PyArgumentList
    kv = {"x": 2, "_undefined": {"a": 1}}
    result = _C

# Generated at 2022-06-23 17:00:41.163695
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def check(cls, kvs: Dict, expected: Dict):
        assert (_CatchAllUndefinedParameters.handle_from_dict(cls,
                                                              kvs) == expected)

    class A:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    class B:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

        def __post_init__(self):
            pass

    class C:
        def __init__(self, a, b, c=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self

# Generated at 2022-06-23 17:00:55.043497
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A:
        def __init__(self, a: int):
            self.a = a

    class B:
        def __init__(self, a: int, b: int = 5):
            self.a = a
            self.b = b

    class C:
        def __init__(self, a: int, *args, **kwargs):
            self.a = a

    def check(cls, kvs: Dict[Any, Any], expected_kvs: Dict[Any,
                                                           Any]):
        assert _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs) \
               == expected_kvs

    # noinspection PyTypeChecker
    check(cls=A, kvs={}, expected_kvs={})
    # no

# Generated at 2022-06-23 17:01:02.750689
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test:
        def __init__(self, a, b, catch=None):
            self.a = a
            self.b = b
            self.catch = catch


    test = Test(1,2,3)
    assert 3 == _CatchAllUndefinedParameters.handle_dump(test)["catch"]
    test = Test(1,2)
    assert {} == _CatchAllUndefinedParameters.handle_dump(test)

# Generated at 2022-06-23 17:01:11.982545
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a=2, b=3, *, c=4, d=5):
            pass

    assert _IgnoreUndefinedParameters.create_init(A)(A(), 1, 2, d=3, e=4) is \
           None

    class A:
        def __init__(self, a=2, b=3, *, c=4, d=5):
            pass

    assert _IgnoreUndefinedParameters.create_init(A)(A(), 1, d=2, e=4) is \
           None

# Generated at 2022-06-23 17:01:13.377449
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-23 17:01:25.985569
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from typing import ClassVar

    from dataclasses import dataclass

    from dataclasses_json import dataclass_json

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class TestClass:
        a: str
        b: str
        c: int
        z: ClassVar[CatchAll] = None

    original_obj = TestClass(a="1", b="2", c=3)
    assert original_obj.z == {}
    tc = TestClass(a="2", b="2", c=3, z={"z1": 11, "z2": 12})
    expected_z = {"z1": 11, "z2": 12}
    assert tc.z == expected_z
    assert _CatchAllUndefinedParameters.handle_dump(tc)

# Generated at 2022-06-23 17:01:37.339828
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        test_parameter: str = dataclasses.field(default=None)
        test_parameter_two: int = dataclasses.field(default=5)
        catch_all: CatchAll = dataclasses.field(default=None)
    tc = TestClass(test_parameter="Hello", test_parameter_two=5)

    assert tc.test_parameter_two == 5
    assert tc.test_parameter == "Hello"
    assert tc.catch_all == {}

# Generated at 2022-06-23 17:01:44.201461
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a, b, c, d, e="e", f="f", g="g"):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(A)
    assert new_init.__signature__ == inspect.signature(A.__init__)

    new_init(A, 1, 2, 3, 4)

# Generated at 2022-06-23 17:01:46.563428
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    result = _UndefinedParameterAction.handle_dump(None)
    assert isinstance(result, dict)

# Generated at 2022-06-23 17:01:49.449778
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction.handle_from_dict(None, None)
    except NotImplementedError:
        assert True



# Generated at 2022-06-23 17:01:50.730740
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("error")
    except UndefinedParameterError as error:
        assert "error" in str(error)
    except:
        assert False



# Generated at 2022-06-23 17:01:59.158345
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import typing


    @dataclasses.dataclass
    class TestClass:
        default: typing.Dict[str, Any] = \
            dataclasses.field(default_factory=dict)


    instance = TestClass()
    assert instance.default == {}


    @dataclasses.dataclass
    class TestClass:
        default: typing.Dict[str, Any] = dataclasses.field(default={})


    instance = TestClass()
    assert instance.default == {}

# Generated at 2022-06-23 17:02:10.728202
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    def noop(self):
        pass


    @dataclasses.dataclass()
    class TestA:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dict())

        def __init__(self):
            pass


    @dataclasses.dataclass()
    class TestB:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __init__(self):
            pass


    @dataclasses.dataclass()
    class TestC:
        catch_all_default: Optional[CatchAllVar] = dataclasses.field(
            default=dict())

# Generated at 2022-06-23 17:02:22.067212
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    schema = Schema(object_pairs_hook=OrderedDict)

    class Test:
        catchall: Optional[CatchAllVar] = field(default=None)

        def __init__(self, **kwargs):
            pass


    instance = Test()
    result = schema.dump(instance)
    assert result == {}

    instance = Test(x=42)
    result = schema.dump(instance)
    assert result == {"x": 42}

    instance = Test(**{"x": 42, "z": 23})
    result = schema.dump(instance)
    assert result == {"x": 42, "z": 23}



# Generated at 2022-06-23 17:02:32.594781
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        def __init__(self, x: int, y: int, z: int, _t: CatchAll=None):
            pass

    test = Test(0, 1, 2)
    init = _UndefinedParameterAction.create_init(test)
    assert init(test, 1, 2, 3, 4)
    assert init(test, 1, 2, 3, 4, 5)
    assert init(test, 1, 2, 3, 4, 5, z=6)
    assert init(test, 1, 2, 3, 4, 5, z=6, _t=7)
    assert not init(test, 1, 2, 3, 4, 5, z=6, _t=7, unknown=8)

# Generated at 2022-06-23 17:02:37.049472
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, **kwargs):
            pass

    test_class = TestClass()
    result = _UndefinedParameterAction.handle_dump(test_class)
    assert {} == result



# Generated at 2022-06-23 17:02:39.503904
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction.handle_from_dict(int, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(0, {}) == {}
    assert _UndefinedParameterAction.handle_dump(0) == {}

# Generated at 2022-06-23 17:02:41.828842
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    result = _UndefinedParameterAction.handle_to_dict(None, {
        "a": 3})
    assert result == {"a": 3}

# Generated at 2022-06-23 17:02:49.847334
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError(
            "Received undefined initialization arguments {'key'}")
    except UndefinedParameterError as e:
        assert str(e) == 'Received undefined initialization arguments {\'key\'}'
        assert e.normalized_messages == ["Received undefined initialization "
                                         "arguments {'key'}"]
        assert isinstance(e.kwargs, dict) and len(e.kwargs) == 0
        assert isinstance(e.fields, dict) and len(e.fields) == 0

# Generated at 2022-06-23 17:02:59.345926
# Unit test for method create_init of class _IgnoreUndefinedParameters

# Generated at 2022-06-23 17:03:10.435757
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        def __init__(self, included, *,
                     undefined=dataclasses.field(
                         default=dataclasses.MISSING, metadata={"unknown": True}),
                     included2=dataclasses.field(
                         default=dataclasses.MISSING, metadata={"known": True})):
            pass

    obj = Test
    old_init = obj.__init__

    new_init = _UndefinedParameterAction.create_init(obj)
    obj.__init__ = new_init

# Generated at 2022-06-23 17:03:16.055362
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    UndefinedParameterAction = _UndefinedParameterAction
    class Foo:
        def __init__(self, f1: int, f2: str, f3: bool):
            pass
    expected = {'f1': 5, 'f2': 'bar'}
    kvs = {'f1': 5, 'f2': 'bar', 'f3': True}
    assert set(UndefinedParameterAction.handle_from_dict(Foo, kvs)) == set(
        expected.items())



# Generated at 2022-06-23 17:03:27.444377
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(init=_IgnoreUndefinedParameters.create_init)
    class A:
        a: int
        b: int
        c: int
        _: CatchAll

        def __init__(self, a: int, b: int, c: int, _: Optional[CatchAll] = None):
            self.a = a
            self.b = b
            self.c = c
            self._ = _ or {}


    assert A.a == 1
    assert A.b == 2
    assert A.c == 3
    assert A._ == {}
    assert A(1, 2, 3, {"e": 3}) == A(1, 2, 3, {"e": 3})

# Generated at 2022-06-23 17:03:38.423582
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Foo:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    f = Foo(bar=14, baz=27, qux="qwerty")

    def get_kvs(f) -> Dict[Any, Any]:
        return {k: getattr(f, k) for k in ["bar", "baz", "qux"]}

    kvs = get_kvs(f)
    assert kvs["bar"] == 14

    ret = _UndefinedParameterAction.handle_to_dict(f, kvs=kvs)
    assert ret == kvs

    ret = _IgnoreUndefinedParameters.handle_to_dict(f, kvs=kvs)
    assert ret == kvs

    ret = _RaiseUndefinedParameters.handle_to_dict

# Generated at 2022-06-23 17:03:39.085007
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-23 17:03:49.571810
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    import marshmallow

    class TestDataClass(object):

        def __init__(self, a: str, b: int, c: bool):
            self.a = a
            self.b = b
            self.c = c

    expected_output = dict(a="hello", b=2, c=False)
    input_dict = dict(a="hello", b=2, d="undefined")

    result = _IgnoreUndefinedParameters.handle_from_dict(
        TestDataClass, input_dict)
    assert marshmallow.validate.Validator.VALIDATORS_BY_TYPE[
               dict](result, allow_none=False) is None
    assert expected_output == result

# Generated at 2022-06-23 17:03:59.063434
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, a: int, b: str, **kwargs):
            self.a = a
            self.b = b
            self.catch_all = kwargs

    action = _UndefinedParameterAction()
    my_object = MyClass(a=1, b="B", c=3, d=4)
    assert action.handle_to_dict(obj=my_object,
                                 kvs={"a": 1, "b": "B", "catch_all": {
                                     "c": 3, "d": 4
                                 }}) == {"a": 1, "b": "B", "c": 3, "d": 4}

# Generated at 2022-06-23 17:04:09.124875
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses_json.config import config

    @dataclasses.dataclass
    class MyClass:
        a: int
        b: str
        undefined: "dataclasses_json.CatchAll" = dataclasses.field(
            default_factory=dict)

        def __init__(self, a: int, b: str, *args, **kwargs):
            self.a, self.b = a, b

    mc_instance = MyClass(1, "a")

    config.undefined = Undefined.INCLUDE
    created_init = _UndefinedParameterAction.create_init(MyClass)
    mc_instance = created_init(mc_instance, undefined={"x": "y"})

    assert mc_instance.undefined == {"x": "y"}
    assert mc_instance.a

# Generated at 2022-06-23 17:04:20.375733
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses_json import Undefined, dataclass_json
    from dataclasses_json.utils import CatchAll

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class Test:
        a: int
        b: str = ""
        catch_all: Optional[CatchAll] = None

        def __init__(self, *args, **kwargs):
            kwargs.update({k: v for k, v in zip(["a", "b"], args)})
            self.a = kwargs.pop("a")
            self.b = kwargs.pop("b")
            self.catch_all = kwargs

    # Try with catch_all field

# Generated at 2022-06-23 17:04:29.247182
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)
        undefined: Undefined = Undefined.INCLUDE

    p = Person("Frank", 42, catch_all={"sex": "male"})
    assert p.name == "Frank"
    assert p.age == 42
    assert p.catch_all == {"sex": "male"}

    assert _CatchAllUndefinedParameters.handle_dump(p) == {"sex": "male"}



# Generated at 2022-06-23 17:04:30.909653
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("test", ["test"])
    assert error.args == ("test", ["test"])

# Generated at 2022-06-23 17:04:39.616786
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Sub(object):
        def __init__(self, x: str, y: int, z: CatchAll = dict()):
            self.x = x
            self.y = y
            self.z = z

    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    class X(object):
        x: str
        y: int
        z: Sub

    # noinspection PyUnresolvedReferences
    sub = Sub("a", 1, dict(x=2, y=3))
    x = X("a", 1, sub)
    known = dict(x=x.x, y=x.y, z=x.z)
    unknown = dict(y=3, x=2, z=2)
    kvs = dict

# Generated at 2022-06-23 17:04:46.522957
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from dataclasses import dataclass
    from typing import List, Dict


    @dataclass
    class C:
        a: int = 0  # type: ignore
        b: str = "hi"  # type: ignore


        def __init__(self, c=None):
            self.c = c


    kvs: Dict = dict(a=1, b="bye", d=4)


    def assert_init(obj):
        obj.__init__(**kvs)
        assert obj.a == 1
        assert obj.b == "bye"


    def assert_no_d(obj):
        assert not hasattr(obj, "d")


    new_cls = _IgnoreUndefinedParameters.create_init(C)
    obj = new_cls()
    assert_init

# Generated at 2022-06-23 17:04:49.255900
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    data = dict(a=1, b=2, c=3)
    kv = dict(a=1, b=2, c=3)
    x = _UndefinedParameterAction.handle_to_dict(data, kv)
    assert x == dict(a=1, b=2, c=3)

# Generated at 2022-06-23 17:04:50.249052
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    _CatchAllUndefinedParameters.create_init(CatchAllUndefinedParametersTest)()



# Generated at 2022-06-23 17:05:02.100712
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class TestClass:
        one: int
        two: int
        catch_all: Optional[CatchAllVar] = None

    # This is a copy of the code in _CatchAllUndefinedParameters.create_init:
    original_init = TestClass.__init__
    init_signature = inspect.signature(original_init)

    @functools.wraps(TestClass.__init__)
    def _catch_all_init(self, *args, **kwargs):
        known_kwargs, unknown_kwargs = \
            _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
                TestClass, kwargs)

# Generated at 2022-06-23 17:05:13.042099
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class TestClass:
        one: int
        two: str

    @dataclasses.dataclasses.dataclass
    class TestClassDefaults:
        one: int = 0
        two: str = ""

    test_class_dict = {"one": 1}
    kwargs = {"one": 1}
    assert _CatchAllUndefinedParameters.handle_dump(TestClass(**kwargs)) == {}
    assert _CatchAllUndefinedParameters.handle_dump(TestClassDefaults(**kwargs)) == {}

    test_class_dict = {"one": 1}
    kwargs = {"one": 1, "two": "two"}

# Generated at 2022-06-23 17:05:19.067877
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameters = {"a": 1}
    obj = CatchAll.__annotations__
    obj["a"] = 1
    rest = {"b": 2}
    out = _UndefinedParameterAction.handle_to_dict(obj, {**undefined_parameters,
                                                     **rest})
    assert undefined_parameters == out

# Generated at 2022-06-23 17:05:24.191767
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("msg")
    assert isinstance(err, Exception)
    assert str(err) == "msg"
    try:
        err = UndefinedParameterError()
        assert str(err) == ""
    except TypeError:
        # existing codebase expects ValidationError to take one parameter
        pass

# Generated at 2022-06-23 17:05:25.170556
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 17:05:26.453556
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:05:35.564864
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    assert _IgnoreUndefinedParameters.handle_from_dict(object, {
                                                           "a": "a",
                                                           "b": "b",
                                                           "c": "c",
                                                           }) == {
               "a": "a",
               "b": "b",
               "c": "c",
           }
    assert _IgnoreUndefinedParameters.handle_from_dict(object, {}) == {}
    assert _IgnoreUndefinedParameters.handle_from_dict(object, {"a": "a"}) == {
               "a": "a"
           }
