

# Generated at 2022-06-23 16:55:32.262220
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    assert not hasattr(_IgnoreUndefinedParameters, 'handle_to_dict')



# Generated at 2022-06-23 16:55:39.048677
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}
    assert _UndefinedParameterAction.handle_dump(obj=1) == {}
    assert _UndefinedParameterAction.handle_dump(obj=1.2) == {}
    assert _UndefinedParameterAction.handle_dump(obj="1.3") == {}
    assert _UndefinedParameterAction.handle_dump(obj=Undefined) == {}
    assert _UndefinedParameterAction.handle_dump(obj=[]) == {}

# Generated at 2022-06-23 16:55:45.622780
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(
                self,
                a,
                b,
        ):
            pass

    TestClass_unmodified = TestClass.__init__
    TestClass_modified = _IgnoreUndefinedParameters.create_init(TestClass)
    tc_unmodified = TestClass(1, 2, 3)
    tc_modified = TestClass(1, 2, 3)

    assert tc_unmodified == tc_modified
    assert TestClass_unmodified.__code__ == TestClass_modified.__code__

# Generated at 2022-06-23 16:55:50.785511
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test:
        def __init__(self,
                     a: float,
                     b: float,
                     undefined: Optional[CatchAllVar] = None) -> None:
            self.a = a
            self.b = b
            self.undefined = undefined

    @dataclasses.dataclass
    class Test2:
        a: float
        b: float
        c: float
        d: float
        undefined: Optional[CatchAllVar] = None

    a = Test(a=1.1, b=2.2, undefined={"c": 3.3, "d": 4.4})
    b = Test2(a=1.1, b=2.2, c=3.3, d=4.4, undefined={"c": 3.3, "d": 4.4})

# Generated at 2022-06-23 16:56:02.878668
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class ClassWithUndefinedArguments:
        def __init__(self, **kwargs):
            pass

    class ClassWithoutUndefinedArguments:
        def __init__(self, known, **kwargs):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(
        ClassWithUndefinedArguments, kwargs={}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(
        ClassWithUndefinedArguments, kwargs={'unknown': 1}) == {}

    assert _RaiseUndefinedParameters.handle_from_dict(
        ClassWithoutUndefinedArguments, kwargs={}) == {'known': None}

# Generated at 2022-06-23 16:56:03.787954
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:56:16.036764
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, name: str, age: int = 30, *,
                     catch_all: CatchAll = None):
            pass

    assert _CatchAllUndefinedParameters.handle_from_dict(Test,
                                                         {"name": "Peter"}) == {
               "name": "Peter", "catch_all": {}}

    assert _CatchAllUndefinedParameters.handle_from_dict(Test,
                                                         {"name": "Peter",
                                                          "age": 20}) == {
               "name": "Peter",
               "age": 20,
               "catch_all": {}}


# Generated at 2022-06-23 16:56:23.557446
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # noinspection Mypy
    @dataclasses.dataclass
    class _TestClass:
        f1: Optional[CatchAllVar] = None

        def __init__(self, f1: Optional[CatchAllVar] = None) -> None:
            self.f1 = f1

    test_class = _TestClass(f1={'test': 'test'})
    print(test_class)
    print(_CatchAllUndefinedParameters.handle_dump(test_class))
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {'test':
        'test'}

# Generated at 2022-06-23 16:56:28.319176
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class SomeClass:
        a: int
        b: int
        c: int

    new_init = _IgnoreUndefinedParameters.create_init(SomeClass)(
        SomeClass(1, 2, 3), 4, 5, a=6)
    assert SomeClass(1, 2, 3).a == 1
    assert SomeClass(1, 2, 3).b == 2
    assert SomeClass(1, 2, 3).c == 3



# Generated at 2022-06-23 16:56:32.766770
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    Test(a=1, c=2)  # should raise UndefinedParameterError.



# Generated at 2022-06-23 16:56:42.000425
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect
    from typing import Optional, TypeVar
    from dataclasses import dataclass

    # noinspection PyProtectedMember
    from dataclasses_json.config import _UndefinedParameterAction as Action

    _T = TypeVar("_T")

    @dataclass
    class MockClass:
        a: int
        b: str
        c: Optional[str] = None

        def __init__(self, a: int = 0, b: str = "", c: str = "0") -> None:
            self.a = a
            self.b = b
            self.c = c

    mock_class = MockClass()
    init_method = Action._IgnoreUndefinedParameters.create_init(mock_class)
    bound_signature = inspect.signature(init_method)

# Generated at 2022-06-23 16:56:49.566034
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def create_cls(**kwargs):
        @dataclasses.dataclass
        class Cls:
            catch_all: Optional[CatchAllVar] = None

            def __post_init__(self):
                if len(self.catch_all) != 0:
                    self.hello = "world"

        return Cls

    cls = create_cls(catch_all=True)
    kvs = {'a': 1, 'b': 2, 'c': 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(cls, kvs)
    assert result == {'catch_all': {'a': 1, 'b': 2, 'c': 3}}


# Generated at 2022-06-23 16:57:00.354040
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[utils.CatchAllVar] = dataclasses.field(default_factory=lambda: {})

    test_dict = {'test': 'test'}
    handled_dict = _CatchAllUndefinedParameters.handle_to_dict(TestClass, test_dict)
    assert handled_dict == {'test': 'test'}
    assert 'catch_all' not in handled_dict

    test_dict = {'test': 'test', 'catch_all': {'test': 'test'}}
    handled_dict = _CatchAllUndefinedParameters.handle_to_dict(TestClass, test_dict)
    assert handled_dict == {'test': 'test', 'test': 'test'}

# Generated at 2022-06-23 16:57:08.502464
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        a: str
        b: str

    kvs = {
        "a": "a",
        "b": "b",
        "c": "c"
    }

    expected_known_parameters = {
        "a": "a",
        "b": "b"
    }
    params = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert params == expected_known_parameters

# Generated at 2022-06-23 16:57:16.811340
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class MyClass:
        def __init__(self, a: int, b: Optional[int]):
            pass

    my_class = MyClass(1, 2)

    known_pars, unknown_pars = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            my_class, {"a": 1, "b": 2, "c": 3})

    assert known_pars == {"a": 1, "b": 2}, \
        "Known parameters should be separated out"
    assert unknown_pars == {"c": 3}, \
        "Unknown parameters should be separated out"


# Generated at 2022-06-23 16:57:18.706852
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # noinspection PyProtectedMember
    assert _UndefinedParameterAction._handle_dump(DataclassesTest.with_ignore) == {}



# Generated at 2022-06-23 16:57:19.945535
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump({}) == {}

# Generated at 2022-06-23 16:57:20.503964
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    pass

# Generated at 2022-06-23 16:57:25.689809
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Dummy:
        a: str
        b: int

        def __init__(self, a: str = "", b: int = 1):
            pass

    dummy = Dummy("a", b=2)
    # No exception should be thrown
    _IgnoreUndefinedParameters.create_init(dummy)(dummy, "a", b=2, c=3)

# Generated at 2022-06-23 16:57:29.924494
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A:
        b: str


    _RaiseUndefinedParameters.handle_from_dict(A, {"b": "c", "c": "d"})

# Generated at 2022-06-23 16:57:39.860486
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    test_class = TestClass()

    assert _UndefinedParameterAction.create_init(test_class) == \
           test_class.__init__
    assert _IgnoreUndefinedParameters.create_init(test_class) != \
           test_class.__init__
    assert _CatchAllUndefinedParameters.create_init(test_class) != \
           test_class.__init__

    TestClass.__init__.__name__ = "__init__"
    assert _UndefinedParameterAction.create_init(test_class).__name__ == \
           "__init__"
    assert _IgnoreUndefinedParameters.create_init(test_class).__name__ == \
           "__init__"
   

# Generated at 2022-06-23 16:57:49.398289
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: str
        b: str
        c: str

    parameters = {
        "a": "a",
        "b": "b",
        "c": "c",
        "d": "d"
    }
    handled_parameters = _RaiseUndefinedParameters.handle_from_dict(
        TestClass, parameters)
    assert handled_parameters == {
        "a": "a",
        "b": "b",
        "c": "c",
    }



# Generated at 2022-06-23 16:57:57.716782
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestDataclass:
        def __init__(self, x=None, y=None, z=None):
            self.x = x
            self.y = y
            self.z = z

    test_dataclass = TestDataclass
    kvs = {
        "x": 1,
        "y": 2,
        "z": 3,
        "z2": 4,
        "z3": 4
    }

    expected = dict(x=1, y=2, z=3)
    actual = _IgnoreUndefinedParameters.handle_from_dict(
        cls=test_dataclass, kvs=kvs)
    assert expected == actual

    expected = dict(x=1, y=2, z=3, z2=4, z3=4)
    actual = _Raise

# Generated at 2022-06-23 16:58:02.025340
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def test_init(self, *args, **kwargs):
        pass

    class _TestClassWithCatchAllUndefinedParameters:

        def __init__(self):
            pass

        undefined_parameters: CatchAll = None

    class _TestClassWithRaiseUndefinedParameters:

        def __init__(self):
            pass

    class _TestClassWithoutUndefinedParameters:

        def __init__(self):
            pass


# Generated at 2022-06-23 16:58:10.325049
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Create a dataclass with undefined init parameters
    @dataclass
    class Test:
        field1: int
        field2: int

        def __init__(self, field1, field2, field3, field4, field5):
            pass

    # Get the original init
    original_init = Test.__init__
    # Create the function that can be used as init for marshmallow
    new_init = _IgnoreUndefinedParameters.create_init(Test)

    # Call the new init with the same parameters as the original init
    t = Test(1, 2, 3, 4, 5)
    # get the field names of the dataclass
    field_names = [f.name for f in fields(t)]

    # It should have only 2 fields, because 3 parameters were undefined
    assert len(field_names) == 2

# Generated at 2022-06-23 16:58:12.282945
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-23 16:58:17.657085
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kws = dict(a=1, b=2, c=3)
    kws_expected = dict(a=1, b=2)

    @dataclasses.dataclass
    class _Test:
        a: int
        b: int

    kws_actual = _IgnoreUndefinedParameters.handle_from_dict(_Test,
                                                             kws)
    assert kws_actual == kws_expected

# Generated at 2022-06-23 16:58:30.026942
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # pylint: disable=unused-argument
    def dummy_init(self, a, b=1, c=2, catch_all: CatchAll = None, *,
                   d=4):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.e = catch_all


# Generated at 2022-06-23 16:58:41.039275
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # Test behavior of handle_to_dict of _CatchAllUndefinedParameters

    class TestClass:
        attr1: int
        attr2: str
        attr3: CatchAll

    test_obj = TestClass(attr1=1)
    all_parameters = {
        "attr1": 1,
        "attr2": "hello",
        "attr3": {"attr2": "hello"}
    }

    expected_attr3_in_output = {"attr2": "hello"}

    all_parameters_but_attr3 = all_parameters.copy()
    del all_parameters_but_attr3["attr3"]

    result_incl_attr3 = _CatchAllUndefinedParameters.handle_to_dict(
        test_obj, all_parameters)
    assert result_incl_attr3

# Generated at 2022-06-23 16:58:46.452676
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b=_CatchAllUndefinedParameters._SentinelNoDefault):
            self.a = a
            self.b = b

    assert Test._CatchAllUndefinedParameters._get_default(fields(Test)[1]) == \
           _CatchAllUndefinedParameters._SentinelNoDefault

    # Set parameter b to the sentinel value,
    # since test instance doesn't have __dict__
    class Test:
        def __init__(self, a, b=_CatchAllUndefinedParameters._SentinelNoDefault):
            self.a = a
            self.b = b

    Test._CatchAllUndefinedParameters.create_init(Test)(Test, 1, 2, 3, 4)
    assert Test.a == 1
    assert Test.b == 3


# Generated at 2022-06-23 16:58:57.177592
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, fields
    from dataclasses_json import config, dataclass_json

    @dataclass(init=True)
    class Parent:
        add_catch_all: bool

        @property
        def init_params(self):
            init_signature = inspect.signature(self.__init__)
            init_params = list(init_signature.parameters.keys())
            return init_params

    def make_dclass(add_catch_all=False) -> type:
        @dataclass(init=True)
        class Derived(Parent):
            a: str
            b: str
            c: str
            d: str
            undefined_parameter: Optional[CatchAllVar] = None


# Generated at 2022-06-23 16:59:02.625727
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=str, kvs=dict(name="test")) == {"name": "test"}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=str, kvs=dict(name="test", age=20)) == {"name": "test"}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=int, kvs=dict(x=20)) == {"x": 20}



# Generated at 2022-06-23 16:59:09.773088
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar

    class WrongClass:
        pass

    class TestClass:
        def __init__(self, arg1: str, arg2: int, arg3: float,
                     catch_all: Optional[CatchAllVar] = None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.catch_all = catch_all if catch_all else {}

    class TestClassWithoutCatchAll:
        def __init__(self, arg1: str, arg2: int, arg3: float):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3


# Generated at 2022-06-23 16:59:23.314118
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int

        def __init__(self, a, b, c, d, e, f):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f

    new_init = _IgnoreUndefinedParameters.create_init(A)
    a = A(1, 2, 3, 4, 5, 6)
    assert a.a == 1
    assert a.c == 3
    assert a.e == 5
    a = A(6, 5, 4, 3, 2, 1, v=2)
    assert a.a == 6


# Generated at 2022-06-23 16:59:34.523380
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Unit test that ensures that method create_init
    for class _IgnoreUndefinedParameters behaves as expected
    """

    DummyClassWithIgnoredUndefinedParameters = dataclasses.make_dataclass(
        "DummyClassWithIgnoredUndefinedParameters",
        [("defined_parameter", int)],
        init=False)

    init = _IgnoreUndefinedParameters.create_init(
        DummyClassWithIgnoredUndefinedParameters)
    assert init.__name__ == "DummyClassWithIgnoredUndefinedParameters.__init__"
    # noinspection PyTypeChecker
    assert init(DummyClassWithIgnoredUndefinedParameters, 1) is not None
    assert init(DummyClassWithIgnoredUndefinedParameters,
                1, "undefined_parameter") is not None

# Generated at 2022-06-23 16:59:41.786126
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        x: int
        y: str
        z: str
        undef: Undefined = Undefined.RAISE

    foo = Foo(1, "a", "b")
    assert _RaiseUndefinedParameters.handle_from_dict(obj=foo, kvs={}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(obj=foo, kvs={"x": 1}) == {
        "x": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(obj=foo, kvs={"x": 1,
                                                                     "y": "a"}) == {
        "x": 1, "y": "a"}

    with pytest.raises(UndefinedParameterError):
        _Raise

# Generated at 2022-06-23 16:59:54.449805
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, param1, param2, param3):
            pass

    kvs = {"param1": "value1", "param2": "value2", "param3": "value3"}
    known_parameters, unknown_parameters = _UndefinedParameterAction \
        ._separate_defined_undefined_kvs(cls=TestClass, kvs=kvs)

    assert len(known_parameters) == 3
    assert len(unknown_parameters) == 0
    assert known_parameters == kvs

    unknown_kvs = {"unknown_param1": "unknown_value1",
                   "unknown_param2": "unknown_value2",
                   "unknown_param3": "unknown_value3",
                   "param1": "value1"}
    known_parameters, unknown_

# Generated at 2022-06-23 17:00:00.200835
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestObject:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: str, c: int):
            pass

    assert _UndefinedParameterAction.create_init(TestObject)(
        TestObject, 1, "2", 3) is None
    assert _UndefinedParameterAction.create_init(TestObject)(
        TestObject, 1, b=2, c=3).a == 1
    assert _UndefinedParameterAction.create_init(TestObject)(
        TestObject, 1, b=2, c=3).b == "2"
    assert _UndefinedParameterAction.create_init(TestObject)(
        TestObject, 1, b=2, c=3).c == 3

# Generated at 2022-06-23 17:00:10.298341
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import field

    class TestClass1:
        foo: int
        bar: str

    class TestClass2:
        foo: int
        bar: str
        catch_all: CatchAllVar = field(default=None)

    class TestClass3:
        foo: int
        bar: str
        catch_all: CatchAllVar = field(default_factory=dict)

    class TestClass4:
        foo: int
        bar: str
        catch_all: CatchAllVar = field(default={})

    class TestClass5:
        foo: int
        bar: str
        catch_all: CatchAllVar = field(default=None)

    class TestClass6:
        foo: int
        bar: str

# Generated at 2022-06-23 17:00:17.889823
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class StoryWithCatchAll:
        name: str
        text: str
        number: float
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, **kwargs):
            catch_all_field = \
                _CatchAllUndefinedParameters._get_catch_all_field(
                    self)
            if catch_all_field.name in kwargs:
                self.catch_all = kwargs.pop(catch_all_field.name)
            dataclasses.dataclass.__init__(self, **kwargs)

        def to_dict(self):
            return _CatchAllUndefinedParameters.handle_to_dict(
                self, dataclasses.asdict(self))

        def dump(self):
            return _

# Generated at 2022-06-23 17:00:21.243330
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 17:00:30.182897
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClass:
        defined: int
        undefined: Optional[CatchAllVar]

        def __init__(self, defined: int, undefined: CatchAll = None):
            super().__init__()
            self.defined = defined
            self.undefined = undefined

    test_cases = [
        (Undefined.INCLUDE,
         {"defined": 1,
          "undefined": {"noparam": "novalue", "included": "included"}}),
        (Undefined.RAISE, {"defined": 1, "undefined": "included"}),
        (Undefined.EXCLUDE, {"defined": 1, "undefined": "included"})
    ]

    for undefined_behavior, kvs in test_cases:
        with_patch = _Undefined

# Generated at 2022-06-23 17:00:41.756195
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Unit test for method create_init of class _UndefinedParameterAction
    """
    import pytest
    from dataclasses_json.typing import LetterCase

    @dataclasses.dataclass
    class Foo:
        i: int = 0
        str_: str = "hallo"

        def __init__(self, i=0, str_="hallo"):
            self.i = i
            self.str_ = str_

        def __repr__(self):
            return f"Foo(i={self.i}, str_='{self.str_}')"

    with pytest.raises(UndefinedParameterError):
        @dataclasses.dataclass
        class _:
            i: int = 0
            str_: str = "hallo"
            foo: Foo = Foo()

# Generated at 2022-06-23 17:00:54.455627
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    from dataclasses_json.undefined import Undefined

    @dataclass
    class Test:
        a: int
        b: str = "default-b"
        unknown: Optional[CatchAllVar] = None

    kvs = {"a": 42, "c": "hello", "d": "world"}

    def test(action: Undefined):
        try:
            result = action.value.handle_from_dict(Test, kvs)
            print(result)
        except UndefinedParameterError as e:
            print(e)

    test(Undefined.RAISE)
    test(Undefined.EXCLUDE)
    test(Undefined.INCLUDE)

# Generated at 2022-06-23 17:01:00.880093
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    assert (_IgnoreUndefinedParameters.create_init(Test)(
        Test, 1, d=3) is None)
    assert _IgnoreUndefinedParameters.create_init(Test)(Test, 1,
                                                        b=2) is None
    assert (_IgnoreUndefinedParameters.create_init(Test)(
        Test, 1, b=2, d=3) is None)

# Generated at 2022-06-23 17:01:10.871756
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Y:
        def __init__(self, a: int, b: dict, c: int):
            self.a = a
            self.b = b
            self.c = c

    def _test_init(init_function, *args, **kwargs):
        y = Y.__new__(Y)
        init_function(y, *args, **kwargs)
        return y

    init_function = _IgnoreUndefinedParameters.create_init(Y)
    assert _test_init(init_function, 0, b={}, c=0) \
           == _test_init(Y.__init__, 0, b={}, c=0)

# Generated at 2022-06-23 17:01:12.202800
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    failure_message = "failing test"
    UndefinedParameterError(failure_message)

# Generated at 2022-06-23 17:01:22.474503
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int

    kvs = {"a": 4}
    _ = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)

    kvs = {"a": 4, "b": 5}
    try:
        _ = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    except UndefinedParameterError:
        pass  # pass test
    else:
        assert False, "Did not raise error when receiving undefined kvs"



# Generated at 2022-06-23 17:01:31.151279
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Foo:
        def __init__(self, a: int, b: str, c: float = 2.5):
            pass

    init = _IgnoreUndefinedParameters.create_init(obj=Foo)
    init(Foo(1, "test"), "override_a", "override_b", d=4, e=5)
    init(Foo(1, "test"), "override_a", "override_b", d=4, e=5, c=3.1)
    init(Foo(1, "test"), "override_a", "override_b", d=4, e=5, c=3.1)

# Generated at 2022-06-23 17:01:39.752529
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    """
    Tests if arguments are correctly separated into defined
    and undefined parameters.
    """
    @dataclasses.dataclass
    class Obj:
        a: int
        b: int
        c: int


# Generated at 2022-06-23 17:01:47.857665
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import dataclasses_json
    from dataclasses_json.utils import CatchAll

    @dataclasses.dataclass
    class JustAClass:
        a: int
        b: str
        c: CatchAll = dataclasses_json.undefined(CatchAll)

    j = JustAClass(a=1, b="two", c={"three": 3})
    d = dataclasses_json.as_dict(j)
    print(d)

# Generated at 2022-06-23 17:01:48.974250
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dump = _UndefinedParameterAction.handle_dump(None)
    assert len(dump) == 0

# Generated at 2022-06-23 17:01:57.154587
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def init_original(self, a: int, b: int, c: int, d: str, e: str,
                      f: str, g: str, h: str, i: str,
                      j: Optional[CatchAllVar] = None):
        pass

    class Type:
        def __init__(self, a: int, b: int, c: int, d: str, e: str,
                     f: str, g: str, h: str, i: str, j: Optional[CatchAllVar] = None):
            pass

    cls = Type
    init_new = _CatchAllUndefinedParameters.create_init(cls)

# Generated at 2022-06-23 17:01:58.469338
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 17:02:05.696452
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str

    test_obj = TestClass(a=1, b="foo")
    kvs1 = {"a": 1, "b": "foo", "c": "bla"}
    kvs2 = {"a": 1, "b": "foo"}

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs1) == kvs2
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs2) == kvs2



# Generated at 2022-06-23 17:02:13.205600
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class C:
        pass  # We don't want to use another class since it would affect other
              # tests.
    c = C()
    c.__init__ = lambda self, a: None
    init = _IgnoreUndefinedParameters.create_init(c)

    class D:
        def __init__(self, a, b, c=None, d=None):
            pass

    d = D(1, 2)
    init = _IgnoreUndefinedParameters.create_init(d)
    init(d, 1, 2, 3, 4)
    init(d, 1, 2)
    init(d, a=1, b=2)
    init(d, 1, 2, c=3)
    init(d, 1, 2, d=3, c=3)

# Generated at 2022-06-23 17:02:21.126619
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, a, b=0):
            self.a = a
            self.b = b

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, {
        'a': 1,
        'b': 2
    }) == {'a': 1, 'b': 2}

    assert _RaiseUndefinedParameters.create_init(TestClass) == TestClass.__init__

# Generated at 2022-06-23 17:02:29.514209
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class ExampleModel:
        lala: int
        catch_all: Optional[CatchAllVar]

        def __init__(self, lala: int, catch_all: Optional[CatchAllVar] = None):
            self.lala = lala
            self.catch_all = catch_all

        def attrs_to_dict(self) -> Dict[str, Any]:
            _cls_fields = fields(type(self))
            return _CatchAllUndefinedParameters.handle_to_dict(self, {
                f.name: getattr(self, f.name)
                for f in _cls_fields
            })


    @dataclass_json(undefined=Undefined.INCLUDE)
    class WithCatchAll:
        lala: int

# Generated at 2022-06-23 17:02:35.073020
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("THE ERROR MESSAGE")
    assert hasattr(err, "message")
    assert type(err.message) == str
    assert err.message == "THE ERROR MESSAGE"

# Generated at 2022-06-23 17:02:41.312731
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int = 5
        b: str = "test"
        catch_all: CatchAll = dataclasses.field(
            default_factory=lambda: None)

    obj = TestClass(a=1, b="2", c=5, d=6)
    expected_result = {'a': 1, 'b': '2', 'catch_all': {'c': 5, 'd': 6}}
    assert _CatchAllUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs={'a': 1, 'b': '2', 'c': 5, 'd': 6}) == \
           expected_result

# Generated at 2022-06-23 17:02:46.459430
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    import dataclasses_json

    @dataclass
    class Model:
        a: str
        b: Optional[CatchAllVar] = dataclasses_json.CatchAll

    dump_result = _CatchAllUndefinedParameters.handle_dump(
        obj=Model)
    assert dump_result == {}

    dump_result = _CatchAllUndefinedParameters.handle_dump(
        obj=Model(a="hello", b={"c": 1}))
    assert dump_result == {"c": 1}

# Generated at 2022-06-23 17:02:58.110202
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class _TestClass:
        height: int
        weight: float = 0.0  # noqa: E800
        description: str = None  # noqa: E800
        names: List[str] = None  # noqa: E800

        def __init__(self, height: int, weight: float = 0.0,
                     description: str = None, names: List[str] = None
                     ) -> None:
            self.height = height
            self.weight = weight
            self.description = description
            self.names = names

    action = _UndefinedParameterAction()
    new_init = action.create_init(_TestClass)

    # noinspection PyUnusedLocal

# Generated at 2022-06-23 17:03:10.066042
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Tests the method handle_to_dict of class _UndefinedParameterAction.
    We don't test the other methods here because they are used by
    dataclasses_json.config, which is tested elsewhere.
    """
    @dataclasses.dataclass(frozen=True)
    class _TestClass:
        catch_all: Optional[CatchAllVar] = None
        test_field: str = "test_value"

    test_object = _TestClass(catch_all={"key": "value"})

    result = _UndefinedParameterAction.handle_to_dict(
        test_object, {"test_field": "test_value", "key": "value"})
    assert result == {"test_field": "test_value"}


# Generated at 2022-06-23 17:03:15.934099
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    undefined_behavior = Undefined.RAISE

    @dataclasses.dataclass
    class Example:
        a: int
        b: str

    example_kwargs = Example(1, "abc").__dict__
    undefined_kwargs = {"a": 2, "b": "def", "c": 3, "d": 4}
    kwargs = {**example_kwargs, **undefined_kwargs}

    assert \
        undefined_behavior.value.handle_from_dict(Example, kwargs) == example_kwargs



# Generated at 2022-06-23 17:03:18.108265
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _UndefinedParameterAction.handle_dump(1) == {}
    assert _UndefinedParameterAction.handle_dump({"a": 1}) == {}

# Generated at 2022-06-23 17:03:22.221334
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert issubclass(_IgnoreUndefinedParameters,
                      _UndefinedParameterAction)
    assert issubclass(_RaiseUndefinedParameters,
                      _UndefinedParameterAction)
    assert issubclass(_CatchAllUndefinedParameters,
                      _UndefinedParameterAction)



# Generated at 2022-06-23 17:03:28.615982
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Given
    class TestClass:
        field_1: str
        field_2: str

    kv_dict = {"field_1": "hallo1", "field_2": "hallo2", "field_3": "hallo3"}

    # When
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kv_dict)
    except UndefinedParameterError as e:
        # Then
        print(e)



# Generated at 2022-06-23 17:03:36.657858
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.config import ConfigBase, FieldsBase

    class MyClass(ConfigBase):
        a: str
        b: int
        c: CatchAll

        class Fields(FieldsBase):
            c: Dict

    my_instance = MyClass("xyz", 23, {"spam": "eggs"})
    my_instance.undefined = Undefined.INCLUDE
    assert my_instance.dump() == {"a": "xyz", "b": 23, "c": {"spam": "eggs"}}

# Generated at 2022-06-23 17:03:43.167243
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestIgnore:
        def __init__(self, a: str, b: str, c: str, d: str):
            pass

    init_without_undefined_parameters = \
        _IgnoreUndefinedParameters.create_init(obj=TestIgnore)

    try:
        init_without_undefined_parameters(None, "a", "b", "c", "d")
    except TypeError:
        assert False, "too many arguments"

    try:
        init_without_undefined_parameters(None, "a", "b", "c")
    except TypeError:
        assert False, "missing argument d"

    init_with_undefined_parameters = \
        _IgnoreUndefinedParameters.create_init(obj=TestIgnore)


# Generated at 2022-06-23 17:03:47.823565
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, *, a, b=None, **kwargs):
            pass

    from dataclasses_json.undefined import Undefined
    _IgnoreUndefinedParameters.create_init(TestClass)()

# Generated at 2022-06-23 17:03:57.755437
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # noinspection PyProtectedMember
    known = {
        "_UNDEFINED1": "undef1",
        "_UNDEFINED2": "undef2",
        "_UNDEFINED3": "undef3",
        "_UNDEFINED4": "undef4",
        "_UNDEFINED5": "undef5",
        "_UNDEFINED6": "undef6",
    }
    unknown = {
        "_UNKNOWN1": "unknown1",
        "_UNKNOWN2": "unknown2",
    }
    kvs = known.copy()
    updated_kvs = _CatchAllUndefinedParameters.handle_to_dict(
        None, kvs)

    assert known == updated_kvs

    kvs.update(unknown)

# Generated at 2022-06-23 17:04:03.788357
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class TestClass(object):

        def __init__(self, param1: str, param2: int, **kwargs):
            self.param1 = param1
            self.param2 = param2

    tc = TestClass("abc", 3, **{"param3": "def"})
    assert tc.param1 == "abc"
    assert tc.param2 == 3



# Generated at 2022-06-23 17:04:04.693308
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("message")

# Generated at 2022-06-23 17:04:13.568254
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import pytest
    import sys

    pytest.importorskip("dill")
    # This test is not in doc test format as it has to import pytest and dill
    # dill allows to pickle functions and other python objects
    # without the same requirements to the import structure as pickle
    # See https://stackoverflow.com/a/53907578/9555988

    from dataclasses_json.config import (
        Undefined, dataclasses_json, ValidationError)

    @dataclasses_json(undefined=Undefined.RAISE)
    @dataclasses.dataclass
    class NoDefault:
        key: str

    @dataclasses_json(undefined=Undefined.RAISE)
    @dataclasses.dataclass
    class WithDefault:
        key: str


# Generated at 2022-06-23 17:04:18.746526
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import dataclasses
    import dataclasses_json

    class Test:
        def __init__(self, x: int, y: str = "hello", z: str = "world"):
            pass

    Test = dataclasses_json.config(
        unknown=dataclasses_json.Undefined.EXCLUDE)(Test)

    Test(3, "world", 4)

# Generated at 2022-06-23 17:04:22.550757
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class _DummyUndefinedParameterAction(_UndefinedParameterAction):
        @staticmethod
        def handle_from_dict(cls, kvs: Dict):
            return kvs

# Generated at 2022-06-23 17:04:26.022338
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {
        "_catch_all": {1: 1},
    }) == {"_catch_all": {1: 1}}



# Generated at 2022-06-23 17:04:36.043421
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: Optional[CatchAllVar]

    test_object = A(a="a", b=1, c=None)
    fields = [
        field
        for name, field in vars(A).items()
        if isinstance(field, dataclasses.Field)
    ]
    known_parameters, unknown_parameters = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(test_object,
                                                                      {
                                                                          "a": "0",
                                                                          "b": "1",
                                                                          "c": "2"
                                                                      })

# Generated at 2022-06-23 17:04:36.704783
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    pass

# Generated at 2022-06-23 17:04:47.421990
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test(metaclass=dataclasses.dataclass):
        a: str
        b: str

    good = Test("a", "b")
    assert _RaiseUndefinedParameters.handle_from_dict(Test, dataclasses.asdict(good)) == {"a": "a", "b": "b"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, {"c": "c"})
    # unknown_given_parameters is ignored
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, {"a": "a", "c": "c"})



# Generated at 2022-06-23 17:04:53.571717
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
        Tests the method _CatchAllUndefinedParameters._handle_from_dict
        of the class UndefinedParameterAction
    """
    from dataclasses import dataclass
    import pytest

    @dataclass
    class _DUMMY:
        a: str
        b: Optional[CatchAllVar] = dataclasses.field(default=None)

    dummy = _DUMMY("hallo")
    assert dummy.b is None

    _CatchAllUndefinedParameters.handle_from_dict(
        _DUMMY, {"a": "a"})

    with pytest.raises(UndefinedParameterError) as error_info:
        _CatchAllUndefinedParameters.handle_from_dict(_DUMMY, {"a": "a", "b": {
            "c": "d"}})  #

# Generated at 2022-06-23 17:04:56.500075
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("message")
    except UndefinedParameterError as e:
        assert e.message == "message"

# Generated at 2022-06-23 17:05:05.698465
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Person:
        pass

    obj = Person()
    assert _CatchAllUndefinedParameters.handle_to_dict(obj,
                                                       {"age": 5,
                                                        "first_name": "Franz"}
                                                       ) == {"age": 5,
                                                             "first_name":
                                                                 "Franz"}

    @dataclasses.dataclass
    class Person2:
        first_name: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field":
                                        {"load_only": True, "dump_only": True}
                                    }
        )

    obj = Person2("Franz", catch_all={"age": 5})

    assert _CatchAllUndefinedParameters.handle_to

# Generated at 2022-06-23 17:05:15.653585
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    def assert_handle_from_dict_equal_to(cls, input_dict, expected_result):
        class NewClass(cls):
            pass

        actual_result = \
            _IgnoreUndefinedParameters.handle_from_dict(NewClass, input_dict)
        assert actual_result == expected_result

    # Test 1
    class defined_class:
        def __init__(self, a, b, c=3, d=4):
            pass

    input_dict = {
        "a": 1,
        "b": 2,
        "d": 4,
    }

    expected_result = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }


# Generated at 2022-06-23 17:05:25.183440
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # No undefined parameters
    defined_parameters = {"a": 1, "b": 2}
    returned_parameters = _RaiseUndefinedParameters.handle_from_dict(
        CatchAll, defined_parameters)
    assert returned_parameters == defined_parameters
    # Undefined parameters
    defined_parameters.update({"c": 3})
    try:
        _RaiseUndefinedParameters.handle_from_dict(CatchAll, defined_parameters)
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'c': 3}"



# Generated at 2022-06-23 17:05:31.710005
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(object, {}) == {}
    try:
        _RaiseUndefinedParameters.handle_from_dict(object, {"a": 1})
    except UndefinedParameterError as e:
        assert e.messages == ["Received undefined initialization arguments "
                              "{'a': 1}"]
    else:
        assert False, "Did not raise"