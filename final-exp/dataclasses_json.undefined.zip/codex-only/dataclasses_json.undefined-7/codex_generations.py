

# Generated at 2022-06-23 16:55:38.217756
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Dummy():
        a: int
        b: str

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            pass

    init_method = _UndefinedParameterAction.create_init(Dummy)

    def dummy_init(self, a: int, b: str):
        self.a = a
        self.b = b

    # Test that _UndefinedParameterAction.create_init works correctly
    assert init_method(Dummy(a=1, b="b")) == dummy_init(Dummy(a=1, b="b"))

# Generated at 2022-06-23 16:55:47.427271
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    assert _IgnoreUndefinedParameters.handle_from_dict(None, {}) == {}
    assert _IgnoreUndefinedParameters.handle_from_dict(None,
                                                       {'a': 'a'}) == {'a': 'a'}
    assert _IgnoreUndefinedParameters.handle_from_dict(None,
                                                       {'a': 'a'}) == {'a': 'a'}
    assert _IgnoreUndefinedParameters.handle_from_dict(None,
                                                       {'b': 'b'}) == {'b': 'b'}



# Generated at 2022-06-23 16:55:52.376948
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # noinspection PyProtectedMember
    cls = dataclasses.dataclass(_IgnoreUndefinedParameters.create_init(_CatchAllUndefinedParameters))
    ignore_init = cls.__init__
    signature = inspect.signature(ignore_init)

    # This should throw an error because the catch-all variable has not been
    #  excluded.
    a = dataclasses.dataclass(cls=cls, init=False, repr=False)()

    # noinspection PyUnusedLocal
    @dataclasses.dataclass(
        init=False, repr=False)
    class DummyClass:
        a: str
        b: str
        c: Optional[CatchAllVar]

        def __init__(self, a, b, c):
            pass

    _IgnoreUndefinedParameters

# Generated at 2022-06-23 16:56:03.457208
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    @dataclasses.dataclass
    class TestClass2:
        a: int
        b: int
        c: Optional[CatchAll] = None

    def check_handle_from_dict(cls):
        cls_name = cls.__name__

        # Simple init: no extra parameters
        expected = {"a": 1, "b": 2, "c": {}}
        params = {"a": 1, "b": 2}
        received = _CatchAllUndefinedParameters.handle_from_dict(cls, params)

# Generated at 2022-06-23 16:56:15.710246
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow as ms

    class TestClass:
        def __init__(self, x: int, y: int, z: int = 10):
            self.x = x
            self.y = y
            self.z = z

    class TestSchema(ms.Schema):
        class Meta:
            unknown = Undefined.EXCLUDE

        x = ms.fields.Int()
        y = ms.fields.Int()
        z = ms.fields.Int()

    original_init = TestClass.__init__
    init_signature = inspect.signature(original_init)
    ignore_init = _IgnoreUndefinedParameters.create_init(TestClass)

    assert ignore_init is not original_init
    assert ignore_init is not TestClass.__init__

# Generated at 2022-06-23 16:56:19.750960
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class MyTestClass:
        def __init__(self, **kwargs):
            pass

    kws = {"a": 1, "b": 2}
    result = _RaiseUndefinedParameters.handle_from_dict(MyTestClass, kws)
    assert result == kws



# Generated at 2022-06-23 16:56:25.798703
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A(object):
        x: int
        y: int
        z: int

    assert _UndefinedParameterAction.handle_from_dict(A, {'x': 1, 'y': 2}) == {'x': 1, 'y': 2}
    try:
        _UndefinedParameterAction.handle_from_dict(A, {'x': 1, 'y': 2, 'z': 3, 'w': 4})
        assert False
    except UndefinedParameterError as e:
        assert True



# Generated at 2022-06-23 16:56:32.767774
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Dummy:
        def __init__(self, a):
            self.a = a

    dummy = Dummy(a='a')

    init = _UndefinedParameterAction.create_init(dummy)
    dummy = init(dummy, b='b', c='c')
    assert dummy.a == 'a'

# Generated at 2022-06-23 16:56:37.575923
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from marshmallow import Schema, fields
    import dataclasses
    import numpy as np

    @dataclasses.dataclass
    class Test:
        x: int
        y: float = 1.0
        catch_all: CatchAll = dataclasses.field(default=None)

        @classmethod
        def _get_schema(cls) -> Schema:
            return Schema.from_dataclass(cls)

    schema = Test._get_schema()
    the_test = Test()
    the_test_json = {"x": 1, "y": 2.0, "w": "test"}
    the_test_json_copy = the_test_json.copy()
    schema.load(the_test_json, unknown=Undefined.INCLUDE)
    assert the_test_json

# Generated at 2022-06-23 16:56:45.935417
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import Undefined, config

    @dataclass
    @config(undefined=Undefined.INCLUDE)
    class Foo:
        i: int
        catch_all: Optional[CatchAllVar] = None

    foo = Foo(2, {"a": 1})
    assert _CatchAllUndefinedParameters.handle_to_dict(foo,
                                                       {"i": foo.i,
                                                        "catch_all": foo.catch_all}) == {"i": 2, "a": 1}

# Generated at 2022-06-23 16:56:47.301245
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    import pytest
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 16:56:59.051223
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DummyClass:
        x: int
        y: str = 'hello'

    assert _RaiseUndefinedParameters.handle_from_dict(DummyClass,
                                                      {'x': 3}) == {'x': 3}
    assert _RaiseUndefinedParameters.handle_from_dict(DummyClass,
                                                      {'x': 1,
                                                       'y': 'hi'}) == {
                                                          'x': 1, 'y': 'hi'}
    try:
        _RaiseUndefinedParameters.handle_from_dict(DummyClass,
                                                   {'x': 1, 'y': 'hi',
                                                    'z': 4})
        assert False
    except UndefinedParameterError:
        pass


# Generated at 2022-06-23 16:57:12.335448
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():

    class TestClass:
        def __init__(self, a: int, b: str, c: float = 3.14,
                     d: int = 42,
                     def_factory: int = CatchAll):
            pass


    class _TestUndefinedParameterAction(_UndefinedParameterAction):
        @staticmethod
        def handle_from_dict(cls, kvs: Dict[Any, Any]) -> Dict[str, Any]:
            known, unknown = \
                _UndefinedParameterAction._separate_defined_undefined_kvs(
                    cls=cls, kvs=kvs)
            return known, unknown

        @staticmethod
        def create_init(obj) -> Callable:
            return super().create_init(obj)



# Generated at 2022-06-23 16:57:14.910306
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class DummyClass(object):
        x: int
        y: int
        z: int

    obj = \
        DummyClass(x=1, y=2, z=3, k="value")



# Generated at 2022-06-23 16:57:16.074171
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters


# Generated at 2022-06-23 16:57:22.995107
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        one: int
        two: str
        three: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field":
                                        dataclasses_json.ABCMetaField(
                                            load_from="three")})

    kvs = {"one": "one", "two": 2}
    received = _RaiseUndefinedParameters.handle_from_dict(MyClass, kvs)
    expected = {"one": "one", "two": 2}
    assert expected == received



# Generated at 2022-06-23 16:57:27.793779
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass, field

    @dataclass
    class Example:
        a: str = "default_a"
        catch_all: Optional[CatchAllVar] = field(
            default_factory=dict)

    ex = Example(a="abc", catch_all={"b": "abc"})
    assert _CatchAllUndefinedParameters.handle_dump(ex) == {"b": "abc"}

# Generated at 2022-06-23 16:57:29.695913
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}



# Generated at 2022-06-23 16:57:38.549486
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Dummy:
        def __init__(self, a: int):
            self.a = a

    dataclass = dataclasses.make_dataclass(
        "Dummy",
        [
            ("a", int)
        ],
        namespace={
            "_UndefinedParameterAction": _RaiseUndefinedParameters
        }
    )

    assert dataclass(a=1).a == 1

    with pytest.raises(UndefinedParameterError) as error_info:
        dataclass(a=1, b=2)

    assert str(error_info.value).startswith(
        "Received undefined initialization arguments")


# Generated at 2022-06-23 16:57:50.810327
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    from dataclasses_json.undefined import Undefined, _CatchAllUndefinedParameters
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class SimpleClass:
        name: str
        age: int

        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class SimpleClass2:
        name: str
        age: int
        inactive: bool

        def __init__(self, name: str, age: int, inactive: bool = False):
            self.name = name
            self.age = age
            self.inactive = inactive

# Generated at 2022-06-23 16:58:03.832667
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class TestClass1:
        required: str
        optional: int

    try:
        tst = TestClass1(required="required1")
        assert False, "Should have raised an error"
    except TypeError:
        pass

    @dataclass
    class TestClass2:
        required: str
        optional: int = 0

    tst = TestClass2(required="required2")

    @dataclass
    class TestClass3:
        required: str
        optional: int = dataclasses.field(default_factory=int)

    tst = TestClass3(required="required3")

    @dataclass
    class TestClass4:
        required: str
        optional: Optional[int] = dataclasses.field(default=None)



# Generated at 2022-06-23 16:58:09.728310
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestDataClass:
        a: int
        b: int

    parameter_handler = _RaiseUndefinedParameters()

    assert parameter_handler.handle_from_dict(TestDataClass, {"a": 42}) == {
        "a": 42}
    assert parameter_handler.handle_to_dict(TestDataClass,
                                            {"a": 42, "b": 43}) == {
        "a": 42, "b": 43}
    assert parameter_handler.handle_dump(TestDataClass) == {}



# Generated at 2022-06-23 16:58:13.155746
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = _UndefinedParameterAction()
    assert obj.handle_to_dict(obj, {"a": 1, "b": 2}) == {"a": 1, "b": 2}



# Generated at 2022-06-23 16:58:16.892453
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    try:
        _RaiseUndefinedParameters.handle_from_dict(list, dict(a=1))
        assert False
    except UndefinedParameterError:
        pass
    assert _RaiseUndefinedParameters.handle_from_dict(list, dict()) == dict()

# Generated at 2022-06-23 16:58:24.775631
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    def _test_func(a, b, c=3, d=4):
        pass

    TEST_KVS = {"a": 1, "b": 2, "d": 4}

    result = _IgnoreUndefinedParameters.handle_from_dict(cls=_test_func,
                                                         kvs=TEST_KVS)
    assert result == {"a": 1, "b": 2, "d": 4}


# Generated at 2022-06-23 16:58:28.660610
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def handle_dump(obj):
        return _UndefinedParameterAction.handle_dump(obj)

    assert handle_dump(_RaiseUndefinedParameters) == {}
    assert handle_dump(_IgnoreUndefinedParameters) == {}
    assert handle_dump(_CatchAllUndefinedParameters) is None

# Generated at 2022-06-23 16:58:40.455855
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # Arrange
    undefined_input_prefix = "_UNKNOWN"
    k1 = "name"
    k2 = "address"
    v1 = "John"
    v2 = "123 Street"
    k3 = "_UNKNOWN1"
    k4 = "_UNKNOWN2"
    v3 = "unknown1"

    parameters_received_by_init = {k1: v1, k2: v2, k3: v3}

    class Test:
        def __init__(self, name: str, address: str, catch_all: CatchAll = None):
            self.name = name
            self.address = address
            self.catch_all = catch_all if catch_all is not None else {}

# Generated at 2022-06-23 16:58:51.433859
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestCatchAll:
        def __init__(self, a: int, b: int, c: CatchAll):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b and self.c == other.c

    class TestDefaultCatchAll:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b and self.c == other.c

    # Test whether it returns a dictionary containing the given parameters

# Generated at 2022-06-23 16:58:55.943285
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    obj = TestClass(a=1)
    print(obj)

# Generated at 2022-06-23 16:59:02.784176
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int = 1
        c: str
        d: str = "d"

    a_init = _IgnoreUndefinedParameters.create_init(A)
    a = a_init(A, "bla", "blub", a=3, b="blub", c=4)
    assert a.a == 3
    assert a.b == "blub"
    assert a.c == "bla"
    assert a.d == "d"
test__IgnoreUndefinedParameters_create_init()

# Generated at 2022-06-23 16:59:09.901289
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: CatchAll

        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    test_class = TestClass(a=1, b=2)

    # This should not produce any undefined parameters
    test_class = TestClass(a=1, b=2, c={'d': 3})

    # This should produce 1 undefined parameter
    c_undefined_parameters = {'d': 3}
    test_class = TestClass(a=1, b=2, **c_undefined_parameters)
    assert test_class.c == c

# Generated at 2022-06-23 16:59:23.378159
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Assert that _IgnoreUndefinedParameters only inserts the defined parameters
    into the call to the actual __init__.
    """

    class Test:
        def __init__(self, a: int, b: Optional[str] = None):
            self.a = a
            self.b = b

    init_with_ignored = _IgnoreUndefinedParameters.create_init(Test)
    test = Test(1, b="b")
    init_with_ignored(test, 3, b="bb", c="c")
    assert test.a == 3
    assert test.b == "b"

    # Check that the original __init__ works
    test = Test(1, b="b")
    Test.__init__(test, 3, b="bb", c="c")
    assert test.a == 3


# Generated at 2022-06-23 16:59:28.318761
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Foo:
        def __init__(self, a: int, b: int, c: int,
                     **kwargs: Optional[CatchAllVar]):
            pass

    func = _CatchAllUndefinedParameters.create_init(Foo)

    # Test only CatchAll
    func(Foo, 1, 2, 3, a=5, b=6, c=7)
    # Test CatchAll and another kwarg
    func(Foo, 1, 2, 3, d=5, a=5, b=6, c=7)
    # Test CatchAll and another positional arg
    func(Foo, 1, 2, 3, 5, a=5, b=6, c=7)

# Generated at 2022-06-23 16:59:37.702079
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class DummyClass:
        myarg: int
        my2ndarg: str
        my3rdarg: bool
        my4tharg: str = dataclasses.field(default="ABC")
        my5tharg: CatchAll = None

        def __init__(self, **kwargs):
            pass

    dummy_instance = DummyClass()

    num_fields_takeable = len(dataclasses.fields(dummy_instance)) - 1
    for i in range(num_fields_takeable + 1):
        kwargs_given = {field.name: "ABC" for field in
                        dataclasses.fields(dummy_instance)[:i]}
        init = _CatchAllUndefinedParameters.create_init(obj=dummy_instance)

# Generated at 2022-06-23 16:59:44.752863
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    This test makes sure that _CatchAllUndefinedParameters.handle_to_dict does
    what it is supposed to do.
    """

    class SomeClass:
        def __init__(self, a: int, b: int, c: int = 0, d: int = 0,
                     **catch_all: Optional[CatchAll]):
            pass

    some_instance = SomeClass(a=1, b=2, c=3, my_field=4)
    some_dict = {"a": 1, "b": 2, "c": 3, "my_field": 4}

    # Test 1
    out = _CatchAllUndefinedParameters.handle_to_dict(cls=SomeClass,
                                                      kvs=some_dict)

# Generated at 2022-06-23 16:59:54.588625
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Foo:
        _undefined: CatchAll
        _other: str
        _undefined_parameters: Undefined = Undefined.INCLUDE

        def __init__(self, _other: str, _undefined: CatchAll = {}):
            self._other = _other
            self._undefined = _undefined

    obj = Foo(other="other")
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}
    obj = Foo(other="other", _undefined={"captured": "parameter"})
    assert _CatchAllUndefinedParameters.handle_dump(obj) \
           == {"captured": "parameter"}

# Generated at 2022-06-23 16:59:58.531770
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a, b, c, d, e):
            pass

    _IgnoreUndefinedParameters.create_init(A)

# Generated at 2022-06-23 17:00:08.672914
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        a: int
        b: int
        c: int = dataclasses.field(default=3)

    obj = Foo(4, 5)
    assert obj.a == 4
    assert obj.b == 5
    assert obj.c == 3

    @dataclasses.dataclass
    class Foo:
        a: int
        b: int
        c: int = dataclasses.field(default=3)

        def __init__(self, a: int, b: int, c: int = 3) -> None:
            _IgnoreUndefinedParameters.create_init(self)(a, b, c)

    obj = Foo(4, 5, 6)
    assert obj.a == 4
    assert obj.b == 5
    assert obj.c == 6



# Generated at 2022-06-23 17:00:10.738698
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-23 17:00:13.012722
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass:
        def __init__(self, a=None):
            pass
    some_dict = {"a": "A", "b": "B"}
    TestClass(**some_dict)  # Should not raise

# Generated at 2022-06-23 17:00:19.974334
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class ValidExample:
        field0: str
        field1: int

    @dataclasses.dataclass
    class InvalidExample:
        field0: str
        field1: int
        field2: float

    example_unchanged = ValidExample("string", 42)
    example_changed = InvalidExample("string", 42, 42.1)

    result0: Dict = _RaiseUndefinedParameters.handle_from_dict(
        ValidExample,
        dataclasses.asdict(example_unchanged))
    result1: Dict = _RaiseUndefinedParameters.handle_from_dict(
        ValidExample,
        dataclasses.asdict(example_changed))

# Generated at 2022-06-23 17:00:26.361511
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # test that unknown parameters are correctly written to catch-all
    @dataclasses.dataclass
    class MyClass:
        field1: str
        field2: Optional[CatchAllVar]

    params = {"field1": "value1", "unknown1": "value2", "unknown2": "value3"}
    known_params, _ = _CatchAllUndefinedParameters.handle_from_dict(MyClass,
                                                                     params)
    assert known_params == {'field1': 'value1', 'field2': {'unknown1': 'value2',
                                                           'unknown2': 'value3'}}

    # test that the default is preserved when no unknown params are received
    @dataclasses.dataclass
    class MyClass:
        field1: str
        field2: Optional[CatchAllVar]

# Generated at 2022-06-23 17:00:38.392196
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def create_cls(default: Any = None,
                   default_factory: Any = None) -> Any:
        @dataclasses.dataclass(frozen=True, eq=True)
        class Test:
            a: int
            b: str
            c: Optional[CatchAllVar] = default_factory
            d: CatchAllVar = default

        return Test

    Test = create_cls()
    assert _CatchAllUndefinedParameters.handle_from_dict(Test,
                                                         {"a": 0, "b": "",
                                                          "c": {}, "d": {}}) == \
           {"a": 0, "b": "", "c": {}, "d": {}}

    Test = create_cls(default={})
    assert _CatchAllUndefinedParameters.handle_from

# Generated at 2022-06-23 17:00:43.003334
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    test_obj = _CatchAllUndefinedParameters()
    input_dict = {"a": 1, "a2": 1, "__catchAll": {"b": 2}}
    res = test_obj.handle_to_dict(obj = test_obj, kvs=input_dict)
    assert res == {"a": 1, "a2": 1}
    return True

# Generated at 2022-06-23 17:00:55.823103
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from marshmallow import Schema
    from typing import Dict

    class _UndefinedParametersSchema(Schema):
        class Meta:
            unknown = Undefined.RAISE  # or Undefined.IGNORE

    @dataclasses.dataclass
    class CatchAllTest:
        """
        This test class is used by the unit test test__CatchAllUndefinedParameters
        """
        catch_all: Optional[CatchAllVar]

    _UndefinedParametersSchema().load(CatchAllTest(catch_all={}))
    _UndefinedParametersSchema().load(CatchAllTest(catch_all=None))

    @dataclasses.dataclass
    class NoCatchAllTest:
        """
        This test class is used by the unit test test__CatchAllUndefinedParameters
        """

    _UndefinedParametersSche

# Generated at 2022-06-23 17:01:05.562023
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass(abc.ABC):

        def __init__(self, arg1: int, arg2: int, arg3: int):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    # Expected input
    known_given_parameters = {"arg1": 1, "arg2": 2, "arg3": 3}
    kvs = {"arg1": 1, "arg2": 2, "arg3": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=kvs) == known_given_parameters

    # Unexpected input
    kvs = {"arg1": 1, "arg2": 2, "arg3": 3, "arg4": 4}
    assert _IgnoreUndefinedParameters.handle

# Generated at 2022-06-23 17:01:13.378218
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.core import LetterCase

    @dataclass(letter_case=LetterCase.CAMEL)
    class TestClass:
        field_a: int
        field_b: str
        other_field: str = "other field"

    expected_params_a = {"fieldA": 1, "fieldB": "str 1", "otherField": "str 1"}
    expected_params_b = {"fieldA": 2, "fieldB": "str 2", "otherField": "str 2"}
    expected_params_c = {"fieldA": 3, "fieldB": "str 3", "otherField": "str 3"}

    given_params_a = {"fieldA": 1, "fieldB": "str 1", "fieldC": "str 1"}
    given_params_b

# Generated at 2022-06-23 17:01:20.618903
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # get_obj_that_doesnt_implement_selfmethod_handle_dump_is_called
    # TODO: Make this test a real unit-test
    def handle_dump(obj) -> Dict[Any, Any]:
        return {}

    _UndefinedParameterAction.handle_dump = handle_dump
    assert _UndefinedParameterAction.handle_dump(1) == {}

# Generated at 2022-06-23 17:01:26.779895
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.api import verify_api
    verify_api(
        cls=_IgnoreUndefinedParameters,
        static_method_name="handle_from_dict",
        expected_parameters=[
            inspect.Parameter("cls", Parameter.POSITIONAL_ONLY),
            inspect.Parameter("kvs", inspect.Parameter.POSITIONAL_ONLY)
        ],
        returns=Dict[str, Any]
    )



# Generated at 2022-06-23 17:01:28.482076
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert isinstance(_UndefinedParameterAction.handle_dump(None), dict)
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:01:38.409258
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import pytest
    from typing import Union


    @dataclasses.dataclass
    class A:
        catch_all: Union[CatchAllVar, dict] = dataclasses.field(
            default_factory=dict)


    class B:
        def __init__(self, *args, **kwargs):
            pass


    @dataclasses.dataclass
    class C:
        catch_all: Union[CatchAllVar, dict] = dataclasses.field(
            default_factory=dict)

        def __init__(self, *args, **kwargs):
            pass


    for cls in (A, B, C):
        with pytest.raises(UndefinedParameterError):
            _CatchAllUndefinedParameters.create_init(cls)()

# Generated at 2022-06-23 17:01:46.457081
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self,
                     a: str,
                     d: str,
                     b: str = "default_b",
                     c: str = "default_c"):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, 2, c="a", e="asd")
    init(TestClass, 1, 2, c="a", b="f", d=3, e="asd")

# Generated at 2022-06-23 17:01:55.582747
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses import dataclass

    @dataclass
    class Test(_UndefinedParameterAction):
        def __init__(self, x: int = 0, y: float = 0, z: str = "") -> None:
            self.x = x
            self.y = y
            self.z = z

    instance = Test(x=1, y=2, z="three")
    kvs = {"x": instance.x, "y": instance.y, "z": instance.z}
    new_kvs = _UndefinedParameterAction.handle_to_dict(instance, kvs)
    assert "x" in new_kvs
    assert "y" in new_kvs
    assert "z" in new_kvs
    assert "x" in kvs
    assert "y" in kvs

# Generated at 2022-06-23 17:02:03.840872
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        field1: str
        field2: str
        field3: str

    example_dict = {"field1": "hello", "field2": "world", "field3": "!"}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, example_dict)\
        == example_dict
    example_dict = {"field1": "hello", "field2": "world", "field4": "!"}
    try:
        _UndefinedParameterAction.handle_from_dict(TestClass, example_dict)
        raise AssertionError("Expected UndefinedParameterError")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 17:02:12.139444
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    catch_all_field = Field(name="_catch_all", type=CatchAllVar, default=None,
                            default_factory=lambda: None)

    @dataclasses.dataclass
    class A:
        foo: str
        _catch_all: CatchAllVar = dataclasses.field(default=None,
                                                    compare=False)

        def __post_init__(self):
            pass

    @dataclasses.dataclass
    class B:
        foo: str
        bar: int
        _catch_all: CatchAllVar = dataclasses.field(default=None,
                                                    compare=False)

        def __post_init__(self):
            pass

    @dataclasses.dataclass
    class C:
        _catch_all: CatchAllVar = dataclasses

# Generated at 2022-06-23 17:02:13.003362
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    dummy_cls = _UndefinedParameterAction()

# Generated at 2022-06-23 17:02:24.984081
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClassWithCatchAll:
        parameter: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={'dataclasses_json': {
                'mm_field': CatchAll}})
        def __post_init__(self):
            if isinstance(self.catch_all, dict):
                self.catch_all.pop('_UNKNOWN2', None)

    @dataclasses.dataclass
    class TestClassWithDuplicateCatchAll:
        parameter: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={'dataclasses_json': {
                'mm_field': CatchAll}})

# Generated at 2022-06-23 17:02:28.506810
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test that the error message is passed to the exception.
    """
    msg = "This is a test error message"
    err = UndefinedParameterError(msg)
    assert err.messages == msg

# Generated at 2022-06-23 17:02:33.620026
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class CatchAllTest:
        a: str
        b: int
        c: Optional[CatchAllVar] = None

    obj = CatchAllTest(
        a="a", b=3, c={"c": "d"})
    result = _CatchAllUndefinedParameters.handle_dump(obj)
    expected = {"c": {"c": "d"}}
    assert result == expected

# Generated at 2022-06-23 17:02:44.295613
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Foo:
        def __init__(self, a, b, c: int = 1, d: int = 1, **unknown):
            for k, v in unknown.items():
                setattr(self, k, v)
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    f1 = Foo(1, 2, d=3, e=4, f=5)
    assert f1.a == 1
    assert f1.b == 2
    assert f1.c == 1
    assert f1.d == 3
    assert f1.e == 4
    assert f1.f == 5

    # Test class initialization

# Generated at 2022-06-23 17:02:47.115806
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Tests that the abstract class _UndefinedParameterAction
    has no constructor.
    """
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 17:02:55.213824
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from dataclasses import dataclass


    @dataclass
    class TestWithTwoFields:
        field1: str
        field2: str

        def __init__(
            self,
            field1: str,
            field2: str,
            field3: str,
        ):
            pass

    a = TestWithTwoFields(field1="Not ignored", field2="Not ignored",
                          field3="Ignored")

# Generated at 2022-06-23 17:02:58.753109
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class FakeClass:
        def __init__(self, a: str, b: str, c: str):
            pass

    fake_cls = FakeClass("a", "b", "c")
    init = _CatchAllUndefinedParameters.create_init(fake_cls)

    assert init.__name__ == "_catch_all_init"
    assert inspect.getsource(init).strip() == inspect.getsource(
        _CatchAllUndefinedParameters.create_init).strip()

# Generated at 2022-06-23 17:03:10.165343
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Cat:
        name: str
        age: int
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

    cat_init = _CatchAllUndefinedParameters.create_init(Cat)
    assert cat_init(Cat, "Tobi", 3)
    assert cat_init(Cat, "Olivia", 3, color="black")
    assert cat_init(Cat, "Marry", 3, color="black", weight=22)
    assert cat_init(Cat, "Tobi", 3)
    assert cat_init(Cat, "Olivia", age=3, color="black")
    assert cat_init(Cat, "Marry", age=3, color="black", weight=22)

# Generated at 2022-06-23 17:03:18.823077
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a, b, c, d=1, e=2):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    parameters = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4}
    obj = Test(**parameters)
    assert obj.a == 0
    assert obj.b == 1
    assert obj.c == 2
    assert obj.d == 3
    assert obj.e == 4

    new_init = _IgnoreUndefinedParameters.create_init(Test)
    parameters["f"] = 5
    obj = new_init(None, **parameters)
    assert obj.a == 0
    assert obj.b == 1


# Generated at 2022-06-23 17:03:25.985601
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json.utils import Undefined

    @dataclass
    class TestUndefined:
        a: int = 1
        b: str = "b"
        c: Undefined = Undefined.Raise

    error_raised = False
    try:
        TestUndefined(a=1, b="b", c=1, d="d")
    except UndefinedParameterError:
        error_raised = True
    assert error_raised



# Generated at 2022-06-23 17:03:27.030991
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Some error message")

# Generated at 2022-06-23 17:03:38.058260
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, foo: int, bar: int = 0,
                     **unknown_parameters: CatchAll):
            pass

    assert _IgnoreUndefinedParameters.handle_from_dict(
        Test, {"foo": 1, "bar": 3, "baz": 10}) == {"foo": 1, "bar": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        Test, {"foo": 1, "bar": 3}) == {"foo": 1, "bar": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        Test, {"foo": 1}) == {"foo": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        Test, {"foo": 1, "baz": 7}) == {"foo": 1}



# Generated at 2022-06-23 17:03:43.872073
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def init_no_args(self):
        self.x = 0
        self.y = ""
        self.z = None

    def init_all_args(self, x, y, z=None):
        self.x = x
        self.y = y
        self.z = z

    test_classes = [(init_no_args, "init_no_args"), (init_all_args, "init_all_args")]

    for init, name in test_classes:
        @dataclasses.dataclass()
        class Test:
            x: int = 1
            y: str = "test"
            z: int = 2
            a: CatchAll = None

            def __init__(self, a: CatchAll = None, **kwargs):
                init(self, **kwargs)
                self.a

# Generated at 2022-06-23 17:03:51.490028
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestDataClass:
        a1: str
    tdc = TestDataClass("Hello")
    known_dict = {"a1": tdc.a1}
    known_dict2 = {"a1": tdc.a1}
    known_dict.update({"a2": "World"})
    assert _UndefinedParameterAction.handle_to_dict(tdc, known_dict) == known_dict2
    assert _UndefinedParameterAction.handle_to_dict(tdc, {}) == {}


# Generated at 2022-06-23 17:03:56.574529
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        field_1: int
        field_2: int
        catch_all: CatchAll

    assert _CatchAllUndefinedParameters.create_init(Test)(
        Test(), 1, 2, 3, 4) == Test(1, 2, {"_UNKNOWN0": 3, "_UNKNOWN1": 4})



# Generated at 2022-06-23 17:04:00.595794
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Foo:
        x: int
        y: Optional[int]
        z: int = 1

    kvs = {"x": 2, "y": 1, "z": 1}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        Foo, kvs)
    assert known == {"x": 2, "y": 1, "z": 1}
    assert unknown == {}

# Generated at 2022-06-23 17:04:06.971191
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class CatchAllWithDumpTest:
        undefined_field: CatchAllVar
        a: Optional[int]

    obj = CatchAllWithDumpTest(undefined_field={}, a=5)
    kvs = dict()
    kvs.update(obj.__dict__)
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs["undefined_field"] == {"a": 5}

# Generated at 2022-06-23 17:04:12.346462
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from ..core import dataclass_json

    @dataclass_json(undefined=Undefined.IGNORE)
    class TestClass:
        a: str
        b: str
        c: str = "default"

    # We can give too many arguments
    tc = TestClass("a", "b", "c", "d", "e")
    assert tc.a == "a"
    assert tc.b == "b"
    assert tc.c == "default"

# Generated at 2022-06-23 17:04:17.989872
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import inspect
    import pytest
    from marshmallow import Schema, fields, validate

    # This class is a unit test for the function _IgnoreUndefinedParameters.
    # It is not intended to be used outside of this unit test.
    @dataclasses.dataclass(init=False, repr=False)
    class SampleClass:
        a: int
        b: str
        c: int = 5
        _undefined: Undefined = Undefined.EXCLUDE

        def __init__(self, *args, **kwargs) -> None:
            self.a = kwargs["a"]
            self.b = kwargs["b"]
            self.c = kwargs["c"]
            instance_init = \
                _IgnoreUndefinedParameters.create_init(self)

# Generated at 2022-06-23 17:04:18.491920
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    pass



# Generated at 2022-06-23 17:04:26.789785
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class _test_class(object):
        pass

    method = _IgnoreUndefinedParameters.handle_to_dict

    kvs = {"a": 1, "b": 2}
    ans = {"a": 1, "b": 2}
    assert method(_test_class(), kvs) == ans

    kvs = {"a": 1, "b": 2, "c": 3}
    ans = {"a": 1, "b": 2}
    assert method(_test_class(), kvs) == ans


# Generated at 2022-06-23 17:04:36.594104
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int = dataclasses.field(default=1)
        c: str = dataclasses.field(default="hello")
        d: CatchAll = None

        def __init__(self, *, c: str, b: int, d: CatchAll, a: str):
            pass

    test_init = _CatchAllUndefinedParameters.create_init(TestClass)

    test_class = TestClass(a="a", b=2, c="c")
    assert test_class is not None

    test_class_2 = TestClass(a="a", b=2, c="c", d={"hello": 1})
    assert isinstance(test_class_2.d, dict)

# Generated at 2022-06-23 17:04:48.019524
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class cls:
        catch_all = {}
        known_field = ""
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    cls.catch_all = {1:2, 3:4}
    cls.known_field = "known"
    test_subject = type("_UndefinedParameterAction", (_UndefinedParameterAction, ), {"handle_to_dict": _UndefinedParameterAction.handle_to_dict})
    # case 1: key in given dict
    kvs = {'known_field': 'known'}
    expected_kvs = {'known_field': 'known'}
    assert test_subject.handle_to_dict(cls, kvs) == expected_kvs
    # case 2: key not in given dict
    kvs = {}


# Generated at 2022-06-23 17:04:49.936872
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters.handle_from_dict(
        _RaiseUndefinedParameters,
        kvs={}
    )

# Generated at 2022-06-23 17:05:01.797781
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.core import config
    from dataclasses_json.undefined import Undefined

    class A:
        a: int
        b: int
        c: int
        undefined: Optional[CatchAll] = None

        # For testing purposes

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = A(a=0, b=1, c=2)
    obj.undefined = {"d": 3, "e": 4, "f": 5, "b": 6}

# Generated at 2022-06-23 17:05:06.315422
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(_IgnoreUndefinedParameters) == {}
    assert _UndefinedParameterAction.handle_dump(
        _RaiseUndefinedParameters) == {}
    assert _UndefinedParameterAction.handle_dump(
        _CatchAllUndefinedParameters) == {}


# Generated at 2022-06-23 17:05:07.884919
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    isinstance(CatchAllVar('test'), CatchAllVar)

# Generated at 2022-06-23 17:05:09.602954
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump({}) == {}


# Generated at 2022-06-23 17:05:16.938890
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a, b=0, c=0, *, d=0, e=0, **kwargs):
            pass

    def dummy_init(*args, **kwargs):
        pass

    A.__init__ = dummy_init
    a = A(0, 0, 0, 0, d=1, e=1, w=0, x=0, y=0)
    A.__init__ = _IgnoreUndefinedParameters.create_init(A)
    a = A(0, 0, 0, 0, d=1, e=1, w=0, x=0, y=0)
    assert True

# Generated at 2022-06-23 17:05:25.496677
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class MyClass:
        def __init__(self):
            self.field_1: int = 1
            self.catch_all: Dict[str, int] = {'b': 2}

    obj = MyClass()

    assert _UndefinedParameterAction.handle_dump(obj) == {}
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'b': 2}
    assert _RaiseUndefinedParameters.handle_dump(obj) == {}
    assert _IgnoreUndefinedParameters.handle_dump(obj) == {}

# Generated at 2022-06-23 17:05:26.084793
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-23 17:05:36.683462
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyProtectedMember
    num_params_init = len(inspect.signature(dataclasses._DataclassBase.__init__).parameters)

    @dataclasses.dataclass
    class Test1:
        a: int
        b: int = 4
        c: int =6

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    @dataclasses.dataclass
    class Test2(Test1):
        d: int = 4

    @dataclasses.dataclass
    class Test3(Test2):
        e: int = 5

    # Base class:
    new_init = _CatchAllUndefinedParameters.create_init(Test1)
    params = new_init.__code__