

# Generated at 2022-06-23 16:55:34.547440
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class A(_UndefinedParameterAction):
        pass
    a = A()
    assert isinstance(a, _UndefinedParameterAction)

# Generated at 2022-06-23 16:55:46.451539
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import json
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class TestDataClass(object):
        x: int
        y: int
        c: Optional[dataclasses_json.CatchAllVar] = None

    obj = TestDataClass(1, 2, dict(z=3))
    obj_dict = dataclasses_json.as_dict(obj)
    assert obj_dict["x"] == 1
    assert obj_dict["y"] == 2
    assert obj_dict["z"] == 3

    cls = TestDataClass(1, 2)
    obj_dict = dataclasses_json.as_dict(cls)
    assert obj_dict["x"] == 1
   

# Generated at 2022-06-23 16:55:55.047382
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: int
        c: str
        d: str

    class Test(_IgnoreUndefinedParameters.create_init(Test)):
        def __init__(self, a, b, c, d):
            pass

    test_init_signature = inspect.signature(Test.__init__)
    test_init_parameters = list(test_init_signature.parameters.values())
    assert len(test_init_parameters) == 5
    assert test_init_parameters[0].name == "self"
    assert test_init_parameters[1].name == "a"
    assert test_init_parameters[2].name == "b"
    assert test_init_parameters[3].name

# Generated at 2022-06-23 16:56:05.153191
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class A(abc.ABC):
        catch_all: CatchAll
        a: int
        b: int
        c: int

    def create_expected_default(cls):
        class_fields = fields(cls)
        return {f.name: f.default for f in class_fields}  # type: ignore

    def get_expected_default(cls, undefined_parameter_action):
        expected_default = create_expected_default(cls)
        if undefined_parameter_action == Undefined.EXCLUDE:
            expected_default.pop("catch_all")
        elif undefined_parameter_action == Undefined.INCLUDE:
            expected_default["catch_all"] = {}
        return expected_default


# Generated at 2022-06-23 16:56:17.032833
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():  # type: ignore
    from dataclasses import dataclass, field
    from dataclasses_json import config
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class TestDataClass(DataClassJsonMixin):
        defined_parameter: str
        catch_all: CatchAll = field(default=None, metadata=config(unknown=True))

    default_initialization = TestDataClass.from_dict({
        "defined_parameter": "test"})
    assert default_initialization.defined_parameter == "test"
    assert default_initialization.catch_all is None

    initialization_with_undefined_parameter = TestDataClass.from_dict({
        "defined_parameter": "test",
        "undefined_parameter": "other"})
    assert initialization_with_

# Generated at 2022-06-23 16:56:22.490321
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    kwargs = {"bla": 3, "blub": 4}
    kwargs_ = kwargs.copy()
    t = TestClass(**kwargs)
    assert _UndefinedParameterAction.handle_to_dict(t, kwargs) == kwargs_



# Generated at 2022-06-23 16:56:29.371263
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class TestClass:
        i: int
        ignore: str = None

    x = TestClass(i=2, foo='bar')

    params = _IgnoreUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs=vars(x))
    assert params == {'i': 2}

    params = _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                        kvs=vars(x))
    assert params == {'i': 2}
    try:
        params = _IgnoreUndefinedParameters.handle_from_dict(cls=TestClass,
                                                             kvs={'foo': 2})

    except UndefinedParameterError:
        assert True



# Generated at 2022-06-23 16:56:33.249290
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("my message")
    except UndefinedParameterError as e:
        assert str(e) == "my message"
        assert e.messages == ["my message"]

# Generated at 2022-06-23 16:56:42.847402
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a: int, catchall: CatchAll = None):
            self.a = a
            self.catchall: CatchAll = catchall

    try:
        _CatchAllUndefinedParameters.handle_from_dict(Test, {'a': 1})
    except UndefinedParameterError:
        assert False

    try:
        _CatchAllUndefinedParameters.handle_from_dict(Test, {'a': 1, 'b': 2})
    except UndefinedParameterError:
        assert False

    t = Test(1)

    try:
        _CatchAllUndefinedParameters.handle_from_dict(Test, {'a': 1, 'b': 2})
    except UndefinedParameterError:
        assert False


# Generated at 2022-06-23 16:56:45.286959
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 16:56:57.450137
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class A:
        a: str = "a"
        b: CatchAll = None

        def __init__(self, a: str, b: Dict[str, Any] = None):
            self.a = a
            self.b = b


    a = A("a", {"b": 3, "c": "c"})
    print("Testing _CatchAll")
    assert a.b == {"b": 3, "c": "c"}
    assert a.a == "a"

    @dataclasses.dataclass
    class B:
        a: str = "a"
        b: CatchAll = None

        def __init__(self, a: str, b: Optional[CatchAllVar] = None):
            self.a = a

# Generated at 2022-06-23 16:57:01.299850
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    input_dict = dict(a="A", b="B", c="C")
    output_dict = dict(a="A", b="B", c="C", d="D")

    # When nothing happens
    assert input_dict == _UndefinedParameterAction.handle_to_dict(obj=None, kvs=input_dict)

    # When Catch-All happens
    assert output_dict == _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs=input_dict)

# Generated at 2022-06-23 16:57:14.478721
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class A:
        b: int
        c: float = 1.0
        d: Optional[CatchAllVar] = None

        def __init__(self, b, c=None, **d):
            self.b = b
            self.c = c
            self.d = d

    a = A(1, d={"hi": "there"})
    assert a.d["hi"] == "there"
    assert a.b == 1
    assert a.c == 1.0

    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_dump(a) == a.d

    a = A(1, d={})
    assert a.d == {}
    assert a.b == 1
    assert a.c == 1.0

    #

# Generated at 2022-06-23 16:57:23.999449
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    cls = dataclasses.make_dataclass("TestClass",
                                     [("a", str), ("b", int)])
    valid_parameters = {"a": "a", "b": 2}
    valid_parameters_2 = {"a": "a", "b": 2, "random": "random"}
    invalid_parameters = {"a": "a", "c": "d"}
    assert (valid_parameters ==
            _RaiseUndefinedParameters.handle_from_dict(cls, valid_parameters))
    assert (valid_parameters ==
            _RaiseUndefinedParameters.handle_from_dict(cls, valid_parameters_2))

# Generated at 2022-06-23 16:57:36.481123
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class NonDataClass:
        def __init__(self, catch_all=None):  # type: ignore
            self.catch_all: CatchAll = catch_all

    class DataClass(metaclass=StrictDataClassJSON):
        catch_all: CatchAll = CatchAll.EXCLUDE  # type: ignore
        foo: str = "bar"

    obj = NonDataClass(catch_all={})
    kvs = {"foo": "bar", "catch_all": {}}
    kvs_out = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert "catch_all" not in kvs_out
    assert kvs_out != kvs

    obj = DataClass(catch_all={})
    kvs = {"foo": "bar", "catch_all": {}}
   

# Generated at 2022-06-23 16:57:38.964196
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test:
        def __init__(self, _ignore_me: str = "foobar",
                     **kwargs) -> None:
            pass

    x = Test(a=1, b=2)
    result = _UndefinedParameterAction.handle_to_dict(x, dict(a=1, b=2))
    assert not isinstance(result, Test)
    assert result['a'] == 1
    assert result['b'] == 2



# Generated at 2022-06-23 16:57:51.429704
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _DummyClass:
        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    # not used here
    # obj = _DummyClass(a=1, b="b", c={"d": 1, "e": 2})

    kvs = {"a": 1, "b": "b", "c": {"d": 1, "e": 2}}
    returned_kvs = _CatchAllUndefinedParameters.handle_to_dict(_DummyClass,
                                                               kvs)
    assert "a" in returned_kvs
    assert "b" in returned_kvs
    assert "c" not in returned_kvs
    assert "d" in returned_k

# Generated at 2022-06-23 16:57:59.303235
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test the method handle_to_dict of the class _UndefinedParameterAction.
    """
    kvs_dict = {"a": 10, "b": 20, "c": 30}
    handler_func = _UndefinedParameterAction.handle_to_dict
    result_dict = handler_func(object, kvs_dict)
    assert result_dict == kvs_dict



# Generated at 2022-06-23 16:58:00.370115
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    action = _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:09.526083
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Test:
        x: int
        y: int
        z: int = 1
        u: CatchAll = None

        def __init__(self, x, y, z=0, u=None):
            self.x = x
            self.y = y
            self.z = z
            self.u = u

    init_with_ignored = _IgnoreUndefinedParameters.create_init(Test)

    t = init_with_ignored(Test, 5, 4, u={"hey": 7})
    assert t.x == 5
    assert t.y == 4
    assert t.z == 1  # default
    assert t.u == {}


# Generated at 2022-06-23 16:58:17.231355
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields
    from marshmallow import Schema
    from dataclasses_json import dataclass_json, config
    import pytest

    @dataclass
    class Subclass:
        id: str


    @dataclass_json(undefined=Undefined.RAISE)
    @dataclass
    class User:
        id: str
        name: str
        role: str

    @dataclass_json(undefined=Undefined.RAISE)
    @dataclass
    class Movie:
        title: str
        year: int
        user: Subclass


# Generated at 2022-06-23 16:58:22.643032
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters
    try:
        _RaiseUndefinedParameters.handle_from_dict(None, None)
        raise Exception("did not raise")
    except NotImplementedError:
        pass


# Generated at 2022-06-23 16:58:30.854331
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses_json

    @dataclasses.dataclass
    class Test:
        x: str
        y: int = 1
        z: int = 2
        w: Optional[CatchAllVar] = None

        def __init__(self, x, y, z=2, *, w=None):
            self.x = x
            self.y = y
            self.z = z
            self.w = w

    # Test that class can be serialized using marshmallow
    dataclasses_json.configure(undefined=Undefined.EXCLUDE)
    test = Test("a", 1)
    assert test.w == {}
    dataclasses_json.configure(undefined=Undefined.INCLUDE)
    test = Test("a", 1)
    assert test.w == {}


# Generated at 2022-06-23 16:58:41.154333
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        pass


    @dataclasses.dataclass
    class TestWithDefault:
        catch_all: Optional[CatchAllVar] = None


    @dataclasses.dataclass
    class TestWithDefaultFactory:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)


    @dataclasses.dataclass
    class TestDefaultAlreadyDefined:
        catch_all: Optional[CatchAllVar] = {}


    @dataclasses.dataclass
    class TestDefaultAlreadyDefinedFactory:
        catch_all: Optional[CatchAllVar] = dataclasses.field(default={})


    @dataclasses.dataclass
    class TestMultiple:
        catch_all

# Generated at 2022-06-23 16:58:46.538331
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: int
        b: int

    assert (_UndefinedParameterAction.handle_from_dict(A, {"a": 1, "b": 1}) ==
            {"a": 1, "b": 1})
    assert (_CatchAllUndefinedParameters.handle_from_dict(A,
                                                          {"a": 1, "b": 1}) ==
            {"a": 1, "b": 1})
    assert (_CatchAllUndefinedParameters.handle_from_dict(A,
                                                          {"a": 1}) ==
            {"a": 1})

# Generated at 2022-06-23 16:58:47.802648
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass

# Generated at 2022-06-23 16:59:01.504785
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class IncludeUndefinedParams:
        undefined: Optional[CatchAllVar] = dataclasses.field(  # type: ignore
            default_factory=dict)

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class ExcludeUndefinedParams:
        undefined: Optional[CatchAllVar] = dataclasses.field(  # type: ignore
            default_factory=dict)

    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class RaiseOnUndefinedParams:
        undefined: Optional[CatchAllVar] = dataclasses.field(  # type: ignore
            default_factory=dict)


# Generated at 2022-06-23 16:59:04.210644
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 16:59:11.745758
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Example:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z


    example_dict = {"x": 3, "y": 4, "z": 5, "w": 6, "a": 7, "b": 8}
    parameters = _RaiseUndefinedParameters.handle_from_dict(
        cls=Example,
        kvs=example_dict)
    assert parameters == {"x": 3, "y": 4, "z": 5}

# Generated at 2022-06-23 16:59:24.003727
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Example:
        _dict: Optional[Dict[Any, Any]]

        def __init__(self, _dict: Optional[Dict[Any, Any]]):
            self._dict = _dict

    def check_function(input_kwargs: Dict[str, Any],
                       expected_output_kwargs: Dict[str, Any],
                       **parameters):
        output = _CatchAllUndefinedParameters.handle_from_dict(
            Example, kvs=input_kwargs, **parameters)
        assert output == expected_output_kwargs

    # Test function without default

    # No input params
    check_function(input_kwargs={}, expected_output_kwargs={"_dict": {}})

    # Input params but no undefined params

# Generated at 2022-06-23 16:59:31.485523
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # use an enum to ensure this method has a single parameter in the init
    class MyClass:
        __init__: Callable
        def __init__(self, foo: str):
            self.foo = foo

    assert _CatchAllUndefinedParameters.create_init(MyClass)(
        MyClass, "bar") is None
    assert MyClass("Bar").foo == "Bar"

# Generated at 2022-06-23 16:59:37.903690
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyUnusedLocal
    class TestClass:
        def __init__(self, x, y, z=3):
            pass

    method = _UndefinedParameterAction.create_init(TestClass)
    assert method is TestClass.__init__



# Generated at 2022-06-23 16:59:45.124339
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Dummy:
        def __init__(self, a, b, c, **kwargs):
            self.a = a
            self.b = b
            self.c = c

    # noinspection PyTypeChecker
    dummy = Dummy(1, 2, 3, **{"d": 4})

    # noinspection PyUnusedLocal
    kvs = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=dummy.__class__, kvs={"a": 1, "b": 2, "c": 3, "d": 4})

# Generated at 2022-06-23 16:59:53.357237
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Poem:
        __metadata__ = {"undefined": Undefined.INCLUDE}
        name: str
        language: str
        catch_all: CatchAll = None

    poem_dict = {
        "name": "Das Wandern",
        "language": "German",
        "_UNKNOWN0": "Die Luft geht frisch und rein,",
        "_UNKNOWN1": "es grünt der Wald"
    }

    try:
        Poem(**poem_dict)
    except UndefinedParameterError as e:
        assert "Received input field with " \
               "same name as catch-all field: " in str(e)
        pass
    else:
        assert False, "Should have raised undefined parameter error"

# Generated at 2022-06-23 17:00:06.364551
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # noinspection PyAbstractClass
    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int) -> None:
            self.a = a
            self.b = b
            self.c = c

    # Defined parameters
    defined_kwargs = {"a": 1, "b": 2, "c": 3}
    # Undefined parameter
    undefined_kwargs = {"d": 4}

    init_method = _IgnoreUndefinedParameters.create_init(Test)
    test_object = Test(**defined_kwargs)
    init_method(test_object, **defined_kwargs, **undefined_kwargs)

    # Test that the undefined keyword argument was ignored

# Generated at 2022-06-23 17:00:18.558374
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, test: str, **kwargs: Any):
            self.test = test
            self.catch_all = kwargs

        @classmethod
        def handle_to_dict(cls, obj, kvs):
            return _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

        @classmethod
        def handle_dump(cls, obj):
            return _CatchAllUndefinedParameters.handle_dump(obj)

        @classmethod
        def handle_from_dict(cls, kvs):
            return _CatchAllUndefinedParameters.handle_from_dict(cls, kvs)

    t = TestClass("This is a test", test=123)
    assert t.test == "This is a test"
    assert t.catch_

# Generated at 2022-06-23 17:00:19.768701
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-23 17:00:29.393300
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, x, y):
            pass

    valid_parameters = {"x": 1, "y": 2}
    more_valid_parameters = {"x": 3, "y": 4, "z": 5}
    less_valid_parameters = {"x": 6}

    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, valid_parameters) == valid_parameters
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, more_valid_parameters) == valid_parameters
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, less_valid_parameters) == less_valid_parameters



# Generated at 2022-06-23 17:00:36.204535
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    It should raise an error when undefined parameters are provided
    """
    class TestClass:
        f1 = int
        f2 = str

    # noinspection PyTypeChecker
    _UndefinedParameterAction.handle_from_dict(cls=TestClass, kvs={
        "f1": 1, "f2": "2", "f3": 3
    })



# Generated at 2022-06-23 17:00:45.140391
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # noinspection PyArgumentList
    class A:
        def __init__(self, a, b=1, c="a", d: str = "hello",
                     e: Optional[str] = None,
                     f: Optional[Callable] = lambda x: None):
            pass


    def init(cls):
        return _IgnoreUndefinedParameters.create_init(
            obj=cls)


    ignored_init = init(A)

    # Test that everything works as expected
    try:
        ignored_init(self=None, a=1, b="string", d=1,
                     e="hello", f=lambda x: x)
    except TypeError as e:
        raise AssertionError("Failed to call __init__ correctly") from e

# Generated at 2022-06-23 17:00:56.296328
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a, b, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    @dataclasses.dataclass
    class B:
        a: int
        b: int
        c: int = 1

    @dataclasses.dataclass
    class C:
        a: int
        b: int
        c: int = dataclasses.field(default_factory=lambda: 1)

    @dataclasses.dataclass
    class D:
        a: Optional[CatchAllVar] = None


# Generated at 2022-06-23 17:01:05.702282
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class SomeClass:
        def __init__(self, a: int, b: int = 4, *, c: CatchAll = None,
                     **undefined_parameters):
            self.a = a
            self.b = b
            self.c = c
            self.undefined_parameters = undefined_parameters

    kvs = {"a": 1, "b": 2, "c": {1: 2, "d": 4, "e": 5}, "d": 3}
    cls = SomeClass

    expected_result = {"a": 1, "b": 2, "c": {1: 2, "d": 4, "e": 5},
                       "undefined_parameters": {"d": 3}}
    parameters = _CatchAllUndefinedParameters.handle_from_dict(cls, kvs)

# Generated at 2022-06-23 17:01:13.490349
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import numpy as np
    from dataclasses_json.undefined import CatchAll

    @dataclasses.dataclass
    class TargetClass:
        p1: int = dataclasses.field(metadata={"unkown": "value"})
        p2: float = 10
        p3: str = "hallo"
        catch_all: CatchAll = CatchAll(dict)

    obj = TargetClass(p1=11, p2=10.1, p3="world", catch_all={
        "p4": np.array([1, 2, 3])
    })


# Generated at 2022-06-23 17:01:16.341698
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    _IgnoreUndefinedParameters._IgnoreUndefinedParameters.handle_from_dict(
        None, kvs={})

# Generated at 2022-06-23 17:01:27.674625
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A(abc.ABC):
        pass


    class B(A):
        @classmethod
        def handle_from_dict(cls, kvs: Dict):
            return kvs


    class C(A):

        def __init__(self, a, b):
            pass


    class D(B):

        def __init__(self, a, b, c):
            pass


    class E(B):

        def __init__(self, a, c, d):
            pass


    class F(B):

        def __init__(self, *args, **kwargs):
            pass


    class G(B):

        def __init__(self, a, b, c=None, d=None):
            pass



# Generated at 2022-06-23 17:01:29.043688
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(obj=None, kvs={}) == {}

# Generated at 2022-06-23 17:01:36.321760
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, **kvs):
            self.kvs = kvs

    obj = MyClass(foo="foo", bar="bar", **{"baz": "baz"})
    results = _UndefinedParameterAction.handle_to_dict(obj,
                                                       obj.kvs)
    expected_results = {'foo': 'foo', 'bar': 'bar'}
    assert results == expected_results, \
        f"Results {results} are not equal to expected results " \
        f"{expected_results}"

# Generated at 2022-06-23 17:01:49.548625
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    # No defaults (no Catch-All)
    known, unknown = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(Test,
                                                                     {
                                                                         "a": 5,
                                                                         "b": 5,
                                                                         "c": {
                                                                             "7": 7
                                                                         },
                                                                         "d": 7
                                                                     })

    expected_k = {
        "a": 5,
        "b": 5,
        "c": {
            "7": 7
        }
    }

# Generated at 2022-06-23 17:01:53.612886
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def handle_from_dict(self, dict_: dict) -> dict:
            pass

        @abc.abstractmethod
        def validate(self, dict_: dict) -> None:
            pass

    tester = Test()
    tester.__class__.handle_from_dict = _UndefinedParameterAction.handle_from_dict
    tester.__class__.validate = _CatchAllUndefinedParameters.handle_from_dict

    tester.validate({'a': 1, 'b': 2, 'c': 3})

    tester.validate({'ignore': "this",
                     'a': 1, 'b': 2, 'c': 3, 'undefined': "parameters"})

# Generated at 2022-06-23 17:01:57.057650
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}
    assert _UndefinedParameterAction.handle_dump(obj=[]) == {}
    assert _UndefinedParameterAction.handle_dump(obj="") == {}



# Generated at 2022-06-23 17:02:06.733550
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, field_1: str, field_2: str, field_3: str):
            self.field_1 = field_1
            self.field_2 = field_2
            self.field_3 = field_3

    method = _IgnoreUndefinedParameters.handle_from_dict

    kvs = {"field_1": "field_1", "field_2": "field_2",
           "field_3": "field_3", "field_4": "field_4"}
    returned = method(cls=TestClass, kvs=kvs)
    assert returned == {"field_1": "field_1", "field_2": "field_2",
                        "field_3": "field_3"}


# Generated at 2022-06-23 17:02:09.405826
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert \
        _RaiseUndefinedParameters.handle_from_dict(
            cls=None, kvs={"a": 1, "b": 2}) == {"a": 1, "b": 2}



# Generated at 2022-06-23 17:02:15.679090
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Foo:
        def __init__(self, a: int, *args, b: int, **kwargs):
            pass

    obj = Foo(1, 2, b=3, d=1)

    @functools.wraps(obj.__init__)
    def _ignore_init(self, *args, **kwargs):
        original_init = obj.__init__
        init_signature = inspect.signature(original_init)
        known_kwargs, _ = \
            _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
                obj, kwargs)

        num_params_takeable = len(
            init_signature.parameters) - 1  # don't count self

# Generated at 2022-06-23 17:02:25.946728
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    import dataclasses

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int

    action = _UndefinedParameterAction()

    def init(self, a, b):
        pass

    TestClass.__init__ = init

    assert action.handle_from_dict(TestClass, {"a": "a", "b": 4}) == {"a": "a",
                                                                      "b": 4}
    assert action.handle_to_dict(TestClass, {"a": "a", "b": 4}) == {"a": "a",
                                                                    "b": 4}
    assert action.handle_dump(TestClass) == {}
    assert action.create_init(TestClass) == init

# Generated at 2022-06-23 17:02:29.868444
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        A, {"a": 1, "b": 2, "c": 3}) == ({"a": 1, "b": 2}, {"c": 3})

# Generated at 2022-06-23 17:02:39.857431
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    try:
        from dataclasses import dataclass

        @dataclass
        class DummyClass:
            field_1: int
            field_2: str
            field_3: Optional[CatchAllVar] = None

        dummy_object = DummyClass(field_1=1, field_2="2")
        dummy_object.field_3 = {"field_3": "3"}
        assert _CatchAllUndefinedParameters.handle_dump(
            obj=dummy_object) == {"field_3": "3"}
    except ImportError:
        pass



# Generated at 2022-06-23 17:02:43.147919
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class ExampleClass:
        defined_parameter: Optional[str]

    action = _UndefinedParameterAction()
    ret = action.handle_from_dict(ExampleClass, {})
    assert ret == {}



# Generated at 2022-06-23 17:02:55.901576
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import unittest


    class _TestClass:
        def __init__(self, a: int, b: int = 1, c: str = "a"):
            pass


    test_object = _TestClass(1)
    old = _TestClass.__init__
    _TestClass.__init__ = _UndefinedParameterAction.create_init(test_object)

    class TestCase(unittest.TestCase):
        def test_default(self):
            with self.assertRaises(TypeError):
                _TestClass()

        def test_missing_kwarg(self):
            with self.assertRaises(TypeError):
                _TestClass(1, c="b")

        def test_unknown_kwarg(self):
            _TestClass(1, 1, "b", x=1)


# Generated at 2022-06-23 17:02:59.181484
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {"x": 1}) == {"x": 1}

# Generated at 2022-06-23 17:03:10.347228
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class MyTest(list):
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

        def get_props(self):
            return self.a, self.b, self.c

    obj = dict(a=1, b=2, c=3, d=4)

    # Test initialization
    obj2 = MyTest(**obj)
    a, b, c = obj2.get_props()
    assert a == 1
    assert b == 2
    assert c == 3
    assert len(obj2) == 0

    # Test creation of object
    init = _IgnoreUndefinedParameters.create_init(MyTest)
    obj2 = init(obj2)
    a, b, c = obj

# Generated at 2022-06-23 17:03:18.943221
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: float
        c: Optional[CatchAll] = dataclasses.field(default_factory=dict)

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = 100

    assert MyClass(1, 2.0, {"a":1}).d == 100
    assert MyClass(a=3, b=3.0, c={"a": 1}).d == 100
    assert MyClass(a=3, b=3.0, c={"a": 1}).c == {"a": 1}

# Generated at 2022-06-23 17:03:20.319550
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    exception = UndefinedParameterError("Message")
    assert exception.messages == "Message"

# Generated at 2022-06-23 17:03:24.820142
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a: int, b: str = "hello"):
            self.a = a
            self.b = b

    Test2 = _IgnoreUndefinedParameters.create_init(Test)

    assert Test2(1, b=2, c=3) == Test(1, b=2)
    assert Test2(1, "hello") == Test(1)
    assert Test2(1, "hello", c=3) == Test(1)
    assert Test2(1, "hello", b=2) == Test(1, b=2)

# Generated at 2022-06-23 17:03:31.682204
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self, a: str, b: int):
            pass
    assert _IgnoreUndefinedParameters.handle_from_dict(C, {"a": "foo"}) == {"a": "foo"}
    assert _IgnoreUndefinedParameters.handle_from_dict(C, {"a": "foo", "c": "bar"}) == {"a": "foo"}



# Generated at 2022-06-23 17:03:40.684230
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        a: str
        b: str
        # noinspection PyTypeChecker
        _catch_all: CatchAll = dataclasses.field(default=dict())

        def __init__(self, a: str = None, b: str = "be", c: str = None,
                     _UNKNOWN0: str = None):
            self.a = a
            self.b = b
            self._catch_all["c"] = c
            self._catch_all["_UNKNOWN0"] = _UNKNOWN0

    class Foo1:
        def __init__(self, a: str = None, b: str = "be", c: str = None,
                     _UNKNOWN0: str = None):
            pass


# Generated at 2022-06-23 17:03:42.955313
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    a = UndefinedParameterError("Error message")
    assert str(a) == "Error message"



# Generated at 2022-06-23 17:03:54.774261
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        catch_all: Optional[CatchAllVar]

    inputs = {
        "catch_all": {"a": 1, "b": 2},
        "a": "a",
        "b": "b"
    }

    assert _CatchAllUndefinedParameters.handle_from_dict(
        Test, inputs) == {
        "catch_all": {"a": 1, "b": 2, "a": "a", "b": "b"}
    }

    inputs = {
        "a": "a",
        "b": "b"
    }

    assert _CatchAllUndefinedParameters.handle_from_dict(
        Test, inputs) == {
        "catch_all": {"a": "a", "b": "b"}
    }

    inputs

# Generated at 2022-06-23 17:04:05.910681
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Foo:
        catch_all_field: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: None)

    foo = Foo()
    assert isinstance(foo.catch_all_field, dict)
    assert len(foo.catch_all_field) == 0

    assert _CatchAllUndefinedParameters.handle_dump(obj=Foo()) == {}

    foo.catch_all_field["test_key"] = "test_value"
    assert _CatchAllUndefinedParameters.handle_dump(obj=foo) == {
        "test_key": "test_value"}

    foo.catch_all_field["test_key2"] = "test_value2"

# Generated at 2022-06-23 17:04:14.243284
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass
    class A:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.MISSING)

    assert _CatchAllUndefinedParameters.handle_from_dict(A, {}) == {}
    assert _CatchAllUndefinedParameters.handle_from_dict(A, {'a': 1, 'b': "2"}) == {'a': 1, 'b': "2"}
    assert _CatchAllUndefinedParameters.handle_from_dict(A, {'a': 1, 'b': "2", 'c': {}}) == {'a': 1, 'b': "2", 'c': {}}

# Generated at 2022-06-23 17:04:18.599912
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}
    assert _RaiseUndefinedParameters.handle_dump(None) == {}

# Generated at 2022-06-23 17:04:19.857255
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("fail")



# Generated at 2022-06-23 17:04:27.892144
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, k :int, v: int):
            self.k = k
            self.v = v

    tc = TestClass(k=1,v=2)
    kvs = {"k" : 1, "v": 2}
    res = _UndefinedParameterAction.handle_to_dict(obj=tc, kvs =kvs)
    assert "k" in res
    assert "v" in res
    assert len(res) == 2



# Generated at 2022-06-23 17:04:33.879820
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def assert_all_equal(a, b):
        assert a == b
        assert len(a) == len(b)
        assert list(a.values()) == list(b.values())
        assert list(a.keys()) == list(b.keys())

    # noinspection PyProtectedMember
    assert_all_equal(
        _UndefinedParameterAction.handle_to_dict(None, {}),
        {})
    # noinspection PyProtectedMember
    assert_all_equal(
        _UndefinedParameterAction.handle_to_dict(None,
                                                 {"field1": 1, "field2": 2}),
        {"field1": 1, "field2": 2})


# Generated at 2022-06-23 17:04:37.218934
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test:
        def __init__(self, x, y=1):
            self.x = x
            self.y = y

    _UndefinedParameterAction.handle_to_dict(Test, {"x": 1, "y": 2})

# Generated at 2022-06-23 17:04:47.462578
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, foo: str, bar: str, **kw):
            pass

    schema = Schema(undefined=Undefined.INCLUDE)
    data_to_serialize = {'foo': 'f', 'bar': 'b', 'param': 'value'}
    serialized_data = schema.dump(TestClass(**data_to_serialize))
    assert serialized_data == data_to_serialize

    data_to_serialize = {'foo': 'f', 'bar': 'b'}
    serialized_data = schema.dump(TestClass(**data_to_serialize))
    assert serialized_data == data_to_serialize

# Generated at 2022-06-23 17:04:50.019076
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}

    assert _UndefinedParameterAction.handle_to_dict(
        None, dict(a="a", b="b")) == dict(a="a", b="b")



# Generated at 2022-06-23 17:04:55.862419
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass(_UndefinedParameterAction):
        pass

    def _init(self, a, b, c: int, d: Optional[str]):
        pass

    TestClass.__init__ = _init
    result = TestClass.create_init(TestClass)
    assert callable(result) is True

# Generated at 2022-06-23 17:04:59.541954
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, x, y):
            pass

    self = Test
    kvs = {"x": 1, "y": 2, "z": 3}

    expected_output = {"x": 1, "y": 2}
    output = _IgnoreUndefinedParameters.handle_from_dict(self, kvs)
    assert output == expected_output



# Generated at 2022-06-23 17:05:07.466353
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class C:
        a: int = field()
        b: int = field(default=4)
        bb: int = field(default=lambda: 4)
        c: str = field()
        d: str
        e: str = field(default="c")

        def __post_init__(self):
            pass

    class CNoDefaults:
        def __init__(self, a: int, b: int, c: str, d: str):
            pass

        def __post_init__(self):
            pass

    class _C_ExtraInit:
        def __init__(self, a: int, b: int, c: str, d: str, extra: str):
            pass


# Generated at 2022-06-23 17:05:08.481542
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 17:05:09.967899
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert len(_UndefinedParameterAction.handle_dump(None)) == 0

# Generated at 2022-06-23 17:05:15.601636
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test(object):
        def __init__(self, a: int, catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.catch_all = catch_all

    out = _CatchAllUndefinedParameters.handle_dump(Test(1))
    assert out == {}

    out = _CatchAllUndefinedParameters.handle_dump(Test(1, {"b": 2}))
    assert out == {"b": 2}



# Generated at 2022-06-23 17:05:26.943452
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # To be precise, this test tests whether the returned dictionary
    # will have the correct keys.
    # Checking the type of the values would be cumbersome and is not
    # necessary for dataclasses-json to work.
    # We also don't need to call handle_from_dict for empty dictionaries,
    # because dataclasses does not care about empty init arguments.
    # As long as the dictionary keys are correct, dataclasses will do the
    # rest.

    TestCase = dataclasses.make_dataclass("TestCase", [
        ("defined_fields", Dict[str, Field]),
        ("expected_fields", Dict[str, str]),
        ("unknown_fields", Dict[str, Any]),
        ("undefined", Undefined)
    ])
    # Known fields are int and float

# Generated at 2022-06-23 17:05:37.008644
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a, b, *args, c=None, d=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

        def __str__(self):
            return f"A(a={self.a}, b={self.b}, c={self.c}, d={self.d})"

    ignore_init = _UndefinedParameterAction.create_init(A)
    assert ignore_init is not A.__init__

    assert ignore_init(A, 1, 2)
    assert ignore_init(A, 1, 2, None, None, e=3)
    assert ignore_init(A, 1, 2, c=3, d=4, e=3)