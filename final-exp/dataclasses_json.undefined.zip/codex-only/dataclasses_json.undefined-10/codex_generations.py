

# Generated at 2022-06-23 16:55:36.816585
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # noinspection PyProtectedMember
    assert _RaiseUndefinedParameters._separate_defined_undefined_kvs({}) == (
        {}, {})
    # noinspection PyProtectedMember
    assert _RaiseUndefinedParameters._separate_defined_undefined_kvs({"a": 1}) == (
        {"a": 1}, {})
    # noinspection PyProtectedMember
    assert _RaiseUndefinedParameters._separate_defined_undefined_kvs(
        {"a": 1, "b": 1}) == ({"a": 1}, {"b": 1})



# Generated at 2022-06-23 16:55:41.114079
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        assert False
    except TypeError as e:
        assert str(e) == "Can't instantiate abstract class \
            _UndefinedParameterAction with abstract methods \
            handle_from_dict"



# Generated at 2022-06-23 16:55:52.560599
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest
    from dataclasses import dataclass
    from typing import Optional
    from dataclasses_json.undefined import CatchAllVar
    from marshmallow import Schema, fields as ma_fields

    @dataclass
    class TestClass:
        foo: int
        bar: str
        bla: Optional[CatchAllVar] = None

    tc = TestClass(foo=1, bar="bar")
    data, _ = Schema().dump(tc)
    assert data == {'foo': 1, 'bar': 'bar'}

    tc = TestClass(foo=1, bar="bar", bla={"hello": "world"})
    data, _ = Schema().dump(tc)
    assert data == {'foo': 1, 'bar': 'bar', "hello": "world"}


# Generated at 2022-06-23 16:56:00.260660
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass
    class Example:
        a: int
        b: int

    ex = Example(a=1, b=2)
    assert ex.a == 1
    assert ex.b == 2

    ex = Example(a=1, b=2, c=3, d=4)
    assert ex.a == 1
    assert ex.b == 2
    assert not hasattr(ex, "c")
    assert not hasattr(ex, "d")

# Generated at 2022-06-23 16:56:01.603671
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("testing")

# Generated at 2022-06-23 16:56:02.277255
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    pass

# Generated at 2022-06-23 16:56:14.339438
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    import typing as t

    @dataclass
    class Simple:
        def __init__(self, **kwargs):
            self._unknown = kwargs

        def to_dict(self):
            return _CatchAllUndefinedParameters.handle_to_dict(self,
                                                               self._unknown)

    s = Simple(a=1, b=2, catchall_a=dict(a=23, b=42))
    assert s.to_dict() == dict(a=1, b=2, catchall_a=dict(a=23, b=42))

    @dataclass
    class Simple2:
        a: int
        b: int
        c: int
        other: t.Optional[CatchAllVar] = None


# Generated at 2022-06-23 16:56:20.875002
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class TestClass:
        field1: str
        field2: str = field(default="default")
        field3: str

        def __init__(self, field1, field2, field3, **undefined_parameters):
            self.field1 = field1
            self.field2 = field2
            self.field3 = field3

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(self=TestClass, field1="a", field2="b", field3="c")



# Generated at 2022-06-23 16:56:28.709539
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # pylint: disable=R0903  # Too few public methods
    # pylint: disable=W0612  # Unused variable
    # pylint: disable=C0111  # Missing docstring
    # pylint: disable=E1101  # Testing method, base class must not be None
    # pylint: disable=R0913  # Too many arguments
    # pylint: disable=C0103  # One-letter-variable names
    class _Test:
        def __init__(self, a, b="b", c="c"):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-23 16:56:39.126880
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Dummy:
        def __init__(self, catch_all: CatchAll=None, **kvs):
            self.catch_all = catch_all
            for k, v in kvs.items():
                setattr(self, k, v)

    d = Dummy(a=1, b=2, c=3, d=4)
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "catch_all": {"e": 5, "f": 6}}
    assert _CatchAllUndefinedParameters.handle_to_dict(d, kvs) == \
           {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}

# Generated at 2022-06-23 16:56:42.672972
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Clazz:
        field1: str
        field2: str
        defaultfield: Optional[CatchAllVar] = None

        def __init__(self, field1: str, field2: str,
                     defaultfield: Optional[CatchAllVar] = None):
            pass

    assert len(fields(Clazz)) == 3
    assert _CatchAllUndefinedParameters._get_catch_all_field(Clazz) == \
           dataclasses.field(default=None, init=True, metadata={}, type=Optional[CatchAllVar])

# Generated at 2022-06-23 16:56:50.101331
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Cls:
        int: int
        float: float
        str: str
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, int: int, float: float, str: str, **kwargs):
            super().__init__()


# Generated at 2022-06-23 16:56:55.432234
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from typing import Optional

    @dataclass
    class CatchAllExample(DataClassJsonMixin):
        param1: str = "value1"
        param2: str = "value2"
        param3: Optional[CatchAllVar] = None  # type: ignore

    @config(undefined=Undefined.INCLUDE)
    @dataclass
    class CatchAllExample2(DataClassJsonMixin):
        param1: str = "value1"
        param2: str = "value2"
        param3: Optional[CatchAllVar] = None  # type: ignore

    example_given_parameters_1 = {"param1": "a", "param2": "b"}
    example

# Generated at 2022-06-23 16:57:03.015358
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a=42, b=54, c=42, d=None):
            pass

        @classmethod
        def from_dict(cls, kvs: Dict[Any, Any]):
            __UNDEFINED = _IgnoreUndefinedParameters
            return __UNDEFINED.handle_from_dict(
                cls, kvs)  # type: ignore

    assert Test.from_dict({"a": 54, "b": None, "c": 42, "d": 12, "e": 54}) == {
               "a": 54, "b": None, "c": 42}
    assert Test.from_dict({"e": 54}) == {}



# Generated at 2022-06-23 16:57:12.853675
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import typing

    def test(a: str, b: int, *args, c: typing.Optional[str] = None,
             **kwargs) -> None:
        print(f"{a} {b} {c} {args} {kwargs}")

    init = _CatchAllUndefinedParameters.create_init(test)

    a = "a"
    b = 2
    c = "c"
    d = "d"
    e = "e"

    init(None, a, b, c, d, e=e)



# Generated at 2022-06-23 16:57:18.853487
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, foo: int, bar: str):
            self.foo = foo
            self.bar = bar
        pass

    assert _IgnoreUndefinedParameters.handle_from_dict(Test,
                                                       {"foo": 1, "bar": "baz",
                                                        "notaparam": None}) == {
                                                           "foo": 1, "bar": "baz"
                                                       }



# Generated at 2022-06-23 16:57:27.576398
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DummyClass:
        name: str
        value: Any
        catch_all: CatchAll = dataclasses.field(
            default=dataclasses.MISSING,
            metadata={'dataclasses_json': {
                'unknown': Undefined.INCLUDE}})

    class_ = DummyClass
    catch_all_field = \
        _CatchAllUndefinedParameters._get_catch_all_field(class_)

    def create_test_case(dict_to_test: Dict[str, Any],
                         expected: Dict[str, Any]):
        received = _CatchAllUndefinedParameters.handle_from_dict(
            class_, dict_to_test)
        assert received == expected

    create_test_case({}, {})
   

# Generated at 2022-06-23 16:57:33.345941
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    TEST_CLASS = 1
    TEST_KVS = 2

    def test_function(cls, kvs):
        return cls, kvs

    def mock_separate_defined_undefined_kvs(cls, kvs):
        return cls, kvs

    _original_separate = _UndefinedParameterAction._separate_defined_undefined_kvs
    _UndefinedParameterAction._separate_defined_undefined_kvs = mock_separate_defined_undefined_kvs

    assert _UndefinedParameterAction.handle_from_dict(test_class=TEST_CLASS,
                                                      kvs=TEST_KVS) == \
           (TEST_CLASS, TEST_KVS)

    _UndefinedParameterAction._separate_defined_undefined_kvs = _original_separate



# Generated at 2022-06-23 16:57:40.133866
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class A:
        a: str
        b: str
        c: str
        d: str
        undefined: Optional[CatchAllVar] = None

    obj = A(a="a", b="b", c="c", d="d", undefined={"e": "e", "f": "f"})
    kvs = {"a": "a", "b": "b", "c": "c", "d": "d", "e": "e", "f": "f"}
    assert kvs == _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

# Generated at 2022-06-23 16:57:52.258744
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Tester:
        def __init__(self, value: int, some_other_value: int = 1,
                     __catch_all__: Optional[CatchAllVar] = None):
            self.value = value
            self.some_other_value = some_other_value
            self.__catch_all__ = __catch_all__


    class Tester2:
        def __init__(self, value: int, some_other_value: int = 1,
                     __catch_all__: Optional[CatchAllVar] = None):
            self.value = value
            self.some_other_value = some_other_value
            self.__catch_all__ = {}  # type: ignore


    assert Tester2(value=1).__catch_all__ == {}

# Generated at 2022-06-23 16:58:05.616692
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        x: str
        y: int
        z: Date = dataclasses.field(default_factory=datetime.datetime.now)
        w: CatchAll = None

        def __init__(self, x, y, z, w=None):
            self.x = x
            self.y = y
            self.z = z
            self.w = w

        def __eq__(self, other):
            return self.x == other.x \
                   and self.y == other.y \
                   and self.z == other.z \
                   and self.w == other.w


# Generated at 2022-06-23 16:58:08.135222
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(MockClass()) == {}

# Generated at 2022-06-23 16:58:09.210791
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    _CatchAllUndefinedParameters.handle_from_dict({}, kvs={})

# Generated at 2022-06-23 16:58:09.861620
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass

# Generated at 2022-06-23 16:58:15.342437
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, x: int, y: str = "test") -> None:
            self.x = x
            self.y = y

    with pytest.raises(UndefinedParameterError) as err:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {"x": 10, "y": 5})
    assert "Received undefined initialization arguments {'y': 5}" in str(
        err.value)



# Generated at 2022-06-23 16:58:25.453230
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import asdict
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass_json(undefined=Undefined.RAISE)
    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass_json(undefined=Undefined.INCLUDE)
    class Test:
        field1: str
        field2: int = 5
        field3: str = dataclasses.field(default_factory=str)

    known_expected = {'field1': 'abc', 'field2': 5, 'field3': ''}

    class_dataclass_json_raise = dataclasses.fields(Test)
    class_dataclass_json_exclude = dataclasses.fields(Test)
    class_dat

# Generated at 2022-06-23 16:58:37.824626
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    Ensure the correct functionality of method
    _CatchAllUndefinedParameters.handle_to_dict()
    """
    class TestClass:
        def __init__(self, field1: str, **kwargs: CatchAll):
            self.field1 = field1
            self.catch_all = kwargs

        def dict(self):
            return {"field1": self.field1, **self.catch_all}

    test_object = TestClass("field1", field2="field2")
    assert test_object.dict() == {'field1': 'field1', 'field2': 'field2'}

    result = _CatchAllUndefinedParameters.handle_to_dict(test_object,
                                                         test_object.dict())

# Generated at 2022-06-23 16:58:50.801778
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a, b, c=3, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    init = _IgnoreUndefinedParameters.create_init(Test)

    assert init(Test(1,2), 3, 4) == Test(1,2, c=3)
    assert init(Test(1,2), 3) == Test(1,2)
    assert init(Test(1,2), 3, 4, 5) == Test(1,2, c=3)

# Generated at 2022-06-23 16:59:02.253440
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    import marshmallow
    import pytest

    @dataclass
    class ObjectWithCatchAll:
        x: int
        y: Optional[CatchAllVar] = None

    @dataclass
    class ObjectWithDefaults:
        x: int
        y: Optional[CatchAllVar] = None

        def __post_init__(self):
            if self.y is None:
                self.y = {}

        @property
        def y(self):
            return self._y

        @y.setter
        def y(self, value):
            if not isinstance(value, dict):
                raise ValidationError(
                    f"Expected type dict for field y, got '{type(value)}'.")
            self._y = value


# Generated at 2022-06-23 16:59:12.481690
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import unittest

    class Test(metaclass=dataclasses.dataclass):
        a: int = 1
        b: int = 2
        x: Optional[CatchAllVar] = None

    class MyTestCase(unittest.TestCase):

        def test_with_undefined_parameters(self):
            kvs = {"a": 1,
                   "b": 2,
                   "x": 3,
                   "y": 4,
                   }
            class_dict = _CatchAllUndefinedParameters.handle_from_dict(
                cls=Test,
                kvs=kvs
            )
            self.assertDictEqual({"a": 1, "b": 2, "x": {"y": 4}}, class_dict)


# Generated at 2022-06-23 16:59:20.701547
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class CatchAllTest:
        foo: Any
        bar: Optional[CatchAllVar]
        baz: Any

    obj = CatchAllTest(foo=1, bar={"baz": 2}, baz=5)
    obj_dump = _CatchAllUndefinedParameters.handle_dump(obj)
    assert obj_dump == {"baz": 2}



# Generated at 2022-06-23 16:59:33.778402
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def constructor(self, a: int, b: int, c: int):
        pass
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 4
        d: Optional[CatchAllVar] = None

        def __init__(self, *, a: int, b: int, c: int, d: Optional[CatchAllVar]):
            ...

    test_object = TestClass(a=1, b=2)
    init_result = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs={"a": 1, "b": 2})

# Generated at 2022-06-23 16:59:41.035394
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass(undefined=_CatchAllUndefinedParameters)
    class _CatchAllTest:
        foo: str
        bar: int = 9
        baz: Optional[CatchAllVar] = None

    @dataclasses.dataclass(undefined=_IgnoreUndefinedParameters)
    class _IgnoreTest:
        foo: str
        bar: int = 9
        baz: Optional[CatchAllVar] = None

    @dataclasses.dataclass(undefined=_RaiseUndefinedParameters)
    class _RaiseTest:
        foo: str
        bar: int = 9
        baz: Optional[CatchAllVar] = None

    # unit test constructor of class _RaiseUndefinedParameters

# Generated at 2022-06-23 16:59:43.279213
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction.__init__ == abc.ABC.__init__
    assert _UndefinedParameterAction().__init__ == abc.ABC.__init__

# Generated at 2022-06-23 16:59:49.195523
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass(frozen=True)
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=None)

    test_class = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

    test_class = TestClass(catch_all={})
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {}

    test_class = TestClass(catch_all={'test': 'test'})
    assert _CatchAllUndefinedParameters.handle_dump(test_class) == {'test': 'test'}

# Generated at 2022-06-23 16:59:57.234965
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import marshmallow

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class TestClass:
        x: str

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class TestClass2:
        x: str

    t = TestClass(x="x")
    assert _CatchAllUndefinedParameters.handle_dump(t) == {}

    t2 = TestClass2(x="x")
    assert _CatchAllUndefinedParameters.handle_dump(t2) == {}

    t2 = TestClass2(x="x")
    setattr(t2, '_UNKNOWN0', 'y')
    assert _CatchAllUndefinedParameters.handle_dump(t2) == {'_UNKNOWN0': 'y'}


# Unit test

# Generated at 2022-06-23 17:00:08.163357
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field

    @dataclass
    class Test:
        a: int
        b: int = 0
        undefined_parameters: Undefined = Undefined.RAISE

    try:
        result = _RaiseUndefinedParameters.handle_from_dict(
            cls=Test, kvs={"a": 0, "c": 1})
        assert False
    except UndefinedParameterError as e:
        assert "c" in str(e)

    try:
        result = _RaiseUndefinedParameters.handle_from_dict(
            cls=Test, kvs={"a": 0, "b": 1, "c": 2})
        assert "c" in str(e)
    except UndefinedParameterError:
        assert False

    result = _RaiseUndefinedParameters.handle_from_

# Generated at 2022-06-23 17:00:16.567820
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class C:
        x: int
        y: int

    kvs = {"x": 1, "y": 2}
    c = _RaiseUndefinedParameters.handle_from_dict(C, kvs)
    assert c == kvs


kvs_undefined = {"x": 1, "y": 2, "z": 3}
decoy_kv = dict()



# Generated at 2022-06-23 17:00:28.932412
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test that the function handle_to_dict correctly removes the catch-all field
    from the output dict.
    """

    @dataclasses.dataclass(
        # frozen=True,
        # eq=True,
        # order=True,
        # unsafe_hash=True,
        init=True,
        repr=True,
        unsafe_hash=False,
    )
    class Dataclass:
        a: int
        b: float
        # noinspection PyTypeChecker
        undefined: CatchAllVar

    inst = Dataclass(a=4, b=5.5)
    input_kvs = {"a": 7, "b": 5.5, "undefined": {"other": "stuff"}}

# Generated at 2022-06-23 17:00:40.970750
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Dummy1(object):
        field1: str
        kwarg1: str

    input = Dummy1.handle_from_dict(Dummy1,
                                    kvs={'field1': 'test', 'kwarg1': 'test'})
    assert input == {'field1': 'test', 'kwarg1': 'test'}

    @dataclasses.dataclass
    class Dummy2(object):
        field2: int
        catchall: Optional[CatchAll]

    input = Dummy2.handle_from_dict(Dummy2, kvs={'field2': 5, 'kwarg2': 'test'})
    assert input == {'field2': 5, 'catchall': {'kwarg2': 'test'}}

    input = Dummy2

# Generated at 2022-06-23 17:00:49.141219
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction.handle_from_dict(int, {}) == {}
    assert _UndefinedParameterAction.handle_from_dict(
        int, {"foo": "bar"}) == {}
    assert _UndefinedParameterAction.handle_from_dict(int, {"f": "bar"}) == {
        "f": "bar"}

# Generated at 2022-06-23 17:00:57.638081
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Tests _IgnoreUndefinedParameters.create_init()
    """
    # noinspection PyMissingOrEmptyDocstring
    class MyClass:
        def __init__(self, a=0, b=1, c=2, d=3, e=4, f=5, g=6, h=7, i=8,
                     j=9, k=10, l=11, m=12, n=13, o=14, p=15, q=16, r=17,
                     s=18, t=19, u=20, v=21, w=22, x=23, y=24, z=25):
            pass

    my_class_init = _IgnoreUndefinedParameters.create_init(MyClass)

# Generated at 2022-06-23 17:01:08.836694
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    assert _CatchAllUndefinedParameters.handle_from_dict(
        _DummyClassWithCatchAll, {"a": 1, "b": 2, "c": 3}) == {
               "a": 1, "b": 2, "c": CatchAll({})}
    assert _CatchAllUndefinedParameters.handle_from_dict(
        _DummyClassWithCatchAll, {"a": CatchAll({}), "b": 2,
                                  "c": 3}) == {"a": CatchAll({}), "b": 2,
                                               "c": CatchAll({})}
    assert _RaiseUndefinedParameters.handle_from_dict(
        _DummyClassWithCatchAll, {"a": 1, "b": 2, "c": 3}) == {"a": 1,
                                                               "b": 2}
   

# Generated at 2022-06-23 17:01:16.361036
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass, asdict
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class MyClass:
        catch_all_field: Optional[CatchAllVar] = None

    my_object = MyClass()
    assert _CatchAllUndefinedParameters.handle_dump(my_object) == {}
    assert asdict(my_object) == {}

    my_object = MyClass(catch_all_field={"a": 1})
    assert _CatchAllUndefinedParameters.handle_dump(my_object) == {"a": 1}
    assert asdict(my_object) == {"a": 1}

# Generated at 2022-06-23 17:01:23.384956
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class X:
        a: int
        b: str
        c: int

    class Y(X):
        def __init__(self, **kwargs):
            self.d = kwargs.pop("d")
            super().__init__(**kwargs)

    _UndefinedParameterAction.handle_from_dict(X, {"a": 5, "d": 12})

# Generated at 2022-06-23 17:01:32.264196
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, x: int, y: int):
            pass

    a = A(1, 2)

    undefined_parameter_action = _RaiseUndefinedParameters.create_init(a)
    try:
        undefined_parameter_action(a, 1, 2, z=3)
    except UndefinedParameterError:
        assert True
    else:
        assert False

    undefined_parameter_action = _CatchAllUndefinedParameters.create_init(a)
    undefined_parameter_action(a, 1, 2, z=3)

    undefined_parameter_action = _IgnoreUndefinedParameters.create_init(a)
    undefined_parameter_action(a, 1, 2, z=3)
    # Here the argument y will not be passed,
    # so it

# Generated at 2022-06-23 17:01:40.437059
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass


    @dataclass
    class ClassWithUndefinedParameter:
        """
        A simple class that allows for
        """
        name: str
        ignore_attribute: str

        def __init__(self, name: str, ignore_attribute: str, **_):
            """
            This dummy constructor is used to check if the generated init
            function has the same signature
            """
            self.name = name
            self.ignore_attribute = ignore_attribute


    class_with_undefined_parameter = ClassWithUndefinedParameter("name",
                                                                 "ignore_attribute",
                                                                 undefined1=1,
                                                                 undefined2=2)
    init_function = _UndefinedParameterAction.create_init(
        ClassWithUndefinedParameter)

# Generated at 2022-06-23 17:01:52.407530
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    field_a = Field("a", Any, default=None)
    field_b = Field("b", Any, default=None)
    field_c = Field("c", Any, default=None)
    class_fields = [field_a, field_b, field_c]

    class MockClass:
        pass

    expected_input = {"a": "my_a", "c": "my_c"}
    expected_result = {"a": "my_a", "c": "my_c", "b": None}
    result = _RaiseUndefinedParameters.handle_from_dict(
        cls=MockClass, kvs=expected_input, fields=class_fields)
    assert result == expected_result


# Generated at 2022-06-23 17:02:00.976927
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class MyTestClass:
        def __init__(self, a: int, b: int = 42):
            self.a = a
            self.b = b

    params = {"a": 23}
    result = _IgnoreUndefinedParameters.handle_from_dict(
        cls=MyTestClass, kvs=params)
    assert result == params
    params = {"a": 23, "b": 23, "c": 42}
    try:
        _IgnoreUndefinedParameters.handle_from_dict(cls=MyTestClass, kvs=params)
    except UndefinedParameterError:
        pass
    else:
        assert False



# Generated at 2022-06-23 17:02:11.138856
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import sys

    @dataclasses.dataclass
    class SomeClass:
        catch_all: CatchAll = dataclasses.field(
            default_factory=dict)


# Generated at 2022-06-23 17:02:23.830879
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import inspect
    import dataclasses
    from dataclasses import dataclass
    from dataclasses_json.undefined import CatchAll
    from dataclasses_json.undefined import _UndefinedParameterAction
    from dataclasses_json.undefined import _CatchAllUndefinedParameters

    @dataclass
    class A:
        a: int
        b: int
        c: Optional[CatchAll] = dataclasses.field(
            default_factory=lambda: {"a": 1, "b": 2, "c": 3})

    assert len(inspect.getfullargspec(A.__init__).args) == 4
    assert {'a': 1, 'b': 2, 'c': 3} == _UndefinedParameterAction.handle_from_dict(cls=A, kvs={})

    assert len

# Generated at 2022-06-23 17:02:31.945627
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field: str


    kvs = {"field": "test_value"}
    assert _RaiseUndefinedParameters.handle_from_dict(
        TestClass, kvs) == kvs

    kvs = {"field": "test_value", "undefined": "test"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False  # Should have thrown an exception
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 17:02:44.017071
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _TestClass:
        def __init__(self, a, b=2, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    test_obj = _TestClass(a=1, c={"a": 3, "d": 4})
    kvs = {"a": 1, "b": 2, "c": {"a": 3, "d": 4}}

    def compare(kvs, expected):
        assert _CatchAllUndefinedParameters.handle_to_dict(
            test_obj, kvs) == expected

    compare(kvs, {"a": 1, "b": 2, "a": 3, "d": 4})
    compare({"c": test_obj.c}, {"a": 3, "d": 4})
    compare

# Generated at 2022-06-23 17:02:55.162977
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.test.test_types import \
        CatchAllTestClass
    from dataclasses_json.utils import CatchAllVar

    c = CatchAllTestClass("AAA", 123, CatchAllVar({"a": "AAA", "b": "BBB"}))
    assert _CatchAllUndefinedParameters.handle_dump(c) == {"a": "AAA", "b": "BBB"}

    c = CatchAllTestClass("BBB", 234, CatchAllVar({"c": "CCC", "d": "DDD"}))
    assert _CatchAllUndefinedParameters.handle_dump(c) == {"c": "CCC", "d": "DDD"}

# Generated at 2022-06-23 17:02:58.729396
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class MyClass:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    obj = MyClass
    f = _IgnoreUndefinedParameters.create_init(obj)
    my_class = f(a=1, b=2, c=3)
    assert my_class.args == ()
    assert my_class.kwargs == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-23 17:03:02.409434
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test that the constructor of class UndefinedParameterError works.
    """
    # noinspection PyTypeChecker
    UndefinedParameterError(message="str")



# Generated at 2022-06-23 17:03:11.389646
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from marshmallow import Schema

    @dataclasses.dataclass
    class MyDataClass:
        test_field: int
        undef: Any = dataclasses_json.Undefined.EXCLUDE
        catch_all: dataclasses_json.CatchAll = dataclasses_json.Undefined.INCLUDE

    data = MyDataClass(test_field=3, undef="undef_value")
    data.catch_all["undef2"] = "undef_value2"
    kvs = dataclasses_json.asdict(data)
    _UndefinedParameterAction.handle_to_dict(data, kvs)
    assert "undef" not in kvs
    assert "undef2" in kvs



# Generated at 2022-06-23 17:03:19.645364
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: str = dataclasses.field()
        b: int = dataclasses.field()

    test_class = TestClass()

    # noinspection PyTypeChecker
    _RaiseUndefinedParameters.handle_from_dict(
        cls=test_class,
        kvs={"a": "a", "b": 1})

    with pytest.raises(UndefinedParameterError):
        # noinspection PyTypeChecker
        _RaiseUndefinedParameters.handle_from_dict(
            cls=test_class,
            kvs={"a": "a", "b": 1, "c": "c"})

    # noinspection PyTypeChecker

# Generated at 2022-06-23 17:03:31.278849
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():

    class TestClass:
        def __init__(self, a, b, c=None, d=4, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    # Make a wrapper around the original init method
    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    test_obj = TestClass(a=1, b=2, b2=3, c=3, e=5, f=6, g=7)
    init_method(test_obj, b2=3, e=5, f=6, g=7)
    assert test_obj.a == 1
    assert test_obj.b == 2
    assert test_obj.c == 3
    assert test_obj.d == 4

# Generated at 2022-06-23 17:03:40.459834
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Example:
        def __init__(self, x: int, y: Optional[CatchAll] = None):
            self.x = x
            self.y = y

    obj = Example(x=1)
    new_dict = _CatchAllUndefinedParameters.handle_to_dict(obj, {"x": 1})
    assert new_dict == {"x": 1}

    obj.y["a"] = 1
    new_dict = _CatchAllUndefinedParameters.handle_to_dict(obj, {"x": 1})
    assert new_dict == {"x": 1, "a": 1}

    obj = Example(x=1, y={"b": 2})
    new_dict = _CatchAllUndefinedParameters.handle_to_dict(obj, {"x": 1})

# Generated at 2022-06-23 17:03:43.142649
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class MyClass:
        def __init__(self, defined_parameter):
            self.defined_parameter = defined_parameter



# Generated at 2022-06-23 17:03:51.330678
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class A:
        def __init__(self, a, b, catch_all=None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    dictionary_to_write = {"a": "a", "b": "b", "c": "c"}
    assert _UndefinedParameterAction.handle_to_dict(A(**dictionary_to_write),
                                                    dictionary_to_write) == \
           dictionary_to_write

test__UndefinedParameterAction_handle_to_dict()



# Generated at 2022-06-23 17:04:01.674397
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import collections

    @dataclasses.dataclass
    class _TestClass:
        a: str
        b: collections.Counter = dataclasses.field(default_factory=dict)
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    test_obj = _TestClass("A", {"B": 1, "C": 2})
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {}

    test_obj = _TestClass("A", {"B": 1, "C": 2}, catch_all={"D": 3})
    assert _CatchAllUndefinedParameters.handle_dump(test_obj) == {"D": 3}


# Generated at 2022-06-23 17:04:03.448499
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("An error")
    assert error.messages == ["An error"]

# Generated at 2022-06-23 17:04:09.425016
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses_json

    class Parent:
        data: Optional[CatchAll] = None

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    class Child(Parent):
        name: str

    assert Child(name="Peter", data={"age": 12}, extra="data").data == {"age": 12}
    assert Child(name="Peter").data == {}
    assert Child(name="Peter", extra="data").data == {}

# Generated at 2022-06-23 17:04:16.120828
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class _CatchAll:
        def __init__(self, **kwargs):
            self.also_catch_all_field: CatchAll = kwargs.pop("also_catch_all_field",{})
            self.catch_all_field: CatchAll = kwargs.pop("catch_all_field", {})
            self.other_field: int = kwargs.pop("other_field", 0)

    x = _CatchAll(catch_all_field={"a": 1}, also_catch_all_field={"b": 2})
    assert len(x.catch_all_field) == 1
    assert len(x.also_catch_all_field) == 1
    assert len(x.other_field) == 0
    assert x.other_field == 0


# Generated at 2022-06-23 17:04:23.976010
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    class B:
        def __init__(self, a: int, *args, **kwargs):
            self.a = a

    class C:
        def __init__(self, a: int, *args, **kwargs):
            self.a = a
            self.b = kwargs.pop("b")

    class D:
        def __init__(self, a: int, *, b: int, c: int = 1):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-23 17:04:34.469017
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class _Foo:
        def __init__(self, arg1: str, arg2: str, arg3: str) -> None:
            pass

    catch_all_init = _CatchAllUndefinedParameters.create_init(_Foo)
    catch_all_init(_Foo, "arg1", "arg2", "arg3", "extra_arg")
    # Must not raise
    undefined_init = _UndefinedParameterAction.create_init(_Foo)
    undefined_init(_Foo, "arg1", "arg2", "arg3", "extra_arg")
    # Must raise
    undefined_error = False

# Generated at 2022-06-23 17:04:46.084044
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses_json.undefined_parameters import _UndefinedParameterAction
    from dataclasses import make_dataclass
    from dataclasses_json.utils import CatchAllVar

    def assert_handle_from_dict(action_name, expected_known_kvs, expected_unknown_kvs, given_kvs):
        TestClass = make_dataclass("TestClass", [(k, v) for k, v in given_kvs])
        known, unknown = _UndefinedParameterAction. \
            _separate_defined_undefined_kvs(cls=TestClass, kvs=given_kvs)
        assert known == expected_known_kvs, f"{action_name}: known"
        assert unknown == expected_unknown_kvs, f"{action_name}: unknown"

    assert_handle_from_

# Generated at 2022-06-23 17:04:49.626698
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    kvs = {"a": 1, "b": 2}
    cls = dataclasses.make_dataclass("dummy", kvs.keys())

    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False, "Should have raised UndefinedParameterError"



# Generated at 2022-06-23 17:05:01.538531
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass(abc.ABC):
        pass

    object_with_data = TestClass()
    data_in_object = dict(x=1)
    setattr(object_with_data, "undefined", data_in_object)
    data_in_object_should_be_mutable = \
        _CatchAllUndefinedParameters.handle_dump(object_with_data)
    assert len(data_in_object_should_be_mutable) == 1
    assert data_in_object_should_be_mutable["x"] == 1

    data_in_object_should_be_mutable["y"] = 2
    assert len(data_in_object_should_be_mutable) == 2

test__CatchAllUndefinedParameters_handle_dump()

# Generated at 2022-06-23 17:05:10.201161
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        catch_all: CatchAll = None

    undefined = _CatchAllUndefinedParameters()

    # Renames keys on export
    output = undefined.handle_to_dict(TestClass(),
                                      {"a": "a", "catch_all": {"b": "b"}})

    assert output == {"a": "a", "b": "b"}

    # Ignores keys on export
    output = undefined.handle_to_dict(TestClass(),
                                      {"a": "a", "catch_all": None})

    assert output == {"a": "a"}

# Generated at 2022-06-23 17:05:10.987234
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-23 17:05:13.467508
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    u = _UndefinedParameterAction
    with pytest.raises(NotImplementedError):
        u.handle_from_dict(cls=_UndefinedParameterAction, kvs={})

# Generated at 2022-06-23 17:05:19.770264
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json._config import Config
    from dataclasses import dataclass
    from dataclasses_json.utils import CatchAllVar
    from dataclasses_json.key_transforms import LetterCase

    # noinspection PyTypeChecker
    @dataclass(config=Config(
        letter_case=LetterCase.KEBAB,
        undefined=Undefined.INCLUDE,
    ))
    class CatchAllExample:
        a: int
        b: str
        catch_all: CatchAllVar

    example = CatchAllExample(a=1, b="Test", catch_all={"c": 123})
    result = example.to_dict()
    expected = {"a": 1, "b": "Test", "c": 123}
    assert result == expected

# Generated at 2022-06-23 17:05:21.008567
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 17:05:29.869609
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        @classmethod
        def handle_to_dict(cls, obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            kvs["abc"] = kvs.pop("abc")
            return kvs

        @property
        def abc(self):
            return self._abc

        @abc.setter
        def abc(self, value):
            self._abc = value


    TestClass.handle_to_dict.__func__.__globals__["obj"] = TestClass
    obj = TestClass(abc="def")
    kvs = {"abc": "def", "ghi": "jkl"}
    kvs = _UndefinedParameterAction.handle

# Generated at 2022-06-23 17:05:31.516439
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    assert hasattr(_IgnoreUndefinedParameters, "create_init")