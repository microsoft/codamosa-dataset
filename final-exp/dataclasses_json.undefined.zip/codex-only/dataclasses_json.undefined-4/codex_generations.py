

# Generated at 2022-06-23 16:55:42.846908
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, x: int, y, z: str):
            ...

    class B:
        def __init__(self, x: int, y=42, z: str = "hello"):
            ...

    def assert_params(cls, kvs, expected_params):
        assert _UndefinedParameterAction.handle_from_dict(cls=cls, kvs=kvs) == \
               expected_params

    assert_params(cls=A,
                  kvs={"x": 1, "y": 2, "z": "hello"},
                  expected_params={"x": 1, "y": 2, "z": "hello"})


# Generated at 2022-06-23 16:55:46.187669
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
    except TypeError:
        pass
    else:
        raise Exception("Constructed abstract base class.")

# Generated at 2022-06-23 16:55:52.787847
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class _TestClass:
        first: str
        second: int
        _third: bool

        def __init__(self, first: str, second: int):
            self.first = first
            self.second = second

    known_params, unknown_params = \
        _UndefinedParameterAction.handle_from_dict(
            _TestClass, {"first": "abc", "second": 123})

    assert known_params == {"first": "abc", "second": 123}
    assert len(unknown_params) == 0



# Generated at 2022-06-23 16:55:57.880808
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    This tests the constructor of the abstract base class
    _UndefinedParameterAction
    """
    cls = _UndefinedParameterAction
    cls._separate_defined_undefined_kvs(cls=_UndefinedParameterAction,
                                         kvs={"a": "a"})



# Generated at 2022-06-23 16:56:05.653703
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.core import make_encoders
    from dataclasses import dataclass

    @dataclass
    class Simple:
        attr: int
        undefined: Optional[CatchAllVar] = None

    encoders = make_encoders(
        undefined_parameters=_CatchAllUndefinedParameters
    )

    obj = Simple(attr=3)
    assert encoders.dump(obj) == {
        "attr": 3,
        "undefined": {}
    }

    obj = Simple(attr=3, undefined={'a': 1})
    assert encoders.dump(obj) == {
        "attr": 3,
        "undefined": {"a": 1}
    }



# Generated at 2022-06-23 16:56:17.118392
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A:
        pass

    class B:
        def __init__(self, a: int, b: int, **kwargs: Any) -> None:
            pass

    _RaiseUndefinedParameters.handle_from_dict(A,
                                               {
                                                   "a": 1,
                                                   "b": 2
                                               })
    try:
        _RaiseUndefinedParameters.handle_from_dict(B,
                                                   {
                                                       "a": 1,
                                                       "b": 2,
                                                       "c": 3
                                                   })
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'c': 3}"

    # _RaiseUndefinedParameters.create_init(A)



# Generated at 2022-06-23 16:56:23.010857
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError as MarshmallowError

    from dataclasses_json import dataclass_json, Undefined, config

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: int
        catch_all: Optional[CatchAllVar] = None

    kvs = {"x": 10, "y": 10, "catch_all": {}}
    expected = {"x": 10, "y": 10}
    assert expected == _CatchAllUndefinedParameters.handle_to_dict(
        TestClass, kvs)

    kvs = {"x": 10, "y": 10, "catch_all": {"z": 10}}

# Generated at 2022-06-23 16:56:28.786359
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Class:
        a: int = 0
        b: str = ""
        c: Optional[CatchAllVar] = None

    cls = Class()
    cls.a = 1
    cls.b = "hello"
    cls.c = {"d": 2}

    actual = _CatchAllUndefinedParameters.handle_to_dict(cls, {
        "a": cls.a,
        "b": cls.b,
        "c": cls.c
    })
    expected = {
        "a": 1,
        "b": "hello",
        "d": 2
    }
    assert expected == actual

# Generated at 2022-06-23 16:56:34.974548
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    data = {"a": 1,
            "_UNKNOWN0": 2,
            "b": 3,
            "_UNKNOWN1": 4,
            "c": 5}
    result = _UndefinedParameterAction.handle_to_dict(None, data)
    expected = {"a": 1, "b": 3, "c": 5}
    assert result == expected



# Generated at 2022-06-23 16:56:45.387468
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self,
                     foo: str,
                     bar: Optional[str] = 'bar_default',
                     baz0: Optional[str] = 'baz0_default',
                     baz1: Optional[str] = 'baz1_default'):
            self.foo = foo
            self.bar = bar
            self.baz0 = baz0
            self.baz1 = baz1

    @dataclasses.dataclass
    class Bar:
        foo: str = 'foo_default'
        bar: Optional[str] = 'bar_default'
        baz0: Optional[str] = 'baz0_default'
        baz1: Optional[str] = 'baz1_default'


# Generated at 2022-06-23 16:56:51.730516
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestDataClass(metaclass=dataclasses.dataclass):
        a: int
        b: int

    print(TestDataClass(a=1, b=2, c=3))
    try:
        print(TestDataClass.__init__({'a': 1, 'b': 2, 'c': 3}))
    except UndefinedParameterError:
        print("Did raise.")



# Generated at 2022-06-23 16:56:56.984174
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # This can be removed when
    # https://github.com/python/mypy/issues/6910 is resolved
    class Stub(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self):
            pass

    _UndefinedParameterAction.create_init(Stub)()

# Generated at 2022-06-23 16:57:02.231110
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class C:
        a: int
        b: str

    assert _IgnoreUndefinedParameters.handle_from_dict(cls=C,
                                                       kvs={'a': 3, 'b': 'c',
                                                            'c': 'd'}) == {
               'a': 3, 'b': 'c'}
    assert _IgnoreUndefinedParameters.handle_from_dict(cls=C, kvs={'a': 3}) == \
           {'a': 3}


# Generated at 2022-06-23 16:57:15.185408
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ClassWithDefaults:
        def __init__(self, a: str = "default_a", b: str = "default_b",
                     **undefined_parameters: CatchAll):
            pass

    assert ({"a": "default_a", "b": "default_b", "undefined_parameters": {}}
            == _CatchAllUndefinedParameters.handle_from_dict(ClassWithDefaults,
                                                             {}))
    assert ({"a": "default_a", "b": "default_b", "undefined_parameters": {}}
            == _CatchAllUndefinedParameters.handle_from_dict(ClassWithDefaults,
                                                             {
                "_UNKNOWN0": "won't matter"}))

# Generated at 2022-06-23 16:57:24.948866
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, x: int):
            self.x = x

    a = A(x=5)
    b = _UndefinedParameterAction.handle_from_dict(a, {"x": 5})
    assert b["x"] == 5

    a = A(x=5)
    b = _UndefinedParameterAction.handle_from_dict(a, {"x": 5, "y": 5})
    assert b["x"] == 5
    assert "y" not in b

    class B:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

    b = B(x=5, y=5)

# Generated at 2022-06-23 16:57:28.199329
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = object()
    output = _UndefinedParameterAction.handle_dump(obj)
    assert len(output) == 0



# Generated at 2022-06-23 16:57:38.953594
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test(object):
        def __init__(self, x: int, y: int, **kwargs):
            self.x = x
            self.y = y

        @classmethod
        def _handle_to_dict(cls, obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            return _UndefinedParameterAction.handle_to_dict(obj, kvs)

    @dataclasses.dataclass()
    class TestClass:
        x: int
        y: int
        z: int = None
        d: Dict[str, str] = dataclasses.field(default_factory=dict)
        p: Optional[CatchAllVar] = None

    test_obj3 = TestClass(1, 2, 3, 4, 5)

# Generated at 2022-06-23 16:57:51.378929
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from unittest.mock import Mock

    class_mock = type('ClassMock', (object,), {})
    class_mock.__init__ = Mock()
    class_mock.__init__.return_value = None
    class_mock.__init__.__signature__ = inspect.signature(class_mock.__init__)
    class_mock.__init__.__signature__ = class_mock.__init__.__signature__.replace(
        parameters=tuple(class_mock.__init__.__signature__.parameters.values())
    )


# Generated at 2022-06-23 16:57:54.531746
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters.handle_from_dict(Any, {})
    try:
        _RaiseUndefinedParameters.handle_from_dict(Any, {'a': 1})
        raise RuntimeError("Should have raised")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 16:57:55.286373
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    pass

# Generated at 2022-06-23 16:58:05.610315
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json import DataClassJsonMixin

    @dataclasses.dataclass
    class _TestClass(DataClassJsonMixin):
        a: int
        b: int
        _undefined: CatchAll

    test = _TestClass(a=2, b=3)
    expected = {}
    result = _CatchAllUndefinedParameters.handle_dump(test)
    assert expected == result

    test = _TestClass(a=2, b=3, _undefined={"test": "test"})
    expected = {"test": "test"}
    result = _CatchAllUndefinedParameters.handle_dump(test)
    assert expected == result

# Generated at 2022-06-23 16:58:10.525751
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class A:
        a: int = 0
        b: int = 1

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-23 16:58:15.907836
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    a = A(x=1)
    known, unknowns = _RaiseUndefinedParameters._separate_defined_undefined_kvs(
        cls=A, kvs=dict(x=1, y=2))
    assert known == dict(x=1)
    assert unknowns == dict(y=2)
    assert len(fields(A)) == 1



# Generated at 2022-06-23 16:58:25.916300
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Foo():
        a: str = "foo"
        b: str = "bar"
        c: Optional[CatchAllVar] = CatchAllVar()
        def __init__(self, a: str, b: str, c: Optional[CatchAllVar]):
            self.a = a
            self.b = b
            self.c = c
    x = Foo("foo", "bar", None)
    y = Foo("foo", "bar", {})
    z = Foo("foo", "bar", {"testing" : "for dump"})
    assert _CatchAllUndefinedParameters.handle_dump(x) == {}
    assert _CatchAllUndefinedParameters.handle_dump(y) == {}
    assert _CatchAllUndefinedParameters.handle_dump(z) == {"testing" : "for dump"}

# Generated at 2022-06-23 16:58:36.439779
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class _TestClass:
        catch_all: CatchAll = dataclasses.field(default=None)
        test: int = dataclasses.field(default=1)

    test_object = _TestClass(catch_all={"test2": 2})
    expected = {"test2": 2, "test": 1}
    assert _UndefinedParameterAction.handle_to_dict(test_object,
                                                    {"test2": 2, "test": 1}) \
           == expected
    assert _UndefinedParameterAction.handle_to_dict(test_object, expected) \
           == expected


# Generated at 2022-06-23 16:58:37.598563
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _IgnoreUndefinedParameters.handle_dump("test") == {}
    assert _CatchAllUndefinedParameters.handle_dump("test") == {}

# Generated at 2022-06-23 16:58:40.077984
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    undefined_parameter_action = _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:51.325134
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class A:
        def __init__(self, this_is_defined: str,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    class B:
        def __init__(self, this_is_defined: str,
                     catch_all: Optional[CatchAllVar] = None,
                     default: Dict = {}):
            pass

    class C:
        def __init__(self, this_is_defined: str,
                     catch_all: Optional[CatchAllVar] = None,
                     default: Dict = {"default": "value"}):
            pass

    parameters = {"this_is_defined": "defined",
                  "default": {"default": "value"},
                  "catch_all": {"key": "value",
                                "other_key": "other_value"}}

   

# Generated at 2022-06-23 16:58:55.241203
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c, d, e=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

        def foo(self, bar):
            pass

    assert TestClass.__init__ == _UndefinedParameterAction.create_init(TestClass)
    assert TestClass.foo == _UndefinedParameterAction.create_init(TestClass.foo)

# Generated at 2022-06-23 16:59:03.742378
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses
    import marshmallow_dataclass

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

        def __init__(self, a, b=1):
            self.a = a
            self.b = b

    schema = marshmallow_dataclass.class_schema(TestClass)
    result = schema.loads({"a": 5})
    assert result.data == TestClass(a=5, b=1)
    result = schema.loads({"a": 6, "b": 7})
    assert result.data == TestClass(a=6, b=7)
    result = schema.loads({"a": 6, "b": 7, "dummy": "dummy"})

# Generated at 2022-06-23 16:59:06.478112
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    a = _IgnoreUndefinedParameters()
    assert isinstance(a, _UndefinedParameterAction)

# Generated at 2022-06-23 16:59:15.185268
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from unittest import mock
    from marshmallow.fields import Field

    class MyClass:
        def __init__(self, field1, field2):
            self.field1 = field1
            self.field2 = field2

    mock_init = mock.create_autospec(MyClass.__init__)
    my_class_1 = MyClass(2, 3)
    my_class_1.__init__ = mock_init
    my_class_2 = MyClass(2, 3)
    my_class_2.__init__ = mock_init

    params_1 = {"field1": 2, "field2": 3, "field3": 1}
    params_2 = {"field1": 1}
    params_3 = {"field1": 1, "field2": 2, "field3": 1}
    params

# Generated at 2022-06-23 16:59:22.686653
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Foo:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            pass
    foo = Foo()
    catch_all_dict = _CatchAllUndefinedParameters.handle_dump(foo)
    assert catch_all_dict == {}

    foo = Foo({"key": "value"})
    catch_all_dict = _CatchAllUndefinedParameters.handle_dump(foo)
    assert catch_all_dict == {"key": "value"}

# Generated at 2022-06-23 16:59:30.787086
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class M(metaclass=Undefined.INCLUDE.value):
        catch_all = CatchAll()

    extra = {'foo': 'bar'}
    m = M(**extra)
    assert m.catch_all == extra
    output = _CatchAllUndefinedParameters.handle_dump(m)
    assert output == extra



# Generated at 2022-06-23 16:59:38.511634
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class _TestClass:
        a: int

    def _should_raise(kvs):
        try:
            _RaiseUndefinedParameters.handle_from_dict(_TestClass, kvs)
        except UndefinedParameterError as e:
            print(f"Successfully raised for kvs: {kvs}")
            return True
        return False

    def _should_not_raise(kvs):
        try:
            _RaiseUndefinedParameters.handle_from_dict(_TestClass, kvs)
        except UndefinedParameterError as e:
            print(f"Raised although no undefined parameters: {kvs}")
            return False
        return True

    _should_raise({"a": 1, "b": 2})

# Generated at 2022-06-23 16:59:51.899534
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from random import randint, random
    from string import ascii_uppercase
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class DummyExample(DataClassJsonMixin):
        a: int = None
        b: int = None

    params = {f"{k}": k for k in list(ascii_uppercase)[:10]}
    num_params = randint(2, 5)
    used_params = {k: v for k, v in
                   (params.popitem() for i in range(num_params))}
    unused_params = params
    params = {**used_params, **unused_params}

    # No exception thrown
    config.undefined = Undefined.RAISE
    _

# Generated at 2022-06-23 16:59:55.396138
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Print me please")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 17:00:04.408395
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class IncompleteClass:

        a: str
        b: int
        c: bool

        def __init__(self, a, b, c, *args, **kwargs):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(IncompleteClass)
    instance = IncompleteClass("a", 2, True)
    new_init(instance, "a", 2, True, "should", "be", "ignored")

# Generated at 2022-06-23 17:00:10.292135
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init = _CatchAllUndefinedParameters.create_init(
        CatchAllClass)  # type: Callable[[CatchAllClass, str, int], None]
    init(None, "a", "b", 3, c=3, d=3)

# Generated at 2022-06-23 17:00:12.358050
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _ = _UndefinedParameterAction()  # mypy
    assert False

# Generated at 2022-06-23 17:00:20.491009
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses_json
    import json

    @dataclasses.dataclass
    class HasCatchAll:
        defined: int
        optional_defined: int = 4
        catch_all: dataclasses_json.CatchAll = dataclasses.field(default=dict)

    json_string = '{"defined":1,"optional_defined":2,"undefined":3}'

    instance = dataclasses_json.load(json_string, HasCatchAll)
    assert instance.defined == 1
    assert instance.optional_defined == 2
    assert instance.catch_all == {"undefined": 3}

    instance = dataclasses_json.loads(json_string, HasCatchAll)
    assert instance.defined == 1
    assert instance.optional_defined == 2

# Generated at 2022-06-23 17:00:25.838367
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Example:
        def __init__(self):
            pass

    assert _UndefinedParameterAction.handle_to_dict(Example(), {
        "hello": "world"
    }) == {
        "hello": "world"
    }



# Generated at 2022-06-23 17:00:28.007361
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert {} == obj.handle_dump(None)

# Generated at 2022-06-23 17:00:30.631269
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Foo:
        def __init__(self):
            pass
    f = Foo()
    print(_UndefinedParameterAction.handle_dump(f))

# Generated at 2022-06-23 17:00:33.714484
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump([]) == {}


# Unit tests for method handle_to_dict of class _UndefinedParameterAction

# Generated at 2022-06-23 17:00:40.650538
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int = 1
        c: Optional[CatchAllVar] = None

    instance = TestClass(a=3, c={"d": 5})

    catch_all_dict = _CatchAllUndefinedParameters.handle_dump(instance)
    assert catch_all_dict == {"d": 5}



# Generated at 2022-06-23 17:00:54.792467
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from typing import Dict, Any

    from dataclasses_json.utils import CatchAllVar
    from dataclasses_json.utils import UndefinedParameterError

    @dataclass
    class A:

        i: int
        b: bool
        c: str = "bla"
        catch_all: CatchAllVar = None

    @dataclass
    class B:

        a: A
        catch_all: CatchAllVar = None

        def __post_init__(self):
            self.a.i += 5

    a = A(i=1, b=True)
    b = B(a=a)
    b.catch_all['d'] = 'blub'

    kvs = dataclasses.asdict(b)

    kvs = _CatchAllUnd

# Generated at 2022-06-23 17:01:05.217977
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class HasKwargs:
        def __init__(self, a: int, b: int, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

    obj = HasKwargs(a=1, b=2, c=3, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.kwargs == {"c": 3, "d": 4}

    obj = HasKwargs(a=1, b=2, c=3, d=4, e=5)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.kwargs == {"c": 3, "d": 4, "e": 5}


# Generated at 2022-06-23 17:01:08.953812
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class BaseClass(_UndefinedParameterAction):
        def handle_to_dict(self, obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            return kvs
    base_class = BaseClass()
    assert base_class.handle_to_dict(obj=None, kvs={}) == {}

# Generated at 2022-06-23 17:01:15.775340
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: str, b: str) -> None:
            pass

    create_init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert create_init is not TestClass.__init__

    class TestClass2:
        def __init__(self, a: str, b: str, c: str, d: str) -> None:
            pass

    create_init = _IgnoreUndefinedParameters.create_init(TestClass2)
    assert create_init is not TestClass2.__init__

# Generated at 2022-06-23 17:01:20.735405
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass(object):
        def __init__(self, a, b, c, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d


    a = TestClass(1, 2, 3, d=4)

    # replace the init with the one created by the Ignore with Undefined
    # parameters class
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    TestClass.__init__ = init

    # first call ignores this parameter
    b = TestClass(1, 2, 3, d=4, e=5)

    # second call uses the default value of this parameter
    c = TestClass(1, 2, 3)

    assert a.a == b.a
    assert a.b == b.b
    assert a

# Generated at 2022-06-23 17:01:29.833636
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class A:
        i: int
        x: int = 0
        catch_all: Optional[CatchAllVar] = None

    a = A(i=1, x=2, catch_all={"a": 3, "b": 4})
    assert _UndefinedParameterAction.handle_to_dict(a, {}) == {"i": 1, "x": 2}
    assert _IgnoreUndefinedParameters.handle_to_dict(a, {}) == {"i": 1, "x": 2}
    assert _RaiseUndefinedParameters.handle_to_dict(a, {}) == {"i": 1, "x": 2}
    assert _CatchAllUndefinedParameters.handle_to_dict(a, {}) == {"i": 1, "x": 2}

# Generated at 2022-06-23 17:01:35.809828
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int = 1
        b: int = 2

    assert _RaiseUndefinedParameters.handle_from_dict(
        A, {"a": 5, "b": 10, "c": 15}) == {"a": 5, "b": 10}
    try:
        _RaiseUndefinedParameters.handle_from_dict(A, {"a": 5, "b": 10, "c": 15,
                                                        "d": 20})
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-23 17:01:37.887229
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-23 17:01:49.355335
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: Optional[CatchAllVar] = None

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    a = 5
    expected_output = {"a": a, "c": 3, "d": "hello"}

    t = TestClass(a=a, b=expected_output)
    assert expected_output == _CatchAllUndefinedParameters.handle_dump(t)

    t = TestClass(a=a, c=3, d="hello")
    assert expected_output == _CatchAllUndefinedParameters.handle_dump(t)



# Generated at 2022-06-23 17:01:57.337620
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses as dt

    @dt.dataclass
    class Foo:
        field1: int
        field2: int
        field3: int
        field4: int

        def __init__(self, field1, field2=None, field3=None, field4=None):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(Foo)
    new_init(Foo, 1, 2, 3, 4, unknown1="definitely ignored",
             unknown2="totally ignored")
    # Also, the new __init__ has the same signature
    expected_sig = inspect.signature(Foo.__init__)
    new_sig = inspect.signature(new_init)
    assert expected_sig.parameters == new_sig.parameters

# Generated at 2022-06-23 17:02:07.327446
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: int, b: int, c: int, d: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    a = A(1, 2, 3)

    def f(self):
        pass

    def g(self, a: int):
        pass

    class B(abc.ABC):
        @abc.abstractmethod
        def h(self, a: int, b: int):
            pass

        @abc.abstractmethod
        def i(self, a: int, b: int, c: int):
            pass

    class C:
        def __init__(self, a: int):
            pass

        def j(self, a: int):
            pass


# Generated at 2022-06-23 17:02:12.049860
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclass_json import config
    import typing

    class DummyClass:
        def __init__(self, test: str, other: str = "default",
                     *,
                     unknown: typing.Optional[CatchAllVar] = None):
            pass

    d = DummyClass(test="test",
                   unknown={"other": "other"})

    assert config.encode_class(d) == {'test': 'test', 'other': 'other'}

# Generated at 2022-06-23 17:02:22.115487
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import inspect
    import sys

    class TestClass:

        def __init__(self, a, b, c):
            pass


    init_signature = inspect.signature(TestClass.__init__)
    mod = sys.modules[__name__]

    expected_num_params = len(init_signature.parameters) - 1  # don't count self
    ignored_init = _IgnoreUndefinedParameters.create_init(TestClass)
    spec = inspect.getfullargspec(ignored_init)
    num_params = len(spec.args)

    assert num_params == expected_num_params

# Generated at 2022-06-23 17:02:33.515592
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect
    import numpy as np
    from dataclasses_json.undefined import Undefined
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    class TestClass:
        a: Optional[int] = dataclasses.field(default=None)
        b: str = dataclasses.field(default="bla")

        _undefined: Undefined = Undefined.INCLUDE

        def __init__(self, a, b, **catch_all):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    test = TestClass(1, "a")
    assert test.a == 1
    assert test.b == "a"
    assert len(test.catch_all) == 0

    test_with_undefined = Test

# Generated at 2022-06-23 17:02:44.252175
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class DummyWithCatchAll:
        i: int
        s: str
        ca: Optional[CatchAllVar] = None

        def __init__(self, i: int, s: str, ca: Optional[CatchAllVar] = None):
            self.i = i
            self.s = s
            self.ca = ca

        def __eq__(self, other):
            return isinstance(other, DummyWithCatchAll) and \
                   self.i == other.i and self.s == other.s


    @dataclasses.dataclass
    class DummyWithoutCatchAll:
        i: int
        s: str

        def __eq__(self, other):
            return isinstance(other, DummyWithoutCatchAll) and \
                   self.i == other.i and self.s

# Generated at 2022-06-23 17:02:56.733322
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, arg1: int, catch_all: Optional[CatchAllVar] = None):
            pass

    kvs = {"arg1": 1, "arg2": 2}
    known_parameters, unknown_parameters = \
        _CatchAllUndefinedParameters.handle_from_dict(
            cls=TestClass, kvs=kvs)
    assert known_parameters == kvs
    assert unknown_parameters == {"arg2": 2}

    kvs = {"arg1": 1, "arg2": 2, "catch_all": {}}
    known_parameters, unknown_parameters = \
        _CatchAllUndefinedParameters.handle_from_dict(
            cls=TestClass, kvs=kvs)
    assert known_parameters == kvs
   

# Generated at 2022-06-23 17:03:01.007566
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():

    class DummyClass:
        pass

    actual = _UndefinedParameterAction.handle_dump(DummyClass)
    expected = {}

    assert actual == expected



# Generated at 2022-06-23 17:03:10.924156
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, c=3, a=1, b=2, **unknown):
            self.a = a
            self.b = b
            self.c = c
            self.unknown = unknown

    example_class = Example()
    known_given_parameters = {"a": 10, "c": 30}
    unknown_given_parameters = {"unknown": {"d": 33}}
    parameters = _IgnoreUndefinedParameters.handle_from_dict(
        Example, {**known_given_parameters, **unknown_given_parameters})
    example_class.__init__(**parameters)
    assert example_class.a == 10
    assert example_class.c == 30
    assert example_class.unknown == {}



# Generated at 2022-06-23 17:03:17.685025
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass(frozen=True, undefined=Undefined.INCLUDE)
    class GenericTestClass:
        a: int
        b: int
        c: int
        d: Optional[CatchAllVar]

    obj = GenericTestClass(1, 2, 3, {"key": "value"})
    kvs = dict(a=1, b=2, c=3, d={"key": "value"})
    result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert result == dict(a=1, b=2, c=3, key="value")

# Generated at 2022-06-23 17:03:28.384489
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():   # noqa
    class TestWithCatchAll(metaclass=CatchAllMeta):
        a: int = 1
        b: float = 10.0
        c: Optional[CatchAllVar] = CatchAll

    test = TestWithCatchAll(a=2, b=2.0)
    assert test.a == 2
    assert test.b == 2.0
    assert test.c == {}

    test = TestWithCatchAll(a=2, b=2.0, c=2)
    assert test.a == 2
    assert test.b == 2.0
    assert test.c == 2

    test = TestWithCatchAll(a=2, b=2.0, c=2, UNKNOWN1=1, UNKNOWN2=2,
                            UNKNOWN3=3, UNKNOWN4=4)


# Generated at 2022-06-23 17:03:34.259027
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Raises UndefinedParameterError if undefined parameters are
    passed in
    """
    kvs = {
        "a_defined_parameter": 2
    }
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(None, kvs)



# Generated at 2022-06-23 17:03:39.897747
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    def _get_init_function_as_string(obj):
        return inspect.getsource(obj.__init__)

    if _get_init_function_as_string(
            _UndefinedParameterAction()) != \
            _get_init_function_as_string(object):
        raise AssertionError(
            "UndefinedParameterAction should overwrite object.__init__")


# Unit tests for new _schema_params_switch

# Generated at 2022-06-23 17:03:46.737365
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def test(obj, expected):
        result = _UndefinedParameterAction.handle_dump(obj)
        assert result == expected

    class TestA:
        def __init__(self):
            pass

    class TestB:
        def __init__(self, a: int, b: str):
            pass

    test(TestA, {})
    test(TestB, {})



# Generated at 2022-06-23 17:03:55.184357
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

        def action(self):
            pass

    test_obj = TestClass()
    new_init = _UndefinedParameterAction.create_init(test_obj)

    def test_init(self, *args, **kwargs):
        pass

    test_obj.__init__ = test_init
    assert test_obj.__init__ is test_init
    assert new_init is not test_obj.__init__
    assert test_obj.action is test_obj.action
    assert test_obj.action is not new_init

# Generated at 2022-06-23 17:03:56.090475
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(
        "A String")

# Generated at 2022-06-23 17:04:06.705766
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        field: int
        catch_all: Optional[CatchAllVar] = None
        other_field: str = None
        optional_field: Optional[str] = None

    catch_all_init = _CatchAllUndefinedParameters.create_init(TestClass)
    obj = catch_all_init(TestClass, 1, optional_field="hello", some_key=42)
    assert obj.field == 1
    assert obj.other_field is None
    assert obj.optional_field == "hello"
    assert obj.catch_all == {"some_key": 42}

    obj = catch_all_init(TestClass, 1, optional_field="hello",
                         some_key=42, field=2)
    assert obj.field == 2
    assert obj.other

# Generated at 2022-06-23 17:04:14.670427
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test:
        def __init__(self, a1, a2, a3):
            self.a1 = a1
            self.a2 = a2
            self.a3 = a3

    class Test__CatchAll(Test):
        def __init__(self, a1, catch_all: Optional[CatchAllVar] = None):
            super().__init__(a1, catch_all=catch_all)
            self.a3 = self.catch_all["a3"]
            self.a4 = self.catch_all["a4"]

    t = Test__CatchAll("a1", catch_all={"a3": "a3", "a4": "a4"})
    assert t.a1 == "a1"

# Generated at 2022-06-23 17:04:16.934981
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # Methods of this class should be tested exclusively with 
    # dataclasses_json.config.Undefined
    pass

# Generated at 2022-06-23 17:04:24.317085
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    from marshmallow import Schema
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    @dataclass_json.dataclass_json(undefined=Undefined.IGNORE,
                                   letter_case=LetterCase.CAMEL)
    @dataclass
    class TestClass2:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

        @classmethod
        def do_something(cls):
            return 42


# Generated at 2022-06-23 17:04:28.758850
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    """
    Test that when parameters are given to a class that does not have such
    fields, the class is still constructed without error.
    """

    @dataclasses.dataclass
    class TestClass:
        pass

    parameters = {"a": 2}
    assert TestClass(**parameters).__dict__ == {}

# Generated at 2022-06-23 17:04:36.410255
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, cat: CatchAll = {}):
            self.cat = cat

    @dataclasses.dataclass
    class TestDataClass:
        cat: CatchAll = dataclasses.field(default_factory=dict)


# Generated at 2022-06-23 17:04:47.857407
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    This method tests the method create_init of class
    _IgnoreUndefinedParameters.
    The test mimics the initialization of a dataclass,
    with and without extra parameters.
    """

    # pylint: disable=unused-variable,too-few-public-methods

    @dataclasses.dataclass(frozen=True)
    class Bar:
        foo: str

    def _check_init(expected_arguments: Dict[str, Any],
                    given_arguments: Dict[str, Any]):
        class Foo:
            def __init__(self, **kwargs):
                self.foo = kwargs["foo"]

                if "bar" in kwargs:
                    self.bar = kwargs["bar"]


# Generated at 2022-06-23 17:04:52.886885
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: int = 4):
            self.a = a
            self.b = b

    assert _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 1,
                                                             "b": 2}) == {"a": 1, "b": 2}
    assert _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 1}) == {"a": 1, "b": 4}
    assert _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 1, "c": 3}) == {'a': 1, 'b': 4}

# Generated at 2022-06-23 17:04:54.746523
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 17:04:59.645087
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        a: int
        b: str

        def __init__(self, a: int, b: str, **kwargs):
            pass

    init_fun = _CatchAllUndefinedParameters.create_init(Test)
    init_fun(Test, 5, "hoi")

# Generated at 2022-06-23 17:05:03.663860
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test_message")
    except UndefinedParameterError as e:
        assert "test_message" in str(e)
        assert "UndefinedParameterError" in str(e)
        assert "UndefinedParameterError: " in str(e)



# Generated at 2022-06-23 17:05:09.169833
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect

    class A:
        def __init__(self, a: int, b: int = 1, c: int = 2):
            pass

    A.__init__ = _IgnoreUndefinedParameters.create_init(obj=A)
    init_signature = inspect.signature(A.__init__)
    assert init_signature == inspect.Parameter.empty

# Generated at 2022-06-23 17:05:11.702931
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test message")
    except UndefinedParameterError as err:
        assert err.args[0] == "Test message"

# Generated at 2022-06-23 17:05:14.260002
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    test_msg = "Test"
    e = UndefinedParameterError(test_msg)
    assert e.messages == test_msg

# Generated at 2022-06-23 17:05:23.619763
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Foo:
        number: int
        name: str

    for d in [
        {"number": 1, "name": "a"},
        {"number": 1, "name": "a", "color": "red"},
        {"number": 1, "name": "a", "color": "blue", "other": 1},
        {"number": 1},
    ]:
        assert _IgnoreUndefinedParameters.handle_from_dict(Foo, d) == {
                   "number": 1, "name": "a"}



# Generated at 2022-06-23 17:05:35.028786
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    """
    This test is not going to pass if we run mypy on this file.
    """
    # noinspection PyProtectedMember
    def handle_from_dict(cls, kvs: Dict) -> Dict[str, Any]:
        known, _ = _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=cls, kvs=kvs)
        return known

    class Foo:
        def __init__(self, bar: str, baz: str, *args, **kwargs):
            pass

    original_init = Foo.__init__
    new_init = _IgnoreUndefinedParameters.create_init(obj=Foo)
