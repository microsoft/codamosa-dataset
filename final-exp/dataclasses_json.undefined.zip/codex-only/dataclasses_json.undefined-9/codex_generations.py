

# Generated at 2022-06-23 16:55:40.607005
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    expected_dict = {"a": 1, "b": 2}
    actual_dict = _CatchAllUndefinedParameters.handle_dump(expected_dict)
    assert expected_dict == actual_dict

    expected_dict = {"a": 1, "b": 2, "c": {"d": 4}}
    actual_dict = _CatchAllUndefinedParameters.handle_dump(expected_dict)
    assert expected_dict == actual_dict

    expected_dict = {}
    actual_dict = _CatchAllUndefinedParameters.handle_dump(expected_dict)
    assert expected_dict == actual_dict

    # None is resulting in an empty dict
    expected_dict = {}
    actual_dict = _CatchAllUndefinedParameters.handle_dump(None)
    assert expected_dict == actual_dict

    # Other types should raise an error


# Generated at 2022-06-23 16:55:42.086490
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 16:55:53.079632
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init_template = """def __init__(self, field1: str, field2: int, 
    field3: str=None, field4: CatchAll=None):
        pass"""

    # Test with positional arguments only
    test_class = type("TestClass", (object,), {
        "__init__": eval(init_template)
    })
    positional = ["a", 5]
    keyword = {}
    new_init = _CatchAllUndefinedParameters.create_init(test_class)
    new_init(test_class(), *positional, **keyword)

    # Test with keyword arguments only
    test_class = type("TestClass", (object,), {
        "__init__": eval(init_template)
    })

    positional = []

# Generated at 2022-06-23 16:55:57.382509
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    expected_kvs = {'valid_field': 2}
    kvs = {'valid_field': 2, 'undefined_field': 3}
    assert _UndefinedParameterAction.handle_to_dict(None, kvs) == expected_kvs

# Generated at 2022-06-23 16:55:58.051500
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-23 16:56:04.917544
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Class(object):
        catch_all: Optional[CatchAllVar]

    obj = Class(catch_all={"a": "b"})
    result = _CatchAllUndefinedParameters.handle_dump(obj)
    assert result == {"a": "b"}

    obj = Class(catch_all={})
    result = _CatchAllUndefinedParameters.handle_dump(obj)
    assert result == {}

    obj = Class(catch_all=None)
    result = _CatchAllUndefinedParameters.handle_dump(obj)
    assert result == {}

# Generated at 2022-06-23 16:56:11.518273
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        def __init__(self, defined_param=3, **kwargs):
            pass

    obj = TestClass()

    initializer = _IgnoreUndefinedParameters.create_init(obj)
    initializer(obj, defined_param=2, undefined_param=3)



# Generated at 2022-06-23 16:56:14.705960
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters().handle_from_dict(None, {"a": 1}) == \
           {"a": 1}



# Generated at 2022-06-23 16:56:24.326696
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    '''
    Unit test for the _IgnoreUndefinedParameters constructor.
    '''
    class A:
        def __init__(self, a: str, b: int, c: float):
            self.a = a
            self.b = b
            self.c = c

    obj = A("a", b=1, c=1.1)
    obj_ignored = A("a", b=1, c=1.1, d=2)
    obj_extra_ignored = A("a", b=1, c=1.1, d=2, e=3.3)
    obj_extra_ignored_args = A("a", 1, 1.1, d=2, e=3.3)

# Generated at 2022-06-23 16:56:36.294944
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class SomeClass:
        def __init__(self, foo: str, *args, **kwargs):
            self.foo = foo

    test_kvs = {"foo": "bar"}
    actual = _RaiseUndefinedParameters.handle_from_dict(SomeClass, test_kvs)
    assert actual == {"foo": "bar"}

    test_kvs = {"foo": "bar", "bar": "baz"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(SomeClass, test_kvs)
        assert False, "Expected UndefinedParameterError"
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'bar': " \
                         "'baz'}"



# Generated at 2022-06-23 16:56:46.993080
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import Field
    from typing import Dict

    def assert_adds_catch_all_field(cls, incoming_parameters: Dict,
                                    expected_additional_args: Dict):
        handled_params = _CatchAllUndefinedParameters.handle_from_dict(
            cls=cls,
            kvs=incoming_parameters)
        assert handled_params == {
                   **expected_additional_args,
                   **incoming_parameters}

    class NumberField:
        pass

    class IntegerField:
        pass

    class MyClass:
        def __init__(self, number: NumberField, integer: int):
            pass


# Generated at 2022-06-23 16:56:52.586960
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # pylint: disable=anomalous-backslash-in-string

    import marshmallow
    import typing

    @dataclasses.dataclass(
        init=False)
    class A:
        test: typing.Optional[str] = dataclasses.field(default=None)

    assert A().test is None
    assert A(test="works").test == "works"

# Generated at 2022-06-23 16:57:02.379289
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        i: int
        k: str = "hello"
        p: str = "bye"

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    with pytest.raises(TypeError):
        # too many args
        init(TestClass, 1, 2, 3, 4, 5, 6)

    with pytest.raises(TypeError):
        # too many kwargs
        init(TestClass, i=1, k=2, p=3, d=4, f=5, g=6)

    # enough args
    init(TestClass, 1, k=2)

    # too few args
    init(TestClass)
    init(TestClass, k=2, p=3)

    #

# Generated at 2022-06-23 16:57:12.661771
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, arg1: int, arg2: Optional[str] = ""):
            pass

    _RaiseUndefinedParameters.handle_from_dict(
        cls=Foo, kvs={"arg1": 1, "arg2": "baz", "unknown": "bar"})
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=Foo, kvs={"arg1": 1, "unknown": "bar"})
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 16:57:22.858293
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class A:
        def __init__(self, a: int, b: int = 0, **kwargs):
            self.a: int = a
            self.b: int = b
            self.catch_all: Optional[CatchAllVar] = CatchAllVar()

    a = A(a=1, undefined=2, something_else=3)
    assert a.a == 1
    assert a.b == 0
    assert a.catch_all["undefined"] == 2
    assert a.catch_all["something_else"] == 3

    d = dataclasses.asdict(a)
    assert d.pop("a") == 1
    assert d.pop("b") == 0
    assert d.pop("catch_all") == {"undefined": 2, "something_else": 3}


# Generated at 2022-06-23 16:57:27.540928
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses import dataclass

    @dataclass
    class C:
        pass

    input = {1: 2}
    output = _UndefinedParameterAction.handle_to_dict(C(), input)
    assert output == input


# Generated at 2022-06-23 16:57:31.927245
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError):
        try:
            raise UndefinedParameterError("This is a test")
        except ValidationError as e:
            assert e.args[0] == "This is a test"

# Generated at 2022-06-23 16:57:39.570001
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    args = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_from_dict(DummyClass, args)
    assert {"a": 1, "b": 2} == result

    args = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = _UndefinedParameterAction.handle_from_dict(DummyClass, args)
    assert {"a": 1, "b": 2} == result



# Generated at 2022-06-23 16:57:43.573794
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    r = _UndefinedParameterAction.handle_from_dict()
    r = _UndefinedParameterAction.handle_to_dict()
    r = _UndefinedParameterAction.handle_dump()

# Generated at 2022-06-23 16:57:47.192105
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Example:
        def __init__(self, known: str, unknown: int):
            pass

        def __init__(self, unknown: int):
            pass

    _IgnoreUndefinedParameters.create_init(Example)(Example, 1, 2)

# Generated at 2022-06-23 16:57:51.016818
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(None, {"a": "b"}) == \
           {"a": "b"}

# Generated at 2022-06-23 16:57:58.605259
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, argument_mandatory: str,
                     argument_optional: Optional[int] = 42,
                     **kwargs: CatchAllVar):
            self.argument_mandatory = argument_mandatory
            self.argument_optional = argument_optional
            self.catch_all = kwargs

    object_to_test = TestClass("mandatory argument", argument_optional=1337,
                               this="will be dumped",
                               and_this="and will be dumped")
    dump_result = _CatchAllUndefinedParameters.handle_dump(object_to_test)

    dump_result_expected = {
        "this": "will be dumped",
        "and_this": "and will be dumped"
    }

    assert dump_result == dump_result_expected

# Generated at 2022-06-23 16:58:08.362149
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class _TestClass:
        def __init__(self, a: str, b: str, c: str,
                     d: Optional[CatchAllVar] = CatchAllVar.DEFAULT):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b \
                   and self.c == other.c and self.d == other.d

    correct_d = dict(a="a", b="b", c="c", d=dict())
    correct_d_undefined = dict(d=dict(x=1, y=2))
    correct_d2 = dict(a="a", b="b", c="c", x=1, y=2)


# Generated at 2022-06-23 16:58:16.729420
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import pytest
    import inspect
    import functools

    class A:
        def __init__(self, a, b, c):
            pass

    init = _IgnoreUndefinedParameters.create_init(A)
    bound_parameters = inspect.signature(init).bind_partial("a", "b", c="c")
    bound_parameters.apply_defaults()
    assert bound_parameters.arguments == {
        "a": "a",
        "b": "b",
        "c": "c"
    }

    bound_parameters = inspect.signature(init).bind_partial("a", "b", "c")
    bound_parameters.apply_defaults()

# Generated at 2022-06-23 16:58:29.025535
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():

    import unittest

    class Test(metaclass=TestMeta):
        a: int = 1
        b: str = "2"

    # Test correct parameters
    correct_parameters = {"a": 1, "b": "2"}
    assert _RaiseUndefinedParameters.handle_from_dict(Test,
                                                      kvs=correct_parameters) == correct_parameters

    # Test undefined parameters
    undefined_parameters = {"a": 1, "b": "2", "c": 3}
    with unittest.mock.patch(
            "dataclasses_json.undefinedbehavior._UndefinedParameterAction."
            "_separate_defined_undefined_kvs") as mock_separate:
        mock_separate.return_value = (correct_parameters,
                                      undefined_parameters)

# Generated at 2022-06-23 16:58:37.293184
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Ensure that create_init attaches the right PEP 526 annotations
    to the wrapper function.
    """
    class Foo:
        def __init__(self, a: str, b: int, c: str = "default"):
            pass

    init_funct = _UndefinedParameterAction.create_init(Foo)
    assert init_funct.__annotations__ == {'a': str, 'b': int, 'c': str}

# Generated at 2022-06-23 16:58:50.553292
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class _Dummy:
        i: int
        j: int = 1
        k: int = 0
        _underscore: int = 0

        def __init__(self, i, j=1, k=0, _underscore=0):
            self.i = i
            self.j = j
            self.k = k
            self._underscore = _underscore

    d = _Dummy(i=1, j=2, k=3, _underscore=10)
    kwargs = vars(d)

    init_func = _IgnoreUndefinedParameters.create_init(_Dummy)
    d1 = _Dummy(1)
    d2 = _Dummy(1, 2)

# Generated at 2022-06-23 16:59:02.136873
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError) as e_info:
        raise UndefinedParameterError()
    assert str(e_info.value) == ''
    with pytest.raises(UndefinedParameterError) as e_info:
        raise UndefinedParameterError(1, 2)
    assert str(e_info.value) == '1 2'
    with pytest.raises(UndefinedParameterError) as e_info:
        raise UndefinedParameterError('3')
    assert str(e_info.value) == '3'
    with pytest.raises(UndefinedParameterError) as e_info:
        raise UndefinedParameterError(message='4')
    assert str(e_info.value) == '4'
    with pytest.raises(UndefinedParameterError) as e_info:
        raise Und

# Generated at 2022-06-23 16:59:10.573616
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def _init(self, a, b=None, c=None):
        pass

    obj = type("IgnoreTest", (), {
        "__init__": _init
    })  # type: Any

    init_ignoring_undefined = _IgnoreUndefinedParameters.create_init(obj)
    obj = init_ignoring_undefined(
        obj, 1, 2, 3, 4, a=1, b=2, c=3,
        d=4, e=5
    )

# Generated at 2022-06-23 16:59:23.678258
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def init_function(self, p1: int, p2: int, p3: int = 1, p4: str = "abc"):
        self.p1 = p1
        self.p2 = p2
        self.p3 = p3
        self.p4 = p4

    cls = type("Test", (object,), {"__init__": init_function})
    custom_init = _IgnoreUndefinedParameters.create_init(obj=cls)

    # Should not raise ValidationError
    custom_init(cls(), 1, p3=2, p4="abc")
    custom_init(cls(), 1, 2)
    custom_init(cls(), 1, 2, p3=1)
    custom_init(cls(), 1, 2, p4="abc")

    # Should raise Val

# Generated at 2022-06-23 16:59:25.523019
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

    test_instance = TestClass.__init__(a=1, b=2)



# Generated at 2022-06-23 16:59:35.341013
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    This test ensures that create_init creates a __init__ method that behaves
    exactly like the original __init__ method.
    This works as long as the original __init__ method also works as expected.
    """
    import random

    class _A:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __eq__(self, other):
            return self.args == other.args and self.kwargs == other.kwargs

    class B(_A):
        def __init__(self, x: Optional[CatchAllVar] = None, *args, **kwargs):
            self.x = x
            kwargs['x'] = x
            super(B, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 16:59:44.515048
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():

    class TestClass:
        __dict__: Dict[str, Any]

        def __init__(self, **kwargs: Any) -> None:
            self.__dict__ = kwargs

    def _test_all_but_one(kvs: Dict, exclude_key: str,
                          expected_result: Dict) -> None:
        obj = TestClass(**kvs)
        result = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
        assert result == expected_result, f"Caught {result}"

    def _test_all(kvs: Dict,
                  expected_result: Dict) -> None:
        excluded_key = list(kvs.keys())[0]
        _test_all_but_one(kvs, excluded_key, expected_result)



# Generated at 2022-06-23 16:59:55.281037
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    def _test(cls):
        # A field with default value
        cls.with_default = Optional[CatchAllVar] = CatchAll(None)
        # A field without any default value
        cls.no_default = CatchAll
        # A field with default value
        cls.with_default_factory = Optional[CatchAllVar] = CatchAll(
            lambda: {"default": 2})

        """
        Here you can see that:
        - with_default / with_default_factory will be initialized with the
        default value if no parameter
        is passed in
        - no_default will be initialized with an empty dict.
        """
        cls()


# Generated at 2022-06-23 17:00:07.156166
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        parameter: int
        catch_all: CatchAll = None

    # ----------------------
    # TEST: no undefined parameters
    try:
        _CatchAllUndefinedParameters.handle_from_dict(TestClass,
                                                      dict(parameter=42))
    except UndefinedParameterError:
        raise AssertionError(
            "Should not raise error if no undefined parameters are given")
    # ----------------------
    # TEST: undefined parameters
    try:
        _CatchAllUndefinedParameters.handle_from_dict(TestClass, dict(
            parameter=42,
            unknown=1337))
    except UndefinedParameterError:
        raise AssertionError("Should not raise error if "
                             "undefined parameters are given")
    # ----------------------
    # TEST:

# Generated at 2022-06-23 17:00:18.844931
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ClassWithCatchAll:
        def __init__(self, field: str, optional: Optional[str] = None,
                     catch_all: Optional[CatchAllVar] = None):
            self.field = field
            self.optional = optional
            self.catch_all = catch_all

    defined_parameters_1 = {"field": "a"}
    defined_parameters_2 = {"optional": "b"}
    undefined_field = "undefined_parameter"
    undefined_value = "y"

    result = _CatchAllUndefinedParameters.handle_from_dict(ClassWithCatchAll,
                                                           defined_parameters_1)
    assert result == defined_parameters_1


# Generated at 2022-06-23 17:00:28.543453
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Example:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    example = Example(a=1, b=2)

    dumped = _CatchAllUndefinedParameters.handle_dump(example)
    assert len(dumped) == 0

    example.c = {"a": 1, "_a": 1}
    dumped = _CatchAllUndefinedParameters.handle_dump(example)
    assert len(dumped) == 2

    assert dumped["a"] == 1
    assert dumped["_a"] == 1

# Generated at 2022-06-23 17:00:40.807612
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    def _test_constructor(cls, kvs, expected_result):
        result = _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
        assert result == expected_result

    class _TestClass:
        def __init__(self, a: int, b: str = "b", **kwargs):
            pass

    _test_constructor(cls=_TestClass, kvs=dict(a=1, b="b"),
                      expected_result=dict(a=1, b="b"))
    _test_constructor(cls=_TestClass, kvs=dict(a=1, b="b", c="c"),
                      expected_result=dict(a=1, b="b"))

# Generated at 2022-06-23 17:00:49.520897
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Arrange
    obj = _UndefinedParameterAction()
    kvs = {'a': 1, 'b': 2}

    # Act
    actual = obj.handle_to_dict(obj=obj, kvs=kvs)

    # Assert
    expected = {'a': 1, 'b': 2}
    assert actual == expected



# Generated at 2022-06-23 17:00:55.630251
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():  # pylint: disable=unused-variable
    from .utils import IDENTITY  # noqa: F401 # pylint: disable=unused-import

    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: IDENTITY = "test"
        d: str = "isset"

    def assert_as_expected(given_params: Dict, expected_params: Dict):
        init = _IgnoreUndefinedParameters.create_init(A)
        a = A(**given_params)
        init(a, **given_params)
        for key, value in expected_params.items():
            assert getattr(a, key) == value


# Generated at 2022-06-23 17:01:04.664630
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        """
        Test Class for testing undefined action handling in
        _UndefinedParameterAction
        """
        field1: int
        field2: str

    known = {'field1': 1, 'field2': '2'}
    unknown = {'field3': '3'}

    test_parameters = {**known, **unknown}
    known_from_dict, unknown_from_dict = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            Test, test_parameters)
    assert known_from_dict == known
    assert unknown_from_dict == unknown


# Generated at 2022-06-23 17:01:11.320199
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, x: int, y: int = 3, *,
                     bar: CatchAll = None):
            pass

    foo = Foo(1, y=2, bar={})

    init = _CatchAllUndefinedParameters.create_init(Foo)
    init(foo, 1, 2, 3, 4, 5, 6)

# Generated at 2022-06-23 17:01:11.904677
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass

# Generated at 2022-06-23 17:01:18.356665
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Test:
        def __init__(self, a: int, b: Optional[CatchAllVar] = {}):
            print(a)
            print(b)

    _CatchAllUndefinedParameters.create_init(Test)(Test, 1, "loo")

    params = _CatchAllUndefinedParameters.handle_from_dict(Test, {"a": 1})
    print(params)

    params = _CatchAllUndefinedParameters.handle_from_dict(Test, {"a": 1,
                                                                  "b": "loo",
                                                                  "c": "foo"})
    print(params)
    input_dict = {"a": 1, "b": {"c": "foo"}, "c": "foo"}
    params = _CatchAllUndefinedParameters.handle_from_dict(Test, input_dict)

# Generated at 2022-06-23 17:01:28.556146
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Test if the custom created init methods stay compatible with the
    functionality of dataclasses.
    """
    import sys
    import types

    # noinspection PyProtectedMember
    # https://docs.python.org/3.8/library/types.html#types.FunctionType
    original_init_types = types.FunctionType.__init__.__get__(object)

    def mock_init_types(self, code, globals=None, name=None, argdefs=(),
                        closure=None):
        return original_init_types(self, code, globals, name, argdefs,
                                   closure)

    # noinspection PyProtectedMember
    types.FunctionType.__init__.__set__(object, mock_init_types)


# Generated at 2022-06-23 17:01:38.447027
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.core import from_dict, to_dict
    from dataclasses_json.undefined import Undefined, CatchAll

    @dataclasses.dataclass
    class A(object):
        a: str
        b: int
        c: Optional[CatchAll] = dataclasses.field(default=None,
                                                  metadata=dict(
                                                      undefined=Undefined.INCLUDE))

    initial_dict = {"a": "bla", "b": 1}
    a = from_dict(A, initial_dict)
    assert to_dict(a) == initial_dict
    assert a.c == {}

    initial_dict = {"a": "bla", "b": 1, "_UNKNOWN_1": "something"}
    a = from_dict(A, initial_dict)


# Generated at 2022-06-23 17:01:46.510987
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Foo:
        def __init__(self, catch_all: Optional[CatchAllVar] = None):
            self.catch_all = catch_all


    _CatchAllUndefinedParameters.create_init(Foo)
    _CatchAllUndefinedParameters.handle_from_dict(Foo,
                                                  {"catch_all": "test"})


if __name__ == "__main__":
    test__CatchAllUndefinedParameters()

# Generated at 2022-06-23 17:01:51.477349
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Foo:
        def __init__(self, bar: int, baz=42):
            pass

    kvs = {"bar": 13, "baz": 13}
    expected = {"bar": 13, "baz": 13}
    assert _UndefinedParameterAction.handle_from_dict(Foo, kvs) \
           == expected



# Generated at 2022-06-23 17:02:00.787062
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Foo:
        def __init__(self, a, b=None, undefined=None):
            self.a = a
            self.b = b
            self.undefined_parameters = undefined

    f = Foo(1, 2, {"x": 3, "y": 4})
    assert _UndefinedParameterAction.handle_to_dict(f, {"a": f.a, "b": f.b,
                                                         "undefined": f.undefined_parameters}) == {"a": 1, "b": 2, "x": 3, "y": 4}

test__UndefinedParameterAction_handle_to_dict()

# Generated at 2022-06-23 17:02:08.327777
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Foo:
        def __init__(self, a: int = 5, b: int = 4, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

    result = _CatchAllUndefinedParameters.handle_to_dict(Foo,
                                                         {"a": 5, "b": 4,
                                                          'kwargs': {"x": 3, "y": 5}})
    assert result["x"] == 3
    assert result["y"] == 5

# Generated at 2022-06-23 17:02:14.648976
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: str = "a"
        b: int = 1
        c: Optional[CatchAllVar] = None

    test_cases: Dict[str, Any] = {
        f"testcase_{i}": {
            "kvs": {"a": "a",
                    "b": 1,
                    "c": {"foo": "bar", "baz": "bla"}},
            "expected": {"a": "a",
                         "b": 1,
                         "c": {"foo": "bar", "baz": "bla"}}}

        for i in range(1, 5)
    }

    # Add more test cases, which do not give all parameters,
    # but set explicitly all parameters

# Generated at 2022-06-23 17:02:26.060523
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Example:
        def __init__(self, a, b, c=None, d=None):
            pass

    assert \
        Example.__init__.__name__ == \
        _IgnoreUndefinedParameters.create_init(Example).__name__
    assert \
        inspect.signature(Example.__init__) == \
        inspect.signature(_IgnoreUndefinedParameters.create_init(Example))

    Example2 = dataclasses.make_dataclass("Example2", [("a", Any), ("b", Any)])

    assert \
        Example2.__init__.__name__ == \
        _IgnoreUndefinedParameters.create_init(Example2).__name__

# Generated at 2022-06-23 17:02:31.003445
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, one, two):
            pass

    parameters, unknown = _RaiseUndefinedParameters.handle_from_dict(
        Test, {"one": 1, "two": 2})
    assert {"one": 1, "two": 2} == parameters
    assert {} == unknown



# Generated at 2022-06-23 17:02:34.262973
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 17:02:41.347187
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Test(metaclass=UndefinedMeta):
        a: str
        b: int = 1
        c: int = 2

    with pytest.raises(UndefinedParameterError):
        Test(_UNDEFINEDACTION=_RaiseUndefinedParameters, a="d")
    with pytest.raises(UndefinedParameterError):
        Test(_UNDEFINEDACTION=_RaiseUndefinedParameters, a="d", d=3)



# Generated at 2022-06-23 17:02:47.624888
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        defined: int
        undefined: int

        @classmethod
        def __init_subclass__(cls, **kwargs):
            dataclasses.init_subclass(cls,
                                      undefined_parameter_policy=Undefined.RAISE)

    data = {"defined": 1, "undefined": 1}
    with pytest.raises(UndefinedParameterError):
        MyClass(**data)

    data = {"defined": 1}
    new_instance = MyClass(**data)
    assert new_instance.defined == 1
    assert new_instance.undefined == dataclasses.MISSING



# Generated at 2022-06-23 17:02:58.371280
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        '''
        No init_value
        '''
        a: str
        b: int
        c: str

    test = Test("foo", 42, "bar")

    assert _IgnoreUndefinedParameters.handle_from_dict(Test, {"a": "foo", "b": 42, "c": "bar"}) == \
        {"a": "foo", "b": 42, "c": "bar"}
    assert _IgnoreUndefinedParameters.handle_from_dict(Test, {"a": "foo", "b": 42, "c": "bar", "d": 4}) == \
        {"a": "foo", "b": 42, "c": "bar"}
    assert test.a == "foo"
    assert test.b == 42


# Generated at 2022-06-23 17:03:10.100453
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self) -> None:
            self.a = 0
            self.c = 'c'

    class D:
        def __init__(self) -> None:
            self.a = 1
            self.c = 'd'
            self.d = 2
            self.e = 'e'

    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=C, kvs=dict(a=1, b=2, d=3))
    assert known == dict(a=1)
    assert unknown == dict(b=2, d=3)


# Generated at 2022-06-23 17:03:18.225526
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def assert_result(cls, kvs, expected):
        res = _CatchAllUndefinedParameters.handle_from_dict(cls, kvs)
        assert res == expected, f"Expected {expected} but got {res}"

    class Cls1:
        catch_all: Optional[CatchAllVar]

    class Cls2:
        a: int
        catch_all: Optional[CatchAllVar]

    class Cls3:
        a: int
        b: str
        catch_all: Optional[CatchAllVar]

    assert_result(Cls1, {}, {'catch_all': {}})
    assert_result(Cls1, {'catch_all': CatchAll}, {'catch_all': CatchAll})

# Generated at 2022-06-23 17:03:20.479792
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    This test makes sure that the constructor of _UndefinedParameterAction
    raises an error.
    """
    try:
        # noinspection PyArgumentList
        _UndefinedParameterAction()
    except TypeError:
        pass

# Generated at 2022-06-23 17:03:24.141827
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field1: int = 10
        field2: str = "hello"

    _init = _IgnoreUndefinedParameters.create_init(TestClass)

    tc = TestClass()
    _init(tc, field1=1, field2="world", field3="unused", field4=8)

    assert tc.field1 == 1
    assert tc.field2 == "world"

# Generated at 2022-06-23 17:03:35.533061
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Define a dataclass with CatchAll
    import dataclasses_json
    from typing import Optional, Callable


    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    class TestClass():
        parameter1: int
        parameter2: str
        parameter3: Optional[CatchAllVar]

        def __init__(self, parameter1, parameter2, parameter3=None) -> None:
            pass

    # Test incorrect calls
    init = TestClass.__init__
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)
    init_signature = inspect.signature(init)
    new_init_signature = inspect.signature(new_init)
    # Must have exact same signature except for the first parameter
    assert new_init

# Generated at 2022-06-23 17:03:41.970710
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.api import dataclass_json

    @dataclass_json
    @dataclasses.dataclass(frozen=True)
    class ClassWithCatchAll:
        catch_all: CatchAll
        name: str

    c = ClassWithCatchAll(catch_all=dict(a=1), name="hallo")
    expected = dict(a=1)
    assert c.catch_all == expected
    assert _CatchAllUndefinedParameters.handle_dump(c) == expected

    c = ClassWithCatchAll(name="hallo")
    assert c.catch_all is None
    assert _CatchAllUndefinedParameters.handle_dump(c) == {}



# Generated at 2022-06-23 17:03:54.316903
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import asdict

    import pytest

    # Define a test class
    class TestClass:
        pass

    # add fields
    for unknown_parameter in ["a", "b", "c"]:
        setattr(TestClass, unknown_parameter, Field(...))

    setattr(TestClass, "catch_all", Field(type=CatchAll, default=None))
    # Define a test instance
    test_instance = TestClass()
    # define some data
    data = {"a": 1}
    # Define some undefined parameters
    undefined_parameters = {"b": 2, "c": 3, "d": 4}
    # Merge the two dictionaries and hand them to the function
    arguments = {**data, **undefined_parameters}
    # run the function
    result = _Catch

# Generated at 2022-06-23 17:03:55.151054
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    pass

# Generated at 2022-06-23 17:04:06.253854
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass(frozen=True)
    class _TestClass:
        a: str
        b: str
        c: Optional[CatchAllVar]

        def __init__(self, a: str, b: str, c: Optional[CatchAllVar] = None):
            pass

    new_init = _CatchAllUndefinedParameters.create_init(_TestClass)
    _TestClass.__init__ = new_init

    # Test with no optional arguments
    test_case = _TestClass("a", "b")
    defined_parameters = {"a": "a", "b": "b"}
    unknown_parameters = {}
    catch_all = _CatchAllUndefinedParameters.handle_to_dict(test_case,
                                                            defined_parameters)
    assert catch_all

# Generated at 2022-06-23 17:04:17.083578
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        a: str
        b: int
        c: float
        # type: float

        def __init__(self, a: str, b: int, c: float) -> None:
            self.a = a
            self.b = b
            self.c = c

    @dataclasses.dataclass
    class Test2(Test):
        d: float

        def __init__(self, a: str, b: int, c: float,
                     d: float) -> None:
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test = Test(a="a", b=1, c=0.0)
    init = _IgnoreUndefinedParameters.create_init(test)


# Generated at 2022-06-23 17:04:21.628281
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test():
        def __init__(self, name: str, **unknown_parameters: Any):
            self.name = name
            self.unknown_parameters = unknown_parameters

    t = Test(name="Name")

    kvs = {"name": "Name"}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(t, kvs)
    assert len(kvs) == 1

    kvs = {"name": "Name", "unknown": "field"}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(t, kvs)
    assert len(kvs) == 1

    t.unknown_parameters = {"unknown": "field"}
    kvs = {"name": "Name"}

# Generated at 2022-06-23 17:04:29.907074
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int
        y: float

    kvs = {'x': 1, 'y': 0.1}
    assert dict(_RaiseUndefinedParameters.handle_from_dict(A, kvs)) == kvs
    kvs = {'x': 1, 'y': 0.1, 'z': 2}
    try:
        _RaiseUndefinedParameters.handle_from_dict(A, kvs)
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 17:04:38.868566
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyClass:
        tag: str
        optional_tag: Optional[str]

        def __init__(self, *,
                     catch=CatchAll,
                     tag: str,
                     optional_tag: Optional[str] = None):
            self.tag = tag
            self.optional_tag = optional_tag
            if catch is not None:
                if isinstance(catch, dict):
                    self.__dict__.update(catch)
                else:
                    self.__dict__.update(catch=catch)

    c = MyClass(tag="tag", optional_tag="optional_tag", optional_tag_2="a")
    assert c.optional_tag == "optional_tag"
    assert c.optional_tag_2 == "a"

# Generated at 2022-06-23 17:04:49.117220
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar

    class A:
        x: int
        y: CatchAllVar

    known, unknown = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(A, {
            "x": 3,
            "y": {"a": 1, "b": 2},
            "z": 0})
    assert known == {
        "x": 3,
        "y": {"a": 1, "b": 2}
    }
    assert unknown == {"z": 0}

    # Test default factory
    class A:
        x: int
        y: CatchAllVar = {}


# Generated at 2022-06-23 17:04:56.288346
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        a: str

    known, unknown = _RaiseUndefinedParameters.handle_from_dict(A, {"a": 1})
    assert unknown == {}
    assert known == {"a": 1}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(A, {"a": 1, "b": 2})


# Generated at 2022-06-23 17:04:58.471493
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        bar: str

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Foo, {"bar": "hello",
                                                         "baz": 42})



# Generated at 2022-06-23 17:05:01.003412
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
    except TypeError:
        pass
    else:
        raise AssertionError(
            "This class is abstract and should not be constructible")

# Generated at 2022-06-23 17:05:05.769220
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    obj1 = _CatchAllUndefinedParameters()
    obj2 = _CatchAllUndefinedParameters()
    assert obj1.handle_dump(obj2) == {}
    obj1.catch_all_field = {"key": "value"}
    obj2.catch_all_field = {}
    assert obj1.handle_dump(obj1) == {"key": "value"}
    assert obj2.handle_dump(obj2) == {}



# Generated at 2022-06-23 17:05:15.672200
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test _CatchAllUndefinedParameters._handle_from_dict
    """
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: int = 2
        unknown: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    def assert_init_parameters(parameters: Dict[str, Any],
                               a: int,
                               b: int = 2,
                               unknown: Dict = {}):
        assert parameters['a'] == a
        assert parameters['b'] == b
        assert parameters['unknown'] == unknown

    assert_init_parameters(
        _CatchAllUndefinedParameters.handle_from_dict(MyClass, {'a': 1}),
        a=1
    )
    assert_init_param

# Generated at 2022-06-23 17:05:16.613124
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert str(UndefinedParameterError("error message")) == "error message"

# Generated at 2022-06-23 17:05:25.056761
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass(
        repr=False,
        init=False)
    class MyClass:
        a: str

        @classmethod
        def create(cls, *args, **kwargs):
            obj = cls.__new__(cls)
            _IgnoreUndefinedParameters.create_init(cls)(obj, *args, **kwargs)
            return obj

    obj = MyClass.create("a", b="b")
    assert hasattr(obj, "b")

# Generated at 2022-06-23 17:05:30.802380
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Example:
        def __init__(self, a: int, **_unknown):
            pass
    expected_result = {'a': 1}
    result = _RaiseUndefinedParameters.handle_from_dict(Example, {'a': 1,
                                                                  'b': 2})
    assert result == expected_result
