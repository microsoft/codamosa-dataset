

# Generated at 2022-06-23 16:55:38.031669
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a, **kwargs):
            self.a = a
            self.kwargs = kwargs

    test = Test("a", b=1, c=2)
    assert test.a == "a"
    assert test.kwargs == {}

    test_2 = Test("a", b=1, c=2, **{"a": "a_2"})
    assert test_2.a == "a"
    assert test_2.kwargs == {}

# Generated at 2022-06-23 16:55:49.626849
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import _UndefinedParameterAction

    class _Test:
        def __init__(self, a: int, b: int, c: int = 3):
            pass

    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: int = dataclasses.field(default=3)

    class Test2:
        def __init__(self, a: int, b: int, c: int = 3):
            pass

    expected = {"_UNKNOWN0": 1, "_UNKNOWN1": 2, "c": 3}


# Generated at 2022-06-23 16:55:56.941754
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from typing import Optional, Dict
    from dataclasses import dataclass

    class A:
        def __init__(self, a: int, b: str, c: Optional[str] = None,
                     d: Dict[str, str] = None):
            self.a: int = a
            self.b: str = b
            self.c: Optional[str] = c
            self.d: Dict[str, str] = d if d is not None else {}

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class B:
        a: int
        b: str
        c: Optional[str] = None

        undefined: Optional[Dict] = field(default_factory=dict)

    x = _CatchAllUndefinedParameters.create_

# Generated at 2022-06-23 16:56:02.305431
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():

    class P(object):
        def __init__(self, a: int, b: int, c: int):
            print(a, b, c)

    P.__init__ = _IgnoreUndefinedParameters.create_init(P)
    P(1, 2, 3)
    P(1, 2, 3, d=4)
    P(1, 2, 3, d=4, e=5)
    P(1, 2, 3, a=1, b=2, c=3)
    P(1, 2, 3, a=1, b=2, c=3, d=4)
    P(1, 2, 3, a=1, b=2, c=3, d=4, e=5)


# Generated at 2022-06-23 16:56:14.341992
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, {"a": 1}) == \
           {"a": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, {"b": "b"}) == \
           {"b": "b"}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {"a": 1, "b": "b"}) == \
           {"a": 1, "b": "b"}


# Generated at 2022-06-23 16:56:23.981869
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class _TestCatchAll:
        a: str
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": {"load_only": True}})
        d: dataclasses.InitVar[int] = 1

        def __init__(self,
                     a: str,
                     b: int,
                     c: Optional[CatchAllVar] = None,
                     d: dataclasses.InitVar[int] = 1):
            self.a = a
            self.b = b
            self.c = c

    test_class = _TestCatchAll
    init = _CatchAllUndefinedParameters.create_init(test_class)

# Generated at 2022-06-23 16:56:25.077029
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert "Test Message" == str(UndefinedParameterError("Test Message"))

# Generated at 2022-06-23 16:56:25.910145
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    _ = UndefinedParameterError()

# Generated at 2022-06-23 16:56:39.049475
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass()
    class _TestClass:
        a: int
        catch_all: CatchAll

    assert _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass, {"a": 3}) == {"a": 3}
    assert _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass, {"a": 3, "b": 6}) == {"a": 3, "catch_all": {"b": 6}}
    assert _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass, {"a": 3, "catch_all": {"b": 6}}) == {
               "a": 3, "catch_all": {"b": 6}}

# Generated at 2022-06-23 16:56:40.439386
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("msg")
    assert err.messages == ["msg"]



# Generated at 2022-06-23 16:56:48.753889
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass():
        def __init__(self, x, y, whole=None):
            self.x = x
            self.y = y
            self.whole = whole

    testObj = TestClass(x=42, y=1002, whole={
        'a': "foo",
        'b': "bar",
        'c': "baz"
    })
    kvs = {
        "x": testObj.x,
        "y": testObj.y,
        "whole": testObj.whole
    }

    checked_kvs = _CatchAllUndefinedParameters.handle_to_dict(
        obj=TestClass,
        kvs=kvs
    )

    assert checked_kvs["a"] == "foo"
    assert checked_kvs["b"] == "bar"
   

# Generated at 2022-06-23 16:56:59.785735
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Dummy:
        a: int
        b: str
        c: float

    @dataclasses_json.config(unknown=Undefined.EXCLUDE)
    @dataclasses.dataclass
    class Test:
        x: int
        y: str
        z: float
        d: Optional[Dummy]

    received = {
        "x": 1,
        "y": "a",
        "z": 2.1,
        "d": {
            "a": 1,
            "b": "b",
            "c": 3.4,
        },
        "dunno": "bla",
    }

# Generated at 2022-06-23 16:57:09.308753
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, foo: str, bar: str, baz: str = "baz") -> None:
            self.foo = foo
            self.bar = bar
            self.baz = baz

    ignore_init = _IgnoreUndefinedParameters.create_init(A)
    a = A("foo", "bar")
    ignore_init(a, "foo", 4, baz="baz")
    assert a.foo == "foo"
    assert a.bar == "bar"
    assert a.baz == "baz"

# Generated at 2022-06-23 16:57:16.734875
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass(_IgnoreUndefinedParameters):
        x: int
        y: str
        acc: int = 0

        def __init__(self, x: int, y: str, acc: int = 0):
            self.x = x
            self.y = y
            self.acc = acc

    test_instance = TestClass(1, "a", acc=0)
    assert test_instance.x == 1
    assert test_instance.y == "a"
    assert test_instance.acc == 0

    test_instance = TestClass(1, "a")
    assert test_instance.x == 1
    assert test_instance.y == "a"
    assert test_instance.acc == 0



# Generated at 2022-06-23 16:57:24.604673
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    output = {"a": 1, "b": 2, "c": 3}
    catch_all_dict = {"d": 4, "e": 5}
    expected_output = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    result = _CatchAllUndefinedParameters.handle_to_dict(None, output)
    assert result == expected_output, \
        f"Failed to add undefined parameters to existing output " \
        f"({output}): " \
        f"Expected {expected_output} but got {result}"


if __name__ == "__main__":
    test__CatchAllUndefinedParameters_handle_to_dict()

# Generated at 2022-06-23 16:57:25.692195
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert isinstance(_UndefinedParameterAction(), _UndefinedParameterAction)

# Generated at 2022-06-23 16:57:37.879919
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test1:
        a: True
        b: int = 1

    @dataclass
    class Test2:
        a: True
        b: int = 1   # type: ignore

    @dataclass
    class Test3:
        a: True
        b: int = 1   # type: ignore

    @dataclass
    class Test4:
        a: True
        b: int = 1

    @dataclass
    class Test5:
        a: True
        b: int = 1

    @dataclass
    class Test6:
        a: True
        b: int = 1

    @dataclass
    class Test7:
        a: True
        b: int = 1


# Generated at 2022-06-23 16:57:42.770276
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class ExampleClass:
        catch_all: CatchAll = dataclasses.field(default_factory=dict)

    example = ExampleClass(catch_all={"blah": 3})

    assert _CatchAllUndefinedParameters.handle_dump(example) == {"blah": 3}

# Generated at 2022-06-23 16:57:49.186611
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    action = _RaiseUndefinedParameters()
    assert action._handle_from_dict == _RaiseUndefinedParameters.handle_from_dict
    assert action._handle_to_dict == _RaiseUndefinedParameters.handle_to_dict
    assert action._handle_dump == _RaiseUndefinedParameters.handle_dump
    assert action._create_init == _RaiseUndefinedParameters.create_init


# Generated at 2022-06-23 16:57:57.563308
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import numpy as np
    import marshmallow as ma
    import numbers

    @dataclasses.dataclass
    class _Tester:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"undefined_parameter_handling": Undefined.INCLUDE})
        an_int: int = dataclasses.field(default=0)

    @dataclasses.dataclass
    class _TesterB:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"undefined_parameter_handling": Undefined.INCLUDE})
        an_int: int = dataclasses.field(default=0)

        def __post_init__(self):
            pass


# Generated at 2022-06-23 16:57:59.948497
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}



# Generated at 2022-06-23 16:58:07.545126
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test(dataclasses.dataclass):
        a: str = "a"
        b: int = 1
        c: str = "c"
        d: CatchAll = dataclasses.field(default_factory=dict)

    test = Test()
    result = _UndefinedParameterAction.handle_to_dict(test, {"a": "a", "b": 1,
                                                              "c": "c",
                                                              "d": {"foo": "bar"}})

    assert result == {"a": "a", "b": 1, "c": "c", "foo": "bar"}

# Generated at 2022-06-23 16:58:13.361865
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    if isinstance(_UndefinedParameterAction, abc.ABCMeta):
        assert issubclass(_UndefinedParameterAction,
                          abc.ABCMeta), "ABCMeta should not be a subclass of ABC"  # type: ignore
    assert isinstance(_UndefinedParameterAction(), abc.ABC), \
        "ABC should be a subclass of _UndefinedParameterAction but not instantiable"

# Generated at 2022-06-23 16:58:23.521355
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Prepare
    @dataclasses.dataclass
    class TestClass:
        a: int = 1
        b: float = 1.1
        c: str = "abc"

        catch_all: Optional[CatchAllVar] = None

        def __init__(self, a, b, c, catch_all):
            # not important
            pass

    @dataclasses.dataclass
    class TestClass2:
        a: int = 1
        b: float = 1.1
        c: str = "abc"

        catch_all: Optional[CatchAllVar] = None

        def __init__(self,  # pylint: disable=unused-argument
                     a, b, c, catch_all=None):
            # not important
            pass


# Generated at 2022-06-23 16:58:29.116117
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        _undefined_handler = _IgnoreUndefinedParameters

        a: int
        b: str
        c: int = 3

    test_ignored_init = Test._undefined_handler.create_init(Test)
    test_instance = test_ignored_init(Test, 1, "x", "nonsense")

    assert test_instance.a == 1
    assert test_instance.b == "x"
    assert test_instance.c == 3

# Generated at 2022-06-23 16:58:37.384207
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    dataclass_params = {"a": 1, "b": 2, "c": 3}
    real_dict = dict({"a": 1, "b": 2, "c": 3, "catch_all": {"d": 4}})
    undefined = _CatchAllUndefinedParameters.handle_to_dict(
        None, real_dict)
    assert dataclass_params == real_dict
    assert undefined == {"d": 4}

# Generated at 2022-06-23 16:58:47.482859
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass(_UndefinedParameterAction):
        expected_output = {
            "a": 1,
            "b": 2
        }

        def __init__(self, a, b):
            pass

    known_params, unknown_params = TestClass.handle_from_dict(
        cls=TestClass, kvs=TestClass.expected_output)
    assert known_params == TestClass.expected_output
    assert len(unknown_params) == 0



# Generated at 2022-06-23 16:58:52.943377
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=5):
            pass

    kvs = {
        "a": 1,
        "b": 2,
        "x": "alphabet"
    }
    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs
        )
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"x": "alphabet"}



# Generated at 2022-06-23 16:59:02.379978
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test the behavior of method _CatchAllUndefinedParameters.handle_from_dict.
    """
    class TestClass:

        def __init__(self, x: int, y: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.x = x
            self.y = y
            self.catch_all = catch_all

    # noinspection PyTypeChecker
    test_object = TestClass(1, 2)
    # noinspection PyTypeChecker
    assert test_object.catch_all == {}

    # noinspection PyTypeChecker
    test_object = TestClass(1, 2, catch_all={"a": True})
    # noinspection PyTypeChecker
    assert test_object.catch_all == {"a": True}

    # noinspection

# Generated at 2022-06-23 16:59:12.525575
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():

    def foo(self, a: int, b: int, c: int = 10, d: Optional[str] = None):
        None

    class ErrorCausing:
        def __init__(self, *args, **kwargs):
            raise UndefinedParameterError

    class UndefinedParameters:
        def __init__(self, *args, **kwargs):
            pass

    undefined_parameters_class = UndefinedParameters
    error_causing_class = ErrorCausing
    for cls in [undefined_parameters_class, error_causing_class]:
        _IgnoreUndefinedParameters.create_init(cls)

    original_init = foo
    init_signature = inspect.signature(original_init)


# Generated at 2022-06-23 16:59:23.923612
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_obj_init(self, a, b=0.0, c="c"):
        self.a = a
        self.b = b
        self.c = c

    class TestObj:
        def __init__(self, a, b=0.0, c="c"):
            self.a = a
            self.b = b
            self.c = c

    TestObj.__init__ = test_obj_init
    TestObj.__signature__ = inspect.signature(test_obj_init)
    new_init = _IgnoreUndefinedParameters.create_init(TestObj)
    assert new_init(TestObj, 1, 2, 3, d=4, e=5) == TestObj(1, 2, 3)



# Generated at 2022-06-23 16:59:27.347365
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, dict(test=1)) == dict(
        test=1)



# Generated at 2022-06-23 16:59:35.973870
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    func = _RaiseUndefinedParameters.create_init(Foo)

    # Should raise for unknown parameters
    try:
        func(Foo(), x=5)
        assert False
    except UndefinedParameterError:
        pass

    # Should work without unknown parameters
    assert func(Foo(), y=5).kwargs == {"y": 5}
    assert func(Foo(), z=5).kwargs == {"z": 5}
    assert func(Foo(), y=5, z=5).kwargs == {"y": 5, "z": 5}

    # Should raise for unknown parameters if given

# Generated at 2022-06-23 16:59:46.012219
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Define the class we want to initialize
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
        g: int

        def __init__(self, *args, **kwargs):
            pass

    init_function = _IgnoreUndefinedParameters.create_init(A)
    init_signature = inspect.signature(init_function)

    # Given too many arguments
    init_function(None, 1, 2, 3, 4, 5, 6, 7, 8)

    # Given too many kwargs
    init_function(None, a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)

    # Given too

# Generated at 2022-06-23 16:59:49.789178
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("msg")
    except UndefinedParameterError as e:
        assert e.messages == ["msg"]

# Generated at 2022-06-23 16:59:54.753334
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class X:
        a: int = 0
        b: int = 1
        c: Optional[CatchAllVar] = None

    x = X()
    x.c = CatchAllVar({"d": 4, "e": 5})
    dump = _CatchAllUndefinedParameters.handle_dump(x)
    assert dump == {"d": 4, "e": 5}

# Generated at 2022-06-23 17:00:02.166479
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def _assert_dict(kvs, expected):
        assert expected == _UndefinedParameterAction.handle_to_dict(None, kvs)

    _assert_dict({}, {})
    _assert_dict({1:1}, {1:1})

# Unit tests for method _separate_defined_undefined_kvs

# Generated at 2022-06-23 17:00:07.245708
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    cls = dataclasses.make_dataclass('cls', [('a', int)])
    result = _UndefinedParameterAction.handle_to_dict(cls, {'a': 1})

    assert len(result) == 1
    assert result['a'] == 1


# Generated at 2022-06-23 17:00:08.732629
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters()

# Generated at 2022-06-23 17:00:19.343186
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-23 17:00:20.716971
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.messages == ["test"]

# Generated at 2022-06-23 17:00:27.022923
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Test for the method _CatchAllUndefinedParameters.handle_from_dict().
    """

    # Test behaviour when no default is given
    class CatchAllNoDefault:
        def __init__(self, a, catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.catch_all = catch_all
    class CatchAllDefault:
        def __init__(self, a, catch_all: Optional[CatchAllVar] = {}):
            self.a = a
            self.catch_all = catch_all
    class CatchAllDefaultFactory:
        counter: int = 0
        def __init__(self, a, catch_all: Optional[CatchAllVar] = None):
            self.a = a
            if catch_all is None:
                self.counter += 1

# Generated at 2022-06-23 17:00:38.392436
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        name: str = None
        surname: str = None
        catch_all: Optional[CatchAllVar] = None

    init_method = \
        _CatchAllUndefinedParameters.create_init(TestClass)
    assert init_method.__name__ == '_catch_all_init'
    assert init_method.__doc__ == \
           'Wrapper for TestClass.__init__ created by dataclasses_json'

    init_method(TestClass(name='a name'), 'an extra arg', age=5,
                street='a street')  # type: ignore
    init_method(TestClass(name='a name'), 'an extra arg', age=5,
                street='a street')  # type: ignore

# Generated at 2022-06-23 17:00:46.703884
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _CatchAllTestClass:
        def __init__(self, _var: int = 3,
                     _catch_all: CatchAll = CatchAll()):
            pass

    # Test no undefined parameters
    test_kvs = {"_var": 1}
    expected_kvs = {"_var": 1, "_catch_all": {}}
    result = _CatchAllUndefinedParameters.handle_from_dict(
        cls=_CatchAllTestClass, kvs=test_kvs)
    assert result == expected_kvs

    # Test undefined parameters
    test_kvs = {"_var": 1, "_var2": 1}
    expected_kvs = {"_var": 1, "_catch_all": {"_var2": 1}}

# Generated at 2022-06-23 17:00:54.317076
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field
    from dataclasses_json.undefined import CatchAll

    @dataclass
    class Model1:
        name: str
        catch_all: Optional[CatchAll] = field(default_factory=dict)

    @dataclass
    class Model2:
        name: str
        catch_all: Optional[CatchAll] = field(default=dict)

    @dataclass
    class Model3:
        name: str
        catch_all: Optional[CatchAll] = field(default_factory=dict)
        another_field: str = field(default="Dummy")

    @dataclass
    class Model4:
        name: str
        catch_all: Optional[CatchAll] = field(default=dict)
        another_field: str = field

# Generated at 2022-06-23 17:00:59.325177
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAll]):
            self.catch_all = catch_all

    t = TestClass({"a": "b"})
    ret = _CatchAllUndefinedParameters.handle_to_dict(t, {"catch_all": {}})
    assert ret == {"a": "b"}

# Generated at 2022-06-23 17:01:09.686865
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class _TestClass:
        a: int
        b: str
        c: bool = True
        _undefined_parameters: Optional[CatchAll] = None

    _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass, {"a": 1, "b": "x", "c": True, "d": False, "e": "undefined"})
    _CatchAllUndefinedParameters.handle_from_dict(
        _TestClass,
        {"a": 1, "b": "x", "c": False, "d": False, "e": "undefined"})

# Generated at 2022-06-23 17:01:15.624159
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, parameter1: int, parameter2: int):
            pass

    kvs: Dict[Any, Any] = {"parameter1": 4, "parameter2": 2,
                           "parameter3": 4}
    result = _IgnoreUndefinedParameters.handle_from_dict(kvs=kvs,
                                                         cls=TestClass)
    expected = {"parameter1": 4, "parameter2": 2}
    assert result == expected



# Generated at 2022-06-23 17:01:27.267172
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import datetime


    class Foo:
        def __init__(self,
                     defined_parameter: int,
                     catch_all: Optional[CatchAllVar]):
            pass


    try:
        _UndefinedParameterAction.create_init(Foo)
    except UndefinedParameterError as e:
        error_message = "No field of type dataclasses_json.CatchAll defined"
        assert error_message == str(e)
    else:
        raise AssertionError("Did not raise UndefinedParameterError")

    class Bar:
        def __init__(self,
                     defined_parameter: int,
                     catch_all: Optional[CatchAllVar]):
            pass

        second_catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)


   

# Generated at 2022-06-23 17:01:37.094050
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        field_a: int
        field_b: int
        field_c: int

        def __init__(self, field_a, field_b, field_c):
            pass

    original_init = TestClass.__init__
    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert original_init != new_init
    assert new_init(TestClass, 1, 2)
    assert new_init(TestClass, 1, 2, 3, 4, 5, field_b=1, field_c=1)
    assert new_init(TestClass, 1, 2, 3, field_c=2, _UNKNOWN7=3)



# Generated at 2022-06-23 17:01:49.817327
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = None
        known: int = 1

    class_fields = fields(TestClass)
    field_names = [field.name for field in class_fields]


# Generated at 2022-06-23 17:01:55.030051
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # noinspection PyUnresolvedReferences
    class TestClass:
        def __init__(self, a: int, b: str):
            pass

    obj = TestClass(1, "2")
    # noinspection PyUnresolvedReferences
    ignore_init = _IgnoreUndefinedParameters.create_init(TestClass)
    ignore_init(obj, 123, "test", f=4, g=5)
    assert obj.a == 1
    assert obj.b == "2"

# Generated at 2022-06-23 17:02:05.430809
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect
    from dataclasses import dataclass

    # Create a dataclass
    @dataclass
    class MyClass:
        param1: str
        init_called: bool = dataclasses.field(init=False)

        def __init__(self, param1: str, param2: str):
            self.init_called = True
            self.param1 = param1
            self.param2 = param2

    # Test if __init__ is used as intended
    mc = MyClass("hi", "there")
    assert mc.param1 == "hi"
    assert mc.param2 == "there"
    assert mc.init_called

    # Set __init__ of MyClass to the customized version created
    # by _IgnoreUndefinedParameters._create_init
    my_class_init = _IgnoreUndefined

# Generated at 2022-06-23 17:02:10.837674
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Unit test for constructor of class _UndefinedParameterAction
    """
    assert type(_UndefinedParameterAction.handle_from_dict) == staticmethod
    assert type(_UndefinedParameterAction.handle_to_dict) == staticmethod
    assert type(_UndefinedParameterAction.handle_dump) == staticmethod
    assert type(_UndefinedParameterAction.create_init) == staticmethod
    assert type(_UndefinedParameterAction._separate_defined_undefined_kvs) == \
           staticmethod



# Generated at 2022-06-23 17:02:23.831340
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}

    assert _CatchAllUndefinedParameters.handle_to_dict(None,
                                                       {"a": 1}) == {"a": 1}
    assert _CatchAllUndefinedParameters.handle_to_dict(None,
                                                       {"a": 1,
                                                        "__data__": None}) \
           == {"a": 1}
    assert _CatchAllUndefinedParameters.handle_to_dict(None,
                                                       {"a": 1,
                                                        "__data__": {}}) \
           == {"a": 1}

# Generated at 2022-06-23 17:02:28.709888
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass(metaclass=abc.ABCMeta):
        _undefined_parameter_action__ = _UndefinedParameterAction

    assert isinstance(TestClass(), _UndefinedParameterAction)

if __name__ == "__main__":
    test__UndefinedParameterAction()

# Generated at 2022-06-23 17:02:37.388897
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from typing import List, Dict
    from dataclasses import dataclass
    @dataclass
    class NoFields:
        pass
    @dataclass
    class OneField:
        a: int
    @dataclass
    class TwoFields:
        a: int
        b: List[Dict]

    for no_fields_object in [NoFields(), NoFields(a=1),
                             NoFields(**{"a":1, "b":2})]:
        kvs = {"a": 1, "b": 2}
        kvs = _CatchAllUndefinedParameters.handle_to_dict(no_fields_object,
                                                           kvs)
        assert kvs == {"a": 1, "b": 2}


# Generated at 2022-06-23 17:02:48.759676
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses
    import inspect
    from typing import Optional, List

    @dataclasses.dataclass(
        init=False,
        repr=False,
        unsafe_hash=False,
        frozen=False,
        eq=False,
        order=False,
        unsafe_hash=False
    )
    class Example:
        """
        This dataclass illustrates that, when instantiated
        with too many args, a regular init will raise a TypeError.
        """
        a: int
        b: int
        c: int
        d: Optional[List[int]] = dataclasses.field(default_factory=list)
        e: Optional[List[int]] = dataclasses.field(default_factory=list)


# Generated at 2022-06-23 17:02:58.882347
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    Test for method _CatchAllUndefinedParameters.create_init
    """

    class TestClass:
        def __init__(self, x: int, y: Optional[int] = 2,
                     unknown_parameters: Optional[CatchAll] = None):
            self.x = x
            self.y = y
            self.unknown_parameters = unknown_parameters

    self_parameter = inspect.Parameter(name="self", kind=inspect.Parameter.POSITIONAL_ONLY)

# Generated at 2022-06-23 17:03:05.216694
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction.handle_from_dict(object, {})
    _UndefinedParameterAction.handle_to_dict(object, {})
    _UndefinedParameterAction.handle_dump(object)
    _UndefinedParameterAction.create_init(object)
    _UndefinedParameterAction._separate_defined_undefined_kvs(object, {})



# Generated at 2022-06-23 17:03:12.738771
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import typing
    import pytest


    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class TestClass:
        test_field: str
        catch_all: typing.Optional[CatchAllVar] = None


    def assert_undefined_parameters_included(expected_value, actual_value):
        if isinstance(expected_value, dict):
            assert isinstance(actual_value, dict)
            for key in expected_value:
                assert_undefined_parameters_included(expected_value[key],
                                                     actual_value[key])
        else:
            assert expected_value == actual_value


    test_input = {"test_field": "abc", "undef_field": "def"}
    expected_output = test_input.copy()
    expected

# Generated at 2022-06-23 17:03:23.504419
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # class definition
    @dataclasses.dataclass
    class TestClass:
        a: int = 0
        b: int = 1
        param_catch_all: CatchAll = None

    test_class_instance = TestClass()
    # initialize the class
    # with parameters that are in the class
    kvs = _CatchAllUndefinedParameters.handle_from_dict(
        cls=TestClass,
        kvs=dict(a=100, b=100, param_catch_all=None))
    test_class_instance = TestClass(**kvs)
    assert test_class_instance.a == 100 and test_class_instance.b == 100 and \
           test_class_instance.param_catch_all == {}
    # with parameters that are in the class and are undefined
    kvs = _CatchAll

# Generated at 2022-06-23 17:03:25.017612
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert isinstance(_UndefinedParameterAction, abc.ABCMeta)  # type: ignore

# Generated at 2022-06-23 17:03:25.691440
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-23 17:03:36.871711
# Unit test for method create_init of class _CatchAllUndefinedParameters

# Generated at 2022-06-23 17:03:49.278291
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    CatchAll = Optional[CatchAllVar]
    @dataclasses.dataclass
    class CatchAllTest:
        foo: int
        bar: str = "bar"
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    catch_all_test = CatchAllTest(foo=1)
    assert (catch_all_test.catch_all == {}), "default_factory of catch_all \
    has not been called"

    @dataclasses.dataclass
    class NoCatchAllTest:
        foo: int
        bar: str = "bar"

    with pytest.raises(UndefinedParameterError, match="No field"):
        NoCatchAllTest()


# Generated at 2022-06-23 17:03:59.233117
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import pytest


# Generated at 2022-06-23 17:04:08.494020
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    import marshmallow
    from marshmallow import Schema, fields

    from dataclasses_json.utils import CatchAll


    class TestUndefinedParameterAction(Schema):
        a = fields.Str()
        b = fields.Str()
        c = fields.Str()

        class Meta:
            unknown = Undefined.EXCLUDE


    class TestCatchAll(Schema):
        a = fields.Str()
        b = fields.Str()
        c = fields.Str()
        unknown_fields = fields.Dict()

        class Meta:
            unknown = Undefined.INCLUDE
    data = {"a": "a", "b": "b", "c": "c", "d": "d"}

    testUndefinedParameterAction = TestUndefinedParameterAction()
    # Test that nothing is modified, if no undefined parameter was

# Generated at 2022-06-23 17:04:15.671501
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class _TestClass:
        def __init__(self, foo: str, bar: int):
            self.foo = foo
            self.bar = bar

    kvs = {"foo": "foo", "bar": 1, "baz": 3}
    known_given_parameters = {"foo": "foo", "bar": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        _TestClass, kvs) == known_given_parameters



# Generated at 2022-06-23 17:04:23.731294
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def _test_init(self, x: int):
        pass

    def _run_test(_create_init, **init_params):
        init = _create_init(_test_init)
        init_kwargs = inspect.signature(init).parameters.keys()
        init_params = {k: v for k, v in init_params.items() if k in init_kwargs}
        class_params = inspect.signature(_test_init).parameters
        expected_params = {k: v for k, v in init_params.items() if k != "self"}
        expected_params.update({k.name: v for k, v in init_kwargs.items() if
                                k.name != "self" and k.name not in init_params})


# Generated at 2022-06-23 17:04:26.405459
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class CatchAllSubclass(_CatchAllUndefinedParameters):
        pass

    CatchAllSubclass.handle_from_dict(None, None)

# Generated at 2022-06-23 17:04:30.684116
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    def test_function(self, a: int, b: int, c: int):
        pass

    assert test_function == _UndefinedParameterAction.create_init(TestClass)

# Generated at 2022-06-23 17:04:39.384375
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    '''
    Test that when _RaiseUndefinedParameters.handle_from_dict is given a
    dictionary with undefined parameters,
    it raises an Error.
    '''
    test_data = {
        "a": 42,
        "b": "spam",
        "c": 7
    }

    a = 7
    b = 8
    c = "eggs"

    class BadClass:
        def __init__(self, a: int, b: int, c: str) -> None:
            self.a = a
            self.b = b
            self.c = c

    # noinspection PyTypeChecker
    _RaiseUndefinedParameters.handle_from_dict(BadClass, test_data)



# Generated at 2022-06-23 17:04:46.247850
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import io
    import sys

    @dataclasses.dataclass
    class C:
        a: str = "a"
        b: str = "b"
        c: str = "c"
        d: str = "d"
        e: str = "e"
        f: str = "f"
        g: str = "g"
        h: str = "h"
        i: str = "i"
        j: str = "j"
        k: str = "k"
        l: str = "l"

    c_init = _IgnoreUndefinedParameters.create_init(C)
    sys.stdout = io.StringIO()

# Generated at 2022-06-23 17:04:50.325532
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar]

    t = TestClass(a=1, b="foo", c={"d": 2})

    assert _CatchAllUndefinedParameters.handle_dump(t) == {"d": 2}



# Generated at 2022-06-23 17:04:59.703337
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        @dataclasses.dataclass
        class Bar:
            a: int
            b: str
            c: float
            _catch_all: CatchAll = dataclasses.field(
                default_factory=dict)

    init_method_without_catch_all = Foo.Bar.__init__
    init_method_with_catch_all = _CatchAllUndefinedParameters.create_init(
        Foo.Bar)

    assert init_method_without_catch_all.__code__ != \
           init_method_with_catch_all.__code__

# Generated at 2022-06-23 17:05:08.572653
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    init_params = dict(a="a", b="b", catch_all=dict(x="x", y="y"))

    class TestClass:
        def __init__(self, a: str, b: str, catch_all: Optional[CatchAll]):
            # noinspection PyUnusedLocal
            self.a = a
            # noinspection PyUnusedLocal
            self.b = b
            self.catch_all = catch_all

    t = TestClass(**init_params)
    res = _CatchAllUndefinedParameters.handle_dump(t)
    assert res == dict(x="x", y="y")



# Generated at 2022-06-23 17:05:17.220937
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAll

    @dataclasses.dataclass
    class DataClassWithDefaultCatchAll:
        hello: str
        catch_all: Optional[CatchAll] = CatchAll()

    @dataclasses.dataclass
    class DataClassWithCustomCatchAll:
        hello: str
        catch_all: Optional[CatchAll] = dataclasses.field(
            default_factory=dict)

    def check(dc):
        result = _CatchAllUndefinedParameters.handle_from_dict(
            dc, {"hello": "world", "catch_all": {}, "x": "y"})
        assert result == {"hello": "world", "catch_all": {"x": "y"}}


# Generated at 2022-06-23 17:05:28.104169
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # define test class with undefined parameters
    class TestClass:
        def __init__(self, _UNDEF1=1, _UNDEF2=2, **kwargs):
            self.undef1 = _UNDEF1
            self.undef2 = _UNDEF2
            self.undef3 = kwargs.get('_UNDEF3', 3)

    import dataclasses
    import dataclasses_json
    import dataclasses_json.config


# Generated at 2022-06-23 17:05:35.639225
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: str = "a_default"
        c: str = dataclasses.field(default="c_default")
        a_list: list = dataclasses.field(default_factory=list)
        d: Optional[CatchAll] = dataclasses.field(default_factory=dict)

    obj = A(a=1, b="b_new", c="c_new", a_list=["an_element", "another_element"])
    # d has the default_factory