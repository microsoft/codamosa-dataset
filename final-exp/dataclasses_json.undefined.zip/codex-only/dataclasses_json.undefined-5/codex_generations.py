

# Generated at 2022-06-23 16:55:34.824606
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Dummy:
        def __init__(self, param_1: str):
            pass

    kvs = {"param_1": "blub", "param_2": 3}
    returned_params = _IgnoreUndefinedParameters.handle_from_dict(Dummy, kvs)
    assert returned_params == {"param_1": "blub"}



# Generated at 2022-06-23 16:55:46.760220
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def __init__(self, *args, **kwargs):
        self.internal_args = args
        self.internal_kwargs = kwargs

    class SomeClass:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def dummy_init(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    SomeClass.__init__ = __init__
    SomeClass.__init__ = _UndefinedParameterAction.create_init(SomeClass)

    # case undefined parameters = 0
    a = SomeClass(1, 2, a=3, b=4)
    assert a.internal_args == (1, 2)

# Generated at 2022-06-23 16:55:53.981952
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: float
    good_input = {"a": 1, "b": "2", "c": 3}
    resultant = _RaiseUndefinedParameters.handle_from_dict(TestClass, good_input)
    assert resultant == good_input
    bad_input = {"a": 1, "b": "2", "c": 3, "d": 4}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, bad_input)
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-23 16:56:04.574535
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test(object):
        a: int
        b: int
        c: int = 10
        _catch_all: CatchAll = dataclasses.field(
            default=dataclasses.field(default_factory=dict),
            metadata={'dataclasses_json': {'mm_field': CatchAllVar}})

    t = Test(1, 2, 3, 4)
    assert t._catch_all == {}
    assert t.a == 1
    assert t.b == 2
    assert t.c == 3

    t = Test(1, 2, undefined_param=4)
    assert t._catch_all == {"undefined_param": 4}

    t = Test(1, 2, 3, catchall_param=4)

# Generated at 2022-06-23 16:56:16.800038
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import numpy as np
    from dataclasses_json.functions import to_json, from_json

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int
        c: np.ndarray
        catch_all: CatchAll = None

    instance = TestClass("a", 1, np.ones(3))
    json = to_json(instance, indent=4, letter_case=LetterCase.PASCAL,
                   undefined=Undefined.INCLUDE)
    print(json)

    instance2 = from_json(json, TestClass)
    json2 = to_json(instance2, indent=4, letter_case=LetterCase.PASCAL,
                    undefined=Undefined.INCLUDE)
    print(json2)


# Generated at 2022-06-23 16:56:21.110647
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    test_class = _CatchAllUndefinedParameters
    test_obj = type("TestClass",(object,),
                    {'catch_all': {'a': 1, 'b': 2}})
    result = test_class.handle_dump(test_obj)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:56:27.696031
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        first_name: str
        last_name: str
        age: int = 0
        catch_all: CatchAll = None

    kvs = {"first_name": "John", "last_name": "Doe", "age": 30,
           "undefined_parameter": "value"}
    received = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    expected = {"first_name": "John", "last_name": "Doe", "age": 30}
    assert expected == received



# Generated at 2022-06-23 16:56:38.283824
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses as dc
    import dataclasses_json as dcj

    @dcj.dataclass_json(undefined=Undefined.EXCLUDE)
    @dc.dataclass
    class Bar:
        foo: str
        bar: int

    @dcj.dataclass_json(undefined=Undefined.EXCLUDE)
    @dc.dataclass
    class Foo:
        bar: Bar

    init_of_bar = Bar.__init__
    init_of_foo = Foo.__init__

    assert init_of_bar.__name__ == "_UndefinedParameterAction_ignore_init"
    assert init_of_foo.__name__ == "_UndefinedParameterAction_ignore_init"

# Generated at 2022-06-23 16:56:40.468130
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert isinstance(_UndefinedParameterAction(), abc.ABC)

# Generated at 2022-06-23 16:56:48.793941
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _ = _RaiseUndefinedParameters
    # noinspection PyAbstractClass
    class ConcreteRaiseUndefinedParameters(_RaiseUndefinedParameters):
        pass

    try:
        ConcreteRaiseUndefinedParameters.handle_from_dict(
            cls=ConcreteRaiseUndefinedParameters,
            kvs={})
        assert False
    except UndefinedParameterError:
        assert True

    assert ConcreteRaiseUndefinedParameters.handle_from_dict(
        cls=ConcreteRaiseUndefinedParameters,
        kvs={'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-23 16:56:55.324650
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class MyClass:
        def __init__(self, a, b, *_args, **_kwargs):
            self.a = a
            self.b = b

    init = _IgnoreUndefinedParameters.create_init(MyClass)
    obj = MyClass(a=1, b=2)
    init(obj, 3, 4, 5, x=6)
    assert obj.a == 3
    assert obj.b == 4

# Generated at 2022-06-23 16:57:03.674489
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # type: () -> None
    class TestClass:
        def __init__(self, a: str, b: str, c: str = "123"):
            setattr(self, "a", a)
            setattr(self, "b", b)
            setattr(self, "c", c)

    test_init = _IgnoreUndefinedParameters.create_init(TestClass)
    test_object = test_init(TestClass, "1", "2")
    assert getattr(test_object, "a") == "1"
    assert getattr(test_object, "b") == "2"
    assert getattr(test_object, "c") == "123"

    test_object = test_init(TestClass, "1", "2", "3", d="4")

# Generated at 2022-06-23 16:57:16.317344
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Foo:
        foo: int

        def __init__(self, foo: int, **kwargs) -> None:
            self.unknown_kwargs = kwargs
            self.foo = foo

    obj = Foo(1)
    assert obj.unknown_kwargs == {}

    init = _CatchAllUndefinedParameters.create_init(obj)
    obj = init(foo=1)
    assert obj.unknown_kwargs == {}

    init = _IgnoreUndefinedParameters.create_init(obj)
    obj = init(foo=1)
    assert obj.unknown_kwargs == {}

    init = _RaiseUndefinedParameters.create_init(obj)
    obj = init(foo=1)
    assert obj.unknown_kwargs == {}

    init = _Catch

# Generated at 2022-06-23 16:57:22.189288
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: str
        b: str
        c: str
        catch_all: Optional[CatchAllVar] = None

    given = dict(a="A", b="B", c="C", d="D")
    result = _IgnoreUndefinedParameters.handle_from_dict(
        Test, given)
    expected = dict(a="A", b="B", c="C")
    assert result == expected



# Generated at 2022-06-23 16:57:26.821021
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Simple unit test that tests if the _IgnoreUndefinedParameters.create_init
    method works as expected.
    """
    class Foo:
        def __init__(self, a: int, b: int, c: int, d: int) -> None:
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    unittest.main()

# Generated at 2022-06-23 16:57:38.175873
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json import config
    import dataclasses
    from dataclasses import dataclass

    @dataclass
    class ClassWithoutCatchAll:
        a: str
        b: str

    @dataclass
    class ClassWithCatchAll:
        a: str
        b: str
        _catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None,
            metadata=config.Meta(field_name="_catch_all"))

    example_kvs_without_undefined = {"a": "a_value", "b": "b_value"}
    example_kvs_with_undefined = {"a": "a_value", "b": "b_value",
                                  "c": "c_value"}

    result = _IgnoreUndefinedParameters.handle_

# Generated at 2022-06-23 16:57:41.422973
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Foo:
        pass

    with pytest.raises(TypeError):
        _CatchAllUndefinedParameters.handle_to_dict(Foo, {'a': 1})



# Generated at 2022-06-23 16:57:53.109823
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a):
            self.a = a

    @dataclasses.dataclass
    class Bar:
        a: str
        b: str

    # case 1: ignore undefined parameters
    # Also check that only defined parameters are passed on to the object
    parameters = {"a": "hello", "b": "b"}
    result = _IgnoreUndefinedParameters.handle_from_dict(Foo, parameters)
    assert result == {"a": "hello"}

    # case 2: ignore undefined parameters in dataclass
    result = _IgnoreUndefinedParameters.handle_from_dict(Bar, parameters)
    assert result == {"a": "hello", "b": "b"}

    # case 3: catchall is allowed, but ignored
    # Also check that only defined parameters are passed on to the object

# Generated at 2022-06-23 16:58:05.913279
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class ParameterizedObject(dataclasses_json.DataClassJsonMixin):
        attr1: int
        attr2: int
        extra_attributes: dataclasses_json.CatchAll = dataclasses.field(
            default_factory=dict)

    object_1 = ParameterizedObject(attr1=1, attr2=2, attr3=3)
    assert object_1.attr1 == 1
    assert object_1.attr2 == 2
    assert object_1.extra_attributes["attr3"] == 3

    object_2 = ParameterizedObject(attr1=1, attr2=2)
    assert isinstance(object_2.extra_attributes, dict)

# Generated at 2022-06-23 16:58:08.573930
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs = {"a": 1, "b": 2, "c": 3, "e": 5}
    result = _IgnoreUndefinedParameters.handle_from_dict(int, kvs)
    assert result == {}



# Generated at 2022-06-23 16:58:10.857948
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():  # noqa: D103
    # noinspection PyAbstractClass
    class MockAction(_UndefinedParameterAction):
        pass

    with pytest.raises(TypeError):
        MockAction.handle_from_dict(MockAction, {})

# Generated at 2022-06-23 16:58:17.764774
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass(
        ordered=True,
        unsafe_hash=True,
        unknown_parameters=_CatchAllUndefinedParameters)
    class Example:
        a: int
        b: int
        c: int = 1
        _c_: int = 2
        catch_all: CatchAll = None

    class_fields = fields(Example)
    field_names = [field.name for field in class_fields]

    def _separate_defined_undefined_kvs(kvs: Dict) -> \
            Tuple[KnownParameters, UnknownParameters]:
        unknown_given_parameters = {k: v for k, v in kvs.items() if
                                    k not in field_names}

# Generated at 2022-06-23 16:58:28.095508
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class DummyClass:
        def __init__(self,
                     a,
                     b,
                     c,
                     d):
            pass

    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=DummyClass,
            kvs={"a": 1, "b": "", "c": True, "d": 0.0, "e": None})

    assert known_given_parameters == {"a": 1, "b": "", "c": True, "d": 0.0}
    assert unknown_given_parameters == {"e": None}



# Generated at 2022-06-23 16:58:40.107678
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import sys
    import json
    import unittest
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, Undefined, config, LetterCase

    @dataclass_json(letter_case=LetterCase.CAMEL,
                    undefined=Undefined.INCLUDE)
    @dataclass
    class Example:
        defined: int = 0
        undefined: Optional[CatchAllVar] = None

    class _HandleToDictTest(unittest.TestCase):
        def runTest(self):
            example = Example(defined=1, undefined={"a": 2}, b=3)
            """
            The undefined variable must not be affected by the letter case.
            """
            result = json.loads(json.dumps(example, cls=config.Encoder))
           

# Generated at 2022-06-23 16:58:45.638462
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, b: int, c: int, d: int, e: int, f: int,
                     g: int, h: int, i: int, j: int, k: int, l: int,
                     m: int, n: int, o: int, p: int, q: int, r: int,
                     s: int, t: int, u: int, v: int, w: int, x: int,
                     y: int, z: int):
            pass

    func = _IgnoreUndefinedParameters.create_init(A)
    assert func is not A.__init__

# Generated at 2022-06-23 16:58:46.718104
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 16:58:48.544216
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 16:59:01.536220
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def _check_init(obj):
        obj.__init__(123)  # should fail without error
        obj = obj(123)  # should fail without error

    catch_all = CatchAllVar()
    lst: List[int] = []
    lst2: List[int] = []
    lst_default: List[int] = [0]

# Generated at 2022-06-23 16:59:03.615172
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()
    UndefinedParameterError("testing")

# Generated at 2022-06-23 16:59:09.358954
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    class TestClass:
        field1: str = "default"
        field2: int = 123
        field3: float = 456.0

    test_dict = dict(field1="value1", field2=456, field3=789.0, field4="value2")
    expected = dict(field1="value1", field2=456, field3=789.0)
    defined, undefined = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=test_dict)
    assert defined == expected
    assert undefined == dict(field4="value2")

# Generated at 2022-06-23 16:59:16.742669
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass1:
        def __init__(self, *, field1: str, **kwargs: CatchAll):
            self.field1 = field1
            self.catch_all = kwargs

        def __repr__(self):
            return f"<{self.__class__.__name__} " \
                   f"field1={self.field1} " \
                   f"catch_all={self.catch_all}>"

    test_class1 = TestClass1(field1="test", test_double_underscore="test2")
    result = _CatchAllUndefinedParameters.handle_dump(test_class1)
    expected_result = {"test_double_underscore": "test2"}
    assert result == expected_result

    # Test with no undefined parameters

# Generated at 2022-06-23 16:59:21.631367
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Wrapper:
        def __init__(self, a, catch_all=None):
            self.a = a
            self.catch_all = catch_all


    _CatchAllUndefinedParameters.handle_from_dict(Wrapper, {"a": 1})

# Generated at 2022-06-23 16:59:33.399025
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, param_1: int, param_2: int, param_3: int):
            self.param_1 = param_1
            self.param_2 = param_2
            self.param_3 = param_3

    test_kvs = {"param_1": 12, "param_2": 15, "param_3": 20, "extra": "not_used"}

    result = _IgnoreUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs=test_kvs)
    assert result == {"param_1": 12, "param_2": 15, "param_3": 20}



# Generated at 2022-06-23 16:59:45.094575
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # noinspection PyUnresolvedReferences
    from dataclasses import dataclass, field
    @dataclass
    class Example:
        a: int = field(default=42)
        catch_all: CatchAll = field(default=None)

    x = Example.__init__
    assert callable(x)
    assert x.__name__ == "_catch_all_init"
    assert x.__doc__ == Example.__init__.__doc__
    assert x.__module__ == Example.__init__.__module__

    y = Example()
    assert vars(y) == {'a': 42, 'catch_all': {}}
    y = Example(a=3, b=4)
    assert vars(y) == {'a': 3, 'catch_all': {'b': 4}}
   

# Generated at 2022-06-23 16:59:51.269525
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class ClassWithNoCatchAll:
        pass

    @dataclass
    class ClassWithCatchAll:
        catch_all: CatchAll = None

    try:
        _CatchAllUndefinedParameters.handle_dump(ClassWithNoCatchAll())
        fail()  # pragma: no cover
    except UndefinedParameterError:
        pass

    catch_all = _CatchAllUndefinedParameters.handle_dump(
        ClassWithCatchAll())
    assert isinstance(catch_all, dict) is True



# Generated at 2022-06-23 16:59:57.481257
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class MyClass:
        pass

    @dataclasses.dataclass
    class MyDataClass:
        a: int = dataclasses.field(
            metadata={"marshmallow_field": "a", "data_key": "a"})
        b: int = dataclasses.field(
            metadata={"marshmallow_field": "b", "data_key": "b"})

    assert _UndefinedParameterAction.handle_from_dict(
        MyClass, {"a": 1}) == {"a": 1}
    assert _UndefinedParameterAction.handle_from_dict(
        MyDataClass, {"a": 1}) == {"a": 1}

# Generated at 2022-06-23 17:00:04.148141
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Test:
        a: int
        b: str = "default"
        c: CatchAll = None

    obj = Test(1, "hello", {"d": 2})
    dump = _CatchAllUndefinedParameters.handle_dump(obj)
    assert dump == {"d": 2}

# Generated at 2022-06-23 17:00:15.929046
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class ClassWithDumpTest:
        catch_all: CatchAll = \
            dataclasses.field(default=CatchAllVar())

    c = ClassWithDumpTest()
    expected = {}
    result = _CatchAllUndefinedParameters.handle_dump(c)
    assert expected == result

    c.catch_all["some_key"] = 3
    expected = {"some_key": 3}
    result = _CatchAllUndefinedParameters.handle_dump(c)
    assert expected == result

# Generated at 2022-06-23 17:00:28.636496
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses


    @dataclasses.dataclass(frozen=True)
    class IgnoredUndefinedParameters:
        a: int
        b: int = dataclasses.field(default=0)
        c: int = dataclasses.field(default=1)
        d: int = dataclasses.field(default=2)
    kwargs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
    expected = {"a": 1, "b": 2, "c": 3, "d": 4}

    init = _IgnoreUndefinedParameters.create_init(IgnoredUndefinedParameters)
    result = init(IgnoredUndefinedParameters(**kwargs))
    assert expected == result.__dict__



# Generated at 2022-06-23 17:00:40.930938
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {'a': 5}) == {'a': 5}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {'a': 5, 'b': 6}) == {
                                                          'a': 5, 'b': 6}
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                      {'a': 5, 'c': 6}) == {
                                                          'a': 5}


# Generated at 2022-06-23 17:00:54.936691
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a, b, c, d=1, e=2, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.kwargs = kwargs

    result = _CatchAllUndefinedParameters.handle_to_dict(TestClass,
                                                         {
                                                             "a": 1,
                                                             "b": 2,
                                                             "c": 3,
                                                             "d": 4,
                                                             "e": 5,
                                                             "kwargs": {
                                                                 "f": 6,
                                                                 "g": 7}
                                                         })


# Generated at 2022-06-23 17:01:02.988742
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": 2, "c": 3}
    result = _UndefinedParameterAction.handle_from_dict(cls=TestClass, kvs=kvs)
    assert result == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-23 17:01:07.346818
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Foo:
        def __init__(self, foo: int, bar: str,
                     undefined: Optional[CatchAllVar] = None):
            self.foo, self.bar, self.undefined = foo, bar, undefined

    foo = Foo(1, "foo", {"baz": "baz"})


# Generated at 2022-06-23 17:01:12.725420
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a, b, c=1, d=2):
            pass

    init = _IgnoreUndefinedParameters.create_init(obj=A)
    init(None, 1, 2, c=3, d=4, e=5)

# Generated at 2022-06-23 17:01:21.375364
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, catch_all: Optional[CatchAllVar]):
            self.catch_all = catch_all
            pass

    obj = TestClass({"a": 1, "b": 2})
    output = _CatchAllUndefinedParameters.handle_to_dict(obj,
                                                         {"a": 1, "b": 2})
    assert output == {"a": 1, "b": 2}

# Generated at 2022-06-23 17:01:30.294239
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Dummy(metaclass=DataClassJson):
        __undefined_parameter_action__ = Undefined.RAISE

        a: str
        b: str

    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=Dummy,
            kvs={"a": "aval", "b": "bval", "c": "cval"})
    assert known_given_parameters == {"a": "aval", "b": "bval"}
    assert unknown_given_parameters == {"c": "cval"}

# Generated at 2022-06-23 17:01:36.971888
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str

    kvs = {"a": 1, "b": "b", "c": 3}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)

    assert known_parameters == {"a": 1, "b": "b"}
    assert unknown_parameters == {"c": 3}



# Generated at 2022-06-23 17:01:42.949573
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Foo:
        bar: str

    test_instance = Foo("baz")

    _RaiseUndefinedParameters.handle_from_dict(Foo, {"bar": "baz"})
    try:
        _RaiseUndefinedParameters.handle_from_dict(Foo, {"bar": "baz", "qux":2})
        assert False, "Expecting exception"
    except UndefinedParameterError:
        pass

    assert _RaiseUndefinedParameters.handle_to_dict(test_instance,
                                                    {"bar": "baz"}) == {"bar":"baz"}
    assert _RaiseUndefinedParameters.handle_to_dict(test_instance,
                                                    {"bar": "baz", "qux":2}) == {"bar": "baz"}


# Generated at 2022-06-23 17:01:53.752841
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: str

    t = Test("1", "2")
    assert _UndefinedParameterAction.handle_to_dict(t,
                                                    {"a": "1", "b": "2"}) == {
               "a": "1", "b": "2"}
    assert _IgnoreUndefinedParameters.handle_to_dict(t,
                                                     {"a": "1", "b": "2"}) == {
               "a": "1", "b": "2"}
    assert _RaiseUndefinedParameters.handle_to_dict(t,
                                                    {"a": "1", "b": "2"}) == {
               "a": "1", "b": "2"}
    assert _CatchAllUnd

# Generated at 2022-06-23 17:01:56.448171
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Tests for the abstract base class.
    :return:
    """
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 17:02:06.184755
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import config

    class _GeneralTestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dict)  # type: ignore

        def __init__(self, **kwargs):
            pass

    test_object = _GeneralTestClass()
    test_object.catch_all = {"a": 1, "b": 2}
    test_dict = {"x": "y"}
    config.undefined = Undefined.INCLUDE
    result_dict = \
        _CatchAllUndefinedParameters.handle_to_dict(obj=test_object,
                                                    kvs=test_dict)
    assert result_dict == {"a": 1, "b": 2, "x": "y"}


# Generated at 2022-06-23 17:02:13.072985
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    fields = [
        Field("field1", type=int),
        Field("field2", type=int),
    ]

    # noinspection PyAbstractClass
    class MockClass:
        def __init__(self, *args, **kwargs):
            pass

    MockClass.__dataclass_fields__ = fields
    MockClass.__dataclass_params__ = {"undefined": Undefined.RAISE}

    # Given
    given_arguments = {"field1": 5, "field2": 10}

    # When
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(
            cls=MockClass,
            kvs=given_arguments,
        )



# Generated at 2022-06-23 17:02:25.016760
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Foo(metaclass=abc.ABCMeta):
        def __init__(self, foo: str = "Hello", baz: str = "Test",
                     **_):
            pass

    assert _IgnoreUndefinedParameters.handle_from_dict(Foo, {"foo": "test"}) == {
               "foo": "test"}

    assert _IgnoreUndefinedParameters.handle_from_dict(Foo, {
               "foo": "test",
               "bar": "Nope"}) == {"foo": "test"}


# Generated at 2022-06-23 17:02:36.233768
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class _TestDataClass:
        a: int
        b: int
        c: int = dataclasses.field(default=1)

    @dataclasses.dataclass
    class _TestDataClassWithCatchAll:
        a: int
        b: int
        c: int = dataclasses.field(default=1)
        d: Optional[CatchAllVar] = dataclasses.field(default=None)

    @dataclasses.dataclass
    class _TestDataClassWithCatchAllAndDefault:
        a: int
        b: int
        c: int = dataclasses.field(default=1)
        d: Optional[CatchAllVar] = dataclasses.field(default=dict())


# Generated at 2022-06-23 17:02:41.225769
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():

    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = CatchAll()

    instance = TestClass()
    undefined = _CatchAllUndefinedParameters.handle_dump(instance)
    assert len(undefined) == 0

    instance.c["d"] = 3
    instance.c["e"] = 4
    undefined = _CatchAllUndefinedParameters.handle_dump(instance)
    assert len(undefined) == 2
    assert {"d", "e"} == set(undefined.keys())

# Generated at 2022-06-23 17:02:49.728803
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Foo:
        name: str
        age: int
        title: str = "Dr."
        catch_all: Optional[CatchAllVar] = None

    assert (_CatchAllUndefinedParameters.handle_from_dict(Foo, {
        "name": "Alice", "age": 19,
        "catch_all": {"Hobbies": ["Swimming", "Running"], "BirthPlace": "Berlin"}}) ==
            {"name": "Alice", "age": 19,
             "catch_all": {"Hobbies": ["Swimming", "Running"], "BirthPlace": "Berlin"},
             "title": "Dr."})


# Generated at 2022-06-23 17:02:59.300624
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():

    @dataclasses.dataclass
    class DummyClass:
        catch_all: Optional[CatchAllVar]

    _CatchAllUndefinedParameters.handle_from_dict(DummyClass, dict())
    _CatchAllUndefinedParameters.handle_from_dict(DummyClass,
                                                  dict(key1="value1"))
    _CatchAllUndefinedParameters.handle_from_dict(DummyClass,
                                                  dict(catch_all=dict(key1="value1")))
    _CatchAllUndefinedParameters.handle_from_dict(
        DummyClass, dict(key1="value1",
                         catch_all="ignore"))

# Generated at 2022-06-23 17:03:03.731100
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    from marshmallow import Schema, fields
    from marshmallow.validate import Length

    try:
        class TestSchema(Schema):
            name = fields.Str(required=True)

        TestSchema().load({"name": "Joe"})
    except ValidationError as e:
        if "required_fields" in e.messages:
            print("Of course some fields are missing!")
        else:
            print(e)

    try:
        class NameSchema(Schema):
            name = fields.Str(validate=Length(min=2))

        NameSchema().load({"name": "a"})
    except ValidationError as e:
        print(e.messages)

# Generated at 2022-06-23 17:03:12.035929
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class MyClass:
        field1: str
        field2: str = "field2 default"
        catch_all: CatchAll = dataclasses.field(  # type: ignore[no-untyped-def]
            default_factory=dict)

    catch_all_init = _CatchAllUndefinedParameters.create_init(MyClass)
    obj = MyClass("field1", "field2")
    assert obj.field1 == "field1"
    assert obj.field2 == "field2"
    assert obj.catch_all == {}

    obj2 = MyClass("field1")
    assert obj2.field1 == "field1"
    assert obj2.field2 == "field2 default"
    assert obj2.catch_all == {}


# Generated at 2022-06-23 17:03:13.198872
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:03:17.708694
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Example:
        def __init__(self, a: int, b: int = 3, catch_all=Undefined.EXCLUDE):
            print("hi")

    init = _IgnoreUndefinedParameters.create_init(Example)
    init(Example, 1, y=2, y2=3)

# Generated at 2022-06-23 17:03:20.919296
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    a = dataclasses.make_dataclass('A', {"x": int, "y": int})
    kvs = {"x": 3}
    expected = {"x": 3}
    assert _UndefinedParameterAction.handle_from_dict(a, kvs) == expected
    assert _UndefinedParameterAction.handle_from_dict(a, {}) == {}



# Generated at 2022-06-23 17:03:28.173980
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        name: str
        age: int
        other: Optional[dataclasses_json.CatchAll] = None

    t1 = TestClass.from_dict({'name': 'John Doe', 'age': 42})
    assert t1.name == 'John Doe'
    assert t1.age == 42
    assert isinstance(t1.other, dict)
    assert not len(t1.other)

    t2 = TestClass.from_dict({'name': 'John Doe', 'age': 42, 'occupation':
        'Professor'})
    assert t2.name == 'John Doe'
    assert t2.age == 42
    assert len(t2.other)
    assert t2.other['occupation'] == 'Professor'

    t3 = TestClass

# Generated at 2022-06-23 17:03:36.658287
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    kvs = {'a': 5, 'b': 7, 'c': 10, 'd': 15}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, kvs)
    assert known == {'a': 5, 'b': 7, 'c': 10}
    assert unknown == {'d': 15}

# Generated at 2022-06-23 17:03:48.913413
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # root cause: no catch-all field
    class A:
        def __init__(self, a, b):
            self.a = a
            self.b = b


    with pytest.raises(UndefinedParameterError,
                       match="No field of type dataclasses_json.CatchAll"):
        _CatchAllUndefinedParameters.handle_from_dict(A, {'a': 1, 'b': 2})

    # root cause: multiple catch-all fields
    class B:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
        catchall: CatchAll = None
        catchall2: CatchAll = None



# Generated at 2022-06-23 17:03:53.037404
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        a: int
        b: str

    params = {"a": 1}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, params)
    assert known == params
    assert unknown == {}



# Generated at 2022-06-23 17:03:59.963792
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a):
            self.a = a

    t = TestClass(a=1)
    undefined_parameter = {"b": 2}
    kvs = _IgnoreUndefinedParameters.handle_from_dict(TestClass,
                                                      {"a": t.a,
                                                       **undefined_parameter})
    assert kvs == {"a": 1}



# Generated at 2022-06-23 17:04:09.901890
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import json

    from marshmallow import Schema, fields

    from dataclasses_json import DataClassJsonMixin, config

    @dataclasses.dataclass(init=False)
    class ClassWithCatchAll(DataClassJsonMixin):
        my_defined: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.field(default_factory=dict))

    config.undefined = Undefined.INCLUDE

    class MySchema(Schema):
        my_defined = fields.Str()

    obj = ClassWithCatchAll("my_defined")
    obj.catch_all["a"] = "A"
    obj.catch_all["b"] = "B"
    dumped = obj.to_json()


# Generated at 2022-06-23 17:04:20.412813
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        _undefined_parameters = CatchAll

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    a = A(a=1, b=2)
    a_init = _CatchAllUndefinedParameters.create_init(a)
    a_init(a, a=1, b=2, c=3, d=4, e=5)
    assert(a.a == 1)
    assert(a.b == 2)
    assert(a._undefined_parameters == {"c": 3, "d": 4, "e": 5})

# Generated at 2022-06-23 17:04:27.038072
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from unittest import mock
    from dataclasses import dataclass

    @dataclass
    class TestCatchAll:
        non_strange_field: str
        all_the_rest: CatchAll = None
        default_factory: Callable[[], str] = mock.Mock(return_value="hello")

    _CatchAllUndefinedParameters.create_init(TestCatchAll)



# Generated at 2022-06-23 17:04:34.064532
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    Test the handle_from_dict method to make sure that it raises
    UndefinedParametersError if it encounters an undefined parameter.
    """
    from dataclasses import dataclass
    from dataclasses_json.config import Config

    @dataclass
    class _DummyClass:
        defined_param: str
        undefined_param: str = "should never see this"

    config = Config.none()
    config = config.copy(undefined_parameter_action=Undefined.RAISE)
    # noinspection PyTypeChecker
    d = _DummyClass(config=config, defined_param="test")
    assert d.defined_param == "test"


# Generated at 2022-06-23 17:04:41.621219
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, field1, field2: CatchAll = None):
            self.field1 = field1
            self.field2 = field2

    test_instance = TestClass("field1", {"field2": "value2"})
    assert \
        _CatchAllUndefinedParameters.handle_to_dict(test_instance,
                                                    {"field1": "field1"}) == \
        {"field1": "field1", "field2": "value2"}

    test_instance = TestClass("field1", {"field2": "value2"})

# Generated at 2022-06-23 17:04:52.840249
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # type: () -> None
    @dataclasses.dataclass(frozen=True)
    class Foo:
        a: int
        b: int
        c: int

    # First case: no undefined parameters found
    known_params, unknown_params = {'a': 1, 'b': 2, 'c': 3}, {}
    returned_params = _RaiseUndefinedParameters.handle_from_dict(Foo,
                                                                  known_params)
    assert returned_params == known_params

    # Second case: no undefined parameters found
    known_params, unknown_params = {'a': 1, 'b': 2, 'c': 3}, {'d': 4, 'e': 5}

# Generated at 2022-06-23 17:05:01.268261
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass(frozen=True)
    class A:
        a = dataclasses.field(default=1, metadata=dict())

    @dataclasses.dataclass(frozen=True)
    class B(A):
        b = dataclasses.field(default=2, metadata=dict())

    kvs = dict(a=3, b=4)
    kvs_result = dict(a=3, b=4)
    assert _UndefinedParameterAction.handle_to_dict(B(), kvs) == kvs_result



# Generated at 2022-06-23 17:05:07.591202
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class TestObj:
        a: int
        b: int
        c: str
        catch_all: Optional[CatchAllVar] = None

    obj = TestObj(a=1, b=2, c="three", catch_all={
        "_QQQ": "222"
    })
    handle_to_dict = _CatchAllUndefinedParameters.handle_to_dict
    assert handle_to_dict(obj, {"a": 1, "b": 2, "c": "three", "_QQQ": "222"})



# Generated at 2022-06-23 17:05:15.638968
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test(object):
        def __init__(self, a: int, b: int = 42):
            pass

    obj = Test(42)
    original_init = obj.__init__
    assert original_init is not _IgnoreUndefinedParameters.create_init(obj)
    assert original_init(obj, 99) is None

    with pytest.raises(TypeError):
        original_init(obj, 99, 99)

    # noinspection PyTypeChecker
    modified_init = _IgnoreUndefinedParameters.create_init(obj)
    # noinspection PyTypeChecker
    assert modified_init(obj, 99, 99, undefined=1) is None

# Generated at 2022-06-23 17:05:21.283710
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        a: int
        b: int

    class TestClass2:
        a: int
        b: int
        CatchAllVar: CatchAllVar

    assert _UndefinedParameterAction.handle_from_dict(TestClass, {"a": 1,
                                                                   "b": 2}) == {"a": 1,
                                                                                 "b": 2}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, {"a": 1,
                                                                   "b": 2,
                                                                   "c": 3}) == {"a": 1,
                                                                                 "b": 2}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, {"a": 1,
                                                                   "c": 3}) == {"a": 1}

# Generated at 2022-06-23 17:05:24.237669
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    class S:
        pass
    try:
        raise UndefinedParameterError(S, "foo")
    except ValidationError:
        pass

# Generated at 2022-06-23 17:05:31.517013
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: str = "default"):
            pass

    given_parameters = {"a": "test", "b": 5, "c": "not_default"}
    expected_parameters = {"a": "test", "b": 5, "c": "not_default"}

    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, given_parameters) == expected_parameters