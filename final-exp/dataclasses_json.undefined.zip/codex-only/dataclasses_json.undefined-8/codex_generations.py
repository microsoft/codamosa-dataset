

# Generated at 2022-06-23 16:55:40.998943
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():

    # Note: This test does not test if the field with name
    # "__undefined_parameters" is present in the final dict but tests if things
    # are handled correctly if it isn't.
    from dataclasses import asdict
    from dataclasses_json import dataclass_json

    # End user facing code:
    @dataclass_json(undefined=Undefined.INCLUDE)
    class User:
        a: str
        b: int
        __undefined_parameters: Optional[CatchAllVar] = None

    valid_kvs = {"a": "test", "b": 42, "c": 12}
    expected_output = {"a": "test", "b": 42, "c": 12}
    User_kvs = asdict(User(**valid_kvs))
    assert User_k

# Generated at 2022-06-23 16:55:41.812585
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    pass

# Generated at 2022-06-23 16:55:46.551048
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Unit test for constructor of class _UndefinedParameterAction
    """
    try:
        _ = _UndefinedParameterAction()
        raise Exception("Abstract base class can not be instantiated")
    except TypeError:
        pass

# Generated at 2022-06-23 16:55:52.423942
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def func(x: int, y: int, *, a: int = 0, b: int = 0, **kwargs) -> str:
        return str(x + y + a + b)

    new_func = _IgnoreUndefinedParameters.create_init(func)
    assert new_func(1, 2, a=3) == "6"
    assert new_func(1, 2, a=3, b=4, z=5) == "6"

# Generated at 2022-06-23 16:56:03.490158
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Note: if this test does not pass, there is no guarantee
    # that the hand-written code will work either.

    class ClassWithCatchAll:
        def __init__(self, a: str, b: str, c: str,
                     catch_all: CatchAll = None):
            ...

    class ClassWithoutCatchAll:
        def __init__(self, a: str, b: str):
            ...

    @functools.wraps(ClassWithCatchAll.__init__)
    def with_catch_all_init(self, a, b, c=3, **kwargs):
        self.a = a
        self.b = b
        self.c = c
        self.kwargs = kwargs

    with_catch_all = ClassWithCatchAll("a", "b", "c")

# Generated at 2022-06-23 16:56:08.540848
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=int, kvs={1: 1, 2: 2}) == {1: 1, 2: 2}



# Generated at 2022-06-23 16:56:09.020126
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _ = _UndefinedParameterAction()

# Generated at 2022-06-23 16:56:19.011887
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import get_type_hints

    from marshmallow import fields, Schema

    from .common import CommonSchema
    from dataclasses_json import DataClassJsonMixin, config

    class DummyValueError(Exception):
        pass

    some_dict = {"a": 1, "b": 2, "c": 3, "d": 4}

    class _Dummy1:
        def __init__(self, a: int, b: int, **kwargs):
            raise DummyValueError()

    class _Dummy2:
        def __init__(self, a: int, b: int, c: int, d: int = 1, **kwargs):
            pass

    def _check_signature_and_raises(_Dummy, **expected):
        args, _, _, defaults = inspect.getargspec

# Generated at 2022-06-23 16:56:26.053224
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a, b, c=1):
            pass

    kvs_with_c = {"a": 1, "b": 2, "c": 3}
    kvs_without_c = {"a": 1, "b": 2}
    assert kvs_with_c == _IgnoreUndefinedParameters.handle_from_dict(Foo,
                                                                      kvs_with_c)
    assert kvs_without_c == _IgnoreUndefinedParameters.handle_from_dict(Foo,
                                                                        kvs_without_c)

# Generated at 2022-06-23 16:56:29.315001
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    action = _IgnoreUndefinedParameters()
    assert(action is not None)

# Generated at 2022-06-23 16:56:37.275590
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class UnknownClass:
        def __init__(self, unknown_param, known_param=9):
            self.unknown_param = unknown_param
            self.known_param = known_param

    new_init = _IgnoreUndefinedParameters.create_init(UnknownClass)
    test_obj = UnknownClass.__new__(UnknownClass)
    new_init(test_obj, 8, known_param=0, unknown_param=9)
    assert test_obj.known_param == 0
    assert not hasattr(test_obj, "unknown_param")

# Generated at 2022-06-23 16:56:40.457043
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert {} == _UndefinedParameterAction.handle_to_dict(obj=None, kvs={})
    assert {"a": 1} == _UndefinedParameterAction.handle_to_dict(obj=None,
                                                                kvs={"a": 1})
    assert {"a": 1, "b": 2} == _UndefinedParameterAction.handle_to_dict(
        obj=None, kvs={"a": 1, "b": 2})



# Generated at 2022-06-23 16:56:52.457646
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class MyClass:
        def __init__(self, a, b, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = MyClass(1, 2, 3, 4)

    # No changes
    original_class = MyClass
    assert _UndefinedParameterAction.create_init(original_class) is \
           original_class.__init__
    # Nothing changes
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4

    # Use undefined parameter action ignore
    ignore_init = \
        _UndefinedParameterAction.create_init(_IgnoreUndefinedParameters)

# Generated at 2022-06-23 16:56:59.863217
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, foo):
            self.foo = foo

    tf = TestClass(foo=2)
    assert tf.foo == 2

    data = {'foo': 2}
    tf = TestClass(**data)
    assert tf.foo == 2

    data = {'foo': 2, 'bar': "joda"}
    try:
        tf = TestClass(**data)
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:57:11.238208
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    result = _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                        {"a": 1, "b": 2, "c": 3, "d": 4})
    assert result == {"a": 1, "b": 2, "c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {"a": 1,
                                                               "b": 2, "c": 3,
                                                               "d": 4,
                                                               "e": 5})



# Generated at 2022-06-23 16:57:17.043419
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError(msg='Test UndefinedParameterError', ctx=None,
                            field_names=None, fields=None)
    UndefinedParameterError(msg='Test UndefinedParameterError', ctx=dict(),
                            field_names=None, fields=None)
    UndefinedParameterError(msg='Test UndefinedParameterError', ctx=None,
                            field_names=list(), fields=None)
    UndefinedParameterError(msg='Test UndefinedParameterError', ctx=None,
                            field_names=None, fields=dict())



# Generated at 2022-06-23 16:57:18.623637
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}



# Generated at 2022-06-23 16:57:27.393683
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert True
    # class A:
    #     def __init__(self, a=None, **kwargs):
    #         pass

    # class B(A):
    #     pass

    # @dataclasses.dataclass
    # class C(B):
    #     c: int
    #
    #     def __init__(self, a=None, **kwargs):
    #         super().__init__(a, **kwargs)
    #
    # @dataclasses.dataclass
    # class D(C):
    #     d: int
    #
    #     def __init__(self, a=None, **kwargs):
    #         super().__init__(a, **kwargs)
    #
    # @dataclasses.dataclass
    # class E(D):

# Generated at 2022-06-23 16:57:30.597252
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a, b):
            pass

    assert _UndefinedParameterAction.handle_dump(TestClass) == {}

# Generated at 2022-06-23 16:57:31.974303
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction._UndefinedParameterAction()

# Generated at 2022-06-23 16:57:39.852450
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class MyClass:
        def __init__(self, **_unknown):
            self._unknown = _unknown

    my_obj = MyClass(**{"a": 1, "b": 2, "c": 3})
    assert my_obj._unknown == {"a": 1, "b": 2, "c": 3}
    expected = {"a": 1, "b": 2, "c": 3}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(my_obj, my_obj._unknown)
    assert kvs == expected
    assert my_obj._unknown == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-23 16:57:52.212390
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from marshmallow import Schema

    from dataclasses_json.utils import CatchAllVar


    @dataclass
    class Test:
        a: int = 1
        b: str = "def"
        c: int = 2
        missing: Optional[CatchAllVar] = None

    init = _CatchAllUndefinedParameters.create_init(Test)
    t = init(None, c=3, d=4, e=6)
    assert t.a == 1
    assert t.b == "def"
    assert t.c == 3
    assert t.missing == {"d": 4, "e": 6}

    @dataclass
    class Test:
        a: int = 1
        b: str = "def"
        c: int = 2
        missing: Catch

# Generated at 2022-06-23 16:57:53.402871
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-23 16:58:05.996597
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: int, b: int):
            pass

    assert A(1, 2) is not None

    class B:
        def __init__(self, a: int, b: int, c: int):
            pass

    try:
        B(1, 2, 3)
        assert False
    except TypeError:
        pass

    class C:
        def __init__(self, a: int, b: int):
            pass

    assert C(1, 2) is not None
    try:
        C(1, 2, 3)
        assert False
    except TypeError:
        pass

    class D:
        def __init__(self, a: int, b: int):
            pass


# Generated at 2022-06-23 16:58:10.170029
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class a:
        __undefined_parameters__ = _UndefinedParameterAction.create_init(a)

        def __init__(self, a, b, c):
            pass



# Generated at 2022-06-23 16:58:17.537521
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass
    class TestDump:
        a: int = 1
        b: int = 2
        c: int = 3
        undefined: CatchAll = None

    print(TestDump)
    print(TestDump(a=1, b=2, c=3, undefined={'abc': 123, 'def': 345}))
    dump = _UndefinedParameterAction.handle_dump(
        TestDump(a=1, b=2, c=3, undefined={'abc': 123, 'def': 345}))
    assert dump == {}

    dump = _UndefinedParameterAction.handle_dump(
        TestDump(a=1, b=2, c=3, undefined={}))
    assert dump == {}


# Generated at 2022-06-23 16:58:26.616438
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    import pytest
    class Foo:
        a: int

        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    obj = Foo(42, 13, 37)
    kvs = {"a": 42, "b": 13, "c": 37}
    output = _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert output == {"a": 42, "b": 13, "c": 37}



# Generated at 2022-06-23 16:58:29.619786
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, foo: str, bar: str, **kwargs):
            pass

    test = TestClass("foo", "bar", baz="baz")
    assert test.foo == "foo"
    assert test.bar == "bar"



# Generated at 2022-06-23 16:58:35.546678
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, param1=None, param2=None):
            self.param1 = param1
            self.param2 = param2

    a = _IgnoreUndefinedParameters.create_init(A)
    a = a(A(), 10, 20, param2=30, param4=40)
    # param4 should be ignored

    assert a.param1 == 10
    assert a.param2 == 30

    a = _IgnoreUndefinedParameters.create_init(A)(A(), param1=10, param2=20)
    assert a.param1 == 10
    assert a.param2 == 20

    a = _IgnoreUndefinedParameters.create_init(A)(A(), 10)
    assert a.param1 == 10
    assert a.param2 is None

# Generated at 2022-06-23 16:58:36.601074
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test")

# Generated at 2022-06-23 16:58:42.276550
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class _TestClass():
        def __init__(self, **kwargs):
            pass

    class _TestClass1(_TestClass):
        def __init__(self, **kwargs):
            pass

    class _TestClass2(_TestClass):
        def __init__(self, **kwargs):
            pass

    test_instance = _TestClass1()
    test_instance2 = _TestClass2()
    assert _UndefinedParameterAction.handle_dump(test_instance) == {}
    assert _UndefinedParameterAction.handle_dump(test_instance2) == {}

# Generated at 2022-06-23 16:58:43.698015
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}


# Generated at 2022-06-23 16:58:51.268998
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class _TestDataClass:
        a: int
        b: int = dataclasses.field(default=2)

    known_given_parameters, unknown_given_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(
            _TestDataClass, {"a": 1, "b": 2, "c": 3})
    assert known_given_parameters == {"a": 1, "b": 2}
    assert unknown_given_parameters == {"c": 3}

# Generated at 2022-06-23 16:59:02.422030
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, *, a):
            self.a = a

    class B:
        def __init__(self, *, b):
            self.b = b

    class C(A, B):
        def __init__(
                self, *,
                a, b):
            super().__init__(a=a)
            super().__init__(b=b)

    def test(args, expected):
        actual = _IgnoreUndefinedParameters.handle_from_dict(cls=C, kvs=args)
        print(actual)
        assert actual == expected

    test({'a': 1, 'b': 'Foo'}, {'a': 1, 'b': 'Foo'})

# Generated at 2022-06-23 16:59:03.986565
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 16:59:12.928109
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import inspect
    class A(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    init = _IgnoreUndefinedParameters.create_init(A)
    assert len(inspect.signature(init).parameters) == 8

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    a = A(1,2, 3, d=4)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    a = A(1,2, 3, d=4, e=5, g=6)
    assert a.a == 1
    assert a.b == 2
   

# Generated at 2022-06-23 16:59:24.827428
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def create_dataclass(input_args):
        @dataclasses.dataclass
        class DummyClass:
            a: str
            b: int
            c: float
            d: bool

            def __init__(self, a: str, b: int, c: float, d: bool):
                self.initialization_arguments = (a, b, c, d)

        init_function = _IgnoreUndefinedParameters.create_init(DummyClass)
        return init_function(DummyClass(**input_args))


    create_dataclass({'a': 'foo', 'b': 1, 'c': 0.1, 'd': True})
    create_dataclass({'a': 'foo', 'b': 1, 'd': True})

# Generated at 2022-06-23 16:59:34.771941
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs = {
        "defined_field_1": "defined_value_1",
        "undefined_field_1": "undefined_value_1",
        "undefined_field_2": "undefined_value_2",
        "defined_field_2": "defined_value_2"
    }

    class _DummyClass:
        defined_field_1: str
        defined_field_2: str

    expected = {
        "defined_field_1": "defined_value_1",
        "defined_field_2": "defined_value_2"
    }

    result = _IgnoreUndefinedParameters.handle_from_dict(
        cls=_DummyClass,
        kvs=kvs
    )

    assert result == expected

# Generated at 2022-06-23 16:59:40.406348
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, catch_all: Optional[CatchAllVar]):
            self.a = a
            self.catch_all = catch_all

    test_object = TestClass(a=1, catch_all={"b": 2})
    known_parameters = {"a": 1}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(test_object, known_parameters)
    assert kvs["b"] == 2
    assert "catch_all" not in kvs

# Generated at 2022-06-23 16:59:43.133384
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Dummy:
        pass
    obj = Dummy()
    result = _UndefinedParameterAction.handle_to_dict(obj, {"a": 1})
    assert result == {"a": 1}


# Generated at 2022-06-23 16:59:45.081955
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}

# Generated at 2022-06-23 16:59:48.925562
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int, b: str="foo", c: int = 42, **kvs):
            pass

    obj = _IgnoreUndefinedParameters.create_init(obj=TestClass)(
        TestClass, "not_int", "not_foo", "also_not_int", d="not_defined")


# Generated at 2022-06-23 16:59:57.011550
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a: int, b: int = 0):
            self.a = a
            self.b = b

    # noinspection PyArgumentList
    new = _IgnoreUndefinedParameters.create_init(obj=A)

    instances = []

    # Test Zero Args
    instances.append(new(A(5)))
    assert instances[-1].b == 0
    assert instances[-1].a == 5

    # Test Positional Args
    instances.append(new(A(5, b=1)))
    assert instances[-1].b == 1
    assert instances[-1].a == 5

    # Test Unrecognised keyword argument

# Generated at 2022-06-23 17:00:05.832901
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class DummyClass:
        a: int
        b: float
        c: bool
        undefined_parameters: Optional[CatchAllVar] = \
            dataclasses.field(default=None, metadata={"marshmallow_field":
                marshmallow.fields.Dict()})

    input_dict = {"a": 7, "b": 5.5, "c": True, "d": 3}
    _UndefinedParameterAction.handle_from_dict(DummyClass, input_dict)



# Generated at 2022-06-23 17:00:17.415684
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class User:
        def __init__(self, *, name: str, **kwargs):
            self.name = name
            self.undefined = kwargs

    kvs = {
        'name': "John Doe",
        'country': "La-La-Land",
        'city': "Lost in Space"
    }
    u = User(**kvs)
    kvs_original = kvs.copy()
    kvs_out = _CatchAllUndefinedParameters.handle_to_dict(u, kvs)
    assert id(kvs_out) == id(kvs)
    assert kvs_out == kvs_original



# Generated at 2022-06-23 17:00:18.375898
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-23 17:00:23.008671
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Test(_RaiseUndefinedParameters):
        def __init__(self, x: int, y: int, z: str = "it's me"):
            pass



# Generated at 2022-06-23 17:00:23.690990
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction()

# Generated at 2022-06-23 17:00:28.973767
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import inspect
    import functools
    from unittest import mock


    class ClassA:
        pass


    class ClassB:
        pass


    class ClassC:
        pass


    class ClassD:
        pass


    @dataclasses.dataclass
    class Klass:
        a: ClassA
        b: ClassB
        d: Optional[ClassD] = dataclasses.field(default=None)
        ca: Optional[utils.CatchAll] = dataclasses.field(default=None)


    def fails_with(name):
        print(f"FAILED TEST: {name}")
        raise AssertionError(f"FAILED TEST: {name}")



# Generated at 2022-06-23 17:00:29.801446
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    ...

# Generated at 2022-06-23 17:00:41.464902
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from .utils import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        field1: str
        field2: str
        catch_all: CatchAll = dataclasses.field(
            default_factory=dict
        )

    testInstance = TestClass('test1', 'test2')
    assert testInstance.catch_all == {}

    testInstance = TestClass('test1', 'test2', {'test3': 'test4'})
    assert testInstance.catch_all == {'test3': 'test4'}

    testInstance = TestClass('test1', 'test2', catch_all={'test3': 'test4'})
    assert testInstance.catch_all == {'test3': 'test4'}


# Generated at 2022-06-23 17:00:55.180833
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Unit test for method create_init of class _IgnoreUndefinedParameters
    """
    class DummyClass:
        def __init__(self, one: int, two: int = 3):
            pass

    constructor = \
        _IgnoreUndefinedParameters.create_init(obj=DummyClass)
    parameters = constructor(DummyClass(), 1, 3, 4, five=5, six="six")
    assert parameters == {"one": 1, "two": 3}

    constructor = _IgnoreUndefinedParameters.create_init(obj=DummyClass)
    parameters = constructor(DummyClass(), 1, 2, 3)
    assert parameters == {"one": 1, "two": 2}

    constructor = _IgnoreUndefinedParameters.create_init(obj=DummyClass)

# Generated at 2022-06-23 17:01:03.091027
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction.handle_from_dict(None, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}
    assert _UndefinedParameterAction.handle_dump(None) == {}

    # Test create_init
    class TestClass:
        pass

    TestClass.__init__ = lambda x, y: None
    _UndefinedParameterAction.create_init(TestClass)(TestClass, 1)


# Generated at 2022-06-23 17:01:08.004310
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        a: int

    unknown_parameters = {"b": 2}
    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction.handle_from_dict(cls=Test,
                                                   kvs=unknown_parameters)

    known_parameters = {"a": 1}
    returned_parameters = _UndefinedParameterAction.handle_from_dict(
        cls=Test, kvs=known_parameters)
    assert returned_parameters == known_parameters

    mixed_parameters = {"a": 1, "b": 2}
    returned_parameters = _UndefinedParameterAction.handle_from_dict(
        cls=Test, kvs=mixed_parameters)
    assert returned_parameters == known_parameters



# Generated at 2022-06-23 17:01:15.056710
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        x: int
        y: int

    assert _IgnoreUndefinedParameters.handle_from_dict(cls=Foo,
                                                       kvs={"x": 42}) == {"x": 42}
    assert _IgnoreUndefinedParameters.handle_from_dict(cls=Foo,
                                                       kvs={"x": 42, "y": 42}) == {"x": 42, "y": 42}



# Generated at 2022-06-23 17:01:22.367215
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class RaisingClass:
        __undefined_parameter_action__ = Undefined.RAISE
        x = dataclasses.field(default=1)
        y = dataclasses.field(default=2)
        z = dataclasses.field(default=3)

    with pytest.raises(UndefinedParameterError):
        RaisingClass(x=1, y=2, z=3, a=4)

# Generated at 2022-06-23 17:01:27.118270
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, param_1: int, param_2: int, *args, **kwargs):
            self.param_1 = param_1
            self.param_2 = param_2

    test_object = TestClass(1, 2)
    assert test_object.param_1 == 1
    assert test_object.param_2 == 2

# Generated at 2022-06-23 17:01:33.358743
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, test: int, test2: int = 0,
                     test3: int = None):
            pass

    created_init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert created_init.__code__.co_argcount == 2
    assert created_init.__code__.co_varnames == ('self', '_UNKNOWN0')
    created_init(None, 1, 2, 3)
    created_init(None, 1)
    created_init(None)



# Generated at 2022-06-23 17:01:40.629571
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, test: int = 34, catch: Optional[CatchAll] = ()):
            pass

    assert A(3).__init__ == A(test=3).__init__
    assert A(test=1, _UNKNOWN0=2).__init__ == A(1, _UNKNOWN0=2).__init__
    assert A(test=1, _UNKNOWN0=2, catch=3).__init__ != A(1, _UNKNOWN0=2,
                                                        catch=3).__init__
    assert A(test=1, _UNKNOWN0=2, catch=3).__init__ == A(1, _UNKNOWN0=2,
                                                        catch=2).__init__

# Generated at 2022-06-23 17:01:52.561409
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def original_init(self, a: int, b: int) -> None:
        pass

    class MockClass():

        def __init__(self, a: int, b: int):
            pass

    obj = MockClass.__new__(MockClass)
    obj.__init__ = original_init

    init = _UndefinedParameterAction.create_init(obj)

    # We expect that the parameters which can be taken by the original init
    # function are ignored and only the known parameters are passed to the
    # original init function.
    known_pars = dict(a=1, b=2)
    unknown_pars = dict(c="some", d="some other")

    init(obj, *tuple(unknown_pars.values()), **unknown_pars, **known_pars)

    assert init.__

# Generated at 2022-06-23 17:01:57.201457
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class ExampleClass:
        def __init__(self, defined_parameter):
            self.defined_parameter = defined_parameter

    # Check that the _UndefinedParameterAction._separate_defined_undefined_kvs
    # method works
    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=ExampleClass, kvs={"undefined_parameter": "test"})



# Generated at 2022-06-23 17:01:59.673590
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Test(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self):
            pass

    Test()

# Generated at 2022-06-23 17:02:09.052682
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from unittest.mock import patch

    def mocked_separate_defined_undefined_kvs(cls, kvs):
        return {"defined": 1}, {"undefined": 2}

    with patch.object(_UndefinedParameterAction,
                      '_separate_defined_undefined_kvs',
                      new=mocked_separate_defined_undefined_kvs):
        # test Catch-All
        assert _CatchAllUndefinedParameters.handle_from_dict(cls=CatchAll,
                                                             kvs=None) == {
                                                                "catches": 2}

        # Test Raise
        assert _RaiseUndefinedParameters.handle_from_dict(cls=CatchAll,
                                                          kvs=None) == {
                                                             "defined": 1}

        # Test

# Generated at 2022-06-23 17:02:11.669706
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs = {"a": 1, "b": 2, "unknown": 4}
    expected = {"a": 1, "b": 2}
    result = _IgnoreUndefinedParameters.handle_from_dict(None, kvs)
    assert result == expected

# Generated at 2022-06-23 17:02:13.013710
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}

# Generated at 2022-06-23 17:02:24.993330
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # type: () -> None
    class test_class_no_catch_all:
        def __init__(self, foo, bar, baz=0, *, qux=None, **kws):
            self.foo = foo
            self.bar = bar
            self.baz = baz
            self.qux = qux

    class test_class_with_catch_all:
        catch_all = dataclasses.field(default=None,
                                      type=Optional[CatchAllVar])

        def __init__(self, foo, bar, baz=0, *, qux=None, **kws):
            self.foo = foo
            self.bar = bar
            self.baz = baz
            self.qux = qux
            self.catch_all = kws


# Generated at 2022-06-23 17:02:34.947910
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.undefined import Undefined, CatchAll


    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class MockClass:
        defined: str
        catch_all: Optional[CatchAll] = None


    d = {
        "defined": "defined",
        "catch_all": {
            "key1": "value",
            "key2": "value"}
    }
    obj = MockClass.from_dict(d)
    assert obj.defined == "defined"
    assert obj.catch_all == {"key1": "value", "key2": "value"}
    assert _CatchAllUndefinedParameters.handle_

# Generated at 2022-06-23 17:02:36.103150
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test _UndefinedParameterAction.handle_to_dict()
    """

# Generated at 2022-06-23 17:02:42.560294
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    """
    Unit test for the constructor of class _CatchAllUndefinedParameters
    :return:
    """
    @dataclasses.dataclass
    class Foo:
        a: int = 4
        b: float
        c: str = dataclasses.field(default_factory=str)
        d: Optional[CatchAllVar] = None

    foo = Foo(1, 2.0)
    assert dataclasses.asdict(foo) == {'a': 4, 'b': 2.0, 'c': '', 'd': {}}
    foo = Foo(1, 2.0, d="123")
    assert dataclasses.asdict(foo) == {'a': 4, 'b': 2.0, 'c': '', 'd': "123"}

# Generated at 2022-06-23 17:02:49.743329
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        def __init__(self, a: Any, b: Any) -> None:
            pass

    for method in [_UndefinedParameterAction.handle_from_dict,
                   _IgnoreUndefinedParameters.handle_from_dict,
                   _RaiseUndefinedParameters.handle_from_dict]:
        got = method(Test, {"b": "b", "_UNKNOWN0": "c"})
        want = {"b": "b"}
        assert got == want

# Generated at 2022-06-23 17:02:58.161345
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: str
        b: int = 1
        _catch_all: Optional[CatchAllVar] = CatchAll

    @dataclass
    class TestClass2:
        a: str
        b: int = 1
        d: bool

    test_class = TestClass()
    test_class_2 = TestClass2()

    catch_all_init = _CatchAllUndefinedParameters.create_init(test_class)
    assert catch_all_init(test_class, a="a", b=2, c="c", d="d") == \
           test_class
    assert test_class.a == "a"
    assert test_class.b == 2
    assert "_catch_all" in test_class.__dict__

# Generated at 2022-06-23 17:03:10.065866
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self, parameter: int,
                     catch_all: Optional[CatchAllVar] = None):
            self.parameter: int = parameter
            self.catch_all: Optional[CatchAllVar] = catch_all

        def _json_undefined_parameters(self):
            return _CatchAllUndefinedParameters

    test = TestClass(1, catch_all={"hello": "world"})
    result = _CatchAllUndefinedParameters.handle_dump(test)
    assert result == {"hello": "world"}

    test = TestClass(1, catch_all=CatchAll({"hello": "world"}))
    result = _CatchAllUndefinedParameters.handle_dump(test)
    assert result == {"hello": "world"}


# Generated at 2022-06-23 17:03:18.197395
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import inspect

    class TestInit:
        def __init__(self, a=1, b=2, c=3):
            pass

    obj = TestInit()
    old_init = obj.__init__
    init_signature = inspect.signature(old_init)

    new_init = _IgnoreUndefinedParameters.create_init(obj)

    # Check that the new method has the right signature
    assert new_init.__name__ == old_init.__name__
    assert inspect.signature(new_init) == init_signature

    # Check that it works correctly with arguments
    obj.__init__(a=1, b=2, c=3, d=4)
    assert obj.__getattribute__("a") == 1
    assert obj.__getattribute__("b") == 2
    assert obj

# Generated at 2022-06-23 17:03:28.922343
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class A:
        def __init__(self, a: str = "default"):
            self.a = a

        def __eq__(self, other):
            ## Avoid comparing the __init__ function
            return self.a == other.a

    class B:
        def __init__(self, a: str = "default", b: str = "default"):
            self.a = a
            self.b = b

        def __eq__(self, other):
            ## Avoid comparing the __init__ function
            return self.a == other.a and self.b == other.b

    class C:
        def __init__(self, a: str = "default", b: int = 1):
            self.a = a
            self.b = b


# Generated at 2022-06-23 17:03:36.864405
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class DataClass:
        __ignore_parameters__ = Undefined.EXCLUDE

        def __init__(self, name: str, id=None, **_):
            self.name = name
            self.id = id

    obj = DataClass("dummy")
    obj.id = 1
    kvs = {"name": "dummy", "id": 1}
    res = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs == res

    obj = DataClass("dummy", id=1)
    kvs = {"name": "dummy", "id": 1}
    res = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs == res

# Generated at 2022-06-23 17:03:49.237661
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init_fn = _CatchAllUndefinedParameters.create_init(CatchAll)

    class TestClass:
        def __init__(self, a: int, b: int, c: int, d: int, e: int,
                     *args, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    init_fn(TestClass, 1, 2, 3, 4, 5)
    obj = TestClass(1, 2, 3, 4, 5)

    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4
    assert obj.e == 5


# Generated at 2022-06-23 17:03:59.232882
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from unittest.mock import Mock, call

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            pass

    test_object = TestClass(a=1, b="a")
    mock_init = Mock()

    _CatchAllUndefinedParameters.create_init(obj=test_object)(
        self=test_object, args=(3,), kwargs={}, __init__=mock_init)

    mock_init.assert_called_once_with(self=test_object, a=3, b="a", c=None)

    _CatchAllUndefinedParameters.create_

# Generated at 2022-06-23 17:04:09.299312
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    def _create_dataclass(**kwargs):
        @dataclasses.dataclass(**kwargs)
        class Test:
            a: int
            b: int
            c: CatchAll = dataclasses.field(default=None)

        return Test

    Test = _create_dataclass()

    Test(1, 2)
    Test(1, 2, {"d": 3})
    Test(1, 2, c={"d": 3})
    Test(1, 2, d=3)
    Test(1, 2, {"d": 3}, e=4)
    Test(1, 2, d=3, e=4)
    Test(1, 2, c={"d": 3}, e=4)
    Test(1, 2, {"d": 3}, c={"e": 4})


# Generated at 2022-06-23 17:04:20.598104
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow as mm
    from marshmallow.exceptions import ValidationError
    from marshmallow.fields import Nested

    from dataclasses import dataclass

    @dataclass
    class Test:
        required: str
        optional: str = mm.fields.Str(allow_none=True)
        nested: Optional[Test] = None
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, *args, **kwargs):
            pass

    Test.__init__ = _IgnoreUndefinedParameters.create_init(Test)

    with pytest.raises(TypeError):
        Test(required="required", optional="optional",
             int_not_defined=99)

    Test(required="required", optional="optional")


# Generated at 2022-06-23 17:04:30.778418
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class X:
        a: int = 0
        b: int = 0

    # noinspection PyTypeChecker
    assert _RaiseUndefinedParameters.handle_from_dict(
        X, kvs={"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2}
    # noinspection PyTypeChecker
    assert _RaiseUndefinedParameters.handle_from_dict(X, kvs={"a": 1}) == {
        "a": 1, "b": 0}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(X, kvs={"a": 1, "c": 3})



# Generated at 2022-06-23 17:04:36.881978
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class _Test:
        a: int = 1
        b: int = 2

    test = _Test()
    undefined_parameters = {"c": 3,
                            "d": 4}

    kvs = _UndefinedParameterAction.handle_to_dict(test,
                                                   {"a": 1,
                                                    "c": 3,
                                                    "b": 2,
                                                    "d": 4})
    assert undefined_parameters == kvs

# Generated at 2022-06-23 17:04:45.457575
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from marshmallow import Schema

    class TestSchema(Schema):
        x1 = int
        x2 = int
        x3 = int

    schema = TestSchema(strict=True)

    @dataclasses.dataclass
    class Test:
        x1: int = 0
        x2: int = 0

    with pytest.raises(UndefinedParameterError):
        Test(**schema.load(data={"x1": 1, "x2": 2, "x3": 3}))



# Generated at 2022-06-23 17:04:56.811753
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass:
        def __init__(self, a: int, b: int, catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    expected_num_arguments_init = 3
    key_args_init = inspect.getfullargspec(TestClass.__init__).args
    assert len(key_args_init) == expected_num_arguments_init

    expected_num_arguments_from_dict = 17
    key_args_from_dict = inspect.getfullargspec(
        _CatchAllUndefinedParameters.handle_from_dict).args
    assert len(key_args_from_dict) == expected_num_arguments_from_dict

    expected_num_arguments_to_dict = 17
   

# Generated at 2022-06-23 17:05:01.570240
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, arg1: int, arg2: float, arg3: bool, arg4: str,
                     arg5: bool = False, arg6: str = "asd"):
            pass

    init = _IgnoreUndefinedParameters.create_init(Test)
    init(Test, 1, 2.0, True, "Hello", arg5=False, arg6="asd",
         arg7="this should be ignored")

# Generated at 2022-06-23 17:05:12.386983
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses as dc

    @dc.dataclass
    class CatchAllExample:
        foo: int
        catch_all: Optional[CatchAllVar] = None

        @staticmethod
        def from_dict(obj):
            return obj

        @staticmethod
        def to_dict(obj):
            return obj

    testdict = {
        "foo": 0,
        "unknown1": 1,
        "unknown2": 2,
    }
    exp_output = {
        "foo": 0,
        "unknown1": 1,
        "unknown2": 2,
    }
    obj = CatchAllExample.from_dict(testdict)
    output = CatchAllExample.to_dict(obj)
    assert output == exp_output
    assert isinstance(obj.catch_all, dict)

# Generated at 2022-06-23 17:05:13.344240
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("This is a test")

# Generated at 2022-06-23 17:05:15.010755
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object) == {}



# Generated at 2022-06-23 17:05:23.104679
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, field: str):
            self.field = field

        def to_dict(self) -> Dict[str, str]:
            return {"field": self.field}

    initializer = _RaiseUndefinedParameters()
    initializer.create_init(TestClass)
    assert initializer.handle_to_dict(TestClass("test"), {
        "field": "test"
    }) == {"field": "test"}

# Generated at 2022-06-23 17:05:27.402988
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def _test_handle_dump(parameter, expected_answer):
        class DummyClass:
            pass

        real_answer = _UndefinedParameterAction.handle_dump(DummyClass)
        assert real_answer == expected_answer

    expected = {}
    _test_handle_dump(None, expected)
    _test_handle_dump(object(), expected)
    _test_handle_dump(CatchAll, expected)

# Generated at 2022-06-23 17:05:32.665623
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        # noinspection PyUnresolvedReferences
        def __init__(self, a: int, b: str, c: str = "C", *, ca: CatchAll = None):
            pass

    _CatchAllUndefinedParameters.create_init(Test)(None)  # type: ignore