

# Generated at 2022-06-23 16:55:39.276194
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(metadata={dataclasses_json.config.Meta.unknown:
                                             dataclasses_json.Undefined.EXCLUDE})

    test_instance = TestClass(a=1, b=2, c=3, d=4)
    assert _UndefinedParameterAction.handle_to_dict(
        obj=test_instance, kvs=vars(test_instance)) == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:55:48.066951
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # Given
    @dataclasses.dataclass
    class SomeClass:
        name: str
        undefined_params: Optional[CatchAllVar] = \
            dataclasses.field(default_factory=dict)

    foo_bar = SomeClass(name="foo", undefined_params={"a": 42})
    bar_foo = SomeClass(name="bar")
    # Then
    assert _CatchAllUndefinedParameters.handle_dump(foo_bar) == {"a": 42}
    assert _CatchAllUndefinedParameters.handle_dump(bar_foo) == {}

# Generated at 2022-06-23 16:55:49.117239
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    p = _UndefinedParameterAction()
    assert False

# Generated at 2022-06-23 16:55:52.548352
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    @dataclass
    class Dummy:
        catch_all: CatchAll

    dummy = Dummy(catch_all={})
    assert _CatchAllUndefinedParameters.handle_dump(dummy) == dummy.catch_all

# Generated at 2022-06-23 16:56:03.552675
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import random
    import string

    random_value = ''.join(
        random.choices(string.ascii_uppercase + string.digits, k=5))
    random_value2 = ''.join(
        random.choices(string.ascii_uppercase + string.digits, k=5))

    class TestClass:
        def __init__(self, a: int, catch_all: CatchAll = None):
            self.a = a
            self.catch_all = catch_all

    assert TestClass(a=4).catch_all is None
    assert TestClass(a=4, catch_all={}).catch_all == {}

    test_obj = TestClass(a=4, catch_all={random_value: random_value2})

# Generated at 2022-06-23 16:56:15.062828
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class ExampleClass:
        def __init__(self, a, b, c):
            pass

    separator = _UndefinedParameterAction
    kvs = {"a": 1, "b": 2, "c": 3}
    known, unknown = separator._separate_defined_undefined_kvs(
        cls=ExampleClass, kvs=kvs)
    assert len(known) == 3
    assert unknown == {}
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known, unknown = separator._separate_defined_undefined_kvs(
        cls=ExampleClass, kvs=kvs)
    assert len(known) == 3
    assert len(unknown) == 1



# Generated at 2022-06-23 16:56:24.655533
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    object_init = object.__init__
    expected_parameters = ["a", "b"]
    expected_kwargs = {"kwarg_a": 1, "kwarg_b": 2}
    init_called = False

    class TestClass:
        def __init__(self):
            pass

    test_class = TestClass()

    def mocked_init(self, *args, **kwargs):
        nonlocal init_called
        assert args == expected_parameters
        assert kwargs == expected_kwargs
        init_called = True

    test_class.__init__ = mocked_init
    # Create the function that the class gets for its __init__ method
    new_init = _UndefinedParameterAction.create_init(test_class)

# Generated at 2022-06-23 16:56:37.145044
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass


    @dataclass
    class Catchall:
        a: int
        b: CatchAll = None


    @dataclass
    class CatchallDefault:
        a: int
        b: CatchAll = CatchAll({1: 2})


    @dataclass
    class CatchallFactory:
        a: int
        b: CatchAll = dataclasses.field(default_factory=lambda: CatchAll({
            1: 2}))


    @dataclass
    class NoCatchall:
        a: int
        b: int


    def assert_correctness(args, kwargs):
        """
        Run Catchall.__init__ with the given arguments
        and check that the resulting instance is valid
        """

# Generated at 2022-06-23 16:56:47.871678
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from typing import NoReturn
    from dataclasses import dataclass

    @dataclass
    class A:
        a: str
        optional: Optional[int] = None
        one_of_many: NoReturn = None
        one_of_many2: NoReturn = None

    @dataclass
    class B:
        b: str
        optional: Optional[int] = None
        catch_all: _CatchAllUndefinedParameters = Optional[CatchAllVar]

    @dataclass
    class C:
        b: str
        optional: Optional[int] = None
        catch_all: _CatchAllUndefinedParameters = Optional[CatchAllVar]()

    try:
        A(a="a")
    except UndefinedParameterError:
        assert False


# Generated at 2022-06-23 16:56:50.334818
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_message = "Test message"
    error = UndefinedParameterError(error_message)
    assert error.messages == [error_message]



# Generated at 2022-06-23 16:56:54.097774
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(None, {"bla": "a"})
    assert _RaiseUndefinedParameters.handle_from_dict(None, {}) == {}

# Generated at 2022-06-23 16:57:03.222222
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class A:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = CatchAll(d={"x": "y"})


    test_obj = A()
    test_obj.__init__()
    result = _UndefinedParameterAction.handle_to_dict(test_obj, {"a": 1,
                                                                  "b": 2,
                                                                  "c":
                                                                      CatchAll(
                                                                          d={
                                                                              "x": "y"})})
    assert result == {"a": 1, "b": 2}


# Generated at 2022-06-23 16:57:16.160427
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, *, x: int, y: int = 0,
                     _: CatchAll = None) -> None:
            self.x = x
            self.y = y
            self.z = _

    foo_init = _CatchAllUndefinedParameters.create_init(Foo)
    foo = foo_init(x=1, y=9)
    assert foo.x == 1, foo
    assert foo.y == 9, foo
    assert foo.z is None, foo

    foo = foo_init(1, 2, x=3, y=4, a=1, b=2, c=3)
    assert foo.x == 3, foo
    assert foo.y == 4, foo

# Generated at 2022-06-23 16:57:25.626071
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import enum
    import json
    import unittest.mock
    import typing
    import collections

    import marshmallow
    import marshmallow.fields

    # Used to 'inspect' the mocked out init method
    import inspect

    class TestClass:
        def __init__(self):
            self.field_1 = None
            self.field_2 = None
            self.field_3 = None

    class TestSchema(marshmallow.Schema):
        field_1 = marshmallow.fields.Str(required=True)
        field_2 = marshmallow.fields.Str(required=True)
        field_3 = marshmallow.fields.Str(required=True)

    class TestEnum(enum.Enum):
        TEST = 1


# Generated at 2022-06-23 16:57:29.470166
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    message = "Test message"
    exc = UndefinedParameterError(message)
    assert str(
        exc) == f"UndefinedParameterError: {message}"

# Generated at 2022-06-23 16:57:34.397210
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class MyClass:
        x: int


    _RaiseUndefinedParameters.handle_from_dict(MyClass, {"x":3})
    _RaiseUndefinedParameters.handle_from_dict(MyClass, {"x":3, "y":"test"})



# Generated at 2022-06-23 16:57:39.220229
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        foo: str


    _RaiseUndefinedParameters.handle_from_dict(TestClass, {'foo': 'bar'})
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {'bar': 'foo'})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:57:51.714486
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        # type: ignore
        _UndefinedParameterAction.handle_from_dict(3.14, {'a': 1})
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        # type: ignore
        _UndefinedParameterAction.handle_from_dict([1, 2, 3], {'a': 1})
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        # type: ignore
        _UndefinedParameterAction.handle_from_dict(None, {'a': 1})
    # noinspection PyTypeChecker

# Generated at 2022-06-23 16:57:58.997818
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import typing
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class B:
        name: str
        catch_all: dataclasses_json.CatchAll = None

    assert B.__init__.__defaults__ == (None,)

    # input parameters with no catch-all field
    assert _CatchAllUndefinedParameters.handle_from_dict(B, {"name": "b"}) == {
        "name": "b", "catch_all": {}}

    # input parameters with no undefined fields
    assert _CatchAllUndefinedParameters.handle_from_dict(B, {"name": "b"}) == {
        "name": "b", "catch_all": {}}

   

# Generated at 2022-06-23 16:58:00.958070
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError, match=r".*abstract methods.*"):
        _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:09.828610
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import Dict, List, Optional

    import pytest

    @dataclasses.dataclass(
        undefined=Undefined.INCLUDE)
    class TemporaryTestClass:
        a: int
        b: str
        c: List[int]
        d: Optional[int] = dataclasses.field(default=None)
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=None)

    cls = TemporaryTestClass

    def get_defined_undefined(kvs: Dict[str, Any]) -> \
            Tuple[KnownParameters, UnknownParameters]:
        defined, undefined = _CatchAllUndefinedParameters \
            ._separate_defined_undefined_kvs(cls=cls, kvs=kvs)
        return defined, undefined


# Generated at 2022-06-23 16:58:11.783920
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}

# Generated at 2022-06-23 16:58:22.196139
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def function(self, a, b, c=3, d=4, e=5, **kwargs):
        pass

    wrapped_function = _IgnoreUndefinedParameters.create_init(function)

    wrapped_function(None, 0, kwargs={})
    wrapped_function(None, 0, 1, kwargs={})
    wrapped_function(None, 0, 1, 2, kwargs={})
    wrapped_function(None, 0, 1, 2, 3, kwargs={})
    wrapped_function(None, 0, 1, 2, 3, 4, kwargs={})
    wrapped_function(None, 0, 1, 2, 3, 4, 5, kwargs={})

# Generated at 2022-06-23 16:58:23.134869
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("hello world")

# Generated at 2022-06-23 16:58:31.179394
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from override_kwargs import override_kwargs

    class A:
        def __init__(self, a: str = "a", b: str = "b", **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

    a = A("foo")
    assert a.a == "foo"
    assert a.b == "b"
    assert a.kwargs == {}

    @override_kwargs(cls=A, undefined=Undefined.EXCLUDE, load_kwargs=True)
    def a_init(self, *args, **kwargs):
        pass

    a = A("foo")
    assert a.a == "foo"
    assert a.b == "b"
    assert a.kwargs == {}



# Generated at 2022-06-23 16:58:41.268481
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert inspect.isclass(_UndefinedParameterAction)
    assert hasattr(_UndefinedParameterAction, "handle_from_dict")
    assert hasattr(_UndefinedParameterAction, "handle_to_dict")
    assert hasattr(_UndefinedParameterAction, "handle_dump")
    assert hasattr(_UndefinedParameterAction, "create_init")
    assert inspect.isfunction(
        _UndefinedParameterAction.handle_from_dict)
    assert inspect.isfunction(
        _UndefinedParameterAction.handle_to_dict)
    assert inspect.isfunction(
        _UndefinedParameterAction.handle_dump)
    assert inspect.isfunction(
        _UndefinedParameterAction.create_init)
    assert inspect.isabstract(_UndefinedParameterAction)
    assert inspect.isabstract(_UndefinedParameterAction.handle_from_dict)


# Generated at 2022-06-23 16:58:41.989610
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:43.989607
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = 1
    assert _UndefinedParameterAction.handle_dump(obj) == {}

# Generated at 2022-06-23 16:58:45.453878
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    obj = _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:53.612947
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import unittest
    from dataclasses_json.undefined import _IgnoreUndefinedParameters
    from typing import NamedTuple

    class A(NamedTuple):
        a1: int = 1
        a2: int = 2

    class B:
        def __init__(self, b1: int = 1, b2: int = 2):
            self.b1 = b1
            self.b2 = b2

    class C:
        def __init__(self, c1: int = 2, b: B = None):
            """

            :param c1:
            :param b:
            """
            self.c1 = c1
            self.b = b


# Generated at 2022-06-23 16:58:55.063780
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:59:03.696384
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Foo:
        bar: int
        baz: int

    class FooWithCatchAll(Foo):
        _catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    parameters = {"bar": 3, "baz": 2, "_catch_all": 12}
    known_kwargs, unknown_kwargs = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            FooWithCatchAll, parameters)
    assert known_kwargs == {"bar": 3, "baz": 2}
    assert unknown_kwargs == {"_catch_all": 12}

    # Check that the _catch_all field receives the unknown parameters

# Generated at 2022-06-23 16:59:11.225715
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, foo, bar):
            pass

    assert _IgnoreUndefinedParameters.handle_from_dict(
        A, {
            "foo": 1,
            "bar": "meow",
            "baz": "baz"
        }) == {
            "foo": 1,
            "bar": "meow"
        }
    assert _IgnoreUndefinedParameters.handle_from_dict(
        A, {
            "foo": "foo"
        }) == {
            "foo": "foo"
        }
    assert _IgnoreUndefinedParameters.handle_from_dict(
        A, {
            "bar": "meow",
            "baz": "baz"
        }) == {
            "bar": "meow"
        }
    assert _Ignore

# Generated at 2022-06-23 16:59:16.031115
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass():
        def __init__(self, a, b, c):
            pass

    _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-23 16:59:26.370106
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, x: float, y, z: float = 0,
                     all_else: Optional[CatchAllVar] = None):
            self.x = x
            self.y = y
            self.z = z
            self.all_else = all_else

        def __eq__(self, other) -> bool:
            return isinstance(other, TestClass) and self.x == other.x and \
                   self.y == other.y and self.z == other.z and \
                   self.all_else == other.all_else

    t1 = TestClass(1, 2)
    t2 = TestClass(1, 2)
    t3 = TestClass(**_CatchAllUndefinedParameters.create_init(TestClass)(
        t1, 1, 2))


# Generated at 2022-06-23 16:59:35.664504
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses import dataclass
    import typing

    @dataclass
    class TestClass:
        a: float
        b: str
        c: int = 0
        d: typing.Optional[typing.CatchAll] = None

    t = TestClass(a=1.1, b="bla", c=123, cde=46, d=dict(foo="bar"))

    assert _UndefinedParameterAction.handle_to_dict(t, dict(a=1.1, b="bla",
                                                            c=123, cde=46,
                                                            d=dict(foo="bar"))) == dict(a=1.1, b="bla",
                                                                                        c=123, cde=46)

# Generated at 2022-06-23 16:59:44.575160
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class C:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

            # type: ignore


    assert _RaiseUndefinedParameters.handle_from_dict(cls=C,
                                                      kvs={"a": 1, "b": 2}) == {
               "a": 1, "b": 2}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=C,
                                                   kvs={"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-23 16:59:46.580008
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _IgnoreUndefinedParameters.handle_dump({}) == {}


# Generated at 2022-06-23 16:59:55.831798
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.api import config
    from dataclasses_json.utils import CatchAll

    @config(unknown=Undefined.INCLUDE)
    @dataclasses.dataclass
    class LetsGetWeird:
        a: int
        b: str
        catch_all: Optional[CatchAll]

    obj = LetsGetWeird(1, "a", catch_all=None)

    assert _CatchAllUndefinedParameters.handle_to_dict(obj, {"a": 1, "b": "a"}) == {"a": 1, "b": "a"}

# Generated at 2022-06-23 17:00:07.441001
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():

    # noinspection PyUnresolvedReferences
    @dataclasses.dataclass(frozen=True,
                           init=_UndefinedParameterAction.create_init(
                               _UndefinedParameterAction),
                           )
    class AClass:
        param: str = dataclasses.field(default="param")
        param2: int = dataclasses.field(default=2)

    kvs = {"param": "new",
           # noinspection PyUnresolvedReferences
           "catch_all": {"new_param": 2}}
    result = _CatchAllUndefinedParameters.handle_from_dict(AClass, kvs)
    assert result == {"param": "new",
                      "param2": 2,
                      "catch_all": {"new_param": 2}}


# Generated at 2022-06-23 17:00:18.943085
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    def define_TestClass(default: Optional[CatchAllVar]) -> type:
        @dataclasses.dataclass
        class TestClass(metaclass=DataClassJson):
            params: Optional[CatchAllVar] = default

        return TestClass

    # Base Case
    TestClass = define_TestClass(default=None)
    kvs = dict(key0=0, key1=1)
    parameter_dict = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, kvs)
    assert parameter_dict == dict(params=kvs)

    # Case: dict received in place of parameter
    kvs = dict(key0=0, key1=1, params=dict(foo=1))

# Generated at 2022-06-23 17:00:23.538131
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(
        obj=None, kvs=dict(foo=1)) == {"foo": 1}



# Generated at 2022-06-23 17:00:27.070557
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    test_args = ("a", "b", "c")
    test_kwargs = dict(a=1, b=2, c=3, d=4)

    def test_init(self, a, b, e, **kwargs):
        # type: (Any, Any, Any, Any) -> None
        pass

    result = _CatchAllUndefinedParameters.create_init(test_init)(
        None, *test_args, **test_kwargs)
    assert result == {}

# Generated at 2022-06-23 17:00:33.736126
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, x: int, y: str, z: float = 0.0):
            self.x = x
            self.y = y
            self.z = z

    params = {"x": 1, "y": "test", "z": 1.0, "w": 3}
    _UndefinedParameterAction.handle_from_dict(TestClass, params)



# Generated at 2022-06-23 17:00:37.487339
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    from typing import Optional

    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class A:
        b: str
        c: int
        d: Optional[CatchAllVar] = None

        def __init__(self, b: str, c: int, d: Optional[CatchAllVar] = None):
            pass

    a = A("xx", 1, {"a": 1, "b": "2"})

    assert _CatchAllUndefinedParameters.handle_dump(a) == {"a": 1, "b": "2"}



# Generated at 2022-06-23 17:00:41.263920
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        pass

    test_obj = TestClass()
    all_kvs = {"key": "value", CatchAllVar: {"catch": "all"}}

    _UndefinedParameterAction.handle_to_dict(test_obj, all_kvs)

# Generated at 2022-06-23 17:00:55.114143
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import dataclass, config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class InvalidCatchAll:
        a: int
        b: CatchAllVar

    @dataclass
    class TestClass0:
        a: int
        b: str
        catch_all: Optional[CatchAllVar] = None

    @dataclass
    class TestClass1:
        a: int
        b: str
        catch_all: Optional[CatchAllVar] = config(undefined=Undefined.INCLUDE)

    @dataclass
    class TestClass2:
        a: int
        b: str

# Generated at 2022-06-23 17:00:59.039175
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error_msg = "Test message"
    error = UndefinedParameterError(error_msg)
    assert error_msg in error.args[0]
    assert error.valid_data is None

# Generated at 2022-06-23 17:01:00.746214
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Foo:
        pass
    assert _UndefinedParameterAction.handle_dump(Foo()) == {}

# Generated at 2022-06-23 17:01:07.207116
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Foo:
        x: int
        y: Optional[CatchAllVar] = None

    a = Foo(x=1)
    b = Foo(x=1, y={"bar": "baz"})
    assert {} == _CatchAllUndefinedParameters.handle_dump(a)
    assert {"bar": "baz"} == _CatchAllUndefinedParameters.handle_dump(b)

# Generated at 2022-06-23 17:01:15.684908
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Example:
        def __init__(self, a: str, b: str, c: str = "c"):
            pass

    Example2 = _IgnoreUndefinedParameters.create_init(Example)

    assert hasattr(Example2, "__init__")
    Example2("a", "b")
    Example2("a", "b", "c")
    Example2("a", "b", "c", d="d")
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        Example2("a", "b", "c", d="d", e="e")

# Generated at 2022-06-23 17:01:27.311343
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    class TestClass:
        def __init__(self, a, b, c, C=3):
            self.a = a
            self.b = b
            self.c = c
            self.C = C

    @dataclass
    class TestClassDC:
        a: int
        b: int
        c: int
        C: int = 3

    @dataclass
    class TestClassDCIgnore:
        a: int
        b: int
        c: int
        C: int = 3

        @dataclasses_json.config(undefined=Undefined.EXCLUDE)
        def __post_init__(self):
            pass

    @dataclass
    class TestClassDCRaise:
        a: int
        b: int
        c

# Generated at 2022-06-23 17:01:33.781023
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class_fields = [Field(name="a", type=int),
                    Field(name="ignore_me", type=int)]
    class_ = dataclasses.make_dataclass("TestClass", class_fields)
    unknown_parameters = {"x": 4, "y": 5}
    parameters_to_dict = {"a": 1}
    parameters_to_dict.update(unknown_parameters)
    obj = class_(**parameters_to_dict)

    actual = _UndefinedParameterAction.handle_to_dict(obj, parameters_to_dict)
    expected = {"a": 1}

    assert actual == expected

# Generated at 2022-06-23 17:01:39.432796
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():

    @dataclasses.dataclass
    class Test:
        defined: str = "defined"
        undefined: Optional[CatchAllVar] = None

    test = Test(defined="defined", undefined={"undefined": 5})
    kvs = dataclasses.asdict(test)
    expected = {
        "defined": "defined",
        "undefined": {"undefined": 5}
    }
    actual = _CatchAllUndefinedParameters.handle_to_dict(test, kvs)
    assert expected == actual


# Generated at 2022-06-23 17:01:42.157689
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 17:01:53.222555
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(frozen=True)
    class IncludedDict:
        foo: str
        catch_all: CatchAll

        def __init__(self, foo: str, bar: str, baz: str = "baz",
                     catch_all: CatchAll = None):
            pass

    @dataclasses.dataclass(frozen=True)
    class NoCatchAll:
        foo: str

        def __init__(self, foo: str, bar: str, baz: str = "baz"):
            pass

    obj = IncludedDict("foo", "bar")
    custom_init = _CatchAllUndefinedParameters.create_init(obj)
    obj2 = IncludedDict(foo="foo", bar="bar", baz="baz")

# Generated at 2022-06-23 17:02:03.611718
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass(undefined=Undefined.INCLUDE)
    class Dummy(DataClassJsonMixin):
        a: int
        b: str
        c: bool
        d: Dict[str, Any] = dataclasses.field(default_factory=dict)

    d = Dummy(a=1, b="2", c=True, d="something", e=6)
    kvs = config(dict_type=dict).encoder(Dummy).dump(d).data
    handled = _CatchAllUndefinedParameters.handle_to_dict(obj=Dummy, kvs=kvs)

# Generated at 2022-06-23 17:02:10.946889
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, a: int, b: int, c: int = 3):
            self.a = a
            self.b = b
            self.c = c

    # noinspection PyTypeChecker
    init = _IgnoreUndefinedParameters.create_init(TestClass)

    assert init(TestClass, 1, 2, c=5) == TestClass(1, 2, c=5)
    assert init(TestClass, 1, 2, c=5, d=6) == TestClass(1, 2, c=5)
    assert init(TestClass, 1, 2, d=6) == TestClass(1, 2)

# Generated at 2022-06-23 17:02:20.642011
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

        @classmethod
        def to_dict(cls, unknown_parameters: Dict[Any, Any] = None):
            return _UndefinedParameterAction.handle_to_dict(cls,
                                                            unknown_parameters)

    test = Test(a=1, b=2)
    test_dict = test.to_dict()
    assert test_dict == {"a": 1, "b": 2}



# Generated at 2022-06-23 17:02:27.794638
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    """
    Test that the method handle_to_dict of class _UndefinedParameterAction
    is working as expected
    :return:
    """
    class SomeTestClass:
        s: str
        o: Optional[CatchAllVar]

    t = SomeTestClass
    t.s = "something"
    t.o = {"dummy": "dummy"}

    result = _CatchAllUndefinedParameters.handle_to_dict(t, {"s": "something",
                                                             "o": {"dummy":
                                                                       "dummy"}})
    expected = {"s": "something"}
    assert result == expected

# Generated at 2022-06-23 17:02:28.866520
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 17:02:37.499676
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Point:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

    class PointSchema:
        from dataclasses_json.core import Configuration, Schema

        SCHEMA_TYPE = Point

        @classmethod
        def create_schema(cls, **kwargs) -> Schema:
            return cls.Schema(strict=True, validate=cls._handle_undefined,
                              **kwargs)

        @classmethod
        def _handle_undefined(cls, *args, **kwargs):
            _RaiseUndefinedParameters.handle_from_dict(cls, kwargs)



    point_schema = PointSchema.create_schema()
    input_dict

# Generated at 2022-06-23 17:02:43.639619
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class TestClass:
        field1: int
        field2: int

        def __init__(self, field1, field2, **kwargs):
            self.field1 = field1
            self.field2 = field2
            self.__dict__.update(**kwargs)

    tc = TestClass(field1=1, field2=2, field3=3)
    dump = _CatchAllUndefinedParameters.handle_dump(tc)
    assert dump == {"field3": 3}

# Generated at 2022-06-23 17:02:55.900203
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: str, b: int, catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all

    @dataclasses.dataclass
    class B:
        a: str = ""
        b: int = 0
        catch_all: CatchAll = None

    data = {"a": "a", "b": 1, "c": "c"}

    a = A(**data)
    assert a.a == "a"
    assert a.b == 1

    b = B(**data)
    assert b.a == "a"
    assert b.b == 1

    assert a.catch_all == b.catch_all is None

# Generated at 2022-06-23 17:03:04.131040
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import config, dataclass_json

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class Foo:
        a: str
        b: str
        c: Optional[CatchAllVar] = None

    assert Foo("a", "b").c == {}


# Generated at 2022-06-23 17:03:05.528935
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = object()
    assert _UndefinedParameterAction.handle_dump(obj) == {}



# Generated at 2022-06-23 17:03:06.841232
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError()
    assert isinstance(error, ValidationError)

# Generated at 2022-06-23 17:03:14.527877
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class SomeClass:
        def __init__(self, a, b=None, c=1):
            self.a = a
            self.b = b
            self.c = c

    m = _IgnoreUndefinedParameters()
    assert m.handle_from_dict(SomeClass, {"a": 1, "b": 2, "c": 3}) == \
           {"a": 1, "b": 2, "c": 3}

    assert m.handle_from_dict(SomeClass, {"a": 1, "b": 2, "c": 3, "d": 4}) == \
           {"a": 1, "b": 2, "c": 3}

    assert m.handle_from_dict(SomeClass, {"a": 1}) == \
           {"a": 1, "b": None, "c": 1}

    assert m

# Generated at 2022-06-23 17:03:25.854040
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    cls = type("DummyClass", (object,), {
        "a": dataclasses.field(default=2)
    })

    expected_known_parameters = {"a": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(cls,
                                                      {"a": 1}) == expected_known_parameters

    expected_unknown_parameters = {"b": 1, "c": 2}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls, expected_unknown_parameters)

    expected_mix_parameters = {"a": 1, "b": 2}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls, expected_mix_parameters)



# Generated at 2022-06-23 17:03:34.455534
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    dataclass_with_init = \
        dataclasses.make_dataclass("d",
                                   [("a", int),
                                    ("b", int),
                                    ("c", int, field(default=4)),
                                    ("d", int),
                                    ("e", int),
                                    ("f", int),
                                    ("g", int),
                                    ("h", int),
                                    ("i", int),
                                    ("j", int),
                                    ("k", int),
                                    ("l", int),
                                    ("m", int),
                                    ("n", int),
                                    ("o", int),
                                    ("p", int)])

    assert len(inspect.signature(dataclass_with_init.__init__).parameters) == 16
    max_arguments_dataclass_

# Generated at 2022-06-23 17:03:35.766387
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

# Generated at 2022-06-23 17:03:39.931897
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Test:
        def __init__(self, unknown):
            self.unknown = unknown
    try:
        Test(unknown="test")
    except UndefinedParameterError as e:
        assert str(e) == ''
        return
    except Exception as e:
        assert False, f"Raised {type(e)}"
    assert False, "Expected UndefinedParameterError"

# Generated at 2022-06-23 17:03:51.372746
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Test that the method returns what it receives
    class TestClass:
        pass

    parameters = {"test": "TestRoot"}
    instance = TestClass()
    assert _RaiseUndefinedParameters.handle_from_dict(instance, parameters) == parameters

    class TestClass:
        def __init__(self, test: str):
            self.test = test

    parameters = {"test": "TestRoot"}
    instance = TestClass()
    assert _RaiseUndefinedParameters.handle_from_dict(instance, parameters) == parameters

    class TestClass:
        def __init__(self, test: str, test2: str):
            self.test = test
            self.test2 = test2

    parameters = {"test": "TestRoot"}
    instance = TestClass()

# Generated at 2022-06-23 17:04:02.904383
# Unit test for method handle_to_dict of class _UndefinedParameterAction

# Generated at 2022-06-23 17:04:10.864503
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    kvs = {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_from_dict(TestClass, kvs) == {}

    kvs = {"a": 1, "b": 2, "c": 3}
    # Should raise an error because of "c" being an undefined parameter
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
        assert False, "Test should have failed."
    except UndefinedParameterError:
        assert True, "Test failed as expected."

    # Should return only defined parameters
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, kvs) == {"a": 1, "b": 2}

    # Should put undefined parameters into catch_all variable

# Generated at 2022-06-23 17:04:14.775293
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(obj="", kvs={}) == {}



# Generated at 2022-06-23 17:04:23.244417
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, test, **kwargs):
            pass

    @dataclasses.dataclass
    class TestClassWithFields:
        test: str
        test2: str

    _IgnoreUndefinedParameters.handle_from_dict(TestClass,
                                                {"test": "Test", "test2":
                                                    "Test2"})
    _IgnoreUndefinedParameters.handle_from_dict(TestClassWithFields,
                                                {"test": "Test", "test2":
                                                    "Test2"})


# Generated at 2022-06-23 17:04:30.341537
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class A:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


    @dataclasses.dataclass
    class B(A):
        c: int = dataclasses.field(**dataclasses.field(default=dataclasses.field(default_factory=int)))


    @dataclasses.dataclass
    class C(A):
        c: int = 1


    @dataclasses.dataclass
    class D(A):
        c: int = dataclasses.field(**dataclasses.field(default=dataclasses.field(default_factory=int)))
        catch_all: Optional[CatchAllVar] = None


    @dataclasses.dataclass
    class E(A):
        c: int = dat

# Generated at 2022-06-23 17:04:35.089620
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    obj = _CatchAllUndefinedParameters()
    expected = {"foo": 1, "catch_all": {"bar": 1}}
    actual = obj.handle_to_dict(obj=expected,
                                kvs={"foo": 1, "catch_all": {"bar": 1}})
    assert expected == actual
    assert isinstance(actual["catch_all"], dict)



# Generated at 2022-06-23 17:04:42.024451
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass1:
        """
        For the sake of testing our UndefinedParameterAction,
        we define a class with a known and unknown parameter.
        """
        def __init__(self, known_parameter: str, unknown_parameter: str):
            self.known_parameter = known_parameter
            self.unknown_parameter = unknown_parameter

    class TestClass2:
        """
        For the sake of testing our UndefinedParameterAction,
        we define a class with a known parameter only
        """
        def __init__(self, known_parameter: str):
            self.known_parameter = known_parameter

    # Test
    undefined_action = Undefined.RAISE
    assert not isinstance(undefined_action, str)



# Generated at 2022-06-23 17:04:48.362890
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    def test_method():
        class Foo:
            a: int = 0
            b: int = 0

        params = _RaiseUndefinedParameters.handle_from_dict(Foo,
                                                            dict(a=1, b=2, c=3,
                                                                 d=4))
        assert len(params) == 2 and params.get("a") == 1 and params.get(
            "b") == 2

    test_method()

# Generated at 2022-06-23 17:04:52.690240
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c_: int

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class_under_test = TestClass
    given_input = {"a": 1, "b": 2, "c_": 3, "d": 4}

    expected_output = {"a": 1, "b": 2, "c_": 3}
    actual_output = _UndefinedParameterAction.handle_from_dict(
        class_under_test, given_input)
    assert expected_output == actual_output



# Generated at 2022-06-23 17:05:03.185604
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: int

    def create_test_obj(**kvs):
        return TestClass(**_RaiseUndefinedParameters.handle_from_dict(
            TestClass, kvs))

    # noinspection PyTypeChecker
    test_obj = create_test_obj(a=1, b=2, c=3)
    assert test_obj.a == 1
    assert test_obj.b == 2
    assert test_obj.c == 3
    with pytest.raises(UndefinedParameterError):
        create_test_obj(a=1, b=2, c=3, d=4)


# Generated at 2022-06-23 17:05:13.340111
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Dummy:
        @staticmethod
        def __init__(self, a: int) -> None:
            pass

    action = _UndefinedParameterAction()
    kvs = {"a": 3}
    with pytest.raises(NotImplementedError):
        action.handle_from_dict(cls=Dummy, kvs=kvs)
    with pytest.raises(NotImplementedError):
        action.handle_to_dict(obj=Dummy, kvs=kvs)
    with pytest.raises(NotImplementedError):
        action.handle_dump(obj=Dummy)
    with pytest.raises(NotImplementedError):
        action.create_init(obj=Dummy)

# Generated at 2022-06-23 17:05:16.036179
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Some error message")
    except UndefinedParameterError as error:
        assert error.messages == ["Some error message"]
        assert error.fields is None
        assert error.valid_data is None


# Generated at 2022-06-23 17:05:27.201602
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Creates an init function in which all undefined parameters are ignored
    and the defined parameters are
    processed only if the correct number of parameters is passed.
    """

    def create_class(x: Any, y: Any, z: Any, a: Any, b: Any) -> Any:
        return locals()

    cls_locals = create_class(1, 2, 3, a=1, b=2)
    cls = type(
        "cls",
        (),
        cls_locals
    )

    init = _IgnoreUndefinedParameters.create_init(cls)

    cls_instance = cls(1, 2, 3, a=1, b=2)

    assert init is cls_instance.__init__
    assert cls_instance.x == 1
    assert cls_instance

# Generated at 2022-06-23 17:05:37.114998
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import typing

    @dataclasses.dataclass
    class MyClass1:
        a: int
        b: str
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = dict() if c is None else c
            pass

        pass

    @dataclasses.dataclass
    class MyClass2:

        a: str
        b: str
        c: typing.Optional[CatchAllVar] = None

        def __init__(self, a: str, b: str, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b