

# Generated at 2022-06-23 16:55:31.937167
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined = UndefinedParameterError()
    assert (undefined.messages == [])
    assert (undefined.field_names == [])
    assert (undefined.fields == {})

# Generated at 2022-06-23 16:55:33.098082
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    raise NotImplementedError



# Generated at 2022-06-23 16:55:37.883258
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    a_dict = {"foo": "bar", "hello": "world"}
    expected_dict = {"foo": "bar"}
    assert _IgnoreUndefinedParameters.handle_from_dict(  # type: ignore
        cls=None, kvs=a_dict) == expected_dict



# Generated at 2022-06-23 16:55:40.444827
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    This test should not be run with pytest. It is only useful for mepy checking
    the constructor of `_UndefinedParameterAction`.
    """
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:55:45.810034
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Foo:
        a: int

    assert _RaiseUndefinedParameters.handle_from_dict(Foo, {}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(Foo, dict(a=1)) == dict(
        a=1)
    assert _RaiseUndefinedParameters.handle_from_dict(Foo, dict(a=1, b=2)) == dict(
        a=1)



# Generated at 2022-06-23 16:55:52.172499
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int = 0, b: int = 0, **kwargs: dict) -> None:
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"
    assert "self" in init.__code__.co_varnames
    assert TestClass.__init__.__code__.co_argcount - 1 == \
           init.__code__.co_argcount

# Generated at 2022-06-23 16:56:03.249996
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses_json.undefined import Undefined
    from dataclasses_json.utils import CatchAllVar


    @dataclasses.dataclass
    class A:
        a: int
        undefined: Undefined = Undefined.INCLUDE

    # INCLUDE
    assert A(a=1).undefined == {}
    assert A(a=1, b=2, undefined=Undefined.INCLUDE).undefined == {"b": 2}

    # RAISE
    try:
        A(a=1, b=2, undefined=Undefined.RAISE)
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError(
            "Expected an error when the undefined parameter "
            "action is RAISE")

    # EXCLUDE

# Generated at 2022-06-23 16:56:10.950802
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    """
    Test that _RaiseUndefinedParameters raises error when undefined
    parameters are supplied
    """
    @dataclasses.dataclass()
    class A:
        pass

    kvs = {1:2}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=A, kvs=kvs)



# Generated at 2022-06-23 16:56:14.364334
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 16:56:16.400081
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, *args, **kwargs):
            pass

    _RaiseUndefinedParameters.create_init(Foo)()



# Generated at 2022-06-23 16:56:25.062752
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow as ma

    @dataclasses.dataclass(init=True)
    class _TestClass(_IgnoreUndefinedParameters):
        a: int
        b: int

    _s = ma.Schema.from_dataclass(_TestClass)
    obj = _s.load({"a": 1, "b": 2, "c": 3, "d": 4})
    _, unknown_kws = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        _TestClass, {"a": 1, "b": 2, "c": 3, "d": 4})
    assert obj.a == 1
    assert obj.b == 2
    assert unknown_kws == {"c": 3, "d": 4}

# Generated at 2022-06-23 16:56:29.861085
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class J:
        i: int

    import marshmallow_dataclass as md

    class JSchema(md.Schema):
        i: int

    kvs = {"i": 5, "j": 6}
    assert (_IgnoreUndefinedParameters.handle_from_dict(J, kvs) ==
            {"i": 5})

    kvs = {"i": 5}
    assert (_IgnoreUndefinedParameters.handle_from_dict(J, kvs) ==
            {"i": 5})

    kvs = {"j": 6}
    assert (_IgnoreUndefinedParameters.handle_from_dict(J, kvs) == {})

    js = JSchema().load(kvs)



# Generated at 2022-06-23 16:56:33.976047
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestDataClass:
        a: int
        b: int
        catch_all: CatchAll = None

    a = TestDataClass.__init__.__code__.co_varnames
    _b = _CatchAllUndefinedParameters.create_init(TestDataClass)().__code__.co_varnames
    b = set(_b)
    assert b.issuperset(a)

    # Test that named arguments that are not captured as **kwargs are declared
    # as free variables
    assert "unknown_kwargs" in _b
    assert "unknown_args" in _b

# Generated at 2022-06-23 16:56:38.559784
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    init = _CatchAllUndefinedParameters.create_init(Test)

    class TestCatchAll:
        def __init__(self, a: int, b: int, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    init_catch_all = _CatchAllUndefinedParameters.create_init(TestCatchAll)

    assert Test(1, 2) == init(Test, 1, 2, _UNKNOWN0=3)
    assert Test(1, 2) == init(Test, 1, 2)


# Generated at 2022-06-23 16:56:38.947148
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-23 16:56:43.585121
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    parameter_list = ["_parameter"]

    class TestClass:
        def __init__(self, _undefined_parameters: Optional[CatchAllVar], *_,
                     **_parameter):
            self._undefined_parameters = _undefined_parameters

    expected_output = {"_parameter": "_parameter"}
    kvs = {"_undefined_parameters": {"_parameter": "_parameter"}}
    assert kvs == _CatchAllUndefinedParameters.handle_to_dict(
        TestClass(*parameter_list), kvs)

    kvs = {"_undefined_parameters": {"_parameter": "_parameter"}}
    kvs = _CatchAllUndefinedParameters.handle_to_dict(TestClass(
        *parameter_list, **kvs), kvs)

# Generated at 2022-06-23 16:56:45.145974
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    raise NotImplementedError

# Generated at 2022-06-23 16:56:57.294421
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import datetime

    @dataclasses.dataclass
    class CatchAllTest(object):
        a: int
        b: int
        c: Optional[CatchAllVar] = None
        d: Optional[CatchAllVar] = None

    CatchAllTest(a=1, b=2)
    CatchAllTest(a=1, b=2, c={})
    CatchAllTest(a=1, b=2, c={"x": "y"})
    CatchAllTest(a=1, b=2, c=CatchAll({}))
    CatchAllTest(a=1, b=2, c=CatchAll({"x": "y"}))

    with pytest.raises(UndefinedParameterError):
        CatchAllTest(a=1, b=2, c=3)


# Generated at 2022-06-23 16:57:04.657508
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json
    import dataclasses_json.api
    import pytest


    @dataclasses.dataclass
    @dataclasses_json.dataclass_json
    class DataClass:
        a: int
        other_field: str


    original_init = DataClass.__init__
    catch_all_init = _CatchAllUndefinedParameters.create_init(DataClass)

    data_class_instance = DataClass(a=1, other_field="other_field")
    assert data_class_instance.a == 1
    assert data_class_instance.other_field == "other_field"


# Generated at 2022-06-23 16:57:15.931809
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int
        unknown: Undefined.RAISE

    input_args = {"a": "hello", "b": 10, "unknown": "parameter"}
    known_args, unknown_args = TestClass.unknown.value.handle_from_dict(
        cls=TestClass, kvs=input_args)
    assert known_args.keys() == {"a", "b"}
    assert known_args == {"a": "hello", "b": 10}
    assert unknown_args == {"unknown": "parameter"}

    with pytest.raises(UndefinedParameterError):
        TestClass(**input_args)

# Generated at 2022-06-23 16:57:19.783282
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, test):
            self.test = test
    source = {'test': 'test'}
    result = _RaiseUndefinedParameters.handle_from_dict(Test, source)
    assert result == {'test': 'test'}



# Generated at 2022-06-23 16:57:28.460963
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Set up dicts and classes.

    @dataclasses.dataclass
    class SomeClass:
        foo: str = "foo"

    class_ = SomeClass
    kvs = {"foo": "bar"}

    # Test without catch-all field

    result = _CatchAllUndefinedParameters.handle_from_dict(class_, kvs)
    assert result == kvs

    # Test with default setting in catch-all field

    @dataclasses.dataclass
    class SomeClass:
        foo: str = "foo"
        extra: CatchAll = CatchAll(default={})

    class_ = SomeClass
    kvs = {"foo": "bar"}

    result = _CatchAllUndefinedParameters.handle_from_dict(class_, kvs)
    assert result == {**kvs, "extra": {}}

# Generated at 2022-06-23 16:57:32.451498
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a, b, c):
            pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D, E):
        pass

    provided_params = {"a": 1, "b": 2, "c": 3, "d": 4}
    expected_params = {"a": 1, "b": 2, "c": 3}

    result = _UndefinedParameterAction.handle_from_dict(A, provided_params)

    assert result == expected_params
    assert result is not expected_params


# Generated at 2022-06-23 16:57:33.546204
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    raise UndefinedParameterError("Test exception")

# Generated at 2022-06-23 16:57:41.368372
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class BaseTestClass:
        pass

    class TestClass(BaseTestClass):
        def __init__(self, a: int):
            self.a = a

    def base_class_init(self):
        BaseTestClass.__init__(self)

    test_instance = TestClass(0)
    test_instance.__init__ = _IgnoreUndefinedParameters.create_init(TestClass)
    if BaseTestClass.__init__ != object.__init__:
        test_instance.__init__ = functools.partial(base_class_init,
                                                   test_instance)
    test_instance.__init__()

    test_instance.__init__(a=1, b=4)
    assert test_instance.a is 1
    assert not hasattr(test_instance, "b")

    test

# Generated at 2022-06-23 16:57:53.068055
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class A:
        a: int
        b: int = 5
        x: str = "hello"
        y: Optional[CatchAllVar] = None

    a_init = A.__init__
    an_a: A = A(a=1, b=2, x="world", e=4)
    assert an_a.a == 1
    assert an_a.b == 2
    assert an_a.x == "world"
    assert an_a.y["e"] == 4

    # No catch all field exists
    with pytest.raises(UndefinedParameterError):
        b_init = _CatchAllUndefinedParameters.create_init(A(a=1))

    # Multiple catch all fields exist

# Generated at 2022-06-23 16:58:05.913055
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.api import from_dict

    class Example:
        a: str
        b: int
        c: float

    @dataclasses.dataclass
    class ClassWithUndefinedParameters:
        a: str
        b: int
        c: float
        undefined_parameter_handler: _UndefinedParameterAction = \
            _IgnoreUndefinedParameters

        def __post_init__(self):
            pass

    test_kvs = {
        "a": "foo",
        "b": 1,
        "c": 1.23,
        "d": 456,
        "e": "foo_bar"
    }

    cls = from_dict(ClassWithUndefinedParameters, test_kvs)
    assert cls.a == "foo"
    assert cls.b == 1


# Generated at 2022-06-23 16:58:14.409626
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    """
    This test is currently only for mypy
    """
    _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs=None)
    _RaiseUndefinedParameters.handle_to_dict(obj=None, kvs=None)
    _RaiseUndefinedParameters.handle_dump(obj=None)
    _RaiseUndefinedParameters.create_init(obj=None)
    _RaiseUndefinedParameters._separate_defined_undefined_kvs(cls=None,
                                                               kvs=None)



# Generated at 2022-06-23 16:58:27.766686
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class Klass:
        a: int
        b: str
        c: float
        d: bool = False

    assert _CatchAllUndefinedParameters.handle_from_dict(Klass, {"a": 1,
                                                                 "b": "B",
                                                                 "c": 2.3,
                                                                 "d": True}) == {
        "a": 1, "b": "B", "c": 2.3, "d": True,
        UNDEFINED_PARAMETERS: {}}

# Generated at 2022-06-23 16:58:33.067164
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @functools.wraps(test__CatchAllUndefinedParameters)
    def test(x: float,
             y: float,
             z: float = 3,
             w: float = 4,
             a: float = 1,
             b: float = 2,
             unknown: Optional[CatchAllVar] = None):
        pass

    class_fields = fields(test)
    for field in class_fields:
        if field.name == "unknown":
            break
    else:
        raise Exception(
            f"Could not find field 'unknown' in test class fields: "
            f"{class_fields}")



# Generated at 2022-06-23 16:58:42.146522
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config

    @dataclass
    class MySettings:
        c: int
        d: float
        e: str
        f: dict

    @dataclass_json()
    class MyClass:
        a: int
        b: float
        settings: MySettings

    myclass = MyClass(1, 2, MySettings(1, 2, "3", {"x": "y"}))
    expected = {
        "a": 1,
        "b": 2,
        "settings": {
            "c": 1,
            "d": 2,
            "e": "3",
            "f": {"x": "y"}
        },
        "a_str": "1"
    }
    actual = MyClass.__

# Generated at 2022-06-23 16:58:52.059145
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class C1:
        def __init__(self, a: int, b: int, c: int = 1,
                     d: Optional[CatchAllVar] = None):
            pass

    class C2:
        def __init__(self, a: int, b: int = 1,
                     d: Optional[CatchAllVar] = None):
            pass

    class C3:
        def __init__(self, a: int, b: int = 1, d: Optional[CatchAllVar] = None,
                     e: int = 1):
            pass

    def assert_raises_undefined_parameters_error(func, *args):
        """
        Assert that a function raises the expected error given some arguments
        """
        with pytest.raises(UndefinedParameterError):
            func(*args)


# Generated at 2022-06-23 16:58:53.518222
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # TODO
    pass

# Generated at 2022-06-23 16:59:03.179787
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameter = {'test': 123}
    known_parameters = {'a': 1, 'b': 2, 'c': 3}
    known_parameters.update(undefined_parameter)

    def assert_expected_result(actual_parameters: dict,
                               expected_parameters: dict):
        assert set(actual_parameters.keys()) == set(
            expected_parameters.keys())
        assert set(actual_parameters.values()) == set(
            expected_parameters.values())

    # do nothing for class_instance
    class_instance = object()
    assert_expected_result(
        _UndefinedParameterAction.handle_to_dict(class_instance,
                                                 known_parameters),
        known_parameters)

    # do nothing for class_instance
    class_instance = object

# Generated at 2022-06-23 16:59:10.512858
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class _TestClass:
        def __init__(self, a, **kwargs):
            pass

    _RaiseUndefinedParameters.handle_from_dict(
        _TestClass, {"a": 1, "b": 2})
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            _TestClass, {"b": 2})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:59:23.650653
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from marshmallow import Schema, fields

    class FooSchema(Schema):
        catch_all = fields.Dict()

    from typing import Dict
    from dataclasses_json.config import Config

    @dataclasses.dataclass
    class Foo:
        catch_all: Dict[Any, Any] = dataclasses.field(
            metadata={
                "marshmallow_field": fields.Dict(),
            })

        def __init__(self, **kwargs):
            pass

    cfg = Config.define(
        letter_case=Config.LetterCase.CAMEL,
        undefined=Config.Undefined.EXCLUDE,
        schema_class=FooSchema,
        unknown=Config.Unknown.EXCLUDE,
    )
    cls: type(Foo)
    cl

# Generated at 2022-06-23 16:59:32.812286
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    parameters = {"a": "a", "b": "b"}
    undefined_parameters = {"b": "b", "c": "c"}
    obj = Undefined.INCLUDE.value.create_init(
        TestCase.test_1)(**parameters, **undefined_parameters)
    assert obj.undefined == undefined_parameters
    parameters2 = Undefined.INCLUDE.value.handle_to_dict(obj, parameters)
    assert parameters2 == {"a": "a", "c": "c"}



# Generated at 2022-06-23 16:59:45.025736
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import Schema


    @dataclass(frozen=True)
    class A(DataClassJsonMixin):
        a: str
        b: str
        c: str


    @dataclass(frozen=True)
    class B(DataClassJsonMixin):
        a: str
        b: str
        c: str = "DEFAULT_C"


    @dataclass(frozen=True)
    class C(DataClassJsonMixin):
        a: str
        b: str
        c: str = "DEFAULT_C"
        d: CatchAll = None


    # test _RaiseUndefinedParameters

# Generated at 2022-06-23 16:59:53.284670
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    """
    Unit test for method handle_from_dict of class _UndefinedParameterAction.
    """
    import pytest

    class TestDataClass:
        atestfield: str
    class TestDataClassFactory:
        @staticmethod
        def from_dict(cls, kvs: Dict[str, Any]) -> "TestDataClass":
            known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
                cls=cls, kvs=kvs)
            return TestDataClass(atestfield=known["atestfield"])

    class TestDataClassCatchAllVar(CatchAllVar):
        pass


# Generated at 2022-06-23 17:00:06.329908
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Test that the create_init method of _IgnoreUndefinedParameters
    returns a function that ignores any number of unknown parameters
    """

    class ExampleClass:
        def __init__(self, *args, **kwargs):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(ExampleClass)

    # TODO find a better way to test this
    assert new_init(ExampleClass(), "a", "b", "c", a="a", b="b", c="c") is None
    assert new_init(ExampleClass(), "a", "b", "c", a="a", b="b", c="c", d="d") \
           is None

# Generated at 2022-06-23 17:00:16.530236
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.api import Schema


    @dataclasses.dataclass(frozen=True)
    class Test:
        a: int
        b: str
        c: CatchAll = None


    s = Schema(
        unknown_parameters=Undefined.INCLUDE
    )
    t = Test(1, "a", {"c": 2})
    assert s.dumps(t) == "{\"a\": 1, \"b\": \"a\", \"c\": {\"c\": 2}}"



# Generated at 2022-06-23 17:00:28.934245
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, a: int = 0, b: int = 1,
                     c: Optional[CatchAllVar] = None):
            pass

    class Bar:
        def __init__(self, a: int = 0, b: int = 1,
                     c: Optional[CatchAllVar] = None):
            pass

    class Baz:
        def __init__(self, a=0, b=1, c=None):
            pass

    import pytest
    foo = Foo()
    bar = Bar()
    baz = Baz()

    init_foo = _CatchAllUndefinedParameters.create_init(foo)
    init_bar = _CatchAllUndefinedParameters.create_init(bar)

# Generated at 2022-06-23 17:00:40.970497
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import argparse
    import itertools
    import sys
    import dataclasses
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE,
                                     letter_case=LetterCase.CAMEL)
    @dataclasses.dataclass
    class Foo:
        foo: str
        bar: int


    all_positions = [
        (1, 2),
        (2, 1),
        (0, 0),
        (1, 0),
        (0, 1),
    ]

    parser = argparse.ArgumentParser()
    parser.add_argument("--foo")
    parser.add_argument("--bar")

# Generated at 2022-06-23 17:00:50.363952
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: int, b: int = 2):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    actual = _IgnoreUndefinedParameters.handle_from_dict(cls=A, kvs=kvs)
    expected = {"a": 1, "b": 2}
    assert actual == expected

# Generated at 2022-06-23 17:00:54.872447
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class ExampleClass:
        def __init__(self, x: str):
            pass

    expected_error_msg = "Received undefined initialization arguments " \
                         "{'y': 12}"
    with pytest.raises(UndefinedParameterError,
                       match=re.escape(expected_error_msg)):
        _RaiseUndefinedParameters.handle_from_dict(ExampleClass, {"x": "a",
                                                                  "y": 12})



# Generated at 2022-06-23 17:01:05.243635
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    @dataclasses.dataclass
    class TestClass:
        defined_field: str
        another_defined_field: int

    def test_init(self, defined_field: str, another_defined_field: int = 12):
        pass
    TestClass.__init__ = test_init

    TestClass = _IgnoreUndefinedParameters.create_init(TestClass)

    TestClass("defined_field_value", "ignored_argument")
    TestClass("defined_field_value", "ignored_argument",
              "ignored_keyword_argument")
    TestClass("defined_field_value", "ignored_argument",
              "ignored_keyword_argument", another_defined_field="ignored")

# Generated at 2022-06-23 17:01:15.777486
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    def to_dict(cls) -> Dict[str, Any]:
        return dict(cls.__dict__)

    class CatchAllClass:
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

        def to_dict(self):
            return dict(a=self.a, b=self.b, c=self.c,
                        **self.catch_all)

        def __eq__(self, other):
            return isinstance(other, self.__class__) and \
                   other.__dict__ == self.__dict__


# Generated at 2022-06-23 17:01:26.104964
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    assert _RaiseUndefinedParameters.handle_from_dict(object,
                                                      {"a": 1, "b": 2}) == {"a": 1, "b": 2}
    # Missing field
    try:
        _RaiseUndefinedParameters.handle_from_dict(object,
                                                   {"a": 1, "b": 2, "c": 3})
    except UndefinedParameterError:
        pass
    else:
        assert False

    # Extra field
    try:
        _RaiseUndefinedParameters.handle_from_dict(object, {"a": 1})
    except UndefinedParameterError:
        pass
    else:
        assert False



# Generated at 2022-06-23 17:01:34.183997
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Dummy:
        def __init__(self, a: int, b: int):
            pass

    init_fct = _CatchAllUndefinedParameters.create_init(Dummy)
    obj = Dummy(a=1, b=2)
    init_fct(obj, *[1, 2, 3], **{})
    import pytest
    with pytest.raises(UndefinedParameterError):
        init_fct(obj, *[], **dict(c=3))

# Generated at 2022-06-23 17:01:41.512025
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.config import config as dataclass_json_config

    dataclass_json_config.undefined = Undefined.EXCLUDE

    @dataclass
    class TestDataClass(DataClassJsonMixin):
        a: int

    assert TestDataClass(a=1).to_dict() == {"a": 1}

    dataclass_json_config.undefined = Undefined.INCLUDE

    @dataclass
    class TestDataClass(DataClassJsonMixin):
        a: int
        _UNDEFINED: Optional[CatchAllVar] = dataclasses.field(
            metadata=dict(default_factory=dict))


# Generated at 2022-06-23 17:01:53.028904
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from copy import copy
    from dataclasses import asdict
    allocator = int

    def new_allocation():
        nonlocal allocator
        value = allocator
        allocator += 1
        return value

    # Create a dataclass with catch-all field
    @dataclasses.dataclass()
    class Dummy:
        a: int
        b: int = dataclasses.field(default_factory=new_allocation)
        c: CatchAll = None
        d: int = dataclasses.field(default_factory=new_allocation)


# Generated at 2022-06-23 17:02:03.161563
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import typing
    ignore_undefined_parameters_instance = _IgnoreUndefinedParameters()
    class TestClass:
        def __init__(self, a: typing.Optional[CatchAllVar], b: int, c="hello",
                     d: str ="world"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_class = TestClass(a=None, b=1, c="hello", d="world")
    result_init: Callable = ignore_undefined_parameters_instance.create_init(
        obj=test_class)
    result = result_init(test_class, a=None, b=1, c="hello", d="world")
    assert result == None

# Generated at 2022-06-23 17:02:03.985184
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass

# Generated at 2022-06-23 17:02:13.613743
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import typing
    import dataclasses
    import dataclasses_json
    from dataclasses import fields


    @dataclasses.dataclass
    class Dummy:
        foo: int = 10
        bar: str = "abc"
        baz: typing.Dict = dataclasses.field(default_factory=dict)
        _undefined: dataclasses_json.CatchAll = None


    @dataclasses.dataclass
    class Dummy2:
        foo: int = 10
        bar: str = "abc"
        baz: typing.Dict = dataclasses.field(default_factory=dict)
        _undefined2: dataclasses_json.CatchAll = None
        _undefined3: dataclasses_json.CatchAll = None



# Generated at 2022-06-23 17:02:24.912656
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # noinspection PyUnusedLocal
    class TestClass:
        def __init__(self, x: int, y: int = 0, z: int = 2):
            pass

    init_fun = _IgnoreUndefinedParameters.create_init(TestClass)
    init_fun(TestClass, 0, 0, 0, 0)
    init_fun(TestClass, 0, 0, a=0)
    init_fun(TestClass, 0, 0, a=0, b=1)
    init_fun(TestClass, 0, a=0)
    init_fun(TestClass, 0, a=0, b=1)
    init_fun(TestClass, a=0)
    init_fun(TestClass, a=0, b=1)

# Generated at 2022-06-23 17:02:27.549670
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(object, {
        "a": "a"}) == {"a": "a"}

# Generated at 2022-06-23 17:02:29.089578
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:02:41.479244
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class MyClass:
        def __init__(self, name, number_of_something, catch_all=None):
            self.name = name
            self.number_of_something = number_of_something
            self.catch_all = catch_all

    new_init = _CatchAllUndefinedParameters.create_init(MyClass)

    obj = new_init("MyClass", "name", "number_of_something",
                   catch_all={"key1": "value1", "key2": "value2"})

    assert obj.name == "name"
    assert obj.number_of_something == "number_of_something"
    assert obj.catch_all["key1"] == "value1"
    assert obj.catch_all["key2"] == "value2"

# Generated at 2022-06-23 17:02:54.189964
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import marshmallow

    @dataclasses.dataclass(frozen=True)
    class DataClass:
        a: int = dataclasses.field()
        b: int = dataclasses.field()

        def __init__(self, a: int, b: int, **kvs: Any):
            super().__init__(**kvs)

    class Schema(marshmallow.Schema):
        a = marshmallow.fields.Integer()
        b = marshmallow.fields.Integer()

    @dataclasses.dataclass(frozen=True,
                          init=True,
                          undefined=Undefined.EXCLUDE)
    class DataClass:
        a: int = dataclasses.field(metadata={"required": True})

# Generated at 2022-06-23 17:03:00.553468
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestPerson:
        name: str
        age: int
        catch_all: CatchAll


# Generated at 2022-06-23 17:03:10.954606
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class DummyOriginalInit(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self, dummy_arg: str) -> None:
            pass

    @dataclasses.dataclass()
    class DummyClass(DummyOriginalInit):
        dummy_arg: str = "dummy_arg"

        def __init__(self, dummy_arg: str) -> None:
            pass

    @dataclasses.dataclass()
    class DummyClass2(DummyOriginalInit):
        dummy_arg: str = "dummy_arg"

        @functools.wraps(DummyOriginalInit.__init__)
        def __init__(self, dummy_arg: str) -> None:
            pass

    obj = DummyClass
    new_init = _UndefinedParameterAction

# Generated at 2022-06-23 17:03:12.581815
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 17:03:20.307827
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class A:
        a: str
        b: int = 1

        def __init__(self, a="A_default", b=2, c=3):
            pass

    @dataclass
    class B:
        a: str
        b: int = 1
        c: Optional[CatchAllVar] = field(default_factory=dict)

        def __init__(self, a="A_default", b=2, c=3):
            pass

    @dataclass
    class C:
        a: str
        b: int = 1
        c: Optional[CatchAllVar] = field(default=CatchAllVar())


# Generated at 2022-06-23 17:03:28.746979
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Dummy:
        field: str

    params = {"field": "abc", "undefined": "undefined"}
    known_params = {"field": "abc"}
    assert _RaiseUndefinedParameters.handle_from_dict(Dummy, params) == \
           known_params

    def test_fails_with_undefined_parameters():
        _RaiseUndefinedParameters.handle_from_dict(Dummy, params)

    with pytest.raises(ValidationError):
        test_fails_with_undefined_parameters()



# Generated at 2022-06-23 17:03:39.401157
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class ExampleWithIgnore(object):
        def __init__(self, one: int, two: int, three: int):
            self.one = one
            self.two = two
            self.three = three

    catch_all_init = _IgnoreUndefinedParameters.create_init(
        ExampleWithIgnore
    )

    exam = ExampleWithIgnore(1, 2, 3)
    assert exam.one == 1
    assert exam.two == 2
    assert exam.three == 3

    exam2 = ExampleWithIgnore(1, 2, 3, four=4, five=5)
    assert exam2.one == 1
    assert exam2.two == 2
    assert exam2.three == 3

    exam3 = catch_all_init(1, 2, 3, four=4, five=5)
    assert exam3

# Generated at 2022-06-23 17:03:50.965671
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    @dataclasses.dataclass
    class TestClassWithCatchAll:
        catch_all: Optional[
            CatchAllVar] = dataclasses.field(default_factory=dict)

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    t = TestClass(a=1, b=2)
    assert {'a': 1, 'b': 2} == \
           _CatchAllUndefinedParameters.handle_to_dict(t, {'a': 1, 'b': 2,
                                                            'c': 3})

    t = TestClassWithCatchAll(a=1, b=2)

# Generated at 2022-06-23 17:03:56.200183
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            pass

    kvs = {"a": 1, "b": 2, "c": 4}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-23 17:04:06.417594
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class _Input:
        x: int
        y: int

    _parameters = {"x": 1, "y": 2, "z": 3}

    def _test(cls, parameters):
        _RaiseUndefinedParameters.handle_from_dict(cls, parameters)

    def _test_error(cls, parameters):
        with pytest.raises(UndefinedParameterError):
            _RaiseUndefinedParameters.handle_from_dict(cls, parameters)

    _test(_Input, _parameters)
    _test_error(_Input, {})
    _test_error(_Input, {"a": 1})
    _test_error(_Input, {"x": 1, "a": 1})



# Generated at 2022-06-23 17:04:07.880844
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Test(metaclass=abc.ABCMeta):
        pass

    Test()

# Generated at 2022-06-23 17:04:15.281388
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Define a dataclass
    import dataclasses
    from dataclasses_json import LetterCase

    @dataclasses.dataclass(frozen=True,
                           config=dataclasses_json.config(
                               letter_case=LetterCase.PASCAL,
                               undefined=Undefined.EXCLUDE
                           ))
    class Example:
        field_a: str
        field_b: str
        field_c: int = dataclasses.field(metadata={"default": 123})

    # E.g. for a to_dict or for_json serializer
    def to_dict(obj: Example) -> Dict[str, Any]:
        kvs = dataclasses.asdict(obj)
        kvs = _IgnoreUndefinedParameters.handle_to_dict(obj, kvs)


# Generated at 2022-06-23 17:04:19.084245
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls="cls", kvs={"unknown": "value"})
    except UndefinedParameterError:
        pass
    else:
        raise Exception("Error not raised")



# Generated at 2022-06-23 17:04:22.435759
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert \
        "handle_from_dict" in inspect.getmembers(_UndefinedParameterAction,
                                                 inspect.isfunction)

# Generated at 2022-06-23 17:04:25.020915
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    with pytest.raises(NotImplementedError):
        _UndefinedParameterAction.handle_dump(None)


# Generated at 2022-06-23 17:04:30.709609
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, a):
            self.a = a


    b = {
        "a": 123
    }
    defined, undefined = \
        _RaiseUndefinedParameters._separate_defined_undefined_kvs(Foo, b)
    assert defined == {"a": 123}
    assert undefined == {}

    b = {
        "d": 456
    }
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Foo, b)



# Generated at 2022-06-23 17:04:31.690647
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        pass

# Generated at 2022-06-23 17:04:39.107462
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class User:
        id: int
        name: str
        token: str = None

    user_class_with_original_init = User

    user_class_with_ignored_init = _UndefinedParameterAction.create_init(
        user_class_with_original_init)

    user = user_class_with_original_init(id=1, name="Bob", token="12345")
    user_with_ignored_init = user_class_with_ignored_init(id=1, name="Bob",
                                                           token="12345")

    assert user == user_with_ignored_init

# Generated at 2022-06-23 17:04:45.971336
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import json
    import unittest
    import dataclasses
    from typing import Dict
    from dataclasses import dataclass
    from marshmallow import Schema, fields as f, post_load, EXCLUDE
    from .enums import LetterCase
    from .converter import Converter

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(Converter, Schema):
        name = f.Str()
        age = f.Integer()
        _UNDEFINED_PARAMETER_ACTION = Undefined.EXCLUDE

        @post_load
        def make_person(self, data: Dict[str, Any], **kwargs) -> Person:
            return Person(**data)

    # vanilla, nothing unexpected

# Generated at 2022-06-23 17:04:52.167413
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    import numpy as np
    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class B:
        def __init__(self, x=1, y=2):
            self.x = x
            self.y = y

    class C:
        def __init__(self, x, y=2):
            self.x = x
            self.y = y

    class D:
        def __init__(self, x: np.ndarray, y=2):
            self.x = x
            self.y = y

    class E:
        def __init__(self, x: int, y: int, z: int = 3):
            self.x = x
            self.y = y
            self.z = z


# Generated at 2022-06-23 17:05:00.589249
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Test:
        def __init__(self,
                     a: int,
                     b: int,
                     *args,
                     foo: str,
                     unknown_kws: CatchAll = None,
                     **kwargs):
            pass

    Test._UNDEFINED_PARAMETERS = _CatchAllUndefinedParameters
    _CatchAllUndefinedParameters.create_init(Test)
    _CatchAllUndefinedParameters.handle_from_dict(Test, dict(
        a=1, b=2, foo="hello"))

# Generated at 2022-06-23 17:05:11.505913
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a: str, b: int, catch_all: CatchAll = None) -> None:
            pass

    original_init = A.__init__
    init_signature = inspect.signature(original_init)

    def _check_undefined_init(self, a):
        bound_parameters = init_signature.bind_partial(self, a=a)
        bound_parameters.apply_defaults()
        assert bound_parameters.arguments["a"] == a
        assert bound_parameters.arguments["b"] == 5  # type: ignore
        # Catch-all is expected to be None
        assert bound_parameters.arguments["catch_all"] is None  # type: ignore
        original_init(**bound_parameters.arguments)


# Generated at 2022-06-23 17:05:17.578839
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, defined_parameter: str, *args, **kwargs):
            pass
    kvs = {"defined_parameter": "asdf", "unknown_parameter": "asdf2"}
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {"defined_parameter": "asdf"}



# Generated at 2022-06-23 17:05:28.362709
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, a: int, b: float, c: str, d: int):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.__undefined_parameters = {}

    class B:
        def __init__(self, a: int, b: float, c: str, d: int,
                     undefined_parameters: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.__undefined_parameters = undefined_parameters if \
                undefined_parameters else {}
