

# Generated at 2022-06-23 16:55:31.812441
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

    t = Test(1, 2)

# Generated at 2022-06-23 16:55:40.522388
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # noinspection PyStatementEffect
    """
    This class allows to add a field of type utils.CatchAll which acts as a
    dictionary into which all
    undefined parameters will be written.
    These parameters are not affected by LetterCase.
    If no undefined parameters are given, this dictionary will be empty.
    """

    class _SentinelNoDefault:
        pass

    @staticmethod
    def handle_from_dict(cls, kvs: Dict) -> Dict[str, Any]:
        known, unknown = _UndefinedParameterAction \
            ._separate_defined_undefined_kvs(cls=cls, kvs=kvs)
        catch_all_field = _CatchAllUndefinedParameters._get_catch_all_field(
            cls=cls)


# Generated at 2022-06-23 16:55:43.601344
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert isinstance(e, ValidationError)
        assert str(e) == "test"
        assert e.messages == ["test"]

# Generated at 2022-06-23 16:55:46.404339
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    _UndefinedParameterAction.handle_to_dict(None, kvs={})
    assert True

# Generated at 2022-06-23 16:55:47.910777
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump("") == {}

# Generated at 2022-06-23 16:55:55.851348
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # region Test create_init without any unknown args
    class SomeDataClass:
        def __init__(self, *args, **kwargs):
            self.a = kwargs.pop("a")
            self.b = kwargs.pop("b")
            self.c = kwargs.pop("c")
            self.d = kwargs.pop("d")


    init = _CatchAllUndefinedParameters.create_init(SomeDataClass)
    instance = init(SomeDataClass(3, 2, 1, a=4, b=5, c=6, d=7))
    assert instance.a == 4
    assert instance.b == 5
    assert instance.c == 6
    assert instance.d == 7
    # endregion

    # region Test create_init with unknown args

# Generated at 2022-06-23 16:55:57.989649
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert {} == _UndefinedParameterAction.handle_dump("a string")



# Generated at 2022-06-23 16:55:59.984199
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        raise AssertionError
    except TypeError:
        pass

# Generated at 2022-06-23 16:56:00.987419
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    Undefined.INCLUDE.value._CatchAllUndefinedParameters.create_init(None)

# Generated at 2022-06-23 16:56:07.410090
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    private_variable = 0

    # noinspection PyUnusedLocal
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            assert private_variable == 10
            private_variable = 0

    class_fields = fields(TestClass)
    assert len(class_fields) == 3
    _CatchAllUndefinedParameters.create_init(TestClass)
    # noinspection PyUnusedLocal
    private_variable = 10
    test_instance = TestClass(1, 2, 3)
    test_instance = TestClass(1, 2, 3)
    test_instance = TestClass(1, 2)
    test_instance = TestClass(1)

# Generated at 2022-06-23 16:56:12.512830
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    dummy_original_to_dict = {
        "a": 1,
        "b": 2
    }
    dummy = _UndefinedParameterAction()
    output = dummy.handle_to_dict(obj=None, kvs=dummy_original_to_dict)
    assert output == dummy_original_to_dict


# Generated at 2022-06-23 16:56:14.970678
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class _Test:
        pass

    test_obj = _Test()
    output = _UndefinedParameterAction.handle_dump(test_obj)
    assert output == {}

# Generated at 2022-06-23 16:56:22.822673
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses

    @dataclasses.dataclass
    class A:
        a: int = 1
        b: str = "Hello"
        _undefined: Optional[CatchAllVar] = None

    a = A(a=1, b="Hello", c="World")
    expected_dict = {"a": 1, "b": "Hello",
                     "c": "World"}
    result = _CatchAllUndefinedParameters.handle_to_dict(obj=A,
                                                         kvs=dataclasses.asdict(
                                                             a))
    assert result == expected_dict

# Generated at 2022-06-23 16:56:29.159904
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():

    class TestClass:
        def __init__(self, a: int, b: str, c: str = "hello", d: str = "world"):
            pass

    init = _IgnoreUndefinedParameters.create_init(TestClass)
    init(TestClass, 1, "hello", "world", "a", "b")
    init(TestClass, 1, "hello", "world", "a", "b", "c", "d")
    init(TestClass, 1, "hello", a="a", b="b")
    init(TestClass, 1, "hello", a="a", b="b", c="c", d="d")

    init(TestClass, 1, "hello")
    init(TestClass, 1, "hello", "world")

# Generated at 2022-06-23 16:56:31.853642
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    exception = UndefinedParameterError("foo")
    assert exception.messages == ["foo"]



# Generated at 2022-06-23 16:56:39.281452
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: dict = {}):
            self.a = a
            self.b = b
            self.c = c

    test_instance = TestClass(1, 2, c={"d": 45})
    kvs = {"a": 56, "b": 76, "c": 3}
    actual = _CatchAllUndefinedParameters.handle_to_dict(test_instance, kvs)
    expected = {"a": 56, "b": 76, "d": 45}
    assert actual == expected

# Generated at 2022-06-23 16:56:48.053071
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int

    @dataclasses.dataclass
    class TestSubclass(TestClass):
        c: int

    kvs = {"a": "test", "b": 3, "c": 2, "d": 4}
    known_kvs = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_kvs == {"a": "test", "b": 3}
    assert kvs == {"a": "test", "b": 3, "c": 2, "d": 4}

    known_kvs = _IgnoreUndefinedParameters.handle_from_dict(TestSubclass, kvs)
    assert known_kvs == {"a": "test", "b": 3, "c": 2}

# Generated at 2022-06-23 16:56:58.234490
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # GIVEN a class with catch-all field
    class FooBar:
        catch_all: CatchAll = CatchAllVar(default={})

    # WHEN calling handle_from_dict without undefined parameters
    parameters = _CatchAllUndefinedParameters.handle_from_dict(FooBar, {})

    # THEN we get an empty dictionary as field value
    assert parameters["catch_all"] == {}

    # WHEN calling handle_from_dict with undefined parameters
    parameters = _CatchAllUndefinedParameters.handle_from_dict(FooBar,
                                                               {"a": "b"})

    # THEN we get the undefined parameters as field value
    assert parameters["catch_all"] == {"a": "b"}



# Generated at 2022-06-23 16:57:01.698695
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    assert _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        None, {}) == ({}, {})



# Generated at 2022-06-23 16:57:09.612546
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    x = None
    y = None

    def __init__(self):
        nonlocal x, y
        x = 42
        y = 47

    obj = type('TestClass', (), {})
    obj.__init__ = __init__
    obj.__init__()
    assert x == 42
    assert y == 47

    new_init = _UndefinedParameterAction.create_init(obj)
    new_init(obj)
    assert x == 42
    assert y == 47

# Generated at 2022-06-23 16:57:17.939982
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    IGNORE_PARAMS = "I will be ignored"
    REQUIRED_PARAM = "I am required"

    @dataclasses.dataclass
    class TestClass:
        ignore_this: str = IGNORE_PARAMS
        safe_this: str = REQUIRED_PARAM

        def __init__(self, safe_this: str = REQUIRED_PARAM):
            self.safe_this = safe_this

    tc = TestClass(safe_this=REQUIRED_PARAM)
    assert tc.safe_this == REQUIRED_PARAM
    assert tc.ignore_this == IGNORE_PARAMS

    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    tc = TestClass(safe_this=REQUIRED_PARAM, ignore_this="")
    assert tc.safe

# Generated at 2022-06-23 16:57:20.198947
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    assert _CatchAllUndefinedParameters._get_catch_all_field(CatchAll) == \
           CatchAllVar.__dataclass_fields__["kv"]

# Generated at 2022-06-23 16:57:28.726805
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    This test ensures that the method create_init creates an init method
    which provides the correct number of required arguments.
    """

    class _ClassWithCatchAll:
        def __init__(self, arg_1: int, arg_2: int,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    _ClassWithCatchAll2 = dataclasses.replace(
        _ClassWithCatchAll,
        frozen=True,
        init=_IgnoreUndefinedParameters.create_init(_ClassWithCatchAll))
    no_parameters = _ClassWithCatchAll2(1, 1)
    with pytest.raises(TypeError):
        no_parameters.__init__(arg_1_given=1)


# Generated at 2022-06-23 16:57:34.545923
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: str, b: int = 2, *, c: int = 0, **undefined):
            self.a = a
            self.b = b
            self.c = c
            self.undefined = undefined

    assert _CatchAllUndefinedParameters.create_init(TestClass) is TestClass.__init__



# Generated at 2022-06-23 16:57:39.853153
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # case 1: we have a dictionary
    obj_1 = dataclasses.dataclass()(unknown=dict(a=1))
    assert isinstance(_CatchAllUndefinedParameters.handle_dump(obj_1), dict)

    # case 2: we have an attribute, not a dictionary
    obj_2 = dataclasses.dataclass()(unknown=2)
    with pytest.raises(TypeError):
        _CatchAllUndefinedParameters.handle_dump(obj_2)

# Generated at 2022-06-23 16:57:52.212061
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # type: () -> None

    @dataclasses.dataclass(frozen=True)
    class TestClass:

        test_int: int
        test_float: float
        test_str: str

        def __init__(self, test_int, test_float=1, test_str="abc"):
            self.test_int = test_int
            self.test_float = test_float
            self.test_str = test_str

    from unittest.mock import MagicMock

    def mocked_init(*args, **kwargs):
        pass

    TestClass.__init__ = mocked_init
    init_test_class = _UndefinedParameterAction.create_init(TestClass)

    # Define some values which we assert to be passed to the __init__ method
    # when the init_test_

# Generated at 2022-06-23 16:58:00.643915
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int = None
        b: str = None
        c: int = None

    kvs = {"a": 1}
    kvs = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert set(kvs.keys()).issubset({"a", "c"})



# Generated at 2022-06-23 16:58:09.695877
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        known: Optional[int]
        catch_all: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

        def __init__(self,
                     known: Optional[int],
                     catch_all: Optional[CatchAllVar] = dataclasses.field(
                         default_factory=dict)):
            self.known = known
            self.catch_all = catch_all

        def __eq__(self, other):
            return (self.known == other.known) and (self.catch_all == other.catch_all)

    given_known = 1
    given_unknown = "value"
    given = {"known": given_known, "unknown": given_unknown}

    given_known_list = [1, 2]

# Generated at 2022-06-23 16:58:11.303167
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError, match="Can't instantiate abstract class _UndefinedParameterAction with abstract methods handle_from_dict"):
        _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:12.635078
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    method = _CatchAllUndefinedParameters.create_init



# Generated at 2022-06-23 16:58:19.456314
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class _TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass


    tc = _TestClass(1, 2, 3)
    init_method = _UndefinedParameterAction.create_init(tc)
    assert init_method.__name__ == "test__UndefinedParameterAction_create_init.<locals>._TestClass._ignore_init"
    init_method(tc, 1, 2, 3)
    init_method(tc, 1, 2, 3, d=4)

# Generated at 2022-06-23 16:58:28.818261
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses
    import dataclasses_json
    import unittest
    from marshmallow import post_dump, Schema

    @dataclasses.dataclass
    class Simple(object):
        a: str
        b: int = 0

    @dataclasses.dataclass
    class IgnoreUndefined(object):
        a: int
        b: str = dataclasses.field(default_factory=str)

    # noinspection PyTypeChecker
    @dataclasses_json.dataclass_json(undefined=Undefined.EXCLUDE)
    class IgnoreUndefinedJSON(object):
        a: int
        b: str = dataclasses.field(default_factory=str)

    # noinspection PyTypeChecker

# Generated at 2022-06-23 16:58:32.272281
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test:
        a: str = "Test"
        catch_all: Optional[CatchAllVar] = None

    t = Test()
    assert _CatchAllUndefinedParameters.handle_dump(t) == {}

    t.catch_all = {"Hello": "World"}
    assert _CatchAllUndefinedParameters.handle_dump(t) == {"Hello": "World"}



# Generated at 2022-06-23 16:58:38.501107
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a=None, b=None, **_catch_all):
            pass
        catch_all = dict()

    assert _CatchAllUndefinedParameters \
           .handle_to_dict(obj=TestClass(),
                           kvs=dict(a=1, b=2, c=3, d="d")) == dict(a=1, b=2)



# Generated at 2022-06-23 16:58:47.781059
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert not _UndefinedParameterAction.__dict__["handle_from_dict"].__isabstractmethod__
    assert not _UndefinedParameterAction.__dict__["handle_to_dict"].__isabstractmethod__
    assert not _UndefinedParameterAction.__dict__["handle_dump"].__isabstractmethod__
    assert not _UndefinedParameterAction.__dict__["create_init"].__isabstractmethod__


# Generated at 2022-06-23 16:59:01.504943
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import abc


    @dataclasses.dataclass
    class TestClass:
        a: int = 0
        b: float = 0.0
        c: Optional[CatchAllVar] = None

        def __init__(self, a, b, c):
            if not isinstance(c, abc.Mapping):
                raise TypeError("argument 'd' must be a Mapping")

        def __repr__(self):
            return f"TestClass(a={self.a}, b={self.b}, c={self.c})"

    t = TestClass(a=1, b=2, c={})
    print(repr(t))

    # Test _IgnoreUndefinedParameters
    init = _IgnoreUndefinedParameters.create_init(TestClass)

# Generated at 2022-06-23 16:59:08.829164
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass
    from dataclasses_json import Undefined

    @dataclass
    class X:
        a: str
        b: int
        c: Undefined = Undefined.EXCLUDE

    x = X(a="a", b=1)
    assert len(_CatchAllUndefinedParameters.handle_dump(x)) == 0

    @dataclass
    class Y:
        a: str
        b: int
        c: Undefined = Undefined.INCLUDE

    y = Y(a="a", b=1, d=2)
    assert len(_CatchAllUndefinedParameters.handle_dump(y)) == 1
    assert _CatchAllUndefinedParameters.handle_dump(y)["d"] == y.c["d"]


# Generated at 2022-06-23 16:59:16.197999
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: str = "a"
        optional: CatchAll = None

    @dataclass
    class B:
        a: str = "b"
        optional: CatchAll = None

    @dataclass
    class C:
        a: str = "c"
        optional: CatchAll = None

    @dataclass
    class Nested:
        c: C = C()
        optional: CatchAll = None

    @dataclass
    class EvenMoreNested:
        nested: Nested = Nested()
        optional: CatchAll = None

    @dataclass
    class EvenMoreNested2:
        nested: Nested = Nested()
        optional: CatchAll = None


# Generated at 2022-06-23 16:59:17.743390
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters()

# Generated at 2022-06-23 16:59:25.780550
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class MyClass:
        def __init__(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c
            self.d = 4

    result = MyClass(1, 2)
    assert _UndefinedParameterAction.handle_to_dict(result, {
        "a": result.a,
        "b": result.b,
        "c": result.c,
        "d": result.d
    }) == {
        "a": result.a,
        "b": result.b,
        "c": result.c,
        "d": result.d
    }



# Generated at 2022-06-23 16:59:27.940817
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    UndefinedParameterAction = _UndefinedParameterAction
    UndefinedParameterAction()

# Generated at 2022-06-23 16:59:34.798236
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import marshmallow.fields as mf
    import dataclasses


    @dataclasses.dataclass
    class ClassA(metaclass=dataclasses_json.DataClassJson):
        a: str
        b: int
        c: dict = dataclasses.field(default_factory=dict)


    a = ClassA("a", 1)
    schema = dataclasses_json.schema_for_dataclass(ClassA)
    dump_result = schema.dump(a)

    assert dump_result == {"a": "a", "b": 1, "c": {}}



# Generated at 2022-06-23 16:59:43.474050
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow_dataclass
    from marshmallow import Schema, fields
    from dataclasses_json import DataClassJsonMixin

    class MySchema(Schema):
        a = fields.Int()
        b = fields.Int(missing=1)
        c = fields.Int()

    @dataclasses.dataclass
    class MyDataClass(DataClassJsonMixin):
        a: int
        b: int = 1
        c: int

        __init__ = _IgnoreUndefinedParameters.create_init(lambda self, a, b, c: None)

    MyDataClass(1, 2, d=3)

    class TestClass:
        def __init__(self, a, b=1, c=3):
            pass

    _IgnoreUndefinedParameters.create_init(TestClass)



# Generated at 2022-06-23 16:59:50.090641
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class A:
        catch_all: Optional[CatchAllVar]

    a = A(catch_all={"a": "b"})
    dump = _CatchAllUndefinedParameters.handle_dump(a)
    assert dump == {"a": "b"}



# Generated at 2022-06-23 16:59:54.419408
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b


    _IgnoreUndefinedParameters.create_init(Test)(Test(0, 0), c=1, d=2)


if __name__ == "__main__":
    test__IgnoreUndefinedParameters()

# Generated at 2022-06-23 17:00:06.831116
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    undefined_parameter_handler = _IgnoreUndefinedParameters()
    defined_class = dataclasses.make_dataclass("Defined", [("a", int)])
    defined_kvs = {"a": 1}
    undefined_kvs = {"b": 2}
    mixed_kvs = {"a": 1, "b": 2}

    assert undefined_parameter_handler.handle_from_dict(cls=defined_class,
                                                        kvs=undefined_kvs) == {}
    assert undefined_parameter_handler.handle_from_dict(cls=defined_class,
                                                        kvs=defined_kvs) == {
                                                           "a": 1}

# Generated at 2022-06-23 17:00:08.882938
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    value = _UndefinedParameterAction.handle_dump(None)
    assert value == {}

# Generated at 2022-06-23 17:00:14.675602
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a: int, b: int = 3, **kwargs):
            pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, {"a": 1, "b": 2,
                                                          "c": 3})
    _RaiseUndefinedParameters.handle_from_dict(Test, {"a": 1})
    _RaiseUndefinedParameters.handle_from_dict(Test, {"a": 1, "b": 2})



# Generated at 2022-06-23 17:00:19.136208
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class DummyClass:
        def __init__(self, catch_all: Optional[CatchAllVar]=None):
            self.catch_all = catch_all

    expected_dict = {'foo': 'bar'}
    obj = DummyClass(catch_all=expected_dict)
    actual_dict = _CatchAllUndefinedParameters.handle_dump(obj)
    assert actual_dict == expected_dict


# Unit tests for method _get_catch_all_field of class _CatchAllUndefinedParameters

# Generated at 2022-06-23 17:00:22.762224
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # noinspection PyUnusedLocal
    def should_fail_with_message(message: str):
        try:
            raise UndefinedParameterError(message)
        except UndefinedParameterError as e:
            assert e.args[0] == message # The message must be contained in the error args
    should_fail_with_message(message="function")
    should_fail_with_message(message="function")

# Generated at 2022-06-23 17:00:24.413782
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    undefined_parameter_action = _UndefinedParameterAction()
    assert issubclass(undefined_parameter_action.__class__,
                      _UndefinedParameterAction)

# Generated at 2022-06-23 17:00:34.836351
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, alpha: str, beta: str, gamma: str, delta: int,
                     epsilon: str) -> None:
            self.alpha = alpha
            self.beta = beta
            self.gamma = gamma
            self.delta = delta
            self.epsilon = epsilon

    obj = TestClass("a", "b", "c", 3, "e")
    init = _IgnoreUndefinedParameters.create_init(obj)
    assert isinstance(init, Callable)

    class TestClass2:
        def __init__(self, alpha: str, beta: str, gamma: str, delta: int,
                     epsilon: str) -> None:
            self.alpha = alpha
            self.beta = beta
            self.gamma = gamma

# Generated at 2022-06-23 17:00:40.547133
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class C:
        a: str
        b: str

    parameters = {'a': 'a', 'c': 'c'}
    only_defined_parameters = _UndefinedParameterAction.handle_from_dict(C,
                                                                         parameters)

    assert only_defined_parameters == {'a': 'a'}



# Generated at 2022-06-23 17:00:53.760336
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, foo: int, bar: int, baz: int) -> None:
            self.foo = foo
            self.bar = bar
            self.baz = baz

        def __eq__(self, other):
            # This should be in a different test LATER
            if isinstance(other, TestClass):
                return self.foo == other.foo and self.bar == other.bar and self.baz == other.baz
            return False

    a = _IgnoreUndefinedParameters.create_init(TestClass)(None, 1, 2)
    assert a.foo == 1
    assert a.bar == 2
    assert a.baz == 0



# Generated at 2022-06-23 17:00:59.303809
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class _TestClass:
        a: int
        b: str
        c: int
        d: str

    sample_data_1 = {"a": 1, "b": "test", "c": 4, "d": "ok", "e": "too many"}
    sample_data_2 = {"a": 1, "b": "test"}

    known_params, unknown_params = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=_TestClass,
            kvs=sample_data_1)

    assert known_params == {"a": 1, "b": "test", "c": 4, "d": "ok"}
    assert unknown_params == {"e": "too many"}

    known_params, unknown_params = \
        _UndefinedParameterAction._separate_defined_

# Generated at 2022-06-23 17:01:07.576583
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        p: Tuple[Any]
        q: int

    import marshmallow

    class TestSchema(marshmallow.Schema):
        p = marshmallow.fields.Constant((1, 2, 3))
        q = marshmallow.fields.Int(missing=5)

    t = TestClass.__new__(TestClass)
    _IgnoreUndefinedParameters.create_init(t)(t, _UNKNOWN0=0, _UNKNOWN1=1)
    assert t.q == 5
    assert t.p == (1, 2, 3)

# Generated at 2022-06-23 17:01:16.980539
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    CatchAll = Optional[CatchAllVar]
    @dataclasses.dataclass
    class A:
        i: int
        f: float = 0.0
        b: bool = False
        s: str = ""
        c: CatchAll = None
        d: Dict[str, int] = dataclasses.field(default_factory=dict)
        n: None = None

    kvs = {
        "i": 3,
        "f": 1.1,
        "b": True,
        "s": "string",
        "c": {"undefined_key": "undefined_value"},
        "d": {"defined_key": 3},
        "n": None
    }
    a = A(**kvs)
    assert a.i == 3
    assert a.f == 1.1
   

# Generated at 2022-06-23 17:01:26.700557
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    import unittest


    class TestClass:
        def __init__(self, a: str, b: str = None, c: str = None,
                     **kwargs) -> None:
            self.a = a
            self.b = b
            self.c = c
            self.kwargs = kwargs


    class TestClassTestCase(unittest.TestCase):
        def test_undefined_parameter_error_raised(self):
            with self.assertRaises(UndefinedParameterError):
                TestClass(a="a", unknown="b")

    unittest.main()


# Unit tests for constructor of class _IgnoreUndefinedParameters

# Generated at 2022-06-23 17:01:37.679775
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, a, b, **kwargs):
            pass

    @dataclasses.dataclass
    class Example2:
        a1: int = 1

    kv = {"a1": 1, "b1": 2}
    kv_exclude = {"a1": 1}

    assert _IgnoreUndefinedParameters.handle_from_dict(Example, kv) == {
        "a": 1, "b": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(Example2, kv) == {
        "a1": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(Example2,
                                                       kv_exclude) == {
                                                           "a1": 1}



# Generated at 2022-06-23 17:01:46.906519
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    def assert_throws(kvs: Dict[Any, Any], message: str):
        try:
            _RaiseUndefinedParameters.handle_from_dict(int, kvs)
            assert False
        except UndefinedParameterError as e:
            assert e.args[0] == message

    assert_throws(kvs={}, message="Received undefined initialization arguments "
                                  "{}")
    assert_throws(kvs={"a": 1}, message="Received undefined initialization "
                                       "arguments {'a': 1}")



# Generated at 2022-06-23 17:01:55.799599
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        x: int = 0

        def __init__(self, x: int = None, y: int = None,
                     catch_all: CatchAllVar = None):
            self.x = x
            self.y = y
            self.catch_all = catch_all

    def get_x(obj):
        return obj.x

    def get_y(obj):
        return obj.y

    def get_catch_all(obj):
        return obj.catch_all

    custom_init = _CatchAllUndefinedParameters.create_init(TestClass)
    t = TestClass()
    assert t.x == 0
    assert get_y(t) is None

    custom_init(t, 1)
    assert get_x(t) == 1
    assert get_y(t) is None


# Generated at 2022-06-23 17:02:05.914242
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    import sys
    import pytest
    from typing import Union
    from typing import Dict
    from dataclasses import dataclass

    undefined = Undefined.EXCLUDE

    @dataclass(undefined=undefined)
    class Data:
        a: Union[str, int]
        b: str
        c: int = 1

    param_dict: Dict[str, Any] = {
        "a": 1,
        "b": "hello",
        "c": 2,
        "d": "I'm undefined!",
        "e": 5
    }

    output_dict = {
        "a": 1,
        "b": "hello",
        "c": 2
    }

    # noinspection PyProtectedMember

# Generated at 2022-06-23 17:02:13.334425
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    a_parameter = 100

    @dataclasses.dataclass
    class DummyClass:
        some_field: str
        b_parameter: int

        def __init__(self, **kvs):
            dataclasses.dataclass_init(self, **kvs)

    dummy_instance = \
        DummyClass(some_field="test", b_parameter=a_parameter)

    d = {"some_field": "test", "b_parameter": a_parameter}
    kwargs = _IgnoreUndefinedParameters.handle_from_dict(DummyClass, d)
    dummy_instance2 = DummyClass(**kwargs)

    assert dummy_instance == dummy_instance2


# Generated at 2022-06-23 17:02:23.084487
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: int
        c: int

    test = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        Test,
        {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": 4
        }
    )
    assert test == ({
        "a": 1,
        "b": 2,
        "c": 3
    }, {
        "d": 4
    })



# Generated at 2022-06-23 17:02:33.655772
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class DataClass:
        name: str
        value: int
        catch_all: CatchAll = None

    undefined = _CatchAllUndefinedParameters

    def test_init(obj, **kvs):
        init = undefined.create_init(obj)
        init(obj, **kvs)

    test_init(DataClass(name="foo", value=5, catch_all=[1, 2]),
              name="bar",
              value=7,
              some_other_thing=[])
    assert DataClass(name="foo", value=5, catch_all=[1, 2]).catch_all == [1, 2]

    tester = DataClass(name="foo", value=5)

# Generated at 2022-06-23 17:02:41.173944
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        pass

    class TestSubClass(TestClass):
        pass

    @dataclasses.dataclass()
    class TestDataClass(TestSubClass):
        x: str
        y: str = "hello"

    print(TestDataClass.__init__.__defaults__)
    print(TestDataClass.__init__.__annotations__)

    # args = []
    # kwargs = {"x": "x", "y": "y", "z": "z"}
    # num_args_takeable = 2
    #
    # for i, arg in enumerate(args):
    #     if i <= num_args_takeable:
    #         kwargs[list(TestDataClass.__init__.__annotations__.keys())[i]] = arg
    #     else:

# Generated at 2022-06-23 17:02:49.692947
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    # Should not change anything
    init_method = _UndefinedParameterAction.create_init(TestClass)
    assert init_method is TestClass.__init__

    # Should not change
    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init_method is TestClass.__init__

    # Should not change
    init_method = _RaiseUndefinedParameters.create_init(TestClass)
    assert init_method is TestClass.__init__

    class TestClass:
        def __init__(self, _ignore1, _ignore2):
            pass

    # Should not change
    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init_method

# Generated at 2022-06-23 17:02:58.718545
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class SomeClass:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def _test_from_dict(from_dict, expected):
        parameters_from_dict = \
            _UndefinedParameterAction.handle_from_dict(cls=SomeClass,
                                                       kvs=from_dict)

        sc = SomeClass(**parameters_from_dict)
        to_dict = _UndefinedParameterAction.handle_to_dict(sc, kvs=sc.kwargs)
        assert to_dict == expected

    _test_from_dict(from_dict={"a": 1}, expected={"a": 1})



# Generated at 2022-06-23 17:03:10.134118
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    import pytest

    def create_cls(field: Field):
        @dataclasses.dataclass
        class _cls:
            field: Any = field

            def __init__(self, **kwargs):
                for k, v in kwargs.items():
                    setattr(self, k, v)

            def __eq__(self, other):
                if not isinstance(other, _cls):
                    return False
                return self.field == other.field

        return _cls

    def check_dump_behavior(cls, undefined_action, params, expected):
        @dataclasses_json.config(unknown=undefined_action)
        class _cls(cls):  # noqa
            pass

        obj_current = _cls(**params)

# Generated at 2022-06-23 17:03:18.255103
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int = 0
        catch_all: Optional[CatchAllVar]
        def __init__(self, a: int, catch_all: Optional[CatchAllVar]):
            self.a, self.catch_all = a, catch_all


# Generated at 2022-06-23 17:03:28.980059
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAll


    @dataclasses.dataclass
    class ClassWithCatchAll(object):
        name: str
        # noinspection PyUnresolvedReferences
        catch_all: Optional[CatchAll] = dataclasses.field(default=None)
        # noinspection PyUnresolvedReferences
        catch_all_with_default: Optional[CatchAll] = dataclasses.field(
            default_factory=lambda: {"a": 1})


    expected_class_defined = {"name": "Bob", "catch_all": {"b": 2}}
    expected_class_with_default_defined = {"name": "Bob",
                                           "catch_all_with_default": {
                                               "a": 1}}
    expected_class_with_default_extended

# Generated at 2022-06-23 17:03:31.541967
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={})



# Generated at 2022-06-23 17:03:38.788717
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass(frozen=True)
    class Thingie:
        catchall: Optional[CatchAllVar] = None

    o = Thingie()
    assert _CatchAllUndefinedParameters.handle_dump(o) == {}

    o = Thingie(catchall={})
    assert _CatchAllUndefinedParameters.handle_dump(o) == {}

    o = Thingie(catchall={"foo": "bar"})
    assert _CatchAllUndefinedParameters.handle_dump(o) == {"foo": "bar"}



# Generated at 2022-06-23 17:03:46.910538
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass(object):
        def __init__(self, catch_all: CatchAll = None):
            self.catch_all = catch_all

    test1 = TestClass(catch_all={"test": 1, "test2": 2})
    kvs = {"test": 1, "test2": 2}
    assert _CatchAllUndefinedParameters.handle_to_dict(
        test1, kvs) == {"test": 1, "test2": 2}



# Generated at 2022-06-23 17:03:56.753557
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Cls(object):

        def __init__(self, a, b, c, d, f=3):
            pass

    def test_case(obj, kwargs, expected_error_type):
        _UndefinedParameterAction.create_init(obj)(obj, **kwargs)

    test_case(Cls,
              {"a": 1, "b": 1, "c": 1, "d": 1},
              None)

    expected_error = UndefinedParameterError
    test_case(Cls,
              {"a": 1, "b": 1, "c": 1},
              expected_error)

    expected_error = UndefinedParameterError
    test_case(Cls, {"a": 1, "b": 1, "c": 1, "d": 1, "x": "unknown"},
              expected_error)


# Generated at 2022-06-23 17:04:03.446920
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        param_a: str
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, param_a, catch_all=None):
            print(param_a)
            print(catch_all)

    init = _CatchAllUndefinedParameters.create_init(obj=MyClass)
    init(MyClass, "a", "b")

# Generated at 2022-06-23 17:04:12.574343
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    """
    The create_init method of _CatchAllUndefinedParameters is not covered by
    unit tests, since it is called by dataclasses_json.config and not
    directly by the user.
    """
    import datetime
    import dataclasses
    from typing import Any, Dict, Optional

    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    class TestClass:
        # Define a field of type CatchAllVar
        _catch_all: Optional[CatchAllVar] = None
        field1: int
        field2: str = None
        field3: datetime.datetime = datetime.datetime.now()
        field4: str = "default_string"


# Generated at 2022-06-23 17:04:18.164881
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class test1:
        a: str = "A"
        b: str = "B"
        c: str = "C"
        attr: Optional[CatchAllVar] = dataclasses.field(default=None,
                                                        metadata={
                                                            'dataclasses_json': {
                                                                'undefined': Undefined.INCLUDE}})

    c = _CatchAllUndefinedParameters._get_catch_all_field(test1)
    assert c.name == "attr"

    @dataclasses.dataclass
    class test2:
        a: str = "A"
        b: str = "B"
        c: str = "C"

# Generated at 2022-06-23 17:04:29.814544
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A():
        a: int
        b: int
        c: str
        d: int = dataclasses.field(default=0)
        e: int = dataclasses.field(default=0)
        catch_all: CatchAll = \
            dataclasses.field(default_factory=dict)

    init_ = _CatchAllUndefinedParameters.create_init(A)

    assert init_(A, 1, 2, "3", d=4, e=5, catch_all=6) == A(1, 2, "3", 4, 5, 6)
    # Don't include the default catch_all
    assert init_(A, 1, 2, "3", d=4, e=5) == A(1, 2, "3", 4, 5, {})


# Generated at 2022-06-23 17:04:32.799402
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {"a": 1, "b": 2}) \
           == {"a": 1, "b": 2}

# Generated at 2022-06-23 17:04:40.829041
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, param1: int, param2: int,
                     unknown_parameters: Optional[CatchAllVar] = None):
            pass

    assert _CatchAllUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs=dict()) == {
               'param1': None, 'param2': None,
               'unknown_parameters': {}}
    assert _CatchAllUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs={
                                                             "param1": 1}) == {
               'param1': 1, 'param2': None,
               'unknown_parameters': {}}

# Generated at 2022-06-23 17:04:51.120180
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import Optional
    from copy import copy
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int
        b: int
        c: Optional[CatchAllVar]

    class Test:
        def test_default_value(self):
            assert _CatchAllUndefinedParameters \
                       .handle_from_dict(MyClass,
                                         {'a': 3, 'b': 4}) == {'a': 3, 'b': 4,
                                                               'c': {}}


# Generated at 2022-06-23 17:05:02.945810
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Foo(object):
        def __init__(self, param1=None, _catch_all=None):
            self.param1 = param1
            self._catch_all = _catch_all

        def __repr__(self):
            return f"param1={self.param1}, catch_all={self._catch_all}"

    def _get_dumped_params(obj):
        dump_parameters = _CatchAllUndefinedParameters.handle_dump(obj=obj)
        dump_parameters.pop(_CatchAllUndefinedParameters._get_catch_all_field(
            obj).name, None)
        return dump_parameters

    f = Foo(1, 'str')
    assert _get_dumped_params(f) == {'param1': 1}
    f = Foo()
    assert _get

# Generated at 2022-06-23 17:05:13.892431
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    unknown_dict = {'abc': 10, 'def': 9}
    parameters = {'a': 5, 'b': 7}
    classes_to_test = [_CatchAllUndefinedParameters,
                       _RaiseUndefinedParameters,
                       _IgnoreUndefinedParameters]
    for cls in classes_to_test:
        parameters_dumped = cls.handle_to_dict(CatchAll, parameters)
        assert 'catch_all' not in parameters_dumped
        parameters_dumped = cls.handle_to_dict(CatchAll(**unknown_dict),
                                               parameters)
        assert 'catch_all' not in parameters_dumped
        expected_dumped_values = {**parameters, **unknown_dict}
        assert parameters_dumped == expected_dumped_values

# Generated at 2022-06-23 17:05:20.210288
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Yo:
        foo: str

    instance = _RaiseUndefinedParameters()

    try:
        instance.handle_from_dict(cls=Yo, kvs={})
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError("Expected Exception")

    output = instance.handle_from_dict(cls=Yo, kvs={"foo": "bar"})
    assert output == {"foo": "bar"}

    kvs = {"bar": "baz"}
    output = instance.handle_to_dict(obj=Yo, kvs=kvs)
    assert output == kvs

    output = instance.handle_dump(obj=Yo)
    assert output == {}

    new_init = instance.create_init(Yo)
    assert new_init

# Generated at 2022-06-23 17:05:26.927280
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: str

    test_field = Test("test")
    assert \
        _RaiseUndefinedParameters.handle_from_dict(Test, {"a": "test"}) == {  # noqa
            "a": "test"}
    assert _RaiseUndefinedParameters.handle_from_dict(Test, {"a": "test",
                                                              "b": "test"}) \
           == {"a": "test"}



# Generated at 2022-06-23 17:05:36.978243
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from collections import UserDict

    @dataclasses.dataclass
    class TestClass:
        name: str
        value: int
        other_value: int = 0
        catch_all: CatchAll = None


    def catch_all_init(self, name: str, value: int, other_value: int,
                       catch_all: CatchAll, *args, **kwargs):
        for key, value in kwargs.items():
            if key not in {"name", "value", "other_value", "catch_all"}:
                raise Exception(f"Unexpected keyword argument '{key}': "
                                f"'{value}'")

    TestClass.__init__ = catch_all_init
    kvs = {"name": "Bob", "value": 42, "other_value": 24}
    test = Test