

# Generated at 2022-06-23 16:55:39.096088
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test(object):
        x: str = "test"
        y: float = 1.0
        z: int = 2
        _UNKNOWN: dataclasses_json.utils.CatchAllVar = {}

        def __init__(self, x, y, z, _UNKNOWN):
            self.x = x
            self.y = y
            self.z = z
            self._UNKNOWN = _UNKNOWN

    t = Test("test", 1.0, 2, {"abc": 123})

    assert _CatchAllUndefinedParameters.handle_dump(t) == {"abc": 123}

# Generated at 2022-06-23 16:55:47.281795
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    test_cls = dataclasses.make_dataclass("TestCls", [('x', int), ('y', float)],
                                          frozen=True,
                                          undefined=Undefined.INCLUDE)

    obj = test_cls(x=1, y=3.3)
    kvs = {'x': 1, 'y': 3.3, 'z': 2.4}
    test_obj = _CatchAllUndefinedParameters
    res = test_obj.handle_to_dict(obj, kvs)
    assert res == {'x': 1, 'y': 3.3, 'z': 2.4}

    obj = test_cls(x=1, y=3.3)
    kvs = {'x': 1, 'y': 3.3}
    res = test_obj

# Generated at 2022-06-23 16:55:55.522774
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Basic test
    @dataclasses.dataclass
    class TestClass:
        a: int
        bc: int
        other: CatchAllVar = None

    kvs = {"a": 1, "bc": 2}
    updated = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert updated == {"a": 1, "bc": 2, "other": {}}

    # Test with undefined attributes
    kvs = {"a": 1, "bc": 2, "other": {"extra": 3}, "tu": "tu"}
    updated = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert updated == {"a": 1, "bc": 2, "other": {"extra": 3, "tu": "tu"}}

    # Test with undefined attributes and names matching class

# Generated at 2022-06-23 16:55:58.470965
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    """
    Test initialization of class _RaiseUndefinedParameters().
    """
    _RaiseUndefinedParameters()

# Generated at 2022-06-23 16:56:07.104601
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class BaseClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class IgnoreClass(BaseClass):
        __init__ = _IgnoreUndefinedParameters.create_init(BaseClass)

    ic = IgnoreClass(a=1, b=2, c=3, d=4, e=5, f=6)
    assert ic.a == 1
    assert ic.b == 2
    assert ic.c == 3

    def test_too_many_args():
        IgnoreClass(1, 2, 3, 4, 5, 6, 7)


# Generated at 2022-06-23 16:56:17.590953
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import typing


    class TestA:
        def __init__(self, a: str, b: str = "b_default"):
            pass


    class TestB:
        def __init__(self, a: str, b: str = "b_default", *args, **kwargs):
            pass


    class TestC:
        def __init__(self, a: str, b: str = "b_default",
                     *, c: int = 2, **kwargs):
            pass

    A = _IgnoreUndefinedParameters.create_init(TestA)
    B = _IgnoreUndefinedParameters.create_init(TestB)
    C = _IgnoreUndefinedParameters.create_init(TestC)

    x = A(a="a_value")

# Generated at 2022-06-23 16:56:18.430389
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:56:26.097898
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses_json.utils import letter_case

    class DataClass(object):
        def __init__(self, a: int = 1, b: str = "2", c=3):
            self.a = a
            self.b = b
            self.c = c

    @dataclasses.dataclass
    @letter_case(LetterCase.LOWER)
    class DataClass2:
        a: int = 1
        b: str = "2"
        c: int = dataclasses.field(default_factory=lambda: 3)

    class DataClass3(object):
        def __init__(self, a: int = 1, b: str = "2", c=3):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-23 16:56:39.050194
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class Test:

        x: str
        catch_all: CatchAll = None

        def __init__(self, x: str, catch_all: CatchAll = None):
            self.x = x
            self.catch_all = catch_all

    known_given_parameters, unknown_given_parameters = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            Test, {"x": "a", "y": 1})
    assert known_given_parameters == {"x": "a"}
    assert unknown_given_parameters == {"y": 1}


# Generated at 2022-06-23 16:56:43.350430
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Nothing is given
    assert _UndefinedParameterAction.handle_to_dict({}, {}) == {}

    # Something is given
    assert _UndefinedParameterAction.handle_to_dict({}, {'key': 'value'}) == {
        'key': 'value'}



# Generated at 2022-06-23 16:56:50.566714
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class _TestDataClass:
        key: str
        catch_all: Optional[CatchAllVar]

        def __init__(self, key: str, catch_all: Optional[CatchAllVar] = None):
            self.key = key
            self.catch_all = catch_all

    from marshmallow import Schema

    class _TestSchema(Schema):
        key = fields.Str()
        catch_all = fields.Dict()

    schema = _TestSchema()
    data = schema.dumps(_TestDataClass("test"))
    loaded_test_data_class = schema.loads(data)
    loaded_test_data_class["_UNKNOWN_ARGUMENT"] = 1
    data = schema.dumps(_TestDataClass("test"))

# Generated at 2022-06-23 16:56:53.571846
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int
        b: int = 2

        def __init__(self, a, b):
            self.a = a
            self.b = b

    a = MyClass.__init__
    b = _RaiseUndefinedParameters.create_init(MyClass)(1, 2)
    assert a == b



# Generated at 2022-06-23 16:56:59.900668
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Foo:
        bar: str

    expected = {"bar": "baz"}
    returned = _UndefinedParameterAction.handle_from_dict(
        cls=Foo, kvs=expected.copy())
    assert returned == expected

    returned = _UndefinedParameterAction.handle_from_dict(
        cls=Foo, kvs={"bar": "baz", "baz": "buz"})
    assert returned == expected



# Generated at 2022-06-23 16:57:13.081798
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A:
        def __init__(self, *args, **kwargs):
            pass

    class B:
        def __init__(self, x, y, *args, **kwargs):
            pass

    class C:
        pass

    assert _RaiseUndefinedParameters.handle_from_dict(A, {"a": 1}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(B, {"x": 1}) == {"x": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(B, {"x": 1, "y": 1}) \
           == {"x": 1, "y": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(C, {}) == {}

# Generated at 2022-06-23 16:57:23.205563
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class C(metaclass=dataclasses.dataclass):
        a: str
        b: int

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    @dataclasses.dataclass
    class C2:
        a: str
        b: int
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    undefined = _UndefinedParameterAction

    c = C(a="a", b="b")
    kvs = dataclasses.asdict(c)
    try:
        undefined.handle_from_dict(C, kvs)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError")

# Generated at 2022-06-23 16:57:30.040284
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        x: int
        y: int

    a = A(1, 2)
    result_dict = _RaiseUndefinedParameters.handle_from_dict(
        A,
        {"x": 1, "y": 2, "z": 3},
    )
    assert result_dict == {"x": 1, "y": 2}



# Generated at 2022-06-23 16:57:32.832975
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        assert False
    except TypeError:
        # _UndefinedParameterAction is abstract
        pass



# Generated at 2022-06-23 16:57:39.604500
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int

    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    t = TestClass("hello", 9)
    assert t.a == "hello"
    assert t.b == 9
    new_t = TestClass("hello2", 9, c="something")
    assert new_t.a == "hello2"
    assert new_t.b == 9
    with pytest.raises(KeyError):
        _ = new_t.c

# Generated at 2022-06-23 16:57:52.168883
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, field1: int, field2: str, __undefined: Any = None):
            self.field1 = field1
            self.field2 = field2
            self.__undefined = __undefined

    test_instance = TestClass(field1=1, field2="asdf")

    kvs = {"field1": 1, "field2": "asdf"}
    assert _UndefinedParameterAction.handle_to_dict(test_instance,
                                                    kvs=kvs) == {"field1": 1,
                                                                 "field2": "asdf"}

    test_instance.__undefined = {"field3": [1, 2]}

# Generated at 2022-06-23 16:58:05.480746
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Foo:
        def __init__(self, a: int, b: int):
            pass

    class Bar:
        def __init__(self, a: int, b: int, c: int):
            pass

    class Baz:
        def __init__(self, a: int, b: int, d: int):
            pass

    assert _UndefinedParameterAction.create_init(Foo) is Foo.__init__
    assert _UndefinedParameterAction.create_init(Bar) is Bar.__init__

    def mocked_init(self, a: int, b: int, *args, **kwargs):
        pass

    def mocked_init_2(self, *args, **kwargs):
        pass

    ignore_init = _UndefinedParameterAction.create_init(Baz)

    # Test that our created

# Generated at 2022-06-23 16:58:13.008642
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses_json.utils import CatchAllVar


    def default_factory():
        return {}


    # noinspection PyPep8Naming
    @dataclasses.dataclass
    class ExampleWithCatchAll:
        a: int
        b: int
        c: int = dataclasses.field(default=10)
        _UNDEFINED: Optional[CatchAllVar] = dataclasses.field(
            default_factory=default_factory)

        def __post_init__(self):
            pass


    # noinspection PyPep8Naming
    @dataclasses.dataclass
    class ExampleWithoutCatchAll:
        a: int
        b: int
        c: int = dataclasses.field(default=10)


# Generated at 2022-06-23 16:58:15.285238
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(1) == {}
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 16:58:24.129054
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, **kwargs):
            pass

    test_input_dict = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4
    }
    expected_result = {
        "a": 1,
        "b": 2
    }
    result = _IgnoreUndefinedParameters.handle_from_dict(TestClass,
                                                         test_input_dict)
    assert result == expected_result

# Generated at 2022-06-23 16:58:37.019346
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # create the class
    @dataclasses.dataclass
    class _Test1:
        a: int = 7

        def __init__(self, a: int, b: int = 71, c: int = 771,
                     d: CatchAll = None):
            self.a = a,
            self.b = b
            self.c = c
            self.d = d

    init_with_catch_all = _CatchAllUndefinedParameters.create_init(_Test1)
    init_without_catch_all = _IgnoreUndefinedParameters.create_init(_Test1)

    # test that the init is wrapped correctly

# Generated at 2022-06-23 16:58:42.050546
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Foo:
        bar: str
        baz: DataBars
        _extra: Optional[CatchAllVar] = CatchAll

        def __init__(self, bar: str, baz: DataBars, **_extra: Any):
            self.bar = bar
            self.baz = baz
            self._extra = _extra

        def __eq__(self, other):
            return (self.bar == other.bar and
                    self.baz == other.baz and
                    self._extra == other._extra)



# Generated at 2022-06-23 16:58:52.177292
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=CatchAllUndefinedParametersTest,
        kvs={"undefined_parameters": {"hi": "there"},
             "undefined_parameters2": {"hi": "there"},
             "defined_parameters": 1}) == {"defined_parameters": 1}
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=CatchAllUndefinedParametersTest,
        kvs={"undefined_parameters": {"hi": "there"},
             "undefined_parameters2": 1,
             "defined_parameters": 1}) == {"defined_parameters": 1}

# Generated at 2022-06-23 16:58:59.976902
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        pass

    # noinspection PyTypeChecker
    assert _UndefinedParameterAction.handle_from_dict(TestClass, {}) == {}
    # noinspection PyTypeChecker
    assert _UndefinedParameterAction.handle_from_dict(TestClass,
                                                      {"a": 1}) == {"a": 1}
    # noinspection PyTypeChecker
    assert _UndefinedParameterAction.handle_from_dict(TestClass, {"b": 2}) == {
                                                                             "b":
                                                                             2}



# Generated at 2022-06-23 16:59:07.525135
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # arrange
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass_json
    @dataclass
    class ClassWithUndefinedParameters:
        a: int
        b: str

        def __init__(self, *args, **kwargs):
            pass

    # act
    _RaiseUndefinedParameters.handle_from_dict(ClassWithUndefinedParameters,
                                               {"a": 1, "c": "hallo"})

    # assert
    # expected to raise UndefinedParameterError
    config.RAISE_ERR_ON_EXCESSIVE_UNDEFINED = True

# Generated at 2022-06-23 16:59:15.705432
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    import typing

    @dataclass
    class TestClass:
        test: str
        catch_all: typing.Optional[CatchAllVar] = None

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    @dataclass
    class TestClassNoCatchAll:
        test: str = "test"

    t1 = TestClass("test_value", catch_all={"another": "value"})
    assert t1.catch_all
    assert t1.catch_all.get("another") == "value"
    assert t1.test == "test_value"

    t2 = TestClass("test_value")
    assert t2.catch_all is None

# Generated at 2022-06-23 16:59:20.745546
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class A:
        def __init__(self):
            self.a = 1

    assert _UndefinedParameterAction.handle_dump(A()) == {}
    assert _UndefinedParameterAction.handle_dump(A()) == {}



# Generated at 2022-06-23 16:59:30.153350
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class SomeClass:
        def __init__(self, a: str, b: int, c: str):
            pass

    expected_kws = {"a": "a", "b": 1}
    kws = {"a": "a", "b": 1, "d": 2}
    result = _IgnoreUndefinedParameters.handle_from_dict(
        SomeClass, kws)
    assert result == expected_kws



# Generated at 2022-06-23 16:59:33.520583
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class _TestClass:
        def __init__(self, *args, **kwargs):
            pass

    _test_class = _TestClass()
    init = _UndefinedParameterAction.create_init(_test_class)
    assert init(_test_class) is None

# Generated at 2022-06-23 16:59:40.820320
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class User:
        name: str
        id: int = field(default=42)
        attributes: CatchAll = field(default_factory=dict)

        def __init__(self, name: str, id: int, attributes: CatchAll = None,
                     **unknown):
            pass

    @dataclass
    class User2:
        name: str
        id: int = field(default=42)

        def __init__(self, name: str, id: int, **unknown):
            pass

    @dataclass
    class User3:
        name: str
        id: int = field(default=42)
        attributes: CatchAll = field(default_factory=dict)


# Generated at 2022-06-23 16:59:48.487949
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass, fields
    from dataclasses_json import Undefined, config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    @config(undefined=Undefined.INCLUDE)
    class MyClass:
        x: int
        y: int
        z: CatchAll = None

    my_class_init = MyClass.__init__

    my_class_init(MyClass(2, 3, CatchAll({})))
    my_class_init(MyClass(2, 3))
    # These succeed.

    my_class_init(MyClass(2, 3, CatchAll({"z": 3})))
    my_class_init(MyClass(2, 3, {"z": 3}))

# Generated at 2022-06-23 16:59:56.627251
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import datetime
    from dataclasses import dataclass

    from marshmallow import Schema

    @dataclass
    class Person:
        valid: str = "valid"
        undefined: Optional[CatchAllVar] = None

        def __init__(self, *args, **kwargs):  # type: ignore
            super().__init__(*args, **kwargs)

    @dataclass
    class PersonWithDefault:
        valid: str = "valid"
        undefined: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __init__(self, *args, **kwargs):  # type: ignore
            super().__init__(*args, **kwargs)

    @dataclass
    class DatedPerson(Person):
        date: datetime.datetime



# Generated at 2022-06-23 17:00:05.947547
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Some:
        def __init__(self, a: int, b: int, c: int = 3):
            pass

    some = Some(1, 2, c=3)
    got = _CatchAllUndefinedParameters.handle_to_dict(
        some, {'a': 1, 'b': 2, 'c': 3})
    assert got == {}
    got = _CatchAllUndefinedParameters.handle_to_dict(
        some, {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert got == {'d': 4}

# Generated at 2022-06-23 17:00:10.959792
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Test1(object):
        pass

    class Test2(object):
        pass

    assert _UndefinedParameterAction.handle_dump(Test1) == {}
    assert _UndefinedParameterAction.handle_dump(Test2) == {}

# Generated at 2022-06-23 17:00:18.386070
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: int, *args, **kwargs):
            pass

    for kwargs in [{"a": 1}, {"a": 1, "b": 2, "c": 3}]:
        try:
            known_parameters = \
                _RaiseUndefinedParameters.handle_from_dict(cls=Foo,
                                                           kvs=kwargs)
            assert kwargs == known_parameters
        except UndefinedParameterError:
            assert False

    for kwargs in [{}, {"a": 1, "c": 3}]:
        try:
            _RaiseUndefinedParameters.handle_from_dict(cls=Foo,
                                                       kvs=kwargs)
            assert False
        except UndefinedParameterError:
            pass



# Generated at 2022-06-23 17:00:26.349220
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, parameter_1: int, **_):
            pass

    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                                   {"parameter_1": 3,
                                                    "undef_param": "a"})
        raise Exception("Failed test")
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 17:00:38.395885
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    # Note that this does not induce an example of recursion
    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: str
        d: float = 1.0

    init = _IgnoreUndefinedParameters.create_init(A)
    a = init(A, 'abc', 1, 'abc', 2.0)
    assert a.a == 'abc'
    assert a.b == 1
    assert a.c == 'abc'
    assert a.d == 2.0
    # test too few params
    with pytest.raises(TypeError):
        a = init(A, 'abc', 1)

    # test additional params
    a = init(A, 'abc', 1, 'abc', 2.0, 'test', 'is', 'ok')

# Generated at 2022-06-23 17:00:40.721131
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    assert _CatchAllUndefinedParameters._get_catch_all_field(
        CatchAll).name == "unknown"

# Generated at 2022-06-23 17:00:54.215219
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import typing

    class Foo:
        def __init__(self, bar: int, baz: str = "str", **kwargs):
            pass

    foo = Foo(1, "str3")

    original_init = foo.__init__
    new_init = _IgnoreUndefinedParameters.create_init(Foo)

    # now we pass some unknown parameters to the new init, that it will
    # ignore
    arguments = list(inspect.signature(original_init).parameters)

    num_args = len(arguments) - 1
    assert num_args == 2

    new_init(foo, 1, "str2", "qux", "quux", "quuux", qux=5, quux=6)



# Generated at 2022-06-23 17:01:04.155343
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestDataClass:
        # type: (...) -> None
        def __init__(self, a: int, b: int, _UNKNOWN1: int, _UNKNOWN2: int):
            self.a = a
            self.b = b
            self._UNKNOWN1 = _UNKNOWN1
            self._UNKNOWN2 = _UNKNOWN2

    data = {'a': 1, 'b': 2, '_UNKNOWN1': 3, '_UNKNOWN2': 4}
    test_class = TestDataClass(**data)
    expected = {'a': 1, 'b': 2}
    result = _CatchAllUndefinedParameters.handle_to_dict(test_class, data)
    assert result == expected



# Generated at 2022-06-23 17:01:12.610788
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Bar:
        def __init__(self, x: float, y: float, w: float, h: float, **kwargs):
            self.x = x
            self.y = y
            self.w = w
            self.h = h

    signature = inspect.signature(Bar.__init__)

    init = _CatchAllUndefinedParameters.create_init(Bar)
    bound_parameters = signature.bind(None, 1.0, 2.0, w=3.0, a=1, b=2, c=3,
                                      **{'_UNKNOWN0': 5.0,
                                         '_UNKNOWN1': 6.0})
    bound_parameters.apply_defaults()
    init(**bound_parameters.arguments)

# Generated at 2022-06-23 17:01:25.857027
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    catch_all_field_name = "UNDEFINED"

    class C1:
        @dataclasses.dataclass(
            init=_CatchAllUndefinedParameters.create_init)
        class C2:
            a: str
            b: int
            undefined: CatchAllVar = dataclasses.field(
                default_factory=dict)

        def __init__(self):
            print(f"{self.__class__.__name__} initialized")
            assert self.c.undefined == {}

    C1.C2(a="a", b=1)
    # Too many arguments but named correctly
    C1.C2(a="a", b=1, undefined={})
    C1.C2(a="a", b=1, undefined={}, c=3)



# Generated at 2022-06-23 17:01:29.469044
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    result = obj.handle_dump(None)
    assert isinstance(result, dict)
    assert result == {}

# Generated at 2022-06-23 17:01:36.695954
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from unittest.mock import patch

    def mock_init(self, a):
        self.a = a

    class TestClass:
        def __init__(self, a: int):
            self.a = a

    TestClass.__init__ = mock_init

    with patch("dataclasses_json.undefined.CatchAll", lambda x: x):
        test_obj = TestClass(1)
        init = _UndefinedParameterAction.create_init(test_obj)
        assert inspect.signature(init).parameters["a"] == \
               inspect.Signature().parameters["a"]
        test_obj_2 = TestClass(1)
        test_obj_2.__init__ = init
        assert test_obj_2.a == 1

# Generated at 2022-06-23 17:01:49.767186
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # noinspection Mypy
    class Test:
        unused_capture_all_1: CatchAll = CatchAll()
        unused_capture_all_2: CatchAll = CatchAll()

    def test_inner() -> CatchAll:
        # noinspection PyShadowingNames
        class Test:
            capture_all: CatchAll = CatchAll()

            def __init__(self):
                self.capture_all = {"B": 2}

        return Test().capture_all
    Test.capture_all = test_inner()

    class A:
        a: int = 0

    class B:
        a: int = 1

    from dataclasses import is_dataclass
    assert not is_dataclass(Test)


# Generated at 2022-06-23 17:01:56.725816
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import dataclass

    @dataclass(undefined=Undefined.INCLUDE)
    class Obj:
        x: int
        _UNKNOWN_PARAMETERS: Optional[CatchAllVar] = None

    obj = Obj(x=1, y=2)
    assert obj._UNKNOWN_PARAMETERS["y"] == 2
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, {"x": 1, "y": 2}) == {
               "x": 1, "y": 2}
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, {"x": 1}) == {"x": 1}

# Generated at 2022-06-23 17:02:02.892521
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        a: int

        def __init__(self, a: int, **kwargs):
            self.a = a

    assert \
        _RaiseUndefinedParameters.handle_from_dict(Test, {"a": 1}) == {"a": 1}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, {"a": 1, "b": 2})



# Generated at 2022-06-23 17:02:10.801475
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # this is used to test the internal method
    class _DummyClass:
        pass

    # No undefined parameters given
    result = _UndefinedParameterAction._separate_defined_undefined_kvs(
        _DummyClass, {"a": 1, "b": 2})
    assert ({"a": 1, "b": 2}, {}) == result

    # Some undefined parameters given
    result = _UndefinedParameterAction._separate_defined_undefined_kvs(
        _DummyClass, {"a": 1, "b": 2, "c": 3, "d": 4})
    assert ({"a": 1, "b": 2}, {"c": 3, "d": 4}) == result



# Generated at 2022-06-23 17:02:20.991108
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, a: int, **__unused_parameters__: CatchAllVar):
            self.a = a
            self.catch_all = __unused_parameters__

    a = A(a=1, b=2, c=3, d=4)
    kvs = {'a': a.a, 'b': 2, 'c': 3, 'd': 4}
    _CatchAllUndefinedParameters.handle_to_dict(a, kvs)
    assert kvs == {'a': 1}

# Generated at 2022-06-23 17:02:26.113820
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Test(object):
        pass

    init = _RaiseUndefinedParameters.create_init(Test)

    init(Test, **{})
    init(Test, **{"a": 1})
    init(Test, **{"a": 1, "b": 2})

    try:
        init(Test, **{"a": 1, "z": 2})
        assert False, "Shouldn't be able to set undefined parameters"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 17:02:28.814056
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    with pytest.raises(NotImplementedError):
        _UndefinedParameterAction.handle_to_dict(object, dict())


# Generated at 2022-06-23 17:02:37.464568
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class Test(metaclass=CatchAll):
        catch_all: CatchAll = field(metadata={"data_key": "catch_all"})
        foo: str = field(metadata={"data_key": "foo"})
        bar: str = field(metadata={"data_key": "bar"})

    generated_class = Test("hello", "world", "bye")
    expected_dump = {}
    generated_dump = _CatchAllUndefinedParameters.handle_dump(generated_class)
    assert generated_dump == expected_dump

    generated_class = Test("hello", "world", "bye", {"hello": "world"})
    expected_dump = {"hello": "world"}

# Generated at 2022-06-23 17:02:45.343394
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from collections import OrderedDict

    @dataclasses.dataclass
    class TestCatchAll:
        a: str
        b: int
        c: Optional[CatchAllVar] = None

        def __init__(self, *args, **kwargs):
            pass

    init_method = _CatchAllUndefinedParameters.create_init(TestCatchAll)
    instance = TestCatchAll()
    assert isinstance(instance, TestCatchAll)

    # Undefined parameters are stored in catch-all field
    init_method(instance, "abc", 123, named="named",
                varargs="varargs1", varargs2="varargs2")
    assert instance.a == "abc"
    assert instance.b == 123
    assert isinstance(instance.c, OrderedDict)
    assert instance.c

# Generated at 2022-06-23 17:02:57.550271
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def _test_init_arg_handling(cls, expected_args, init_arguments):
        _ignore_init = _UndefinedParameterAction.create_init(cls)
        actual_args = _ignore_init(None, *init_arguments, **{}).__dict__
        assert actual_args == expected_args


    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class _TestClass:
        a: int
        b: str


    _test_init_arg_handling(_TestClass, {'a': 1, 'b': '2'}, [1, '2'])
    _test_init_arg_handling(_TestClass, {'a': 1, 'b': '2'}, [1, '2'])
    _test_init_arg

# Generated at 2022-06-23 17:03:09.123718
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from typing import Any, Optional
    from dataclasses import dataclass
    from dataclasses_json import Undefined, dataclass_json

    @dataclass_json(undefined=Undefined.RAISE)
    @dataclass
    class A:
        a: str
        b: str

    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class B:
        a: str
        b: str
        c: str

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass
    class C:
        a: str
        b: str
        c: Optional[CatchAllVar]

# Generated at 2022-06-23 17:03:18.528837
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import NewType
    from dataclasses import dataclass

    CatchAllVar = NewType('CatchAllVar', Dict[str, Any])

    @dataclass
    class Cls(object):
        a: str
        b: int
        c: CatchAllVar = dataclasses.field(default_factory=dict)
        d: str = "default"
        e: CatchAllVar = dataclasses.field(default=dict())

    c1 = {"a": "a1", "b": 11}

    # Default
    class_parameters = _CatchAllUndefinedParameters.handle_from_dict(
        Cls, c1)
    assert class_parameters == c1

    # Defined parameters only

# Generated at 2022-06-23 17:03:29.655341
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import pytest
    struct1_dict = {"a": 1, "b": 2, "c": 3, CatchAll: {"x": "y"}}
    struct1 = dataclasses.make_dataclass("struct1", struct1_dict.keys(),
                                         frozen=True)(**struct1_dict)

    struct2_dict = {"a": 1, "b": 3, "c": 3}
    struct2 = dataclasses.make_dataclass("struct2", struct2_dict.keys(),
                                         frozen=True)(**struct2_dict)

    expected_output = {"a": 1, "b": 3, "c": 3, "x": "y"}
    result = _CatchAllUndefinedParameters.handle_dump(struct1)
    assert result == expected_output


# Generated at 2022-06-23 17:03:32.242783
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    with pytest.raises(TypeError,
                       match="Can't instantiate abstract class"):
        _UndefinedParameterAction()

# Generated at 2022-06-23 17:03:40.954716
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    def _new_class(fields_to_include):
        @dataclasses.dataclass
        class _TestClass:
            __write_only__ = False  # type: bool
            __undefined__ = None  # type: Undefined
            __field_rename__ = None  # type: Dict[str, str]

            pass
        for field in fields_to_include:
            setattr(_TestClass, f"__{field.name}", field)

        return _TestClass

    class _TestField(dataclasses.Field):
        def __init__(self, field_name):
            super().__init__(default=object())
            self.name = field_name

    for action in Undefined:
        for field_name in ["include_field", "rename_field"]:
            field = _TestField

# Generated at 2022-06-23 17:03:52.544875
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        def __init__(self,
                     catch_all: Optional[CatchAllVar] = None, **kwargs):
            super().__init__(**kwargs)
            self.__dict__.update(catch_all)

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

        def __repr__(self):
            return self.__dict__.__repr__()

        def to_dict(self) -> Dict[Any, Any]:
            return _CatchAllUndefinedParameters.handle_to_dict(self,
                                                               self.__dict__)

    test_input = {"y": 1, "x": 2}
    t = TestClass(**test_input)
    assert t.x == 2 and t.y == 1


# Generated at 2022-06-23 17:03:53.868107
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:03:56.380478
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError()
    assert error.field_names == []
    assert error.field_names == []

# Generated at 2022-06-23 17:04:01.005727
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import marshmallow
    import dataclasses

    @dataclasses.dataclass
    class MyClass(object):
        all_data: CatchAllVar

        def __init__(self, *args, **kwargs):
            self.all_data = kwargs

    derived = MyClass(foo="bar", baz=42)
    schema = marshmallow.Schema.from_dataclass(MyClass)
    assert {"foo": "bar", "baz": 42} == schema.dump(derived)

# Generated at 2022-06-23 17:04:10.702195
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import Config

    @dataclass
    class Foo:
        bar: str
        baz: Optional[int] = None
        buz: Optional[str] = ""

    raw_dict = {
        "bar": "test",
        "baz": 1,
        "qux": "should not be there"
    }
    expected_result = {"bar": "test", "baz": 1}

    config = Config(undefined=Undefined.RAISE)
    result = _RaiseUndefinedParameters.handle_from_dict(cls=Foo, kvs=raw_dict)
    assert result == expected_result

    # Test if the same works when using the dataclasses_json
    # config for instantiating
    foo_instance = Foo.schema

# Generated at 2022-06-23 17:04:11.265916
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-23 17:04:15.224068
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class New:
        x = CatchAll

    n = New()
    assert(_CatchAllUndefinedParameters.handle_dump(n) == {})

# Generated at 2022-06-23 17:04:18.646127
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    UndefinedParameterAction = _UndefinedParameterAction()
    kvs = {"name": "a", "id": 1}
    assert kvs == UndefinedParameterAction.handle_to_dict(None, kvs)



# Generated at 2022-06-23 17:04:19.898734
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    _UndefinedParameterAction.handle_to_dict()

# Generated at 2022-06-23 17:04:22.656351
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    undefined_parameter_action = _UndefinedParameterAction()
    assert undefined_parameter_action is not None

# Generated at 2022-06-23 17:04:33.385390
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass:
        pass

    @dataclasses.dataclass
    class TestCase:
        give: Dict[Any, Any]
        want: Dict[Any, Any]

    def test_handle_from_dict(cls, cases):
        for case in cases:
            got = _UndefinedParameterAction.handle_from_dict(cls=cls,
                                                             kvs=case.give)
            assert got == case.want

    test_class_raise_parameters = dataclasses.dataclass(
        init=False,
        repr=False,
        eq=False,
        frozen=False,
        undefine_kwargs=_RaiseUndefinedParameters)(DummyClass)


# Generated at 2022-06-23 17:04:43.919720
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import json
    import dataclasses_json

    @dataclasses.dataclass(frozen=True)
    class Test(object):
        a: int
        b: int
        c: CatchAllVar = dataclasses.field(default=None)  # type: ignore

    a = Test(a=1, b=2, d=3)
    serialized_a = dataclasses_json.dump(a)
    b = dataclasses_json.load(serialized_a, cls=Test)
    c = dataclasses_json.load(json.dumps(
        {"a": 1, "b": 2, "d": 3}), cls=Test)
    assert a == b
    assert a == c

# Generated at 2022-06-23 17:04:54.968261
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import dataclasses
    import typing
    import marshmallow
    from marshmallow.fields import Dict as DictField, Str as StringField

    @dataclasses.dataclass
    class Test:
        a: str = "A"
        b: str = "B"
        c: str = "C"

        # This class has no ctor and no ctor parameters, but it is
        # necessary for the test to pass
        def __init__(self, a, b, c): pass

    # get init signature of the class Test
    signature = inspect.signature(Test.__init__)

    # create the ignore init function
    ignore_init_func = _IgnoreUndefinedParameters.create_init(Test)

    # create args and kwargs that disregard the signature of Test

# Generated at 2022-06-23 17:05:04.678024
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int = 1
        b: str = "default"
        kwarg: int = 1
        kwargs: int = 2

        def __init__(self, a: int, b: str, kwarg: int, **kwargs):
            pass  # pragma: no cover


# Generated at 2022-06-23 17:05:05.512808
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("some message")

# Generated at 2022-06-23 17:05:13.590979
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import attr

    @attr.s
    class Dummy:
        catch_all: Optional[CatchAllVar] = attr.ib(default=None)

    dummy = Dummy()
    expected = {}
    actual = _CatchAllUndefinedParameters.handle_dump(dummy)
    assert actual == expected

    dummy = Dummy({"key1": "value1", "key2": "value2"})
    expected = {"key1": "value1", "key2": "value2"}
    actual = _CatchAllUndefinedParameters.handle_dump(dummy)
    assert actual == expected

# Generated at 2022-06-23 17:05:16.196808
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert issubclass(_RaiseUndefinedParameters, _UndefinedParameterAction)
    assert issubclass(_IgnoreUndefinedParameters, _UndefinedParameterAction)
    assert issubclass(_CatchAllUndefinedParameters, _UndefinedParameterAction)

# Generated at 2022-06-23 17:05:26.821690
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        name: str
        age: int
        undefined_parameters: Optional[CatchAllVar]

        def __init__(self, name: str, age: int,
                     undefined_parameters: Optional[CatchAllVar] = None) -> \
                None:
            pass

    old_init = Test.__init__
    new_init = _UndefinedParameterAction.create_init(Test)
    assert new_init != old_init
    assert new_init(Test) == old_init
    assert new_init(Test, "John Doe", 20) != old_init(Test, "John Doe", 20)
    assert new_init(Test, "John Doe", 20) == old_init(Test, "John Doe", 20)



# Generated at 2022-06-23 17:05:32.585480
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Test:
        catch_all: CatchAll = None
        not_catch_all: str = "foo"

    test = Test(not_catch_all="bar")
    test.catch_all["hello"] = "world"
    assert _CatchAllUndefinedParameters.handle_dump(test) == \
           {"hello": "world"}