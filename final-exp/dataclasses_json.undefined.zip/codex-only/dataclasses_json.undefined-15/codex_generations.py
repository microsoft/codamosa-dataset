

# Generated at 2022-06-23 16:55:36.842372
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class DataClassWithUndefined:
        some_parameter: int
        catch_all: Optional[CatchAllVar] = None

    expected = {"some_parameter": 1}
    initial = dict(expected)
    initial["catch_all"] = {"other_parameter": 2}

    actual = _UndefinedParameterAction.handle_to_dict(
        obj=DataClassWithUndefined, kvs=initial)

    assert actual == expected

# Generated at 2022-06-23 16:55:48.418207
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # import sys
    # sys.path.append(".")

    from dataclasses_json.undefined import _CatchAllUndefinedParameters

    @dataclasses.dataclass
    class MyClass:
        field_1: str
        field_2: int
        catch_all: Optional[_CatchAllUndefinedParameters.CatchAllVar] = \
            _CatchAllUndefinedParameters.CatchAllVar()

    class_to_create = MyClass

    # noinspection PyProtectedMember
    # create instance without undefined parameters
    init_dictionary = _CatchAllUndefinedParameters.handle_from_dict(
        class_to_create,
        {"field_1": "abc", "field_2": -1})

# Generated at 2022-06-23 16:55:54.757850
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, *, a: int = 1, b: int = 2, c: int = 3):
            pass

        def __repr__(self):
            return f"TestClass(a={self.a}, b={self.b}, c={self.c})"

    test_instance = TestClass()
    kvs = {"a": 10, "c": 30}

    assert _UndefinedParameterAction.handle_to_dict(obj=TestClass,
                                                    kvs=kvs) == {"a": 10,
                                                                 "c": 30}



# Generated at 2022-06-23 16:55:58.963747
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init = _CatchAllUndefinedParameters.create_init  # type: Callable
    obj = Undefined.RAISE
    init(obj)
    obj = Undefined.EXCLUDE
    init(obj)

# Generated at 2022-06-23 16:56:06.561232
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():  # noqa
    # https://github.com/jamescooke/dataclasses-json/issues/8
    # We want to make sure that the following code is properly formatted:

    from dataclasses_json.undefined import Undefined
    from dataclasses_json.json import Configuration

    @dataclass
    class _Class:
        position: str
        undefined: Undefined = Undefined.INCLUDE

    print(_Class.__init__.__annotations__)

    # If __annotations__ is empty,
    # the mypy check for __parameters__ will fail.
    print(_Class.__init__.__code__.co_varnames)

    # If __code__.co_varnames is empty,
    # the mypy check for __parameters__ will fail.

# Generated at 2022-06-23 16:56:17.290546
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from marshmallow import Schema
    from marshmallow.fields import String
    from marshmallow.fields import Nested
    from marshmallow.fields import Dict

    class _CatchAllTest(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self, test_param: str,
                     test_catch_all: CatchAll = None):
            pass

    def _assert_raises_constructor_error_for_missing_catch_all(cls):
        try:
            cls()
        except UndefinedParameterError:
            return
        raise AssertionError(
            "Constructor does not raise error for class without "
            "catch-all parameter")

    _assert_raises_constructor_error_for_missing_catch_all(_CatchAllTest)



# Generated at 2022-06-23 16:56:25.156007
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import pytest
    from dataclasses_json.utils import CatchAll

    class Exp1:
        b: int
        c: int
        _catch_all: Optional[CatchAll] = dataclasses.field(
            default=None, metadata={"marshmallow_field": dataclasses.field(
                metadata={"data_key": "_catch_all"})})

    with pytest.raises(UndefinedParameterError):
        Exp1(a=1, b=2)

    with pytest.raises(ValidationError):
        _CatchAllUndefinedParameters.handle_from_dict(Exp1, kvs={"a": 1, "b": 2})

# Generated at 2022-06-23 16:56:28.093398
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction._separate_defined_undefined_kvs(None, {})

# Generated at 2022-06-23 16:56:35.601568
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClassWithInit(object):

        def __init__(self, a: str):
            pass


    @dataclasses.dataclass
    class TestClassNoInit(object):
        pass


    assert _IgnoreUndefinedParameters.create_init(TestClassWithInit) == None
    assert _IgnoreUndefinedParameters.create_init(TestClassNoInit) == \
           TestClassNoInit.__init__



# Generated at 2022-06-23 16:56:38.310311
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Test:
        def __init__(self, a: int, b: int,
                     c: Optional[CatchAllVar] = None):
            pass

    test = Test(a=1, b=2, c={"one": 1, "two": 2})
    init = _CatchAllUndefinedParameters.create_init(test)
    test = init(test, 1, 2)
    assert test.__class__ == Test

# Generated at 2022-06-23 16:56:41.603526
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # pylint: disable=no-self-use
    # pylint: disable=unused-argument
    class A:
        def __init__(self, a, b, c):
            pass

    try:
        _RaiseUndefinedParameters.handle_from_dict(A, {"a": 3, "b": 3, "c": 3,
                                                       "d": 4})
        assert False
    except UndefinedParameterError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 16:56:49.356255
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    some_dict = {"a": 1, "b": 2, "c": 3}
    orig_dict = {"a": 1, "b": 2, "c": 3}

    def some_class_init(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    some_class = type("SomeClass", (), {"__init__": some_class_init})

    def inner_test(handle_method):
        _UndefinedParameterAction.handle_to_dict = handle_method
        some_instance = some_class(**some_dict)
        assert some_instance.__dict__ is not some_dict
        assert some_instance.__dict__ == orig_dict
        assert some_dict == orig_dict


# Generated at 2022-06-23 16:57:00.267531
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnusedLocal,PyUnusedLocal
    @dataclasses.dataclass
    class E(object):
        a: int
        b: str
        c: CatchAll

        def __init__(self, a: int, b: str, c: CatchAll = None):
            pass

    # With the wrong number of arguments, this should still raise an error.
    @dataclasses.dataclass
    class F(object):
        a: int
        b: str
        c: CatchAll

        def __init__(self, a: int, b: str, c: CatchAll = None):
            pass


# Generated at 2022-06-23 16:57:11.822168
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: str
        b: int = 20
        c: int = dataclasses.field(default=30)
        d: int
        __undefined__: Undefined = Undefined.EXCLUDE

        def __init__(self, a: str, b: int = 20, c: int = 30, d: int = 40):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    a = A('a')
    assert a.a == 'a'
    assert a.b == 20
    assert a.c == 30
    assert a.d == 40



# Generated at 2022-06-23 16:57:16.535340
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Something has gone wrong")
    except UndefinedParameterError as e:
        if str(e) != "Something has gone wrong":
            raise AssertionError("str() of UndefinedParameterError is wrong")
        if repr(e) != f"UndefinedParameterError('Something has gone wrong')":
            raise AssertionError("repr() of UndefinedParameterError is wrong")
        if e.args[0] != "Something has gone wrong":
            raise AssertionError("args of UndefinedParameterError is wrong")

# Generated at 2022-06-23 16:57:24.688492
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int
        baz: str

    def dummy_init(self, bar: int, baz: str) -> None:
        pass

    Foo.__init__ = dummy_init
    assert Foo(bar=1, baz="foo").bar == 1
    assert Foo(bar=1, baz="foo").baz == "foo"
    assert hasattr(Foo(bar=1, baz="foo"), "qux") is False
    try:
        Foo(bar=1, baz="foo", qux="quux")
        raise AssertionError("Should not reach here")
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:57:28.047623
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    _CatchAllUndefinedParameters._get_catch_all_field(
        _CatchAllUndefinedParameters)

    def func():
        pass  # type: Callable

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters._get_catch_all_field(func)



# Generated at 2022-06-23 16:57:33.797962
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, arg1: str, arg2: str):
            pass

    old_init = TestClass.__init__
    new_init = _UndefinedParameterAction.create_init(TestClass)
    assert inspect.signature(old_init) == inspect.signature(new_init)



# Generated at 2022-06-23 16:57:39.644263
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass():
        a: int
        b: int
        c: int

    kvs = {"a": 1, "b": 2, "c": 3, "x": 4, "y": 5, "z": 6}
    try:
        _UndefinedParameterAction._separate_defined_undefined_kvs(MyClass, kvs)
        assert False, "Should have thrown UndefinedException"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:57:50.188082
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class TestClass1:
        k1: str
        k2: str

    with pytest.raises(UndefinedParameterError) as excinfo:
        TestClass1.from_dict({"k1": "v1", "k2": "v2", "k3": "v3"})

    with pytest.raises(UndefinedParameterError) as excinfo:
        TestClass1.from_dict({"k1": "v1", }),


# Unit tests for method handle_from_dict of class _IgnoreUndefinedParameters

# Generated at 2022-06-23 16:57:52.033229
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(msg="Error")
    assert error.message == "Error"



# Generated at 2022-06-23 16:57:57.592302
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses_json import DataClassJsonMixin

    test_dict = {
        'defined_parameter': True,
        'undefined_parameter': 123
    }

    class TestClass(DataClassJsonMixin, Undefined=Undefined.EXCLUDE):
        defined_parameter: bool

    t = TestClass.from_dict(test_dict)
    assert 'defined_parameter' in t.to_dict()
    assert 'undefined_parameter' not in t.to_dict()



# Generated at 2022-06-23 16:58:01.888940
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.undefined import _IgnoreUndefinedParameters
    class Car:

        def __init__(self, brand):
            self.brand = brand

        def __eq__(self, o: Any) -> bool:
            return o.brand == self.brand

    @dataclasses.dataclass
    class OtherCar:
        brand: str

    car = Car(brand="BMW")
    other_car = OtherCar(brand="BMW")
    assert car == other_car
    assert car == _IgnoreUndefinedParameters.handle_from_dict(
        OtherCar, {"brand": "BMW"})

# Generated at 2022-06-23 16:58:03.692798
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("msg")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 16:58:11.303555
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    @dataclasses.dataclass
    class Dataclass:
        field1: str = dataclasses.field(default="field1_default")
        field2: int = dataclasses.field(default=20)
        catch_all: CatchAll = dataclasses.field(default=dataclasses.MISSING)

        # This is the default factory that dataclass_json will use
        # to replace the missing value:
        def __init_subclass__(cls, **kwargs):
            dataclasses.replace(
                cls, catch_all=lambda: {})

    obj = Dataclass("field1_val", 30, catch_all={"field3": "field3_value"})

# Generated at 2022-06-23 16:58:19.592024
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # noinspection PyUnresolvedReferences
    from dataclasses_json.undefined import Undefined
    # noinspection PyUnresolvedReferences
    from dataclasses_json.api import DataClassJsonMixin

    @dataclasses.dataclass
    class TestClass(DataClassJsonMixin):
        a: int
        b: int
        c: int

        @classmethod
        def allow_undefined_parameters(cls) -> Undefined:
            return Undefined.EXCLUDE

    test_instance = TestClass(a=1, b=2, c=3, d=4, e=5)
    assert test_instance.d is None

# Generated at 2022-06-23 16:58:28.817171
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class _TestClass:
        pass

    @dataclasses.dataclass
    class TestClass(_TestClass):
        known1: int
        known2: float
        known3: str = field(default="default value")
        known4: Optional[str] = None

    @dataclasses.dataclass
    class TestClass2(_TestClass):
        catchall: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class TestClass3(_TestClass):
        known1: int
        known2: float
        known3: str = field(default="default value")
        known4: Optional[str] = None
        catchall: Optional[CatchAllVar] = None

    _UndefinedParameterAction.handle_from_dict(cls=TestClass, kvs=dict())

    _Und

# Generated at 2022-06-23 16:58:30.953989
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:58:36.389892
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # noinspection PyUnusedLocal
    @dataclasses.dataclass(frozen=True)
    class _TestClass(object):
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=None)

        def __post_init__(self):
            pass

    # noinspection PyUnusedLocal
    @dataclasses.dataclass(frozen=True)
    class _TestClass2(object):
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.field(default_factory=dict))

        def __post_init__(self):
            pass

    # noinspection PyUnusedLocal

# Generated at 2022-06-23 16:58:40.821332
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        letter_case = 1
        catch_all: Optional[CatchAllVar] = None

    test_case = TestClass()
    test_case.catch_all = dict(b=2)

    print(_CatchAllUndefinedParameters.handle_to_dict(
        test_case,
        {"letter_case": 1, "catch_all": {}}))



# Generated at 2022-06-23 16:58:43.729628
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Test:
        __undefined__ = Undefined.INCLUDE

        def __init__(self, value: int):
            self.value = value

    test_1 = Test(value=1)
    assert test_1.value == 1

    with pytest.raises(UndefinedParameterError):
        Test(value=1, unknown_parameter=2)

# Generated at 2022-06-23 16:58:51.045789
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class DemoClass:
        def __init__(self, a, b, *, c: str = "c"):
            self.a = a
            self.b = b
            self.c = c

    result = _CatchAllUndefinedParameters.handle_to_dict(
        obj=DemoClass,
        kvs=dict(a=1, b=2, c="c", x=4)
    )
    assert result == dict(a=1, b=2, c="c")

# Generated at 2022-06-23 16:58:56.231948
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {"field1": "value1"}
    expected = {"field1": "value1"}
    actual = _UndefinedParameterAction.handle_to_dict(None, kvs)
    assert actual == expected



# Generated at 2022-06-23 16:59:03.695979
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: float = 0.0) -> None:
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(a="a", b=1, c=2.0)
    input_dict = {"a": test_obj.a, "b": test_obj.b, "c": test_obj.c}
    output_dict = _UndefinedParameterAction.handle_to_dict(test_obj,
                                                            input_dict)
    assert output_dict == {"a": test_obj.a, "b": test_obj.b, "c": test_obj.c}

# Generated at 2022-06-23 16:59:10.043129
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class DummyClass:
        a: int
        b: str
        c: CatchAllVar
        undefined_action = _CatchAllUndefinedParameters

    d = DummyClass(a=1, b=2, c={3: 4})
    assert d.c == {3: 4}

    d_ = DummyClass(a=1, b=2, c={3: 4}, d=5, e=6)
    assert d_.c == {3: 4, "d": 5, "e": 6}

    d__ = DummyClass(a=1, b=2, d=5, e=6)
    assert d__.c == {"d": 5, "e": 6}

    d

# Generated at 2022-06-23 16:59:23.445691
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def f(self: "Test",
          known: str,
          unknown_1: int = 1,
          unknown_2: Optional["str"] = None,
          *,
          unknown_arg_1: "Test",
          unknown_arg_2: str = "Default",
          unknown: CatchAll = None):
        self.known = "1"
        self.unknown_1 = 1
        self.unknown_2 = None
        self.unknown_arg_1 = "1"
        self.unknown_arg_2 = "Default"
        self.unknown = None


    @dataclasses.dataclass
    class Test:
        known: str
        unknown_1: int = 1
        unknown_2: Optional[str] = None


# Generated at 2022-06-23 16:59:34.548567
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, param1, param2, param3,
                     undefined: Optional[CatchAllVar] = None):
            self.param1 = param1
            self.param2 = param2
            self.param3 = param3
            self.undefined = undefined


# Generated at 2022-06-23 16:59:39.431704
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def _test_init(self,
                   defined_parameter: str,
                   *undefined_args: Any, **undefined_kwargs):
        pass

    decorated_init = _IgnoreUndefinedParameters.create_init(_test_init)

    class TestClass:
        def __init__(self, defined_parameter: str):
            pass

    TestClass.__init__ = decorated_init
    test_obj = TestClass(defined_parameter="test")
    assert test_obj

# Generated at 2022-06-23 16:59:52.158675
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest

    @dataclasses.dataclass
    class CatchAllTestClass:
        my_bool: bool = False
        catch_all: Optional[CatchAll] = None

    catch_all_class = CatchAllTestClass

    @dataclasses.dataclass
    class TestClassWithoutCatchAll:
        my_bool: bool = False

    no_catch_all_class = TestClassWithoutCatchAll

    @dataclasses.dataclass
    class TestClassWithMultipleCatchAll:
        my_bool: bool = False
        catch_all1: Optional[CatchAll] = None
        catch_all2: Optional[CatchAll] = None

    multiple_catch_all_class = TestClassWithMultipleCatchAll


# Generated at 2022-06-23 17:00:03.957195
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class MyClass:
        def __init__(self, field):
            self.field = field

    my_class = MyClass(1)
    parameters = _RaiseUndefinedParameters.handle_from_dict(MyClass,
                                                            {'field': 1,
                                                             'field2': 2})
    assert parameters == {'field': 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(MyClass, {'field2': 2})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 17:00:09.552841
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError) as exception_info:
        raise UndefinedParameterError(msg="Some error has occurred")
    assert exception_info.value.msg == "Some error has occurred"

# Generated at 2022-06-23 17:00:19.589316
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    UnknownParameters = Dict[str, Any]

    class A:
        def __init__(self, a1: str):
            pass


# Generated at 2022-06-23 17:00:21.938605
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    kvs = {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}
    assert _UndefinedParameterAction.handle_dump(obj=kvs) == kvs



# Generated at 2022-06-23 17:00:29.005486
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def init(self, a, b, c, d=None, e=None):
        pass

    @dataclasses.dataclass
    class TestClass:
        a: Any
        b: Any
        c: Any
        d: Any = None
        e: Any = None
        catch_all: Optional[CatchAll] = None

        def __init__(self, a, b, c, d=None, e=None):
            pass

    init_signature = inspect.signature(init)
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)
    new_init_signature = inspect.signature(new_init)
    assert init_signature == new_init_signature

# Generated at 2022-06-23 17:00:34.292521
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class A:
        def __init__(self, a: int, b: str, c: object = object) -> None:
            pass

    assert _UndefinedParameterAction.handle_dump(A) == {}


# Unit tests for method handle_to_dict of class _UndefinedParameterAction

# Generated at 2022-06-23 17:00:43.941101
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test:
        def __init__(self, letter_cased: str = "letter_cased",  # type: ignore
                     camel_cased: str = "camel_cased",  # type: ignore
                     _catch_all: CatchAll = None):  # type: ignore
            self.letter_cased = letter_cased
            self.camel_cased = camel_cased
            self._catch_all = _catch_all

    test = Test(letter_cased="letter_cased",
                camel_cased="camel_cased",
                _catch_all={
                    "wrong_letter_cased": "wrong_letter_cased",
                    "wrong_camel_cased": "wrong_camel_cased"})

# Generated at 2022-06-23 17:00:48.553081
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    kvs = dict(name=5, age=5, missing=5)
    correct_kws = dict(name=5, age=5)
    kws = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert kws == correct_kws



# Generated at 2022-06-23 17:00:57.425290
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class UndefinedParameterHandlingTest:
        def __init__(self,
                     name: str,
                     age: int,
                     **catch_all: CatchAllVar):
            self.name = name
            self.age = age
            self.undefined_parameters = catch_all

    # Normal case
    class_params = {
        "name": "John Doe",
        "age": 24,
        "undefined": "Test"
    }
    expected_params = {
        "name": "John Doe",
        "age": 24,
        "undefined_parameters": {
            "undefined": "Test"
        }
    }
    actual_params = _CatchAllUndefinedParameters.handle_from_dict(
        UndefinedParameterHandlingTest, class_params)
    assert actual_params == expected_params

# Generated at 2022-06-23 17:01:06.034209
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Foo:
        def __init__(self, a, b, c, d=1, e=1):
            pass


    def _get_constructor_args(self, *args, **kwargs):
        init_signature = inspect.signature(self.__init__)
        bound_parameters = init_signature.bind_partial(self, *args, **kwargs)
        bound_parameters.apply_defaults()
        return bound_parameters.arguments


    class Foo:
        __init__ = _IgnoreUndefinedParameters.create_init(Foo)

        def __init__(self, a, b, c, d=1, e=1):
            super().__init__()
            arguments = _get_constructor_args(self, a, b, c, d, e)
           

# Generated at 2022-06-23 17:01:13.679621
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyUnresolvedReferences
    import marshmallow

    @dataclasses.dataclass
    class TestCatchAllParam:
        x: int
        y: int
        z: str
        c: CatchAll = dataclasses.field(default_factory=dict)

        def __init__(self, *args, **kwargs):
            pass

    @dataclasses.dataclass
    class TestCatchAllParamInherits(TestCatchAllParam):
        a: int
        b: int

        def __init__(self, *args, **kwargs):
            pass

    test_cases = [
        TestCatchAllParam,
        TestCatchAllParamInherits,
    ]

# Generated at 2022-06-23 17:01:19.145209
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Cls:
        def __init__(self,
                     a: int,
                     b: int = None,
                     c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    c = Cls(1, 2, {"a": 3})
    d = dict(a=1, b=2, c={"a": 3})
    assert c.a == 1
    assert c.b == 2
    assert c.c["a"] == 3
    assert dataclasses.asdict(c) == d

    c = Cls(1, 2)
    d = dict(a=1, b=2, c={})
    assert c.a == 1
    assert c.b == 2
    assert c.c == {}

# Generated at 2022-06-23 17:01:23.377560
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClassABC:
        a: int
        b: int
        c: int

    kvs = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClassABC, kvs)

    kvs = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    result = _RaiseUndefinedParameters.handle_from_dict(TestClassABC, kvs)
    assert len(result) == 3



# Generated at 2022-06-23 17:01:25.386892
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    o = _UndefinedParameterAction()
    obj = object()
    assert o.handle_dump(obj) == {}

# Generated at 2022-06-23 17:01:36.845919
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class CatchAllTest:
        a: int = 1
        b: int
        c: int = dataclasses.field(default=2)
        catch: Optional[CatchAll] = dataclasses.field(default=None)


    @dataclasses.dataclass
    class NoCatchAllTest:
        a: int
        b: int


    def assert_init(init_func, kwargs_given, expected_kwargs):
        actual_state = init_func(**kwargs_given)
        for key, value in expected_kwargs.items():
            assert getattr(actual_state, key) == value


    init_func_catch_all = \
        _CatchAllUndefinedParameters.create_init(CatchAllTest)
    init_func_

# Generated at 2022-06-23 17:01:49.768185
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json.utils import type_validator

    @dataclass
    class CatchAllFixture:
        a: int
        b: int = 10
        c: Optional[CatchAllVar]

    @dataclass
    class CatchAllFixture2:
        a: int
        b: int = 10
        c: CatchAllVar

    @dataclass
    class CatchAllFixture3:
        a: int
        b: int = 10
        c: CatchAllVar = type_validator(CatchAllVar, {})

    @dataclass
    class CatchAllFixture4:
        a: int
        b: int = 10
        c: CatchAllVar = type_validator(CatchAllVar, dict)


# Generated at 2022-06-23 17:01:56.878473
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    undefined = Undefined.RAISE.value
    assert undefined.handle_from_dict(cls=str, kvs={"_": "_"}) == {"_": "_"}

    with pytest.raises(UndefinedParameterError):
        undefined.handle_from_dict(cls=str, kvs={"_": "_", "x": "x"})



# Generated at 2022-06-23 17:02:03.976993
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # type: () -> None
    class C:
        def __init__(self, x, y=1, z=None):
            # type: (int, int, Optional[int]) -> None
            self.x = x
            self.y = y
            self.z = z

    new_init = _IgnoreUndefinedParameters.create_init(C)
    obj = new_init(0, y=2, z=3, a=4)
    assert obj.x == 0
    assert obj.y == 2
    assert obj.z == 3

# Generated at 2022-06-23 17:02:12.225548
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Define the class that we want to create the init function for
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class MyClass:
        field1: str = "a"
        field2: str = "b"
        field3: str = "c"
        catch_all: Optional[CatchAll] = None

        def __init__(self, **kws):
            for k, v in kws.items():
                setattr(self, k, v)

    # Create the init function
    created_init_function = \
        _CatchAllUndefinedParameters.create_init(MyClass)

    # Define an object of the class
    my_obj = MyClass()

    # Define a keyword-argument mapping that we want to pass to the init
    # function
   

# Generated at 2022-06-23 17:02:18.592345
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class MockClass:
        pass

    method = _UndefinedParameterAction.handle_from_dict

    assert method(MockClass, {}) == {}
    assert method(MockClass, {"k1": "v1", "k2": "v2"}) == {"k1": "v1", "k2":
                                                           "v2"}

# Generated at 2022-06-23 17:02:20.513978
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError(message=f"Message")



# Generated at 2022-06-23 17:02:29.813363
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class SimpleClass:
        def __init__(self, a, b, c=3, d=4, *args, **kwargs):
            pass

    actual_init = _CatchAllUndefinedParameters.create_init(SimpleClass)
    actual_init_signature = inspect.signature(actual_init)

    @functools.singlespace
    def expected_init_signature(self, a, b, c=3, d=4, *args, **kwargs):
        pass

    assert str(actual_init_signature) == str(expected_init_signature)



# Generated at 2022-06-23 17:02:31.339325
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("test")

# Generated at 2022-06-23 17:02:40.699840
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    undefined_parameter_action = _IgnoreUndefinedParameters

    test_args = dict(a=1, b=2, c=3)
    expected_result = test_args.copy()
    del expected_result["c"]
    result = undefined_parameter_action.handle_from_dict(TestClass, test_args)
    assert result == expected_result




# Generated at 2022-06-23 17:02:41.647898
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass



# Generated at 2022-06-23 17:02:54.393546
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest  # type: ignore
    import datetime
    import json

    from dataclasses_json.core import (
        make_encoder, make_decoder, config, dataclass_json)
    from dataclasses_json.undefined_parameters import _CatchAllUndefinedParameters

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclasses.dataclass
    class MyDataClass:
        name: str

    encoder = make_encoder(encoder_config=config)
    decoder = make_decoder(decoder_config=config)

    obj = MyDataClass(name="test")
    kvs = encoder(obj)
    kvs["age"] = 12


# Generated at 2022-06-23 17:02:57.044282
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    exception = None
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs=dict())
    except UndefinedParameterError as e:
        exception = e
    assert exception is not None



# Generated at 2022-06-23 17:03:09.479760
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class SimpleDataClass:
        x: int
        y: int

    # Defined initialization parameters
    x = 1
    y = 2
    kvs = {"x": x, "y": y}
    result = _RaiseUndefinedParameters.handle_from_dict(cls=SimpleDataClass,
                                                        kvs=kvs)
    assert result == kvs

    # Undefined initialization parameter
    x = 1
    y = 2
    kvs = {"x": x, "y": y, "z": "undefined"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=SimpleDataClass,
                                                   kvs=kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False



# Generated at 2022-06-23 17:03:10.483052
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except Exception:
        pass

# Generated at 2022-06-23 17:03:11.707536
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    a = _UndefinedParameterAction()
    assert a is a

# Generated at 2022-06-23 17:03:12.966224
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-23 17:03:17.393922
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    raise_parameter_handler = _RaiseUndefinedParameters()
    assert hasattr(raise_parameter_handler, "handle_from_dict")
    assert hasattr(raise_parameter_handler, "handle_to_dict")
    assert hasattr(raise_parameter_handler, "handle_dump")
    assert hasattr(raise_parameter_handler, "create_init")


# Generated at 2022-06-23 17:03:28.199254
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        field_1: str
        field_2: int
        field_3: float
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    def call_handle_from_dict(kvs: Dict[str, Any]):
        return _CatchAllUndefinedParameters.handle_from_dict(
            cls=Test,
            kvs=kvs)

    assert call_handle_from_dict({}) == {
        "field_1": None,
        "field_2": None,
        "field_3": None,
        "catch_all": {}
    }


# Generated at 2022-06-23 17:03:35.173475
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, x: str, y: int):
            self.x = x
            self.y = y

    caught_exception = False
    try:
        _IgnoreUndefinedParameters.handle_from_dict(A, kvs=dict(y=42, z=1))
    except UndefinedParameterError:
        caught_exception = True
    assert caught_exception



# Generated at 2022-06-23 17:03:42.377099
# Unit test for method create_init of class _IgnoreUndefinedParameters

# Generated at 2022-06-23 17:03:54.356133
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    catch_all_field = _CatchAllUndefinedParameters._get_catch_all_field
    handle_dump = _UndefinedParameterAction.handle_dump
    assert handle_dump(None) == {}
    assert handle_dump(Undefined.INCLUDE) == {}
    assert handle_dump(Undefined.RAISE) == {}
    with pytest.raises(
            UndefinedParameterError) as exc_info:
        _ = catch_all_field(Undefined.RAISE)
    assert "No field of type dataclasses_json.CatchAll defined" in \
           str(exc_info.value)

    assert handle_dump(Undefined.EXCLUDE) == {}

# Generated at 2022-06-23 17:04:02.216992
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    import pytest

    @dataclass_json(undefined=Undefined.RAISE)
    @dataclass
    class TestClass:
        a: int
        b: str
        c: float = 0.0

    # Should not raise
    TestClass(a=0, b="")

    with pytest.raises(UndefinedParameterError):
        TestClass(a=0, b="", d=True)

# Generated at 2022-06-23 17:04:11.661312
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Test that the create_init method of _IgnoreUndefinedParameters
    behaves correctly.
    This test ensures that we correctly handle the subclass init
    method correctly, to correctly discard invalid parameters.
    """

    import dataclasses
    import dataclasses_json

    @dataclasses_json.dataclass_json(
        undefined=dataclasses_json.Undefined.EXCLUDE)
    @dataclasses.dataclass
    class DataclassBla(object):
        ivar: int

        def __init__(self, ivar: int):
            self.ivar = ivar

    import json

    dumps = dataclasses_json.dumps
    loads = dataclasses_json.loads

    d = DataclassBla(ivar=1)

# Generated at 2022-06-23 17:04:22.239280
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert type(Undefined.INCLUDE.value("")) is _CatchAllUndefinedParameters
    assert type(Undefined.RAISE.value("")) is _RaiseUndefinedParameters
    assert type(Undefined.EXCLUDE.value("")) is _IgnoreUndefinedParameters

# Create tests for the class _UndefinedParameterAction
# These tests are dynamically created and show the best practice to create
# unit tests for a derived class from _UndefinedParameterAction
# Note that this is not a test for _UndefinedParameterAction but for its
# child classes.
UndefinedParameterAction: Callable[..., _UndefinedParameterAction]

for action in Undefined:
    UndefinedParameterAction = action.value
    test_name = f"test__{type(UndefinedParameterAction).__name__}"

    def test(self):
        kvs

# Generated at 2022-06-23 17:04:33.079197
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass: pass

    class DummySubClass(DummyClass):
        def __init__(self, a, b=None):
            pass

    test_class = _UndefinedParameterAction()

    exception_raised = False
    try:
        test_class.handle_from_dict(cls=DummyClass, kvs={"c": "d"})
    except NotImplementedError:
        exception_raised = True
    assert exception_raised

    exception_raised = False
    try:
        test_class.handle_to_dict(obj=DummyClass, kvs={"c": "d"})
    except NotImplementedError:
        exception_raised = True
    assert exception_raised

    exception_raised = False

# Generated at 2022-06-23 17:04:40.769461
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class _TestCatchAll(object):

        attr_a: str
        attr_b: int
        attr_c: float
        undefined: CatchAll = dataclasses.field(default=dataclasses.MISSING)

    _test_object = _TestCatchAll(attr_a='test',
                                 attr_b=42,
                                 attr_c=3.141,
                                 undefined={'test': 1234,
                                            'test2': 'test'})

    _test_result = _CatchAllUndefinedParameters.handle_dump(
        _test_object)

    assert _test_result == {'test': 1234, 'test2': 'test'}


# Generated at 2022-06-23 17:04:51.086987
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class _TestClass:
        def __init__(self, a, b, c=3):
            pass

    n = _IgnoreUndefinedParameters.create_init(_TestClass)
    n(_TestClass, 1, 2, 3, 4, 5, 6)
    n(_TestClass, 1, 2, 3, 4, 5, 6, a=1)
    n(_TestClass, 1, 2, 3)
    n(_TestClass, 1, 2, 3, a=1, b=1)
    n(_TestClass, 1, 2, 3, c=1)
    n(_TestClass, 1, 2, 3, a=1, b=1, c=1)

    n = _IgnoreUndefinedParameters.create_init(_TestClass)

# Generated at 2022-06-23 17:05:02.947700
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: str = "c"
        d: Optional[CatchAllVar] = dataclasses.field(default=dict)

    @dataclasses.dataclass
    class B:
        a: str
        b: int
        c: str = "c"
        d: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    @dataclasses.dataclass
    class C:
        a: str
        b: int
        c: str = "c"
        d: Optional[CatchAllVar]

    @dataclasses.dataclass
    class D:
        a: str
        b: int
        c: str = "c"

    data_cls

# Generated at 2022-06-23 17:05:09.603625
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int = dataclasses.field(default=4)
        b: int = dataclasses.field(default=6)
        c: int = dataclasses.field(default=7)
        d: int = dataclasses.field(default=9)
        e: int

    @dataclasses.dataclass
    class B(A):
        f: int = dataclasses.field(default=9)
        g: int = dataclasses.field(default=12)
        h: int = dataclasses.field(default=9)
        undefined: Optional[CatchAllVar]

    @dataclasses.dataclass
    class C(B):
        i: int = dataclasses.field(default=11)
        j: int = dat

# Generated at 2022-06-23 17:05:21.108328
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int = dataclasses.field(default=123)

    tc = TestClass(1, 2)
    assert tc.c == 123

    init_func = _UndefinedParameterAction.create_init(TestClass)
    tc = TestClass.__init__.__get__(object(), TestClass)
    tc(1, 2, 3)
    assert tc.c == 3

    init_func = _CatchAllUndefinedParameters.create_init(TestClass)
    tc = TestClass.__init__.__get__(object(), TestClass)
    tc(1, 2, 3)
    assert tc.c == 3

    init_func = _IgnoreUndefinedParameters.create_init(TestClass)
    tc

# Generated at 2022-06-23 17:05:29.006375
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Tests that _IgnoreUndefinedParameters.create_init() removes arguments
    in the initialization that are not handled by the class.
    """
    @dataclasses.dataclass
    class TestClass:
        foo: str
        bar: str = "baz"
