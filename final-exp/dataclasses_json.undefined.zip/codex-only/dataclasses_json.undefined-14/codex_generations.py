

# Generated at 2022-06-23 16:55:33.104311
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-23 16:55:44.456775
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a_field, b_field, c_field, _UNKNOWN=None):
            self.a_field = a_field
            self.b_field = b_field
            self.c_field = c_field
            self._UNKNOWN = _UNKNOWN

    # First test, no undefined parameters given
    kvs_1 = {
        "a_field": "value 1",
        "b_field": "value 2",
        "c_field": "value 3",
    }

    result = _CatchAllUndefinedParameters.handle_from_dict(Test, kvs_1)

# Generated at 2022-06-23 16:55:50.144733
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json import dataclass, Undefined
    from dataclasses_json.utils import Undefined

    @dataclass
    class TestCatchAll:
        a: str
        b: int
        c: Undefined.CATCH_ALL

        def __init__(self, a: str, b: int, c: Optional[CatchAllVar] = dict()):
            pass

    test_instance = TestCatchAll("hello", 8, {"a": "b"})
    as_dict = test_instance.__dict__
    assert as_dict == {"a": "hello", "b": 8, "c": {"a": "b"}}

    dict_without_catch_all = _CatchAllUndefinedParameters.handle_to_dict(
        test_instance, as_dict)
    assert dict_without_

# Generated at 2022-06-23 16:55:57.266757
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        name: str

    @dataclasses.dataclass
    class B:
        name: str = "bob"
        catch_all: Optional[CatchAllVar] = CatchAll

    @dataclasses.dataclass
    class B_DefaultNone:
        name: str = "bob"
        catch_all: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class BCatchAllFirst:
        catch_all: Optional[CatchAllVar] = CatchAll
        name: str = "bob"

    @dataclasses.dataclass
    class UnknownFirst:
        unknown: int
        name: str = "bob"
        catch_all: Optional[CatchAllVar] = CatchAll


# Generated at 2022-06-23 16:55:58.817381
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert (_UndefinedParameterAction.handle_dump(
        object) == {})

# Generated at 2022-06-23 16:56:05.703152
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Dummy:
        def __init__(self, a, b, c):
            pass

    class DummyWithInit:
        def __init__(self, a, b, c):
            pass

        def __init_subclass__(cls):
            # Dummy implementation
            pass

    dummy_with_init = DummyWithInit(1, 2, 3)

    assert not inspect.isclass(dummy_with_init)
    catch_all_init = _CatchAllUndefinedParameters.create_init(Dummy)(
        dummy_with_init, 1, 2, 3)
    assert catch_all_init.__class__ == Dummy



# Generated at 2022-06-23 16:56:12.451442
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def __init__(self, a, b: int, c: Optional[CatchAllVar]):
        pass

    init_func = _CatchAllUndefinedParameters.create_init(__init__)
    assert init_func.__name__ == "__init__"
    init_func = _IgnoreUndefinedParameters.create_init(__init__)
    assert init_func.__name__ == "__init__"

# Generated at 2022-06-23 16:56:22.228081
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: str
        b: str

    a = A(a="A", b="B")
    assert a.a == "A"
    assert a.b == "B"

    @dataclasses.dataclass
    class B:
        a: str
        b: str
        c: str
        d: CatchAll

        def __init__(self, a, b, e, c="C", **d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

        def __dataclass_json__(self, _):
            return {**super().__dataclass_json__(_), **self.d}


# Generated at 2022-06-23 16:56:22.955968
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass



# Generated at 2022-06-23 16:56:29.835779
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class_fields = {
        "a": Field(name="a", type=int, default=10),
        "b": Field(name="b", type=str, default=""),
        "c": Field(name="c", type=str, default=None)
    }
    parameters = {
        "a": 0,
        "b": "",
        "c": None
    }

    def _check(action: _UndefinedParameterAction,
               expected: Dict[str, Any]):
        result = action.handle_from_dict(class_fields, parameters)
        assert result == expected

    _check(_IgnoreUndefinedParameters, {"a": 0, "b": "", "c": None})
    _check(_RaiseUndefinedParameters, {"a": 0, "b": "", "c": None})
    _check

# Generated at 2022-06-23 16:56:40.305346
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import sys
    import inspect
    # noinspection PyProtectedMember
    init_method_before = sys.modules.pop('__main__').__dict__['MyClass'].__init__
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    # noinspection PyProtectedMember
    method_after = sys.modules.pop('__main__').__dict__['MyClass'].__init__
    init_signature_before = inspect.signature(init_method_before)
    init_signature_after = inspect.signature(method_after)
    assert init_signature_before == init_signature_after

    obj = MyClass(1, 2, 3)

# Generated at 2022-06-23 16:56:47.432578
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int = 5
        catch_all: Optional[CatchAllVar] = dataclasses_json.CatchAllVar()

    result = _CatchAllUndefinedParameters.handle_to_dict(
        TestClass(a=1),
        {"a": "a_str", "b": -4, "catch_all": {"catch": "all"}}
    )
    assert len(result) == 3
    assert result["a"] == 1
    assert result["b"] == -4
    assert result["catch"] == "all"



# Generated at 2022-06-23 16:56:59.104564
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class MyClass:
        def __init__(self, a, b=None):
            self._a = a
            self._b = b

            self.handle_to_dict(object(),
                                kvs={"a": "a", "b": "b", "c": "c"})

        @staticmethod
        def handle_to_dict(obj, kvs: Dict[Any, Any]):
            kvs.pop("a", None)
            kvs.pop("b", None)
            return kvs

    class MyOtherClass:
        def __init__(self, **kvs):
            pass

    assert len(_RaiseUndefinedParameters.handle_from_dict(MyClass, {
        "a": "a"
    })) == 1


# Generated at 2022-06-23 16:57:12.334551
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestData(DataClassJsonMixin):
        field: int
        catch_all: Optional[CatchAllVar] = None

        @staticmethod
        def _undefined_parameters_handler() -> _UndefinedParameterAction:
            return _CatchAllUndefinedParameters

    def _test(given_value, expected_value):
        td1 = TestData.from_dict({"field": 3, "catch_all": given_value})
        td1_dict = td1.to_dict()
        assert td1_dict["catch_all"] == expected_value

# Generated at 2022-06-23 16:57:20.310339
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    from typing import List
    import dataclasses_json

    @dataclass
    class Foo:
        l: List[int]
        d: dict
        s: str
        i: int = 4
        ca: dataclasses_json.CatchAll = None

    foo = Foo(l=[1, 2, 3], d={"a": 1, "b": 2}, s="s", b=7)
    assert foo.i == 4
    assert foo.d["a"] == 1
    assert foo.d["b"] == 2
    assert foo.ca["b"] == 2
    assert foo.ca["b"] == 2

# Generated at 2022-06-23 16:57:28.821419
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import Optional
    import pytest
    from dataclasses_json.utils import CatchAll


    class TestClass:

        def __init__(self, catch_all: Optional[CatchAll] = None):
            self.catch_all = catch_all


    def test_valid_default_call():
        kvs = {}
        kv_expected = {"catch_all": None}
        kv_actual = _CatchAllUndefinedParameters.handle_from_dict(
            cls=TestClass, kvs=kvs)
        assert kv_expected == kv_actual


    def test_valid_default_call_with_defined_parameter():
        kvs = {"catch_all": None}
        kv_expected = {"catch_all": None}
        kv_actual = _CatchAllUnd

# Generated at 2022-06-23 16:57:39.220603
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Test the create_init method belonging to the _UndefinedParameterAction
    class.
    """
    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    # noinspection PyArgumentList
    @dataclass
    class TestClass:
        a: int
        b: str
        c: float
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, a: int, b: str, c: float, catch_all: Optional[
            CatchAllVar] = None):
            pass

    # noinspection PyArgumentList
    @dataclass
    class TestClass2:
        a: int
        b: str
        c: float


# Generated at 2022-06-23 16:57:47.753813
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: str
    obj = TestClass("a", "b", "c")
    given = {"a": "a", "b": "b", "c": "c", "d": "d", "e": "e"}
    expected = {"a": "a", "b": "b", "c": "c"}
    actual = _UndefinedParameterAction.handle_to_dict(obj, given)
    assert actual == expected



# Generated at 2022-06-23 16:57:52.987562
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = {"foo": "bar"}
    kvs = {"foo": "bar", "bar": "baz"}
    expected_output = {"foo": "bar", "bar": "baz"}
    actual_output = \
        _UndefinedParameterAction.handle_to_dict(obj, kvs)
    assert actual_output == expected_output

# Generated at 2022-06-23 16:57:55.431854
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}



# Generated at 2022-06-23 16:58:07.009851
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import dataclasses

    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int = 1
        d: int = 2
        e: Optional[CatchAllVar] = None

        def __init__(self, a, b, c, d, e):
            pass


    init_with_catch_all = _CatchAllUndefinedParameters.create_init(A)
    init_with_catch_all(A, 1, 2)
    init_with_catch_all(A, 1, 2, c=3)
    init_with_catch_all(A, 1, 2, c=3, d=4, f=5)
    init_with_catch_all(A, 1, 2, c=3, d=4, e={5: 6})



# Generated at 2022-06-23 16:58:13.994303
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    dict_with_defined_parameter = {'a': 1}
    dict_with_undefined_parameter = {'a': 1, 'b': 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(dict_with_defined_parameter) == dict_with_defined_parameter
    assert _IgnoreUndefinedParameters.handle_from_dict(dict_with_undefined_parameter) == dict_with_defined_parameter


# Generated at 2022-06-23 16:58:23.454942
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Course:
        def __init__(self, name: str, catch_all: CatchAll, log: Optional[bool] = False):
            self.name = name
            self.catch_all = catch_all

    course = Course(name="Introduction to Python", log=True, some_key="some_value")
    kvs = _UndefinedParameterAction.handle_dump(course)
    assert kvs == {"some_key": "some_value"}



# Generated at 2022-06-23 16:58:31.415474
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin

    @dataclass
    class Person(DataClassJsonMixin):
        first_name: str
        last_name: str
        age: int
        catch_all: Optional[CatchAllVar]


    @config(unknown=Undefined.INCLUDE)
    @dataclass
    class PersonCatchAllInclude(Person):
        pass


    @config(unknown=Undefined.EXCLUDE)
    @dataclass
    class PersonCatchAllExclude(Person):
        pass


# Generated at 2022-06-23 16:58:41.349638
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert issubclass(Undefined.INCLUDE.value, _UndefinedParameterAction)
    assert issubclass(Undefined.RAISE.value, _UndefinedParameterAction)
    assert issubclass(Undefined.EXCLUDE.value, _UndefinedParameterAction)

    # Check that no instance of the classes can be created.
    with pytest.raises(TypeError):
        Undefined.INCLUDE.value()
    with pytest.raises(TypeError):
        Undefined.RAISE.value()
    with pytest.raises(TypeError):
        Undefined.EXCLUDE.value()

    # Check that the methods defined in the ABC are implemented.
    assert hasattr(Undefined.INCLUDE.value, "handle_from_dict")

# Generated at 2022-06-23 16:58:46.308631
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int,
                     b: int, c: int):
            pass

    kvs = dict(a=42,
               b=23,
               bla=12)
    parsed = _IgnoreUndefinedParameters.handle_from_dict(obj=TestClass,
                                                         kvs=kvs)
    assert parsed == dict(a=42,
                          b=23)



# Generated at 2022-06-23 16:58:52.502908
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            pass

    t_cls = TestClass(1, 2, 3)
    t_cls2 = _IgnoreUndefinedParameters._IgnoreUndefinedParameters.create_init(
        t_cls)(t_cls, 1, 2, 3, d=4, e=5)
    assert t_cls2



# Generated at 2022-06-23 16:58:59.887535
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    # type: ignore
    class Test:
        test: int
        optional: str = "optional"
        catch_all: CatchAll = None

    dataclass = Test(test=10, not_defined="not_defined")
    assert dataclass.test == 10
    assert dataclass.optional == "optional"
    assert dataclass.catch_all is not None
    assert "not_defined" in dataclass.catch_all

# Generated at 2022-06-23 16:59:03.089851
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert issubclass(_UndefinedParameterAction, abc.ABC)

# Generated at 2022-06-23 16:59:07.171625
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # no undefined parameters
    assert _CatchAllUndefinedParameters.handle_from_dict(object, {}) == {}
    # one undefined parameter
    assert _CatchAllUndefinedParameters.handle_from_dict(object, {"a": 1}) \
           == {"a": {"_UNKNOWN0": 1}}
    # two undefinied parameters
    assert _CatchAllUndefinedParameters.handle_from_dict(object, {"a": 1,
                                                                  "b": 2}) == {
           "a": {"_UNKNOWN0": 1, "_UNKNOWN1": 2}}
    # undefined parameter and catch-all field present

# Generated at 2022-06-23 16:59:09.711871
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert issubclass(
        Undefined.EXCLUDE.value,
        _UndefinedParameterAction)

# Generated at 2022-06-23 16:59:12.903115
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Unit test to check the existence of this class.
    """
    _UndefinedParameterAction()

# Generated at 2022-06-23 16:59:18.336042
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    assert _CatchAllUndefinedParameters.handle_to_dict(None,
                                                       {}) == dict()


if __name__ == "__main__":
    test__CatchAllUndefinedParameters_handle_to_dict()

# Generated at 2022-06-23 16:59:30.294851
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json.config import Config

    @dataclass(config=Config,
               undefined=Undefined.INCLUDE)
    class TestClass:
        field: str
        catch_all: Optional[CatchAllVar]

    kvs = {"field": "hello", "undefinedfield": "blah",
           "catch_all": {"field2": "bye"}}
    expected_kvs = {"field": "hello", "catch_all": {"undefinedfield": "blah",
                                                    "field2": "bye"}}
    actual_kvs: Dict[str, Any] = TestClass.INCLUDE._handle_from_dict(
        TestClass, kvs)
    assert actual_kvs == expected_kvs


# Generated at 2022-06-23 16:59:36.063897
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int

    error_message = f"Received undefined"
    undefined_parameter_key = "b"
    undefined_parameter_value = 5
    with pytest.raises(UndefinedParameterError,
                       match=f"{error_message}"):
        _RaiseUndefinedParameters.handle_from_dict(
            TestClass, {undefined_parameter_key: undefined_parameter_value})



# Generated at 2022-06-23 16:59:46.040920
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Foo:
        def __init__(self, a: str, b: str, c: int, d: float,
                     e: Optional[int] = None, f: Optional[int] = None,
                     g: Optional[int] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
            self.g = g

    def check_undefined_parameters(undefined_action: _UndefinedParameterAction,
                                   expected_last_call_parameters: Dict):
        init = undefined_action.create_init(Foo)

        calls = []

        class FooMock:
            def __init__(self, **kwargs):
                calls.append(kwargs)


# Generated at 2022-06-23 16:59:51.575559
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class C:
        def __init__(self, a: str = "test", b: str = "test",
                     c: int = 100):
            pass

    _UndefinedParameterAction.create_init(C)(C)()

# Generated at 2022-06-23 16:59:58.702046
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class _TargetClass:
        def __init__(self, a, b=1, **kwargs):
            pass

    init_ignoring = _UndefinedParameterAction.create_init(_TargetClass)
    calling_ignoring = functools.partial(init_ignoring, _TargetClass(), a=1,
                                         b=2, c=3)
    calling_ignoring()

    class _TargetClassCatchAll:
        def __init__(self, a, b=1, d: CatchAll = None):
            pass

    init_catchall = _UndefinedParameterAction.create_init(_TargetClassCatchAll)
    calling_catchall = functools.partial(init_catchall, _TargetClassCatchAll(),
                                         a=1, b=2, c=3)
    calling_catchall()

# Generated at 2022-06-23 17:00:00.366728
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(obj=3) == {}

# Generated at 2022-06-23 17:00:10.357227
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from marshmallow import Schema, fields, post_load

    class MySchema(Schema):
        catch_all = fields.List(fields.Str())

        @post_load
        def make_obj(self, data, **kwargs):
            return MyClass(**data)

    class MyClass:
        def __init__(self, a: int, b: int, c: str, d: str,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.catch_all = catch_all

    schema = MySchema()


# Generated at 2022-06-23 17:00:17.953109
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from dataclasses import dataclass

    class Key(Enum):
        x = "x"
        y = "y"


    @dataclass
    class A:
        x: Any = Field(default=None, repr=False)
        y: Any = Field(default=None, repr=False)

        def __init__(self, *args, **kwargs):
            self.x = kwargs.get("x", 42)
            self.y = kwargs.get("y", 43)


    class B(A):
        def __init__(self, *args, **kwargs):
            super().__init__(x=kwargs.pop(Key.x.value, None),
                             y=kwargs.pop(Key.y.value, None))



# Generated at 2022-06-23 17:00:29.344336
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

        def __repr__(self):
            return f"TestClass({self.a}, {self.b}, {self.c})"

    test_cases = {
        Undefined.EXCLUDE: {},
        Undefined.RAISE: {},
        Undefined.INCLUDE: {},
    }
    test_class = TestClass(3, 4, 5)
    for key, value in test_cases.items():
        schema_output = key.value.handle_dump(test_class)
        assert schema_output == value


# Generated at 2022-06-23 17:00:41.125593
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from jsonclasses import jsonclass, types

    @jsonclass(class_graph='test_utils__CatchAllUndefinedParameters_handle_from_dict')
    class AllUndefinedParameters:
        a: str = "a"
        b: int = 1

    @jsonclass(class_graph='test_utils__CatchAllUndefinedParameters_handle_from_dict')
    class MissingParameter:
        a: str = "a"
        b: int = 1
        _undefined: CatchAllVar = types.CatchAll(factory=dict)

    @jsonclass(class_graph='test_utils__CatchAllUndefinedParameters_handle_from_dict')
    class DefaultValue:
        a: str = "a"
        b: int = 1

# Generated at 2022-06-23 17:00:42.537531
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    x = _UndefinedParameterAction()

# Generated at 2022-06-23 17:00:55.400353
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestDataClass:
        a: str
        b: int
        c: str = "default"
        d: Optional[CatchAllVar] = CatchAll

        def __init__(self, **kwargs):
            pass

    assert TestDataClass.__init__ is not _CatchAllUndefinedParameters.create_init(
        TestDataClass)

    init = _CatchAllUndefinedParameters.create_init(TestDataClass)
    assert init(TestDataClass(), "a", "b", 1, 2) is None
    assert init(TestDataClass(), "a", "b", 1, 2, 3) is not None
    assert init(TestDataClass(), "a", "b", 1, 2, d=3) is not None

# Generated at 2022-06-23 17:00:58.146996
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Junk:
        pass
    obj = Junk()
    assert _UndefinedParameterAction.handle_dump(obj) == {}

# Generated at 2022-06-23 17:01:00.704156
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test exception")
    except UndefinedParameterError as exception:
        assert str(exception) == "Test exception"

# Generated at 2022-06-23 17:01:02.997388
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    assert isinstance(UndefinedParameterError("test"), Exception)
    assert "test" in str(UndefinedParameterError("test"))

# Generated at 2022-06-23 17:01:07.947746
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    ## Test: undefined parameters
    # Test: Undefined.INCLUDE
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        d: Optional[CatchAllVar] = dataclasses.field(
            default=None)
        __undefined__ = dataclasses_json.Undefined.INCLUDE

    # Test: No undefined parameters
    try:
        parsed = dataclasses_json.undefined.UndefinedParameterAction(
            action=dataclasses_json.Undefined.INCLUDE).handle_from_dict(
            cls=TestClass, kvs=dict(a=1, b=2, c=3))
    except dataclasses_json.UndefinedParameterError:
        raise AssertionError("No undefined parameters")



# Generated at 2022-06-23 17:01:09.784960
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("Test message")

# Generated at 2022-06-23 17:01:17.522947
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class X:
        defined: int = 0
        undefined: Optional[CatchAllVar] = None

    _ = dict(undefined={1, 2, 3})
    _ = dict(defined=1, undefined={1, 2, 3})
    _ = dict(defined=1, undefined={1, 2, 3}, _UNKNOWN1=1, _UNKNOWN2=2)

    _ = dict(defined=1, _UNKNOWN_1=1, _UNKNOWN_2=2)
    _ = dict(defined=1, undefined={})

    with pytest.raises(UndefinedParameterError):
        dict(defined=1, UNDEFINED={})

    with pytest.raises(UndefinedParameterError):
        dict(defined=1, undefined=1)



# Generated at 2022-06-23 17:01:20.562673
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    try:
        _UndefinedParameterAction.handle_to_dict(None, None)
    except:  # noqa
        assert False
    assert True

# Generated at 2022-06-23 17:01:27.927840
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # code copied from https://github.com/thombashi/pytest-mypy-plugins/issues/32
    import sys

    if sys.version_info >= (3, 7):

        class ClassInit:
            def __init__(self, x: int, y: str):
                self.x = x
                self.y = y

        obj = ClassInit(x=1, y="a")
        _IgnoreUndefinedParameters._separate_defined_undefined_kvs(obj,
                                                                    {"x": 1,
                                                                     "y": "a",
                                                                     "z": 3})

# Generated at 2022-06-23 17:01:31.774718
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def func(self, *, a: str, b: str) -> None:
        pass
    x = _IgnoreUndefinedParameters.create_init(func)(1, a="1", b="2", c="3")

# Generated at 2022-06-23 17:01:36.888211
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        pass

    ret = _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                     kvs={})
    assert ret == {}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                   kvs={"key": "value"})



# Generated at 2022-06-23 17:01:49.766540
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        i: str
        j: str = "test"
        k: Optional[CatchAllVar] = dataclasses.field(default=None)

    # default values
    kwargs = dict(i="test")
    known_given_parameters, unknown_given_parameters = \
        _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kwargs)
    assert known_given_parameters == dict(i="test", j="test")
    assert unknown_given_parameters == dict()

# Generated at 2022-06-23 17:02:02.090626
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        undefined: Undefined = Undefined.INCLUDE

        def __init__(self, **kwargs):
            pass

        def __eq__(self, other):
            if isinstance(other, self.__class__):
                return self.__dict__ == other.__dict__
            else:
                return False

    field = Field(name="undefined", default=Undefined.INCLUDE,
                  default_factory=None, type=Undefined, init=True, repr=True,
                  hash=True, compare=True,
                  metadata={'marshmallow_field': 'undefined'})
    obj = TestClass(undefined=Undefined.INCLUDE,
                    _CatchAll={"a_key": "a_value"})
   

# Generated at 2022-06-23 17:02:11.018348
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass


    @dataclass
    class TestClass:
        a: int
        b: int
        c: int = 10


    # Test _RaiseUndefinedParameters
    raise_init = _UndefinedParameterAction.create_init(TestClass)
    raise_instance = TestClass(1, 2)
    # Test with keyword argument with default value
    assert raise_instance.c == 10
    # Test with keyword argument without default value
    assert raise_instance.a == 1
    # Test with positional argument
    assert raise_instance.b == 2
    try:
        # Test with keyword argument that is undefined
        TestClass(1, 2, e=5)
        assert False, "Exception should have been raised"
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 17:02:13.283114
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(
        object) == {}



# Generated at 2022-06-23 17:02:25.168396
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Foo:
        a: int
        b: int = 3
        c: str = "abc"
        d: int = 4
        e: int = 4
        f: int = 5
        catchall: Optional[CatchAllVar] = None

    # Check that the custom constructor is used
    assert Foo.__init__ != object.__init__
    assert Foo(1, 2).a == 1
    assert Foo(1, 2).b == 2

    # Check that the catch-all field works
    assert Foo(a=1, _UNKNOWN1=2)._unknown == {
               "_UNKNOWN1": 2}  # noqa: E221

    # Check that the catch-all field works even if an additional
    # defined field is received

# Generated at 2022-06-23 17:02:26.256004
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    _ = _IgnoreUndefinedParameters()

# Generated at 2022-06-23 17:02:35.874033
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class MyClass:

        def __init__(self, a: int, b: int, c: int, *, d: int, e: int):
            pass

        def __init__(self, *args, **kwargs):
            pass

    class MySubClass(MyClass):
        pass


# Generated at 2022-06-23 17:02:46.776298
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Tests the function handle_from_dict of class
    _CatchAllUndefinedParameters.
    """
    import pytest
    import datetime
    import dataclasses
    import dataclasses_json

    # noinspection PyProtectedMember
    def _build_catch_all_field(cls):
        field = dataclasses.field(default_factory=dict)
        setattr(cls, dataclasses_json.config._UNDEFINED_PARAMETER_FIELD_NAME,
                field)

    @dataclasses.dataclass(unsafe_hash=True)
    class CatchAllObject:
        catch_all: Optional[CatchAllVar]


# Generated at 2022-06-23 17:02:52.421050
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class MyClass:
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b

    init = _IgnoreUndefinedParameters.create_init(MyClass)
    init(MyClass(a="a", b="b"), c="c")

# Generated at 2022-06-23 17:02:55.914088
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import marshmallow


    @dataclasses.dataclass
    class TestClass(_UndefinedParameterAction):
        pass

    assert TestClass.create_init(TestClass)



# Generated at 2022-06-23 17:03:09.043352
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class DummyClass:
        i: int
        d: Dict[str, Any] = dataclasses.field(default_factory=dict)

        def __init__(self, i, *, d: Optional[Dict[str, Any]] = None):
            self.i = i
            self.d = d
            assert d is not None
            assert self.d is not None

    new_init = _CatchAllUndefinedParameters.create_init(obj=DummyClass)
    dummy_instance = new_init(DummyClass, 3, a=1, b=2)
    assert dummy_instance.i == 3
    assert dummy_instance.d == {"a": 1, "b": 2}

# Generated at 2022-06-23 17:03:10.597805
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError):
        raise UndefinedParameterError("Some message")

# Generated at 2022-06-23 17:03:19.165772
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str

        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    init_signature = inspect.signature(TestClass.__init__)

    test_obj = TestClass(1, "3")
    _IgnoreUndefinedParameters.create_init(test_obj)(test_obj, 1, "3")
    assert test_obj.a == 1
    assert test_obj.b == "3"

    test_obj = TestClass(1, "3")
    _IgnoreUndefinedParameters.create_init(test_obj)(test_obj, 1, "3", c=4)
    assert test_obj.a == 1
    assert test_obj.b

# Generated at 2022-06-23 17:03:30.753048
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses
    from dataclasses_json.utils import CatchAllVar

    from dataclasses import fields, Field
    from enum import Enum

    from dataclasses_json import config
    from dataclasses_json.undefined import _UndefinedParameterAction, \
        _CatchAllUndefinedParameters
    from dataclasses_json.utils import CatchAllVar

    config.undefined = Undefined.INCLUDE

    @dataclasses.dataclass
    class _UndefinedParameterClass:
        provided_defined: str = "test"
        provided_undefined: int = 1
        provided_catch_all: CatchAllVar = CatchAllVar({"a": str, "b": int})


# Generated at 2022-06-23 17:03:40.169617
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass():
        def __init__(self, a, b=1):
            pass

# Generated at 2022-06-23 17:03:51.528651
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    def _test_handle_from_dict(init_kwargs_list: List[Dict[str, Any]],
                               cls,
                               expected_return: List[Dict[str, Any]]):
        for init_kwargs, expected in zip(init_kwargs_list, expected_return):
            actual = _CatchAllUndefinedParameters.handle_from_dict(cls=cls,
                                                                   kvs=init_kwargs)
            assert actual == expected

    class TestClass:
        def __init__(self, a: int,
                     b: str = "foo",
                     c: Optional[CatchAllVar] = CatchAllVar()):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-23 17:04:03.530339
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    import dataclasses_json
    import datetime
    import dataclasses_json.config

    create_config = dataclasses_json.config.Configuration
    encode = dataclasses_json.encode_class
    decoded_class = dataclasses_json.config.Decoded
    # noinspection PyUnresolvedReferences
    decode = dataclasses_json.decode_class

    @dataclasses.dataclass(frozen=True)
    class ClassA(decoded_class):
        a: int
        b: int
        # noinspection PyTypeHints
        c: datetime.datetime


# Generated at 2022-06-23 17:04:11.057156
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class DataClassTest:
        a: Any
        b: Optional[CatchAllVar] = UndefinedParameterAction \
            .CatchAll._SentinelNoDefault

        def __init__(self, a: Any, b: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b

    obj = DataClassTest(a=1)
    obj_with_catch_all = DataClassTest(a=2, b={})
    obj_with_filled_catch_all = DataClassTest(a=3, b={"a": 1})

    assert isinstance(obj, DataClassTest)
    assert isinstance(obj_with_catch_all, DataClassTest)
    assert isinstance(obj_with_filled_catch_all, DataClassTest)



# Generated at 2022-06-23 17:04:22.171135
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyPep8Naming
    class A(object):

        foo: str
        bar: str
        baz: str = "baz"

        def __init__(self, foo: str, bar: str, baz: str = "baz"):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    init = _UndefinedParameterAction.create_init(A)

    def test_correct_parameters(obj):
        expected_output = A("foo", "bar", "baz")
        assert obj.foo == expected_output.foo
        assert obj.bar == expected_output.bar
        assert obj.baz == expected_output.baz

    test_correct_parameters(init("foo", "bar", "baz"))
    test_correct_param

# Generated at 2022-06-23 17:04:33.034587
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class A:
        def __init__(self, a: int, *args, b: str, c: str, **kwargs):
            ...


    class B:
        def __init__(self, a: int, *args, b: str, c: str = "c", **kwargs):
            ...


    class C:
        def __init__(self, a: int, *args, b: str, c: str = "c",
                     catch_all: Optional[CatchAllVar] = None, **kwargs):
            ...



# Generated at 2022-06-23 17:04:40.974065
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestUnknownParameters:
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b

    test_dicts = [
        {"a": "A"},
        {"a": "A", "b": "B"},
        {"a": "A", "b": "B", "c": "C"},
    ]
    expected_results = [
        ["A", "b"],
        ["A", "B"],
        ["A", "B"],
    ]

    for i, test_dict in enumerate(test_dicts):
        result = _IgnoreUndefinedParameters.handle_from_dict(TestUnknownParameters,
                                                             test_dict)
        assert result == {"a": expected_results[i][0], "b": expected_results[i][1]}



# Generated at 2022-06-23 17:04:51.668364
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestKls(object):
        a: str
        b: str
        c: Optional[CatchAll] = dataclasses.field(default=None)

    # Everything works as expect when catch-all field is not filled
    result1 = _CatchAllUndefinedParameters.handle_from_dict(TestKls,
                                                            {"a": "testa",
                                                             "b": "testb"})
    assert result1 == {"a": "testa", "b": "testb", "c": {}}

    # Everything works as expect when catch-all field is filled with default

# Generated at 2022-06-23 17:04:54.111443
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert not hasattr(_UndefinedParameterAction, '__init__')

# Generated at 2022-06-23 17:04:56.770586
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction()
        raise Exception("This should not have happened")
    except TypeError:
        pass

# Generated at 2022-06-23 17:05:02.738699
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int

    test_object = TestClass(1, 2, c=3)
    assert test_object.a == 1
    assert test_object.b == 2

    # noinspection PyTypeChecker
    with pytest.raises(UndefinedParameterError):
        TestClass(1, 2, 3, d=4)



# Generated at 2022-06-23 17:05:03.332695
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    pass

# Generated at 2022-06-23 17:05:14.056496
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, fields

    @dataclass
    class TestClass:
        baz: Optional[CatchAllVar] = None

    @dataclass
    class TestClass2:
        baz: Optional[CatchAllVar] = dict()

    @dataclass
    class TestClass3:
        baz: Optional[CatchAllVar] = field(default_factory=dict)

    @dataclass
    class TestClass4:
        baz: Optional[CatchAllVar] = field(default=dict())


# Generated at 2022-06-23 17:05:25.841576
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-23 17:05:36.526523
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    def _testcase(kvs: Dict, expected_result: Dict):
        actual_result = _UndefinedParameterAction.handle_from_dict(
            TestClass, kvs)
        assert actual_result == expected_result

    _testcase(kvs={}, expected_result={})
    _testcase(kvs={"a": 1}, expected_result={"a": 1})
    _testcase(kvs={"a": 1, "b": 2, "c": 3},
              expected_result={"a": 1, "b": 2, "c": 3})