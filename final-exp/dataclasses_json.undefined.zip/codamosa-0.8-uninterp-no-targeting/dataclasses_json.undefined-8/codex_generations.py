

# Generated at 2022-06-21 11:34:29.404199
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        a: int = 0
        b: int = 0

    assert _IgnoreUndefinedParameters.handle_from_dict(TestClass, {}) == {}
    assert _IgnoreUndefinedParameters.handle_from_dict(TestClass, {"a": 1}) == {"a": 1}
    assert _IgnoreUndefinedParameters.handle_from_dict(TestClass, {"c": 1}) == {}

# Generated at 2022-06-21 11:34:39.193183
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass
    class Test:
        foo: int = 0

    assert _UndefinedParameterAction.handle_dump(Test()) == {}

    @dataclasses.dataclass
    class Test2(Undefined):
        bar: int = 0
        baz: dataclasses_json.CatchAll = dataclasses_json.CatchAll(
            default_factory=dict)

    reference = Test2()
    copy = Test2(bar=12)
    assert reference.__dict__ != copy.__dict__
    assert reference.bar == copy.bar == 12
    assert reference.baz == copy.baz == {}
    assert _UndefinedParameterAction.handle_dump(reference) == {}
    assert _UndefinedParameterAction.handle_dump(copy) == {}


# Generated at 2022-06-21 11:34:49.418306
# Unit test for constructor of class _UndefinedParameterAction

# Generated at 2022-06-21 11:34:53.203898
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    undefined_parameter_error = UndefinedParameterError("this is a test")
    field, message = undefined_parameter_error.args[0]
    assert field == ''
    assert message == "this is a test"

# Generated at 2022-06-21 11:35:01.127431
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: str
        b: int
        c: Undefined = Undefined.RAISE

    class B(A):
        pass

    @dataclasses.dataclass
    class C:
        a: str
        b: int
        c: Undefined = Undefined.EXCLUDE

    @dataclasses.dataclass
    class D:
        a: str
        b: int
        c: Undefined = Undefined.INCLUDE
        d: Optional[CatchAllVar] = None

    @dataclasses.dataclass
    class E:
        a: str
        b: int
        c: Undefined = Undefined.INCLUDE
        d: Optional[CatchAllVar] = None


# Generated at 2022-06-21 11:35:11.593191
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class MyClass:
        value: str
        other: int
        catch_all: Optional[CatchAllVar] = None

        def __init__(self, value: str, other: int, catch_all: Optional[
            CatchAllVar] = None):
            self.value = value
            self.other = other
            self.catch_all = catch_all

    # If a CatchAll field is defined and the class is initialized without
    # an undefined parameter, the CatchAll field should hold an empty
    # dictionary.
    instance_without_undefined = MyClass("a", 1)
    assert isinstance(instance_without_undefined.catch_all, dict)
    assert instance_without_undefined.catch_all == {}

    # If a CatchAll field is defined and the class is initialized with

# Generated at 2022-06-21 11:35:23.062341
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class Clazz:
        a: int
        b: str
        d: CatchAll

    test_cases = [
        {"a": 0, "b": "0"},
        {"b": "0", "a": 0},
        {"a": 0, "b": "0", "c": "c"},
        {"a": 0, "b": "0", "c": "c", "d": {"c": 0}}
    ]
    for case in test_cases:
        expected_known_parameters = {k: v for k, v in case.items() if
                                     k in ['a', 'b']}

# Generated at 2022-06-21 11:35:31.594096
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init_signature = inspect.signature(_CatchAllUndefinedParameters.create_init(
        TestClass))

    assert "arg_a" in init_signature.parameters
    assert "arg_b" in init_signature.parameters
    assert "arg_c" not in init_signature.parameters
    assert "arg_d" in init_signature.parameters
    assert "arg_e" in init_signature.parameters
    assert "_UNKNOWN0" in init_signature.parameters
    assert "_UNKNOWN1" in init_signature.parameters

    test_init = _CatchAllUndefinedParameters.create_init(TestClass)


# Generated at 2022-06-21 11:35:42.890246
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import List

    from dataclasses import dataclass

    from dataclasses_json import Undefined
    from dataclasses_json.utils import CatchAllVar


    @dataclass
    class TestClass:
        name: str
        age: int
        hobbies: List[str] = dataclasses.field(default_factory=list)
        undefined: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"marshmallow_field": CatchAllVar})


    # test cases:
    # * no undefined parameters given
    # * undefined parameter given
    # * catch-all field with default not given
    # * catch-all field given with default
    # * default factory used
    # * duplicated field names with catch-all field


# Generated at 2022-06-21 11:35:47.987870
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass, field
    from typing import Optional

    @dataclass
    class _TestClass:
        all_values: Dict[str, Optional[str]] = field(metadata=dict(
            dataclasses_json={
                "_undefined": Undefined.INCLUDE
            }))

# Generated at 2022-06-21 11:36:07.265982
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: str, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

    initializer = _RaiseUndefinedParameters.handle_from_dict(Foo,
                                                             {"a": 1, "b": "2"})
    obj = Foo(**initializer)
    assert obj.a == 1
    assert obj.b == "2"
    assert obj.kwargs == {}



# Generated at 2022-06-21 11:36:18.068879
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: str, c: int = 3):
            self.a = a
            self.b = b
            self.c = c

    tc = TestClass(a=1, b="a")
    assert tc.a == 1
    assert tc.b == "a"
    assert tc.c == 3

    init_function_wrapper = _UndefinedParameterAction.create_init(TestClass)
    assert init_function_wrapper == _UndefinedParameterAction.create_init(
        obj=TestClass)  # should return the same function

    tc2 = TestClass(a=2, b="b")
    assert tc2.a == 2
    assert tc2.b == "b"
    assert tc2.c == 3


# Generated at 2022-06-21 11:36:24.596613
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        defined_param: str

    kvs = {"another_param": "x", "defined_param": "y"}

    arg_dict = _RaiseUndefinedParameters.handle_from_dict(Test, kvs)
    assert arg_dict == {"defined_param": "y"}



# Generated at 2022-06-21 11:36:29.746228
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    obj = TestClass(**{'a': 1, 'b': 2, 'c': 3})
    out = _UndefinedParameterAction.handle_dump(obj)
    expected = {'a': 1, 'b': 2, 'c': 3}
    assert out == expected

# Generated at 2022-06-21 11:36:41.541327
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    """
    Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
    """
    @dataclasses.dataclass()
    class DummyClass:
        a: int = 1
        b: str = "default"
        c: int = 2

    assert _IgnoreUndefinedParameters.handle_from_dict(cls=DummyClass,
                                                       kvs={}) == dict(
        a=1, b="default", c=2)
    assert _IgnoreUndefinedParameters.handle_from_dict(cls=DummyClass,
                                                       kvs=dict(a=2)) == dict(
        a=2, b="default", c=2)

# Generated at 2022-06-21 11:36:55.537984
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class _TestClass:
        def __init__(self, a: int, b: str, c: float = 0.0, d: int = 0):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

        def __eq__(self, other):
            return type(self) == type(other) and \
                   self.a == other.a and \
                   self.b == other.b and \
                   self.c == other.c and \
                   self.d == other.d

    correct_input = {"a": 1, "b": "2", "c": 3.0, "d": 4}
    obj1 = _TestClass(**correct_input)
    obj2 = _TestClass(**correct_input, x=5)
    obj3 = _

# Generated at 2022-06-21 11:36:59.551484
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    obj = Any()
    d = {1: 2, 3: 4}

    def __init__(self, a):
        pass

    obj.__init__ = __init__
    result = _IgnoreUndefinedParameters.handle_from_dict(obj, d)
    assert result == {}



# Generated at 2022-06-21 11:37:08.072323
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses_json.undefined import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class Example:
        catchall1: CatchAllVar = CatchAllVar(str)
        catchall2: CatchAllVar

    def tinit(self, catchall1: Optional[str] = None, catchall2: Optional[str] = None):
        self.catchall1 = catchall1
        self.catchall2 = catchall2

    Example.__init__ = tinit

    _CatchAllUndefinedParameters.create_init(Example)

# Generated at 2022-06-21 11:37:15.375341
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses_json
    from typing import List, Optional

    @dataclasses.dataclass(
        init=False,
        repr=False,
        eq=False,
        order=False,
        unsafe_hash=False,
        frozen=False)
    class Animal:
        age: int
        name: str
        origin: str = "Africa"

    @dataclasses.dataclass
    class Zoo:
        name: str
        animals: List[Animal]
        location: str
        catch_all: Optional[CatchAllVar]

    zoo_just_parameters = Zoo("Zurich", [Animal(3, "Alice")], "Switzerland")
    zoo_just_parameters_reconstructed = Zoo(**zoo_just_parameters.to_dict())
    assert zoo_just_param

# Generated at 2022-06-21 11:37:20.854271
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Positional:
        def __init__(self, a: int, b: str):
            pass

    class YetAnotherPositional:
        def __init__(self, a: str):
            pass

    class SomeClass1:
        def __init__(self, a: int, b: str, c: float, d: float = 0.5):
            pass

    class SomeClass2:
        def __init__(self, a: int, b: str, c: float, d: float = 0.5, **kwargs):
            pass

    class SomeClass3:
        def __init__(self, a: int, b: str, c: float, d: float = 0.5,
                     catch_all: Optional[CatchAll] = None):
            pass


# Generated at 2022-06-21 11:37:48.685153
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass(frozen=True)
    class _TestClass:
        catch_all: Optional[CatchAllVar] = None

    assert \
        _CatchAllUndefinedParameters.handle_from_dict(_TestClass,
                                                      {"catch_all": {}}) == {
            "catch_all": {}}

# Generated at 2022-06-21 11:37:56.282735
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    undefined_parameter_action = _CatchAllUndefinedParameters()

    class Test:
        def __init__(self, a: int, b: str, c: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c

    actual = undefined_parameter_action.create_init(Test)
    expected = Test.__init__
    assert isinstance(actual, type(expected))
    assert inspect.signature(actual) == inspect.signature(expected)

# Generated at 2022-06-21 11:37:58.033603
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError("Test message")
    assert e.messages == {"": ["Test message"]}

# Generated at 2022-06-21 11:38:09.597312
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, defined_parameter: str, undefined_parameter: str):
            self.defined_parameter = defined_parameter
            self.undefined_parameter = undefined_parameter

    test_class = TestClass("defined_parameter", "undefined_parameter")
    defined_parameters, undefined_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass,
            kvs={"defined_parameter": test_class.defined_parameter,
                 "undefined_parameter": test_class.undefined_parameter})

    assert defined_parameters["defined_parameter"] == \
           test_class.defined_parameter
    assert defined_parameters["undefined_parameter"] is None

# Generated at 2022-06-21 11:38:16.981844
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class ClassWithCatchAll(object):
        def __init__(self, catch_all: CatchAll = None):
            for k, v in catch_all.items():
                setattr(self, k, v)

    _IgnoreUndefinedParameters.handle_from_dict(
        ClassWithCatchAll, {"a": 3, "b": {"d": 4}}) == {"a": 3, "b": {"d": 4}}

    # Check that unknown fields are excluded when a CatchAll field is present
    assert _CatchAllUndefinedParameters.handle_from_dict(
        ClassWithCatchAll, {"a": 3, "b": {"d": 4}, "catch_all": 5}) == {
           "a": 3, "b": {"d": 4}, "catch_all": {"b": {"d": 4}, "a": 3}}

# Generated at 2022-06-21 11:38:25.167892
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, unknown: int, **kwargs: int) -> None:
            self.unknown = unknown
            self.kwargs = kwargs

    assert TestClass.__init__(TestClass(unknown=1, x=2, y=3), 1, x=2, y=3)

    wrapped_init = _UndefinedParameterAction.create_init(TestClass)
    wrapped_object = TestClass(1)
    assert wrapped_init(wrapped_object, unknown=1, x=2, y=3)
    assert wrapped_object.unknown == 1
    assert wrapped_object.kwargs == {'x': 2, 'y': 3}

    # Arguments ignored
    assert wrapped_init(wrapped_object, 1, 3, 4)
    assert wrapped_object.unknown == 1


# Generated at 2022-06-21 11:38:26.606582
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-21 11:38:33.128147
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from typing import List, Optional
    from abc import ABC
    from dataclasses import dataclass

    @dataclass
    class Example(ABC):
        a: int
        b: List
        c: Optional[str]

    class _Dummy_RaiseUndefinedParameters(_RaiseUndefinedParameters):
        pass

    parameters = {"a": 1, "b": ["one"], "c": "one", "foo": "bar"}
    kwargs = _Dummy_RaiseUndefinedParameters.handle_from_dict(cls=Example,
                                                              kvs=parameters)
    assert kwargs == {"a": 1, "b": ["one"], "c": "one"}



# Generated at 2022-06-21 11:38:34.656741
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(5) == {}



# Generated at 2022-06-21 11:38:36.422828
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    a = UndefinedParameterError("Some error")
    assert isinstance(a, UndefinedParameterError)

# Generated at 2022-06-21 11:39:30.821499
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from typing import Type

    class A: pass
    cls: Type[A] = A
    kvs = {"x": "y"}

    parameters = _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
    assert parameters == {}



# Generated at 2022-06-21 11:39:31.716677
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-21 11:39:44.041552
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, some_param: int,
                     catch_all: Optional[CatchAllVar]=None) -> None:
            self.some_param = some_param
            self.catch_all = catch_all

    init = _UndefinedParameterAction.create_init(TestClass)

    obj = TestClass(6, {'a': 42})
    init(obj, 1, 2, 3, a=4, b=5, c=6)
    kvs = {'some_param': 7, 'catch_all': {'a': '42', 'b': 'lemming'}}
    expected = {'some_param': 7, 'a': '42', 'b': 'lemming'}
    assert _UndefinedParameterAction.handle_to_dict(obj, kvs) == expected
   

# Generated at 2022-06-21 11:39:54.571722
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass(metaclass=abc.ABCMeta):
        pass
    class TestClassDefinition:
        def __init__(self, **kwargs):
            pass

    class TestClassDefinedParameter(TestClass, dataclasses.dataclass):
        param1: Any

    class TestClassUndefinedParameter(TestClass, dataclasses.dataclass):
        param1: Any
        param2: Any = None

    class TestClassCatchAllParameter(TestClass, dataclasses.dataclass):
        param1: Any
        catch_all: Optional[CatchAllVar] = None

    class TestClassCatchAllParameterDefined(TestClass, dataclasses.dataclass):
        param1: Any
        param2: Any
        catch_all: Optional[CatchAllVar] = None


# Generated at 2022-06-21 11:39:55.918721
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("")

# Generated at 2022-06-21 11:40:06.130090
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    # pylint: disable=no-self-use
    class MyClass:
        # pylint: disable=no-self-use
        def __init__(self, a: int, b: str,
                     c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    my_class = MyClass(a=1, b="b",
                       c={
                           "d": 2,
                           "e": "f"
                       })
    result = _CatchAllUndefinedParameters.handle_dump(my_class)
    assert result == {
        "d": 2,
        "e": "f"
    }

# Generated at 2022-06-21 11:40:07.635811
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(1) == {}



# Generated at 2022-06-21 11:40:16.773172
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Foo:
        x: int
        y: int
        z: int = 1

    setattr(Foo, "__dataclasses_json__", dataclasses.asdict({
        "init": True,
        "unknown": Undefined.INCLUDE,
    }))

    # test case 1: CatchAll and Undefined ignored, too many args
    with pytest.raises(TypeError):
        Foo(0, 0, 0, 0)

    # test case 2: CatchAll defined, Undefined ignored
    class CatchAllFoo(_CatchAllUndefinedParameters.create_init(Foo)):
        pass


# Generated at 2022-06-21 11:40:29.441333
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:
        def __init__(self, first_name, last_name, *, catch_all=None):
            self.first_name = first_name
            self.last_name = last_name
            self.catch_all = catch_all

        @classmethod
        def _get_catch_all_field(cls):
            return Field(name="catch_all", default=None,
                         type=Optional[CatchAll], init=True,
                         default_factory=dict)

    new_init = _CatchAllUndefinedParameters.create_init(Foo)
    f = Foo(first_name="Peter", last_name="Tester",
            catch_all={"telephone_number": 987654321},
            salutation="Mr."
            )  # does not overwrite catch_all dict
   

# Generated at 2022-06-21 11:40:32.624454
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction.handle_from_dict(1, 2) is None
    assert _UndefinedParameterAction.handle_to_dict(1, 2) == 2
    assert _UndefinedParameterAction.handle_dump(1) is None
    assert _UndefinedParameterAction.create_init(1) is None

# Generated at 2022-06-21 11:42:56.241928
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    import pytest

    class TestClass:
        def __init__(self, a, b, c, d):
            pass

    class FillInParameterAction(abc.ABC):
        """
        This class is used for testing the abc UndefinedParameterAction.
        It checks whether it received the correct arguments for the
        handle_from_dict class method and calls the method with the same
        arguments.
        """

        def __init__(self, expected_class, expected_kvs):
            self.expected_class = expected_class
            self.expected_kvs = expected_kvs

        def handle_from_dict(self, cls, kvs):
            assert cls == self.expected_class
            assert kvs == self.expected_kvs
            return _UndefinedParameterAction.handle_from_dict(cls, kvs)

# Generated at 2022-06-21 11:43:05.380633
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import marshmallow_dataclass
    from dataclasses import dataclass
    import dataclasses_json

    @dataclass
    class Test(metaclass=dataclasses_json.DataClassJSON):
        catch_all: Optional[CatchAllVar] = None
        a: int
        b: int = 1

        def __init__(self, a, b, catch_all=None):
            pass

    schema = marshmallow_dataclass.class_schema(Test)()
    dump = schema.dump({'a': 1})
    assert dump == {'a': 1, 'b': 1, 'catch_all': {}}

    load = schema.load({'a': 1, 'a_undefined': 4, 'b_undefined': 5})

# Generated at 2022-06-21 11:43:08.963050
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass():
        def __init__(self):
            pass

    kvs = {"a": 1, "b": 2}
    result = _UndefinedParameterAction.handle_to_dict(obj=TestClass, kvs=kvs)
    assert result == kvs



# Generated at 2022-06-21 11:43:09.440910
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-21 11:43:17.603680
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, param_a=None, param_b=None, **kwargs):
            pass

        def to_dict(self):
            return {}

    # Check that no error gets raised when only one argument is supplied
    try:
        _IgnoreUndefinedParameters.create_init(TestClass)(None, param_b=None)
    except TypeError:
        assert False

    # Check that no error gets raised when two arguments are supplied
    try:
        _IgnoreUndefinedParameters.create_init(TestClass)(None, None)
    except TypeError:
        assert False

    # Check that no error gets raised when three arguments are supplied

# Generated at 2022-06-21 11:43:24.496184
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, defined_parameter, *, catch_all: CatchAll = None):
            pass

    test_class = TestClass
    test_kwargs = {
        "defined_parameter": True,
        "undefined_parameter_1": 1,
        "undefined_parameter_2": 2,
        "catch_all": 3
    }
    result = _IgnoreUndefinedParameters.create_init(test_class)
    result(test_class(), **test_kwargs)

# Generated at 2022-06-21 11:43:34.389320
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b


    instance = Foo(a=1, b=2)
    # We don't actually use the instantiated class, we just want to
    # retrieve its fields, which is why we can pass in Foo here.
    params, unknown_params = _RaiseUndefinedParameters._separate_defined_undefined_kvs(
        Foo,
        {"a": 1, "b": 2, "c": 3, "d": 4})
    assert len(params) == 2
    assert params["a"] == 1
    assert params["b"] == 2
    assert len(unknown_params) == 2
    assert unknown_params["c"] == 3
    assert unknown_params["d"] == 4

    params

# Generated at 2022-06-21 11:43:42.509813
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        foo: int
        bar: str

    kvs = {"foo": 1, "bar": "baz"}
    expected = {"foo": 1, "bar": "baz"}
    assert _RaiseUndefinedParameters \
        .handle_from_dict(TestClass, kvs) == expected

    with pytest.raises(UndefinedParameterError):
        kvs = {"foo": 1, "bar": "baz", "baz": "foo"}
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-21 11:43:46.025819
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("an exception occurred")
    except UndefinedParameterError as e:
        assert e.detail == "an exception occurred"

# Generated at 2022-06-21 11:43:54.252061
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from typing import Optional, Dict

    from dataclasses import dataclass

    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class TestClass:
        a: str
        b: int
        c: Optional[str] = None
        d: Optional[CatchAllVar] = None

    config.ENFORCE_INTEGER_TYPES = True
    test_dict = {
        "a": "test",
        "b": 3,
        "d": {"e": 5, "f": "q", "g": None}}

    kvs = _CatchAllUndefinedParameters.handle_to_dict(TestClass,
                                                      test_dict.copy())
    assert kvs == test_dict
