

# Generated at 2022-06-21 11:34:34.347113
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class UnknownParameters:
        unknown = CatchAll()

    class DummyClass:
        def __init__(self, foo: str, bar: int, **kwargs: UnknownParameters):
            self.foo = foo
            self.bar = bar
            self.unknown = kwargs

    dummy = DummyClass("hello", 42, spam="eggs", spam2=None)

    kvs_original = {
        "foo": dummy.foo,
        "bar": dummy.bar,
        "unknown": dummy.unknown
    }
    kvs_handled = {
        "foo": dummy.foo,
        "bar": dummy.bar,
        "spam": dummy.unknown["spam"],
        "spam2": dummy.unknown["spam2"]
    }

    kvs_from_handle_to_dict = \
        _

# Generated at 2022-06-21 11:34:35.089535
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    pass


# Generated at 2022-06-21 11:34:45.960370
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _CatchAllClass:
        def __init__(self, *, catch_all: CatchAll = None,
                     no_catch_all: str = "v"):
            self.catch_all = catch_all if catch_all is not None else {}
            self.no_catch_all = no_catch_all

    obj = _CatchAllClass(catch_all={"k": "v"})
    kvs = dict(**obj.__dict__)

    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)

    assert "catch_all" not in kvs
    assert "no_catch_all" in kvs
    assert "k" in kvs
    assert kvs["k"] == "v"



# Generated at 2022-06-21 11:34:56.837691
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: str = "a"
        b: str = "b"
        all: CatchAll = dataclasses.field(default=None,
                                          metadata={
                                              "dataclasses_json": {
                                                  "include_by_default": False
                                              }
                                          })

    # Test 1: No undefined parameters given
    parameters = {"a": "a", "b": "b"}
    instance = Test(**parameters)
    new_parameters = _CatchAllUndefinedParameters.handle_to_dict(obj=Test,
                                                                 kvs=parameters)
    assert parameters == new_parameters

    # Test 2: Undefined parameters given

# Generated at 2022-06-21 11:35:03.838838
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        def __init__(self, my_field, **unknown):
            self.my_field = my_field

    # case: we have one undefined parameter
    a = A("known_field", unknown_field="dont_touch_me")
    assert _CatchAllUndefinedParameters.handle_to_dict(a, {
        "my_field": a.my_field,
        "unknown_field": a.unknown_field
    }) == {
        "my_field": a.my_field
    }

    # case: we have no undefined parameters
    b = A("known_field")

# Generated at 2022-06-21 11:35:09.978213
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclass
    class TestCatchAll:
        include_me: bool = False
        catch_all: CatchAll = None

    obj = TestCatchAll(include_me=True)
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj.catch_all["foobar"] = "barfoo"
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {
               "foobar": "barfoo"}



# Generated at 2022-06-21 11:35:21.052307
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, defined_int: int, defined_str: str,
                     undefined_int: int=None,
                     undefined_str: str=None,
                     _UNDEFINED_PARAMETER_ACTION=Undefined.INCLUDE):
            pass

    defined_dict = {
        "defined_int": "1",
        "defined_str": "I am defined"
    }
    undefined_dict = {
        "undefined_int": "1",
        "undefined_str": "I am undefined"
    }

# Generated at 2022-06-21 11:35:30.232651
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import Dict, Optional

    from unittest import TestCase
    from unittest.mock import Mock, patch

    from dataclasses import dataclass, field
    from dataclasses_json import config

    class TestCase(TestCase):
        def test_normal_case(self):
            @dataclass
            class A:
                a: int
                b: int
                c: int

                catch_all: Optional[CatchAllVar] = field(
                    default_factory=dict,
                    metadata=config.metadata(
                        dataclasses_json=config.Config(
                            unknown=config.Unknown.INCLUDE)))

            a = {"a": 1, "b": 2}
            expected = {"a": 1, "b": 2}

            result = _CatchAllUndefinedParameters.handle_

# Generated at 2022-06-21 11:35:33.805734
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class _TestClass:
        def __init__(self, a, b=5, **kwargs):
            self.a = a
            self.b = b
            self.undefined = kwargs

    test_instance = _TestClass(4, b=8, f=2, d=3)
    assert _CatchAllUndefinedParameters.handle_dump(test_instance) == {
        "d": 3,
        "f": 2,
    }

# Generated at 2022-06-21 11:35:45.432527
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, *, c, d=1):
            pass

    # Test that normal init is not changed
    assert TestClass.__init__ == \
           _UndefinedParameterAction.create_init(TestClass)

    # Test that _IgnoreUndefinedParameters does not accept arguments
    # beyond the defined parameters
    ignore_init = _IgnoreUndefinedParameters.create_init(TestClass)
    try:
        ignore_init(TestClass, 1, 2, 3, 4)
    except TypeError as e:
        assert "Too many positional arguments" in str(e)

# Generated at 2022-06-21 11:36:08.082416
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses
    from dataclasses import dataclass
    from typing import Dict

    from dataclasses_json import config
    from dataclasses_json.utils import CatchAllVar, CatchAll

    @dataclass
    class TestClass:
        defined_parameter: int
        catch_all: Optional[CatchAllVar] = CatchAll()

    @dataclass
    class ErrorClass:
        catch_all: Optional[CatchAllVar] = CatchAll()
        default: str = "default"

    kvs = {"defined_parameter": 1, "undefined_parameter": 2, 'key': 'value'}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)

# Generated at 2022-06-21 11:36:16.837960
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class _TestClass:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    kvs = {"a": 10,
           "b": "Hello",
           "c": [1, 2, 3]}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=_TestClass,
        kvs=kvs
    )
    assert known == {"a": 10,
                     "b": "Hello"}
    assert unknown == {"c": [1, 2, 3]}



# Generated at 2022-06-21 11:36:28.734659
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def dummy_init(self, a: int, b: int, c: int = 4):
        self.a = a
        self.b = b
        self.c = c

    class DummyClass:
        def __init__(self, a: int, b: int, c: int = 4):
            self.a = a
            self.b = b
            self.c = c

        def dummy_method(self,):
            pass

    dummy_object = DummyClass(1, 2, 3)
    result = _IgnoreUndefinedParameters.create_init(dummy_object)
    assert result(dummy_object, 1, 2, 3, 4) == dummy_init(dummy_object, 1, 2)
    assert result(dummy_object, 1, 2, 3, 4, 5) == dummy_init

# Generated at 2022-06-21 11:36:40.900186
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Unit test for method handle_from_dict of class
    _CatchAllUndefinedParameters
    """
    # noinspection PyUnresolvedReferences
    def get_field_instance_exec(field: Field):
        return field.default_factory()

    @dataclasses.dataclass(unsafe_hash=True)
    class TestClass0:
        a: int = 1
        b: int = 2

    @dataclasses.dataclass(unsafe_hash=True)
    class TestClass1:
        a: int = 1
        b: int = 2
        c: CatchAll = 3

    @dataclasses.dataclass(unsafe_hash=True)
    class TestClass2:
        a: int = 1
        b: int
        c: CatchAll


# Generated at 2022-06-21 11:36:41.647917
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError('abc')

# Generated at 2022-06-21 11:36:54.844467
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class A:
        b: int

    @dataclass
    class B:
        b: int
        c: int

    @dataclass
    class C(A):
        c: int

    def test_case(cls: type, kvs: Dict, expected):
        actual = _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
        assert actual == expected

    test_case(A, {}, {})
    test_case(A, {'b': 1}, {'b': 1})
    test_case(A, {'b': 1, 'c': 2}, {'b': 1})


# Generated at 2022-06-21 11:36:57.399767
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = object()
    # Should do nothing
    kvs = _UndefinedParameterAction.handle_to_dict(obj, {1:2})
    assert kvs == {1:2}


# Generated at 2022-06-21 11:37:09.204702
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class CatchAllInCtor:
        x: int
        y: int
        z: Optional[CatchAll]

        def __init__(self, x: int, y: int, z: Optional[CatchAll] = None):
            self.x = x
            self.y = y
            self.z = z

    test = CatchAllInCtor(0, 0)
    assert test.x == 0 and test.y == 0 and test.z is None

    test = CatchAllInCtor(0, 0, z={"a": 1})
    assert test.x == 0 and test.y == 0 and test.z == {"a": 1}

    test = CatchAllInCtor(0, 0, {"a": 1})
    assert test.x == 0 and test.y == 0

# Generated at 2022-06-21 11:37:12.828230
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        def __init__(self, param_one =int, param_two =int):
            self.param_one = param_one
            self.param_two = param_two

    init = _RaiseUndefinedParameters.create_init(TestClass)
    assert init(TestClass,1,2)



# Generated at 2022-06-21 11:37:21.772844
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.config import from_dict, from_json
    from dataclasses_json.utils import CatchAll
    from dataclasses_json.undefined import Undefined

    @from_dict(undefined=Undefined.INCLUDE)
    @from_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass()
    class JsonClass:
        a: int
        b: int
        ca: Optional[CatchAll] = None

    jc = JsonClass(a=1, b=2, c=3)
    assert getattr(jc, "ca") == {'c': 3}
    assert getattr(jc, "a") == 1
    assert getattr(jc, "b") == 2
    dumped_obj = JsonClass.schema().dump

# Generated at 2022-06-21 11:37:56.720864
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    def dict_with_default_dict(a: CatchAll = CatchAll({})):
        pass

    obj = dict_with_default_dict()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj = dict_with_default_dict(a={'b': 1})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'b': 1}

    def dict_with_no_default_dict(a: CatchAll):
        pass

    obj = dict_with_no_default_dict(a={'b': 1})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'b': 1}

    obj = dict_with_no_default_dict()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

# Generated at 2022-06-21 11:38:08.008759
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import datetime

    @dataclasses.dataclass
    class A:
        a: str
        b: str
        ca: Optional[CatchAllVar] = dataclasses.field(default=None)

    @dataclasses.dataclass
    class B:
        a: str
        b: str
        ca: Optional[CatchAllVar] = dataclasses.field(default={})

    @dataclasses.dataclass
    class C:
        a: str
        b: str
        ca: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)


# Generated at 2022-06-21 11:38:16.256025
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class MyClass:
        def __init__(self, a: int, b: str) -> None:
            self.a = a
            self.b = b

    @dataclasses.dataclass
    class MyDataclass:
        a: int = 1
        b: str = "two"

    class _TestUndefinedParameterAction(_UndefinedParameterAction):
        """
        Tests the abstract class which handles undefined parameters
        """

        @staticmethod
        def handle_from_dict(cls, kvs: Dict) -> Dict[str, Any]:
            return {"a": 1}

    def test_abstract_class(klass: Any) -> None:

        test_action = _TestUndefinedParameterAction()
        assert test_action.create_init(klass=klass) is klass.__init__


# Generated at 2022-06-21 11:38:23.079503
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Example:
        known: str
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: dict())

    unknowns = [
        {"known": "value", "_UNKNOWN_1": "value"},
        {"known": "value", "_UNKNOWN_1": "value", "catch_all": {}},
        {"known": "value", "_UNKNOWN_1": "value", "catch_all": None}
    ]
    for unknown in unknowns:
        assert _CatchAllUndefinedParameters.handle_from_dict(Example, unknown) \
            == {"known": "value", "catch_all": {"_UNKNOWN_1": "value"}}


# Generated at 2022-06-21 11:38:31.715209
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class Data:
        a: str
        catch_all: CatchAll = dataclasses.field(default=None)

    def _test(func,
              unknown_parameters: Tuple[str, Any], known_parameters: Tuple[
                  str, Any], number_of_args: int = 1, **kwargs):
        args = ("x",) * number_of_args
        all_parameters_to_pass: Dict[str, Any]
        all_parameters_to_pass = dict(unknown_parameters)
        all_parameters_to_pass.update(known_parameters)
        all_parameters_to_pass.update(kwargs)

        threshold = number_of_args - len(known_parameters)

# Generated at 2022-06-21 11:38:34.889777
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as ex:
        assert str(ex) == "test"



# Generated at 2022-06-21 11:38:35.526223
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()

# Generated at 2022-06-21 11:38:38.454332
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyUnusedLocal
    @CatchAll
    @dataclasses.dataclass
    class MyClass:
        a: str
        b: int

    MyClass(a="test", b=3, c=2)

# Generated at 2022-06-21 11:38:41.758620
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters.handle_from_dict(TestClass,
                                               {"test_param": "test"})



# Generated at 2022-06-21 11:38:52.484514
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: str, b: int, c: str = "c",
                     catch_all: Optional[CatchAllVar] = None):
            pass

    action = _CatchAllUndefinedParameters
    init = action.create_init(TestClass)

    # Test keyword argument handling
    init(None, a="a", b=1, c="cc", d="d")
    init(None, a="a", b=1, d="dd")
    init(None, a="a", b=1, c="cc", d="dd")
    init(None, a="a", b=1, catch_all={"u": "undefined"})
    # Should not raise error: No catch_all field
    init(None, a="a", b=1, d="dd")


# Generated at 2022-06-21 11:39:46.517714
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    @dataclasses.dataclass
    class Foo:
        x: int
        y: str

    x, y = 1, "y"
    foo = Foo(x, y)

    init = _CatchAllUndefinedParameters.create_init(Foo)
    assert inspect.signature(init) == inspect.signature(Foo.__init__)

# Generated at 2022-06-21 11:39:57.339317
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    def _create_instance(field_kwargs: Dict,
                         init_kwargs: Dict,
                         undefined_action: Undefined) -> Optional[CatchAllVar]:
        @dataclasses.dataclass
        class CatchAllTest(object):
            catch_all: CatchAllVar = dataclasses.field(**field_kwargs)

            @classmethod
            def _undefined_parameter_action(cls):
                return undefined_action

            def __init__(self, **kwargs):
                kwargs = cls._undefined_parameter_action().handle_from_dict(
                    cls, kwargs)
                cls.__init__(self, **kwargs)


# Generated at 2022-06-21 11:40:07.078133
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

    parameter_action = _RaiseUndefinedParameters
    assert parameter_action.handle_from_dict(TestClass, {'a': 1, 'b': 2}) == {
        'a': 1, 'b': 2}
    assert parameter_action.handle_from_dict(TestClass, {'b': 2}) == {
        'a': None, 'b': 2}
    try:
        parameter_action.handle_from_dict(TestClass, {'b': 2, 'c': 3})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-21 11:40:16.473980
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: int = dataclasses.field(metadata={"marshmallow_field": "a"})
        b: int = dataclasses.field(metadata={"marshmallow_field": "b"})
        c: Optional[CatchAllVar] = dataclasses.field(
            default=dict(), metadata={"marshmallow_field": "c"})

    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(A,
                                                                   {"a": 1})
    assert known == {"a": 1, "c": {}}
    assert unknown == {}

    known, unknown = _CatchAllUndefinedParameters.handle_from_dict(A,
                                                                   {"a": 1,
                                                                    "b": 2})

# Generated at 2022-06-21 11:40:21.593539
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        first: int
        second: int

    test = Test(first=1, second=2, third=3)
    assert test.first == 1
    assert test.second == 2
    with pytest.raises(AttributeError):
        test.third

# Generated at 2022-06-21 11:40:32.320959
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import inspect
    import json

    import logging
    from dataclasses_json import config, dataclass_json, letter_case

    @dataclass_json
    @dataclasses.dataclass(frozen=True, order=True)
    class TestClass:
        param: str
        catch_all: dataclasses_json.CatchAllVar = \
            _CatchAllUndefinedParameters._SentinelNoDefault

        def __init__(self, param: str, catch_all: dataclasses_json.CatchAllVar
                     = None):
            self.param = param
            self.catch_all = catch_all

        def __eq__(self, other):
            if isinstance(other, TestClass):
                return self.param == other.param \
                       and self.catch_all

# Generated at 2022-06-21 11:40:34.167016
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        ...

# Generated at 2022-06-21 11:40:43.175373
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class _TestClass():
        b: str

    inst = _TestClass('b string')
    assert _CatchAllUndefinedParameters.handle_to_dict(inst, {}) == {}

    inst = _TestClass('b string')
    assert _CatchAllUndefinedParameters.handle_to_dict(inst, {'b': 'value'}) \
           == {'b': 'value'}

    @dataclasses.dataclass
    class _TestClass1():
        b: str
        __undefined__: CatchAll

    inst = _TestClass1('b string')
    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_to_dict(inst, {})

    inst = _TestClass1('b string')
    assert _

# Generated at 2022-06-21 11:40:47.285184
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            cls=type("Test", (), {"Foo": str}),
            kvs={"Foo": "Bar", "Bar": 2})
    except UndefinedParameterError:
        pass
    else:
        raise RuntimeError("Expected UndefinedParameterError")



# Generated at 2022-06-21 11:40:49.137367
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("some message")
    assert error.messages == ['some message']
    assert error.field_names == []

# Generated at 2022-06-21 11:43:11.268747
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError as e:
        assert e.error is None

    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError as e:
        assert e.error == "test"

# Generated at 2022-06-21 11:43:15.649333
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    test_dict = {"a": 1, "b": 2}
    test_dict2 = {"a": 3, "c": 4}
    _RaiseUndefinedParameters.handle_from_dict(test_dict)
    try:
        _RaiseUndefinedParameters.handle_from_dict(test_dict2)
        raise AssertionError("No exception raised")
    except UndefinedParameterError:
        pass



# Generated at 2022-06-21 11:43:18.668798
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    _CatchAllUndefinedParameters._get_catch_all_field(
        cls=_CatchAllUndefinedParameters)


# Code taken from https://stackoverflow.com/questions/4015417/python-classmethod-and-staticmethod-for-beginners.
# 23. Mär 2020, https://stackoverflow.com/users/1698/abarnert

# Generated at 2022-06-21 11:43:28.884856
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

        def __init__(self, a: int, b: int, c: int,
                     **kwargs):
            self.a = a
            self.b = b
            self.c = c

    expected_parsing_return_value = {"a": 1, "b": 2, "c": 3}
    parsing_return_value = _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1, "b": 2,
                    "c": 3})
    assert expected_parsing_return_value == parsing_return_value



# Generated at 2022-06-21 11:43:36.846006
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class TestClass:
        name: str
        age: int
        catch_all: CatchAll

        def __init__(self, name: str, age: int, catch_all: CatchAll = None):
            self.name = name
            self.age = age
            self.catch_all = catch_all

    test_object = TestClass(name="Daniel", age=15, catch_all={
        "foo": "bar"
    })
    assert test_object.name == "Daniel"
    assert test_object.age == 15
    assert test_object.catch_all == {
        "foo": "bar"
    }

    test_object = TestClass(name="Daniel", age=15)
    assert test_object.name == "Daniel"
    assert test_object.age == 15
    assert test_object.catch_

# Generated at 2022-06-21 11:43:45.412281
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c):
            pass

    parameters = {"a": 1, "b": 2, "d": 3, "e": 4}

    received = _UndefinedParameterAction.handle_from_dict(
        cls=TestClass, kvs=parameters)
    assert received == {"a": 1, "b": 2}

    received = _CatchAllUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs=parameters)
    assert received == {"a": 1, "b": 2, "c": {}}

    parameters = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}

# Generated at 2022-06-21 11:43:54.028188
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():

    # Test for class _RaiseUndefinedParameters

    # Normal case: no undefined arguments; no raise
    _UndefinedParameterAction.handle_from_dict(
        cls=MyClass, kvs={"a": 1, "b": 2})

    # Normal case: undefined argument; raise
    with pytest.raises(UndefinedParameterError):
        _UndefinedParameterAction.handle_from_dict(
            cls=MyClass, kvs={"a": 1, "b": 2, "c": 3})

    # Test for class _IgnoreUndefinedParameters

    # Normal case: no undefined arguments; no raise
    assert _UndefinedParameterAction.handle_from_dict(
        cls=MyClass, kvs={"a": 1, "b": 2}) == {"a": 1, "b": 2}

    # Normal case:

# Generated at 2022-06-21 11:43:58.457128
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, foo: int):
            self.foo = foo

    test_obj = Test(111)
    print(test_obj.foo)

    x = _RaiseUndefinedParameters.handle_from_dict(
        cls=Test,
        kvs={
            "foo": 42
        }
    )
    print(x)


if __name__ == '__main__':
    test__RaiseUndefinedParameters_handle_from_dict()

# Generated at 2022-06-21 11:44:05.488610
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a=None, b=None, c=None, d=None,
                     # type: CatchAll
                     e=None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    # this should work fine
    init(TestClass(), a=1, b=2, c=3)

    # Catch-all field should accept too many parameters
    init(TestClass(), a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-21 11:44:14.366093
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(list, {"_": 1}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(list, {"_": 1, "0": 2}) == \
           {"0": 2}
    assert _RaiseUndefinedParameters.handle_to_dict({}, {"_": 1}) == {}
    assert _RaiseUndefinedParameters.handle_to_dict({}, {"_": 1, "0": 2}) == \
           {"0": 2}
    assert _RaiseUndefinedParameters.handle_dump({}) == {}
    assert _RaiseUndefinedParameters.create_init([]) is list.__init__

