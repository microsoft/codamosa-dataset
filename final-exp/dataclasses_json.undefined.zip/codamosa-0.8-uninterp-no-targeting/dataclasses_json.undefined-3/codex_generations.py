

# Generated at 2022-06-21 11:34:37.468265
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import inspect
    import pytest
    from typing import ClassVar
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: str
        b: str
        c: ClassVar[CatchAll] = None

        def __init__(self, **kwargs):
            pass

    def _mock_init(cls, **kwargs):
        pass

    init_signature = inspect.Signature()
    for parameter in fields(TestClass):
        # noinspection PyTypeChecker
        init_signature = init_signature.replace(parameters=[parameter.name])

    # Catch-all field given, but undefined fields given:

# Generated at 2022-06-21 11:34:43.905661
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import pytest

    class _TestClassA:
        """
        Unit test for method create_init of class _CatchAllUndefinedParameters
        """
        def __init__(self, x: int, y: int = -2, z: int = -3):
            self.x = x
            self.y = y
            self.z = z

        def __eq__(self, other):
            return self.x == other.x and self.y == other.y and self.z == \
                   other.z

    _new_init = _CatchAllUndefinedParameters.create_init(_TestClassA)
    assert _new_init(None, 1, 2, 3, 4) is None
    assert _TestClassA(1, 2, 3) == _TestClassA(1, 2, 3)
    assert _TestClass

# Generated at 2022-06-21 11:34:51.321847
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: int
        c: Optional[CatchAllVar] = None

    obj = MyClass(a=1, b=2, c={"d":4, "e":6})
    caught = _CatchAllUndefinedParameters.handle_dump(obj=obj)
    desired = {"d":4, "e":6}
    assert caught == desired


# Generated at 2022-06-21 11:34:55.118788
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class C:
        a: str
        b: str
        c: str

    parameters = {"a": "a", "b": "b", "c": "c", "d": "d"}
    known_parameters, _ = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        C, parameters)
    assert known_parameters == {"a": "a", "b": "b", "c": "c"}



# Generated at 2022-06-21 11:34:59.319112
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    undefined_parameters = {"a": "b"}
    expected_result = {"c": 1, "a": "b"}
    handler = _IgnoreUndefinedParameters
    assert handler.handle_to_dict(None, {"c": 1}) == {"c": 1}
    assert handler.handle_to_dict(None, {"c": 1, "a": "b"}) == expected_result



# Generated at 2022-06-21 11:35:03.987583
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: int
        c: Optional[CatchAllVar]

    def test__default_value_with_no_undefined_parameters():
        kvs_to_use = {"a": 1, "b": 2}
        expected_return_value = {"a": 1, "b": 2, "c": {}}
        return_value = _CatchAllUndefinedParameters.handle_from_dict(
            cls=TestClass, kvs=kvs_to_use)
        assert return_value == expected_return_value


# Generated at 2022-06-21 11:35:12.298539
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: str
        catch_all: Optional[CatchAllVar] = None
        c: str

    t_all_known_params = Test.catch_all.__class__.handle_from_dict(
        Test, {"a": 1, "b": "Hello", "c": "World"})
    assert t_all_known_params == {"a": 1, "b": "Hello",
                                  "catch_all": {}, "c": "World"}

    t_all_known_params = Test.catch_all.__class__.handle_from_dict(
        Test, {"a": 1, "b": "Hello", "catch_all": {1: 2}, "c": "World"})

# Generated at 2022-06-21 11:35:13.456278
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # should get an error if the arg 'message' is missing
    try:
        UndefinedParameterError()
    except TypeError:
        assert True

# Generated at 2022-06-21 11:35:24.728234
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestCls:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    obj = TestCls(a=1, b="a")
    kvs = {"a": 1, "b": "a"}

    result = _RaiseUndefinedParameters.handle_from_dict(TestCls, kvs=kvs)
    assert result == {k: v for k, v in kvs.items()}

    kvs = {"a": 1, "b": "a", "d": 3}
    try:
        _RaiseUndefinedParameters.handle_from_dict(TestCls, kvs=kvs)
    except UndefinedParameterError:
        pass
    else:
        assert False, "Expected to fail"



# Generated at 2022-06-21 11:35:32.443818
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from unittest.mock import Mock


    @dataclasses.dataclass(frozen=True)
    class ClassWithoutUndefinedParameters:
        foo: str



# Generated at 2022-06-21 11:35:56.933300
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # pylint: disable=missing-docstring,no-member

    class A:
        def __init__(self, catch_all: Optional[CatchAll]):
            self.catch_all = catch_all

    class B:
        def __init__(self, catch_all: Optional[CatchAll] = None):
            self.catch_all = catch_all

    class C:
        def __init__(self, catch_all=None):
            self.catch_all = catch_all

    class D:
        def __init__(self, catch_all: Optional[CatchAll] = {}):
            self.catch_all = catch_all

    class E:
        def __init__(self, catch_all=None, another: int = 1):
            self.catch_all = catch_all
            self

# Generated at 2022-06-21 11:36:07.957789
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # This test might not be needed in future, since the constructor
    # is defined by the dataclass-decorator automatically.
    class MyClass_1:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y

    class MyClass_2:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

    class MyClass_3:
        def __init__(
                self,
                x: int,
                y: int,
                z: int = 1,
                a: int = 2
        ):
            self.x = x
            self.y = y
            self.z = z
            self.a = a

    #

# Generated at 2022-06-21 11:36:18.668281
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Animal:
        def __init__(self, name, type, habitat):
            self.name = name
            self.type = type
            self.habitat = habitat

    def get_animal_init():
        animal_init = Animal.__init__
        return animal_init

    animal_init_original = get_animal_init()

    @dataclasses.dataclass()
    class Dog:
        name: str
        type: str
        habitat: str

        DOG = type("DOG", (object,), {
            "__init__": get_animal_init()
        })

    dog = Dog(name="Tom", type="domestic dog", habitat="domestic")
    assert dog.name == "Tom"
    assert dog.type == "domestic dog"

# Generated at 2022-06-21 11:36:29.804161
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class X:
        a: int
        b: int

    received = dict(a=1, b=2, c=3)
    expected = dict(a=1, b=2)
    received_undefined = dict(c=3)

    def test_case(received: Dict[str, Any], expected: Dict[str, Any],
                  received_undefined: Dict[str, Any]):
        from_dict = _RaiseUndefinedParameters.handle_from_dict(X, received)
        assert from_dict == expected

# Generated at 2022-06-21 11:36:38.949270
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class SomeClass:
        def __init__(self, required_arg: str, other_arg: str,
                     catch_all: Optional[CatchAllVar] = None):
            pass

    some_class = SomeClass("x", None)
    init = _IgnoreUndefinedParameters.create_init(some_class)
    assert init is not some_class.__init__
    assert init.__name__ == "__init__"
    assert init.__doc__ == "Wrapper around SomeClass.__init__"


# Unit tests for method handle_from_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-21 11:36:40.705720
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(obj) == {}

# Generated at 2022-06-21 11:36:53.317531
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestCls:
        def __init__(self, a=True, b=True):
            self.a = a
            self.b = b
            self.undefined = {}

    def test(undefined_action, expected):
        to_dict = Undefined.INCLUDE.value.handle_to_dict(TestCls(),
                                                         {'a': True,
                                                          'b': True,
                                                          'undefined': {
                                                              'c': False}})
        assert to_dict == expected


    test(_IgnoreUndefinedParameters, {'a': True, 'b': True})
    test(_RaiseUndefinedParameters, {'a': True, 'b': True})

# Generated at 2022-06-21 11:37:00.502060
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.api import dataclass_json

    @dataclass_json
    @dataclasses.dataclass
    class TestData:
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(default=lambda: {},
                                                     metadata={
                                                         "undefined":
                                                             Undefined.INCLUDE
                                                     })

    t = TestData(a=1, c=2)
    assert t.b == {"c": 2}
    d = t.to_json()
    assert d == '{"a": 1}'

# Generated at 2022-06-21 11:37:01.664163
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-21 11:37:11.667047
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from typing import List, Optional
    import re

    class Example:
        pass

    class ExampleWithCatchAll:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict
        )

    class ExampleWithCatchAllAndDefault:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default={"hello": "world"}, default_factory=dict
        )

    class ExampleWithoutCatchAllAndInitWithOneArg:
        arg: str

        def __init__(self, arg: str) -> None:
            self.arg = arg

    class ExampleWithCatchAllInitWithOneArg:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict
        )

# Generated at 2022-06-21 11:37:44.693711
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class MyClass:
        a: str
        b: str
        c: str = "abc"
        d: str = dataclasses.field(default=None)
        # noinspection PyTypeChecker
        e: str = dataclasses.field(default_factory=lambda: "efg",
                                   metadata={"marshmallow_field":
                                                 fields.Str(load_only=True)})
        f: Optional[CatchAllVar] = None


    o = MyClass("aa", "bb", "cc", None, "ee", {"g": "gg"})
    expected = {"a": "aa", "b": "bb", "g": "gg"}

# Generated at 2022-06-21 11:37:47.232100
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class Test:
        a: str

        def __init__(self, a: str, **catch_all):
            self.a = a
            self.catch_all = catch_all

    t = Test("foo", b="bar")
    catch_all = _CatchAllUndefinedParameters.handle_dump(t)
    assert catch_all == {"b": "bar"}

# Generated at 2022-06-21 11:37:58.384447
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Test(abc.ABC):
        @abc.abstractmethod
        def handle_to_dict(cls, obj, kvs: Dict[Any, Any]) -> Dict[Any, Any]:
            pass

    def _test_for_class(cls, expected: Dict[Any, Any]):
        actual = cls.handle_to_dict(None, {"a": 1, "b": 2})
        assert actual == expected

    # _RaiseUndefinedParameters
    _test_for_class(_RaiseUndefinedParameters, {"a": 1, "b": 2})
    # _IgnoreUndefinedParameters
    _test_for_class(_IgnoreUndefinedParameters, {"a": 1, "b": 2})
    # _CatchAllUndefinedParameters

# Generated at 2022-06-21 11:38:00.852443
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class A(_UndefinedParameterAction):
        pass
    a = A()
    assert(isinstance(a, _UndefinedParameterAction))


# Generated at 2022-06-21 11:38:08.387177
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class A:
        a: str
        b: str = "b"
        c: str = CatchAll
    obj = A(a="a", b="b", c={"c": "c"})
    assert _CatchAllUndefinedParameters.handle_to_dict(obj, {"a" : "a", "b" : "b", "c" : {"c" : "c"}}) == {"a" : "a", "b" : "b", "c" : "c"}


# Generated at 2022-06-21 11:38:13.814959
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class SomeClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    kvs = {"a": 1, "b": "2", "c": 3}
    result = _UndefinedParameterAction.handle_from_dict(SomeClass, kvs)
    assert result == kvs


# Generated at 2022-06-21 11:38:24.294065
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class TestClass:
        field1: str
        field2: str = "default"
        field3: CatchAll = dataclasses.field(default_factory=dict)
        _hidden: int = -1

        def __post_init__(self):
            setattr(self, "_hidden", 10)

        @classmethod
        def assertEqual(cls, a, b):
            assert a == b

    @dataclass
    class TestSchema(Schema):
        class Meta:
            unknown = Undefined.INCLUDE

    # test to_dict
    obj = TestClass(field1="value1", field2="value2", _unique=100)


# Generated at 2022-06-21 11:38:27.194105
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Tests that construction of the class is not allowed.
    """
    try:
        _UndefinedParameterAction()
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 11:38:33.080714
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    cls = object
    # Pass no unknown arguments
    kvs = {}
    new_kvs = _RaiseUndefinedParameters._separate_defined_undefined_kvs(
        cls=cls, kvs=kvs)
    assert len(new_kvs) == 0
    # Pass 2 unknown arguments
    kvs = {"asdf": 123, "jklö": 456}
    with pytest.raises(UndefinedParameterError):
        new_kvs = _RaiseUndefinedParameters._separate_defined_undefined_kvs(
            cls=cls, kvs=kvs)



# Generated at 2022-06-21 11:38:38.146619
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int = 1
        b: str = ""

    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, dict()) == dict(
        a=1, b="")
    assert _RaiseUndefinedParameters.handle_from_dict(TestClass, dict(
        a=10)) == dict(a=10, b="")



# Generated at 2022-06-21 11:39:30.455572
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    obj = object()
    kvs = dict(obj=obj)

    result = _UndefinedParameterAction.handle_to_dict(obj, kvs)

    assert result == {"obj": obj}



# Generated at 2022-06-21 11:39:37.371594
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, field_1: int, field_2: str):
            self.field_1 = field_1
            self.field_2 = field_2

    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs={"field_1": 1, "field_2": "2", "u": 3}) == {
               "field_1": 1, "field_2": "2"}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs={"field_1": 1, "field_2": "2", "u": 3}) == {
               "field_1": 1, "field_2": "2"}

# Generated at 2022-06-21 11:39:47.848073
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import dataclasses

    @dataclasses.dataclass
    class Cls:
        a: int
        b: int

        @classmethod
        def create_from_dict(cls, kvs: Dict):
            return cls(**_RaiseUndefinedParameters.handle_from_dict(cls, kvs))

    cls = Cls.create_from_dict({"a": 3, "b": 4})
    assert cls.a == 3
    assert cls.b == 4

    try:
        cls = Cls.create_from_dict({"a": 3, "b": 4, "c": 5})
    except UndefinedParameterError:
        pass
    else:
        assert False, "Should have raised"



# Generated at 2022-06-21 11:39:51.404693
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=Foo, kvs={
            "a": 1,
            "b": 2
        })



# Generated at 2022-06-21 11:40:00.128090
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a) -> None:
            self.a = a

    @dataclasses.dataclass
    class Test2:
        a: int

    sample_value = 5
    expected = {"a": sample_value}

    received_1 = _RaiseUndefinedParameters.handle_from_dict(Test,
                                                            expected)
    received_2 = _RaiseUndefinedParameters.handle_from_dict(Test2,
                                                            expected)
    assert received_1 == received_2 == expected



# Generated at 2022-06-21 11:40:11.446249
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class SomeClass:
        first_name: str
        last_name: str

    def assert_equal_dicts(d1, d2):
        assert len(d1) == len(d2), "Dictionaries not of same length"
        for k, v in d1.items():
            assert d2[k] == v, f"Field {k} not equal: {d2[k]} != {v}"

    param1 = "some name"
    param2 = "some other name"
    kvs = {
        "first_name": param1,
        "last_name": param2
    }

    # case 1: all defined
    expected = kvs
    actual = _CatchAllUndefinedParameters.handle_to_dict

# Generated at 2022-06-21 11:40:15.974660
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Test:
        a: str
        b: int
        c: int

    kvs = {"a": "aaa", "b": 2, "d": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=Test, kvs=kvs)
    assert known == {"a": "aaa", "b": 2}
    assert unknown == {"d": 3}

# Generated at 2022-06-21 11:40:28.536774
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # type: () -> None
    class Test:

        def __init__(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

    test = Test(1, 2)
    assert test.a == 1
    assert test.b == 2
    assert test.c == 3

    init_fn = _IgnoreUndefinedParameters.create_init(Test)
    obj = init_fn(self=0, a=1, b=2, d=4)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    with pytest.raises(TypeError):
        init_fn(self=0, a=1, b=2, d=4, e=5)

# Generated at 2022-06-21 11:40:32.412763
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    assert _UndefinedParameterAction.create_init(
        lambda x: None)() is None
    assert not _UndefinedParameterAction.create_init(
        lambda x: None).__class__.__name__ == "wrapper_descriptor"
    assert _UndefinedParameterAction.create_init(
        lambda x: None).__name__ == "lambda"

# Generated at 2022-06-21 11:40:34.626401
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}


# Generated at 2022-06-21 11:43:03.753210
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    data = {"key": "value", "_catch_all" : {"undef_key": "undef_value"}}
    def get_catch_all_field(cls):
        return "CatchAll"
    kvs = {"key": "value", "CatchAll": {"undef_key": "undef_value"}}
    res = _CatchAllUndefinedParameters.handle_to_dict(obj=None, kvs=kvs)
    print(res)
    assert res == data


# Generated at 2022-06-21 11:43:05.561498
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # noinspection PyTypeChecker
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=None, kvs={"my_dict": {}}) == {}

# Generated at 2022-06-21 11:43:08.551262
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class A:
        pass

    assert _UndefinedParameterAction.handle_to_dict(A, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(A, dict(
        a=1)) == dict(a=1)

# Generated at 2022-06-21 11:43:15.216576
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    """
    In order to test this method, we have to mock dataclasses.fields
    """
    def mocked_fields(cls):
        return [
            Field(name="name", type=str, default=mock.Mock()),
            Field(name="age", type=int, default=mock.Mock()),
            Field(name="height", type=int, default=mock.Mock()),
            Field(name="weight", type=int, default=mock.Mock()),
        ]

    @dataclasses.dataclass
    class Dummy:
        name: str = "John"
        age: int = 0
        height: int = 0
        weight: int = 0

    import unittest.mock as mock

# Generated at 2022-06-21 11:43:20.319459
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, param1, param2, **undefined_parameters):
            self.param1 = param1
            self.param2 = param2
            self.undefined_parameters = undefined_parameters
    obj = TestClass("a", "b", **{"c":1, "d":2})
    kvs = dict(
        param1="a",
        param2="b"
    )
    kvs = _CatchAllUndefinedParameters.handle_to_dict(
        obj, kvs
    )
    assert kvs == dict(
        param1="a",
        param2="b",
        c=1,
        d=2
    )

# Generated at 2022-06-21 11:43:22.454192
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():  # type: () -> None
    message = "This is a test"
    exception = UndefinedParameterError(message)
    assert message == exception.messages

# Generated at 2022-06-21 11:43:32.896350
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import make_dataclass

    @make_dataclass
    class Klass:
        a: str
        b: str = "bar"
        c: Optional[CatchAllVar]

    klass = Klass("foo", c={1: "two"})
    klass_dict = dataclasses.asdict(klass)
    assert getattr(klass, "c") == {1: "two"}

    # Test default factory as default
    @make_dataclass
    class Klass:
        a: str
        b: str = "bar"
        c: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    klass = Klass("foo")
    klass_dict = dataclasses.asdict(klass)

# Generated at 2022-06-21 11:43:43.728189
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():

    class TestClass:
        def __init__(self, undefined_parameter_action):
            self.undefined_parameter_action = undefined_parameter_action

    @dataclasses.dataclass
    class TestClassWithCatchAll:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)

    test_classes = [TestClass(_RaiseUndefinedParameters),
                    TestClass(_IgnoreUndefinedParameters),
                    TestClass(_CatchAllUndefinedParameters),
                    TestClassWithCatchAll()]
    for test_class in test_classes:
        kvs = {"a": 1, "b": 2}
        result = test_class.undefined_parameter_action.handle_to_dict(
            test_class, kvs)
        assert result == kvs

# Generated at 2022-06-21 11:43:48.558207
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    init = _IgnoreUndefinedParameters.create_init(Foo)
    f = init(1, 2, 3, 4, string="s", integer=int)
    assert f.a == 1
    assert f.b == 2
    assert f.string == "s"
    assert f.integer == int



# Generated at 2022-06-21 11:43:51.969149
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        name: str
        age: int
        weight: float
        ignore_me: Optional[CatchAllVar] = None

    result = _IgnoreUndefinedParameters.handle_from_dict(
                Test, {"name": "test", "age": 33, "height": 1.88})
    assert result == {"name": "test", "age": 33}

    result = _IgnoreUndefinedParameters.handle_from_dict(Test, {})
    assert result == {}

