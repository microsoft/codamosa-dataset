

# Generated at 2022-06-21 11:34:27.779109
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Test that the class _UndefinedParameterAction can not be constructed
    """
    try:
        _UndefinedParameterAction()
    except TypeError as e:
        assert "Can't instantiate" in str(e)

# Generated at 2022-06-21 11:34:38.054497
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        x: int = 1
        y: str = "Test"
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=dict)

        def __init__(self, *args, **kwargs):
            pass

    tc = TestClass()
    assert tc.x == 1
    assert tc.y == "Test"
    assert tc.catch_all == {}

    tc = TestClass(x=5, y="Another")
    assert tc.x == 5
    assert tc.y == "Another"
    assert tc.catch_all == {}

    tc = TestClass(x=5, y="Another", z=3)
    assert tc.x == 5
    assert tc.y == "Another"

# Generated at 2022-06-21 11:34:44.307864
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # class dummy(metaclass=abc.ABCMeta):
    #     @abc.abstractmethod
    #     def __init__(self):
    #         pass
    #
    #     @abc.abstractmethod
    #     def to_dict(self) -> dict:
    #         pass
    #
    # class _Dummy(_UndefinedParameterAction, metaclass=abc.ABCMeta):
    #     @classmethod
    #     @abc.abstractmethod
    #     def handle_from_dict(cls, kvs: dict) -> dict:
    #         pass

    class Foo:
        def to_dict(self) -> dict:
            raise NotImplementedError()

    # class _RaiseUndefinedParameters(_UndefinedParameterAction):
    #     @staticmethod
    #     def handle_from_

# Generated at 2022-06-21 11:34:53.204153
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

    known_parameters, undefined_parameters = \
        _RaiseUndefinedParameters._separate_defined_undefined_kvs(A, {"a": 3,
                                                                       "c": 4})
    assert len(known_parameters) == 1
    assert len(undefined_parameters) == 1
    assert known_parameters["a"] == 3
    assert undefined_parameters["c"] == 4



# Generated at 2022-06-21 11:34:56.288370
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class TestClass:
        def __init__(self):
            pass

        def __dataclass_json__(self):
            schema_kvs = {
                "test": "parameter"
            }
            return schema_kvs

    t = TestClass()
    kvs = _UndefinedParameterAction.handle_dump(t)
    assert len(kvs.keys()) == len(["test"])



# Generated at 2022-06-21 11:35:00.341376
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=None, kvs={"a": 1}) == {"a": 1}
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={"a": 1,
                                                                   "b": 2})
        assert False  # Should not get executed
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:35:06.713803
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # given
    kvs = {
        "name": "value"
    }

    data_class = dataclasses.make_dataclass("test",
                                            ["name"])

    # when
    known = _RaiseUndefinedParameters.handle_from_dict(data_class, kvs)

    # then
    assert known == kvs



# Generated at 2022-06-21 11:35:14.762597
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class Data(metaclass=abc.ABCMeta):
        @abc.abstractmethod
        def __init__(self, a: int, b: int, c: int) -> None:
            pass

    class Data1(Data):
        def __init__(self, a: int, b: int, c: int) -> None:
            self.a = a
            self.b = b
            self.c = c

    class Data2(Data):
        def __init__(self, a: int, b: int, c: int) -> None:
            self.a = a
            self.b = b
            self.c = c

    data1 = Data1(1, 2, 3)
    data2 = Data2(1, 2, 3)

    assert data1.a == 1

# Generated at 2022-06-21 11:35:15.502765
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass



# Generated at 2022-06-21 11:35:22.962600
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestDataClass:
        a: int = 1
        b: str = "b"
        c: Dict[Any, Any] = dataclasses.field(default_factory=dict)

    test_data_class = TestDataClass()
    original_init = test_data_class.__init__
    _CatchAllUndefinedParameters.create_init(test_data_class)()
    assert original_init == test_data_class.__init__

# Generated at 2022-06-21 11:35:42.002704
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: int

        def __post_init__(self):
            self.init_args = self.__dict__

    class A(A, Undefined):
        pass

    result = A.INCLUDE.handle_from_dict(A,
                                        {"a": 1, "b": 1})
    assert result == {"a": 1}
    assert result.get("b") is None

# Generated at 2022-06-21 11:35:49.659328
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import fields
    from typing import Any

    @dataclasses.dataclass
    class TestClass:
        d: Dict[str, Any] = dataclasses.field(
            default_factory=lambda: {"undefined_key": "undefined_value"})
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    _CatchAllUndefinedParameters.create_init(TestClass)

    # Unit test check if the default factory is used
    d = {
        "c": {
            "undefined_key": "undefined_value"
        }
    }
    TestClass(**d)
    # Unit test that the default factory does not overwrite user input

# Generated at 2022-06-21 11:36:00.669235
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class A:
        a1: float
        a2: float
        catch_all: CatchAll = dataclasses.field(default=None)

        def __init__(self, *args, **kwargs):
            pass

    my_a = A(1.0, 2.0)

    new_init = _UndefinedParameterAction.create_init(A)
    new_init(my_a)

    new_init = _IgnoreUndefinedParameters.create_init(A)
    new_init(my_a)

    new_init = _CatchAllUndefinedParameters.create_init(A)
    new_init(my_a)

# Generated at 2022-06-21 11:36:06.616941
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        defined_parameter: str
        catch_all: CatchAll
        undefined_parameter: str

    t = TestClass("x", {}, "y")

    assert _CatchAllUndefinedParameters.handle_dump(t) == {}

    t.catch_all = {"z": "z"}
    assert _CatchAllUndefinedParameters.handle_dump(t) == {"z": "z"}

# Generated at 2022-06-21 11:36:13.722461
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a: int,
                     b: int = None):
            self.a = a
            self.b = b


    # No undefined parameters
    a = _IgnoreUndefinedParameters.create_init(A)(None, 2, b=3)
    assert a.a == 2
    assert a.b == 3

    # Unknown kwarg
    a = _IgnoreUndefinedParameters.create_init(A)(None, 2, b=3, c=5)
    assert a.a == 2
    assert a.b == 3

    # Unknown arg
    a = _IgnoreUndefinedParameters.create_init(A)(None, 2, 3, b=5)
    assert a.a == 2
    assert a.b == 5

    # Unknown args and kwargs
    a

# Generated at 2022-06-21 11:36:21.448002
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import pytest
    from dataclasses_json.utils import CatchAllVar

    from dataclasses import dataclass

    @dataclass
    class SomeClass:
        included_var1: str = "included_var1"
        included_var2: str = "included_var2"
        undefined_parameters: CatchAllVar = dataclasses.field(
            metadata={"marshmallow_field": CatchAllVar(str)})

    class_instance = SomeClass(undefined_parameters={"undefined_var": "test"})

# Generated at 2022-06-21 11:36:22.298512
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}


# Generated at 2022-06-21 11:36:27.998803
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class MockClass:
        pass

    known_given_parameters, unknown_given_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=MockClass, kvs={"a": 1, "b": 1})
    assert known_given_parameters == {"a": 1}, \
        "Known parameters separated incorrectly."
    assert unknown_given_parameters == {"b": 1}, \
        "Undefined parameters separated incorrectly."



# Generated at 2022-06-21 11:36:40.299347
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    def _create_catch_all_init(init_type: type, num_params = 1):
        class DefinedParameterClass:
            def __init__(self, *args, **kwargs):
                pass

        _CatchAllUndefinedParameters.create_init(DefinedParameterClass)

        if num_params == 1:
            if init_type == type(int):
                class IntParameterClass:
                    def __init__(self, a: int, **kwargs):
                        pass

                return _CatchAllUndefinedParameters.create_init(
                    IntParameterClass)
            elif init_type == Optional[type(int)]:
                class OptionalIntParameterClass:
                    def __init__(self, a: Optional[int], **kwargs):
                        pass


# Generated at 2022-06-21 11:36:45.088813
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # pylint: disable=W0212
    assert _RaiseUndefinedParameters.handle_from_dict(None, {}) == {}
    assert _RaiseUndefinedParameters.handle_to_dict(None, {"a": "a", "b": "b"}) == {
               "a": "a", "b": "b"}



# Generated at 2022-06-21 11:37:14.123904
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    unknown_field_name = "unknown_field"
    value = 42

    class TestClass:
        def __init__(self, known_field: int, **kwargs):
            self.known_field = known_field
            self.unknown_field = kwargs["unknown_field"]

    test_class = TestClass(known_field=1, unknown_field=value)
    assert getattr(test_class, unknown_field_name) == value

    kvs = {
        "known_field": 1,
        unknown_field_name: value
    }

    _UndefinedParameterAction.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-21 11:37:15.501098
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(None, {}) == {}

# Generated at 2022-06-21 11:37:24.666329
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class DummyClass:
        def __init__(self, a, b):
            pass

    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=DummyClass,
        kvs={"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        cls=DummyClass,
        kvs={"a": 1, "c": 2}) == {"a": 1}
    try:
        _IgnoreUndefinedParameters.handle_from_dict(
            cls=DummyClass,
            kvs={})
        assert False
    except TypeError as e:
        assert "missing 2 required positional arguments" in str(e)



# Generated at 2022-06-21 11:37:34.137939
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestCatchAllInit(object):
        one: int
        two: int = 2
        three: Optional[CatchAll] = dataclasses.field(default=None,
                                                      metadata=dict(
                                                          letter_case="camel"))

    cls = TestCatchAllInit
    init = _CatchAllUndefinedParameters.create_init(cls)
    init_signature = inspect.signature(init)

    # Check if __init__ has the same signature as before
    assert "one" in init_signature.parameters
    assert "two" in init_signature.parameters
    assert "three" in init_signature.parameters

    # Case 1: All arguments are given
    test = init(1, 2, three={})
    assert test

# Generated at 2022-06-21 11:37:44.239616
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Foo:
        a: int
        b: Optional[CatchAllVar]

    # Test case 1
    kvs = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    expected = {
        "a": 1,
        "b": {
            "c": 3
        }
    }
    actual = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs)
    assert expected == actual

    # Test case 2
    kvs = {
        "a": 1
    }
    expected = {
        "a": 1,
        "b": {}
    }
    actual = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs)
    assert expected == actual

    # Test case 3

# Generated at 2022-06-21 11:37:49.030975
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from aenum import Enum
    from typing import List
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class MyDataClass(DataClassJsonMixin):
        a: str
        b: str
        c: 'List[str]'
        cat: Optional[CatchAll] = config(field_name="cat")

    my_class = MyDataClass("a", "b", ["c"])
    my_class.cat = {"d": "e"}
    kvs = {
        "a": my_class.a,
        "b": my_class.b,
        "c": my_class.c,
        "cat": my_class.cat
    }

# Generated at 2022-06-21 11:37:53.930365
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    test_obj = TestClass()
    init = _IgnoreUndefinedParameters.create_init(test_obj)
    init(test_obj, a=1, b=2, c=3)

# Generated at 2022-06-21 11:38:04.611780
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field
    from dataclasses_json import config

    @dataclass
    class _MockDataclass:
        name: str = ""
        _action: _UndefinedParameterAction = _RaiseUndefinedParameters

        def __init__(self, **kvs: Any):
            validated = self._action.handle_from_dict(self.__class__, kvs)
            super().__init__(**validated)

    data = {'name': 'peter',
            'age': 21,
            'city': 'zurich',
            'country': 'Switzerland'}

    @dataclass
    class _MockDataclass1(_MockDataclass):
        age: int = field(metadata={config.undefined: Undefined.RAISE})
        city: str

# Generated at 2022-06-21 11:38:14.803843
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyDataclass
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: Optional[CatchAllVar] = dataclasses.field(default_factory=None)

    assert _CatchAllUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs={"x": 1}) == {
            "x": 1}
    assert _CatchAllUndefinedParameters.handle_from_dict(cls=TestClass,
                                                         kvs={"x": 1,
                                                              "y": {
                                                                  "a": 1,
                                                                  "b": 2,
                                                              }}) == {
            "x": 1, "y": {
                "a": 1, "b": 2,
            }}


# Generated at 2022-06-21 11:38:20.226770
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # given
    kvs = {"a": 1, "b": 2}
    cls = dataclasses.make_dataclass("A", kvs.keys())

    # when
    known = _RaiseUndefinedParameters.handle_from_dict(cls, kvs)

    # then
    assert known == kvs



# Generated at 2022-06-21 11:39:08.033512
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    # Should raise error because abstract class
    with pytest.raises(TypeError):
        _UndefinedParameterAction()

    # Should not raise an error because it does not inherit from abstract class
    _IgnoreUndefinedParameters()

# Generated at 2022-06-21 11:39:11.740355
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError(description="description",
                                      path="path")
    except UndefinedParameterError as err:
        assert err.__cause__ is None, "__cause__ is not None"
        assert err.description == 'description', "description is not correct"
        assert err.path == 'path'

# Generated at 2022-06-21 11:39:16.397707
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestObject(object):
        a: int
        b: str

    kvs = {"a": 1, "b": "2", "c": 3}
    known_parameters = dict(a=1, b="2")
    _IgnoreUndefinedParameters.handle_from_dict(TestObject, kvs) == \
    known_parameters
    # Output: True



# Generated at 2022-06-21 11:39:20.934124
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Dataclass(metaclass=dataclasses.dataclass):
        number: int = dataclasses.field()
        text: str = dataclasses.field()

    my_class = Dataclass(1, "hello")

    result = _UndefinedParameterAction.handle_to_dict(my_class,
                                                      {"number": 1, "text": "hello"})

    assert result == {"number": 1, "text": "hello"}



# Generated at 2022-06-21 11:39:24.461831
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass(object):
        pass

    assert {} == _UndefinedParameterAction.handle_to_dict(TestClass(), {})

# Generated at 2022-06-21 11:39:27.404683
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    """
    Test the init constructor of RaiseUndefinedParameters
    """

    class TestClass:
        def __init__(self, test: int):
            pass

    kvs = {}
    _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)



# Generated at 2022-06-21 11:39:33.872355
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a: int = 100):
            self.a = a

    test_object = A()
    modified_init = _IgnoreUndefinedParameters.create_init(A)
    test_object = modified_init(test_object, a=10)
    assert test_object.a == 10
    try:
        modified_init(test_object, a=11, b=12)
    except:
        assert True
    test_object2 = modified_init(test_object, b=13)
    assert test_object2.a == 10



# Generated at 2022-06-21 11:39:34.358001
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    pass

# Generated at 2022-06-21 11:39:35.592746
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    action = _RaiseUndefinedParameters()
    action.handle_from_dict(Any, None)



# Generated at 2022-06-21 11:39:46.626374
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(
        message="a message",
        field_name="field_name",
        valid_data="valid_data",
        field_value="field_value",
        field_type="field_type",
        field_schema="field_schema",
        parent=dataclasses.asdict,
        exc=NotImplementedError("a message")
    )

    # Test the __str__ method
    assert str(error) is not None and \
           len(str(error)) > 0

    assert isinstance(error.messages, list) and \
           len(error.messages) > 0

    assert error.field_name is not None
    assert error.valid_data is not None
    assert error.field_value is not None
    assert error.field_type is not None
    assert error

# Generated at 2022-06-21 11:41:35.335006
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, value: int, other: str, **kwargs):
            pass

    _IgnoreUndefinedParameters.create_init(TestClass)(TestClass, 1, 2, value=1)

# Generated at 2022-06-21 11:41:45.441275
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    """
    Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
    """
    A = dataclasses.make_dataclass('A', [('a', str)])

    # correct usage
    kvs = {'a': 'asdf', 'b': 'undefined'}
    _CatchAllUndefinedParameters.handle_from_dict(A, kvs)

    # two catch-all-fields
    B = dataclasses.make_dataclass('B', [('a', str, None),
                                         ('catch_all_1', CatchAll),
                                         ('catch_all_2', CatchAll)])

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_from_dict(B, kvs)

    # miss-match with default


# Generated at 2022-06-21 11:41:49.400171
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class C:
        pass
    
    params = {1:11}
    expected_params = {}

    actual_params = _RaiseUndefinedParameters.handle_from_dict(C, params)
    
    assert actual_params == expected_params



# Generated at 2022-06-21 11:41:58.091111
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import dataclasses_json

    class TestCatchall:
        def __init__(self, catch_all: Optional[dataclasses_json.CatchAll] = None):
            self.catch_all = catch_all

        def as_dict(self) -> dict:
            # noinspection PyPep8Naming
            d = dataclasses.asdict(self,
                                   dict_factory=dataclasses_json.Undefined.EXCLUDE)
            return d

    t = TestCatchall(5)
    result = t.as_dict()
    assert result == {}

    t = TestCatchall({"a": 5})
    result = t.as_dict()
    assert result == {"a": 5}


# Generated at 2022-06-21 11:42:03.159525
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class _TestClass:
        field: int
        catch_all: Optional[CatchAll] = None

    test_obj = _TestClass(field=42)
    expected_result = {"field": 42}
    result = _CatchAllUndefinedParameters.handle_from_dict(
        cls=_TestClass,
        kvs={})
    assert expected_result == result

    expected_result = {"field": 42, "catch_all": {}}
    result = _CatchAllUndefinedParameters.handle_from_dict(
        cls=_TestClass,
        kvs={"field": 42})
    assert expected_result == result

    expected_result = {"field": 6, "catch_all": {"one": 2, "two": 3}}
    result

# Generated at 2022-06-21 11:42:13.861200
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Test:
        def __init__(self, a, b="b", c: CatchAll = None):
            pass

    # These should work
    _CatchAllUndefinedParameters.create_init(Test)
    _CatchAllUndefinedParameters.create_init(Test)(Test, a="a", b="b", c={})
    _CatchAllUndefinedParameters.create_init(Test)(Test, a="a", b="b",
                                                   d="d")

    # These should raise errors
    try:
        _CatchAllUndefinedParameters.create_init(Test)(Test, a="a", b="b", c={},
                                                       d="d")
    except UndefinedParameterError as e:
        assert "Received input field with same name as catch-all field" in str(
            e)

# Generated at 2022-06-21 11:42:25.816180
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from marshmallow import Schema

    @dataclasses.dataclass
    class TestClass:
        name: str
        age: int
        height: float
        catch_all: Optional[CatchAllVar] = \
            dataclasses.field(default=None, metadata={"marshmallow_field":
                                                      CatchAll})

    def assert_mapping(
            given_input: Dict[str, Any],
            expected_output: Dict[str, Any]):
        output = TestClass(**given_input)
        output_dict = test_schema.dump(output)
        assert output_dict == expected_output

    test_schema = Schema.from_dataclass(TestClass)

# Generated at 2022-06-21 11:42:30.486151
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def __init__(self, param1: str, param2: str = "default_value",
                 **undefined_parameters):
        pass

    create_init = _IgnoreUndefinedParameters.create_init(None)
    init = create_init(__init__)
    init('asd', 'sd')

# Generated at 2022-06-21 11:42:35.108505
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class ExampleClass:
        a: int
        b: int = 5

    kvs = {"a": 5, "b": 4, "c": 7}
    expected_parameters = {"a": 5, "b": 4}
    actual_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(ExampleClass, kvs)
    assert expected_parameters == actual_parameters



# Generated at 2022-06-21 11:42:43.050937
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow_dataclass
    import marshmallow

    @dataclasses.dataclass
    @marshmallow_dataclass.dataclass
    class BasicClass:
        a: int
        b: float = None

        def __init__(self, a: int, b: float = None):
            self.a = a
            self.b = b

    assert len(inspect.signature(BasicClass.__init__).parameters) == 2
    wrapped_init = _IgnoreUndefinedParameters.create_init(BasicClass)
    assert len(inspect.signature(wrapped_init).parameters) == 3
    assert len(inspect.signature(wrapped_init).parameters) == 3

    basic_object = BasicClass(a=5, c="Hello")