

# Generated at 2022-06-21 11:34:33.725536
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class MyClass:
        def __init__(self,
                     a: str,
                     b: str,
                     c: str):
            pass

    obj = MyClass("a", "b", "c")
    # Test for constructor
    new_init = _IgnoreUndefinedParameters.create_init(obj)
    new_init(obj, "a", "b", "c")
    new_init(obj, "a", "b", "c", d="d", e="e")
    new_init(obj, "a", "b", "c", d="d", e="e")
    # Test that the arguments match
    signature = inspect.signature(new_init)
    bound = signature.bind(obj, "a", "b", "c")
    bound.apply_defaults()
    args = bound.arguments

# Generated at 2022-06-21 11:34:44.697908
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Define a class with a catch all field
    @dataclasses.dataclass
    class A:
        _undefined: Undefined = Undefined.INCLUDE
        a: int
        catch_all: CatchAll


# Generated at 2022-06-21 11:34:48.332031
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('Test')
    except UndefinedParameterError as exp:
        assert exp.args[0] == 'Test'
    else:
        assert False



# Generated at 2022-06-21 11:34:54.796131
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class RaisedParameterClass:
        param1: str

    x = RaisedParameterClass(param1="Echo")
    assert x.param1 == "Echo"

    caught_error = False
    try:
        RaisedParameterClass(param1="Echo", param2="Bravo")
    except UndefinedParameterError:
        caught_error = True
    assert caught_error



# Generated at 2022-06-21 11:34:56.036332
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
        assert False
    except UndefinedParameterError as e:
        assert str(e) == ''

# Generated at 2022-06-21 11:34:57.463095
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError(None)
    except UndefinedParameterError as e:
        assert e

# Generated at 2022-06-21 11:34:58.603308
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    message = "this is an error"
    UndefinedParameterError(message)

# Generated at 2022-06-21 11:35:05.625227
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        _include_validators = ()
        ignore_unknown_parameters: Undefined = Undefined.EXCLUDE
        unknown: CatchAll = None

    a = A(unknown={"foo": "bar"})
    assert a.unknown["foo"] == "bar"

    a = A(unknown={"foo": "bar"},
          ignore_unknown_parameters=Undefined.INCLUDE)
    assert a.unknown["foo"] == "bar"

    with pytest.raises(UndefinedParameterError):
        A(ignore_unknown_parameters=Undefined.RAISE)

    with pytest.raises(UndefinedParameterError):
        A(unknown={"foo": "bar"},
          ignore_unknown_parameters=Undefined.RAISE)


# Generated at 2022-06-21 11:35:07.113436
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert {} == _UndefinedParameterAction.handle_dump(None)

# Generated at 2022-06-21 11:35:14.927579
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    assert _CatchAllUndefinedParameters.handle_from_dict(object, {}) == {}
    assert _CatchAllUndefinedParameters.handle_from_dict(object, {"u1": 1}) \
           == {"u1": 1}
    assert _CatchAllUndefinedParameters.handle_from_dict(object,
                                                         {"u1": 1, "_UNKNOWN0": 2}) == {"u1": 1,
                                                                                        "_UNKNOWN0": 2}
    assert _CatchAllUndefinedParameters.handle_from_dict(object,
                                                         {CatchAllVar: {"u1": 1,
                                                                        "_UNKNOWN0": 2}}) == {
               CatchAllVar: {"u1": 1, "_UNKNOWN0": 2}}

# Generated at 2022-06-21 11:35:36.498522
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    """
    Unit test to check if the constructor of class _CatchAllUndefinedParameters
    works.
    """

    def _check_params(
            params: Dict[str, Any], expected_kvs: Dict[str, Any]):
        if not isinstance(params, dict):
            raise ValueError(
                f"Given params is not of type dict: {type(params)}")
        for k, v in params.items():
            if k in expected_kvs:
                if expected_kvs[k] != v:
                    raise ValueError(f"Key '{k}' has wrong value: "
                                     f"Expected: '{expected_kvs[k]}', "
                                     f"Received: '{v}'")

# Generated at 2022-06-21 11:35:46.023500
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs = {"a": 1, "b": 2, "x": "okay"}

    @dataclasses.dataclass()
    class TestHandleFromDict:
        a: int
        b: float
        def __init__(self, **kvs) -> None:
            self.x = kvs.pop("x", "")

    known_given_parameters = _IgnoreUndefinedParameters.handle_from_dict(
        TestHandleFromDict, kvs)
    assert known_given_parameters["a"] == 1
    assert known_given_parameters["b"] == 2
    assert len(known_given_parameters) == 2


# Generated at 2022-06-21 11:35:56.398902
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # Test that no error is raised when none is given


    class TestClass:
        def __init__(self):
            pass


    _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, {})

    # Test that an error is raised when one is given


    class TestClass:
        def __init__(self):
            pass


    try:
        _IgnoreUndefinedParameters.handle_from_dict(
            TestClass, {"test": "test"})
    except UndefinedParameterError:
        pass
    else:
        assert False, "Should have raised an error due to undefined parameter."



# Generated at 2022-06-21 11:36:07.575611
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class CatchAllClass:
        a: int
        b: str
        undefined_parameters: Optional[CatchAllVar] = \
            dataclasses.field(default=None)
        pass

    catch_all_class: CatchAllClass = dataclasses.make_dataclass(
        "catch_all_class",
        [("a", int), ("b", str), ("undefined_parameters", Optional[CatchAllVar])],
        bases=(),
        namespace={"undefined_parameters": dataclasses.field(default=None)},
        exec_body=True,
    )

    new_init: Callable = _CatchAllUndefinedParameters.create_init(catch_all_class)
    decorated_init_signature = inspect.signature(new_init)

# Generated at 2022-06-21 11:36:15.960890
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAllVar]

    instance = TestClass(a=0, b="a", c={})
    result = _CatchAllUndefinedParameters.handle_dump(obj=instance)
    assert result == {}

    instance.c = {"a": 2, "b": 4}
    result = _CatchAllUndefinedParameters.handle_dump(obj=instance)
    assert result == {"a": 2, "b": 4}

# Generated at 2022-06-21 11:36:22.698169
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Example:
        foo: str
        bar: str
        _UNDEFINED_PARAMETERS: Optional[CatchAllVar] = None

        def __init__(self, *, foo: str, bar: str,
                     _UNDEFINED_PARAMETERS: Optional[CatchAllVar]):
            self.foo = foo
            self.bar = bar
            self._UNDEFINED_PARAMETERS = _UNDEFINED_PARAMETERS

    kvs = {'foo': 'a', '_UNDEFINED_PARAMETERS': {'b': 'b'}}
    args = {'foo': 'x', 'bar': 'y', '_UNDEFINED_PARAMETERS': {'b': 'b',
                                                              'c': 'c'}}

# Generated at 2022-06-21 11:36:23.910558
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    Unit tests for class _UndefinedParameterAction
    """

    _UndefinedParameterAction()

# Generated at 2022-06-21 11:36:24.690484
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters()



# Generated at 2022-06-21 11:36:32.494195
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class DC:
        def __init__(self, a, b, **kwargs):
            pass

    d = {"a": 1, "b": 2}
    expected_return = {"a": 1, "b": 2}

    assert _CatchAllUndefinedParameters.handle_dump(DC(a=1, b=2, c=3)) == \
           expected_return
    assert _UndefinedParameterAction.handle_dump(DC(a=1, b=2, c=3)) == \
           expected_return



# Generated at 2022-06-21 11:36:34.025991
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # type: () -> None
    UndefinedParameterError("Message")

# Generated at 2022-06-21 11:37:00.603794
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError(message="abc")
    except UndefinedParameterError as e:
        assert str(e) == "abc"

# Generated at 2022-06-21 11:37:11.206795
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    kvs = {"hello": "world"}
    param = object()
    class A:
        def __init__(self, param: object, hello: str = "default"):
            self.hello = hello
            self.param = param
            pass


    init = _RaiseUndefinedParameters.create_init(A)
    @functools.wraps(init)
    def _test_init(A, *args, **kwargs):
        return init(A, *args, **kwargs)

    # test missing param
    with pytest.raises(TypeError):
        a = A()

    # test invalid param
    with pytest.raises(TypeError):
        a = A(5)

    # test valid param
    a = A(param)
    assert isinstance(a, A)

# Generated at 2022-06-21 11:37:21.368256
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # Ignore undefined parameters
    assert _IgnoreUndefinedParameters.handle_dump(1) == {}

    # Raise
    try:
        _RaiseUndefinedParameters.handle_dump(1)
        assert False
    except UndefinedParameterError:
        pass

    # Catch all
    def _init(self, test: str, data: dict):
        pass

    def _dict_repr(self):
        return {"test": self.test, "data": self.data}

    Test = dataclasses.make_dataclass("Test", [("test", str)],
                                      init=_init,
                                      repr=_dict_repr)
    test1 = Test("abc", data={"abc": "abc"})
    assert _CatchAllUndefinedParameters.handle_dump(test1) == {"abc": "abc"}



# Generated at 2022-06-21 11:37:22.330266
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    undefined = _RaiseUndefinedParameters()
    assert undefined is not None

# Generated at 2022-06-21 11:37:31.647283
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: Optional[CatchAllVar]

    kvs = {"a": 1,
           "b": {"a": 1}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    expected = {"a": 1,
                "b": {"a": 1}}
    assert result == expected

    kvs = {"a": 1}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    expected = {"a": 1,
                "b": {}}
    assert result == expected

    kvs = {"a": 1,
           "b": {"a": 1},
           "c": {"a": 1}}

# Generated at 2022-06-21 11:37:32.765306
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    pass


# Generated at 2022-06-21 11:37:39.167513
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(frozen=True)
    class CatchAllTestClass:
        catch_all: Optional[CatchAllVar] = \
            dataclasses.field(default=dict(), init=False)

        def __init__(self, **kwargs):
            pass

    init = _CatchAllUndefinedParameters.create_init(CatchAllTestClass)
    init(CatchAllTestClass())

# Generated at 2022-06-21 11:37:47.288973
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
            self.d = 42
            pass

    class TestClass2:
        def __init__(self, a, b, c, d: str, f: str = "DEFAULT", g: str = "DEFAULT"):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.f = f
            self.g = g
            pass

    class TestClass3:
        def __init__(self, a, b, c, d: str = "DEFAULT", f: str = "DEFAULT", g: str = "DEFAULT"):
            self.a = a

# Generated at 2022-06-21 11:37:48.322277
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass


# Generated at 2022-06-21 11:37:59.512638
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int, c: int) -> None:
            pass

    result = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs={"a": 1, "b": 2, "c": 3})
    assert len(result[0]) == 3
    assert len(result[1]) == 0

    result = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs={"a": 1, "b": 2, "c": 3, "d": 4})
    assert len(result[0]) == 3
    assert len(result[1]) == 1


# Generated at 2022-06-21 11:38:53.982748
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class Session:
        @dataclasses.dataclass
        class Data:
            time: str

        @dataclasses.dataclass
        class _Request:
            data: Data
            http_method: str

        @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
        class Request(_Request):
            random_number: int = dataclasses.field(metadata={"metadata_key":
                                                                 "some data"})

        @dataclasses.dataclass
        class _Response:
            code: int


# Generated at 2022-06-21 11:39:05.740385
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from marshmallow import post_load

    @dataclasses.dataclass()
    class _TestClass:
        field1: str
        field2: str

        @post_load
        def post_load(self, data, **kwargs):
            return _TestClass(**data)

    @dataclasses.dataclass()
    class _TestClassWithUndefinedParameters:
        field1: str
        field2: str
        undefined_field: int = 5

        @post_load
        def post_load(self, data, **kwargs):
            return _TestClassWithUndefinedParameters(**data)

    @dataclasses.dataclass()
    class _TestClassWithUndefinedParametersAndExtraField:
        field1: str
        field2: str
        undefined_field: int = 5


# Generated at 2022-06-21 11:39:11.953952
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    """
    This test is needed because the testing is done by altering the class
    __init__ method.
    As a consequence, the test will only detect errors in the refactored
    __init__ method,
    not in the original one.
    """
    from unittest import TestCase, mock

    class TestClass:
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    @dataclasses.dataclass
    class TestDataClass:
        foo: str
        bar: str

    @dataclasses.dataclass
    class TestDataClassWithValidChecks:
        foo: str
        bar: str

        def __post_init__(self):
            if self.foo != self.bar:
                raise ValueError("foo must equal bar")


# Generated at 2022-06-21 11:39:16.808388
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: int, b: int):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(A, {"a": 1, "b": 2}) == {"a": 1, "b": 2}
    try:
        _RaiseUndefinedParameters.handle_from_dict(A, {"a": 1, "b": 2, "c": 3})
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-21 11:39:18.469847
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # Arrange

    # Act
    # Assert
    pass


# Generated at 2022-06-21 11:39:26.464849
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class A:
        def __init__(self, x: int) -> None:
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

    class B:
        def __init__(self, x: int) -> None:
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

    assert _UndefinedParameterAction.handle_dump(A(2)) == {}
    assert _UndefinedParameterAction.handle_dump(B(2)) == {}


# Generated at 2022-06-21 11:39:32.943077
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # type: () -> None
    class MyClass:
        pass
    assert _UndefinedParameterAction.handle_from_dict(
        cls=MyClass,
        kvs={}) == {}

    class MyClass:
        def __init__(self, a: str, b: int = 1):
            pass
    assert _UndefinedParameterAction.handle_from_dict(
        cls=MyClass,
        kvs={"a": "value1", "b": 1}) == {"a": "value1", "b": 1}



# Generated at 2022-06-21 11:39:35.556382
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    # type: () -> None
    try:
        _UndefinedParameterAction()
    except TypeError:
        assert True
        return
    assert False

# Generated at 2022-06-21 11:39:46.578657
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, field_a: int, field_b: str, field_c: str = "foo"):
            self.field_a = field_a
            self.field_b = field_b
            self.field_c = field_c

    a = A(field_a=1, field_b="bar")

    assert _RaiseUndefinedParameters.handle_from_dict(A, {"field_a": 1,
                                                           "field_b": "bar"}) \
           == {"field_a": 1, "field_b": "bar"}

# Generated at 2022-06-21 11:39:48.225930
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class DummyClass:
        pass

    _UndefinedParameterAction.handle_from_dict(DummyClass, {})

# Generated at 2022-06-21 11:41:40.558806
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("I am an error") 
    assert(isinstance(error, ValidationError))

# Generated at 2022-06-21 11:41:42.715856
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    _ = _RaiseUndefinedParameters.handle_from_dict(
        cls=dataclasses.dataclass(), kvs={"a": 1, "b": 2})


# Generated at 2022-06-21 11:41:53.076901
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class _TestClass:
        def __init__(self, a, b, c, d=1):
            pass

    @dataclasses.dataclass
    class _TestClass2:
        a: int
        b: str
        c: int
        d: int = dataclasses.field(default=1)
        e: int = dataclasses.field(default_factory=lambda: 3)

    def test_class_with_zero_arg_init():
        @dataclasses.dataclass
        class _ZeroArgInitClass:
            pass

        _IgnoreUndefinedParameters.create_init(_ZeroArgInitClass)
        _ZeroArgInitClass()


# Generated at 2022-06-21 11:42:00.288152
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    nocatchall_dict = {"some_field": 1, "other_field": 2}
    assert _CatchAllUndefinedParameters.handle_dump(nocatchall_dict) == {}

    class WithCatchAll:
        def __init__(self, some_field: int,
                     other_field: int,
                     catchall: Optional[CatchAllVar] = None):
            self.some_field = some_field
            self.other_field = other_field
            self.catchall = catchall or {}

    withcatchall_dict = WithCatchAll(1, 2, {"some_field": 3})
    assert _CatchAllUndefinedParameters.handle_dump(withcatchall_dict) == {
               "some_field": 3}

# Generated at 2022-06-21 11:42:03.092200
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A(object):
        pass
    a = A()
    A.__init__ = _RaiseUndefinedParameters.create_init(A)
    assert a is not None

# Generated at 2022-06-21 11:42:05.353394
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # TODO
    pass

# Generated at 2022-06-21 11:42:14.322138
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

    result = _UndefinedParameterAction.handle_from_dict(TestClass,
                                                        {'a': 1})
    assert result == {'a': 1}

    result = _UndefinedParameterAction.handle_from_dict(TestClass,
                                                        {'a': 1, 'b': 3})
    assert result == {'a': 1, 'b': 3}

    result = _UndefinedParameterAction.handle_from_dict(TestClass,
                                                        {'a': 1, 'b': 3, 'c': 4})
    assert result == {'a': 1, 'b': 3}



# Generated at 2022-06-21 11:42:26.263930
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class_fields = [
        Field("a", type = int),
        Field("b", type = int, default = 0),
        Field("c", type = int),
        Field("d", type = int)
    ]

    def get_parameters(class_fields, kvs):
        def get_parameter_names():
            # noinspection PyListCreation
            parameter_names = []
            for field in class_fields:
                if field.has_default_factory():
                    parameter_names.append(field.name)
            return parameter_names

# Generated at 2022-06-21 11:42:29.517132
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    # noinspection PyProtectedMember
    assert _CatchAllUndefinedParameters.create_init(
        _CatchAllUndefinedParameters)(
        None) is not None

# Generated at 2022-06-21 11:42:30.866931
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # type: () -> None
    UndefinedParameterError("Description")