

# Generated at 2022-06-21 11:34:35.445321
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        a: str
        b: str
        c: str

    class TestClassExclude:
        a: str
        b: str
        c: str

        def __init__(self, a: str, b: str, c: str, **kwargs):
            pass

    class TestClassWithCatchAll:
        a: str
        b: str
        c: str

        # Type ignored because mypy does not know about dataclasses.
        catch_all: Optional[CatchAllVar] = None  # type: ignore

    t = TestClass("a", "b", "c")


# Generated at 2022-06-21 11:34:41.482256
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters(): # pylint: disable=unused-variable
    # noinspection PyMissingOrEmptyDocstring
    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        weight: float

        def __post_init__(self) -> None:
            self.name = "Bob"
            self.age = 5

    p = Person("Sam", 5, 50)
    # This raises an exception because the post-init function would remove
    # the name attribute
    with pytest.raises(UndefinedParameterError):
        dataclasses_json.undefined(_IgnoreUndefinedParameters).encode(p)

# Generated at 2022-06-21 11:34:51.212778
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass(eq=True)
    class TestClass:
        test_field: str

        def __init__(self, test_field: str, unknown_field: str):
            self.test_field = test_field

    func = _IgnoreUndefinedParameters.create_init(TestClass)
    obj = TestClass("test_field", "unknown_field")
    expected = TestClass("test_field", "unknown_field")

    result = func(obj, "test_field", "unknown_field")

    assert id(result) == id(obj)
    assert result == expected

# Generated at 2022-06-21 11:34:54.368423
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class Test:
        def __init__(self, something, **kwargs):
            self.something = something

    init = _IgnoreUndefinedParameters.create_init(Test)
    obj = init(None, 0, a=1, b=2, c=3, d=4, e=5, f=6, g=7)
    assert obj.something == 0
    assert list(vars(obj).keys()) == ['something']



# Generated at 2022-06-21 11:34:55.621462
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Test")
    except UndefinedParameterError as e:
        assert e.args[0] == "Test"

# Generated at 2022-06-21 11:34:58.007382
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class A:
        pass

    class B:
        pass

    assert _UndefinedParameterAction.handle_dump(A) == {}
    assert _UndefinedParameterAction.handle_dump(B) == {}

# Generated at 2022-06-21 11:35:04.695561
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class C:
        a: int

    @dataclasses.dataclass
    class D:
        a: int

    class E:
        def __init__(self, a: int, *args, **kwargs):
            self.a = a

    def f(a: int, *args, **kwargs):
        return a

    class G:
        def __init__(self, a: int, b: int, *args, **kwargs):
            self.a = a
            self.b = b

    kvs = {"a": 5, "b": 6}
    assert _IgnoreUndefinedParameters.handle_from_dict(C, kvs) == {"a": 5}
    assert _IgnoreUndefinedParameters.handle_from_dict(D, kvs) == {"a": 5}
    assert _Ignore

# Generated at 2022-06-21 11:35:08.953990
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a, c, b=2, **kwargs):
            pass

    init = _IgnoreUndefinedParameters.create_init(A)

# Generated at 2022-06-21 11:35:17.406828
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class MyClass:
        pass
    my_class = MyClass()
    assert isinstance(_UndefinedParameterAction.create_init(my_class),
                      Callable)
    assert \
        _UndefinedParameterAction.handle_from_dict("MyClass",
                                                   {"foo": "bar"}) == \
        {"foo": "bar"}
    assert \
        _UndefinedParameterAction.handle_to_dict(my_class,
                                                 {"foo": "bar"}) == \
        {"foo": "bar"}
    assert _UndefinedParameterAction.handle_dump(my_class) == {}



# Generated at 2022-06-21 11:35:27.967592
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    This test ensures that the method _UndefinedParameterAction.create_init
    correctly wraps the __init__ method of the class
    """

    class A:
        def __init__(self, a, b, c=2, d=3, e=4, f=6, g=6, h=6):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
            self.g = g
            self.h = h

    a = A(5, 6, 7, 8)
    # a should be initialized with d=3 and f=6
    assert a.a == 5
    assert a.b == 6
    assert a.c == 7
    assert a.d == 8
    assert a.e

# Generated at 2022-06-21 11:35:52.384292
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction.create_init(None)
        raise AssertionError(
            f"UndefinedParameterAction base class must not "
            f"have a 'create_init' method.")
    except AttributeError:
        pass

# Generated at 2022-06-21 11:35:55.453480
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('Foo')
    except UndefinedParameterError as e:
        assert e.args == ('Foo',)

# Generated at 2022-06-21 11:36:06.341130
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class MyClass:
        def __init__(self, defined_param, undefined_param):
            self.defined_param = defined_param
            self.undefined_param = undefined_param

    input_dict = {"defined_param": "hello", "undefined_param": "worold"}

    # check Raise
    try:
        # noinspection PyTypeChecker
        _UndefinedParameterAction.handle_from_dict(
            cls=MyClass, kvs=input_dict)
        assert False
    except UndefinedParameterError:
        assert True

    # check Ignore
    output_dict = _UndefinedParameterAction.handle_from_dict(
        cls=MyClass, kvs=input_dict)
    assert output_dict == {"defined_param": "hello"}

# Generated at 2022-06-21 11:36:14.950226
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str
        c: str
        d: int = 3

        def __init__(self, c: str, d: int = 3, **_):
            self.a = 5
            self.b = "Hello"
            self.c = c
            self.d = d

    init = _IgnoreUndefinedParameters.create_init(Foo)
    assert init(Foo, "hello", 4, x=2) == Foo(a=5, b="Hello", c="hello", d=4)

# Generated at 2022-06-21 11:36:21.743414
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class _CatchAllTestAccessor:
        some_dict: CatchAllVar = dataclasses.field(default_factory=dict)

    obj = _CatchAllTestAccessor()
    obj.some_dict["a"] = "yes"
    dumped = _CatchAllUndefinedParameters.handle_dump(
        obj)
    assert dumped == {"a": "yes"}

# Generated at 2022-06-21 11:36:27.410760
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    klass = dataclasses.make_dataclass("klass", [("a", int), ("b", str)])
    params = {"a": 1, "b": "x", "c": "y"}

    # test expected case
    _IgnoreUndefinedParameters.create_init(klass)(klass(**params))
    # test too many args
    try:
        _IgnoreUndefinedParameters.create_init(klass)(klass(**params, a=2))
    except TypeError as e:
        pass
    # test too many args and kwargs (args should be ignored)
    try:
        _IgnoreUndefinedParameters.create_init(klass)(klass(**params, a=2), 3)
    except TypeError as e:
        pass
    # test positional arguments
    _IgnoreUndefined

# Generated at 2022-06-21 11:36:39.718193
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    import marshmallow

    @dataclass
    class MyClass:
        undefined: CatchAllVar = dataclasses.field(
            init=False, default_factory=dict)
        defined: str = dataclasses.field(default="abc")

        def __init__(self, *args: Any, defined: str = "abc",
                     **kwargs: Any) -> None:
            MyClass.undefined = kwargs
            MyClass.defined = defined

        @marshmallow.post_dump
        def dump(self, data: Dict[Any, Any], **kwargs: Any) -> Dict[Any, Any]:
            if len(MyClass.undefined) > 0:
                data.update(MyClass.undefined)
            return data

    cls = MyClass

   

# Generated at 2022-06-21 11:36:46.365446
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass
    # noinspection PyUnusedLocal
    class TestClass:
        a: int
        b: int = dataclasses.field(init=False)
        c: str = dataclasses.field(default="foo")
        d: Optional[CatchAllVar] = dataclasses.field(default=CatchAll)

        def __init__(self, a: int, c: str, **kwargs):
            self.a = a
            self.c = c

    dump_result = _UndefinedParameterAction.handle_dump(TestClass(1, "hallo"))
    assert dump_result == {}


# Unit Test for method handle_from_dict of class _RaiseUndefinedParameters

# Generated at 2022-06-21 11:36:58.762275
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass
    from typing import NamedTuple

    @dataclass
    class TestDataClass:
        name: str
        age: int

    # noinspection PyProtectedMember
    raise_undefined_class = _RaiseUndefinedParameters()

    # This is necessary to pass the _UndefinedParameterAction ABC
    assert hasattr(raise_undefined_class, "handle_from_dict")
    assert hasattr(raise_undefined_class, "handle_to_dict")

    # test raise UndefinedParameterError during initialization
    with pytest.raises(UndefinedParameterError):
        raise_undefined_class.handle_from_dict(TestDataClass,
                                               {"name": "TestUser",
                                                "age": 20,
                                                "gender": "M"})

    #

# Generated at 2022-06-21 11:37:01.596510
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class A:
        def __init__(self):
            pass

    assert _CatchAllUndefinedParameters.handle_dump(A) == {}

# Generated at 2022-06-21 11:37:46.049089
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import abc
    import dataclasses
    import inspect
    import sys
    from typing import Any, Dict, Optional

    class Foo:
        def __init__(self, foo: str, bar: str,
                     baz: Optional[int] = 1):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    MissingType = dataclasses._MISSING_TYPE  # type: Any


# Generated at 2022-06-21 11:37:46.742586
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass #TODO

# Generated at 2022-06-21 11:37:55.203195
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class MyTestClass:
        catch_all: Optional[CatchAllVar] = None

    test_obj = MyTestClass()

    expected = {}
    actual = _CatchAllUndefinedParameters.handle_dump(obj=test_obj)
    assert actual == expected

    test_obj.catch_all = {'a': 'b'}
    expected = {'a': 'b'}
    actual = _CatchAllUndefinedParameters.handle_dump(obj=test_obj)
    assert actual == expected



# Generated at 2022-06-21 11:37:56.223479
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError
    except ValidationError as e:
        pass

# Generated at 2022-06-21 11:37:58.389637
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    action = _UndefinedParameterAction()
    with pytest.raises(NotImplementedError):
        action.handle_from_dict(None, None)

# Generated at 2022-06-21 11:38:09.968194
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # Successful path
    class Successful:
        def __init__(self, a: int, b: int, c: int,
                     d: Undefined = Undefined.EXCLUDE):
            pass

    init_func = _IgnoreUndefinedParameters.create_init(Successful)
    init_func(Successful, 1, 2, 3, e=4)
    assert True

    # Should raise because too many arguments are given
    class TooMany:
        def __init__(self, a: int, b: int,
                     d: Undefined = Undefined.EXCLUDE):
            pass

    init_func = _IgnoreUndefinedParameters.create_init(TooMany)

# Generated at 2022-06-21 11:38:15.943790
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: Any
        b: Any = dataclasses.field(default_factory=dict)
        c: Any = "c"

    kvs = {"a": 1, "b": {"b4": 4}, "c": "c", "d": "d"}
    known = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)

    assert len(known) == 3
    assert known["a"] == 1
    assert isinstance(known["b"], dict)
    assert known["c"] == "c"



# Generated at 2022-06-21 11:38:22.639189
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, field_a, field_b, field_c, x=None):
            pass

    _UndefinedParameterAction.handle_from_dict(TestClass, dict())
    _UndefinedParameterAction.handle_from_dict(TestClass, dict(x=2))
    _UndefinedParameterAction.handle_from_dict(TestClass, dict(field_a=2))
    _UndefinedParameterAction.handle_from_dict(TestClass, dict(field_a=2,
                                                               x=3))



# Generated at 2022-06-21 11:38:29.223504
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, var: str,
                     undefined: _CatchAllUndefinedParameters = None):
            self.var = var
            self.undefined = undefined


    kvs: Dict[str, Any] = {"var": "test", "undefined": {"test": "test"}}
    params: Dict[str, Any] = _UndefinedParameterAction.handle_from_dict(
        TestClass, kvs)
    assert params == dict(var="test", undefined={"test": "test"})

# Generated at 2022-06-21 11:38:39.649762
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import sys

    class Foo:
        def __init__(self, a: str, b: str,
                     c: Optional[str] = None,
                     *, d: Optional[str] = None,
                     e: Optional[str] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

        def __eq__(self, other):
            return isinstance(other, Foo) and self.a == other.a and \
                   self.b == other.b and self.c == other.c and \
                   self.d == other.d and self.e == other.e

    modified_init = _CatchAllUndefinedParameters.create_init(Foo)

# Generated at 2022-06-21 11:39:36.746247
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: str
        catch_all: Optional[CatchAllVar] = None

    kvs = {'bar': 'Baz', 'catch_all': {'baz': 'Baz'}}
    result = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs)
    assert 'catch_all' in result
    assert result['catch_all'] == {'baz': 'Baz'}

    kvs = {'bar': 'Baz', 'baz': 'baz', 'qux': 'qux'}
    result = _CatchAllUndefinedParameters.handle_from_dict(Foo, kvs)
    assert 'catch_all' in result

# Generated at 2022-06-21 11:39:39.675614
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {"a": 1, "b": 2}
    assert _UndefinedParameterAction.handle_to_dict(None, kvs) == kvs



# Generated at 2022-06-21 11:39:40.534153
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    instance = _UndefinedParameterAction()
    assert isinstance(instance, _UndefinedParameterAction)

# Generated at 2022-06-21 11:39:43.523354
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    a = _UndefinedParameterAction()
    assert a.handle_dump(None) == {}
    assert a.handle_dump(1) == {}

# Generated at 2022-06-21 11:39:49.115683
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def original_init(self,
                      a: int = 0,
                      b: int = 1,
                      c: int = 3,
                      d: int = 4):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
    _IgnoreUndefinedParameters.create_init(original_init)(
        None, 1, b=4, e=5, f=6)

# Generated at 2022-06-21 11:40:00.641637
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A():
        def __init__(self, a: str, b: str=None, c: str=None):
            self.a = a
            self.b = b
            self.c = c

        def __eq__(self, other):
            if not isinstance(other, A):
                return False
            return self.a == other.a and self.b == other.b and self.c == other.c

    obj_a = A("a", "b")
    assert _IgnoreUndefinedParameters.handle_from_dict(
        A, {"a": "a", "b": "b", "c": "c"}) == {"a": "a", "b": "b", "c": "c"}

# Generated at 2022-06-21 11:40:11.950215
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses_json._UndefinedParameterAction import _RaiseUndefinedParameters
    from _dataclasses import dataclass
    from typing import Optional

    @dataclass(init=False)
    class T:
        foo: str = "bar"
        catch_all: Optional[CatchAll] = None

    T._undefined = Undefined.RAISE

    params1 = {"foo": "baz"}
    assert _RaiseUndefinedParameters.handle_from_dict(T, params1) == params1

    params2 = {"foo": "baz", "bar": "too"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(T, params2)

    assert T(**params1) == T(**params1)

# Generated at 2022-06-21 11:40:18.819907
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.undefined import Undefined

    from dataclasses import dataclass

    @dataclass()
    class A:
        defined_field: str
        catch_all: Undefined.INCLUDE.value

        def __post_init__(self):
            self.defined_field = self.defined_field.upper()

    a = A("Hello World", {"one": 1, "two": 2})
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj=a,
                                                      kvs=a.__dict__)
    assert a.defined_field == "HELLO WORLD"
    assert a.catch_all == {"one": 1, "two": 2}

# Generated at 2022-06-21 11:40:30.820050
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    # type: () -> None
    class A:

        def __init__(self, a: int, b: int, c: int,
                     catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

        def to_dict(self, letter_case: LetterCase = LetterCase.CAMEL) -> Dict:
            kvs = dataclasses.asdict(self)
            kvs = _CatchAllUndefinedParameters.handle_to_dict(self, kvs)
            kvs = apply_letter_case_to_dict(letter_case, kvs)
            return kvs

    a = A(a=1, b=2, c=3, catch_all={"d": 4})
    assert a

# Generated at 2022-06-21 11:40:34.968013
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # type: ()->None
    _RaiseUndefinedParameters.handle_from_dict(None, {})


# Generated at 2022-06-21 11:42:52.484465
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from marshmallow.schema import Schema

    from dataclasses_json import DataClassJsonMixin

    @dataclasses.dataclass
    class Data(DataClassJsonMixin):
        _extra: CatchAllVar = dataclasses.field(default_factory=dict)
        attr1: str
        attr2: int = dataclasses.field(metadata={'marshmallow_field':
                                                 fields.Int(validate=lambda
                                                             n: n >= 0)})

    assert Data._extra == dict()

    d = Data("a", 1)
    assert d.attr1 == "a" and d.attr2 == 1
    assert d._extra == dict()

    d = Data("a", 1, _extra={"catch_all": "x"})

# Generated at 2022-06-21 11:42:58.149248
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        a: int = dataclasses.field(metadata={'json_key': 'A'})
        b: int = dataclasses.field(metadata={'json_key': 'B'})

    assert _IgnoreUndefinedParameters.handle_from_dict(MyClass,
                                                       {'A': 1, "B": 2}) == {
        'a': 1, 'b': 2}

    assert _IgnoreUndefinedParameters.handle_from_dict(MyClass, {
        'A': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-21 11:42:58.971880
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    result = _UndefinedParameterAction.handle_dump(None)
    assert result == {}

# Generated at 2022-06-21 11:43:06.551833
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import json
    import os
    from dataclasses_json.api import dump, load

    # this is the class under test
    from_json = os.path.join(os.path.dirname(__file__),"tests","person.json")
    with open(from_json, "r") as f:
        json_string = f.read()
    person = load(Person, json_string)

    kvs = {}
    _CatchAllUndefinedParameters.handle_to_dict(obj=person, kvs=kvs)
    serialized = json.dumps(kvs)

    # this is the class under test
    from_json = os.path.join(os.path.dirname(__file__),"tests","person.json")
    with open(from_json, "r") as f:
        json_string

# Generated at 2022-06-21 11:43:15.647287
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # noinspection PyTypeChecker
    @dataclasses.dataclass
    class TestUndefinedParameter(abc.ABC):
        foo: int
        _undefined_parameters: _UndefinedParameterAction = \
            _RaiseUndefinedParameters

        @classmethod
        def from_dict(cls, kvs: Dict) -> "TestUndefinedParameter":
            pass

    expected = {"foo": 1,
                "bar": 2}
    # noinspection PyTypeChecker
    result = TestUndefinedParameter._undefined_parameters \
        .handle_from_dict(TestUndefinedParameter, expected)
    assert result == expected

    # noinspection PyTypeChecker
    expected = {"foo": 1,
                "bar": 2,
                "bar2": 3}
    # noinspection PyTypeChecker


# Generated at 2022-06-21 11:43:21.533017
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():

    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    @dataclasses_json.config(unknown=Undefined.EXCLUDE)
    class A:
        a: str
        b: str

    expected_init = A.__init__
    new_init = _UndefinedParameterAction.create_init(A)
    assert new_init is expected_init

    @dataclasses.dataclass
    @dataclasses_json.config(unknown=Undefined.INCLUDE)
    class A:
        a: str
        b: str
        c: dataclasses_json.CatchAll = dataclasses.field(default_factory=dict)

    expected_init = A.__init__

# Generated at 2022-06-21 11:43:32.001020
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_init(self, a: int, b: int, c: int = 2, d: int = 4,
                  e: Optional[CatchAllVar] = None, f: int = 1) -> None:
        pass

    k = _CatchAllUndefinedParameters._get_catch_all_field
    assert k.__name__ == "_CatchAllUndefinedParameters._get_catch_all_field"
    test_init_ignored = _IgnoreUndefinedParameters.create_init(test_init)
    assert test_init_ignored.__name__ == "test_init"

    signature = inspect.signature(test_init)
    parameters = signature.parameters
    expected_parameter_order = ["self", "a", "b", "c", "d", "e", "f"]
    actual_parameter_

# Generated at 2022-06-21 11:43:36.678258
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass
    class Tmp:
        a: int
        b: int
        catch_all: Optional[CatchAllVar] = None
        # This has to be the last field.

    to_dict = _CatchAllUndefinedParameters.handle_to_dict

    obj = Tmp(1, 2, dict(x=9, y=10))
    output = to_dict(obj, dict())
    assert output == dict(a=1, b=2, x=9, y=10)

    # Undefined parameters that have the same name as a defined parameter
    # will overwrite the defined parameter
    obj2 = Tmp(1, 2, dict(x=9, b=10, y=15))

# Generated at 2022-06-21 11:43:42.261912
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Dummy:
        def __init__(self, x: int, y: Optional[str] = None):
            assert x == 1
            assert y == "y"

    dummy = Dummy(1, y="y")
    _obj = _IgnoreUndefinedParameters
    dummy_init = _obj.create_init(dummy)
    dummy_init(dummy, x=1, y="y")

# Generated at 2022-06-21 11:43:45.553546
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert isinstance(_RaiseUndefinedParameters.handle_from_dict(object, {}),
                      dict) is True

