

# Generated at 2022-06-21 11:34:34.499838
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    """
    This function tests that _IgnoreUndefinedParameters.create_init() wraps
    the original __init__ function
    in a way that it ignores parameters that do not correspond to
    class attributes.
    """

    class MyClass:
        def __init__(self, a: int, b: str = "hello", c: int = 1):
            self.a = a
            self.b = b
            self.c = c

    assert isinstance(MyClass.__init__, functools.wraps)

    init_ignore = _IgnoreUndefinedParameters.create_init(MyClass)
    my_obj = MyClass(1, b=2)
    init_ignore(my_obj, 5, b=7, d=20)
    assert my_obj.a == 1
    assert my_obj.b == 2


# Generated at 2022-06-21 11:34:45.499470
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class SampleClass:
        def __init__(self, param1, param2, param3, param4):
            self.param1 = param1
            self.param2 = param2
            self.param3 = param3
            self.param4 = param4

    class NoUndefinedTestClass(SampleClass):
        UNDEFINED = Undefined.EXCLUDE

    class UnknownTestClass(SampleClass):
        UNDEFINED = Undefined.RAISE

    class IncludeTestClass(SampleClass):
        UNDEFINED = Undefined.INCLUDE
        undefined: Optional[CatchAllVar] = None

    # Test class which allows undefined parameters and receives undefined
    # parameters.

# Generated at 2022-06-21 11:34:54.912422
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(
        init=False,
        undefined=Undefined.INCLUDE)
    class Dummy:
        no_default: int
        default: str = "default"
        default_factory: str = dataclasses.field(default_factory=lambda: "hi")

    # This seems silly to test but it was added because I had
    # a bug in _CatchAllUndefinedParameters.create_init where
    # I deleted the case which captures the correct number of
    # arguments and passed them on.
    # If you delete the corresponding case in create_init this test fails.
    Dummy(no_default=123)

# Generated at 2022-06-21 11:35:02.282630
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import pytest

    class A:
        def __init__(self, x: int, y: int = 2, z: int = 3):
            pass

    class B:
        def __init__(self, x: int, y: int, z: int = 3):
            pass

    class C:
        def __init__(self, x: int, y: int, z: int):
            pass

    class D:
        def __init__(self, x: int, *args):
            pass

    def run_create_init_test(cls, kwargs, expected_kwargs):
        ignore_init = _IgnoreUndefinedParameters.create_init(cls)
        inst = cls(**kwargs)

        # The created function should have the same name as the original one
        assert ignore_init.__name

# Generated at 2022-06-21 11:35:11.106199
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, a: str, b: int, c: float, catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all

    obj = TestClass("a", 1, 2.5)
    kvs = {"b": 1, "a": "a", "c": 2.5}
    kvs_result = _UndefinedParameterAction.handle_to_dict(obj, kvs)

    if kvs_result != kvs:
        raise AssertionError("kvs and kvs_result differ.")



# Generated at 2022-06-21 11:35:22.614667
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import attr
    @attr.s(auto_attribs=True)
    class _Test(object):
        a: int
        b: int = attr.ib(default=5, kw_only=True)
        c: Optional[CatchAllVar] = attr.ib(default=None, kw_only=True)

        def __init__(self, a, b=10, c=None):
            self.a = a
            self.b = b
            self.c = c

    def test_from_dict(cls):
        known, unknown = \
            _UndefinedParameterAction._separate_defined_undefined_kvs(
                cls=cls, kvs={"a": 1, "b": 2, "e": 5})

# Generated at 2022-06-21 11:35:25.253551
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, existing_parameter, *,
                     existing_optional_parameter: str = "default") -> None:
            pass

# Generated at 2022-06-21 11:35:28.483049
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_to_dict({}, {}) == {}
    assert _RaiseUndefinedParameters.handle_dump({}) == {}
    assert _RaiseUndefinedParameters.create_init(object) == object.__init__



# Generated at 2022-06-21 11:35:36.890789
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert isinstance(_UndefinedParameterAction, abc.ABCMeta)

    u = _UndefinedParameterAction()
    with pytest.raises(AttributeError) as excinfo:
        u.handle_from_dict(None, None)
    assert str(excinfo.value) == "Can't call abstract method"

    with pytest.raises(AttributeError) as excinfo:
        u.create_init(None)
    assert str(excinfo.value) == "Can't call abstract method"

    with pytest.raises(AttributeError) as excinfo:
        u.handle_to_dict(None, None)
    assert str(excinfo.value) == "Can't call abstract method"

    with pytest.raises(AttributeError) as excinfo:
        u.handle_dump(None)

# Generated at 2022-06-21 11:35:47.435029
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class ExampleClass():
        test: str = "Hello"
        _catch_all: Any = dataclasses.field(metadata={"undefined": Undefined.INCLUDE})

    @dataclasses.dataclass
    class NotAClass():
        pass
    # Should not raise an error
    _UndefinedParameterAction.handle_from_dict(ExampleClass,
                                               {"test": "World"})
    try:
        _UndefinedParameterAction.handle_to_dict(ExampleClass, {"test": "World"})
        raise AssertionError("Should have raised error")
    except NotImplementedError:
        pass

# Generated at 2022-06-21 11:36:02.481524
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    class A:
        def __init__(self, a: Optional[dataclasses_json.CatchAllVar] = None):
            self.a = a
    test_obj = A(a={})
    assert _CatchAllUndefinedParameters.handle_dump(obj=test_obj) == {}
    test_obj = A(a={'1':2})
    assert _CatchAllUndefinedParameters.handle_dump(obj=test_obj) == {'1':2}

# Generated at 2022-06-21 11:36:11.021827
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyClass:
        a: str = "default"
        b: int = 2

    assert _CatchAllUndefinedParameters.handle_from_dict(MyClass,
                                                         {"a": "somevalue",
                                                          "c": "someother"}) == {
               "a": "somevalue"}
    assert _CatchAllUndefinedParameters.handle_from_dict(MyClass,
                                                         {"b": 3,
                                                          "c": "someother"}) == {
               "b": 3}
    assert _CatchAllUndefinedParameters.handle_from_dict(MyClass,
                                                         {"a": "somevalue",
                                                          "b": 3}) == {
               "a": "somevalue", "b": 3}


# Unit test

# Generated at 2022-06-21 11:36:20.288366
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import typing

    class TestClass:
        def __init__(self, a, b, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

        @classmethod
        def get_known_parameters(cls):
            return {name: True for name in
                    ("a", "b", "c", "d")}

    test_class_init = TestClass.__init__
    new_class_init = \
        _CatchAllUndefinedParameters.create_init(cls=TestClass)
    assert test_class_init != new_class_init

    test_class_init_signature = inspect.signature(test_class_init)

# Generated at 2022-06-21 11:36:29.951059
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class IgnoreDummy:
        def __init__(self, known1: int, known3: int,
                     ignore1: int, ignore2: int):
            pass

    kvs = {
        "known1": 1,
        "ignore1": 2,
        "unknown": 3,
        "ignore2": 4,
        "known3": 5
    }
    expected = {
        "known1": 1,
        "ignore1": 2,
        "ignore2": 4,
        "known3": 5
    }

    assert (expected ==
            _IgnoreUndefinedParameters.handle_from_dict(cls=IgnoreDummy,
                                                         kvs=kvs))



# Generated at 2022-06-21 11:36:38.743638
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    kvs = {"a": "test1", "b": "test2",
           "c": {"test": "test3"}, "d": 42, "_UNKNOWN1": "test4",
           "e": {"test": "test5"}}
    known_given_parameters, _ = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(None, kvs)
    assert known_given_parameters == {"a": "test1", "b": "test2",
                                      "c": {"test": "test3"}, "d": 42}



# Generated at 2022-06-21 11:36:40.900038
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Unit test for constructor of class UndefinedParameterError
    """
    UndefinedParameterError("a message")

# Generated at 2022-06-21 11:36:53.690897
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, one: str, two: Optional[int]=None):
            self.one = one
            self.two = two

    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, kvs={"one": "test", "two": 2}) == {"one": "test", "two": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, kvs={"one": "test", "two": 2, "three": 3}) == \
           {"one": "test", "two": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, kvs={"one": "test"}) == {"one": "test"}

# Generated at 2022-06-21 11:37:05.279606
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, a: int = 0, b: int = 0, c: int = 0, d: int = 0,
                     e: int = 0, f: int = 0, g: int = 0, h: int = 0,
                     i: int = 0, j: int = 0, k: int = 0, **kwargs) -> None:
            pass

    init_method = _CatchAllUndefinedParameters.create_init(TestClass)

    for num_args in range(100):
        # Generate args
        the_args = range(num_args)
        kwargs = {f"arg_{i}": i for i in range(num_args, num_args + 100)}

        # Run the init method
        init_method(None, *the_args, **kwargs)

# Generated at 2022-06-21 11:37:13.660363
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Given
    class TestClass:
        def __init__(self, a: int, b: str = "default",
                     **undefined_parameters) -> None:
            self.a = a
            self.b = b
            self.undefined_parameters = undefined_parameters

        def __eq__(self, other):
            return (self.a == other.a and self.b == other.b)

    known_kvs = {"a": 3, "b": "keyword"}
    kvs = known_kvs.copy()
    kvs.update({"c": "Dict-only"})

    # When
    result = _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=kvs)

    # Then
    assert result == known_kvs

    # When


# Generated at 2022-06-21 11:37:22.302459
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, field

    @dataclass
    class SuperDummy(_CatchAllUndefinedParameters):
        a: int
        b: int
        c: int
        _undefined: Dict[str, Any] = field(default_factory=dict)

    @dataclass
    class Dummy(SuperDummy):
        d: int

    @dataclass
    class ReallyDummy(SuperDummy):
        e: int
        f: int
        g: int

    def test_from_dict(cls, kvs: Dict[Any, Any], expected: Dict[str, Any]):
        returned = SuperDummy.handle_from_dict(cls=cls, kvs=kvs)
        assert returned == expected


# Generated at 2022-06-21 11:37:46.057451
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class C:
        a: str
        b: int
        c: str

    _IgnoreUndefinedParameters.create_init(C)(C, "a", "b", "c")

# Generated at 2022-06-21 11:37:57.186751
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    foo = "foo"

    class DummyClass(_UndefinedParameterAction):
        def __init__(self, foo: str):
            self.foo = foo

    instance = DummyClass(foo=foo)
    assert instance.foo == foo

    dump = _UndefinedParameterAction.handle_dump(instance)
    assert dump == {}

    class DummyClass(_CatchAllUndefinedParameters):
        def __init__(self, foo: str, catch_all: CatchAll = {}):
            self.foo = foo
            self.catch_all = catch_all

    instance = DummyClass(foo=foo)
    assert instance.foo == foo
    assert instance.catch_all == {}

    dump = _UndefinedParameterAction.handle_dump(instance)
    assert dump == instance.catch_all


# Generated at 2022-06-21 11:38:08.609719
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str

    data = {
        "a": 1,
        "b": "test",
        "c": 2
    }
    try:
        _RaiseUndefinedParameters.handle_from_dict(obj=TestClass, kvs=data)
        raise AssertionError("ValidationError not raised")
    except UndefinedParameterError:
        pass

    assert len(_IgnoreUndefinedParameters.handle_from_dict(
        obj=TestClass, kvs=data)) == 2

    assert len(_CatchAllUndefinedParameters.handle_from_dict(
        obj=TestClass, kvs=data)) == 3



# Generated at 2022-06-21 11:38:14.718439
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class Test:
        def __init__(self, a, b, c=1, *, d, e=2, **kwargs):
            pass

    d = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
    ctor = functools.partial(Test, **d)
    ctor()


if __name__ == "__main__":
    test__CatchAllUndefinedParameters()

# Generated at 2022-06-21 11:38:19.896130
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Foo:
        bar: int

    kvs = {"bar": 123, "foo": 456}
    expected = {"bar": 123}
    actual = _RaiseUndefinedParameters.handle_from_dict(Foo, kvs)
    assert actual == expected



# Generated at 2022-06-21 11:38:25.389765
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclasses.dataclass(frozen=True)
    class TestClass:
        a: int = 1
        catch_all: CatchAll = None
        # Use the catch-all field to handle undefined parameters

        def __post_init__(self):
            pass

    kvs = {"undefined_parameter": "42",
           "catch_all": {"undefined_parameter": "42"}}
    result = _CatchAllUndefinedParameters.handle_to_dict(
        TestClass(**kvs), kvs)
    assert "undefined_parameter" not in result



# Generated at 2022-06-21 11:38:26.692525
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-21 11:38:33.479325
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        defined_param: str = "test"
        undefined_param: Optional[CatchAllVar] = None

    test = TestClass(defined_param="test",
                     undefined_param={"undefined_param_1": "value_1",
                                      "undefined_param_2": "value_2"})

    kvs = {"defined_param": "test",
           "undefined_param": {"undefined_param_1": "value_1",
                               "undefined_param_2": "value_2"}}

    assert kvs == _CatchAllUndefinedParameters.handle_to_dict(test, kvs)

# Generated at 2022-06-21 11:38:38.688243
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        def __init__(self, a, b=2, **kwargs):
            pass

    # The normal init should not change
    assert _UndefinedParameterAction.create_init(Test) == Test.__init__

    # If another init function is returned, something went wrong
    assert _IgnoreUndefinedParameters.create_init(Test) != Test.__init__
    assert _CatchAllUndefinedParameters.create_init(Test) != Test.__init__

    # Normal cases
    assert _IgnoreUndefinedParameters.create_init(Test)(Test, 0, 1, c=3, d=4)
    assert _CatchAllUndefinedParameters.create_init(Test)(Test, 0, 1, c=3, d=4)

    # Ignoring parameters
    assert _IgnoreUndefinedParameters.create_init

# Generated at 2022-06-21 11:38:46.370338
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    bindings: Dict[str, Any] = {}

    class TestClass:
        def __init__(self, a: int, b: Optional[int] = None):
            bindings["a"] = a
            bindings["b"] = b

    _UndefinedParameterAction.create_init(obj=TestClass)(obj=TestClass, a=1,
                                                         b=2)
    assert bindings == {"a": 1, "b": 2}


# Generated at 2022-06-21 11:39:42.122216
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass:
        def __init__(self):
            pass

        def foo(self):
            pass

    cls = TestClass
    undefined_parameter_handler = _UndefinedParameterAction()
    assert cls.foo is undefined_parameter_handler.create_init(cls).foo
    assert cls.__init__ is undefined_parameter_handler.create_init(cls).__init__
    assert {} == undefined_parameter_handler.handle_dump(cls)
    assert {} == undefined_parameter_handler.handle_to_dict(cls, {1: 2})
    assert {} == undefined_parameter_handler.handle_from_dict(cls, {1: 2})

# Generated at 2022-06-21 11:39:53.237116
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from .abc_field_converters import FieldConverter
    from .abc_mapper import Mapper, MapperMetaclass
    from .abc_schema import Schema
    from .decoder import _populate_dataclass_from_dict
    from .encoder import _to_dict
    from dataclasses import dataclass, field
    from marshmallow.fields import String, List, Nested
    from marshmallow.schema import Schema as MarshmallowSchema
    import dataclasses_json
    import marshmallow as mm

    class TestSchema(Schema):
        class Meta:
            target_class = TestClass
            mapper_class = TestMapper

        field1 = String(required=True)
        field2 = String(missing="default")
        field3 = String()

# Generated at 2022-06-21 11:39:56.133322
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test_message")
    except UndefinedParameterError as e:
        assert str(e) == "test_message"

# Generated at 2022-06-21 11:39:59.037081
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("message")
    except UndefinedParameterError as e:
        assert str(e) == "message"
        assert e._field_names == []

# Generated at 2022-06-21 11:40:10.483049
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import pytest

    class Foo:
        def __init__(self, foo: int, bar: int):
            pass

    foo = Foo(foo=1, bar=2)

    init = _UndefinedParameterAction.create_init(foo)
    assert init == Foo.__init__

    init = _RaiseUndefinedParameters.create_init(foo)
    assert init == Foo.__init__

    init = _IgnoreUndefinedParameters.create_init(foo)
    assert init != Foo.__init__
    with pytest.raises(TypeError):
        init(foo)

    # a value that is not a class instance should also fail
    init = _IgnoreUndefinedParameters.create_init(1)
    assert init != Foo.__init__

# Generated at 2022-06-21 11:40:17.573957
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    from typing import Optional
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass(frozen=True)
    class CatchAllExample:
        a: int
        b: Optional[int] = None
        _undefined: Optional[CatchAllVar] = None

    ex = CatchAllExample(a=1, b=2, d=3)
    kvs = {"a": 1, "d": 3}
    transformed = _CatchAllUndefinedParameters.handle_to_dict(ex, kvs)
    assert transformed == {"a": 1, "d": 3}
    assert ex._undefined == {"d": 3}



# Generated at 2022-06-21 11:40:30.213312
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import pytest

    def test_class_with_catch_all_parameter(test_dict: CatchAll = None):
        pass

    def test_class_without_catch_all_parameter():
        pass

    def test_class_with_multiple_catch_all_parameter(
            test_dict_1: CatchAll = None, test_dict_2: CatchAll = None):
        pass

    test_dict = {"foo": "bar"}
    assert test_dict == \
           _CatchAllUndefinedParameters.handle_from_dict(
               cls=test_class_with_catch_all_parameter,
               kvs={"test_dict": test_dict, "foo": "bar"})

    with pytest.raises(UndefinedParameterError):
        _CatchAllUndefinedParameters.handle_from_

# Generated at 2022-06-21 11:40:41.782320
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    def check_kvs_against_fields(kvs_result: Dict, fields: Dict):
        for k in kvs_result:
            assert k in fields

    class Foo:
        def __init__(self, a: str, b: int) -> None:
            self.a = a
            self.b = b

    # Check that parameters are separated correctly into known and unknown.
    known_t, unknown_t = _UndefinedParameterAction._separate_defined_undefined_kvs(Foo, {"a": "a", "b": "b", "c": "c"})
    assert len(known_t) == 2
    assert len(unknown_t) == 1
    assert "a" in known_t and "b" in known_t and "c" not in known_t
    assert "c" in unknown

# Generated at 2022-06-21 11:40:50.538838
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass


    @dataclass
    class CatchAllTest:
        a: int
        b: int = 10

        def __post_init__(self):
            pass


    _CatchAllUndefinedParameters.handle_from_dict(CatchAllTest, {"a": 10})
    _CatchAllUndefinedParameters.handle_from_dict(CatchAllTest, {"a": 10,
                                                                  "b": 10,
                                                                  "c": 20})
    _CatchAllUndefinedParameters.handle_from_dict(CatchAllTest, {"a": 10,
                                                                  "c": 20})
    try:
        _CatchAllUndefinedParameters.handle_from_dict(CatchAllTest, {"c": 20})
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:41:01.052631
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    catch_all_field = CatchAll(default_factory=dict)
    class_fields = [Field("a", type=int),
                    Field("b", type=int),
                    Field("c", type=CatchAllVar, default=catch_all_field)]

    def mock_cls(**kwargs):
        return type("MOCK_CLASS", (object,), kwargs)

    basic_operation = {"a": 1, "b": 2, "c": dict()}
    class_dict = {"__annotations__": dict((f.name, f.type) for f in
                                          class_fields)}
    cls = mock_cls(**class_dict)

    result = _RaiseUndefinedParameters.handle_from_dict(cls=cls,
                                      kvs=basic_operation)

# Generated at 2022-06-21 11:43:16.304796
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # noinspection PyProtectedMember
    assert issubclass(dataclasses_json.Undefined.CATCHALL.value,
                      _CatchAllUndefinedParameters)
    catch_all_init = _CatchAllUndefinedParameters.create_init
    init = catch_all_init(TestClass)



# Generated at 2022-06-21 11:43:19.665401
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        x: int
        z: int
        __undefined__ = dataclasses_json.undefined.Undefined.INCLUDE

    init = _CatchAllUndefinedParameters.create_init(A)
    assert init is not A.__init__
    assert inspect.signature(init) == inspect.signature(A.__init__)



# Generated at 2022-06-21 11:43:30.529342
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import dataclasses

    @dataclasses.dataclass(frozen=True)
    class A:
        a: int
        b: int
        c: Optional[CatchAllVar]

    @dataclasses.dataclass(frozen=True)
    class B:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(default=dict)

    @dataclasses.dataclass(frozen=True)
    class C:
        a: int
        b: int
        c: Optional[CatchAllVar] = dataclasses.field(
            default_factory=lambda: dict())

    def _do_test(cls, kwargs, expected_value, expected_undefined):
        known_given_parameters, undefined_given_parameters

# Generated at 2022-06-21 11:43:34.258712
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, a: str, b: str = "b"):
            self.a = a
            self.b = b


    def b(self, *a):
        pass


    assert _UndefinedParameterAction.create_init(A) == A.__init__
    assert _UndefinedParameterAction.create_init(b) == b

# Generated at 2022-06-21 11:43:42.428445
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    """
    If a class is annotated with a method __post_init__,
    the defined parameter values may change after class initialization.
    """
    class Klass:
        def __post_init__(self):
            self.post_init_defined = 1
            self.post_init_undefined = 2

    klass = Klass()
    klass.post_init_undefined = None

    catch_all_dict = _CatchAllUndefinedParameters.handle_dump(klass)
    assert catch_all_dict["post_init_undefined"] == 2

# Generated at 2022-06-21 11:43:50.284589
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class _TestClass:
        def __init__(self, a: int, b: int = 1):
            pass

    kvs = {"a": 1, "b": 2, "c": 3}
    known_given_parameters = \
        _RaiseUndefinedParameters.handle_from_dict(_TestClass, kvs)
    assert len(known_given_parameters) == 2
    assert isinstance(known_given_parameters["a"], int)
    assert isinstance(known_given_parameters["b"], int)



# Generated at 2022-06-21 11:43:55.272810
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, a=1):
            self.a = a
            self.b = 1
            self.c = 1
    test_instance = TestClass()
    assert _CatchAllUndefinedParameters.handle_to_dict(
        test_instance,
        {
            "a": 1,
            "b": 1,
            "c": 1,
            "d": 1
        }
    ) == {
        "a": 1,
        "b": 1,
        "c": 1,
    }

# Generated at 2022-06-21 11:43:58.735718
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass
    init_fct = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init_fct(TestClass, 1, 2, 3) == None
    assert init_fct(TestClass) == None
    assert init_fct(TestClass, a=1, b=2) == None
    assert init_fct(TestClass, a=1, b=2, z=3) == None

# Generated at 2022-06-21 11:44:08.642573
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    import abc
    import dataclasses
    import dataclasses_json
    import pytest


    @dataclasses.dataclass
    class TestClass:
        # does not matter what type is here
        included_field: Any
        catch_all: dataclasses_json.CatchAll = None


    inputs = [
        {"included_field": "some_value", "catch_all": "some_value"},
        {"included_field": "some_value", "not_in_class": "some_value"},
        {"not_in_class": "some_value"},
        {}
    ]
    expected_outputs = [
        {"included_field": "some_value", "catch_all": {}},
        {"included_field": "some_value"},
        {}
    ]


# Generated at 2022-06-21 11:44:18.647229
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(frozen=True)
    class X:
        param1: str
        param2: int
        # CatchAllVar = Optional[Dict[str, Any]]
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    # no undefined parameters
    kvs: Dict[str, Any] = {"param1": "asdf", "param2": 23}
    defined, unknown = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        X, kvs)
    assert defined == kvs
    assert unknown == {}
    result = _CatchAllUndefinedParameters.handle_from_dict(X, kvs)