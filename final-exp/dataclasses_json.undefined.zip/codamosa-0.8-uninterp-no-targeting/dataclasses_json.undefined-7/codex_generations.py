

# Generated at 2022-06-21 11:34:37.222711
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def assert_does_not_raise(*args, **kwargs):
        pass

    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    TestClass.__init__ = \
        _IgnoreUndefinedParameters.create_init(TestClass)()
    assert_does_not_raise(TestClass, a=1, b=2)
    assert_does_not_raise(TestClass, 1, 2, 3, 4, 5, a=1, b=2)
    assert_does_not_raise(TestClass, 1, 2, b=2, _UNKNOWN=1)
    assert_does_not_raise(TestClass, a=1, b=2, _UNKNOWN=1)



# Generated at 2022-06-21 11:34:37.775912
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-21 11:34:39.251376
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError("message")
    assert e.messages == ["message"]

# Generated at 2022-06-21 11:34:51.977552
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass, field

    @dataclass
    class TestClass:
        field1: str
        field2: int
        field3: Optional[CatchAllVar] = field(default=None)

        def __init__(self, field1: str, field2: int,
                     field3: Optional[CatchAllVar] = None):
            self.field1 = field1
            self.field2 = field2
            self.field3 = field3

    obj = TestClass("field1value", 2, {"field3key": "field3value"})
    expected_dump = {"field1key": "field1value", "field2key": 2,
                     "field3key": "field3value"}
    assert _CatchAllUndefinedParameters.handle_dump(obj) == expected_dump


# Generated at 2022-06-21 11:34:57.290260
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    """
    This test is currently not executed automatically
    when running `pytest` as we don't want to import
    the module in `conftest.py`.
    :return:
    """
    # noinspection PyUnresolvedReferences
    # pylint: disable=no-member,unsubscriptable-object
    from dataclasses_json.utils import CatchAllVar

    class TestClass1:

        def __init__(self, field1: int, aux: CatchAllVar = None):
            # type: (int, CatchAll) -> None
            self.field1 = field1
            self.aux = aux

    # noinspection PyUnresolvedReferences
    init = _CatchAllUndefinedParameters.create_init(TestClass1)
    obj = TestClass1(field1=123)

# Generated at 2022-06-21 11:35:03.729685
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: Any = dataclasses.field(default=None)
        catch_all: Optional[CatchAllVar] = \
            dataclasses.field(default_factory=dict,
                              metadata=dataclasses_json.config(
                                  undefined=Undefined.EXCLUDE))

        def __init__(self, a: Any, catch_all: Optional[CatchAllVar] = None):
            pass

    test_init = TestClass.__init__
    test_class = TestClass
    new_init = _CatchAllUndefinedParameters.create_init(test_class)
    assert new_init(self=None, a=None) is None



# Generated at 2022-06-21 11:35:13.013130
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class NoUndefinedParameterInit:
        def __init__(self, a: str, b: str, c: Optional[int] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = "not init"

    class WithUndefinedParameterInit:
        def __init__(
                self, a: str, b: str, c: Optional[int] = None,
                *,
                d: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d


# Generated at 2022-06-21 11:35:22.667324
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Foo:
        a:int
        b:int
        c:int

    original_init = Foo.__init__
    init_signature = inspect.signature(original_init)
    new_init = _IgnoreUndefinedParameters.create_init(obj=Foo)
    assert new_init.__signature__ == init_signature
    assert new_init(Foo(a=1, b=2, c=3), d=4, e=5) == \
           original_init(Foo(a=1, b=2, c=3), d=4, e=5)



# Generated at 2022-06-21 11:35:31.359719
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # Test default operation
    @dataclasses.dataclass
    class TestDefault:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

    class_fields = fields(TestDefault)

    obj = TestDefault()

    kvs_test_default = _CatchAllUndefinedParameters.handle_from_dict(
        TestDefault,
        {"catch_all": {"hello": True}})
    assert kvs_test_default == {
        k.name: k.default for k in class_fields}
    obj = TestDefault(**kvs_test_default)
    assert obj.catch_all == {}

    default_value = _CatchAllUndefinedParameters._get_default(
        catch_all_field=class_fields[0])

    kvs_test

# Generated at 2022-06-21 11:35:36.861565
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    kvs = dict(a = 1, _b = 2, c = 3)
    class_fields = ['a']
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        class_fields, kvs)
    assert known['a'] == 1
    assert unknown.get('b') is None
    assert unknown.get('_b') == 2
    assert unknown.get('c') == 3

# Generated at 2022-06-21 11:36:01.322166
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class Test(DataClassJsonMixin):
        a: int
        b: str
        undefined_parameters: CatchAll = None

    @config(unknown=Undefined.INCLUDE)
    class TestConfigCatchall(Test):
        pass

    @config(unknown=Undefined.RAISE)
    class TestConfigRaise(Test):
        pass

    @config(unknown=Undefined.EXCLUDE)
    class TestConfigNoUndefined(Test):
        pass

    @dataclass
    class TestNoCatchAll(DataClassJsonMixin):
        a: int
        b: str


# Generated at 2022-06-21 11:36:08.551673
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    if not False:
        class Foo:
            def __init__(self, a=1, b=2, c=3):
                pass

        init = _UndefinedParameterAction.create_init(Foo)
        init(Foo(3, 5), 6, 7, 8)

    if False:
        class Foo:
            def __init__(self, a=1, b=2, c=3):
                pass

        init = _UndefinedParameterAction.create_init(Foo)
        init(Foo(3, 5), 6, 7, 8)

# Generated at 2022-06-21 11:36:15.201395
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, b: str):
            self.b = b

    assert _RaiseUndefinedParameters.handle_from_dict(
        A, {"b": "test"}) == {"b": "test"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(A, {"a": "test"})
        assert False
    except UndefinedParameterError:
        assert True



# Generated at 2022-06-21 11:36:19.901946
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Klass:
        x: int = 1

    _IgnoreUndefinedParameters.handle_from_dict(Klass, dict()) == dict()
    _IgnoreUndefinedParameters.handle_from_dict(Klass, dict(y=1)) == dict()
    _IgnoreUndefinedParameters.handle_from_dict(Klass, dict(x=1, y=1)) == dict(
        x=1)

# Generated at 2022-06-21 11:36:27.469206
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect

    class TestClass:
        def __init__(self, a: int, b: int, c: int, catch_all: Optional[CatchAllVar] = None):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init.__name__ == "__init__"

# Generated at 2022-06-21 11:36:39.777483
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest
    import marshmallow

    # This is an example of a class with a catch-all field
    @dataclasses.dataclass
    class Fields:
        field1: str
        field2: int
        field3: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAllVar())

    @dataclasses.dataclass
    class InvalidFieldName:
        field1: str
        field2: int
        field3: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAllVar(default="hello world"))
        field3_invalid_name: int = 123

    @dataclasses.dataclass
    class InvalidDefault:
        field1: str
        field2: int
        field3: Optional[CatchAllVar] = dataclasses

# Generated at 2022-06-21 11:36:51.972048
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class SimpleObject:
        def __init__(self, a, b, c=3):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(
        SimpleObject, kvs=dict(a=1, b=2, c=9)) == dict(a=1, b=2, c=9)
    assert _RaiseUndefinedParameters.handle_from_dict(
        SimpleObject, kvs=dict(a=1, b=2)) == dict(a=1, b=2)
    assert _RaiseUndefinedParameters.handle_from_dict(
        SimpleObject, kvs=dict(a=1, b=2, d=9)) == dict(a=1, b=2)

# Generated at 2022-06-21 11:36:58.698608
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses

    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class ExampleClass:
        a: int
        b: int

    e = ExampleClass(3, 4, c=10)
    assert e.a == 3
    assert e.b == 4

    e = ExampleClass(3, 4, a=5, c=10)
    assert e.a == 5
    assert e.b == 4

    e = ExampleClass(3, 4, b=5, c=10)
    assert e.a == 3
    assert e.b == 5


# Generated at 2022-06-21 11:37:06.974578
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from marshmallow import Schema, fields

    class Person:
        def __init__(self, name, last_name):
            self.name = name
            self.last_name = last_name

    class PersonSchema(Schema):
        name = fields.Str()
        last_name = fields.Str()

    schema = PersonSchema()
    p = Person(name="John", last_name="Doe")
    data = schema.dump(p)
    assert data == {"name": "John", "last_name": "Doe"}

# Generated at 2022-06-21 11:37:13.512691
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class DummyClass:
        catch_all: CatchAll

    original_dict = {"catch_all": {"some_parameter": "value"},
                     "defined_param": "value"}
    target_dict = _CatchAllUndefinedParameters.handle_to_dict(
        obj=DummyClass, kvs=original_dict)
    undefined_parameter_should_be_in_result = "some_parameter" in target_dict
    expected_result = {"defined_param": "value",
                       "some_parameter": "value"}
    assert undefined_parameter_should_be_in_result
    assert target_dict == expected_result

# Generated at 2022-06-21 11:37:41.139531
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class _TestClass:
        always_given_parameter: str
        undef_param1: str = None
        undef_param2: Optional[str] = None

    [defined_given_parameters, undefined_given_parameters] = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=_TestClass, kvs={
                "always_given_parameter": "hello",
                "undef_param1": "world",
                "undef_param2": "world2",
                "undef_param3": "world3"})

    kvs = _IgnoreUndefinedParameters.handle_from_dict(
        cls=_TestClass, kvs=defined_given_parameters)


# Generated at 2022-06-21 11:37:44.541530
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    """
    If a subclass is defined with a constructor, we want to make sure that
    the class can still be instantiated without arguments without raising errors.
    This test makes sure that this does not break in the future.
    """
    subclass = _CatchAllUndefinedParameters
    instance = subclass()

# Generated at 2022-06-21 11:37:49.265893
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        a: int
        b: int

    class B:
        a: int
        b: int
        c: str

    res1 = _UndefinedParameterAction.handle_from_dict(A, {"a": 1, "b": 3})
    assert res1 == {"a": 1, "b": 3}

    try:
        _UndefinedParameterAction.handle_from_dict(A, {"a": 1, "b": 3, "c": 4})
        assert False
    except:
        assert True

    try:
        _UndefinedParameterAction.handle_from_dict(A, {"a": 1, "b": 3, "c": 4})
        assert False
    except:
        assert True


# Generated at 2022-06-21 11:37:55.152367
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: str):
            pass

    kvs = {"a": "a", "unknown": "unknown"}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestClass, kvs=kvs)
    assert known == {"a": "a"}
    assert unknown == {"unknown": "unknown"}



# Generated at 2022-06-21 11:38:06.034502
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        pass

    class B(A):
        def __init__(self, a: int):
            self.a = a

    data = {"a": 0, "b": 1}
    known, unknown = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=B, kvs=data)
    assert known == {"a": 0}
    assert unknown == {"b": 1}

    known = _RaiseUndefinedParameters.handle_from_dict(cls=B, kvs=data)
    assert known == {"a": 0}

    del data["a"]
    try:
        _RaiseUndefinedParameters.handle_from_dict(cls=B, kvs=data)
        assert False
    except UndefinedParameterError:
        pass


# Generated at 2022-06-21 11:38:12.527967
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    assert _UndefinedParameterAction.handle_to_dict(None, {}) == {}
    assert _UndefinedParameterAction.handle_to_dict(None, {"abc": "abc"}) == \
           {"abc": "abc"}
    assert _UndefinedParameterAction.handle_to_dict(None, {"abc": "abc",
                                                            "def": "def"}) == \
           {"abc": "abc", "def": "def"}



# Generated at 2022-06-21 11:38:14.018994
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    from dataclasses import dataclass

    from dataclasses_json import config, DataClassJsonMixin

# Generated at 2022-06-21 11:38:23.201695
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a=0, b=0, c=0):
            self.a = a
            self.b = b
            self.c = c

    test_object = TestClass(10, 20)

    assert isinstance(test_object.c, int)
    assert test_object.c == 0

    dictionary_to_write = {
        "a": 1,
        "c": 3
    }

    inferred_dictionary = _IgnoreUndefinedParameters.handle_from_dict(
        TestClass, dictionary_to_write)

    assert inferred_dictionary == {
        "a": 1
    }



# Generated at 2022-06-21 11:38:31.350473
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    BaseClass = type("BaseClass", (object,),
                     {"__init__": lambda self: None})  # type: ignore

    class MyClass(BaseClass):
        def __init__(self, a: str, b: int = 0):
            self.a = a
            self.b = b

    with pytest.raises(UndefinedParameterError):
        data = dict(a="hello", b=17, c=42)
        _RaiseUndefinedParameters.handle_from_dict(MyClass, data)

    data = dict(a="hello", b=17)
    result = _RaiseUndefinedParameters.handle_from_dict(MyClass, data)
    assert dict(a="hello", b=17) == result



# Generated at 2022-06-21 11:38:36.083191
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # handle_to_dict should not modify the input dict, since we use it
    # several times
    kvs = dict(test=1)
    output = _UndefinedParameterAction.handle_to_dict(obj=None, kvs=kvs)
    assert output is kvs

# Generated at 2022-06-21 11:39:34.417156
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # If a dictionary has a CatchAll dictionary at its root, this dictionary
    # should be removed and its contents added to the outside
    class TestClass():
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    test_obj = TestClass(
        **{
            "a": "hello",
            "b": 5,
            "_CatchAll0": {
                "c": "world",
                "d": 3
            }
        }
    )
    expected_dict = {
        "a": "hello",
        "b": 5,
        "c": "world",
        "d": 3
    }


# Generated at 2022-06-21 11:39:39.958598
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def _assert_handle_dump(
            undefined_action: _UndefinedParameterAction,
            undefined_parameters: Dict[str, Any],
            catch_all: Optional[CatchAllVar]) -> None:
        @dataclasses.dataclass
        class TestClass:
            field_a: str
            field_b: str
            undefined_parameters: Optional[CatchAllVar] = catch_all

        test_object = TestClass("test_a", "test_b")
        test_object.undefined_parameters = undefined_parameters
        actual_dump = undefined_action.handle_dump(obj=test_object)
        expected_dump = undefined_parameters
        assert actual_dump == expected_dump

    undefined_parameters = {"field_c": "test_c"}

# Generated at 2022-06-21 11:39:50.427938
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    """
    Test __init__ of _IgnoreUndefinedParameters.
    """
    def _init__(self, a, b, c, d, e, f, g=None) -> None:
        return

    assert _IgnoreUndefinedParameters.create_init(obj=_init__)(
        obj=None, a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8) is None
    assert _IgnoreUndefinedParameters.create_init(obj=_init__)(
        obj=None, a=1, b=2, c=3, d=4, e=5, f=6, h=8) is None

# Generated at 2022-06-21 11:39:58.737717
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class_under_test = _IgnoreUndefinedParameters

    @dataclasses.dataclass
    class DataTestClass:
        value1: int = dataclasses.field(default=0)
        value2: int = dataclasses.field(default=0)

    class_with_correct_init = DataTestClass.__init__
    obj = DataTestClass()

    class_with_modified_init = class_under_test.create_init(obj=obj)
    assert class_with_modified_init is not class_with_correct_init

# Generated at 2022-06-21 11:40:10.238521
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClassWithCatchAll(object):
        def __init__(self, a, b: dataclasses_json.CatchAll = None):
            self.a = a
            self.b = b

    class DummyClassWithoutCatchAll(object):
        def __init__(self, a):
            self.a = a

    dummy_class_with_catch_all = DummyClassWithCatchAll
    dummy_class_without_catch_all = DummyClassWithoutCatchAll

    known_parameters_for_dummy_class_with_catch_all = {
        "a": "a"
    }
    unknown_parameters_for_dummy_class_with_catch_all = {
        "b": "b",
        "c": "c",
    }


# Generated at 2022-06-21 11:40:18.079299
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def simple_init(self, a: int, b: int, c: int, d: int, e: int, f: int, g: int,
                    h: int, i: int, j: int, k: int, l: int, m: int, n: int, o: int,
                    p: int, q: int, r: int, s: int, t: int, u: int, v: int, w: int,
                    x: int, y: int, z: int):
        pass

    def complex_init(self, abc: int = 5, def_: int = 5, hijk: int = 5):
        pass

    for init in [simple_init, complex_init]:
        init = _IgnoreUndefinedParameters.create_init(init)

        for i in range(27):
            input_args

# Generated at 2022-06-21 11:40:28.267729
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, foo: int = 0, bar=1, *args, **kwargs):
            pass

    c = _UndefinedParameterAction()
    assert c.create_init(obj=TestClass) == TestClass.__init__

    init_ignore = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init_ignore(instance=TestClass, foo=2, foo2=2)

    init_catch_all = _CatchAllUndefinedParameters.create_init(TestClass)
    assert init_catch_all(instance=TestClass, foo=2, bar=3, foo2=2)

# Generated at 2022-06-21 11:40:32.476006
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass(
        init=_CatchAllUndefinedParameters.create_init(
            _CatchAllUndefinedParameters))
    class A:
        z: str
        u: str
        catch_all: CatchAll

    a = A("z", "u", {}, {'a': 'b', 4: 5})
    assert isinstance(a, A)

# Generated at 2022-06-21 11:40:34.480227
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass(_UndefinedParameterAction):
        pass
    test_class = TestClass()
    test_class.handle_from_dict(str, {})
    test_class.handle_dump(str)
    test_class.handle_to_dict(str, {})
    test_class.create_init(str)

# Generated at 2022-06-21 11:40:43.400743
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class JsonClassWithoutCatchAll:
        def __init__(self, x: int, y: int, z: int = 0, ):
            self.z = z
            self.x = x
            self.y = y


    class JsonClassWithCatchAll:
        def __init__(self, x: int, y: int, z: Optional[CatchAllVar] = None,
                     *args, **kwargs):
            self.z = z
            self.x = x
            self.y = y


    class JsonClassWithCatchAllDefault:
        def __init__(self, x: int, y: int,
                     z: Optional[CatchAllVar] = {'a': 'a', 'b': 'b'}):
            self.z = z
            self.x = x
           

# Generated at 2022-06-21 11:43:05.040329
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class NoUndefined(object):
        a: str
        b: int
        c: float
        catch_all: CatchAll = None

        def __init__(self, a, b, c, catch_all=None):
            # noinspection PyShadowingNames,PyUnusedLocal
            """
            :param a:
            :param b:
            :param c:
            :param catch_all:
            """
            pass

    @dataclass
    class CatchAllUndefined(object):
        a: str
        b: int
        c: float
        catch_all: CatchAll = None


# Generated at 2022-06-21 11:43:12.277371
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class_example = type("Example", (), {})  # noqa: F811
    class_example.handle_from_dict = classmethod(
        _IgnoreUndefinedParameters.handle_from_dict)
    obtained_kvs = class_example.handle_from_dict(
        kvs={"a": 1, "b": 2, "c": 3, "d": 4})
    expected_result = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert obtained_kvs == expected_result



# Generated at 2022-06-21 11:43:14.877277
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    u = _UndefinedParameterAction
    dct = {"a": "a", "b": "b"}
    result = u.handle_to_dict("obj", dct)
    assert result == {"a": "a", "b": "b"}

# Generated at 2022-06-21 11:43:16.521961
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass
    class MyClass:
        pass

    assert _UndefinedParameterAction.handle_dump(MyClass()) == {}

# Generated at 2022-06-21 11:43:17.241077
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass



# Generated at 2022-06-21 11:43:27.563054
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # noinspection PyUnresolvedReferences,PyProtectedMember
    class TestClass:
        def __init__(self, s: str) -> None:
            self.s = s

    class TestSubclass(TestClass):
        pass

    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, {}) == ({}, {})
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, {"s": "hello"}) == ({"s": "hello"}, {})
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        TestClass, {"s": "hello", "other": "world"}) == ({"s": "hello"},
                                                          {"other": "world"})
    assert _UndefinedParameterAction._separ

# Generated at 2022-06-21 11:43:33.858727
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # Given
    kvs = {"a": "a", "b": 1, "c": None, "d": False}
    class_fields = [dataclasses.field(default=None)]

    # When
    defined_parameters, undefined_parameters = \
        _IgnoreUndefinedParameters.handle_from_dict(
            cls=check_class_fields, kvs=kvs
        )

    # Then
    assert defined_parameters == kvs
    assert undefined_parameters == {}



# Generated at 2022-06-21 11:43:44.074958
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import pytest
    from dataclasses import dataclass

    from dataclasses_json import dataclass_json, letter_case
    from dataclasses_json.utils import CatchAllVar


    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass
    class A:
        a: str


    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class B:
        a: str
        catch_all: Optional[CatchAllVar] = None


    @dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass
    class C:
        a: str
        catch_all: Optional[CatchAllVar] = None
        b: str



# Generated at 2022-06-21 11:43:49.676938
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def normal_init(self, a: str, b: str, c: CatchAll = None):
        pass

    class TestClass:
        def __init__(self, a: str, b: str, c: CatchAll = None):
            pass

    TestClass.__init__ = normal_init
    TestClass = _CatchAllUndefinedParameters.create_init(TestClass)

    t = TestClass("a", "b", "c", d="d", e="e")
    assert t.__init__.__name__ == "normal_init"
    assert t.a == "a"
    assert t.b == "b"
    assert t.c == {"d": "d", "e": "e"}

# Generated at 2022-06-21 11:43:56.628963
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import datetime
    from typing import Optional

    @dataclasses.dataclass
    class TestCatchAll:
        id: str
        amount: str
        # noinspection PyTypeHints
        unknown_params: Optional[CatchAllVar] = None

        def __init__(self, *args, **kwargs):
            kwargs['amount'] = str(kwargs['amount'])
            self.time_created = str(datetime.datetime.now())
            super().__init__(*args, **kwargs)

    @dataclasses.dataclass
    class TestCatchAllDefaultDict:
        id: str
        amount: str
        # noinspection PyTypeHints