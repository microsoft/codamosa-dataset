

# Generated at 2022-06-21 11:34:34.943743
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field
    from dataclasses_json.undefined import Undefined
    from dataclasses_json.config import Config
    from dataclasses_json.api import DataClassJsonMixin
    from marshmallow import fields as schema_fields
    import marshmallow

    @dataclass
    class Thing(DataClassJsonMixin):
        a: int
        b: int
        c: int
        d: int

    def check(num_params_known: int, kwargs: dict, *args):
        init = Thing.__init__
        assert num_params_known == len(init.__code__.co_varnames) - 1


# Generated at 2022-06-21 11:34:46.166786
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: int = dataclasses.field(default_factory=lambda: 4)
        b: int = dataclasses.field(default=-3, metadata={"lettercase": "camel"})
        c: Optional[CatchAll] = dataclasses.field(default=None)

        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    cls = Test

    init = _CatchAllUndefinedParameters.create_init(cls)
    # Did not receive default
    t = init(cls, 0, 1, {})
    assert t.c == {}

    t = init(cls, 0, 1, None)
    assert t.c == {}

# Generated at 2022-06-21 11:34:48.585245
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    # pylint: disable=no-value-for-parameter
    _UndefinedParameterAction()

# Generated at 2022-06-21 11:34:54.656982
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Klass:
        def __init__(self, a, b=None):
            pass

    klass = Klass(a=1)
    known = {'a': 1}
    assert known == _IgnoreUndefinedParameters.handle_from_dict(Klass, {
        'a': 1,
        'b': 1,
        'c': 1,
    })



# Generated at 2022-06-21 11:35:02.104564
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    cls = dataclasses.make_dataclass("Test", [("a", int), ("b", int)])

    def assert_raises_undefined(kvs):
        with pytest.raises(UndefinedParameterError):
            _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)

    assert _RaiseUndefinedParameters.handle_from_dict(cls=cls, kvs={}) == {}
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=cls, kvs={"a": 10, "b": 20}) == {"a": 10, "b": 20}
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=cls, kvs={"a": 10}) == {"a": 10}
   

# Generated at 2022-06-21 11:35:11.941841
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestCase:
        def __init__(self, known1: str, known2: Optional[str]) -> None:
            self.known1 = known1
            self.known2 = known2
            self.unknown: CatchAll = None

    obj = TestCase("foo", "bar")
    obj.unknown = {"baz": "qux"}
    kvs = {"known1": "foo", "known2": "bar", "unknown": {"baz": "qux"}}
    returned_kvs = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert returned_kvs == {"known1": "foo", "known2": "bar", "baz": "qux"}
    assert isinstance(returned_kvs, dict)

# Generated at 2022-06-21 11:35:21.003143
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class TempDataclass:
        field1: int = dataclasses.field(
            default=23)
        field2: str = dataclasses.field(
            default="Hello")
        field3: int = dataclasses.field(
            default=23)
        field4: Optional[CatchAllVar] = dataclasses.field(
            default=CatchAllVar(loaded={"a": 1}))

    obj = TempDataclass(**{"field4": CatchAllVar()})
    assert isinstance(obj.field4, dict)
    assert obj.field4 == {"a": 1}

# Generated at 2022-06-21 11:35:26.008307
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class A:
        def __init__(self, a: int, b: float, c: Optional[int] = None):
            self.a = a
            self.b = b
            self.c = c

    _IgnoreUndefinedParameters.create_init(A)(A, 1, 2, 3, c=4)



# Generated at 2022-06-21 11:35:28.834593
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class MyClass:
        def __init__(self, a, b=2, **kwargs):
            pass

    not_allowed = {"c": 3, "d": 4, "e": 5}
    allowed = {"a": 1, "b": 2}

    result = _IgnoreUndefinedParameters.handle_from_dict(MyClass,
                                                         allowed | not_allowed)
    allowed == result

    result = _IgnoreUndefinedParameters.handle_from_dict(MyClass, not_allowed)
    assert result == {}



# Generated at 2022-06-21 11:35:37.026961
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    invalid_combinations = [
        ("asdf", "default", "asdf"),
        ("default", "asdf", "asdf"),
        ("default", "default", "default"),
        ("default", "asdf", "default"),
        ("asdf", "default", "default"),
        ("asdf", "asdf", "asdf"),
    ]
    valid_combinations = [
        ("asdf", "default", None),
        ("asdf", "default", "default"),
        ("default", "default", None),
        ("default", "default", "asdf"),
    ]

    for given_value, default_value, expected_value in invalid_combinations:
        kwargs = {"field_name": "field_name", "default": default_value,
                  "_given_value": given_value}

# Generated at 2022-06-21 11:35:50.232418
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object) == {}


# Generated at 2022-06-21 11:36:02.630347
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from marshmallow import Schema, fields

    class CatchAllSchema(Schema):
        b = fields.Int(required=True)
        c = fields.String()
        d = fields.Dict(keys=fields.Str(), values=fields.Str())
        catch_all = fields.Nested(CatchAllSchema, default=dict, required=True)

        @property
        def _undefined_parameter_action(self):
            return Undefined.INCLUDE

    class CatchAllSchemaNoDefault(CatchAllSchema):
        @property
        def _undefined_parameter_action(self):
            return Undefined.INCLUDE

        @property
        def _is_strict(self):
            return False

    result = CatchAllSchema().load({"b": 1})

# Generated at 2022-06-21 11:36:11.109046
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    @dataclasses.dataclass
    class _TestDataClass:
        a: int
        b: int
        c: CatchAll
        d: int = 1
        e: int = 1

    # First check that the method decorates the __init__ method
    class_without_catch_all = _TestDataClass(1, 2, {}, 3)
    assert class_without_catch_all.__init__ == _TestDataClass.__init__

    _CatchAllUndefinedParameters.create_init(obj=_TestDataClass)
    assert class_without_catch_all.__init__ != _TestDataClass.__init__

    # Then check that the decorated init handles all unknown parameters correctly
    class_with_catch_all = _TestDataClass(1, 2, {}, x=3)
    assert class_with_catch

# Generated at 2022-06-21 11:36:20.314543
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():

    class DummyClass:
        def __init__(self, unknown=Dict[Any, Any]):  # type: ignore
            pass

    @dataclasses.dataclass
    class DummyClass2:
        unknown: CatchAll = None

    expected_result1 = dict(unknown=dict(foo="bar"))
    result1 = _CatchAllUndefinedParameters.handle_from_dict(
        cls=DummyClass,
        kvs=dict(unknown=dict(foo="bar")))
    assert expected_result1 == result1

    expected_result2 = dict(unknown=dict(foo="bar"))
    result2 = _CatchAllUndefinedParameters.handle_from_dict(
        cls=DummyClass, kvs=dict(foo="bar"))
    assert expected_result2 == result2

    expected_result

# Generated at 2022-06-21 11:36:26.156839
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: int

    # noinspection PyArgumentList
    cls = type(
        "TestClass", (TestClass,),
        {'__init__': _IgnoreUndefinedParameters.create_init(TestClass)})

    def check_arguments(kwargs, expected_a, expected_b):
        t = cls(**kwargs)
        assert t.a == expected_a and t.b == expected_b

    # noinspection PyArgumentList
    check_arguments(dict(a="a", b=1), "a", 1)
    # noinspection PyArgumentList
    check_arguments(dict(b=2, a="b"), "b", 2)
    # noinspection PyArgumentList


# Generated at 2022-06-21 11:36:33.146019
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class A:
        def __init__(self, x):
            self.x = x

    class B:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class C:
        def __init__(self, x, *args):
            self.x = x

    class D:
        def __init__(self, x, *args, y):
            self.x = x
            self.y = y

    class E:
        def __init__(self, x, *args, y=1, **kwargs):
            self.x = x
            self.y = y

    class F:
        def __init__(self, x, y=2, **kwargs):
            self.x = x
            self.y = y


# Generated at 2022-06-21 11:36:38.022588
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():

    class TestClass:
        pass

    unknown_keys = ["a", "b", "c"]
    kvs = unknown_keys
    known_params = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert len(known_params) == 0, "Did not expect any valid keys"

# Generated at 2022-06-21 11:36:39.718363
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-21 11:36:44.777382
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        def __init__(self, hello=None, world=None):
            self.hello = hello
            self.world = world

    kwargs = {
        'hello': 'Hello',
        'world': 'World',
    }

    assert _UndefinedParameterAction.handle_to_dict(TestClass, kwargs) == kwargs


# Generated at 2022-06-21 11:36:57.626191
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, name: str, known: int, *args, **kwargs):
            self.name = name
            self.known = known
            self.unknown = kwargs

    testclass = TestClass("hello", 42, unknown1=3, unknown2=5)
    assert testclass.name == "hello"
    assert testclass.known == 42
    assert list(testclass.unknown.keys()) == ["unknown1", "unknown2"]
    assert list(testclass.unknown.values()) == [3, 5]

    testClassInitiator = _IgnoreUndefinedParameters.create_init(TestClass)
    testclass = testClassInitiator("hello", 42, unknown1=3, unknown2=5)
    assert testclass.name == "hello"

# Generated at 2022-06-21 11:37:26.761624
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class Test:
        foo: str
        bar: int = dataclasses.field(default=1)
        _catch_all: Optional[CatchAll] = dataclasses.field(default=None)

    # noinspection PyUnresolvedReferences
    no_catch_all_init = Test.__init__

    test_catch_all_init = _CatchAllUndefinedParameters.create_init(cls=Test)
    assert test_catch_all_init(
        Test, foo="foo", bar=2, _catch_all={"unknown_1": 1, "unknown_2": 2}) == \
           Test(foo="foo", bar=2, _catch_all={'unknown_1': 1, 'unknown_2': 2})

# Generated at 2022-06-21 11:37:29.081343
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    u = _UndefinedParameterAction()
    obj = dict(c=7)
    assert {} == u.handle_dump(obj=obj)



# Generated at 2022-06-21 11:37:40.573406
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MyDataClass:
        field1: str
        field2: str
        field3: str = dataclasses.field(
            default="default")
        field4: str = dataclasses.field(
            default_factory=lambda: "default_factory")
        _catch_all: CatchAll = None

        def __init__(self, *, field1: str, field2: str, **kwargs):
            self.field1 = field1
            self.field2 = field2
            self._catch_all = kwargs


# Generated at 2022-06-21 11:37:41.350152
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-21 11:37:48.435986
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class DummyClass:
        def __init__(self,
                     a,
                     b,
                     c,
                     d,
                     e,
                     f=5,
                     g=6,
                     h=7,
                     i=8,
                     j=9,
                     k=10,
                     l=11,
                     m=12,
                     n=13,
                     o=14,
                     p=15,
                     q=16,
                     r=17,
                     catch_all: Optional[CatchAll] = None):
            pass


    init = _CatchAllUndefinedParameters.create_init(DummyClass)
    first = dict(a=1, b=2, c=3, d=4)
    second = dict(p=15, q=16)
    third = dict(r=17)


# Generated at 2022-06-21 11:37:59.609497
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    from typing import Optional
    from dataclasses_json.utils import CatchAllVar

    from marshmallow import Schema, post_dump

    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class A:
        a: int
        b: int

    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class B:
        a: int
        b: int
        ca: Optional[CatchAllVar] = dataclasses.field(default=None)

    def _test_no_default(cls, *args, **kwargs):
        dataclasses.dataclass(undefined=Undefined.RAISE)(cls, *args, **kwargs)


# Generated at 2022-06-21 11:38:11.221228
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import unittest.mock as mock
    import marshmallow.exceptions as marshmallow_exceptions
    import dataclasses_json.utils as utils

    class TestClass(dataclasses.dataclass):
        _catch_all: utils.CatchAll

        def __init__(self, _catch_all: utils.CatchAll,
                     **other_undefined_parameters):
            self._catch_all = _catch_all
            self._other_undefined_parameters = other_undefined_parameters

    class TestSecondClass(dataclasses.dataclass):
        known_field: int
        undefined_parameters: utils.CatchAll

        def __init__(self, known_field,
                     **undefined_parameters: Dict[str, Any]):
            self.known_field

# Generated at 2022-06-21 11:38:17.636627
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass
    from typing import List

    from dataclasses_json.utils import CatchAllVar

    @dataclass(undefined=Undefined.INCLUDE, eq=True)
    class Test:
        a: int = 17
        b: int = 18
        c: str = "c"
        catch_all: Optional[CatchAllVar] = None

    i = Test(19, 20, "abcd", "d", e=1, f=2)
    assert i.a == 19
    assert i.b == 20
    assert i.c == "abcd"
    assert i.catch_all == {"e": 1, "f": 2}

    i = Test(20, 21, "ab", d="d", e=1, f=2)
    assert i.a == 20


# Generated at 2022-06-21 11:38:24.499235
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    test_dict = {"a": "a"}

    @dataclasses.dataclass
    class TestClass:
        a: Any = dataclasses.field(metadata=dict(mm_field=True))

        def __repr__(self):
            return f"{self.__class__.__name__}({self.a})"

    TestClass_class = TestClass
    TestClass_object = TestClass("a")
    TestClass_object_dump = _UndefinedParameterAction.handle_dump(
        TestClass_object)
    assert TestClass_class == TestClass
    assert TestClass_object.a == "a"
    assert TestClass_object_dump == test_dict

# Generated at 2022-06-21 11:38:27.385659
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    """
    Test that the handle_from_dict method of class _UndefinedParameterAction
    returns a dictionary that contains only keyword arguments that are
    known to initialize the class.
    """



# Generated at 2022-06-21 11:39:18.487884
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass, field
    from typing import List
    class _Foo:
        pass

    @dataclass
    class _DataClassInitTest:
        a: str = field(default="a default")
        b: int = field(default=20)
        c: List[_Foo] = field(default_factory=list)

    _my_init = _IgnoreUndefinedParameters.create_init(_DataClassInitTest)
    foo1 = _Foo()
    foo2 = _Foo()
    data_class_instance = _my_init(a="a", b=40, c=[foo1], d=True, e=foo2)
    assert data_class_instance.a == "a"
    assert data_class_instance.b == 40

# Generated at 2022-06-21 11:39:29.481648
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass
    class Test:
        a: str
        b: int

    assert Test._UNDEFINED_PARAMETERS_HANDLER.handle_from_dict(
        Test, {'a': 'hello'}) == {'a': 'hello'}

    assert Test._UNDEFINED_PARAMETERS_HANDLER.handle_from_dict(
        Test, {'a': 'hello', 'c': 'ignore-me'}) == {'a': 'hello'}


# Generated at 2022-06-21 11:39:36.154823
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    # Sample input data
    cls = type("_Test", (), {})
    kvs = dict(a=1, b="c")
    # Function to test
    actual_return_value = _UndefinedParameterAction.handle_from_dict(cls=cls,
                                                                     kvs=kvs)
    # Expected return value
    expected_return_value = dict(a=1, b="c")

    assert actual_return_value == expected_return_value

# Generated at 2022-06-21 11:39:47.156764
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from marshmallow_dataclass import class_schema
    from marshmallow import fields as mfields

    @dataclasses.dataclass
    class UnknownParametersObject:
        test_key1: str
        test_key2: int = 10

        def __init__(self, **kwargs):
            super(UnknownParametersObject, self).__init__(**kwargs)

    @dataclasses.dataclass
    class MyClass:
        test_key: str
        unknown_parameters: Optional[UnknownParametersObject] = \
            _UndefinedParameterAction.create_init(  # type: ignore
                UnknownParametersObject)({}, catch_all=True)

# Generated at 2022-06-21 11:39:58.234135
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class MyDataClass:
        def __init__(self, a: int, b: str):
            pass

    assert MyDataClass.__init__ is not _UndefinedParameterAction.create_init(
        MyDataClass)
    orig_init = MyDataClass.__init__

    new_init = _UndefinedParameterAction.create_init(MyDataClass)
    assert new_init is not orig_init

    assert new_init is not _UndefinedParameterAction.create_init(MyDataClass)

    mdc = MyDataClass(a=1, b="")
    assert (mdc.__dict__ == {'a': 1, 'b': ''})

    MyDataClass.__init__ = new_init
    mdc = MyDataClass(a=1, b="", c="")

# Generated at 2022-06-21 11:40:09.671770
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Example(metaclass=abc.ABCMeta):
        a: int
        b: str
        c: int
        d: str

    class MyExample(_RaiseUndefinedParameters, Example):
        a: int
        b: str
        c: int
        d: str

    caught_error = False
    try:
        MyExample.handle_from_dict(MyExample, {"b": 1, "c": 2, "d": "3"})
    except UndefinedParameterError:
        caught_error = True

    assert caught_error
    assert MyExample.handle_from_dict(MyExample,
                                      {"a": 1, "b": "2", "c": 3, "d": "4"}) == {"a": 1, "b": "2", "c": 3, "d": "4"}


# Unit test

# Generated at 2022-06-21 11:40:15.862753
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():  # pragma: no cover
    # Arrange

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: str

    def original_init(self, a, b, c):
        pass

    TestClass.__init__ = original_init

    # Act
    new_init = _CatchAllUndefinedParameters.create_init(TestClass)

    # Assert
    assert isinstance(new_init, Callable)
    assert new_init.__name__ == original_init.__name__

# Generated at 2022-06-21 11:40:29.135397
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import pytest
    from dataclasses_json.undefined import CatchAll, _CatchAllUndefinedParameters
    from marshmallow.utils import missing

    @dataclasses.dataclass(unsafe_hash=True)
    class DataClassWithCatchAll:
        first_name: str
        catch_all: CatchAll = dataclasses.field(default=None)

    @dataclasses.dataclass(unsafe_hash=True)
    class DataClassWithCatchAllAndDefault:
        first_name: str
        catch_all: CatchAll = dataclasses.field(default={},
                                                metadata={"marshmallow_field": "default_factory"})

    @dataclasses.dataclass(unsafe_hash=True)
    class DataClassWithCatchAllAndDefaultFactory:
        first_

# Generated at 2022-06-21 11:40:36.324858
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            pass
    kvs = {"a": 123, "c": "abc"}
    known_kvs, unknown_kvs = _UndefinedParameterAction. \
        _separate_defined_undefined_kvs(TestClass, kvs)
    assert known_kvs == {"a": 123}
    assert unknown_kvs == {"c": "abc"}
    known_kvs = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert known_kvs == {"a": 123}

    try:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs=kvs)
    except UndefinedParameterError:
        pass
    else:
        raise Exception("Test failed")




# Generated at 2022-06-21 11:40:44.449198
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass(
        undefined=_UndefinedParameterAction)
    class _UndefinedParameterActionImpl(_UndefinedParameterAction):
        @staticmethod
        def handle_from_dict(cls, kvs):
            known, unknown = _UndefinedParameterAction. \
                _separate_defined_undefined_kvs(cls=cls, kvs=kvs)
            return known


# Generated at 2022-06-21 11:42:54.248475
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class ClassWithCatchAll:
        unknown_fields: Optional[Dict[str, str]] = None

    kvs = {"unknown_fields": {"hello": "world"}}
    ClassWithCatchAll.__init__ = _CatchAllUndefinedParameters.create_init(
        ClassWithCatchAll)
    instance = ClassWithCatchAll(**kvs)

    assert instance.unknown_fields == {"hello": "world"}

# Generated at 2022-06-21 11:42:55.217883
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # noinspection PyTypeChecker
    UndefinedParameterError()

# Generated at 2022-06-21 11:43:04.639279
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    dc = dataclasses.dataclass()
    dc.__init__ = _UndefinedParameterAction.create_init(dc)
    dc.handle_dump = _UndefinedParameterAction.handle_dump
    dc.to_dict = _UndefinedParameterAction.handle_to_dict
    dc.undefined = Undefined.INCLUDE

    @dataclasses.dataclass
    class Test:
        a: int
        b: str

    # No 'c' parameter
    t = Test(a=1, b="c")
    # Check that no default is added
    assert t.handle_dump() == {}

    # An unbounded catch-all field
    t = Test(a=1, b="c", c={"c": 2})
    assert t.handle_dump() == {"c": {"c": 2}}

   

# Generated at 2022-06-21 11:43:13.957827
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: str = "a-default", b: int = 42, c: Any = None):
            self.a = a
            self.b = b
            self.c = c

    parameters = {
        "a": "not-default",
        "b": 24,
        "c": "this-is-defined-as-c"
    }
    produced = _UndefinedParameterAction.handle_from_dict(TestClass, parameters)
    expected = parameters
    assert produced == expected

    # Unknown parameter
    parameters = {
        "a": "not-default",
        "b": 24,
        "c": "this-is-defined-as-c",
        "x": "unknown-parameter"
    }


# Generated at 2022-06-21 11:43:20.026665
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class ExampleClass:
        field_a: str
        field_b: str
        field_c: str = dataclasses.field(default='c')
        field_d: str = dataclasses.field(init=False)

    # No undefined parameters
    kvs = {'field_a': 'a', 'field_b': 'b'}
    expected = {'field_a': 'a', 'field_b': 'b', 'field_c': 'c'}
    assert _RaiseUndefinedParameters.handle_from_dict(cls=ExampleClass, kvs=kvs) == expected

    # Simple undefined parameter
    kvs = {'field_a': 'a', 'field_b': 'b', 'field_d': 'd'}

# Generated at 2022-06-21 11:43:26.705848
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass
    from dataclasses_json.config import Undefined

    @dataclass
    class Example:
        x: int
        y: str
        catch_all: Optional[CatchAllVar] = Undefined.INCLUDE

    assert Example(x=1, y="hello", some_field="foo",
                   another_field=None).catch_all == {"some_field": "foo",
                                                     "another_field": None}

# Generated at 2022-06-21 11:43:35.105112
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class A:
        a: int
        b: int
        c: int
        d: str = "d"

    expect_known = {"a": 1, "b": 2, "c": 3, "d": "d"}
    test_input_known = {"a": 1, "b": 2, "c": 3, "d": "d"}
    result_known = _RaiseUndefinedParameters.handle_from_dict(A,
                                                               test_input_known)
    assert result_known == expect_known

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(A, {"b": 2, "c": 3})



# Generated at 2022-06-21 11:43:40.242570
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass(object):
        def __init__(self, field1: str, field2: str, field3: str,
                     field4: str):
            pass

    initalize_function = _IgnoreUndefinedParameters.create_init(TestClass)
    initalize_function(TestClass, "", "", "", "")

# Generated at 2022-06-21 11:43:47.221693
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Test(object):
        def __init__(self, a, b, **kwargs):
            pass

    kvs = {"a": "a"}
    _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs=kvs)
    # Fail if kvs is not of type dict
    kvs = [1]
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs=kvs)
    # Fail if undefined parameter
    kvs = {"a": "a", "c": "c"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=Test, kvs=kvs)
    # Fail if undefined parameter is a keyword argument


# Generated at 2022-06-21 11:43:54.973210
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_init(self, a, b, c=None):
        pass

    obj = type("TestClass", (object,), {"__init__": test_init})
    init_method = _IgnoreUndefinedParameters.create_init(obj)
    assert init_method is not test_init
    assert init_method.__name__ == "_ignore_init"
    assert init_method.__doc__ == obj.__init__.__doc__

    test_instance = obj()
    init_method(test_instance, 1, 2, c=3, x=4)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert test_instance.c == 3

    init_method(test_instance, 1, 2, 3, x=4)
    assert test_instance.a == 1
   