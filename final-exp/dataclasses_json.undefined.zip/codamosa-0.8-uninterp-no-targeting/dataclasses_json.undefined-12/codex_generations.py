

# Generated at 2022-06-21 11:34:29.598563
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert type(_UndefinedParameterAction.handle_dump) is type(lambda x: x)

# Generated at 2022-06-21 11:34:37.862636
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    some_param = 1014

    class Example:
        def __init__(self, defined_param):
            self.defined_param = defined_param

    example = Example(defined_param=some_param)
    init = _IgnoreUndefinedParameters.create_init(example)
    other_example = Example(**{"defined_param": some_param + 10,
                               "undefined_param": 201})
    other_example.defined_param += 1
    init(example, undefined_param=other_example.undefined_param,
         defined_param=other_example.defined_param)
    assert example.defined_param == other_example.defined_param

# Generated at 2022-06-21 11:34:49.366030
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Foo:
        def __init__(self, a: int, b: int):
            pass

    def assert_handles_properly(input_values: dict, expected_values: dict =
    None):
        if expected_values is None:
            expected_values = input_values
        parsed = _RaiseUndefinedParameters.handle_from_dict(
            cls=Foo, kvs=input_values)
        if parsed != expected_values:
            raise AssertionError(f"Got: {parsed}, Expected: {expected_values}")

    assert_handles_properly({"a": 1, "b": 2})
    assert_handles_properly({"a": 1, "b": 2, "c": 11})



# Generated at 2022-06-21 11:34:58.984205
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = [{('a', 'b'): 12, ('x', 'y'): {'z': 42}},
           {('a', 'b'): 12, ('x', 'y'): {'z': 42}},
           {('a', 'b'): 12, ('x', 'y'): {'z': 42}},
           {('a', 'b'): 12, ('x', 'y'): {'z': 42}},
           {('a', 'b'): 12, ('x', 'y'): {'z': 42}},
           {('a', 'b'): 12, ('x', 'y'): {'z': 42}}]

# Generated at 2022-06-21 11:35:03.633754
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int = 42, c: int = 53):
            pass

    for action in [Undefined.RAISE, Undefined.EXCLUDE]:
        kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
        try:
            action.value.handle_from_dict(TestClass, kvs)
        except UndefinedParameterError:
            pass
        else:
            assert action == Undefined.EXCLUDE

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    result = Undefined.INCLUDE.value.handle_from_dict(TestClass, kvs)
    assert isinstance(result, dict)
    assert len(result) == 3
   

# Generated at 2022-06-21 11:35:11.669976
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    import dataclasses
    import typing
    import unittest


    class TestObject(object):
        def __init__(self, unknown_parameters: typing.Optional[CatchAllVar] = None):
            self.unknown_parameters = unknown_parameters if unknown_parameters else {}


    @dataclasses.dataclass
    class TestDataClass(object):

        unknown_parameters: typing.Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict, repr=False
        )



# Generated at 2022-06-21 11:35:23.158157
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.api import DataClassJsonMixin
    from dataclasses_json.api import config
    from typing import Dict

    # The important part about this class is that the default for
    # `undefined_parameters` is not defined
    @dataclasses.dataclass(frozen=True)
    class TestClass(DataClassJsonMixin):
        str_field: str
        int_field: int = 10
        undefined_parameters: CatchAll = config(
            init=True,
            repr=True,
            unknown=Undefined.INCLUDE)

    # Test case 0: unknown parameters are given, but we do not receive a default
    # value for catch-all field (either because we do not define one
    # or because it is a dictionary)

# Generated at 2022-06-21 11:35:24.184618
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    _RaiseUndefinedParameters()

# Generated at 2022-06-21 11:35:32.194379
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Person:
        def __init__(self, name: str, age: int,
                     catch_all: CatchAll = None):
            self.name = name
            self.age = age
            self.catch_all = catch_all

    init = _CatchAllUndefinedParameters.create_init(Person)
    person = Person(name="Bob", age=42)
    p = Person.__init__
    original_args = ('name', 'age', 'catch_all')
    original_kwargs = {'name': 'Bob', 'age': 42}
    init(person, *original_args, **original_kwargs)  # does not raise error
    p(person, *original_args, **original_kwargs)  # does not raise error

# Generated at 2022-06-21 11:35:36.613911
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    def test_function(*args, **kwargs):
        pass

    catch_all: Callable = \
        _CatchAllUndefinedParameters.create_init(test_function)
    catch_all(None, 1, 2, 3, kwarg1=1, kwarg2=2, kwarg3=3)

# Generated at 2022-06-21 11:35:50.689397
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:36:00.778090
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    import dataclasses_json
    import logging

    logging.basicConfig(level=logging.INFO)

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass(unsafe_hash=True)
    class Foo:
        b: int = 2
        a: int = 1

        def __init__(self, *args, **kwargs):
            pass

    class_init = _IgnoreUndefinedParameters.create_init(Foo)
    Foo.__init__ = class_init
    foo = Foo()
    assert foo.a == 1
    assert foo.b == 2



# Generated at 2022-06-21 11:36:08.161921
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    def create_cls():
        @dataclasses.dataclass
        class Cls:
            catch_all: Optional[CatchAllVar] = None
            name = "A"

        return Cls

    obj = create_cls()(**{'catch_all': {'bla': 1, 'blub': 2}})
    kvs = _CatchAllUndefinedParameters.handle_dump(obj)
    assert len(kvs) == 2
    assert kvs['bla'] == 1
    assert kvs['blub'] == 2


# Generated at 2022-06-21 11:36:09.663418
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-21 11:36:12.953419
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class TestClass:
        pass
    instance = _UndefinedParameterAction()
    assert instance.create_init(TestClass) is TestClass.__init__


# Generated at 2022-06-21 11:36:21.071323
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from test.test_utils.test_dataclass_with_undefined import \
        ClassWithUndefinedParameters

    class_fields = fields(ClassWithUndefinedParameters)
    field_names = [field.name for field in class_fields]
    known_given_parameters = {k: v for k, v in {"a": 1, "b": 2}.items()
                              if k in field_names}
    unknown_parameters = {"c": 3, "d": 4}
    parameters_to_init = ClassWithUndefinedParameters.__dict__[
        "_UNDEFINED_PARAMETER_ACTION"].handle_from_dict(
        ClassWithUndefinedParameters, {**known_given_parameters,
                                       **unknown_parameters})
    assert parameters_to_init == {**known_given_parameters}

# Generated at 2022-06-21 11:36:26.849384
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int = 3, c: int = 4,
                     d: Optional[CatchAllVar] = CatchAll):
            pass

    init = _UndefinedParameterAction.create_init(TestClass)

    # Test for case where no unknown args are given:
    assert init(TestClass, 1, b=2) == TestClass(1, 2, 4, {})
    assert init(TestClass, 1, 2, 3, 4) == TestClass(1, 2, 3, 4, {})

    # Test for case where unknown args are given:
    assert init(TestClass, 1, 2, 3, 4, 5) == TestClass(1, 2, 3, {5: 4})

# Generated at 2022-06-21 11:36:33.915677
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    # Handle correctly:
    #- 2 fields, kv for both -> 2 kv in result
    #- 2 fields, one kv, one not -> 1 kv in result
    #- 2 fields, neither kv -> {} in result

    # UndefinedParameterError:
    #- 2 fields, kv for both and one more -> UndefinedParameterError
    #- 2 fields, kv for both and one more -> UndefinedParameterError
    pass

# Generated at 2022-06-21 11:36:35.188830
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    print(UndefinedParameterError("test"))

# Generated at 2022-06-21 11:36:38.538087
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    kvs = {"a": 1, "b": 2}
    kvs2 = _UndefinedParameterAction.handle_to_dict(None, kvs)
    assert kvs == kvs2



# Generated at 2022-06-21 11:37:08.734530
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class ClassWithTwoFields:
        x: int
        y: int

    test_case = _IgnoreUndefinedParameters()
    expected = {"x": 1, "y": 2}
    given = {"x": 1, "y": 2, "z": 3}
    actual = test_case.handle_from_dict(
        ClassWithTwoFields, kvs=given)
    assert expected == actual



# Generated at 2022-06-21 11:37:10.621301
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test_1")
    except UndefinedParameterError as e:
        assert str(e) == "test_1"

# Generated at 2022-06-21 11:37:20.690137
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass(object):
        def __init__(self,
                     a: Optional[CatchAllVar] = None,
                     z: int = 0,
                     b: int = 1,
                     c: int = 2,
                     d: int = 3,
                     ):
            self.a = a
            self.z = z
            self.b = b
            self.c = c
            self.d = d

    t = TestClass(a={'a': 1, 'b': 2}, z=-1, b=-2, c=-3)

    correct_dict = {
        'a': {'a': 1, 'b': 2},
        'z': -1,
        'b': -2,
        'c': -3,
        'd': 3
    }


# Generated at 2022-06-21 11:37:22.630384
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError as error:
        assert error.fields == []
        assert error.messages == []
        assert str(error) == "None"

# Generated at 2022-06-21 11:37:29.857857
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    parameters = {
        "raise": "undefined",
        "my_key": "my_value"
    }

    class TestDataClass:
        def __init__(self, my_key: str):
            self.my_key = my_key

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestDataClass,
                                                   kvs=parameters)


# Unit tests for constructor of class _IgnoreUndefinedParameters

# Generated at 2022-06-21 11:37:31.142195
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    raise UndefinedParameterError("Test")



# Generated at 2022-06-21 11:37:36.550354
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        def __init__(self, a, b):
            pass

    assert _UndefinedParameterAction.handle_from_dict(A, {"a": 1, "b": 2}) == {
        "a": 1, "b": 2}



# Generated at 2022-06-21 11:37:37.321671
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert issubclass(_UndefinedParameterAction, abc.ABC)


# Generated at 2022-06-21 11:37:46.087676
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class CatchAllTester:
        a: int
        b: int
        c: Optional[CatchAllVar] = None
        d: int = 3

        def __post_init__(self):
            print(f"__post_init__; c:{self.c}")
        pass

    ca_obj = CatchAllTester(a=1, b=2)
    assert ca_obj.a == 1
    assert ca_obj.b == 2
    assert ca_obj.d == 3
    assert ca_obj.c == {}

    ca_obj = CatchAllTester(a=1, b=2, d=4, e=5)
    assert ca_obj.a == 1
    assert ca_obj.b == 2
    assert ca_obj.d == 4

# Generated at 2022-06-21 11:37:55.005904
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class C:
        def __init__(self, *, a, b=None):
            self.a = a
            self.b = b

        def to_dict(self) -> Any:
            return {
                "a": self.a,
                "b": self.b,
            }

    undefined_action = _IgnoreUndefinedParameters()

    new_init = undefined_action.create_init(obj=C)
    # Invoke the constructor
    c = new_init(42, 5, b=7, c=8)
    assert c.to_dict() == {"a": 42, "b": 7}

# Generated at 2022-06-21 11:38:51.343503
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Class:
        def __init__(self, a, b):
            self.a = a
            self.b = b


    def run_test(kvs, expected_result):
        result = _IgnoreUndefinedParameters.handle_from_dict(Class, kvs)
        assert result == expected_result
        # Confirm that the ignored arguments aren't taken into the arguments
        # of the __init__ call
        expected_init_args = set(expected_result)
        actual_init_args = set(inspect.getfullargspec(Class.__init__).args)
        unexpected_args = expected_init_args.difference(actual_init_args)
        assert len(unexpected_args) == 0, \
            f"Unexpected init args: {unexpected_args}"


    kvs_all_in

# Generated at 2022-06-21 11:38:57.428781
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from unittest.mock import Mock
    catch_all_action = _CatchAllUndefinedParameters()
    mock_init = Mock(spec=CatchAll)
    _CatchAllUndefinedParameters._get_catch_all_field = Mock(return_value=None)
    init = catch_all_action.create_init(mock_init)
    init(1)
    mock_init.assert_called_once_with(1)

# Generated at 2022-06-21 11:39:05.073450
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = None

    test_obj = TestClass()
    catch_all_dictionary = {"test_key": "test_value"}
    setattr(test_obj, "catch_all", catch_all_dictionary)
    returned_dictionary = \
        _CatchAllUndefinedParameters.handle_dump(test_obj)
    assert returned_dictionary == catch_all_dictionary

# Generated at 2022-06-21 11:39:06.581909
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}

# Generated at 2022-06-21 11:39:12.222205
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # Preparation
    class Foo:
        def __init__(self, param1: str, param2: float = 42.0,
                     param3: str = "default"):
            pass

    schema = dataclasses_json.configure(
        undefined=Undefined.INCLUDE)
    obj = Foo("abc")

    # Test
    constructed_dict = _UndefinedParameterAction.handle_dump(obj)

    # Assert
    expected = {}
    assert constructed_dict == expected

# Generated at 2022-06-21 11:39:16.240685
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class _TestClass:
        test: str

        def __init__(self, **kwargs):
            pass

        def __str__(self):
            return "Test Class"

    # noinspection PyTypeChecker
    _CatchAllUndefinedParameters.create_init(obj=_TestClass)



# Generated at 2022-06-21 11:39:17.341053
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert True
    # TODO: Add tests

# Generated at 2022-06-21 11:39:18.668907
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}



# Generated at 2022-06-21 11:39:20.477407
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError(
        "Test message")
    assert error.messages == "Test message"
    assert error.fields is None

# Generated at 2022-06-21 11:39:29.947205
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    def test_init(self, a, b=2):
        self.a = a
        self.b = b

    class TestClass:
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

        def test_method(self):
            pass

    TestClass.__init__ = test_init

    TestClass_wo_ignore = TestClass(a=1, c=3)
    TestClass_w_ignore = TestClass_wo_ignore.__class__(a=1, c=3)

    assert TestClass_w_ignore == TestClass_wo_ignore

# Generated at 2022-06-21 11:41:27.747061
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b, c=None, d: str = "d", e: str = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    kwargs = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": "4",
        "e": "5",
        "f": "6"
    }
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kwargs)
    assert actual == {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": "4",
        "e": "5"
    }


# Unit

# Generated at 2022-06-21 11:41:37.354530
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class MyClass(dataclasses.dataclass):
        s: str
        opt: Optional[str]
        catch_all: Optional[CatchAllVar] = dataclasses.field(default=None)

        @classmethod
        def handle_undefined(cls, unknown_parameters):
            return unknown_parameters

    class MyClass_Undef(dataclasses.dataclass):
        s: str
        opt: Optional[str]

        @classmethod
        def handle_undefined(cls, unknown_parameters):
            return unknown_parameters

    @dataclasses.dataclass
    class MyClass_Undef_Ignore(dataclasses.dataclass):
        s: str
        opt: Optional[str]
        opt2: Optional[str] = None


# Generated at 2022-06-21 11:41:47.189598
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, foo: str=None, bar: str=None,
                     catch_all: Optional[CatchAllVar] = None):
            dataclasses.replace(self, foo=foo, bar=bar, catch_all=catch_all)

    a1 = A.__new__(A)
    kvs = {"foo": "foo", "bar": "bar"}
    assert {"foo": "foo", "bar": "bar", "catch_all": {}} == \
           _CatchAllUndefinedParameters.handle_from_dict(a1, kvs)

    kvs = {"foo": "foo", "bar": "bar", "catch_all": {"baz": 1}}

# Generated at 2022-06-21 11:41:56.609464
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Example:
        def __init__(self, a, b, c=5):
            pass

    ex = Example
    original_init = ex.__init__
    init_signature = inspect.signature(original_init)

    @functools.wraps(ex.__init__)
    def _ignore_init(self, a, b=5, **kwargs):
        known_kwargs, _ = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
            ex, kwargs)
        num_params_takeable = len(
            init_signature.parameters) - 1  # don't count self
        num_args_takeable = num_params_takeable - len(known_kwargs)


# Generated at 2022-06-21 11:42:07.525249
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int
        c: int
        __undefined_parameters__: _IgnoreUndefinedParameters
        __ignore_unset__: bool = True

    kvs = {"a": 1,
           "b": 2,
           "c": 3,
           "d": 4}
    expected = {"a": 1,
                "b": 2,
                "c": 3}
    result = Test._UndefinedParameterAction.handle_from_dict(cls=Test, kvs=kvs)
    assert result == expected

    kvs = {"a": 1,
           "c": 3}
    expected = {"a": 1,
                "c": 3}

# Generated at 2022-06-21 11:42:11.752949
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # type: () -> None
    kvs1 = {"a": 1, "b": 2}
    kvs2 = {"a": 1, "b": 2, "c": 3}
    cls = object

    # Normal case
    assert _RaiseUndefinedParameters.handle_from_dict(cls, kvs1) == kvs1

    # Defined parameters should be given
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls, kvs2)



# Generated at 2022-06-21 11:42:22.704191
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.api import dump

    @dataclasses.dataclass
    class Test:
        a: int = dataclasses.field(metadata={"marshmallow_field":
                                                 {"dump_to": "A"}})
        b: int = dataclasses.field(metadata={"marshmallow_field":
                                                 {"dump_to": "B"}})
        c: Optional[CatchAllVar]
        _UNKNOWN0: str = dataclasses.field(init=False)

        def __post_init__(self) -> None:
            self.c = {self._UNKNOWN0: "c"}

    test = Test(1, 2, _UNKNOWN0="d")
    result = dump(test, strict=True)

# Generated at 2022-06-21 11:42:30.798551
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str = "b"
        c: CatchAll = None

    instance = TestClass(a="a", c=dict(d=1, e=2, f=3))
    result = _CatchAllUndefinedParameters.handle_dump(instance)
    assert result == {'d': 1, 'e': 2, 'f': 3}

    instance = TestClass(a="a")
    result = _CatchAllUndefinedParameters.handle_dump(instance)
    assert result == {}

# Generated at 2022-06-21 11:42:36.185462
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass:
        undefined_params: CatchAll

    instance = TestClass()
    kvs = {"undefined_params": {'a': 1, 'b': 2}}
    undefined_parameters = _UndefinedParameterAction.handle_to_dict(instance,
                                                                    kvs)
    assert kvs == {"a": 1, "b": 2}
    assert undefined_parameters == {"a": 1, "b": 2}



# Generated at 2022-06-21 11:42:43.715350
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class ClassToTest:
        def __init__(self, a: int, b: int = 1, c: Optional[CatchAllVar] = None):
            pass

    sample = ClassToTest(2, 3)
    schema = ClassToTest.Schema()
    assert schema.dump(sample) == {"a": 2}
    sample = ClassToTest(1, c={"_b": 1})
    assert schema.dump(sample) == {"a": 1, "_b": 1}

    sample = ClassToTest(a=1, b=2, c={"b": 1})
    assert schema.dump(sample) == {"a": 1, "_b": 1}

    sample = ClassToTest(a=1, b=2, c=None)
    schema = ClassToTest.Schema(unknown=Undefined.RAISE)
