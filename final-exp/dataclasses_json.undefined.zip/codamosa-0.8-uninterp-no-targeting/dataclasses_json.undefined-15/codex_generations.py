

# Generated at 2022-06-21 11:34:40.195202
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestCatchAll:
        def __init__(self, x: int, y: str, z: Optional[CatchAllVar]):
            self.x = x
            self.y = y
            self.z = z

        def __repr__(self):
            return f"TestCatchAll({self.x}, {self.y}, {self.z})"

    class SuperTest(_CatchAllUndefinedParameters):
        def __init__(self, super_parameter: int):
            self.super = super_parameter

        def __repr__(self):
            return f"SuperTest({self.super})"


# Generated at 2022-06-21 11:34:46.177001
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # pylint: disable=unused-variable
    class Dummy:
        pass
    # pylint: enable=unused-variable

    actual_create_init = _UndefinedParameterAction.create_init(Dummy)
    assert inspect.signature(actual_create_init) == inspect.signature(
        Dummy.__init__)

# Generated at 2022-06-21 11:34:54.092880
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, *args, **kwargs):
            pass

    class_with_catch_all: TestClass = \
        _CatchAllUndefinedParameters.create_init(TestClass)(TestClass)
    class_without_catch_all: TestClass = \
        _IgnoreUndefinedParameters.create_init(TestClass)(TestClass)

    assert class_with_catch_all is not TestClass
    assert class_without_catch_all is not TestClass

# Generated at 2022-06-21 11:35:01.729934
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class BasicClass():
        def __init__(self, param1, param2, undefined_parameter=None):
            self.param1 = param1
            self.param2 = param2
            self.undefined_parameter = undefined_parameter

    obj = BasicClass("a1", "a2", "uuuuuuuuundefined")
    expected_kvs = {"param1": "a1", "param2": "a2"}
    actual_kvs = _UndefinedParameterAction.handle_to_dict(obj=obj,
                                                          kvs={"param1": "a1",
                                                               "undefined_parameter":
                                                               "uuuuuuuuundefined",
                                                               "param2": "a2"})
    assert actual_kvs == expected_kvs


# Unit test

# Generated at 2022-06-21 11:35:11.980748
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import marshmallow as mm
    import marshmallow.fields as mf
    import marshmallow_dataclass as md
    from dataclasses_json import _UndefinedParameterAction

    class _TestClass1:
        a: int
        b: int
        c: int
        d: int

        def __init__(self, a, b, c, d) -> None:
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    TestClass1_init = _TestClass1.__init__
    TestClass1_init_signature = inspect.signature(TestClass1_init)

    class TestClass1(_TestClass1):
        json_module = None
        # noinspection PyMethodParameters

# Generated at 2022-06-21 11:35:23.442357
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    """
    Ensure that the catch-all field is not included in the output,
    but instead its values are.
    """
    class TestClass:
        def __init__(self, *, x, y, ___unknown):
            self.x = x
            self.y = y
            self.___unknown = ___unknown

        def init(self, kwargs):
            final_parameters = _CatchAllUndefinedParameters.handle_from_dict(
                self.__class__, kwargs)
            self.__init__(**final_parameters)

    t = TestClass(**{"x": 1, "y": 2, "catchAllField": {"z": 3, "w": 4}})
    assert t.x == 1
    assert t.y == 2
    assert t.___unknown["z"] == 3

# Generated at 2022-06-21 11:35:30.293862
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    """
    Test handle_from_dict for _UndefinedParameterAction
    """
    class TestClass:
        def __init__(self, a: int, b: int):
            pass

    kvs = {"a": 1, "b": 2, "c": 3, "d": 4}
    known_parameters, unknown_parameters = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_parameters == {"a": 1, "b": 2}
    assert unknown_parameters == {"c": 3, "d": 4}


# Generated at 2022-06-21 11:35:35.448652
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Note that this test assumes the correctness of the dataclasses module
    # (which we do not want to write tests for)

    @dataclasses.dataclass
    class TestClass:
        field_1: Any = dataclasses.field(default_factory=list)
        field_2: Any = dataclasses.field(default_factory=list)
        field_3: Any = dataclasses.field(default_factory=lambda: "test")
        field_4: Any = dataclasses.field(default_factory=lambda: "test")

    test_init_1 = _IgnoreUndefinedParameters.create_init(TestClass)
    test_class = TestClass()

    # test 1: use all parameters that are available

# Generated at 2022-06-21 11:35:42.170299
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    for undefined_parameter_action in Undefined:
        if undefined_parameter_action is Undefined.INCLUDE:
            continue
        from dataclasses_json import config

        config.undefined = undefined_parameter_action
        from dataclasses_json import dataclass

        @dataclass
        class TestObject:
            name: str

        _CatchAllUndefinedParameters.create_init(TestObject)

# Generated at 2022-06-21 11:35:55.116048
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Person:
        name: str
        catch_all: Optional[CatchAllVar] = None
        @classmethod
        def _undefined_parameters_json_hook(cls, kvs: Dict[Any, Any],
                                            is_init: bool,
                                            is_dump: bool) -> Dict[Any, Any]:
            if is_init:
                return _CatchAllUndefinedParameters.handle_from_dict(cls, kvs)
            elif is_dump:
                return _CatchAllUndefinedParameters.handle_dump(cls)
            else:
                return _CatchAllUndefinedParameters.handle_to_dict(cls, kvs)

    p = Person("Max Mustermann", foo=1, bar=2)

# Generated at 2022-06-21 11:36:18.223636
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestCatchAll:
        catch_all: Optional[CatchAll]

    object_with_empty_catch_all = TestCatchAll(catch_all={})
    object_with_nonempty_catch_all = TestCatchAll(
        catch_all={"key_1": "value_1", "key_2": "value_2"})

    assert _CatchAllUndefinedParameters.handle_dump(
        obj=object_with_empty_catch_all) == {}
    assert _CatchAllUndefinedParameters.handle_dump(
        obj=object_with_nonempty_catch_all) == {
               "key_1": "value_1",
               "key_2": "value_2"}

# Generated at 2022-06-21 11:36:29.422750
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from typing import NoReturn

    @dataclass
    class DummyClass:
        field1: int
        field2: int
        field3: int

    input_ = {"field1": 1, "field2": 2, "field3": 3, "field4": 4}
    expected = {"field1": 1, "field2": 2, "field3": 3}
    assert _IgnoreUndefinedParameters.handle_from_dict(DummyClass, input_) \
           == expected

    input_ = {"field1": 1, "field2": 2, "field3": 3, "field3": 4}
    with pytest.raises(ValidationError):
        _IgnoreUndefinedParameters.handle_from_dict(DummyClass, input_)


# Generated at 2022-06-21 11:36:39.007627
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Cls(object):
        def __init__(self):
            pass

    field = dataclasses.field(type=CatchAll)
    Cls.__dataclass_fields__ = {"catch_all": None}
    Cls.catch_all = field
    instance = Cls()
    instance.catch_all = {"A": 1}
    kvs = {"A": 1, "B": 2, catch_all_field.name: {"C": 3}}
    assert _CatchAllUndefinedParameters.handle_to_dict(instance, kvs) == \
           {"A": 1, "B": 2, "C": 3}

# Generated at 2022-06-21 11:36:42.155233
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # noinspection PyUnresolvedReferences
    dummy1 = _UndefinedParameterAction._create_init(3)


if __name__ == '__main__':
    test__UndefinedParameterAction_create_init()

# Generated at 2022-06-21 11:36:55.589904
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a: Optional[CatchAllVar] = None, b = None):
            self.a = a
            self.b = b
            pass

    kvs = {"a": "foo", "b": "bar", "c": "catch_all"}
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)

    kvs = {"a": None, "b": None, "c": "catch_all"}
    res = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert res == {}

    kvs = {"a": None, "b": None, "c": None}

# Generated at 2022-06-21 11:37:07.398262
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from marshmallow import Schema, fields
    from dataclasses_json.utils import CatchAllVar
    from dataclasses import dataclass
    import inspect
    import functools


    @dataclass
    class Person:
        name: str = fields.Str()
        age: int = fields.Int()
        undefined_parameters: CatchAll = CatchAllVar(
            _UndefinedParameterAction=_IgnoreUndefinedParameters)


    init_signature = inspect.signature(Person.__init__)
    assert (len(init_signature.parameters) == 3)

    @dataclass
    class Person:
        name: str = fields.Str()
        age: int = fields.Int()

# Generated at 2022-06-21 11:37:11.921487
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Data:
        def __init__(self, a: int = 0, b: int = 0, **kwargs):
            assert len(kwargs) == 0
            self.a = a
            self.b = b

    f = _IgnoreUndefinedParameters.create_init(Data)
    d = f(Data(), 1)

    assert d.a == 1
    assert d.b == 0



# Generated at 2022-06-21 11:37:21.482239
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class CatchAllTest:
        foo: str
        bar: Optional[CatchAllVar] = dataclasses.field(default=None)
        baz: Optional[CatchAllVar] = dataclasses.field(default_factory=dict)

    _CatchAllUndefinedParameters.create_init(CatchAllTest)()
    CatchAllTest("foo")
    CatchAllTest("foo", bar=1)
    CatchAllTest("foo", bar=1, baz=2)
    CatchAllTest("foo", baz=2)
    CatchAllTest("foo", bar=1, baz=2, example_undefined_parameter="foo")

# Generated at 2022-06-21 11:37:22.376704
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(obj=None) == {}



# Generated at 2022-06-21 11:37:31.671834
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    import types

    class TestClass:
        def __init__(self, **kwargs):
            pass

    def test_method(self, **kwargs):
        pass
    test_method.__name__ = "test_method"

    def test_method_2(self, *args, **kwargs):
        pass
    test_method_2.__name__ = "test_method_2"

    for action in (Undefined.EXCLUDE, Undefined.INCLUDE, Undefined.RAISE):
        obj = action.value
        assert isinstance(obj.create_init(TestClass), types.FunctionType)
        assert isinstance(obj.create_init(test_method),
                          functools.partial)

# Generated at 2022-06-21 11:37:59.133988
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    (known_given_parameters, unknown_given_parameters) = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            {"a": 1},
            {"a": 1, "unknown": 2})
    assert known_given_parameters == {"a": 1}
    assert unknown_given_parameters == {"unknown": 2}

# Generated at 2022-06-21 11:38:04.721094
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class _TestSelfCatchAllClass:
        pass

    with pytest.raises(UndefinedParameterError) as exc_info:
        _CatchAllUndefinedParameters.create_init(_TestSelfCatchAllClass)

    assert exc_info.value.args[0] == "No field of type dataclasses_json." \
                                     "CatchAll defined"



# Generated at 2022-06-21 11:38:13.886268
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from dataclasses import dataclass

    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TestUndefinedParameterActionToDict:
        a: int = 1
        b: str = '2'
        _UNDEFINED_PARAMETER_HANDLER: _UndefinedParameterAction = \
            _IgnoreUndefinedParameters

    instance = TestUndefinedParameterActionToDict(a=1, b='2', c=3)
    dict_repr = instance.to_dict()
    assert dict_repr == {'a': 1, 'b': '2'}



# Generated at 2022-06-21 11:38:21.645260
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import numpy as np
    # noinspection PyProtectedMember
    from dataclasses_json.core import _MISSING_TYPE
    from dataclasses_json.core import _CatchAllUndefinedParameters
    from dataclasses_json import Undefined
    from dataclasses_json.utils import CatchAll

    @dataclasses.dataclass(frozen=True,
                           undefined=Undefined.EXCLUDE)
    class TestClass:
        a: int
        b: str
        c: CatchAll = None

    assert (_CatchAllUndefinedParameters.handle_to_dict(
            TestClass,
            {"a": 1, "b": "test", "c": {'a': 1}}) == {"a": 1, "b": "test"})

    # noinspection PyArgumentEqualDefault


# Generated at 2022-06-21 11:38:26.431080
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses_json.undefined import Undefined

    @dataclasses.dataclass
    class DummyClass:
        a: int
        b: int = 1

    dummy_instance = DummyClass(**_IgnoreUndefinedParameters.
                                handle_from_dict(DummyClass, kvs={"a": 1}))

    assert dummy_instance.a == 1
    assert dummy_instance.b == 1

# Generated at 2022-06-21 11:38:31.742776
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(CatchAll.INCLUDE) == \
           {"_undefined_parameter_behavior": "CATCH_ALL"}
    assert _UndefinedParameterAction.handle_dump(CatchAll.EXCLUDE) == \
           {"_undefined_parameter_behavior": "IGNORE"}
    assert _UndefinedParameterAction.handle_dump(CatchAll.RAISE) == \
           {"_undefined_parameter_behavior": "RAISE"}


# Generated at 2022-06-21 11:38:40.281640
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    import json

    @dataclass
    class TestClass:
        foo: int
        bar: str = "Hello"
        catch_all: CatchAll = None

    test_inst = TestClass(1, bar="World")
    test_json = json.dumps(test_inst)
    assert test_json == '{"foo": 1, "bar": "World"}'

    test_inst2 = TestClass(1, unknown="This are other parameters")
    test_json2 = json.dumps(test_inst2)
    assert test_json2 == '{"foo": 1, "bar": "Hello", ' \
                         '"catch_all": {"unknown": "This are other parameters"}}'



# Generated at 2022-06-21 11:38:41.709130
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(obj) == {}

# Generated at 2022-06-21 11:38:52.449420
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class A():
        def __init__(self, test: str, a: str, b: str,
                     what: str = "", **undefined_parameters):
            self.test = test
            self.a = a
            self.b = b
            self.what = what
            self.undefined_parameters = undefined_parameters

    class B(A):
        def __init__(self, test: str, a: str, b: str,
                     what: str = "", **undefined_parameters):
            super().__init__(test, a, b, what, **undefined_parameters)


# Generated at 2022-06-21 11:38:58.995307
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class DummyClass:
        pass
    _RaiseUndefinedParameters.handle_from_dict(DummyClass, {"a": 1})
    try:
        _RaiseUndefinedParameters.handle_from_dict(DummyClass, {"a": 1, "b": 2})
        assert False, (
            "This code should have raised UndefinedParameterError")
    except UndefinedParameterError:
        pass


# Generated at 2022-06-21 11:39:53.332378
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("Dummy")  # noqa
        assert False
    except UndefinedParameterError as ex:
        assert str(ex) == "Dummy"

# Generated at 2022-06-21 11:40:05.334941
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # Let's create a simple model:
    @dataclass
    class Model(object):
        a: int
        b: int
        c: Optional[CatchAllVar] = field(default=None)

    model1 = Model(a=1, b=2, c={"d": 4})
    assert model1.c == {"d": 4}
    # Test that the handle_to_dict method works correcly
    for undefined_parameter_model in [Undefined.INCLUDE.value,
                                      Undefined.RAISE.value,
                                      Undefined.EXCLUDE.value]:
        kvs = dataclasses.asdict(model1)
        kvs, undefined_parameter_model = \
            undefined_parameter_model.handle_to_dict(model1, kvs), \
            undefined

# Generated at 2022-06-21 11:40:06.029869
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-21 11:40:09.321518
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _CatchAllUndefinedParameters.handle_dump(None) == {}
    assert _IgnoreUndefinedParameters.handle_dump(None) == {}
    assert _RaiseUndefinedParameters.handle_dump(None) == {}

# Generated at 2022-06-21 11:40:14.126428
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    """
    Only tests that the catch-all field is used.
    """
    catch_all_field = Field(name="test", type=CatchAllVar)
    obj = type("TestObject", (object,), {catch_all_field.name: {"x": "y"}})
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"x": "y"}

# Generated at 2022-06-21 11:40:19.938113
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

    parameters = {"a": 1, "b": 2, "c": 3}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, parameters)



# Generated at 2022-06-21 11:40:31.594754
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    Foo = dataclasses.make_dataclass('Foo', [('name', str),
                                             ('age', int, 42)])

    def foo_init(self, name: str, age: int):
        self.name = name
        self.age = age + 1

    Foo.__init__ = foo_init
    # Test: no parameter
    foo = Foo(name='Paul')
    assert foo.age == 43

    # Test: no parameter, define parameter
    foo = Foo(name='Paul', age=5)
    assert foo.age == 6

    # Test: parameter, no parameter, define parameter
    foo = Foo(name='Paul', spam='eggs', age=5)
    assert foo.age == 6

    # Test: parameter, parameter, no parameter, define parameter

# Generated at 2022-06-21 11:40:39.964769
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class catch_all:
        pass
    obj = catch_all()
    obj.__dict__["a"] = 5
    obj.__dict__["b"] = 6
    obj.__dict__["c"] = 7
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {"a": 5, "b": 6, "c": 7}
    assert _IgnoreUndefinedParameters.handle_dump(obj) == {}
    try:
        _RaiseUndefinedParameters.handle_dump(obj)
        assert False
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:40:41.502270
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    method = _CatchAllUndefinedParameters.handle_dump
    assert method(obj=None)=={}

# Generated at 2022-06-21 11:40:47.612553
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    k = _UndefinedParameterAction
    k = k.handle_from_dict
    k = k.handle_to_dict
    k = k.handle_dump
    k = k.create_init
    k = k._separate_defined_undefined_kvs
    k = k.handle_from_dict
    k = k.handle_to_dict
    k = k.handle_dump
    k = k.create_init
    k = k._separate_defined_undefined_kvs
    k = k.handle_from_dict
    k = k.handle_to_dict
    k = k.handle_dump
    k = k.create_init
    k = k._separate_defined_undefined_kvs

# Generated at 2022-06-21 11:43:09.927584
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError('Test')

# Generated at 2022-06-21 11:43:16.698621
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    class A:
        def __init__(self, a: int, b: int, *,
                     catch_all: Optional[CatchAll] = None):
            self.a = a
            self.b = b
            self.catch_all = catch_all or {}

    import pytest

    A_schema = {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "integer"},
        },
    }
    a = A(a=1, b=2, c=3)
    assert a.a == 1
    assert a.b == 2
    assert a.catch_all == {"c": 3}

    a = A(a=1, b=2)
    assert a.a == 1
    assert a.b == 2


# Generated at 2022-06-21 11:43:23.555270
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a, b, c=3, d: str = "33", e: int = None,
                     f: Optional[str] = None, g: Optional[str] = None):
            pass

    original_init = TestClass.__init__
    self_initialised_init = _UndefinedParameterAction.create_init(obj=TestClass)
    assert self_initialised_init == original_init


# Unit tests for IgnoreUndefinedParameters

# Generated at 2022-06-21 11:43:24.497401
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    _ = UndefinedParameterError("Undefined Parameter Error")

# Generated at 2022-06-21 11:43:34.389681
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class Mock:
        def __init__(self, x: int, y: int, z: int = -1):
            """
            Mock init constructor for testing purpose
            """
            self.x = x
            self.y = y
            self.z = z

    MockWithUnknownParams = dataclasses.make_dataclass(
        "MockWithUnknownParams", [
            ('x', int),
            ('y', int),
            ('z', int, -1),
        ],
        # noinspection PyTypeChecker
        undefined=Undefined.INCLUDE
    )


# Generated at 2022-06-21 11:43:40.765434
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: int, b: bool, **kwargs):
            pass

    known, unknown = _IgnoreUndefinedParameters.handle_from_dict(
        A, {"a": 1, "b": True, "c": None, "d": ""})
    assert known == {"a": 1, "b": True}
    assert unknown == {}



# Generated at 2022-06-21 11:43:51.535333
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    def init_method(self, a, b: int, c: str = "default", *args, **kwargs):
        print(f"a: {a}, b: {b}, c: {c}")

    with_nothing = _UndefinedParameterAction.create_init(init_method)
    with_nothing(None, 1, 2)
    with_nothing(None, 1, 2, c=3, d=4)

    with_ignored = _IgnoreUndefinedParameters.create_init(init_method)
    with_ignored(None, 1, 2)
    with_ignored(None, 1, 2, c=3, d=4)

    with_catch_all_init = _CatchAllUndefinedParameters.create_init(
        init_method)


# Generated at 2022-06-21 11:43:52.288804
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-21 11:43:54.818932
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    obj = _UndefinedParameterAction()
    assert hasattr(obj, "create_init"), "Should have create_init"
    assert hasattr(obj, "handle_dump"), "Should have handle_dump"
    assert hasattr(obj, "handle_to_dict"), "Should have handle_to_dict"
    assert hasattr(obj, "handle_from_dict"), "Should have handle_from_dict"

# Generated at 2022-06-21 11:43:59.841062
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from copy import copy
    from dataclasses import dataclass

    @dataclass
    class BogusClass:
        a: int = 0
        b: int = 1
        x: int = 2

    input_dict = {"a": 0, "b": 1, "x": 2, "y": 3, "z": 4}

    _IgnoreUndefinedParameters.handle_from_dict(cls=BogusClass,
                                             kvs=input_dict)

    assert input_dict == {"a": 0, "b": 1, "x": 2, "y": 3, "z": 4}
