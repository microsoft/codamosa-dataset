

# Generated at 2022-06-21 11:34:32.521748
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, a: int, b: str):
            pass

    kvs = {"a": 1, "b": "b"}
    _RaiseUndefinedParameters.handle_from_dict(Foo, kvs)



# Generated at 2022-06-21 11:34:34.447904
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError()
    assert str(e) == 'UndefinedParameterError'


# Generated at 2022-06-21 11:34:37.222853
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Test:
        def __init__(self, a, b, c):
            pass

    assert _UndefinedParameterAction.create_init(Test) == Test.__init__



# Generated at 2022-06-21 11:34:42.159837
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, dict1, int1, dict2=None):
            self.dict1 = dict1
            self.int1 = int1
            self.dict2 = dict2


    # Act
    catch_all_field = _CatchAllUndefinedParameters.handle_to_dict(TestClass,
                                                                  {"dict1": 1,
                                                                   "int1": 1,
                                                                   "dict2": 2})

    # assert
    assert catch_all_field == {"dict1": 1, "int1": 1}

# Generated at 2022-06-21 11:34:53.961541
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    for undefined in Undefined:
        class TestClass:
            @dataclasses.dataclass
            class TestSubclass(undefined=undefined):
                # noinspection PyTypeChecker
                value: Any
                # noinspection PyTypeChecker
                other_value: Any

        # Unit tests for method _UndefinedParameterAction.create_init
        ######################################################################
        # If there are no undefined parameters, init should work as expected #
        ######################################################################

        # Test for init with only undefined parameter
        TestClass.TestSubclass(value=123)

        # Test for init with defined and undefined parameter
        TestClass.TestSubclass(value=123, other_value=456)

        # Test for init with only undefined parameter
        TestClass.TestSubclass(123)

        # Test for init with defined and undefined parameter

# Generated at 2022-06-21 11:35:01.406526
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test(metaclass=dataclasses_json.DataClassJson):
        a: int
        b: int
        c: int = dataclasses.field(metadata=Undefined.INCLUDE)

    kvs = {"a": 1, "c": 2, "_UNDEFINED": 3}
    result = _CatchAllUndefinedParameters.handle_from_dict(Test, kvs)
    assert result == {"a": 1, "c": {"_UNDEFINED": 3}}

    kvs = {"a": 1, "c": CatchAll}
    result = _CatchAllUndefinedParameters.handle_from_dict(Test, kvs)
    assert result == {"a": 1, "c": {}}



# Generated at 2022-06-21 11:35:09.406461
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: str

    defined_kvs = {"a": 1, "b": 2}
    undefined_kvs = {"c": "c", "d": "d"}

    result_kvs = _IgnoreUndefinedParameters.handle_from_dict(
        cls=TestClass, kvs={**defined_kvs, **undefined_kvs})

    test_passed = result_kvs == defined_kvs
    assert test_passed



# Generated at 2022-06-21 11:35:12.262768
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        pass

    undef_param_handle = _RaiseUndefinedParameters()
    undef_param_handle.handle_from_dict(cls=Foo, kvs={})



# Generated at 2022-06-21 11:35:20.481430
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    class TestClass:
        pass

    test_instance = TestClass()
    result = _CatchAllUndefinedParameters.handle_dump(test_instance)
    assert result == {}

    test_instance.undefined = {}
    result = _CatchAllUndefinedParameters.handle_dump(test_instance)
    assert result == {}

    test_instance.undefined = {"a": 1, "b": 2}
    result = _CatchAllUndefinedParameters.handle_dump(test_instance)
    assert result == {"a": 1, "b": 2}



# Generated at 2022-06-21 11:35:25.112153
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: int

    try:
        _RaiseUndefinedParameters.handle_from_dict(Test, {})
    except UndefinedParameterError as e:
        assert "Received undefined initialization arguments {}" in str(e)



# Generated at 2022-06-21 11:35:47.493101
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class Example:
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(
            default=None
        )

        def __init__(self, a: int, b: Optional[CatchAllVar]):
            self.a = a
            self.b = b

    example = Example(a=1, b={"x": "y", "a": "b"})
    kvs = {
        "a": 1,
        "b": {"x": "y", "a": "b"}
    }
    kvs = _CatchAllUndefinedParameters.handle_to_dict(obj=Example, kvs=kvs)

# Generated at 2022-06-21 11:36:00.504596
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class ClassWithInit(dataclasses.Dataclass):
        a: int
        b: int

    class ClassWithoutInit(dataclasses.Dataclass):
        a: int
        b: int

    def test_instance_with_init(cls, value):
        if value == 5:
            assert cls.init_is_ignored is False
            assert cls.old_init_is_preserved is True
        else:
            assert cls.init_is_ignored is True
            assert cls.old_init_is_preserved is False

    def test_instance_without_init(cls, value):
        if value == 5:
            assert cls.init_is_ignored is False
            assert cls.old_init_is_preserved is False

# Generated at 2022-06-21 11:36:06.480283
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass():
        a: int

        def __init__(self, a: int):
            pass

    test_class = TestClass()
    new_init = _UndefinedParameterAction.create_init(test_class)

    test_class = TestClass()
    new_init(test_class, 123)
    assert test_class.a == 123



# Generated at 2022-06-21 11:36:17.354305
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        def __init__(self, par1: int, par2: int,
                     undef_par: Optional[CatchAllVar] = None):
            self.par1 = par1
            self.par2 = par2
            self.undef_par = undef_par

    new_init = \
        _CatchAllUndefinedParameters.create_init(obj=TestClass)

    # Test that new_init works like the original init:
    class1 = TestClass(1, 2)
    class2 = new_init(class1, par1=5, par2=6)
    assert new_init(TestClass, 1, 2) == TestClass(1, 2, {})
    assert class2 == TestClass(5, 6, {})

    # Test

# Generated at 2022-06-21 11:36:28.983110
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        s: str
        i: int
        d: CatchAll = None
        f: float = dataclasses.field(default=0.0)
        l: list = dataclasses.field(default_factory=list)

    # These should succeed
    TestClass(s="a", i=1)
    TestClass(s="a", i=1, d={})
    TestClass(s="a", i=1, f=1.1, d={})
    TestClass(s="a", i=1, f=1.1, d={"s": "a"})
    TestClass(s="a", i=1, f=1.1, d={"s": "a"}, l=[1, 2, 3])
    Test

# Generated at 2022-06-21 11:36:39.438722
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Foo:
        def __init__(self, a: int, b: int = 10):
            pass

    _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 5})
    _RaiseUndefinedParameters.handle_from_dict(Foo, {"b": 5})
    _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 7, "b": 5})
    try:
        _RaiseUndefinedParameters.handle_from_dict(Foo, {"a": 7, "b": 5,
                                                         "c": 100})
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-21 11:36:46.639915
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses_json.letter_case import LetterCase

    @dataclasses.dataclass
    class Temp:
        my_catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict,
            metadata={
                "marshmallow_field": dataclasses_json.fields.CatchAll})

        def __init__(self, *args, **kwargs):
            extra_args = [v for i, v in enumerate(args)
                          if f"_UNKNOWN{i}" in kwargs]
            if len(extra_args) > 0:
                raise ValueError("Extra positional parameters")

        def __eq__(self, other):
            return type(self) == type(other) and self.my_catch_all == \
                   other.my_catch_

# Generated at 2022-06-21 11:36:58.645121
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class _TestClass:
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            pass

    obj = _TestClass(1, 2, 3)
    new_init = _IgnoreUndefinedParameters.create_init(obj)
    new_obj = _TestClass(1, 2, 3, d=4, e=5)
    assert obj.a == 1
    assert obj.b == 2
    with pytest.warns(UserWarning):
        new_obj = _TestClass(1, 2, 3, d=4, e=5)
    assert new_obj.a == 1
    assert new_obj.b == 2

# Generated at 2022-06-21 11:37:07.713897
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses_json.utils import CatchAllVar

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class MyClass:
        a: int
        b: float
        c: str
        d: bool
        e: CatchAllVar

    obj = MyClass(1, 2.3, "4", True, CatchAllVar({'hello': 'world'}))
    params = _CatchAllUndefinedParameters.handle_dump(obj)
    assert params.get('hello') == 'world'
test__CatchAllUndefinedParameters_handle_dump()

# Generated at 2022-06-21 11:37:17.884642
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    def run_handle_from_dict(kvs: dict, params_should_be_included: dict) -> dict:
        class A:
            def __init__(self, a, b, c):
                self.a = a
                self.b = b
                self.c = c

        return _RaiseUndefinedParameters.handle_from_dict(cls=A, kvs=kvs)

    params_should_be_included = {"a": 1, "b": 2, "c": 3}
    kvs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    assert run_handle_from_dict(kvs=kvs,
                                params_should_be_included=params_should_be_included) == params_should_be_in

# Generated at 2022-06-21 11:37:33.141621
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError()
    UndefinedParameterError(message="test")

# Generated at 2022-06-21 11:37:43.815367
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    RaiseUndefinedParameters = _RaiseUndefinedParameters()
    assert RaiseUndefinedParameters.handle_from_dict(None, None) == {}

    class TestClassEmpty:
        pass
    TestClassEmpty = dataclasses.make_dataclass(TestClassEmpty)
    with pytest.raises(UndefinedParameterError):
        RaiseUndefinedParameters.handle_from_dict(TestClassEmpty, {'a': 1})

    class TestClassOne:
        def __init__(self, a):
            self.a = a

    TestClassOne = dataclasses.make_dataclass(TestClassOne)
    assert RaiseUndefinedParameters.handle_from_dict(TestClassOne, {'a': 1}) == {'a': 1}

    class TestClassTwo:
        def __init__(self, a, b):
            self

# Generated at 2022-06-21 11:37:48.336882
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class ClassToDump:
        a: str
        b: int
        c: dict = dataclasses.field(default_factory=dict)
        d: list = dataclasses.field(default_factory=list)
        e: tuple = dataclasses.field(default_factory=tuple)

    class_to_dump = ClassToDump(a="a", b=1, c={"c1": "v1", "c2": "v2"}, d=[1, 2], e=(1, 2))
    assert _CatchAllUndefinedParameters.handle_dump(class_to_dump) == {"c1": "v1", "c2": "v2"}



# Generated at 2022-06-21 11:37:59.519386
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class Cat:
        color: str
        fluffiness: float
        age: CatchAll = dataclasses.field(default=5)


    c = Cat("grey", 42.0)
    assert c.age == 5
    c = Cat("grey", 42.0, age=dict(some="field", another=42))
    assert c.age == dict(some="field", another=42)
    c = Cat("grey", 42.0, another="field")
    assert c.age == dict(another="field")
    c = Cat("grey", 42.0, another="field", age=dict(some="f1"))
    assert c.age == dict(some="f1", another="field")

# Generated at 2022-06-21 11:38:02.105358
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    instance = _UndefinedParameterAction()
    assert isinstance(instance, _UndefinedParameterAction)


# Unit tests for class _RaiseUndefinedParameters

# Generated at 2022-06-21 11:38:13.279495
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_instance = TestClass("a", "b")
    assert _RaiseUndefinedParameters.handle_from_dict(
        cls=test_instance.__class__, kvs={"a": "a", "b": "b"}) == {"a": "a",
                                                                   "b": "b"}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(
            cls=test_instance.__class__, kvs={
                "a": "a",
                "b": "b",
                "c": "c"})

    with pytest.raises(UndefinedParameterError):
        _RaiseUnd

# Generated at 2022-06-21 11:38:16.100886
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Foo:
        def __init__(self, *args, **kwargs):
            pass

    foo_instance = Foo()
    _UndefinedParameterAction.create_init(Foo)(foo_instance)

# Generated at 2022-06-21 11:38:23.705762
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class MyClass:
        a: int
        b: int

        def __init__(self, a: int, b: int):
            pass

    init = _UndefinedParameterAction.create_init(obj=MyClass)
    init(MyClass, 1)
    init(MyClass, 1, 2)
    init(MyClass, 1, b=2)
    init(MyClass, a=1, b=2)
    init(MyClass, a=1)
    init(MyClass)
    try:
        init(MyClass, b=2)
        assert False, "Did not raise TypeError"
    except TypeError:
        pass

# Generated at 2022-06-21 11:38:24.291485
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    pass

# Generated at 2022-06-21 11:38:30.678544
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=object, kvs=dict()) == (dict(), dict())
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=object, kvs={"a": 1}) == (dict(), dict(a=1))
    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=object, kvs={"self": 1}) == (dict(), dict(self=1))



# Generated at 2022-06-21 11:39:07.941998
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters

# Generated at 2022-06-21 11:39:12.014489
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Test:
        a: int = 1
        b: str = "b"
        c: Optional[CatchAllVar] = None

    test = Test(b="a", c={"c": "c"})
    assert _CatchAllUndefinedParameters.handle_dump(test) == {"c": "c"}

# Generated at 2022-06-21 11:39:17.038770
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Person:
        def __init__(self, a: int, b: str):
            pass

    test_input = {"a": 1, "b": "hello", "c": "extra parameter"}
    try:
        _RaiseUndefinedParameters.handle_from_dict(Person, kvs=test_input)
    except UndefinedParameterError as e:
        assert str(e) == "Received undefined initialization arguments {'c': " \
                         "'extra parameter'}"
        return
    assert False



# Generated at 2022-06-21 11:39:20.074758
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    """
    Helper method for tests to access private constructor of
    _CatchAllUndefinedParameters.
    Note that we cannot test this via the public interface as we cannot access
    the private init constructor of the class.
    """
    return _CatchAllUndefinedParameters


# Generated at 2022-06-21 11:39:28.458725
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    # empty dictionary contains no undefined parameters
    assert _UndefinedParameterAction.handle_dump({}) == {}
    # empty dict subclass contains no undefined parameters
    assert _UndefinedParameterAction.handle_dump(dict()) == {}
    # a dict subclass that inherits from dict is treated like a dict
    assert _UndefinedParameterAction.handle_dump(dict()) == {}
    # a dict subclass that doesn't inherit dict is not treated like a dict
    # this might be unwanted behavior
    assert _UndefinedParameterAction.handle_dump(dict) == {}
    pass

# Generated at 2022-06-21 11:39:33.534442
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    init = _CatchAllUndefinedParameters.create_init(obj=TestClass)
    tc = TestClass(a=1, b=2, c=3, _UNKNOWN0=4, _UNKNOWN1=5, b=6)
    assert tc.a == 1
    assert tc.b == 6
    assert tc.c == 3
    assert tc.get_catch_all() == {'_UNKNOWN0': 4, '_UNKNOWN1': 5}



# Generated at 2022-06-21 11:39:37.572466
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class _Class:
        def __init__(self, defined: str = "defined",
                     undefined: str = "undefined"):
            self._defined = defined
            self._undefined = undefined

    _ = _RaiseUndefinedParameters()



# Generated at 2022-06-21 11:39:48.351289
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from unittest.mock import MagicMock, call

    class A:
        def __init__(self, a: int, b: int, c: int, catch_all: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all
            self.__init__.called = False

        def __init__(self, *args, **kwargs):
            self.__init__.called = True

    init_function = _CatchAllUndefinedParameters.create_init(A)
    instance = A(1, 2, 3)
    init_function(instance, 1, 2, 3, 4)
    extra_kwargs = {str(i): i for i in range(4, 100)}

# Generated at 2022-06-21 11:39:59.594693
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import sys
    import types
    import unittest
    import tempfile
    from contextlib import contextmanager

    @dataclasses.dataclass
    class Test(object):
        a: str
        b: str
        c: str

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    @contextmanager
    def temp_module(name, source):
        module = types.ModuleType(name)
        sys.modules[name] = module
        print(f"Module {name} created")

# Generated at 2022-06-21 11:40:02.141839
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError("test")
    assert e.messages == ['test']


action = Undefined.INCLUDE.value

# Generated at 2022-06-21 11:41:03.632603
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class _Test:
        def __init__(self, a: int, b: int = 0, catch_all: Optional[CatchAll] =
        None):
            self.a = a
            self.b = b
            self.catch_all = catch_all


    test_obj = _Test(1, b=2, c=3)
    kvs = {"a": 1, "b": 2, "catch_all": {"c": 3}}
    res = _CatchAllUndefinedParameters.handle_to_dict(test_obj, kvs)
    expected = {"a": 1, "b": 2, "c": 3}
    assert res == expected

# Generated at 2022-06-21 11:41:09.830765
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def do_the_test(cls, test_values: Dict[str, Any]):

        class WithCatchAll:
            def __init__(self, test_parameter: str,
                         undefined: CatchAll = None):
                self.test_parameter = test_parameter
                self.undefined = undefined

        class WithoutCatchAll:
            def __init__(self, test_parameter: str):
                self.test_parameter = test_parameter

        def _do_the_test(cls, test_values: Dict[str, Any]):
            init_func = cls.create_init(cls)
            init_func(cls, **test_values)


# Generated at 2022-06-21 11:41:10.427064
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    pass



# Generated at 2022-06-21 11:41:11.741127
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    error = UndefinedParameterError("test message")
    assert error.message == "test message"

# Generated at 2022-06-21 11:41:18.743997
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class TestClass:
        first: str

        def second_method(self) -> int:
            pass

        def __init__(self, first: str, unknown: Optional[CatchAllVar] = {}):
            self.first = first
            self.unknown = unknown
            super().__init__()

    t = TestClass("first")
    kvs = dict(first="foo", second="bar")
    expected = dict(first="foo", second="bar")
    actual = _CatchAllUndefinedParameters.handle_to_dict(t, kvs)
    assert expected == actual



# Generated at 2022-06-21 11:41:30.045817
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():

    def test_case(show_code: bool = False):
        @dataclasses.dataclass
        class Test:
            a: int
            b: str
            ca: CatchAll

            def __init__(self, a: int, b: str, ca: Optional[CatchAll] = None):
                self.a = a
                self.b = b
                self.ca = ca or {}

        init_function = _CatchAllUndefinedParameters.create_init(Test)

        def test(args, kwargs, expected_result):
            result = init_function(Test(a=0, b="", ca={}), *args, **kwargs)
            if show_code:
                print(f"TEST: init_function({args}, {kwargs}) == {expected_result}")

# Generated at 2022-06-21 11:41:39.212105
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int
        b: Optional[str]

    assert _IgnoreUndefinedParameters.handle_from_dict(MyClass,
                                                       {"a": 1, "b": "c"}) == \
           {"a": 1, "b": "c"}
    assert _IgnoreUndefinedParameters.handle_from_dict(MyClass,
                                                       {"a": 1, "b": "c",
                                                        "c": "d"}) == \
           {"a": 1, "b": "c"}
    assert _IgnoreUndefinedParameters.handle_from_dict(MyClass,
                                                       {"a": 1}) == {"a": 1}


# Generated at 2022-06-21 11:41:40.351800
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert isinstance(_UndefinedParameterAction, type)

# Generated at 2022-06-21 11:41:41.175529
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    cls = _UndefinedParameterAction
    cls()

# Generated at 2022-06-21 11:41:46.291064
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        undefined: Optional[CatchAllVar]

    test_object = TestClass("a", "b", {"x": "y"})
    dump = _CatchAllUndefinedParameters.handle_dump(test_object)
    assert dump == {"x": "y"}

# Generated at 2022-06-21 11:44:05.424796
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():

    class DummyClass:
        def __init__(self, a, b, d):
            self.a = a
            self.b = b
            self.d = d

    # noinspection PyTypeChecker
    kvs = {"a": "a_value", "b": "b_value", "c": "c_value", "d": "d_value"}
    expected_kvs = {"a": "a_value", "b": "b_value", "d": "d_value"}
    assert _RaiseUndefinedParameters.handle_from_dict(
        DummyClass, kvs) == expected_kvs



# Generated at 2022-06-21 11:44:16.146266
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int

        def __init__(self, a=1, **kwargs):
            pass

    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, {"b": 3})
    assert {"a": 1, "b": 3} == result
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, {"a": 3})
    assert {"a": 3} == result
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, {})
    assert {"a": 1} == result

    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, {"a": 3, "b": 4})
    assert {"a": 3, "b": 4} == result

    result