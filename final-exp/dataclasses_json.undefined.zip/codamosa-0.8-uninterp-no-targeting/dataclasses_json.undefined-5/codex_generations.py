

# Generated at 2022-06-21 11:34:36.147996
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class A:
        a: int
        b: int

    assert _RaiseUndefinedParameters.handle_from_dict(
        A, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2}
    try:
        _RaiseUndefinedParameters.handle_from_dict(
            A, {"a": 1, "b": 2, "c": 3, "d": 4})
    except UndefinedParameterError:
        pass
    else:
        raise Exception("Did not raise")


# Generated at 2022-06-21 11:34:38.530741
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Unit tests for method _separate_defined_undefined_kvs of class _UndefinedParameterAction

# Generated at 2022-06-21 11:34:41.542408
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    @dataclasses.dataclass
    class Integer(object):
        val: int
        _undefined_parameters: _UndefinedParameterAction = \
            _UndefinedParameterAction

    obj = Integer(val=42)

    assert _UndefinedParameterAction.handle_dump(obj) == {}



# Generated at 2022-06-21 11:34:46.795962
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyUnresolvedReferences
    class MockClass(object):
        def __init__(self, foo: str, bar: int,
                     no_default: str = "no_default_value",
                     with_default: int = 123,
                     default_factory: str = None,
                     catch_all: CatchAll = None):
            setattr(self, "foo", foo)
            setattr(self, "bar", bar)
            setattr(self, "no_default", no_default)
            setattr(self, "with_default", with_default)
            setattr(self, "default_factory", default_factory)
            setattr(self, "catch_all", catch_all)

    # Case 1: Empty catch_all field

# Generated at 2022-06-21 11:34:55.120756
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass(undefined=Undefined.RAISE)
    class TestClass:
        a: str
        b: str

    c = TestClass("I am a", "I am b")
    assert c.a == "I am a" and c.b == "I am b"

    try:
        TestClass({"a": "I am a", "b": "I am b", "c": "I am c"})
        assert False
    except UndefinedParameterError as e:
        assert "c" in str(e)



# Generated at 2022-06-21 11:34:57.597251
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class DummyClass():
        def __init__(self, *, a:str, b: str, c: str=None, **kwargs):
            pass
    init = _IgnoreUndefinedParameters.create_init(DummyClass)
    dummy_class = DummyClass()
    init(dummy_class, "a", "b", "c", d="d")



# Generated at 2022-06-21 11:35:02.210730
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # this test uses the file "test_io" to verify that the new create_init
    # method produces the same results as the old one
    from marshmallow import Schema
    import dataclasses_json.tests.test_io
    import inspect
    import functools

    class _Tester:
        def __init__(self, action: _UndefinedParameterAction):
            self.old_create_init = action.create_init
            self.new_create_init = _UndefinedParameterAction.create_init

        def test(self, cls):
            """
            Returns true if the new and the old create_init function
            produce the same result
            """
            old_init, new_init = self.old_create_init(cls), \
                                 self.new_create_init(cls)
            old_sign

# Generated at 2022-06-21 11:35:12.298521
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    from dataclasses_json.core import config, DataClassJsonMixin


    @config(undefined=Undefined.INCLUDE)
    class Foo(DataClassJsonMixin):
        field: int


    assert Foo(field=1).dict() == {"field": 1}

    @config(undefined=Undefined.INCLUDE)
    class Foo(DataClassJsonMixin):
        field: int
        catch_all: Optional[CatchAllVar]


    assert Foo(field=1, catch_all={
        "undefined_field": "undefined_value"}).dict() == {
               "field": 1, "undefined_field": "undefined_value"}

    @config(undefined=Undefined.INCLUDE)
    class Foo(DataClassJsonMixin):
        field

# Generated at 2022-06-21 11:35:16.490966
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str

        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj = TestClass("a", "b")

    init = _IgnoreUndefinedParameters.create_init(obj)

    import ipdb
    ipdb.set_trace()

    # Test 1:
    # _IgnoreUndefinedParameters._get_catch_all_field(obj)

    # Test 2:
    # Test normal initialization

    # Test 3:
    # Test undefined parameter dict

# Generated at 2022-06-21 11:35:21.101699
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:
        y: int

    with pytest.raises(UndefinedParameterError) as e:
        _RaiseUndefinedParameters.handle_from_dict(TestClass, {"x": 10})
    assert "Received undefined initialization arguments {'x': 10}" in str(e)



# Generated at 2022-06-21 11:35:46.147886
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, field

    @dataclass
    class Example:
        x: int
        y: int
        z: Optional[CatchAllVar] = field(default_factory=dict)
        w: int = 0
        __ignore_undefined_parameters__ = True

    original_init = Example.__init__
    init_signature = inspect.signature(original_init)

    @functools.wraps(Example.__init__)
    def _example_init(self, *args, **kwargs):
        kwargs.update({"x": 3, "y": 5, "z": {"a": 1}, "w": 2})
        original_init(self, *args, **kwargs)


# Generated at 2022-06-21 11:35:47.239131
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-21 11:36:00.301337
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class TestClass:
        def __init__(self, x: int, y: int, z: int):
            self.x = x
            self.y = y
            self.z = z

    def test_init_works(self, obj):
        assert isinstance(self, TestClass)
        assert self.x == obj.x
        assert self.y == obj.y
        assert self.z == obj.z

    self = TestClass(x=1, y=2, z=3)

    new_init = _IgnoreUndefinedParameters.create_init(self)
    new_init(self, 1, 2, 3)
    test_init_works(self, self)

    new_init(self, 1, y=2, z=3)
    test_init_works(self, self)

    new_

# Generated at 2022-06-21 11:36:05.589068
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    example_dict = {"a": "b", "c": "d", "e": "f"}
    example_dict_to_dict = {"a": "b", "c": "d", "e": "f"}
    assert _UndefinedParameterAction.handle_to_dict(None, example_dict) == \
           example_dict_to_dict



# Generated at 2022-06-21 11:36:08.664916
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class TestClass:
        pass

    kvs = {"y": 1, "z": 4}
    result = _RaiseUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == {}



# Generated at 2022-06-21 11:36:19.049790
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # This unit test is essential, because it tests that arguments passed to
    # the class can be retrieved.
    # Therefore, it is not enough to just have a code coverage unit test.
    class TestClass:
        def __init__(self, i: int, s: str, c: CatchAll = {}):
            pass

    init = _CatchAllUndefinedParameters.create_init(TestClass)
    # Should take only positional arguments "i" and "s" and
    # put the rest into "c"
    instance = TestClass(1, "positionals_and", "keyword1=1",
                         "keyword2=2")
    assert instance.c == {"keyword1": "1", "keyword2": "2"}
    instance = TestClass(1, "positionals")
    assert instance.c == {}

# Generated at 2022-06-21 11:36:26.349194
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        def __init__(self, a: int, b: int = 1):
            self.a = a
            self.b = b

    kvs = {"a": 3, "b": 4, "c": 5}
    known_kvs = {k: v for k, v in kvs.items() if k in fields(A).keys()}
    assert known_kvs == {'a': 3, 'b': 4}

# Generated at 2022-06-21 11:36:35.731312
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class TestClass:
        def __init__(self, **kwargs):
            self.test_data = "nothing"


# Generated at 2022-06-21 11:36:43.643167
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    def setUp():
        class MyType(object):
            def __init__(self, field1: int, field2: str, field3: int):
                pass

        arguments = {"field1": 1, "field2": "field2", "field3": "3"}
        known_parameters = {"field2": "field2"}
        return MyType, arguments, known_parameters
    # Test if undefined arguments are ignored
    MyType, arguments, known_parameters = setUp()
    assert \
        _IgnoreUndefinedParameters.handle_from_dict(MyType, arguments) == \
        known_parameters

# Generated at 2022-06-21 11:36:44.878154
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction



# Generated at 2022-06-21 11:37:10.321996
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    UndefinedParameterError("something went wrong")

# Generated at 2022-06-21 11:37:16.877517
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class C1:
        def __init__(self, a: int, b: Optional[CatchAllVar] = None) -> None:
            self.a = a
            self.b = b

    @dataclasses.dataclass
    class C2:
        a: int
        b: Optional[CatchAllVar] = dataclasses.field(default=None)

    @dataclasses.dataclass
    class C3:
        a: int
        b: staticmethod = dataclasses.field(default=None)

    def _assert(obj, expected_dump):
        dump = _UndefinedParameterAction.handle_dump(obj)
        assert dump == expected_dump

    _assert(C1(a=0), {'a': 0})

# Generated at 2022-06-21 11:37:22.794378
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, field1, field2, field3, kwarg1=10, kwarg2=20,
                     kwarg3=30, something_else=40):
            pass

    new_init = _IgnoreUndefinedParameters.create_init(TestClass)
    args = (2, 3)
    kwargs = {"field1": 1, "field3": 5, "kwarg1": 1,
              "kwarg3": 5, "something_else": 42}
    new_init(TestClass, *args, **kwargs)

# Generated at 2022-06-21 11:37:26.635398
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class A:
        def __init__(self):
            self.attribute = "value"

    assert _UndefinedParameterAction.handle_dump(A()) == {}

# Generated at 2022-06-21 11:37:33.064319
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class StrategyClass(_UndefinedParameterAction):
        def test_function(self, data: Dict[Any, Any]) -> Dict[Any, Any]:
            pass

    a_class = StrategyClass()
    a_func = a_class.test_function
    # Check our assumptions about 'a_func'
    assert a_func.__name__ == 'test_function'
    assert a_func.__self__ is a_class

    # _UndefinedParameterAction.handle_from_dict() expects a *class* as first
    # argument
    assert _UndefinedParameterAction.handle_from_dict(a_class,
                                                       {'x': 1, 'y': 2}) == {
               'x': 1, 'y': 2}
    # _UndefinedParameterAction.handle_from_dict() expects a *class* as first

# Generated at 2022-06-21 11:37:43.773963
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Foo:
        def __init__(self, bar1: float = 3.14,
                     bar2: float = 1.41,
                     catch_all: Optional[CatchAllVar] = None):
            self.bar1 = bar1
            self.bar2 = bar2
            self.catch_all = catch_all

    obj = Foo(bar1=1.1, bar2=2.2, catch_all={"additional": "field"})
    kvs = {"bar1": 1.1, "bar2": 2.2, "additional": "field"}
    kvs2 = _CatchAllUndefinedParameters.handle_to_dict(obj, kvs)
    assert kvs2 == {"bar1": 1.1, "bar2": 2.2, "additional": "field"}

# Generated at 2022-06-21 11:37:48.661568
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():

    class C:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int, *, k: str = "k"):
            pass

    expected_kwargs = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4, "f": 5,
                       "g": 6, "k": "k"}

    class D:
        def __init__(self, a: int, b: int, c: int, d: int, e: int, f: int,
                     g: int):
            pass

    expected = (0, 1, 2, 3, 4)

# Generated at 2022-06-21 11:37:58.582147
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    data = {
        "id": "10",
        "location": "Bavaria",
        "_UNKNOWN1": "abc",
        "_UNKNOWN2": "def",
        "blah": "blub"
    }
    known_parameters = {
        "id": "10",
        "location": "Bavaria"
    }
    expected_result = {
        "id": "10",
        "location": "Bavaria",
        "_UNKNOWN1": "abc",
        "_UNKNOWN2": "def",
        "blah": "blub"
    }

    assert expected_result == \
           _CatchAllUndefinedParameters.handle_to_dict(tuple, known_parameters)

# Generated at 2022-06-21 11:38:10.118827
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    args = {"a": 1, "b": 2, "c": 3}

    @dataclasses.dataclass
    class TestFixture:
        a: int
        b: int
        c: int

    assert _IgnoreUndefinedParameters.handle_from_dict(TestFixture, args) == \
           {"a": 1, "b": 2, "c": 3}

    @dataclasses.dataclass
    class TestFixture:
        b: int

    assert _IgnoreUndefinedParameters.handle_from_dict(TestFixture, args) == \
           {"b": 2}

    @dataclasses.dataclass
    class TestFixture:
        a: int
        b: int
        c: int
        d: int


# Generated at 2022-06-21 11:38:20.132078
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        x: int
        y: int = dataclasses.field(default=1)
        z: int = dataclasses.field(default=2)

        def __post_init__(self):
            self.a = self.x + self.y + self.z

    cls = TestClass
    x, y, z = 5, 2, 3
    kvs = {'x': x, 'y': y, 'z': z}
    final_parameters = _RaiseUndefinedParameters.handle_from_dict(cls=cls,
                                                                   kvs=kvs)
    assert all([param in final_parameters.keys() for param in kvs.keys()])

# Generated at 2022-06-21 11:39:17.252133
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # Setup
    class A:
        def __init__(self, a: int, b: int = 3, c: str = "asdf"):
            self.a = a
            self.b = b
            self.c = c

    obj = A(1, 2, "foo")

    # Test
    new_init = _IgnoreUndefinedParameters.create_init(obj)
    # Assert
    assert new_init(None, 1) == obj
    assert new_init(None, 1, 2) == obj
    assert new_init(None, 1, 2, "foo") == obj
    assert new_init(None, 1, 2, "foo", "bar") == obj



# Generated at 2022-06-21 11:39:23.148226
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses
    from dataclasses_json.config import config
    from dataclasses_json.undefined import Undefined

    @dataclasses.dataclass
    class TestCatchAllClass:
        foo: str
        bar: int
        undefined: Undefined = Undefined.INCLUDE

    obj = TestCatchAllClass(foo="foo", bar=1)
    obj.undefined = {"baz": "baz"}
    schema = config(unknown=Undefined.INCLUDE,
                    letter_case=LetterCase.CAMEL).schema(TestCatchAllClass)
    dumped = schema.dump(obj)
    expected = {
        "foo": "foo",
        "bar": 1,
        "baz": "baz"
    }
    assert dumped == expected


# Unit test

# Generated at 2022-06-21 11:39:32.906879
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    class Example:
        def __init__(self, a, b, c=1, d=2, e=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    kwargs = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
    kwargs = _CatchAllUndefinedParameters.handle_from_dict(Example, kwargs)
    assert "f" not in kwargs
    assert "g" not in kwargs
    assert kwargs["c"] == 3
    assert kwargs["d"] == 4
    assert kwargs["e"] == {"f": 6, "g": 7}


# Unit

# Generated at 2022-06-21 11:39:36.697408
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class DummyClass:
        pass

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters \
            .handle_from_dict(cls=DummyClass, kvs={'x': 5})

# Generated at 2022-06-21 11:39:47.685003
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None)  # type: ignore

    # First test: Defined parameter catch_all overwrites an undefined parameter
    kvs = {"a": 1, "b": 2, "c": 3, "catch_all": {}}
    expected = {"a": 1, "b": 2, "c": 3, "catch_all": {"a": 1, "b": 2, "c": 3}}
    result = _CatchAllUndefinedParameters.handle_from_dict(TestClass, kvs)
    assert result == expected

    # Second test: Don't do anything if no undefined parameters are given
    kvs = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-21 11:39:58.883955
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from marshmallow import Schema, fields

    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int = 5
        c: CatchAll = None
        __undefined__ = Undefined.INCLUDE

        def __init__(self, a: int, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c or {}


    class TestClassSchema(Schema):
        a = fields.Integer()
        b = fields.Integer(allow_none=True)
        c = fields.Dict(keys=fields.String, values=fields.String)



# Generated at 2022-06-21 11:40:10.381697
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class IgnoreSelf:
        def __init__(
                self,
                defined_field: str = "default_defined_field",
                another_defined_parameter: str = "default_another_defined_parameter",
                *args, **kwargs):
            pass

    class IgnoreA1:
        def __init__(self, a1: str, *args, **kwargs):
            pass

    class IgnoreA1Kw:
        def __init__(self, a1: str, *, kw1: str, kw2: str, **kwargs):
            pass

    IgnoreSelfObj = _IgnoreUndefinedParameters.create_init(IgnoreSelf)
    IgnoreSelfObj()
    IgnoreSelfObj(defined_field="my_defined_field",
                  some_other_field="some_other_thing")
    Ignore

# Generated at 2022-06-21 11:40:18.145272
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Test if create_init returns the original method if no undefined
    parameters are defined.
    Also test that it returns the modified method if catch-all is defined.
    """
    from .dataclass_config import config

    @dataclasses.dataclass
    class DummyClass:
        a: int
        b: int
        c: int
        d: int

    dummy_instance = DummyClass(1, 2, 3, 4)

    # Test without catch-all
    assert _UndefinedParameterAction.create_init(
        DummyClass) == DummyClass.__init__
    # Test with catch_all
    with config(undefined=Undefined.INCLUDE):
        assert _UndefinedParameterAction.create_init(
            DummyClass) != DummyClass.__init__

# Generated at 2022-06-21 11:40:30.360935
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    try:
        @dataclasses.dataclass()
        class TestClass:
            pass

        init = _CatchAllUndefinedParameters.create_init(TestClass)
        init(TestClass, 1, 2)
        assert False, "Should raise error because parameters are defined"
    except UndefinedParameterError as err:
        assert "undefined initialization arguments {'_UNKNOWN0': 1, '_UNKNOWN1': 2}" in err.messages
    except:
        assert False, f"Unexpected error: {sys.exc_info()[0]}"

    @dataclasses.dataclass()
    class TestClass:
        a: int
        b: float
        c: str
        cc: str = "default"
        xx: Optional[CatchAllVar] = None


# Generated at 2022-06-21 11:40:41.780417
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, param1: int, param2: int, param3: int):
            self.param1 = param1
            self.param2 = param2
            self.param3 = param3


# Generated at 2022-06-21 11:43:08.360150
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    pass

# Generated at 2022-06-21 11:43:15.023451
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import datetime
    from enum import Enum
    from dataclasses import dataclass, field
    from dataclasses_json import config, DataClassJsonMixin, dataclass_json

    @dataclass
    class FooType(DataClassJsonMixin):
        foo_id: str

    @dataclass
    class TimeStampType(DataClassJsonMixin):
        timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)

    class ActionType(Enum):
        POST = "post"
        GET = "get"

    @config(undefined=Undefined.EXCLUDE)
    @dataclass
    class BarType(DataClassJsonMixin):
        action: ActionType = ActionType.POST
        timestamp: Optional[datetime.datetime]

# Generated at 2022-06-21 11:43:16.697253
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("boo")
    except UndefinedParameterError as exception:
        assert exception.messages == "boo"

# Generated at 2022-06-21 11:43:17.627607
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    pass

# Generated at 2022-06-21 11:43:22.493373
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Cls:
        x: int
        undefined_parameters: CatchAllVar = dataclasses.field(
            default_factory=dict)

    new_cls = Cls(x=1, y=2)
    assert {"y": 2} == _CatchAllUndefinedParameters.handle_dump(new_cls)

# Generated at 2022-06-21 11:43:32.935971
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    - Test if _UndefinedParameterAction.create_init returns the original
    function if the action is RAISE
    - Test _UndefinedParameterAction.create_init returns the according
    function if the action is INCLUDE or EXCLUDE
    """
    # --- Test if all cases of _UndefinedParameterAction return the original
    # method if the action is RAISE
    @dataclasses.dataclass
    class TestDataClass:
        a: int
        b: int

        def __init__(self, a, b):
            self.a = a
            self.b = b

    assert _UndefinedParameterAction.create_init(TestDataClass) == \
           TestDataClass.__init__
    # --- Test if all cases of _UndefinedParameterAction return the original
    # method if the action is RAISE

# Generated at 2022-06-21 11:43:43.764216
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    temp_dict = {}

    @dataclass
    class Test:
        fix: str = "fix"
        fix2: int = 1
        fix3: str = "fix3"
        catch_all: CatchAll = None

        def __init__(self, **kvs):
            super().__init__()
            for k, v in kvs.items():
                setattr(self, k, v)

    obj = Test(fix="fix")
    temp_dict.update(fix="fix")

    assert _CatchAllUndefinedParameters.handle_from_dict(Test, temp_dict) == {
        "fix": "fix",
        "fix2": 1,
        "fix3": "fix3",
        "catch_all": {}
    }

    assert obj.__

# Generated at 2022-06-21 11:43:50.134751
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class MyClass():
        a: int
        b: int
        c: int

        def __init__(self, a: int, b: int, c: int):
            pass

    known = {'a': 1, 'b': 2}
    unknown = {'d': 4}
    kvs = {**known, **unknown}
    _UndefinedParameterAction.handle_from_dict(MyClass, kvs)



# Generated at 2022-06-21 11:43:50.959377
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert _UndefinedParameterAction  # to silence pyflakes

# Generated at 2022-06-21 11:43:57.505737
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # noinspection PyProtectedMember
    import dataclasses_json._fields as _fields
    from dataclasses_json.config import Config
    import dataclasses


    def _test_catch_all_handle_from_dict(cls, kvs: Dict, expected: Dict) -> None:
        result = _CatchAllUndefinedParameters.handle_from_dict(cls=cls, kvs=kvs)
        assert result == expected


    class NoDictNoDefault:
        dct: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)


    class NoDictDefault1:
        dct: Optional[CatchAllVar] = dataclasses.field(
            default={})
        # noinspection PyArgumentList
        # noinspection Py