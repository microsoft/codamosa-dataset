

# Generated at 2022-06-21 11:34:34.953345
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # Using namedtuple to avoid having to create a custom class
    from collections import namedtuple
    TestParameterClass = namedtuple("TestParameterClass",
                                    ['a', 'b', 'c'])

    known, unknown = _RaiseUndefinedParameters.handle_from_dict(
        TestParameterClass, {"a": 1, "b": 2, "c": 3})
    assert known == {'a': 1, 'b': 2, 'c': 3}
    assert unknown == {}

    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(TestParameterClass, {
            "a": 1, "b": 2, "c": 3, "d": 4})



# Generated at 2022-06-21 11:34:46.166492
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    # Original init function
    class A:
        def __init__(self, a: int, b: int, c: str):
            self.a = a
            self.b = b
            self.c = c

    # Make sure original init function works
    assert A(1, 2, "3").a == 1
    assert A(1, 2, "3").b == 2
    assert A(1, 2, "3").c == "3"

    # Make sure that the new version works
    @dataclasses.dataclass()
    class B:
        a: int
        b: int
        c: str
    assert B(1, 2, "3").a == 1
    assert B(1, 2, "3").b == 2
    assert B(1, 2, "3").c == "3"

    #

# Generated at 2022-06-21 11:34:57.021910
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    from dataclasses import dataclass
    from typing import Dict

    class CatchAll(CatchAllVar):
        pass

    @dataclass()
    class TestClass:
        a: int
        b: str
        c: Optional[CatchAll]

        def __init__(self, a: int, b: str, c: Optional[CatchAll] = None):
            self.a = a
            self.b = b
            self.c = c

    @dataclass()
    class TestClassIgnore:
        a: int
        b: str

        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    # Tests for undefined.include, tested with and without catch-all field

# Generated at 2022-06-21 11:35:03.975237
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class C:
        def __init__(self, a, b, c=None, catch_all: CatchAll = None):
            pass


    def assert_handles(cls, output, expected, input=None):
        if input is None:
            input = expected
        obj = cls()
        result = _CatchAllUndefinedParameters.handle_to_dict(
            obj, input)

        assert (result == expected,
                f"Expected {expected} but got {result}")


    expected_dict = {"a": 1, "b": 2, "c": 3}
    assert_handles(C, expected_dict, expected_dict)
    assert_handles(C, expected_dict, {"a": 1, "b": 2, "catch_all": {"c": 3}})

# Generated at 2022-06-21 11:35:13.151745
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class Example:
        def __init__(self, a: int, b: Optional[int] = 1):
            self.a = a
            self.b = b
    example: Example = dataclasses.replace(Example(a=1), b=2)
    assert example.a == 1
    assert example.b == 2

    class Model:
        def __init__(self, a: int, b: Optional[int] = 1):
            self.a = a
            self.b = b
    model: Model = dataclasses.replace(Model(a=1), b=2)
    assert model.a == 1
    assert model.b == 2

    class Model2(Model):
        def __init__(self, a: int, b: Optional[int] = 1):
            super().__init__(a, b)

# Generated at 2022-06-21 11:35:24.435520
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import dataclasses
    from dataclasses import dataclass, field
    from typing import Optional

    from dataclasses_json import Undefined, config

    CatchAll = Optional[CatchAllVar]

    @dataclass
    class TestObj:
        known_field: str = "a"
        catch_all: CatchAll = field(default_factory=dict)

    @dataclass
    class TestObj2:
        known_field: str = "a"
        catch_all: CatchAll = field(default=dict())

    obj = TestObj()

    # noinspection PyTypeChecker
    ctor = config.undefined.create_init(obj)

    # noinspection PyTypeChecker
    ctor(obj, known_field="b")
    assert obj.known_field == "b"

# Generated at 2022-06-21 11:35:26.316919
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        known: int
        catch_all: Optional[CatchAllVar] = None

        @classmethod
        def handle_undefined_parameters(cls) -> Undefined:
            return Undefined.RAISE

    t = TestClass(known=42, unknown=43)



# Generated at 2022-06-21 11:35:36.322085
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert _RaiseUndefinedParameters.handle_from_dict(
        MyClass,
        {"foo": 123,
         "bar": 2}) == {"foo": 123, "bar": 2}
    assert _RaiseUndefinedParameters.handle_to_dict(
        MyClass,
        {"foo": 123,
         "bar": 2,
         "baz": 3}) == {"foo": 123, "bar": 2, "baz": 3}
    assert _RaiseUndefinedParameters.handle_dump(MyClass) == {}
    assert _RaiseUndefinedParameters.create_init(MyClass) == MyClass.__init__

# Generated at 2022-06-21 11:35:44.132959
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # noinspection PyTypeChecker
    action = _IgnoreUndefinedParameters()

    class Sample:
        def __init__(self):
            self.defined_parameter = 1
            self.undefined_parameter = 2

    sample = Sample()

    expected = {"defined_parameter": 1}

    result = action.handle_to_dict(obj=sample,
                                   kvs={"defined_parameter": 1,
                                        "undefined_parameter": 2})
    assert result == expected

# Generated at 2022-06-21 11:35:52.389608
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import inspect
    from dataclasses import dataclass

    @dataclass
    class A(object):
        param1: int
        param2: int
        param3: int
        param4: Optional[CatchAllVar]

    a = A(1, 2, 3, param4={"a": 1})
    init = _CatchAllUndefinedParameters.create_init(a)
    num_arguments_required = len(inspect.signature(init).parameters) - 1
    assert num_arguments_required == 2

# Generated at 2022-06-21 11:36:13.071011
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    instance = UndefinedParameterError('test')
    assert 'test' == instance.args[0]

# Generated at 2022-06-21 11:36:17.747297
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    dct = dict(a=1, b=2, c=3, e=4)
    cls = {"a": 1, "b": 2, "c": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=cls, kvs=dct)
    assert known == {"a": 1, "b": 2, "c": 3}
    assert unknown == {"e": 4}

# Generated at 2022-06-21 11:36:25.190597
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    @dataclasses.dataclass
    class _TestUndefinedParameterAction(abc.ABC):
        @abc.abstractmethod
        def handle_from_dict(self, kvs: Dict[Any, Any]) -> Dict[str, Any]:
            pass

    test_obj = _TestUndefinedParameterAction()
    with pytest.raises(TypeError, match="Can't instantiate"):
        _UndefinedParameterAction()

# Generated at 2022-06-21 11:36:32.723443
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    import dataclasses
    import unittest.mock
    from dataclasses import dataclass

    @dataclass
    class Dummy:
        a: int

    def assert_raises(error_type, error_text, callable, *args, **kwargs):
        try:
            callable(*args, **kwargs)
        except error_type as e:
            assert error_text == str(e)
        else:
            raise AssertionError("assert_raises did not raise exception")

    assert_raises(UndefinedParameterError,
                  "Received undefined initialization arguments {'c': 1, "
                  "'d': 4}",
                  _RaiseUndefinedParameters.handle_from_dict,
                  cls=Dummy, kvs=dict(a=1, c=1, d=4))



# Generated at 2022-06-21 11:36:43.522014
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import Dict

    class TestClass:
        def __init__(self, arg1: str, arg2: int, arg3: Dict):
            pass

    test_obj = TestClass("str", 1, {})
    signature = inspect.signature(TestClass.__init__)
    num_params_takeable = len(
        signature.parameters) - 1

    unknown_params = {"arg1": "str", "not_an_arg": "str", "_UNKNOWN0": 1,
                      "_UNKNOWN1": {}}

    class_fields = fields(test_obj)
    field_names = [field.name for field in class_fields]
    known_params = {k: v for k, v in unknown_params.items() if
                    k in field_names}

# Generated at 2022-06-21 11:36:49.325345
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    err = UndefinedParameterError("foo")
    assert err.__str__() == "foo"
    assert err.__repr__() == "UndefinedParameterError('foo',)"
    assert not err.field_name
    assert not err.field_names
    assert not err.fields
    assert not err.valid_data

# Generated at 2022-06-21 11:36:55.249921
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    def empty_init(self):
        pass


    class Obj1():
        pass


    obj_class = type("Obj2", (Obj1,), {
        "x": int,
        "__init__": empty_init,
        "_undefined": _RaiseUndefinedParameters
    })

    obj_class(x=3, y=5)



# Generated at 2022-06-21 11:37:03.324498
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    test_dict = {"a": 1, "b": 2, "_UNKNOWN1": 3, "_UNKNOWN2": 4}

    # known parameter a and b, unknown parameters are not removed
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_kvs(
        cls=TestDataClass, kvs=test_dict)
    assert sorted(unknown.items()) == sorted([("_UNKNOWN1", 3),
                                              ("_UNKNOWN2", 4)])
    assert sorted(known.items()) == sorted([("a", 1), ("b", 2)])

    # known parameters a, b and _UNKNOWN1, unknown parameters are removed
    test_dict = {"a": 1, "b": 2, "_UNKNOWN1": 3}
    known, unknown = _UndefinedParameterAction._separate_defined_undefined_

# Generated at 2022-06-21 11:37:12.410447
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    assert Undefined.INCLUDE._value_._get_catch_all_field(
        CatchAllClass.__mro__[0]) == CatchAllClass.__dataclass_fields__["_" +
                                                                        "catch_all"]
    assert Undefined.INCLUDE._value_._get_catch_all_field(
        CatchAllClassWrong.__mro__[0]) == \
           CatchAllClassWrong.__dataclass_fields__["_" +
                                                    "catch_all"]
    assert Undefined.INCLUDE._value_._get_catch_all_field(
        CatchAllClassTypeMismatch.__mro__[0]) == \
           CatchAllClassTypeMismatch.__dataclass_fields__["_" +
                                                           "catch_all"]

# Generated at 2022-06-21 11:37:17.970710
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    d = {'a': 1, 'c': 3, 'b': 2,
         '_CATCH_ALL': {'e': 5, 'd': 4}}
    dc = type('DummyClass', (), d)
    result = _CatchAllUndefinedParameters.handle_to_dict(dc, d)
    assert result == {'a': 1, 'c': 3, 'b': 2, 'e': 5, 'd': 4}
    d = {'a': 1, 'c': 3, 'b': 2}
    dc = type('DummyClass', (), d)
    result = _CatchAllUndefinedParameters.handle_to_dict(dc, d)
    assert result == {'a': 1, 'c': 3, 'b': 2}

# Generated at 2022-06-21 11:37:47.001680
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    known = {"a": 1, "b": 2}
    unknown = {"c": 3, "d": 4}
    assert _IgnoreUndefinedParameters.handle_to_dict(
        obj=object, kvs=known) == known
    assert _IgnoreUndefinedParameters.handle_to_dict(
        obj=object, kvs=known) == known

    dict_with_catch_all = known.copy()
    dict_with_catch_all["CatchAll"] = unknown
    assert _CatchAllUndefinedParameters.handle_to_dict(
        obj=object, kvs=dict_with_catch_all) == known



# Generated at 2022-06-21 11:37:52.781455
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        A: int

    _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs={"A": 3})
    _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs={"A": 3,
                                                                   "B": 2})



# Generated at 2022-06-21 11:38:03.611912
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    # This is a dummmy class to test the IgnoreUndefinedParameters
    # __init__ wrapper for a class.
    @dataclasses.dataclass
    class DummyClass:
        field_1: str
        field_2: int = 5
        non_initialized: str = dataclasses.field(init=False)

    def _check_expectations(wrapper_init,
                            non_initialized_value,
                            field_1_value,
                            field_2_value,
                            extra_field_1_value):
        dummy = DummyClass(field_1=field_1_value, field_2=field_2_value,
                           extra_field_1=extra_field_1_value)

# Generated at 2022-06-21 11:38:14.301563
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass(frozen=True)
    class FrozenTestDataclass:
        def __init__(self, a: int, b: int = 3, c: int = 4):
            pass

    @dataclasses.dataclass(frozen=False)
    class TestDataclass:
        a: int
        b: int = 3
        c: int = 4

    # noinspection PyShadowingNames
    class FakeUndefinedParameterAction(_UndefinedParameterAction):
        pass

    fake = FakeUndefinedParameterAction()

    assert FakeUndefinedParameterAction.create_init(FrozenTestDataclass) \
           == FrozenTestDataclass.__init__
    assert FakeUndefinedParameterAction.create_init(TestDataclass) \
           != TestDataclass.__init__



# Generated at 2022-06-21 11:38:24.328217
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    kvs = {"a": 1, "b": 2, "c": 3}
    known, undefined = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            TestClass, kvs)

    assert known == {"a": 1, "b": 2}
    assert undefined == {"c": 3}

    # test the inverse case
    kvs = {"a": 1, "b": 2}
    known, undefined = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            TestClass, kvs)

    assert known == {"a": 1, "b": 2}
    assert undefined == {}


# Generated at 2022-06-21 11:38:30.951705
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, first: int, second: int, third: int,
                     fourth: int = 4, fifth: int = 5,
                     catch_all: Optional[CatchAllVar] = None, seventh: int = 7,
                     eighth: int = 8, ninth: int = 9):
            self.first = first
            self.second = second
            self.third = third
            self.fourth = fourth
            self.fifth = fifth
            self.catch_all = catch_all
            self.seventh = seventh
            self.eighth = eighth
            self.ninth = ninth
            assert third == 3
            assert fourth == 4


# Generated at 2022-06-21 11:38:37.430326
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        # noinspection PyMissingConstructor
        def __init__(self, name: str, age: int = 0,
                     unknown: int = 0) -> None:
            self.name = name
            self.age = age
            self.unknown = unknown

    test = _IgnoreUndefinedParameters.create_init(Test)
    test(Test(), "Name", 1, 2, 3, 4)

# Generated at 2022-06-21 11:38:49.202034
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field1: str
        field2: int
        field3: list
        field4: bool
        field5: str

    @dataclass
    class TestClassUnknownParameters:
        field1: str
        field2: int
        field3: list
        field4: bool
        field5: str = Undefined.INCLUDE

    @dataclass
    class TestClassUnknownParametersCatchAll:
        field1: str
        field2: int
        field3: list
        field4: bool
        field5: CatchAll = Undefined.INCLUDE


    class_to_test = TestClass


# Generated at 2022-06-21 11:38:58.835387
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    from collections import defaultdict
    from unittest import TestCase, mock

    class _Mock:
        pass

    mocked_obj = _Mock()

    # Test if nothing is changed if there is no catch all field.
    kvs = {"a": "a"}
    expected = {"a": "a"}
    returned = _UndefinedParameterAction.handle_to_dict(mocked_obj, kvs)
    assert returned == expected

    # Test if nothing is changed if there is a catch all field.
    class _MockCatchAll(_Mock):
        @dataclasses.dataclass
        class _:
            catch_all: CatchAll = dataclasses.field(
                default_factory=dict)

    mocked_obj = _MockCatchAll()
    return_value = _UndefinedParameterAction.handle_

# Generated at 2022-06-21 11:38:59.523623
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    pass

# Generated at 2022-06-21 11:40:00.740199
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import marshmallow as ma
    import pytest
    import pytest_mock

    @dataclasses.dataclass
    class _TestClass:
        name: str
        age: int
        _undefined_parameter_action: _UndefinedParameterAction = \
            _UndefinedParameterAction

        def __init__(self, name, age, **kwargs):
            self.name = name
            self.age = age

        @ma.post_load
        def make_student(self, data, **kwargs):
            data.update(kwargs)
            return _TestClass(**data)

    schema = ma.Schema.from_dataclass(_TestClass)
    schema.dumps({"name": "Alex", "age": 23, "occupation": "Student"})
    assert False


# Unit tests for class

# Generated at 2022-06-21 11:40:12.045295
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class TestClass:
        a: str = dataclasses.field(default="a")

    original_init = TestClass.__init__

    @_IgnoreUndefinedParameters.create_init(TestClass)
    def _ignore_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)

    assert _ignore_init is TestClass.__init__
    TestClass("a")
    TestClass("a")
    TestClass("a", **{"a": "a"})
    try:
        TestClass("a", **{"a": "a", "b": "b"})
    except TypeError as e:
        assert "got an unexpected keyword argument" in str(e)

# Generated at 2022-06-21 11:40:24.499555
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    from dataclasses import dataclass


    @dataclass
    class DummyClass:
        def __init__(self, a=1, b=2, c=3,
                     catch_all: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c
            self.catch_all = catch_all


    dummy_class = DummyClass(1, 2, 3)
    assert dummy_class.a == 1
    assert dummy_class.b == 2
    assert dummy_class.c == 3
    assert dummy_class.catch_all == {}

    dummy_class = DummyClass(a=1, b=2, c=3, catch_all=dict(d=4))
    assert dummy_class.a == 1
    assert dummy_class

# Generated at 2022-06-21 11:40:33.723032
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class CatchAllTest:
        test: str
        unknown: CatchAllVar = dataclasses.field(
            default_factory=dict)
        unknown2: CatchAllVar = dataclasses.field(
            default=dataclasses.MISSING)

    CatchAllTest.__init__ = \
        _CatchAllUndefinedParameters.create_init(CatchAllTest)

    basic = CatchAllTest(test="bla")
    assert basic.unknown == {}
    assert basic.unknown2 == {}

    with_undefined = CatchAllTest(test="bla", test2="blubb")
    assert with_undefined.unknown == {"test2": "blubb"}
    assert with_undefined.unknown2 == {}


# Generated at 2022-06-21 11:40:37.942161
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        a: int

    kvs = {"a": 0, "b": 1}
    actual = _IgnoreUndefinedParameters.handle_from_dict(TestClass, kvs)
    expected = {"a": 0}
    assert actual == expected



# Generated at 2022-06-21 11:40:42.765411
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class CatchAllTest:
        d1: int
        d2: str
        c: Optional[CatchAllVar]

    test_object = CatchAllTest(1, "2", {"d3": 3, "d4": "4"})

    assert _CatchAllUndefinedParameters.handle_dump(test_object) == {"d3": 3, "d4": "4"}

# Generated at 2022-06-21 11:40:44.880830
# Unit test for constructor of class _RaiseUndefinedParameters

# Generated at 2022-06-21 11:40:46.522038
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # Use the class to get a fresh object
    # noinspection PyTypeChecker
    assert isinstance(_RaiseUndefinedParameters(), _UndefinedParameterAction)



# Generated at 2022-06-21 11:40:49.477583
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("a", "b")
    except UndefinedParameterError as e:
        assert str(e) == "a"
        assert repr(e) == "b"
    else:
        assert False

# Generated at 2022-06-21 11:40:59.958717
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, a, b=1):
            pass

    assert _RaiseUndefinedParameters.handle_from_dict(cls=Test,
                                                      kvs={"a": 1}) == \
           {"a": 1}
    assert _RaiseUndefinedParameters.handle_from_dict(cls=Test,
                                                      kvs={"z": 1}) == \
           {}
    assert _RaiseUndefinedParameters.handle_from_dict(cls=Test,
                                                      kvs={"a": 1,
                                                           "b": 2}) == \
           {"a": 1,
            "b": 2}

# Generated at 2022-06-21 11:43:16.653213
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    import pytest

    class MyObject:
        def __init__(self, parameter1, parameter2):
            self.parameter1 = parameter1
            self.parameter2 = parameter2

    created_init = _UndefinedParameterAction.create_init(MyObject)
    my_object = MyObject(1, 2)

    with pytest.raises(TypeError):
        created_init(my_object)

    with pytest.raises(TypeError):
        created_init(my_object, 3)

    with pytest.raises(TypeError):
        created_init(my_object, 3, 4, 5)

    with pytest.raises(TypeError):
        created_init(my_object, parameter1=1)


# Generated at 2022-06-21 11:43:22.185661
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    @dataclasses.dataclass
    class Test(_CatchAllUndefinedParameters):
        a: str
        b: str = "ignore"
        c: str = dataclasses.field(default="ignore")  # type: ignore
        d: str = dataclasses.field(default_factory=lambda: "ignore")  # type: ignore
        e: str = dataclasses.field(default=dataclasses.MISSING)  # type: ignore
        f: str = dataclasses.field(default_factory=dataclasses.MISSING)  # type: ignore
        undefined: dataclasses_json.CatchAll[str] = dataclasses.field(
            default_factory=lambda: {})

    cls = Test

# Generated at 2022-06-21 11:43:32.662851
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class DummyClass:
        a: int
        b: str
        c: float

    @dataclass
    class DummyClassWithCatchAll:
        a: int
        b: str
        c: float = dataclasses.field(metadata={"marshmallow_field": CatchAll})

    dummy_data = {"a": 1, "b": "2", "c": 3.0, "d": "e"}
    dummy_data_catch_all = {"a": 1, "b": "2", "c": {"d": "e"}}

# Generated at 2022-06-21 11:43:35.584821
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    class A:
        def __init__(self, a: str, b: int, c: float):
            pass

    a = _IgnoreUndefinedParameters.create_init(A)
    a(A(), "test", 1, 2.0, d=3, e=4)



# Generated at 2022-06-21 11:43:43.232710
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    try:
        _RaiseUndefinedParameters.handle_from_dict(int, {"foo": 1})
        assert False, "Should raise"
    except UndefinedParameterError:
        pass
    try:
        _RaiseUndefinedParameters.handle_from_dict(int, {})
        assert True, "Should pass"
    except UndefinedParameterError:
        assert False, "Should not raise"
    try:
        _RaiseUndefinedParameters.handle_from_dict(int, {"foo": 1})
        assert False, "Should raise"
    except UndefinedParameterError:
        pass



# Generated at 2022-06-21 11:43:45.387542
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    e = UndefinedParameterError("Test")
    assert e.messages == ["Test"]

# Generated at 2022-06-21 11:43:53.994540
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Foo:
        def __init__(self, a: int, b: int, c: int):
            self.a = a
            self.b = b
            self.c = c

    # noinspection PyArgumentList
    class Bar(_UndefinedParameterAction):
        pass

    _UndefinedParameterAction.create_init(Foo)(Foo, 1, 2, 3)
    _UndefinedParameterAction.create_init(Foo)(Foo, 1, 2, 3, d=4)
    _UndefinedParameterAction.create_init(Foo)(Foo, 1, 2, d=4, e=5)
    _UndefinedParameterAction.create_init(Foo)(Foo, 1, 2, 3, d=4, e=5)


# Generated at 2022-06-21 11:43:54.608187
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    _UndefinedParameterAction()

# Generated at 2022-06-21 11:44:00.533901
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class A:
        x: int
        y: int

    a: Dict[int, int] = {"x": 1, "y": 2}
    b: Dict[int, int] = {"x": 1, "y": 2, "z": 3}

    try:
        _UndefinedParameterAction.handle_from_dict(cls=A, kvs=b)
    except Exception as e:
        e.args[0] == "Received undefined initialization arguments {'z': 3}"
    else:
        assert False, "Did not receive exception"

    result = _UndefinedParameterAction.handle_from_dict(cls=A, kvs=a)
    assert result == {"x": 1, "y": 2}

# Generated at 2022-06-21 11:44:05.125093
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    from dataclasses import dataclass

    @dataclass
    class Test:
        x: int
        y: int = 5
        z: Optional[CatchAllVar] = None

    t = Test(x=3, y=4, z={"a": 1})
    return _CatchAllUndefinedParameters.handle_dump(t) == {}

