

# Generated at 2022-06-21 11:34:37.223514
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int
        c: int
        _undefined_parameters = \
            dataclasses_json._Undefined(
                strategy=dataclasses_json.Undefined.RAISE)

    with pytest.raises(UndefinedParameterError, match=r".*\"foo\".*"):
        TestClass(a=0, b=1, c=2, foo="bar")

    assert TestClass(a=0, b=1, c=2) == TestClass(a=0, c=2, b=1)
    assert TestClass(a=0, b=1, c=2) == TestClass(c=2, b=1, a=0)



# Generated at 2022-06-21 11:34:43.069960
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class _ExampleClass:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    instance = _ExampleClass(1, "2")
    with pytest.raises(TypeError, match="missing 1 required positional argument"):
        _UndefinedParameterAction.create_init(_ExampleClass)(instance)

# Generated at 2022-06-21 11:34:54.571464
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class _TestClass:
        def __init__(self):
            self._attr = 1

        def __getattr__(self, item):
            return getattr(self, "_attr")

    kvs = {"a": 1, "b": 2}
    result = _IgnoreUndefinedParameters._separate_defined_undefined_kvs(
        _TestClass, kvs)
    expected = ({}, kvs)
    assert result == expected
    result = _RaiseUndefinedParameters._separate_defined_undefined_kvs(
        _TestClass, kvs)
    expected = ({}, kvs)
    assert result == expected
    result = _CatchAllUndefinedParameters._separate_defined_undefined_kvs(
        _TestClass, kvs)
    expected = ({}, kvs)
    assert result == expected

# Generated at 2022-06-21 11:34:59.337639
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    try:
        from marshmallow import Schema, fields
    except ImportError:
        return

    undefined_parameter_action = _UndefinedParameterAction

    class TestSchema(Schema):
        a = fields.String(required=True)
        b = fields.String(required=True)
        c = fields.String(required=True)

        @dataclasses.dataclass
        class Meta:
            pass

    schema = TestSchema()

    @dataclasses.dataclass
    class TestClass:
        a: str
        b: str
        c: str

        def __init__(self, a: str, b: str, c: str = "x"):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-21 11:35:02.827722
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    import dataclasses_json
    from dataclasses import dataclass

    from dataclasses_json.utils import CatchAllVar

    @dataclass(undefined=dataclasses_json.Undefined.INCLUDE)
    class CatchAllDataClass:
        x: int
        catch_all: CatchAll = None

    data_class = CatchAllDataClass(x=0, y=1)
    assert data_class.x == 0
    assert data_class.y == 1
    assert data_class.catch_all["y"] == 1



# Generated at 2022-06-21 11:35:03.583975
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    pass

# Generated at 2022-06-21 11:35:12.922412
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    # type: () -> None
    class TestDataClass(object):
        def __init__(self, hello=None,
                     undefined_parameters=Optional[CatchAllVar]):
            # type: (str, Optional[CatchAllVar]) -> None
            self.hello = hello
            self.undefined_parameters = undefined_parameters

    test_data_class_instance = TestDataClass(
        hello="world",
        undefined_parameters={"foo": "bar"}
    )

    init_dict = dataclasses.asdict(
        test_data_class_instance,
        dict_factory=dict
    )

    # Test that the '_CatchAllUndefinedParameters.handle_to_dict' works

# Generated at 2022-06-21 11:35:15.215197
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError('Some error message')
    except UndefinedParameterError as e:
        assert str(e) == 'Some error message'

# Generated at 2022-06-21 11:35:26.239485
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Test:
        def __init__(self, x: float, y: float, z: float,
                     undefined_params: CatchAll = None):
            self.x = x
            self.y = y
            self.z = z
            self.undefined_params = undefined_params

    obj = Test(x=1.2, y=3.45, z=6.789,
               undefined_params={'a': 'A', 'b': 'B', 'c': 'C'})
    kvs = {'x': obj.x, 'y': obj.y, 'z': obj.z,
           'undefined_params': obj.undefined_params}


# Generated at 2022-06-21 11:35:29.199982
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class _TestClass:
        __init__ = None

    param_name = "param"
    value = "value"
    param = {param_name: value}
    actual = _IgnoreUndefinedParameters.handle_from_dict(_TestClass, param)
    assert actual == param

# Generated at 2022-06-21 11:35:43.905471
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    # noinspection PyArgumentList
    instance = _RaiseUndefinedParameters()
    assert isinstance(instance, _UndefinedParameterAction)



# Generated at 2022-06-21 11:35:56.398807
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    import dataclasses
    import dataclasses_json

    @dataclass.dataclass
    class SimpleClass:
        a: int

    @dataclasses_json.dataclass_json(undefined=Undefined.EXCLUDE)
    @dataclass.dataclass
    class Exclude:
        a: int
        b: int

    @dataclasses_json.dataclass_json(undefined=Undefined.RAISE)
    @dataclass.dataclass
    class Raise:
        a: int
        b: int

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    @dataclass.dataclass
    class Include:
        a: int
        b: int
        c: dataclasses_json.CatchAll

# Generated at 2022-06-21 11:36:00.192576
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    assert hasattr(_UndefinedParameterAction, "handle_from_dict")
    assert hasattr(_UndefinedParameterAction, "handle_to_dict")
    assert hasattr(_UndefinedParameterAction, "handle_dump")

# Generated at 2022-06-21 11:36:09.761218
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass
    class A:
        a: int
        b: int

    a = A(1, 2)
    # this will be ignored
    assert a.a == 1
    assert a.b == 2
    a = A(1, 2, 3, 4)
    # this will be ignored
    assert a.a == 1
    assert a.b == 2

    @dataclasses.dataclass
    class B:
        a: int
        b: int
        c: int

    b = B(1, 2, c=3)
    # this will be ignored
    assert b.a == 1
    assert b.b == 2
    assert b.c == 3
    b = B(1, 2, 3, 4)
    # this will be ignored
    assert b.a == 1


# Generated at 2022-06-21 11:36:19.696389
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class MyClass:
        def __init__(self, x: int, y: int, z: int = 3, *args, **kwargs):
            self.x = x
            self.y = y
            self.z = z
            self.args = args
            self.kwargs = kwargs

    init = _IgnoreUndefinedParameters.create_init(MyClass)
    my_object = init(MyClass(x=1, y=2, z=3, a=1, b=2, c=3))
    assert my_object.x == 1
    assert my_object.y == 2
    assert my_object.z == 3
    assert my_object.args == ()
    assert my_object.kwargs == {}


# Generated at 2022-06-21 11:36:30.483552
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class A:
        include_field: str

        _undefined_parameters: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.field(
                default_factory=lambda: {}),
            metadata=dataclasses_json.config(
                unknown=Undefined.INCLUDE))

        def __post_init__(self):
            self.include_field = self.include_field.upper()

    a = A(include_field="abc", undefined_field="def")
    assert a.include_field == "ABC"
    assert a._undefined_parameters == {"undefined_field": "def"}
    a._undefined_parameters["test"] = "test"

# Generated at 2022-06-21 11:36:36.716954
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    undefined_parameter_dict = {"foo": "bar"}
    defined_parameters_dict = {"foo_defined": "bar_defined"}
    defined_parameters_dict["catch_all"] = undefined_parameter_dict

    result = _CatchAllUndefinedParameters.handle_to_dict(obj=None,
                                                         kvs=defined_parameters_dict)
    assert result == undefined_parameter_dict

# Generated at 2022-06-21 11:36:38.395666
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class X(_UndefinedParameterAction):
        handle_dump = _UndefinedParameterAction.handle_dump

    assert X.handle_dump(None) == {}


# Generated at 2022-06-21 11:36:46.274780
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class Class1:
        catch_all = CatchAll
        def __init__(self, *args, **kwargs):
            pass

    obj1 = Class1()
    dump_result1 = _CatchAllUndefinedParameters.handle_dump(obj1)
    assert isinstance(dump_result1, dict)
    assert len(dump_result1) == 0

    @dataclasses.dataclass
    class Class2:
        catch_all = CatchAll
        x: int = 0

    obj2 = Class2(x=42)
    dump_result2 = _CatchAllUndefinedParameters.handle_dump(obj2)
    assert isinstance(dump_result2, dict)
    assert len(dump_result2) == 0


# Generated at 2022-06-21 11:36:58.685937
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    MyClass = dataclasses.make_dataclass("MyClass", [
        ("known_field", str)
    ])
    known_parameters = {
        'known_field': 'known_value'
    }
    unknown_parameters = {
        'undefined_field': 'undefined_value'
    }
    # Only known parameters
    result = _RaiseUndefinedParameters.handle_from_dict(cls=MyClass,
                                                        kvs=known_parameters)
    assert result == known_parameters

    # Add unknown parameters
    result = _RaiseUndefinedParameters.handle_from_dict(cls=MyClass,
                                                        kvs=dict(
                                                            known_parameters,
                                                            **unknown_parameters))
    assert result == known_parameters


#

# Generated at 2022-06-21 11:37:32.010769
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    """
    Test if create_init works
    """

    def something_expensive():
        return "expensive"

    expected_value = "expected"

    class Test:
        def __init__(self, a, b, c="default", *args, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.args = args
            self.kwargs = kwargs

    test_class = Test
    init = _IgnoreUndefinedParameters.create_init(test_class)

    # Test correct construction
    instance = init(a="a", b="b", c=expected_value)
    assert instance.a == "a"
    assert instance.b == "b"
    assert instance.c == expected_value
    assert len(instance.args) == 0
    assert len

# Generated at 2022-06-21 11:37:42.203183
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    undefined_parameters_action = _UndefinedParameterAction
    class Dummy:
        a: str
        b: int

    @dataclasses.dataclass
    class Dummy2(Dummy):
        a: int
        c: str

    test_input = {"a": "wrong_type", "b": "should_raise", "c": "should_exclude"}
    with pytest.raises(UndefinedParameterError):
        undefined_parameters_action.handle_from_dict(Dummy, test_input)

    result = undefined_parameters_action.handle_from_dict(Dummy2, test_input)
    assert result == {"a": "wrong_type", "b": "should_raise"}



# Generated at 2022-06-21 11:37:48.836872
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    # Make sure that arguments are translated into kwargs correctly
    class TestClass:
        def __init__(self, a: str, b: int, c: str = "c", d: int = 4,
                     e: CatchAll = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    test_instance = \
        _CatchAllUndefinedParameters(_CatchAllUndefinedParameters.
                                     _get_catch_all_field(TestClass)). \
            create_init(TestClass)("a", 2, "c", 4)

    assert test_instance.a == "a"
    assert test_instance.b == 2
    assert test_instance.c == "c"
    assert test_instance.d == 4

# Generated at 2022-06-21 11:37:53.138292
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass
    class UninitializedClass:
        a: int
        b: str

    @dataclasses.dataclass
    class CatchAllClass:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(default=None)

    @dataclasses.dataclass
    class CatchAllClassWithDefault:
        a: int
        b: str
        c: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.field(default_factory=dict))

    # Can't override a catch all field that is not there
    try:
        _CatchAllUndefinedParameters.create_init(UninitializedClass)
        assert False
    except UndefinedParameterError:
        pass

    # Initializing a class with a

# Generated at 2022-06-21 11:37:58.734136
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class A:
        x: int
        u: CatchAll

    a = A(x=1, u={"abc": 3})
    kvs = a.__dict__.copy()
    kvs = _CatchAllUndefinedParameters.handle_to_dict(a, kvs)
    assert kvs == {"x": 1, "abc": 3}

# Generated at 2022-06-21 11:38:01.616289
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    try:
        _UndefinedParameterAction.handle_from_dict()
        raise RuntimeError("Should have raised TypeError before this!")
    except TypeError:
        pass



# Generated at 2022-06-21 11:38:12.937231
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class DummyClass1:
        pass

    class DummyClass2:
        a: int
        b: bool

    class DummyClass3:
        a: int
        b: bool

    class DummyClass4:
        pass

    dummy_class_fields = fields(DummyClass2)

    _UndefinedParameterAction.handle_from_dict(DummyClass1, {})

    assert _UndefinedParameterAction.handle_from_dict(DummyClass2, {}) == {}
    assert _UndefinedParameterAction.handle_from_dict(
        DummyClass2, {'a': 1})['a'] == 1
    assert _UndefinedParameterAction.handle_from_dict(
        DummyClass2, {'a': 1, 'b': True})['a'] == 1
    assert _UndefinedParameterAction.handle_

# Generated at 2022-06-21 11:38:21.261432
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    class MyClass:
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b

    res = _UndefinedParameterAction.handle_from_dict(MyClass,
                                                     {"a": 1, "b": 2, "c": 3})
    assert res == {"a": 1, "b": 2}

    obj = MyClass(1, 2)
    res = _UndefinedParameterAction.handle_to_dict(obj, {"a": 1, "b": 2})
    assert res == {"a": 1, "b": 2}
    assert dataclasses.asdict(obj) == {"a": 1, "b": 2}


# Generated at 2022-06-21 11:38:30.437285
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class _TestClass:
        def __init__(self, a: str, b: str = "", c: str = "",
                     d: Optional[CatchAll] = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    _test_instance = \
        _TestClass.__init__  # get the original init function

    # Try without any undefined parameter
    _ignore_init = _IgnoreUndefinedParameters.create_init(_TestClass)
    # One undefined parameter given
    _ignore_init(None, "a", "b", "c", "a", c="C", d={"A", "CDE"}, e=5, f=7)
    # Check that all the placeholders of args and kwargs
    # have been filled with a value


# Generated at 2022-06-21 11:38:34.367116
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("testmsg")
    except UndefinedParameterError as e:
        assert str(e) == "testmsg"

# Generated at 2022-06-21 11:39:24.981953
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    with pytest.raises(UndefinedParameterError):
        raise UndefinedParameterError("That's an error")


UndefinedParameterAction = _UndefinedParameterAction

# Generated at 2022-06-21 11:39:29.012363
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    parameters = {"a": 1, "b": 2}  # type: Dict[str, Any]
    assert type(_UndefinedParameterAction) is not abc.ABCMeta
    assert _UndefinedParameterAction.handle_to_dict(object, parameters) == \
           parameters

# Generated at 2022-06-21 11:39:36.478702
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from typing import Optional, Any


    @dataclass
    class Test:
        param1: str
        param2: Optional[Any] = None


    # Test 1:  With default factory:
    # No input:
    Test._default_handle_from_dict("x")
    Test._default_handle_from_dict("x", param1="a", _UNKNOWN1=5, _UNKNOWN2="x")

    # Test 2: With default:
    # No input:
    Test._default_handle_from_dict("x")
    # With inputs:
    Test._default_handle_from_dict("x", param1="a", _UNKNOWN1=5, _UNKNOWN2="x")

    # Test 3: Without default:
    # No input:
    Test._default

# Generated at 2022-06-21 11:39:45.883003
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    def create_obj():
        class CatchAllClass:
            def __init__(self, extra_params: CatchAll = None, foo='bar'):
                self.extra_params = extra_params
                self.foo = foo

        return CatchAllClass()

    obj = create_obj()
    data = _UndefinedParameterAction.handle_dump(obj)
    assert len(data) == 0

    obj = create_obj()
    obj.extra_params = {'hello': 'world'}
    data = _UndefinedParameterAction.handle_dump(obj)
    assert len(data) == 1
    assert data['hello'] == 'world'



# Generated at 2022-06-21 11:39:48.819693
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    def test(d):
        return d

    class A:
        def __init__(self, a, b, c=5, *args, **kwargs):
            test(locals())

    _IgnoreUndefinedParameters.create_init(A)(A, 1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-21 11:39:50.471253
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    expected = {}
    actual = _UndefinedParameterAction.handle_to_dict({})
    assert actual == expected



# Generated at 2022-06-21 11:39:52.134051
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(object()) == {}


# Generated at 2022-06-21 11:39:54.334694
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    class Dummy(_UndefinedParameterAction):
        pass
    assert Dummy.handle_dump(Dummy) == {}

# Generated at 2022-06-21 11:40:06.074906
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    # type: () -> None
    import dataclasses_json

    @dataclasses_json.dataclass_json(undefined=Undefined.INCLUDE)
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar]

    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"catch_all": CatchAllVar()}) == {"catch_all": {}}

    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"catch_all": {}, "a": 1}) == {"catch_all": {},
                                                  "a": 1}

    assert _CatchAllUndefinedParameters.handle_from_dict(
        TestClass, {"a": 1}) == {"catch_all": {"a": 1}}

# Generated at 2022-06-21 11:40:07.993770
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    try:
        raise UndefinedParameterError("test")
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:42:15.547913
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class DummyClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    assert _IgnoreUndefinedParameters.handle_from_dict(
        DummyClass, {"a": 1, "b": 2})  == {"a": 1, "b": 2}
    assert _IgnoreUndefinedParameters.handle_from_dict(
        DummyClass, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2}

# Generated at 2022-06-21 11:42:26.723578
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    @dataclass_json
    @dataclass
    class Dummy:
        name: str
        age: int
        catch_all: Optional[CatchAll] = None

    d = Dummy(name="Hans", age=46, catch_all={"a": 1, "b": 2})
    assert d.catch_all == {"a": 1, "b": 2}
    assert type(d.catch_all) == dict
    kvs = _UndefinedParameterAction.handle_to_dict(d, vars(d))
    assert "name" in kvs
    assert "age" in kvs
    assert "catch_all" not in kvs
    assert "a" in kvs
    assert "b" in kvs



# Generated at 2022-06-21 11:42:33.472382
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    class TestClass:

        def __init__(self, field_one: str, field_two: int, field_three: str):
            pass


    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(cls=TestClass,
                                                   kvs={"field_one": "1",
                                                        "field_two": 2,
                                                        "field_four": 3})


# Generated at 2022-06-21 11:42:41.734045
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass
    from dataclasses_json import Undefined, config
    import json

    @dataclass
    @config(undefined=Undefined.INCLUDE)
    class Dataclass:
        name: str
        age: int
        catch_all: Optional[CatchAllVar] = dict()

        def __post_init__(self) -> None:
            self.name = self.name.upper()

    with open("../tests/test_data.json", "r") as f:
        json_str = f.read()

    dataclass_json = Dataclass.schema().loads(json_str)
    expected = json.loads(json_str)

    assert dataclass_json.age == expected["age"]

# Generated at 2022-06-21 11:42:49.075818
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        def __init__(self, foo: str, bar: str = None):
            self.foo = foo
            self.bar = bar

    # This test initialises the class with all parameters
    kvs = {"foo": "a", "bar": "b"}
    known_parameters = _IgnoreUndefinedParameters.handle_from_dict(Test, kvs)
    assert known_parameters == {"foo": "a", "bar": "b"}

    # This test initialises the class with an undefined parameter
    kvs = {"foo": "a", "baz": "b"}
    known_parameters = _IgnoreUndefinedParameters.handle_from_dict(Test, kvs)
    assert known_parameters == {"foo": "a"}

    # This test initialises the class with no parameter

# Generated at 2022-06-21 11:42:55.443294
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    # Test normal usage
    def test_with_args(self, a, b, *args, **kwargs):
        pass

    normal_init_signature = inspect.signature(test_with_args)
    init_signature = inspect.signature(
        _IgnoreUndefinedParameters.create_init(
            test_with_args))
    assert init_signature.parameters == normal_init_signature.parameters
    assert init_signature.return_annotation == normal_init_signature.return_annotation

    # Test when receiving too many parameters
    def test_with_too_many_args(self):
        pass

    too_many_init_signature = inspect.signature(test_with_too_many_args)

# Generated at 2022-06-21 11:43:02.569008
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int
        b: str
        c: str
        d: int = 5

        def __init__(self, a, b, c, d=5):
            print(f"a: {a}, b: {b}, c: {c}, d: {d}")

    init = \
        _IgnoreUndefinedParameters.create_init(TestClass, )
    init(TestClass, 1, "dummy", "dummy", d=9)

# Generated at 2022-06-21 11:43:09.675014
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class TestFromDict:
        a: int
        b: int = 3

    # noinspection PyTypeChecker
    class_ = _UndefinedParameterAction.handle_from_dict(
        TestFromDict,
        {"a": 1, "b": 2})
    assert class_ == {"a": 1, "b": 2}

    # noinspection PyTypeChecker
    class_ = _UndefinedParameterAction.handle_from_dict(
        TestFromDict,
        {"a": 1})
    assert class_ == {"a": 1, "b": 3}

    # noinspection PyTypeChecker
    class_ = _UndefinedParameterAction.handle_from_dict(
        TestFromDict,
        {"a": 1, "c": 2})

# Generated at 2022-06-21 11:43:17.664248
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():

    class A:
        def __init__(self, a: str, b: int, c: int = 42):
            self.a = a
            self.b = b
            self.c = c

    class B:
        def __init__(self, a: str, b: int, c: Optional[CatchAllVar] = None):
            self.a = a
            self.b = b
            self.c = c

    class C:
        def __init__(self, a: str, b: int, c: CatchAllVar = None):
            self.a = a
            self.b = b
            self.c = c

    class D:
        def __init__(self, a: str, b: int, c: CatchAllVar = {}):
            self.a = a
            self.b = b


# Generated at 2022-06-21 11:43:21.538085
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    class TestClass(object):
        def __init__(self, **kwargs):
            pass

    obj = TestClass()
    assert ({'abc': 123} ==
            _UndefinedParameterAction.handle_to_dict(obj, {'abc': 123}))

