

# Generated at 2022-06-21 11:34:24.775955
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    assert \
        _RaiseUndefinedParameters.handle_from_dict(cls=None, kvs={}) == {}


if __name__ == '__main__':
    test__RaiseUndefinedParameters()

# Generated at 2022-06-21 11:34:35.532505
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    class ClassWithNonDefaultParameters:
        def __init__(self, a: int, b: int = 42):
            pass

    given_parameters = {"a": 42, "b": 23, "c": 84}
    given_parameters_2 = {"a": 42, "c": 84}
    given_parameters_3 = {"b": 23, "c": 84}

    expected_parameters = {"a": 42, "b": 23}
    expected_parameters_2 = {"a": 42}
    expected_parameters_3 = {"b": 23}

    assert _UndefinedParameterAction._separate_defined_undefined_kvs(
        ClassWithNonDefaultParameters, given_parameters) == (
               expected_parameters, {"c": 84})
    assert _UndefinedParameterAction._separate_defined_undefined_

# Generated at 2022-06-21 11:34:47.218893
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    @dataclasses.dataclass(undefined=_CatchAllUndefinedParameters)
    class X:
        value: str
        catch_all: Optional[CatchAllVar]

    class Y:
        def __init__(self, catch_all: Optional[CatchAllVar], value: str,
                     **unknown_kwargs):
            pass

    x_init1 = X.__init__
    x_init2 = x_init1.__func__
    x_init3 = _CatchAllUndefinedParameters.create_init(X)
    x_init4 = x_init3.__func__
    x_init5 = x_init4.__func__

    y_init1 = Y.__init__
    y_init2 = y_init1.__func__

    assert x_init1 is x_

# Generated at 2022-06-21 11:34:57.542430
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    from dataclasses_json.utils import CatchAllVar
    from dataclasses_json.undefined import _CatchAllUndefinedParameters

    @dataclasses.dataclass
    class ExampleClass:
        a: int
        b: str = "default_value"
        c: CatchAll = None

    kvs = {"a": 3, "d": "d_value"}
    data = _CatchAllUndefinedParameters.handle_from_dict(ExampleClass, kvs)
    assert data["a"] == 3 and data["b"] == "default_value" and data["d"] == "d_value"
    assert len(data) == 3

    kvs = {"a": 3, "b": "b_value"}
    data = _CatchAllUndefinedParameters.handle_from_dict(ExampleClass, kvs)

# Generated at 2022-06-21 11:35:02.884475
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    from typing import List


    class Example:
        def __init__(self,
                     field1: str,
                     field2: List[int],
                     field3: Optional[CatchAllVar] = None):
            self.field1 = field1
            self.field2 = field2
            self.field3 = field3


    ex = Example(field1="a", field2=[1, 2, 3], field4="b", field5="c")
    assert ex.field1 == "a"
    assert ex.field2 == [1, 2, 3]
    assert ex.field3 is None



# Generated at 2022-06-21 11:35:12.551751
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass(
        init=False)
    class A:
        foo: str
        bar: int
        baz: Optional[CatchAllVar] = dataclasses.field(
            default=dataclasses.MISSING)

    assert _CatchAllUndefinedParameters._get_catch_all_field(
        cls=A) == dataclasses.fields(A)[-1]


# Generated at 2022-06-21 11:35:19.830075
# Unit test for method handle_to_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_to_dict():
    test_dict = {
        "hello": "world",
        "catch_all": {"key": "value"}
    }

    @dataclasses.dataclass(undefined=Undefined.INCLUDE)
    class TestClass:
        hello: str
        catch_all: CatchAll

    expected = {
        "hello": "world",
        "key": "value"
    }
    assert _UndefinedParameterAction.handle_to_dict(TestClass,
                                                    test_dict) == expected

# Generated at 2022-06-21 11:35:29.460809
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    import typing
    import dataclasses

    @dataclasses.dataclass
    class InnerClass:
        one: str
        two: int
    @dataclasses.dataclass
    class ClassToTest:
        value: str

    kwargs = {"value": "foo", "one": "bar", "two": 2}
    result = _CatchAllUndefinedParameters.handle_from_dict(ClassToTest, kwargs)
    assert result == kwargs
    assert result is not kwargs

    kwargs = {"value": "foo", "one": InnerClass("bar", 2)}
    result = _CatchAllUndefinedParameters.handle_from_dict(ClassToTest, kwargs)
    assert result == kwargs
    assert result is not kwargs


# Generated at 2022-06-21 11:35:35.992688
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:
        def __init__(self, a: str, b: str, *args, **kwargs):
            self.a = a
            self.b = b

    catch_all_init = _IgnoreUndefinedParameters.create_init(TestClass)
    catch_all_init(TestClass, "a value", "b value", "c value", **{"c": "c",
                                                                  "d": "d"})
    catch_all_init(TestClass, "a value", "b value", "c value", **{"b": "b",
                                                                  "d": "d"})

# Generated at 2022-06-21 11:35:39.916742
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class SomeClass:
        def __init__(self, *args, **kwargs):
            pass

    assert (SomeClass.__init__ == _UndefinedParameterAction.create_init(
        SomeClass))



# Generated at 2022-06-21 11:36:05.257542
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class TestClass:
        name: str
        age: int

    kvs = {"name": "Klaus", "age": 12, "number_of_kittens": 42}
    known_kvs, unknown_kvs = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=TestClass, kvs=kvs)
    assert known_kvs == {"name": "Klaus", "age": 12}
    assert unknown_kvs == {"number_of_kittens": 42}

    _RaiseUndefinedParameters.handle_from_dict(cls=TestClass, kvs=known_kvs)

# Generated at 2022-06-21 11:36:12.830852
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    @dataclasses.dataclass()
    class SomeClass:
        dummy: str
        def __init__(self, dummy: str, other: Optional[str]=None):
            self.dummy = dummy
            self.other = other
    # Given
    instance = SomeClass(dummy="value")
    # When
    f = _IgnoreUndefinedParameters.create_init(SomeClass)
    # Then
    assert f(instance, dummy="other_value") is None
    assert instance.dummy == "other_value"
    assert instance.other is None
    # When
    f = _IgnoreUndefinedParameters.create_init(SomeClass)
    # Then
    assert f(instance, dummy="other_value", other="a value") is None
    assert instance.dummy == "other_value"

# Generated at 2022-06-21 11:36:17.478777
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    """
    Unit test for method create_init of class _UndefinedParameterAction
    """
    class SomeClass:
        def __init__(self):
            assert False, "Wrong init called. Does not accept any parameters"

    assert _UndefinedParameterAction.create_init(obj=SomeClass) is \
        SomeClass.__init__


# Generated at 2022-06-21 11:36:29.023828
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class Test:
        a: bool
        b: int
        c: str

    assert _IgnoreUndefinedParameters.handle_from_dict(Test,
                                                       {"a": True}) == {"a": True}
    assert _IgnoreUndefinedParameters.handle_from_dict(Test,
                                                       {"a": True, "c": "c"}) == {"a": True, "c": "c"}
    assert _IgnoreUndefinedParameters.handle_from_dict(Test,
                                                       {"a": True, "unknown": "unknown"}) == {"a": True}
    assert _IgnoreUndefinedParameters.handle_from_dict(Test,
                                                       {"a": True, "unknown": "unknown", **{"c": "c"}}) == {"a": True, "c": "c"}


# Generated at 2022-06-21 11:36:41.136413
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from dataclasses import dataclass, field
    from typing import List

    @dataclass(undefined=Undefined.INCLUDE)
    class TestClass:
        a: str
        b: int
        catch_all: Optional[CatchAllVar] = field(default=dict,
                                                 metadata={
                                                     'dataclasses_json': {
                                                         'mm_field':
                                                             'catchAll'}})

        def __init__(self, a, b, c=None, d=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    test_instance = TestClass("a", 1, 3, d=4)

    assert test_instance.a == "a"
    assert test_instance

# Generated at 2022-06-21 11:36:46.106249
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class A:
        field_a: int
        field_b: int

    known, unknown = _IgnoreUndefinedParameters.handle_from_dict(A, {'a':5})
    assert known == {'field_a': 5}
    assert len(unknown) == 0


# Generated at 2022-06-21 11:36:55.691008
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class SingleCatchAll:
        catch_all: CatchAll

        def __init__(self, catch_all: CatchAll = None) -> None:
            self.catch_all = catch_all or {}

    result = _CatchAllUndefinedParameters.handle_to_dict(
        obj=SingleCatchAll,
        kvs={"a": "b", "c": "d", "catch_all": {"e": "f", "g": "h"}})
    assert result == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-21 11:37:03.558162
# Unit test for method handle_from_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_from_dict():
    import dataclasses
    import random
    import string

    class TestClass:
        def __init__(self, a, b, c=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.kwargs = kwargs

        @classmethod
        def _separate_defined_undefined_kvs(cls, kvs: Dict[Any, Any]) -> \
                Tuple[Dict[Any, Any], Dict[Any, Any]]:
            """
            Returns a 2 dictionaries: defined and undefined parameters
            """
            class_fields = dataclasses.fields(cls)
            field_names = [field.name for field in class_fields]

# Generated at 2022-06-21 11:37:06.284249
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    """
    Test constructor
    """
    try:
        raise UndefinedParameterError("Test message")
    except ValidationError as e:
        assert e.message == "Test message"

# Generated at 2022-06-21 11:37:11.630655
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    @dataclasses.dataclass
    class D:
        d: int
        catch_all: CatchAll = None

    obj = D(d=1, catch_all={'e': 5})
    d = _CatchAllUndefinedParameters.handle_to_dict(obj, {
        'd': 1,
        'catch_all': {'e': 5}
    })
    assert d == {'d': 1, 'e': 5}



# Generated at 2022-06-21 11:37:32.666685
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        test: str
        test_catch_all: CatchAll = dataclasses.field(default=None)
    test_obj = TestClass("test")
    test_dict = _CatchAllUndefinedParameters.handle_dump(test_obj)
    assert dict == type(test_dict)

# Generated at 2022-06-21 11:37:40.648902
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    import dataclasses


    @dataclasses.dataclass
    class TestClass:
        a: int
        b: int

        def __init__(self, a: int, b: int = 2):
            self.a = a
            self.b = b


    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    tc = TestClass(None, None)
    init_method(tc, a=1, b=2, c=3)
    assert tc.a == 1
    assert tc.b == 2



# Generated at 2022-06-21 11:37:48.241880
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from typing import Type

    class TestClass(abc.ABC):
        def __init__(self, *, a: int, b: float, c: str, d: Type[int]):
            pass

    init_method = _IgnoreUndefinedParameters.create_init(TestClass)
    init_signature = inspect.signature(init_method)
    assert len(init_signature.parameters) == 3
    assert "self" in init_signature.parameters
    assert "a" in init_signature.parameters
    assert "b" in init_signature.parameters

    # Test that unknown parameters are ignored
    init_method(TestClass, 0, 0.0, "", dict, e=5)
    # Test that known parameter are parsed correctly

# Generated at 2022-06-21 11:37:59.386233
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    assert _CatchAllUndefinedParameters.handle_from_dict(
        dict, dict(a=1)) == dict(a=1)
    assert _CatchAllUndefinedParameters.handle_from_dict(
        dict, dict()) == dict()
    assert _CatchAllUndefinedParameters._get_catch_all_field(dict) == \
           dict.__annotations__["__dataclasses_json__"]

    assert _CatchAllUndefinedParameters.handle_dump(
        dict(__dataclasses_json__=1)) == 1

    assert \
        _CatchAllUndefinedParameters.handle_to_dict(
            dict(), dict(__dataclasses_json__=1)) == dict()
    assert \
        _CatchAllUndefinedParameters.handle_to_dict(
            dict(), dict()) == dict()


# Generated at 2022-06-21 11:38:01.004862
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump(None) == {}

# Generated at 2022-06-21 11:38:12.429149
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass, fields
    from enum import Enum
    from copy import deepcopy

    from dataclasses_json.undefined import _RaiseUndefinedParameters

    # Define a class for which we can test undefined handling
    @dataclass
    class Test:
        required: str
        optional_with_default: str = "default"
        optional_with_default_factory: str = fields(
            default_factory=lambda: "called factory")

        def __init__(self, **kwargs):
            super().__init__()

        # noinspection PyMethodOverriding
        def __post_init__(self):
            pass

    # Define a copy of the class but with a different name
    class TestCopy(Test):
        pass

    # Create a dictionary of known and unknown keys
   

# Generated at 2022-06-21 11:38:20.737208
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    # noinspection PyProtectedMember
    handle_from_dict = _RaiseUndefinedParameters.handle_from_dict  # type: ignore

    class TestDataClass:
        a: int

    output = handle_from_dict(cls=TestDataClass, kvs={"a": 1, "b": 2})
    assert output == {"a": 1}

    with pytest.raises(UndefinedParameterError):
        handle_from_dict(cls=TestDataClass, kvs={"a": 1, "b": 2, "c": 3})

    with pytest.raises(UndefinedParameterError):
        handle_from_dict(cls=TestDataClass, kvs={"b": 1, "c": 2})



# Generated at 2022-06-21 11:38:25.484692
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class Test:
        field: str = "default"

    kvs = {
        "field": "not default",
        "field2": "undefined"
    }
    with pytest.raises(UndefinedParameterError):
        _RaiseUndefinedParameters.handle_from_dict(Test, kvs)



# Generated at 2022-06-21 11:38:31.141075
# Unit test for method handle_dump of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_dump():
    @dataclasses.dataclass
    class TestClass:
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default=None, metadata={"undefined": Undefined.INCLUDE})
    obj = TestClass()
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {}

    obj.catch_all = {'a': 'b'}
    assert _CatchAllUndefinedParameters.handle_dump(obj) == {'a': 'b'}

# Generated at 2022-06-21 11:38:40.475385
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    class Foo:

        def __init__(self, x: int, y: int, z: int, _UNKNOWN_PARAMETERS: CatchAll):
            self.x = x
            self.y = y
            self.z = z
            self._UNKNOWN_PARAMETERS = _UNKNOWN_PARAMETERS

    new_init = _CatchAllUndefinedParameters.create_init(Foo)
    foo = Foo(1, y=2, z=3)
    assert foo.x == 1
    assert foo.y == 2
    assert foo.z == 3
    assert foo._UNKNOWN_PARAMETERS == dict()

    foo = new_init(1, 2, 3, 4)
    assert foo.x == 1
    assert foo.y == 2
    assert foo.z == 3
    assert foo._

# Generated at 2022-06-21 11:39:18.070042
# Unit test for method handle_from_dict of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_handle_from_dict():
    class SolveMe:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    input_keys = ["a", "b", "c"]
    input_values = [5, 6, 7]
    input_dict = dict(zip(input_keys, input_values))

    result_dict = _IgnoreUndefinedParameters.handle_from_dict(SolveMe,
                                                              input_dict)
    assert result_dict["a"] == input_dict["a"]
    assert result_dict["b"] == input_dict["b"]
    assert len(result_dict) == 2



# Generated at 2022-06-21 11:39:29.055802
# Unit test for method handle_to_dict of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_handle_to_dict():
    class Subclass(object):
        def __init__(self, foo: int, bar: str, baz: int = 5, **kwargs):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    obj = Subclass(foo=1, bar='test')
    assert _CatchAllUndefinedParameters.handle_to_dict(obj=obj,
                                                       kvs={'foo': 1,
                                                            'bar': 'test',
                                                            'baz': 5,
                                                            'catch_all': {}}) == {
        'foo': 1,
        'bar': 'test',
        'baz': 5,
    }


# Generated at 2022-06-21 11:39:35.079399
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class TestClass:

        def __init__(self, a: int, b: str, **kwargs):
            pass

    expected_init_params = ["self", "a", "b"]
    assert TestClass.__init__.__code__.co_varnames == expected_init_params
    init = _IgnoreUndefinedParameters.create_init(TestClass)
    assert init.__code__.co_varnames == expected_init_params

# Generated at 2022-06-21 11:39:40.209643
# Unit test for constructor of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters():
    @dataclasses.dataclass
    class Test:
        a: int
        b: int

    test = Test(1, 2)
    if test.a != 1:
        raise Exception()
    if test.b != 2:
        raise Exception()

    with pytest.raises(UndefinedParameterError):
        _ = Test(1, 2, 3)



# Generated at 2022-06-21 11:39:48.746113
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    @dataclasses.dataclass
    class A:
        a: int = dataclasses.field(repr=False)
        b: str = dataclasses.field(default=None)
        c: Optional[CatchAll] = dataclasses.field(default=None)

    assert len(fields(A)) == 3

    # test normal behavior
    with pytest.raises(UndefinedParameterError) as excinfo:
        A(a=1, z=1)
    assert "Undefined initialization arguments" in str(excinfo.value)

    with pytest.raises(UndefinedParameterError) as excinfo:
        A(a=1, c=[])
    assert "same name as catch-all field" in str(excinfo.value)


# Generated at 2022-06-21 11:39:51.604393
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError():
    # This test is necessary to be able to catch UndefinedParameterError
    # when it is raised
    try:
        raise UndefinedParameterError()
    except UndefinedParameterError:
        pass

# Generated at 2022-06-21 11:40:01.279334
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int = 1
        b: int = 2

    Test._UNDEFINED_PARAMETERS = _RaiseUndefinedParameters

    test = Test(a=1, b=2)
    assert test.a == 1
    assert test.b == 2
    assert test._UNDEFINED_PARAMETERS == _RaiseUndefinedParameters

    try:
        test = Test(a=1, b=2, c=3)
        assert False
    except UndefinedParameterError as e:
        assert "c" in str(e)



# Generated at 2022-06-21 11:40:02.922316
# Unit test for constructor of class _UndefinedParameterAction
def test__UndefinedParameterAction():
    obj = _UndefinedParameterAction()
    assert obj is not None

# Generated at 2022-06-21 11:40:06.927024
# Unit test for constructor of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters():
    def foo(a, b):
        pass

    sig = inspect.signature(foo)
    params = sig.parameters
    assert isinstance(params, OrderedDict)

    _CatchAllUndefinedParameters.create_init(foo)

# Generated at 2022-06-21 11:40:10.930681
# Unit test for method create_init of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters_create_init():
    from dataclasses import dataclass

    @dataclass
    class Test(object):
        """
        Test object for the create_init function.
        """

        name: str
        age: int
        tag: str = ""
        tags: Dict[str, int] = dataclasses.field(default_factory=dict)
        catch_all: Optional[CatchAllVar] = dataclasses.field(
            default_factory=dict)

        def __init__(self, name, age, tag="", tags=None,
                     catch_all=None):
            """
            Initialize the Test object
            """
            self.name = name
            self.age = age
            self.tag = tag
            self.tags = tags
            self.catch_all = catch_all

    init = _IgnoreUndefined

# Generated at 2022-06-21 11:41:32.601544
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    @dataclasses.dataclass(undefined=Undefined.EXCLUDE)
    class TestDataClass:
        x: int
        y: int
        z: int
    TestDataClass(1, y=2, z=3, more_params=4)

# Generated at 2022-06-21 11:41:41.905184
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class Foo:
        def __init__(self, x, y, z=3, *args, **kwargs):
            pass

        def __call__(self):
            pass

    original_init = Foo.__init__
    kwargs = {"y": 2, "x": 1, "z": 4, "foo": "bar"}

    init_signature = inspect.signature(original_init)

    @functools.wraps(original_init)
    def _test_init(self, *args, **kwargs):
        known_kwargs, unknown_kwargs = \
            _UndefinedParameterAction._separate_defined_undefined_kvs(Foo,
                                                                       kwargs)
        num_params_takeable = len(
            init_signature.parameters) - 1  # don't

# Generated at 2022-06-21 11:41:51.371867
# Unit test for method create_init of class _CatchAllUndefinedParameters
def test__CatchAllUndefinedParameters_create_init():
    from typing import Undefined as UndefinedParam
    class TestClass():
        def __init__(self, a: int, b: int, c: int, d: int = 1,
                     e: int = 2, f: int = 3,
                     undefined: Optional[UndefinedParam] = None):
            pass

    new_init = _CatchAllUndefinedParameters.create_init(TestClass)
    new_test_class = type(TestClass.__name__, (), {"__init__": new_init})
    test_class = new_test_class(a=1, b=2, c=3, g=4, h=5)
    assert test_class.undefined == {'g': 4, 'h': 5}

# Generated at 2022-06-21 11:41:54.756284
# Unit test for method create_init of class _UndefinedParameterAction
def test__UndefinedParameterAction_create_init():
    class TestClass:
        def __init__(self, a: int, b: int = 2):
            pass

    new_init = _UndefinedParameterAction.create_init(TestClass)
    assert hasattr(new_init, "__wrapped__")



# Generated at 2022-06-21 11:41:55.825495
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    assert _UndefinedParameterAction.handle_dump("test") == {}

# Generated at 2022-06-21 11:42:01.245629
# Unit test for method handle_from_dict of class _RaiseUndefinedParameters
def test__RaiseUndefinedParameters_handle_from_dict():
    @dataclasses.dataclass
    class MockClass:
        a: int
        b: int = 1

    assert _RaiseUndefinedParameters.handle_from_dict(MockClass,
                                                      {"a": 2, "b": 3}) == {
               "a": 2, "b": 3}

    try:
        _RaiseUndefinedParameters.handle_from_dict(MockClass,
                                                   {"a": 2, "b": 3, "c": 5,
                                                    "d": 6})
        # Expect an exception to be raised
        assert False
    except UndefinedParameterError:
        pass



# Generated at 2022-06-21 11:42:08.375878
# Unit test for method handle_dump of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_dump():
    obj = _UndefinedParameterAction()
    assert obj.handle_dump(None) == dict()
    obj = _CatchAllUndefinedParameters()
    assert obj.handle_dump(object()) == dict()
    assert obj.handle_dump(None) == dict()
    obj = _RaiseUndefinedParameters()
    assert obj.handle_dump(None) == dict()
    obj = _IgnoreUndefinedParameters()
    assert obj.handle_dump(None) == dict()

# Generated at 2022-06-21 11:42:12.234170
# Unit test for constructor of class _IgnoreUndefinedParameters
def test__IgnoreUndefinedParameters():
    class Test:
        def __init__(self, a, b=2, **kwargs):
            pass

    Test = _IgnoreUndefinedParameters.create_init(Test)

    Test(1)
    Test(1, 2)
    Test(1, 2, c=3)

    with pytest.raises(Exception) as e:
        Test(1, 2, 3)
    assert "got an unexpected keyword argument '3'" in str(e.value)



# Generated at 2022-06-21 11:42:13.102146
# Unit test for constructor of class UndefinedParameterError
def test_UndefinedParameterError(): 
    UndefinedParameterError("")

# Generated at 2022-06-21 11:42:21.090429
# Unit test for method handle_from_dict of class _UndefinedParameterAction
def test__UndefinedParameterAction_handle_from_dict():
    @dataclasses.dataclass
    class A:
        defined1: int
        defined2: int = 0

    known, unknown = \
        _UndefinedParameterAction._separate_defined_undefined_kvs(
            cls=A,
            kvs={"defined1": 1, "defined2": 2, "undefined": 0})
    assert known == {"defined1": 1, "defined2": 2}
    assert unknown == {"undefined": 0}