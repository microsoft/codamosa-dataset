

# Generated at 2022-06-11 16:41:34.115600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # setup mock objects
    class tqm(object):
        pass
    mock_tqm = tqm()
    try:
        mock_tqm.run_handlers = False
    except TypeError:
        # skip trying to use the mock variable
        pass

    # run the constructor
    obj = StrategyModule(mock_tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:41:34.683580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 2

# Generated at 2022-06-11 16:41:37.456975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = ""
        StrategyModule(tqm)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-11 16:41:48.462276
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:41:50.989311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module = StrategyModule(tqm=tqm)
    except Exception:
        assert False


# Generated at 2022-06-11 16:41:52.640812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-11 16:41:53.334672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:54.422160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-11 16:41:56.676589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#    tqm = TaskQueueManager()
#    sm = StrategyModule(tqm)


# Generated at 2022-06-11 16:42:01.835535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(StrategyModule):
        def run(self, iterator, play_context):
            return super(Test, self).run(iterator, play_context)

    tqm = Test(tqm="Stub")
    assert tqm.debugger_active == True


# Generated at 2022-06-11 16:42:12.289206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockConfigManager:
        def __init__(self):
            self.config_file = ''
            self.data = dict(
                roles_path = '',
            )
    config_manager = MockConfigManager()
    class MockTaskQueueManager:
        def __init__(self):
            self.stats = dict(
                ok = 0,
                failures = 0,
                processed = 0,
                skipped = 0,
                unreachable = 0,
            )
            self.hostvars = dict()
            self.config = config_manager
            self.inventory = None
    tqm = MockTaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:42:13.190786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:14.175128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule != None)



# Generated at 2022-06-11 16:42:19.010588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTaskQueueManager:
        def __init__(self):
            self.stats = dict(processed=dict())

    # This is enough to instantiate StrategyModule and run tests in constructor
    tqm = MockTaskQueueManager()
    s = StrategyModule(tqm)



# Generated at 2022-06-11 16:42:23.402063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ##########
    # create test data
    tqm = None
    strategy_module = StrategyModule(tqm)

    ##########
    # check
    assert strategy_module.tqm == None
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:42:24.503687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:42:26.766711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        tqm = 0
        strategyModule = StrategyModule(tqm)
        assert strategyModule


# Generated at 2022-06-11 16:42:27.556588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-11 16:42:31.233530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    assert isinstance(StrategyModule(tqm), LinearStrategyModule) == True


# Generated at 2022-06-11 16:42:33.631399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm, StrategyModule)


# Generated at 2022-06-11 16:42:37.742688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:42:39.510111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__


# Execute the Playbook.

# Generated at 2022-06-11 16:42:41.385013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-11 16:42:42.256587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.debugger_active


# Generated at 2022-06-11 16:42:43.794384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:42:45.566755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:42:47.835711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:57.002846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = get_linear_tqm()
        strategy_debug = StrategyModule(tqm)
    except:
        raise AssertionError("StrategyModule class constructor fail")

import ansible.constants as C
from ansible.utils.unicode import to_unicode
from ansible.errors import AnsibleError, AnsibleParserError
from ansible.inventory.host import Host
from ansible.inventory.group import Group
from ansible.inventory.included import InventoryIncluded
from ansible.inventory.manager import InventoryManager
from ansible.playbook.play import Play
from ansible.playbook.task import Task
from ansible.playbook.included import IncludedFile
from ansible.playbook.role import Role
from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-11 16:43:08.925644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule()
    assert test_StrategyModule.debugger_active==True

# def execute_task(self, task, play_context, variable_manager, loader, templar, task_vars):
#     """ Executes the module specified by the given task.
#     """

    # FIXME: is this a hack?
#     if 'action' in task and task['action'].get('__use_unsafe_shell__', False):
#         play_context.become = False
#         play_context.become_user = None

#     module_vars = self._configure_module_vars(task_vars=task_vars, task=task)
#     module = module_vars.get('module', task.action)
#     module_name = module_vars

# Generated at 2022-06-11 16:43:11.810492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)

# Check the content of results

# Generated at 2022-06-11 16:43:16.511678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule


# Generated at 2022-06-11 16:43:17.314043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)


# Generated at 2022-06-11 16:43:27.440592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestHost():
        def __init__(self, name):
            self.name = name
            self.port = 22
            self.result = {}
            self.task_vars = {}
    class TestTask():
        def __init__(self, host):
            self.host = host
            self.name = 'test_task'
    class TestTQM():
        def __init__(self, hosts):
            self.hosts = hosts
            self.tasks = [ TestTask(hosts[0]) ]
            self.args = {}
            self.callback = None
            self.callback_plugins = {}
    inventory = dict([(hostname, TestHost(hostname)) for hostname in ['localhost']])
    tqm = TestTQM(inventory.values())

# Generated at 2022-06-11 16:43:28.053971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:43:29.479009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(type(StrategyModule))
    assert StrategyModule



# Generated at 2022-06-11 16:43:31.252924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-11 16:43:35.012516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategyModule = StrategyModule(tqm)

    assert strategyModule.tqm == tqm
    assert strategyModule.debugger_active == True

# main method of class StrategyModule

# Generated at 2022-06-11 16:43:38.296512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TqmMock:
        def __init__(self):
            self.hostvars = None
    tqm_obj = TqmMock()
    strategy_obj = StrategyModule(tqm_obj)



# Generated at 2022-06-11 16:43:39.627217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule()")


# Generated at 2022-06-11 16:43:44.937469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def __init__(self, tqm=None):
            self.tqm = tqm
    taskqueue_manager = TaskQueueManager(tqm=None)
    strategy_module = StrategyModule(taskqueue_manager)
    assert strategy_module.debugger_active
# End of unit test for constructor of class StrategyModule


# Generated at 2022-06-11 16:43:56.279692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:43:56.924719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True



# Generated at 2022-06-11 16:43:59.652685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm)
    except Exception: err = 1
    assert err == 0, 'test_StrategyModule() - constructor'


# Generated at 2022-06-11 16:44:08.245021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestHost:
        def __init__(self, host_name):
            self.name = host_name
            self.vars = {}

    class TestInventory:
        def __init__(self):
            self.hosts = {"test": TestHost("test")}

    class TestTQM:
        def __init__(self):
            self.inventory = TestInventory()

    test_tqm = TestTQM()
    strategy_module = StrategyModule(test_tqm)
    assert not strategy_module.debugger_active



# Generated at 2022-06-11 16:44:13.598508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a Fake TQM
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )

    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, LinearStrategyModule)


# Generated at 2022-06-11 16:44:17.043875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM(object):
        pass

    strategy_class = StrategyModule(MockTQM())
    assert strategy_class.debugger_active == True 


# Generated at 2022-06-11 16:44:21.365591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    tqm = object()
    sm = ansible.plugins.strategy.debug.StrategyModule(tqm)
    assert sm._tqm == tqm, "constructor does not seem to be correct"



# Generated at 2022-06-11 16:44:32.321693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.task_include as task_include
    import ansible.template as template
    import ansible.vars.manager as vars_manager
    import ansible.vars.hostvars as hostvars
    import ansible.vars.variable_manager as variable_manager

    class TestTaskQueueManager:
        def __init__(self):
            self.inventory = None
            self.stdout_callback = None
            self.options = None

        def get_host_vars(self, host, new_pb_ds):
            return hostvars.HostVars(
                    host,
                    variable_manager.VariableManager(loader=None, inventory=self.inventory),
                    new_pb_ds)

    # All class members in StrategyModule must be initialized

# Generated at 2022-06-11 16:44:35.152189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm = None)
    # Exception handling
    except AttributeError:
        print("AttributeError exception caught")


# Generated at 2022-06-11 16:44:38.891408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(None)
    assert t.name == "default", "constructor of class StrategyModule failed"
    assert t.debugger_active, "constructor of class StrategyModule failed"


# Generated at 2022-06-11 16:45:06.224644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def __init__(self):
            self.shared_loader_obj = 'shared_loader_obj'
            self.host_list = 'host_list'
            self.extra_vars = 'extra_vars'
            self.options = 'options'
            self.variable_manager = 'variable_manager'
            self.loader = 'loader'
            self.inventory = 'inventory'
            self.passwords = 'passwords'

    tqm = TestTqm()
    sm = StrategyModule(tqm)
    assert sm.tqm.shared_loader_obj == tqm.shared_loader_obj
    assert sm.tqm.host_list == tqm.host_list
    assert sm.tqm.extra_vars == tqm.extra

# Generated at 2022-06-11 16:45:07.043388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")



# Generated at 2022-06-11 16:45:08.164673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule('test')


# Generated at 2022-06-11 16:45:11.065608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule is interface of StrategyModule
    from ansible.plugins.strategy import StrategyModule
    assert issubclass(StrategyModule, StrategyModule)



# Generated at 2022-06-11 16:45:11.899048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return


# Generated at 2022-06-11 16:45:13.215146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:45:15.428153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("task_queuemanager")

###  Interactive Debug Session Class

# Generated at 2022-06-11 16:45:16.042752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:45:17.920707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active



# Generated at 2022-06-11 16:45:19.364196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '1'
    StrategyModule(tqm)


# Generated at 2022-06-11 16:45:52.311150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule is not None


# Generated at 2022-06-11 16:45:56.943219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible_test.debug
        ansible_test.debug.test_StrategyModule()
    except Exception as e:
        print('Exception: {}'.format(repr(e)))
        raise e


# Generated at 2022-06-11 16:45:58.917120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(None)
    assert result.debugger_active == True


# Generated at 2022-06-11 16:46:04.294550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test():
        def __init__(self):
            self.host_queue = ['test']

    s = StrategyModule(Test())

# global variables and statements
# This global variables are used in class Cmd and test case of it.
g_task = 0
g_hosts = ['test']
g_subtask = 0
g_subtask_warnings = []
g_subtask_deps = []
g_subtask_skip_reason = []


# Generated at 2022-06-11 16:46:08.133899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    class TQM():
        pass
    tqm = TQM()
    tqm.__init__ = lambda self: 0
    StrategyModule(tqm)
    return 1


# Generated at 2022-06-11 16:46:10.802178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    srv = StrategyModule(1)
    assert srv.debugger_active == True


# Generated at 2022-06-11 16:46:21.303364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugins
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager 
    loader = DataLoader()
    inventory = InventoryManager(loader, [])
    variable_manager = VariableManager(loader, inventory)
    playbook_context = PlayContext()

# Generated at 2022-06-11 16:46:25.432405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = "mock tqm"
    strategy = StrategyModule(tqm)
    assert strategy.tqm == "mock tqm"
    assert strategy.debugger_active



# Generated at 2022-06-11 16:46:27.964681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(issubclass(StrategyModule, LinearStrategyModule))

# TODO(retr0h): This class is too coupled to Ansible and the Ansible library
#               This makes it difficult to test.

# Generated at 2022-06-11 16:46:29.576942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=object)


# Generated at 2022-06-11 16:47:45.494736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == "Executes tasks in interactive debug session."



# Generated at 2022-06-11 16:47:50.382760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import cmd
    import pprint
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    # Create StrategyModule for test
    tqm = sys
    sm = StrategyModule(tqm)
    assert isinstance(sm,StrategyModule)
    assert isinstance(sm,LinearStrategyModule)
    assert sm.debugger_active


# Generated at 2022-06-11 16:47:54.264701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  
    tqm = "foo"
    strategy = StrategyModule(tqm)
    assert strategy.tqm == "foo"
    assert strategy.play_has_tasks() == False
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:47:56.285788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy = StrategyModule(tqm)
    assert strategy.tqm == "tqm"


# Generated at 2022-06-11 16:47:56.986788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:47:58.560290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    print(str(sm))



# Generated at 2022-06-11 16:48:01.008366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-11 16:48:05.268895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''

    # Create a class of command interpreter of python
    class MyCmd(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)

    # Create a object of command interpreter by using class MyCmd
    debugger = MyCmd()

    # Run debugger.
    debugger.cmdloop()

# Generated at 2022-06-11 16:48:07.129075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == False


# Generated at 2022-06-11 16:48:09.336323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM: pass
    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active
    assert sm.tqm == tqm


# Generated at 2022-06-11 16:50:54.124643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    debug_obj = StrategyModule(tqm)
    assert(debug_obj.debugger_active)
    

# Generated at 2022-06-11 16:50:55.083663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)



# Generated at 2022-06-11 16:50:56.634657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active is True



# Generated at 2022-06-11 16:50:58.963579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert(sm.tqm == tqm)
    assert(sm.debugger_active == True)



# Generated at 2022-06-11 16:51:08.537007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    display = Display()
    display.verbosity = 4
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=False,
        display=display
    )
    try:
        StrategyModule(tqm)
    except Exception as e:
        return False
    return True


# Generated at 2022-06-11 16:51:09.075026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:51:16.433357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM(object):
        pass
    dummyTQM = DummyTQM()
    strategyModule = StrategyModule(dummyTQM)
    assert isinstance(strategyModule, StrategyModule)
    assert isinstance(strategyModule._tqm, DummyTQM)
    assert isinstance(strategyModule._workers, list)
    assert strategyModule._workers == []
    assert isinstance(strategyModule._display, cmd.Cmd)
    assert strategyModule._display._prompt == '\nansible (debug)> '
    assert strategyModule._max_fail_pct == 0.0
    assert strategyModule._callbacks == []
    assert strategyModule._final_q is None
    assert strategyModule._failed_hosts == {}
    assert strategyModule._unreachable_hosts == {}

# Generated at 2022-06-11 16:51:22.342797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=True)
    assert s.debugger_active == True
    assert s.tqm == True
    assert s.host_state == {}
    assert s.playbook is None
    assert s.task_queue == []
    assert s.default_vars == {}
    assert s.strategy_name == 'linear'

if __name__ == '__main__':
    test_StrategyModule()

