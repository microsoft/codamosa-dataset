

# Generated at 2022-06-11 16:41:23.453589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:25.701853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_mods = StrategyModule(tqm)
    assert(strategy_mods.debugger_active == True)



# Generated at 2022-06-11 16:41:31.781156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class DebugStrategyModuleTest(unittest.TestCase):
        def test_constructor(self):
            m = StrategyModule(None)
            self.assertTrue(m.debugger_active)

    suite = unittest.TestLoader().loadTestsFromTestCase(DebugStrategyModuleTest)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-11 16:41:34.112227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert strategy_module is not None
    assert strategy_module.debugger_active is True



# Generated at 2022-06-11 16:41:35.774471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:41:37.786631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule = sys.modules['ansible.plugins.strategy.debug']
    assert StrategyModule



# Generated at 2022-06-11 16:41:40.328631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:41:42.854129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock_tqm = None
    # sm = StrategyModule(mock_tqm)
    # assert sm is not None
    assert True

test_StrategyModule()

# Generated at 2022-06-11 16:41:48.317766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unit_test_runner
    import mock
    import os

    test_result = unit_test_runner.run_test(StrategyModule, [mock.ANY, 'test'], {},
        test_module=os.path.abspath(__file__), lint=False)
    assert test_result.success, test_result.exception



# Generated at 2022-06-11 16:42:00.809518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	import ansible.parsing.dataloader
	from ansible.vars.manager import VariableManager
	from ansible.inventory.manager import InventoryManager
	from ansible import context
	from ansible.executor.task_queue_manager import TaskQueueManager

	context.CLIARGS = {}
	loader = ansible.parsing.dataloader.DataLoader()
	variable_manager = VariableManager(loader=loader)
	inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
	variable_manager.set_inventory(inventory)

	tqm = TaskQueueManager(
		inventory=inventory,
		variable_manager=variable_manager,
		loader=loader,
		passwords=dict(),
		stdout_callback='default',
	)

# Generated at 2022-06-11 16:42:03.664322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test
    pass
##
#
#


# Generated at 2022-06-11 16:42:05.487999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

#    def get_host_list(self):
#        return []

# Generated at 2022-06-11 16:42:07.471931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
#
# ----------------------------------------------------------------------------------------------------------------------

# !!!!!!FIXME!!!!!!

# Generated at 2022-06-11 16:42:09.542181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None).debugger_active == True


# Generated at 2022-06-11 16:42:20.436841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "test.example.com"
    loader = DictDataLoader({host: DictDataLoader.empty_data_source})

    inventory = Inventory(loader)
    inventory.hosts = [host]
    host = inventory.get_host(host)

    variable_manager = VariableManager(loader, inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tq

# Generated at 2022-06-11 16:42:21.904747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Sample Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:42:23.997575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert LinearStrategyModule
    assert hasattr(StrategyModule, '__init__')


# Generated at 2022-06-11 16:42:27.045681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = []

    strategy = StrategyModule(tqm)

    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:28.000422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('')
    assert sm.debugger_active



# Generated at 2022-06-11 16:42:28.460561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:42:31.385262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:32.692391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None



# Generated at 2022-06-11 16:42:33.529526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:34.113605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:34.660815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:36.441058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule().debugger_active 
    print("test_StrategyModule passed")
    


# Generated at 2022-06-11 16:42:44.655526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import pprint
    
    # create a task queue manager and a task list to debug
    tqm = FakeTaskQueueManager()

    t1 = FakeTask()
    t1.set_name('debug task 1')
    t1.set_loop([{'item1': 'a'}, {'item2': 'b'}])
    t1.set_action(FakeActionModule({'msg': 'debug task 1 result'}))
    tqm.add_task(t1)

    t2 = FakeTask()
    t2.set_name('debug task 2')
    t2.set_loop([{'item3': 'c'}, {'item4': 'd'}])
    t2.set_action(FakeActionModule({'msg': 'debug task 2 result'}))
    tqm

# Generated at 2022-06-11 16:42:46.432427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active is True


# Generated at 2022-06-11 16:42:47.353430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:50.069371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm) # FIXME "tqm" is not defined
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:56.940797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.name == "debug"
    assert strategy_module.need_static_info == False
    assert strategy_module.need_onetask_info == False
    assert strategy_module.check_implicit_deps == False

# Generated at 2022-06-11 16:43:00.851211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var = StrategyModule(tqm=None)
    assert var.debugger_active == True

# This class is derived from cmd insted of AnsibleCLI, to
# avoid deprecation of AnsibleCLI.


# Generated at 2022-06-11 16:43:02.059768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#     StrategyModule()



# Generated at 2022-06-11 16:43:06.032880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        pass
    from ansible.plugins.strategy import StrategyModule
    strategy = StrategyModule(TQM())
    assert isinstance(strategy, StrategyModule) is True



# Generated at 2022-06-11 16:43:07.159245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:43:10.393817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = AnsibleTaskQueueManager()
        assert tqm
    except NameError:
        tqm = object()

    object = StrategyModule(tqm)
    assert object


# Generated at 2022-06-11 16:43:13.238894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule();
    assert type(s) == StrategyModule
    assert s.debugger_active == True


# Generated at 2022-06-11 16:43:14.313538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:43:15.927389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), LinearStrategyModule)


# Generated at 2022-06-11 16:43:17.379447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Unit tests for the __init__ method of class StrategyModule

# Generated at 2022-06-11 16:43:28.154440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy.debugger_active is True
    assert len(strategy._tqm._workers) == 0



# Generated at 2022-06-11 16:43:33.095363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   print(StrategyModule.__doc__)
   sm = StrategyModule('tqm')
   print('Sm - ' + str(sm))
   print('Sm active - ' + str(sm.debugger_active))
   print('Sm active - ' + str(sm.tqm))


# Generated at 2022-06-11 16:43:36.031638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test of constructor
    tqm = None
    obj = StrategyModule(tqm)
    assert obj.tqm == None
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:43:37.467463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule
    test_inst = StrategyModule(tqm="Test_value")


# Generated at 2022-06-11 16:43:39.184381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)



# Generated at 2022-06-11 16:43:39.780546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:43:41.631591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit test for constructor of class StrategyModule')
    print('TODO')


# Generated at 2022-06-11 16:43:44.115674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debugger
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    strategy_module = debugger.StrategyModule(tqm)
    assert strategy_module.debugger_active



# Generated at 2022-06-11 16:43:48.157869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test case
  tqm = 'testtqm'

  # Test
  StrategyModule(tqm)

  # Assertion
  assert self.tqm == 'testtqm'
  assert self.step == 0
  assert self.results_callback == None
  assert self.display.verbosity == 0


# Generated at 2022-06-11 16:43:50.128416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:44:14.003639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestResult:
        def __init__(self, _task, _host, _result):
            self._task = _task
            self._host = _host
            self._result = _result
    ansible_play_hosts = "localhost"
    ansible_play_remote_user = "local_user"

# Generated at 2022-06-11 16:44:19.023677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQModule()
    sm = StrategyModule(tqm)
    assert sm.get_tqm() == tqm
    assert sm.get_worker_count() == 0
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:44:21.406519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.module_docs as module_docs

# Generated at 2022-06-11 16:44:24.215822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test normal instantiation
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-11 16:44:27.450207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule test")
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:44:30.740400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule test")
    # pass all arguments with values of the generic interface
    x = StrategyModule(None)
    # do something wuth x
    x.debugger_active = True
    print("StrategyModule test passed!")



# Generated at 2022-06-11 16:44:33.055427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert sm.tqm == tqm


# Generated at 2022-06-11 16:44:35.968563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    strategy = StrategyModule()
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:44:39.759235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test for init function in class StrategyModule.
    '''
    tqm = None
    test_strategy_module = StrategyModule(tqm)
    assert test_strategy_module.debugger_active == True



# Generated at 2022-06-11 16:44:41.790346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:45:17.509659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTqm()
    strategy = StrategyModule(tqm)
    assert tqm == strategy._tqm
    assert isinstance(strategy._tasks, list)
    assert isinstance(strategy._notified_handlers, dict)
    assert isinstance(strategy._block_list, list)
    assert strategy.debugger_active
# end test_StrategyModule



# Generated at 2022-06-11 16:45:18.562049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:45:19.558276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__



# Generated at 2022-06-11 16:45:23.114040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(">>> test_StrategyModule")
    #pass all arguments of linear module
    tqm = {}
    strategy_instance = StrategyModule(tqm)
    if strategy_instance.debugger_active != True:
        raise AssertionError("strategy module is not properly implemented")

# unit test for next_task method

# Generated at 2022-06-11 16:45:26.963538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule.__init__")
    sys.argv = [ 'ansible','-c','debug' ]
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:45:39.302177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = {}
    class TaskQueueManager:
        def __init__(self):
            self.data = data
            self.inventory = None
            self.tasks = None
            self.variables = None
        def get_vars(self, play, host, task):
            return self.variables
        def get_inventory(self):
            return self.inventory
        def get_variables(self, play, host, task):
            return self.variables

    class Host:
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    class Task:
        def __init__(self, name, module_name):
            self.name = name
            self.module_name = module_name
        def get_name(self):
            return

# Generated at 2022-06-11 16:45:44.910372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an empty task queue manager
    tqm = {}
    # Create a new instance of the StrategyModule class
    strategymodule = StrategyModule(tqm)
    # Check the debugger_active variable
    assert strategymodule.debugger_active is True
    # End the test
    return True

# End of test_StrategyModule function


# Generated at 2022-06-11 16:45:54.420199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.utils
    import ansible.callbacks

    loader = ansible.loader.Loader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager,  host_list='/dev/null')
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )


# Generated at 2022-06-11 16:45:57.304824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:45:58.830969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:47:04.975579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    return True


# Generated at 2022-06-11 16:47:06.694048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    StrategyModule(tqm)


# Generated at 2022-06-11 16:47:08.974086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n========== test_StrategyModule ===========")
    sys.exit("stub")



# Generated at 2022-06-11 16:47:10.516519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__


# Generated at 2022-06-11 16:47:12.938344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'result': {}}
    s = StrategyModule(tqm)
    assert s.debugger_active


# Generated at 2022-06-11 16:47:14.914791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=object())
    assert obj is not None


# Generated at 2022-06-11 16:47:15.786957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert true == false


# Generated at 2022-06-11 16:47:17.230349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:47:18.564172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    StrategyModule(tqm)


# Generated at 2022-06-11 16:47:20.793752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQMStub:
        pass
    tqm = TQMStub()
    StrategyModule(tqm)
    assert tqm.debugger_active == True


# Generated at 2022-06-11 16:49:53.077149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = ""
        sm = StrategyModule(tqm)
    except:
        print('Failed')


# Generated at 2022-06-11 16:50:03.468910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import tempfile
    import ansible.constants as C
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    options = C.init_ansible_module()
    options.private_key_file = '../test/test_data/ansible-key'
    options.connection = 'local'

    # Create data loader
    loader = DataLoader()

    # Create inventory and pass to var manager
    inventories = InventoryManager(loader, [options.inventory])
    variable_manager = VariableManager(loader, inventories, options)

    # Initialize task queue manager

# Generated at 2022-06-11 16:50:07.839463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print()
    print("Unit test of class StrategyModule")
    class fake_task_queue_manager:
        def __init__(self):
            self.stats = {}

    fake_tqm = fake_task_queue_manager()
    actual = StrategyModule(fake_tqm)
    assert actual.debugger_active == True


# Generated at 2022-06-11 16:50:09.749098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    sm = StrategyModule(tqm)

    print(sm.debugger_active)


# Generated at 2022-06-11 16:50:11.078009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:50:12.162292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:50:14.135131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [0]
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:50:15.366000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)



# Generated at 2022-06-11 16:50:16.343852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:50:18.496158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Executing' + __file__ + ':test_StrategyModule()')
    test_StrategyModule = StrategyModule()

