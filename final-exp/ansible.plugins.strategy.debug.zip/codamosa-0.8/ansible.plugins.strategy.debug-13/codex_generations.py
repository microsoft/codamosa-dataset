

# Generated at 2022-06-11 16:41:30.340977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global debugger_active
    tqm = MockTQM()
    StrategyModule(tqm)

    assert(debugger_active is True)

# FIXME: When adding new test case, it should be done on test_ansible_module.py.
#  This test case only checks if it is working when adding new test case.

# Generated at 2022-06-11 16:41:31.008882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:41:32.012014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:41:36.554629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = None

    # Act
    strategy_module = StrategyModule(tqm)

    # Assert
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:41:41.776915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This is a testing class.
    # Constructor of StrategyModule will not be called in "normal"
    # operation.  Nevertheless, this function tests constructor of
    # StrategyModule.
    tqm = cmd.Cmd
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True
    assert sm.tqm is tqm


# Generated at 2022-06-11 16:41:45.327947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock

    # get a StrategyModule
    strategyModule = StrategyModule(tqm=mock.MagicMock())
    assert isinstance(strategyModule, StrategyModule)


# Generated at 2022-06-11 16:41:47.814837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(LinearStrategyModule)
    except Exception as e:
        print("Exception on StrategyModule: {}".format(e))

# Runs the interactive session.

# Generated at 2022-06-11 16:41:49.820368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x.debugger_active == True


# Generated at 2022-06-11 16:41:51.858270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#    sm = StrategyModule(tqm)
#    assert sm.debugger_active == True
    return 0



# Generated at 2022-06-11 16:42:02.011460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            self.hosts = []
            self.result_callback = 0
            self.run_handlers = []
            self.notified_handlers = []
    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm.tqm.hosts == []
    assert sm.tqm.result_callback == 0
    assert sm.tqm.run_handlers == []
    assert sm.tqm.notified_handlers == []
    assert sm.tqm == tqm
    assert sm.debugger_active


# Generated at 2022-06-11 16:42:03.575091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:42:04.699660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)


# Generated at 2022-06-11 16:42:07.785222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.tqm == None
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:08.458024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:12.673826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests for constructor of class StrategyModule
    try:
        StrategyModule(None)
    except Exception as e:
        print('test_StrategyModule failed')
        print(e)


# Generated at 2022-06-11 16:42:13.234221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:42:16.537035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.linear import LinearStrategyModule
    except:
        print("ERROR: Failed to import 'ansible.plugins.strategy.linear' module.")

    try:
        strategy_module = StrategyModule(LinearStrategyModule)
    except:
        print("ERROR: Failed to create an object of 'StrategyModule' class.")

# Generated at 2022-06-11 16:42:18.333229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # assert tqm is not null
    print("test_StrategyModule")
    StrategyModule(1)
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:42:21.807459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {'name': 'tqm'}
    sm = StrategyModule(mock_tqm)
    assert sm.tqm == mock_tqm
    assert sm.debugger_active


# Generated at 2022-06-11 16:42:23.892017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test1 = StrategyModule(tqm)

# Unit test of method get_host_group_vars

# Generated at 2022-06-11 16:42:27.523682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except TypeError as e:
        assert False


# Generated at 2022-06-11 16:42:39.024997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        def __init__(self):
            self.hostvars = {'host1': {'groups': ['group1', 'group2'], 'hostvars': {'hostvars_var1': True, 'hostvars_var2': True}}}
    class Options(object):
        def __init__(self):
            self.module_path = 'self.module_path'
            self.forks = 'self.forks'
            self.become = 'self.become'
            self.become_method = 'self.become_method'
            self.become_user = 'self.become_user'
            self.remote_user = 'self.remote_user'
            self.private_key_file = 'self.private_key_file'
            self.remote

# Generated at 2022-06-11 16:42:41.804854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nTest Constructor of Class StrategyModule')
    tqm = []
    strategy = StrategyModule(tqm)
    print(strategy.__dict__)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:42:42.340722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:45.466497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm.debugger_active, 'debugger_active is not True'

# Example debugging session snippet

# Generated at 2022-06-11 16:42:46.076645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

# Generated at 2022-06-11 16:42:51.032443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        pass
    t = TestTQM()
    sm = StrategyModule(t)
    assert type(sm.debugger_active) == bool
    assert sm.debugger_active == True


# Executes task from host specified by host index

# Generated at 2022-06-11 16:42:54.527412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # Test StrategyModule object initialization
    #
    # Expected:
    #   A StrategyModule object should be created
    #   and its attribute 'debugger_active' should
    #   be set to True.
    #
    # TODO: Write test code


# Generated at 2022-06-11 16:42:56.054869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_mod = StrategyModule(tqm)


# Generated at 2022-06-11 16:42:59.033523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert test.tqm == None
    assert test.debugger_active == True


# Generated at 2022-06-11 16:43:04.173169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:43:13.055732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def __init__(self):
            self.inventory = ['a', 'b', 'c']
            self.default_vars = ['aa', 'bb', 'cc']

    tqm = FakeTQM()
    sm = StrategyModule(tqm)

    assert(sm.tqm == tqm)
    assert(sm.inventory == ['a', 'b', 'c'])
    assert(sm.default_vars == ['aa', 'bb', 'cc'])
    assert(sm.host_name == None)
    assert(sm.host == None)
    assert(sm.task_queue == [])
    assert(sm.feed_queue == [])
    assert(sm.results_queue == [])
    assert(sm.item_queue == [])

# Generated at 2022-06-11 16:43:14.590258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None)


# Generated at 2022-06-11 16:43:20.968777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import sys
    import tempfile
    sys.path.append('/home/kishin/ansible/test/integration/targets/plugin_strategy_debug')
    from __main__ import mock_tqm # pylint: disable=import-error

    tqm = mock_tqm

    strategy = StrategyModule(tqm)
    print('Assertions for constructor of class StrategyModule')
    assert strategy.debugger_active == True


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:43:22.773237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(0)
    except:
        assert False
    assert True



# Generated at 2022-06-11 16:43:23.389129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:43:25.189742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_runner = StrategyModule(1)
    assert my_runner.debugger_active == True


# Generated at 2022-06-11 16:43:36.292265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True
    assert sm.debugger_history == []
    assert sm.debugger_locals == []
    assert sm.done == []
    assert sm.stats == dict(changed=0, failures=0, ok=0, skipped=0, unreachable=0)
    assert sm.failed_hosts == {}
    #assert sm.get_name() == "linear"
    assert sm.iterator is not None
    assert sm.iterator_class == "LinearIterator"
    assert sm.noop_task is None
    assert sm.noop_task_skip == True
    assert sm.play is not None
    assert sm.play_basedir is None
    assert sm.playbook is not None
    assert sm.playbook_basedir is not None
    assert sm

# Generated at 2022-06-11 16:43:42.057668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.context_objects as context_objects
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    context_objects._initialize()
    loader = DataLoader()
    loader.set_basedir('/')
    host_list = [{'hostname': 'localhost', 'port': 2222, 'username': 'vagrant',
                 'password': 'vagrant', 'private_key_file': None, 'vault_pass': None, 'ssh_args': ''}]
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = Variable

# Generated at 2022-06-11 16:43:42.804406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-11 16:43:53.186481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stat = StrategyModule(tqm = "tqm")
    assert stat.debugger_active == True



# Generated at 2022-06-11 16:43:54.915408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not(StrategyModule('tqm') == None)


# Generated at 2022-06-11 16:44:01.289614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 0
  obj = StrategyModule(tqm)
  assert obj.debugger_active == True
  assert obj.host_list == []
  assert obj.iterator is None
  assert obj.inventory == None
  assert obj.name == 'debug'
  assert obj.noop_task_result is None
  assert obj.play is None
  assert obj.play_context is None
  assert obj.queue_name == 'debug_queue'
  assert obj.tqm is 0
  assert obj.vars is None


# Generated at 2022-06-11 16:44:02.727217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # obj = StrategyModule(tqm)



# Generated at 2022-06-11 16:44:07.748728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_tqm():
        def __init__(self):
            self.stats = {}

    tqm = Test_tqm()
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True
    obj.debugger_active = False


# Generated at 2022-06-11 16:44:11.842279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    # TODO: Should this not take an argument?
    strategy = StrategyModule()
    assert strategy
    assert not strategy.debugger_active

# TODO: This is a straight copy from `linear`.
#       Should we be testing the output of this function?

# Generated at 2022-06-11 16:44:13.213439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert LinearStrategyModule
    

# Generated at 2022-06-11 16:44:14.871073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: I have no idea how to test this.
    pass


# Generated at 2022-06-11 16:44:15.937027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-11 16:44:18.152993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(tqm) == "StrategyModule")



# Generated at 2022-06-11 16:44:36.310484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(False).debugger_active == True
    assert isinstance(StrategyModule(False), StrategyModule) == True


# Generated at 2022-06-11 16:44:37.252247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:44:45.330935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-11 16:44:46.742176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-11 16:44:49.238266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm, StrategyModule)


StrategyModule.test = test_StrategyModule



# Generated at 2022-06-11 16:44:50.115755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) != None

# Generated at 2022-06-11 16:44:53.371273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = pprint.pformat({"foo": "bar"})
    strategy_debug = StrategyModule(fake_tqm)
    assert strategy_debug.debugger_active is True


# Generated at 2022-06-11 16:44:54.732546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule is not None
  sys.exit()


# Generated at 2022-06-11 16:44:59.322555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize task queue manager
    tqm = None
    # Initialize class
    strategy = StrategyModule(tqm)
    # Check the param of debugger_active
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:45:03.964218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = [{'hostname': '127.0.0.1', 'gather_facts': 'no'}]
    task = [{'shell': 'hostname', 'register': 'hostname'}]
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-11 16:45:39.347972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM():
        pass
    fake_tqm = FakeTQM()
    strategy_module = StrategyModule(fake_tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:45:42.513663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    strategy = ansible.plugins.strategy.debug.StrategyModule("A")
    assert strategy != None


# Generated at 2022-06-11 16:45:45.724724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    t = StrategyModule(tqm)
    assert t.debugger_active == True

# Tests class StrategyModule with the debugger

# Generated at 2022-06-11 16:45:53.189978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    config = {}
    tqm = {}

    m = StrategyModule(tqm)
    assert m.tqm == tqm
    assert m.tqm__unreachable_hosts == {}
    assert m.tqm_failed_hosts == {}
    assert m.tqm_stats == {}
    assert m.tqm_variables == {}
    assert m.tqm_iterator is None
    assert m.tqm_pending_results == 0
    assert m.tqm_unparsed_results == []
    assert m.tqm_workers == 0
    assert m.tqm_should_run_persistent_connections is False
    assert m.debugger_active



# Generated at 2022-06-11 16:45:57.031931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("Unit test for constructor of class StrategyModule")
  strategy = StrategyModule(None)
  assert strategy.debugger_active == True
  return strategy


# Generated at 2022-06-11 16:45:59.705530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module.debugger_active is True



# Generated at 2022-06-11 16:46:10.691418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display, verbosity_threshold

    class TestCallback(CallbackBase):

        verbosity = 2

        def __init__(self):
            super(TestCallback, self).__init__()
            self.show_stdout = False
            self.verbose = False
            self.debugger_active = False

    display = Display()
    display.verbosity = verbosity_threshold('vvv')
    callback = TestCallback()
    callback.display = display
    callback.verbose = True
    callback.show_stdout = True
    callback.debugger_active = True

    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active == True
    assert s.show_stdout == False


# Generated at 2022-06-11 16:46:12.721747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        stats = None

    sm = StrategyModule(TQM)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:46:13.467168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:46:16.856549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class_under_test = StrategyModule(None)
    assert class_under_test is not None, "test_StrategyModule: constructor failed"
    assert class_under_test.debugger_active is True, "test_StrategyModule: constructor failed"
    return class_under_test



# Generated at 2022-06-11 16:47:37.386007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mod = StrategyModule()
    assert isinstance(strategy_mod, StrategyModule)
    assert strategy_mod.debugger_active is True


# Generated at 2022-06-11 16:47:38.547449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:47:46.130208
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:47:48.396857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("test_StrategyModule")
  return StrategyModule('tqm')

if __name__ == "__main__":
  pprint.pprint(test_StrategyModule())

# Generated at 2022-06-11 16:47:50.948044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    assert StrategyModule(tqm)


# Generated at 2022-06-11 16:47:53.646348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    strategy = StrategyModule(TaskQueueManager())
    assert strategy.debugger_active
    


# Generated at 2022-06-11 16:47:54.812022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    print('It\'s a unit test!')


# Generated at 2022-06-11 16:47:55.619334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-11 16:47:56.686713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-11 16:47:58.637605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:50:47.972334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:50:49.452254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructor test
    """
    pass



# Generated at 2022-06-11 16:50:58.893927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeQueueManager:
        def __init__(self):
            self.stats = {'processed': 0}

    fake_queue_manager = FakeQueueManager()
    strategy_module = StrategyModule(fake_queue_manager)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active == True
    assert strategy_module.host_vars == {}
    assert isinstance(strategy_module.inventory, dict)
    assert strategy_module.inventory == {}
    assert strategy_module.variable_manager == None
    assert isinstance(strategy_module.tqm, FakeQueueManager)
    assert strategy_module.tqm == fake_queue_manager
    assert strategy_module.pattern == None
    assert strategy_module.subset == None

# Generated at 2022-06-11 16:51:02.130128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm.debugger_active
    assert sm.tqm == "tqm"
    assert sm.runners



# Generated at 2022-06-11 16:51:02.860374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:51:06.454747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active


# Generated at 2022-06-11 16:51:11.335334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv.remove('--debugger')
    import ansible.plugins.strategy.debug as debug_strategy_mod
    reload(debug_strategy_mod)
    reload(debug_strategy_mod.StrategyModule)
    reload(debug_strategy_mod.Debugger)
    strategy_module = debug_strategy_mod.StrategyModule(None)
    assert strategy_module.debugger_active == True

# Generated at 2022-06-11 16:51:12.952682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print(StrategyModule(1))



# Generated at 2022-06-11 16:51:15.474261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert True == isinstance(strategy, StrategyModule)


# Generated at 2022-06-11 16:51:16.431469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule('tqm')
