

# Generated at 2022-06-11 16:41:26.228352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == 'StrategyModule')



# Generated at 2022-06-11 16:41:29.280841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('fake_tqm')
    assert strategy_module.tqm == 'fake_tqm'
    assert strategy_module.debugger_active == True



# Generated at 2022-06-11 16:41:32.793557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('[TASK] Unit test for constructor')
    sm = StrategyModule(tqm)
    assert sm is not None
    print('[PASS] Constructor of class StrategyModule')


# Generated at 2022-06-11 16:41:34.370543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True



# Generated at 2022-06-11 16:41:35.685234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_obj = StrategyModule(None)
    assert test_obj is not None


# Generated at 2022-06-11 16:41:42.921348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import RESERVED_VARS
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.strategy.debug import debug


# Generated at 2022-06-11 16:41:45.676780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategy_module = StrategyModule(tqm)
    assert(False)


# Generated at 2022-06-11 16:41:46.595966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule([])
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-11 16:41:47.912312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    sm = StrategyModule(test_tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:41:52.934700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # stubs
    tqm = []
    # test
    strategy = StrategyModule(tqm)
    assert hasattr(strategy, 'debugger_active')

# class StrategyModule
#     run(self, iterator, play_context):
    # Unit test for method 'run'

# Generated at 2022-06-11 16:41:57.752910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.template
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins import callback_loader
    from ansible.playbook.play import Play
    loader = DataLoader()
    host = Host(name="127.0.0.1")
    group = Group(name="test")
    group.add_host(host)
    variable_manager = VariableManager()
   

# Generated at 2022-06-11 16:41:59.401375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM(object):
        def __init__(self):
            pass

    mock = MockTQM()
    strategy = StrategyModule(mock)
    assert strategy is not None


# Generated at 2022-06-11 16:42:00.161609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-11 16:42:11.045298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active

    assert(sm.stats.moved_file == {})
    assert(sm.stats.failed_hosts == {})
    assert(sm.stats.changed_hosts == {})
    assert(sm.stats.dark_hosts == {})
    assert(sm.stats.ok_hosts == {})
    assert(sm.stats.processed_hosts == {})
    assert(sm.stats.total_failures == 0)
    assert(sm.stats.total_ok == 0)
    assert(sm.stats.total_dark == 0)
    assert(sm.stats.total_processed == 0)
    assert(sm.stats.total_tasks == 0)


# Generated at 2022-06-11 16:42:13.841469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = LinearStrategyModule(tqm)
    if isinstance(test_object, LinearStrategyModule):
        return True
    else:
        return False


# Generated at 2022-06-11 16:42:16.485471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

    # verify that we can create an instance of StrategyModule
    # strategy = StrategyModule(Tqm())


# Generated at 2022-06-11 16:42:18.915585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active == True


# Generated at 2022-06-11 16:42:29.968261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Introducing mock objects until ansible.utils.module_docs_fragments gets a manual constructor
    from ansible.utils import module_docs_fragments
    from ansible.utils.module_docs_fragments import get_docstring, get_version
    module_docs_fragments.get_docstring = lambda modname: {'version_added': "2.3", 'short_description': 'Executes tasks in interactive debug session.'}
    module_docs_fragments.get_version = lambda: '2.3'

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Task
    document = TaskInclude()
    document._role = 'debug'
    task_obj = Task()
    tqm = 'Test tqm'
    strategy_module = StrategyModule

# Generated at 2022-06-11 16:42:36.650345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing constructor of class StrategyModule")
    test_tqm_obj = object()
    strategy_module_instance = StrategyModule(test_tqm_obj)
    assert strategy_module_instance.tqm == test_tqm_obj
    assert hasattr(strategy_module_instance, 'debugger_active')
    assert strategy_module_instance.debugger_active == True



# Generated at 2022-06-11 16:42:40.955909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # You can get tqm from Ansible like below.
    # Let's ansible.executor.task_queue_manager.TaskQueueManager
    #   be defined as tqm.
    #
    # tqm = Ansible.executor.task_queue_manager.TaskQueueManager()

    strategy_module = StrategyModule(tqm)

    assert strategy_module.tqm is tqm
    assert strategy_module.debugger_active is True

# Generated at 2022-06-11 16:42:44.431388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-11 16:42:45.821949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-11 16:42:48.487524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'test'
  s = StrategyModule(tqm)
  assert isinstance(s, StrategyModule)



# Generated at 2022-06-11 16:42:53.065714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'Test'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active
    assert isinstance(strategy_module, LinearStrategyModule)
    assert isinstance(strategy_module, StrategyModule)



# Generated at 2022-06-11 16:42:57.593317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class_object = StrategyModule(tqm = None)
    for (field, value) in ((v, getattr(class_object, v)) for v in dir(class_object)):
        if (field.startswith('_')):
            continue
        print("{0} = {1}".format(field, value))

    assert True


# Generated at 2022-06-11 16:43:09.351416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True

# >>>>>>>>>>>>>> Start of custom code >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
import sys
if sys.version_info[0] == 3:
    py_version = 3
else:
    py_version = 2

# import re module (regular expression)
import re

# import getpass module
import getpass

# import os module
import os

# import sendkeys module
import sendkeys

# import fileinput module
import fileinput

# import ctypes module
import ctypes

# import subprocess module
import subprocess

# import signal module
import signal

# import time module
import time

# import shutil module
import shutil

# import datetime module
import datetime

# import pywin32 module

# Generated at 2022-06-11 16:43:15.594615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    tqm['tasks'] = [{
        'action': {
            '__ansible_module__': 'ping',
            '__ansible_arguments__': {
                'data': 'pong'
            },
        },
    }]
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-11 16:43:22.935710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils
    import ansible.plugins
    import ansible.callbacks
    import ansible.inventory
    import ansible.playbook

    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    from ansible import errors

    from ansible.vars import VariableManager

    class Test:
        name = 'Debug Test'
        playbook = None

    import ansible.utils.vars
    import ansible.utils.unicode
    import ansible.utils.path

    import ansible.plugins.cache

    from ansible.plugins.strategy import StrategyBase

    class TQM(StrategyBase):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 16:43:23.589425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:43:28.525789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        def __init__(self):
            pass
    class TestOptions:
        def __init__(self):
            pass
    class TestVariableManager:
        def __init__(self):
            pass
    strategy = StrategyModule(TestTaskQueueManager())
    assert strategy.debugger_active == True

# Generated at 2022-06-11 16:43:43.005765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', '--help']
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.display import Display
    from ansible.utils.shlex import shlex_split

    playbook = "/path/to/sample_playbook.yml"
    display = Display()
    options = None
    loader = None
    variable_manager = None
    passwords = dict()
    tqm = PlaybookExecutor(playbooks = [playbook],
                           inventory = None,
                           variable_manager = variable_manager,
                           loader = loader,
                           options = options,
                           passwords = passwords,
                           display = display)
    StrategyModule(tqm)

# Main for

# Generated at 2022-06-11 16:43:44.427779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()
    print ("StrategyModule has been created")


# Generated at 2022-06-11 16:43:45.428235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-11 16:43:46.466226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule

# Generated at 2022-06-11 16:43:48.106913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    StrategyModule(tqm)


# Generated at 2022-06-11 16:43:49.282095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:43:53.079370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dummy_tqm = 'dummy_tqm'
    strategyModule = StrategyModule(dummy_tqm)
    assert strategyModule.debugger_active == True

# Ansible Debugger Class

# Generated at 2022-06-11 16:44:02.382434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.loader import DataLoader
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    #from ansible.plugins.strategy.linear import StrategyModule
    from ansible.utils.display import Display
    #from ansible.constants import FORCE_COLOR

    class Host(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name


# Generated at 2022-06-11 16:44:05.948597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {}
    sm1 = StrategyModule(mock_tqm)
    assert sm1.debugger_active

# unit test for run method of class StrategyModule

# Generated at 2022-06-11 16:44:08.469771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule("test")
    assert test.debugger_active == True
    assert test.tqm == "test"



# Generated at 2022-06-11 16:44:56.495974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-11 16:45:00.990643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    setup_test_data()
    test_class = StrategyModule(tqm)
    assert test_class.debugger_active == True
    teardown_test_data()

StrategyModule.add_action = LinearStrategyModule.add_action


# Generated at 2022-06-11 16:45:06.897646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    init_tqm = 'init_tqm'
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.init_tqm == init_tqm
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True
    assert strategy_module.shared_loader_obj


# Generated at 2022-06-11 16:45:07.696079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Add some test
    assert True

# Generated at 2022-06-11 16:45:14.882424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n")
    print("Running test cases for debug plugin: constructor of StrategyModule")
    class TestObj():
        def __init__(self):
            self.cur_triple = ('a', 'b', 'c')
            self.failed_hosts = ['a', 'b', 'c']
            self.work_queue = ['a', 'b', 'c']

    test_obj = TestObj()
    strategy_module = StrategyModule(test_obj)


# Generated at 2022-06-11 16:45:16.238865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    assert StrategyModule is not None


# Generated at 2022-06-11 16:45:24.722506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        class AnsibleOptions:
            verbosity = 0
            debug = False
            stdout_callback = 'human'

    class TestHost:
        class Configuration:
            transport = 'paramiko'

        def __init__(self, name):
            self.name = name
            self.configuration = TestHost.Configuration()

    class TestInventory:
        def __init__(self):
            self.hosts = dict(
                local=TestHost('127.0.0.1'),
                remote=TestHost('192.168.0.1'),
            )
            self.hosts['local'].groups = dict(local=['local'])
            self.hosts['remote'].groups = dict(remote=['remote'])


# Generated at 2022-06-11 16:45:26.371039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: mock results of super(...).__init__() for unit test
    pass



# Generated at 2022-06-11 16:45:34.381183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start unit test of StrategyModule constructor.")
    # need to run StrategyModule's constructor
    # StrategyModule.__init__(self, tqm)
    class tqm():
        pass
    tqm = tqm()
    test_object_StrategyModule = StrategyModule(tqm)
    print("StrategyModule object name: " + str(test_object_StrategyModule.__class__.__name__))
    print("End unit test of StrategyModule constructor.")


# run_once unit test

# Generated at 2022-06-11 16:45:36.568921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = "") is not None


# Generated at 2022-06-11 16:46:05.709805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule("foo")

    # Attributes should exists
    assert hasattr(res, "debugger_active")


# Generated at 2022-06-11 16:46:14.801453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# class ConsoleDebug(cmd.Cmd):

#     def __init__(self, worker):
#         cmd.Cmd.__init__(self)
#         self.prompt = 'ConsoleDebug> '
#         self.worker = worker
#         self.update_prompt(worker.task_name)
#         self.intro = "Launching interactive console debugger. 'help' lists available commands."

#     def emptyline(self):
#         pass

#     def do_next(self, arg):
#         "Go to next task"
#         self.worker.debugger_active = False

#     def do_step(self, arg):
#         "Step into task"
#         # print 'STUB'
#         self.worker.debugger_active = False

#     def do_up(

# Generated at 2022-06-11 16:46:18.187700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # Note: The test requires AnsibleTQM to be instantiated first.

    # The following code is stub.
    # tqm = AnsibleTQM()    
    # sm = StrategyModule(tqm)
    # assert sm

# Generated at 2022-06-11 16:46:23.732556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import callback_loader
    from ansible_debug.test.test_commandline import test_stub_commandline

    def stub_display(msg, color=None, stderr=False, screen_only=False, log_only=False):
        pass

    # To remove debug session when testing this class
    test_stub_commandline.remove_debug_session()

    # Stub object to replace display class
    display_obj = callback_loader.get('display', class_only=True)
    setattr(display_obj, 'display', stub_display)

    # Create a task queue manager to execute tasks.
    tqm = test_stub_commandline.create_task_queue_manager(0)
    strategy_obj = StrategyModule(tqm)

    # Test if the debugger is active


# Generated at 2022-06-11 16:46:24.790719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:46:28.881123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test = StrategyModule(tqm)
    except Exception as e:
        assert(False)

# This controls whether to fork off a separate Python interpreter
# to execute the code or to execute the code in one interpreter.
# The reason to fork off a new interpreter is to prevent the
# code to be executed from "polluting" the caller's interpretation.

# Generated at 2022-06-11 16:46:32.958805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    mod = StrategyModule(None)
    assert mod.tqm is None
    assert mod.debugger_active is True


# Generated at 2022-06-11 16:46:34.142750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-11 16:46:37.980419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm():
        def __init__(self):
            self.hosts = {'dummy': DummyHost()}
            self.inventory = DummyInventory()
            self.callback = DummyCallback()
            self.stats = DummyStats()
    module = StrategyModule(DummyTqm())


# Generated at 2022-06-11 16:46:46.147099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test for constructor of class StrategyModule")

    # Initializing an empty AnsibleTaskQueueManager
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    cli = CLI(args=[])
    loader = DataLoader()
    inventory_manager = InventoryManager(loader, cli.options, None)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)

# Generated at 2022-06-11 16:47:52.545581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert(module.debugger_active == True)


# Generated at 2022-06-11 16:47:54.581031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategyModule = StrategyModule(tqm)
  assert strategyModule.debugger_active == True


# Generated at 2022-06-11 16:47:57.634875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        __module__ = 'ansible.executor.task_queue_manager'

    test_tqm = TestTQM()
    test_strategy = StrategyModule(test_tqm)



# Generated at 2022-06-11 16:47:59.756256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('##### test_StrategyModule()')
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:48:03.682120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = ''

    strategy = StrategyModule(tqm)

    if strategy.__class__.__name__ == 'StrategyModule':
        print('SUCCESS: __init__: constructor')
    else:
        print('FAILED: __init__: constructor')

#test_StrategyModule()


# Generated at 2022-06-11 16:48:10.008493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def __init__(self):
            self.hostvars = {'all': {}}
    tqm = FakeTQM()
    module = StrategyModule(tqm)
    assert isinstance(module, LinearStrategyModule)
    assert module.tqm == tqm
    assert module.debugger_active == True

# The below is based on https://docs.python.org/2/library/cmd.html
# To test, run
# python -m ansible.plugins.strategy.debug debug/test_debug.py
# at time of commit, it needs to be run from the plugins directory
# rather than the debug directory

# Generated at 2022-06-11 16:48:15.902133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    exec(compile(open(sys.argv[1]).read(), sys.argv[1], 'exec'))
    tqm = TaskQueueManager()
    strategy = StrategyModule(tqm)
    import inspect
    assert inspect.getsource(strategy.__init__) == inspect.getsource(test_StrategyModule.__wrapped__)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:48:19.998784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        stats = {}
    class StrategyModule:
        def __init__(self, tqm):
            pass
    self.assertRaises(TypeError,StrategyModule,TQM)
    StrategyModule(TQM)
    self.assertEqual(True,True)



# Generated at 2022-06-11 16:48:20.708974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:48:22.855376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule()
    assert test_StrategyModule
