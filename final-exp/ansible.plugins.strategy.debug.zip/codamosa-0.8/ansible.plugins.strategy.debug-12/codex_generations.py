

# Generated at 2022-06-11 16:41:26.360992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None


# Generated at 2022-06-11 16:41:29.424867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("in test_StrategyModule")
    tqm = None
    strategy = StrategyModule(tqm)
    assert (strategy.debugger_active == True)


# Generated at 2022-06-11 16:41:31.378529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:41:34.062300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#    tqm=None
    strategy = StrategyModule(None)
    assert strategy.tqm == None
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:41:37.208363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0] == LinearStrategyModule
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, 'debugger_active')


# Generated at 2022-06-11 16:41:38.215722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:41:39.983562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert(sm.debugger_active == True)


# Generated at 2022-06-11 16:41:42.896408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_obj = StrategyModule(tqm="Some text")
    assert isinstance(debug_obj, LinearStrategyModule)
    assert debug_obj is not None
    assert debug_obj.debugger_active


# Generated at 2022-06-11 16:41:43.545983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-11 16:41:44.449252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:47.497882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule(tqm=None)
    assert test_module.debugger_active == True


# Generated at 2022-06-11 16:41:48.522680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:41:51.471107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # dev debug module
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:41:57.707553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    test_tqm = ""
    strategy_module = StrategyModule(test_tqm)
    assert(strategy_module.debugger_active == debugger_active)
    assert(strategy_module.tqm == test_tqm)
    assert(strategy_module.loop is None)


# Generated at 2022-06-11 16:41:58.853501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-11 16:41:59.919884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__


# Generated at 2022-06-11 16:42:03.189564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    from ansible.plugins.strategy.debug import StrategyModule

    tqm = mock.MagicMock()

    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-11 16:42:05.843290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a trivial task queue manager
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-11 16:42:08.238914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError as e:
        assert "missing 1 required positional argument" in str(e)


# Generated at 2022-06-11 16:42:16.684437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = 'mock_tqm'
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module.debugger_active == True


# Run the unit tests for this module
# Ansible itself imports ansible.plugins.strategy.debug module to run its unit tests.
# This conditional is executed when in this module is imported from playbook
# from playbook.
if __name__ == '__main__':
    test_StrategyModule()
    print('Unit test for `strategy/debug` module passed.')

# Generated at 2022-06-11 16:42:19.079637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:42:22.622316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    linear_strategy_module = LinearStrategyModule(task_queue_manager)

    assert isinstance(linear_strategy_module, LinearStrategyModule)



# Generated at 2022-06-11 16:42:32.234719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.runner = object()
    class TestRunner(object):
        def __init__(self):
            self.host_results = {'localhost': {'task': {}, 'result':{}}}
    class TestModule(object):
        def __init__(self):
            self._name = 'MyModule'
    tqm = TestTQM()
    tqm.runner = TestRunner()
    strategy = StrategyModule(tqm)
    module = TestModule()
    strategy.add_tasks(host=None, tasks=[dict(action=dict(module=module, args=dict()))])
    assert strategy.host_tasks['localhost'] == [[dict(action=dict(module=module, args=dict()))]]

# Generated at 2022-06-11 16:42:36.307959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'result': 'result', 'kerberos_cache': 'kerberos_cache'}
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:40.185138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # unit test for constructor of class StrategyModule
    pass

    tqm = cmd.Cmd()

    sm = StrategyModule(tqm)
    assert(sm.debugger_active == True)


# Called from Main when running with linear strategy

# Generated at 2022-06-11 16:42:43.742788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        t = 'Test'
        tqm = StrategyModule(t)
    except NameError:
        pass
    except:
        assert False


# Generated at 2022-06-11 16:42:45.174076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:42:46.631015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-11 16:42:48.488167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule('')

# Unit Test for constructor of class Debugger

# Generated at 2022-06-11 16:42:49.512526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:44:02.727704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.host_states == dict()
    assert strategy.host_results == dict()
    assert strategy.host_variables == dict()
    assert strategy.results == dict()
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:44:03.824202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule

# Generated at 2022-06-11 16:44:06.052078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(NoopTQM())
    assert sm.debugger_active


# Generated at 2022-06-11 16:44:08.147990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule = StrategyModule(3)
    assert StrategyModule.tqm == 3


# Generated at 2022-06-11 16:44:10.128695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:44:11.911658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm_module = StrategyModule("test")
    assert test_tqm_module.debugger_active == True



# Generated at 2022-06-11 16:44:13.310545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule
    assert isinstance(strategy, object)


# Generated at 2022-06-11 16:44:24.112089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.playbook
    import ansible.utils as utils
    import ansible.variables as variables
    import ansible.callbacks as callbacks
    import ansible.inventory as inventory
    import ansible.constants as constants

    class TestablePlaybook:
        def __init__(self):
            self.inventory = inventory.Inventory(
                constants.DEFAULT_HOST_LIST
            )

    class TestableTqm:
        def __init__(self):
            self.stats = callbacks.AggregateStats()
            self.callbacks = callbacks.PlaybookCallbacks(
                verbose=utils.VERBOSITY
            )

# Generated at 2022-06-11 16:44:28.194919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert(strategy_module.debugger_active == True)
    assert(strategy_module.tqm == 'tqm')



# Generated at 2022-06-11 16:44:31.325098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None)
    StrategyModule(tqm)


# Generated at 2022-06-11 16:45:37.406759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager():
        def __init__(self):
            self.stats = {}
    class Module():
        def __init__(self):
            self.TASK_NOOP = 'TASK_NOOP' 
            self.TASK_FAILED = 'TASK_FAILED' 
            self.TASK_INCLUDES = 'TASK_INCLUDES' 
            self.TASK_KEEP_REMOTE_FILES = 'TASK_KEEP_REMOTE_FILES'
            self.TASK_TAGS_IGNORE = 'TASK_TAGS_IGNORE'
            self.TASK_TAGS_ALL = 'TASK_TAGS_ALL'

# Generated at 2022-06-11 16:45:40.569780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(object)
    assert isinstance(strategy, LinearStrategyModule)
    assert isinstance(strategy, object)
    assert strategy.tqm == object
    assert strategy.debugger_active



# Generated at 2022-06-11 16:45:43.744257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    tqm = None
    strategy = strategy_loader.get('debug', tqm)
    assert(isinstance(strategy, StrategyModule) == True)


# Generated at 2022-06-11 16:45:45.037614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)



# Generated at 2022-06-11 16:45:49.544238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('tqmtest', (object,), {'_final_q': '_final_qtest', '_failed_hosts': '_failed_hoststest', 'stats': 'statstest'})
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:45:58.134414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialization of StrategyModule object
    import ansible.plugins.strategy.debug
    import ansible.playbook
    import ansible.playbook.task_include
    import ansible.utils.shlex
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import ansible.utils.vars
    import ansible.parsing.splitter
    import ansible.plugins.loader

    test_templar = Templar(loader=None)

    class MockInventory(object):
        pass

    test_inventory = MockInventory()

    test_variable_manager = ansible.vars.VariableManager()

    test_loader = ansible.plugins.loader.PluginLoader()


# Generated at 2022-06-11 16:46:02.189434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    exit()
    
    def hostvars(host):
        return {}

    tqm = type('TQM', (object,), {'hostvars': hostvars})()
    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:46:04.515223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    return



# Generated at 2022-06-11 16:46:13.971130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTaskQueueManager:
        stats = {
            'dark': {},
            'failures': {},
            'processed': {},
            'ok': {},
            'skipped': {},
        }
        def __init__(self):
            self.host_failed_events = set()
            self.host_unreachable_events = set()
            self.host_skipped_events = set()
            self.task_ok_events = set()
            self.task_failed_events = set()
            self.task_stats = self.stats

    FakeHost = lambda addr: None
    tqm = FakeTaskQueueManager()
    tqm.get_hosts = lambda pattern: [FakeHost('127.0.0.1')]
    strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:46:15.602836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:46:33.580960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyResult()
    res = StrategyModule(tqm)
    assert res.debugger_active == True


# Generated at 2022-06-11 16:46:35.470356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active


# Generated at 2022-06-11 16:46:38.609545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert stm.debugger_active == True


examine_queue = []


# Generated at 2022-06-11 16:46:40.953207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    # Check strategy object variables
    assert strategy.tqm is None
    assert strategy.debugger_active is True


# Generated at 2022-06-11 16:46:51.782768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    tqm = TaskQueueManager(
        inventory='inventory.example',
        variable_manager='var_manager.example',
        loader='loader.example',
        options='options.example',
        passwords='password.example',
        stdout_callback='stdout.example',
        run_additional_callbacks='callbacks.example',
        run_tree='run_tree.example',
    )
    play_context=PlayContext()
    play_context.update_vars({'foo': 'bar'})

    # test 1
    strategyModule = StrategyModule(
        tqm=tqm,
        play_context=play_context,
    )
    assert strategyModule.debugger

# Generated at 2022-06-11 16:46:56.987526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    options = {"connection": "local", "module_path": None, "forks": 5, "become": False, "become_method": None, "verbosity": 3}
    loader = None
    variable_manager = None
    inventory = None

    tqm = TestTaskQueueManager(loader, options, variable_manager, inventory)
    module = StrategyModule(tqm)
    assert module.debugger_active == True


# Generated at 2022-06-11 16:46:59.390508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()

# Set up a simple unit test

# Generated at 2022-06-11 16:47:00.925598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__module__ == 'ansible.plugins.strategy.debug')

# class StrategyModule

# Generated at 2022-06-11 16:47:11.511629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MyTqm():
        def __init__(self, host_list):
            self.host_list = host_list
            self.stats = dict()

    class MyTaskQueueManager(MyTqm):
        def __init__(self, host_list):
            super(MyTaskQueueManager, self).__init__(host_list)

        def get_host_list(self):
            return self.host_list

    host_list = [
        'host_1',
        'host_2',
        'host_3'
    ]

    tqm = MyTaskQueueManager(host_list)
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:47:13.571500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-11 16:47:56.210255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running unit test for constructor of class StrategyModule')
    test_tmq = None
    test_sm = StrategyModule(test_tmq)
    assert test_sm == None


# Generated at 2022-06-11 16:47:57.556261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' == StrategyModule.__name__


# Generated at 2022-06-11 16:48:00.672819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock.Mock()
    debugger = StrategyModule(tqm)
    assert debugger.tqm is tqm
    assert debugger.shown is None
    assert debugger.debugger_active is True


# Generated at 2022-06-11 16:48:02.982439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

_STRATEGY_PLUGIN_CLASSES['debug'] = StrategyModule
_STRATEGY_PLUGIN_CONSTANTS['debug'] = "debug"

# Generated at 2022-06-11 16:48:03.793968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:48:04.602624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:48:05.966276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule
    except:
        assert False



# Generated at 2022-06-11 16:48:07.649176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    test = StrategyModule(tqm)
    assert test.tqm == tqm


# Generated at 2022-06-11 16:48:10.544933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create class/object
    strategy_module = StrategyModule("test_tqm")
    # Verify properties are set properly
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:48:11.098695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True
