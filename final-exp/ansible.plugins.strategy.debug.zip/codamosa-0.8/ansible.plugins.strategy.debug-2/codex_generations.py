

# Generated at 2022-06-11 16:41:25.040469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert not StrategyModule.__doc__

if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-11 16:41:35.868311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.utils.color as color
    import ansible.vars.manager as varmanager
    import ansible.vars.hostvars as hv
    import ansible.playbook.play as playbookplay
    import ansible.playbook.task as task
    import ansible.playbook.handler as handler
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.modules.system.setup import Setup
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.clean import clean_facts
    from ansible.vars.reserved import reserved_variables
    from ansible.vars.manager import Variable

# Generated at 2022-06-11 16:41:38.513954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    tqm = None
    ans = StrategyModule(tqm)

    # Assertion
    assert ans is not None
    assert ans.debugger_active == True


# Generated at 2022-06-11 16:41:40.329036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #simple test for debug constructor
    assert StrategyModule('test')



# Generated at 2022-06-11 16:41:43.915636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('')
    print('Begin test')
    print('Begin test for StrategyModule constructor')
    tqm = ''
    strategy = StrategyModule(tqm)
    print('End test')
    print('')


# Generated at 2022-06-11 16:41:55.316235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    obj = StrategyModule(tqm)
    assert obj.debugger_active
#unit tests end
    
    def run_debugger(self):
        '''
        Launches debugger as a subshell
        '''

        # run debugger in subshell until end of execution
        while self.debugger_active:
            self.debugger.cmdloop()
            # if the interpreter is about to quit, stop the debugger
            # or the debugger will cause it to wait for more input
            if sys.flags.quit:
                self.debugger_active = False

    def run(self, iterator, play_context):
        '''
        Run the handler for a task.
        '''

        self.debugger = Debugger(self._tqm, play_context)
        self._tqm._terminated

# Generated at 2022-06-11 16:41:59.067413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("TEST: test_StrategyModule()")

    strategy_module = StrategyModule(None)
    assert strategy_module
    assert strategy_module.debugger_active



# Generated at 2022-06-11 16:41:59.603666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule("tqm")


# Generated at 2022-06-11 16:42:01.370146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule('tqm')
    assert m.debugger_active == True



# Generated at 2022-06-11 16:42:12.155527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(sys.version_info[0] == 3)
    tqm = None
    obj = StrategyModule(tqm)
    assert(str(obj) == '<ansible.plugins.strategy.debug.StrategyModule object at 0x0>')
    assert(obj.name == 'debug')
    assert(obj.display == 'debug')

# Generated at 2022-06-11 16:42:14.881722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:42:23.953046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    # We want to play a single play for testing.
    pb = Playbook.load('./test/ansible/playbooks/debugger/debugger_hostgroup.yml')
    tqm = TaskQueueManager(
        inventory=pb.get_hosts(),
        variable_manager=pb.get_variable_manager(),
        loader=pb.get_loader(),
        passwords=dict(vault_pass='secret'),
        stdout_callback='default',
        run_additional_callbacks=True,
        run_tree=False,
        playbook='./test/ansible/playbooks/debugger/debugger_hostgroup.yml',
    )
    # Set the strategy to Linear instead of

# Generated at 2022-06-11 16:42:33.066571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Setting up ansible for handling yaml file(yaml is superset of json)
    variables = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='hosts')

# Generated at 2022-06-11 16:42:34.616995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# A simple debugger class for testing.

# Generated at 2022-06-11 16:42:41.294766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unit
    import sys
    import multiprocessing
    tqm = unit.TestTaskQueueManager(
        os.environ['ANSIBLE_LIBRARY'],
        os.environ['ANSIBLE_MODULE_UTILS'],
        forks=multiprocessing.cpu_count(),
        module_name = 'debug',
        module_path = os.path.join(os.path.dirname(unit.__file__), '../../plugins/strategy/debug.py')
    )
    saved_stdout = sys.stdout
    try:
        this_module = StrategyModule(tqm)
        assert this_module != None
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-11 16:42:53.064977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.hostvars = {}
    test_TQM = TestTQM()
    test_StrategyModule = StrategyModule(test_TQM)
    assert test_StrategyModule.debugger_active == True

# TODO: Apply tests for StrategyModule class functions below
# def _pause(self): 
# def _pause_on_pending(self): 
# def _pause_on_work(self, play_context, iterator, play_context): 
# def _pause_on_handler(self, play_context, iterator, play_context): 
# def _pause_on_error(self, play_context, iterator, play_context): 
# def _process_pending_results(self, iterator): 
# def _print_result

# Generated at 2022-06-11 16:42:57.162393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible'] = MockAnsible()
    sys.modules['ansible.plugins'] = MockAnsiblePlugins()
    tqm = MockTaskQueueManager()
    obj = StrategyModule(tqm)
    assert obj is not None
test_StrategyModule.__test__ = False


# Generated at 2022-06-11 16:43:00.582048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check whether constructor of class StrategyModule runs OK.
    tqm = object()
    s = StrategyModule(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-11 16:43:01.904925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-11 16:43:06.310553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module_name = 'test_StrategyModule'
    m = StrategyModule(test_module_name)
    assert m.name == test_module_name
    assert m.debugger_active == True
    


# Generated at 2022-06-11 16:43:09.606060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None # Constructor only


# Generated at 2022-06-11 16:43:14.052200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTqm()
    StrategyModule(tqm)
    if not tqm.is_debugger_active():
        raise Exception("StrategyModule does not set debugger_active in tqm.")



# Generated at 2022-06-11 16:43:16.086003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('dummy')
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:43:20.560458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm.debugger_active == True)

# testing code for debug
# TODO: Make sure to append "debug" to the list of strategies.
# TODO: Read ansible-playbook or ansible to learn how to call ansible-playbook with strategy "debug".
# TODO: When strategy is debug, run test_debug() below.


# Generated at 2022-06-11 16:43:22.362739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    o_StrategyModule = StrategyModule(tqm)
    assert o_StrategyModule != None


# Generated at 2022-06-11 16:43:25.009287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTaskQueueManager():
        pass
    fake_manager = FakeTaskQueueManager()
    strategy_module = StrategyModule(fake_manager)
    assert strategy_module


# Generated at 2022-06-11 16:43:28.371988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule()
    except NotImplementedError:
        1==1
    else:
        assert False, "Should throw NotImplementedError"


# Generated at 2022-06-11 16:43:29.383744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:43:33.840067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule()
    assert test_module.debugger_active == True

    # Test for the class definition
    assert issubclass(StrategyModule, LinearStrategyModule)   
    assert isinstance(test_module, StrategyModule)


# Generated at 2022-06-11 16:43:42.428893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    foo = StrategyModule(tqm)
    assert foo.tqm == tqm
    assert foo.debugger_active


# Class Debugger is a Cmd class object to handle user input
# Commands that can be handled by this class is given below.
#
# q       : exit debugger
# r       : run next task
# c       : continue run until end
# p       : run current and continue
# s       : skip current and continue
# n       : skip current and run next
# pp      : print results of current task
#
# user_host is a string of user@host to run tasks

# Generated at 2022-06-11 16:43:47.880284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_args = {}
    strategy_module = StrategyModule(tqm=None)


# Generated at 2022-06-11 16:43:52.975175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    print("\nTesting StrategyModule constructor")
    print("Expected value: True\nResult: ", strategy_module.debugger_active)
    assertTrue(strategy_module.debugger_active)


# Generated at 2022-06-11 16:44:02.329352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.utils.display import Display
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    class AnsibleModuleTest(cmd.Cmd, object):
        display = Display()
        loader = None
        inventory = Inventory(loader, variable_manager=VariableManager())
        variable_manager = VariableManager()

# Generated at 2022-06-11 16:44:03.394490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None



# Generated at 2022-06-11 16:44:05.696195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

#Unit test for run method of class StrategyModule

# Generated at 2022-06-11 16:44:14.559006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    play_source =  dict(
            name = "Ad-Hoc",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    tqm = None

# Generated at 2022-06-11 16:44:16.094584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)


# Generated at 2022-06-11 16:44:20.306174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = __import__('ansible.executor.task_queue_manager').executor.task_queue_manager
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:44:20.951306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:44:23.737041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test: Create a StrategyModule
    # Expectation: id of debugger should be True
    x = StrategyModule(0)
    assert x.debugger_active == True




# Generated at 2022-06-11 16:44:37.311741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv=["", "", "-c", "local"]
    TASK_QUEUE_MANAGER = "TASK_QUEUE_MANAGER"
    assert StrategyModule(TASK_QUEUE_MANAGER)._tqm == TASK_QUEUE_MANAGER



# Generated at 2022-06-11 16:44:43.371545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nINSIDE TEST_STRATEGYMODULE")

    print(StrategyModule.__module__)

    pp = pprint.PrettyPrinter()

    class Test:
        pass

    t = Test()
    t.tqm = "tqm"
    sm = StrategyModule(t.tqm)
    pp.pprint(sm.__dict__)

    if sm.debugger_active:
        print("Test: [ PASS ]")
    else:
        print("Test: [ FAIL ]")

    print("\n")


# Generated at 2022-06-11 16:44:45.256155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm = None)
    assert isinstance(test_StrategyModule, StrategyModule)


# Generated at 2022-06-11 16:44:46.683297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:44:48.411674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0] == LinearStrategyModule


# Generated at 2022-06-11 16:44:49.682059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active


# Generated at 2022-06-11 16:44:51.417697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(tqm)
    assert st.debugger_active is True


# Generated at 2022-06-11 16:44:52.074660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:45:00.581576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Invoking test_StrategyModule class constructor")
    strategy_module = StrategyModule(tqm="tqm")
    assert "tqm" in strategy_module.__dict__
    assert "debugger_active" in strategy_module.__dict__
    assert "debugger_active" in strategy_module.__dict__
    assert strategy_module.__dict__["debugger_active"] == True
    print("test_StrategyModule class constructor successful: " + str(strategy_module.__dict__))



# Generated at 2022-06-11 16:45:04.744324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize debugger_active to False
    assert StrategyModule.debugger_active == False
    # Set debugger_active to True
    StrategyModule.debugger_active = True
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-11 16:45:22.436800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up TQM
    tqm = None
    # Instantiate class StrategyModule
    sm = StrategyModule(tqm)
    # Return
    return sm



# Generated at 2022-06-11 16:45:23.478526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != LinearStrategyModule


# Generated at 2022-06-11 16:45:25.644853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    module = StrategyModule(tqm)
    assert module.debugger_active is True


# Generated at 2022-06-11 16:45:26.780971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-11 16:45:29.972336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'something'
    cmd = StrategyModule(tqm)
    assert isinstance(cmd, StrategyModule)

# Tests for class SimpleCmd

# Generated at 2022-06-11 16:45:35.188586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.plugins.strategy.debug import StrategyModule

    class FakePlaybook:
        def __init__(self):
            self.basedir = "test"

    class FakePlay:
        def __init__(self):
            self.hosts = "test"
            self.basedir = "test"
            self.name = "test"
            self.roles = "test"
            self.vars = "test"

    class FakeTaskResult:
        def __init__(self):
            self.is_changed = "test"
            self.is_failed = "test"


# Generated at 2022-06-11 16:45:36.731307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # unit test: strategy: module: StrategyModule
  pass


# Generated at 2022-06-11 16:45:44.718369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.test.test_play_context import TEST_HOST_LIST
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    play = Play.load(dict(
        name="foobar",
        hosts="all",
        gather_facts=True,
    ), loader=None, variable_manager=VariableManager())
    task = Task.load(dict(
        name="foo",
        action=dict(
            module="setup",
        )
    ), play=play, variable_manager=VariableManager(), loader=None)
    play.add_task(task)
    play._included_roles = []
    play._handlers = []


# Generated at 2022-06-11 16:45:46.125378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    return StrategyModule(tqm)


# Generated at 2022-06-11 16:45:47.396538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(None))



# Generated at 2022-06-11 16:46:19.045360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:46:24.832999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    pp = pprint.PrettyPrinter(indent=4)

    class TestClass(StrategyModule):
        pass

    strategy = TestClass(tqm=None)

    input_data = {'debugger_active': True}
    expected_output = {'debugger_active': True}

    assert strategy.debugger_active == expected_output['debugger_active']



# Generated at 2022-06-11 16:46:31.623860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start unit test for constructor of class StrategyModule")

    # If the task queue manager is not instantiated, the constructor cannot be called.
    # So, it cannot be properly tested by unit test.
    # Each strategy's constructor must be checked by functional test.
    #
    # It is also impossible to implement the functional test for the constructor of class StrategyModule.
    # Because functional test_action.py does not create the task queue manager instance.
    # It only check whether the strategy plugin exist.
    #
    # We will check the constructor behavior after the task queue manager is instantiated.
    # So, we need to call the constructor of StrategyModule from another module.
    # The other module must be the playbook executor module which is called by test_action.py.

    print("End unit test for constructor of class StrategyModule")



# Generated at 2022-06-11 16:46:33.689889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Handler for the task

# Generated at 2022-06-11 16:46:35.900374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ok_(StrategyModule is StrategyModule)   # todo: debugging

# TODO: test following debugger functions


# Generated at 2022-06-11 16:46:40.740836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM():
        class Play():
            class Playbook():
                name = 'abc'
        inventory = 'abc'
        def __init__(self):
            self.play = TQM.Play()
    assert StrategyModule(TQM()).debugger_active == True


# Generated at 2022-06-11 16:46:42.306032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) != None


# Generated at 2022-06-11 16:46:42.902902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    

# Generated at 2022-06-11 16:46:46.530485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test')
    assert not strategy_module.is_failed
    assert not strategy_module.is_done
    assert strategy_module.debugger_active



# Generated at 2022-06-11 16:46:56.592695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.inventory
    import ansible.runner
    Options = ansible.utils.hashabledict
    options = Options()
    inventory = ansible.inventory.Inventory("x")
    variable_manager = ansible.utils.create_variable_manager("y", inventory)
    loader = ansible.utils.AnsibleLoader(None)

    tqm = ansible.playbook.TaskQueueManager(
                inventory=inventory,
                variable_manager=variable_manager,
                loader=loader,
                options=options,
                passwords=dict(),
                stdout_callback='default',
    )

# Generated at 2022-06-11 16:48:11.210169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# end of StrategyModule



# Generated at 2022-06-11 16:48:12.819711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-11 16:48:13.747588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:48:21.996562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            return

        def tearDown(self):
            return

        def test_constructor(self):
            print("Testing constructor of class StrategyModule")
            strategy_module = StrategyModule(None)
            self.assertEqual(strategy_module.debugger_active, True)

    # Test running the tests in this class
    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    return unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-11 16:48:23.644466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-11 16:48:29.846108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True
    assert strategy_module.ignore_errors == False
    assert strategy_module.original_queue == None
    assert strategy_module.success == False
    assert strategy_module.iterator == None
    assert strategy_module.tqm == None
    assert strategy_module.tqm_tasks == None



# Generated at 2022-06-11 16:48:31.578788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-11 16:48:33.029677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = { "debugger_active" : True}
    StrategyModule(tqm)


# Generated at 2022-06-11 16:48:35.029057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert(s.debugger_active == True)

# Generated at 2022-06-11 16:48:46.777991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    original_stdin = sys.stdin
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    class FakeModule:
        class FakeConnection:
            def __init__(self):
                self.transport = 'local'

        class FakeTask:
            def __init__(self, mod):
                self.module = mod

        class FakeQueue:
            def __init__(self, mod):
                self.module_name = 'shell'
                self.module_args = 'echo HELLO'
                self.module_vars = []
                self.module_kv = {}
                self.module_raw_params = None
                self.module = mod
                self.delegate_to = None
                self.register = ''
                self.no_log = False
                self.environment