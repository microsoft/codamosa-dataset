

# Generated at 2022-06-11 16:41:30.725007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        class Play(object):
            class Host(object):
                pass
            play_hosts = [Host()]

        class Host(object):
            pass

        play = Play()
        hosts = [Host()]

    tqm = TQM()

    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:41:31.732448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:41:32.705364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")



# Generated at 2022-06-11 16:41:35.727374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
	@param tqm
	"""
    # Test successful execution
    strategy_module = StrategyModule("tqm")
    assert strategyModule.debugger_active == True



# Generated at 2022-06-11 16:41:42.920996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create mock
    class MockTaskQueueManager():

        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.passwords = {}

        def get_host_list(self):
            return ['localhost']

        def get_inventory(self):
            return
    class MockInventory():
        pass

    class MockVariableManager():
        pass

    class MockLoader():
        pass


    # Create mock object
    mock_tqm_object = MockTaskQueueManager()
    mock_tqm_object.inventory = MockInventory()
    mock_tqm_object.variable_manager = MockVariableManager()
    mock_tqm_object.loader = MockLoader()

    # Create instance

# Generated at 2022-06-11 16:41:47.953165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock class TaskQueueManager
    class _TaskQueueManager:
        def __init__(self, *args, **kwargs):
            return

    tqm = _TaskQueueManager()
    sm = StrategyModule(tqm)

    assert sm.debugger_active is True, "debugger_active was not set to True"


# Generated at 2022-06-11 16:41:48.713275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:50.320767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('checking StrategyModule constructor')
    return True


# Generated at 2022-06-11 16:42:02.519763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        def __init__(self):
            self.inventory = "fake_inventory"
            self.variable_manager = "fake_variable_manager"
            self.loader = "fake_loader"
            self.shared_loader_obj = "fake_shared_loader_obj"
            self.options = "fake_options"
            self.stdout_callback = "fake_stdout_callback"
            self.stats = "fake_stats"
            self.hostvars = "fake_hostvars"
            self.filter = "fake_filter"
            self.passwords = "fake_passwords"
            self.__queue_lock = "fake__queue_lock"
            self.__current_hosts = "fake__current_hosts"
            
    tmp = StrategyModule(FakeTQM())


# Generated at 2022-06-11 16:42:05.115109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

# unit test for main body of class StrategyModule

# Generated at 2022-06-11 16:42:09.091010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    obj = StrategyModule(tqm)
    assert obj != None
    assert obj.tqm == tqm
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:42:12.476981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=0)
    if strategy.debugger_active != True:
        raise Exception("unit test failed on constructor of class StrategyModule")



# Generated at 2022-06-11 16:42:14.802752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_strategy = StrategyModule(tqm)
    assert test_strategy.debugger_active == True


# Generated at 2022-06-11 16:42:23.893612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        class TestPlayBook:
            playbook_basedir = '/ansible/playbooks/test'
        class TestHost:
            name = 'test'
        class TestTask:
            name = 'test task name'
            _role = 'test task role'
        class TestVariableManager:
            def get_vars(self, loader, path, entities):
                return None
        def __init__(self, loader, inventory, variable_manager, db_callback):
            self.loader = loader
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.db_callback = db_callback
        def get_plugin_loader(self):
            return self.loader
        def get_inventory(self):
            return self.inventory
        def get_variable_manager(self):
            return self

# Generated at 2022-06-11 16:42:25.757012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True



# Generated at 2022-06-11 16:42:27.687403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    st = StrategyModule(tqm)
    assert st.tqm == tqm
    assert st.debugger_active == True


# Generated at 2022-06-11 16:42:34.895691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    s = StrategyModule(tqm)
    assert isinstance(s.debugger_active, bool)


# Generated at 2022-06-11 16:42:37.893260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.shlex as shlex
    tm = AnsibleTaskModule(dict(action=dict(module_name="debug")))
    sm = StrategyModule(tm)
    assert sm.debugger_active is True


# Generated at 2022-06-11 16:42:43.802817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test with things that should pass
  strategy_module_should_pass = StrategyModule(object)

  # Test with things that should fail
  try:
    StrategyModule()
  except TypeError as err:
    assert(True)
  else:
    assert(False)

  try:
    StrategyModule(None)
  except TypeError as err:
    assert(True)
  else:
    assert(False)

  try:
    StrategyModule("")
  except TypeError as err:
    assert(True)
  else:
    assert(False)


# Generated at 2022-06-11 16:42:48.487777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a mock tqm to pass in
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# wrapper class around ansible iterator if result callback is enabled

# Generated at 2022-06-11 16:42:51.443109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-11 16:42:53.512757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:55.269435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-11 16:43:02.748926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm(object):
        def __init__(self):
            self.stats = dict(changed=0, failed=0, ok=0, skipped=0)
            self.hosts = ['host1', 'host2', 'host3']
    dummy_tqm = DummyTqm()
    strategyModule = StrategyModule(dummy_tqm)
    assert strategyModule.debugger_active == True
    assert strategyModule.tqm == dummy_tqm


# Generated at 2022-06-11 16:43:08.331915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    strategy_module.debugger_active = True
    assert(strategy_module.debugger_active == True)

try:
    import __builtin__ as builtins
    HAS_BUILTINS = True
except ImportError:
    HAS_BUILTINS = False


# Generated at 2022-06-11 16:43:11.147287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:43:20.967089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

#    def run(self, iterator, play_context):
#        host_list = [host for host in self._tqm._inventory.get_hosts(iterator._play.hosts) if host.name not in iterator._play.dead_hosts]
#
#        if self._tqm.options.diff and host_list:
#            return self._tqm.RUN_UNSUPPORTED_ERROR
#
#        # initialize the shared dictionary
#        self._tqm._shared_loader_obj = loader.shared_loader()
#
#        # load the vars plugin, which will be used to load the ansible vars
#        # used in the loop below
#        vars_loader = self._tqm._shared_loader_obj.get('vars', loader=self._tqm

# Generated at 2022-06-11 16:43:23.968808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    tqm = object()

    # Exercise
    strategy_module = StrategyModule(tqm)

    # Verify
    assert strategy_module.tqm == tqm



# Generated at 2022-06-11 16:43:26.236766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

    sm = StrategyModule
    assert sm.debugger_active == True

# Generated at 2022-06-11 16:43:26.865998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("testing class StrategyModule")
    print("success")



# Generated at 2022-06-11 16:43:32.656615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM: pass
    StrategyModule(TestTQM)


# Generated at 2022-06-11 16:43:35.018838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = []
    obj = StrategyModule(tqm)


# Generated at 2022-06-11 16:43:35.942635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# ------------------------------------------------------------------------------


# Generated at 2022-06-11 16:43:37.436168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:43:40.025788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s.__class__ == StrategyModule
    assert s.debugger_active == True



# Generated at 2022-06-11 16:43:41.918876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm.debugger_active == True)

    return



# Generated at 2022-06-11 16:43:43.056864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-11 16:43:46.554424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #return '<ansible.plugins.strategy.debug.StrategyModule object at 0x7f81ac1c3f50>'
    return '<ansible.plugins.strategy.debug.StrategyModule object>'


# Generated at 2022-06-11 16:43:48.554994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = dict(tqm='tqm')
    test = StrategyModule(**args)
    assert test.debugger_active == True



# Generated at 2022-06-11 16:43:52.450335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    strategy = StrategyModule(tqm)
    assert('debugger_active' in strategy.__dict__)
    assert(strategy.debugger_active == True)


# Generated at 2022-06-11 16:44:00.676549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:44:08.148027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initializing a task_queue_manager object
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=results_callback,  # Use our custom callback instead of the ``default`` callback plugin
    )

    # initializing a new strategy module
    sm = StrategyModule(tqm)
    print("Module ID of StrategyModule: ", id(sm))
    return sm


# Generated at 2022-06-11 16:44:10.486941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:44:13.213332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.values is not None
    assert StrategyModule.results is not None
    assert StrategyModule.queue_items is not None
    assert StrategyModule.debugger_active is not None



# Generated at 2022-06-11 16:44:15.783527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active is True



# Generated at 2022-06-11 16:44:20.002364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create object of class StrategyModule
    modObj = StrategyModule(None)
    # assert to check if object named StrategyModule is created
    assert modObj.debugger_active is True
    



# Generated at 2022-06-11 16:44:20.957898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    print()

# Generated at 2022-06-11 16:44:32.014875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = FakeHost()
    host.name = 'test_host'
    host.variables = dict()
    host.vars = dict()
    host.vars['ansible_connection'] = 'ssh'
    host.vars['ansible_ssh_host'] = '127.0.0.1'
    host.vars['ansible_ssh_port'] = 22
    host.vars['ansible_ssh_user'] = 'test_user'
    host.vars['ansible_ssh_private_key_file'] = 'test_private_key_file'

    host_result = dict()
    host_result['contacted'] = dict()
    host_result['contacted']['test_host'] = dict()
    host_result['contacted']['test_host']['failed'] = True


# Generated at 2022-06-11 16:44:34.592451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('tqm')
    assert isinstance(module, StrategyModule)
    assert module.debugger_active is True


# Generated at 2022-06-11 16:44:37.490014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert tqm.debugger_active == True



# Generated at 2022-06-11 16:45:05.031714
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:45:08.240841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

#

    def run(self, iterator, play_context):
        super(StrategyModule, self).run(iterator, play_context)
        self.debugger = Debugger()
        self.debugger.cmdloop()
        self.cleanup()


# Generated at 2022-06-11 16:45:10.747526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    user = "!UNKNOWN"

    sm = StrategyModule(user)

    assert sm.debugger_active == True


# Generated at 2022-06-11 16:45:12.623300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor of linear strategy with debugger')
    assert StrategyModule
    pass


# Generated at 2022-06-11 16:45:16.301649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    SM = StrategyModule(None)
    assert isinstance(SM, StrategyModule)

    # verify the StrategyModule class has inherited from the
    # LinearStrategyModule class
    assert isinstance(SM, LinearStrategyModule)


# Generated at 2022-06-11 16:45:18.148809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule(None).debugger_active)


# Generated at 2022-06-11 16:45:20.945003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        sm = StrategyModule(None)
    except:
        pass
    else:
        raise Exception('Should fail with argument None')
    sm = StrategyModule(object)
    assert sm



# Generated at 2022-06-11 16:45:26.282365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    sys.path.insert(0, "../")
    from ansible.plugins.loader import strategy_loader

    strategy = strategy_loader.get('debug', None)
    try:
        StrategyModule(None)
        unittest.TestCase().fail()
    except Exception as e:
        pass


# Generated at 2022-06-11 16:45:28.184160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit Test for constructor of class StrategyModule')


# Generated at 2022-06-11 16:45:30.513552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-11 16:46:03.260978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:46:09.151966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tasks = [{
        'name': 'local_action',
        'local_action': 'shell echo "TEST"',
        'register': 'result'
    }]
    inventory = '{"_meta": {"hostvars": {}}, "ungrouped": {"hosts": [ "localhost" ]}}'
    tqm = None
    s = StrategyModule(tqm)
    s.run(tasks, inventory)


# Generated at 2022-06-11 16:46:10.107393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass



# Generated at 2022-06-11 16:46:13.093629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = None
    strategy = StrategyModule(TASK_QUEUE_MANAGER)
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:46:13.846836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1



# Generated at 2022-06-11 16:46:15.532287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:46:17.767051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-11 16:46:20.469747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__') and callable(getattr(StrategyModule, '__init__'))



# Generated at 2022-06-11 16:46:24.741753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule constructor')
    module = StrategyModule('tqm')
    assert module.debugger_active == True, 'Actual value: %s' % module.debugger_active

# Test for constructor of class ANSIBullshitDebuggerCmd

# Generated at 2022-06-11 16:46:26.060538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True



# Generated at 2022-06-11 16:47:45.872976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=import-error
    from ansible.plugins import module_loader
    from ansible.module_utils.basic import AnsibleModule
    # pylint: enable=import-error

    module_loader.add_directory('./')
    module = AnsibleModule(argument_spec={})
    tqm = module.load_callbacks()
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy.debugger_active


# Generated at 2022-06-11 16:47:49.472914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader

    strategy = strategy_loader.get('debug', None)
    assert strategy is not None

    assert strategy._display.verbosity == 2
    assert strategy._tqm is None
    assert strategy.debugger_active == True

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:47:54.441118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils import context_objects as co
    c = PlayContext()
    co.set(task_vars=dict(a=dict(b=1)))
    sm = StrategyModule(None)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-11 16:48:00.797712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Debugger module
    debugger = StrategyModule
    assert debugger.__name__ == 'StrategyModule'
    assert debugger.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'

# Debugger class is the main class of debugger module that
# inherits cmd command mode

# Generated at 2022-06-11 16:48:01.342361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:48:02.981945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ 
    Test case 7: test constructor of class StrategyModule
    """
    assert StrategyModule()


# Generated at 2022-06-11 16:48:03.793267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True;


# Generated at 2022-06-11 16:48:04.601815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)



# Generated at 2022-06-11 16:48:05.718091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)



# Generated at 2022-06-11 16:48:07.167091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # load test
    test = StrategyModule(None)
    assert test.debugger_active


# Generated at 2022-06-11 16:50:55.003038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # assert replace_token.get_module_path('module_utils.module_common') == 'lib/ansible/module_utils/module_common.py'
  print(StrategyModule, type(StrategyModule))
  return


# Generated at 2022-06-11 16:50:58.151818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        ansible.plugins.strategy.linear.StrategyModule(None)
    except Exception as e:
        pass
    try:
        StrategyModule(None)
    except Exception as e:
        pass


# Generated at 2022-06-11 16:50:58.816828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:51:03.943059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active == True

# Run StrategyModule class
#def run(tqm):
#    strategymodule = StrategyModule(tqm)
#    strategymodule.run()


# Generated at 2022-06-11 16:51:13.278510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = None
    sm = StrategyModule(fake_tqm)
    assert sm.debugger_active == True


    def get_next_task_lockstep(self):
        '''
        This is the input loop for the interactive debugger.
        '''

        if self.debugger_active:
            self.debugger_active = self._input_loop()
        return self.next_task

    # Unit test for get_next_task_lockstep function
    def test_get_next_task_lockstep(self):
        fake_task = "fake_task"
        sm = StrategyModule(fake_tqm)
        sm.next_task = fake_task
        sm.debugger_active = False
        sm.debugger_active = True
        assert sm.get_next_task_lockstep

# Generated at 2022-06-11 16:51:14.207552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:51:18.790524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    host_list = []
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert type(sm) == StrategyModule
    assert sm.get_host_list(host_list) == []



# Generated at 2022-06-11 16:51:26.758325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self, hosts, inventory, play, variable_manager, loader, options, stdout_callback, run_additional_callbacks, run_tree,
                datastore=None, passwords={}):
            self.hosts = hosts
            self.inventory = inventory
            self.play = play
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.stdout_callback = stdout_callback
            self.run_additional_callbacks = run_additional_callbacks
            self.run_tree = run_tree
            self.datastore = datastore
            self.passwords = passwords