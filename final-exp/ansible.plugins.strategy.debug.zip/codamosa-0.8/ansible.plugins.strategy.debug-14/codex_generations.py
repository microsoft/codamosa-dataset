

# Generated at 2022-06-11 16:41:30.295386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = getattr(__import__('ansible.executor.task_queue_manager', fromlist=['TaskQueueManager']), 'TaskQueueManager')(None, None, None)
    except AttributeError:
        tqm = getattr(__import__('ansible.executor.task_queue_manager', fromlist=['TaskQueueManager']), 'TaskQueueManager')(None, None)
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-11 16:41:33.338933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    tqm = 'ansible.plugins.strategy.debug.StrategyModule(tqm)'
    print(tqm)

# Generated at 2022-06-11 16:41:36.472175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        pass

    fake_tqm = FakeTQM()
    strategy = StrategyModule(fake_tqm)
    assert strategy.debugger_active


# Generated at 2022-06-11 16:41:42.097393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ('\n::: TEST: test_StrategyModule()')

#    import ansible.plugins.strategy.debug as debug_module
#    debug_module.StrategyModule(tqm={})

    class tqm:
        def __str__(self):
            return 'tqm'

    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:41:43.527269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("")
    assert module.debugger_active


# Generated at 2022-06-11 16:41:45.780461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

StrategyModule.test_StrategyModule = test_StrategyModule



# Generated at 2022-06-11 16:41:46.721913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)



# Generated at 2022-06-11 16:41:47.838703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert(sm.debugger_active == True)


# Generated at 2022-06-11 16:41:51.257555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert LinearStrategyModule
    assert StrategyModule.__bases__[0] == LinearStrategyModule
    assert StrategyModule(1).debugger_active == True



# Generated at 2022-06-11 16:41:57.248472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def __init__(self):
            self.stats = {}
            self.inventory = None
            self.var_manager = None

    strategy_module = StrategyModule(TestTqm())
    assert strategy_module
    assert type(strategy_module) == StrategyModule



# Generated at 2022-06-11 16:41:59.242888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)



# Generated at 2022-06-11 16:42:00.306080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-11 16:42:02.306301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)



# Generated at 2022-06-11 16:42:03.763025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:06.044148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m.debugger_active == True


# Generated at 2022-06-11 16:42:15.036454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from unittest import TestCase
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils import context_objects as co
    from ansible.vars import VariableManager
    from ansible.vars import HostVars
    from ansible.host_list import Host
    from ansible.inventory import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host as InventoryHost
    from ansible.inventory.group import Group as InventoryGroup
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 16:42:17.763656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        sm = StrategyModule(None)
    except TypeError as e:
        raise
    except:
        raise



# Generated at 2022-06-11 16:42:25.198128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start Unit test of StrategyModule constructor")
    class TestTQM(object):
        def __init__(self):
            self.hostvars = dict()


    def test_strategy_module_default_value():
        sm = StrategyModule(TestTQM())

        assert sm.tqm is not None
        assert sm.display is not None
        assert sm.inventory is not None
        assert sm.variable_manager is not None
        assert sm.loader is not None
        assert sm.play is not None
        assert sm.current_play is not None
        assert sm.task_queue is not None
        assert sm.play_basedir is not None
        assert sm.shared_loader_obj is not None

    test_strategy_module_default_value()
    print("End Unit test of StrategyModule constructor")



# Generated at 2022-06-11 16:42:27.260586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """unittest for class StrategyModule"""
    strategy_instance = StrategyModule('tqm')
    assert strategy_instance.debugger_active == True


# Generated at 2022-06-11 16:42:28.493483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:36.037077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        def __init__(self):
            self.stats = {'dark': 0}
        def get_stats(self):
            return self.stats
    assert (sys.version_info < (3, 0)) == True
    TQM = TQM()
    sm = StrategyModule(tqm=TQM)

# Generated at 2022-06-11 16:42:38.095951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t1 = StrategyModule(None)
    assert t1.debugger_active == True

# Generated at 2022-06-11 16:42:39.781399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule,LinearStrategyModule)


# Generated at 2022-06-11 16:42:44.714536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(None)

    tqm.debugger_active = False
    assert tqm.debugger_active == False

    tqm.debugger_active = True
    assert tqm.debugger_active == True



# Generated at 2022-06-11 16:42:45.715671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-11 16:42:47.989890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule('test')
    assert tqm.debugger_active is True


# Generated at 2022-06-11 16:42:49.815398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:52.786483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'ansible.executor.task_queue_manager.TaskQueueManager'
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-11 16:42:54.524806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:42:57.377672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm is a empty dict
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active



# Generated at 2022-06-11 16:43:07.369921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule

    sm = StrategyModule('tqm')
    assert type(sm) == StrategyModule
    assert isinstance(sm, StrategyModule)
    assert isinstance(sm, LinearStrategyModule)
    assert sm.debugger_active == True




# Generated at 2022-06-11 16:43:08.188469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-11 16:43:11.502681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    s = StrategyModule(tqm)
    assert s.tqm == tqm
    assert s.debugger_active == True



# Generated at 2022-06-11 16:43:12.968684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == StrategyModule



# Generated at 2022-06-11 16:43:20.793430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test of constructor.")
    # An ansible_job = TaskQueueManager(private_key_file, hosts, module_name,
    #               module_args, forks, become, become_method, become_user,
    #               check, tags, skip_tags, extra_vars, subset, inventory,
    #               passwords, stdout_callback, run_additional_callbacks,
    #               run_tree)
    tqm = StrategyModule('private_key_file')
    print("    => The type of object is StrategyModule.")
    print("       %s" % sys.exc_info()[0])
    print("       Enter the class StrategyModule.")


# Generated at 2022-06-11 16:43:25.486663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        def __init__(self):
            self.timeout = 10
    test_module = StrategyModule(Tqm())
    if test_module.debugger_active == True:
        pass

StrategyModule.__init__.__test__ = False
# end - Test cases for Strategy Module


# Generated at 2022-06-11 16:43:28.375127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.name = 'TestTQM'
    assert StrategyModule(tqm()).debugger_active


# Generated at 2022-06-11 16:43:29.383710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None



# Generated at 2022-06-11 16:43:31.961864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:43:42.025219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv.insert(1, "ansible-playbook")
    sys.argv.insert(2, "debug")

# __init__() of class Debugger
    debugger = Debugger()
    debugger.intro = None

# get_host_list() of class Debugger
    hosts = debugger.tqm.host_list

# get_play() of class Debugger
    play = debugger.tqm.play

# get_play_iterator() of class Debugger
    iterator = debugger.tqm._get_play_iterator(play, hosts)

# set_play_context() of class Debugger
    debugger.tqm._set_play_context(play)

    debugger.run()



# Generated at 2022-06-11 16:43:53.436670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    SM = StrategyModule(debugger_active)
    assert SM.debugger_active
    assert SM.tqm == debugger_active
    # TODO: more test cases


# Generated at 2022-06-11 16:44:01.542072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ["ansible-playbook", "anything.yaml"]
    if len(sys.argv) != 2:
        raise Exception("ERROR: test_StrategyModule() only accepts single argument")
    filename = sys.argv[1]

    try:
        from ansible.cli import CLI
        cli = CLI(["-vvvv", "-f1", "playbook.yaml"])
        tqm = cli.cli()
    except Exception as e:
        raise e

    run_debug = StrategyModule(tqm)

    print("\nUnit Test for StrategyModule::__init__()\n")
    print("Passed")


# Generated at 2022-06-11 16:44:03.031913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__ is not None


# Generated at 2022-06-11 16:44:04.948098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object), "Module StrategyModule is not a class"


# Generated at 2022-06-11 16:44:06.872352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("ansible")
    assert sm is not None


# Generated at 2022-06-11 16:44:12.239388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class mytqm:
        def __init__(self):
            self.terminated = False
            self.failed_hosts = {}
            self.stats = {}
    t = mytqm()
    m = StrategyModule(t)
    assert isinstance(m, LinearStrategyModule)
    assert m.module_name == 'debug'
    assert m.queue_name == 'debug'



# Generated at 2022-06-11 16:44:13.309688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "Test not implemented"


# Generated at 2022-06-11 16:44:14.538752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)



# Generated at 2022-06-11 16:44:17.515128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(isinstance(s, LinearStrategyModule))
    assert(s.debugger_active)



# Generated at 2022-06-11 16:44:25.952867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import callback_loader
    from ansible.vars.reserved import DEFAULT_VAULT_ID_MATCH
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult

    host_list = ["test_host"]
    vars_dict = {}
    stdout_callback = "default"

    task_list = [{'action': {'__ansible_module__': "setup", '__ansible_arguments__': "filter='*_interfaces'"}}]

# Generated at 2022-06-11 16:44:43.947032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(object):
        def __init__(self, tqm):
            assert tqm == 'test'
    x = TestStrategyModule('test')



# Generated at 2022-06-11 16:44:45.057772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'tqm' in dir(StrategyModule())



# Generated at 2022-06-11 16:44:48.454050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    linear_strategy = StrategyModule(tqm)
    assert linear_strategy.debugger_active == True


# Generated at 2022-06-11 16:44:59.786510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTqm(object):
        class FakeHost(object):
            def __init__(
                    self, host_name, socket_path, port, connection_type,
                    become=False, become_method=None, become_user=None,
                    check=False, diff=False):
                self.host_name = host_name
                self.socket_path = socket_path
                self.port = port
                self.connection_type = connection_type
                self.become = become
                self.become_method = become_method
                self.become_user = become_user
                self.check = check
                self.diff = diff


# Generated at 2022-06-11 16:45:05.239015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context
    import ansible.playbook.task as task

    # Create StrategyModule object
    tqm = plugin_loader.get('DebugStrategy', task.Task()).load()
    assert type(tqm) == StrategyModule


# Generated at 2022-06-11 16:45:07.508619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("constructor of class StrategyModule")
    self = StrategyModule(None)
    self.debugger_active = True
    print (self.debugger_active)


# Generated at 2022-06-11 16:45:09.441643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True



# Generated at 2022-06-11 16:45:20.714995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


    class TestDebugger(cmd.Cmd):
        prompt = '(' + 'DEBUGGER' + ') : '

        def __init__(self, tqm):
            cmd.Cmd.__init__(self)
            self._setup_commands()
            self.tqm = tqm

        def emptyline(self):
            pass

        def _setup_commands(self):

            self.cmdnames = []
            for attr in dir(self):
                if not callable(getattr(self, attr)):
                    continue

                if attr[0] == '_':
                    continue

                self.cmdnames.append(attr)
                self.cmdnames.append(attr[0])

            self.cmdnames.sort()


# Generated at 2022-06-11 16:45:21.858335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-11 16:45:23.516403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:45:57.724552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "TQM"
    strategymodule = StrategyModule(tqm)
    assert strategymodule


# Generated at 2022-06-11 16:46:00.118995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)
    return True


# Generated at 2022-06-11 16:46:03.608757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == None


# Generated at 2022-06-11 16:46:12.903848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test(object):
        pass
    test.tasks = {}
    test.tasks['TASK:debug_task'] = 'TASK:debug_task'
    test.notified_handlers = []
    test.notified_handlers = ['TASK:sys_config']
    test.noop_task = 'TASK:noop_task'
    test.callback = 'TASK:callback'
    test.bb = 'TASK:bb'

    tm = StrategyModule(test)
    assert hasattr(tm, 'debugger_active')
    assert tm.debugger_active == True

    assert tm.tasks == {'TASK:debug_task': 'TASK:debug_task'}

# Generated at 2022-06-11 16:46:14.149564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("in test_StrategyModule")



# Generated at 2022-06-11 16:46:16.947683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    my_strategy_args={}
    my_StrategyModule=ansible.plugins.strategy.debug.StrategyModule(my_strategy_args)
    print(my_StrategyModule)


# Generated at 2022-06-11 16:46:20.472266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = None
    _strategy = StrategyModule(_tqm)
    assert hasattr(_strategy, 'debugger_active')
    assert _strategy.debugger_active == True


# Generated at 2022-06-11 16:46:29.638763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

#    # This emulates the behavior of __init__ function of class LinearStrategyModule.
#    # I created this function to test the constructor of class StrategyModule.
#    # tqm = TaskQueueManager()
#    # tqm._final_q = Queue()
#    # tqm._initial_q = Queue()
#    # tqm._failed_hosts = dict()
#    # tqm._stats = dict()
#    # tqm._tqm_stdout_handle = sys.stdout
#    # tqm._unreachable_hosts = dict()
#    # tqm._inventory = Inventory()
#    # tqm._variable_manager = VariableManager()
#
#    # tqm.add_host(host=Host(name='localhost'), group=

# Generated at 2022-06-11 16:46:31.650492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-11 16:46:37.849864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.task_queue_manager
    tqm = ansible.playbook.task_queue_manager.TaskQueueManager(
      inventory = '',
      variable_manager = '',
      loader = '',
      options = '',
      passwords = '',
      stdout_callback = '',
    )
    strategy = StrategyModule(tqm)
    print(strategy)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:47:57.982580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = True
    strategy_module = StrategyModule(test_tqm)

# Test for DEFAULT_OPTIMIZATION_LIST

# Generated at 2022-06-11 16:48:02.090224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start testing StrategyModule class constructor")
    try:
        sm = StrategyModule(tqm=None)
    except Exception as e:
        print("Failed to instantiate the StrategyModule class: %s" % e)
        sys.exit(1)
    print("Passed testing StrategyModule class constructor")
    return sm



# Generated at 2022-06-11 16:48:03.901914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert stm.debugger_active


# Generated at 2022-06-11 16:48:04.408655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:48:08.317735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_q = []
    play_context = {}
    worker_q = []
    result_q = []
    tqm = [task_q, play_context, worker_q, result_q]
    sm1 = StrategyModule(tqm)

    assert sm1.debugger_active == True
    assert sm1.tqm == tqm


# Generated at 2022-06-11 16:48:15.703912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    t = TaskQueueManager(
        inventory=InventoryManager(
            sources=[],
            vault_password_files=[]
        )
    )
    s = debug.StrategyModule(t)
    assert type(s) == debug.StrategyModule
    assert s.debugger_active == True


# Generated at 2022-06-11 16:48:19.886430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except:
        return False
    else:
        return True

if __name__ == '__main__':
    print("Start test")
    result = test_StrategyModule()
    print("test result: " + str(result))

# Generated at 2022-06-11 16:48:23.061014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("")
    assert obj.tqm == "" and obj.debugger_active == True


# Generated at 2022-06-11 16:48:31.286680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.password_loader = None
            self.stdout_callback = None
            self.run_additional_callbacks = None
            self.stats = None
            self.hostvars = None
    tqm = DummyTaskQueueManager()
    ret = StrategyModule(tqm)
    assert ret
    assert ret.tqm == tqm
    assert ret.debugger_active == True


# Generated at 2022-06-11 16:48:35.238433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyBase
    assert issubclass(StrategyModule, StrategyBase)
    assert issubclass(StrategyModule, cmd.Cmd)
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert not issubclass(StrategyModule, object)
