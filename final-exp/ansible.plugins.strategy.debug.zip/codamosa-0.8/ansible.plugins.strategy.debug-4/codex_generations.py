

# Generated at 2022-06-11 16:41:24.287320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s,StrategyModule)
    assert s.debugger_active == True


# Generated at 2022-06-11 16:41:30.437676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestedStrategyModule(StrategyModule):
        def get_host_list(self):
            return ['']

    tqm = object()
    sm = TestedStrategyModule(tqm)
    assert hasattr(sm, 'tqm')
    assert sm.tqm == tqm
    assert sm.host_list == ['']

# Test case for run()

# Generated at 2022-06-11 16:41:32.923385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test")
    assert strategy_module is not None
    assert strategy_module.debugger_active == True

######################################################################


# Generated at 2022-06-11 16:41:40.428269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test constructor of class StrategyModule
    :return:
    """
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
            inventory=None,
            variable_manager=None,
            loader=None,
            options=None,
            passwords=None,
            stdout_callback=None,
            run_additional_callbacks=False,
            run_tree=False,
    )

    assert tqm

    strategy_module = StrategyModule(tqm)
    assert strategy_module

    #assert strategy_module.tqm is tqm
    assert strategy_module.debugger_active



# Generated at 2022-06-11 16:41:42.948050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {}
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-11 16:41:45.267247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule("args1")
    assert m.debugger_active == True



# Generated at 2022-06-11 16:41:57.136715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ check the constructor of `StrategyModule` class """
    from ansible.utils.color import stringc
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    tokens = dict(
        connection='local',
        forks=10,
        remote_user='root',
        become='no',
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        vault_password_file=None,
        verbosity=5,
        start_at_task=None
    )

# Generated at 2022-06-11 16:42:06.359560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.handler
    import ansible.playbook.task
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    class FakePlayContext:  # Fake class for unit test of constructor of class StrategyModule
        def __init__(self):
            self.remote_addr = '127.0.0.1'
            self.port = '22'
            self.connection = 'smart'

# Generated at 2022-06-11 16:42:07.003638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:07.632036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:42:18.222932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    result = StrategyModule(tqm)
    assert result.tqm == tqm
    assert result.inventory == None
    assert result.variable_manager == None
    assert result.loader == None
    assert result._final_q == None
    assert result._blocked_hosts == set()
    assert result._cur_worker == 0
    assert result._display == None
    assert result._last_task_banner == None
    assert result._final_task_failed == False
    assert result._final_task_result == False
    assert result._final_task_banner == ''



# Generated at 2022-06-11 16:42:18.963572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:19.510927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:42:24.504865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module.tqm is None
    assert strategy_module.debugger_active == True


# This class exists in file 'plugins/strategy/linear.py', but it's tested here because
# it's overwritten in this runner.

# Generated at 2022-06-11 16:42:27.840287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

# fake class for unit test, because cmd module doesn't allow inherit.

# Generated at 2022-06-11 16:42:31.900036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = {}
    sm = StrategyModule(test_tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:34.895592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # There is no class named 'DebugStrategyModule'
    sm = StrategyModule('strategy_debug')

    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:36.941767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    "Test StrategyModule constructor"
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-11 16:42:41.621328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if 'StrategyModule' not in globals():
        print("Cannot find class StrategyModule. No test would be executed")
        return
    ansible = Ansible()
    tqm = TaskQueueManager(ansible=ansible)
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)


# Generated at 2022-06-11 16:42:44.173081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)
    except:
        assert False, "failed to initialize StrategyModule"
    


# Generated at 2022-06-11 16:42:49.310131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Test(None, None, None, None)
    assert LinearStrategyModule(tqm)


# Generated at 2022-06-11 16:42:51.030204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # make sure we are actually testing something
    #assert True


# Generated at 2022-06-11 16:42:51.710564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:54.448529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     tqm = """Dummy Task Queue Manager"""
     s = StrategyModule(tqm)
     assert s != None

# AnsibleDebugger class
# The class is derived from cmd.Cmd class

# Generated at 2022-06-11 16:42:57.292109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    #print(strategy_module)
    assert strategy_module.debugger_active

StrategyModule.test_StrategyModule = test_StrategyModule


# Generated at 2022-06-11 16:42:59.849216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:43:04.112524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


    print("Unit test for class StrategyModule passed")


# Generated at 2022-06-11 16:43:07.746023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_strategy_module = StrategyModule(None)
    assert isinstance(obj_strategy_module, StrategyModule)
    assert obj_strategy_module.debugger_active == True



# Generated at 2022-06-11 16:43:19.126555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    # mock TaskQueueManager
    class TaskQueueManager:
        def __init__(self):
            self.created = True

    class TestStrategyModule(unittest.TestCase):
        # test constructor
        def test_init(self):
            tqm = TaskQueueManager()
            strategy = StrategyModule(tqm)
            self.assertEqual(isinstance(strategy, LinearStrategyModule), True)
            self.assertEqual(strategy.debugger_active, True)
            self.assertEqual(strategy.tqm, tqm)

    # execute unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest

# Generated at 2022-06-11 16:43:20.273486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # TODO: Add unit test code



# Generated at 2022-06-11 16:43:24.661109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:43:25.252034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:43:28.154142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except:
        assert False


# End of Unit test for StrategyModule


# Generated at 2022-06-11 16:43:30.190440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass:
        def __init__(self):
            pass

    _ = StrategyModule(TestClass())

# Generated at 2022-06-11 16:43:30.781326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:43:32.008851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-11 16:43:34.544734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor Test StrategyModule')
    # Dummy Test
    obj = StrategyModule('tqm')
    if obj.debugger_active == True:
        print('Debugger is active')
    else:
        print('Debugger is not active')

# Function that returns a debugger object

# Generated at 2022-06-11 16:43:43.654791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    result = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_additional_callbacks=True, run_tree=False)

    #Test constructor
    debugStrategyModule = StrategyModule(tqm=result)
    assert isinstance(debugStrategyModule, StrategyModule) is True
    assert isinstance(debugStrategyModule, LinearStrategyModule) is True
    assert debugStrategyModule.tqm is result
    assert debugStrategyModule.debugger_active is True



# Generated at 2022-06-11 16:43:47.016132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule() should not have any error
    tqm = object()
    sm = StrategyModule(tqm)
    assert tqm == sm.tqm
    assert True == sm.debugger_active


# Generated at 2022-06-11 16:43:49.615178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

    # tqm = TaskQueueManager()
    # strategy = StrategyModule(tqm)
    # assert_true(strategy.debugger_active)


# Generated at 2022-06-11 16:44:09.340505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    for fmt in ('xml', 'json', 'yaml'):
        try:
            execute_path = self.get_bin_path('ansible-playbook', False)
        except:
            continue
        cmd = [execute_path, '--syntax-check', '--list-hosts', '--inventory-file=%s' % self.playbook.host_list, self.playbook.playbook_file]
        if fmt != 'json':
            cmd.append('--list-tasks')
            cmd.append('--list-tags')
            cmd.append('--list-hosts')
            cmd.append('--list-groups')
            cmd.append('--list-all')

# Generated at 2022-06-11 16:44:13.749183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create fake TaskQueueManager
    class FakeTaskQueueManager():
        def __init__(self):
            self.options = {}
            self.stats = {}
    tqm = FakeTaskQueueManager()

    # Do constructor of class StrategyModule
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:44:17.619705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm={})
    assert type(result) == StrategyModule
    assert result.tqm == {}
    assert result.debugger_active == True


# Generated at 2022-06-11 16:44:21.093975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        my_strategy_module = StrategyModule(0)
        assert type(my_strategy_module) == StrategyModule
    except Exception:
        raise
    else:
        assert True



# Generated at 2022-06-11 16:44:21.994653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule("tqm")
    assert p.debugger_active == True



# Generated at 2022-06-11 16:44:24.131636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: pass the test.
    s = StrategyModule(None)
    assert s.debugger_active


# Generated at 2022-06-11 16:44:25.994720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-11 16:44:29.259383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    sm = StrategyModule(None)
    assert not sm.debugger_active
    assert sm.get_host_list() == sm.get_host_list()



# Generated at 2022-06-11 16:44:32.931908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None, "module import failed"
    strategy_module_instance = StrategyModule()
    assert strategy_module_instance.debugger_active is True, "incorrect value for variable 'debugger_active'"



# Generated at 2022-06-11 16:44:35.290027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    m = StrategyModule(tqm)
    assert m.debugger_active


# Generated at 2022-06-11 16:44:52.173086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass



# Generated at 2022-06-11 16:44:54.215019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test creating an instance of class StrategyModule
    # No exception should be submitted
    assert True


# Generated at 2022-06-11 16:44:56.994290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nTest StrategyModule\n")
    module = StrategyModule(None)
    assert module.debugger_active == True


# Generated at 2022-06-11 16:44:58.119009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:45:07.981451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
        
    #    self.display.debug("entering debug mode")
    #    self._tqm.send_callback('v2_playbook_on_start')
    #    self._tqm._stats.reset_aggregate()
    #    self.set_host_lists()
    #    self.last_task_banner = None
    #    self.debugger = Debugger(self._tqm)
    #    self._tqm.send_callback('v2_playbook_on_notify')
    #    self.debugger.interact()
    #    self._tqm.send_callback('v2_playbook_on_stats')
    #    return True



# Generated at 2022-06-11 16:45:10.113047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.debugger_active



# Generated at 2022-06-11 16:45:10.700720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:45:12.554853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    print("Nothing to test.")

# Generated at 2022-06-11 16:45:15.514870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    module = StrategyModule(tqm)
    assert module.tqm == tqm
    assert module.debugger_active


# Generated at 2022-06-11 16:45:17.828580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Task execution is controlled by an interactive debug session

# Generated at 2022-06-11 16:45:50.884838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:45:52.177481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-11 16:45:56.771847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert len(sm.step_plays) == 0
    assert sm.debugger_active is True


# Generated at 2022-06-11 16:45:57.920190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:46:02.032352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ans_plugin_strat = StrategyModule(None)
    assert(ans_plugin_strat.__class__.__name__ == 'StrategyModule')
    assert(ans_plugin_strat.debugger_active == True)

# Unit test to test the run function

# Generated at 2022-06-11 16:46:03.262280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule(1)


# Generated at 2022-06-11 16:46:04.923778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    StrategyModule(tqm)


# Generated at 2022-06-11 16:46:07.957957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create class instance
    strategy_mod = StrategyModule(None)

    # check status of class variables
    assert strategy_mod.tqm == None
    assert strategy_mod.debugger_active == True



# Generated at 2022-06-11 16:46:11.193052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Just instantiate class
    # AnsibleError has super class of Exception, so just call constructor
    StrategyModule()


# Generated at 2022-06-11 16:46:13.176433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # This is not possible to test
        StrategyModule(None)
    except:
        pass # This is not possible to test


# Generated at 2022-06-11 16:47:36.825087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert isinstance(StrategyModule, type)
    assert not StrategyModule.__init__.__doc__
    assert len(StrategyModule.__doc__) > 0
#
#   def get_hosts(self, pattern):
#       ''' Wraps get_hosts in order to activate interactive debugging for
#           specified hosts if required.
#       '''
#       hosts = super(StrategyModule, self).get_hosts(pattern)
#       if self.debugger_active:
#           for host in hosts:
#               host.vars['ansible_become_pass'] = True
#       return hosts


# Generated at 2022-06-11 16:47:47.005353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.stats = {}
    tqm_ = tqm()
    tqm_.stats = {'hosts': {'localhost': {'changed': 0}}}
    c = StrategyModule(tqm_)
    assert c.debugger_active == True
    assert c.tqm == tqm_
    assert c._tqm == tqm_._tqm
    assert c.display is None
    assert c.loop is None
    assert c.inventory is None
    assert c.loader is None
    assert c.vars is None
    assert c.strat_var is None
    assert c.module_name == 'debug'
    assert c.module_args is None
    assert c.hosts is None
    assert c.all_

# Generated at 2022-06-11 16:47:50.477561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active is True
    assert strategy.tqm is tqm
    assert strategy.failed_hosts.get_failed_hosts() == []
    assert strategy.get_host_list() == []

# Test for method 'run' of class StrategyModule

# Generated at 2022-06-11 16:47:55.020628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        pass
    tqm = DummyTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm is tqm
    assert strategy_module.debugger_active


    # Unit test for subclass Debugger

# Generated at 2022-06-11 16:47:55.849472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-11 16:47:58.028791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:47:58.962319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:48:01.008584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = mock.MagicMock()

    module = StrategyModule(tqm)

    assert module.debugger_active == True



# Generated at 2022-06-11 16:48:06.088387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
        run_additional_callbacks=None,
        run_tree=False,
    )
    sm = StrategyModule(tqm)
    return sm


# Generated at 2022-06-11 16:48:07.162234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active is True


# Generated at 2022-06-11 16:50:57.213642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:51:02.361042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Create a task queue manager.
        tqm = TaskQueueManager(
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader,
            passwords=passwords,
            stdout_callback=results_callback,
        )
        
        # Create a strategy module object.
        sm = StrategyModule(tqm)
        # Check whether the created object is an instance of the class StrategyModule.
        assert isinstance(sm, StrategyModule)
        # Check whether the attribute debugger_active of the created object is True.
        assert sm.debugger_active == True
    except:
        assert False


# Generated at 2022-06-11 16:51:06.918496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True
    assert isinstance(strategy.runner, MockRunner) == True



# Generated at 2022-06-11 16:51:12.613087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(LinearStrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
            self.debugger_active = True
    modulename = "debug"
    sys.argv = ['ansible-debug', '-f', '1', '--module-path', '/home/user/ansible-dir/lib/ansible/modules']
    tqm = TestStrategyModule
    StrategyModule(tqm)


# Generated at 2022-06-11 16:51:16.941883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print('test_StrategyModule')
  l_tqm = object()
  strategy_module = StrategyModule(l_tqm)
  assert strategy_module.tqm == l_tqm



# Generated at 2022-06-11 16:51:18.434213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("This is a test.")



# Generated at 2022-06-11 16:51:25.825280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm('test_StrategyModule'))
    assert bool(mod.debugger_active)
    assert bool(mod.tqm)
    assert bool(mod.hosts)
    assert bool(mod.results)
    assert bool(mod.callbacks)
    assert bool(mod.default_vars)
    assert bool(mod.iterator)
    assert bool(mod.notified_handlers)
    assert bool(mod.notified_handler_results)
    assert bool(mod.notified_handler_interrupts)
    assert bool(mod.worker_callbacks)
    assert bool(mod.display)

