

# Generated at 2022-06-11 16:41:30.533890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.queue_name == 'debug_task'
    assert strategy_module.run_once == True
    assert strategy_module.display.verbosity == 2


# Generated at 2022-06-11 16:41:31.964218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule(tqm = None)



# Generated at 2022-06-11 16:41:33.383334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert strategy_module


# Generated at 2022-06-11 16:41:35.309912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestStrategyModule()
    TestStrategyModule.__init__(tqm)


# Generated at 2022-06-11 16:41:36.995890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:41:40.830290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Not sure how to test this, just make sure no exceptions occur
        tqm = None
        StrategyModule(tqm)
    except Exception as e:
        assert(False)

    assert(True)


# Generated at 2022-06-11 16:41:41.776200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:41:44.787894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(type(strategy_module))
    print(strategy_module.ThreadQueueManager_instance)
    print(strategy_module.debugger_active)


# Generated at 2022-06-11 16:41:46.298771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: dummy test
    assert StrategyModule is not None


# Generated at 2022-06-11 16:41:48.141617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def __init__(self):
            self.stats = {}
    sm = StrategyModule(FakeTQM())

# inherit from cmd.Cmd

# Generated at 2022-06-11 16:41:50.702111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

'''
Debugger class
'''

# Generated at 2022-06-11 16:41:54.785049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager

    except ImportError:
        print("Cannot simulate module due to import errors.  Must run under ansible for actual unit test.")
        sys.exit(0)

    # Create a PlayContext
    play_context = PlayContext()

    # Create a Play

# Generated at 2022-06-11 16:41:55.454147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:58.753133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None  # mock
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:06.941218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        def __init__(self, host_list, module_name='debug', forks=10, timeout=None, inventory=None, no_log=False,
                     passwords=dict(), stdout_callback=None, run_tree=False):
            self.host_list = host_list
            self.module_name = module_name
            self.forks = forks
            self.timeout = timeout
            self.inventory = inventory
            self.no_log = no_log
            self.passwords = passwords
            self.stdout_callback = stdout_callback
            self.run_tree = run_tree
#

    # test initialization
    fake_tqm = FakeTQM(['localhost'])
    tqm = LinearStrategyModule(fake_tqm)


# Generated at 2022-06-11 16:42:07.579424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:08.164903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:19.830133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    loader = strategy_loader
    tqm = 'debug'
    strategy_module = StrategyModule(tqm)
    assert 'StrategyModule' == strategy_module.__class__.__name__
    # Unit test for method adopt_to_individual_host()
    loader_module_path = "ansible.plugins.loader"
    strategy_module_path = "ansible.plugins.strategy.debug"
    strategy_module_classname = "DebugStrategy"
    strategy_module_path_name = "debug_strategy"
    test_strategy_module = strategy_module.__class__.adopt_to_individual_host(loader_module_path, strategy_module_path, strategy_module_classname, strategy_module_path_name)
    assert test_

# Generated at 2022-06-11 16:42:21.175309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-11 16:42:23.201064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    assert StrategyModule(tqm).tqm == tqm


# Generated at 2022-06-11 16:42:33.825821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTqm()
    tqm.hostvars = {
        'host1': {'host': 'host1'},
        'host2': {'host': 'host2'},
        'host3': {'host': 'host3'}
        }
    strategy = StrategyModule(tqm)
    assert(strategy.debugger_active)
    assert(strategy.tqm == tqm)
    result = strategy.print_via_ansible_debug(tqm, "hello")
    assert (result == None)


# Generated at 2022-06-11 16:42:35.223445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('StrategyModule()')
    m = StrategyModule(None)


# Generated at 2022-06-11 16:42:37.587927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n' + '=' * 60)
    print('Unit test for constructor of class StrategyModule')
    StrategyModule.__init__(None)
    print('Pass')


# Generated at 2022-06-11 16:42:42.506960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def FakeCMD():
        # to avoid argparse error due to missing argv[0]
        sys.argv.insert(0, '')
        cmd.Cmd.__init__(self)

    tqm = FakeTQM()
    sm = StrategyModule(tqm)
    assert isinstance(sm.debugger_active, bool)
    assert sm.debugger_active



# Generated at 2022-06-11 16:42:44.382696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active


# Generated at 2022-06-11 16:42:45.715230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm).debugger_active == True




# Generated at 2022-06-11 16:42:52.376408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    sys.argv[1:] = ['somehost']
    tqm = TaskQueueManager(inventory=None)
    assert isinstance(tqm, TaskQueueManager)
    assert isinstance(StrategyModule(tqm), StrategyModule)
    tqm.cleanup()
    tqm = None

# Interactive shell

# Generated at 2022-06-11 16:42:54.053893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an object and do something with it
    debug = StrategyModule(tqm=None)
    assert debug.debugger_active == True


# Generated at 2022-06-11 16:42:57.700503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        pp = pprint.PrettyPrinter(indent=4)
        sm = StrategyModule()
        pp.pprint(vars(sm))
    except Exception as e:
        print(e)
        sys.exit(1)


# Generated at 2022-06-11 16:43:00.635703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type("TestType", (object,), {"_terminated": False })
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-11 16:43:08.681021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dummy_tqm = None
    test_instance = StrategyModule(dummy_tqm)

    assert isinstance(test_instance, StrategyModule)
    assert isinstance(test_instance, LinearStrategyModule)
    assert test_instance.debugger_active == True

# Generated at 2022-06-11 16:43:15.928047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule")
    print("    def __init__(self, tqm):")
    print("        super(StrategyModule, self).__init__(tqm)")
    print("        self.debugger_active = True")
    print()


    print("tqm: " + tqm.get_name())

    StrategyModule(tqm)


#- end of test_StrategyModule()



# Generated at 2022-06-11 16:43:19.126058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '' # dummy value for constructor of class StrategyModule
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active # must true
    assert strategy._tqm is tqm # _tqm is set in constructor


# Generated at 2022-06-11 16:43:19.629067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:43:21.204250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cm = StrategyModule(tqm=None)
    assert cm.debugger_active


# Generated at 2022-06-11 16:43:26.293678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM():
        def __init__(self):
            self.stats = dict()
            self.host_list = [
                {'name': 'localhost'}
            ]

    mock_tqm = MockTQM()
    obj = StrategyModule(mock_tqm)
    assert obj.debugger_active is True


# Generated at 2022-06-11 16:43:30.925329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    s = StrategyModule(tqm)
    assert s.debugger_active is True
    assert s.hosts == s.inventory.get_hosts()
    assert s is not None

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 16:43:39.075408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a fake task queue manager for testing
    class FakeTQM:
        def __init__(self):
            self.hostvars = dict()

    tqm = FakeTQM()

    # Create an instance of the class StrategyModule for testing
    strategy_module = StrategyModule(tqm)

    # Check that the saved attributes are correct
    assert(strategy_module.tqm == tqm)
    assert(strategy_module.tqm.hostvars == dict())
    assert(strategy_module.debugger_active == True)



# Generated at 2022-06-11 16:43:40.567630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)


# Generated at 2022-06-11 16:43:41.180201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:44:00.170990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os
    import json

    class TestCase(unittest.TestCase):
        def setUp(self):
            # Ansible config
            os.environ['ANSIBLE_CONFIG'] = 'test/ansible.cfg'

# Generated at 2022-06-11 16:44:01.564105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:44:11.138359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    tqm = mock.Mock()
    strategy = StrategyModule(tqm)
    assert not strategy.done
    assert strategy.debugger_active
    assert tqm == strategy.tqm
    tqm.hostvars = {'dummy_host' : {}}
    tqm.hostvars['dummy_host']['ansible_facts'] = {'dummy_key' : 'dummy_value'}
    tqm.hostvars['dummy_host']['dummy_var'] = 'dummy_value'


# Generated at 2022-06-11 16:44:22.502639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    import ansible.constants
    import six
    import random
    import os
    import json

    def _get_host_name():
        return 'hostname{}'.format(random.randint(0,1000))


# Generated at 2022-06-11 16:44:27.678283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.task
    task = ansible.playbook.task.Task()
    test_tqm = object()
    sm = StrategyModule(test_tqm)
    assert sm._tqm == test_tqm


# Generated at 2022-06-11 16:44:33.052469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        def __init__(self):
            self.stats = {}
    # TQM object is needed to create StrategyModule object
    tqm = TQM()
    strategy = StrategyModule(tqm)
    # Test that StrategyModule object is created
    assert strategy

    # Test that debugger_active is set to True
    assert strategy.debugger_active

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:44:38.128626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Notify instance tqm is initialized as a flag to indicate that it is not empty or nil.
    tqm = True
    strategyModule = StrategyModule(tqm)
    assert strategyModule.tqm == True
    assert strategyModule.debugger_active == True



# Generated at 2022-06-11 16:44:41.335828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.tqm is None
    assert strategy_module.debugger_active
    assert strategy_module.debugger_state is None
    assert strategy_module.debugger_result is None



# Generated at 2022-06-11 16:44:42.663128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Execute StrategyModule")



# Generated at 2022-06-11 16:44:44.709797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "something"
    res = StrategyModule(tqm)
    assert res.debugger_active == True


# Generated at 2022-06-11 16:45:08.560868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a fake instance of the Ansible Task Queue Manager
    class FakeClass1:
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.passwords = None
            self.stdout_callback = None
            self.run_tree = None
            self.stats = None
            self.hostvars = {}
    tqm1 = FakeClass1()

    sm = StrategyModule(tqm1)
    assert sm.play is None
    assert sm.debugger_active



# Generated at 2022-06-11 16:45:11.550350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("test")
    assert sm.debugger_active

# Note: Use of globals is required as this function is called from the debugger (see next function)

# Generated at 2022-06-11 16:45:14.401272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TODO: mock tqm
    tqm = ()
    sm = StrategyModule(tqm)
    return sm



# Generated at 2022-06-11 16:45:15.436504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-11 16:45:21.339501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    # A TaskQueueManager object is needed to instantiate a StrategyModule object.
    TaskQueueManager = namedtuple('TaskQueueManager', ['stats'])
    tqm = TaskQueueManager(stats = namedtuple('stats', ['tasks', 'dark', 'failures', 'ok', 'processed']))
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:45:27.062918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.playbook.play import Play
        from ansible.playbook.task import Task
        from ansible.playbook.handler import Handler
        from ansible.inventory.host import Host
        from ansible.inventory.group import Group
        from ansible.vars.manager import VariableManager
        from ansible.plugins.loader import lookup_loader
        from ansible.executor import task_queue_manager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.parsing.vault import VaultLib
        pass
    except ImportError as e:
        print('ImportError: ' + str(e))
        exit(1)

    play_source_name = 'test_data/debug_play_source.yml'

   

# Generated at 2022-06-11 16:45:28.362466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()



# Generated at 2022-06-11 16:45:31.645109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info[0] < 3:
        x = StrategyModule('tqm')
    else:
        x = StrategyModule(6)



# Generated at 2022-06-11 16:45:32.705550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:45:35.903113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return {'stdout': 'Execution mode is debug'}

    ##########
    # std_in #
    ##########



# Generated at 2022-06-11 16:46:10.106685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-11 16:46:11.283957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:46:21.864429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TQM:
        def __init__(self):
            self.hostvars = None
            self.play = None
            self.callbacks = None
            self.stats = None
            self.inventory = None
            self.failed_hosts = None
            self.done = None
            self.skipped_hosts = None
            self.unreachable_hosts = None
            self.all_vars = None
            self.extra_vars = None
            self.options = None
            self.variable_manager = None
            self.passwords = None
            self.loader = None

    class Callbacks:
        def __init__(self):
            self.on_any = None
            self.on_setup = None
            self.on_import_for_host = None
            self.on_not_import

# Generated at 2022-06-11 16:46:27.813424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from nose import SkipTest
        raise SkipTest()
    except ImportError:
        pass

    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None)
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm.debugger_active


# Generated at 2022-06-11 16:46:38.290998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader
    import ansible.utils.plugin_docs as plugin_docs
    module = ansible.plugins.loader.strategy_loader.get('debug', sys.modules[__name__])
    print('\n\nTesting Debug Strategy Module')
    print('=============================')
    print('Type  : ', type(module))
    print('Name  : ', module.__name__)
    print('Doc   : ', module.__doc__)
    print('Available methods:')
    plugin_docs.print_methods(module)
    print('Available classes:')
    plugin_docs.print_classes(module)
    print('Method __init__:')
    plugin_docs.print_method_args(module, '__init__')
    print('\n\n')


# Generated at 2022-06-11 16:46:39.262182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Debugger

# Generated at 2022-06-11 16:46:40.593496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Use this debugger when you want to debug in an importable function

# Generated at 2022-06-11 16:46:42.518031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj.debugger_active == True


# Generated at 2022-06-11 16:46:43.483573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # We should not fail
    StrategyModule()



# Generated at 2022-06-11 16:46:47.717748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.plugin_docs as plugin_docs
    s = StrategyModule(plugin_docs.get_tqm(None, None, None, None, None, './', None, None, None, None, None, None))
    return s


# Generated at 2022-06-11 16:48:07.051788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:48:08.745088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-11 16:48:10.827402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module.debugger_active is True


# Generated at 2022-06-11 16:48:11.845709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-11 16:48:14.045263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(1)
    assert(strategymodule.debugger_active)


# Generated at 2022-06-11 16:48:22.826952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n")
    print("Test StrategyModule")
    print("-------------------")

    import ast
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader, strategy_loader


# Generated at 2022-06-11 16:48:26.159665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    reload(ansible.plugins.strategy.debug)
    from ansible.plugins.strategy.debug import StrategyModule

    assert issubclass(StrategyModule, LinearStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'

    # Todo: Add test code here

if __name__ == "__main__":
    # Todo: Remove following code and add actual test code
    strategy_module = StrategyModule("test")
    sys.exit(0)

# Generated at 2022-06-11 16:48:29.436595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor of class StrategyModule')
    try:
        StrategyModule(None)
    except NameError as e:
        print('## Exception', e)


# Generated at 2022-06-11 16:48:33.140512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    debugger = StrategyModule(tqm)
    assert debugger.debugger_active == True, "StrategyModule constructor test 1 failed"
    assert debugger.current_task_index == 0, "StrategyModule constructor test 2 failed"
    assert debugger.tqm == tqm, "StrategyModule constructor test 3 failed"



# Generated at 2022-06-11 16:48:35.030406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)

    assert s.debugger_active == True

