

# Generated at 2022-06-11 16:41:28.425427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("Test")
    assert strategy_module.tqm == "Test"
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:41:30.438310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active is True


# Generated at 2022-06-11 16:41:31.432781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:41:33.454370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class T(object):
        pass
    tqm = T()
    tqm.load_callbacks_for_plugins = print
    tqm.send_callback = print
    tqm.stats = print
    tqm.terminated = False
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True
    assert sm.hosts_left is None
    assert sm.task_queue is None


# Generated at 2022-06-11 16:41:41.694413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from .debugger import Debugger

    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Interactive debug sessions."
    assert StrategyModule.__module__ == "ansible.plugins.strategy.debug"

    # Debugger inherits StrategyModule, so we only unit test StrategyModule
    strategy_module = StrategyModule(None)
    assert strategy_module.tqm is None
    assert strategy_module.host_states == dict()
    assert strategy_module.debugger_active is True
    assert strategy_module.get_host_state.__name__ == "get_host_state"
    assert strategy_module.get_host_state.__doc__ == "return dict containing loop state for hosts"

# Generated at 2022-06-11 16:41:46.031255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert(obj.debugger_active == True and isinstance(obj, StrategyModule))
    print(obj.__doc__)
    print(obj.__init__.__doc__)
    print(obj.run.__doc__)


# Generated at 2022-06-11 16:41:46.750629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(TQM())


# Generated at 2022-06-11 16:41:48.045883
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:41:51.930198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    test_object = StrategyModule(tqm)
    assert test_object
    assert test_object.tqm == tqm
    assert test_object.debugger_active == True


# Generated at 2022-06-11 16:41:58.200434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global DEBUGGER_ACTIVE

    class TestTqm:
        @staticmethod
        def get_host_list():
            pass

        @staticmethod
        def get_inventory():
            pass
    #    global DEBUGGER_ACTIVE

    tsm = StrategyModule(TestTqm)
    assert tsm.debugger_active == True


# Generated at 2022-06-11 16:41:59.449629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:42:04.086444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as module

    # Test result with debug flag is false
    _tqm = None
    _play = None
    _iterator = None
    _all_vars = None
    _options = None
    _variables = None

    strategy = module.StrategyModule(_tqm)
    assert strategy.debugger_active == False



# Generated at 2022-06-11 16:42:05.946463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# End unit test for constructor of class StrategyModule


# Generated at 2022-06-11 16:42:08.335160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    assert(ansible.plugins.strategy.debug.StrategyModule)


# Generated at 2022-06-11 16:42:12.122838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # check whether the class was initialised with the right parameters
    #assert StrategyModule.__init__(self, 42) == "I am 42."


# Generated at 2022-06-11 16:42:13.063449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active



# Generated at 2022-06-11 16:42:18.436461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager():
        def get_host_list(self):
            return
        def get_vars(self):
            return
        def add_host(self, host):
            return
        def add_group(self, group):
            return
        def add_task(self, task):
            return
        def get_final_qty(self):
            return
        def get_failed_hosts(self):
            return
        def get_failed_hosts(self):
            return
        def get_variable_manager(self):
            return
    tqm = TestTaskQueueManager()
    ds = StrategyModule(tqm)



# Generated at 2022-06-11 16:42:21.607454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        stats = {}
    tqm = TestTQM()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active is True


# Generated at 2022-06-11 16:42:23.683270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm.debugger_active == True)


# Generated at 2022-06-11 16:42:32.867739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with empty tqm
    try:
        StrategyModule([])
    except:
        assert False
    # Test with one element tqm

# Generated at 2022-06-11 16:42:36.438992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)
    assert not StrategyModule.__init__.__doc__



# Generated at 2022-06-11 16:42:36.941438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:42:40.723350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test.debugger_active == True

# `debug` function is defined in ./plugins/action/debug.py
# Please see function definition of `debug` function of `ActionModule`.

# Generated at 2022-06-11 16:42:43.575980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(None)
    assert result.debugger_active == True
    assert result.tqm == None


# Generated at 2022-06-11 16:42:44.617486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None




# Generated at 2022-06-11 16:42:46.429184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-11 16:42:49.510366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTaskQueueManager(object):
        pass
    sm = StrategyModule(FakeTaskQueueManager())
    assert sm.debugger_active


# Generated at 2022-06-11 16:42:54.193666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    print('\n===== test StrategyModule.__init__ =====')
    print('test StrategyModule.__init__: debugger_active =', \
            strategy_module.debugger_active)
    print('===== end test StrategyModule.__init__ =====\n')


# Generated at 2022-06-11 16:42:56.681736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = StrategyModule.debugger_active

    if debugger_active:
        print("Test passed")

# Class Debugger inherits cmd.Cmd

# Generated at 2022-06-11 16:42:57.700419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')


# Generated at 2022-06-11 16:43:03.158133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:43:05.133997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = 'mock_tqm'
    test_subject = StrategyModule(mock_tqm)
    assert test_subject is not None
    assert test_subject.tqm == mock_tqm
    assert test_subject.debugger_active == True
    assert isinstance(test_subject.tqm, object) == True

test_StrategyModule()



# Generated at 2022-06-11 16:43:06.421575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-11 16:43:09.941210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Assuming tqm is TaskQueueManager instance,
    instance of StrategyModule should be created with tqm.
    """
    class TaskQueueManager:
        pass
    tqm = TaskQueueManager()
    strategy_instance = StrategyModule(tqm)


# Generated at 2022-06-11 16:43:17.128170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test copy operator
    tqm_dict1 = {}
    tqm1 = StrategyModule(**tqm_dict1)
    tqm_dict1 = tqm1.__dict__
    tqm2 = StrategyModule(**tqm_dict1)

    assert tqm1.__dict__ == tqm2.__dict__, 'Equal of tqm1 and tqm2 is not true.'

# Generated at 2022-06-11 16:43:19.548795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mydebugger = StrategyModule(None)
    assert isinstance(mydebugger.debugger_active, bool)
    assert mydebugger.debugger_active == True


# Generated at 2022-06-11 16:43:30.096878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    pb = Playbook()
    play_src =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    pb.set_variable_manager(VariableManager())
    play = Play().load(play_src, variable_manager=pb.variable_manager, loader=pb._loader)

# Generated at 2022-06-11 16:43:32.659407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ans_inst = Ansible()
    strategy = StrategyModule(ans_inst)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:43:34.176869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1
    test1 = StrategyModule(None)
    assert test1.debugger_active == True


# Generated at 2022-06-11 16:43:44.937834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


        #self._tqm.send_callback(u'v2_playbook_on_start')

        #self._tqm._unreachable_hosts.update(host_list)
        #self._tqm.send_callback('v2_playbook_on_stats', self._tqm._stats)

        #if len(self._tqm._unreachable_hosts) > 0:
            #self._tqm.send_callback('v2_playbook_on_unreachable', self._tqm._unreachable_hosts)



    def run(self):
        ''' run the task sequence in linear mode '''


# Generated at 2022-06-11 16:43:55.205353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-11 16:43:56.567604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)



# Generated at 2022-06-11 16:43:57.676128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:43:59.166656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-11 16:44:10.752041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test task queue manager with a single host 'host' to for testing
    from ansible.playbook.play_context import PlayContext
    import ansible.inventory.host as ansible_host

    tqm = TestTaskQueueManager()
    tqm._initialize_processes(2)
    tqm.inventory._hosts_cache = {
        'host': ansible_host.Host('localhost',
                                  port=22,
                                  variables={'foo': 'bar'},
                                  groups=[
                                      ansible_host.Group('all'),
                                      ansible_host.Group('ungrouped')
                                  ],
                                  )
    }

# Generated at 2022-06-11 16:44:12.324729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # Test body;
    #assertEqual(expVal, actVal)



# Generated at 2022-06-11 16:44:14.491327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-11 16:44:19.076967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
        exit(1) # FAILED
    except Exception as e:
        print("Failed: " + str(e))
        exit(0) # OK


# Generated at 2022-06-11 16:44:19.692915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-11 16:44:21.516431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    if StrategyModule is None:
        import ansible.plugins.strategy.debug as StrategyModule
    StrategyModule(None)


# Generated at 2022-06-11 16:44:42.023153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    sm = StrategyModule(test_tqm)
    if sm.tqm != test_tqm:
        raise AssertionError("StrategyModule(tqm) is not setting tqm correctly")
    try:
        sm.debugger_active
    except AttributeError:
        raise AssertionError("StrategyModule(tqm) is not setting debugger_active correctly")



# Generated at 2022-06-11 16:44:43.235178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    # should be tested here



# Generated at 2022-06-11 16:44:44.869282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm='tqm')
    assert s.debugger_active


# Generated at 2022-06-11 16:44:45.819715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:44:47.162399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement test
    pass


# Generated at 2022-06-11 16:44:58.517411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', '--verbose', '--inventory', 'hosts', 'linuxtest.yml', '-c', 'debug']
    import ansible.utils.module_docs as mod_docs
    mod_docs.get_docstring = lambda x: x
    import ansible.playbook.play_context as play_context
    play_context.CLIARGS = {'module_path': 'somepath'}
    import ansible.constants as C
    C.DEFAULT_MODULE_PATH = 'modulepath'
    import ansible.playbook.task_include as task_include
    task_include._load_tags = lambda x, y: x
    import ansible.utils.plugins as plugins
    plugins._find_base_path = lambda x: 'base'

# Generated at 2022-06-11 16:45:02.214980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('StrategyModule testing...', file=sys.stderr)
    tqm = {}
    strategymodule = StrategyModule(tqm)
    print('StrategyModule: done', file=sys.stderr)


# Generated at 2022-06-11 16:45:03.846586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm)
    assert result.debugger_active


# Generated at 2022-06-11 16:45:07.348674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print('hello')
  tqm = 'this is tqm'
  sm = StrategyModule(tqm)
  assert sm.tqm == tqm
  assert sm.debugger_active == True


# Generated at 2022-06-11 16:45:08.163093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:45:40.547769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None



# Generated at 2022-06-11 16:45:41.076160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:45:52.339764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule.__init__()

    assert res is not None
# end of test_StrategyModule


    def run(self, iterator, play_context):
        p = play_context.as_dict()
        hosts = p.get('inventory', {}).get('hosts')

        task_vars = {}
        self._tqm._failed_hosts = {}

        # FIXME: only applies to linear strategy, but this is the easiest way
        #        to set it
        task_vars = self._tqm._extra_vars.copy()

        # until we refactor inventory to be a global function
        # this is a hack to allow use in the strategy module
        self._inventory = p.get('inventory')

        # all_vars = self._tqm.compute_all_vars(play=

# Generated at 2022-06-11 16:45:53.330820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-11 16:45:54.974139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-11 16:45:59.043441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  
    tqm = None
    strategy_module = StrategyModule(tqm)
    # LinearStrategyModule.__init__(tqm) should be executed
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:46:02.796886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM():
        def __init__(self):
            self.inventory = None
    tqm = FakeTQM()
    strategyModule = StrategyModule(tqm)
    print(strategyModule.debugger_active)


# Generated at 2022-06-11 16:46:05.553550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True
  
if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-11 16:46:07.334823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test if constructor is defined
    try:
        StrategyModule()
    except:
        pass


# Generated at 2022-06-11 16:46:11.192925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "something"
    strategy_object = StrategyModule(tqm)
    assert strategy_object.debugger_active == True


# Generated at 2022-06-11 16:47:26.351993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if False:
        # Fake tqm object
        tqm = type('_', (), dict(host_list=[],
                                 stats=None,
                                 callbacks=None,
                                 inventory=None,
                                 variable_manager=None))

        s = StrategyModule(tqm)
        assert(isinstance(s.run, types.FunctionType))


# Generated at 2022-06-11 16:47:30.094389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule(None)
    assert foo.debugger_active == True
    
    foo.debugger_active = False
    assert foo.debugger_active == False


# Generated at 2022-06-11 16:47:31.932193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1

# Run the interactive debugger

# Generated at 2022-06-11 16:47:39.645794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock

    class FakeTQM(object):
        pass

    class FakeLinearStrategy(object):
        def __init__(self, tqm):
            self.tqm = tqm

    with mock.patch('ansible.plugins.strategy.debug.LinearStrategyModule', FakeLinearStrategy):
        tqm = FakeTQM()
        strategy_module = StrategyModule(tqm)

        assert strategy_module.tqm == tqm
        assert strategy_module.debugger_active
        assert strategy_module.linear_strategy is not None
        assert strategy_module.linear_strategy.tqm == tqm


# Generated at 2022-06-11 16:47:44.389700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start: test_StrategyModule")
    strategy_module = StrategyModule(None)

    assert strategy_module, "Instance not created"
    assert strategy_module.debugger_active == True, "Wrong initial value"
    print("Success: test_StrategyModule")


# Generated at 2022-06-11 16:47:48.289505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    This method is for testing constructor with parameters of class StrategyModule
    '''
    tqm = None
    test_variable = StrategyModule(tqm)
    assert hasattr(test_variable,"tqm")
    assert isinstance(test_variable.tqm, object)


# Generated at 2022-06-11 16:47:51.415781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n*** test_StrategyModule ***')
    stm = StrategyModule()


# Generated at 2022-06-11 16:47:53.585624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj.debugger_active == True, 'Failed to initialize debugger_active'


# Generated at 2022-06-11 16:48:02.662054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cur_strat_mod = StrategyModule(None)
    assert cur_strat_mod.debugger_active == True


    def get_specific_host_variables(self, host):
        return super(StrategyModule, self).get_specific_host_variables(host)

    def run(self, iterator, play_context):
        """Runs the iterator, using the specified strategy"""
        self.iterator = iterator
        self.play_context = play_context
        host = self.inventory.get_host(play_context.remote_addr)

        self.host = host

        self.host_vars = self.get_specific_host_variables(host)

        # Create a Cmd object (if one exists yet)

# Generated at 2022-06-11 16:48:04.565016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	sm = StrategyModule("test queue manager")
	assert sm.debugger_active
# end test_StrategyModule()


# Generated at 2022-06-11 16:50:48.721600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-11 16:50:49.673020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-11 16:50:50.908032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm).debugger_active == True


# Generated at 2022-06-11 16:50:59.972568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n# Unit test starts...\n")

    # Make strategy module object
    #   - Try to make tqm object
    #      - Try to make inventory object
    #         - Try to make loader object
    #      - Try to make variable manager object
    #      - Try to make playbook executor object
    #         - Try to make host inventory object
    #      - Try to make callback object
    #   - Try to make strategy module object
    from ansible.plugins.loader import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 16:51:10.712299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.errors import AnsibleError
    except ImportError:
        print("Could not find module 'ansible.errors'")
        raise

    try:
        from unit.mock.loader import DictDataLoader
    except ImportError:
        print("Could not find module 'unit.mock.loader'")
        raise

    try:
        from ansible.vars.manager import VariableManager
    except ImportError:
        print("Could not find module 'ansible.vars.manager'")
        raise

    try:
        from ansible.inventory.manager import InventoryManager
    except ImportError:
        print("Could not find module 'ansible.inventory.manager'")
        raise


# Generated at 2022-06-11 16:51:18.478680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm is tqm
    assert isinstance(sm.host_states, dict)
    assert sm.host_states == {}
    assert isinstance(sm.result_q, list)
    assert sm.result_q == []
    assert isinstance(sm.step_results, dict)
    assert sm.step_results == {}


# Generated at 2022-06-11 16:51:22.025095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Create the object that will be tested
    stm = StrategyModule()

    #Test the name attribute
    assert stm.name == "debug", "StrategyModule.name should be 'debug' but is %s" % (stm.name)


# Generated at 2022-06-11 16:51:28.589070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #
    # initialize
    task = dict(action=dict(module='test'))
    task_result = dict(result='hello')
    task_exec = dict(task=task, result=task_result)
    host = dict(name='localhost')
    pending = dict(host=host, task_exec=task_exec)

    #
    # prepare test instance
    class MockTQM(object):
        def __init__(self, hostvars):
            self.hostvars = dict(localhost=hostvars)
            self.host_failed = {}
            self.host_unreachable = {}
            self.stats = dict(pending=1, ok=1, dark=1, failed=1, changed=1)

        def enable_callbacks(self):
            pass
