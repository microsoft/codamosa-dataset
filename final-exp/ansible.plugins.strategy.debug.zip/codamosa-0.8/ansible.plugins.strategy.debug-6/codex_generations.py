

# Generated at 2022-06-11 16:41:29.326234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(StrategyModule):
        def __init__(self, tqm):
            pass
    Result = Test(None)
    if hasattr(Result, 'debugger_active') is True:
        print('Unit test is successful')
    else:
        print('Unit test is failed')
    sys.exit()


# Generated at 2022-06-11 16:41:31.732840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m.debugger_active is True


# Generated at 2022-06-11 16:41:39.258382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    print(sys.argv)
    sys.argv = [None, '-vvvv', '-c', 'local', '-m', 'debug', '-u', 'root', '-i', '/etc/ansible/hosts', '-a', 'ls']
    global TASK_QUEUE_MANAGER
    TASK_QUEUE_MANAGER = TaskQueueManager(None, sys.argv)
    global STRATEGY_MODULE_CONSTRUCTOR
    STRATEGY_MODULE_CONSTRUCTOR = StrategyModule(TASK_QUEUE_MANAGER)


# Generated at 2022-06-11 16:41:43.914632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    test_StrategyModule: test constructor of class StrategyModule
    '''
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active is True



# Generated at 2022-06-11 16:41:46.391151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:41:51.000056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active == True
    assert strategy.tasks_to_run == []
    assert strategy.tasks_to_run_copy == None
    assert strategy.connections == {}
    assert strategy.hosts_cache == {}
    assert strategy.hosts_results == {}
    assert strategy.hosts_failed == []
    assert strategy.hosts_skipped == {}
    assert strategy.hosts_unreachable == {}
    assert strategy.lasterror == None
    assert strategy.last_failed_host == None
    assert strategy.last_failed_task == None
    assert strategy.last_task_banner == None

# Executes tasks in interactive debug session.

# Generated at 2022-06-11 16:41:54.104341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'dummy'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    return


# Generated at 2022-06-11 16:41:54.829717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:41:59.453828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True

    # Reset to original state
    strategy_module.debugger_active = False


# Generated at 2022-06-11 16:42:00.030120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)



# Generated at 2022-06-11 16:42:03.035024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.debugger_active is True


# Generated at 2022-06-11 16:42:04.035375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:42:05.537900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

_STRATEGY = StrategyModule

# Generated at 2022-06-11 16:42:06.509791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.debugger_active == True


# Generated at 2022-06-11 16:42:09.409600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert(sm)

    # Any TaskQueueManager object is used for
    # the test because it is not used in the function


# Generated at 2022-06-11 16:42:10.044481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:42:17.061132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins

    class TestStrategyModule(unittest.TestCase):
        def test_pass(self):
            module = StrategyModule(tqm=None)
            self.assertEqual(hasattr(module, 'debugger_active'), True)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-11 16:42:18.068507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:42:21.092817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create mock task queue manager
    tqm = None
    # Create test strategy module
    sm = StrategyModule(tqm)
    # Assert debugger_active set
    assert sm.debugger_active == True


# Generated at 2022-06-11 16:42:23.557594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = fake_tqm()
    strategymodule = StrategyModule(tqm)

# Mock of object TaskQueueManager

# Generated at 2022-06-11 16:42:27.842870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        mock_tqm = MockTQM()
        strategy = StrategyModule(mock_tqm)
    except:
        print("StrategyModule test fail")
        return
    print("StrategyModule test pass")


# Generated at 2022-06-11 16:42:39.388976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def test_inventory(path, loader, variable_manager, host_list):
        return '{}/hosts'.format(path)

    my_path = '.'
    my_loader = 10
    my_variable_manager = VariableManager()
    my_host_list = ['localhost']
    my_hosts = test_inventory(my_path, my_loader, my_variable_manager, my_host_list)
    my_task = Task()

# Generated at 2022-06-11 16:42:47.634759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # test for invalid tqm
        StrategyModule(None)
        raise AssertionError('Invalid tqm')
    except:
        pass

    # test for valid tqm
    try:
        tqm = object()
        strategy_module = StrategyModule(tqm)
        assert strategy_module.debugger_active == True
    except:
        raise AssertionError('Fail to create strategy_module')


# Python 2 and 3 compatible subclass of cmd.Cmd

# Generated at 2022-06-11 16:42:51.813246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = type('tqm', (object,), {})
        StrategyModule(tqm)
    except Exception as e:
        pytest.fail('StrategyModule failed: ' + str(e))



# Generated at 2022-06-11 16:42:53.820518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = None
    sm = StrategyModule(TQM)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-11 16:42:54.955822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)



# Generated at 2022-06-11 16:42:58.597653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('test_tqm', (object,), {'_stats': {}})
    sm = StrategyModule(tqm)
    assert sm.debugger_active

# TODO: Improve the testability.

# Generated at 2022-06-11 16:43:02.060868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
        This is a test for the constructor of class StrategyModule
    """
    first_obj = LinearStrategyModule
    second_obj = StrategyModule
    assert second_obj == first_obj


# Generated at 2022-06-11 16:43:08.553954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.strategy_plugins
    manager = ansible.utils.strategy_plugins.StrategyModuleManager()
    manager.add_strategy("debug", StrategyModule)
    module = manager.get('debug')
    assert module.__doc__ == DOCUMENTATION
    assert module.__name__ == 'StrategyModule'
    assert module.__module__ == __name__


# Generated at 2022-06-11 16:43:12.017388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule(tqm=cmd.Cmd)
    assert isinstance(instance, LinearStrategyModule)
    assert isinstance(instance, StrategyModule)


# Generated at 2022-06-11 16:43:16.876809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(None).debugger_active == True)



# Generated at 2022-06-11 16:43:17.941275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#    assert "Plugin" == "Plugin"


# Generated at 2022-06-11 16:43:20.109070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:43:23.440271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    tqm.tmpdir = None
    # Call constructor of base class
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-11 16:43:24.015381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:43:35.252012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    context.CLIARGS = { 'module_path': '', 'forks': 1,
            'become': None, 'become_method': None, 'become_user': None,
            'verbosity': 3, 'check': False}

    # Set up test objects
    dummy_loader = DataLoader()

# Generated at 2022-06-11 16:43:37.374110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# For unit test
if __name__ == '__main__':
    test_StrategyModule()

# For unit test
# EOF

# Generated at 2022-06-11 16:43:37.808795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:43:48.090348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except Exception as e:
        assert(type(e) == TypeError)
        assert(e.__str__() == "__init__() takes exactly 2 arguments (1 given)")
    try:
        tqm = []
        StrategyModule(tqm)
    except Exception as e:
        assert(type(e) == TypeError)
        assert(e.__str__() == "__init__() takes exactly 2 arguments (1 given)")
    try:
        tqm = ""
        StrategyModule(tqm)
    except Exception as e:
        assert(type(e) == TypeError)
        assert(e.__str__() == "__init__() takes exactly 2 arguments (1 given)")

# Generated at 2022-06-11 16:43:50.042814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    return True

if __name__ == '__main__':

    test_StrategyModule()

# Generated at 2022-06-11 16:44:32.285186
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # define some unit test variables
    module_name = "test_StrategyModule"
    test_queue_manager = module_name
    # execute constructor code
    tqm = StrategyModule(test_queue_manager)
    # perform assertions
    assert tqm.debugger_active == True
    assert tqm.tqm.__str__ == module_name.__str__


# Generated at 2022-06-11 16:44:33.677529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-11 16:44:40.883886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM:
        verbose = 2
        inventory = None

    class MockInventory(object):
        def __init__(self):
            self.host_list = []

        def get_host_vars(self, host, new_pb_basedir):
            return {}

        def get_host(self, pattern):
            return None

    inventory = MockInventory()
    sm = StrategyModule(MockTQM)
    assert sm.debugger_active is True


# Generated at 2022-06-11 16:44:49.330305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class UnitTestTaskQueueManager():
        class PlayContext():
            verbosity = 0
        class Play():
            name = 'play'
            hosts = 'hosts'
            #play_context = PlayContext()
            @property
            def play_context(self):
                return self.PlayContext()

        class Host():
            def __init__(self, name):
                self.name = name

        def __init__(self):
            self.hosts = []
            self.hosts.append(self.Host(name='localhost'))
            self.play = self.Play()

    tqm = UnitTestTaskQueueManager()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True



# Generated at 2022-06-11 16:44:56.995218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        class FakeOptions(object):
            def __init__(self):
                self.module_path = None
        def __init__(self):
            self.options = self.FakeOptions()
            self.get_vars = None
            self.get_vars_files = None
            self.extra_vars = None
            self.inventory = None
    tqm = FakeTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-11 16:44:59.425320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active is True


# Generated at 2022-06-11 16:45:03.695963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active
    # This is a stub class. you can check the functionality in playbook_test.test_playbook.test_playbook_run_debug.

# This class is itself a stub class.

# Generated at 2022-06-11 16:45:06.224518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This constructor is not tested, because tqm is always required.
    # Please write test code in __init__.py
    pass


# Generated at 2022-06-11 16:45:07.044536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:45:18.511948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# -----------------------------------------------------
# The following code is from jinja2 shell.
# The original code is from jinja2.shell.
#  - https://github.com/pallets/jinja/blob/master/jinja2/shell.py
#  - BSD-License
#
# The following code is modified.
#  - For py3k.
#  - import module more carefully.
#  - Replace to use ansible.parsing.dataloader.
#    - Use template_loader.get_source() instead of open().
#  - Remove the code which is unnecessary to use as ansible.
# -----------------------------------------------------

# -*- coding: utf-8 -*-

# Generated at 2022-06-11 16:45:35.578873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:45:37.274315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == 'Executes tasks on hosts in sequence'
    assert StrategyModule.__init__.__doc__ == 'TODO: Write a better docstring for __init__'

# unit test for public method execute_tasks

# Generated at 2022-06-11 16:45:42.183756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTqm(object):
        class FakeLoader(object):
            pass
        class FakeVariableManager(object):
            pass
        class FakeStats(object):
            pass

        def __init__(self):
            self.loader = self.FakeLoader()
            self.variable_manager = self.FakeVariableManager()
            self.stats = self.FakeStats()
    sm = StrategyModule(FakeTqm())


# Generated at 2022-06-11 16:45:43.744897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active


# Generated at 2022-06-11 16:45:46.850661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    StrategyModule(tqm=MagicMock())



# Generated at 2022-06-11 16:45:48.385909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #
    s = StrategyModule(None)
    assert s.debugger_active == True


# Generated at 2022-06-11 16:45:49.625454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')


# Generated at 2022-06-11 16:45:53.587632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy import debug
        debug.StrategyModule
    except (TypeError, NameError):
        version = '%s.%s' % sys.version_info[:2]
        if (version < '2.7'):
            raise



# Generated at 2022-06-11 16:45:54.699058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:45:56.725487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    return StrategyModule(tqm)


# Generated at 2022-06-11 16:46:27.710532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-11 16:46:29.090242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm').debugger_active


# Generated at 2022-06-11 16:46:35.008126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import pdb
    except ImportError:
        raise
    tqm = pdb.Pdb()
    try:
        StrategyModule(tqm)
        raise
    except SyntaxError:
        raise
    except ImportError:
        raise

# Inherit class InteractiveDebugSession from pdb.Pdb

# Generated at 2022-06-11 16:46:44.781014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

    ansible.plugins.strategy_loader.set_directory(
        ansible.utils.path.get_plugins_path() + "/strategy")

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    extra_vars = load_extra_vars(loader=DataLoader(), options={})
    host_list = [{"name": "debugger_test_host"}]

# Generated at 2022-06-11 16:46:46.662121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Need to be implemented
    pass


# Generated at 2022-06-11 16:46:56.693498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import load_strategy_plugins
    load_strategy_plugins()
    from ansible import constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    passwords = {}
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
        stdout_callback='default',
    )
    sm = StrategyModule(tqm)

# Generated at 2022-06-11 16:47:00.971125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert isinstance(strategy_module, LinearStrategyModule)


# Generated at 2022-06-11 16:47:02.302596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            pass
    StrategyModule(tqm())


# Generated at 2022-06-11 16:47:06.447231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    tqm = create_tqm(['-m', 'debug'])
    assert isinstance(StrategyModule(tqm), StrategyModule)


# Generated at 2022-06-11 16:47:07.609206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-11 16:49:52.718530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)

    if sm.debugger_active:
        print("Constructed StrategyModule object successfully")


# Generated at 2022-06-11 16:50:03.274307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.strategy.debug
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 16:50:06.894211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n# Test StrategyModule')
    # Should be passed as class variable to LinearStrategyModule.__init__.
    tqm = 'test'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-11 16:50:17.089334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.plugins
    tqm = ansible.utils.plugins.complex_loader.get('v2_runner', 'TaskQueueManager')(
        inventory=ansible.utils.plugins.complex_loader.get('inventory', 'Inventory')('localhost'),
        variable_manager=ansible.utils.plugins.complex_loader.get('var_manager', 'VariableManager')(),
        loader=ansible.utils.plugins.complex_loader.get('loader', 'DataLoader')(),
    )
    #tqm = ansible.plugins.loader.get('v2_runner', 'TaskQueueManager')(
    #    inventory=ansible.plugins.loader.get('inventory', 'Inventory')('localhost'),
    #    variable_manager=ansible.plugins.loader.get('var_manager', 'VariableManager'

# Generated at 2022-06-11 16:50:24.888961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugin_loader
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.cli.adhoc import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
   

# Generated at 2022-06-11 16:50:27.229019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule.tqm is None
    assert strategyModule.debugger_active is True



# Generated at 2022-06-11 16:50:30.653095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("UNITTEST: test_StrategyModule")
    base = LinearStrategyModule('True')
    derived = StrategyModule('True')
    print("UNITTEST: test_StrategyModule finished successfully")


# Generated at 2022-06-11 16:50:33.822888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Foo:
        pass
    tqm = Foo()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active
    assert strategy.tqm is tqm


# Generated at 2022-06-11 16:50:36.809240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # call __init__()
    tqm = object
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-11 16:50:37.365168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
