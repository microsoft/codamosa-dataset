

# Generated at 2022-06-25 11:58:16.215677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:20.328638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:21.089779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Generated at 2022-06-25 11:58:21.805687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:23.232746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()
    # Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 11:58:25.557489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Test not implemented yet
    assert False


# Generated at 2022-06-25 11:58:27.150751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:29.749950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert float_0 == float_0


# Generated at 2022-06-25 11:58:32.707762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as inst:
        print('Exception caught: ' + str(inst))

# This main function executes the unit tests

# Generated at 2022-06-25 11:58:33.461083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if __debug__:
        test_case_0()

# Generated at 2022-06-25 11:58:37.640941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, StrategyModule)
    assert strategy_module_0.debugger_active is True
    assert strategy_module_0.name == 'debug'

# Generated at 2022-06-25 11:58:43.932653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 7
    int_1 = 9
    print_0 = pprint.PrettyPrinter()
    strategy_module_0 = StrategyModule(int_0)
    del strategy_module_0
    # Create object for class StrategyModule
    strategy_module_0 = StrategyModule(int_1)
    # Re-init object
    strategy_module_0.__init__(int_0)
    bool_0 = bool(strategy_module_0)
    print_0.pprint(bool_0)
    bool_1 = bool(strategy_module_0)
    print_0.pprint(bool_1)


# Generated at 2022-06-25 11:58:45.124492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of the class
    test_case_0()


# Generated at 2022-06-25 11:58:45.973958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == 0



# Generated at 2022-06-25 11:58:48.689878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:49.665297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:50.305065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:52.078693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()
    print("Everything passed")

# Generated at 2022-06-25 11:58:55.178957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:57.633989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception when calling constructor for class StrategyModule: " + str(err))


# Generated at 2022-06-25 11:59:02.869810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(strategy_module_0.debugger_active)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:59:06.918143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2350.0
    strategy_module_0 = StrategyModule(float_0)

# #####################################################################################################################
# Action: Unit test
# #####################################################################################################################
test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 11:59:08.339800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test to check if the function run is working 

# Generated at 2022-06-25 11:59:09.691528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        return True
    except:
        return False


# Generated at 2022-06-25 11:59:10.986819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:11.769111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__




# Generated at 2022-06-25 11:59:12.551474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:13.715576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 11:59:15.355332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule(0.0)
    print('strategy_module_obj ' + str(strategy_module_obj))

    test_case_0()

# Generated at 2022-06-25 11:59:16.439192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test

# Generated at 2022-06-25 11:59:23.558405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:24.742516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(0)
    assert x.tqm == 0



# Generated at 2022-06-25 11:59:29.867719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:33.591875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None, "task.py:StrategyModule()"


# Generated at 2022-06-25 11:59:34.960922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    value = 2868.0
    strategy_module_0 = StrategyModule(value)


# Generated at 2022-06-25 11:59:44.614877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Cmd_0 = cmd.Cmd
    bool_0 = bool(0)
    int_1 = int(0)
    str_0 = str(2)
    instance_0 = StrategyModule(0.407856)
    dict_0 = dict()
    dict_1 = dict()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()


# Generated at 2022-06-25 11:59:45.233134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:45.787108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:50.208699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:51.070072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_set_strategy_module_0 = test_case_0()



# Generated at 2022-06-25 12:00:05.798184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(str(LinearStrategyModule)) == 0
    assert len(str(LinearStrategyModule)) == 0
    assert len(repr(StrategyModule)) == 86
    assert 'time.time' in str(StrategyModule)
    assert 'cmd.Cmd' in str(LinearStrategyModule)
    assert 'cmd.Cmd' in str(LinearStrategyModule)
    assert len(str(LinearStrategyModule)) == 0
    assert '_terminate_value_count' in str(StrategyModule)
    assert len(str(StrategyModule)) == 86
    assert '_terminate_value_count' in str(StrategyModule)
    assert len(str(StrategyModule)) == 86
    assert '_terminate_value_count' in str(StrategyModule)

# Generated at 2022-06-25 12:00:06.794297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("TestStrategyModule")
    test_case_0()


# Generated at 2022-06-25 12:00:07.776880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:08.922869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule constructor...')
    test_case_0()
    print('PASSED')


# Generated at 2022-06-25 12:00:10.202468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(1)
    assert isinstance(strategy_module_0, StrategyModule)



# Generated at 2022-06-25 12:00:12.576273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Executing test_StrategyModule')
    test_case_0()

if __name__ == '__main__':
    print('Test module of class StrategyModule')
    print('Sample inputs:')
    print('Test #0')
    print('Expected outputs:')
    test_StrategyModule()

# Generated at 2022-06-25 12:00:13.703358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1 is not None


# Generated at 2022-06-25 12:00:14.570093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test 0
    test_case_0()


# Generated at 2022-06-25 12:00:18.608439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Fixme
    float_0 = float
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:00:20.501368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("initializing StrategyModule")
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:38.191992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    number_0 = 2868
    strategy_module_0 = StrategyModule(number_0)
    assert strategy_module_0._tqm == 2868


# Generated at 2022-06-25 12:00:38.922718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test

# Generated at 2022-06-25 12:00:41.083977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:42.579094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_case_0()

sys.dont_write_bytecode = True


# Generated at 2022-06-25 12:00:43.288893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:48.347954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test method or function named constructor of class class StrategyModule
    test_case_0()


# Generated at 2022-06-25 12:00:49.950763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)



# Generated at 2022-06-25 12:00:55.292704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = float()
    strategy_module_0 = StrategyModule(float_0)


if(__name__ == '__main__'):
    test_case_0()
    # test_StrategyModule()

# Generated at 2022-06-25 12:00:57.310384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:00.820467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:33.958974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # Console entry point
    # test_case_0()

    test_StrategyModule()

    print("All test cases passed!")

# Generated at 2022-06-25 12:01:40.747769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 7
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3(int_0)
    return 0



# Generated at 2022-06-25 12:01:43.271269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    float_1 = 3729.0
    strategy_module_0 = StrategyModule(float_1)



# Generated at 2022-06-25 12:01:46.409908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 0 == 0


# Generated at 2022-06-25 12:01:51.859931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_playbook_0 = None
    ansible_playbook_1 = None
    tqm_0 = TaskQueueManager(inventory=ansible_playbook_0, variable_manager=ansible_playbook_1, loader=None, options=ansible_playbook_1, passwords=None, stdout_callback=None)
    strategy_module_0 = StrategyModule(tqm_0)

# Debugger hookup
if sys.version_info[0] == 2:
    import pydevd
    pydevd.settrace(host='localhost', suspend=False)

# Generated at 2022-06-25 12:01:52.504161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:55.052696
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:01:55.721579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:59.475432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:02:02.971106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:23.289861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:03:26.066858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test_StrategyModule")
        print(e)
        assert False
    finally:
        print("test_StrategyModule finished")



# Generated at 2022-06-25 12:03:27.520531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    test_case_0()


# Generated at 2022-06-25 12:03:28.502168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 12:03:29.861441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:31.475159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    unittest.main()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:03:32.234076
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): test_case_0()


# Generated at 2022-06-25 12:03:34.039545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    strategy_module_0 = StrategyModule(float_0)
    assert type(strategy_module_0) is StrategyModule


# Generated at 2022-06-25 12:03:35.609946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:38.689201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loop_list = [0,1,2]
    for i in loop_list:
        TestCase_Kishin_Yagami(i)

# Make test case function

# Generated at 2022-06-25 12:06:45.461798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 48.0
    strategy_module_1 = StrategyModule(float_1)
    float_2 = 30.0
    strategy_module_2 = StrategyModule(float_2)
    float_3 = 56.0
    strategy_module_3 = StrategyModule(float_3)
    float_4 = 10.0
    strategy_module_4 = StrategyModule(float_4)


# Generated at 2022-06-25 12:06:46.629665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    assert StrategyModule(float_0).debugger_active


# Generated at 2022-06-25 12:06:47.544735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Success")


# Generated at 2022-06-25 12:06:48.419536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests the constructor of class StrategyModule
    test_case_0()


# Generated at 2022-06-25 12:06:51.426484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_2 = 3487.0
    strategy_module_1 = StrategyModule(float_2)
    assert strategy_module_1 is not None

test_0()

test_case_0()

# Generated at 2022-06-25 12:06:54.587176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2868.0
    test_case_0()
    test_case_1() # TODO: We don't have `eval()` in Python 3.

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:06:55.659080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main program for executing unit test

# Generated at 2022-06-25 12:06:56.309156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:06:56.986383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:57.660497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()