

# Generated at 2022-06-25 11:58:15.404970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()




# Generated at 2022-06-25 11:58:16.020685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:20.408929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_debug_hosts = ['localhost', '127.0.0.1', '192.168.56.102']
    task_1 = {'action': {'__ansible_argspec': {}, '__ansible_module__': 'ping'}, 'notify': [], 'when': [], 'rescue': [], 'always_run': [], '__ansible_module__': 'shell', 'loop': '', 'delegate_to': '', 'changed_when': True, 'vars': {}, 'loop_control': {}, '__ansible_version__': 1.2, 'always': [], 'name': 'test', '__ansible_debug__': True, 'tags': [], 'args': 'echo hello world', 'register': '', 'notified_by': []}

# Generated at 2022-06-25 11:58:21.438162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    test_case_0()


# Generated at 2022-06-25 11:58:22.167945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:29.625328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0 is not None
    assert repr('/home/travis/build/ansible/ansible/lib/ansible/plugins/strategy/debug.py') in repr(strategy_module_0)
    assert "<ansible.plugins.strategy.debug.StrategyModule object at 0x7f27ee8d1b00>" == repr(strategy_module_0)


# Generated at 2022-06-25 11:58:30.531336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Verify that StrategyModule() returns as instance of class StrategyModule
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:31.925344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests for method __init__
    test_case_0()



# Generated at 2022-06-25 11:58:35.140374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args_0 = None
    try:
        test_case_0()
    except:
        print('exception encountered: ' + str(sys.exc_info()))

test_StrategyModule()

# Generated at 2022-06-25 11:58:42.683156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# This class defines the behavior of the debug session.
#
# It is a subclass of cmd.Cmd which provides a simple framework for writing
# line-oriented command interpreters.
#
# These are the methods of interest:
#
# cmdloop() -- loop until an EOF is read
# precmd(line) -- hook method executed just before the command line line is
#                  interpreted, but after the input prompt is generated and
#                  issued.
#
# do_*() and help_*() methods interact with the debugger.
#
# The debugger can be configured to process other commands, but at present it
# supports the following:
#
# commands:
#   play_tasks - iterate through the tasks in the play and execute them
#   task_list - print the list of tasks in the play
#  

# Generated at 2022-06-25 11:58:45.101696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    var_0 = StrategyModule(test_tqm)


# Generated at 2022-06-25 11:58:47.708343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('')
    tqm = None
    try:
        StrategyModule(tqm)
    except Exception as e:
        print('FAILED: test_StrategyModule encountered exception')
        print(str(e))

# Generated at 2022-06-25 11:58:48.925135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = StrategyModule(tqm)
    assert var_1 is not None, "Error: call to StrategyModule() constructor failed"


# Generated at 2022-06-25 11:58:51.031865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global var_0,var_1
    var_0 = StrategyModule(None)
    print("var_0: {0}".format(var_0))
    var_1 = None
    var_2 = id(var_0)
    assert(var_2 != var_1)


# Generated at 2022-06-25 11:58:53.061155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except:
        print("method \"StrategyModule\" of class StrategyModule has errors.")


# Generated at 2022-06-25 11:58:54.167145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert_raises(TypeError, lambda: StrategyModule())


# Generated at 2022-06-25 11:58:58.053672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    test_obj_0 = StrategyModule(tqm)
    test_obj_0.add_tasks()
    test_obj_0.add_tasks()
    test_obj_0.add_tasks()


# Generated at 2022-06-25 11:59:01.434900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(var_0)
    strategy_module_0 = StrategyModule(var_0)


# Generated at 2022-06-25 11:59:05.525059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with default parameters
    strategy_module_0 = StrategyModule(tqm = None)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, LinearStrategyModule)
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 11:59:06.368783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()


# Generated at 2022-06-25 11:59:09.797696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-25 11:59:12.029316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.debug
        # ctor
        test_case_0()
    except ImportError:
        pass
    except NameError:
        pass


# Generated at 2022-06-25 11:59:15.354725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        var_1 = None
        var_1 = StrategyModule(var_1)
    except:
        var_2 = 'exception'
    finally:
        if (test_case_0() == var_2):
            var_3 = 'test case 0'

test_StrategyModule()

# Generated at 2022-06-25 11:59:16.158160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:17.487786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert isinstance(tqm, StrategyModule)


# Generated at 2022-06-25 11:59:18.313074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-25 11:59:19.911904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    # Perform unit test for constructor of class StrategyModule

    # Unit test for constructor of class StrategyModule
    StrategyModule(tqm)


# Generated at 2022-06-25 11:59:24.858511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:25.923409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)



# Generated at 2022-06-25 11:59:29.956356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert(strategyModule.debugger_active == True)


# Generated at 2022-06-25 11:59:36.297507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = True
    strategy_module_1 = StrategyModule(bool_1)
    assert strategy_module_1._tqm is bool_1
    assert strategy_module_1.host_list == dict({})
    assert strategy_module_1.host_state_map == dict({})
    assert strategy_module_1.debugger_active == True


# Generated at 2022-06-25 11:59:40.022221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 11:59:41.658597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # unit test within this file
    test_StrategyModule()

# Generated at 2022-06-25 11:59:44.892507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:46.241367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:50.724139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module_0 = StrategyModule(1234)
  assert strategy_module_0 != None

# Generated at 2022-06-25 11:59:53.678353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:01.853748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(bool)
    assert type(obj) is StrategyModule
    obj = StrategyModule(list)
    assert type(obj) is StrategyModule
    obj = StrategyModule(dict)
    assert type(obj) is StrategyModule
    obj = StrategyModule(set)
    assert type(obj) is StrategyModule
    obj = StrategyModule(tuple)
    assert type(obj) is StrategyModule
    obj = StrategyModule(str)
    assert type(obj) is StrategyModule
    obj = StrategyModule(int)
    assert type(obj) is StrategyModule
    obj = StrategyModule(float)
    assert type(obj) is StrategyModule
    obj = StrategyModule(None)
    assert type(obj) is StrategyModule
    obj = StrategyModule(Exception)
    assert type(obj) is StrategyModule

# Generated at 2022-06-25 12:00:06.383180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#
# Code is generated below by python script and then format is applied to the code
#


# Generated at 2022-06-25 12:00:07.869740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = True
    strategy_module_1 = StrategyModule(tqm_0)



# Generated at 2022-06-25 12:00:18.683303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.price = 8.072098688641278
    strategy_module_0.price = 9.928880033834986
    bool_0 = True
    strategy_module_0.use_task_cache = bool_0
    bool_0 = True
    strategy_module_0.noop_task = bool_0
    bool_0 = True
    strategy_module_0.noop_command = bool_0
    assert strategy_module_0.get_name() is "linear"
    assert strategy_module_0.get_host_keys() == []
    assert strategy_module_0.get_host_vars_files() == []
    strategy_module_0.done = bool_0

# Generated at 2022-06-25 12:00:19.332078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:20.646646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(False)
    assert True


# Generated at 2022-06-25 12:00:25.274585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:00:26.636965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:00:29.932444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:31.400064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:00:34.180729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:37.216081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Test class constructor
    test_StrategyModule()

# Generated at 2022-06-25 12:00:37.988844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:42.917140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    return None


# Generated at 2022-06-25 12:00:44.180216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:48.023897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:48.557835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:49.345168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # When tqm is true, debug should be True
    test_case_0()




# Generated at 2022-06-25 12:00:49.797860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:51.289334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 12:00:53.363963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Constructor and destructor"""
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:58.738983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0.debugger_active == True
    assert strategy_module_0.task_counter == 0
    assert strategy_module_0.tqm == bool_0


# Generated at 2022-06-25 12:00:59.782375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create test case
    # TODO
    return True


# Generated at 2022-06-25 12:01:08.229071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:10.091605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(test_case_0.__doc__)

    test_case_0()


# Generated at 2022-06-25 12:01:12.365511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None



# Generated at 2022-06-25 12:01:16.394523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.run()


if __name__ == '__main__':

    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 12:01:18.474204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:20.687619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    pprint.pprint(str(strategy_module_0))
    pass


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()
    pass

# Generated at 2022-06-25 12:01:21.401638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:28.063266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    print(strategy_module_0.__class__.__name__)
    print(strategy_module_0.__init__.__class__.__name__)
    assert isinstance(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:01:29.195851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

print('TEST EXECUTION FINISHED!')

# Generated at 2022-06-25 12:01:31.516536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Test case 0: Successful")
    except Exception as e:
        print("Test case 0: Failed")
        print("Exception occurred: {}".format(e))
    else:
        print("")
        print("--- Test for class StrategyModule completed successfully ---")


test_StrategyModule()

# Generated at 2022-06-25 12:01:49.424162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

ansible.plugins.strategy.debug.StrategyModule = StrategyModule

# Generated at 2022-06-25 12:01:53.867708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test runner

# Generated at 2022-06-25 12:01:55.202530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:59.508846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(True)


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:02:02.388292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:07.906716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock
    class ReaderMock(object):
        def __init__(self):
            self.data = []

        def readline(self):
            try:
                return self.data.pop(0)
            except IndexError:
                return ''

    class FileMock(object):
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

    # unit test
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0.debugger_active



# Generated at 2022-06-25 12:02:09.977054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:02:11.024707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 12:02:14.463801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run unit tests
#test_StrategyModule()

# Generated at 2022-06-25 12:02:15.100785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:02:54.779299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:58.345131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pp1 = pprint.PrettyPrinter(indent=2)

    # Testing execution of constructor for class StrategyModule
    print("Testing execution of constructor for class StrategyModule")
    try:
        test_case_0()
        print("Test 1 passed!")
    except Exception as e:
        print("Exception raised during execution of test case 1:")
        print(e)


# Generated at 2022-06-25 12:03:03.141817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    test_case_0()


# Generated at 2022-06-25 12:03:04.034741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:03:08.722364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0 -> True
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:09.464107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:03:13.417966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True;
    strategy_module_0 = StrategyModule(bool_0)




# Generated at 2022-06-25 12:03:15.925318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test of method run of class StrategyModule

# Generated at 2022-06-25 12:03:17.864261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:19.971282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, LinearStrategyModule)

# Generated at 2022-06-25 12:04:48.811865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:04:49.564789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:51.558225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:04:52.841010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.run()


# Generated at 2022-06-25 12:04:54.832667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    test_case_0()
    print('test_StrategyModule OK')


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:56.159534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:57.039457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test case 0:
    test_case_0()



# Generated at 2022-06-25 12:04:58.042702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = bool
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 12:04:59.276730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for StrategyModule.__init__(self, tqm)
    test_case_0()


# Generated at 2022-06-25 12:05:00.190940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()