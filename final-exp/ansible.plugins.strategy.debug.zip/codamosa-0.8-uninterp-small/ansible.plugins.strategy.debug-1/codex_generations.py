

# Generated at 2022-06-25 11:58:21.004667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:22.834667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Not run directly.
if __name__ == '__main__':
    test_StrategyModule()
    sys.exit()

# Generated at 2022-06-25 11:58:26.346703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Unit tests
    test_StrategyModule()

# Generated at 2022-06-25 11:58:28.921159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(object)
    assert(strategy_module_1.tqm is None)
    assert(strategy_module_1.debugger_active == True)


# Generated at 2022-06-25 11:58:32.075267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:33.393539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:35.488941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor')
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:38.331629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print ('[-] Test Case  Failed')
        return
    print ('[+] Test Case "test_case_0" Passed')


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:39.324969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:42.413630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n**********Test StrategyModule**********')
    print('\n\n****Test case 0****')
    test_case_0()
    print('\n\n')



if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:44.103206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:45.019739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:46.555843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:51.094316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.debugger_active == True

test_case_0()


# Generated at 2022-06-25 11:58:54.812363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Execute commands

# Generated at 2022-06-25 11:58:56.422948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:57.814233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:58:58.798700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:01.435106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Executes tasks in interactive debug session

# Generated at 2022-06-25 11:59:03.857924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test run if this file is run as a standalone program
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:05.927415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:08.311636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run test for class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 11:59:09.333947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:11.011796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # Run the command and print the output
    test_StrategyModule()

# Generated at 2022-06-25 11:59:12.664660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # without any parameter
    strategy_module_0 = StrategyModule()

    # with one parameter
    strategy_module_1 = StrategyModule(1)



# Generated at 2022-06-25 11:59:13.288689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main function

# Generated at 2022-06-25 11:59:14.143144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:15.924652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

    print('OK')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:17.076993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_elem_0 = 'available_algorithms'
    test_case_0(my_elem_0)

test_StrategyModule()

# Generated at 2022-06-25 11:59:19.156612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:23.678289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:25.452630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 11:59:30.537439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing method constructor of class StrategyModule")
    test_case_0()
    print ("Unit tests for constructor of class StrategyModule finished")

# Unit testing function calls
test_StrategyModule()



# Generated at 2022-06-25 11:59:33.771763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test entry point

# Generated at 2022-06-25 11:59:34.584005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:35.571389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Program to test the StrategyModule class

# Generated at 2022-06-25 11:59:37.015040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 11:59:41.363610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_0 = dict()
    ansible_0['key'] = 'value'
    ansible_0['key_2'] = 'value_2'
    ansible_1 = dict()
    ansible_1['another_key'] = 'another_value'
    ansible_1['another_key_2'] = 'another_value_2'
    strategy_module_0 = StrategyModule(((ansible_0, ansible_1)))
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 11:59:46.794765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

tasks = ['t1', 't2', 't3']
inventory = ['localhost']
variable_manager = ['localhost']
loader = ['localhost']

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:50.755150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:56.178794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Constructor Error")



# Generated at 2022-06-25 11:59:59.249741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:01.067536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Test for class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-25 12:00:05.536855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:06.415327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:08.025841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:11.612843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:12.755705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# End of unit test for constructor of class StrategyModule


# Generated at 2022-06-25 12:00:13.867064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:21.023302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'play'
    str_2 = 'host'
    str_3 = 'task'
    str_4 = 'iterator'
    str_5 = 'result'
    strategy_module_0.run(str_1, str_2, str_3, str_4, str_5)



# Generated at 2022-06-25 12:00:31.049558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:34.444229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 12:00:35.580319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:39.093077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None, "test_case_0"

test_cases = [
    test_case_0,
    test_StrategyModule,
]

#
# Unit tests to test the method list_available_algorithms
#

# Generated at 2022-06-25 12:00:41.481938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:42.358170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:44.647730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    print("Unit test for 'strategy_module.py'")
    print("====================================")
    print("Testing constructor of class StrategyModule")
    test_StrategyModule()

# Generated at 2022-06-25 12:00:48.364177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test runner

# Generated at 2022-06-25 12:00:50.517946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.NONE_CACHE = {}



# Generated at 2022-06-25 12:00:54.455206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:13.383406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = None
    name = 'available_algorithms'
    tqm = None
    test_case_0()
    pass

test_StrategyModule()

# Generated at 2022-06-25 12:01:14.544427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()




# Generated at 2022-06-25 12:01:18.304000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Case 0
    test_case_0()
    
    
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:19.542527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = "available_algorithms"
    strategy_module_1 = StrategyModule(str_1)



# Generated at 2022-06-25 12:01:23.037840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    print('Starting unit test')
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()
    print('Test Ended unit test')

# Generated at 2022-06-25 12:01:29.045125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        global test_case_0
        test_case_0 = None
    except:
        global test_case_0
        if test_case_0 is not None:
            raise
    finally:
        if test_case_0 is not None:
            test_case_0()

# Generated at 2022-06-25 12:01:31.541602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass




# Generated at 2022-06-25 12:01:32.787234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception e")

# Generated at 2022-06-25 12:01:36.192173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# If StrategyModule.py is called in stand alon mode, then call function test_StrategyModule()
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:38.531278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()




# Generated at 2022-06-25 12:02:13.065772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None, "StrategyModule constructor failed."
    print("StrategyModule constructor passed.")

# Generated at 2022-06-25 12:02:16.790313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import glob
    import os

    import ansible.utils.template
    import ansible.playbook.play
    import ansible.playbook.play_context

    import ansible.playbook.task
    import ansible.playbook.handler
    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text, to_native
    from ansible.template import Templar
    import ansible.utils.vars
    import ansible.vars.unsafe_proxy


    class AnsibleVarsModule():
        def __init__(self, str_0):
            self.vars = dict()

# Generated at 2022-06-25 12:02:20.914323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:02:23.065153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:02:31.236145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    import sys
    import os
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    class NullPlayContext:
        def __init__(self):
            self.remote_addr = ''
            self.connection = ''
            self.remote_user = ''
            self.password = ''
            self.port = 0
            self.become_method = ''
            self.become_user = ''
            self.become_pw = ''


# Generated at 2022-06-25 12:02:31.717397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:32.647584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# entry point
if __name__ == '__main__':
    # test_StrategyModule()
    print('test finished!')

# Generated at 2022-06-25 12:02:33.564375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule')
    test_case_0()
    print('Done')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:35.241289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:02:40.685050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('test')
    assert (strategy_module_0.tqm == 'test')
    assert (strategy_module_0.strategy == 'debug')


# Generated at 2022-06-25 12:04:01.245936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test StrategyModule.py: Success!")


# Generated at 2022-06-25 12:04:02.276973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:04:03.544910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:05.108163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    case 0:
    '''
    test_case_0()


# Generated at 2022-06-25 12:04:08.890094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# python -m pytest -s -v  -k "test_StrategyModule"
# nosetests --verbose --rednose -s -v strategy/test_debug
import unittest

# Generated at 2022-06-25 12:04:09.467499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:10.557712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule...")
    test_case_0()
    print("Passed")

test_StrategyModule()

# Generated at 2022-06-25 12:04:15.482184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# End of testing StrategyModule


# Generated at 2022-06-25 12:04:21.393036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('available_algorithms')
    assert strategy_module_0

## Unit test for execute_task_of_method_of_class_StrategyModule
#def test_execute_task_of_method_of_class_StrategyModule():
#    strategy_module_0 = StrategyModule('available_algorithms')
#    assert strategy_module_0


# Generated at 2022-06-25 12:04:22.081496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:07:28.052490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'available_algorithms'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0.debugger_active == True


# Check the return type of method execute in class StrategyModule

# Generated at 2022-06-25 12:07:29.696783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests to be written

# Generated at 2022-06-25 12:07:31.056764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:34.973072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(StrategyModule.__doc__)
    pp.pprint(StrategyModule.__init__.__doc__)
    pp.pprint(StrategyModule.__dict__)
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:36.991011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print ("Successful test_StrategyModule")
    except (IOError, TypeError, NameError):
        print ("Failed test_StrategyModule")

# Generated at 2022-06-25 12:07:37.858454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:07:38.555905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:07:39.661029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:41.699063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # testing for name
    test_case_0()

    # testing for debug_strategy
    test_case_1()

    # testing for check_args
    test_case_2()



# Generated at 2022-06-25 12:07:42.702155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv[1] = 'debug'
    test_case_0()
