

# Generated at 2022-06-25 11:58:17.557880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Global list of test cases
test_cases = [ test_case_0 ]

# Main execution of all test cases
for test_case in test_cases:
    test_case()

# Generated at 2022-06-25 11:58:22.033482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(10)

    # Verify constructor of class StrategyModule with CommandLineParseException as parameter
    # strategy_module_0 = StrategyModule(CommandLineParseException())
    # assert strategy_module_0.debugger_active == True

# Generated at 2022-06-25 11:58:25.106847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:27.006346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    test_case_0()


# Generated at 2022-06-25 11:58:28.738045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 1.0
    strategy_module_0 = StrategyModule(float_1)


# Generated at 2022-06-25 11:58:38.982889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import imp
    import os
    import shutil

    # create a temporary directory
    temp_path = os.path.realpath('temp')
    if os.path.exists(temp_path):
        shutil.rmtree(temp_path)
    os.makedirs(temp_path)

    # create a test module

# Generated at 2022-06-25 11:58:41.793957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    # case where float_0 is float in [1.0, inf]
    assert float_0 > -1
    assert float_0 <= 1.7976931348623157e+308


# Generated at 2022-06-25 11:58:42.515393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:44.068483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 11:58:44.983804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-25 11:58:51.210523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print('[-] Exception in test_StrategyModule: %s' % e)
        raise



# Generated at 2022-06-25 11:58:55.095448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
       constructor: __init__
    '''

    strategy_module_1 = StrategyModule()


# Generated at 2022-06-25 11:58:56.696738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:57.754443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-25 11:59:04.461621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active
    assert strategy_module.strategy == 'debug'
    assert strategy_module.host_states == {}
    assert strategy_module._host_states_cache == {}
    assert strategy_module.task_states == {}
    assert strategy_module.failed_hosts == {}
    assert strategy_module.run_state == 'pickle'


# Generated at 2022-06-25 11:59:06.651815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule test starts")
    test_case_0()
    print("StrategyModule test ends")

# main function to start unit test

# Generated at 2022-06-25 11:59:07.450188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:08.855027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True


# Generated at 2022-06-25 11:59:10.228529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 11:59:12.109454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule.py")
    #  Unit test for constructor of class StrategyModule
    test_case_0()
    print("Test run completed")



# Generated at 2022-06-25 11:59:15.698837
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 11:59:21.789838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # init
    TASK = {"action": {"__ansible_module__": "apt", "__ansible_arguments__": ["aptitude", "install", "cowsay"]}}
    TASK_RESULT = "dummy_task_result"
    VARIABLES = {"dummy_var_name0": "dummy_0", "dummy_var_name1": "dummy_1"}
    STRATEGY = "dummy_strategy"

    strategy_module_0 = StrategyModule(tqm=None)
    # method_name: set_options
    strategy_module_0.set_options(var_manager=None, forks=None, diff=None)

    # method_name: get_hosts
    retval_get_hosts_0 = strategy_module_0.get_hosts

# Generated at 2022-06-25 11:59:22.807520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:24.620940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NotImplementedError:
        return
    assert False

# Generated at 2022-06-25 11:59:29.352079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:30.843142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()

    assert(strategy_module_1 == strategy_module_1)
    assert(not (strategy_module_1 != strategy_module_1))



# Generated at 2022-06-25 11:59:33.919525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:59:41.155515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, LinearStrategyModule)
    assert isinstance(strategy_module_1, cmd.Cmd)
    assert isinstance(strategy_module_1, object)
    assert hasattr(strategy_module_1, 'debugger_active')
    assert strategy_module_1.debugger_active



# Generated at 2022-06-25 11:59:44.870684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()


# Generated at 2022-06-25 11:59:47.175581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check StrategyModule is object of class LinearStrategyModule
    assert StrategyModule.__bases__[0] == LinearStrategyModule


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:59:50.977532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("successfully run test case test_StrategyModule")

# Unit test entry
if __name__ == '__main__':
    # test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 11:59:55.304861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
    print("Done all Tests for class StrategyModule")

# Generated at 2022-06-25 11:59:56.139536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:00.786849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    for i in range(1, 13):
        strategy_module_0.run()

test_StrategyModule()

# Generated at 2022-06-25 12:00:04.374358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:06.315285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None


# Generated at 2022-06-25 12:00:07.021094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:11.852232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:00:13.022921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:13.675014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:17.905990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-25 12:00:19.605718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#def test_StrategyModule():
#    assert strategy_module_0.tqm == float_0


# Generated at 2022-06-25 12:00:20.611904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:24.472662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test of constructor')
    test_case_0()

# Generated at 2022-06-25 12:00:28.397076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0.tasks_this_run == list(), 'Attribute tasks_this_run of class StrategyModule is not initialized to empty list'
    assert strategy_module_0._tqm == float_0, 'Attribute _tqm of class StrategyModule is not initialized correctly'

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:31.331762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # unit test
    test_StrategyModule()

# Generated at 2022-06-25 12:00:34.182091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:40.821434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with no args
    strategy_module_0 = StrategyModule()

    # Test with invalid test_case
    try:
        test_case_0()
    except NameError as e:
        assert(e == NameError())
    except TypeError as e:
        assert(e == TypeError())
    except:
        print('Unexpected error: ', sys.exc_info()[0])


test_StrategyModule()

# Generated at 2022-06-25 12:00:41.409919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:44.330008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        print("\n")
        print("--- Testcase 0 ---")
        test_case_0()
    except:
        print("\nException caught in test_StrategyModule()")
        raise
    print("\n")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:54.687030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    the_input = 0
    try:
        test_case_0()
    except:
        the_input = -1
    if the_input == 0:
        True
    else:
        False

# Generated at 2022-06-25 12:00:58.220296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0_arg = 1.0
    strategy_module_0 = StrategyModule(float_0_arg)


# Generated at 2022-06-25 12:01:00.745361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:03.563070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor
    result = test_case_0()
    assert result is None, "Strategy module example failed"

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:01:06.560781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    assert((strategy_module_0.debugger_active == True))


# Generated at 2022-06-25 12:01:08.500932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    print(strategy_module_0)
    print(repr(strategy_module_0))
    return strategy_module_0



# Generated at 2022-06-25 12:01:12.782549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:01:14.313166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None

# Generated at 2022-06-25 12:01:16.839427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)

# Unit test of function push

# Generated at 2022-06-25 12:01:22.499784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 1.0
    strategy_module_1 = StrategyModule(float_1)
    assert strategy_module_1.tqm == 1.0
    assert strategy_module_1.inventory == None
    assert strategy_module_1.variable_manager == None
    assert strategy_module_1.loader == None
    assert strategy_module_1.options == None
    assert strategy_module_1.stdout_callback == None
    assert strategy_module_1.run_tree == False
    assert strategy_module_1.display == None
    float_2 = 1.0
    strategy_module_2 = StrategyModule(float_2)
    assert strategy_module_2.tqm == 1.0
    assert strategy_module_2.inventory == None
    assert strategy_module_2.variable_manager == None

# Generated at 2022-06-25 12:01:40.992540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:44.546554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    print('Testing StrategyModule_0')
    test_case_0()

# Unit testing the module
test_StrategyModule()

# Generated at 2022-06-25 12:01:47.538901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

__all__ = [
    'Debugger',
    'StrategyModule'
]

# Generated at 2022-06-25 12:01:48.921415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:52.397757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dump_list = [
        ('float_0', 1.0),
    ]
    strategy_module_0 = StrategyModule(dump_list[0][1])
    compare_values(dump_list[0][1], strategy_module_0.tqm)
    check_class_instance(strategy_module_0.tqm)


# Generated at 2022-06-25 12:01:53.096981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:53.844653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test framework

# Generated at 2022-06-25 12:01:56.836600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)

if __name__ == '__main__':
    # Running unit tests
    print('Testing ')
    test_case_0()
    print('Testing ')
    test_StrategyModule()
    print('Testing ')
    print('Everything passed')

# Generated at 2022-06-25 12:01:58.580470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0

    # Test case for method __init__
    def test_case_0():
        strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:02:02.650291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = strategy_module_0(float_0)


# Generated at 2022-06-25 12:02:51.977750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Not possible to pass cmd.Cmd()
    # strategy_module_0 = StrategyModule(cmd.Cmd())
    print("Not possible to pass cmd.Cmd()")
    # Not possible to pass pprint.PrettyPrinter()
    # strategy_module_0 = StrategyModule(pprint.PrettyPrinter())
    print("Not possible to pass pprint.PrettyPrinter()")
    # Not possible to pass sys.modules
    # strategy_module_0 = StrategyModule(sys.modules)
    print("Not possible to pass sys.modules")
    # Not possible to pass sys.stdin
    # strategy_module_0 = StrategyModule(sys.stdin)
    print("Not possible to pass sys.stdin")

# Generated at 2022-06-25 12:02:53.485080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:54.919417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:02:57.068723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with 1.0
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    assert(type(strategy_module_0) == StrategyModule)


# Generated at 2022-06-25 12:02:57.822320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:02:59.164806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:03:02.982748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:03:04.122649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:03:09.860212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    float_0 = float_0
    strategy_module_0.__init__(float_0)


# Generated at 2022-06-25 12:03:13.715145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Execute test cases
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:44.130930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-25 12:04:46.676849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    # Constructor for class StrategyModule
    '''

    # Test 0:
    print('\n***** test case 0 *****')
    test_case_0()



# Generated at 2022-06-25 12:04:48.069003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:49.324085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 1.0
    strategy_module_1 = StrategyModule(float_1)


# Generated at 2022-06-25 12:04:55.815085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {'variable_manager': {'extra_vars': {}},
                'get_vars': lambda x: mock_tqm['variable_manager']['extra_vars'],
                'host_key_checking': False, 
                'explicit_subset': [], 
                'inventory': 'MOCK_INVENTORY', 
                'pattern_cache': {},
                'display': {'verbosity': 2},
                'loader': {'_all_files': {}},
                '_restart_state': {}}
    strategy_module_0 = StrategyModule(mock_tqm)
    # Test: attr '_tqm' has value
    assert(strategy_module_0._tqm == mock_tqm)
    # Test: attr 'run

# Generated at 2022-06-25 12:04:56.467403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:57.530837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp_instance = StrategyModule(1.0)
    assert tmp_instance.debugger_active == True


# Generated at 2022-06-25 12:04:58.916904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:01.181888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(1.0)
    # Exception thrown when the current task is rescheduled
    # but no task is returned by the scheduler
    try:
        strategy_module_0.run()
    except Exception:
        pass


# Generated at 2022-06-25 12:05:01.617317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
