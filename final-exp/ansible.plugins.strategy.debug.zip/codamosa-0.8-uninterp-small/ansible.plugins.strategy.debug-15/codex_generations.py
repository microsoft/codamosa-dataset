

# Generated at 2022-06-25 11:58:20.655512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p1 = test_case_0()
    pprint.pprint(p1)

# Generated at 2022-06-25 11:58:22.328610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 11:58:25.194741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:26.535327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests for module

# Generated at 2022-06-25 11:58:27.342678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:33.324808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n\nUnit test for constructor of class StrategyModule')
    test_case_0()
    print('\n')

if __name__ == '__main__':
    test_StrategyModule()
    print('\n\nAll test cases have been passed')

# Generated at 2022-06-25 11:58:35.685915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 11:58:37.380995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")
        assert False
        

# Generated at 2022-06-25 11:58:38.685916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:39.416926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Generated at 2022-06-25 11:58:43.674696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0.debugger_active



# Generated at 2022-06-25 11:58:44.596566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 11:58:46.514952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    # System.out.println(float_0)
    return 'Success'


# Generated at 2022-06-25 11:58:51.716554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float)
    assert (strategy_module_0.debugger_active == True), "Failed to create StrategyModule with valid argument"


# Generated at 2022-06-25 11:58:53.144307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    print(strategy_module_0)

# Generated at 2022-06-25 11:58:55.456624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# pylint: disable=too-many-branches,too-many-statements,too-many-locals,too-many-return-statements,unused-argument

# Generated at 2022-06-25 11:58:57.081833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 11:58:58.822862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(test_case_0)



# Generated at 2022-06-25 11:59:01.812052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# if __name__ == "__main__":
#     test_StrategyModule()

# Generated at 2022-06-25 11:59:03.136151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Case 0
    test_case_0()



# Generated at 2022-06-25 11:59:06.096818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:07.663930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None, "StrategyModule_0"


# Generated at 2022-06-25 11:59:08.476268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:09.719245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Command line entry point

# Generated at 2022-06-25 11:59:10.526522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:12.777735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(int())

# def test_case_1():
#     print("unit test for function: test_case_1")
#     print("TODO: custom test")

# Generated at 2022-06-25 11:59:13.952991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:14.949271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 11:59:16.363450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 11:59:19.370959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0,StrategyModule)


# Generated at 2022-06-25 11:59:24.674982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:29.866820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module_1 = StrategyModule(tqm)


# Generated at 2022-06-25 11:59:34.171573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# now let's run it!
if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-25 11:59:34.961950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:40.692323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    test_case_0()


# Generated at 2022-06-25 11:59:42.169200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test case passed")



if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:42.784911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:43.912675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    assert isinstance(StrategyModule(3.14), StrategyModule)


# Generated at 2022-06-25 11:59:45.941946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        return False
    else:
        return True

if __name__ == "__main__":
    if test_StrategyModule():
        print("OK")
    else:
        print("FAIL")

# Generated at 2022-06-25 11:59:51.511916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule
    except NameError:
        print("Class StrategyModule not found.\n")
        print("Failed.\n")
    else:
        print("Passed.\n")


# Generated at 2022-06-25 12:00:06.515612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: check constructor
    test_case_0()


if __name__ == '__main__':
    import sys
    import unittest

    suite = unittest.TestSuite()

    suite.addTest(unittest.makeSuite(TestSample1))

    result = unittest.TextTestRunner().run(suite)
    if result.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-25 12:00:07.215606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:11.785033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0 is not None, "Could not construct object"


# Generated at 2022-06-25 12:00:12.475535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:13.613452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:00:14.226885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:15.350607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:00:18.385929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: add test
    pass



# Generated at 2022-06-25 12:00:19.770885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    run = False
    object_StrategyModule = StrategyModule(run)
    assert object_StrategyModule != False

# Generated at 2022-06-25 12:00:21.882946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    print('Testing constructor of class StrategyModule')
    test_case_0()


if __name__ == '__main__':
    print('Testing StrategyModule')
    test_StrategyModule()

# Generated at 2022-06-25 12:00:41.159371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_function = 'test_case_0'
    func_name = sys._getframe().f_code.co_name
    func_line_no = sys._getframe().f_lineno
    print("********** " + func_name + "(" + func_line_no + ") **********")
    test_case_0()

# Generated at 2022-06-25 12:00:43.020084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test entry point
if __name__ == "__main__":
    test_StrategyModule()
    print("Unittest completed successfully\n")

# Generated at 2022-06-25 12:00:48.379737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Test for the case where multiple hosts are run at the same time

# Generated at 2022-06-25 12:00:49.719023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:00:51.152289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.6531213584634595e+78
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0.tqm == float_0
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:00:54.026892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print(err)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:55.947531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    check_int(1, 1)


# Generated at 2022-06-25 12:00:59.401974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Type test for constructor of class StrategyModule")
    try:
        test_case_0()
    except:
        print("Unexpected exception")
        raise


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:00.872404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:09.207497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0
    test_case_0()
    # test_case_1
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 12:01:41.702700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    strategy_module_0.get_host_list()
    strategy_module_0.add_task(float_0)


# Generated at 2022-06-25 12:01:46.257898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:48.351025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)
    str(strategy_module_0)
    repr(strategy_module_0)
    strategy_module_0.execute()

# Generated at 2022-06-25 12:01:49.709124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = 1.0
    strategy_module_0 = StrategyModule(var_0)


# Generated at 2022-06-25 12:01:51.179513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError as name_error:
        print(str(name_error))
    else:
        print('ok')


# Generated at 2022-06-25 12:01:52.671749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()
    print('Unit test completed successfully.')

# Generated at 2022-06-25 12:01:53.333252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:58.045433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0.variable_manager == float_0.variable_manager, 'constructor of class StrategyModule failed: variable_manager'
    assert strategy_module_0.loader == float_0.loader, 'constructor of class StrategyModule failed: loader'
    assert strategy_module_0.inventory == float_0.inventory, 'constructor of class StrategyModule failed: inventory'
    assert strategy_module_0.tasks == [], 'constructor of class StrategyModule failed: tasks'
    assert strategy_module_0.notified_handlers == {}, 'constructor of class StrategyModule failed: notified_handlers'
    assert strategy_module_0.failures == 0, 'constructor of class StrategyModule failed: failures'
    assert strategy_

# Generated at 2022-06-25 12:01:59.356870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:02.863085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:03:18.002673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:21.883096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("==============Begin test for StrategyModule==============")
    test_case_0()
    print("==============End test for StrategyModule================")



# Generated at 2022-06-25 12:03:26.646414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)
    float_0 = 1.0
    assert strategy_module_0.run(float_0) is True


# Generated at 2022-06-25 12:03:32.235116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    test_args = [(float, 1.0)]
    test_returns = []
    test_case_0()
    '''
    StrategyModule(float, 1.0)

if __name__ == '__main__':
    import sys
    import re

    test_func = [
        (re.compile('^test_StrategyModule$'), test_StrategyModule),
    ]

    for test_tuple in test_func:
        if test_tuple[0].search(sys.argv[1]):
            test_tuple[1]()

# Generated at 2022-06-25 12:03:32.987809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:33.741499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:34.817498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:40.596306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global strategy_module_0

    test_case_0()
    print("Test case 0:", end = '')
    if strategy_module_0 is None:
        print("FAILED")
    else:
        print("PASSED")

test_StrategyModule()

# Generated at 2022-06-25 12:03:44.992830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(test_case_0.__name__)
    test_case_0()

test_arr = [
    test_StrategyModule
]

# Run all unit test

# Generated at 2022-06-25 12:03:46.792417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise Exception('Test case failed')
    else:
        print('Test case passed')

test_StrategyModule()

# Generated at 2022-06-25 12:06:35.585082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:39.400205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0, StrategyModule) is True

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:06:42.246550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    try:
        test_case_0()
    except:
        print('Exception caught in test_case_0')


if __name__ == "__main__":
    print('Testing the module')
    test_StrategyModule()

# Generated at 2022-06-25 12:06:43.165571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    StrategyModule(float_0)



# Generated at 2022-06-25 12:06:47.839688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("============================================================================================")
    print("============================================================================================")
    print("=================== Unit Testing for the function __init__ in class StrategyModule =========")
    print("============================================================================================")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
# Unit test


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:06:48.726107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:06:50.748956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError):
        StrategyModule(float_0)


# Generated at 2022-06-25 12:06:51.414177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test

# Generated at 2022-06-25 12:06:52.687445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:06:56.617754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    final_result = True
    test_case_0()
    if final_result:
        print("Test case passed successfully")
        return True

    else:
        print("Test case failed")
        return False

#Main
if __name__=="__main__":
    test_StrategyModule()
    print("StrategyModule class passed")