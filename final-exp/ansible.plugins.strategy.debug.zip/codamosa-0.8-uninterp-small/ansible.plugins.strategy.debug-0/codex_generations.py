

# Generated at 2022-06-25 11:58:14.810701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:16.925645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#  Local variables:
#  mode: python
#  python-indent: 4
#  tab-width: 4
#  indent-tabs-mode: nil
#  End:

# Generated at 2022-06-25 11:58:21.202572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0(strategy_module_0=strategy_module_0, float_0=float_0)


# Generated at 2022-06-25 11:58:22.328411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule(float(0))
    return



# Generated at 2022-06-25 11:58:25.779904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:26.678892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:27.438407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Generated at 2022-06-25 11:58:31.105189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:35.389188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    # catch *all* exceptions
    except Exception as e:
        # display *exception* type
        print('An exception of type {0} occurred.  Arguments:\n{1!r}'.format(type(e).__name__, e.args)); raise e


# Generated at 2022-06-25 11:58:36.276603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TestFunctionality()


# Generated at 2022-06-25 11:58:37.987721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:39.528155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    sys.exit(test_StrategyModule())

# Generated at 2022-06-25 11:58:42.346986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_0.debugger_active = True
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 11:58:43.897623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:48.626900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)
    # Check if true is returned as the result of constructor
    # create object of class StrategyModule and check if object created is not null
    assert strategy_module_0 is not None
    # Check if type of object is type(strategy_module_0)
    if isinstance(strategy_module_0, StrategyModule):
        print("StrategyModule")
    else:
        print("StrategyModule fail")



# Generated at 2022-06-25 11:58:51.906283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_cases = [
        0,
    ]
    for test_case in test_cases:
        if test_case == 0:
            test_case_0()



# Generated at 2022-06-25 11:58:55.428206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:57.039095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 11:59:01.121037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)

print()
print(sys.version)
print()

# Run unittests

# Generated at 2022-06-25 11:59:02.213377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:06.406093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert(strategy_module_0.running == False)

# unit test for method StrategyModule::run()

# Generated at 2022-06-25 11:59:10.217132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        print('FAILED: test_case_0()')
    print('SUCCESS: StrategyModule class')

if __name__ == '__main__':
    print('Running tests for StrategyModule.py')
    test_StrategyModule()
    print('Tests completed for StrategyModule.py')

# Generated at 2022-06-25 11:59:11.511347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:13.716184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 11:59:14.529577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:19.236527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    if not strategy_module_0.get_variable('name'):
        print("0")
    else:
        print("1")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:59:22.534829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:23.443955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:24.621923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:59:29.341859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:34.015804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['10.92.53.77','10.92.53.78','10.92.53.79','10.92.53.80','10.92.53.81']
    test = StrategyModule(host_list)
    assert len(test.tqm) == len(host_list)

# Generated at 2022-06-25 11:59:40.024514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockAnsibleTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-25 11:59:45.950731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Call the constructor of class StrategyModule
        test_StrategyModule_0 = StrategyModule( )

        # Verify test_StrategyModule_0 is a StrategyModule object
        assert(isinstance(test_StrategyModule_0, StrategyModule))

    except Exception:
        print('There is a problem with your test_StrategyModule() function')


# Generated at 2022-06-25 11:59:50.695516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # unit test for constructor of class StrategyModule
    strategyModule = StrategyModule(tqm=None)


# Generated at 2022-06-25 12:00:01.027301
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:00:05.363425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__') and callable(StrategyModule.__init__)
    try:
        obj_0 = StrategyModule()
    except Exception as ex:
        assert isinstance(ex, TypeError)
        assert str(ex) == "__init__() missing 1 required positional argument: 'tqm'"
    obj_0 = StrategyModule(float_0)
    assert isinstance(obj_0, StrategyModule)


# Generated at 2022-06-25 12:00:09.361749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize class StrategyModule
    tqm = mago
    StrategyModule_instance0 = StrategyModule(tqm)
    float_0 = float_0
    # Assert instance variables
    tqm = StrategyModule_instance0.tqm
    assert tqm == mago
    # Assert instance variable
    StrategyModule_instance0.test_case_0()
    pass # test method with arguments


# Generated at 2022-06-25 12:00:11.147659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    obj = StrategyModule(tqm)
    assert isinstance(obj, StrategyModule)
    assert isinstance(obj, LinearStrategyModule)
    assert isinstance(obj, object)


# Generated at 2022-06-25 12:00:14.085374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  try:
    tqm = None
    StrategyModule(tqm)
    test_case_0()
  except:
    import traceback,sys
    info = sys.exc_info()
    print (info[0],info[1])
    traceback.print_tb(info[2])

if __name__ == '__main__':
  test_StrategyModule()

# Generated at 2022-06-25 12:00:18.718490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    print('sm:', sm)
    assert sm is not None, "StrategyModule.get failed"


# Generated at 2022-06-25 12:00:26.206515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    num_0 = 8
    num_1 = 7
    tqm = None
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-25 12:00:30.630218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_strategy = StrategyModule("tqm")
    assert ansible_strategy.debugger_active == True


# Generated at 2022-06-25 12:00:34.381941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    test_case_0()


# Generated at 2022-06-25 12:00:38.069927
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:00:41.343006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_0 = StrategyModule(None)

'''
if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()
'''

# Generated at 2022-06-25 12:00:42.394625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-25 12:00:43.611936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    if (stm is None):
        pass
    pass


# Generated at 2022-06-25 12:00:49.032015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    in_q = None
    host_q = None
    tqm = None
    test_obj = StrategyModule(tqm)
    assert test_obj


# Generated at 2022-06-25 12:00:54.564675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule

# Generated at 2022-06-25 12:00:57.920812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'YW8'
  StrategyModule(tqm)

 

# Generated at 2022-06-25 12:01:05.480680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case for test_case_0
    float_0 = -2119.0
    # Expected Output:
    
    test_case_0()
    print('test case 0 finished')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:06.963165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule("tqm")


# Generated at 2022-06-25 12:01:15.734498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()

# Generated at 2022-06-25 12:01:18.413688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_case_0()

    test_StrategyModule = StrategyModule(tqm)


# Generated at 2022-06-25 12:01:19.866471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    term = MockTerminal()
    tqm = MockTaskQueueManager(term.load_fragment)
    StrategyModule(tqm)


# Generated at 2022-06-25 12:01:22.143991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test-0")
    print("test_StrategyModule")
    float_0 = -2119.0
    print("test-1")
    return (float_0)


# Generated at 2022-06-25 12:01:27.298034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a HashTable
    obj = StrategyModule(1.0)
    obj.__init__(StrategyModule(1.0))
    assert 1.0 == obj.tqm



# Generated at 2022-06-25 12:01:38.428408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.utils.display import Display
    import contextlib
    import io
    import tempfile
    import sys
    import unittest

    # unit test for default constructor
    print(StrategyModule.__doc__)
    with tempfile.NamedTemporaryFile(mode='a+t') as stdout, tempfile.NamedTemporaryFile(mode='a+t') as stderr:
        sys.stdout = stdout
        sys.stderr = stderr
        strategy_module = StrategyModule(None)
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        print('Stdout: ' + stdout.read())

# Generated at 2022-06-25 12:01:44.882272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTaskQueueManager():
        def __init__(self):
            self.stats = ""
            self.hostvars = ""
            self.verbose = ""
            self.log_only = ""
            self.run_additional_callbacks = ""
            self.run_handlers = ""
            self.result_callback = ""
            self.async_seconds = ""
            self.async_poll_interval = ""
            self.flush_cache = ""
            self.dump_callbacks = ""
            self.remote_user = ""
            self.remote_pass = ""
            self.timeout = ""
            self.tree = ""
            self.module_path = ""
            self.forks = ""
            self.become = ""
            self.become_method = ""

# Generated at 2022-06-25 12:01:53.307341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -0.0
    float_1 = -100.4
    float_1 = 15.0
    float_2 = -0.0894
    float_3 = -0.0
    float_4 = -2119.0
    float_5 = -2119.0
    float_6 = -2119.0
    float_7 = -0.0
    float_8 = -0.0
    float_9 = -0.0
    float_10 = -2119.0
    float_11 = -0.0
    float_12 = -100.4
    float_13 = -100.4
    float_14 = -100.4
    float_15 = -0.0
    float_16 = -2119.0
    float_17 = -100.4
    float_18

# Generated at 2022-06-25 12:01:59.646427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_test = StrategyModule(4.4)
    assert my_test.tqm == 4.4

# Generated at 2022-06-25 12:02:03.071381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 3373.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:02:04.036794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)



# Generated at 2022-06-25 12:02:05.330717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:02:06.256893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:10.609971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call all the test cases in this class
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:13.576161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 668.0
    strategy_module_0 = StrategyModule(float_0)

    assert strategy_module_0 is not None
    assert strategy_module_0.tqm is not None
    assert strategy_module_0.tqm._internal_stats == {}
    assert isinstance(strategy_module_0.tqm, float)

    assert strategy_module_0.debugger_active == True

# Generated at 2022-06-25 12:02:14.183026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:15.456226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # scalar test
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:20.830232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:31.895775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(strategy_module_1)


# Generated at 2022-06-25 12:02:33.200914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)

test_StrategyModule()

# Generated at 2022-06-25 12:02:34.324140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


sys.exit(0)

# Generated at 2022-06-25 12:02:34.988654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-25 12:02:36.211251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test class StrategyModule

# Generated at 2022-06-25 12:02:40.867942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_0 = StrategyModule(None)
    test_case_0()

# Test cases for method get_host_list

# Generated at 2022-06-25 12:02:43.608718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test 01 - If StrategyModule is defined")
    assert 'StrategyModule' in globals() or 'StrategyModule' in locals()


# Generated at 2022-06-25 12:02:46.510545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0 == None


# Generated at 2022-06-25 12:02:54.405522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = -2119.0
    strategy_module_1 = StrategyModule(float_1)
    assert(strategy_module_1._final_q.empty())
    assert(not strategy_module_1._failed_hosts)
    assert(not strategy_module_1._unreachable_hosts)
    assert(not strategy_module_1.debugger_active)
    assert(not strategy_module_1.get_host_list())
    assert(not strategy_module_1.get_original_task_list())
    assert(not strategy_module_1.get_task_list())
    assert(not strategy_module_1.get_next_task_lock())


# Generated at 2022-06-25 12:02:54.884613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:19.342007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor of class StrategyModule')
    try:
        test_case_0()
        print('Successfully ran test case 0')
    except Exception as e:
        print('Failed to run test case 0')
        print(e)

# Test cases for todo

# Generated at 2022-06-25 12:03:21.699582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:23.011272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:03:26.949255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main function for the test

# Generated at 2022-06-25 12:03:27.438382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:03:29.018360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:03:30.099516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert type(StrategyModule(1)) == StrategyModule


# Generated at 2022-06-25 12:03:36.031111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 12:03:37.967232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:40.349986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:23.825579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:26.132996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:26.817298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:27.926532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:04:28.932960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:34.068203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2088.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:04:34.533078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:04:35.090911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:35.641084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:04:36.603938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:06:06.402403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0.debugger_active == False

# Generated at 2022-06-25 12:06:07.581129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # First test case
  assert test_case_0() == None


# Generated at 2022-06-25 12:06:08.304030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:06:09.676783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:10.704159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None


# Generated at 2022-06-25 12:06:12.383692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2119.0
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0.debugger_active == True

# Generated at 2022-06-25 12:06:14.945660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Exception caught by constructor test")


# Generated at 2022-06-25 12:06:15.549860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:17.174845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for StrategyModule. Constructor.")
    test_case_0()


if __name__ == '__main__':
    print("Running unit tests...")
    test_StrategyModule()

# Generated at 2022-06-25 12:06:18.405574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


test_StrategyModule()