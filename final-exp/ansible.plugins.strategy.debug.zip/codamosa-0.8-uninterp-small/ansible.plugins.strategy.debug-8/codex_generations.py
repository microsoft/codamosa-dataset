

# Generated at 2022-06-25 11:58:21.100203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 11:58:21.836163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:22.645131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:25.220244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:26.825613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:32.459940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(sys.argv) == 2
    try:
        int_0 = int(sys.argv[1])
    except:
        print("Parameter Error")
        return
    if int_0 == 0:
        test_case_0()
    elif int_0 == 1:
        test_case_1()
    elif int_0 == 2:
        test_case_2()
    elif int_0 == 3:
        test_case_3()
    elif int_0 == 4:
        test_case_4()
    elif int_0 == 5:
        test_case_5()
    else:
        print("Parameter Error")
        return
    print("Success")


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:35.388769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    assert(isinstance(strategy_module_0, StrategyModule))



# Generated at 2022-06-25 11:58:36.270481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:37.283868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:38.054882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:39.901769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:42.482376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:44.047431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 11:58:45.651235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:50.228210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 11:58:51.093925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:55.095634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# vim: ansible-vim-v0.2.25

# Generated at 2022-06-25 11:58:56.977300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests for importing the module

# Generated at 2022-06-25 11:58:58.798700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 11:58:59.795438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:04.372214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except NameError as e:
        if 'global name' not in str(e) or 'is not defined' not in str(e):
            raise(e)


# Generated at 2022-06-25 11:59:06.098421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 11:59:08.299819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 11:59:12.153201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.debugger_active = True
    strategy_module_0.display()
    assert(strategy_module_0.DEBUGGER_VERSION == "1.0")

# TODO: generate a test case, by loading a task file

# TODO: generate a test case, by loading a playbook file

# Generated at 2022-06-25 11:59:12.968263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:15.086061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_case_0()
    print('STRATEGY MODULE FUNCTIONAL TEST 0 DONE')

# Generated at 2022-06-25 11:59:16.407117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:19.175592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule_test_cases
    StrategyModule_test_cases = [
        {
            'name': 'test_case_0',
            'test_func': test_case_0
        }
    ]

    for test_case in StrategyModule_test_cases:
        test_case.get('test_func')()

# Generated at 2022-06-25 11:59:22.845974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

main = test_StrategyModule

# Generated at 2022-06-25 11:59:24.663132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:27.316845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test case 0: " + strategy_module_0)



# Generated at 2022-06-25 11:59:28.170481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:29.866921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:59:34.182516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("")
    print("Testing constructor of class StrategyModule.")
    test_case_0()
    print("Completed testing constructor of class StrategyModule.")
    print("")


# Generated at 2022-06-25 11:59:35.466480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('test_StrategyModule completed!')


# Generated at 2022-06-25 11:59:39.954016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test empty constructor
    test_case_0()

# Run the unit tests
test_StrategyModule()

# Generated at 2022-06-25 11:59:42.494852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, LinearStrategyModule)
    assert isinstance(strategy_module_0.tqm, object)



# Generated at 2022-06-25 11:59:43.968502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _play_context = None
    _display = None
    _shared_loader_obj = None
    _variable_manager = None

    test_case_0()

# Generated at 2022-06-25 11:59:44.561273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:45.585810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test: constructor with no arguments")
    test_case_0()



# Generated at 2022-06-25 11:59:50.034471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:59:51.815240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    command_0 = "python -m unittest tests/unit/strategy/test_strategy_debug.py"
    assert sys.argv[1] == "-t", command_0
    
    test_case_0()

# Generated at 2022-06-25 11:59:54.718536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)

# Generated at 2022-06-25 11:59:56.218747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

    assert(strategy_module is not None)


# Generated at 2022-06-25 12:00:00.484794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("<DESCRIBE::> test_StrategyModule")
    test_case_0()
    print("<COMPLETEDIN::>")

test_StrategyModule()

# Generated at 2022-06-25 12:00:04.374358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(tqm)
    assert strategy_module_0 != None


# Generated at 2022-06-25 12:00:05.640089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:06.509417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule)


# Generated at 2022-06-25 12:00:07.747379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:00:12.344792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()
    # print('Test')

# Generated at 2022-06-25 12:00:18.073677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:19.826871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test constructor of class StrategyModule"""
    strategy_module_0 = StrategyModule(tqm=tqm)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:00:24.382624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor 1
    test_case_0()


# Generated at 2022-06-25 12:00:25.741945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:30.248364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:34.826183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up test cases

    # Set up mock objects

    # Run test

    # Assert

    # Return
    return



# Generated at 2022-06-25 12:00:38.921251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class FakeTQM:
            pass

        fake_tqm = FakeTQM()
        sm = StrategyModule(fake_tqm)
        assert sm.debugger_active == True
    except:
        raise AssertionError("Error: test_StrategyModule")

test_case_0()



# Generated at 2022-06-25 12:00:41.083667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:42.871046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as ex:
        assert False, "%s" % (ex)
# -----------------------------------------------------------------------


# Generated at 2022-06-25 12:00:51.195623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.get_host_list()
    strategy_module_0.get_next_task_lock()
    strategy_module_0.run()
    strategy_module_0.run_once()
    strategy_module_0.cleanup()
    strategy_module_0.add_tasks()
    strategy_module_0.wait_on_pending_results()


# Generated at 2022-06-25 12:01:03.194154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        bool_0 = None
        strategy_module_0 = StrategyModule(bool_0)
        test_case_0()
    except Exception as e:
        print("TEST FAILED: " + str(e))

test_StrategyModule()

# Generated at 2022-06-25 12:01:04.135616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass


# Generated at 2022-06-25 12:01:07.161784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    assert(strategy_module_0.debugger_active == True)

# Generated at 2022-06-25 12:01:08.235542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:08.898269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:13.323583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        raise AssertionError('Failed to execute test case 0')

# Unit tests for class StrategyModule

# Generated at 2022-06-25 12:01:14.470239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:01:19.602646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test for line_number_0
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)

    # test for line_number_1
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)

#Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:01:21.434058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("All test cases passed")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:23.234538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)



# Generated at 2022-06-25 12:01:40.646179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:42.440467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # No exception should be raised
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-25 12:01:46.707634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(Exception):
        StrategyModule(None)


# Generated at 2022-06-25 12:01:47.499602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:48.884689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Unit test of entry_point in class StrategyModule

# Generated at 2022-06-25 12:01:51.598980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a TaskQueueManager instance of class TaskQueueManager for testing
    tqm_0 = TaskQueueManager(bool_0)
    # Create an instance of class StrategyModule for testing
    strategy_module_0 = StrategyModule(tqm_0)


# Generated at 2022-06-25 12:01:52.992465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:54.084458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = None
    test_case_0()


# Generated at 2022-06-25 12:01:58.821110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    test_case_0()
    print('Done testing constructor of class StrategyModule')   



# Generated at 2022-06-25 12:02:02.390448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:39.887583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:41.543226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:02:45.336546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0.tqm is None
    assert not strategy_module_0.debugger_active

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:02:47.039994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    return 0

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:02:51.189342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0.debugger_active, bool)


# Generated at 2022-06-25 12:02:53.916350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:02:54.742774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:57.990529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Instance of class StrategyModule
    strategy_module_0 = StrategyModule(bool_0)

    # Verify the parent class of strategy_module_0 is LinearStrategyModule.
    assert isinstance(strategy_module_0, LinearStrategyModule) is True
    assert isinstance(strategy_module_0, object) is True


# Generated at 2022-06-25 12:02:59.237401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 12:02:59.902677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:04:16.196587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:04:17.202010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:22.782823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with None as argument
    test_case_0()

    # Test with obj as argument
    test_case_1()

    # Test with dict as argument
    test_case_2()


test_StrategyModule()



# Generated at 2022-06-25 12:04:24.162039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:26.179279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:04:27.256037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:04:27.805697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:28.807939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = None
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:04:29.439143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:04:37.869024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock task queue manager
    tqm = None

    # Create a mock connection which just returns a host for every host.
    # This is enough for our debugger, which only cares about the current
    # task and the vars of the current host.
    class MockConnection(object):
        def __init__(self, host):
            self.host = host

        def get_host(self):
            return self.host
    tqm.get_connection = MockConnection

    strategy_module_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:07:29.780872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Unit Test for constructor of class StrategyModule: Success")

    except AssertionError:
        print("Unit Test for constructor of class StrategyModule: Failed")



# Generated at 2022-06-25 12:07:30.663246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:07:31.581585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Unit test to check the functionality of class StrategyModule

# Generated at 2022-06-25 12:07:32.190639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:07:33.207371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test: StrategyModule.")


# Generated at 2022-06-25 12:07:34.619910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:07:35.959630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    strategy_module_0 = StrategyModule(None)

# Generated at 2022-06-25 12:07:37.970261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = None
    strategy_module_1 = StrategyModule(bool_1)
    assert strategy_module_1.tqm == None


test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:07:39.986251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = StrategyModule.debugger
    bool_0 = StrategyModule.debugger_active
    test_case_0()

if __name__ == '__main__':
    debug = StrategyModule()
    debug.cmdloop()

# Generated at 2022-06-25 12:07:40.614937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
