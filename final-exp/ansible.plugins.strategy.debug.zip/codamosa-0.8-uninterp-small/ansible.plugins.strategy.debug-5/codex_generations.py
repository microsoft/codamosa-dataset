

# Generated at 2022-06-25 11:58:20.602579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:22.166487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

    return strategy_module_0



# Generated at 2022-06-25 11:58:29.417832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    set_0 = set()
    # Act
    strategy_module_0 = StrategyModule(set_0)
    # Assert
    assert isinstance(strategy_module_0, StrategyModule), \
            "return value of StrategyModule.__init__() is not an instance of StrategyModule"
    assert isinstance(strategy_module_0.host, dict), \
            "value of StrategyModule.host is not an instance of dict"


# Generated at 2022-06-25 11:58:31.314124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:32.740622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated test cases for method run on class StrategyModule

# Generated at 2022-06-25 11:58:35.652638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active == True



# Generated at 2022-06-25 11:58:36.544320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass



# Generated at 2022-06-25 11:58:38.171312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:39.416996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:40.405257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:42.346270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:46.603803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0.tqm, set)
    assert isinstance(strategy_module_0.debugger_active, bool)
    assert strategy_module_0.tqm == set_0
    assert strategy_module_0.debugger_active == True
# End of test case 0


# Generated at 2022-06-25 11:58:48.350575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)
    assert(strategy_module_1.tqm == set_1)


# Generated at 2022-06-25 11:58:50.949912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:51.753438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:55.611434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    set_0.add(strategy_module_0)
    assert len(set_0) == 1
    assert strategy_module_0.debugger_active == True

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 11:59:01.120805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_2 = set()
    assert len(set_2) == 0
    strategy_module_3 = StrategyModule(set_2)
    assert len(set_2) == 0
    assert strategy_module_3.debugger_active == True
    assert isinstance(strategy_module_3, LinearStrategyModule)


# Generated at 2022-06-25 11:59:02.605529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# To generate tests against above units

# Generated at 2022-06-25 11:59:04.242169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 11:59:06.305693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Run unit tests
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:08.081820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:08.853926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:10.401278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert False

# Generated at 2022-06-25 11:59:12.004620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test case 0
    test_case_0()


# Generated at 2022-06-25 11:59:14.741276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module_0 = StrategyModule()
    except TypeError:
        strategy_module_0 = StrategyModule()
        assert strategy_module_0.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-25 11:59:16.147045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:16.904488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:17.623741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

print('Testing complete')

# Generated at 2022-06-25 11:59:18.316800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:23.409211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert isinstance(strategy_module_0, StrategyModule)



# Generated at 2022-06-25 11:59:29.665240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0.debugger_active == True, \
        "strategy_module_0.debugger_active != True"
    assert isinstance(strategy_module_0,
                      StrategyModule) or strategy_module_0 is None, \
        "strategy_module_0 is not of class StrategyModule"
    assert strategy_module_0 == strategy_module_0 or \
        strategy_module_0 is None, \
        "strategy_module_0 != strategy_module_0"


# Generated at 2022-06-25 11:59:33.299429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:34.680499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0.tqm is None


# Generated at 2022-06-25 11:59:35.441617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(__doc__)
    print(StrategyModule.__doc__)



# Generated at 2022-06-25 11:59:36.645018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1.debugger_active == True

# Generated at 2022-06-25 11:59:37.813243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for StrategyModule")
    test_case_0()
    return 0


# Generated at 2022-06-25 11:59:38.749618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:59:40.479478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NotImplementedError:
        print('NotImplementedError')
    
test_StrategyModule()

# Generated at 2022-06-25 11:59:41.023957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:46.535847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Error in test_case_0()")

__all__ = ["test_StrategyModule"]

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:49.658122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert type(strategy_module_0) is StrategyModule


# Generated at 2022-06-25 11:59:51.171974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:58.468714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        sys.exit(0)
    except SystemExit as e:
        if not e.code == 0:
            sys.exit(1)
    except Exception as e:
        print('FAIL: Caught unexpected exception: {}'.format(e))
        sys.exit(1)
    else:
        print('PASS: StrategyModule()')
    sys.exit(0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:59.322356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:01.206208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    test case : test_StrategyModule

    :return: Nothing
    """
    test_case_0()


# Generated at 2022-06-25 12:00:05.092830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:06.248699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        raise



# Generated at 2022-06-25 12:00:06.958250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    assert True



# Generated at 2022-06-25 12:00:09.276262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    task_buffer_0 = strategy_module_0.task_buffers[None]
    assert task_buffer_0.__class__.__name__ == 'TaskBuffer'


# Generated at 2022-06-25 12:00:09.897078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:13.868548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import DebugStrategyModule
    strategy_module_0 = DebugStrategyModule()
    assert (strategy_module_0.__class__.__name__ == 'DebugStrategyModule')


# Generated at 2022-06-25 12:00:14.513014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()



# Generated at 2022-06-25 12:00:19.214729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule
    # Debugger is activated
    assert(strategy_module_0.debugger_active == True)



# Generated at 2022-06-25 12:00:20.502361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Tear down the unit test

# Generated at 2022-06-25 12:00:24.467602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(tqm)


# Generated at 2022-06-25 12:00:26.379238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    strategy_module_2 = StrategyModule()


# Generated at 2022-06-25 12:00:28.126704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-25 12:00:30.710470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    strategy_module_0.run()

# Generated at 2022-06-25 12:00:34.110399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:36.505935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:00:42.507156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0.debugger_active



# Generated at 2022-06-25 12:00:43.465747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.debugger_active is True


# Generated at 2022-06-25 12:00:48.024876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None


# Generated at 2022-06-25 12:00:49.918272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(tqm=None)

    
if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-25 12:00:50.914259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:52.611588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Global variable for the main method
tqm = 1


# Generated at 2022-06-25 12:00:54.121208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Debugger Shell

# Generated at 2022-06-25 12:00:57.842333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(getattr(StrategyModule, '__init__'))


# Generated at 2022-06-25 12:01:02.578470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nUnit test for constructor of class StrategyModule')
    test_case_0()




if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 12:01:06.176027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    # The line below is equivalent to:
    #    strategy_module_0 = StrategyModule()
    assert strategy_module_0 is not None

# Generated at 2022-06-25 12:01:12.365056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:16.741096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=unused-variable
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    if (strategy_module_0.debugger_active != True):
        raise ValueError('AssertionError')


# Generated at 2022-06-25 12:01:18.786920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("fail")
        print(e)

# Generated at 2022-06-25 12:01:20.143107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test constructor')
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)



# Generated at 2022-06-25 12:01:24.343697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    pprint.pprint(strategy_module_0)
    pprint.pprint(strategy_module_0.__dict__)
    set_1 = set()
    pprint.pprint(set_1)



# Generated at 2022-06-25 12:01:28.853417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(set())
    set_1 = set()
    strategy_module_0 = StrategyModule(set_1)


# Generated at 2022-06-25 12:01:30.159142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:01:31.414540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:01:32.916164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_1 = StrategyModule(set_0)
    return strategy_module_1


# Generated at 2022-06-25 12:01:36.090952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test 1: Test the constructor of class")
    test_case_0()
    print("Test 1: Test case passed")
    print("------------------------------------------")


# Generated at 2022-06-25 12:01:46.896762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:48.571886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Testing
    test_StrategyModule()

# Generated at 2022-06-25 12:01:49.637477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:01:50.412314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:54.201407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:01:55.395427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Success!")
    except:
        print("Failure!")


# Generated at 2022-06-25 12:01:55.941435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:59.287264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Collect command-line arguments.

# Generated at 2022-06-25 12:02:08.473037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    list_0 = list()
    def func_0(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8, arg_9):
        list_0.append(arg_0)
        list_0.append(arg_1)
        list_0.append(arg_2)
        list_0.append(arg_3)
        list_0.append(arg_4)
        list_0.append(arg_5)
        list_0.append(arg_6)
        list_0.append(arg_7)
        list_0.append(arg_8)
        list_0.append(arg_9)

    set_0 = set()

# Generated at 2022-06-25 12:02:09.257957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

# Generated at 2022-06-25 12:02:32.006187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:33.311385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("# Test_case 0: Test constructor")
    # test_case_0()
    print("Well done !")

test_StrategyModule()

# Generated at 2022-06-25 12:02:34.722629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:02:36.183071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:40.291521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Run test case
    test_case_0()


# Generated at 2022-06-25 12:02:44.815162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    pprint.pprint(strategy_module_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()



# Generated at 2022-06-25 12:02:46.739812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:02:47.856276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:02:51.099343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

# Generated at 2022-06-25 12:02:52.911382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main entry point for module execution

# Generated at 2022-06-25 12:03:35.018419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Show how to use the debugger

# Generated at 2022-06-25 12:03:37.631619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:38.317366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:40.722828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:03:44.830596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # Unit test
    test_StrategyModule()

# Generated at 2022-06-25 12:03:45.940666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:03:47.247841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:03:48.274550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()

# Main function.

# Generated at 2022-06-25 12:03:50.541601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Failed to test_case_0: %s" % str(e))
    try:
        set_0 = set()
        strategy_module_0 = StrategyModule(set_0)
    except:
        assert False


# Generated at 2022-06-25 12:03:56.802806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert isinstance(strategy_module_0, StrategyModule) is True
    assert isinstance(strategy_module_0, LinearStrategyModule) is True
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:05:27.216399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Execute test code
if __name__ == "__main__":
    test_StrategyModule()
    pass

# Generated at 2022-06-25 12:05:28.689926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:05:29.481174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    test_case_0()



# Generated at 2022-06-25 12:05:30.064004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:31.037110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(set())
    assert not hasattr(strategy_module_0, 'TEST')

# Generated at 2022-06-25 12:05:32.253114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(strategy_module_0)
    print('unit test of class StrategyModule: ')
    #print(strategy_module_0.get_host_list)


# Generated at 2022-06-25 12:05:33.253643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:05:35.223351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert(strategy_module_0)
    assert(strategy_module_0.tqm == set_0)
    assert(strategy_module_0.debugger_active == True)



# Generated at 2022-06-25 12:05:35.891837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:05:36.396586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
