

# Generated at 2022-06-25 11:58:20.364212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:22.166340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 11:58:30.745788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Assert equality
# assert m == n
# Assert inequality
# assert m != n
# Assert less than or equal
# assert m <= n
# Assert less than
# assert m < n
# Assert greater than or equal
# assert m >= n
# Assert greater than
# assert m > n

# Test if a condition is true
# if m:
#     ...

# Test if a condition is false
# if not m:
#     ...

# Test if two references refer to the same object
# if m is n:
#     ...

# Test if two references do not refer to the same object
# if m is not n:
#     ...

# Generated at 2022-06-25 11:58:37.381221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0.tqm == str_0
    assert strategy_module_0.run_once
    assert strategy_module_0.serial == 0
    assert strategy_module_0.pool is None
    assert strategy_module_0.display is None
    assert strategy_module_0.tqm_vars is None
    assert not strategy_module_0.debugger_active


# Generated at 2022-06-25 11:58:38.685872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # A constructor for a class named StrategyModule
    test_case_0()


# Generated at 2022-06-25 11:58:39.418216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:47.602981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.color import ANSIBLE_COLOR
    from ansible.parsing.dataloader import DataLoader

    import os
    import random
    import string

    def generate_random_string(length):
        random_characters = string.ascii_letters + string.digits
        return ''.join(random.choice(random_characters) for i in range(length))

    # Generate the test data
    random_string_0 = generate_random_string(random.randint(1, 10))
    random_string_1 = generate_random_string(random.randint(1, 10))
    random_string_2 = generate_random_string(random.randint(1, 10))
    random_string_3 = generate_random_string(random.randint(1, 10))
    random

# Generated at 2022-06-25 11:58:48.428910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor StrategyModule')
    test_case_0()


# Generated at 2022-06-25 11:58:54.150624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cmd_0 = '\n\n\t)l\t\n'
    cmd_1 = '\t\n\t\n\n\\'
    host_state_0 = '\n\t\n\t'
    result_0 = '\n\n\n\t\n\n\n\t\n\t\n\t'
    inventory = '\n\n\t\n\t\n\n\n\n\n\n\n\n'
    task_0 = '\n\t\n\n;'
    task_1 = '\n\t\n\t\n\t\n\t\n\n\n\t\n\t'

# Generated at 2022-06-25 11:59:01.006422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cmd_0 = cmd.Cmd()
    pprint_0 = pprint.pprint()
    sys_0 = sys.stdin
    strategy_module_0 = StrategyModule(cmd_0)
    str_0 = '%c\x04\x87\x80B\x04|\x1eI\x04\xe9\n\nM\x03\x82'
    str_1 = '\x0b\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19'

# Generated at 2022-06-25 11:59:03.933526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# main function for unit test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:05.482127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Test class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 11:59:08.007467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test case 0
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 11:59:08.779414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:09.556108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-25 11:59:10.600901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(object), StrategyModule)


# Generated at 2022-06-25 11:59:18.190501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_1 = StrategyModule(str_1)
    assert isinstance(strategy_module_1.tqm, str)
    assert isinstance(strategy_module_1.run_handlers, bool)
    assert isinstance(strategy_module_1.legacy_playbook, bool)
    assert isinstance(strategy_module_1.builtin_basedir, str)
    assert strategy_module_1.tqm == str_1
    assert not strategy_module_1.run_handlers and not strategy_module_1.legacy_playbook
    assert strategy_module_1.builtin_basedir == '/home/joe/ansible/lib/ansible/modules/extras'

# Generated at 2022-06-25 11:59:23.596230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(tqm_0)


# Generated at 2022-06-25 11:59:24.782022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Basic test for constructor of class cmd.Cmd

# Generated at 2022-06-25 11:59:30.087524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_course = [
    test_StrategyModule,
]

for test in test_course:
    test()

# Generated at 2022-06-25 11:59:32.895991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test runner

# Generated at 2022-06-25 11:59:34.035636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = True
    try:
        test_case_0()
    except:
        result = False
    assert result


# Generated at 2022-06-25 11:59:40.311535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
    except Exception as ex:
        print("Failed", ex)
    else:
        print("Passed")


# Generated at 2022-06-25 11:59:42.357146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pprint.pprint("test_StrategyModule")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 11:59:44.960863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:46.305116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:48.003213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # There is not a return value for constructor of class StrategyModule
    # Assertion
    assert test_case_0()


# Generated at 2022-06-25 11:59:50.019813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests using Python assert statement
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 11:59:50.697208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:56.297075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    @add_decorator(param1, param2)
    def function_0():
        return function_0
    strategy_module_0 = StrategyModule(function_0)
    str_0 = strategy_module_0.run()
    unit_test.assert_equals(str_0, None)


# Generated at 2022-06-25 12:00:00.598720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("[+] test_case_0 finished")
    except:
        print("[-] test_case_0 aborted")
        raise



# Generated at 2022-06-25 12:00:07.423453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)

    except AssertionError as e:
        print(e)
    except IOError as e:
        print(e)
    except NameError as e:
        print(e)
    except ImportError as e:
        print(e)
    except EOFError as e:
        print(e)
    except KeyboardInterrupt as e:
        print(e)
    except LookupError as e:
        print(e)
    except IndentationError as e:
        print(e)
    except IndexError as e:
        print(e)
    except KeyError as e:
        print(e)
    except SyntaxError as e:
        print(e)
    except NotImplementedError as e:
        print(e)


# Generated at 2022-06-25 12:00:12.326205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except (TypeError, ValueError):
        pass



# Generated at 2022-06-25 12:00:13.703461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  obj = StrategyModule(tqm)
  test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:17.569749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    var_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:00:18.682315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-25 12:00:21.384017
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:00:24.203664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = None


# Generated at 2022-06-25 12:00:26.694063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    strategy.__init__(None)
    # test_case_0
    strategy = StrategyModule(None)
    test_case_0()


# Generated at 2022-06-25 12:00:31.540008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)
    assert strategymodule is not None
    assert strategymodule._tqm == None
    assert strategymodule._play is None
    assert strategymodule.debugger_active == True


# Generated at 2022-06-25 12:00:37.639615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule_1 = StrategyModule()
    assert strategyModule_1 != None, "Error: StrategyModule() instance is null"



# Generated at 2022-06-25 12:00:38.921589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-25 12:00:41.085144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:43.794105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Running test_StrategyModule...")
    tqm = random.random()
    try:
        test_case_0()
    except Exception as e:
        print("Exception caught in test_StrategyModule()")
        print(e)


# Generated at 2022-06-25 12:00:48.557567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = StrategyModule(tqm)
    assert isinstance(var_1, StrategyModule)


# Generated at 2022-06-25 12:00:49.918567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = StrategyModule('var_0')
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:52.482087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = True
    var_1 = 42
    strategy = StrategyModule(var_0)
    var_2 = strategy.run_queue
    assert var_2 == var_0
    var_3 = strategy.next_task
    assert var_3 == var_1



# Generated at 2022-06-25 12:00:56.082496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        assert False, "constructor do not failed"
    else:
        assert True, "constructor do not failed"


# Generated at 2022-06-25 12:00:58.121352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = StrategyModule(None)


# Generated at 2022-06-25 12:01:00.613372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with no argument.
    try:
        StrategyModule()
    except Exception as exception:
        assert type(exception).__name__ == "TypeError"
        assert (exception.message == "object.__init__() takes no parameters") or \
               (exception.message == 'object() takes no parameters')

    # Test with required arguments.
    test_StrategyModule_0(None)

    # Test with all arguments.
    test_StrategyModule_1(None)



# Generated at 2022-06-25 12:01:12.871726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    # Unit test for instance variable 'tqm'
    tqm = None
    test_case_0()
    assert StrategyModule(tqm).tqm == tqm

    # Unit test for instance variable 'failed_hosts'
    StrategyModule(tqm).failed_hosts = []
    assert StrategyModule(tqm).failed_hosts == []

    # Unit test for instance variable 'debugger_active'
    assert StrategyModule(tqm).debugger_active == True

    # Unit test for instance variable 'debugger_running'
    assert StrategyModule(tqm).debugger_running == False

    # Unit test for instance variable '_

# Generated at 2022-06-25 12:01:14.431574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)


# Generated at 2022-06-25 12:01:15.992004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = StrategyModule()


# Generated at 2022-06-25 12:01:17.349835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule(None)
   assert(strategy_module != None)


# Generated at 2022-06-25 12:01:18.786917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == True


# Generated at 2022-06-25 12:01:23.570489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_var = StrategyModule(None);
    test_case_0();
    return;


# Generated at 2022-06-25 12:01:33.073378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.manager import VariableManager
    my_inventory = InventoryManager(loader=None, sources=None)
    var_0 = load_options_vars(loader=None, variable_manager=None, options=None)
    var_1 = load_extra_vars(loader=None, variable_manager=None, options=None)
    var_2 = VariableManager(loader=None, inventory=my_inventory)
    my_tqm_0 = dict()
    my_tqm_0['_variables'] = var_2
    my_tqm_0['_extra_vars'] = var_1


# Generated at 2022-06-25 12:01:36.467927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = StrategyModule(tqm)
    assert var_1.__class__.__name__ == 'StrategyModule'
    assert var_1.debugger_active is True


# Generated at 2022-06-25 12:01:38.292856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:01:39.875077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test case for test_case_0 """

    test_give = StrategyModule(test_case_0)

    # Here we will check attribute of object
    assert test_give.debugger_active == True

# Generated at 2022-06-25 12:01:46.850990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:01:47.942977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(strategy_module_0, StrategyModule) is True


# Generated at 2022-06-25 12:01:49.318708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:51.496358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def test_case_0():
        str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
        strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:01:55.052956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import re

    str_1 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_1 = StrategyModule(str_1)
    r_1 = re.compile('^\w+$')
    str_2 = r_1.match('lTI\n')
    r_0 = re.compile('^\w+$')
    str_3 = r_0.match('lTI\n')

# Generated at 2022-06-25 12:02:00.244566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert type(strategy_module_0) == StrategyModule

# Generated at 2022-06-25 12:02:03.860425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Entry Point for script
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:05.198821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:06.624535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:07.485523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test runner for test_StrategyModule

# Generated at 2022-06-25 12:02:17.712624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Define the main function

# Generated at 2022-06-25 12:02:27.294619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    (num_chars_0, num_chars_1, num_chars_2, num_chars_3, num_chars_4) = (48, 28, 44, 41, 24)
    (num_chars_5, num_chars_6, num_chars_7, num_chars_8, num_chars_9) = (46, 39, 44, 36, 38)
    (num_chars_10, num_chars_11, num_chars_12) = (46, 49, 30)
    (num_chars_13, num_chars_14, num_chars_15, num_chars_16, num_chars_17) = (17, 47, 41, 22, 49)

# Generated at 2022-06-25 12:02:27.996486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:02:28.660043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# TEST

# Generated at 2022-06-25 12:02:33.611080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(strategy_module_0)


# Generated at 2022-06-25 12:02:35.510754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:02:39.388867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 12:02:40.931100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:02:49.998916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1.debugger_active == True
    assert strategy_module_1.one_line_jeopardy == u'\u00033\u001b[0m'
    assert strategy_module_1.r == 'W\x8a\x0f\x12\x15fm\x8a\x0f\x12\x15f\x01\x12\x06\n\x05value)Z\x13\x01\x10\x01\x12\x04\n\x02\x12\x02\n\x08\n\x05value\x12\x04j\x04\x04\n\x08\n\x05value\x12\x04j\x04\x04'
    assert strategy_

# Generated at 2022-06-25 12:02:51.891179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:48.983813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    try:
        from ansible.plugins.strategy import debug
        strategy_module_1 = debug.StrategyModule('.\x0B~2#\x1E`3\x01\x14\x16')
        assert strategy_module_1 is not None
    except ImportError:
        pass


# Generated at 2022-06-25 12:03:50.210387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(test_case_0)

test_StrategyModule()

# Generated at 2022-06-25 12:03:50.914397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:51.428888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:53.239070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        argument_0 = ')\n;V:"qbXscV\n\tF]P}E:'
        strategy_module_0 = StrategyModule(argument_0)
    except Exception as e:
        err_0 = str(e)
        assert "" == err_0


# Generated at 2022-06-25 12:03:56.300217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:00.792152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:04:02.886806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)
    print(strategy_module_0)


# Generated at 2022-06-25 12:04:03.997259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:09.001867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)
    assert (strategy_module_0.tqm == str_0)


# Generated at 2022-06-25 12:05:09.760526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    arg0 = None
    test_case_0()


# Generated at 2022-06-25 12:05:10.971899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)
    strategy_module_0 = StrategyModule(0)



# Generated at 2022-06-25 12:05:11.879192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# @staticmethod

# Generated at 2022-06-25 12:05:16.523884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case where str_0 is a str type
    # Create a new object @strategy_module_0 
    str_0 = ')\n;V:"qbXscV\n\tF]P}E:'
    strategy_module_0 = StrategyModule(str_0)
    # Assert if not Equal
    assert (strategy_module_0.debugger_active == True)


# Generated at 2022-06-25 12:05:17.196181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:17.886912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:19.161824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # TODO: implement your test here

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:05:19.824602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:20.915800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_0 = StrategyModule(None)


# Generated at 2022-06-25 12:05:22.521855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    test_case_0()

# Execute unit tests
if __name__ == '__main__':
    test_StrategyModule()