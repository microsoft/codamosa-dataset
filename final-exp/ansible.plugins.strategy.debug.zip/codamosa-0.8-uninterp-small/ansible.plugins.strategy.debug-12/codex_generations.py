

# Generated at 2022-06-25 11:58:16.123438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule("5")
    my_class_0 = Runner(strategy_module_0)
    pprint.pprint(strategy_module_0)


# Generated at 2022-06-25 11:58:20.610852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:21.336308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:23.088938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Sample run
# python -m ansible.plugins.strategy.debug
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:26.383841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_class = None
    strategy_module = StrategyModule(complex_class)
    assert strategy_module is not None
    assert True


# Generated at 2022-06-25 11:58:27.151678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:30.290903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print('unit test for class StrategyModule. constructor')
        print('done.')
    except Exception as e:
        print('Expection')
        print(str(e))
        print('Failed')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:32.167747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:32.910060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:35.286243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:37.512920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("#### Unit test for StrategyModule ####")
    test_case_0()

# end class StrategyModule


# Generated at 2022-06-25 11:58:38.817275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:41.902433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError as err:
        print('NameError: ',err)
    except AttributeError as err:
        print('AttributeError: ',err)
    else:
        print('Unit test for class StrategyModule passed')


# Generated at 2022-06-25 11:58:43.430786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print('exception')



# Generated at 2022-06-25 11:58:47.165550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule()
    assert strategy_module_0._tqm is not None
    assert strategy_module_0._inventory is not None
    assert strategy_module_0._variable_manager.get_vars(loader=None, play=None, host=None) == {}
    assert strategy_module_0.debugger_active


# Generated at 2022-06-25 11:58:53.593462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule constructor:")
    try:
        test_case_0()
    except Exception as e:
        print("StrategyModule constructor test failed: ", e)
        raise
    print("StrategyModule constructor test passed!")
    print("")


if __name__ == '__main__':
    # Run unit tests for this class
    test_StrategyModule()

# Generated at 2022-06-25 11:58:56.247108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
#     assert strategy_module_0 is not None
    print(strategy_module_0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:57.606393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_1 = None
    test_case_0()



# Generated at 2022-06-25 11:59:01.386058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for constructor of class StrategyModule")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:02.353727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:10.512697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create object
    tqm = None
    obj_0 = StrategyModule(tqm)

    # Test if object is instance of class
    if not isinstance(obj_0, StrategyModule):
        print("FAILED: obj_0 is not instance of class")
        return False

    # Test if variable is set correctly
    if obj_0.debugger_active != True:
        print("FAILED: obj_0.debugger_active is not True")
        return False

    # All tests passed
    return True


# Generated at 2022-06-25 11:59:12.359079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with invalid parameters
    try:
        StrategyModule(tqm='tqm')
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 11:59:16.615302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        var_1 = StrategyModule()
    except Exception:
        var_2, var_3, var_4 = sys.exc_info()
        var_5 = var_3.__name__
        var_6 = str(var_2)
        print('''Failed to create instance of StrategyModule class due to %s %s''' % (var_5, var_6))
        assert False
    else:
        var_7 = isinstance(var_1, StrategyModule)
        assert var_7


# Generated at 2022-06-25 11:59:19.378370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initializing object with module-dependent data:
    # ansible.plugins.strategy.debug.StrategyModule.__init__(ansible.plugins.strategy.debug.StrategyModule, ansible.utils.unsafe_proxy.AnsibleUnsafeText)
    # TODO: Implement test
    pass



# Generated at 2022-06-25 11:59:29.354481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import TaskInclude
    from ansible.template import Templar

    var_0 = Play(name="test-play", hosts=["all"], roles=[], tasks=[])
    var_1 = TaskInclude(name="debug", include="debug", static=True)
    var_0.tasks.append(var_1)
    var_2 = Playbook('/home/test_user/test-playbook.yaml')
    var_3 = Templar(basedir=None)
    var_4 = StrategyModule(tqm=None)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:59:38.447216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = ansible.plugins.strategy.linear.StrategyModule('test_tqm')
    assert var_0 is not None
    assert var_0.tqm == 'test_tqm'
    assert var_0.inventory == {}
    assert var_0.host_list == []
    assert var_0.total_tasks == 0
    assert var_0.host_vars == {}
    assert var_0.display is not None
    assert var_0.done_hosts == []
    assert var_0.failed_hosts == []
    assert var_0.runner_queue == {}
    assert var_0.results_queue == None
    assert var_0.squashed_callback_results == {}
    assert var_0.squashed_results == {}
    assert var_0.pending_

# Generated at 2022-06-25 11:59:39.634342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    out_0 = StrategyModule(tqm)

    assert True


# Generated at 2022-06-25 11:59:45.280052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm
    assert strategy_module._inventory._hosts == []
    assert strategy_module._inventory._patterns == {}
    assert strategy_module._inventory._pattern_cache == {}
    assert strategy_module._inventory._variable_manager._inventory == strategy_module._inventory
    assert strategy_module._loader._basedir == './'
    assert strategy_module._loader._inventory == strategy_module._inventory
    assert isinstance(strategy_module._variable_manager, object)
    assert isinstance(strategy_module._templar, object)
    assert strategy_module._rconns == {}
    assert strategy_module._workers == {}
    assert isinstance(strategy_module._play, object)

# Generated at 2022-06-25 11:59:46.252085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    #test_case_0
    StrategyModule(tqm)


# Generated at 2022-06-25 11:59:51.750086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    assert callable(StrategyModule.__init__)
    assert callable(StrategyModule.run)
    assert callable(StrategyModule.get_host_result)
    assert callable(StrategyModule.cleanup)
    assert callable(StrategyModule.get_result_for_host)
    assert callable(StrategyModule.wait_on_pending_results)
    assert callable(StrategyModule.check_result)
    assert callable(StrategyModule.add_tqm_variables)
    assert callable(StrategyModule.load_callbacks)


# Generated at 2022-06-25 11:59:54.031950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-25 11:59:54.918486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:55.786350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:03.632496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = None
    loader = None
    variable_manager = None
    instance = StrategyModule(inventory, loader, variable_manager)
    assert isinstance(instance, StrategyModule)
    assert instance.inventory == inventory
    assert instance.loader == loader
    assert instance.variable_manager == variable_manager
    assert instance.console == None
    assert instance.options == None
    assert instance.passwords == None
    assert instance.stdout_callback == None
    assert instance.run_tree == False
    assert instance.become_methods_supported == False
    assert instance.become_method == None
    assert instance.become_user == None
    assert instance.become_pass == None
    assert instance.become_exe == None
    assert instance.become_flags == None
    assert instance.become_ask_pass == False


# Generated at 2022-06-25 12:00:04.693598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_1 = None
    strategy_module_1 = StrategyModule(complex_1)


# Generated at 2022-06-25 12:00:06.349827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call test_case_0
    test_case_0()


# Execute a task in debug session

# Generated at 2022-06-25 12:00:08.848293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing',os.path.basename(__file__),'...',end='')
    test_case_0()
    print('Done testing',os.path.basename(__file__))

# Code cover for test of class StrategyModule

# Generated at 2022-06-25 12:00:10.147335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:00:11.418000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    test_case_0()


# Generated at 2022-06-25 12:00:13.481837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_1 = None
    strategy_module_1 = StrategyModule(complex_1)
    assert strategy_module_1.tqm == complex_1
    assert strategy_module_1.debugger_active == True


# Generated at 2022-06-25 12:00:18.682007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:00:19.770866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 12:00:21.545989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:23.009118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# ansible-playbook --step --start-at-task='debugging' playbook.yml

# Generated at 2022-06-25 12:00:25.786899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor')
    test_case_0()

# Unit tests for methods of class StrategyModule

# Generated at 2022-06-25 12:00:30.249766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:00:35.712683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test constructor of class StrategyModule
    """
    try:
        tqm = None
        strategy_module = StrategyModule(tqm)
    except Exception as e:
        print('Caught exception when testing StrategyModule(): ' + str(e))




# Generated at 2022-06-25 12:00:38.403479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Testcase for StrategyModule is done!")


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:42.498603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        if 'StrategyModule' in sys.modules:
            del sys.modules['StrategyModule']

        test_case_0()
    except Exception as err:
        print(err)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:46.737553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except TypeError as e:
        assert True
    else:
        assert False


if __name__ == '__main__':
    for test_function in dir():
        if test_function.startswith('test_'):
            print('Running function: {}'.format(test_function))
            try:
                globals()[test_function]()
                print('Test OK')
            except AssertionError as e:
                print('Test ERROR: {}'.format(e))
                raise

# Generated at 2022-06-25 12:00:52.190607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module_0 = StrategyModule(None)
        strategy_module_0._StrategyModule__init__(None)
    except:
        assert False



# Generated at 2022-06-25 12:00:54.432322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    strategy_module_0.run()

# Generated at 2022-06-25 12:00:58.392021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:00:59.965651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 12:01:04.210978
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:01:06.963780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test for constructor of class StrategyModule");
    test_case_0()
    print("Test for constructor of class StrategyModule completed");


# Generated at 2022-06-25 12:01:08.660105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:01:13.049043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    w_strategy_module_0 = StrategyModule(None)
    assert w_strategy_module_0 is not None

# Test cases

# Generated at 2022-06-25 12:01:15.882087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:17.240226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:01:27.522886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:32.445000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    assert strategy_module_0.debugger_active == True



# Generated at 2022-06-25 12:01:34.847232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        return False
    return True

"""
    For testing and debugging, the strategy class was moved to separate file
    strategy_debug.py, as it is easier to edit/modify.
"""


# Generated at 2022-06-25 12:01:41.352308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert (strategy_module_0 is not None)
    assert (isinstance(strategy_module_0, StrategyModule))

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 12:01:46.706489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert test_case_0() == True
        print("Pass: test_case_0")
    except:
        print("Fail: test_case_0")

# Generated at 2022-06-25 12:01:52.823219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__') and callable(getattr(StrategyModule, '__init__'))
    #instance must be created
    assert isinstance(StrategyModule(None), StrategyModule)
    #created instance must be 'instance of StrategyModule'
    assert isinstance(StrategyModule(None), StrategyModule)
    assert isinstance(StrategyModule(None), LinearStrategyModule)
    assert issubclass(StrategyModule, LinearStrategyModule)
    #test for __init__
    assert hasattr(StrategyModule, '__init__') and callable(getattr(StrategyModule, '__init__'))



# Generated at 2022-06-25 12:01:54.275444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    #
    #    It doesn't have test case.
    #
    test_case_0()


import unittest

# Generated at 2022-06-25 12:01:57.149164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:01:59.380855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Define the main() function

# Generated at 2022-06-25 12:02:02.583208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()



# Generated at 2022-06-25 12:02:26.810453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:02:28.720047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    x = strategy_module_0
    # Assert with expected example values
    assert strategy_module_0 != None


# Generated at 2022-06-25 12:02:34.806376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(complex_0)
    strategy_module_0.debugger_active = None
    strategy_module_0.host_name = None
    strategy_module_0.results = None
    strategy_module_0.connection = None
    strategy_module_0.task_queue = None
    strategy_module_0.shell = None
    strategy_module_0.play = None
    strategy_module_0.tqm = None
    strategy_module_0.pattern = None
    strategy_module_0.loader = None
    strategy_module_0.inventory = None
    strategy_module_0.variable_manager = None
    strategy_module_0.notified_handlers = None
    strategy_module_0.module_name = None
    strategy_module_0.host = None
    strategy

# Generated at 2022-06-25 12:02:36.312043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:41.146612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:02:44.695038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test case 0 PASSED")
    return 0

print("Starting test for class StrategyModule (located in file lib/ansible/plugins/strategy/debug.py)")
# import pdb;pdb.set_trace()
test_StrategyModule()
print("Test completed for class StrategyModule")

# Generated at 2022-06-25 12:02:46.966149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1
    test_case_0()
    # Test 2
    test_case_1()
    # Test 3
    test_case_2()



# Generated at 2022-06-25 12:02:48.920632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_1 = None
    strategy_module_1 = StrategyModule(complex_1)
    assert strategy_module_1._tqm == None


# Generated at 2022-06-25 12:02:51.245599
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

sys.stdout.flush()


# Generated at 2022-06-25 12:02:52.091636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:03:35.611201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)
    attr_value_0 = getattr(strategy_module_0, "debugger_active", None)
    assert attr_value_0 is True


# Generated at 2022-06-25 12:03:37.705391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:38.898588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_0 = None
    strategy_module_0 = StrategyModule(complex_0)


# Generated at 2022-06-25 12:03:45.743634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running test_StrategyModule...')
    test_case_0()
    sys.exit(0)

# Import Ansible utilities
from ansible.utils.display import Display
display = Display()

# Import Ansible runner classes
from ansible.plugins.strategy import StrategyBase
from callback_debugger import DebuggerCallback_0

from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.vars.manager import VariableManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.error import AnsibleParserError
from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-25 12:03:46.405566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:03:48.328002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as ex:
        print('[ERROR]\t Exception in %s: %s' % (__file__, str(ex)))
        return ex
    else:
        return None



# Generated at 2022-06-25 12:03:49.698353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(complex)
    assert repr(strategy_module) == "<StrategyModule(tqm=<unknown>)"


# Generated at 2022-06-25 12:03:50.652840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# vim: syntax=python:expandtab:shiftwidth=4:softtabstop=4

# Generated at 2022-06-25 12:03:51.605225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0


# Generated at 2022-06-25 12:03:56.179595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:05:26.912245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(None)


# Generated at 2022-06-25 12:05:28.187547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(None)
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 12:05:28.996031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(test_case_0.__name__)
    test_case_0()

# Generated at 2022-06-25 12:05:29.581372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:05:34.711542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    complex_1 = 'QEhcARlIHgFYPVsY'
    strategy_module_1 = StrategyModule(complex_1)
    # Test attribute 'debugger_active'
    assert strategy_module_1.debugger_active is True, "Attribute 'debugger_active' should be True."
    complex_2 = 'QEhcARlIHgFYPVsY'
    strategy_module_2 = StrategyModule(complex_2)
    # Test attribute 'debugger_active'
    assert strategy_module_2.debugger_active is True, "Attribute 'debugger_active' should be True."
    complex_3 = 'QEhcARlIHgFYPVsY'
    strategy_module_3 = StrategyModule(complex_3)
    # Test attribute 'debugger_active'
    assert strategy_module

# Generated at 2022-06-25 12:05:35.298739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:36.609820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Success")
    except SystemExit as e:
        print("Failure")

# Test suite for class StrategyModule

# Generated at 2022-06-25 12:05:39.479863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Case 0: Run empty constructor test_case_0()")
    test_case_0()



if __name__ == "__main__":

    num_test_cases = 1
    test_suite = [(strategy_module.test_StrategyModule, ())]
    print("total num of test cases: " + str(num_test_cases))
    for (test, args) in test_suite:
        print("Running test " + test.__name__)
        test(*args)

# Generated at 2022-06-25 12:05:40.974869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = None
    assert not StrategyModule(tqm_0)

#Unit test for 

# Generated at 2022-06-25 12:05:43.476490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    print("Testing StrategyModule.py")
    test_StrategyModule()