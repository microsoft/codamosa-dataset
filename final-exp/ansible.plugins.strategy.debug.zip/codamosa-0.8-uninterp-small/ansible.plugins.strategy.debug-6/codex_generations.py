

# Generated at 2022-06-25 11:58:21.028947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)



# Generated at 2022-06-25 11:58:21.769207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:23.209554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Passed")
    except:
        print("Failed")



# Generated at 2022-06-25 11:58:26.680076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_case_0())
    loop.close()


# Generated at 2022-06-25 11:58:28.950193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n  Executing test_StrategyModule")

    test_case_0()

# Main function
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:31.279738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:32.739915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 11:58:38.252834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('-- Unit test for StrategyModule constructor')
    output = ""
    try:
        test_case_0()
    except Exception as e:
        output = "Failed: " + str(e)
        print(output)
    if output == "":
        print("Passed")


# main entrance for unit test
if __name__ == "__main__":
    print('-- debug.py --')
    test_StrategyModule()
    print('-- debug.py done --')

# Generated at 2022-06-25 11:58:42.415335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print('\ntest class StrategyModule PASS')
    except AssertionError as e:
        print('\ntest class StrategyModule FAILED')
    except Exception as e:
        print('\nIn test class StrategyModule, error occurred. ')
        print(e)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:45.380174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    byte_0 = b'\x00'
    strategy_module_0 = StrategyModule(byte_0)
    print(strategy_module_0)
    print(type(strategy_module_0))


# Generated at 2022-06-25 11:58:50.595342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:58:51.450069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#---


# Generated at 2022-06-25 11:58:53.174354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 11:58:56.130955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print('FAILED: test_StrategyModule')
        raise
    else:
        print('SUCCESS: test_StrategyModule')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:59.144064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test passed.")
    return(0)


if __name__ == '__main__':
    result = test_StrategyModule()
    sys.exit(result)

# Generated at 2022-06-25 11:59:02.214100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 11:59:03.845163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	bytes_0 = b''
	strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 11:59:06.778328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    #
    # TaskQueueManager's 'returncode' field is an instance of the class int
    #
    test_case_0()



# Generated at 2022-06-25 11:59:08.488673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a tmp dir to hold test files
    #strategy_module_0 = StrategyModule()
    assert True
    

# Generated at 2022-06-25 11:59:10.620592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    print('Testing class StrategyModule')
    test_StrategyModule()
    print('Done!')

# Generated at 2022-06-25 11:59:12.184314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:12.968343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:13.828293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:14.648355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass

# Generated at 2022-06-25 11:59:16.939376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0
    # TypeError: __init__() missing 1 required positional argument: 'tqm'
 

# Generated at 2022-06-25 11:59:17.943437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 11:59:21.801426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 11:59:24.096902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with zero argument
    try:
        test_case_0()
    except TypeError:
        pass



# Generated at 2022-06-25 11:59:24.935365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:34.507212
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 11:59:37.026258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:37.722030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:40.167731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = bytes()
    returned = StrategyModule(tqm)
    print(type(returned)) 
    assert type(returned) is StrategyModule

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:59:40.686521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:42.600746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    err = None
    try:
        test_case_0()
    except Exception as e:
        err = e
    assert err is None, 'An error occurred when running the test: ' + str(err)

# Generated at 2022-06-25 11:59:43.219919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:44.044820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # invoke StrategyModule() constructor
    strategy_module_0 = StrategyModule()



# Generated at 2022-06-25 11:59:45.073032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:46.369097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:47.278489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:54.815607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Create instance of StrategyModule
    # TODO: Verify constructor has created the required attributes
    pass



# Generated at 2022-06-25 11:59:56.635383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:58.819895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test0_args = None
    test0_kwargs = {}
    test0_return = test_case_0()
    assert(test0_return == None)


# Generated at 2022-06-25 12:00:03.765909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print("[FAIL] test_StrategyModule()")
        print("Exception: " + str(err))
        return False
    else:
        print("[SUCCESS] test_StrategyModule()")
        return True

if __name__ == '__main__':
    from __main__ import _runtime_main

    # Run the tests and print results.
    _runtime_main(test_StrategyModule)

#endif

# Generated at 2022-06-25 12:00:04.609069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(b'')


# Generated at 2022-06-25 12:00:05.219158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:00:06.859855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n----Test 0----\n")
    test_case_0()

test_StrategyModule()


# Generated at 2022-06-25 12:00:07.840651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:08.566643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:00:14.426265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(bytes_0)
    return_value_0 = strategy_module_0.get_host_list()
    return_value_0 = strategy_module_0.get_failed_hosts()
    return_value_0 = strategy_module_0.get_changed_hosts()
    return_value_0 = strategy_module_0.get_dark_hosts()
    return_value_0 = strategy_module_0.get_encoded_host_vars()
    return_value_0 = strategy_module_0.get_encoded_completed_hosts()
    return_value_0 = strategy_module_0.get_encoded_unreachable_hosts()
    return_value_0 = strategy_module_0.get_encoded_failed_hosts()
    return

# Generated at 2022-06-25 12:00:24.203655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:25.761781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:31.471901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b''
    strategy_module_1 = StrategyModule(bytes_1)
    assert (bytes_1 == strategy_module_1.tqm)
    assert (True == strategy_module_1.debugger_active)



# Generated at 2022-06-25 12:00:34.180359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:37.214502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-25 12:00:45.449531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import imp
    import os.path


    ansible_module_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..',
                                       'lib', 'ansible', 'modules')
    sys.path.append(ansible_module_path)
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)
    assert str(isinstance(strategy_module_0, object))
    assert str(isinstance(strategy_module_0, cmd.Cmd))
    assert str(isinstance(strategy_module_0, LinearStrategyModule))
    assert str(isinstance(strategy_module_0, object))
    assert str(isinstance(strategy_module_0, cmd.Cmd))
    assert str

# Generated at 2022-06-25 12:00:46.786566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:48.249121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:48.964122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:49.788178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:01:05.230798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:01:07.203771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:09.185326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # for unit test
    test_StrategyModule()

# Generated at 2022-06-25 12:01:12.848345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:15.771151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:20.281927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in strategy_module.py: {0}".format(e))
        sys.exit(1)

# Start of System Test
import unittest
import ansible
import ansible.playbook
import ansible.utils
import ansible.callbacks
import ansible.inventory
import subprocess as sb
import os
import json
import time


# Generated at 2022-06-25 12:01:21.145441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:23.689623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b''
    strategy_module_1= StrategyModule(bytes_1)


# Generated at 2022-06-25 12:01:26.146377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test for constructor of class StrategyModule
    :return: nothing
    :since: 2019-10-27
    :author: Kishin Yagami
    """
    tqm = b''
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None



# Generated at 2022-06-25 12:01:27.734955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:59.356405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:03.888834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b''
    strategy_module_1 = StrategyModule(bytes_1)

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 12:02:04.936409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_5 = StrategyModule(object())


# Generated at 2022-06-25 12:02:06.129534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(bytes_0)

test_case_0()

# Generated at 2022-06-25 12:02:10.091112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.debugger_active


# Generated at 2022-06-25 12:02:10.725458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-25 12:02:11.796724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:15.308793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor')
    try:
        test_case_0()
    except:
        print('FAILED: test_case_0()')


# Generated at 2022-06-25 12:02:16.197751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b''
    strategy_module_0 = StrategyModule(bytes_1)




# Generated at 2022-06-25 12:02:21.214701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:38.286168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:40.932051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    print("Hello, world!")
    test_StrategyModule()

# Generated at 2022-06-25 12:03:44.658726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:45.266863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:50.769525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    stdout = sys.stdout

    class View:
        stdout = stdout

    class UserInterface:
        view = View()

    class Cmd(cmd.Cmd):
        def __init__(self):
            self.debugger_active = False
#
        def do_intro(self, line):
            return False

        def do_halt(self, line):
            return True

        def emptyline(self):
            return False

        def default(self, line):
            return True

    class TQM:
        _terminated = False
        _failed_hosts = {}
        _unreachable_hosts = {}
        statistics = {}
        _host_states = {}

        def __init__(self):
            self._stdout_callback = None


# Generated at 2022-06-25 12:03:51.584833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NotImplementedError:
        assert False


# Generated at 2022-06-25 12:03:56.148187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:58.359932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Sample input
    bytes_0 = b''
    test_case_0(bytes_0)

# Generated at 2022-06-25 12:04:01.421758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    # Object creation
    """
    bytes_0 = b''
    assert(strategy_module_0 == StrategyModule(bytes_0))

# Generated at 2022-06-25 12:04:02.191090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0()
    pass



# Generated at 2022-06-25 12:07:00.622300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:07:01.352981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not test_case_0()

# Generated at 2022-06-25 12:07:04.662235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print("Exception raised during test_case_0: " + str(err))

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:06.297389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module_0 = StrategyModule(b'')
    except TypeError:
        print("TypeError")


# Generated at 2022-06-25 12:07:07.004624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:07:08.874280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    # Assign parameters as follows
    tqm = ''

    strategy_module_0 = StrategyModule(tqm)
    strategy_module_0.run()



# Generated at 2022-06-25 12:07:09.790505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# vim: foldmethod=indent

# Generated at 2022-06-25 12:07:11.622064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    bytes_0 = b''

    # Act
    strategy_module_0 = StrategyModule(bytes_0)

    # Assert
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0.tqm, bytes)

# Generated at 2022-06-25 12:07:12.602458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:07:15.084735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b''
    strategy_module_0 = StrategyModule(bytes_0)

    assert(isinstance(strategy_module_0, StrategyModule))
    # Unit test for method __init__ of class StrategyModule
    test_case_0()
