

# Generated at 2022-06-25 11:58:20.505944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:21.234079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:21.969161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:28.134269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Compare created object with pre-defined value
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
 
    # All exceptions are handled here

# Generated at 2022-06-25 11:58:31.995358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:33.323376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:36.648355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    if isinstance(strategy_module, LinearStrategyModule):
        print("Success")
    else:
        print("Failure")


# Generated at 2022-06-25 11:58:38.818272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# -------------------------------------------------------------------------------
# Main:
# -------------------------------------------------------------------------------
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:39.547902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:40.805386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:44.714313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    pytest.main(sys.argv)

# Generated at 2022-06-25 11:58:46.394375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0.debugger_active == True



# Generated at 2022-06-25 11:58:50.358179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:54.280827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        raise e

if __name__ == "__main__":
    import traceback
    import sys
    test_StrategyModule()

# Generated at 2022-06-25 11:58:55.687205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:56.665645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:58.089358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 11:58:59.108885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:01.385579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:03.092865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:07.448829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:59:14.456759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('\tGiB')
    assert strategy_module_0.host_states == dict()

    strategy_module_1 = StrategyModule('/8')
    assert strategy_module_1.host_states == dict()

    strategy_module_2 = StrategyModule('_')
    assert strategy_module_2.host_states == dict()

    strategy_module_3 = StrategyModule(',')
    assert strategy_module_3.host_states == dict()

    strategy_module_4 = StrategyModule(None)
    assert strategy_module_4.host_states == dict()

    strategy_module_5 = StrategyModule('9e-')
    assert strategy_module_5.host_states == dict()

    strategy_module_6 = StrategyModule(',')

# Generated at 2022-06-25 11:59:16.762135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = None
    strategy_module_0 = StrategyModule(int_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:59:18.890234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 11:59:22.458294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:26.912570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test 1:
    # Action: Initialize a StrategyModule with a null value
    # Expect: A TypeError is thrown
    #print ('Unit test for constructor of class StrategyModule')
    #print ('Test 1: Null value for TQM')
    try:
        test_case_0()
        assert(False)
    except TypeError:
        assert(True)
    except:
        assert(False)



# Generated at 2022-06-25 11:59:28.313061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:28.768243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:29.384755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

__all__ = ['StrategyModule']

# Generated at 2022-06-25 11:59:30.056150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:34.853568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run the debugger

# Generated at 2022-06-25 11:59:39.919354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(sys.modules[__name__])


# Generated at 2022-06-25 11:59:40.624993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:41.502703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:45.444168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result_0 = test_case_0()

# Run unit tests
test_StrategyModule()

# Generated at 2022-06-25 11:59:46.400546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:49.158747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    case_list_0 = [
        test_case_0
    ]
    
    # Run test case
    for test_case in case_list_0:
        test_case()


# unit test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:49.910608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:51.887170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    test_case_0()

# Test the python code in module 
if __name__ == '__main__':
    print("Test the code in module: %s" % __file__)
    test_StrategyModule()
    print("Test end.")

# Generated at 2022-06-25 11:59:52.329670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

