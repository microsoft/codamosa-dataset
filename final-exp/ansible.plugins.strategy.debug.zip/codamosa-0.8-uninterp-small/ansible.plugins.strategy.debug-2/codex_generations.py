

# Generated at 2022-06-25 11:58:16.936560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'debugger_active' in dir(StrategyModule(None))


# Generated at 2022-06-25 11:58:20.408956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:58:21.670302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:23.141110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "z~S'L"
    # strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 11:58:26.082951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_strategy_module_0 = StrategyModule(strategy_module_0)


# Generated at 2022-06-25 11:58:28.448480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.stdout.reset()
    test_case_0()
    sys.stdout.reset()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:32.317246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Local Variables:
# compile-command: "py.test -v --capture=no"
# End:

# Generated at 2022-06-25 11:58:33.990047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:42.159719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = "z~S'L"
    var_1 = StrategyModule(var_0)

if __name__ == '__main__':
    if len(sys.argv) == 2 and len(sys.argv[1]) == 0:
        while True:
            str_0 = input()
            str_1 = str.split(str_0)
            if str_1[0] == 'quit':
                break
            else:
                if str_1[0] == 'StrategyModule':
                    if len(str_1) == 2:
                        test_StrategyModule()
                    else:
                        print('function StrategyModule has 0 arguments')
                elif str_1[0] == 'test_case_0':
                    test_case_0()

# Generated at 2022-06-25 11:58:43.142788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:45.651491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    StrategyModule(tqm)


# Generated at 2022-06-25 11:58:46.516885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    pass



# Generated at 2022-06-25 11:58:50.399173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:53.396835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.debug
        tqm = test_case_0()
        testobj = StrategyModule(tqm)
    except Exception as e:
        print("Exception in StrategyModule: %s" % str(e))



# Generated at 2022-06-25 11:58:55.426534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    sm = StrategyModule(tqm)
    assert sm


# Generated at 2022-06-25 11:58:57.397501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    sm = StrategyModule(tqm)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 11:59:02.779134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0
    u_t0_args = [ 'test_StrategyModule_0' ]
    u_t0_kwargs = {  }
    u_t0_result = StrategyModule(test_case_0())
    assert(u_t0_result is not None)



# Generated at 2022-06-25 11:59:03.710412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(0)


# Generated at 2022-06-25 11:59:05.921556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-25 11:59:08.414587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    unittest.TestCase.assertIsInstance(StrategyModule, cmd.Cmd)
    unittest.TestCase.assertIs(StrategyModule.prompt, 'debug> ')


# Generated at 2022-06-25 11:59:10.096773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:12.628565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    str_0 = "p~S'LinearStrategyModule"
    assert isinstance(LinearStrategyModule(str_0), LinearStrategyModule)


# Generated at 2022-06-25 11:59:13.455911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:14.929115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:17.941823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:59:18.873094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:59:26.745548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'z~S\'L'
    str_1 = StrategyModule(tqm)


# ========
# Test Case
# ========
if __name__ == '__main__':
    if sys.argv[1] == 'test_case_0':
        test_case_0()
    elif sys.argv[1] == 'test_StrategyModule':
        test_StrategyModule()
    else:
        print('Wrong test case name.')

# Generated at 2022-06-25 11:59:27.199855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:28.605713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:29.072238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:32.273961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # run_module(strategy='debug')
    test_StrategyModule()

# Generated at 2022-06-25 11:59:32.816616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 11:59:33.544679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test using two __init__
    test_case_0()



# Generated at 2022-06-25 11:59:34.894343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:39.380528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:40.118531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:42.621567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests whether the exception is raised if the type of the task queue manager is invalid
    try:
        str_0 = "z~S'L"
        strategy_module_0 = StrategyModule(str_0)
    except AssertionError:
        pass


# Generated at 2022-06-25 11:59:45.850851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main method
if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:51.490189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "b~S'L"
    strategy_module_0 = StrategyModule(str_0)
    str_1 = "b~S'L"
    strategy_module_1 = StrategyModule(str_1)



# Generated at 2022-06-25 11:59:55.664239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print(err)

# Unit test execution
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:01.068349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:09.815189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for StrategyModule")
    strategy_module_0 = StrategyModule(str_0)
    # assert(strategy_module_0.tqm == str_0)
    try:
        strategy_module_0 = StrategyModule(str_0)
        assert(strategy_module_0.tqm == str_0)
    except:
        print("Error: {}".format(sys.exc_info()[0]))
    assert(strategy_module_0.debugger_active == True)

if __name__ == "__main__":
    print("Test strategy.debug")
    test_case_0()
    test_StrategyModule()



# Generated at 2022-06-25 12:00:10.742846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for StrategyModule: success')


# Generated at 2022-06-25 12:00:11.318212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:13.110539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()

# Run program
if __name__ == "__main__":
    print("test_strategy_module")
    test_StrategyModule()

# Generated at 2022-06-25 12:00:14.228656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:18.033685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:00:20.198633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Since StrategyModule is an abstract class, the method run should not be tested.
# However, we test it's parent method, the _run_play method, by testing the 
# StrategyModule class, which is a child class of LinearStrategyModule.

# Generated at 2022-06-25 12:00:27.188292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n*** Starting test_StrategyModule ***\n")
    str_0 = "z~S'L"
    strategy_module_0 = StrategyModule(str_0)
    assert type(strategy_module_0) == StrategyModule
    print("\n*** Ending test_StrategyModule ***\n")


# Generated at 2022-06-25 12:00:30.422251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:40.782083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    # test_StrategyModule() 
    # Uncomment the above line to test constructor of class StrategyModule
    pass

# Generated at 2022-06-25 12:00:42.149326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:45.388996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except (TypeError) as exp:
        print(exp)
        print("Construtor test of StrategyModule failed")



# Generated at 2022-06-25 12:00:48.964956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Aj8'
    print(str_0)
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:00:51.588925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test output should look like
# "test_StrategyModule ... ok"
# or
# "test_StrategyModule ... FAILED"
# or
# "test_StrategyModule ... ERROR"

# Generated at 2022-06-25 12:00:53.833652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except AttributeError as e:
        assert False
    else:
        assert True

# Generated at 2022-06-25 12:00:57.880238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test for StrategyModule")
    test_case_0()

# Main flow of this test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:09.454073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # No exception thrown when using correct arguments
    try:
        test_case_0()
    # Expected exception when using incorrect arguments
    except TypeError as e:
        assert e.message == "object of type 'str' has no len()"

if __name__ == '__main__':
    # Run test case when executing script, else execute unit test
    if '-t' in sys.argv:
        test_StrategyModule()
    else:
        class Debugger(cmd.Cmd):
            def __init__(self, task):
                super(Debugger, self).__init__()
                self.task = task
                self.debugger_active = True

            def do_nop(self, arg):
                ''' no-op is a no-op '''


# Generated at 2022-06-25 12:01:12.097315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global test_count
    print("\ntest " + str(test_count) + ": StrategyModule()")
    test_count += 1
    test_case_0()

# Run all tests
if __name__ == '__main__':
    test_count = 1
    test_StrategyModule()

# Generated at 2022-06-25 12:01:12.803188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:01:38.508074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    params_0 = {
        'description': "Executes tasks in interactive debug session.",
        'short_description': 'Executes tasks in interactive debug session.',
        'version_added': '2.1',
        'author': 'Kishin Yagami (!UNKNOWN)'
    }
    str_0 = 'Executes tasks in interactive debug session.'
    module_name_0 = 'debug'
    import sys
    import ast
    import re
    import inspect
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.utils.strategy_loader import find_strategy_class


# Generated at 2022-06-25 12:01:39.818876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:42.837043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    test_case_0()


argv = sys.argv[1:]

if '-v' in argv:
    # Run unit test with increase verbosity
    print("Unit test of class StrategyModule with verbose")
    test_StrategyModule()
else:
    # Run unit test without increase verbosity
    print("Unit test of class StrategyModule")
    test_StrategyModule()

# Generated at 2022-06-25 12:01:46.757508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 12:01:47.343390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:48.427094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    print("test: StrategyModule class defined")


# Generated at 2022-06-25 12:01:49.468771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule
    assert type(stm) is type


# Generated at 2022-06-25 12:01:54.140266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:01:55.235677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Unit test for class StrategyModule has succeeded")

test_StrategyModule()

# Generated at 2022-06-25 12:01:56.744324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:40.291673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('z~S\'L').debugger_active == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:02:41.825239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:02:46.016322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:02:47.155238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:02:47.925837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main function

# Generated at 2022-06-25 12:02:55.245255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert ((StrategyModule.__module__ == 'ansible.plugins.strategy') and (StrategyModule.__doc__ is None) and (len(StrategyModule.__dict__) == 1))
    assert (StrategyModule.__init__.__module__ == 'ansible.plugins.strategy')
    assert (StrategyModule.__init__.__doc__ is None)
    assert (len(StrategyModule.__init__.__dict__) == 1)
    assert (StrategyModule.__init__.__dict__['__annotations__'] == {'tqm': '<class \'str\'>'})
    assert (StrategyModule.__init__.__dict__['__defaults__'] == None)

# Generated at 2022-06-25 12:02:57.684600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = "a"
    strategy_module_0 = StrategyModule(a)
    #Assertion
    assert strategy_module_0.tqm == "a"
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:03:02.769087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n'*10)
    test_case_0()

# Command line arguments parsing
if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(prog='ansible-debug')
    parser.add_argument('--test', help='Run unit test for this module', action='store_true')
    args = parser.parse_args()

    if args.test:
        import time
        start_time = time.time()
        test_StrategyModule()
        print('Execution time: %s seconds' % (time.time() - start_time))
    else:
        main()

# Generated at 2022-06-25 12:03:04.651077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "z~S'L"
    test_case_0()

if __name__ == "__main__":
    # test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:03:08.757945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:31.287592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test Case:
    test_case_0()


# Generated at 2022-06-25 12:04:39.748205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor (__init__) for class StrategyModule")
    print("Test 1: No exception")
    try:
        test_case_0()
        print("PASS")
    except Exception as e:
        print("Exception test failed: {}".format(repr(e)))
    print("Test 2: Check parameters")
    try:
        print("Test 2.1: Check tqm")
        test_case_0()
        print("PASS")
    except Exception as e:
        print("Exception test failed: {}".format(repr(e)))
    try:
        print("Test 2.2: Check self.debugger_active")
        test_case_0()
        print("PASS")
    except Exception as e:
        print("Exception test failed: {}".format(repr(e)))


# Generated at 2022-06-25 12:04:40.857637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Executes user's command

# Generated at 2022-06-25 12:04:44.170885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global p, test_case_0
    p = StrategyModule(sys.argv[1])
    print (p)
    test_case_0()



# Generated at 2022-06-25 12:04:47.242482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('===Test for constructor of class StrategyModule===')
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
    print('===Test for constructor of class StrategyModule===')
    sys.exit(0)

# Generated at 2022-06-25 12:04:48.912430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "z~S'L"
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:04:50.438969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "z~S'L"
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:04:51.244562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(strategy_module)


# Generated at 2022-06-25 12:04:53.133139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = "z~S'L"
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0.debugger_active == True, "StrategyModule constructor() test case 0 failed"



# Generated at 2022-06-25 12:04:54.095324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()


# Generated at 2022-06-25 12:07:56.609883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 12:07:57.283473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:07:59.844908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule
    str_0 = "z~S'L"
    strategy_module_0 = StrategyModule(str_0)
    for number in range(1):
        print("Test #" + str(number + 1))

test_case_0()

# Generated at 2022-06-25 12:08:00.506873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:01.162758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:08:04.071530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:08:05.733570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test Code.
# Begin of main
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:08:07.880712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()
    print('done')

# Generated at 2022-06-25 12:08:09.300857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0()
    print("Test Case 0 : {}".format(test_case_0()))


# Generated at 2022-06-25 12:08:09.937301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main program