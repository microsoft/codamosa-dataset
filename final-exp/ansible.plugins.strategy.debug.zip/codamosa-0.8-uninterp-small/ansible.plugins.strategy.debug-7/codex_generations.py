

# Generated at 2022-06-25 11:58:16.229909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:58:22.328235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # 1. Arrange
    bool_0 = True
    
    # 2. Act
    strategy_module_0 = StrategyModule(bool_0)
    
    # 3. Assert
    assert(strategy_module_0 != None)
    

# Generated at 2022-06-25 11:58:25.780305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), "Constructor of StrategyModule is not callable"


# Generated at 2022-06-25 11:58:26.969563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print ("Done")

# Generated at 2022-06-25 11:58:28.170054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:35.558238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = True
    strategy_module_0 = StrategyModule(tqm_0)
    assert strategy_module_0.tqm is tqm_0
    assert strategy_module_0.current_task is None
    assert strategy_module_0.play is None
    assert strategy_module_0.iterator is None
    assert strategy_module_0.runners is None


# Generated at 2022-06-25 11:58:38.356385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = True

    try:
        test_case_0()
    except:
        result = False

    if result == True:
        print("Successfully completed all test cases!")
    else:
        print("At least one test case failed!")
    return result

# Generated at 2022-06-25 11:58:39.348611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 11:58:47.548248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:51.183375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:58:53.345041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:56.785568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule = StrategyModule()
    except TypeError:
        return
    except:
        print ('Unexpected error:', sys.exc_info()[0] )
        raise
    print (str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:58:58.616555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        test_case_0()


# Generated at 2022-06-25 11:59:07.788427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Case for StrategyModule
        StrategyModule()
    except TypeError:
        # Case for child class of StrategyModule
        try:
            StrategyModule(tqm)
        except TypeError:
            # Case for constructor of StrategyModule is not callable
            try:
                test_case_0()
            except Exception:
                print('TEST: StrategyModule(tqm) constructor is callable')
        else:
            print('TEST: constructor of StrategyModule is not callable')
    else:
        print('TEST: StrategyModule constructor is callable')



# Generated at 2022-06-25 11:59:10.585563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)
    except TypeError:
        test_case_0()
        print('test_StrategyModule -- Pass')
    else:
        print('test_StrategyModule -- Failure')


# Generated at 2022-06-25 11:59:14.393836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        ansible_0 = StrategyModule('ansible_0')
        ansible_0.should_run_on('test_host')
        test_case_0()
        print('test_StrategyModule unit test is failed')
    except NotImplementedError:
        print('test_StrategyModule unit test is successed')


# Generated at 2022-06-25 11:59:20.977270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assert if all method in class exists
    sm = StrategyModule
    assert hasattr(sm, '__init__'), test_case_0
    assert hasattr(sm, 'run'), 'run method is not defined'
    assert hasattr(sm, 'put_result'), 'put_result method is not defined'
    assert hasattr(sm, 'debugger_active'), 'debugger_active method is not defined'
    assert hasattr(sm, 'execute_task'), 'execute_task method is not defined'
    assert hasattr(sm, 'get_fq_name'), 'get_fq_name method is not defined'
    assert hasattr(sm, 'get_active_step'), 'get_active_step method is not defined'
    assert hasattr(sm, 'debugger'), 'debugger method is not defined'
    assert hasattr

# Generated at 2022-06-25 11:59:23.974493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except:
        test_case_0()


# Generated at 2022-06-25 11:59:28.066755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    strategy_module_0 = StrategyModule('tqm')
    strategy_module_0.__class__ = StrategyModule
    if hasattr(strategy_module_0, '__call__'):
        print('Constructor of StrategyModule is callable')
        print('Test case 0 is pass')
    else:
        print('Test case 0 is fail')


# Generated at 2022-06-25 11:59:30.670515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError:
        print('The Constructor of StrategyModule should not be callable without arguments!')
        return
    test_case_0()


# Generated at 2022-06-25 11:59:34.278736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert callable(sm.__init__), test_case_0()


# Generated at 2022-06-25 11:59:40.338422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError as exc:
        if str(exc) != test_case_0():
            return False
        return True

test_case_1 = lambda self: self.debugger_active


# Generated at 2022-06-25 11:59:42.163343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module_0 = StrategyModule()
        assert False, test_case_0()
    except:
        assert True

test_StrategyModule()

# Generated at 2022-06-25 11:59:46.106475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Default value of tqm should be None
    tqm = None
    debugger = StrategyModule(tqm)
    assert debugger is not None, test_case_0()



# Generated at 2022-06-25 11:59:50.966878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategyModule = StrategyModule
        strategyModule(None)
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-25 12:00:00.687779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # test whether StrategyModule has a constructor
    try:
        StrategyModule(None)
        print('In try block')
    except TypeError:
        print('TypeError in try block')
        #test_case_0()
    except NameError as e:
        print('In except block')
        print(e.name, e.args)
        #test_case_0()
    except AttributeError:
        print('AttributeError in try block')
        #test_case_0()
    except:
        print('In except block')
        #test_case_0()
    else:
        print('In else block')
        #test_case_0()
    finally:
        print('In finally block')

test_StrategyModule()

# Generated at 2022-06-25 12:00:06.662841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor
    strategy_module_instance = StrategyModule(None)

    # print strategy_module_instance
    print(strategy_module_instance)
    if isinstance(strategy_module_instance, StrategyModule):
        print('StrategyModule instance')


# Generated at 2022-06-25 12:00:07.376982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:00:11.818764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0()


# Generated at 2022-06-25 12:00:12.961873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    msg = 'StrategyModule of linear strategy should be callable'
    assert callable(StrategyModule), msg


# Generated at 2022-06-25 12:00:22.367619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if hasattr(StrategyModule, '__init__'):
        if callable(StrategyModule.__init__):
            test_case_0()
        else:
            print('[FAILED] : Constructor of StrategyModule is not callable')
            sys.exit(1)
    else:
        print('[FAILED] : Constructor of StrategyModule is not callable')
        sys.exit(1)
    
    print('[SUCCESS] : Constructor of StrategyModule is callable')

if __name__ == '__main__':
    # Unit test
    test_StrategyModule()

# Generated at 2022-06-25 12:00:26.104996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    state = False
    try:
        StrategyModule()
    except:
        state = True
    assert(state == True)
    return True

# Get all ansible module

# Generated at 2022-06-25 12:00:30.936568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    try:
        StrategyModule()
    except TypeError:
        pass
    except:
        raise
    else:
        raise AssertionError(str_0)

# Generated at 2022-06-25 12:00:35.361860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print('test case 0: ' + 'passed')
    except AssertionError as e:
        print('test case 0: ' + 'failed')


# Generated at 2022-06-25 12:00:38.333373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0()

if __name__ == "__main__":
    if "test" in sys.argv:
        test_StrategyModule()



# Generated at 2022-06-25 12:00:40.740800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    return strategy_module


# Generated at 2022-06-25 12:00:43.461133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    tqm = object()
    try:
        strategy_module = StrategyModule(tqm)
    except:
        assert 0, test_case_0()
    else:
        assert 1


# Generated at 2022-06-25 12:00:45.874817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    setattr(StrategyModule, '__init__', StrategyModule.__init__)

    if (not callable(StrategyModule.__init__) 
            and 'Constructor of StrategyModule is not callable'):
        raise AssertionError(str_0)

# Generated at 2022-06-25 12:00:48.064075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    try:
        StrategyModule
    except NameError:
        assert True == True
    else:
        assert True == False
    # Test case 1
    o_1 = StrategyModule(TestTQM(None))
    # Test case 2
    o_2 = StrategyModule(TestTQM(None))



# Generated at 2022-06-25 12:00:49.684030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assert that returned value from method __init__ is not None
    assert test_case_0() is None


# Generated at 2022-06-25 12:00:52.300039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if (StrategyModule == None):
        test_case_0()
    else:
        print("Constructor of StrategyModule is working as expected")

test_StrategyModule()

# Generated at 2022-06-25 12:00:53.410719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:56.125525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0()

test_StrategyModule()



# Generated at 2022-06-25 12:00:58.109844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule) == True, test_case_0()



# Generated at 2022-06-25 12:01:02.261106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule.__init__(StrategyModule)
    except:
        AssertionError(test_case_0)

test_StrategyModule()

# Generated at 2022-06-25 12:01:03.830492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), 'Constructor of StrategyModule is not callable'


# Generated at 2022-06-25 12:01:05.900967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if not callable(StrategyModule):
        raise Exception(test_case_0())


# Generated at 2022-06-25 12:01:08.236856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_StrategyModule = StrategyModule(None)
    assert isinstance(obj_StrategyModule, StrategyModule)
    del obj_StrategyModule

# Generated at 2022-06-25 12:01:13.323227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    try:
        StrategyModule()
    except TypeError:
        pass
    except:
        raise RuntimeError('Case 0 failed: ' + str_0)


# Generated at 2022-06-25 12:01:14.093835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:01:19.303485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError:
        test_case_0()
    else:
        print('StrategyModule Error: constructor is callable')

if __name__ == '__main__':
    test_StrategyModule()


# Generated at 2022-06-25 12:01:23.880789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    try:
        strategy_module = StrategyModule()
    except:
        pass
    assert strategy_module == None, test_case_0()


# Generated at 2022-06-25 12:01:25.031890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        pass
    else:
        raise Exception(test_case_0())

# Generated at 2022-06-25 12:01:29.233222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError:
        test_case_0()
    else:
        raise AssertionError('This statement should not be reached.')

# Ansible playbook test case

# Generated at 2022-06-25 12:01:30.291723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm=None)
    except:
        assert False, test_case_0()
    assert True


# Generated at 2022-06-25 12:01:31.311151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if (StrategyModule.__init__.__name__ == '__init__'):
        return True


# Generated at 2022-06-25 12:01:33.041234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        a = StrategyModule(tqm)
    except:
        assert 1, test_case_0
    else:
        assert 1, test_case_0


# Generated at 2022-06-25 12:01:34.907289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = 'tqm'
        sm = StrategyModule(tqm)
        test_case_0()
    except TypeError as e:
        print(e)



# Generated at 2022-06-25 12:01:35.653155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if StrategyModule.__init__.__doc__ == None:
        return False
    else:
        return True


# Generated at 2022-06-25 12:01:41.417923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0()
    test_0 = StrategyModule(1)
    # if successful, test_0 should have a property called 'name'
    if not hasattr(test_0, 'name'):
        print('Test case 0 failed, expected result is not returned.')


# Generated at 2022-06-25 12:01:47.975954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:49.074380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0()


# Generated at 2022-06-25 12:01:57.891846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert_0 = isinstance(StrategyModule(), StrategyModule)
    assert_1 = isinstance(StrategyModule(), StrategyModule)
    assert_2 = isinstance(StrategyModule(), StrategyModule)
    assert_3 = isinstance(StrategyModule(), StrategyModule)
    assert_4 = isinstance(StrategyModule(), StrategyModule)
    assert_5 = isinstance(StrategyModule(), StrategyModule)
    assert_6 = isinstance(StrategyModule(), StrategyModule)
    assert_7 = isinstance(StrategyModule(), StrategyModule)
    assert_8 = isinstance(StrategyModule(), StrategyModule)
    assert_9 = isinstance(StrategyModule(), StrategyModule)
    assert_10 = isinstance(StrategyModule(), StrategyModule)
    assert_11 = isinstance(StrategyModule(), StrategyModule)
    assert_12 = isinstance

# Generated at 2022-06-25 12:01:59.182890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return test_case_0()

# Generated at 2022-06-25 12:02:04.587927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        s_m = StrategyModule
        test_case_0()
    except TypeError:
        print('Test of StrategyModule constructor passed')
        return
    else:
        print('Test of StrategyModule constructor failed')
        return

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:08.970720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    debugger = StrategyModule(tqm)

    result_0 = False
    if (str(type(debugger)) == "<class 'ansible.plugins.strategy.debug.StrategyModule'>") or (str(type(debugger)) == "<type 'ansible.plugins.strategy.debug.StrategyModule'>"):
        result_0 = True

    if result_0:
        print('Constructor of StrategyModule is callable')

    elif not result_0:
        sys.exit(test_case_0())

# Generated at 2022-06-25 12:02:10.200157
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:02:12.145336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    try:
        assert strategy, test_case_0()
    except AssertionError as e:
        print(e)
    finally:
        print("Test case 0 passed")


# Generated at 2022-06-25 12:02:13.814351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError:
        print('succ: Constructor of StrategyModule is not callable')
        return 0
    except:
        raise


# Generated at 2022-06-25 12:02:15.539992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Constructor of StrategyModule is not callable'
    try:
        assert(callable(StrategyModule))
    except AssertionError:
        print(str_0)

# Generated at 2022-06-25 12:02:26.628593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0

# Generated at 2022-06-25 12:02:30.479487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule as DebugStrategyModule
    from ansible.plugins.action import ActionModule
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import fragment_loader

    class test_action_module(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    class test_play(object):
        def __init__(self):
            self.hosts = [1,2,3]
            self.roles = [4,5,6]
            self.post_validate

# Generated at 2022-06-25 12:02:34.652889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError as e:
        assert e.message == test_case_0
    else:
        raise AssertionError('Exception must be thrown')

# Generated at 2022-06-25 12:02:40.807568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case = globals()['test_case_0']
    try:
        test_case()
    except Exception as e:
        print("Failed: {}".format(e))
    else:
        print("Passed")


# TODO: test_case_3:  Cannot run with --limit=

# Generated at 2022-06-25 12:02:43.902149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class MockTaskQueueManager():
            pass

        StrategyModule(MockTaskQueueManager())
    except:
        test_case_0()



# Generated at 2022-06-25 12:02:47.379862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    true_0 = True
    if not isinstance(true_0, bool):
        test_case_0()
    else:
        print("Unit test for constructor of class StrategyModule completed")


# Generated at 2022-06-25 12:02:56.069778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = [sys.argv[0], '-i','tm-gce','debug','--start-at-task','ping']
    str_0 = 'Task execution is linear but controlled by an interactive '
    str_1 = 'debug session.'
    str_2 = '| debug_msg: Task execution is linear but controlled by an '
    str_3 = 'interactive debug session.'
    str_4 = 'StrategyModule'
    str_5 = 'true'
    str_6 = 'Constructor of StrategyModule is not callable'
    str_7 = 'TASK [common : ping]'
    str_8 = 'ok: [127.0.0.1]'
    str_9 = 'StrategyModule'
    str_10 = 'false'
    str_11 = 'tm-gce'
    str

# Generated at 2022-06-25 12:03:02.950401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test: %s" % test_case_0.__name__)
    try:
        StrategyModule()
        assert False, 'Error: %s' % test_case_0.__name__
    except TypeError as err:
        print(err.args)
        print('Ok: %s' % test_case_0.__name__) 
    print('\n')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:05.951093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
       StrategyModule.__init__(StrategyModule, 'constructor')
    except Exception as error:
        assert error.args[0] == test_case_0()
        return
    else:
        assert 0, 'expected exception'

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-25 12:03:08.616305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), test_case_0()


# Generated at 2022-06-25 12:03:26.855316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-25 12:03:29.338776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception: " + str(e))
        sys.exit(1)

    sys.exit(0)

# debug.py ends here

# Generated at 2022-06-25 12:03:32.344958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:33.648968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:35.223995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:03:37.661818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:38.636932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:41.049878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 12:03:44.268808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        nil = 0

# Generated at 2022-06-25 12:03:45.770713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = True
    # strategy_module_1 = StrategyModule(bool_1)
    # assert strategy_module_0.debugger_active == True

test_StrategyModule()

# Generated at 2022-06-25 12:04:08.019068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:04:09.005153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:11.184892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    try:
        assert isinstance(strategy_module_0, StrategyModule) and strategy_module_0 is not None
    except AssertionError:
        print("AssertionError: expected StrategyModule, got " + str(StrategyModule.__name__))

# Generated at 2022-06-25 12:04:15.775112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:04:16.429951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor")
    test_case_0()
    print("Done")

# Generated at 2022-06-25 12:04:18.182627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test constructor")
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:22.902524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None, "test_case_0 returned: " + str(test_case_0())
test_StrategyModule()
print("StrategyModule passed unit tests successfully!")

# Generated at 2022-06-25 12:04:24.563105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0


# Generated at 2022-06-25 12:04:25.922507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:04:28.834263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test setting global var
    bool_0 = True
    if bool_0:
        strategy_module_0 = StrategyModule(bool_0)
        assert (strategy_module_0.debugger_active == True)
    else:
        strategy_module_0 = StrategyModule(bool_0)
        assert (strategy_module_0.debugger_active == False)

# Generated at 2022-06-25 12:05:17.333274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:05:18.878051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 12:05:19.984582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:05:20.856752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0()

# Generated at 2022-06-25 12:05:22.005062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:05:23.581194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

#   pprint.pprint(locals())



# Generated at 2022-06-25 12:05:24.222687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:05:24.841926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:05:25.852646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# -------------------------------------------------------------------------------------------------

# Generated at 2022-06-25 12:05:26.567735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:06:57.267822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:59.621492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(strategy_module_0)
    test_case_0()



if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:01.288152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # test_StrategyModule()
    pass

# Generated at 2022-06-25 12:07:02.289056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

###############################################################################

# Generated at 2022-06-25 12:07:09.870784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        strategy_module_0 = StrategyModule(bool)
    except TypeError as err:
        #print(err.args)
        assert err.args[0] == "'bool' object is not callable"

    try:
        strategy_module_0 = StrategyModule(str)
    except TypeError as err:
        #print(err.args)
        assert err.args[0] == "'str' object is not callable"

    try:
        strategy_module_0 = StrategyModule(int)
    except TypeError as err:
        #print(err.args)
        assert err.args[0] == "'int' object is not callable"


# Generated at 2022-06-25 12:07:13.367979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    task_queue_manager_0 = TaskQueueManager()

    # Constructor for class StrategyModule
    strategy_module_0 = StrategyModule(task_queue_manager_0)

    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 12:07:14.504179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:07:15.375445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:07:16.553141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:17.631574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()