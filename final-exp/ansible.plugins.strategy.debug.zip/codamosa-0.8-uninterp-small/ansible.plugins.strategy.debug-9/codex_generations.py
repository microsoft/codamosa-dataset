

# Generated at 2022-06-25 11:58:20.690806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test that the base class has correct type

# Generated at 2022-06-25 11:58:21.969820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)

# Generated at 2022-06-25 11:58:25.408519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    StrategyModule(set_0)


# Generated at 2022-06-25 11:58:26.420799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:29.202452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    # Test for the "__init__" method of class "StrategyModule"
    test_case_0()
    return True

test_case_0()

# Generated at 2022-06-25 11:58:31.819367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing')
    test_case_0()


# Generated at 2022-06-25 11:58:33.428023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # Unit test
    test_StrategyModule()

# Generated at 2022-06-25 11:58:35.784036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)


# Generated at 2022-06-25 11:58:37.119046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 11:58:38.685858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Python Cmd Debugger

# Generated at 2022-06-25 11:58:40.438079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:42.482282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.tqm == set_0
    assert strategy_module_0.debugger_active == True


# Generated at 2022-06-25 11:58:44.701602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    return 0

if __name__ == "__main__":
    test_StrategyModule()
    sys.exit(0)

# Generated at 2022-06-25 11:58:50.845287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert 'StrategyModule' == strategy_module_0.name
    assert 'plugins.strategy.debug' == strategy_module_0.__module__
    assert not strategy_module_0.bypass_host_loop
    assert True == strategy_module_0.debugger_active
    assert not strategy_module_0.playbook_has_become
    assert not strategy_module_0.playbook_has_vars_prompt
    assert not strategy_module_0.become_prompts
    assert not strategy_module_0.var_prompt_meta
    assert not strategy_module_0.var_prompt_meta_task_vars
    assert not strategy_module_0.var_prompt_meta_role_

# Generated at 2022-06-25 11:58:53.211993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exc:
        msg = "Script raised exception: " + str(exc)
        print(msg)
        sys.exit(1)



# Generated at 2022-06-25 11:58:54.063981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:55.500383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 11:58:57.126382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# This is the entry point for unit test of class StrategyModule

# Generated at 2022-06-25 11:58:59.009266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__=='__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:02.054164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:03.535700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-25 11:59:05.102958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()
    # Test case doesn't fail, test passes.

# Generated at 2022-06-25 11:59:05.960866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(set())


# Generated at 2022-06-25 11:59:07.524322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule is tested in test_case_0
    return 0


# Generated at 2022-06-25 11:59:08.924479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)



# Generated at 2022-06-25 11:59:09.705222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()


# Generated at 2022-06-25 11:59:11.301930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except AssertionError:
        pass
    except Exception:
        assert False



# Generated at 2022-06-25 11:59:13.299707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active == True



# Generated at 2022-06-25 11:59:16.039709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule:\n")
    test_case_0()

if __name__ == '__main__':
    print("test_StrategyModule done")
    sys.exit(0)

# Generated at 2022-06-25 11:59:18.239526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:29.664782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active == True
    assert strategy_module_0.hostvars == {}
    assert strategy_module_0.hostvars_teardown == []
    assert strategy_module_0.hostvars_post_tasks == {}
    assert strategy_module_0.hostvars_pre_tasks == {}
    assert strategy_module_0.hostvars_pre_tasks_always == {}
    assert strategy_module_0.host_states == {}
    assert strategy_module_0.host_states_teardown == []
    assert strategy_module_0.iterator == None
    assert strategy_module_0.noop_task_result == {}
    assert strategy_module_0.task

# Generated at 2022-06-25 11:59:30.423904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 11:59:35.090562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)
    assert strategy_module_1 is not None

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:59:40.432056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_0 = StrategyModule(set_1)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 11:59:40.953015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(set())


# Generated at 2022-06-25 11:59:42.655581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for constructor of class StrategyModule')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:43.702131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Failed test_case_0")
        raise

# Generated at 2022-06-25 11:59:49.085954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Import testcase_base for testcase which use unittest
from testcase_base import TestCaseBase

# Import other test suites
from testcase_adhoc import TestAdhoc
from testcase_module_args import TestModuleArgs
from testcase_module_common import TestModuleCommon
from testcase_module_utils import TestModuleUtils
from testcase_module_utils_basic import TestModuleUtilsBasic
from testcase_module_utils_common import TestModuleUtilsCommon
from testcase_module_utils_connection import TestModuleUtilsConnection
from testcase_module_utils_crypto import TestModuleUtilsCrypto
from testcase_module_utils_json import TestModuleUtilsJson
from testcase_module_utils_loader import TestModuleUtilsLoader

# Generated at 2022-06-25 11:59:50.414969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try: 
        test_case_0()
    except:
        print("Failed test case 0")


# Generated at 2022-06-25 11:59:51.422441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule')
    print('Constructor')
    test_case_0()


# Generated at 2022-06-25 11:59:56.452062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test_case_0 :
    # test_case_0()

    # Execution should never reach here.
    assert True == False


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:00.257115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    # Unit-tests
    test_StrategyModule()

# Generated at 2022-06-25 12:00:07.193006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
# Debugging starts here
    strategy_module_1 = strategy_module_0
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)
    set_1 = set()
    strategy_module_2 = StrategyModule(set_1)
    strategy_module_2 = strategy_module_0
    strategy_module_1 = strategy_module_0
    set_1 = set()
    strategy_module_0 = StrategyModule(set_1)
    set_1 = set()
    strategy_module_2 = StrategyModule(set_1)
    strategy_module_2 = strategy_module_1
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)
    set_

# Generated at 2022-06-25 12:00:13.389958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert isinstance(strategy_module_0, LinearStrategyModule) and isinstance(strategy_module_0, StrategyModule) and isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:00:19.326876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result_hash = {}
    result_hash['constructor'] = []
    test_case_0()
    if strategy_module_0.debugger_active:
        result_hash['constructor'] = 'PASS'
    else:
        result_hash['constructor'] = 'FAIL'

    return result_hash



# Generated at 2022-06-25 12:00:22.271281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError as ne:
        assert False , "Unit test for constructor of class StrategyModule failed: " + ne.__str__()
    else:
        assert True, "Unit test for constructor of class StrategyModule passed"



# Generated at 2022-06-25 12:00:25.786726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:00:31.988869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert set_0 == set_0
    assert not set_0
    assert strategy_module_0.debugger_active
    assert strategy_module_0.tqm is set_0



# Generated at 2022-06-25 12:00:34.475391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    return

# Unit tests for class StrategyModule

# Generated at 2022-06-25 12:00:37.264978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Test of constructor StrategyModule failed.")
        raise


# Generated at 2022-06-25 12:00:52.248332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    # Debugger
    # Call the debugger using 'python -m pdb' and pass the module name 'ansible.plugins.strategy.debug' as argument
    # Passing 'ansible.plugins.strategy.debug' as argument will automatically sets the trace for the calling method ' run' of
    # class StrategyModule
    debugger_0 = StrategyModule(sys.argv[0])
    pass

# Debugger
# Debugger sample tests
if __name__ == '__main__':
    test_StrategyModule()
    pass

# Generated at 2022-06-25 12:00:54.163804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)



# Generated at 2022-06-25 12:00:56.646831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

    print ("Successfully passed all test cases")

# Generated at 2022-06-25 12:00:57.959757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:01.944468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test run
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:02.776138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:05.791964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:01:09.587139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Constructor of class StrategyModule did not perform as expected.")
        raise
    else:
        print("Constructor of class StrategyModule performed as expected.")

# unit test

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:01:14.250649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test StrategyModule')
    print('test_case_0')
    test_case_0()

if __name__ == "__main__":
    print('begin unit tests')
    print('=' * 10)
    test_StrategyModule()
    print('=' * 10)
    print('end unit tests')

# Generated at 2022-06-25 12:01:19.980678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check if str(obj) is in output
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert "strategy.debug.StrategyModule object at" in str(strategy_module_0)
    assert "strategy.debug.StrategyModule object at" in repr(strategy_module_0)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:01:38.724345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert isinstance(strategy_module_0, StrategyModule) == true


# Generated at 2022-06-25 12:01:39.748382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_run_module_set_0 = set()
    strategy_module_0 = StrategyModule(ansible_run_module_set_0)


# Generated at 2022-06-25 12:01:42.118574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active == True



# This class is used to initialize the debugger environment.

# Generated at 2022-06-25 12:01:46.806170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:01:47.614557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:01:49.316637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    # Testing for constructor of class 'StrategyModule'
    strategy_module_0 = StrategyModule(set_0)



# Generated at 2022-06-25 12:01:50.429151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 0  # TODO: implement your test here


# Generated at 2022-06-25 12:01:51.181999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests

# Generated at 2022-06-25 12:01:54.704109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(set())
    assert isinstance(strategy_module_0, StrategyModule)

test_classes = [StrategyModule]
test_case_0()

# Generated at 2022-06-25 12:01:58.054609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.errors import AnsibleError
    try:
        strategy_module_1 = StrategyModule(set())
    except:
        print('test_StrategyModule() raised unexpected exception')
        raise
#     else:
#         print('test_StrategyModule() did not raise exception')
#     print(strategy_module_1.__str__())
#     print(strategy_module_1.__repr__())
#     print(str(strategy_module_1))
#     print(repr(strategy_module_1))



# Generated at 2022-06-25 12:02:43.716829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First test case
    test_case_0()

if __name__ == "__main__":
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-25 12:02:45.597078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:02:46.414853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:02:49.529937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert 1==0
    else:
        assert 1==1

# Test if run function of class StrategyModule is invoked when using strategy 'debug'
# and breaks when debugger_active is set to True

# Generated at 2022-06-25 12:02:51.320399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:02:54.036490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_var = set()
    strategy_module_var = StrategyModule(set_var)
    set_var.add(strategy_module_var)



# Generated at 2022-06-25 12:02:57.163321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert test_case_0() is None
    print('StrategyModule.__init__ test successful')

# tests begin here
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:57.699882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:03:02.142485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:07.917845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # set up object
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

    assert not strategy_module_0.RUN_STATE

    assert not strategy_module_0.DEBUG_BROKEN_TASKS

    assert not strategy_module_0.DEBUG_HOSTS

    assert not strategy_module_0.DEBUG_TAGS

    assert not strategy_module_0.DEBUG_VARS

    assert not strategy_module_0.DEBUG_RESULT_CALLBACK

    if getattr(strategy_module_0, '_tqm', None) is not None:
        strategy_module_0._tqm = None

    # set up object
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

# Generated at 2022-06-25 12:04:38.616287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert_equal(strategy_module_0.debugger_active, True)

if __name__ == "__main__":
    run_module_suite()

# Generated at 2022-06-25 12:04:39.398774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:04:43.002766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print("test_case_0: FAILED")
        print(e)
    else:
        print("test_case_0: PASSED")


# Generated at 2022-06-25 12:04:45.438700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.debugger_active is True



# Generated at 2022-06-25 12:04:47.107318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:04:48.498389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:04:50.281040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    try:
        StrategyModule(set_0)
    except AttributeError:
        raise AttributeError('An attribute error occurred!')


# Generated at 2022-06-25 12:04:51.480236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("failed in test_case_0")


# Generated at 2022-06-25 12:04:53.673980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    strategy_module_0.debugger_active = False
    assert strategy_module_0.debugger_active == False




# Generated at 2022-06-25 12:04:56.118835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n\n========================")
    print("\nTest function is: " + test_case_0.__name__)
    test_case_0()
    print("\n========================\n")

# This class is responsible for controlling the execution of the tasks of ansible

# Generated at 2022-06-25 12:08:13.203624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:14.448783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:08:15.036941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:08:16.055523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:08:17.392401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    
    
