

# Generated at 2022-06-17 13:51:11.262673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:12.073865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-17 13:51:14.559082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:51:16.920872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:24.095121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:26.106097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:51:27.504708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:28.141581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:51:38.856462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__name__ == 'StrategyModule'
    assert StrategyModule.__init__.__qualname__

# Generated at 2022-06-17 13:51:41.801852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:44.659275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:52.909028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__defaults__ == (None,)
    assert StrategyModule.__dict

# Generated at 2022-06-17 13:51:56.931081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:59.550801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:01.883420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:08.607043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test object
    test_obj = StrategyModule(None)
    # Check if the object is an instance of class StrategyModule
    assert isinstance(test_obj, StrategyModule)
    # Check if the object is an instance of class LinearStrategyModule
    assert isinstance(test_obj, LinearStrategyModule)
    # Check if the debugger_active attribute is set to True
    assert test_obj.debugger_active == True


# Generated at 2022-06-17 13:52:10.125876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement
    pass


# Generated at 2022-06-17 13:52:15.118811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__init__.__func__.__name__ == '__init__'
    assert StrategyModule.__init__.__func__.__doc__ == None
    assert StrategyModule.__init__.__func__.__dict__ == dict()
    assert StrategyModule.__init__.__func__.__defaults__ == None
    assert StrategyModule.__init__.__func__.__code__.co_argcount == 3
    assert StrategyModule.__init__.__func__

# Generated at 2022-06-17 13:52:16.155416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:18.267207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:21.822681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:52:24.876041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__


# Generated at 2022-06-17 13:52:25.771776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:29.182954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:43.328093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:52:45.361180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:52:45.851245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:52:47.776878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:49.982831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:52:51.648314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Write unit test
    pass


# Generated at 2022-06-17 13:52:57.433365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with no parameters
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:07.404301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_next_task_for_host.__doc__ == LinearStrategyModule.get_next_task_for_host.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.add_tasks.__doc__ == LinearStrategyModule.add_tasks.__doc__

# Generated at 2022-06-17 13:53:08.944855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with empty constructor
    StrategyModule()


# Generated at 2022-06-17 13:53:10.941239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:53:18.626683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''
    name: debug
    short_description: Executes tasks in interactive debug session.
    description:
        - Task execution is 'linear' but controlled by an interactive debug session.
    version_added: "2.1"
    author: Kishin Yagami (!UNKNOWN)
'''
    assert StrategyModule.__init__.__doc__ == '''
    Initialize the strategy module.
    '''
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == (None,)
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
   

# Generated at 2022-06-17 13:53:24.949883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__

# Generated at 2022-06-17 13:53:26.054834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:27.315393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:27.958748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:53:30.781394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__



# Generated at 2022-06-17 13:53:47.855598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None
    assert StrategyModule.run.__doc__ is not None
    assert StrategyModule.get_host_list.__doc__ is not None
    assert StrategyModule.get_next_task_for_host.__doc__ is not None
    assert StrategyModule.get_failed_hosts.__doc__ is not None
    assert StrategyModule.get_changed_hosts.__doc__ is not None
    assert StrategyModule.get_skipped_hosts.__doc__ is not None
    assert StrategyModule.get_unreachable_hosts.__doc__ is not None
    assert StrategyModule.get_host_result.__doc__ is not None
    assert StrategyModule.get_host_list.__doc__ is not None

# Generated at 2022-06-17 13:53:56.881337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:00.430931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_StrategyModule()
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:01.866137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:03.931605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:04.543779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:06.614994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:12.750446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:13.345248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:54:16.400959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:41.932166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__module__ == LinearStrategyModule.__module__
    assert StrategyModule.__bases__ == (LinearStrategyModule,)
    assert StrategyModule.__dict__.keys() == ['__init__']
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__doc__ == '\n    '
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__defaults__ == (None,)

# Generated at 2022-06-17 13:54:45.271535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:47.650048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:50.058508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:52.458775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:53.444376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:54:54.367911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:54:57.217361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:09.711127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and runs the module on each host before moving on.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:12.030527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:55:46.109013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:47.373763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:55:48.947316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)
    assert StrategyModule(tqm).debugger_active == True


# Generated at 2022-06-17 13:55:52.328963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:54.021507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:55:55.368103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:55.887012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:56.950882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:56:07.931548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:12.312263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.stats = {}
    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:57:29.704867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:31.622582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:57:34.586236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:57:38.017262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:41.334869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:51.816754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def __init__(self):
            self.stats = dict()
            self.hostvars = dict()
            self.inventory = dict()
            self.vars = dict()
            self.vars_cache = dict()
            self.default_vars = dict()
            self.extra_vars = dict()
            self.options = dict()
            self.passwords = dict()
            self.callback = dict()
            self.shared_loader_obj = dict()
            self.variable_manager = dict()
            self.loader = dict()
            self.filter_plugin_manager = dict()
            self.connection_plugin_manager = dict()
            self.stdout_callback = dict()
            self.notified_handlers = dict()
            self.playbook = dict()
           

# Generated at 2022-06-17 13:57:53.651693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:55.877615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:57.026557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:58:01.939071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'


# Generated at 2022-06-17 14:00:36.366831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-17 14:00:47.734816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 14:00:56.063410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 14:01:00.244659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None
    assert StrategyModule.run.__doc__ is not None


# Generated at 2022-06-17 14:01:03.930504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 14:01:05.086331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 14:01:07.227273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-17 14:01:08.026586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)
