

# Generated at 2022-06-17 13:51:07.206918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:08.256539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-17 13:51:10.477446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:20.655473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:21.903270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:51:32.076297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:34.733558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:35.581736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:51:47.571891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:48.868627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:51:52.057697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:55.497969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:58.197072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:01.572339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: mock tqm
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:07.590225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:09.519700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:52:13.274292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__defaults__ == (None,)
    assert StrategyModule.__dict

# Generated at 2022-06-17 13:52:21.657136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:28.478149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'


# Generated at 2022-06-17 13:52:31.658315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.debug"
    assert StrategyModule.__doc__ == "Executes tasks in interactive debug session."


# Generated at 2022-06-17 13:52:37.009052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:38.653037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__


# Generated at 2022-06-17 13:52:47.279315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:52:51.257345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:54.351839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:56.773521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:06.754724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:09.152298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:10.691962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:12.198924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:27.105355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:37.430612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__init__.__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert StrategyModule.__init__.__code__.co_argcount == 2


# Generated at 2022-06-17 13:53:39.335668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:47.152845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    Executes tasks in interactive debug session.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:57.508325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Constructor of class StrategyModule'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.run.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.run.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.run.__name__ == 'run'
    assert StrategyModule.run_async.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.run

# Generated at 2022-06-17 13:54:00.102332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:54:01.193713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:54:09.904444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:12.622268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:19.528012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:28.912319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:29.791963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:42.562716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__init__.__doc__ == '\n        Initialize the strategy module.\n        '

# Generated at 2022-06-17 13:54:53.699703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:55.849191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:59.001139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:00.912339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:55:10.305647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:10.931005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:55:13.536103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:32.412961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:35.203239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:37.659826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:55:41.355127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:43.764816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:44.833261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:55:46.997927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with empty tqm
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:54.460651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:04.620787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-17 13:56:07.703291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:56:42.087275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:56:43.250929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:56:45.052592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:56:46.759134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:56:49.712831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''
    name: debug
    short_description: Executes tasks in interactive debug session.
    description:
        - Task execution is 'linear' but controlled by an interactive debug session.
    version_added: "2.1"
    author: Kishin Yagami (!UNKNOWN)
'''


# Generated at 2022-06-17 13:56:51.103250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:56:52.056692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test
    pass


# Generated at 2022-06-17 13:57:01.861813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-17 13:57:02.590485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:57:14.024630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply\n    iterates over all hosts and runs the module on each host\n    before moving on.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:58:18.558926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:58:19.699733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:58:21.952664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:58:24.387311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:58:31.028464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:58:45.315197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:58:46.843854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement unit test for constructor of class StrategyModule
    pass


# Generated at 2022-06-17 13:58:48.382703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:59:00.394296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:59:11.369709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__defaults__ == (None,)
    assert StrategyModule.__dict