

# Generated at 2022-06-17 13:51:08.898478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:51:13.971477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)


# Generated at 2022-06-17 13:51:22.677673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == None
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert StrategyModule.__init__

# Generated at 2022-06-17 13:51:24.070612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:35.281740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__defaults__ == ()

# Generated at 2022-06-17 13:51:38.097536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:40.292802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:43.729413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:50.453128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:53.848821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:57.809345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:00.377040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:01.486678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:52:02.843575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:52:12.712785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:15.113078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:25.814016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:52:29.182848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:52:32.957451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:44.539403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:52:48.673430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:52.763731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:55.532667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:57.042574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:53:00.347828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:01.379106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:02.620232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:53:05.489543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:06.478898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:08.794938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:14.338231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:16.338057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:53:29.034878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__name__ == 'StrategyModule.__init__'

# Generated at 2022-06-17 13:53:31.248074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:53:32.083888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:53:44.137687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:55.704039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__

# Generated at 2022-06-17 13:53:59.072723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:07.069789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)


# Generated at 2022-06-17 13:54:16.993517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:26.846138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:27.806546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement
    pass


# Generated at 2022-06-17 13:54:38.579729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert Strategy

# Generated at 2022-06-17 13:54:47.895869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_argcount == 3
    assert StrategyModule.__init__.__code

# Generated at 2022-06-17 13:54:56.528943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and runs the module on each host before moving on. This is the\n    fastest strategy and should work for the vast majority of use cases.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:57.814128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:59.129429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:02.240414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:04.891898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:07.510651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:29.165964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule
    # Arrange
    tqm = None
    # Act
    strategy_module = StrategyModule(tqm)
    # Assert
    assert strategy_module is not None
    assert strategy_module.debugger_active is True


# Generated at 2022-06-17 13:55:33.438012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:45.737387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:48.172748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:49.995631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:51.622532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:56:03.807288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:09.124533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_argcount == 3
    assert StrategyModule.__init__.__code

# Generated at 2022-06-17 13:56:10.412394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:56:22.838702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:02.063910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:04.816998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:07.558131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:09.873798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:12.120771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:13.694791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:57:15.816517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:17.771289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:18.724998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:57:29.217045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:58:36.277117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:58:38.263985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:58:49.506041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__name__ == 'StrategyModule'
    assert StrategyModule.__init__.__qualname__ == 'StrategyModule.__init__'
    assert StrategyModule.__init__.__defaults__ == (None,)
    assert StrategyModule.__init__.__kwdefaults__ == {}
    assert StrategyModule.__init__.__annotations

# Generated at 2022-06-17 13:58:52.405292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:58:54.096431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:58:55.702201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:58:57.419827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:58:58.656442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:59:00.241453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:59:09.125016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
