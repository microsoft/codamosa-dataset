

# Generated at 2022-06-17 13:51:10.732502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:13.488239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:51:16.040108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:17.265510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:24.299269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:51:35.534078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.stats = {}
            self.hostvars = {}
            self.inventory = {}
            self.variable_manager = {}
            self.loader = {}
            self.shared_loader_obj = {}
            self.options = {}
            self.callback = {}
            self.callbacks = {}
            self.stdout_callback = {}
            self.run_additional_callbacks = {}
            self.run_tree = {}
            self.inventory_manager = {}
            self.variable_manager = {}
            self.loader = {}
            self.shared_loader_obj = {}
            self.options = {}
            self.callback = {}
            self.callbacks = {}
            self.stdout_callback = {}
            self.run_additional_callbacks

# Generated at 2022-06-17 13:51:38.898140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:49.752737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:51:53.059156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:51:55.556809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:59.002264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:01.468789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:06.902630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.hostvars = {}
            self.inventory = {}
            self.vars = {}

    tqm = TestTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:09.629573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:11.206413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:11.845171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:52:16.110143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and sequentially runs all tasks for each host.\n    '


# Generated at 2022-06-17 13:52:17.134097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:19.133927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:52:20.539192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:52:32.773393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:44.489483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:50.435619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.hosts = dict()
            self.hosts['localhost'] = dict()
            self.hosts['localhost']['vars'] = dict()
            self.hosts['localhost']['vars']['ansible_connection'] = 'local'
            self.hosts['localhost']['vars']['ansible_python_interpreter'] = sys.executable
            self.hosts['localhost']['vars']['ansible_debug'] = True
            self.hosts['localhost']['vars']['ansible_debug_host'] = 'localhost'
            self.hosts['localhost']['vars']['ansible_debug_port'] = '1234'

# Generated at 2022-06-17 13:53:02.505858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:05.396735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:07.764664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:09.026180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:09.634449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:53:10.560240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:11.447843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-17 13:53:16.700266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:20.493443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a class object
    strategy_module = StrategyModule(None)
    # Check if the variable is initialized correctly
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:22.798556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:53:32.247222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:33.340550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:53:34.242535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:53:36.716456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:37.922527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:53:39.959466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:41.480732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:53:58.572649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and runs the module on each host before moving on. This is the\n    fastest strategy and it behaves similarly to past versions of Ansible\n    but it does not give you as much control over the execution of the\n    play.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:08.644305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__init__.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__

# Generated at 2022-06-17 13:54:11.667024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:54:13.305771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:16.058775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:17.865260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:21.068034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule object
    strategy_module = StrategyModule(None)
    # Check if debugger_active is true
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:30.545609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:31.098485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:33.109825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__


# Generated at 2022-06-17 13:54:50.240690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:59.619084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:11.229298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:55:13.862593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:15.278700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:55:16.213195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:19.221347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.stats = {}
    tqm = TestTQM()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:23.131536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)



# Generated at 2022-06-17 13:55:25.694806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:28.408400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:56:01.599358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:56:02.294400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:56:07.639969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:20.500457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:22.007501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:56:24.241708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:56:26.203744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement unit test for constructor of class StrategyModule
    pass


# Generated at 2022-06-17 13:56:27.661169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:56:29.085243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:56:42.942976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:55.979979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:57:57.110846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:58:04.783156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.run.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.run.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.run.__name__ == 'run'
    assert StrategyModule.run.__defaults__ == (None,)

# Generated at 2022-06-17 13:58:06.955434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:58:15.486440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:58:16.533888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:58:19.190464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:58:19.805128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:58:30.118931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert Strategy

# Generated at 2022-06-17 13:58:32.065384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)
