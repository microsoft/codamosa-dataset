

# Generated at 2022-06-17 13:51:11.926319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:14.421288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:17.788885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'


# Generated at 2022-06-17 13:51:19.142635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:51:20.006959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:24.123710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:27.348259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:28.538151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:29.522604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:33.600805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:35.491321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-17 13:51:36.700352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:39.378859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:51:50.184607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == 'Task execution is \'linear\' but controlled by an interactive debug session.'
    assert StrategyModule.__dict__['__init__'].__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'
    assert StrategyModule.__dict__['__init__'].__qualname__ == 'StrategyModule.__init__'
   

# Generated at 2022-06-17 13:51:52.227533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:51:53.769681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 13:51:55.985106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:51:58.502397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:01.010789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:03.388023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:06.953160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:52:10.603386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__


# Generated at 2022-06-17 13:52:11.200336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:52:12.453095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:15.272320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:17.325763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:18.523271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:52:19.049619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:52:29.309768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__['__init__'].__doc__ == '\n        Initialize the strategy module.\n        '
    assert StrategyModule.__dict__['__init__'].__code__.co_v

# Generated at 2022-06-17 13:52:33.978855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:38.524835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:47.182723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:52:50.467662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:51.863088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:52:54.968158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-17 13:52:57.378797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:52:58.464310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:53:00.866269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:04.480728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock task queue manager
    tqm = MockTaskQueueManager()
    # Create a strategy module
    strategy_module = StrategyModule(tqm)
    # Assert that the debugger is active
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:05.849450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:53:25.683336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert StrategyModule.run.__doc__ == LinearStrategyModule.run.__doc__
    assert StrategyModule.get_host_list.__doc__ == LinearStrategyModule.get_host_list.__doc__
    assert StrategyModule.get_failed_hosts.__doc__ == LinearStrategyModule.get_failed_hosts.__doc__
    assert StrategyModule.get_changed_hosts.__doc__ == LinearStrategyModule.get_changed_hosts.__doc__
    assert StrategyModule.get_dark_hosts.__doc__ == LinearStrategyModule.get_dark_hosts.__doc__
    assert StrategyModule.get_

# Generated at 2022-06-17 13:53:26.328314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-17 13:53:27.345461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-17 13:53:37.636909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__defaults__ == ()
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert Strategy

# Generated at 2022-06-17 13:53:39.563201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:41.884330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:53:54.637575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:53:57.920924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'


# Generated at 2022-06-17 13:54:00.323524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:01.431596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:16.704907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-17 13:54:18.641754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:30.104093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:54:34.325246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:54:44.188691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__qualname__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__dict__ == dict()
    assert StrategyModule.__subclasses__() == []

# Generated at 2022-06-17 13:54:46.548638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:47.651749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 13:54:50.052888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:54:51.040402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:54:53.617879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 1
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:24.525408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None


# Generated at 2022-06-17 13:55:33.636095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:35.323421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 13:55:39.212523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:55:42.573609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 13:55:50.842067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:55:51.474939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-17 13:56:03.633004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    assert StrategyModule.__init__.__doc__ == '''Constructor of class StrategyModule.'''
    assert StrategyModule.run.__doc__ == '''Runs the tasks/playbook.'''
    assert StrategyModule.cleanup.__doc__ == '''Cleans up the strategy module object.'''
    assert StrategyModule.get_host_list.__doc__ == '''Returns the list of hosts to iterate over.'''
    assert StrategyModule.get_next_task_for_host.__doc__ == '''Returns the next task for the given host.'''
    assert StrategyModule.get_failed_hosts.__doc__ == '''Returns the list of failed hosts.'''

# Generated at 2022-06-17 13:56:11.569701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:56:14.168102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-17 13:57:21.179965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 13:57:22.281478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test
    pass



# Generated at 2022-06-17 13:57:30.528413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:31.453919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-17 13:57:39.467077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == LinearStrategyModule.__doc__
    assert StrategyModule.__name__ == LinearStrategyModule.__name__
    assert StrategyModule.__module__ == LinearStrategyModule.__module__
    assert StrategyModule.__bases__ == (LinearStrategyModule,)
    assert StrategyModule.__dict__ == LinearStrategyModule.__dict__


# Generated at 2022-06-17 13:57:50.269948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:56.164981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 13:57:57.582627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-17 13:58:07.327196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and runs the module on each host before moving on. This is the\n    fastest strategy and it is the default.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)
    assert StrategyModule.__init__.__doc__ == '\n        Initialize the class\n        '
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init

# Generated at 2022-06-17 13:58:09.389882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''


# Generated at 2022-06-17 14:00:41.246042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-17 14:00:50.305393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    This is the default strategy module, which simply iterates over all\n    hosts and runs the module on each host before moving on. This is the\n    fastest strategy and should work for most use cases.\n    '
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 14:00:52.095378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-17 14:00:58.969877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 14:01:05.640146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.linear.StrategyModule,)

# Generated at 2022-06-17 14:01:06.695452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-17 14:01:07.848024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-17 14:01:10.584536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
