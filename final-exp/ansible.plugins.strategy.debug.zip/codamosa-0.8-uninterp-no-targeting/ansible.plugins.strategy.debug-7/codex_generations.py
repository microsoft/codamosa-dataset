

# Generated at 2022-06-21 07:19:09.440669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        pass

    instance = StrategyModule(FakeTQM())
    assert instance.debugger_active


# Generated at 2022-06-21 07:19:13.439160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    try:
        t = test_StrategyModule()
    except MemoryError:
        assert False, 'Out of Memory'

# Generated at 2022-06-21 07:19:15.904511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock = MockTQM()
    strategy_module = StrategyModule(mock)
    assert strategy_module
    assert strategy_module.tqm == mock
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:19:16.611558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-21 07:19:19.847395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert sm.debugger_active


# Generated at 2022-06-21 07:19:21.208982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-21 07:19:27.907662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    tqm = object
    strategy = StrategyModule(tqm)
    if strategy.debugger_active != True:
        print('Failed!')
        sys.exit(1)
    else:
        print('Passed!')

# Generated at 2022-06-21 07:19:31.571048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #We expect the return value to be an instance of class 'StategyModule'
    assert isinstance(StrategyModule,type)


# Generated at 2022-06-21 07:19:32.359784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:19:34.653307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.debugger_active


# Generated at 2022-06-21 07:19:38.463432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:19:48.805925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.hosts = {}
            self.hosts['192.168.1.1'] = 'Test'
            self.callbacks = {}
            self.callbacks['default'] = None
            self.stats = {}
            self.stats.total_tasks = 0
            self.stdout_callback = 'default'
            self.wait_for_finish = False
            self.threads = 0
            self.run_handlers = False
            self.run_once = False
            self.cksum_save = False
            self.stdout_lines = []
            self.stdout_callback = None
            self.inventory = None
            self.private_data = None
            self.msg_queue = None
            self.timeout = None
            self.forks

# Generated at 2022-06-21 07:19:50.108988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# Generated at 2022-06-21 07:19:54.091243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    module_args = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:19:59.097369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, LinearStrategyModule)



# Generated at 2022-06-21 07:20:02.035790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test to check if StrategyModule class is created
    assert True == True


# Generated at 2022-06-21 07:20:05.785179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        foo = 'bar'

    sm = StrategyModule(FakeTQM())
    assert hasattr(sm, 'debugger_active')



# Generated at 2022-06-21 07:20:07.545281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:20:09.596162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module
    assert type(strategy_module) is StrategyModule
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:20:10.920540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Empty constructor
    sm = StrategyModule()
    assert sm.debugger_active == False


# Generated at 2022-06-21 07:20:15.727215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_TQM:
        pass
    tqm = Test_TQM()
    test_class = StrategyModule(tqm)
    assert test_class.debugger_active == True


# Generated at 2022-06-21 07:20:25.024621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    tqm1 = StrategyModule(tqm)
    assert(tqm1.debugger_active == True)

# == Unit test for print_task_result ==
# print_task_result (self, host, task_result, task)


# Generated at 2022-06-21 07:20:30.277739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    tqm = (1,"two")
    strategy_module = LinearStrategyModule(tqm)
    assert tqm == strategy_module.tqm



# Generated at 2022-06-21 07:20:37.129417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('')
    print(type(obj))
    print(isinstance(obj, StrategyModule))
    print(hasattr(obj, 'debugger_active'))
    print(getattr(obj, 'debugger_active'))

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:20:47.021953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.hostvars = {
                'host1': {},
                'host2': {}
            }
    tqm = TestTQM()
    assert len(tqm.hostvars) == 2
    assert sorted(tqm.hostvars.keys()) == ['host1', 'host2']
    assert tqm.hostvars['host1'] == {}
    assert tqm.hostvars['host2'] == {}


# Generated at 2022-06-21 07:20:51.838485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # use tqm option
    tqm = None

    # call constructor of class
    module = StrategyModule(tqm)

    # check if the following attributes are defined
    assert module.debugger_active


# Generated at 2022-06-21 07:20:55.971313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    return StrategyModule(tqm)


# Generated at 2022-06-21 07:20:59.395209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        sm = StrategyModule(tqm)
    except:
        print("Could not instantiate StrategyModule class")


# Generated at 2022-06-21 07:21:11.420265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


    class Debugger(cmd.Cmd):
        def __init__(self, tqm):
            cmd.Cmd.__init__(self)
            self.prompt = 'ansible> '
            self.tqm = tqm
            self.current_task = None
            self.host = None
            self.current_play = None
            self.current_playbook = None
            self.current_playbook_path = None
            self.last_result = None
            self.onecmd('help')

        def emptyline(self):
            pass

        def printable_task(self, task):

            def _recursify(obj, d=0):
                if isinstance(obj, dict):
                    obj = obj.copy()

# Generated at 2022-06-21 07:21:18.122910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy:
        pass

    tqm = Dummy()
    tqm.send_callback = Dummy()
    tqm.send_callback.stats = Dummy()
    tqm.send_callback.stats.summarize = lambda: None

    StrategyModule(tqm)



# Generated at 2022-06-21 07:21:32.616895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
            super(TestTaskQueueManager, self).__init__(inventory, variable_manager, loader, options, passwords, stdout_callback=stdout_callback)

        def run(self, play):
            super(TestTaskQueueManager, self).run(play)

    class Options():
        def __init__(self):
            self.module_path = C.DEFAULT_MODULE_PATH
            self.forks = 1
            self.step = False
            self.become = False
            self.bec

# Generated at 2022-06-21 07:21:37.874413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dummy_tqm = object()
    strategy_module = StrategyModule(dummy_tqm)
    assert(isinstance(strategy_module, StrategyModule))
    assert(strategy_module.debugger_active)


# Generated at 2022-06-21 07:21:39.474440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)

    assert sm.debugger_active



# Generated at 2022-06-21 07:21:40.924572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude

    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-21 07:21:45.776855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert isinstance(obj, StrategyModule)

    #obj.run()

# Tasks are executed one by one, with the user's approval.

# Generated at 2022-06-21 07:21:51.895893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.tqm_cache == {}
    assert sm.host_cache == {}
    assert sm.host_list == []
    assert sm.runner_queue == []
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:21:57.840985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert sm.tqm == tqm



# Generated at 2022-06-21 07:21:59.997553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  t = dict(one = '1')
  strategy_module = StrategyModule(t)
  assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:22:01.974909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear = StrategyModule('test')
    assert linear.debugger_active == True


# Generated at 2022-06-21 07:22:03.839264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active


# Generated at 2022-06-21 07:22:13.425544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	assert True


# Generated at 2022-06-21 07:22:14.318705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = 'some_tqm')


# Generated at 2022-06-21 07:22:16.706937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(StrategyModule):
        def __init__(self, tqm):
            super(Test, self).__init__(tqm)
            assert self.debugger_active == True
    Test(object())

# Test: ansible-playbook playbook --list-tasks

# Generated at 2022-06-21 07:22:21.166535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert('debug' in __file__)
    # Constructor not implemented in this module
    assert(StrategyModule.__init__.__code__.co_argcount == 1)
    # TODO: verify more about members. Revisit when __init__ is actually implemented




# Generated at 2022-06-21 07:22:24.496030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    ansible.plugins.strategy.debugger.StrategyModule
    """

    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:22:34.835055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ["ansible-playbook", "-c", "local", "playbook.yml"]
    from ansible.cli import CLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 07:22:46.414900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    from ansible.plugins.strategy.linear import StrategyModule

    TASK_TO_FREEZE_NAME = "task_to_freeze_name"
    TASK_TO_FREEZE_ACTION = "task_to_freeze_action"
    TASK_TO_FREEZE_ARGS = {"test_argv_name": "test_argv_name"}

    host = "test_host"


# Generated at 2022-06-21 07:22:55.283453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert "StrategyModule" in str(s)

    #unit test for build_timeout_timer
    #s.build_timeout_timer()

    #unit test for clear_traceback
    s.clear_traceback()
    assert None == None

    #unit test for reset_repl
    s.reset_repl()
    assert None == None

    #unit test for waiting
    s.waiting()
    assert None == None

    #unit test for use_tags
    #s.use_tags("tags")

    #unit test for get_host_list
    s.get_host_list("pattern")
    assert None == None

    #unit test for get_host_variables
    s.get_host_variables("pattern")

# Generated at 2022-06-21 07:22:59.534542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        elem = StrategyModule()
    except:
        assert False, "Could not initialize the StrategyModule class"



# Generated at 2022-06-21 07:23:02.631135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self): pass
    tqm = TestTQM()
    s = StrategyModule(tqm)
    assert s.tqm == tqm


# Generated at 2022-06-21 07:23:19.258193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)
    assert True

# Generated at 2022-06-21 07:23:21.047020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# AsynchronousUnit is a helper class to wrap a task
# and provide Cmd methods

# Generated at 2022-06-21 07:23:23.866700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    main()
    assert True


# Generated at 2022-06-21 07:23:26.216294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test constructor of class StrategyModule")
    print("Testing is done!")



# Generated at 2022-06-21 07:23:32.091420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor
    # str is not a subclass of list, so TypeError
    try:
        StrategyModule('hi')
        assert False
    except TypeError:
        pass
    # Test constructor
    try:
        StrategyModule([])
        assert True
    except TypeError:
        assert False

# Test the class Debugger

# Generated at 2022-06-21 07:23:34.069116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:23:37.234943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

    # execution = StrategyModule(tqm)
    # assert execution.debugger_active



# Generated at 2022-06-21 07:23:43.184466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule')
    print()

    # pylint: disable=no-member

    strategy_module = StrategyModule()

    print('Property debugger_active is True.')
    print(strategy_module.debugger_active)
    print()

    print('Test passed')
    print()



# Generated at 2022-06-21 07:23:45.952177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-21 07:23:53.410748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def __init__(self):
            self.inventory = 'inventory'
            self.variable_manager = 'variable manager'
            self.loader = 'loader'
            self.options = 'options'
            self.passwords = 'passwords'
            self.shared_loader_obj = 'shared_loader_obj'

    tqm = FakeTQM()
    strategy = StrategyModule(tqm)
    assert hasattr(strategy, 'hosts')
    assert hasattr(strategy, 'iterator')


# Generated at 2022-06-21 07:24:42.598456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.result = {'was_failed': False, 'failed_hosts': [],
                           'was_unreachable': False, 'unreachable_hosts': [],
                           'results': []}

        def debug() : pass # TODO

    tqm = TestTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active



# Generated at 2022-06-21 07:24:43.552513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    st = StrategyModule(tqm)
    assert st.debugger_active


# Generated at 2022-06-21 07:24:45.728087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active == True


# Generated at 2022-06-21 07:24:55.826494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        class Options:
            pass
        options = Options()

    tqm = DummyTaskQueueManager()
    tqm.stdout_callback = 'default'
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

# A simplified interactive debugger that can only run one command.
# The command is given as the parameter of do_run.
#
# Note: This class is for test only and doesn't use the actual tasks.
#       It prints a message before and after the command and the class name
#       of the command for test purpose.

# Generated at 2022-06-21 07:24:57.451212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule()


# Generated at 2022-06-21 07:24:58.323897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-21 07:25:00.813923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'TaskExecutor' in str(StrategyModule)



# Generated at 2022-06-21 07:25:06.965642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    reload(ansible.plugins.strategy.debug)

    tqm = NotImplemented
    strategy_module = ansible.plugins.strategy.debug.StrategyModule(tqm)
    assert strategy_module.debugger_active


# Monkey patching for class StrategyModule
StrategyModule.run_plugins = NotImplemented
StrategyModule.run_play = NotImplemented
StrategyModule.cleanup_tasks = NotImplemented



# Generated at 2022-06-21 07:25:07.825425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:25:10.255941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active == True
    assert strategyModule.tqm == None


# Generated at 2022-06-21 07:26:30.034579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule not tested")
# End unit test for constructor of class StrategyModule


# Generated at 2022-06-21 07:26:33.335132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    #strategy = StrategyModule(tqm)
    #assert(strategy.debugger_active == True)


# Generated at 2022-06-21 07:26:34.907887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:26:35.875306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active is False


# Generated at 2022-06-21 07:26:38.181462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # arrange
    tqm = MockTqm()

    # act
    actual = StrategyModule(tqm)

    # assert
    assert actual is not None


# Generated at 2022-06-21 07:26:48.169829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert type(strategy_module) is StrategyModule
    assert strategy_module.tqm is None
    assert strategy_module.hosts is None
    assert strategy_module.inventory is None
    assert strategy_module.variable_manager is None
    assert strategy_module.loader is None
    assert strategy_module.options is None
    assert strategy_module.passwords is None
    assert strategy_module.stdout_callback is None
    assert strategy_module.run_tree is True
    assert strategy_module.debugger_active is True


# Generated at 2022-06-21 07:26:54.463772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('start test StrategyModule')
    # OK = True
    tqm = None
    # call always raise exception
    try:
        StrategyModule(tqm)
    except:
        pass
    print('end test StrategyModule')

test_StrategyModule()

# Generated at 2022-06-21 07:26:55.664364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-21 07:27:01.341653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible.plugins.strategy.linear'] = sys.modules[__name__]
    from ansible.plugins.strategy import debug
    class TQM:
        def __init__(self):
            self.ansible_play_hosts = []
            self.host_list = []
            self.hosts = {}
        def __getitem__(self, name):
            pass
    tqm = TQM()
    s = StrategyModule(tqm)
    assert(isinstance(s, cmd.Cmd))
    assert(s.debugger_active)
    assert(s.help_quit == 'Exit the debugger')


# Generated at 2022-06-21 07:27:02.032213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
