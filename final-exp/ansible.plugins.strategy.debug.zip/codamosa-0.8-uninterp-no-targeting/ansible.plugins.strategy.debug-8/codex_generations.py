

# Generated at 2022-06-21 07:19:11.697214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_module = StrategyModule(None)
    assert debug_module
    assert debug_module.debugger_active



# Generated at 2022-06-21 07:19:13.723762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

# Generated at 2022-06-21 07:19:15.462112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-21 07:19:17.326241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a.debugger_active


# Generated at 2022-06-21 07:19:20.659172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:19:32.776776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.utils.vars import combine_hash
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins import module_loader
    from ansible.errors import AnsibleError
    from ansible.playbook import play_context


# Generated at 2022-06-21 07:19:34.756948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-21 07:19:45.761265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'mock tqm'
    sm = StrategyModule(tqm)
    assert sm is not None
    assert sm.dep_chain is not None
    assert sm.inventory is not None
    assert sm.all_vars is not None
    assert sm.queue_name is not None
    assert sm.run_once is not None
    assert sm.new_stdout is not None
    assert sm.debugger_active is not None
    assert sm.last_task_banner is not None
    assert sm.stats is not None
    assert sm.failed_hosts is not None
    assert sm.unreachable_hosts is not None
    assert sm.tqm is not None



# Generated at 2022-06-21 07:19:51.202106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)

    assert(issubclass(sm.__class__, LinearStrategyModule))
    assert(hasattr(sm, 'debugger_active'))
    assert(sm.debugger_active)



# Generated at 2022-06-21 07:19:52.674754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.test()


# Generated at 2022-06-21 07:19:57.406627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)

    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:19:58.561770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-21 07:20:08.066764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import strategy_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    test_task = Task()
    test_task._role = None
    test_task.action = 'shell'
    test_task.args['creates'] = '$file'
    test_task.args['free_form'] = 'ls'

    test_include = TaskInclude()
    test_include._block = Block

# Generated at 2022-06-21 07:20:09.776573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp_tqm = None
    obj = StrategyModule(tmp_tqm)
    assert obj.debugger_active == True



# Generated at 2022-06-21 07:20:12.502760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a 'fake' TaskQueueManager object.
    tqm = object()
    assert tqm

    # Create an instance of the class StrategyModule.
    obj = StrategyModule(tqm)
    assert obj
    assert isinstance(obj, LinearStrategyModule)


# Generated at 2022-06-21 07:20:13.819988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not self.debugger_active


# Generated at 2022-06-21 07:20:26.569486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.connection.local
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task

    tqm = TaskQueueManager(
        stdout_callback='default',
    )

    current_play_context = PlayContext()
    current_play_context._set_file_name('/home/somebody/playbooks/test.yml')
    tqm.set_play_context(current_play_context)


# Generated at 2022-06-21 07:20:37.995534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        pass
    tqm = TQM()
    tqm.shared_loader_obj = None
    tqm.inventory = '1'
    tqm.variable_manager = '2'
    tqm.loader = '3'
    tqm.options = '4'
    tqm.stdout_callback = '5'
    tqm._initialize_processes(5)

    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-21 07:20:42.315118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = 1
    try:
        StrategyModule(LinearStrategyModule)
        result = 0
    except Exception:
        result = 1
    finally:
        return result



# Generated at 2022-06-21 07:20:46.406287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestLinearStrategyModule()
    s = StrategyModule(tqm)
    assert s.debugger_active == True
    assert s.tqm == tqm


# Generated at 2022-06-21 07:20:50.953345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-21 07:20:59.189581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=passwords, stdout_callback=results_callback)

    sm = StrategyModule(tqm)
    assert sm.tqm == tqm

# Generated at 2022-06-21 07:21:02.451225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None

    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:21:04.671090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-21 07:21:09.344014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = True
    class_instance = None
    try:
        class_instance = StrategyModule(test_tqm)
    except Exception as e:
        print(e)
        raise
    assert class_instance.debugger_active == True


# Generated at 2022-06-21 07:21:10.725481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm=None)



# Generated at 2022-06-21 07:21:22.139928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert isinstance(strategy, cmd.Cmd)
    assert strategy.debugger_active
    assert hasattr(strategy, 'tqm')

# The following code was adapted from the Python Standard Library's
# cmd.py module to allow the StrategyModule class to work with Python 2.6.
# The original code was licensed by PSF as follows:
#
#     PSF LICENSE AGREEMENT FOR PYTHON 3.6.2
#     ...
#     1. This LICENSE AGREEMENT is between the Python Software Foundation
#        ("PSF"), and the Individual or Organization ("Licensee") accessing
#        and otherwise using Python 3.6.2 software in source or binary form
#        and its associated documentation.


# Generated at 2022-06-21 07:21:25.601309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active

# An interactive debugger for Ansible.

# Generated at 2022-06-21 07:21:28.398854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("test")
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:21:32.922508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(None).debugger_active



# Generated at 2022-06-21 07:21:45.825104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    print('Testing if variable self.debugger_active is True')
    assert StrategyModule.debugger_active == True #Test if variable debugger_active is True
    print('Test passed')
    print('Testing if variable self.debugger_active is boolean')
    assert isinstance(StrategyModule.debugger_active, bool) #Test if variable debugger_active is bool
    print('Test passed')
    print('Testing if method StrategyModule is a subclass of LinearStrategyModule')
    assert issubclass(StrategyModule, LinearStrategyModule) #Test if method StrategyModule is a subclass of LinearStrategyModule
    print('Test passed')
    print('Testing if method StrategyModule is a class')
    assert isinstance(StrategyModule, type) #Test if method StrategyModule is a class
    print('Test passed')

# Generated at 2022-06-21 07:21:48.373808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy_module = LinearStrategyModule(None)
    strategy_module = StrategyModule(None)

    # Check instance of StrategyModule
    assert(isinstance(strategy_module, StrategyModule))

    # Check inheritance of StrategyModule
    assert(isinstance(strategy_module, LinearStrategyModule))


# Generated at 2022-06-21 07:21:53.969505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    try:
        tqm = TaskQueueManager(localhost='localhost')
        strategy = StrategyModule(tqm)
        assert(strategy.tqm == tqm)
    finally:
        tqm.cleanup()
        tqm.send_callback('v2_playbook_on_stats', {})


# Generated at 2022-06-21 07:21:59.505152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("---Start StrategyModule---")
    tasks()
    #tqm = lin_strategy_plugin.LinearStrategyModule(tqm)
    #tqm.run()
    


# Generated at 2022-06-21 07:22:02.314095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm_class(object):
        fake_tqm = 1
    test = StrategyModule(tqm_class())
    assert test.debugger_active


# Generated at 2022-06-21 07:22:03.636339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-21 07:22:05.642421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor
    unittest.TestCase()


# Generated at 2022-06-21 07:22:06.406690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:22:11.401130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a task queue manager to use
    tqm = None
    # Create a instance of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Check the result of property 'debugger_active'
    assert strategy_module.debugger_active is True



# Generated at 2022-06-21 07:22:14.862510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object() # create dummy instance
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:22:26.367027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("Test")
    assert strategy_module.debugger_active == True

# Generated at 2022-06-21 07:22:29.701145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True

# test for constructor of class Debugger

# Generated at 2022-06-21 07:22:32.332696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    "Test if the constructor of class StrategyModule is working"

    s = StrategyModule(None)
    assert s.debugger_active
    assert s.host_set == []
    assert s.host_results == {}


# Generated at 2022-06-21 07:22:36.425947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule  constructor")
    #1
    #FIXME
    #if StrategyModule.__module__ == __module__:
    #    print("Unittest is running as a module")

    #2
    strategym = StrategyModule
    assert strategym is not None



# Generated at 2022-06-21 07:22:41.549204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.utils

        class FakeTqm(object):
            pass

        linear = StrategyModule(tqm=FakeTqm())
        assert True
    except ImportError:
        pass


# Generated at 2022-06-21 07:22:53.044997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        class TestContext(dict):
            def __init__(self, x):
                self.x = x

            def __getattr__(self, name):
                return self[name]

        def __init__(self, x):
            self.x = x
            self.context = self.TestContext(x)

    tqm = TestTaskQueueManager(5)
    strategy = StrategyModule(tqm)  # pylint: disable=redefined-outer-name

    assert strategy.debugger_active == True
    assert strategy.tqm == tqm
    assert strategy.tqm.context == tqm.context
    assert strategy.tqm.context.x == 5



# Generated at 2022-06-21 07:23:07.027807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.dummy import DummyModule
    from ansible.module_utils.dummy import DummyTask
    from ansible.module_utils.dummy import DummyTaskResult
    from ansible.module_utils.dummy import Display
    from ansible.module_utils.dummy import Runner
    from ansible.module_utils.dummy import Playbook
    from ansible.module_utils.dummy import Inventory
    from ansible import errors
    from ansible.plugins.strategy import StrategyBase
    tqm = DummyTaskQueueManager(
        'dummyhost',
        playbook,
        inventory,
        display,
        loader,
        options
    )


# Generated at 2022-06-21 07:23:08.091415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:23:16.543021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule([]) is None
 #

    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self.debugger_active = True

    def run(self, iterator, play_context):
        super(StrategyModule, self).run(iterator, play_context)

        if not C.STRATEGY_DEBUG_HOSTS:
            return

        # Note: we clone the list of hosts since the hosts will be removed
        #       from the list as we iterate through it and we may re-use
        #       the list (e.g. in the action_loader.py) later.
        hosts = list(self._tqm._inventory.get_hosts(C.STRATEGY_DEBUG_HOSTS))
        hosts.sort()


# Generated at 2022-06-21 07:23:17.881176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:23:38.231741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)


# Generated at 2022-06-21 07:23:39.309736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:23:40.576876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm is not None


# Generated at 2022-06-21 07:23:46.868466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    class DummyTQM:
        def __init__(self):
            self.play = Play()
            self.play.context = PlayContext(play=self.play)
            self.play.context.prompt = {}

    d = DummyTQM()

    d.play.context.prompt['debug'] = True
    sm = strategy_loader.get('debug')(d)
    assert sm.debugger_active == True
    assert sm.host_list == []

    d.play.context.prompt['debug'] = False
    sm = strategy_loader.get('debug')(d)
    assert sm.debugger_active == False

# Generated at 2022-06-21 07:23:48.268837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) == {'tqm': tqm}


# Generated at 2022-06-21 07:23:53.416396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    assert StrategyModule(tqm).debugger_active == True
    return


# Generated at 2022-06-21 07:23:54.184527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:23:59.261217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        StrategyModule("test_tqm")
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


# Generated at 2022-06-21 07:24:01.334699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:24:05.090158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)

    assert sm.debugger_active == True
    assert sm.tqm == tqm
    assert sm.result_handler == None



# Generated at 2022-06-21 07:25:12.868499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global task_queue_manager
    task_queue_manager = StrategyModule(task_queue_manager)
    assert task_queue_manager.display is not None
    assert task_queue_manager.runner is not None
    assert task_queue_manager.tqm is not None
    assert task_queue_manager.inventory is not None
    assert task_queue_manager.stdout_callback is not None
    assert task_queue_manager._final_q is not None
    assert task_queue_manager._final_q._all_done is False
    assert task_queue_manager._final_q._unfinished_tasks == 0


# Generated at 2022-06-21 07:25:14.837213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '1'
    sm = StrategyModule(tqm)
    assert sm.debugger_active, "debugger active is wrong"


# Generated at 2022-06-21 07:25:21.585792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # unable to mock the constructor of the super class, so we just
    # assume construction of the class StrategyModule was successful
    strategy = StrategyModule(None)
    print('strategy = %s' % strategy)
    assert isinstance(strategy, StrategyModule)


# Generated at 2022-06-21 07:25:26.300263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert x is not None


# Generated at 2022-06-21 07:25:38.650231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class fake_StrategyModule:
        def __init__(self, tqm):
            self.tqm = tqm
    fake_tqm = fake_StrategyModule()
    test_object = StrategyModule(fake_tqm)
    assert test_object.debugger_active is not None


    class fake_module:
        def __init__(self, tqm):
            self.tqm = tqm
    fake_tqm = fake_module()
    test_object = StrategyModule(fake_tqm)
    assert test_object.debugger_active is not None


    class fake_module:
        def __init__(self, tqm):
            self.tqm = tqm
    fake_tqm = fake_module()
    test_object = Strategy

# Generated at 2022-06-21 07:25:43.416409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that StrategyModule constructor executes without errors
    linear_strategy_module = StrategyModule(None)

    # Test that StrategyModule constructor behaves as expected
    assert linear_strategy_module._tqm is None



# Generated at 2022-06-21 07:25:46.944503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:25:51.157615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.debugger_active == True

# Test method of class StrategyModule

# Generated at 2022-06-21 07:25:54.564227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule = StrategyModule()
    assert isinstance(StrategyModule, object)
    assert isinstance(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-21 07:25:56.959762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    instance = StrategyModule('tqm')

    # assert that attributes were correctly set
    assert instance.debugger_active == True


# Generated at 2022-06-21 07:29:17.088694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('test_StrategyModule', (object,), {'stats': ''})
    tqm.hostvars = type('hostvars', (object,), {'hostvars': ''})
    tqm.hostvars.hostvars = {}
    tqm.hostvars.hostvars['host1'] = {'hostname': 'host1'}
    tqm.hostvars.hostvars['host2'] = {'hostname': 'host2'}
    tqm.hostvars.hostvars['host3'] = {'hostname': 'host3'}
    strategy_module = StrategyModule(tqm)
    # When constructor of this class is excecuted,
    # host_list contain host names in hostvars
    assert strategy_module.host_list