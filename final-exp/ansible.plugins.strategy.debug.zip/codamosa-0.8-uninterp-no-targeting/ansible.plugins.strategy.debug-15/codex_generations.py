

# Generated at 2022-06-21 07:19:22.125852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import debug
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host_list = [['127.0.0.1', 'localhost']]

    inv_manager = InventoryManager(loader=None, sources=host_list)

    variable_manager = VariableManager(loader=None, inventory=inv_manager)

    variable_manager.extra_vars = {'ansible_connection': 'local'}


# Generated at 2022-06-21 07:19:35.034955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


    class Debugger(cmd.Cmd):

        def __init__(self, tqm):
            cmd.Cmd.__init__(self)
            self.tqm = tqm
            self.prompt = "pdb > "
            self.doc_header = "Debugger commands (type help <command>):"

            self.intro = "Ansible Debugger"

            if not sys.stdout.isatty():
                sys.stdout = open('/dev/tty', 'w')

        @staticmethod
        def do_exit(_):
            print('Exiting debugger...\n')
            return True

        @staticmethod
        def help_exit():
            print('Exits debugger and continues play\n')

       

# Generated at 2022-06-21 07:19:36.815794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:19:47.120759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.loader import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class Hosts:
        def __init__(self):
            self.hosts = []


# Generated at 2022-06-21 07:19:48.516948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of class StrategyModule.
    # Returned value should be True.
    returnValue = True
    return returnValue


# Generated at 2022-06-21 07:19:50.489475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test StrategyModule initialized")


# Generated at 2022-06-21 07:19:53.236371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module.debugger_active == True


# Generated at 2022-06-21 07:20:02.242849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


#   def __init__(self, tqm):
#       super(StrategyModule, self).__init__(tqm)
#       self.debugger_active = True
#
#
#   def run(self, iterator, play_context):
#       """:arg iterator: A task or play iterator.
#       :arg play_context: Play context which has been setup by the playbook.
#       :returns: Return code
#       """
#
#       self._hosts_cache = {}
#       if self.debugger_active:
#
#           debugger = InteractiveDebug(iterator, self, play_context)
#           debugger.cmdloop()
#
#           if not debugger.has_errored:
#               return 0
#           else:
#               return 1
#       else:
#           return

# Generated at 2022-06-21 07:20:04.837625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod.debugger_active

# Create commands for Debugger

# Generated at 2022-06-21 07:20:08.549043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    playbook = [{'hosts': 'localhost', 'tasks': [{'name': 'test_task', 'debug': 'msg="this is a test"'}]}]
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:20:11.056103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    CmdStrategyModule.run_test()

# Class that imports function 'action' from the class StrategyModule and instantiates the class Debugger

# Generated at 2022-06-21 07:20:12.511150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1==1


# Generated at 2022-06-21 07:20:18.239565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-21 07:20:20.930024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t_inst = StrategyModule('tqm')
    assert t_inst.debugger_active is True



# Generated at 2022-06-21 07:20:23.702026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('test_tqm')
    assert obj.debugger_active is True


# Generated at 2022-06-21 07:20:29.708433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    sm = StrategyModule(test_tqm)
    assert sm.debugger_active



# Generated at 2022-06-21 07:20:31.084921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# unit tests find these

# Generated at 2022-06-21 07:20:33.422162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:20:34.844956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-21 07:20:36.778571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys 
    assert sys.version_info[0] >= 2


# Generated at 2022-06-21 07:20:42.386142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    s = StrategyModule()
    assert s.debugger_active == True


# Generated at 2022-06-21 07:20:45.062170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    assert StrategyModule(tqm)



# Generated at 2022-06-21 07:20:45.748767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)
    assert True



# Generated at 2022-06-21 07:20:47.252445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True, "debugger active"


# Generated at 2022-06-21 07:20:47.989007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:20:52.354973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    tqm = {}
    StrategyModule(tqm)
# END Unit test for constructor of class StrategyModule



# Generated at 2022-06-21 07:21:00.602483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.tasks = []
            self.stats = {}
        def _add_task(self, task):
            self.tasks.append(task)
    tqm = TestTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm is tqm
    assert strategy_module.debugger_active is True



# Generated at 2022-06-21 07:21:11.659820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm = True)
        
    def run(self, iterator, play_context):
        """
        The main strategy entry point. This method is invoked by the executor 
        when it is done setting up the play and will actually run the play.
        """
        
        all_vars = dict((k, self._templar.template(v)) for k, v in self._variable_manager.get_vars(play=self._play).items())
        new_play = self._play.copy()
        new_play.post_validate(all_vars, fail_on_undefined=False)
        
        # Create the cmd line interface to present to the user
        DebugSession(self, iterator).cmdloop()
            

# Generated at 2022-06-21 07:21:16.602422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        def __init__(self):
            self.host_list = None
    tqm = Tqm()
    sm = StrategyModule(tqm)


# Generated at 2022-06-21 07:21:17.455541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:21:21.893551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:21:24.028504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-21 07:21:27.805556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, "__init__")
    assert callable(StrategyModule.__init__)



# Generated at 2022-06-21 07:21:33.391609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    obj = StrategyModule(tqm)
    print(obj.tqm)
    print(obj.debugger_active)
    print(dir(LinearStrategyModule))
#test_StrategyModule()


# Generated at 2022-06-21 07:21:44.747375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils
    import ansible.callbacks
    import ansible.errors
    import tests.utils
    import tests.mock.loader
    import tests.mock.plugins.strategy.linear

    # Create test objects
    tqm = ansible.utils.TestQueueManager(module_name='module',
                                         module_args='args',
                                         timeout=1,
                                         connection='connection',
                                         runner_callbacks=ansible.callbacks.DefaultRunnerCallbacks(),
                                         stats=ansible.callbacks.AggregateStats(),
                                         stdout_callback=None,
                                         verbosity=1,
                                         host_list=['localhost'],
                                         extra_vars={'test': 'test'})


# Generated at 2022-06-21 07:21:46.204840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [0, 1, 1]
    strategy_object = StrategyModule(tqm)
    assert strategy_object.debugger_active == True


# Generated at 2022-06-21 07:21:48.223813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is True


# Generated at 2022-06-21 07:21:51.678943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type
    strategyModule = StrategyModule(None)
    assert strategyModule != None
    assert strategyModule.debugger_active == True


# Generated at 2022-06-21 07:21:55.771227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:21:58.116310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_it = StrategyModule('tqm')
    assert test_it.debugger_active == True


# Generated at 2022-06-21 07:22:11.982806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# TODO: add unit test for apply_async
# TODO: add unit test for _wait_on_pending_results

# dbg_file_handle is set only for unit testing.
# If not set, use sys.stdout as output stream.
dbg_file_handle = None


# Generated at 2022-06-21 07:22:13.766207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule("blah")


# Generated at 2022-06-21 07:22:18.560593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    debugger_active2 = False

    # create an instance of class StrategyModule
    tqm = StrategyModule(None)

    # check if instance of the class was created
    assert (tqm != None)

    # set debugger_active
    tqm.debugger_active = debugger_active

    # check if debugger_active is set to True
    assert (tqm.debugger_active == debugger_active)

    # set debugger_active again
    tqm.debugger_active = debugger_active2

    # check if debugger_active is set to False
    assert (tqm.debugger_active == debugger_active2)


# Generated at 2022-06-21 07:22:19.336418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:22:21.840896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0] == LinearStrategyModule
    assert StrategyModule.debugger_active is True
    assert callable(getattr(StrategyModule, '__init__'))


# Generated at 2022-06-21 07:22:31.333143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # import the module
        _temp = __import__('ansible.plugins.strategy.debug', globals(), locals(), ['StrategyModule'], -1)
        StrategyModule = getattr(_temp, 'StrategyModule')
        debugger = StrategyModule()
        # check debugger_active attribute
        assert debugger.debugger_active == True, "The debugger_active attribute should be True"
    except:
        # import error
        assert False, "The StrategyModule constructor should not fail"


# Generated at 2022-06-21 07:22:34.582680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-21 07:22:36.678540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(0)
    assert t.debugger_active


# Generated at 2022-06-21 07:22:41.771893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        pass
    tqm = TestTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active
    assert strategy_module.tqm is tqm


# Generated at 2022-06-21 07:22:55.289334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=unused-variable,unused-argument

    class MockTaskQueueManager:
        def __init__(self):
            pass

    class MockOptions:
        def __init__(self):
            self.module_path = None
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False

    class MockVariableManager:
        def __init__(self):
            pass

    class MockDisplay:
        def __init__(self):
            pass

    class MockLoader:
        def __init__(self):
            pass

    class MockInventory:
        def __init__(self):
            pass

    class MockVariableManager:
        def __init__(self):
            pass


# Generated at 2022-06-21 07:23:23.387917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import callback_loader
    #import ansible.playbook.play_context
    #import ansible.playbook.play
    import ansible.playbook.task

    class VariableManager(object):
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
            return {}

        def load_extra_vars(self, loader):
            pass

        def load_options_vars(self, options):
            pass


# Generated at 2022-06-21 07:23:24.821260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:23:27.620715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True



# Generated at 2022-06-21 07:23:29.470759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-21 07:23:34.075032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule class constructor test")
    test_strategy_module = StrategyModule("test_tqm")
    print("tqm: " + test_strategy_module.tqm)
    print("host_vars: " + test_strategy_module.host_vars)
    print("blocks: " + test_strategy_module.blocks)



# Generated at 2022-06-21 07:23:44.736617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Prepare mock object
    import copy
    import ansible.plugins.strategy.linear
    class MockTQM:
        def __init__(self):
            self.hostvars = {}
            self.get_host_vars = lambda x: self.hostvars.get(x)
            self.get_vars = None
            self.extra_vars = {}
            self.playbook_dir = None

        def __call__(self):
            return self

    m = MockTQM()
    m.get_vars = lambda x: m.extra_vars.get(x)

    # Prepare test target
    t = StrategyModule(m)

    # Unit test for empty TQM
    assert t.tqm == m
    assert t.get_host_vars(None) == {}
   

# Generated at 2022-06-21 07:23:48.010263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test Constructor of StrategyModule:")
    tqm = None
    sm = StrategyModule(tqm)
    print("Pass Constructor of StrategyModule!")


# Generated at 2022-06-21 07:23:55.858567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule

    class TQM():
        def __init__(self):
            self.loader = self
            self.shell = self

        def get_basedir(self):
            return self

        def get_vault_password(self):
            pass

        def load_resource(self, res):
            return self

    tqm = TQM()
    sm = StrategyModule(tqm)



# Generated at 2022-06-21 07:24:04.934903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self): self.callback = callback
        def cleanup(self): pass
        def send_callback(self, event): pass
        def clear_failed_hosts(self): pass
    class callback:
        def v2_on_any(self, *args, **kwargs): pass
    tqm = tqm()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-21 07:24:08.130439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule("tqm")
    assert res is not None



# Generated at 2022-06-21 07:24:55.441943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    if not strategy_module.debugger_active:
        raise Exception('attribute "debugger_active" of StrategyModule should be True by default')


# Helper function for unit testing

# Generated at 2022-06-21 07:25:04.394340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_tmq(object):
        def __init__(self, tqm):
            self.tqm = tqm

    class test_tqm(object):
        def __init__(self, tqm):
            self.tqm = tqm
        pass

    print("test")
    tmq = test_tmq(test_tqm)
    StrategyModule(tmq)



# Generated at 2022-06-21 07:25:07.199805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert isinstance(test, LinearStrategyModule)
    assert test.debugger_active


# Generated at 2022-06-21 07:25:15.752089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.constants import C
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import strategy_loader

    inventory = [
        ["localhost","127.0.0.1","22","root","passwd","",True,"",{},[],[]],
        ["::1","::1","22","root","passwd","",True,"",{},[],[]],
        ["remote","192.168.1.1","22","root","passwd","",True,"",{},[],[]],
    ]
    test_inventory = StrategyModule.__name__+"_inventory"
    setattr(C, test_inventory, inventory)

    class DummyOptions:
        pass
    options = DummyOptions()
    options.inventory = test_

# Generated at 2022-06-21 07:25:17.423084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:25:28.242123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a temporary file and write data to it
    file = tempfile.NamedTemporaryFile(mode='w')
    file.write('This is the temporary file data')
    file.flush()

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()

# These commands will be executed once before any tasks are tripped
# by the master shell
pre_cmds = [
    'set +o history', # no command history
    'set +o histexpand', # no history expansion
    'bind "set completion-ignore-case on"', # completion ignores case
    'set completion-query-items 100', # 100 items to be displayed for completion
    'set print elements 200', # print no more than 200 items in an array

    'set prompt="ansible (? for help)> "' # prompt
]
cmd_table

# Generated at 2022-06-21 07:25:29.635871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-21 07:25:34.260264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor for class StrategyModule')
    result = StrategyModule()
    assert result == None, 'Constructor for class StrategyModule should not return anything.'


# Generated at 2022-06-21 07:25:39.440932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Initialize task queue manager
  tqm = TaskQueueManager(
    inventory=inventory,
    variable_manager=variable_manager,
    loader=loader,
    options=options,
    passwords=passwords,
    stdout_callback=results_callback,  # Use our custom callback instead of the ``default`` callback plugin
  )

  # Instantiate class StrategyModule
  strategy_module = StrategyModule(tqm)
  print(strategy_module.debugger_active)



# Generated at 2022-06-21 07:25:43.144625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:27:09.391885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = MockTaskQueueManager()
    strategy = StrategyModule(task_queue_manager)
    assert strategy.debugger_active == True


# Mock of class TaskQueueManager

# Generated at 2022-06-21 07:27:11.411542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active == True


# Generated at 2022-06-21 07:27:14.258969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule(None)
    assert test_strategy.debugger_active



# Generated at 2022-06-21 07:27:19.021001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for StrategyModule")
    tqm = ""
    strategy = StrategyModule(tqm)
    assert(strategy.debugger_active==True)
    print("Success")

# Runner for unit test

# Generated at 2022-06-21 07:27:21.857796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule
    #strategy_module = StrategyModule
    # TODO: Not implemented yet
    pass


# Generated at 2022-06-21 07:27:24.394605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-21 07:27:31.342678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy import debug
        reload(debug)
    except:
        assert False, "Failed to load StrategyModule"


if __name__ == '__main__':
    import __main__
    if hasattr(__main__, '__file__'):
        # Can only import this module from the CLI
        import unittest
        unittest.main(module='strategy.debug', failfast=True)

# Generated at 2022-06-21 07:27:34.607691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:27:42.611084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # For constructor of class StrategyModule
    # We will use a strategy module from linear.py
    # StrategyModule() inherits from LinearStrategyModule()
    # We will pass a fixture named "tqm" from tests/unit/plugins/strategy/fixtures/test_strategy.py
    debugger = StrategyModule(tqm)
    assert debugger.debugger_active == True


# Generated at 2022-06-21 07:27:43.986103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

