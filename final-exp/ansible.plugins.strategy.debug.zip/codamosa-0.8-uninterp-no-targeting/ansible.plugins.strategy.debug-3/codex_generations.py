

# Generated at 2022-06-21 07:19:13.654369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:19:14.785049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-21 07:19:22.274841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    StrategyModule = ansible.plugins.strategy.debug.StrategyModule
    tqm = object()
    test_strategy = StrategyModule(tqm)
    assert test_strategy.tqm is tqm
    assert test_strategy.debugger_active == True
    assert issubclass(StrategyModule, ansible.plugins.strategy.linear.StrategyModule) == True

# Generated at 2022-06-21 07:19:30.664280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_tqm = object()
    ansible_module_instance = StrategyModule(new_tqm)
    assert ansible_module_instance.playbook == None
    assert ansible_module_instance.inventory == None
    assert ansible_module_instance.variable_manager == None
    assert ansible_module_instance.loader == None
    assert ansible_module_instance.options == None
    assert ansible_module_instance.passwords == None
    assert ansible_module_instance.tqm == new_tqm
    assert ansible_module_instance.debugger_active == True


# Generated at 2022-06-21 07:19:33.659867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

    # should not get here.
    assert False, 'StrategyModule failed to raise expected exception'


# Generated at 2022-06-21 07:19:41.859463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None                 #TODO: set this to a testable value
    strategy_instance = StrategyModule(tqm)
    if strategy_instance.debugger_active  != True:
        raise Exception("Failed!")
    if strategy_instance.tqm != tqm:
        raise Exception("Failed!")

    print("Success!")



# Generated at 2022-06-21 07:19:45.473939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    tqm = Cmd()
    strategy = StrategyModule(tqm)
    pprint.pprint(strategy)


# Generated at 2022-06-21 07:19:50.173109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    sm = StrategyModule(task_queue_manager)
    assert sm.debugger_active


# Generated at 2022-06-21 07:19:51.668884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	StrategyModule(None) is StrategyModule

# Generated at 2022-06-21 07:19:54.387678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:19:58.166245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test
    pass


# Generated at 2022-06-21 07:20:00.503776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule
    assert module.__name__ == 'StrategyModule'
    assert module.__doc__ == 'Executes tasks in interactive debug session.'


# Generated at 2022-06-21 07:20:03.157747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tactic = StrategyModule('tqm')
    assert tactic.debugger_active == True


# Generated at 2022-06-21 07:20:05.744154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active

# Generated at 2022-06-21 07:20:06.939898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test')


# Generated at 2022-06-21 07:20:10.650810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create StrategyModule
    tqm = None
    sm = StrategyModule(tqm)
    # Assert that debugger_active must be True
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:20:14.649696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule('tqm')
    assert test_StrategyModule
    assert test_StrategyModule.debugger_active is True
    assert isinstance(test_StrategyModule, LinearStrategyModule) is True


# Generated at 2022-06-21 07:20:16.563696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) != None



# Generated at 2022-06-21 07:20:19.215388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__


# Generated at 2022-06-21 07:20:25.998262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        pass
    tqm = TestTqm()
    sm = StrategyModule(tqm)
    assert sm.debugger_active
    assert sm.tqm == tqm
    assert sm.host_name_to_host == {}
    assert sm.host_state == {}
    assert sm.host_count == 0
    assert sm.failed_hosts == {}
    assert sm.stats == {}


# Generated at 2022-06-21 07:20:30.472098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:20:37.588371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None # type: TaskQueueManager
    strategy_module = StrategyModule(task_queue_manager)

    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, LinearStrategyModule)
    assert isinstance(strategy_module, object)

    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:20:39.457297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug = StrategyModule
    assert isinstance(debug, object)



# Generated at 2022-06-21 07:20:48.265109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    import ansible.plugins.strategy

    assert len(strategy_loader._all) > 0
    for strategy in strategy_loader._all:
        assert strategy == strategy_loader.get(strategy)

    assert strategy_loader.get_strategy_class('linear') == ansible.plugins.strategy.LinearStrategyModule
    assert strategy_loader.get_strategy_class('free') == ansible.plugins.strategy.FreeStrategyModule

    strategy_loader.get('unknown')



# Generated at 2022-06-21 07:20:50.878669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-21 07:20:52.281317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)


# Generated at 2022-06-21 07:20:58.608432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == 'StrategyModule')
    assert(hasattr(StrategyModule, '__init__'))
    assert(hasattr(StrategyModule, 'run'))



# Generated at 2022-06-21 07:21:01.313499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule(None)
    assert test_instance.debugger_active == True



# Generated at 2022-06-21 07:21:06.687336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ The following is the test for dunder(__init__) method implemented above """
    StrategyModule(tqm=None)
    assert True

    class tqm():
        initialized = True
        class _terminated():
            terminated = False

        class _failed_hosts():
            exception = False

        def _final_q():
            def qsize():
                return None
            return qsize

        def _rsync():
            return None

        def cleanup():
            return None

    StrategyModule(tqm=tqm())
    assert True



# Generated at 2022-06-21 07:21:07.341784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement
    pass


# Generated at 2022-06-21 07:21:14.650948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(None)
    assert result.debugger_active == True

    print("The constructor of class StrategyModule Test Pass")


# Generated at 2022-06-21 07:21:16.830860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Interactive debugger Cmd sub-class

# Generated at 2022-06-21 07:21:19.983769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    if hasattr(tqm, 'debugger_active') and tqm.debugger_active:
        return True
    else:
        return False


# Generated at 2022-06-21 07:21:24.583677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active

# Test for class Debugger

# Generated at 2022-06-21 07:21:28.763819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_StrategyModule = StrategyModule('')
    assert obj_StrategyModule
    assert obj_StrategyModule.debugger_active == True


# Generated at 2022-06-21 07:21:32.874237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class AnsibleHost(object):
        def __init__(self, name, port):
            self.name = name
            self.port = port

# Main class of task debugger

# Generated at 2022-06-21 07:21:42.706496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    s = StrategyModule(test_tqm)
    assert test_tqm == s._tqm


FirstTask = '''
- hosts: all
  tasks:
    - debug:
        msg: "1st task"
'''

SecondTask = '''
- hosts: all
  tasks:
    - debug:
        msg: "2nd task"
'''

ThirdTask = '''
- hosts: all
  tasks:
    - debug:
        msg: "3rd task"
'''


# Generated at 2022-06-21 07:21:46.641337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy
    assert strategy.debugger_active
# --- End of Unit test for StrategyModule.__init__



# Generated at 2022-06-21 07:21:49.521012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(__import__('mocks.tqm')).debugger_active


# Generated at 2022-06-21 07:21:57.466905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        def __init__(self):
            self.name = "Dummy Task Queue Manager"
        def tasks(self):
            return {"Dummy Task 1", "Dummy Task 2"}
    dtm = DummyTaskQueueManager()
    sm = StrategyModule(dtm)
    if sm.tqm != dtm:
        raise AssertionError("StrategyModule.tqm should be set at __init__")
    if sm.debugger_active != True:
        raise AssertionError("StrategyModule.debugger_active should be set to True at __init__")
    assert 1 == 1

# Generated at 2022-06-21 07:22:11.015312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = 'test'
        StrategyModule(tqm)
    except:
        assert False, 'Failed to initialize StrategyModule class.'
    else:
        assert True, 'StrategyModule class initialized.'


# Generated at 2022-06-21 07:22:21.544184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible
    import ansible.modules

    class FakeTaskQueueManager:
        def __init__(self):
            self.stats = {}
        def __getattr__(self, name):
            return False

    class test_ansible_debug_module(unittest.TestCase):
        def test_contructor(self):
            self.tqm = FakeTaskQueueManager()
            obj = StrategyModule(self.tqm)
            self.assertEqual(obj.debugger_active, True)

    unittest.main(ansible.modules, verbosity=2, exit=False)



# Generated at 2022-06-21 07:22:24.935748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Test"
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
		

# Generated at 2022-06-21 07:22:35.006232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("#### debug: Run constructor test")

    # Run constructor with tqm object
    tqm = None
    try:
        StrategyModule(tqm)
        assert False
    except TypeError:
        pass

    # Run constructor with real tqm object
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars, load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-21 07:22:38.334029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'

    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-21 07:22:47.341758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy: pass
    Dummy.connection_plugins = {}
    Dummy.action_plugins = {}
    Dummy.cache = {}
    Dummy.callbacks = {}
    Dummy.inventory = {}
    Dummy.stats = {}

    tqm = Dummy()
    sm = StrategyModule(tqm)

    # Check that _tqm attribute has been assigned
    if sm._tqm is not tqm:
        raise AssertionError('Sm._tqm has not been assigned to tqm parameter')

    # Check that debugger_active has been assigned to true
    if sm.debugger_active != True:
        raise AssertionError('Debugger_active has not been assigned to true')


# Generated at 2022-06-21 07:22:48.411333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(object())


# Generated at 2022-06-21 07:22:49.081731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:22:55.926251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

    play = Play()
    play.name = "Unit test play"
    task = Task()
    task.name = "Unit test task"
    handler = Handler()
    handler.name = "Unit test handler"
    role = Role()
    role.name = "Unit test role"

    play.handlers = [handler]
    play.tasks = [task]
    play.roles = [role]


# Generated at 2022-06-21 07:23:00.730347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None
    assert strategy.debugger_active is True
# end of test_StrategyModule



# Generated at 2022-06-21 07:23:16.953398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:23:25.313367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True, 'Error: strategy.debugger_active should be True.'
    #assert strategy.stopping == False, 'Error: strategy.stopping should be False.'
    #assert strategy.host_states == {}, 'Error: strategy.host_states is not empty'
    #assert strategy.task_states == {}, 'Error: strategy.task_states is not empty'
    #assert strategy.name == 'linewrap', 'Error: strategy.name is not linewrap'
    #assert strategy.tqm == tqm, 'Error: strategy.tqm is not tqm.'
    #assert strategy.cleanup_jobs == {}, 'Error: strategy.cleanup_jobs is not empty'
    #assert strategy.running_

# Generated at 2022-06-21 07:23:33.804937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("----Test start for constructor of class StrategyModule----")
    tqm = StrategyModule(["test_task"], "/home/ansible/projects/contrib")
    tqm.test_switch = True
    tqm.send_callback = "testcallback"
    tqm.send_task_event = "test_task_event"
    tqm.stdout_callback = "test_stdout_callback"
    tqm.display = "test_display"
    tqm.run()
    print("----Test over----")

###


# Generated at 2022-06-21 07:23:37.087251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)



# Generated at 2022-06-21 07:23:39.022506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(None)
    assert t.debugger_active is True


# Generated at 2022-06-21 07:23:42.900600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor')
    module = StrategyModule(None)
    print('Constructor ran without problem.')
    print('Testing all methods')
    print('is_debugger_active:', module.debugger_active)


# Generated at 2022-06-21 07:23:47.945569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    run = StrategyModule(tqm)
    assert run.debugger_active == True

# unit test for execute_tasks

# Generated at 2022-06-21 07:23:57.843476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# End of code for unit test for constructor of class StrategyModule

    def run(self, iterator, play_context):
        self.iterator = iterator
        self.play_context = play_context

        self.hosts = []
        self.callbacks = []
        self.results_callback = None
        self.setup_results_callback()

        failed_hosts = {}
        unreachable_hosts = {}

        all_vars = self.tqm.set_host_variables(loader=self.tqm._loader, variables=self.tqm.extra_vars)

        host_results = {}
        while True:

            self.queue_task(iterator, play_context, all_vars)

            while self.debugger_active:
                time.sleep(1)

            self.queue_

# Generated at 2022-06-21 07:24:01.616145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0] == LinearStrategyModule
    assert StrategyModule.__init__.__code__.co_argcount == 2



# Generated at 2022-06-21 07:24:05.460792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None



# Generated at 2022-06-21 07:25:01.020022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active == True
   
    # Calling superclass __init__ constructor
    super(StrategyModule, strategy_module).__init__('tqm')

    


# Generated at 2022-06-21 07:25:04.969102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:25:09.638084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.debug as debug_module
        s = debug_module.StrategyModule(None)
    except Exception as err:
        assert False, "unexpected error: {}".format(err)
    else:
        assert type(s) == debug_module.StrategyModule



# Generated at 2022-06-21 07:25:12.868374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create TQM object
    tqm_obj = TQM()
    # Create StrategyModule object
    strategy_module_obj = StrategyModule(tqm_obj)
    # Unit test execution
    assert strategy_module_obj.debugger_active == True



# Generated at 2022-06-21 07:25:14.558653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert(s.debugger_active == True)


# Generated at 2022-06-21 07:25:19.686686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        obj = StrategyModule(None)
    except:
        raise AssertionError(
            "Constructor of Class StrategyModule returned unexpected result"
        )


# Generated at 2022-06-21 07:25:25.380186
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    sm = StrategyModule(tqm)
    assert sm.debugger_active
    assert sm.tqm == ''
    assert sm.display.verbosity >= 2
    assert sm.display.color == 'YELLOW'


# Generated at 2022-06-21 07:25:38.128634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor import task_queue_manager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # Generate a StrategyModule instance with parameters
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, [])

# Generated at 2022-06-21 07:25:39.450140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:25:49.650868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 07:28:48.586257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    object = StrategyModule(tqm)


# Generated at 2022-06-21 07:28:49.272424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-21 07:28:54.076907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)

# Requires a host name and a task to be passed
# For example, 'host' and 'debug_one' if only one host is defined in ansible.cfg
    #add_host(host=host_name, groups=dict(group_name=dict(hosts=[host_name])))
    #add_task(dict(action=dict(module_name='debug', args=dict(msg='<some_action_key>'))))
    #play()
    #d = Debugger(play, inventory)
    #d.cmdloop()
    #sys.exit(d.get_result())

# Generated at 2022-06-21 07:29:00.760821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # set up argument parser
    import argparse
    parser = argparse.ArgumentParser(description='Ansible debug strategy plugin')
    #parser.add_argument('-i', '--inventory', required=True, help='Inventory file name')
    parser.add_argument('-e', '--extra-vars', dest='extra_vars', action='append', default=[],
            help='Set additional variables as key=value or YAML/JSON')
    parser.add_argument('--list-hosts', action='store_true', default=False,
            help='Outputs a list of matching hosts; does not execute anything else')
    parser.add_argument('--list-tags', action='store_true', default=False,
            help='Outputs a list of all available tags')

# Generated at 2022-06-21 07:29:01.702424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-21 07:29:02.302400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass




# Generated at 2022-06-21 07:29:03.344246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = SomeClass()
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-21 07:29:05.092829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy_module = StrategyModule(tqm=None)
    assert my_strategy_module.debugger_active == True


# Generated at 2022-06-21 07:29:06.685127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    assert(StrategyModule(tqm))




# Generated at 2022-06-21 07:29:07.998858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()
