

# Generated at 2022-06-21 07:19:14.961251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(tqm=None)
    assert strategymodule != None
    assert strategymodule.debugger_active == True
    

# Generated at 2022-06-21 07:19:19.558871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            self.stats = {}
    tqm = TQM()
    s = StrategyModule(tqm)
    print('%s' % s.stats)
# test_StrategyModule()



# Generated at 2022-06-21 07:19:22.241147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM(None)
    sf = StrategyModule(tqm)
    assert sf.debugger_active


# Generated at 2022-06-21 07:19:25.431291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-21 07:19:28.611474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(None)
  assert(strategy_module.debugger_active == True)



# Generated at 2022-06-21 07:19:30.515575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)



# Generated at 2022-06-21 07:19:35.844689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.stdout.write("test_StrategyModule...")
    sys.stdout.flush()
    try:
        StrategyModule(1)
        sys.stdout.write("OK\n")
    except:
        sys.stdout.write("NG (StrategyModule)\n")
        raise
    sys.stdout.flush()


# Generated at 2022-06-21 07:19:40.829279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True, "test_StrategyModule: debugger_active should be True"


# Generated at 2022-06-21 07:19:45.194353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Since StrategyModule is just a wrapper of class LinearStrategyModule,
    # This case just checks if the constructor works fine.
    test_tqm = type('', (), {})()
    StrategyModule(test_tqm)


# Generated at 2022-06-21 07:19:50.161253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategyModule = StrategyModule(tqm)
    assert strategyModule.tqm == tqm, "tqm is not " + tqm
    assert strategyModule.debugger_active, "debugger_active is not True"

#--------------------------------------------------------------------------------------------
# Below methods are copied from original ansible code
#--------------------------------------------------------------------------------------------
    def add_tasks(self):
        # host_to_visit is a list of dicts containing the hostname and the task to run on it
        host_to_visit = []

        self._default_host_loop_ref = None

        task_vars = self._get_global_vars()
        play_context = self._play_context
        default_vars = dict()

# Generated at 2022-06-21 07:19:53.237039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule, object))


# Generated at 2022-06-21 07:19:56.020942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test environment
    # and start testing StrategyModule.
    p = StrategyModule()
    assert p.debugger_active == True

# Generated at 2022-06-21 07:20:07.183225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule('TEST')
    assert tm.debugger_active is True

# class Debugger(cmd.Cmd):
#     def __init__(self, tqm):
#         super(Debugger, self).__init__()
#         self.prompt = 'dbg> '
#         self.tqm = tqm

#     def do_next(self, args):
#         """
#         Execute next task.
#         usage: next
#         """
#         self.tqm.next_task()

#     def do_quit(self, args):
#         """
#         Quit debugger.
#         usage: quit
#         """
#         sys.exit(0)

#     def do_skip(self, args):
#         """
#         Skip executing task

# Generated at 2022-06-21 07:20:09.045453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Executes one task and return whether more tasks are available.
# If more tasks are available, it will be in "self.current_task".

# Generated at 2022-06-21 07:20:09.811737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-21 07:20:12.312928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    original_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    tqm_instance = None
    StrategyModule(tqm_instance)
    sys.stdout = original_stdout


# Generated at 2022-06-21 07:20:13.665701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:20:15.021486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active


# Generated at 2022-06-21 07:20:15.899443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:20:19.835534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:20:25.206699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule(None)
    assert isinstance(S, StrategyModule)
    assert S.debugger_active == True


# Generated at 2022-06-21 07:20:28.253588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert isinstance(StrategyModule(tqm), StrategyModule)


# Generated at 2022-06-21 07:20:29.069041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:20:33.653744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = {'name': None, 'debugger_active': True}
    sm = StrategyModule(TASK_QUEUE_MANAGER)
    assert sm.tqm == TASK_QUEUE_MANAGER


# Generated at 2022-06-21 07:20:36.821246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # If there is no module name, then this function return False.
    if not StrategyModule.__module__:
        return False


# Generated at 2022-06-21 07:20:38.101761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Do nothing
    pass


# Generated at 2022-06-21 07:20:46.681046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'fake_task_queue'
    strategy = StrategyModule(tqm)
    assert strategy.min_worker_threads == 1
    assert strategy.def_max_worker_threads == 1
    assert strategy.max_worker_threads == 1
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True
    assert isinstance(strategy.queue, cmd.Cmd)


# Generated at 2022-06-21 07:20:54.533540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {
        "runners": {
            "default": {
                "_start_at_task": None,
                "_task_cache": {},
            },
        },
    }
    try:
        z = StrategyModule(tqm)
        assert z.debugger_active == True
    except Exception as e:
        raise e


# Generated at 2022-06-21 07:21:02.614173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def get_host_list(self):
            pass

        def get_host_vars(self, host):
            pass

    try:
        sm = StrategyModule(FakeTQM())
    except:
        e = sys.exc_info()[1]
        raise AssertionError("Failed to create instance of class StrategyModule: %s" % e)



# Generated at 2022-06-21 07:21:06.030814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    object = StrategyModule("tqm")
    print(object)


# Generated at 2022-06-21 07:21:13.707513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:21:19.706205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy():
        class Dummy_tqm():
            def __init__(self):
                self.stats = {}
        tqm = Dummy_tqm()

    obj = StrategyModule(Dummy.tqm)

    # Assertion
    assert obj.debugger_active == True
# End of unit test



# Generated at 2022-06-21 07:21:22.455742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test for creation of an object of class StrategyModule
    tqm = StrategyModule()



# Generated at 2022-06-21 07:21:23.240156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:21:25.121518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:21:28.180481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except NameError as e:
        return True
    return False


# Generated at 2022-06-21 07:21:31.744140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-21 07:21:43.318190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy import debug
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    class Tqm():
        def __init__(self):
            self.shared_loader_obj = 'not null'
            self.display = Display()
            self._final_q = 'not null'
            self.inventory = 'not null'
            self.stats = 'not null'
            self._notified_handlers = dict()

    tqm = Tqm()
    try:
        strategy = debug.StrategyModule(tqm)
    except:
        assert False
    assert strategy.debugger_active is True


# Generated at 2022-06-21 07:21:47.945871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        s = StrategyModule(None)
        assert s.debugger_active
    except AssertionError:
        print("Assertion error in test_StrategyModule")
        assert 0


# Generated at 2022-06-21 07:21:54.518771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    # tqm is an object of class TaskQueueManager
    sm = StrategyModule(tqm)
    # sm is an object of class StrategyModule.
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-21 07:22:07.768071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        def __init__(self):
            self.stats = True
    strategy = StrategyModule(Tqm())
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:22:10.977601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        s = StrategyModule()
    except:
        assert True, "throw exception"
    else:
        assert False, "should throw exception"


# Generated at 2022-06-21 07:22:20.745055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
        mixing=None,
        module_path=None
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Execute tasks in interactive debug session

# Generated at 2022-06-21 07:22:21.609092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return


# Generated at 2022-06-21 07:22:31.218374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _s = StrategyModule(tqm=None)
    assert _s.tqm is None
    assert _s.host_list is None
    assert _s.failed_hosts == dict()

#    print "tqm -> %s" % _s.tqm
#    print "host_list -> %s" % _s.host_list
#    print "failed_hosts -> %s" % _s.failed_hosts
    assert _s.debugger_active is True


# Generated at 2022-06-21 07:22:34.916854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule.__init__("tqm")
    assert sm.debugger_active

# vim: set expandtab ft=python ts=4 sw=4 :

# Generated at 2022-06-21 07:22:35.740374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:22:38.419514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:22:47.846353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play as playbook_play

    plugin_loader.add_directory('./test')
    test_playbook = playbook_play.Playbook.load('test/test_playbook.yml', loader=plugin_loader)
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=ansible.inventory.Inventory(host_list='./test/hosts'),
        variable_manager=ansible.vars.VariableManager(),
        loader=plugin_loader,
        options=ansible.utils.options.Options(verbosity=1),
        passwords=None,
        stdout_callback='test',
        run_additional_callbacks=False,
        run_tree=False,
    )

    strategy

# Generated at 2022-06-21 07:22:49.125962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:23:09.970435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(LinearStrategyModule)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:23:16.255878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #tqm = ansible.plugins.callback.default.CallbackModule()
    tqm = _ansible.plugins.callback.default.CallbackModule()
    s = StrategyModule(tqm)
    # Test Variables
    assert type(s) is StrategyModule
    assert type(s.debugger_active) is bool

# debug command class

# Generated at 2022-06-21 07:23:17.755177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)



# Generated at 2022-06-21 07:23:23.505669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test task queue manager.
    from ansible.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        # Use a simple inventory for the test.
        inventory=dict(hosts=dict(dummy=dict())),
        stdout_callback='yaml',
    )
    # Create a Strategy Module. It will be tested.
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:23:24.420684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:23:27.132765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-21 07:23:36.052005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test for constructor of class StrategyModule
    # Create
    test_tqm = None
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.host_name == None
    assert strategy_module.host_vars == None
    assert strategy_module.host_patterns == None
    assert strategy_module.inventory == None
    assert strategy_module.loop_control == None
    assert strategy_module.new_group_name == None
    assert strategy_module.new_groups == None
    assert strategy_module.new_var_name == None
    assert strategy_module.new_vars == None
    assert strategy_module.noop_task_attrs == None
    assert strategy_module.play_context == None
    assert strategy_module

# Generated at 2022-06-21 07:23:39.842342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule.debugger_active == True


# Generated at 2022-06-21 07:23:42.674941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_name = 'debug'
  tqm = None
  sm = StrategyModule(tqm)
  assert sm.debugger_active


# Generated at 2022-06-21 07:23:46.627361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:24:36.748207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create StrategyModule class object
    strategy_module_obj = StrategyModule(tqm = 'tqm')
    assert(strategy_module_obj)
    assert(strategy_module_obj.debugger_active == True)


# Generated at 2022-06-21 07:24:41.143546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.name == 'debug', 'StrategyModule must have "debug" as name attribute'
    assert strategy_module.debugger_active == True, 'debugger_active must be True'



# Generated at 2022-06-21 07:24:44.883221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    global s

    s = StrategyModule(None)
    s.debugger_active = True
    assert s.debugger_active == True


# Generated at 2022-06-21 07:24:49.630587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm:
        def __init__(self):
            self.delegate = "N/A"
            self.cur_task = "N/A"
    obj = StrategyModule(MockTqm())

# Using __main__ is an intentional hack.
# This is required to allow unittest to test protected and private methods. 
#
# This class is used to test protected and private methods of class StrategyModule, 
# by inheriting class StrategyModule. 

# Generated at 2022-06-21 07:24:58.221582
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:25:00.239606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:25:00.784919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-21 07:25:06.145055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.inventory == None
    assert strategy_module.loader == None
    assert strategy_module.variable_manager == None
    assert strategy_module.display == None
    assert strategy_module.options == None


# Generated at 2022-06-21 07:25:07.809566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-21 07:25:09.537761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-21 07:26:37.878285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule(None)
    assert isinstance(test_strategy_module, StrategyModule)
    assert test_strategy_module.debugger_active is True



# Generated at 2022-06-21 07:26:39.918442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:26:49.214682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # In order to unit test correctly, I need to mock the below import.
    import __builtin__
    class MockAnsibleModule:
        def __init__(self,):
            pass
        def fail_json(self, **kwargs):
            pass
    sys.modules['ansible.plugins.action.__init__'] = type('', (), {})
    sys.modules['ansible.plugins.action.__init__'].ActionBase = MockAnsibleModule
    assert StrategyModule


# Generated at 2022-06-21 07:27:00.210939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.num_tasks_run = 0
            self.num_tasks_failed = 0
            self.num_tasks_skipped = 0
            self.tqm_variables = dict()
            self.hostvars = dict()
            self.stats = dict()

        def _process_pending_results(self, iterator, one_pass=False):
            return list()

        def _tqm_make_control_path(self, host):
            return "/nonexistent"

        def _final_q_cleanup(self):
            return None

    tqm = TestTQM()
    s = StrategyModule(tqm)

    assert isinstance(s, StrategyModule)



# Generated at 2022-06-21 07:27:03.380110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    with StrategyModule(tqm=None) as test_instance:
        test_instance.debugger_active = True
        assert test_instance.debugger_active == True
    print("Constructor of class StrategyModule is working")


# Generated at 2022-06-21 07:27:09.453831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.module_utils.debug.get_tqm()
    strategyModule = StrategyModule(tqm)
    assert strategyModule.tqm == tqm
    assert strategyModule.strategy == 'debug'
    assert strategyModule.debugger_active is True
    


# Generated at 2022-06-21 07:27:10.860364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(g)


# Generated at 2022-06-21 07:27:15.521658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['__main__'].__file__ = 'foo'
    tqm = cmd.Cmd()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:27:19.669508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = pprint.pformat('test')
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm is tqm
    assert strategy_module.debugger_active is True


# Generated at 2022-06-21 07:27:22.960382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
