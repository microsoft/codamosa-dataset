

# Generated at 2022-06-21 07:19:15.939806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible'] = __import__('ansible')
    obj = StrategyModule(tqm=None)
    assert isinstance(obj, StrategyModule)
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:19:18.291436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm)
    assert tqm.debugger_active == True


# Generated at 2022-06-21 07:19:20.710187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:19:25.206531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = StrategyModule('tqm')
    assert task.debugger_active


# Generated at 2022-06-21 07:19:33.355002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Testtqm(object):
        def __init__(self):
            self.hostvars = {
                'host1': {
                    'ansible_host': 'host1',
                    'ansible_port': 22,
                }
            }

    tqm = Testtqm()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:19:38.243066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        verbosity = 0

    test_StrategyModule = StrategyModule(TestTQM())
    assert test_StrategyModule.tqm.verbosity == 0


# Generated at 2022-06-21 07:19:40.518553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:19:46.066670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm is tqm
    assert strategy.inventory == {}
    assert strategy.variable_manager == {}
    assert strategy.loader == {}
    assert strategy.all_hosts == []
    assert strategy.tasks == []



# Generated at 2022-06-21 07:19:50.955589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule.debugger_active is True
    assert strategyModule.failed_hosts == {}
    assert strategyModule.done_hosts == {}

# Generated at 2022-06-21 07:19:57.900702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None

    obj = StrategyModule(tqm)
    assert obj != None

#    def run(self, iterator, play_context):
#        try:
#            super(StrategyModule, self).run(iterator, play_context)
#        except Exception:
#            if self.debugger_active:
#                debugger = Debugger(self.tqm, self._host_state_results)
#                debugger.cmdloop()
#            raise


# Generated at 2022-06-21 07:20:01.809470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert StrategyModule(tqm="test")



# Generated at 2022-06-21 07:20:04.410204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm.__dict__['debugger_active']


# Generated at 2022-06-21 07:20:06.980650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__module__ == 'ansible.plugins.strategy.debug' and
        StrategyModule.__name__ == 'StrategyModule')



# Generated at 2022-06-21 07:20:07.853221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # ToDo
    assert True


# Generated at 2022-06-21 07:20:08.363015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:20:11.394254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTqm:
        def __init__(self):
            self.hosts = ['localhost']

    fake_tqm = FakeTqm()
    sm = StrategyModule(fake_tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:20:14.793092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module is not None
    assert module.tqm is None
    assert module.debugger_active == True


# Generated at 2022-06-21 07:20:26.965932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.six import StringIO

    class FakeTaskQueueManager(object):
        def __init__(self):
            self.hosts_left = []

    def FakePlayContext():
        return {'forks': 1,
                'name': 'test',
                'privilege_escalation': False,
                'remote_addr': '127.0.0.1',
                'remote_user': 'remote_user',
                'local_tmp': '/tmp/ansible/tmp',
                'become': False,
                'become_user': 'become_user',
                'become_method': 'become_method',
                'become_exe': 'become_exe'}

    class FakeTask(object):
        def __init__(self):
            self.action = 'setup'


# Generated at 2022-06-21 07:20:28.618082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:20:31.316626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:20:39.927854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        play = dict(
                name = "play",
                hosts = 'all',
                gather_facts = 'no',
                tasks = [
                        dict(action=dict(module='shell', args='echo hello')),
                        dict(action=dict(module='shell', args='echo world')),
                        ]
                )
        loader = None
        variable_manager = None
        host_list = 'hosts'
        tqm = None
        sm = StrategyModule(tqm)

# Main method for unit test

# Generated at 2022-06-21 07:20:40.859628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:20:43.011128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:20:47.942110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#     print('Test: test_StrategyModule')
    TaskQueueManager = TaskQueueManager_Class()
    TaskQueueManager.debugger_active = True

    StrategyModule_Object = StrategyModule(TaskQueueManager)

    assert StrategyModule_Object.tqm == TaskQueueManager
    assert StrategyModule_Object.debugger_active == True


# Generated at 2022-06-21 07:20:49.926191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)


# Generated at 2022-06-21 07:21:00.076533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import imp
    import os
    from ansible.utils.module_docs import get_docstring
    from ansible.parsing import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-21 07:21:03.015502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a TaskQueueManager instance.
    mock_tqm = MagicMock()

    # Create a StrategyModule object
    strategy_module_obj = StrategyModule(mock_tqm)

    assert strategy_module_obj.debugger_active == True

# Generated at 2022-06-21 07:21:04.594612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:21:09.762862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test whether the constructor of base class is called by StrategyModule(tqm)
    # When tqm is not a variable.
    try:
        StrategyModule()
    except Exception as e:
        assert e == TypeError("__init__() missing 1 required positional argument: 'tqm'")
    # Test whether the constructor of base class is called by StrategyModule(tqm)
    # When tqm is an empty variable.
    try:
        StrategyModule({})
    except Exception as e:
        assert e == TypeError("__init__() missing 1 required positional argument: 'tqm'")

TEST_STRATEGY_MODULE = StrategyModule(tqm=None)


# Generated at 2022-06-21 07:21:12.145322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule()
    assert res is not None


# Generated at 2022-06-21 07:21:18.483210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    test_sm = StrategyModule(test_tqm)


# Generated at 2022-06-21 07:21:21.267188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Unit Test of the class Debugger

# Generated at 2022-06-21 07:21:25.121889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    tqm = mock.MagicMock()
    global strategy_module
    strategy_module = StrategyModule(tqm)



# Generated at 2022-06-21 07:21:26.231679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:21:29.529123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test that constructor works correctly

    For example, test that member variables are initialized correctly, etc.

    """
    StrategyModule(tqm=None)


# Generated at 2022-06-21 07:21:33.255869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-21 07:21:39.287414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test linear
    stragegy_linear = LinearStrategyModule({})
    # Test debug
    stragegy_debug = StrategyModule({})
    assert stragegy_debug.debugger_active == True

# -----------------------------------------------------------------
# Declare class Debugger
# -----------------------------------------------------------------

# Generated at 2022-06-21 07:21:40.823438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="some_tqm")


# Generated at 2022-06-21 07:21:45.083701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-21 07:21:48.153473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule(None)
        assert strategy.tqm is None
    except Exception as e:
        raise e


# Generated at 2022-06-21 07:22:00.976265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'Stub'
    obj = StrategyModule(tqm)

    assert obj.debugger_active == True


# Generated at 2022-06-21 07:22:02.966824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule.__test__ = False
    assert (StrategyModule and True)



# Generated at 2022-06-21 07:22:05.516395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    assert len(StrategyModule(tqm)) > 0


# Generated at 2022-06-21 07:22:11.504423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  obj = StrategyModule(tqm = None)
  assert isinstance(obj, StrategyModule)
  assert obj.tqm is None
  assert obj.host_states is None
  assert isinstance(obj.host_states, dict)
  assert isinstance(obj.host_state_map, dict)
  assert obj.debugger_active is True



# Generated at 2022-06-21 07:22:17.192848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for constructor of class StrategyModule
    # Create an instance of a class StrategyModule
    # Compare self.debugger_active with expected value(True)
    expected_value = StrategyModule(cmd.Cmd()).debugger_active
    assert (expected_value == True)


# Generated at 2022-06-21 07:22:20.565079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # creates a instance of StrategyModule and returns
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:22:25.081855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj.debugger_active == True
    assert strategy_obj.tqm == None




# Generated at 2022-06-21 07:22:26.010808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule()
    assert isinstance(test, LinearStrategyModule)
    assert test.debugger_active == True


# Generated at 2022-06-21 07:22:27.503854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # assert ()
    return



# Generated at 2022-06-21 07:22:30.983605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = type('FakeTQM', (object, ), {'stats': {}})
    StrategyModule(fake_tqm)


# Generated at 2022-06-21 07:23:22.033913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Test()
    debugger = StrategyModule(tqm)
    assert debugger.debugger_active == True


# Generated at 2022-06-21 07:23:27.621151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.tqm == test_tqm


# Generated at 2022-06-21 07:23:31.137942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:23:33.807503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('>>>test_StrategyModule:')
    my_tqm = 'Hello'
    print('task_queue_manager={}'.format(my_tqm))
    StrategyModule(my_tqm)



# Generated at 2022-06-21 07:23:37.861193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__doc__ == StrategyModule.__init__.__doc__)



# Generated at 2022-06-21 07:23:40.081869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:23:42.567387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active

# Custom debugger class    

# Generated at 2022-06-21 07:23:46.382753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None


# Generated at 2022-06-21 07:23:54.836844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['__main__'].SUPPORTED_FILTER_PLUGINS = []
    sys.modules['__main__'].SUPPORTED_CACHE_PLUGINS = {}
    sys.modules['__main__'].SUPPORTED_LOOKUP_PLUGINS = []
    sys.modules['__main__'].ACTION_PLUGINS = dict()
    sys.modules['__main__'].CALLBACK_PLUGINS = dict()
    sys.modules['__main__'].STRATEGY_PLUGINS = dict()
    sys.modules['__main__'].CLICONF_PLUGINS = dict()
    sys.modules['__main__'].TERMINAL_PLUGINS = dict()
    sys.modules['__main__'].CACHE_PLUGINS = dict()

# Generated at 2022-06-21 07:23:59.387548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  my_tqm = None
  res = StrategyModule(my_tqm)
  assert res.debugger_active == True


# Generated at 2022-06-21 07:26:46.831079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test invalid type of tqm argument
    try:
        StrategyModule(None)
    except TypeError:
        print('Invalid type of tqm argument')

# Create a subclass of Cmd from the Python module cmd

# Generated at 2022-06-21 07:26:48.652701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = LinearStrategyModule(tqm)
    assert strategy is not None
    assert strategy.debugger_active


# Generated at 2022-06-21 07:26:55.223291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = __import__('ansible.executor.task_queue_manager').executor.task_queue_manager
        sm = StrategyModule(tqm)
    except ImportError:
        # This means we are being called as part of unit tests. Ignore and pass.
        pass


# Generated at 2022-06-21 07:26:57.675389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True
#end test_StrategModule



# Generated at 2022-06-21 07:27:08.092365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nTesting StrategyModule")

    class MyTest(cmd.Cmd):
        # Initialize testing object with object 'tpj'
        def __init__(self, tpj):
            self.tpj = tpj
            cmd.Cmd.__init__(self)
            self.prompt = 'ansible>'
            self.intro = 'Welcome to ansible run debugger!'
            self.use_rawinput = False

        def default(self, line):
            try:
                return cmd.Cmd.default(self, line)
            except (AttributeError, NameError):
                pass

        def do_continue(self, line):
            '''
            continue execution until next breakpoint
            '''
            # Remove the breakpoint
            for bp in self.tpj:
                self.tpj.remove_breakpoint

# Generated at 2022-06-21 07:27:10.032122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testModule = StrategyModule()
    assert testModule.debugger_active == True


# Generated at 2022-06-21 07:27:14.122677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {"hostvars": "hostvars value"}
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:27:14.961748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:27:18.790798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    items = dict(tqm='tqm')
    obj = StrategyModule(**items)
    assert obj.tqm == items['tqm']



# Generated at 2022-06-21 07:27:22.463956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Init StrategyModule with TQM
    task_queue_manager = mock.Mock()
    sm = StrategyModule(task_queue_manager)
    assert sm.debugger_active == True