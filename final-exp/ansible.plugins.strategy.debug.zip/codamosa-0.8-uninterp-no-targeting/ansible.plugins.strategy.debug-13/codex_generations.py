

# Generated at 2022-06-21 07:19:13.508513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:19:19.308663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    if sm.debugger_active is True:
        print("StrategyModule initialized with debugger active")
    else:
        print("StrategyModule initialized with debugger NOT active")

# Unit tests for init_child method

# Generated at 2022-06-21 07:19:21.909203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm)
    assert tqm.debugger_active == True


# Generated at 2022-06-21 07:19:25.430970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-21 07:19:28.611548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'tqm'
  strategy = StrategyModule(tqm)
  assert strategy.debugger_active


# Generated at 2022-06-21 07:19:31.465962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['__main__'].__file__ = 'debug.py'
    print('In main: {}'.format(__name__))
    if __name__ == '__main__':
        exit('Error: You appear to be running the debugger from within the debugger. Please run this module standalone.')



# Generated at 2022-06-21 07:19:34.373568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True
    assert sm.tqm == None

############################################################################


# Generated at 2022-06-21 07:19:37.950381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check if class StrategyModule exist
    assert StrategyModule
    # Check if parent method __init__ exist
    assert StrategyModule.__init__



# Generated at 2022-06-21 07:19:43.715910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Make an instance for testing
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:19:49.763502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:19:51.748684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:19:55.896947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create new StrategyModule instance with dummy TaskQueueManager
    sm = StrategyModule(tqm=None)
    # check that debugger_active is set to True
    assert sm.debugger_active


# Generated at 2022-06-21 07:19:59.089531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Method to run tasks on target host, in a linear manner

# Generated at 2022-06-21 07:20:08.166994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self, host_list=None, module_vars=None):
            self.host_list = host_list
            self.module_vars = module_vars
    host_list = ['localhost', '127.0.0.1']
    module_vars = {'ansible_connection': 'local', 'ansible_user': 'root'}
    tqm = TQM(host_list, module_vars)
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-21 07:20:08.704624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:20:10.895145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Empty:
        pass
    obj = Empty()
    obj.tqm = None
    strategy_module = StrategyModule(obj.tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:20:14.932170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.tqm is None
    assert isinstance(sm, LinearStrategyModule)
    assert isinstance(sm, StrategyModule)


# Generated at 2022-06-21 07:20:15.831998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:20:18.524662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-21 07:20:20.043961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-21 07:20:25.956585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm(object):
        def __init__(self):
            self.hostvars = { 'a': 'b' }

    t = DummyTqm()
    s = StrategyModule(t)

    assert s.debugger_active
    assert t == s.tqm



# Generated at 2022-06-21 07:20:33.023863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print()
    print("--- Test start: test_StrategyModule ---")
    print()
    StrategyModule(tqm=None)
    print()
    print("--- Test passed: test_StrategyModule ---")
    print()


# Generated at 2022-06-21 07:20:35.057500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Debugger Executor

# Generated at 2022-06-21 07:20:37.914551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert 'debugger_active' in strategy.__dict__
    assert strategy.debugger_active is True


# Generated at 2022-06-21 07:20:39.845589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-21 07:20:42.530312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(10)
    assert strategy == 10


# Generated at 2022-06-21 07:20:44.104517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(LinearStrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
            self.debugger_active = True
    tqm = TestStrategyModule
    return tqm


# Generated at 2022-06-21 07:20:46.048058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm='tqm')


# Generated at 2022-06-21 07:20:58.796147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    #def enter_debug(self, host):
    #    self.debugger_active = True
    #    self.tqm._terminated = True
    #    self.tqm.send_callback('debugger_active', host.get_name())
    #    self.tqm.send_callback('v2_playbook_on_handler_task_start', None)

    #def exit_debug(self):
    #    self.debugger_active = False
    #    self.tqm.send_callback('debugger_active', None)

    #def run(self, iterator, play_context):
    #    super(StrategyModule, self).run(iterator, play_context)

    #    self.tqm.send_callback('v2_playbook_on_handler_task_start

# Generated at 2022-06-21 07:21:02.107632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule.debugger_active is True, "constructor of class StrategyModule failed"


# Generated at 2022-06-21 07:21:08.210798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-21 07:21:10.862967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-21 07:21:20.691395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.plugins.strategy.debug import StrategyModule
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
        run_additional_callbacks=False,
        run_tree=False
    )
    sm = StrategyModule(tqm)
    assert sm.debugger_active



# Generated at 2022-06-21 07:21:24.279207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        def __init__(self, *args, **kwargs):
            pass
    strategy = StrategyModule(tqm)


# Generated at 2022-06-21 07:21:27.956459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    _module = StrategyModule(tqm)
    assert _module.debugger_active == True


# Generated at 2022-06-21 07:21:29.957383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule(tqm=None)
    assert test_strategy.debugger_active == True


# Generated at 2022-06-21 07:21:33.902032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = None
    _strategy = StrategyModule(_tqm)
    assert _strategy.debugger_active == True


# Generated at 2022-06-21 07:21:38.152056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = None
    sm = StrategyModule(tqm)
    assert sm != None


# Generated at 2022-06-21 07:21:39.474118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

# This class is the debug session loop

# Generated at 2022-06-21 07:21:41.170347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create new instance of class StrategyModule
    sm = StrategyModule(None)

    # Test StrategyModule.debugger_active
    print(sm.debugger_active)


# Generated at 2022-06-21 07:21:53.650449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:22:02.927859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=['localhost']),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
        options=None,
        passwords=None,
        stdout_callback=Display(),
    )


# Generated at 2022-06-21 07:22:11.858286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule instance
    assert StrategyModule.__name__ == 'StrategyModule'

    assert hasattr(StrategyModule, '__init__') == True
    assert callable(getattr(StrategyModule, '__init__')) == True
    assert hasattr(StrategyModule, '__init__') == True
    assert callable(getattr(StrategyModule, '__init__')) == True
    assert hasattr(StrategyModule, 'run') == True
    assert callable(getattr(StrategyModule, 'run')) == True


# Generated at 2022-06-21 07:22:15.278157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.__class__.__name__ == "StrategyModule"



# Generated at 2022-06-21 07:22:16.643810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()



# Generated at 2022-06-21 07:22:19.127021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    sm = StrategyModule(tqm)
    assert sm


# Generated at 2022-06-21 07:22:25.318884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug

    strategy_module = ansible.plugins.strategy.debug.StrategyModule(None)

    assert strategy_module is not None
    assert strategy_module.debugger_active is True

#   This is useful for #import code; code.interact(local=vars())
#   to drop into a shell.
#
#   task_vars = dict(
#       ansible_connection='local',
#       ansible_inventory='inventory',
#       ansible_play_hosts='localhost',
#       play_hosts=dict(localhost=None),
#       hostvars=dict(localhost=dict())
#   )
#
#
#   ansible.plugins.strategy.debug.StrategyModule(task_vars,
#       host_list=['localhost'],

# Generated at 2022-06-21 07:22:35.114723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_inventory = {}
    ansible_playbook = {}
    ansible_callbacks = {}
    ansible_variables = {}
    ansible_verbosity = 0
    ansible_only_tags = {}
    ansible_skip_tags = {}
    ansible_check = False
    ansible_diff = False
    ansible_python_interpreter = ''
    ansible_timeout = 10
    ansible_forks = 5
    test_tqm = {}
    test_strategymodule = StrategyModule(test_tqm)
    assert test_strategymodule.tqm == test_tqm
    assert test_strategymodule.serial == 0
    assert test_strategymodule.worker_pids == {}
    assert test_strategymodule.worker_procs == {}
    assert test_

# Generated at 2022-06-21 07:22:35.960506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True==True

# Generated at 2022-06-21 07:22:39.253716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case
    s = StrategyModule("testqm")

    # Assertion
    assert s.debugger_active is True


# Generated at 2022-06-21 07:22:56.451152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:23:00.419632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    lsm = StrategyModule(tqm=None)
    assert lsm.debugger_active == True


# Generated at 2022-06-21 07:23:07.284946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy.tqm == tqm
    assert strategy.host_has_tasks.keys() == []
    assert strategy.current_task == None
    assert strategy.debugger_active == True



# Generated at 2022-06-21 07:23:16.275592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from mock import Mock

    tqm = Mock()
    variable_manager = Mock()
    variable_manager.__str__.return_value = "variable_manager"
    tqm.variable_manager = variable_manager
    loader = Mock()
    loader.__str__.return_value = "loader"
    tqm.loader = loader
    inventory = Mock()
    inventory.__str__.return_value = "inventory"
    tqm.inventory = inventory
    PlayContext = namedtuple('PlayContext', 'play play_basedirs remote_addr')
    play_context = PlayContext(play=None, play_basedirs=None, remote_addr=None)
    tqm.play_context = play_context

# Generated at 2022-06-21 07:23:17.219828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:23:25.403040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    import ansible.plugins.loader
    import ansible.playbook.task_include
    import ansible.playbook.handler
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.inventory.host
    import ansible.template
    import ansible.utils.ssh_functions
    import ansible._vendor.six

    tqm = ansible.plugins.loader.get_loader_from_class(ansible.plugins.strategy.debug.StrategyModule).load_common_utils(ansible.plugins.loader.get_all_plugin_loaders()[0])

# Generated at 2022-06-21 07:23:26.990086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return _test_StrategyModule()


# Generated at 2022-06-21 07:23:28.219484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-21 07:23:36.361729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new StrategyMudule
    strategy_module = StrategyModule(None)
    # Check that the debugger is active
    assert strategy_module.debugger_active == True

# TODO: Add unit tests for run and HandlePlaybookResult

# TODO: Add unit tests for Debugger

# TODO: Add unit test for  run_async_task_once

# TODO: Add unit test for cmdloop

# TODO: Add unit test for emptyline

# TODO: Add unit test for do_exit

# TODO: Add unit test for do_next

# TODO: Add unit test for do_continue

# TODO: Add unit test for do_run

# TODO: Add unit test for do_host

# TODO: Add unit test for do_var

# TODO: Add unit

# Generated at 2022-06-21 07:23:37.822402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


# Generated at 2022-06-21 07:24:26.060941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)




# Generated at 2022-06-21 07:24:26.808689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:24:38.847287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #
    # Set up.
    #
    class ObjectForTest(object):
        def __init__(self, name):
            self.name = name

    class TqmForTest():
        def __init__(self):
            self.inventory = ObjectForTest('inventory')
            self.variable_manager = ObjectForTest('variable_manager')
            self.loader = ObjectForTest('loader')
            self.options = ObjectForTest('options')
            self.stdout_callback = ObjectForTest('stdout_callback')

    tqm = TqmForTest()

    #
    # Test.
    #
    strategy = StrategyModule(tqm)

    assert strategy.tqm == tqm
    assert strategy.tqm.inventory.name == 'inventory'
    assert strategy.tqm.variable_

# Generated at 2022-06-21 07:24:42.410670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test code
    task_queue_manager = None
    debugger = Debugger(tqm=task_queue_manager)
    print(isinstance(debugger, object))
    print(isinstance(debugger, LinearStrategyModule))
    assert isinstance(debugger, LinearStrategyModule)

# test_StrategyModule()

# Generated at 2022-06-21 07:24:45.684646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule()
    assert test_module.debugger_active == True


# Generated at 2022-06-21 07:24:47.507709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-21 07:24:51.384002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test object of type StrategyModule
    test_strategy_module = StrategyModule(None)
    print(test_strategy_module)


# Generated at 2022-06-21 07:24:55.815007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:25:02.098798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    try:
        strategy = StrategyModule(tqm)
    except TypeError:
        assert False, "StrategyModule() does not take any argument"
    else:
        assert isinstance(strategy, StrategyModule)



# Generated at 2022-06-21 07:25:12.061844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    display = Display()
    display.verbosity = 0
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
    )
    debug = StrategyModule(tqm)
    assert debug.debugger_active == True


# Generated at 2022-06-21 07:26:47.939105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(None)
    assert tqm.debugger_active == True
# End of test case


# Generated at 2022-06-21 07:26:52.811037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    debugger_active = True
    strmod = StrategyModule(tqm)
    assert strmod.debugger_active == debugger_active


# Generated at 2022-06-21 07:26:54.180430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:26:58.291726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == None
    assert StrategyModule.__init__.__dict__['__module__'] == '__main__'


# Generated at 2022-06-21 07:27:02.565187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm.debugger_active



# Generated at 2022-06-21 07:27:09.547471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' in globals(), "StrategyModule must be defined"
    s = StrategyModule(None)
    assert isinstance(s, StrategyModule), "StrategyModule is not a subclass of StrategyModule"
    assert s.debugger_active == True, "s.debugger_active must be True"
    return s



# Generated at 2022-06-21 07:27:12.767052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Running StrategyModule constructor")
    assert True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:27:20.375596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        host_list = None
        inventory = None
        variable_manager = None
        loader = None
        options = None
        passwords = None
        stdout_callback = None
        run_additive_tasks = None
        run_subset = None
        new_stdin = None
        callback = None

    tqm = TQM()

    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:27:27.758927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_hosts = ['host1', 'host2', 'host3', 'host4']
    strategy = StrategyModule(test_hosts)
    assert hasattr(strategy, 'tqm')
    assert strategy.tqm == test_hosts
    assert hasattr(strategy, 'debugger_active')
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:27:35.901967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    sm = StrategyModule(tqm)
    assert hasattr(sm, 'debugger_active')
