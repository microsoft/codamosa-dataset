

# Generated at 2022-06-21 07:19:07.682213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:19:09.040875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-21 07:19:09.859562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:19:13.173339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-21 07:19:14.539606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pprint.pprint('constructor of class StrategyModule')


# Generated at 2022-06-21 07:19:20.247702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def __init__(self):
            self.stdout_callback = None
    task_queue_manager = TaskQueueManager()
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module != None
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:19:29.245982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Host:
        pass
    tqm = Host()
    tqm.host_result_callback = None
    tqm.job_result_callback = None
    tqm.stats = None
    tqm.host_queue = None
    tqm.result_q = None
    tqm.task_events = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:19:30.001414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()



# Generated at 2022-06-21 07:19:31.273423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # this should be true
    StrategyModule(tqm=None).debugger_active



# Generated at 2022-06-21 07:19:32.153480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True # 1+1 == 2



# Generated at 2022-06-21 07:19:35.916869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n")
    StrategyModule([])
    print("\n")


# Generated at 2022-06-21 07:19:41.498516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert repr(s) == "<ansible.plugins.strategy.debug.StrategyModule object at 0x10e8b2550>"
    #assert s.debugger_active == True



# Generated at 2022-06-21 07:19:44.108229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# inherits from LinearStrategyModule

# Generated at 2022-06-21 07:19:48.169595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup variables
    tqm = None

    # Constructor test
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-21 07:19:52.519601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except:
        print("Exception in StrategyModule constructor")
        assert False
    assert True


# Generated at 2022-06-21 07:19:55.978210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm1 = None
    tqm2 = None
    stm = StrategyModule(tqm1)
    stm = StrategyModule(tqm2)



# Generated at 2022-06-21 07:19:59.464437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = {}
    task_queue_manager = {}
    strategyModule = StrategyModule(task_queue_manager)
    assert strategyModule != None


# Generated at 2022-06-21 07:20:04.188910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    strategy_module = StrategyModule(tqm)
    if strategy_module.debugger_active != True:
        raise AssertionError()


# This class is for test

# Generated at 2022-06-21 07:20:12.313987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.host_list = ['testhost']
    class TestInventory:
        def hosts(self):
            return TestTQM.host_list
    tqm = TestTQM()
    tqm.inventory = TestInventory()
    strategy = StrategyModule(tqm)
    assert tqm.inventory.hosts() == strategy.tqm.inventory.hosts()
    assert tqm.host_list == strategy.tqm.inventory.hosts()
    assert strategy.debugger_active == True

# Unit test method of class StrategyModule:debugger
#def test_StrategyModule_debugger():

# Unit test method of class StrategyModule:insert_tqm_variables
#def test_StrategyModule_insert_

# Generated at 2022-06-21 07:20:18.398757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', 'debug.yml']
    tqm = AnsibleTaskQueueManager(
        inventory=InventoryManager(loader=loader, sources='localhost,'),
        variable_manager=variable_manager,
        loader=loader,
        passwords=dict(),
        stdout_callback=None)
    process = StrategyModule(tqm)



# Generated at 2022-06-21 07:20:24.673689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module = StrategyModule(None)
    except:
        # According to unit test, raise an exception
        return False

    return isinstance(strategy_module, StrategyModule) and strategy_module.debugger_active


# Generated at 2022-06-21 07:20:30.024784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        def __init__(self):
            self.hostvars = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active



# Generated at 2022-06-21 07:20:40.906120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm():
        def __init__(self):
            self.hosts_left_to_run = ['host1', 'host2']
    class MockPlayContext():
        def __init__(self):
            self.become = False
            self.become_user = ''
    class MockTask():
        def __init__(self):
            self.play_context = MockPlayContext()
        
    mock_tqm = MockTqm()
    mock_task = MockTask()
    sm = StrategyModule(mock_tqm)
    sm.delete_cur_task()
    # First task
    sm.add_cur_task(mock_task)
    # Second task
    sm.add_cur_task(mock_task)
    # Delete second task
    sm.delete_cur

# Generated at 2022-06-21 07:20:51.088464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    s = StrategyModule(tqm)
    assert s.tqm == tqm
    assert s.strategy == 'debug'
    assert s.debugger_active == True

# StrategyModule::run
#
# Function of StrategyModule:
#         def run(self):
#             '''
#             Executes the strategy module.
#             '''
#             super(StrategyModule, self).run()
#
#             if C.DEFAULT_KEEP_REMOTE_FILES:
#                 display.warning("The option `default_keep_remote_files` is set to True. "
#                                 "This means existing temporary files will be not deleted after the playbook finishes.")
#
#             display.banner("Running free form commands on all hosts via '%s' runner" % self._play_

# Generated at 2022-06-21 07:20:55.915389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-21 07:21:00.658183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True

"""
    TODO:
        - add variables
        - add facts
        - add results
        - add state
        - add task
        - add play
        - add step
        - add strategy
        - add stuff
        - ...
"""

# Generated at 2022-06-21 07:21:02.110703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # Should not raise any Exception


# Generated at 2022-06-21 07:21:06.185384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        assert (StrategyModule(tqm))
    except:
        assert False


# class for prompt user for input

# Generated at 2022-06-21 07:21:08.505209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule('test_tqm')

# Override function begin_play() from class StrategyModule

# Generated at 2022-06-21 07:21:11.981960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for check constructor of class StrategyModule.
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-21 07:21:22.835745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    from mock import MagicMock
    tqm = MagicMock()
    strategy_module = debug.StrategyModule(tqm)
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module.task_queue_manager == tqm


# Generated at 2022-06-21 07:21:25.761273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm).debugger_active


# Generated at 2022-06-21 07:21:27.956797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(1)
# #####################

# test_ansible

# Generated at 2022-06-21 07:21:29.080756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:21:31.753857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # As constructor of class StrategyModule is not accessible directly
    # so test will check whether the class is being initialized or not
    try:
        _ = StrategyModule(tqm = 'test')
    except:
       assert(False)
    assert(True)


# Generated at 2022-06-21 07:21:37.563325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing Strategy Module constructor")
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == ""
    print("Strategy Module constructor passed")


# Generated at 2022-06-21 07:21:40.958737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global debugger_active
    debugger_active = True
    g = StrategyModule()
    assert debugger_active == g.debugger_active
    return g


# Generated at 2022-06-21 07:21:45.844892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__mro__ == (StrategyModule, LinearStrategyModule, object)



# Generated at 2022-06-21 07:21:56.914361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.plugins import load_class
    from ansible.utils.color import colorize, ANSIBLE_COLOR
    from ansible.plugins.strategy import StrategyBase
    import ansible.playbook.task_include as task_include
    tqm = load_class('ansible.executor.task_queue_manager.TaskQueueManager')()
    tqm._final_q = load_class('ansible.executor.task_queue_manager.TaskQueueManager')()
    tqm._final_q._queue = []
    tqm._inventory = load_class('ansible.inventory.manager.InventoryManager')()
    tqm._loader = load_class('ansible.parsing.dataloader.DataLoader')()

# Generated at 2022-06-21 07:22:01.180730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:22:14.933416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active
    assert strategy.tqm is tqm



# Generated at 2022-06-21 07:22:20.170443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible.plugins.loader'] = 'Test'
    from ansible.plugins.loader import strategy_loader
    strategy_loader._create_instances()
    assert strategy_loader._strategy_plugins == {'linear': StrategyModule}




# Generated at 2022-06-21 07:22:21.959802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # test main
  s = StrategyModule(None)
  assert s.tqm == None
  assert s.debugger_active

# Run with --debug not in args

# Generated at 2022-06-21 07:22:23.546787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("class StrategyModule")



# Generated at 2022-06-21 07:22:26.367085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Testing variable debugger_active
# debugger_active is field of class StrategyModule

# Generated at 2022-06-21 07:22:27.806207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Constructor for class Debugger

# Generated at 2022-06-21 07:22:32.608246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert sm.debugger_active == True
    assert sm.host_states == dict()
    assert sm.index == 0
    assert sm.noop_task is None
    assert sm.tqm == None
    assert sm.task_queue == list()


# Generated at 2022-06-21 07:22:35.393139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print()
    tqm = None
    strategy = StrategyModule(tqm)
    pprint.pprint(strategy.__dict__)


# Generated at 2022-06-21 07:22:41.183202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestObject():
        def __init__(self):
            self.step_execution = False

    tqm = TestObject()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active != False


# Generated at 2022-06-21 07:22:42.639550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Executor for unit test of StrategyModule

# Generated at 2022-06-21 07:23:01.328688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    assert StrategyModule(tqm) is not None


# Generated at 2022-06-21 07:23:03.712982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: create a strategy module and pass it to tqm
    pass



# Generated at 2022-06-21 07:23:10.350375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm.tqm == 1
    assert sm.debugger_active == True
    assert sm.hosts_left == None
    assert sm.tasks_to_run == None
    assert sm.statistics == None
    assert sm.strategy == 'debug'
    assert sm.name == 'debug'

# Generated at 2022-06-21 07:23:13.545262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("test")
    assert module.debugger_active == True


# Generated at 2022-06-21 07:23:21.565713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    from ansible.playbook.task_queue_manager import TaskQueueManager
    class FakeTaskQueueManager(TaskQueueManager):
        def __init__(self):
            self.list_hosts = ['localhost', 'localhost']
            self.list_tasks = []
            self.options = {'listhosts': False}

    str_obj = StrategyModule(FakeTaskQueueManager())

    # Assert
    assert str_obj.debugger_active


# Generated at 2022-06-21 07:23:25.434535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This class cannot be unit tested.
    # It needs many elements to instantiate strategy module object.
    pass



# Generated at 2022-06-21 07:23:26.990043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active



# Generated at 2022-06-21 07:23:28.009286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:23:31.549428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _module = StrategyModule(None)
    assert(isinstance(_module.tqm, type(None)))
    assert(_module.debugger_active == True)


# Generated at 2022-06-21 07:23:36.638832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def __init__(self):
            self.hostvars = {
                "host1": {
                        "testvar1": "value1",
                        "testvar2": "value2",
                        "testvar3": "value3",
                        },
                "host2": {
                        "testvar4": "value4",
                        "testvar5": "value5",
                        "testvar6": "value6",
                        },
                }

    test_tqm = TestTqm()
    test_sm = StrategyModule(test_tqm)

    assert test_sm.debugger_active is True


# Generated at 2022-06-21 07:24:26.976605
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    print('\nRunning test_StrategyModule...')
    LinearStrategyModule()
    StrategyModule()
    print('Passed test_StrategyModule')

if __name__ == '__main__':
    import unittest
    sys.exit(unittest.main(verbosity=2))

# Generated at 2022-06-21 07:24:29.925099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)
    # assert False, "Unimplemented"



# Generated at 2022-06-21 07:24:32.858803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:24:38.136124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert(strategy_module._debugger_active == True)


# Generated at 2022-06-21 07:24:42.410106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategyModule = StrategyModule(tqm)
    assert None != strategyModule
    tqm = object()
    strategyModule = LinearStrategyModule(tqm)
    assert None != strategyModule

# Executes tasks in interactive debug session
# In other words, this method is called by the 'ansible-playbook' command

# Generated at 2022-06-21 07:24:44.958410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-21 07:24:45.584158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:24:47.074608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:24:49.532758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active



# Generated at 2022-06-21 07:24:56.311048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import ansible.plugins.loader

    ansible.plugins.loader._package_overrides = collections.defaultdict(dict)
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=ansible.inventory.manager.InventoryManager('127.0.0.1'))

    strategy_module = StrategyModule(tqm)
    assert strategy_module
    assert not strategy_module.debugger_active



# Generated at 2022-06-21 07:26:27.893368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    parser = MockParser()
    options = parser.parse_args()
    tqm = MockTaskQueueManager(options)

    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-21 07:26:31.259454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test of the constructor in class StrategyModule
    try:
        StrategyModule()
        assert False
    except NameError:
        assert True



# Generated at 2022-06-21 07:26:33.940762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #print("Starting test_StrategyModule")
    #print("Ending test_StrategyModule")
    return


# Generated at 2022-06-21 07:26:34.816901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global debugger_active
    print("test for constructor of class StrategyModule")
    debugger_active = True



# Generated at 2022-06-21 07:26:41.286660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    StrategyModule(tqm)
    assert True

#    def run(self, iterator, play_context):
#        hosts = [host for host in self._tqm.inventory.get_hosts(iterator._play.hosts) if host.name not in iterator._play.dep_chain]
#        debug_hosts = [host for host in self._tqm.inventory.get_hosts(iterator._play.hosts) if host.name not in iterator._play.dep_chain]
#        hosts_results = []
#
#        try:
#            for host in debug_hosts:
#                self._display.v("GATHERING FACTS %s" % host)
#                self._tqm.send_callback('v2_runner_on_ok', host, 'G

# Generated at 2022-06-21 07:26:45.286868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.debugger_active == True
    assert isinstance(StrategyModule, type)
    assert issubclass(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-21 07:26:46.830630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-21 07:26:47.862376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Nothing to test.
    return

# Generated at 2022-06-21 07:26:50.400241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)



# Generated at 2022-06-21 07:26:55.905326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM (object):
        def __init__(self):
            self.tqm = 'test_tqm'

    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)

