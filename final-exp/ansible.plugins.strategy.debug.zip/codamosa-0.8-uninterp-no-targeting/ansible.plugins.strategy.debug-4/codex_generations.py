

# Generated at 2022-06-21 07:19:08.313324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:19:12.750269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None, None, None)
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module.tqm is not None

# Generated at 2022-06-21 07:19:13.651564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:19:24.601225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_tqm = "I'm tqm"
    my_strategy_module = StrategyModule(my_tqm)
    assert my_strategy_module.debugger_active == True


    class Debugger(cmd.Cmd):
        '''
        Interactive debugger extension of cmd.Cmd
        '''

        def __init__(self):
            cmd.Cmd.__init__(self)
            self.prompt = '**db**> '

        def display(self, v, fmt='pprint'):
            '''
            Print the value of a variable
            '''
            print('\n')
            if fmt == 'pprint':
                pprint.pprint(v)

        def do_display(self, args):
            '''
            Display the value of a variable
            '''

# Generated at 2022-06-21 07:19:27.238577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)
test_StrategyModule()


# Generated at 2022-06-21 07:19:30.371233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("TEST")
    #TODO implement test
    print("END TEST")


# Generated at 2022-06-21 07:19:31.714532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-21 07:19:32.745960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:19:35.278584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:19:37.044212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-21 07:19:43.714445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        t = tqm = ''
        x = StrategyModule(t)
    except NameError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 07:19:50.597259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm)
  assert isinstance(strategy_module, StrategyModule)
  assert isinstance(strategy_module, LinearStrategyModule)



# Generated at 2022-06-21 07:20:00.038373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    exec("from ansible.plugins.strategy import linear")
    exec("from ansible.plugins.strategy import debug")
    print("---", linear.__name__)
    print("---", debug.__name__)
    print("---", linear.StrategyModule)
    print("---", debug.StrategyModule)
    print("---", linear.StrategyModule.__bases__)
    print("---", debug.StrategyModule.__bases__)
    assert linear.__name__ is not debug.__name__
    assert linear.StrategyModule is not debug.StrategyModule
    assert linear.StrategyModule.__bases__ is not debug.StrategyModule.__bases__
    assert linear.StrategyModule.__bases__[0] is debug.StrategyModule.__bases__[0]

# Generated at 2022-06-21 07:20:09.482354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        def __init__(self, hosts_to_run, callbacks):
            self.hosts_to_run = hosts_to_run
            self.callbacks = callbacks

    class FakeRunner:
        def __init__(self, host):
            self.host = host

    class FakeTask:
        def __init__(self, name):
            self.name = name

    class FakeHost:
        def __init__(self, name):
            self.name = name

    def fake_load_callbacks():
        return ['callback0', 'callback1']

    def fake_get_host_list(host_pattern):
        hosts = []
        hosts.append(FakeHost(host_pattern))
        return hosts

    def fake_create_task(task):
        return FakeTask(task)

# Generated at 2022-06-21 07:20:10.236175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__("test")


# Generated at 2022-06-21 07:20:16.649997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Just do nothing but check if constructor is working
    import ansible
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 07:20:18.318608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:20:22.675497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class_instance = StrategyModule('tqm')
    except Exception as e:
        assert(e.args == ())
    assert(isinstance(class_instance, StrategyModule))


# Generated at 2022-06-21 07:20:24.051437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-21 07:20:30.957417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor without parameters
    strategyModule = StrategyModule(tqm=True)
    assert strategyModule.debugger_active is True
    assert strategyModule.tqm is True
    assert strategyModule.result_handler.default_handler is True

# Test functions of class StrategyModule

# Generated at 2022-06-21 07:20:37.299109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM:
        def __init__(self):
            self.hostvars = {}
    tqm = DummyTQM()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-21 07:20:38.103918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:20:41.292242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    mod = StrategyModule(tqm)

    # check properties
    assert mod.debugger_active == True


# Generated at 2022-06-21 07:20:44.024830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TODO: Figure out how to unit test.
    assert True



# Generated at 2022-06-21 07:20:52.030252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        ansible_play_hosts = None
    tqm = DummyTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert tqm.ansible_play_hosts is None
    assert strategy_module.tqm == tqm
    assert strategy_module.options is None
    assert strategy_module.host_list is None
    assert strategy_module.inventory is None
    assert strategy_module.variable_manager is None
    assert strategy_module.loader is None
    assert strategy_module.notified_handlers is None
    assert strategy_module.shared_loader_obj is None
    assert strategy_module.index is None
    assert strategy_module.current_task is None
    assert strategy_module.current_task_vars is None
    assert strategy_module

# Generated at 2022-06-21 07:20:57.089893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {
        'hostvars': {
            'host1': {'name': 'host1'},
            'host2': {'name': 'host2'}
        }
    }

    sm = StrategyModule(tqm)


# Generated at 2022-06-21 07:21:10.971896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager():
        def __init__(self):
            self.inventory = 'test'
            self.variable_manager = 'test'
            self.loader = 'test'
            self.options = 'test'
            self.passwords = 'test'
            self.stdout_callback = 'test'
            self.connection_info = 'test'

    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.inventory == tqm.inventory
    assert sm.variable_manager == tqm.variable_manager
    assert sm.loader == tqm.loader
    assert sm.options == tqm.options
    assert sm.passwords == tqm.password
    assert sm.stdout_callback == tqm.std

# Generated at 2022-06-21 07:21:22.636067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    context.CLIARGS = {'connection': 'local', 'module_path': None, 'forks': 100, 'become': None, 'become_method': None, 'become_user': None, 'check': False, 'diff': False}
    args = [
        'debug.yml'
    ]
    playbook_executor = PlaybookExecutor(args)

# Generated at 2022-06-21 07:21:25.313038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is True


# Generated at 2022-06-21 07:21:31.111469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
    )
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-21 07:21:38.364285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tcp = cmd.Cmd()
    StrategyModule(tcp)
    assert tcp.debugger_active is True


# Generated at 2022-06-21 07:21:40.323696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(tqm)
    assert t.debugger_active


# Generated at 2022-06-21 07:21:45.712684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    some_object = StrategyModule('tqm')
    assert some_object.debugger_active == True

# The debugger class is straightforwardly derived from cmd.Cmd,
# as shown with this code.

# Generated at 2022-06-21 07:21:56.844078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

#################################################################################
# Plugin Implementation
##############################################################################
# debug strategy
#
# Plugin to new strategy to use ansible-playbook --step, which will step through each task in a play.
# In each step, user will be prompted and if user chooses not to execute the step, the next step will be executed instead.
#
# The strategy plugin saves the variables of each host and displays them as a dictionary in the debug prompt for user to reference.
# The strategy plugin saves the facts of each host and displays them as a dictionary in the debug prompt for user to reference.
# The strategy plugin saves the templated results of each task and displays them in the debug prompt for user to reference.
# The strategy plugin saves the stdout_lines results of each task and displays them in the debug prompt for user to reference.
#

# Generated at 2022-06-21 07:22:00.712019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    StrategyModule(tqm)
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-21 07:22:02.203514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Test code for class StrategyModule

# Generated at 2022-06-21 07:22:05.797013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert isinstance(s, LinearStrategyModule)
    assert s.debugger_active == True


# Generated at 2022-06-21 07:22:11.085646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print('Testing __init__')

  real_tqm = object()
  strategy_module = StrategyModule(real_tqm)

  assert strategy_module.tqm == real_tqm
  assert strategy_module.debugger_active == True
  print('Constructor test passed')


# Generated at 2022-06-21 07:22:18.432347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    tqm = {'tqm': 1}
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True
    assert sm.tqm == tqm
    assert sm.servers == None
    assert sm.host_vardirs == None


# Generated at 2022-06-21 07:22:22.579299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        setup_done = False
        cleanup_done = False
    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm.host_result_callback is None
    assert sm.host_records is None
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:22:36.672503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.module_utils.connection import ConnectionFactory
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.parsing.dataloader import DataLoader

    # create empty play
    play = Play()
    task = Task()
    play.add_task(task)

    # create empty inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)

    # create empty variable manager
    variable_manager = VariableManager(host_list=inventory)


# Generated at 2022-06-21 07:22:37.300695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   print(StrategyModule)

# Generated at 2022-06-21 07:22:42.798474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# This class is modified version of http://code.activestate.com/recipes/134892/
# See http://code.activestate.com/recipes/134892/license.html
# Note that this is a recipe and has no copyright.

# Generated at 2022-06-21 07:22:48.056821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    myStrategy = StrategyModule(tqm)
    assert myStrategy.debugger_active == True
    

# Generated at 2022-06-21 07:22:51.216904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test the constructor
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert type(sm) == StrategyModule


# Generated at 2022-06-21 07:22:52.697283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-21 07:23:00.836775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active == True

    # TODO: Is there a way of testing the __init__(tqm) of LinearStrategyModule?



# Generated at 2022-06-21 07:23:10.175856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategymodule = StrategyModule(tqm)


# TaskQueueManager is a Cmd object and do_debug is one of its methods.
# We replaced do_debug with a new method of same name. That's why debugger_active
# is a member so that we can access it in the new method.
# We copied the original method to do_debug_orig and changed it to private.
# Then we added a new method of name do_debug.

# Generated at 2022-06-21 07:23:14.600833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm, LinearStrategyModule)
    assert not sm.debugger_active


# Generated at 2022-06-21 07:23:19.328854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    strategy_module = StrategyModule(tqm=None)
    print("StrategyModule - OK")


StrategyModule.debugger = cmd.Cmd()
StrategyModule.debugger.prompt = '> '


# Generated at 2022-06-21 07:23:36.528123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ != None

# Generated at 2022-06-21 07:23:37.462515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:23:40.715512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing implementation of __init__ in class StrategyModule
    module = StrategyModule(None)
    assert hasattr(module, 'debugger_active')
    assert module.debugger_active == True


# Generated at 2022-06-21 07:23:43.238962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:23:48.604008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert(s.debugger_active == True)

# from this point on the code is the actual debugger implementation.

# This is a fake task based on cmd.Cmd.
# TODO: support more commands, such as "set"

# Generated at 2022-06-21 07:23:53.669877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass(object):
        pass
    test_obj = TestClass()
    test_obj.playbook = TestClass()
    test_obj.playbook.hostvars = {}

    test_sm = StrategyModule(test_obj)
    assert isinstance(test_sm, StrategyModule)



# Generated at 2022-06-21 07:23:54.702281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)



# Generated at 2022-06-21 07:23:59.809096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "abc"
    test = StrategyModule(tqm)
    assert test.tqm == "abc"
    assert test.debugger_active == True


# Generated at 2022-06-21 07:24:03.026176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:24:09.359898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Unittest for execution of class StrategyModule '''
    import ansible.plugins.strategy_debugger as StrategyModule
    import ansible.playbook.task as task

    test_task = task.Task(play=None,
                          block=None,
                          role=None,
                          task_include=None,
                          parameters=None,
                          private_data=None,
                          variable_manager=None,
                          loader=None)

    import ansible.playbook.play as play
    test_play = play.Play().load({})
    test_task._play = test_play

    test_play_ds = test_play._ds
    test_task._ds = test_play_ds

    import ansible.template as template

# Generated at 2022-06-21 07:25:59.102164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:26:07.774685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# End of unit test

    def run(self, iterator, play_context):
        '''
        Override run function of the linear strategy.
        '''
        self.inventory = self._tqm._inventory

        # Create class object
        myclass = MyOutClass(self, play_context)

        # Run class method
        myclass.run(self._tqm._inventory.get_hosts(iterator._play.hosts))


# Generated at 2022-06-21 07:26:11.496009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule(tqm)
    assert tm.debugger_active == True



# Generated at 2022-06-21 07:26:14.441883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    pass



# Generated at 2022-06-21 07:26:17.146994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return
    # dummy variables
    tqm = None
    # test function
    strategy_module = StrategyModule(tqm)
    return


# Generated at 2022-06-21 07:26:22.725389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule
    # Create an object of class StrategyModule and check if __init__ was called correctly
    strategyModule = StrategyModule(None)
    assert strategyModule.debugger_active is True, "Constructor of class StrategyModule failed to assign the value True to variable debugger_active"

    # Test for constructor of class DebugCmd
    # Create an object of class DebugCmd and check if __init__ was called correctly
    debugCmd = DebugCmd(None)
    assert debugCmd.cmdqueue == [], "Constructor of class DebugCmd failed to assign the value [] to variable cmdqueue"
    assert debugCmd.prompt == "(dbg) ", "Constructor of class DebugCmd failed to assign the value (dbg) to variable prompt"

# Generated at 2022-06-21 07:26:27.281201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_debugger = Debugger(None, None)
    global_debugger.debugger_active = False

    test = StrategyModule(None)
    assert test.debugger_active == global_debugger.debugger_active



# Generated at 2022-06-21 07:26:30.910035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:26:34.178305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # arrange, act and assert
    module = StrategyModule(tqm=None)
    assert isinstance(module, StrategyModule)



# Generated at 2022-06-21 07:26:35.531689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

