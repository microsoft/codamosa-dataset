

# Generated at 2022-06-21 07:19:18.734644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule.
    """
    assert StrategyModule.__name__ == 'StrategyModule'

# Debugger to bring up interactive debugging session.
# Executes the task list linearly, bringing the user into
# a debugger session when an error is encountered.

# Generated at 2022-06-21 07:19:20.712595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:19:26.963277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test constructor of class StrategyModule
    tqm = StrategyModule('tqm')
    assert(tqm.debugger_active == True)


# Generated at 2022-06-21 07:19:38.152042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {"hoge": "fuga"}
    inventory = Inventory("hosts", variable_manager)
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=None,
                           options=None, passwords=None)
    playbook = PlayBook(loader=None, inventory=inventory, variable_manager=variable_manager,
                        options=None, passwords=None)
    strategy_module = StrategyModule(tqm)
    assert tqm == strategy_module.tqm
    assert type(strategy_module) == StrategyModule

# Generated at 2022-06-21 07:19:47.111294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        if sys.version_info >= (3,0):
            from io import StringIO
        else:
            from StringIO import StringIO

        class FakeTaskQueueManager:
            def __init__(self):
                self.out = StringIO()

        tqm = FakeTaskQueueManager()
        strategy = StrategyModule(tqm)
        assert strategy.__class__.__name__ == 'StrategyModule'
    except:
        # if an assertion fails then it'll be caught by the test runner anyway
        pass

#Unit test for run method of class StrategyModule

# Generated at 2022-06-21 07:19:48.615420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")
    assert True



# Generated at 2022-06-21 07:19:51.201899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-21 07:19:53.431961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    try:
        assert strategy_module.debugger_active == True
    except AssertionError:
        print("Error: assert failed!")

# Execute function

# Generated at 2022-06-21 07:19:55.813817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active


# Generated at 2022-06-21 07:19:59.465268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True
    assert type(sm) == StrategyModule



# Generated at 2022-06-21 07:20:09.917325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO(Kishin): Remove DATA_DIR after fixing it.
    DATA_DIR = 'C:/Users/Kishin/Documents/ansible/test/integration/complex'
    OPTIONS = {'module_path': '', 'forks': 1, 'become':  False, 'become_method': None, 'become_user': None, 'verbosity': 4, 'check': False}
    loader, inventory, variable_manager = AnsibleLoader(DATA_DIR, OPTIONS)
    tqm = AnsibleTaskQueueManager(inventory, variable_manager, loader, options=OPTIONS)
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Generated at 2022-06-21 07:20:10.930042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm").debugger_active == True



# Generated at 2022-06-21 07:20:13.820361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('foo')
    assert obj.tqm == 'foo'
    assert obj.debugger_active == True


# Generated at 2022-06-21 07:20:17.813042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active == True


# Generated at 2022-06-21 07:20:25.721943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.test_var = 'cde'

    test_obj = TestTQM()
    test_obj.test_var = 'abc'

    test_task_queue_manager = StrategyModule(test_obj)
    assert test_task_queue_manager.debugger_active == True
    assert test_task_queue_manager.tqm == test_obj
    assert test_obj.test_var == 'cde'


# Generated at 2022-06-21 07:20:30.809023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule: Start")
    stm = StrategyModule(None)
    print("test_StrategyModule: Finish")


# Generated at 2022-06-21 07:20:33.216749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-21 07:20:36.545250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    p = StrategyModule(tqm)
    assert p.debugger_active == True


# Generated at 2022-06-21 07:20:37.238708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:20:39.706968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ret = StrategyModule(tqm='tqm')
    assert ret.debugger_active == True



# Generated at 2022-06-21 07:20:43.195104
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:20:51.727854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    taskmgr = None
    sm = StrategyModule(taskmgr)
    assert sm.debugger_active


# Generated at 2022-06-21 07:21:00.101583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = MockTaskQueueManager()
    strategy = StrategyModule(mock_tqm)
    assert strategy.tqm == mock_tqm
    assert strategy.debugger_active
    assert isinstance(strategy.display, DebugDisplay) # defined below in the DebugDisplay class
    assert strategy.display.task_queue_manager == mock_tqm


# Generated at 2022-06-21 07:21:01.383246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp = StrategyModule(None)
    assert tmp.debugger_active


# Generated at 2022-06-21 07:21:05.955064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except TypeError:
        print('TypeError: __init__() missing 1 required positional argument: tqm')
# End of Unit test for constructor of class StrategyModule


# Generated at 2022-06-21 07:21:09.035440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    sm = StrategyModule(tqm)
    assert sm._tqm == 0
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:21:14.528301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TEST_TASK_QUEUE_MANAGER'
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True


# CmdLine class for Interactive Debug

# Generated at 2022-06-21 07:21:17.364346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    helper = LinearStrategyModule({})
    print(helper)
    assert helper




# Generated at 2022-06-21 07:21:18.184551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:21:18.745822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:21:32.888369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        _final_q = []
        _internal_id_count = 1
        def build_main_task_queue(self):
            class TestQ:
                def __init__(self):
                    self.queue = [1, 2, 3]
                def __len__(self):
                    return len(self.queue)
                def __getitem__(self, item):
                    return self.queue[item]
                def get(self, timeout=None):
                    return None

            class TestTask:
                def __init__(self):
                    self._task = TestQ()
                    self._strategy = StrategyModule(self)
                @property
                def task(self):
                    return self._task

            return TestTask()

        @property
        def final_q(self):
            return self._final_

# Generated at 2022-06-21 07:21:34.863476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    StrategyModule(tqm)
    pass


# Generated at 2022-06-21 07:21:37.921865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'

#
# This is the main part of this file
#

# The class Debugger is the main part of the functionality
# The functionality is the same as in ansible-playbook. The only difference is that the latter
# is triggered by pressing CTRL+D (EOF) and this is always enabled

# Generated at 2022-06-21 07:21:45.250433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible import context

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=[]),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
        options=context.CLIOptions(),
        passwords={},
        stdout_callback='default',
    )
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:21:50.322553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    return strategy_module


# TODO: move this class to the utils/ in the future

# Generated at 2022-06-21 07:21:52.034939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-21 07:21:57.512131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:21:59.113656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: impl
    pass

# vim: set et ts=8 sw=4 :

# Generated at 2022-06-21 07:22:05.391799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# TODO: need to implement michaelts/ansible-playbook#1685
# class Debugger(cmd.Cmd):
#     """
#     The debugger class
#     """
#     def __init__(self, tqm):
#         cmd.Cmd.__init__(self)
#         self.prompt = ''
#         self.tqm = tqm
#         self.current_task = None
#         self.task_results = []

#     def precmd(self, line):
#         """
#         This method is called after the line has been input
#         but before it has been interpreted.
#         """
#         self.prompt = '(' + (
#             'ok' if self.current_task.result._result['failed'] == False else 'failed'
#

# Generated at 2022-06-21 07:22:08.877754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            pass
    tqm = TestTqm()
    StrategyModule(tqm)



# Generated at 2022-06-21 07:22:18.918840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active


# Generated at 2022-06-21 07:22:21.166336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '''Default TQM'''
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True


# Generated at 2022-06-21 07:22:22.537046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-21 07:22:25.052276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:22:25.521733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == False


# Generated at 2022-06-21 07:22:31.218255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
    tqm = TestStrategyModule(None)
    assert tqm.debugger_active == True


# Generated at 2022-06-21 07:22:36.672454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule(None)

    # instance of StrategyModule is returned
    assert isinstance(my_strategy, StrategyModule)
    # has the right parent
    assert my_strategy.__class__.__bases__[0] == LinearStrategyModule
    # debugger_active is True by default
    assert my_strategy.debugger_active



# Generated at 2022-06-21 07:22:47.182208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.callbacks
    import ansible.plugins.loader
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.executor.task_queue_manager
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.plugins.strategy
    import ansible.plugins.strategy.linear
    import ansible.template
    import ansible.utils.vars
    import ansible.utils
    import ansible.utils.display
    import ansible.utils.plugin_docs
    import ansible.errors
    import ansible.constants

    from ansible.parsing.metadata import MetaParser
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-21 07:22:49.089649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-21 07:22:52.069213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm._stats = {}
    tqm._inventory = {}
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj.debugger_active == True


# Put class Debugger in global namespace

# Generated at 2022-06-21 07:23:13.482815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class fake_tqm(object):
        def __init__(self, play):
            self.play = play

    class fake_play(object):
        def __init__(self):
            self.tasks = []

    fakeplay = fake_play()
    faketqm = fake_tqm(fakeplay)
    strategy = StrategyModule(faketqm)
    assert strategy.tqm == faketqm



# Generated at 2022-06-21 07:23:14.392914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:23:17.485876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert isinstance(strategy_module, StrategyModule)



# Generated at 2022-06-21 07:23:18.842614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:23:22.214082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    strate = StrategyModule(tqm)
    assert not strate.new_tasks is None
    assert strate.cleanup_mess is False
    assert strate.debugger_active is True



# Generated at 2022-06-21 07:23:34.603700
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:23:40.252254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Dummy test to check whether copy & paste from the generated code works """
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active

# Unit test to check whether copy & paste from the generated code works

# Generated at 2022-06-21 07:23:42.713904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod != None
    assert mod.debugger_active == True


# Generated at 2022-06-21 07:23:54.283881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


    def get_host_result(self, result):
        debug_results = []
        # This is basically copied and modified from ActionBase.run()
        # we basically re-run the entire thing with the debugger enabled.
        new_tqm = self._play_context.make_new_tqm(loader=self._loader, var_manager=self._variable_manager,
                                                  shared_loader_obj=self._shared_loader_obj)

        # all hosts, task and vars are constructed in advance
        # pylint: disable=too-many-nested-blocks

# Generated at 2022-06-21 07:23:59.940848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.debugger_active == True



# Generated at 2022-06-21 07:24:50.927286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest.mock as mock
    from ansible.plugins.strategy.debug import StrategyModule

    # initialize with mock for task queue mangager, then assert
    mock_tqm = mock.Mock(tasks=[], connection_info=None, remaining_tasks=[],
               stats=None, loader=None, variable_manager=None, stdout_callback=None)
    sm = StrategyModule(mock_tqm)
    assert sm.tqm == mock_tqm
    assert sm.tqm.stats == sm.stats
    assert sm.tqm.loader == sm.loader
    assert sm.tqm.variable_manager == sm.variable_manager
    assert sm.tqm.stdout_callback == sm.stdout_callback



# Generated at 2022-06-21 07:24:55.998900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True



# Generated at 2022-06-21 07:24:57.668811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-21 07:25:06.302924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    tqm = None
    test = StrategyModule(tqm)
    try:
        assert test.tqm == tqm
        assert test.debugger_active == True
    except AssertionError:
        print("unit test for StrategyModule constructor failed")
        exit(1)
    print("unit test for StrategyModule constructor passed")
    exit(0)



# Generated at 2022-06-21 07:25:08.553601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        print("StrategyModule creator test pass!")



# Generated at 2022-06-21 07:25:11.122532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    sm = ansible.plugins.strategy.debug.StrategyModule(0)
    assert sm.debugger_active == True

# Generated at 2022-06-21 07:25:11.927105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:25:15.123300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    if (None != strategyModule._tqm):
        raise Exception("expecting _tqm to be None")
    if (False != strategyModule.debugger_active):
        raise Exception("expecting debugger_active to be False")



# Generated at 2022-06-21 07:25:19.685739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy.debugger_active


# Generated at 2022-06-21 07:25:28.737366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.config
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block

    # Creating Play, Block and Runner in order to run class StrategyModule
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=''))
        ]
    )

    play = Play().load(play_source, variable_manager={}, loader=ansible.cli.CLI.loader)

    tqm = None

# Generated at 2022-06-21 07:26:57.479525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = {}
    strategy_module = StrategyModule(tqm)
    if (not isinstance(strategy_module, LinearStrategyModule)):
        print("Unexpected strategy_module class")
        assert(False)
    if (not strategy_module.debugger_active):
        print("Debugger not active")
        assert(False)
    print("test_StrategyModule OK")


# Generated at 2022-06-21 07:27:06.516150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Constructor of class StrategyModule
    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self.debugger_active = True


    # define class for unit test
    class TqmClass(object):
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
            pass

    # Constructor of class TqmClass
    def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
        pass


    # construct tqm
    tqm_obj = TqmClass(None, None, None, None, None, None)

    # unit test of constructor
    strat = StrategyModule(tqm_obj)

# Generated at 2022-06-21 07:27:09.790242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    s = StrategyModule(test_tqm)
    assert s.debugger_active == True

# Unit test to check that debugger is active after initializing
# self.debugger_active

# Generated at 2022-06-21 07:27:12.904560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = tests.loader.TestLoader().loadTestsFromTestCase(MyTest)
    assert tqm is not None


# Generated at 2022-06-21 07:27:18.500280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj.__class__.__name__ == "StrategyModule"
    assert isinstance(obj, LinearStrategyModule)
    assert isinstance(obj, StrategyModule)
    assert isinstance(obj, object)

# Generated at 2022-06-21 07:27:29.879990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    assert StrategyModule.__init__.__func__.__doc__ == 'Initialize the strategy module.\n        :param tqm: The TaskQueueManager\n        :param play_context: The PlayContext\n        :param variable_manager: The VariableManager\n        :param loader: The DataLoader\n        :param options: The Options\n        :param passwords: The Passwords'


# Generated at 2022-06-21 07:27:33.119416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s.debugger_active is True
    assert s.tqm =="tqm"

#Unit test for playbook execute

# Generated at 2022-06-21 07:27:41.226331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import ansible.plugins.strategy.debug
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule

    class TestStrategyModule(unittest.TestCase):
        def test_StrategyModule_constructor(self):
            obj = ansible.plugins.strategy.debug.StrategyModule(None)
            self.assertIsInstance(obj, LinearStrategyModule)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-21 07:27:50.739281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None
    assert StrategyModule.on_file_diff.__doc__ is not None
    assert StrategyModule.run.__doc__ is not None
    assert StrategyModule.cleanup.__doc__ is not None
    assert StrategyModule.on_any.__doc__ is not None
    assert StrategyModule.on_failed.__doc__ is not None
    assert StrategyModule.on_ok.__doc__ is not None
    assert StrategyModule.on_unreachable.__doc__ is not None
    assert StrategyModule.on_skipped.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None

# Run unit tests
if __name__ == '__main__':
    test_StrategyModule()


# Generated at 2022-06-21 07:27:53.517893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj
    assert obj.debugger_active
