

# Generated at 2022-06-21 07:19:21.826372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.queue = []
        def grab_job_from_queue(self):
            return self.queue.pop(0)
        def executed_hosts(self):
            return {'127.0.0.1' : {'hostname' : '127.0.0.1', 'ok' : True, 'unreachable' : 0, 'skipped' : 0, 'failed' : 0}, '192.168.0.2' : {'hostname' : '192.168.0.2', 'ok' : True, 'unreachable' : 0, 'skipped' : 0, 'failed' : 0}}
        def print_stats(self):
            print('blah blah blah')

# Generated at 2022-06-21 07:19:32.858835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test 1:
  # Test StrategyModule with no TQM
  stm1 = StrategyModule(None)
  assert 0 == len(stm1.host_failed)
  assert 0 == len(stm1.host_unreachable)
  assert 0 == len(stm1.host_all)
  assert 0 == len(stm1.tasks)
  assert 0 == len(stm1.done)
  assert 0 == len(stm1.failed)
  assert 0 == len(stm1.unreachable)
  assert 0 == len(stm1.flag_done)
  assert 0 == len(stm1.notified_handlers)
  assert False == stm1.debugger_active

# Run me to test debug
if __name__ == '__main__':
  test_Strategy

# Generated at 2022-06-21 07:19:35.503248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active is True


# Generated at 2022-06-21 07:19:45.792588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = object()
    strategy_module = StrategyModule(tqm=task_queue_manager)
    assert strategy_module.tqm == task_queue_manager
    assert strategy_module.current_task_name == None
    assert strategy_module.current_play == None
    assert strategy_module.current_playbook == None
    assert strategy_module.current_loader == None
    assert strategy_module.current_variable_manager == None
    assert strategy_module.current_passwords == None
    assert strategy_module.background == 0
    assert strategy_module.callbacks == None
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:19:47.183109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-21 07:19:59.016567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug as debug_strategy_module
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )

    # Create data structure that represents our play, including tasks
   

# Generated at 2022-06-21 07:20:08.780441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = inventory._variable_manager
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
        stdout_callback=None
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True



# Generated at 2022-06-21 07:20:09.557323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:20:10.873479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test case for StrategyModule.
    """
    assert StrategyModule.__doc__



# Generated at 2022-06-21 07:20:13.711720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.tqm == None
    assert sm.debugger_active == True


# Generated at 2022-06-21 07:20:16.564084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # TODO: Proper test for this class



# Generated at 2022-06-21 07:20:21.619122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True

if __name__ == '__main__':
    sys.exit(0)

# Generated at 2022-06-21 07:20:24.709204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert sm.tqm == tqm


# Generated at 2022-06-21 07:20:33.495106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class Object:
        def __init__(self):
            self.shared_loader_obj = Object
            self.options = Object
            self.variables = Object
            self.inventory = Object
            self.stdout_callback = 'test'

    class Object2:
        def __init__(self):
            self.inventory = Object
            self.subset = Object
            self.subset_pattern = Object
            self.all_hosts = Object
            self.restriction = Object
            self.pattern = Object

    class Object3:
        def __init__(self):
            self.hostvars = Object

    obj = Object()
    obj2 = Object2()
    obj3 = Object3();

    strat = StrategyModule(obj)

    assert strat.tqm == obj
    assert strat.subset == None
   

# Generated at 2022-06-21 07:20:34.418955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:20:38.194441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testStrategyModule = StrategyModule("tqm")
    assert type(testStrategyModule) == StrategyModule
    assert testStrategyModule.debugger_active == True

# Unit test to check whether the results of self.run() is correct

# Generated at 2022-06-21 07:20:39.525398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return (StrategyModule(tqm))


# Generated at 2022-06-21 07:20:40.999431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:20:43.727762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymod = StrategyModule()
    assert strategymod.debugger_active == True

# Generated at 2022-06-21 07:20:46.169027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active



# Generated at 2022-06-21 07:20:49.418299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:20:52.057239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create debugger variable
    debugger = Debugger()
    debugger.cmdloop()




# Generated at 2022-06-21 07:20:57.362057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # print('hi')
    # print(strategy_module_instance.__class__.__name__)
    # print(strategy_module_instance.__doc__)
    strategy_module_instance = StrategyModule()
    print(strategy_module_instance.__init__())



# Generated at 2022-06-21 07:21:05.423235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=passwords, stdout_callback=results_callback)
  tqm = 'test'
  strategy = StrategyModule(tqm)
  assert strategy.debugger_active == True


# Generated at 2022-06-21 07:21:08.755292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ts = pprint.pformat(sys.modules)
    assert StrategyModule
    assert ts.find('ansible.plugins.strategy.debugger') != -1


# Generated at 2022-06-21 07:21:21.681355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy
    import ansible.plugins.strategy.debug
    import mock
    import unittest

    class StrategyModuleTest(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        @mock.patch.object(ansible.plugins.strategy.debug.StrategyModule, '__init__')
        @mock.patch.object(ansible.plugins.strategy.LinearStrategyModule, '__init__')
        def test_class_created(self, mock_linear_init, mock_super_init):
            tqm = mock.Mock()
            ansible.plugins.strategy.debug.StrategyModule(tqm)
            assert mock_linear_init.called
            assert mock_super_init.called

# Generated at 2022-06-21 07:21:28.326416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Positive test case
  sys.argv.append("-v")
  sys.argv.append("-vv")
  sys.argv.append("-vvv")
  tqm = {}
  StrategyModule(tqm) 
  assert StrategyModule.tqm == tqm



# Generated at 2022-06-21 07:21:38.151979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()

# Generated at 2022-06-21 07:21:38.516754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# Generated at 2022-06-21 07:21:39.537645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert type(s) == StrategyModule


# Generated at 2022-06-21 07:21:44.512015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:21:47.639844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule(1).debugger_active == True)
    assert (StrategyModule(1)._final_q == None)


# Generated at 2022-06-21 07:21:56.529586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    for i in range(10):
        try:
            args = sys.argv[1:]
            if not args:
                # test case 1: no argv, return with error
                sys.exit(255)
            elif args[0] == 'linear':
                # test case 2: linear strategy
                sys.exit(0)
            elif args[0] == 'debug':
                # test case 3: debug strategy
                sys.exit(1)
            else:
                # test case 4: other strategy
                sys.exit(10)
        except ValueError as e:
            # test case 5: ValueError
            sys.exit(2)


# Generated at 2022-06-21 07:22:00.076624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass  # Nothing to test


# Generated at 2022-06-21 07:22:02.125284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:22:05.174989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(issubclass(StrategyModule, cmd.Cmd))

# cmd.Cmd subclass that adds a do_pprint

# Generated at 2022-06-21 07:22:08.687315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {}
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:22:15.216200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    # Given
    linear_strategy_class_object = LinearStrategyModule(tqm = 'tqm')

    # When
    strategy_module_object = StrategyModule(tqm = 'tqm')

    # Then
    assert strategy_module_object
    assert strategy_module_object.run_handlers
    assert strategy_module_object.run_module_importers
    assert strategy_module_object.run_queue
    assert strategy_module_object.run_tasks
    assert strategy_module_object.debugger_active
    assert strategy_module_object.run_queue == linear_strategy_class_object.run_queue



# Generated at 2022-06-21 07:22:16.576155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:22:17.945379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active



# Generated at 2022-06-21 07:22:35.352147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestLinearStrategyModuleConstructor(unittest.TestCase):
        def setUp(self):
            import ansible.plugins.strategy.linear

            # initialize class StrategyModule
            self.test_class = StrategyModule(None)

        def tearDown(self):
            del self.test_class

        def test_StrategyModule_instance(self):
            self.assertIsInstance(self.test_class, StrategyModule)

        def test_StrategyModule_super(self):
            self.assertTrue(issubclass(StrategyModule, LinearStrategyModule))

        def test_StrategyModule_parent(self):
            self.assertTrue(issubclass(StrategyModule, ansible.plugins.strategy.linear.StrategyModule))


# Generated at 2022-06-21 07:22:36.179580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:22:40.079985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # debugger = StrategyModule(tqm)
    # assert debugger

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:22:40.652022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:22:49.704578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    # Create a simple play
    locals = Bunch(
        play_tasks = [Bunch(
            action = 'Bunch(value = {"command": "ls")',
            task = 'Bunch(name = play_task_1)'
            )],
        )
    g = globals()
    g.update(locals())
    tqm = Mock()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    '''
    pass


# Generated at 2022-06-21 07:22:50.431360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:22:55.003382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    s = StrategyModule(tqm)
    assert s.debugger_active == True
    assert s.tqm == 'tqm'
    assert s.play is None
    assert s.host_states is None
    assert s.results is None


# Generated at 2022-06-21 07:23:02.099836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for constructor of class StrategyModule
    class MockTQM(object):
        def __init__(self):
            self.done = False
    tqm = MockTQM()
    strategy = StrategyModule(tqm)
    actual = strategy._tqm.done
    expected = False
    assert actual == expected

# Generated at 2022-06-21 07:23:05.526108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    StrategyModule(tqm) == "StrategyModule(tqm)"


# Generated at 2022-06-21 07:23:10.552984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = object
        StrategyModule(tqm)
    except NameError:
        assert False, 'Unable to create object of class StrategyModule'


# Generated at 2022-06-21 07:23:27.895468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule(tqm) != None

# Generated at 2022-06-21 07:23:30.391856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-21 07:23:31.660130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:23:42.801913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit test for constructor of class StrategyModule')

    import sys
    import unittest
    from unittest import mock

    from ansible.plugins.strategy.debug import StrategyModule

    tqm = mock.Mock(name='tqm')

    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.run_one_task == strategy_module.run_task



# Generated at 2022-06-21 07:23:47.043240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=1)


# Generated at 2022-06-21 07:23:48.114133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Inside test_StrategyModule")
    assert True


# Generated at 2022-06-21 07:23:53.214400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


#--------------------------------------------------------------------------
# REPL
#--------------------------------------------------------------------------


# Generated at 2022-06-21 07:23:54.844165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'id': 'test_id'}
    StrategyModule(tqm)




# Generated at 2022-06-21 07:23:56.952866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:23:58.046164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:24:49.739051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import lib.ansible_module_runner as amr
    import lib.ansible_modlib as aml
    import lib.ansible_task_queue_manager as atqm
    m = amr.AnsibleModule('copy', 'copy', 'copy', 'copy')
    t = atqm.TaskQueueManager(module_name='debug')
    s = StrategyModule(tqm=t)
    assert(s.debugger_active == True)
    assert(s.tqm == t)
    assert(s.play_context == atqm.DEFAULT_PLAY_CONTEXT)


# Generated at 2022-06-21 07:24:51.437816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-21 07:24:56.227112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    s = StrategyModule(tqm)
    assert s.debugger_active == True

# Implementation of strategy module
    # This is a subclass of LinearStrategyModule



# Generated at 2022-06-21 07:24:58.825182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # Unit test for constructor of class Debugger



# Generated at 2022-06-21 07:25:04.259238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_TUPLE = ()
    HOST_LIST = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    module = StrategyModule(TASK_TUPLE)
    assert module.debugger_active == True


# Generated at 2022-06-21 07:25:05.386951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-21 07:25:07.009312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-21 07:25:12.597088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #make sure that the "parent" of the class is correct
    assert(StrategyModule.__bases__[0].__name__ == 'LinearStrategyModule')
    assert(LinearStrategyModule.__bases__[0].__name__ == 'BaseStrategyModule')

##CODE UNDER TEST


# Generated at 2022-06-21 07:25:15.174783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Tqm = make_mock_tqm()
    assert isinstance(Tqm, object)
    strategy_module = StrategyModule(Tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-21 07:25:15.893042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:26:45.460748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-21 07:26:48.346641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm.debugger_active


# Generated at 2022-06-21 07:26:51.762332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj
    assert obj.debugger_active


# Generated at 2022-06-21 07:26:52.607503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:27:00.355984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    mytqm = TaskQueueManager(
        inventory=Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost'),
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
    )
    assert mytqm.inventory.list_hosts() == ['localhost',]


# Generated at 2022-06-21 07:27:05.968080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n\n===Unit Test: StrategyModule.__init__()===")
    parser = argparse.ArgumentParser(description='TODO: should be documented')
    parser.add_argument('-v', '--verbose', action='store_true', default=False,
                        help='show detailed info')
    # Uncomment to test different argument
    # test_args = ['-vvvv','--become','--become-user','root','--ask-become-pass','--list-hosts','--list-tasks','--list-tags','--syntax-check','--check','--diff','--host','10.10.1.1','--step','--start-at-task','task10','--limit','foo','--forks','5','--subset','2','--module-path','~/ansible_modules']

# Generated at 2022-06-21 07:27:12.936436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play_context
    import ansible.executor.task_queue_manager
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.utils.vars

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader, sources='localhost')
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    passwords = {}
    context = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords, stdout_callback='default',
    )

# Generated at 2022-06-21 07:27:15.965537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule(None)
    print (strategy_module.debugger_active)


# Generated at 2022-06-21 07:27:23.669269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.vars import combine_vars

    StrategyBase.add_strategy('debug', StrategyModule)

    loader = DataLoader()
    inventory = Inventory

# Generated at 2022-06-21 07:27:26.115613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

