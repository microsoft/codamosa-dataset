

# Generated at 2022-06-23 12:51:40.974312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:51:41.481609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:51:44.054128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(1)
    assert isinstance(s, LinearStrategyModule)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:51:49.084139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        print("Testing constructor")
        print("Calling constructor with argument")
        StrategyModule("Test")
    except TypeError as e:
        print("\tTypeError raised: %s" % (str(e)))
    except Exception as e:
        print("\tException raised: %s" % (str(e)))
    else:
        print("\tNo exception raised")

# Unit tests to test debugger_active variable.

# Generated at 2022-06-23 12:51:52.141132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    test_strategy_module = StrategyModule(test_tqm)
    assert test_strategy_module.debugger_active == True

# UNIT TEST FOR execute_chunk

# Generated at 2022-06-23 12:52:02.661859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    test_playbook = Playbook.load('./test_strategy_debug.yml', variable_manager='', loader='', options='', passwords='')
    test_tqm = test_playbook.run()

    strategyModule = StrategyModule(test_tqm)

    # Assert that StrategyModule is the instance of StrategyModule
    assert StrategyModule == type(strategyModule)
    # Assert that they are the same debug session
    assert test_tqm.debugger is strategyModule.tqm.debugger
    # Assert that the debug session is active
    assert strategyModule.tqm.debugger.active



# Generated at 2022-06-23 12:52:07.558413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit test for debug.py: constructor of StrategyModule')
    print('--------------------------------------------------------------------')

    sta = StrategyModule(0)
    if '0' != sta.tqm:
      print('FAIL: Expected sta.tqm: 0')
      print('Actual sta.tqm:', sta.tqm)
      print('--------------------------------------------------------------------')
      return False

    print('PASS: sta.tqm:', sta.tqm)
    print('--------------------------------------------------------------------')
    return True


# Generated at 2022-06-23 12:52:08.130684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:10.956710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = AnsibleTaskQueueManager()
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module.tqm == task_queue_manager
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:52:12.341157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Need proper unittest
    StrategyModule(object)



# Generated at 2022-06-23 12:52:16.190808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    strategy_module = StrategyModule(tqm)
    assert strategy_module.__name__ == "ansible.plugins.strategy.debug"
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:52:17.716906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    return StrategyModule(tqm)


# Debugger class inherited from a class cmd

# Generated at 2022-06-23 12:52:20.394815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:52:24.912058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #print('test_StrategyModule')
    mock = type('Mock', (object,), {
        'tasks': [
            {'name': 'hello'},
            {'name': 'world'},
        ]
    })
    #print (mock)
    obj = StrategyModule(mock)
    #print('obj', obj)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:52:25.619259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:28.369176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == tqm



# Generated at 2022-06-23 12:52:30.595294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:52:31.130194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:52:35.195311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    import ansible.plugins.strategy.linear

    assert issubclass(ansible.plugins.strategy.debug.StrategyModule, ansible.plugins.strategy.linear.StrategyModule) == True



# Generated at 2022-06-23 12:52:36.297224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Executing test_StrategyModule')


# Generated at 2022-06-23 12:52:37.121623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
      assert False, 'test_StrategyModule is not implemented'

# Generated at 2022-06-23 12:52:47.095054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import load_options
    from ansible.executor.task_queue_manager import TaskQueueManager
    options = load_options()
    options.private_key_file = 'tests/utils/ssh_host_rsa_key'
    options.host_key_checking = False
    options.connection = 'ssh'
    options.remote_user = 'root'
    options.become_method = 'sudo'
    options.module_name = 'command'
    options.module_args = 'uptime'
    tqm = TaskQueueManager(
        inventory=options.inventory,
        variable_manager=options.variable_manager,
        loader=options.loader,
        options=options,
        passwords=options.passwords,
        stdout_callback=options.stdout_callback
    )


# Generated at 2022-06-23 12:52:57.436256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    tqm = None
    templar = Templar(loader=None, variables=VariableManager())
    task = Task()
    task._role = None
    task._block = None
    task._loader = None
    task._shared_loader_obj = None
    task.action = 'setup'
    del task.args['free_form']  # setup module

# Generated at 2022-06-23 12:53:00.791202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['test_host_1', 'test_host_2']
    inventory = MockInventory(host_list)
    tqm = MockTaskQueueManager(host_list, inventory)
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active
    strategy.run()
    assert not tqm.run_called
    strategy.cleanup()
    assert not tqm.cleanup_called


# Generated at 2022-06-23 12:53:03.085928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = []
    # Act
    strategy_module = StrategyModule(tqm)
    # Assert
    assert strategy_module.debugger_active
    assert strategy_module.tqm == tqm


# Generated at 2022-06-23 12:53:06.564382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class tqm:
        hosts = []

    s = StrategyModule(tqm)
    assert s
    assert s.tqm == tqm
    assert s.debugger_active is True



# Generated at 2022-06-23 12:53:11.171628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.is_task_skipped
    #self.debugger_active
    #self._need_to_wait_for_connect
    #self._final_q
    #self._wait_on_pending_results
    #self._wait_on_pending_lookups
    #self._pending_results
    #self._pending_lookups


# Generated at 2022-06-23 12:53:13.206775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:17.215789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    result = True
    try:
        StrategyModule(tqm)
    except:
        result = False

    assert result == True

# Test task_executor

# Generated at 2022-06-23 12:53:19.371207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 12:53:23.128463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert stm.debugger_active is True


# Generated at 2022-06-23 12:53:26.381933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert tqm is sm.tqm
    assert not sm.stop_at_task
    assert sm.debugger_active


# Generated at 2022-06-23 12:53:28.666048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In test_StrategyModule()")
    tqm = ""
    sm = StrategyModule(tqm)
    assert sm is not None
    print("End test_StrategyModule()")


# Generated at 2022-06-23 12:53:30.312657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    StrategyModule()


# Generated at 2022-06-23 12:53:31.454879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:53:34.249417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = StrategyModule(tqm)
    except Exception as e:
        assert False, "Creation of StrategyModule object failed with: %s" % e.message


# Generated at 2022-06-23 12:53:35.908621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # No test
    assert True
    return True



# Generated at 2022-06-23 12:53:38.680967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__bases__ == (LinearStrategyModule,)
    assert StrategyModule.__doc__  == None
    assert StrategyModule.__module__ == "ansible.plugins.strategy.debug"


# Generated at 2022-06-23 12:53:41.670698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize arguments
    tqm = 'hoge'
    # Instantiate instance
    debug_obj = StrategyModule(tqm)
    # Execute method
    result = debug_obj.debugger_active
    # Check the result
    assert result

# Generated at 2022-06-23 12:53:46.200069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_obj = LinearStrategyModule('tqm')
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert hasattr(StrategyModule, '__init__')
    assert hasattr(linear_obj, 'debugger_active')


# Generated at 2022-06-23 12:53:47.659823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)



# Generated at 2022-06-23 12:53:48.214169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:51.144340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:53:52.910530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategyObj = StrategyModule(None)
  assert(strategyObj.debugger_active == True)


# Generated at 2022-06-23 12:53:56.165335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize
    tqm = None

    # Code being tested
    strategy_module = StrategyModule(tqm)

    # Check
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:54:06.089169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = object()
        StrategyModule(tqm)
    except TypeError as e:
        assert False



# Generated at 2022-06-23 12:54:06.473967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:07.553868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("OK")


# Generated at 2022-06-23 12:54:11.242918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = {'_queue_items': ['dummy1','dummy2'],
           'stats': ['dummy3','dummy4']}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:54:14.372814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    debug_init = StrategyModule(tqm).debugger_active
    assert debug_init is True
    print("StrategyModule Constructor is correct")


# Generated at 2022-06-23 12:54:15.371427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:20.058025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    strategy_module = StrategyModule(tqm)

    assert strategy_module.name == "debug"
    assert strategy_module.debugger_active is True

#--------------------------------------------------------------------------------

# Generated at 2022-06-23 12:54:23.360807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create object of LinearStrategyModule
    tqm = LinearStrategyModule("tqm")
    # Create object of StrategyModule
    sm = StrategyModule("tqm")
    # Compare the value between two variables
    assert sm.debugger_active == True
    return

# Constructor of class InteractDebug

# Generated at 2022-06-23 12:54:26.314015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pp = pprint.PrettyPrinter(indent=4)
	pp.pprint("--Unit test start--")
	pp.pprint("--Unit test end--")


# Generated at 2022-06-23 12:54:28.530965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("=== test_Strategy: test_StrategyModule ===")
    pass


# Generated at 2022-06-23 12:54:29.239417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:37.218069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__doc__ == '''Executes tasks in interactive debug session.'''
    #assert StrategyModule.__init__.__dic__ is not None
    #assert StrategyModule.__init__.__dic__ == '''Task execution is 'linear' but controlled by an interactive debug session.'''
    assert StrategyModule.run.__doc__ is not None
    assert StrategyModule.run.__doc__ == '''Does nothing, only need so we can call ui.debug'''
    assert StrategyModule.get_host_groups.__doc__ is not None
    assert StrategyModule.get_host_groups.__doc__ == '''Implementation of the get_host_groups interface'''
    assert StrategyModule.add_tqm_variables.__doc__ is not None
    assert Strategy

# Generated at 2022-06-23 12:54:39.341831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = TaskQueueManager()
        linear_stategy_module = StrategyModule(tqm)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 12:54:40.482518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:42.555132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO:
    # test StrategyModule(tqm)
    # implementation here
    # return True or False
    return True



# Generated at 2022-06-23 12:54:43.747374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:54:46.168415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Test for __init__ constructor of class StrategyModule'''
    assert StrategyModule


# Generated at 2022-06-23 12:54:49.881973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        tqm = StrategyModule(tqm)
    except Exception as e:
        print(e)
        return False

    return True



# Generated at 2022-06-23 12:54:52.384806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.Mock()
    strategy = StrategyModule(tqm)
    assert tqm == strategy.tqm
    assert not strategy.nested


# Generated at 2022-06-23 12:54:54.941532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m_tqm = MagicMock()
    return StrategyModule(m_tqm)


# Generated at 2022-06-23 12:54:58.079032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=1)
    if(a.tqm == 1) & (a.debugger_active):
        print("Success")

#main function

# Generated at 2022-06-23 12:55:01.568140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule('tqm')

    assert instance.tqm is 'tqm'
    assert isinstance(instance, LinearStrategyModule)
    assert instance.debugger_active is True


# Generated at 2022-06-23 12:55:04.208530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    if StrategyModule(tqm) == 'ERROR':
        assert 0, 'TEST FAILED'
    sys.exit(1)


# Generated at 2022-06-23 12:55:05.414099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    


# Generated at 2022-06-23 12:55:06.941908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:55:16.086580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = 'strategy'
    play_context = {}
    loader = None
    templar = None
    shared_loader_obj = None
    strategy = 'debug'
    hostvars = {}
    all_vars = {}
    play = None
    options = {}
    variable_manager = None
    loader = None
    passwords = {}

    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.hosts == []
    assert strategy_module.host_index == 0
    assert strategy_module.name == 'debug'


# Generated at 2022-06-23 12:55:17.766935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger = StrategyModule(None)
    assert debugger.debugger_active == True


# Generated at 2022-06-23 12:55:19.338288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__=="ansible.plugins.strategy.debug"


# Generated at 2022-06-23 12:55:19.902653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:21.188607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    StrategyModule(tqm)


# Generated at 2022-06-23 12:55:24.101357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert isinstance(obj, StrategyModule)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:55:26.867051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:55:32.378938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class test_TQM(object):
            def __init__(self):
                    pass

        test_tqm = test_TQM()
        sm = StrategyModule(test_tqm)
    except Exception as e:
        print("strategies/debug.py constructor : %s" % e)
        raise AssertionError()
    else:
        print("strategies/debug.py constructor : ok")


# Generated at 2022-06-23 12:55:36.408804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_object = None
    strategy_module = StrategyModule(tqm_object)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:55:45.906864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('In test_StrategyModule()')
    class TestTaskQueueManager:
        def __init__(self):
            class TestHostManager:
                def __init__(self):
                    self.hosts = ['host1', 'host2']
                def get_hosts(self):
                    return self.hosts
            class TestPatternGenerator:
                def __init__(self):
                    class TestInventoryManager:
                        def __init__(self):
                            self.inventory = ['inventory1', 'inventory2']
                        def get_inventory(self):
                            return self.inventory
                    class TestVarManager:
                        def __init__(self):
                            self.vars_manager = ['vars_manager1', 'vars_manager2']

# Generated at 2022-06-23 12:55:47.779095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    #m = StrategyModule(tqm)
    assert StrategyModule.__init__({}, tqm)


# End of test_StrategyModule()



# Generated at 2022-06-23 12:55:51.342529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    module = StrategyModule(tqm)
    assert isinstance(module, LinearStrategyModule)
    assert module.debugger_active is True


# Generated at 2022-06-23 12:55:57.155171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.playbook import Playbook
    except ImportError as e:
        print("ImportError: %s" % e)
        sys.exit(1)

    pb = Playbook().load('test_playbook.yml', variable_manager={}, loader=None)
    tqm = None
    try:
        from ansible.executor.task_queue_manager import TaskQueueManager
        tqm = TaskQueueManager()
        tqm.load_callbacks = None
        tqm.tqm_send_callback = None
    except ImportError as e:
        print("ImportError: %s" % e)
        sys.exit(1)

    tqm.run(playbook=pb)

    sm = StrategyModule(tqm)
    sm.debugger_active = False

# Generated at 2022-06-23 12:55:59.751168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 12:56:01.302796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:56:11.451009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 12:56:13.234504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True

# Test output of execute()

# Generated at 2022-06-23 12:56:15.463759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    strategy = StrategyModule(test_tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:56:24.907977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # set stub
    class tqm:
        pass
    tqm.send_callback = "dummy"
    tqm.send_callback.playbook_on_start = "dummy"
    tqm.send_callback.playbook_on_stats = "dummy"
    tqm.send_callback.playbook_on_notify = "dummy"
    tqm.send_callback.playbook_on_handler_task_start = "dummy"
    tqm.send_callback.playbook_on_v2_playbook_on_start = "dummy"
    tqm.send_callback.playbook_on_v2_playbook_on_stats = "dummy"
    tqm.send_callback.playbook_on_v2_playbook_on_handler

# Generated at 2022-06-23 12:56:32.760974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeStrategyModule:
        def __init__(self, tqm):
            self.tqm = tqm
            self.debugger_active = False
    fake_tqm = object()
    strategy_module = StrategyModule(fake_tqm)
    assert strategy_module.tqm == fake_tqm
    assert strategy_module.debugger_active
    fake_strategy_module = FakeStrategyModule(fake_tqm)
    strategy_module = StrategyModule(fake_tqm)
    assert strategy_module.tqm == fake_tqm
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:56:40.415289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import tempfile
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.plugins.loader
    import ansible.plugins.strategy.linear
    import ansible.vars.manager
    import ansible.template
    import ansible.vars.hostvars

    t = tempfile.NamedTemporaryFile(mode='w+')
    t.write('foobar')
    t.flush()

    g_task = ansible.playbook.task.Task()
    g_task.action = 'copy'
    g_task.args = {'content': "foobar", 'dest': '/tmp/foobar'}


# Generated at 2022-06-23 12:56:42.599822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    __StrategyModule = StrategyModule(tqm)



# Generated at 2022-06-23 12:56:46.692679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    tqm = None
    class_init = StrategyModule(tqm)
    class_init.itervars = {}
    assert class_init.debugger_active == True



# Generated at 2022-06-23 12:56:50.868974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Make sure that the constructor of StrategyModule class works fine.
    assert('debugger_active' in vars(StrategyModule(None)))
    assert(StrategyModule(None).debugger_active == True)


# Generated at 2022-06-23 12:56:53.611124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        st = StrategyModule(None)
        assert st
        assert st.debugger_active == True
    except Exception as e:
        raise e


# Generated at 2022-06-23 12:56:57.051774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule("no_tqm")
    assert foo.tqm == "no_tqm"
    assert foo.debugger_active == True



# Generated at 2022-06-23 12:57:00.482504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'hostvars': {'host2': 'host2'}, '_variable_manager': {'_fact_cache': {'host2': {'ansible_facts': 'host2'}}}}
    assert isinstance(StrategyModule(tqm), StrategyModule)



# Generated at 2022-06-23 12:57:02.432597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active == True

# instantiate class StrategyModule
s = StrategyModule()


# Generated at 2022-06-23 12:57:03.917083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    StrategyModule(tqm)
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:57:05.688442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Module is tested in test_playbook_execution.py
    pass


# Generated at 2022-06-23 12:57:11.509548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    play_source = dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    
    tqm = None
    pm = None
    global_timeout = 1000
    workers = 5
    inventory = InventoryManager(loader=None, sources='localhost,')

    s

# Generated at 2022-06-23 12:57:16.988825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.tqm is None
    assert sm.step is None
    assert sm.step_state is None
    assert sm.host_states is None
    assert sm.iterator is None
    assert sm.debugger_active



# Generated at 2022-06-23 12:57:18.780167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj != None


# Generated at 2022-06-23 12:57:19.980397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule


# Generated at 2022-06-23 12:57:24.124378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule), "Can't construct object."
    assert isinstance(StrategyModule(None), LinearStrategyModule), "Can't inherit class."


# Generated at 2022-06-23 12:57:26.351074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'test_tqm'
    strategy_module = StrategyModule(test_tqm)




# Generated at 2022-06-23 12:57:30.058312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, 'debugger_active')
    assert strategy_module.debugger_active == True

# Generated at 2022-06-23 12:57:30.539936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:32.333392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with pass-through constructor
    Tqm = object()
    strategy_module = StrategyModule(Tqm)
    assert strategy_module.tqm == Tqm


# Generated at 2022-06-23 12:57:34.820132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 12:57:45.756367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_task = {'action': {'__ansible_module__': 'test'}}
    test_task_result = {'results_file': 'test'}
    test_tqm = {'vars': {'test': 'test'}, 'inventory': {'vars': {'test': 'test'}},
                'task_queue': {'get': lambda: (test_task, test_task_result)}}

    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.tqm == test_tqm
    assert strategy_module.tqm_vars == {'test': 'test'}
    assert strategy_module.inventory_vars == {'test': 'test'}

# Generated at 2022-06-23 12:57:46.628566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:48.758048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:57:50.553547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    mc = StrategyModule(tqm)
    assert mc != None


# Generated at 2022-06-23 12:57:54.037576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm = 0)
    a.version = 2

    assert a.debugger_active == True


# Class DebuggerApp which implements a cmd base application

# Generated at 2022-06-23 12:57:54.856798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:57:59.752680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', '-i', 'inventories/stage', 'main.yml']
    from ansible.cli import CLI
    cli = CLI(sys.argv)
    tqm = cli.base.setup()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:58:02.925659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:58:06.223556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sut = StrategyModule(tqm)


# Generated at 2022-06-23 12:58:08.314017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(isinstance(s, StrategyModule))
    return s


# Generated at 2022-06-23 12:58:10.178333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('test')
    assert isinstance(obj, StrategyModule)


# Generated at 2022-06-23 12:58:15.965064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.shlex as shlex
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play 1",
            hosts = 'web',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )


# Generated at 2022-06-23 12:58:18.071681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm.debugger_active)


# Generated at 2022-06-23 12:58:21.333743
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:58:21.968878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 12:58:29.513609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy(object):
        def __init__(self):
            self.cur_task = 1
            self.total_tasks = 5
            self.stats = dict()
    class CustomCmd(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)
            self.prompt = '(CustomCmd) '
        def do_show_tasks(self, line):
            print('Tasks are:')
            pprint.pprint(tqm.tasks)
            print('Max number of parallel processes: %s' % tqm._options.forks)
            print('Stats:')
            print(tqm.stats)
            print('Current task number: %s' % tqm.cur_task)

# Generated at 2022-06-23 12:58:30.534915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:58:39.273174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager
    from ansible.vars.manager import load_extra_vars_files
    from ansible.vars.clean import strip_internal_keys
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import is_special_var
    from ansible.cli import CLI
    import ansible.constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader

# Generated at 2022-06-23 12:58:42.392239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule('host')
    host.task_retries
    host.task_sleep_secs
    host.host_set = 'host_set'


# Generated at 2022-06-23 12:58:44.390702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1) is not None, "Creation of instance StrategyModule failed"


# Generated at 2022-06-23 12:58:48.298918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'test_tqm'
    module = StrategyModule(test_tqm)
    assert test_tqm == module._tqm
    assert module.debugger_active == True


# Generated at 2022-06-23 12:58:50.724725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = {}
    tqm = StrategyModule(args)
    assert tqm.debugger_active == True




# Generated at 2022-06-23 12:59:00.896141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = object()
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.tqm == test_tqm
    assert strategy_module.debugger_active == True


    # FIXME: Regenerate these tests via the ansible-test tool.
    # Example:
    #   ansible-test sanity --docker --python 3.5 --coverage --test strategy/debug
    #   TODO: ansible-test sanity --docker --python 3.5 --coverage --test strategy/debug --python-version 3.5
    #
    # Execute the Ansible test using this command:
    #   ansible-test units --python 3.5 --coverage --docker -v
    #
    # ansible-test units --python 3.5 --coverage --test strategy/debug --python-

# Generated at 2022-06-23 12:59:01.485582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:59:03.495845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    pass



# Generated at 2022-06-23 12:59:07.897131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1: Create instance of class StrategyModule
    test_list_1 = list(range(2))
    Test_StrategyModule_1 = StrategyModule(test_list_1)
    assert Test_StrategyModule_1.tqm == test_list_1
    assert Test_StrategyModule_1.debugger_active == True

# Generated at 2022-06-23 12:59:11.587723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule(None)) is StrategyModule


    def set_current_task(self, task):
        self.current_task = task

    def get_current_task(self):
        return self.current_task


# Generated at 2022-06-23 12:59:15.852873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    __import__('ansible.utils.display').Display = lambda *a, **kw: a[0]
    __import__('ansible.plugins.strategy.linear').CommandLine = lambda *a, **kw: a[0]
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True, 'Debugger should be active'



# Generated at 2022-06-23 12:59:17.944682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    assert dir(StrategyModule).__contains__('__init__')


# Generated at 2022-06-23 12:59:20.415573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:59:22.815596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class _tqm(object):
        pass
    tqm = _tqm()
    tqm = StrategyModule(tqm)


# Generated at 2022-06-23 12:59:24.396654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass


# Generated at 2022-06-23 12:59:29.594514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nConstructor: test_StrategyModule")
    obj = StrategyModule("tqm")
    assert obj.debugger_active == True, "debugger_active=True"

if __name__ == "__main__":
    print("EXECUTING:", sys.argv[0])
    test_StrategyModule()

# Generated at 2022-06-23 12:59:32.259421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.linear
    typecheck(ansible.plugins.strategy.linear.StrategyModule)



# Generated at 2022-06-23 12:59:32.787846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:42.192125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
 
   class  Test_Module(cmd.Cmd):
    def preloop(self):
        pprint.pprint(globals())

    def do_first(self, line):
      print(line)

    def do_second(self, line):
      print(line)

    def do_EOD(self, line):
      return True

    def emptyline(self):
      pass


# Generated at 2022-06-23 12:59:44.468376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    stm = StrategyModule(tqm)
    assert stm.debugger_active is True
    assert stm.tqm is tqm

test_StrategyModule.unittest = ['ansible.plugins.strategy_debug']



# Generated at 2022-06-23 12:59:46.571704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Entering test_StrategyModule')
    sm = StrategyModule(None)
    assert sm is not None
    assert sm.debugger_active is True
    print('test_StrategyModule passed.')



# Generated at 2022-06-23 12:59:57.506283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Cmd(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)
            self.prompt = 'debug> '
            self.real_stdout = sys.stdout
            self.stdout = sys.stdout
            self.real_stdin = sys.stdin
            sys.stdin = self
            sys.stdout = self
            self.hostname = None

        def do_hostname(self, args):
            self.hostname = args
            self.stdout = self.real_stdout

        def do_eof(self, args):
            self.stdout = self.real_stdout
            sys.stdin = self.real_stdin
            sys.stdout = self.real_stdout
            return True


# Generated at 2022-06-23 12:59:59.468321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myvar = StrategyModule(tqm)


# Generated at 2022-06-23 13:00:04.674189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock of TaskQueueManager()
    tqm_mock = mock.Mock(spec=TaskQueueManager)
    tqm_mock.stats = mock.Mock()
    # test code
    sm = StrategyModule(tqm_mock)
    # assert
    assert sm.tqm == tqm_mock


# Generated at 2022-06-23 13:00:11.509007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a TaskQueueManager object
    my_TQM = TaskQueueManager(
        host_list=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
    )

    # Create a StrategyModule object
    my_StrategyModule = StrategyModule(tqm=my_TQM)

    # Test StrategyModule is an instance of cmd.Cmd
    assert isinstance(my_StrategyModule, cmd.Cmd)

    return True

# Test get_command()

# Generated at 2022-06-23 13:00:20.488093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.debugger_active is True

#    def enter_debug(self, host, task, play_context):
#        self._tqm.send_callback('v2_playbook_on_task_start', host, task)
#        cmd = DebugPlaybookCmd(task, host, self._tqm, self._loader)
#        cmd.prompt = 'pause:%s>' % host.get_name()
#        cmd.cmdloop()
#
#    def run(self, iterator, play_context):
#        result = super(StrategyModule, self).run(iterator, play_context)
#        if self.debugger_active:
#            sys.stdout.write("\npausing for debug\n")
#            cmd = DebugPlaybookCmd(None, None

# Generated at 2022-06-23 13:00:22.300991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert type(StrategyModule) == type


# Generated at 2022-06-23 13:00:24.886527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {
      'options': {
        'debugger_enabled': True,
      }
    }
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == tqm



# Generated at 2022-06-23 13:00:31.344850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader
    import ansible.plugins.strategy
    import ansible.utils.plugin_docs
    plugin_name = 'debug'
    task_queue_manager = None
    strategy_module = ansible.plugins.loader.strategy_loader.get(plugin_name, task_queue_manager)
    assert isinstance(strategy_module, ansible.plugins.strategy.debug.StrategyModule)


# Generated at 2022-06-23 13:00:33.914227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = {}
  strategy_module = StrategyModule(tqm)
  assert strategy_module.debugger_active == True



# Generated at 2022-06-23 13:00:37.177727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n*********************\n")
    print("Unit test for constructor of class StrategyModule")
    print("\n*********************\n")
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:47.185343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.sentinel import Sentinel
    class Options:
        connection = 'local'

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=[]),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
        stdout_callback=None
    )
    assert isinstance(StrategyModule(tqm), StrategyModule)


# Generated at 2022-06-23 13:00:48.049799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:00:50.329763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    runner = StrategyModule(None)
    assert runner.debugger_active is None
    assert runner.tqm is None


# Generated at 2022-06-23 13:00:53.660247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule("tqm")
    assert isinstance(instance, StrategyModule)
    assert isinstance(instance, LinearStrategyModule)
    assert instance.debugger_active == True


# Generated at 2022-06-23 13:00:55.573632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)
    assert st.debugger_active == True

StrategyModule.Host = None



# Generated at 2022-06-23 13:00:57.101419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Custom commands for strategy module

# Generated at 2022-06-23 13:01:00.293522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy = StrategyModule(tqm)
    assert strategy
    strategy.debugger_active = False
# Unit test ends


# Generated at 2022-06-23 13:01:04.226515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test constructor of class StrategyModule
    """
    try:
        strategy = StrategyModule(tqm)
    except Exception as e:
        return str(e)

# Testcase for Tasks
# Testcase : Test Run

# Generated at 2022-06-23 13:01:06.959276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule(tqm = 'test')
    assert test_strategy.debugger_active == True


# Generated at 2022-06-23 13:01:10.800105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule(None)

    assert isinstance(test_instance, LinearStrategyModule)
    assert test_instance.debugger_active


# Generated at 2022-06-23 13:01:12.561348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert not s.debugger_active


# Generated at 2022-06-23 13:01:14.597905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == __doc__
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:01:15.514210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 13:01:17.414695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule) and hasattr(StrategyModule, '__init__')



# Generated at 2022-06-23 13:01:18.527081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')



# Generated at 2022-06-23 13:01:28.611306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    output = StrategyModule(0)

    assert(type(output) is StrategyModule)


# Override play() function of parent class
    def run(self, iterator, play_context):
        hosts = []
        failed_hosts = []
        unreachable_hosts = []
        skipped_hosts = {}

        all_vars = dict()

# Generated at 2022-06-23 13:01:29.459473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:01:31.272846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModul(tqm)

# Generated at 2022-06-23 13:01:34.159330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active

# Unit tests for function _run_tasks

# Generated at 2022-06-23 13:01:35.085897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # TODO


# Generated at 2022-06-23 13:01:36.160619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:01:39.449863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None
    var = StrategyModule(tqm)

    assert var.debugger_active == True


# Generated at 2022-06-23 13:01:40.802426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = None
   t = StrategyModule(tqm)
