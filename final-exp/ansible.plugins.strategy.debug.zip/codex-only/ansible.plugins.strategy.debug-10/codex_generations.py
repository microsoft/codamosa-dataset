

# Generated at 2022-06-23 12:51:43.293435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        def __init__(self):
            self.hostvars = {}
    tqm_obj = TestTaskQueueManager()
    sm_obj = StrategyModule(tqm_obj)
    assert sm_obj.debugger_active == True


# Generated at 2022-06-23 12:51:44.431881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 12:51:47.990561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    test_tqm = StrategyModule(tqm)
    assert test_tqm.tqm == tqm
    assert test_tqm.debugger_active == True


# Generated at 2022-06-23 12:51:57.900596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # To test strategy plugin, needs to initiate an environment of Ansible
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import fragment_loader, action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # initiate necessary objects
    loader = DataLoader()
    play_context = PlayContext()
    play_context.prompt = dict()

    # Define a fake host
    host = dict()
    host['name']

# Generated at 2022-06-23 12:51:58.786815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active == True



# Generated at 2022-06-23 12:52:08.904878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestPluginOptions(object):
        def __init__(self):
            self.tags = []
            self.skip_tags = []
            self.one_line = False
            self.tree = None
            self.verbosity = 2
            self.ask_pass = False
            self.private_key_file = None
            self.listhosts = False
            self.subset = None
            self.su = None
            self.su_user = None
            self.su_pass = None
            self.vault_password_file = None
            self.forks = 5
            self.module_path = None
            self.remote_user = None
            self.connection = 'smart'
            self.timeout = 10
            self.ssh_common_args = None
            self.ssh_extra_args = None

# Generated at 2022-06-23 12:52:11.185423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:52:13.498643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:52:16.781489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True

# Global variable for the test in debug_command_step
tqm = ''

# Generated at 2022-06-23 12:52:18.539455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("debugger_active: " + str(StrategyModule.debugger_active))


# Generated at 2022-06-23 12:52:19.605525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()


# Generated at 2022-06-23 12:52:21.812383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call the constructor of class StrategyModule
    strategy_module = StrategyModule(tqm = None)

    assert strategy_module


# Generated at 2022-06-23 12:52:24.462593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global test_class2
    test_class2 = StrategyModule(None)
    assert test_class2.debugger_active == True

# Unit tests for function play_async()
if __name__ == '__main__':
    test_StrategyModule()

##############

# Generated at 2022-06-23 12:52:27.303482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    >>> import ansible.plugins.strategy.debug as debug_plugin
    >>> tqm = None # TODO
    >>> sm = debug_plugin.StrategyModule(tqm)
    '''


# Generated at 2022-06-23 12:52:28.827942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active is True


# Generated at 2022-06-23 12:52:30.654977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-23 12:52:33.407206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule('tqm')
    assert test_StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:52:35.088258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == '__init__() takes 1 positional argument but 2 were given' in str(Context())



# Generated at 2022-06-23 12:52:41.823617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = variable_manager.loader
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['testhost'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello world!')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 12:52:46.479231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    tqm = TaskQueueManager()
    tqm.__init__()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.get_host_list() == []
    assert strategy_module.run() == True # XXX: return value not implemented


# Generated at 2022-06-23 12:52:49.005024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:52:50.038503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)



# Generated at 2022-06-23 12:52:52.872035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    test = StrategyModule(None)
    assert test is not None
    assert test.debugger_active is True

# Generated at 2022-06-23 12:52:53.656381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:53:01.425245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import strategy

    class Test_StrategyModule(unittest.TestCase):
        def test_init(self):
            tqm = mock.MagicMock(spec=TaskQueueManager)
            strategy_module = strategy.load_strategy_module('debug')
            instance = strategy_module(tqm)
            self.assertIsInstance(instance, StrategyModule)

    suite = unittest.TestLoader().loadTestsFromTestCase(Test_StrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-23 12:53:11.076881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Initialization of task queue manager
        from ansible.executor.task_queue_manager import TaskQueueManager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader

        loader = DataLoader()
        inventory = InventoryManager(loader, None, None)
        tqm = TaskQueueManager(
            inventory=inventory,
            variable_manager=None,
            loader=loader,
            passwords=None,
            stdout_callback='default'
        )
    except:
        print("\nFailed to initialize task queue manager")
        sys.exit(1)

    # Testing first argument
    tmp_strategy_module = StrategyModule("bad_tqm")

# Generated at 2022-06-23 12:53:13.934963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__doc__ == """Task execution is 'linear' but controlled by an interactive debug session.""")
    assert(StrategyModule.__init__.__doc__ == """Unit test for constructor of class StrategyModule""")


# Generated at 2022-06-23 12:53:15.577229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-23 12:53:19.909017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        sm = StrategyModule()
        assert sm
    except Exception as err:
        # failure
        print("test_LinearStrategyModule failed: "+(str(err)))
        raise
    else:
        # success, no exception
        pass
    finally:
        # cleanup code  
        pass

# Generated at 2022-06-23 12:53:22.401348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 12:53:23.877718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        a = StrategyModule(None)
        assert True
    except:
        assert False


# Generated at 2022-06-23 12:53:25.889433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert hasattr(strategy, "debugger_active")



# Generated at 2022-06-23 12:53:29.622750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert hasattr(s, 'debugger_active')
    assert s.debugger_active is True


# Generated at 2022-06-23 12:53:34.442547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    if (
        not isinstance(strategy_module, StrategyModule) or
        not strategy_module.debugger_active
    ):
        raise RuntimeError("constructor of class StrategyModule has error")


# Command Processor Class

# Generated at 2022-06-23 12:53:36.695747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('tqm')
    assert test.debugger_active == True
# End of unit test for constructor of class StrategyModule


# Generated at 2022-06-23 12:53:39.285371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("===== test_StrategyModule =====")

    print("Nothing to be tested because functions in 'class StrategyModule' are only inherited")


# Generated at 2022-06-23 12:53:41.302327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: need to make a test.
    assert False


# Generated at 2022-06-23 12:53:46.764223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    from ansible.runner.return_data import ReturnData
    from ansible.utils import template

    task = mock_Task()
    tqm = mock_TaskQueueManager(task)

    s = StrategyModule(tqm)

    assert not hasattr(s, 'devnull')
    assert s.host_states
    assert not s.host_states['localhost']

    assert s.get_host_state('localhost') is s.host_states['localhost']


# Generated at 2022-06-23 12:53:48.521580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:53:52.691102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as debug_module
    tqm = None
    try:
        debug_module.StrategyModule(tqm)
        assert True
    except:
        assert False


# Generated at 2022-06-23 12:53:54.490493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dbg = StrategyModule(None)
    assert dbg.debugger_active is True



# Generated at 2022-06-23 12:53:56.508307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # making sure that the constructor of StrategyModule does not give error
    # for now, that's enough.
    st = StrategyModule('1')


# Generated at 2022-06-23 12:53:59.073457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active


C = ' '*4

# Generated at 2022-06-23 12:54:02.774935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule(tqm)
    assert S.debugger_active is True
    assert S.tqm is tqm
    assert S.tqm._final_q.is_empty() is True


# custom class that interacts with user based on the prompt

# Generated at 2022-06-23 12:54:04.984719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  #print(StrategyModule)
  print('Tests for StrategyModule passed!')


# Generated at 2022-06-23 12:54:06.353646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__



# Generated at 2022-06-23 12:54:07.802732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == "Executes tasks in interactive debug session."



# Generated at 2022-06-23 12:54:09.592391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    debugger_active = True
    debugger_active = False


# Generated at 2022-06-23 12:54:10.829307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)



# Generated at 2022-06-23 12:54:14.937555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    sm = StrategyModule(tqm)
    assert_true('tqm' in dir(sm))
    assert sm.tqm is tqm
    assert_true('debugger_active' in dir(sm))
    assert sm.debugger_active


# Generated at 2022-06-23 12:54:17.901988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("#### test_StrategyModule ####")
    # Test constructor exists, no exception
    StrategyModule(None)

# Generated at 2022-06-23 12:54:19.127111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Unittest
    pass


# Generated at 2022-06-23 12:54:22.376306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategyModuleTest = StrategyModule(tqm)
    assert strategyModuleTest.tqm == 'tqm'
    assert strategyModuleTest.debugger_active is True



# Generated at 2022-06-23 12:54:25.133956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', '--strategy', 'debug']
    tqm = strategy.init()


# Generated at 2022-06-23 12:54:31.784375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.plugins.strategy import debug
    st = debug.StrategyModule(task_queue_manager.TaskQueueManager(inventory=None))
    print("st = %s" % st)
    print("st = %s" % dir(st))
    assert hasattr(st, "debugger_active")
    assert st.debugger_active

#####


# Generated at 2022-06-23 12:54:34.100754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        sm = StrategyModule(None)
        assert sm.debugger_active == True
    except Exception as e:
        print(e)


# Generated at 2022-06-23 12:54:39.490691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.linear
    except:
        assert False, "Failed to import ansible.plugins.strategy.linear"
    assert callable(ansible.plugins.strategy.linear.StrategyModule), "Import was successful but constructor isn't callable"
    return

# Generated at 2022-06-23 12:54:41.441955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(task_queue_manager=None)
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:54:43.413971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_strategy_module = StrategyModule
  assert test_strategy_module.debugger_active == True

# Generated at 2022-06-23 12:54:47.487873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("# Unit test for StrategyModule")
    tqm = Debugger(None)
    sm = StrategyModule(tqm)
    assert sm.name == 'debug'


# Generated at 2022-06-23 12:54:48.689780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")


# Generated at 2022-06-23 12:54:51.509747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # test for data type of tqm
  assert type({}) == type(tqm)
  # test for data type of debugger_active
  assert type(bool) == type(debugger_active)


# Generated at 2022-06-23 12:54:56.586473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # FIXME: can't figure out how to create a TaskQueueManager here
    # tqm = None
    # sm = StrategyModule(tqm)
    # assert sm.tqm == tqm
    # assert sm.debugger_active
#     assert False, "fixme"


# Generated at 2022-06-23 12:54:57.416562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:01.308573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.linear'
    assert StrategyModule.__bases__ == (LinearStrategyModule,)

    

# Generated at 2022-06-23 12:55:03.252979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Call StrategyModule constructor')
    execute_task = StrategyModule(tqm=None)
    assert execute_task.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:55:04.680330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Give fake input value
    strategyModule = StrategyModule(None)
    # TODO: Verify output value
    assert strategyModule


# Generated at 2022-06-23 12:55:13.421591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm is an object, referenced from ansible.plugins.strategy.linear.StrategyModule
    tqm = 'test_tqm'

    # Execute __init__ of StrategyModule
    strategy_module = StrategyModule(tqm)

    # Check attributes of strategy_module
    assert strategy_module.tqm == 'test_tqm'
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:55:23.902523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Host():
        def __init__(self, name):
            self.name = name

#    class TaskIterator():
#        def __init__(self, play, play_context, host_list):
#            self.play = play
#            self.play_context = play_context
#            self.host_list = host_list

#    class PlayContext():
#        def __init__(self):
#            self.connection = 'local'
#            self.port = 22
#            self.remote_user = 'root'
#            self.become = False
#            self.become_method = 'sudo'
#            self.become_user = 'root'
#            self.become_pass = None
#            self.environment = None
#            self.only_tags = None
#            self.

# Generated at 2022-06-23 12:55:28.106623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from unittest.mock import MagicMock

        tqm = MagicMock()
        assert StrategyModule(tqm)
    except ImportError:
        from mock import MagicMock
        tqm = MagicMock()
        assert StrategyModule(tqm)


# Generated at 2022-06-23 12:55:29.029012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass





# Generated at 2022-06-23 12:55:29.610954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:55:32.652580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = True
    # Check if variable 'debugger_active' is True
    try:
        module = StrategyModule()
        result = module.debugger_active
    except:
        result = False
    assert result


# Generated at 2022-06-23 12:55:37.540492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MyTQM(): pass
    tqm = MyTQM()
    sm = StrategyModule(tqm)

    assert hasattr(sm, 'debugger_active')
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:55:39.316147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule('a')
    except Exception as e:
        print(e)


# Generated at 2022-06-23 12:55:42.161729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(2)
    if sm.debugger_active == True:
        print('OK')
    else:
        print('NG')



# Generated at 2022-06-23 12:55:53.402009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile


# Generated at 2022-06-23 12:56:02.310831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        @property
        def inventory(self):
            return 'inventory'

        @property
        def hosts(self):
            return 'hosts'

        @property
        def callback(self):
            return 'callback'

        def __init__(self, *args, **kwargs):
            return

    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm.inventory == 'inventory'
    assert sm.hosts == 'hosts'
    assert sm.callback == 'callback'
    assert sm.run_once == False



# Generated at 2022-06-23 12:56:03.073168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cmd.Cmd.test_StrategyModule()

# Generated at 2022-06-23 12:56:08.444669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy object
    strategy_obj = StrategyModule(tqm=None)
    # Compare actual and expected results
    assert strategy_obj.debugger_active == True,\
           "Test_StrategyModule_debugger_active"

    assert isinstance(strategy_obj, LinearStrategyModule),\
           "Test_StrategyModule_inheritance"


# Generated at 2022-06-23 12:56:10.596969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    exit_code = 1
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:56:14.860789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # Look at the code below and determine the following:
    # 1. How many lines of code are in this function?
    # 2. Can we get it to one line?

    # def test_StrategyModule():
    #     pass

    # 3. How many lines of code are in this function?
    # 4. Can we get it to zero lines?


# Generated at 2022-06-23 12:56:15.792904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:56:16.845336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

__all__ = ['StrategyModule']

# Generated at 2022-06-23 12:56:23.198228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TQM:
        def __init__(self):
            self.terminated = False
            self.done = False
            self.failed_hosts = {}
            self.stats = {}
            self.succeeded_hosts = {}
            self.unreachable_hosts = {}

    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.host_states == {}
    assert sm.iterator is None
    assert sm.loop is None
    assert sm.threads is None


# Generated at 2022-06-23 12:56:26.521331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def fake_super_init(self, tqm):
        self.tqm = tqm
    setattr(StrategyModule, '__init__', fake_super_init)
    StrategyModule(tqm=None)



# Generated at 2022-06-23 12:56:28.204127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ != None


# Generated at 2022-06-23 12:56:29.546264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule('tqm'), StrategyModule)


# Generated at 2022-06-23 12:56:31.330930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test case for constructor of StrategyModule
    '''
    pass


# Generated at 2022-06-23 12:56:33.541885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing the constructor of class StrategyModule")
    # testing the constructor of the StrategyModule
    assert 'StrategyModule'
    
    

# Generated at 2022-06-23 12:56:34.163052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return


# Generated at 2022-06-23 12:56:34.792447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:56:35.433045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:38.836405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    test_module = StrategyModule(tqm)
    assert test_module.debugger_active == True



# Generated at 2022-06-23 12:56:48.291931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self, host_list):
            self.host_list = host_list

        def get_host_list(self):
            return self.host_list

    class TestHost:
        def __init__(self, name, task_list):
            self.name = name
            self.task_list = task_list

        def get_name(self):
            return self.name

        def get_tasks(self):
            return self.task_list

    class TestTask:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

        def get_action(self):
            return self.name


# Generated at 2022-06-23 12:56:51.723270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('=== test_StrategyModule()')
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:56:52.723049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 12:56:55.550149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_strategy_module = StrategyModule(None)
    assert debug_strategy_module.debugger_active == True


# Generated at 2022-06-23 12:56:56.499068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:57:02.214162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = 'TASK_QUEUE_MANAGER'
    strategy = StrategyModule(TASK_QUEUE_MANAGER)

    assert strategy.tqm == TASK_QUEUE_MANAGER
    assert strategy.debugger_active

# Main part of the execution body.

# Generated at 2022-06-23 12:57:07.225436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # instance to test
    tqm = None
    instance = StrategyModule(tqm)
    # assert that results of constructor are correct
    assert instance.tqm == tqm
    assert instance.tqm == tqm
    assert instance.strategy == 'debug'
    assert not instance.use_loop


# Generated at 2022-06-23 12:57:08.276821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)





# Generated at 2022-06-23 12:57:09.996026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = "")
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:57:11.722264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.name == 'debug'
    assert s.debugger_active


# Generated at 2022-06-23 12:57:19.704612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule.__doc__ is not None
    except Exception as e:
        print(e)
        assert False
    try:
        assert StrategyModule.__init__.__doc__ is not None
    except Exception as e:
        print(e)
        assert False
    try:
        assert StrategyModule.run.__doc__ is not None
    except Exception as e:
        print(e)
        assert False
    try:
        assert StrategyModule.debugger_active is not None
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-23 12:57:24.631953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            self.host_list = []
            self.result_callback = ""

    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm is not None


# Generated at 2022-06-23 12:57:31.479765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    assert hasattr(StrategyModule, 'run')
    assert callable(StrategyModule.run)
    # test constructor
    strategy = StrategyModule(None)
    assert hasattr(strategy, 'debugger_active')
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:57:36.351141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    assert issubclass(StrategyModule.__bases__[0], LinearStrategyModule)
    assert getattr(StrategyModule, '__init__')
    assert getattr(StrategyModule, 'run')
    assert getattr(StrategyModule, 'debugger_active')
    assert isinstance(StrategyModule.debugger_active, property)

# Test the debugger_active function

# Generated at 2022-06-23 12:57:39.674221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        pass
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:57:40.321259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 12:57:44.468778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    except ImportError:
        return "Traceback (most recent call last):"


# Generated at 2022-06-23 12:57:47.750571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(None)
    assert tqm is not None
    assert tqm.get_name() == 'debug'


# Generated at 2022-06-23 12:57:48.810670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule")
    return True



# Generated at 2022-06-23 12:57:57.154689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a debugger
    class DummyTQM(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)
            self.hostnames = ['hostname1', 'hostname2']
            self.vars = {}
    class DummyRunner:
        def __init__(self, hosts, tqm):
            self.hosts = hosts
            self.tqm = tqm
    class DummyPlay:
        def __init__(self, runner):
            self.runner = runner
            self.hosts = []
        def get_strategy(self):
            return {'name': 'debug'}
    class DummyHost:
        def __init__(self, hostname):
            self.name = hostname

# Generated at 2022-06-23 12:57:59.112232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule.run.im_self.tqm
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:07.284851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Arrange
    tqm = MagicMock()
    linear_strategy_module = StrategyModule(tqm)

    # Act

    # Assert
    assert linear_strategy_module.debugger_active


# class Debugger(cmd.Cmd):
#     pass

# def main():

#     debugger = Debugger()

#     debugger.cmdloop()


# if __name__ == '__main__':
#     main()

# Generated at 2022-06-23 12:58:12.913104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock

    # TaskQueueManager class is not defined in file __init__.py,
    # so it is not imported.
    # However, unittest.mock can deal with it by using spec parameter.
    # Therefore, the test does not fail as a result.
    tqm = mock.MagicMock(spec=['shared_loader_obj'])

    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)


# Generated at 2022-06-23 12:58:14.846529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    return StrategyModule(tqm)



# Generated at 2022-06-23 12:58:15.593358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:58:19.344238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module = StrategyModule()
    except Exception as e:
        print(e)


# Extend the command line interface of the debugger with an extra command

# Generated at 2022-06-23 12:58:26.647254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    mock_tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=True,
        run_tree=True,
    )
    sm = StrategyModule(mock_tqm)
    assert sm.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:58:28.345589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # To-do
    return


# Generated at 2022-06-23 12:58:31.586025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.linear import StrategyModule
    except ImportError:
        pass

    assert isinstance(StrategyModule, object)


# Generated at 2022-06-23 12:58:33.386393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testvar = StrategyModule("test")
    assert isinstance(testvar,StrategyModule)
    assert isinstance(testvar._tqm,str)

# Generated at 2022-06-23 12:58:35.227175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm is not None
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:37.474575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

main = sys.modules['__main__']
try:
    __import__('termcolor')
    color = True
except ImportError:
    color = False


# Generated at 2022-06-23 12:58:40.858240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'debug' in sys.modules
    assert callable(sys.modules['debug'])
    assert StrategyModule(None)
    assert isinstance(StrategyModule(None), LinearStrategyModule)


# Generated at 2022-06-23 12:58:45.549825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    obj = StrategyModule(tqm)
    assert obj.tqm == tqm
    assert obj.current_task == None
    assert obj.num_tasks == 0
    assert obj.host_pinned == False
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:58:48.135702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:58:51.618596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t=S

    # t.assertEqual(strategy_module.__dict__,
    #               {'debugger_active': True,
    #                'tqm':
    #
    #                })


# Generated at 2022-06-23 12:59:01.436624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.tqm
    import ansible.playbook
    import ansible.playbook.play
    import ansible.inventory


# Generated at 2022-06-23 12:59:03.955079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger = StrategyModule(None)
    assert debugger.debugger_active == True


# Generated at 2022-06-23 12:59:05.676039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-23 12:59:08.694071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s.debugger_active

# Test for assigning attributes correctly in constructor of class StrategyModule

# Generated at 2022-06-23 12:59:09.291345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:59:18.237490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook

    playbook = PlayBook()

    # .count() cannot be used to get the total number of tasks in the list because
    # of the particular way that Ansible works. It's necessary to use len().
    tasks = [1, 2, 3, 4, 5]
    assert len(tasks) == 5

    # The total number of tasks is 9, not 8.
    tasks = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    assert len(tasks) == 9

    # The number of tasks is the same when using a PlayBook object.
    # The number of tasks is 9, not 8.
    tasks = PlayBook()
    assert len(tasks) == 9

    # The total number of tasks is 9, not 8.
    tasks = playbook.tasks
   

# Generated at 2022-06-23 12:59:21.276788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:59:21.851274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:59:22.599746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:27.052638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm != None
    assert isinstance(sm, LinearStrategyModule)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:59:28.013728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()


# Generated at 2022-06-23 12:59:30.822268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This fixture is needed to construct class StrategyModule
    tqm = True
    t = StrategyModule(tqm)
    assert t.debugger_active == True



# Generated at 2022-06-23 12:59:31.522737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:32.791032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    StrategyModule(tqm)


# Generated at 2022-06-23 12:59:34.402321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:59:44.820398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule('tqm')
    assert p.debugger_active is True
    # assert p.display is True
    # assert p.host_hash_filename is None
    # assert p.inventory is None
    # assert p.inventory_basedirs == []
    # assert p.host_records == {}
    # assert p.host_queue == []
    # assert p.job_result is None
    # assert p.notified_handlers == {}
    # assert p.notified_event_handlers == {}
    # assert p.playbook is None
    # assert p.play_basedirs == {}
    # assert p.run_handlers == False
    # assert p.stats == {}
    # assert p.task_pushed_count == 0
    # assert p.task_uuids == []
    # assert

# Generated at 2022-06-23 12:59:51.889378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from collections import namedtuple
    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts',
                                     'syntax', 'connection','module_path',
                                     'forks', 'remote_user',
                                     'private_key_file', 'ssh_common_args',
                                     'ssh_extra_args', 'sftp_extra_args',
                                     'scp_extra_args', 'become',
                                     'become_method', 'become_user',
                                     'verbosity', 'check', 'extra_vars'])

# Generated at 2022-06-23 12:59:53.949515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    assert (StrategyModule(tqm) != None)


# Generated at 2022-06-23 12:59:55.272759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:59:56.471926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    assert debugger_active == getattr(StrategyModule, 'debugger_active')



# Generated at 2022-06-23 12:59:58.143335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = None
    StrategyModule(TQM)
    
    

# Generated at 2022-06-23 13:00:08.052904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='')
    variable_manager.set_inventory(inventory)
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=None,
    )
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm, 'StrategyModule.__init__(tqm) ... tqm should be set as attribute'

# Generated at 2022-06-23 13:00:09.588096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

    #initalize class with tqm
    instance = StrategyModule(tqm)

# Generated at 2022-06-23 13:00:12.678977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    sm = StrategyModule(tqm)
    print('StrategyModule initialized with debugger_active =', sm.debugger_active)

test_StrategyModule()


# Generated at 2022-06-23 13:00:15.031300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is True


# Generated at 2022-06-23 13:00:24.796817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    host_list = Inventory('')
    variable_manager = VariableManager()
    loader = variable_manager._loader

# Generated at 2022-06-23 13:00:25.260646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# Generated at 2022-06-23 13:00:28.355349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm, StrategyModule)
    assert sm.debugger_active


# debug module

# Generated at 2022-06-23 13:00:36.745398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class AnsibleTQM():
        timeout = 1
        def __init__(self):
            self.hostvars = []
            self.inventory = []
            self.extra_vars = {}
        def filter_targets(self, k):
            return k
        def get_vars(self, k):
            return {}
        def get_inventory(self):
            return {}
        def get_variable_manager(self):
            return {}
    tqm = AnsibleTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True

# Generated at 2022-06-23 13:00:38.873656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TBD: Use Mock to simulate tqm and run test
    assert True == True

# For test purpose

# Generated at 2022-06-23 13:00:40.550968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    StrategyModule(tqm)


# Generated at 2022-06-23 13:00:42.979490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test StrategyModule constructor
    """
    tqm = None
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-23 13:00:44.099784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)



# Generated at 2022-06-23 13:00:44.751570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:00:45.852483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-23 13:00:53.755875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def show_custom_vars(self, host):
            return host.get_name(), host.vars

    module = TestStrategyModule(None)

    assert isinstance(module.host_list, list)
    assert isinstance(module.failed_hosts, dict)
    assert isinstance(module.stats, dict)
    assert isinstance(module.get_host_list(), list)
    assert isinstance(module.get_failed_hosts(), dict)
    assert isinstance(module.get_stats(), dict)

# Generated at 2022-06-23 13:00:55.376649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #tqm =  # TODO: let's fill this
    StrategyModule(tqm)


# Generated at 2022-06-23 13:01:01.854276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.task_include
    import ansible.playbook.handler
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.inventory.host

    task_ds = dict(
        action=dict(module='shell', args='touch /tmp/hello.world'),
        name='create hello.world task', 
    )

    play_ds = dict(
        name='create hello.world task',
        hosts='all',
        gather_facts='no',
        tasks=[task_ds]
    )


# Generated at 2022-06-23 13:01:11.739813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    block = Block()
    block.append(Task())

    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

    strategy_module = StrategyModule(task_queue_manager)
    strategy_module.run(
        task=block,
        play_context=PlayContext(),
        variable_manager=None,
        loader=None,
    )

    assert not strategy_module.debugger_active



# Generated at 2022-06-23 13:01:19.384068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    sm = StrategyModule(tqm) 
    #Test if variables are correctly initialized
    assert sm.tqm == tqm 
    assert sm.tqm_variable_manager == None
    assert sm.inventory == None
    assert sm.loader == None
    assert sm.fail_list == []
    assert sm.success_list == []
    assert sm.unreachable_list == []
    assert sm.run_once == False
    assert sm.callback_plugins == []
    assert sm.display == None
    assert sm.results_callback == None
    assert sm.options == None
    assert sm.get_options == None
    assert sm.variable_manager == None
    assert sm.loader == None
    assert sm.inventory == None
    assert sm.passwords == None
    assert sm.std

# Generated at 2022-06-23 13:01:22.433659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.serial == 0
    assert sm.display.verbosity == 2
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:01:31.959415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test-case-1
    host_names = ['test1','test2','test3']
    options = {'module_name':'ping','module_path':'/usr/lib/python2.7/dist-packages/ansible/modules/system/ping.py'}
    host_name = 'test1'
    tqm_instance = [host_name]
    sm = StrategyModule(tqm_instance)
    assert isinstance(sm,StrategyModule)
    assert sm.host_names == host_names
    assert sm.host_name == host_name
    assert sm.options == options
    pprint.pprint(str(sm))
    print()
    print()
    print()


# unit tests for StrategyModule run method

# Generated at 2022-06-23 13:01:33.949180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-23 13:01:35.386855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy = LinearStrategyModule()
    assert linear_strategy is not None


# Generated at 2022-06-23 13:01:45.824546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.executor.play_iterator import PlayIterator

    tqm_test = TaskQueueManager