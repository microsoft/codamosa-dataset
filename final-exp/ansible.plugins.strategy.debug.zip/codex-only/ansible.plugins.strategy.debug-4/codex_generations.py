

# Generated at 2022-06-23 12:51:41.978620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:51:52.850703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.template
    import ansible.utils
    import ansible.vars

    # Constructor test
    pb = ansible.playbook.Playbook.load('test.yml', variable_manager=ansible.vars.VariableManager(), loader=ansible.vars.DataLoader())
    play = ansible.playbook.play.Play().load(pb.data[0], pb.loader)

# Generated at 2022-06-23 12:52:00.007285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        inventory = None
        variable_manager = None
        loader = None
        options = None
        passwords = None
        stdout_callback = None
        run_additional_callbacks = False
        callback_plugins = []
        stats = None
        failed_hosts = dict()
        succeeded_hosts = dict()
        skipped_hosts = dict()

    tqm = TestTQM()
    strategy = StrategyModule(tqm)
    assert strategy.tqm is tqm

    pp = pprint.PrettyPrinter(indent=2, compact=True)
    pp.pprint(strategy.__dict__)



# Generated at 2022-06-23 12:52:04.382730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTqm()
    stmod = StrategyModule(tqm)

    assert(tqm == stmod.tqm)
    assert(stmod.debugger_active)


# Implicitly test all methods by running the strategy.

# Generated at 2022-06-23 12:52:07.466871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    mod = StrategyModule
    assert mod.__mro__ == (mod, object)
    assert hasattr(mod, '__init__')
    assert callable(mod.__init__)



# Generated at 2022-06-23 12:52:08.346624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 12:52:12.373839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module != None
    assert strategy_module.debugger_active == True
# End of test_StrategyModule



# Generated at 2022-06-23 12:52:13.028481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:14.794438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:52:18.308512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert strategy.debugger_active
    assert strategy._tqm == None
    assert strategy._workers_pool == None


# Generated at 2022-06-23 12:52:22.102057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.loader = None
            self.inventory = None
    strategy_module = StrategyModule(TestTqm())
    assert strategy_module.debugger_active


# Executes task list with an interactive debug session

# Generated at 2022-06-23 12:52:24.412897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testobj = StrategyModule('Test')
    assert testobj.debugger_active == True


# Generated at 2022-06-23 12:52:27.265883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        pass
    tqm = TestTaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active


# Generated at 2022-06-23 12:52:31.366890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("test_StrategyModule")
  tqm = TQM()
  strategy_module = StrategyModule(tqm)
  if not isinstance(strategy_module,LinearStrategyModule):
    print("Error in StrategyModule constructor")
    sys.exit(1)
  return



# Generated at 2022-06-23 12:52:33.465343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:52:34.541759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-23 12:52:39.949868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class testTqm():
        def __init__(self):
            self.loader = None
            self.shared_loader_obj = None
            self.inventory = None
            self.variable_manager = None
            self.passwords = None
            self.stdout_callback = None
            self.notified_handlers = []
            self.stats = None
            self.options = None
            self.defaults = None
    tqm = testTqm()
    strategy = StrategyModule(tqm)
    return strategy



# Generated at 2022-06-23 12:52:44.120308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert not sm.hosts_remaining
    assert sm.debugger_active


# Generated at 2022-06-23 12:52:47.232664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type(object)


# Test case for StrategyModule.__init__()
# 1. No error occurs

# Generated at 2022-06-23 12:52:51.634595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    tqm['shared_loader_obj'] = 12
    obj = StrategyModule(tqm)
    assert(obj.tqm == tqm)
    assert(obj.debugger_active == True)
    assert(obj.loader == 12)



# Generated at 2022-06-23 12:52:52.890044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:52:58.182456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test1(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self.debugger_active = True
    t1 = Test1(1)
    assert isinstance(t1, StrategyModule)
    assert t1.tqm == 1
    assert t1.debugger_active == True



# Generated at 2022-06-23 12:53:02.378321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm
    assert strategy_module._final_q is None
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:05.082859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        pass
    sm = StrategyModule(FakeTQM())
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:53:07.923400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:53:11.024783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True
                                                                                                                                                                                    

# Generated at 2022-06-23 12:53:13.621531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule(None)
    assert test_strategy_module.debugger_active is True, 'constructor of StrategyModule does not set debugger_active to True'




# Generated at 2022-06-23 12:53:19.167968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO : invalid parameter
    task_queue_manager = None
    strategy_module = StrategyModule(task_queue_manager)
    assert type(strategy_module) == StrategyModule
    assert strategy_module.debugger_active == True


    # TODO : valid parameter
    # TODO : assert values


# Generated at 2022-06-23 12:53:24.279250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == type(StrategyModule)
    assert LinearStrategyModule == type(StrategyModule.__bases__[0])
    assert cmd.Cmd == type(StrategyModule.__bases__[0].__bases__[0])


# Generated at 2022-06-23 12:53:27.466535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print('Testing constructor StrategyModule')
  sm = StrategyModule()
  assert sm.debugger_active is True


# Generated at 2022-06-23 12:53:37.081354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info[0] == 2:
        import __builtin__
    else:
        import builtins
    assert 'StrategyModule' in dir(builtins)

StrategyModule.test = test_StrategyModule


# Generated at 2022-06-23 12:53:40.400263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    check_strategy_module = StrategyModule(tqm)
    assert check_strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:42.087941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:42.822144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:47.788999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager():
        def __init__(self):
            self.stats = dict()
            self.hostvars = dict()
            self.module_vars = dict()
            self.task_vars = dict()

    tqm = TaskQueueManager()
    strategy = StrategyModule(tqm)
    assert (strategy.debugger_active == True)


# Generated at 2022-06-23 12:53:49.571081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active is True


# Generated at 2022-06-23 12:53:51.301979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-23 12:53:53.047313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Really need some work in this area....


# Generated at 2022-06-23 12:53:53.997759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:53:56.124196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    result = StrategyModule(tqm)
    assert result.debugger_active


# Generated at 2022-06-23 12:53:59.741006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert hasattr(strategy_module, 'run')



# Generated at 2022-06-23 12:54:05.520160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule
    assert obj.__doc__ == 'Executes tasks in linear order on all selected hosts.'
    assert obj.__name__ == 'StrategyModule'
    assert obj.__module__ == 'ansible_collections.ansible.builtin.linear'
    assert obj.__init__.__doc__ == 'Executes tasks in linear order.\n'
    assert obj.run.__doc__ == 'Performs the actual work of the strategy plugin, in this case, executing the tasks in order.'



# Generated at 2022-06-23 12:54:14.439180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(cmd.Cmd):
        prompt="(test) "
        def __init__(self, stm):
            self.stm = stm
            cmd.Cmd.__init__(self)
            self.pp = pprint.PrettyPrinter(indent=4)

        def do_exit(self, line):
            return True

        def do_EOF(self, line):
            return True

        def do_host(self, line):
            host = self.stm.inventory.get_host(line)
            if not host:
                host = self.stm.inventory.localhost
            print("host: %s" % (host,))

        def do_task(self, line):
            print("task: %s" % (self.stm.get_task(line),))


# Generated at 2022-06-23 12:54:15.627183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:54:16.373078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:54:20.334688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'Test'
    s = StrategyModule(tqm)

    assert s.tqm == 'Test'
    assert s.debugger_active == True


# Generated at 2022-06-23 12:54:21.073161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:54:27.650055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm(object):
        def __init__(self):
            self.workers = 4
            self.disabled_pull_mode = False
            self.inventory = None
            self.timeout = 5
            self.args = None

    tqm = MockTqm()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active is True



# Generated at 2022-06-23 12:54:30.931666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing StrategyModule()
    tqm = 'test_tqm'
    strategy_module = StrategyModule(tqm)
    assert(strategy_module.debugger_active == True)


# Generated at 2022-06-23 12:54:33.557471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy:
        pass
    tqm = Dummy()
    strategy = StrategyModule(tqm)
    assert(strategy.debugger_active)


# Generated at 2022-06-23 12:54:44.306439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm is tqm
    assert strategy.debugger_active is True

if sys.version_info >= (3,0):
    class Debugger(cmd.Cmd):
        def __init__(self, tqm):
            cmd.Cmd.__init__(self)
            self.tqm = tqm

        def do_run(self, line):
            self.tqm.run()
            return True

        def do_continue(self, line):
            return True

        def do_inventory(self, line):
            # TODO: Better inventory printer 
            pprint.pprint(self.tqm._inventory.get_hosts(line))


# Generated at 2022-06-23 12:54:46.338117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        assert StrategyModule == StrategyModule, """'test_StrategyModule' is not class 'StrategyModule'"""


# Generated at 2022-06-23 12:54:50.027559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager():
        def __init__(self):
            self.test_val = 10
    s = StrategyModule(TestTaskQueueManager())
    assert s.debugger_active is True


# Generated at 2022-06-23 12:54:55.184833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_tqm = 'ansible.executor.task_queue_manager.TaskQueueManager'
    my_strategy_module = StrategyModule(my_tqm)
    assert(my_strategy_module.debugger_active == True)


# Generated at 2022-06-23 12:54:56.094345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-23 12:55:02.782453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.num_tasks = 3
            self.args = []
    test_tqm = TestTQM()
    test_strategy = StrategyModule(test_tqm)
    assert test_strategy.tasks_queue is not None
    assert test_strategy.tasks_queue.num_tasks == 3
    assert test_strategy.debugger_active



# Generated at 2022-06-23 12:55:03.971421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = 0
        StrategyModule(tqm)
        sys.stdout.write('Pass constructor test!')
    except:
        sys.stdout.write('Failed constructor test!')


# Generated at 2022-06-23 12:55:04.673242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:10.197287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    check_obj = StrategyModule(tqm=1)
    ansible_assert(check_obj.debugger_active, True)

# if __name__ == '__main__':
#     test_StrategyModule()


# Generated at 2022-06-23 12:55:19.000662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # for Python2, ansible.utils.module_docs_fragments.DOCUMENTATION is unicode
    # and must be converted to str
    if sys.version_info.major == 2:
        description = DOCUMENTATION.encode('utf-8')
    else:
        description = DOCUMENTATION
    # Set up attributes for testing, this is normally done in the constructor of the super class
    # AnsibleModule
    tqm = object() # dummy object
    tqm.module_vars = dict()
    tqm.module_vars['__ansible_debug_strategy_module__'] = description
    tqm.module_vars['__ansible_module__'] = 'ansible.plugins.strategy.debug'
    strategy_module = StrategyModule(tqm)
    assert strategy_

# Generated at 2022-06-23 12:55:21.693550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp_tqm = "test"
    strategy = StrategyModule(tmp_tqm)
    assert tmp_tqm == strategy._tqm



# Generated at 2022-06-23 12:55:23.302012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert LinearStrategyModule



# Generated at 2022-06-23 12:55:27.581832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

#
# REF: https://docs.python.org/2/library/cmd.html
#
# The idea of Python's cmd module is to allow the programmer to easily
# implement a simple command-based application that a user can run from a
# terminal window.
#

# Generated at 2022-06-23 12:55:35.280639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active == True
# End of unit test for constructor of class StrategyModule

# Test for function run() in class StrategyModule
# <20180402, chenw>
#    def run(self, play):
#        self.run_async = False
#
#        loop = asyncio.new_event_loop()
#        asyncio.set_event_loop(loop)
#
#        try:
#            loop.run_until_complete(self._run(play))
#        except (KeyboardInterrupt, asyncio.CancelledError):
#            self.tqm._terminate_all_hosts()
#            loop.stop()
#            loop.close()
#            sys.exit(1)

#

# Generated at 2022-06-23 12:55:36.716647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pass
    pass



# Generated at 2022-06-23 12:55:39.143710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sd = StrategyModule(None)
    assert sd.__class__.__name__ == 'StrategyModule'
    assert sd.debugger_active == True


# Generated at 2022-06-23 12:55:41.274156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:55:42.360215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True



# Generated at 2022-06-23 12:55:46.432153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m, "Instantiation of class StrategyModule failed"
    assert m.debugger_active, "Wrong value of debugger_active attribute"


# Generated at 2022-06-23 12:55:55.382597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-23 12:55:58.383454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm={})

    assert hasattr(strategy, 'debugger_active')
    assert strategy.debugger_active == True

# Generated at 2022-06-23 12:56:06.369235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert sys.stdin.read.__doc__ == "read([size]) -> read at most size bytes, returned as a string.\n\n  If the size argument is negative or omitted, read until EOF is reached.\n  Notice that when in non-blocking mode, less data than what was requested\n  may be returned, even if no size parameter was given.\n"
    assert sys.stdin.readline.__doc__ == "readline([size]) -> next line from the file, as a string.\n\n  Retain newline.  A non-negative size argument limits the maximum\n  number of bytes to return (an incomplete line may be returned then).\n  Return an empty string at EOF.\n"

# Generated at 2022-06-23 12:56:09.368409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active == True, "strategy_module.debugger_active is not True"


# Generated at 2022-06-23 12:56:10.248470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()


# Generated at 2022-06-23 12:56:12.140545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True

# A simple command-line based debugger

# Generated at 2022-06-23 12:56:22.365205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test for returning None
    temp = StrategyModule(None)
    assert temp.debugger_active == True
    return temp

test1 = test_StrategyModule()

ansible = '''
action: ansible
host: localhost
module: debug
module_args:
  msg: This is a test message
playbook: /path_to/playbook.yml
tasks: [{task}]
task:
  action: debug
  args:
    msg: This is a test message
  delegate_to: localhost
  name: DEBUG: test message
'''


# Generated at 2022-06-23 12:56:24.009819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fm = StrategyModule("tqm")
    assert fm.debugger_active == True



# Generated at 2022-06-23 12:56:25.278263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm=None)


# Generated at 2022-06-23 12:56:30.377551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing main constructor")
    print("========================")
    try:
        StrategyModule(None)
    except Exception as e:
        print("Failed to instantiate StrategyModule object!")
        print("Exception: {} {}".format(e.__class__.__name__, e))
        print("Test case result: failed")
        return False

    print("Test case result: success")
    return True


# Generated at 2022-06-23 12:56:31.054202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:56:35.353723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    sys.modules['__main__'].__file__ = '/ansible/strategy/debugger.py'
    import ansible.plugins.strategy.debugger as debugger
    debug_obj = debugger.StrategyModule(1)
    assert debug_obj.debugger_active is True


# Generated at 2022-06-23 12:56:46.076119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        debugger_active = StrategyModule.debugger_active
    except AttributeError:
        raise Exception('StrategyModule should have debugger_active attribute')
    assert debugger_active == True
    
    test_tqm = object()
    StrategyModule.__init__(test_tqm)
    assert test_tqm == test_tqm

test_StrategyModule()
        
    #def __init__(self, tqm):
    #    super(StrategyModule, self).__init__(tqm)
    #    self.debugger_active = True
                                

# Generated at 2022-06-23 12:56:47.013031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")


# Generated at 2022-06-23 12:56:52.082648
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create a strategy module object
    strategy_module = StrategyModule(None)

    # Check the properties of strategy_module
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == None
    assert strategy_module.host_list == None
    assert strategy_module.pattern == None



# Generated at 2022-06-23 12:56:53.262580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:57:02.322421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.pattern import Pattern
    from ansible.plugins.loader import load_plugins
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.connection.ssh import Connection

# Generated at 2022-06-23 12:57:02.981528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:57:06.831969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pprint.pprint(StrategyModule.__init__.func_code.co_varnames)
    pprint.pprint(StrategyModule.__init__.func_code.co_argcount)



# Generated at 2022-06-23 12:57:07.438415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:08.977256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:57:13.148710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global su

    class TQM:
        class Playbook:
            class Play:
                pass
        class Inventory:
            class Host:
                pass
        class Runner:
            pass

    StrategyModule(TQM())

    assert su.debugger_active == True
    assert su.tqm.queue_name == 'debug'


# Generated at 2022-06-23 12:57:14.504543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # TODO



# Generated at 2022-06-23 12:57:23.042136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Create dummy inventory
    inventory = InventoryManager(host_list=[])
    inventory.add_host(Host(name='testhost1.test'))
    inventory.add_host(Host(name='testhost2.test'))

    # Create dummy Play
    play = Play()
    play.name = 'test'
    play.hosts = 'all'
    play.tasks = [{'action': {'module': 'debug', 'args': {'msg': 'dummy task'}}}]

    #

# Generated at 2022-06-23 12:57:29.995964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Since we're not actually takling to the Ansible engine, we'll encounter errors
    # so lets simply disable printing out the traceback
    sys.tracebacklimit = 0

    class TestableStrategyModule(StrategyModule):
        def __init__(self, tqm):
            return super(TestableStrategyModule, self).__init__(tqm)

    class TestableTqm(cmd.Cmd):
        def __init__(self):
            return super(TestableTqm, self).__init__()

    t = TestableStrategyModule(TestableTqm())
    return t.debugger_active



# Generated at 2022-06-23 12:57:33.878965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQMModule:
        pass
    tqm = TQMModule()
    sm = StrategyModule(tqm)
    assert sm
    assert sm.debugger_active
    assert not sm.hosts
    assert not sm.conductor


# Generated at 2022-06-23 12:57:35.346056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)

# Generated at 2022-06-23 12:57:38.213663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)
# End of unit test for constructor of class StrategyModule



# Generated at 2022-06-23 12:57:40.701793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    tqm = Mock()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-23 12:57:44.758276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.debugger_active
    assert sm.tqm == tqm
    

# Generated at 2022-06-23 12:57:48.863964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor without a task_queue_manager')
    try:
        StrategyModule()
    except:
        print('Exception was caught')
    print('Complete constructor without a task_queue_manager\n')


# Generated at 2022-06-23 12:57:50.263975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [0]
    StrategyModule(tqm)


# Generated at 2022-06-23 12:57:51.377140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule( tqm )


# Generated at 2022-06-23 12:57:53.035108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 12:57:54.275108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:58.904819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")
    StrategyModule("tqm")

# Generated at 2022-06-23 12:58:11.195346
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:58:13.385140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global debugger_active
    try:
        debugger_active
    except NameError:
        debugger_active = False
    assert debugger_active == True


# Generated at 2022-06-23 12:58:19.470688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm(object):
        def __init__(self):
            self.stats = {}
    s = StrategyModule(MockTqm())
    assert s is not None
    assert isinstance(s, LinearStrategyModule)
    assert isinstance(s, StrategyModule)



# Generated at 2022-06-23 12:58:23.142671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Tqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:26.910347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert(sm)

#
# To test AnsibleTaskExecutor
#
    sm.task_executor = null
    assert (sm.task_executor is null)


if __name__ == '__main__':
    sm = StrategyModule()
    assert(sm)
    sys.exit(0)

# Generated at 2022-06-23 12:58:34.184963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    input_file = sys.stdin
    output_file = sys.stdout
    task_queue_manager = cmd.Cmd(stdin=input_file, stdout=output_file)
    task_queue_manager.prompt = '(Cmd) '
    strategy_module = StrategyModule(task_queue_manager)

    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, LinearStrategyModule)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:35.675628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-23 12:58:37.277024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Write unit test for constructor of class StrategyModule
    assert False


# Generated at 2022-06-23 12:58:37.868346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:40.810448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:58:42.030621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:58:52.613403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  try:
    import unittest2 as unittest
  except ImportError:
    import unittest
  from ansible.plugins.strategy import StrategyModule as ParentStrategyModule
  from ansible.plugins.strategy.debug import StrategyModule as ChildStrategyModule
  from ansible import constants as C
  from ansible.executor.task_queue_manager import TaskQueueManager
  class TestStrategyModule(unittest.TestCase):
    def setUp(self):
      self.tqm = TaskQueueManager(
          inventory=None,
          variable_manager=None,
          loader=None,
          options=None,
          passwords=None,
          run_tree=False,
          stdout_callback=None,
      )

    def tearDown(self):
      pass


# Generated at 2022-06-23 12:58:53.664430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()



# Generated at 2022-06-23 12:58:57.260776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        pass
    tqm = FakeTQM()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, LinearStrategyModule)



# Generated at 2022-06-23 12:58:58.430086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-23 12:58:59.174226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 12:59:09.236984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # empty class
    class TASK_QUEUE_MANAGER:
        pass

    tqm = TASK_QUEUE_MANAGER()

    assert StrategyModule.__name__ == "StrategyModule"

    strategy_module = StrategyModule(tqm)
    # Assert the init works
    assert not strategy_module.done, strategy_module.done
    assert strategy_module.errors == {}, strategy_module.errors
    assert strategy_module.failed_hosts == {}, strategy_module.failed_hosts
    assert strategy_module.unreachable_hosts == {}, strategy_module.unreachable_hosts
    assert strategy_module.cur_task, strategy_module.cur_task
    assert not strategy_module.cur_task_include, strategy_module.cur_task_include

# Generated at 2022-06-23 12:59:11.778309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        sm = StrategyModule(tqm)
        assert sm.debugger_active == True
    except:
        assert 0



# Generated at 2022-06-23 12:59:18.592948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import tempfile
    fd, path = tempfile.mkstemp()

    tqm = FakeTaskQueueManager(
        hosts=['localhost'],
        forks=1,
        module_path=None,
        stdout_callback=None,
        results_callback='on_file',
        runner_callbacks=None,
        stats=None,
        private_data_dir=path,
        connection_type='local',
        passwords=None,
    )

    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:59:21.102573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('tqm')
    assert test.debugger_active == True
# end of test_StrategyModule()



# Generated at 2022-06-23 12:59:22.604969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugobj = StrategyModule("tqm")
    assert debugobj.debugger_active == True


# Generated at 2022-06-23 12:59:33.366435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import json
    import unittest

    class TestStrategyModule(unittest.TestCase):
        tqm = None

        @classmethod
        def setUpClass(self):
            self.tqm = object
            self.strategy_module = StrategyModule(self.tqm)

        def test_strategy_module(self):
            self.assertEqual(self.strategy_module.tqm, self.tqm)
            self.assertEqual(str(self.strategy_module), '<ansible.plugins.strategy.debug.StrategyModule object at 0x10f8e9550>')

    return unittest.main(module='ansible.plugins.strategy.debug', exit=False)


# Generated at 2022-06-23 12:59:34.616334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:59:35.588898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:37.212986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module.debugger_active == True


# Generated at 2022-06-23 12:59:41.652829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test of class StrategyModule
    '''
    # ansible.utils.module_docs.get_docstring(StrategyModule)
    obj = StrategyModule(None)
    assert obj.tqm == None
    assert obj.debugger_active == True

# Generated at 2022-06-23 12:59:43.543968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert len(s.inventory) == 0
    assert s.debugger_active == True



# Generated at 2022-06-23 12:59:45.635004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 12:59:56.830841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.playbook.play import Play
    from ansible.utils.debug import debug

    my_play = Play().load({
        'name' : 'just a test',
        'hosts': 'webservers',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'shell', 'args': 'ls'}}
        ]
    }, variable_manager=dict(), loader=dict())
    tqm = None
    debug_strategy = StrategyModule(tqm)
    assert isinstance(debug_strategy.tqm, None)
    assert isinstance(debug_strategy.existing_tags, list)
    assert isinstance(debug_strategy.dependencies, dict)
    assert debug

# Generated at 2022-06-23 13:00:07.339964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from lib.test_module import TestModule
    import os
    import argparse
    import yaml

    # Test vars
    playbook_path = "./playbook.yaml"
    ansible_playbook = "ansible-playbook"
    host_key_checking = False

    # Prepare
    module = TestModule()
    parser = argparse.ArgumentParser()

# Generated at 2022-06-23 13:00:09.454286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True, \
    "returned false for StrategyModule(None).debugger_active"



# Generated at 2022-06-23 13:00:12.082776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sam = StrategyModule(tqm)
    assert sam.debugger_active == True
    assert isinstance(sam, LinearStrategyModule)


# Generated at 2022-06-23 13:00:15.151321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module.debugger_active, bool)


# Generated at 2022-06-23 13:00:15.836520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:00:20.936594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock for class TaskQueueManager
    class TaskQueueManager():
        def __init__(self):
            pass
    taskQueueManager = TaskQueueManager()
    instance = StrategyModule(taskQueueManager)
    members = vars(instance)
    assert members['debugger_active'] == True



# Generated at 2022-06-23 13:00:23.124756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stg = StrategyModule(tqm = None)
    if not stg.debugger_active:
        raise Exception('unexpected value')



# Generated at 2022-06-23 13:00:33.862483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active is True


    def get_runner(self, host=None):
        if host is None:
            host = self._inventory.get_hosts()[0]

        # We do not use the debugger per host, but per task.
        # Therefor we have to get the host from the task result,
        # which is not available here, we have to do it later in the
        # execute_task function.
        play_context = copy.deepcopy(self._play_context)
        #play_context.remote_addr = host.name
        #play_context.remote_user = host.get_connection_info().get('user')

# Generated at 2022-06-23 13:00:35.025555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-23 13:00:38.277711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_StrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            assert(self.debugger_active)
    # end of class Test_StrategyModule

    test_obj = Test_StrategyModule(None)



# Generated at 2022-06-23 13:00:45.223717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class Test:
            pass
        tqm = Test()
        tqm.stats = Test()
        tqm.stats.failed_hosts = dict()
        tqm.stats.dark_hosts = set()
        tqm.stats.processed_hosts = set()
        tqm.stats.fail_results = dict()
        tqm.hostvars = dict()
        
        strategy = StrategyModule(tqm)
        assert strategy.debugger_active
    except:
        assert False, "StrategyModule constructor failed."
    else:
        assert True


# Generated at 2022-06-23 13:00:47.947925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 13:00:50.014948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert (sm.debugger_active == True)


# Generated at 2022-06-23 13:00:52.111290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test is skipped because this module is not fully implemented.
    pass


# Generated at 2022-06-23 13:00:54.149587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert isinstance(strategy.tqm, object)
    assert strategy.debugger_active is True


# Generated at 2022-06-23 13:00:57.808889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        tqm = StrategyModule(tqm)
        print("StrategyModule() SUCCESSFUL")
    except Exception as e:
        print("StrategyModule() FAILED")
        print(e)



# Generated at 2022-06-23 13:00:58.906436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() != None


# Generated at 2022-06-23 13:01:10.019253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        pass
    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True

    '''
    def _run_play(self, play):
        '''

# Generated at 2022-06-23 13:01:13.092857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.play_iterator import PlayIterator
    result = PlayIterator()

    stragegy_class = StrategyModule(result)

    assert stragegy_class.debugger_active == True



# Generated at 2022-06-23 13:01:17.668075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule with an invalid task_queue_manager
    try:
        StrategyModule(None)
        assert False
    except RuntimeError:
        pass


    # Test for constructor of class StrategyModule with an non-invalid task_queue_manager
    try:
        strategy = StrategyModule(object())
        assert strategy.tqm is not None
        assert strategy.debugger_active is True
    except RuntimeError:
        assert False



# Generated at 2022-06-23 13:01:26.114399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy
    import ansible.utils.shlex
    import ansible.utils.vars
    import ansible.vars.hostvars
    import ansible.vars.vars
    import ansible.vars.clean
    import ansible.vars.reserved
    import ansible.vars.unsafe_proxy
    import collections
    import optparse
    import os
    import time
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy
    import ansible.utils.shlex
    import ansible.utils.vars
    import ansible.vars.hostvars
   

# Generated at 2022-06-23 13:01:28.224240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm


# Generated at 2022-06-23 13:01:30.032217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:01:31.468561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 13:01:38.426165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(object):
        def __init__(self):
            self.strategy = 'first'
            self.strategy_opts = {}
    tqm = Test()
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy.tqm == tqm
    assert strategy.tqm.strategy == strategy
    assert strategy.tqm.strategy_opts == {}
    assert strategy.hosts_left == []
    assert strategy.hosts_assigned_left == []
    assert strategy.hosts_assigned_right == []
    assert strategy.hosts_right == []
    assert strategy.iterator is None


# Generated at 2022-06-23 13:01:40.802912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:01:44.651471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible
    except ImportError:
        print("Ansible not found, skipping test")
        sys.exit(0)

    class Tqm():
        def __init__():
            pass

    module = StrategyModule(Tqm())
    assert module.debugger_active is True
