

# Generated at 2022-06-23 12:51:50.490448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_PlayContext(object):
        def __init__(self, loader=None, options=None, passwords=None, connection_user=None, become_method=None,
                     become_user=None, become_pass=None, sudo_flags=None, forks=None, remote_user=None,
                     connection=None, module_path=None, environment=None, become=None, become_ask_pass=None,
                     verbosity=None, check=None, diff=None):
            self.loader=loader
            self.options=options
            self.passwords=passwords
            self.connection_user=connection_user
            self.become_method=become_method
            self.become_user=become_user
            self.become_pass=become_pass
            self.sudo_flags=sudo_flags

# Generated at 2022-06-23 12:51:53.367681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:52:00.899037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.callbacks as callbacks
    import ansible.constants as constants
    import ansible.inventory as inventory
    import ansible.runner.return_data as return_data
    import ansible.vars as vars
    import ansible.utils.module_docs as utils_module_docs
    from ansible.playbook.play import Play

    class Host(object):
        def __init__(self, host_name, variables, groups=None):
            self.name = host_name
            self.groups = groups if groups else []
            self.variables = variables

        def get_name(self):
            return self.name


# Generated at 2022-06-23 12:52:03.622968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for constructor of class StrategyModule
    assert hasattr(StrategyModule, "debugger_active")



# Generated at 2022-06-23 12:52:05.178612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(0)
    assert st._name == 'debug'
    assert st.debugger_active == True


# Generated at 2022-06-23 12:52:07.197423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active is True

# performs a generic test for constructor of StrategyModule class

# Generated at 2022-06-23 12:52:08.165287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:52:17.569038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_tqm(object):
        class Test_inventory(object):
            class Test_hosts(object):
                class Test_get(object):
                    def __call__(self):
                        return iter([])

                    def __iter__(self):
                        return self

            hosts = Test_hosts()
            get_groups = Test_get()
            get_host = Test_get()
            get_group = Test_get()

        inventory = Test_inventory()
        hosts = inventory.hosts
        play = dict(hosts='all')
        allhosts = inventory.get_hosts()

    tqm = Test_tqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True

# Generated at 2022-06-23 12:52:20.577992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    sm = StrategyModule(test_tqm)
    assert sm.tqm == test_tqm



# Generated at 2022-06-23 12:52:23.509179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("testing constructor of class StrategyModule...")
    tqm = "TQM"
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    print("passed.")



# Generated at 2022-06-23 12:52:31.285280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Start")
    # Unit test for constructor of class StrategyModule
    class AnsibleDebug(cmd.Cmd):
        def __init__(self, *args):
            super(AnsibleDebug, self).__init__(*args)
            # pylint: disable=unsubscriptable-object
            self.current_host = self.inventory._hosts[0]
            # pylint: enable=unsubscriptable-object

        def precmd(self, line):
            if line == "EOF":
                return "exit"
            if not line:
                return line
            else:
                return line

        def do_vars(self, args):
            '''
            Print variables
            '''
            print("current_host")
            print(self.current_host)
            # pylint: disable=no-

# Generated at 2022-06-23 12:52:32.980319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}

    assert StrategyModule(tqm).debugger_active != None

# Generated at 2022-06-23 12:52:36.543973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import ansible.plugins.strategy.debug
    # ansible.plugins.strategy.debug.StrategyModule

    tqm = None
    sm = StrategyModule(tqm)
    sm.debugger_active = True


# Generated at 2022-06-23 12:52:38.753519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm,LinearStrategyModule)
    assert sm.debugger_active


# Generated at 2022-06-23 12:52:47.516092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=0)
    assert s.debugger_active == True
    assert s.host_hash_name == 2
    assert s.host_pinned == 0
    assert s.host_vars == 1
    assert s.hostnames == 3
    assert s.playbook_basedir == 4
    assert s.playbook_filename == 5
    assert s.playbook_inventory == 6
    assert s.playbook_vars == 7
    assert s.results_callback == 8
    assert s.run_handlers == 9
    assert s.run_once == 10
    assert s.stats == 11
    assert s.strategy == 'linear'
    assert s.task_queue_manager == 0
    assert s.tqm == 0


# Generated at 2022-06-23 12:52:49.641894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(object):
        pass
    obj = Test()
    tqm = obj
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 12:52:59.744998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = ansible.playbook.play_context.PlayContext()

# Generated at 2022-06-23 12:53:01.480152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-23 12:53:03.214069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for StrategyModule class"""
    try:
        import ansible
    except ImportError:
        print('Could not import ansible module. Aborting.')
        sys.exit(1)

    print('Trying to import ansible.plugins.strategy.linear.StrategyModule')



# Generated at 2022-06-23 12:53:12.676694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import yaml
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    from ansible.plugins.loader import strategy_loader
    from ansible.utils.display import Display

    class FakeTaskInclude(object):
        def __init__(self):
            self._task_blocks = []
            self._parent_block = None
            self._role = None
            self._set_loader = None

        def load_tasks(self):
            return self._task_blocks

    class FakeTask(object):
        def __init__(self):
            self.block = None        # only used with strategy: free

# Generated at 2022-06-23 12:53:13.545215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:17.167465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    test_strategymodule = StrategyModule(tqm)
    assert test_strategymodule.debugger_active == True


# Generated at 2022-06-23 12:53:17.873139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:53:19.080902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__bases__[0].__name__ == 'LinearStrategyModule')


# Generated at 2022-06-23 12:53:21.674816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1



# Generated at 2022-06-23 12:53:22.482065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-23 12:53:25.287556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test initialization with a dummy class
    class Test_tqm:
        def __init__(self):
            self.options = None
    Test_tqm = Test_tqm()
    Test_strategyModule = StrategyModule(Test_tqm)
    assert Test_strategyModule is not None



# Generated at 2022-06-23 12:53:27.710268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:53:30.354954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
        pass
    except Exception as e:
        print(e)



# Generated at 2022-06-23 12:53:34.866908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task1 = dict(action=dict(module='shell', args='whoami', register='whoami_output'))
    print(task1['action'])
    print(type(task1['action']))
    tasks = [task1]
    for task in tasks:
        print(task['action'])



# Generated at 2022-06-23 12:53:37.041926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_obj = 'test'
    StrategyModule(tqm_obj)



# Generated at 2022-06-23 12:53:40.821490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    config = {}
    tqm = {'config': config}
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active


# Generated at 2022-06-23 12:53:42.689505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create tqm
    assert True == True


# Generated at 2022-06-23 12:53:45.112211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'


# Generated at 2022-06-23 12:53:45.921530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-23 12:53:56.653964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest2 as unittest
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, *args, **kwargs):
            self._patched_send_callback = kwargs.pop('send_callback')
            self._patched_host_result_callback = kwargs.pop('host_result_callback')
            self._patched_results_callback = kwargs.pop('results_callback')


# Generated at 2022-06-23 12:53:57.338627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:53:59.030244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-23 12:54:00.828077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active
# Unit test end


# Generated at 2022-06-23 12:54:02.611176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-23 12:54:03.471270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:54:06.554403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stub_tqm = True
    strategy_module = StrategyModule(stub_tqm)
    assert(strategy_module.debugger_active == True)


# Generated at 2022-06-23 12:54:08.844900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:54:13.394269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.module_utils.basic
    tqm = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    strategy = StrategyModule(tqm)
    assert(strategy is not None)



# Generated at 2022-06-23 12:54:14.745244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    tqm = None
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-23 12:54:18.218946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(True), StrategyModule)
    assert isinstance(StrategyModule(True), LinearStrategyModule)


# Generated at 2022-06-23 12:54:21.249390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = None

    # Act
    strategy_module = StrategyModule(tqm)

    # Assert 
    assert strategy_module != None

# Generated at 2022-06-23 12:54:25.183047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Debugger(cmd.Cmd):
        pass
    tqm = Debugger()
    sm = StrategyModule(tqm)
    assert(sm.debugger_active == True)


# Generated at 2022-06-23 12:54:27.407464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    debugger = StrategyModule()
    assert debugger.debugger_active == debugger_active



# Generated at 2022-06-23 12:54:37.151843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugins
    from ansible.playbook.play_context import PlayContext

    tqm = plugins.PluginLoader.load_callback_plugins('run', PlayContext(), 'debug')
    sm = StrategyModule(tqm)

    if not sm:
        raise Exception("Cannot load strategy module.")

    if sm.tqm is not tqm:
        raise Exception("The strategy module is not properly initialized.")

    if not sm.run_once:
        raise Exception("The strategy module is not properly initialized.")

    if sm.step:
        raise Exception("The strategy module is not properly initialized.")

    if sm.host_list is not None:
        raise Exception("The strategy module is not properly initialized.")

    if sm.results:
        raise Exception("The strategy module is not properly initialized.")


# Generated at 2022-06-23 12:54:42.179767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    msg = "Test StrategyModule constructor"
    print(msg)
    class TestStrategy(object):
        def __init__(self, tqm):
            pass
    strategy = StrategyModule(TestStrategy) # type: StrategyModule
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:54:46.337882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'host_list': ['host1', 'host2', 'host3']}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active



# Generated at 2022-06-23 12:54:50.027530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Start unit test for StrategyModule class')
    obj = StrategyModule(None)
    if(obj.debugger_active):
        print('Test passed')
    else:
        print('Test failed')


# Generated at 2022-06-23 12:54:52.974120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy_module_object = LinearStrategyModule(None)
    strategy_module_object = StrategyModule(None)


# Generated at 2022-06-23 12:54:56.411692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    assert hasattr(StrategyModule, 'debugger_active')
    assert hasattr(StrategyModule, '__init__')
    
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:54:58.128935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Execute unit test for constructor of class StrategyModule")



# Generated at 2022-06-23 12:55:06.350182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import __version__ as ansible_version
    from collections import namedtuple
    from ansible.plugins.strategy import StrategyBase

    FakeTqm = namedtuple('FakeTqm', ['stats'])
    fake_tqm = FakeTqm(stats=dict(processed={}))
    ansible_version = [int(x) for x in ansible_version.split('.')]
    ansible_is_2_1 = (ansible_version[0] >= 2 and ansible_version[1] >= 1)

    strategy_module = StrategyModule(fake_tqm)
    assert isinstance(strategy_module, StrategyBase) == True



# Generated at 2022-06-23 12:55:09.443454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    print("initialized")


# Generated at 2022-06-23 12:55:13.513656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy_mock = LinearStrategyModule(None)
    StrategyModule(None)
    StrategyModule_instance = StrategyModule(None)
    assert StrategyModule_instance.debugger_active == True


# Generated at 2022-06-23 12:55:17.420876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)

    assert TestStrategyModule.debugger_active == True



# Generated at 2022-06-23 12:55:18.278038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    assert True



# Generated at 2022-06-23 12:55:21.407161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __getattr__(self, name):
            print(name)
    tqm = TestTQM()
    StrategyModule(tqm)


# Generated at 2022-06-23 12:55:29.128925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            args_list = ['', '1', '2']
            opts_list = ['', '', '']
            self.set_options(args_list, opts_list)

    # If the test is OK, it returns nothing.
    test_strategy_module = TestStrategyModule(None)



# Generated at 2022-06-23 12:55:32.478679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._tqm == tqm
    assert strategy_module.debugger_active
#
#
#


# Generated at 2022-06-23 12:55:34.494980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:55:35.795021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:55:37.357658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  s = StrategyModule('tqm')
  assert s != None


# Generated at 2022-06-23 12:55:37.989547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:45.659452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Mock objects
    class MockTqm(object):
        def __init__(self):
            self.host_list = 'host_list'
            self.inventory = 'inventory'

    # Create object and check for expected attributes
    tqm = MockTqm()
    strategy_module = StrategyModule(tqm)

    assert hasattr(strategy_module, 'tqm')
    assert hasattr(strategy_module, 'tasks_per_worker')
    assert hasattr(strategy_module, 'debugger_active')
    assert hasattr(strategy_module, 'current_task_name')


# Generated at 2022-06-23 12:55:49.903594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        def __init__(self, hosts, inventory):
            self.hosts = host
            self.inventory = inventory

    host = '127.0.0.1'
    sm = StrategyModule(FakeTQM(host, None))
    assert sm.debugger_active == True
    assert sm.hosts == host
    assert sm.inventory == None
    assert sm.tqm == FakeTQM(host, None)
    assert sm.host_state_map == {}
    assert sm.worker_threads == []



# Generated at 2022-06-23 12:55:52.277647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import ansible.playbook.task
    tqm = mock.Mock()
    StrategyModule(tqm)

# Execute method of class StrategyModule

# Generated at 2022-06-23 12:55:55.872365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Test properties are correctly set
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm is tqm

    assert strategy_module.debugger_active is True



# Generated at 2022-06-23 12:56:00.874577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock_tqm()
    strategy = StrategyModule(tqm)

    # Test if strategy.debugger_active is something
    assert strategy.debugger_active

    # Test if StrategyModule is a subclass of LinearStrategyModule
    assert isinstance(strategy, LinearStrategyModule)



# Generated at 2022-06-23 12:56:03.212131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        slm = StrategyModule(tqm=None)
    except Exception:
        raise AssertionError
    assert slm



# Generated at 2022-06-23 12:56:05.958199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        pass

    assert issubclass(StrategyModule(TestTaskQueueManager()), LinearStrategyModule)


# Generated at 2022-06-23 12:56:11.319731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    task = Task()
    play = Play()
    play.add_task(task)
    block = Block()
    block.append_task(task)
    strategy = StrategyModule(play)

# I haven't found method to add asserts to this unit test

# Generated at 2022-06-23 12:56:18.164095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Init constructor with invalid parameter 'tqm'
    assert StrategyModule is not None
    with pytest.raises(ValueError):
        StrategyModule(tqm)


    for test in [StrategyModule]:
        # Init constructor with valid parameter
        assert StrategyModule is not None
        StrategyModule(tqm)
        # Check whether the result of constructor is instance of the StrategyModule
        assert isinstance(result, StrategyModule)



# Generated at 2022-06-23 12:56:18.924861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:56:21.002580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-23 12:56:23.892594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert isinstance(strategyModule, StrategyModule)
    assert isinstance(strategyModule, LinearStrategyModule)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 12:56:27.106234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = null
    assert isinstance(tqm, LinearStrategyModule) == True
    tqm.__init__(tqm)
    assert tqm.debugger_active == True

# Unit test of startup_message()

# Generated at 2022-06-23 12:56:28.433114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule(1)
    p.__init__()


# Generated at 2022-06-23 12:56:32.832694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    sm = StrategyModule(tqm)
    assert sm.debugger_active
    assert sm.host_states == {}
    assert sm.host_pinned_context == {}
    assert sm.host_pinned_failing == []


# Generated at 2022-06-23 12:56:34.043639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module is not None



# Generated at 2022-06-23 12:56:35.605176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule(tqm=None)


# Generated at 2022-06-23 12:56:39.360003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def _tqm(tqm):
        return tqm

    tqm = StrategyModule(_tqm)
    assert tqm.debugger_active == True


# Generated at 2022-06-23 12:56:40.359715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This test is a stub
    pass



# Generated at 2022-06-23 12:56:41.714062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is object



# Generated at 2022-06-23 12:56:46.694157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm(object):
        def __init__(self, da):
            self.debugger_active = da
    assert isinstance(StrategyModule(tqm(False)), LinearStrategyModule), 'Failed to initialize object of type StrategyModule'



# Generated at 2022-06-23 12:56:55.677125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Bunch:
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    tqm = Bunch(
        hosts=['localhost'],
        get_host_vars=lambda x: '',
        get_vars=lambda x: '',
        get_host=lambda x: Bunch(name='localhost', get_vars=lambda: Bunch(vars={}))
    )

    s = StrategyModule(tqm)
    assert(s.debugger_active)


# Generated at 2022-06-23 12:56:57.812513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Generated at 2022-06-23 12:56:59.965264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"


# Generated at 2022-06-23 12:57:02.427197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:57:03.706417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:57:05.629485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Unit test requires to re-design StrategyModule's constructor
    pass



# Generated at 2022-06-23 12:57:10.154493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	assert StrategyModule.__doc__ == "Exectues tasks in interactive debug session." 
	assert cmd.Cmd.__doc__ == None
	assert pprint.__doc__ == "Pretty-print a Python object to a stream [default is sys.stdout]."
	assert sys.__doc__ == "This module provides access to some variables used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."


# Generated at 2022-06-23 12:57:10.952561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:17.525843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule:
        def __init__(self):
            self.debugger_active = None
    tqm = TestStrategyModule()
    s = StrategyModule(tqm)
    if tqm.debugger_active is not False:
        raise Exception("StrategyModule constructor is broken: tqm.debugger_active should be False")



# Generated at 2022-06-23 12:57:19.203778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:57:26.012226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new instance of class StrategyModule
    sm = StrategyModule()

    # Check if debugger_active has the expected value
    expected_debugger_active = True
    actual_debugger_active = sm.debugger_active
    assert actual_debugger_active == expected_debugger_active, 'Actual debugger_active is "%s" instead of expected "%s"' % (actual_debugger_active, expected_debugger_active)


# Generated at 2022-06-23 12:57:36.588335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # constructor of class PlaybookExecutor
    from ansible.executor import PlaybookExecutor
    from ansible.playbook import Playbook
    # _playbook is an attribute of class PlaybookExecutor
    # _playbook is an instance of class Playbook
    playbook = Playbook([])
    playbook_executor = PlaybookExecutor(playbook)
    # prepare the task queue manager, which manages my_playbook_executor
    # task_queue_manager is instance of class TaskQueueManager
    playbook_executor._setup_task_queue_manager()
    # tqm is instance of class TaskQueueManager
    tqm = playbook_executor._tqm
    # instantiation of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # check debugger_active attribute
    assert strategy_module.debugger_

# Generated at 2022-06-23 12:57:44.100821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.name == 'debug', "StrategyModule.name should be 'debug'"
    assert StrategyModule.description == 'Executes tasks in interactive debug session.', "StrategyModule.description should be 'Executes tasks in interactive debug session.'"
    assert StrategyModule.short_description == 'Executes tasks in interactive debug session.', "StrategyModule.short_description should be 'Executes tasks in interactive debug session.'"
    assert StrategyModule.version_added == "2.1", "StrategyModule.version_added should be '2.1'"



# Generated at 2022-06-23 12:57:47.427073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestTQM()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

# Test for run method of class StrategyModule

# Generated at 2022-06-23 12:57:51.592926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create test objects
    tqm = dict()
    tqm['stats'] = dict()
    tqm['hostvars'] = dict()

    # Verify initialization variables
    strategyModule = StrategyModule(tqm)
    assert strategyModule.tqm == tqm


# Generated at 2022-06-23 12:58:02.233473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.callback.default import CallbackModule
    except ImportError:
        pass
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor import task_queue_manager
    tqm = task_queue_manager.TaskQueueManager(
            inventory=None,
            variable_manager=None,
            loader=None,
            options=None,
            passwords=None,
            stdout_callback=CallbackModule(),
    )
    try:
        s = StrategyModule(tqm)
    except:
        assert False
    assert s._tqm == tqm
    assert s.debugger_active == False
    assert s._final_q is None
# End of unit test for constructor of class StrategyModule



# Generated at 2022-06-23 12:58:13.120153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create a new TaskQueueManager and set into module
    sys.modules[__name__].TaskQueueManager = TaskQueueManager = AnsibleTaskQueueManager
    TaskQueueManager.run = MagicMock(return_value=0)
    sys.modules[__name__].TQM = TQM = TaskQueueManager()

    # Create a new StrategyModule and set into module
    sys.modules[__name__].LinearStrategyModule = LinearStrategyModule = AnsibleLinearStrategyModule
    sys.modules[__name__].StrategyModule = StrategyModule = AnsibleStrategyModule
    StrategyModule.run = MagicMock(return_value=1)

    # Construct new instance of class StrategyModule
    ansible_strategy_module = StrategyModule(TQM)

    # Test if the debugger is active
    assert ansible_strategy_

# Generated at 2022-06-23 12:58:15.160578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-23 12:58:19.408469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

    assert strategy_module.get_host_results() == {}
    assert strategy_module.tqm is None



# Generated at 2022-06-23 12:58:22.288528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Unit test to check the method StrategyModule.run
# Currently, just prints out the debug message

# Generated at 2022-06-23 12:58:22.904948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:58:27.022388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible.plugins.strategy'] = sys.modules['ansible.plugins.strategy.standard']
    sys.modules['ansible.plugins.strategy.standard'] = sys.modules['ansible.plugins.strategy.standard']
    reload(sys.modules['ansible.plugins.strategy.standard'])
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 12:58:37.277238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import textwrap
    from ansible.utils.display import Display
    from ansible.callbacks import CallbackBase
    from ansible.plugins import strategy_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    class TestDisplay(Display):
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False, newline=True):
            print

# Generated at 2022-06-23 12:58:39.054463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    

#
# Start of debugger
#

# Generated at 2022-06-23 12:58:48.954125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.splitter import parse_kv

    class Options():
        def __init__(self, become=False, become_user='root', become_ask_pass=False,
                     diff=False, forks=5, tags=[], skip_tags=[],
                     remote_user='root', private_key_file='/root/.ssh/id_rsa'):
            self.become = become

# Generated at 2022-06-23 12:58:50.034126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:58:51.576786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule(tqm=None)
    assert c.debugger_active == True


# Generated at 2022-06-23 12:58:55.783143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = ''
        strategyModule = StrategyModule(tqm)
    except Exception as inst:
        sys.stderr.write("ERROR: StrategyModule failed to init")
        sys.stderr.write("Error: %s" % inst)
        assert False


# Generated at 2022-06-23 12:58:59.617985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('#####  Unit test for class StrategyModule  #####')
    print('* class StrategyModule : constructor(self, tqm)')
    strategy_module = StrategyModule(None)
    print(dir(strategy_module))


# Generated at 2022-06-23 12:59:00.504898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-23 12:59:03.720058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' in globals(), "Function StrategyModule() not defined."
    assert 'debugger_active' in globals(), "Variable debugger_active not defined."
    assert type(debugger_active) is bool, "Variable debugger_active is not of type bool."
    assert debugger_active is True, "Variable debugger_active is not True."


# Actual strategy module

# Generated at 2022-06-23 12:59:07.749606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) != None


    def use_shell(self, host):
        ''' overriding the default behavior of not using the shell.
            When using the interactive debugger we want to be able to call
            programs on the remote host.
        '''
        return True

# Generated at 2022-06-23 12:59:11.815200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as debug
    reload(debug)
    tqm = "test_tqm"
    strategy = debug.StrategyModule(tqm)
    assert tqm == strategy._tqm


# Generated at 2022-06-23 12:59:13.075239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod.debugger_active


# Generated at 2022-06-23 12:59:14.811629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert sm.debugger_active == True

# Generated at 2022-06-23 12:59:18.383517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = DummyTaskQueueManager()
  strategy = StrategyModule(tqm)
  assert isinstance(strategy, LinearStrategyModule)
  assert strategy.debugger_active == True

# Unit Test for method run

# Generated at 2022-06-23 12:59:22.359241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule
    sm = StrategyModule()
    assert sm.get_host_list() == []
    assert sm.host_list == []
    assert sm.task_list == []
    assert sm.pattern == None


# Generated at 2022-06-23 12:59:26.732517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(0)
    if strategy_module.debugger_active == True:
        return 0
    else:
        return 1

test_StrategyModule()



# Generated at 2022-06-23 12:59:27.505273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:59:37.375680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK = dict(action=dict(module='command', args='uname -a'))
    TASK_B = dict(action=dict(module='command', args='uptime'))
    INVENTORY = dict(host_list=['localhost'], group_list=[])
    PLAY = dict(playbook='playbook.yml', task_list=[TASK, TASK_B])
    PLAYBOOK = dict(play_list=[PLAY])
    TASK_QUEUE_MANAGER = dict(host_list=[TASK, TASK], host_vars=INVENTORY, inventory=INVENTORY,
                             VariableManager=dict(extra_vars={}), SHH_CONNECTION=object)

# Generated at 2022-06-23 12:59:38.231884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule('s') is not None)


# Generated at 2022-06-23 12:59:41.512092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:59:42.541862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 12:59:45.108293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up mock objects
    testobject = StrategyModule(tqm="tqm_test_value")
    assert testobject.debugger_active == True


# Generated at 2022-06-23 12:59:46.880889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test1 = StrategyModule(None)
    assert test1.debugger_active == True


# Generated at 2022-06-23 12:59:48.763532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:59:58.675476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_task = {
        'action': {
            '__ansible_arguments__': {'module_name': 'ping'},
            '__ansible_task_vars__': {'inventory_hostname': 'localhost'},
            '__ansible_version__': '2.1.0',
        },
        'diffs': {},
        'name': 'ping',
        'notify': [],
        'register': 'debugger_test'
    }
    test_host = {'vars': {}}

    sm = StrategyModule(object)
    sm.add_host(test_host, None)
    sm.add_tasks(test_task)

    assert sm.hosts == ['localhost']
    assert sm.host_vars == {}
    assert sm.noop_task == test_task

# Generated at 2022-06-23 13:00:08.366048
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:00:09.157127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:00:11.234355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.debugger_active



# Generated at 2022-06-23 13:00:14.500023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    assert obj is not None


# Generated at 2022-06-23 13:00:15.972412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 13:00:16.767816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:00:20.058010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active, "Failed. StrategyModule constructor should activate debugger."


# Generated at 2022-06-23 13:00:27.227882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import DictInventory
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create needed objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, True)
    variable_manager._extra_vars = load_extra_vars(loader, options.extra_vars)
    variable_manager._options_vars = load_options_vars(options)
    variable_manager._vault_password = options.v

# Generated at 2022-06-23 13:00:32.346240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_dict ={
        'tqm': {
            'tqm_debug': True,
            '_variables': {
                'my_var': 'bar',
            }
        }
    }
    try:
        my_object = StrategyModule(tqm=my_dict['tqm'])
    except:
        my_object=None
    assert my_object.debugger_active == True



# Generated at 2022-06-23 13:00:39.187584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule('test')
    assert test_strategy_module.debugger_active == True


    # Override run method of base class.
    # Basically it's copied from original with some additions.
    def run(self, iterator, play_context):

        import signal
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        self._tqm._terminated = False

        result = super(StrategyModule, self).run(iterator, play_context)


# Generated at 2022-06-23 13:00:41.015990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    ok_(len(sm.tasks) == 0)



# Generated at 2022-06-23 13:00:48.343912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        def __init__(self):
            self.hostvars = {
                'host1': {
                    'module_setup': True,
                    'module_defaults': {'some_module_defaults_option': 'module_defaults_value'},
                    'ansible_facts': {'core_module_facts': 'core_facts_value'},
                    'ansible_facts_cacheable': {'core_module_facts_cacheable': 'core_facts_cacheable_value'},
                    'ansible_facts_d': {'core_module_facts_d': 'core_facts_d_value'},

                    'some_added_variable_should_not_be_included': 'some_added_variable_should_not_be_included_value'
                }
            }

# Generated at 2022-06-23 13:00:52.693840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # def print_result(self, result):
    #     return super(StrategyModule, self).print_result(result)

    # def run(self, iterator, play_context):
    #     return super(StrategyModule, self).run(iterator, play_context)



# Generated at 2022-06-23 13:00:54.089921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

    return True # Constructor is successful

test_StrategyModule()



# Generated at 2022-06-23 13:00:54.750226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True



# Generated at 2022-06-23 13:00:55.950230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule is not tested because it is an abstract class with no implementation
    pass


# Generated at 2022-06-23 13:00:57.952441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = 'test')

# from ansible.cli import CLI
# cli = CLI(['', 'playbooks/debug.yml'])
# cli.parse()
# cli.run()

# ansible-playbook playbooks/debug.yml -vvvv



# Generated at 2022-06-23 13:01:09.377019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.module_docs as module_docs
    from ansible.errors import AnsibleError
    from ansible.utils import module_formatter
    from ansible.utils import module_list
    
    test_action_plugins = '''
    lib/ansible/plugins/action/ping.py
    lib/ansible/plugins/action/script.py'''.strip()
    
    test_cache = '''
    '''

# Generated at 2022-06-23 13:01:12.132282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('Test', (object,), {})
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-23 13:01:14.314099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:01:15.620799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.debugger_active == False


# Generated at 2022-06-23 13:01:16.720305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)



# Generated at 2022-06-23 13:01:22.669435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.strategy_module = StrategyModule(None)

        def test_to_string(self):
            self.assertEqual(str(self.strategy_module), "<class 'ansible.plugins.strategy.debug.StrategyModule'>")

    unittest.main()


# Generated at 2022-06-23 13:01:25.530811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:01:35.996867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from unittest.mock import Mock
        from ansible.utils import module_docs
    except ImportError:
        from mock import Mock
        from ansible.utils import module_docs

    # Define tqm
    tqm = Mock()
    tqm.send_callback = Mock()
    tqm.RUN_OK = 'RUN_OK'
    # Create an instance of class StrategyModule
    test_StrategyModule = StrategyModule(tqm)
    # Check if debugger_active is false or not
    if not test_StrategyModule.debugger_active:
        raise Exception('Debug is not active')
    # Check run_execution_module method and returns RUN_OK

# Generated at 2022-06-23 13:01:38.739784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)
    assert True



# Generated at 2022-06-23 13:01:39.968775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-23 13:01:40.909563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

