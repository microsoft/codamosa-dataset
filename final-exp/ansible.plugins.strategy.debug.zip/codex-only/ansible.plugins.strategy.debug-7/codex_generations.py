

# Generated at 2022-06-23 12:51:42.635822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:51:46.348615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None)
    strategy_module = StrategyModule(tqm)
    print(strategy_module.debugger_active)



# Generated at 2022-06-23 12:51:47.321592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 12:51:48.094524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:51:49.735151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Interactive debugger

# Generated at 2022-06-23 12:51:51.950321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test StrategyModule constructor")
    test_StrategyModule = StrategyModule(None)
    assert isinstance(test_StrategyModule, StrategyModule)


# Generated at 2022-06-23 12:51:53.674750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm-ansible"
    StrategyModule(tqm)


# Generated at 2022-06-23 12:51:54.911536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True


# Generated at 2022-06-23 12:51:58.444044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True

################################################################################

# Unit tests for debugger


# Generated at 2022-06-23 12:51:59.023898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    pass


# Generated at 2022-06-23 12:52:00.505954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In test_StrategyModule")
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:52:03.196790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(None)
    assert not result.debugger_active



# Generated at 2022-06-23 12:52:04.576274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule(tqm)
    assert c.debugger_active == True
    

# Generated at 2022-06-23 12:52:09.446734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    globals()[StrategyModule.__module__] = StrategyModule
    import ansible.plugins.strategy.debug as debug
    sys.modules['ansible.plugins.strategy.debug'] = debug
    from ansible.plugins.strategy.debug import StrategyModule
    sm = StrategyModule()
    print(sm)
    del globals()[StrategyModule.__module__]

test_StrategyModule()


# Generated at 2022-06-23 12:52:14.590653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'test'
  strategy_module = StrategyModule(tqm)
  assert strategy_module is not None
  assert strategy_module.tqm == tqm
  assert strategy_module.inventory is not None
  assert strategy_module.queue_name is not None
  assert strategy_module.variable_manager is not None
  assert not strategy_module.background
  assert strategy_module.debugger_active


# Generated at 2022-06-23 12:52:22.480733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.shared_loader_obj = None
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.host_list = None
            self.stdout_callback = None
            self.stats = None
            self.options = None
        def add_host(self, host):
            pass
    tqm = TestTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:52:26.170704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert(isinstance(strategy_module, LinearStrategyModule))

# Test for constructor of class Debugger

# Generated at 2022-06-23 12:52:31.613419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert issubclass(StrategyModule, object)
    assert issubclass(StrategyModule, cmd.Cmd)
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    assert hasattr(StrategyModule, 'debugger_active')


# Generated at 2022-06-23 12:52:40.212237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Debugger(cmd.Cmd):
        def cmdloop(self, intro=None):
            self.s = StrategyModule(TestTaskQueueManager())
            cmd.Cmd.cmdloop(self)

        def emptyline(self):
            return

        def do_task(self, args):
            if args == 'no':
                print('No Task')
                return

            t = self.s._task()
            if t is None:
                print('No Task')
                return

            print('')
            t.post_validate(t._ds)
            print(t.get_name_to_run())
            pprint.pprint(t)
            print('>')

        def do_prev(self, args):
            self.s._prev()

        def do_next(self, args):
            self.s._next

# Generated at 2022-06-23 12:52:45.768863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Mock out some of the elements needed by the constructor
    class MyTqm(object):
        def __init__(self):
            self.stats = dict()
    tqm = MyTqm()
    testee = StrategyModule(tqm)
    assert testee._tqm == tqm
    assert testee.debugger_active


# Generated at 2022-06-23 12:52:56.734782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            pass
    strategy = StrategyModule(TQM)
    assert strategy.debugger_active is True
    assert strategy.tqm is not None

# Usage
#   ansible-playbook playbook.yml -v -i inventory --debug -vvvv
#
# Example
#
#    TASK ACTION: [debug] task1 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#    	#
#    	# Ansible task debug session
#    	#
#    	# Commands: task, args, host, var, skip, resume, exit
#    	#
#    	debug> 
#
#    task
#    	##########################################
#    	# Task: task1
#    	##########################################


# Generated at 2022-06-23 12:52:58.238184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule('tqm')
    assert t.debugger_active == True, 'debugger_active not set to True'


# Generated at 2022-06-23 12:52:59.289591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of class StrategyModule
    pass



# Generated at 2022-06-23 12:53:01.378504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# A class that inherits from cmd.Cmd
# cmd is a built-in module

# Generated at 2022-06-23 12:53:02.486850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('Test')


# Generated at 2022-06-23 12:53:04.442371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    debug.StrategyModule('tqm_mock')



# Generated at 2022-06-23 12:53:09.776640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = None
    def test_get_hosts_remaining(self, play):
        return []
    def test_get_next_task_for_host(self, host):
        return []
    try:
        test_strategy_module = StrategyModule(test_strategy_module)
    except Exception as e:
        traceback.print_exc()
    assert(test_strategy_module != None)


# Generated at 2022-06-23 12:53:12.446818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert tqm == sm.tqm


# Generated at 2022-06-23 12:53:16.369282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True
    assert StrategyModule(None).__mro__ == (StrategyModule, LinearStrategyModule, object)



# Generated at 2022-06-23 12:53:24.074150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import module
    from ansible.plugins.strategy import debug as debug_strategy

    # create an instance of 'StrategyModule' class
    _StrategyModule = debug_strategy.StrategyModule(None)

    # test instantiation of the class
    assert isinstance(_StrategyModule, debug_strategy.StrategyModule) is True

    # test the instantiation of the attribute 'debugger_active'
    assert _StrategyModule.debugger_active == True

    # test the inherited instance of 'StrategyBase'
    from ansible.plugins.strategy import linear
    assert isinstance(_StrategyModule, linear.StrategyModule) is True



# Generated at 2022-06-23 12:53:26.521132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM:
        stats = {}
    assert StrategyModule(DummyTQM).stats == {}


# Generated at 2022-06-23 12:53:31.570857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == tqm
    assert type(strategy.task_queue_manager) == type('')


# Generated at 2022-06-23 12:53:33.649133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

    assert strategy_module is not None
    assert strategy_module.debugger_active is True



# Generated at 2022-06-23 12:53:35.950298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active is True

print("\n[debug] test StrategyModule complete!")

# Generated at 2022-06-23 12:53:37.334920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

# Unit tests for class StrategyModule

# Generated at 2022-06-23 12:53:41.424954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == tqm
    assert strategy.step == 2


# Generated at 2022-06-23 12:53:44.111857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy.tqm == 'tqm'
    assert strategy.debugger_active is True



# Generated at 2022-06-23 12:53:44.848219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:55.706152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import ansible.parsing.vault as vault
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    opts = mock.Mock()
    opts.module_path = ':memory:'
    opts.listtags = opts.listtasks = opts.syntax = False
    opts.connection = 'local'
    opts.forks = 5
    opts.become = opts.become_method = opts.become_user = None
    opts.module_path = './'
    opts.remote_user = 'ron'
    opts.private_key_file = '/home/ron/.ssh/private_key'
    opts.verbosity = 0

# Generated at 2022-06-23 12:53:58.112219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(None)
    assert test_StrategyModule.debugger_active == True



# Generated at 2022-06-23 12:54:01.847481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # making an empty array
    strategy = []
    tqm = []
    # appending an object to the array
    strategy.append(StrategyModule(tqm))
    assert strategy[0].debugger_active == True


# Generated at 2022-06-23 12:54:06.450495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.stats = dict(ok=0, failed=0, unreachable=0, skipped=0)

    sm = StrategyModule(tqm())
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:54:07.502310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True



# Generated at 2022-06-23 12:54:11.489828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    import ansible.plugins.strategy.debug as debug

    assert issubclass(debug.StrategyModule, StrategyModule.StrategyModule)
    assert issubclass(debug.StrategyModule, debug.Cmd)
    assert issubclass(debug.StrategyModule, LinearStrategyModule)


# Generated at 2022-06-23 12:54:20.703979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Expected attributes of StrategyModule
    attr = {'_tqm': None,
            'name': 'linear',
            '_callbacks': [],
            '_failed_hosts': {},
            'host_callbacks': {},
            'host_failed_conditions': {},
            'host_no_host': {},
            'iterations': 0,
            'max_fail_percentage': None,
            'max_fail_pct': 0,
            'results': [],
            'runner_callbacks': [],
            'runner_on_failed': {},
            'runner_on_ok': {},
            'runner_on_skipped': {},
            'queue_empty': None,
            'task_queue': [],
            'vars_prompt': {}}


# Generated at 2022-06-23 12:54:25.000729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''test_StrategyModule
    This test creates StrategyModule object.
    '''
    sm = StrategyModule()
    print('Successfully created StrategyModule object')
    return sm


# Generated at 2022-06-23 12:54:32.602005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Creating a test TaskQueueManager object")
    tqm = TaskQueueManager()
    print("Creating a test StrategyModule object")
    sm = StrategyModule(tqm)
    print("Asserting that the class StrategyModule has the correct parent class")
    assert(sm.__class__.__bases__[0].__name__ == "LinearStrategyModule")
    print("Asserting that the class StrategyModule has been initialized correctly")
    assert(sm.debugger_active)



# Generated at 2022-06-23 12:54:34.811445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'bla':'bla'}
    s = StrategyModule(tqm)
    assert s._tqm is tqm



# Generated at 2022-06-23 12:54:45.050672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active

#################################################################
#
# debugger commands
#
#################################################################

    def do_list(self, arg):
        """
        lists all tasks
        """
        if arg:
            ids = arg.split()
            for task_id in ids:
                if task_id not in self._tasks:
                    self.tqm.display.error("task not found: %s" % task_id)
                    continue
                task = self._tasks[task_id]
                self.tqm.display.display(u"%s\t%s" % (task_id, task.name))
        else:
            for task_id in self._tasks:
                task = self._tasks[task_id]

# Generated at 2022-06-23 12:54:47.384278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TqmMock()
    assert tqm.debugger_active == True


# Generated at 2022-06-23 12:54:47.993527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 12:54:50.471519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, "__init__")
    assert callable(StrategyModule.__init__)


# Generated at 2022-06-23 12:54:53.853461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor of class StrategyModule")
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:54:56.139725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor...")
    test_object = StrategyModule(None)
    print("\tConstructor passed")


# Generated at 2022-06-23 12:55:04.038149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    setattr(sys.modules[__name__], '__ansible_test__', True)
    import ansible.plugins.strategy.debug
    test_instance = ansible.plugins.strategy.debug.StrategyModule(1)
    assert isinstance(test_instance, ansible.plugins.strategy.debug.StrategyModule)
    assert test_instance.tqm == 1
    assert test_instance.debugger_active is True
    delattr(sys.modules[__name__], '__ansible_test__')



# Generated at 2022-06-23 12:55:09.812416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import task_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    result = loader.load_from_file('../test/test_strategy_debug.yml')
    inv_data = {}
    hosts = result['hosts']
    inv = InventoryManager(loader=loader, sources=hosts.keys())
    inv_data = inv.get_hosts()
    inv_data.extend(inv.get_groups())

# Generated at 2022-06-23 12:55:18.207757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    sys.argv = ["ansible-playbook", "tmp.yml", "-vvvv", "-i",
                "playbook/hosts", "playbook/site.yml"]
    sys.stdin = StringIO()
    with patch('ansible.plugins.strategy.debug.LinerStrategyModule') as MockedLinerStrategyModule:
        strategy_module = debug.StrategyModule(tqm)
        mocked_init = MockedLinerStrategyModule.return_value.__init__
        assert strategy_module.debugger_active
        assert isinstance(mocked_init.call_args[0][0], MagicMock) == True


# Generated at 2022-06-23 12:55:28.264020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins import strategy_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader   
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor 

    # Load play book with debug strategy
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    inventory.get_hosts(hosts='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 12:55:29.234701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:30.249690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test if the class StrategyModule is exist"""
    startegy_module = StrategyModule(tqm = None)
    assert startegy_module is not None


# Generated at 2022-06-23 12:55:33.788799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active is True

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# DebuggerClass - Debugger class
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-23 12:55:37.435244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #
    # init
    #
    #print(dir(StrategyModule))
    #print(StrategyModule.__doc__)
    #print(StrategyModule.__init__.__doc__)
    #print(docopt.docopt(StrategyModule.__init__.__doc__, argv=['--help']))
    pass

StrategyModule.test = test_StrategyModule


# Generated at 2022-06-23 12:55:40.485029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    """
    cls_strategy = StrategyModule(tqm=None)
    assert cls_strategy.debugger_active is True


# Generated at 2022-06-23 12:55:42.515512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule(tqm)
    assert strategy_module.tqm==tqm
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:55:43.560857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:55:48.324865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("DEBUG: test_StrategyModule()")
    S = StrategyModule(None)
    assert S.debugger_active
    assert S.name == 'debug'
    assert S.display == 'debug'


# Generated at 2022-06-23 12:55:51.683443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("check constructor of class StrategyModule")
    tqm = Fake_tqm()
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy.debugger_active is True



# Generated at 2022-06-23 12:55:57.601702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock

    # Create a mock of TaskQueueManager class
    mock_tqm = mock.MagicMock()

    # Create an instance of StrategyModule
    strategy_module_instance = StrategyModule(mock_tqm)

    # Assert that debugger_active is True
    assert strategy_module_instance.debugger_active is True



# Generated at 2022-06-23 12:56:00.832368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import mock

    tqm = mock.MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Generated at 2022-06-23 12:56:03.211003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for StrategyModule")
    tqm = "tqm"
    sm = StrategyModule(tqm)


# Generated at 2022-06-23 12:56:05.562431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, LinearStrategyModule)
    assert isinstance(StrategyModule, object)



# Generated at 2022-06-23 12:56:09.643548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert issubclass(StrategyModule, cmd.Cmd)
    assert cmd.Cmd.prompt == '\n(debug) '


# Generated at 2022-06-23 12:56:10.922671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    [tqm] = args = [None]

    assert StrategyModule(tqm)



# Generated at 2022-06-23 12:56:13.485047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:56:14.655181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(StrategyModule)


# Generated at 2022-06-23 12:56:19.049567
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:56:21.055229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)


# Generated at 2022-06-23 12:56:26.325283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

    tqm = TaskQueueManager(inventory=inventory, loader=loader, stdout_callback=None)
    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True

# Mock class of callbackQueue

# Generated at 2022-06-23 12:56:34.554388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Play():
        @staticmethod
        def get_variable_manager():
            return None

    class TaskQueueManager():
        def __init__(self):
            self.stats = {}
            self.tasks_by_name = {}
            self.tasks_by_id = {}
            self.host_info = {}
            self.host_states = {}
            self.host_state = {}
            self.get_var_manager = lambda: None
            self.get_task_queue = lambda: None
            self.play = Play()
            self.callback = []
            self.listeners = []

    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    assert(sm is not None)


# Generated at 2022-06-23 12:56:35.767074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    raise NotImplementedError


# Generated at 2022-06-23 12:56:40.361305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True

    sm._tqm.send_callback('v2_playbook_on_stats', None)
    assert sm.debugger_active == False


# Generated at 2022-06-23 12:56:43.585503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_tqm = {'task_status': 'pending'}
    result = StrategyModule(temp_tqm)
    assert result.debugger_active == True


# Generated at 2022-06-23 12:56:44.520467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-23 12:56:46.910643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:56:51.626528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


    # TODO: Add test for constructor of class RemoteDebugger


# Generated at 2022-06-23 12:56:52.282852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:57.531610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.stdout_callback = 'default'

    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:57:00.625753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    StrategyModule(tqm)
    assert tqm.print.call_count == 0


# Generated at 2022-06-23 12:57:06.652213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as LStrategyModule
    from mock import MagicMock

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.tqm = MagicMock()

        def test_init(self):
            s = StrategyModule(self.tqm)
            self.assertIsInstance(s, StrategyModule)
            self.assertIsInstance(s, LStrategyModule)
            self.assertEqual(s._tqm, self.tqm)

    unittest.main()

# Generated at 2022-06-23 12:57:14.943112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.passwords = None
            self.stdout_callback = None
            self.run_tree = None
            self.hostvars = {}
            self.callback_queue = None
            self.callback_buffer = None
            self.notified_handlers = {}
            self.stats = {}
            # debug
            self.debugger_active = True

    tqm = TaskQueueManager()
    s = StrategyModule(tqm)
    assert s.tqm == tqm



# Generated at 2022-06-23 12:57:18.456961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import DebugStrategy
    tqm = DebugStrategy.tqm
    tqm.get_option = lambda option: option
    StrategyModule(tqm)
    assert True



# Generated at 2022-06-23 12:57:20.582162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stg = StrategyModule(None)
    assert(stg.debugger_active == True)


# Generated at 2022-06-23 12:57:30.341503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible import constants
    except ImportError:
        from __init__ import constants
    from ansible.cli import CLI
    cli = CLI(args=[])
    cli.options.verbosity = 0
    cli.options.inventory = False
    cli.parse()
    constants.VERBOSITY = cli.options.verbosity

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = inventory.get_variable_manager()

# Generated at 2022-06-23 12:57:30.780713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:31.684164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-23 12:57:32.636200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()



# Generated at 2022-06-23 12:57:38.972633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class test_class(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_constructor(self):
            pass

    unittest.main()


# Generated at 2022-06-23 12:57:43.345416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#    tqm = TaskQueueManager(
#        inventory=inventory,
#        variable_manager=variable_manager,
#        loader=loader,
#        options=options,
#        passwords=passwords,
#    )
#    strategy = StrategyModule(tqm)


# vim: et ts=4 sw=4

# Generated at 2022-06-23 12:57:44.640769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "Test not implemented"

# Generated at 2022-06-23 12:57:48.345706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # def __init__(self, tqm):

    #     super(StrategyModule, self).__init__(tqm)
    #     self.debugger_active = True


# Generated at 2022-06-23 12:57:52.962825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugins
    (stdin, stdout, stderr) = (None, None, None)
    tqm = plugins.loader.get_plugin('debug').get_strategy('debug').get_task_queue_manager(stdin, stdout, stderr)
    assert isinstance(tqm, TaskQueueManager)



# Generated at 2022-06-23 12:57:54.220826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = LinearStrategyModule()


# Generated at 2022-06-23 12:57:55.307300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-23 12:58:03.966022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Set up tqm
    tqm = object()
    assert not hasattr(tqm, '_noncompleted_hosts')
    assert not hasattr(tqm, '_poll_interval')
    assert not hasattr(tqm, '_final_q')
    assert not hasattr(tqm, '_failed_hosts')
    assert not hasattr(tqm, '_unreachable_hosts')

    # Instantiate class StrategyModule, then tqm is set up
    StrategyModule(tqm)
    assert hasattr(tqm, '_noncompleted_hosts')
    assert len(tqm._noncompleted_hosts) == 0
    assert hasattr(tqm, '_poll_interval')

# Generated at 2022-06-23 12:58:05.153053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule(tqm=None)
    assert test_object.debugger_active


# Generated at 2022-06-23 12:58:06.698060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)


# Generated at 2022-06-23 12:58:10.901484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

    # Testing __init__
    tqm = None
    instance_1 = StrategyModule(tqm)
    assert instance_1.debugger_active == True
    assert instance_1.tqm == None


# Generated at 2022-06-23 12:58:11.506008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:58:14.451257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # class Test(object):
    #     def __init__(self):
    #         return None
    #
    # tqm = Test()
    # strategy = StrategyModule(tqm)
    #
    # assert len(strategy)
    return True


# Generated at 2022-06-23 12:58:15.660495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 12:58:17.811818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm') is not None


# Generated at 2022-06-23 12:58:28.002856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task = Task()
    task._role = None
    task.action = 'shell'
    task.name = 'debug-shell'
    task.args['_raw_params'] = 'ls'
    task_include = TaskInclude(task=task, role=task._role)

    task = Task()
    task._role = None
    task.action = 'debug'
    task.name = 'debug-register'
    task.args['var'] = 'var1 var2'
    task.args['msg'] = 'hoge'
    task_include = TaskInclude(task=task, role=task._role)

    assert task_include.task.action == task.action


# Generated at 2022-06-23 12:58:31.188738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)
    except TypeError:
        pass

# Execution of task(s) is linear, but interaction is done by using an interactive debug session.

# Generated at 2022-06-23 12:58:33.018853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:58:37.564639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True

# # This should be for debug only
# if __name__ == '__main__':
#     test_StrategyModule()

# Generated at 2022-06-23 12:58:39.307156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # strategy = LinearStrategyModule()
    # assert(False)



# Generated at 2022-06-23 12:58:42.772594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of class StrategyModule
    obj = StrategyModule(tqm=None)
    # Check if the object is an instance of class StrategyModule
    assert isinstance(obj, StrategyModule)


# Generated at 2022-06-23 12:58:44.465877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule...")
    # Test with correct inputs.
    try:
        StrategyModule("tqm")
    except:
        print("FAILED: Should not fail with correct inputs")
    else:
        print("SUCCESS: Did not fail with correct inputs")



# Generated at 2022-06-23 12:58:54.098377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module.debugger_active == True
#

    def run(self, iterator, play_context):
        super(StrategyModule, self).run(iterator, play_context)

        #print('')
        #pprint.pprint(self._tqm._hosts.get_hosts(iterator.hosts))
        #for group in iterator.groups:
        #    print(group)

        #print('')
        #pprint.pprint(self._tqm._stats.processed)
        #print('')
        #pprint.pprint(self._tqm._stats.failures)
        #print('')
        #pprint.pprint(self._tqm._stats.dark)
        #print(''

# Generated at 2022-06-23 12:58:56.557939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = TestStrategyModule()
        StrategyModule(tqm)
        raise AssertionError("StrategyModule() was supposed to throw AssertionError")
    except AssertionError:
        pass


# Generated at 2022-06-23 12:58:59.085517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock(tqm = 'tqm')
    sm = StrategyModule(tqm)
    assert sm


# Generated at 2022-06-23 12:59:00.679281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible_debug import FakeTQM
    strategy = StrategyModule(FakeTQM)


# Generated at 2022-06-23 12:59:06.248677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stdout = sys.stdout
    stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    tqm = DummyTqm()
    StrategyModule(tqm)
    sys.stdout = stdout

# Test for method get_host_list

# Generated at 2022-06-23 12:59:16.062747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True

# Ignore the following lines so that this module can be imported by
# test_runner.py
if __name__ != "__main__":
    class InteractiveDebugger(cmd.Cmd):
        prompt = 'ansible> '
        doc_header = 'Commands: exit, list, next, print'

        def cmdloop(self, intro=None):
            print('Entered into command loop')

        def do_exit(self, arg):
            sys.exit(0)

        def do_list(self, arg):
            print('list')

        def do_next(self, arg):
            print('next')

        def do_print(self, arg):
            print(arg)


# Generated at 2022-06-23 12:59:23.359825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.plugins.strategy import debug

    class TestTaskQueueManager(unittest.TestCase):
        def setUp(self):
            self.tqm = unittest.mock.MagicMock()
            self.debugger = debug.StrategyModule(self.tqm)

        def test_constructor(self):
            assert self.debugger.tqm == self.tqm
            assert self.debugger.debugger_active == True
            assert self.debugger.strategy == 'debug'
            assert self.debugger.host_state_queue == None

    unittest.main()


# Generated at 2022-06-23 12:59:24.903210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:59:28.360551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'var': 'testvar'}
    test_object = StrategyModule(tqm)
    assert test_object.debugger_active



# Generated at 2022-06-23 12:59:32.420299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    # Assert that strategy_module is instance of LinearStrategyModule
    assert isinstance(strategy_module, LinearStrategyModule)
    # Assert that the attribute of strategy_module is True
    assert strategy_module.debugger_active is True



# Generated at 2022-06-23 12:59:41.901598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader, host_list=[])
    variable_manager = VariableManager(loader, inventory)
    play_src =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello World'))),
            ]
        )

# Generated at 2022-06-23 12:59:44.751295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Sample constructor of class StrategyModule. See program source for actual definition.
    tqm = None
    strategy_module = StrategyModule(tqm)

    # Confirm that `debugger_active` of instance `strategy_module` is equal to True.
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:59:46.792439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(tqm = None)
    assert isinstance(strategy_obj, StrategyModule)


# Generated at 2022-06-23 12:59:47.881987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:59:58.330107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.errors import AnsibleError, AnsibleParserError

    play_context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader, play_context)
    variable_manager = VariableManager(loader, inventory)

# Generated at 2022-06-23 13:00:00.810469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 0
    assert StrategyModule(test_tqm) != None



# Generated at 2022-06-23 13:00:03.272678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Host selection and ordering"


# Generated at 2022-06-23 13:00:05.206900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = 0
        StrategyModule(tqm)
    except:
        print("Cannot create a StrategyModule object")


# Generated at 2022-06-23 13:00:09.478078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stream = sys.stdout
    sys.stdout = stream
    tqm = _TQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 13:00:11.793487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running test_StrategyModule')
    obj = StrategyModule(None)
    assert(isinstance(obj, StrategyModule))



# Generated at 2022-06-23 13:00:16.226498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(1)
    assert type(obj) == StrategyModule
    assert issubclass(StrategyModule, object)
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert type(obj.debugger_active) == bool


# Generated at 2022-06-23 13:00:19.718450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = 'Try to get exception'
        StrategyModule(tqm)
    except:
        pass
# END of unit test for constructor of class StrategyModule



# Generated at 2022-06-23 13:00:21.648329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert issubclass(StrategyModule, object)


# Generated at 2022-06-23 13:00:27.373731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(object):
        def __init__(self):
            self.options = dict()
            self.options['accelerate_port'] = 5099
            self.options['accelerate_timeout'] = 30
            self.options['accelerate_connect_timeout'] = 30.5
            self.options['private_key_file'] = "key.pem"
            self.options['remote_user'] = "root"
            self.options['remote_pass'] = "root"

    t_o = Test()
    sm = StrategyModule(t_o)
    assert sm._tqm.options == t_o.options
    assert sm.debugger_active is True



# Generated at 2022-06-23 13:00:30.956013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, LinearStrategyModule)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 13:00:32.631048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1



# Generated at 2022-06-23 13:00:33.644207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)


# Generated at 2022-06-23 13:00:34.223510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:00:37.080616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')
    assert StrategyModule(tqm='tqm') != "STRATEGY MODULE"
    assert isinstance(StrategyModule(tqm='tqm'), StrategyModule)

# Tests for class Debugger

# Generated at 2022-06-23 13:00:38.245491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # todo
    pass


# Generated at 2022-06-23 13:00:40.766783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.debug
        assert True
    except:
        assert False


# Generated at 2022-06-23 13:00:43.386845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        pass

    tqm_obj = TQM()
    s = StrategyModule(tqm_obj)
    assert s.debugger_active


# Generated at 2022-06-23 13:00:46.661762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM:
        pass
    tqm = DummyTQM()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.debugger_active == True



# Generated at 2022-06-23 13:00:53.494460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list=[1,2]
    module_name="setup"
    task_name="setup"
    loaded_name="setup"
    task_vars={"result": ""}
    #self.tasks_queue.append((host, task, task_vars, loaded_name))
    # TODO:tqm is not define, so this test is not completed.
    # assert isinstance(StrategyModule(host_list, module_name, task_name, task_vars), object)



# Generated at 2022-06-23 13:00:54.461691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)


# Generated at 2022-06-23 13:00:58.767506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        obj = StrategyModule(tqm)
        obj.debugger_active = True
    except:
        assert False
    assert True


    def run(self, iterator, play_context):
        super(StrategyModule, self).run(iterator, play_context)
        self.debugger = Debugger()
        self.debugger.run()


# Generated at 2022-06-23 13:01:09.951713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    class AnsibleOptions(object):
        verbosity = 0
        inventory = None
        listhosts = None
        subset = None
        module_paths = None
        extra_vars = None
        forks = 100
        ask_vault_pass = False
        vault_password_files = []
        new

# Generated at 2022-06-23 13:01:11.006765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:01:12.812859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQMModule()
    obj = StrategyModule(tqm)
    assert obj


# Generated at 2022-06-23 13:01:14.345910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')



# Generated at 2022-06-23 13:01:15.337442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:01:16.784849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # testing constructor
    StrategyModule(tqm=None)


# Generated at 2022-06-23 13:01:17.470908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert True

# Generated at 2022-06-23 13:01:18.214241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:01:21.498456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule.tqm.send_callback('v2_playbook_on_start')
    sm = StrategyModule(test_StrategyModule.tqm)
    assert sm.debugger_active is True


# Generated at 2022-06-23 13:01:28.351164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


    def _execute_module(self, host, tmp_path, module_name, module_args, inject):
        """
        Execute a module for a given host.
        """
        if self.debugger_active:
            self.dbg.interact(host, tmp_path, module_name, module_args, inject)

        if not self.debugger_active:
            return super(StrategyModule, self)._execute_module(host, tmp_path, module_name, module_args, inject)


# Generated at 2022-06-23 13:01:32.735362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_StrategyModule = StrategyModule('tqm')
    print("test: Type of data received from constructor is: " + str(type(my_StrategyModule)))
    print("test: Value of data received from constructor: " + str(my_StrategyModule))


# Generated at 2022-06-23 13:01:40.546648
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = [host0, host1, host2]
    tqm._inventory.get_hosts = lambda: host_list
    assert len(tqm._inventory.get_hosts()) == 3

    tqm._inventory.get_hosts = lambda: host_list
    assert tqm._inventory.get_hosts() == host_list

    tqm._inventory.get_hosts = lambda: host_list
    assert tqm._inventory.get_hosts()[0].vars == host0.vars

    tqm._inventory.get_hosts = lambda: host_list
    assert len(tqm._inventory.get_hosts()[0].vars) == 2

    tqm._inventory.get_hosts = lambda: host_list

# Generated at 2022-06-23 13:01:41.261497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
