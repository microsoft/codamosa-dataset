

# Generated at 2022-06-23 12:51:41.676570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:51:50.126478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True



# Generated at 2022-06-23 12:51:52.354507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('StrategyModule test')
    class dummy_class(object):
        var = 1
    strategy_module = StrategyModule(dummy_class)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:51:54.041310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active is True


# Generated at 2022-06-23 12:51:56.292500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)



# Generated at 2022-06-23 12:51:57.663780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None
    assert isinstance(StrategyModule(None),LinearStrategyModule)


# Generated at 2022-06-23 12:52:00.233020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    # note: Couldn't find any way of reconciling the mocked TQM object with
    # the expectations of the constructor.
    with pytest.raises(TypeError):
        debug.StrategyModule(None)


# Generated at 2022-06-23 12:52:02.430235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True, "Unit tests fail!"

# Generated at 2022-06-23 12:52:03.157949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:52:04.494066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:52:06.694274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    print(module.debugger_active)
    assert module.debugger_active == True


# Generated at 2022-06-23 12:52:09.748147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import the module
    from ansible.plugins.strategy.debug import StrategyModule
    # create the test object
    strategy_module = StrategyModule('test')
    # test if the object is a StrategyModule instance
    assert isinstance(strategy_module, StrategyModule)



# Generated at 2022-06-23 12:52:18.065480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class debug_strategy_module_class:
        def __init__(self, tqm):
            self.tqm = tqm
    import ansible.plugins.strategy.linear
    debug_strategy_module_class.__bases__ = (ansible.plugins.strategy.linear.StrategyModule,)
    debug_strategy_module = debug_strategy_module_class
    tqm = 'hoge'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module.__class__.__bases__ == (debug_strategy_module,)


# Generated at 2022-06-23 12:52:19.606823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-23 12:52:22.140345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategym = StrategyModule(tqm)
    assert strategym.debugger_active == True
    # assert strategym.__init__(tqm) == None


# Generated at 2022-06-23 12:52:25.153260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active


# Execute a task, called from run()

# Generated at 2022-06-23 12:52:27.714822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.tqm is None
    assert strategy_module.debugger_active is True



# Generated at 2022-06-23 12:52:28.397482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:36.503523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    testvar1 = 'testname'
    testvar2 = 'testpass'
    testvar3 = 'testhost'
    testvar4 = 'testport'
    testvar5 = 'testuser'

    class TestConnection(object):
        def get_name(self):
            return testvar1

        def get_option(self,key):
            if key == 'ansible_password':
                return testvar2
            elif key == 'ansible_host':
                return testvar3
            elif key == 'ansible_port':
                return testvar4
            elif key == 'ansible_user':
                return testvar5
            else:
                return None

    class TestVariableManager():

        def __init__(self):
            self.extra_vars = {}


# Generated at 2022-06-23 12:52:37.072853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:39.083225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm  = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:52:44.665543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    print("")
    print("*** Unit test for StrategyModule")
    print("*** module is running as __main__")

    # create dummy task queue manager
    class DummyTQM:
        def __init__(self):
            pass
    tqm = DummyTQM()

    # just test the constructor
    sm = StrategyModule(tqm)

    print("*** unit test for StrategyModule is done")
    print("")
    sys.exit(0)



# Generated at 2022-06-23 12:52:52.163019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=display.display,
        run_tree=False,
        )
    strategy_module = StrategyModule(tqm)

# Unit test of class TaskExecutor

# Generated at 2022-06-23 12:52:55.381320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = 'Default Test Value'
   # Test with the Value in the constructor from super
   TestStrategyModule = StrategyModule( tqm )
   assert TestStrategyModule.debugger_active == True



# Generated at 2022-06-23 12:52:58.019023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule('tqm')
    print(strategymodule.debugger_active)
    assert strategymodule.debugger_active == True



# Generated at 2022-06-23 12:53:02.685055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def __init__(self):
            self.var = "test"

    tqm = TestTqm()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm

# Mock class for cmd.Cmd

# Generated at 2022-06-23 12:53:04.418737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:53:13.388227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Foo = StrategyModule()
    assert Foo.TASK_QUEUE_MANAGER.is_fact_cache() == True
    assert Foo.TASK_QUEUE_MANAGER.only_template() == False
    assert Foo.TASK_QUEUE_MANAGER.get_work_queue() == None
    assert Foo.TASK_QUEUE_MANAGER.get_notified_handlers() == {}
    assert Foo.TASK_QUEUE_MANAGER.get_dependency_manager() == None
    assert Foo.TASK_QUEUE_MANAGER.get_listening_queues() == []
    assert Foo.TASK_QUEUE_MANAGER.get_inventory() == None

# Generated at 2022-06-23 12:53:15.941296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# TODO: Execute task in linear mode, but with interactive debug session.


# Generated at 2022-06-23 12:53:18.070505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:53:21.806753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor and variables of the class.
    test_strategy = StrategyModule()

    # Assertions
    assert isinstance(test_strategy, LinearStrategyModule)
    assert hasattr(test_strategy, 'debugger_active')
    assert isinstance(test_strategy.debugger_active, bool)



# Generated at 2022-06-23 12:53:23.382366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule(None)
    assert p.debugger_active == True



# Generated at 2022-06-23 12:53:26.306450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tuple = ([], [])

    sm = StrategyModule(test_tuple)

    assert(sm.tqm == test_tuple)
    assert(sm.debugger_active)



# Generated at 2022-06-23 12:53:35.910545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import json
    import mock
    import unittest
    from ansible.plugins.strategy.linear import StrategyModule

    host_data = {'name': 'test_host'}
    host_data_json = json.dumps(host_data)

    class TestStrategyModule(unittest.TestCase):
        def test_init(self):
            test_host = mock.Mock()
            test_host.get_name.return_value = 'test_host'

            test_host_list = [test_host]

            test_playbook = mock.Mock()
            test_playbook.get_hosts.return_value = test_host_list

            test_playbook_entry = mock.Mock()
            test_playbook_entry.get_hosts.return_value = test_host_list



# Generated at 2022-06-23 12:53:41.256888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.testStrategyMod = StrategyModule(None)
        def test_debugger_active(self):
            self.assertEqual(self.testStrategyMod.debugger_active, True)
    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=3).run(suite)


# Generated at 2022-06-23 12:53:49.723507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play
    class Objects:
        pass
    option = Objects()

# Generated at 2022-06-23 12:53:52.252144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-23 12:53:54.859318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    strategy = StrategyModule('tqm')
    assert strategy.name == 'debug'
    assert strategy.debugger_active


# Generated at 2022-06-23 12:53:56.605471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()


# Generated at 2022-06-23 12:53:57.853187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:53:59.556356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor
    s = StrategyModule(None)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:54:10.273733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv[0] = 'ansible'

    from ansible.playbook import Play
    from ansible.inventory import Inventory

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager

    playbook_path = './tests/test_strategy_debug.yml'
    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list='./tests/hosts')
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    loader = DataLoader()

    passwords = dict(vault_pass='secret')


# Generated at 2022-06-23 12:54:12.562927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    T = StrategyModule()
    assert(T.debugger_active)


# Generated at 2022-06-23 12:54:14.656119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:54:17.756530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with StrategyModule(None) as module:
        assert module.debugger_active == True


# Generated at 2022-06-23 12:54:18.427535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:54:25.064476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['/usr/bin/ansible-playbook', 'test/test_strategy_debug.yml']
    tqm = TaskQueueManager(
        inventory=Inventory(PlaybookInventory(['test/test_strategy_debug.yml']), play_pattern='all'),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(listtags=False, listtasks=False, listhosts=False, syntax=False),
        passwords={},
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy.__class__.__name__ == StrategyModule.__name__
    assert strategy._tqm is tqm


# Generated at 2022-06-23 12:54:26.801660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test is not None


# Generated at 2022-06-23 12:54:28.011059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Overridden method

# Generated at 2022-06-23 12:54:30.048401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self.debugger_active = True

# Generated at 2022-06-23 12:54:33.389167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def reload_inventory():
            pass

    sm = StrategyModule(tqm)
    if sm.debugger_active:
        pass
    else:
        raise ValueError("debugger_active")


# Generated at 2022-06-23 12:54:34.889948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:54:36.183778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:40.482038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "A test tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == "A test tqm"
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:54:44.059674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTaskQueueManager(object):
        def __init__(self):
            self.stats = dict()
    tqm = MockTaskQueueManager()
    module = StrategyModule(tqm)
    assert module.tqm == tqm
    assert module.debugger_active is True



# Generated at 2022-06-23 12:54:45.410039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule(None)



# Generated at 2022-06-23 12:54:48.688384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    return strategy_module.debugger_active
assert test_StrategyModule() is True


# Generated at 2022-06-23 12:54:50.057499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_instance = StrategyModule(None)


# Used to test constructor of class StrategyModule

# Generated at 2022-06-23 12:55:00.757916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.debug"
    assert hasattr(StrategyModule, "__init__")
    assert hasattr(StrategyModule, "run")
    assert hasattr(StrategyModule, "get_host_list")
    assert hasattr(StrategyModule, "get_next_task_for_host")
    assert len(StrategyModule.__bases__) == 1
    assert StrategyModule.__bases__[0].__name__ == "LinearStrategyModule"
    assert hasattr(StrategyModule.__bases__[0], "__init__")
    assert hasattr(StrategyModule.__bases__[0], "run")

# Generated at 2022-06-23 12:55:04.709507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running test_StrategyModule...')
    # Create a instance of class StrategyModule and check the value of attribute debugger_active.
    assert StrategyModule(None).debugger_active is True
    print('test_StrategyModule passed.')


# Generated at 2022-06-23 12:55:07.198062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module.debugger_active == True)



# Generated at 2022-06-23 12:55:08.038440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__ is not None


# Generated at 2022-06-23 12:55:18.332024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:55:21.981534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule({ 'max_fail_pct': 80, 'randomize_wait': '60' })
    print(sm)
    assert hasattr(sm, 'debugger_active')
    assert True in sm.debugger_active


# Generated at 2022-06-23 12:55:25.148754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:55:27.073674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:55:31.979376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm=None)
    assert isinstance(tqm, LinearStrategyModule)
    assert tqm.debugger_active is True

# Unit test of method main_loop of class StrategyModule
#def test_StrategyModule_main_loop():


# Unit test of method get_host_list of class StrategyModule
#def test_StrategyModule_get_host_list():

# Generated at 2022-06-23 12:55:32.593306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:43.919189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Cmd(cmd.Cmd):
        '''
        Fake class for unittest of StrategyModule class
        '''
        def __init__(self):
            cmd.Cmd.__init__(self)

        def cmdloop(self):
            return

        def emptyline(self):  # pylint: disable=no-self-use
            sys.exit(0)

    class TQM:
        '''
        Fake class for unittest of StrategyModule class
        '''
        def __init__(self, hosts, callback, inventory, variable_manager, loader, options, stdout_callback, run_additional_callbacks, run_tree):
            self.hosts = hosts
            self.callback = callback
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
           

# Generated at 2022-06-23 12:55:45.768712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-23 12:55:49.188209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active
    assert isinstance(strategy_module, LinearStrategyModule)



# Generated at 2022-06-23 12:55:49.872312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:55:51.379812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 12:55:52.648856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.debugger_active == True



# Generated at 2022-06-23 12:55:54.308928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)


# Generated at 2022-06-23 12:55:57.448258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    workflow = []
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

# Unit Test for execute

# Generated at 2022-06-23 12:56:02.119622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True

# Main function.
if __name__ == '__main__':
    # Unit test for class DebugStrategyModule.
    test_StrategyModule()
    # Test for successful import of module.
    print("Successful import of module")

# Generated at 2022-06-23 12:56:09.429474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

    # Unit test for init function
    tqm = ansible.cli.CLI.setup_inventory(
        options, os.path.expanduser("~/.ansible_hosts"), True)
    sm = StrategyModule(tqm)
    assert sm is not None
    assert sm.debugger_active is True
    assert isinstance(sm.tqm, ansible.executor.task_queue_manager.TaskQueueManager)


# Override display function of class TaskQueueManager

# Generated at 2022-06-23 12:56:10.553291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule) == True


# Generated at 2022-06-23 12:56:12.100133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('Quit')
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:56:15.367573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__(self, tqm)
    raise ValueError('tqm should be defined before initialization')
#
# end of test cases for StrategyModule
#


# Generated at 2022-06-23 12:56:24.071855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import strategy_loader
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    strategy = strategy_loader.get('debug', None)

# Generated at 2022-06-23 12:56:24.526872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:27.107220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    #TODO
    #assert StrategyModule.__author__ == '!UNKNOWN'


# Generated at 2022-06-23 12:56:28.997019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:31.167454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    assert StrategyModule(tqm) != None


# Generated at 2022-06-23 12:56:32.379088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass


# Generated at 2022-06-23 12:56:33.592474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:56:34.633564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy = StrategyModule(tqm)



# Generated at 2022-06-23 12:56:45.951563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.plugins.loader import action_loader
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestTaskQueueManager(TaskQueueManager):
        def load_callbacks(self):
            pass

        def run(self):
            pass

        def _final_qc(self, worker, queue=None):
            pass

        def _terminate_processes(self):
            pass


# Generated at 2022-06-23 12:56:48.124597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


    # TODO: other tests for StrategyModule class methods
    # TODO: test for interactive debugger session
    # TODO: test for cmd.Cmd class ??


# Generated at 2022-06-23 12:56:51.154166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:52.174161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "Test not implemented"



# Generated at 2022-06-23 12:57:01.718235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    import ansible.inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=ansible.inventory.Inventory(['/dev/null']),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
    )

    pb = Playbook.load('./test/strategy_plugins/debugger/debugger_playbook.yml', tqm.loader)
    tqm._unreachable_hosts = dict()
    tqm._tqm_variables = dict()
    tqm._extra_vars = dict()
    tqm

# Generated at 2022-06-23 12:57:03.943104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule({})
    assert sm.debugger_active
    assert sm.task_queue is None
    assert sm.cleanup_queue is None
    assert sm.role_q is None
    assert sm.satisfied_deps is None


# Generated at 2022-06-23 12:57:05.688550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is True

# Generated at 2022-06-23 12:57:13.225028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  class AnsibleDebugger(object):
    def __init__(self):
      return

    def get_vars(self, play, host, task, var_name):
      return

  class Host(object):
    def get_vars(self):
      return

    def vars(self):
      return

  class Play(object):
      def __init__(self):
          return

      def get_variable_manager(self):
          return

      def get_task_vars(self, task):
          return

      def get_vars(self):
          return

  class TaskQueueManager(object):
    def __init__(self):
      self.playbook = Playbook()

  class Task(object):
    def __init__(self):
      return

    def get_name(self):
      return

 

# Generated at 2022-06-23 12:57:22.236213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == "test"
    assert strategy_module.add_tqm_variables == True
    assert strategy_module._final_q is not None
    assert strategy_module.fragment_key is not None
    assert strategy_module.progress_callback is not None
    assert strategy_module.itervars is not None
    assert strategy_module.var_manager is not None
    assert strategy_module.tmp is not None
    assert strategy_module.default_vars is not None
    assert strategy_module.inventory is not None
    assert strategy_module.host_list is not None
    assert strategy_module.noop_task is not None
    assert strategy_module.cmdline is not None
    assert strategy_

# Generated at 2022-06-23 12:57:23.350393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule(None)) == StrategyModule


# Generated at 2022-06-23 12:57:31.456684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        class Test():
            def __init__(self):
                self.hostvars = {}
        class Test2():
            def __init__(self):
                self.noop = False
        class Test3():
            def __init__(self):
                self.max_fail_percentage = 0.0
        class Test4():
            def __init__(self):
                self.display = None
                self.var_manager = Test()
                self.stats = Test2()
                self.options = Test3()
        class Test5():
            def __init__(self):
                self.cur_task = None
                self.cur_task_var = None
                self.cur_file_name = None
                self.cur_file_lines = None
                self.cur_file_num = None

# Generated at 2022-06-23 12:57:37.344900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This function is used to check __init__() function of class StrategyModule.
    """
    # Create an object of class TaskQueueManager.
    tqm = TaskQueueManager(
        inventory=InventoryManager(Loader())
    )

    # Create an object of class StrategyModule. Check if the object is created with no errors.
    strategyModule = StrategyModule(tqm)
    assert type(strategyModule) is StrategyModule

    # Check if the debugger_active is set to True as initialized.
    assert strategyModule.debugger_active is True


# Generated at 2022-06-23 12:57:40.702954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_task_queue_manager = object()
    strategy_module = StrategyModule(test_task_queue_manager)
    assert type(strategy_module) == StrategyModule



# Generated at 2022-06-23 12:57:52.418738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.module_docs as module_docs
    # Please test '__doc__' (StrategyModule.__doc__)
    print('StrategyModule.__doc__ is "%s"' % StrategyModule.__doc__)
    assert StrategyModule.__doc__ and len(StrategyModule.__doc__) > 1
    # Please test '__init__' (StrategyModule.__init__)
    assert '__init__' in dir(StrategyModule)

if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    def test_tqm():
        return None
    tqm = test_tqm()
    test_StrategyModule()

# Generated at 2022-06-23 12:57:58.488830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a class of TqmModule
    class TqmModule:
        def __init__(self):
            self.hosts = 'TqmModule instance'
    tqm = TqmModule()
    s = StrategyModule(tqm)
    assert s.debugger_active == True
    assert s.hosts == 'TqmModule instance'


# Generated at 2022-06-23 12:58:00.450985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:58:01.205201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:58:04.272667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-23 12:58:06.077619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  class FakeTQM(object):
    pass

  tqm = FakeTQM()
  assert(StrategyModule(tqm))



# Generated at 2022-06-23 12:58:07.160211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-23 12:58:07.696374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:58:08.972654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule)


# Class to implement the ansible-playbook debugger

# Generated at 2022-06-23 12:58:10.464654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:12.841885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.tqm is None
    assert sm.step is None
    assert sm.iterator is None
    assert sm.results_callback is None
    assert sm.default_variables is None
    assert sm.debugger_active is True



# Generated at 2022-06-23 12:58:25.558168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys_stdout_backup = sys.stdout
    sys.stdout = None
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True
    assert strategy_module.current_task == None
    assert strategy_module.current_task_var == None
    assert strategy_module.tasks_to_run == []
    assert strategy_module.tasks_to_cleanup == []
    assert strategy_module.task_fields == []
    assert strategy_module.task_results == {}
    assert strategy_module.task_deps == {}
    assert strategy_module.task_dep_chain == {}
    assert strategy_module.task_notified_handlers == {}
    assert strategy_module.task_vars == {}
    assert strategy_module.tasks_to_run_done == []

# Generated at 2022-06-23 12:58:27.021117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None).debugger_active == True


# Generated at 2022-06-23 12:58:31.525083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class TestAnsibleTQM: pass
        x = TestAnsibleTQM()
        sm = StrategyModule(x)
        assert sm.debugger_active == True
    except:
        assert False


# Generated at 2022-06-23 12:58:33.888924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Fix this unit test which uses "Mock"
    tqm = "Mock"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:58:41.581698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    startegyModule = StrategyModule(None)
    assert(startegyModule.debugger_active == True)
# Unit test ends
   
    def run(self, iterator, play_context):
        self.last_task_banner = None
        self.callbacks.on_start()

        # used to track execution of file_root tasks
        self._file_root_tasks = set()

        for host in self._inventory.get_hosts(iterator._play.hosts):
            self._tqm._initialize_host_variables(host)

        # send message about current strategy
        self.callbacks.display('Using ' + self._display + ' strategy', color='cyan')
        # always execute the "setup" block
        # may set self.debugger_active = False

# Generated at 2022-06-23 12:58:45.257965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, False, False, None, None, None, None)
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 12:58:46.654522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object).debugger_active == True


# Generated at 2022-06-23 12:58:54.352309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.linear import StrategyModule as test_StrategyModule
    from ansible.plugins.callback.default import CallbackModule as test_CallbackModule
    from ansible.plugins.callback.default import vvv
    from ansible.utils.color import stringc
    from ansible.plugins.action.debug import ActionModule as test_ActionModule

    test_strategy_module = test_StrategyModule(test_CallbackModule())
    test_strategy_module._tqm = test_strategy_module

    assert test_strategy_module.debugger_active == True
    assert test_strategy_module._display == vvv
    assert test_strategy_module._display.verbosity < 3
    assert test_strategy_module._tqm == test_strategy_module
    assert test_strategy_module

# Generated at 2022-06-23 12:58:59.774747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    tqm = TaskQueueManager(
            inventory=Inventory(loader=DataLoader()),
            variable_manager=VariableManager(),
            loader=DataLoader(),
            )

    s = StrategyModule(tqm)
    assert(s is not None)


#TODO: need to review this class and make it more "pythonic"

# Generated at 2022-06-23 12:59:09.684675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as debug_strategy

    #print(dir(debug_strategy))
    #print(str(debug_strategy.__doc__))
    #print(str(debug_strategy.__file__))
    #print(str(debug_strategy.__name__))
    #print(str(debug_strategy.__package__))

    debugger = debug_strategy.StrategyModule(None)
    if debugger is None:
        raise Exception("StrategyModule: Object is not created.")
    if isinstance(debugger, debug_strategy.StrategyModule):
        if not hasattr(debugger, 'debugger_active'):
            raise Exception("StrategyModule: debugger_active attribute is not defined.")

# Generated at 2022-06-23 12:59:14.592874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert not strategy_module.display.verbosity
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:59:16.695531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:59:18.184146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _printfunc()
    pass


# Generated at 2022-06-23 12:59:20.185616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule.__init__(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:59:23.693584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            StrategyModule.__init__(self, tqm)
            self.debugger_active = True
            assert tqm is not None
    test_StrategyModule(None)


# Generated at 2022-06-23 12:59:34.171523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm)
    assert a.debugger_active

# from ansible.playbook.block import Block
# from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
# from ansible.plugins.strategy.linear import TaskResult
# from ansible.utils.vars import combine_vars

# class StrategyModule(LinearStrategyModule):
#     def __init__(self, tqm):
#         super(StrategyModule, self).__init__(tqm)
#         self.debugger_active = True

#     def run(self, iterator, play_context):
#         """
#         The linear strategy will process all hosts in an iterator, in the order
#         given in the iterator and will stop processing on hosts in the iterator
#         as soon as a failure

# Generated at 2022-06-23 12:59:44.618639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self,tqm):
            super(TestStrategyModule, self).__init__(tqm)

    class FakeTQM(object):
        def __init__(self):
            class FakeTQMRun(object):
                def __init__(self):
                    self.stats = {
                        'ok': 0,
                        'dark': 0,
                        'failures': 0,
                        'processed': 0
                    }

                def _increment(self, name):
                    self.stats[name] += 1

            class FakeScheduler(object):
                def __init__(self):
                    self.serialized_queue = []
                    self.current_serialized_queue = []
                    self.pending_bundle_tasks = []

               

# Generated at 2022-06-23 12:59:45.800317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-23 12:59:47.251614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert ('StrategyModule' == StrategyModule.__name__)


# Generated at 2022-06-23 12:59:52.795940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm(object):
        def __init__(self):
            pass
    tqm = DummyTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:59:57.723509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert isinstance(obj, StrategyModule)
    assert not hasattr(obj, "debugger_active")
    obj = StrategyModule(None)
    assert isinstance(obj, StrategyModule)
    assert hasattr(obj, "debugger_active")
    assert obj.debugger_active == True

if __name__ == "__main__":
    # run unit tests
    test_StrategyModule()

# Generated at 2022-06-23 12:59:59.652321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active


# Generated at 2022-06-23 13:00:02.609065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:08.415538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialization
    if sys.version_info >= (3, 0):
        from io import StringIO
        capture_ansible_stdout = StringIO()
    else:
        from StringIO import StringIO
        capture_ansible_stdout = StringIO()
    #sys.stdout = capture_ansible_stdout
    #ansible_stdout = capture_ansible_stdout.getvalue() # this will get the output of print

    # Test
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 13:00:12.357199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, 'localhost,', None)
    test_instance = StrategyModule(tqm)
    assert test_instance.debugger_active


# Generated at 2022-06-23 13:00:14.919319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule()
    tqm = object()
    StrategyModule(tqm)



# Generated at 2022-06-23 13:00:20.894854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm: Task Queue Manager
    tqm = "tqm"
    x = StrategyModule(tqm)
    assert x.tqm == "tqm"
    assert x._callbacks == []
    assert x._display is None
    assert x._last_task_banner == None

# Class for running interactive debug session

# Generated at 2022-06-23 13:00:21.566840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:00:22.949003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-23 13:00:25.062770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) != None
# End unit test for constructor of class StrategyModule


# Generated at 2022-06-23 13:00:26.935828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None



# Generated at 2022-06-23 13:00:27.654864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:00:28.306298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:00:35.850963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    import ansible.plugins.strategy.linear
    import types

    assert issubclass(StrategyModule, LinearStrategyModule)
    assert issubclass(StrategyModule, ansible.plugins.strategy.linear.StrategyModule)
    assert issubclass(StrategyModule, object)
    assert "StrategyModule" in StrategyModule.__name__
    assert isinstance(StrategyModule.__init__, types.FunctionType)



# Generated at 2022-06-23 13:00:36.581250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:00:38.692508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=too-many-function-args
    StrategyModule('tqm')



# Generated at 2022-06-23 13:00:43.102270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule  # verify class exists

    # verify class can be instantiated and has the properties we need
    sm = StrategyModule(None)
    assert hasattr(sm, '_tqm')
    assert hasattr(sm, 'debugger_active')


# Generated at 2022-06-23 13:00:44.849330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running simple unit test')
    StrategyModule(tqm='tqm')
    return True



# Generated at 2022-06-23 13:00:48.574019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing constructor of class StrategyModule
    tqm = None
    try:
        tqm = StrategyModule(tqm)
    except TypeError:
        assert False, 'Constructor of StrategyModule() raises unexpected TypeError'
    assert True, 'Constructor of StrategyModule() does not raise TypeError'



# Generated at 2022-06-23 13:00:52.614271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up environment for StrategyModule
    tqm = None

    # Create object for class StrategyModule
    test_strategymodule = StrategyModule(tqm)

    assert test_strategymodule.debugger_active == True

# Unit test to check the function run of class StrategyModule

# Generated at 2022-06-23 13:01:00.309524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    tqm = TaskQueueManager()
    
    assert not hasattr(tqm, 'debugger_active')
    assert not hasattr(tqm, 'inventory')
    assert not hasattr(tqm, 'variable_manager')
    assert not hasattr(tqm, 'loader')
    assert not hasattr(tqm, 'tqm_vars')
    assert not hasattr(tqm, 'options')
    assert not hasattr(tqm, 'passwords')
    assert not hasattr(tqm, 'results_callback')
    assert not hasattr(tqm, 'host_failed_callback')
    assert not hasattr(tqm, 'host_ok_callback')

# Generated at 2022-06-23 13:01:01.048819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:01:02.688712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 13:01:04.579434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

    sm = StrategyModule()
    assert(sm.__class__ == StrategyModule)



# Generated at 2022-06-23 13:01:06.912388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module
    assert strategy_module.debugger_active


# Generated at 2022-06-23 13:01:16.802566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Borrowed from this page
    # http://www.voidspace.org.uk/python/mock/examples.html#dealing-with-mocking-magic-methods
    class NonCallableMagicMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def __getattr__(self, name):
            attr = NonCallableMagicMock(name)
            return attr

    tqm = NonCallableMagicMock()
    s = StrategyModule(tqm)
    assert hasattr(s, 'tqm')
    assert hasattr(s, 'debugger_active')
    assert not hasattr(s, 'items')
    assert not hasattr(s, 'iterator')


# Generated at 2022-06-23 13:01:19.324592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strag = StrategyModule(tqm)
    assert strag is not None
    assert strag.debugger_active is True


# Generated at 2022-06-23 13:01:20.862752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('', (), {})()
    assert StrategyModule(tqm)



# Generated at 2022-06-23 13:01:24.783045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    obj = StrategyModule(tqm)
    assert obj is not None
    assert obj.debugger_active is True


# Generated at 2022-06-23 13:01:27.513010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__base__ == type
    assert issubclass(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-23 13:01:29.403519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

#####################################################################



# Generated at 2022-06-23 13:01:31.234181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # StrategyModule.__init__(self, tqm)


# Generated at 2022-06-23 13:01:39.265542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import sys
    import tempfile
    import filecmp
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.linear as linear
    import ansible.plugins.strategy.linear as linear
    import ansible.utils.template as template
    import ansible.plugins.loader as loader
    import ansible.plugins.lookup as lookup
    import ansible.plugins.callback as callback
    import ansible.plugins.connection as connection
    import ansible.plugins.vars.vars as vars

    import ansible.template as template
    import ansible.playbook.play as play
    import ansible.playbook.playbook as playbook
    import ansible.playbook.task_include as task_include
    import ansible.vars.manager as manager

# Generated at 2022-06-23 13:01:41.341457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)
    assert isinstance(StrategyModule(None), LinearStrategyModule)
    assert len(StrategyModule(None).__dict__) == 3
