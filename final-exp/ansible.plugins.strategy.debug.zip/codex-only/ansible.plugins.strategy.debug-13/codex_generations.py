

# Generated at 2022-06-23 12:51:42.485624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
# End of unit test for constructor of class StrategyModule


# Generated at 2022-06-23 12:51:47.350398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = {}
    b = {}
    c = { 'a': a, 'b': b }
    d = { 'a': a, 'b': b, 'c': c }
    a['d'] = d
    b['d'] = d
    c['d'] = d
    d['d'] = d
    pprint.pprint(a)

# Generated at 2022-06-23 12:51:50.815083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert LinearStrategyModule
    tqm = StrategyModule
    assert tqm
    tqm = LinearStrategyModule
    assert tqm


# Generated at 2022-06-23 12:51:52.320365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	# BUG: Todo test code
	return False


# Generated at 2022-06-23 12:51:54.709240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm object")
    assert sm.debugger_active == True
    assert sm.tqm



# Generated at 2022-06-23 12:51:56.718839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:52:06.289994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Tqm = pprint.PrettyPrinter().pformat
    _tqm = Tqm()
    myStrategyModule = StrategyModule(_tqm)
    assert myStrategyModule.debugger_active == True
    assert myStrategyModule._tqm == _tqm
    assert myStrategyModule.run_once == False
    assert myStrategyModule.host_results == {}
    assert myStrategyModule.workers_count == DEFAULT_WORKERS
    assert myStrategyModule.encourage_workers_to_exit == False
    assert myStrategyModule.result_q is None
    assert myStrategyModule._inventory is None
    assert myStrategyModule._play is None
    assert myStrategyModule.status_display is None
    assert myStrategyModule._last_task_banner is None

# Unit test

# Generated at 2022-06-23 12:52:07.871848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-23 12:52:17.716903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('test', (object,), {'tasks': [], 'failed_hosts': []})
    st = StrategyModule(tqm)
    assert st.tqm == tqm 
    assert st.debugger_active == True 
    assert st.host_list == [] 
    assert st.sort_queue == [] 
    return st
# Unit test: test.test_strategy.StrategyModule.test_StrategyModule

#    def add_tasks(self, new_tasks):
#        return super(StrategyModule, self).add_tasks(new_tasks)

#    def run_queued_tasks(self, host, queue, is_conditional):
#        return super(StrategyModule, self).run_queued_tasks(host, queue, is

# Generated at 2022-06-23 12:52:19.005896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    assert False


# Generated at 2022-06-23 12:52:21.072578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule("")
    assert test_strategy_module.debugger_active is True


# Generated at 2022-06-23 12:52:25.686049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__doc__ == 'Executes tasks in interactive debug session.\n'
    assert StrategyModule.__init__ != LinearStrategyModule.__init__
    assert StrategyModule.run != LinearStrategyModule.run



# Generated at 2022-06-23 12:52:29.497684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Test constructor of class StrategyModule")
    try:
        tqm = TaskQueueManager()
        strategy_module = StrategyModule(tqm)
        print ("Test passed")
    except:
        print ("Test failed")
    return


# Generated at 2022-06-23 12:52:32.562233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ()
    a = StrategyModule(tqm)
    assert a.debugger_active == True
    assert a.tqm == tqm
    assert a.is_debugger_enabled == True


# Generated at 2022-06-23 12:52:35.248115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # tqm = None
    # obj = StrategyModule(tqm)
    # print obj
    # print obj.debugger_active


# Generated at 2022-06-23 12:52:38.396108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm():
        def __init__(self):
            pass

    d_tqm = DummyTqm()
    strategy_module = StrategyModule(d_tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:52:44.119350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
            self.current_task = None
            self.play = None

    tqm = TestStrategyModule(None)
    assert tqm.current_task is None
    assert tqm.play is None
    assert tqm.debugger_active



# Generated at 2022-06-23 12:52:47.731475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = Host()
    std = Std()
    tqm = TaskQueueManager(std, host)
    StrategyModule(tqm)


# Generated at 2022-06-23 12:52:57.772808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#    assert False, "Test if the testcase is working."

    # In Linux:
    #   echo '#!/bin/bash' > debugger.sh
    #   echo 'tasks: ' >> debugger.sh
    #   echo '  - debug:' >> debugger.sh
    #   echo '      var: show_me' >> debugger.sh
    #
    #   echo '- hosts: all' > hosts
    #   echo '  remote_user: root' >> hosts
    #   echo '  gather_facts: false' >> hosts
    #
    #   echo 'show_me: This is a test.' > ansible.cfg
    #   echo 'library = /root/ansible/module_utils'
    #
    #   echo 'export ANSIBLE_CONFIG=ansible.cfg'
    #   echo "

# Generated at 2022-06-23 12:53:07.714579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        def __init__(self, callback=None):
            self.hostvars = {}
            self.hosts = {}
            self.callback = callback

    tqm = TQM()

    sm = StrategyModule(tqm)

    assert(sm.tqm == tqm)
    assert(sm.host_name == None)
    assert(sm.host_queue == [])
    assert(sm.step == 0)
    assert(sm.last_step == 0)
    assert(sm.last_step_host == {})
    assert(sm.aggregated_results == {})
    assert(sm.debugger_active == True)


# Generated at 2022-06-23 12:53:09.467248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategy = StrategyModule(tqm)



# Generated at 2022-06-23 12:53:11.902469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:53:17.400675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.MagicMock()
    SModule = StrategyModule(tqm)
    assert SModule is not None
    assert SModule.debugger_active == True
    assert SModule.tqm == tqm


# Generated at 2022-06-23 12:53:18.909719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:53:25.439226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy:
        pass
    dummy = Dummy()
    dummy.host_state = {}
    dummy.host_state['hostname'] = 'fqdn'
    dummy.hostvars = {}
    dummy.hostvars['fqdn'] = {}
    dummy.hostvars['fqdn']['inventory_hostname'] = 'hostname'
    test_module = StrategyModule(dummy)
    assert test_module.tqm == dummy



# Generated at 2022-06-23 12:53:26.874959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:27.362551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Generated at 2022-06-23 12:53:29.087113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule,object)


# Generated at 2022-06-23 12:53:34.146629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    params = {'_ansible_check_mode': False, '_ansible_no_log': False}
    tqm_test = TestTQM(host_list=[])
    mod_test = StrategyModule(tqm_test)
    assert mod_test.debugger_active == True
    return


# Generated at 2022-06-23 12:53:43.518546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible
    sys.modules['ansible'] = ansible
    from ansible.plugins.strategy.debug import StrategyModule as DebugStrategyModule

    class TestTQM(object):
        def __init__(self):
            self.workers = 4
            self.jobs = 10
            self.start_at_done = True
            self.send_worker_msg = True

        def _do_queue_results(self, hosts):
            print(hosts)

        def cleanup(self):
            print('cleanup')

        def get_socket_path(self):
            return '/tmp/test'

        def run_handlers(self):
            print('run_handlers')

    tqm = TestTQM()
    #tqm = TestTQM(['localhost'],None,None,None,None,

# Generated at 2022-06-23 12:53:47.146896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    tm = StrategyModule(tqm)
    # tm is not a null
    assert tm is not None
    # tm has correct debuger_active
    assert tm.debugger_active is True


# Generated at 2022-06-23 12:53:49.621190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s != None
    assert s.debugger_active == True

# print debugging helper

# Generated at 2022-06-23 12:53:54.907003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    assert StrategyModule.__bases__[0].__name__ == 'LinearStrategyModule'
    assert len(StrategyModule.__init__.__defaults__) == 0
    assert StrategyModule.__init__.__code__.co_argcount == 2



# Generated at 2022-06-23 12:53:57.511152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:54:02.247495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {"test": "test"}
    test_mod = StrategyModule(tqm)
    test_mod.debugger_active = True
    assert test_mod.debugger_active == True, 'Actual: %s' % test_mod.debugger_active


# Generated at 2022-06-23 12:54:05.313020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(getattr(StrategyModule, 'tqm'))
    assert(getattr(StrategyModule, 'debugger_active'))


# Generated at 2022-06-23 12:54:07.113386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active


# Generated at 2022-06-23 12:54:07.818439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:54:10.580766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class _tqm:
        def _load_callbacks(self):
            return None

    a = _tqm()
    sm = StrategyModule(a)
    assert sm.debugger_active


# Generated at 2022-06-23 12:54:11.285832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:54:12.929785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-23 12:54:22.376259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.debugger_active == True
    
    #assert sm.__class__ == StrategyModule
    #assert sm.host_state == None
    #assert sm.loader == None
    #assert sm.templar == None
    #assert sm.tqm == 'tqm'
    #assert sm.result == None
    #assert sm.results == {}
    #assert sm.runner_retries == 0
    #assert sm.runner_retry_interval == 1
    #assert sm.variable_manager == None


# Generated at 2022-06-23 12:54:26.131017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule constructor")
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.terminated == False


# Generated at 2022-06-23 12:54:27.345564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:54:28.589343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()


# Generated at 2022-06-23 12:54:36.722287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global debug_playbook
    global debugger_active
    task1 = Task()
    task2 = Task()
    host1 = Host()
    host2 = Host()
    task1.set_name('TASK 1', 'TASK 1')
    task1.set_action('ACTION 1', 'ACTION 1')
    task2.set_name('TASK 2', 'TASK 2')
    task2.set_action('ACTION 2', 'ACTION 2')
    host1.set_name('HOST 1', 'HOST 1')
    host1.add_task(task1)
    host1.add_task(task2)
    host2.set_name('HOST 2', 'HOST 2')
    host2.add_task(task1)
    host2.add_task(task2)
    play

# Generated at 2022-06-23 12:54:38.408580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#
# Demo code for implementing a debug session
#

# Generated at 2022-06-23 12:54:40.428964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# end of unit test of test_StrategyModule()


# Generated at 2022-06-23 12:54:45.080626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager():
        def __init__(self):
            self._tasks = []

        def add_task(self, task):
            self._tasks.append(task)

        def get_tasks(self):
            return self._tasks

    tqm = TestTaskQueueManager()
    strategy_obj = StrategyModule(tqm)
    assert not tqm.get_tasks()



# Generated at 2022-06-23 12:54:45.767587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:54:47.583470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)


# Generated at 2022-06-23 12:54:49.146610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-23 12:54:56.497442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.loader as plugins

    class TestStrategyModule(unittest.TestCase):
        def test_constructor(self):
            # Test : initialize class variable
            strategy_module_class = plugins.get_strategy_plugin(__name__)
            strategy = strategy_module_class(tqm={'tasks': []})
            assert strategy.name == 'debug'
            assert strategy.debugger_active == True

    unittest.main()


# Generated at 2022-06-23 12:54:59.172664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test1 = StrategyModule(tqm)
    assert test1.debugger_active



# Generated at 2022-06-23 12:55:01.201966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug_class = StrategyModule()
    assert debug_class.__class__.__name__ == 'StrategyModule'



# Generated at 2022-06-23 12:55:02.885353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class test_class(StrategyModule):
            pass
        assert(True)
    except AssertionError:
        assert(False)


# Generated at 2022-06-23 12:55:04.657829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-23 12:55:06.148921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-23 12:55:14.233338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include

    tqm = ansible.playbook.task_queue_manager.TaskQueueManager(inventory=None, variable_manager=None, loader=None)
    sm = StrategyModule(tqm)
    assert sm.current_task == None
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:55:18.119703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        pass
    from ansible.plugins.strategy.debug import StrategyModule
    sm = StrategyModule(tqm())
    assert sm.name == 'debug'
    assert sm.debugger_active

# init_runner_by_task_queue

# Generated at 2022-06-23 12:55:20.925166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule
    except:
        raise AssertionError("StrategyModule method not defined.")
    return
test_StrategyModule()


# Generated at 2022-06-23 12:55:32.291558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include

    task_vars = dict()
    play_vars = dict()


# Generated at 2022-06-23 12:55:34.121309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Test loop without errors.
    assert True == True


# Generated at 2022-06-23 12:55:35.916109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule('')


# Generated at 2022-06-23 12:55:38.156848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    LinearStrategyModule.module_utils = True
    strategymodule = StrategyModule(True)
    assert strategymodule.debugger_active


# Generated at 2022-06-23 12:55:39.569198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:55:40.097652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:41.252322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
#------------------------------------------------------------------------------


# Generated at 2022-06-23 12:55:41.820036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:43.765795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test target
    strategy = StrategyModule(None)
    assert strategy.debugger_active



# Generated at 2022-06-23 12:55:44.710786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:55:52.121710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_vars = dict()
    loader = None
    variable_manager = None
    inventory = None
    options = dict()
    options['verbosity'] = 0
    options['debug'] = True
    options['diff'] = False
    options['connection'] = 'local'

    tqm = None
    sm = StrategyModule(tqm)
    sm.run(global_vars, loader, variable_manager, inventory, options)



# Generated at 2022-06-23 12:55:54.970628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = getattr(StrategyModule(None), 'debugger_active', None)
    assert debugger_active is True



# Generated at 2022-06-23 12:55:56.836240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Unit test for constructor of class StrategyModule
    pass


# Generated at 2022-06-23 12:55:59.199398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass
#    raise NotImplementedError()

# Test for method of class StrategyModule

# Generated at 2022-06-23 12:56:01.798000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TaskQueueManager = TaskQueueManager({})
    StrategyModule = StrategyModule(TaskQueueManager)
    assert hasattr(StrategyModule, 'debugger_active')


# Generated at 2022-06-23 12:56:11.814788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert isinstance(strategy._display, pprint.PrettyPrinter)


    class TestCommand(cmd.Cmd):
        def __init__(self, strategy, tqm):
            cmd.Cmd.__init__(self)
            self.strategy = strategy
            self.tqm = tqm

        def do_task(self, line):
            '''Simply run a task and move on to the next one'''
            self.strategy._tqm.send_callback(
                'v2_playbook_on_task_start',
                task=self.strategy._tqm._current_task
            )

# Generated at 2022-06-23 12:56:14.127950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if StrategyModule is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-23 12:56:16.225243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None


# Generated at 2022-06-23 12:56:22.797435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s is not None
    assert s.debugger_active is True

# This method is called in Ansible
    def run(self, iterator, play_context):

        # initialize callback, which is needed for Ansible
        super(StrategyModule, self).run(iterator, play_context)
        hosts = sorted(iterator._hosts, key=lambda h: h.name)

        p = DebugPrompt()
        p.prompt = 'ansible> '

        while self.debugger_active:
            try:
                p.cmdloop()

                if p.stop:
                    # @todo: save some play state to disk so we can resume.
                    return
                self.run_once(hosts, iterator)
            except KeyboardInterrupt:
                break

        return


# Generated at 2022-06-23 12:56:23.279924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:24.676046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Generate test case
    assert True


# Generated at 2022-06-23 12:56:27.971839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm).debugger_active == True
    assert StrategyModule(tqm).tqm == None
    assert StrategyModule(tqm).done == False

# class Debugger

# Generated at 2022-06-23 12:56:29.326088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    StrategyModule(debugger_active)


# Generated at 2022-06-23 12:56:32.485911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = None
    strategyModule = StrategyModule(mock_tqm)
    assert strategyModule.debugger_active == True



# Generated at 2022-06-23 12:56:33.387920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 12:56:34.907529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This test case was added for unit test of constructor of class StrategyModule
    a = StrategyModule(tqm=1)



# Generated at 2022-06-23 12:56:37.177505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        assert False, "StrategyModule Constructor test failed."


# Generated at 2022-06-23 12:56:39.374635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_vars = dict()
    global_vars['hostvars'] = dict()
    tqm = dict()
    tqm['hostvars'] = global_vars['hostvars']
    tqm['inventory'] = dict()

    # Create an object of class StrategyModule
    assert StrategyModule(tqm)


# Generated at 2022-06-23 12:56:42.321851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for constructor of class StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None



# Generated at 2022-06-23 12:56:44.647724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert True == StrategyModule(tqm).debugger_active


# Generated at 2022-06-23 12:56:46.311046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert LinearStrategyModule.__doc__ is not None



# Generated at 2022-06-23 12:56:48.323505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_debug.setUp()
    strategy_debug._make_mod_args('debug')
    strategy_debug.StrategyModule
    strategy_debug.tearDown()


# Generated at 2022-06-23 12:56:53.467103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # case 1
    test_tqm = {
        'somevar1': 'abc',
        'somevar2': 123,
    }

    obj = StrategyModule(test_tqm)
    assert obj._tqm == test_tqm
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:56:58.961232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['_ansible_remote_tmp'] = __import__('_ansible_remote_tmp')
    __import__('ansible.plugins.strategy.linear')
    sys.modules['ansible.plugins.strategy.linear'].StrategyModule = StrategyModule
    __import__('ansible.plugins.strategy.debug')



# Generated at 2022-06-23 12:57:01.525740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert test.debugger_active



# Generated at 2022-06-23 12:57:04.199609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule...")
    objStrat = StrategyModule(None)
    assert objStrat.debugger_active



# Generated at 2022-06-23 12:57:06.212689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj is not None


# Generated at 2022-06-23 12:57:07.379811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:57:08.922284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None


# Generated at 2022-06-23 12:57:12.225074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.tqm == tqm
    assert strategy.debugger_active


# Generated at 2022-06-23 12:57:12.946841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:14.258474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:57:22.927224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    # construct a FakeTaskQueueManager
    FakeTaskQueueManager = collections.namedtuple(
        'FakeTaskQueueManager', ['host_vars', 'inventory', 'play', 
        'stats', 'options', 'variable_manager'])

# Generated at 2022-06-23 12:57:23.916004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 12:57:25.273777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(None).debugger_active)



# Generated at 2022-06-23 12:57:29.249829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTaskQueueManager:
        def __init__(self):
            pass
    dummy_tqm = DummyTaskQueueManager()
    StrategyModule(dummy_tqm)


# Generated at 2022-06-23 12:57:33.636300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    sm = StrategyModule(tqm)
    assert sm.tqm == 0
    assert sm.get_host_list() == []
    assert sm.get_next_task_lock() == None
    assert sm.get_next_task_for_host(1) == None
    assert sm.run() == False
    assert sm.run_handlers() == False
    assert sm.cleanup() == False
    assert sm.cleanup_tasks() == False
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:57:39.843112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    # Check if StrategyModule class attributes are properly initialized
    assert isinstance(strategy_module, LinearStrategyModule)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:57:42.665776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    s = StrategyModule(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:57:44.933340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:57:50.598964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestObject(object):
        def __init__(self,tqm):
            self.tqm = tqm

        def __repr__(self):
            return "debugger_class"

    tqm = TestObject(None)
    sm=StrategyModule(tqm)
    assert repr(sm) == "debugger_class"


# Generated at 2022-06-23 12:57:54.097146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: make a test instance of TaskQueueManager
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-23 12:57:56.649503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:57:59.483275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        pass
    tqm = Tqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm is tqm
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:58:02.313639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1, "Just a test"

sys.modules['ansible.plugins.strategy.debug'] = sys.modules[__name__]

# Generated at 2022-06-23 12:58:13.118704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queues = [dict() for i in range(5)]
    tqm = dict(task_queues=task_queues)
    strategy_module = StrategyModule(tqm)
    assert(strategy_module.task_queue_manager == tqm)
    assert(strategy_module.RUN_STATE_ERROR == 'ERROR')
    assert(strategy_module.RUN_STATE_UNREACHABLE == 'UNREACHABLE')
    assert(strategy_module.RUN_STATE_FAILED == 'FAILED')
    assert(strategy_module.RUN_STATE_OK == 'OK')
    assert(strategy_module.iterator == None)
    assert(strategy_module.iterator_task_list == None)
    assert(strategy_module.debugger_active == True)


# Generated at 2022-06-23 12:58:20.872112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n***** UNIT TEST of StrategyModule.__init__ *****")
    try:
        x = StrategyModule(tqm=None)
        print("SUCCESS: StrategyModule.__init__")
    except:
        print("FAIL: StrategyModule.__init__")
    print("***** UNIT TEST of StrategyModule.__init__ *****\n")
        
# Test for AnsibleModule

# Generated at 2022-06-23 12:58:22.157159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategy = StrategyModule(tqm)

    assert strategy.debugger_active



# Generated at 2022-06-23 12:58:29.494909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


    def run(self, iterator, play_context):
        cmd.Cmd.__init__(self)
        self.iterator = iterator
        self.play_context = play_context
        self.prompt = ''
        self.intro = '\n\n' + '*'*76 +\
        '\nStarted / paused / stopped (!run / !continue / !omit) / executed (!next / !step) ' +\
        'each module.\n' + '*'*76 + '\n'
        if self.play_context.verbosity > 0:
            self.intro += 'Verbosity turned on. Use !verbose and !verbose off to turn it off/on.\n'
            self.intro += 'Use !help for a list of available commands.\n'
            self

# Generated at 2022-06-23 12:58:36.561503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active == True

# ---------------------------
# Context
# ---------------------------

    def get_context(self, host, task, include_vars=True):
        """
        returns a Context object of the current host and task.
        """
        # run_once here is very intentional instead of get_play()
        # as the play context includes the task_vars which is the
        # "merged" version with inventory vars, which overwrites vars
        # which we do not want.  This is mostly in place to provide
        # the include_vars=False option for use later in the queue_item
        # to reduce memory overhead of having every variable for
        # every host held in memory.  With this memory overhead is
        # only per

# Generated at 2022-06-23 12:58:41.943189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.result_q = []
            self.worker_q = []
    tqm = TestTQM()
    test_module = StrategyModule(tqm)
    assert test_module.debugger_active == True


# Generated at 2022-06-23 12:58:43.868114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Generated at 2022-06-23 12:58:46.955356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    debugger_active = True
    debugger_active_result = bool(debugger_active)
    assert debugger_active_result == True, "Debugger state is not activated"



# Generated at 2022-06-23 12:58:49.249478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(estrategy=None)
    assert obj is not None
    assert isinstance(obj, StrategyModule)
    assert obj.debugger_active==True



# Generated at 2022-06-23 12:58:50.642708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'debugger_active' in StrategyModule.__dict__



# Generated at 2022-06-23 12:58:53.202550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        my_debug = StrategyModule(tqm)
        my_debug.debugger_active = True
        print("StrategyModule constructor works")
    except:
        print("StrategyModule constructor issue")



# Generated at 2022-06-23 12:58:54.557840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:58:55.619028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    assert LinearStrategyModule is not None


# Generated at 2022-06-23 12:58:57.375265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(False)


# Generated at 2022-06-23 12:58:58.542741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:58:59.916437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:59:03.609576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test Execution
    strategy_module = StrategyModule(tqm=None)
    # Verification
    assert strategy_module.debugger_active == True

# Test for function get_host_list

# Generated at 2022-06-23 12:59:04.312112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False

# Generated at 2022-06-23 12:59:09.848397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TASK_QUEUE_MANAGER():
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None, run_additional_callbacks=True, run_tree=False):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = passwords
            self.stdout_callback = stdout_callback
            self.run_additional_callbacks = run_additional_callbacks
            self.run_tree = run_tree
    class Inventory():
        def __init__(self, host_list=None, source=None, loader=None, variable_manager=None, plugin_manager=None):
            self.host_list = host_list
            self.source = source

# Generated at 2022-06-23 12:59:13.108937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger = StrategyModule(tqm=None)
    assert debugger.debugger_active == True



# Generated at 2022-06-23 12:59:19.418352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # @classmethod
    # def get_host_list(cls, inventory):
    #     return inventory.get_hosts()
    #
    # def run(self, play):
    #     self.play = play
    #     self.tqm._send_callback('v2_playbook_on_play_start')
    #     hosts = self.get_host_list()
    #     result = self.run_sequential(hosts)
    #     self.tqm._send_callback('v2_playbook_on_play_start')
    #     return result
    #
    # def run_sequential(self, hosts):
    #     # sequential is a generator that yields return state
    #     sequential = self._tqm.get_iterator(hosts, self._tqm._

# Generated at 2022-06-23 12:59:19.913350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:23.303429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The task queue manager for this strategy.
    tqm = None
    # Create a StrategyModule object.
    sm = StrategyModule(tqm)
    # Verify that debugger_active attribute is True.
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:59:29.406006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    strategy_module = StrategyModule(task_queue_manager)
    assert str(strategy_module) == '<ansible.plugins.strategy.debug.StrategyModule object at 0x1069c6a10>'
    assert strategy_module.debugger_active == True

#
# Interactive Debugger Commands
#


# Generated at 2022-06-23 12:59:32.095084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:59:32.959049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('__init__')


# Generated at 2022-06-23 12:59:33.482863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:35.378855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active == True

# Unittest for constructor of class TaskDebugger

# Generated at 2022-06-23 12:59:42.817535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        host_list='dummy_hosts',
        inventory='dummy_inventory',
        variable_manager='dummy_variable_manager',
        loader='dummy_loader',
        passwords='dummy_passwords',
        stdout_callback='dummy_stdout_callback',
    )
    # Unit test
    dbg = StrategyModule(tqm)
    assert 'debugger_active' in dbg.__dict__.keys()
    assert dbg.debugger_active == True


# Generated at 2022-06-23 12:59:46.002297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    try:
        tqm = __import__('tqm')
        StrategyModule(tqm)
    except ImportError:
        pass



# Generated at 2022-06-23 12:59:57.096232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', 'test.yml', '-vvvvvvvvvvvvvvvvvvv', '-i', 'localhost']
    print("Argv: ", sys.argv)

    # create a test object
    class test_object:
        class args():
            verbosity = 18
            inventory = None
            subset = 'localhost'
            module_path = None
            forks = 5
            become = False
            become_method = None
            become_user = None
            check = False
            listhosts = None
            listtasks = None
            listtags = None
            syntax = None
            step = None
            start_at_task = None
            diff = False
            
            class connection():
                class vars():
                    ansible_connection = 'local'
            

# Generated at 2022-06-23 13:00:07.486837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global host_result

    def get_host_result(host):
        return host_result[host]

    def get_host_result_empty(host):
        return {}

    class TestTQM:
        host_result = {}

        def get_host_result(self, host):
            return host_result[host]

        def get_host_result_empty(self, host):
            return {}

    host_result = {
        'host0': {
            'task0': {
                'action': 'test0',
                'task': 'task0',
                'play': 'play0',
            },
            'task1': {}
        }
    }
    tqm = TestTQM()
    test = StrategyModule(tqm)
    assert test.debugger_active

# Generated at 2022-06-23 13:00:08.493226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return ('result', '')


# Generated at 2022-06-23 13:00:12.116746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'stdin': sys.stdin}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:14.446886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-23 13:00:17.074172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_tqm = None
  test_stmod = StrategyModule(test_tqm)
  assert isinstance(test_stmod, StrategyModule)
  assert test_stmod.debugger_active == True


# Generated at 2022-06-23 13:00:18.457342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)



# Generated at 2022-06-23 13:00:19.525020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info[0] == 3:
        assert False


# Generated at 2022-06-23 13:00:27.185529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unit_tests.utils as utils
    import tempfile
    import os
    import shutil
    import sys

    tmpdir = tempfile.mkdtemp()
    test_inventory = utils.make_temp_inventory(tmpdir, 'test_inventory.txt')
    test_playbook = utils.make_temp_playbook(tmpdir, 'test_playbook.yml')
    test_module = utils.make_temp_playbook(tmpdir, 'test_playbook.py')

    sys.path.append(tmpdir)
    from test_playbook import TestPlaybook
    module_class = TestPlaybook

    test_tqm = utils.FakeTaskExecutionManager(None, None, None)
    test_tqm.set_inventory(test_inventory)

# Generated at 2022-06-23 13:00:30.806716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None, "Failed constructing StrategyModule"
    assert strategy_module.debugger_active == True, "Failed initialising debugger_active variable in StrategyModule"



# Generated at 2022-06-23 13:00:33.874600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'task queue manager'
    strategy = StrategyModule(tqm)
    assert(strategy.debugger_active == True)

# Main function

# Generated at 2022-06-23 13:00:39.976778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("test StrategyModule")
    tqm = None
    sm = StrategyModule(tqm)
    print("sm=" + str(sm))
    print("sm.debugger_active=" + str(sm.debugger_active))
    print("sm.tqm=" + str(sm.tqm))
    print("sm.host_vars_files=" + str(sm.host_vars_files))
    print("sm.group_vars_files=" + str(sm.group_vars_files))
    print("sm.inventory=" + str(sm.inventory))
    print("sm.play_context=" + str(sm.play_context))
    print("sm.loader=" + str(sm.loader))
    print("sm.templar=" + str(sm.templar))

# Generated at 2022-06-23 13:00:43.243187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm: pass
    tqm = Tqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == tqm


# Generated at 2022-06-23 13:00:44.751189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active



# Generated at 2022-06-23 13:00:45.844404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:00:49.119489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert tqm is strategy.tqm
    assert strategy.debugger_active


# Generated at 2022-06-23 13:00:53.609615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True

# -------------------------------------------------
# Command line interface
# 
# As the strategy is the "main program",
# we should emulate the command line interface
# (argparse, etc...) giving the users the
# ability to specify at least task_id
# -------------------------------------------------


# Generated at 2022-06-23 13:00:57.597542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=True,
        # Now we inject 'debug' as strategy in order to test the debugger
        strategy='debug'
    )

# taken from cmd.py, which is not available in python3
# https://docs.python.org/2/library/cmd.html

# Generated at 2022-06-23 13:00:58.684484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule != None)



# Generated at 2022-06-23 13:01:00.184824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')


# Generated at 2022-06-23 13:01:03.257910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    name = 'test'
    tqm = 'tqm'
    assert StrategyModule(tqm).__init__(tqm) == None


# Generated at 2022-06-23 13:01:04.325474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-23 13:01:08.107965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert True == True
        print("Unit test for constructor of class StrategyModule is PASSED!")
    except AssertionError:
        print("Unit test for constructor of class StrategyModule is FAILED!")


# Generated at 2022-06-23 13:01:09.300081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible.plugins.strategy.debug.StrategyModule(tqm)



# Generated at 2022-06-23 13:01:10.675066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:01:12.315873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Return an initialized class"""
    return StrategyModule(tqm='test')


# Generated at 2022-06-23 13:01:20.652630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.constants
    import ansible.inventory
    import ansible.playbook

    myvar = ansible.constants.DEFAULT_HASH_BEHAVIOUR
    pass
#
# class DebugStrategy(object):
#     """
#     The 'linear' strategy class provides the basic framework for
#     strategies default and debug.
#     """
#     def __init__(self, tqm):
#         self.tqm              = tqm
#         self.inventory        = tqm.inventory
#         self.variable_manager = tqm.variable_manager
#         self.loader           = tqm.loader
#         self.host_queue       = None
#
#         display.debug("using strategy: linear")
#
#     def _compute_next_task_lockfiles(self

# Generated at 2022-06-23 13:01:23.920171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test initialization of class StrategyModule")
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True

# Unit tests from ansible/plugins/strategy/linear.py, with extra debug statements

# Generated at 2022-06-23 13:01:25.769160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 13:01:26.916826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:01:36.974837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as debug
    # construct StrategyModule
    mock_tqm = 'mock_tqm'
    mock_variable_manager = 'mock_variable_manager'
    mock_loader = 'mock_loader'
    mock_options = 'mock_options'
    sm = debug.StrategyModule(tqm=mock_tqm)

    assert sm.tqm == mock_tqm
    assert sm.variable_manager == mock_variable_manager
    assert sm.loader == mock_loader
    assert sm.options == mock_options
    assert sm.passwords == {}
    assert sm.all_vars == {}
    assert sm.debugger_active


if __name__ == '__main__':
    import pytest


# Generated at 2022-06-23 13:01:38.061611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj.debugger_active


# Generated at 2022-06-23 13:01:39.661726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        pass
    tqm = Tqm()
    StrategyModule(tqm)



# Generated at 2022-06-23 13:01:42.345817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n### Test StrategyModule constructor')
    test_obj = StrategyModule(tqm=None)
    print('\n### Test StrategyModule constructor - done')

