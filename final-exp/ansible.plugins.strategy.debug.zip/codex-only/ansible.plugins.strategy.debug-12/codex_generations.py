

# Generated at 2022-06-23 12:51:45.399490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self, tags, skip_tags, extra_vars):
            self.tags = tags
            self.skip_tags = skip_tags
            self.extra_vars = extra_vars

    tags = ['all']
    skip_tags = ['never']
    extra_vars = ['foo=bar']

    sm = StrategyModule(tqm(tags, skip_tags, extra_vars))

    assert sm.tqm.tags == tags
    assert sm.tqm.skip_tags == skip_tags
    assert sm.tqm.extra_vars == extra_vars



# Generated at 2022-06-23 12:51:47.315075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-23 12:51:57.562259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    test_var_manager = VariableManager()
    test_InventoryManager = InventoryManager(test_var_manager, [])
    test_tqm = TaskQueueManager(
                inventory=test_InventoryManager,
                variable_manager=test_var_manager,
                loader=None,
                options=None,
                passwords=None,
                stdout_callback=None,
                run_additional_callbacks=False,
                run_tree=False)
    test_StrategyModule = StrategyModule(tqm=test_tqm)
    assert isinstance(test_StrategyModule, StrategyModule)


# Generated at 2022-06-23 12:51:59.081959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active is True


# Generated at 2022-06-23 12:52:02.221075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:52:04.311160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm



# Generated at 2022-06-23 12:52:06.914213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    res = '<StrategyModule: No: module: workingdir: >'
    assert repr(strategy)==res


# Generated at 2022-06-23 12:52:16.905396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_StrategyModule - Constructor
    strategy_module = StrategyModule(None)
    if strategy_module:
        print('Constructor works')
    else:
        print('Constructor failed')

# Executing tasks in interactive debug session
    def run(self, iterator, play_context):
        """
        The run method is the entry point for the strategy plugin, which provides
        the interface through which Ansible executes specific actions on hosts.
        """
        # First we create the actual play object, based on the play context
        # and the iterator, which provides the hosts and tasks to be executed
        # for this particular run.
        play = self._play_for_host(iterator, play_context)

        # Debugger starts with import of module 'cmd'
        print("Tasks execution is 'linear' but controlled by an interactive debug session.")
       

# Generated at 2022-06-23 12:52:22.872576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #init
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Strategy module for 'debug' strategy plugin."
    assert StrategyModule.__module__ == "ansible.plugins.strategy.debug"
    assert cmd.Cmd.__name__ == "Cmd"
    assert cmd.Cmd.__doc__ == "Base class for line-oriented command interpreters."
    assert cmd.Cmd.__module__ == "cmd"
    assert pprint.__name__ == "pprint"
    assert pprint.__doc__ == "Data pretty printer."
    assert pprint.__module__ == "pprint"
    assert sys.__name__ == "sys"

# Generated at 2022-06-23 12:52:26.744665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import __main__
        __main__.display = {'verbosity': 2}
        print("\nTest constructor of Class StrategyModule:\n")
        tqm = __main__.tqm = _create_manager(3, 0, 0)
        sm = StrategyModule(tqm)
    except:
        print("Test constructor of Class StrategyModule is failed")
        exit(5)
    else:
        print("Test constructor of Class StrategyModule is passed")


# Generated at 2022-06-23 12:52:28.140589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == "StrategyModule")


# Generated at 2022-06-23 12:52:34.597302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = dict(action=dict(module='shell', args='ls'))
    tasks = [task]
    tqm = dict(tasks=tasks)
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# This is a copy of cmd.Cmd from Python 2.7.11, with the precmd and postcmd
# methods commented out to avoid recursion.
#
# This class is used for unit testing instead of the cmd.Cmd class.

# Generated at 2022-06-23 12:52:41.660558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\ntest_StrategyModule")

    class MockTQM:
        def __init__(self):
            self.hosts = 'hosts'
            self.callbacks = 'callbacks'
            self.stats = 'stats'
            self.run_state = 'run_state'

    debugger_test = StrategyModule(MockTQM)

    assert debugger_test.tqm == 'hosts'
    assert debugger_test.get_host_list == 'hosts'
    assert debugger_test._tqm == 'callbacks'
    assert debugger_test._stats == 'stats'
    assert debugger_test.run_state == 'run_state'
    assert debugger_test.playbook is None
    assert debugger_test.block_list is None

# Generated at 2022-06-23 12:52:49.846283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "all"
    play = None
    ds = None
    variable_manager = None
    loader = None
    options = None
    passwords = None
    run_tree = False
    settings = None
    tqm = None
    sm = StrategyModule(tqm)
    if sm.debugger_active == True:
        print(True)



# class Debugger(cmd.Cmd):
#     def __init__(self):
#         cmd.Cmd.__init__(self)
#         self.curr_task = None
#         self.pp = pprint.PrettyPrinter(indent=2)
#
#     def do_prompt(self, prompt):
#         "Set the prompt"
#         self.prompt = prompt + " "
#
#     def postcmd(self, stop

# Generated at 2022-06-23 12:52:53.436168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock_tqm()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


#TODO: Write test(s) for this method
#TODO: Return object from run

# Generated at 2022-06-23 12:52:55.248407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:52:57.124741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__.__doc__



# Generated at 2022-06-23 12:53:08.510297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #import os
    #sys.path.append(os.path.abspath('/root/'))
    from ansible.plugins import strategy_loader
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory

    cli = CLI(['--debugger'])
    cli.parse()
    cli.options.module_path = ['']
    cli.options.forks = 1

    inventory = Inventory(cli.options.inventory)


# Generated at 2022-06-23 12:53:09.039162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:11.464888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s != None


# Generated at 2022-06-23 12:53:12.021052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return None

# Generated at 2022-06-23 12:53:18.425743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    print(sm)
    assert sm.__class__.__name__ == "StrategyModule"
    assert sm.tqm == None

# Test run_* functions
# ---------------------------------------------------------------------------------------------------------------
# For each function run_* runs Ansible code in debug mode and checks that it is working.


# Generated at 2022-06-23 12:53:24.248979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')
    sys.stdout.seek(0)
    assert sys.stdout.read() == '<ansible.plugins.strategy.debug.StrategyModule object at 0x7f6b3eb6e7d0>\n'
    sys.stdout = sys.__stdout__



# Generated at 2022-06-23 12:53:25.562408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(tqm)


# Generated at 2022-06-23 12:53:27.179609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')


# Generated at 2022-06-23 12:53:28.474861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s
    assert isinstance(s, LinearStrategyModule)


# Generated at 2022-06-23 12:53:34.647297
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:53:36.824802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:53:43.242335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = True
    tqm = {}
    tqm['__class__'] = 'ansible.executor.task_queue_manager.TaskQueueManager'
    strategy = eval('StrategyModule(tqm)')
    assert strategy.debugger_active == debugger_active
    assert strategy.get_task_queue_manager() == tqm



# Generated at 2022-06-23 12:53:47.404541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(object)
    assert isinstance(obj, StrategyModule)

################
# This is a copy from https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/strategy/debug.py
################

# Generated at 2022-06-23 12:53:50.917499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(StrategyModule):
        pass
    t = Test(None)
    assert t.increment_stat == 'runner_on_'
    assert t.debugger_active


# Generated at 2022-06-23 12:53:52.346628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:53:55.619616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert bool(StrategyModule) is True



# Generated at 2022-06-23 12:53:58.604181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == None



# Generated at 2022-06-23 12:54:01.166674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a.debugger_active == True
    assert a.tqm == None


# Generated at 2022-06-23 12:54:11.628792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # print("\n*******running test_StrategyModule()*****\n")
    sys.stdout.flush()

    class AnsibleDebugger(cmd.Cmd):
        def __init__(self, strategy):
            cmd.Cmd.__init__(self)
            self.intro = "### Ansible Debugger ###"
            self.prompt = "> "
            self.exit_message = "Goodbye!"

            self.strategy = strategy
            self.tqm = strategy.tqm
            self.current_task = None
            self.current_play = "play"
            self.playbook = None

            self._last_result = {}
            self.current_host = None

        def emptyline(self):
            print("call emptyline")
            sys.stdout.flush()
            pass


# Generated at 2022-06-23 12:54:13.686169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    TQM("DIR", "PLAYBOOK")
    assert isinstance(ansible.plugins.strategy.debug.StrategyModule(TQM("DIR", "PLAYBOOK")), StrategyModule)


# Generated at 2022-06-23 12:54:20.195344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    try:
        tqm = None
        strategy_module = StrategyModule(tqm)
        assert strategy_module != None, "test_StrategyModule failed: object should not be None"
    except Exception as e:
        print("test_StrategyModule failed: {}".format(e))


# Generated at 2022-06-23 12:54:22.010121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        a = LinearStrategyModule(tqm)
    except TypeError as e:
        pass

# Test for 'linear' strategy

# Generated at 2022-06-23 12:54:33.817227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['lib.setup'] = mock_setup_module
    sys.modules['lib.task'] = mock_task_module
    sys.modules['lib.play'] = mock_play_module
    sys.modules['lib.notify'] = mock_notify_module
    sys.modules['lib.cleanup'] = mock_cleanup_module
    sys.modules['lib.worker'] = mock_worker_module
    sys.modules['lib.utils'] = mock_utils_module
    sys.modules['lib.loader'] = mock_loader_module
    sys.modules['lib.callbacks'] = mock_callbacks_module
    sys.modules['lib.display'] = mock_display_module
    sys.modules['lib.block'] = mock_block_module
    sys.modules['lib.utils.plugin_docs'] = mock_plugin

# Generated at 2022-06-23 12:54:42.091754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def check_func(tqm):
        return (tqm.tqm_is_setup,tqm.tqm_variables,tqm.tqm_loader)

    tqm = { 'tqm_is_setup': 1, 'tqm_variables': 2, 'tqm_loader': 3 }
    s = StrategyModule(tqm)
    assert(check_func(s) == (1,2,3))

# test for run() with debugger_active = True

# Generated at 2022-06-23 12:54:48.483355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'strategy_debug'
    # Test constructor
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == "Task execution is 'linear' but controlled by an interactive debug session."

# Unit tests for class StrategyModule

# Generated at 2022-06-23 12:54:49.888360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("Unit testing StrategyModule")
  assert StrategyModule(tqm = "tqm")



# Generated at 2022-06-23 12:54:59.597989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self, host_list, inventory):
            self.host_list = host_list
            self.inventory = inventory
            self.stats = None
            self.failed_hosts = {}
            self.worker_procs = 0

        def cleanup(self):
            pass

    class TestHost(object):
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

        def get_name(self):
            return self.name

    class TestTask(object):
        def __init__(self, name, loop, loop_args, args, module_name, delegate_to):
            self.name = name
            self.loop = loop
            self.loop_args = loop_args
            self.args = args

# Generated at 2022-06-23 12:55:02.530492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == tqm


# Generated at 2022-06-23 12:55:06.469056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a dummy TaskQueueManager
    class TaskQueueManager:
        def __init__(self):
            self.host_vars = {}
    tqm = TaskQueueManager()

    # Call constructor of class StrategyModule
    strategy_module = StrategyModule(tqm)

    # Check state of debugger
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:55:08.204401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-23 12:55:12.394848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    obj = StrategyModule(tqm)
    assert obj.tqm == tqm
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:55:13.508980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:55:15.467951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    print("Constructor of class StrategyModule works well")


# Generated at 2022-06-23 12:55:17.598223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0

    x = StrategyModule(tqm)
    assert(type(x) == StrategyModule)


# Generated at 2022-06-23 12:55:20.383219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Begin unit test: debug')
    print('Begin unit test: StrategyModule')
    strategy = StrategyModule(None)
    assert(type(strategy.debugger_active) is bool)
    print('End unit test: StrategyModule')



# Generated at 2022-06-23 12:55:28.448572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert(strategy.tqm == tqm)
    assert(strategy.strategy == 'debug')
    assert(strategy.host_state == {})
    assert(strategy.iterator == None)
    assert(strategy.iterator_cache == {})
    assert(len(strategy._tqm_iterables) == 0)
    assert(strategy.debugger_active == True)


# Helper function for unit test for the run method

# Generated at 2022-06-23 12:55:31.506221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_object = object
    strategy_module = StrategyModule(tqm_object)
    strategy_module.get_host_list()
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:55:38.515256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTaskQueueManager:
        pass

    tqm = MockTaskQueueManager()
    strategy = StrategyModule(tqm)

    assert strategy.debugger_active == True
# End of unit test for constructor of class StrategyModule

    def dump_retry(self, retry):
        """
        Pretty-print the information in a retry.
        """
        pr = pprint.PrettyPrinter(indent=2)
        print('---')
        print('Result: %s' % retry.result)
        if isinstance(retry.result, AnsibleError):
            print('Error: %s' % retry.result.message)
        print('Controlling host: %s' % retry.host)
        print('Task name: %s' % retry.task.name)

# Generated at 2022-06-23 12:55:45.330671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.loader
    except ImportError:
        print("ImportError")
        sys.exit(1)

    try:
        import ansible.playbook
    except ImportError:
        print("ImportError")
        sys.exit(1)

    try:
        import ansible.vars
    except ImportError:
        print("ImportError")
        sys.exit(1)

    try:
        import ansible.utils
    except ImportError:
        print("ImportError")
        sys.exit(1)

    t1 = ansible.plugins.loader._find_plugin('strategy', 'debug')
    t2 = ansible.playbook.Playbook()
    t3 = ansible.vars.VariableManager()
    t4 = ansible.utils.plugin.class_loader.find_

# Generated at 2022-06-23 12:55:46.985386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:55:49.303165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test')
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:55:51.301563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test for class StrategyModule """
    strategy_module = StrategyModule(None)


# Generated at 2022-06-23 12:55:54.684697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule
    assert 'tqm' in module.__init__.__code__.co_varnames



# Generated at 2022-06-23 12:56:04.714443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Host
    from ansible.inventory.group import Group

    playbook = Playbook()
    inventory = playbook.get_inventory()
    host = Host(name='localhost')
    group = Group('ungrouped')
    group.add_host(host)
    inventory.add_group(group)
    variable_manager = playbook.get_variable_manager()
    loader = playbook.get_loader()
    passwords = dict()
    play_context = PlayContext(play=playbook.get_plays()[0], variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 12:56:05.419036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Generated at 2022-06-23 12:56:07.792154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)
    assert True


# Generated at 2022-06-23 12:56:15.561140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock TQM
    class MockTaskQueueManager(object):
        def __init__(self):
            self.hostvars = []

    # Create a mock PlayContext
    class MockPlayContext():
        def __init__(self):
            self.become_user = 'mock_become_user'
    # create a mock Host
    class MockHost(object):
        def __init__(self):
            self.name = 'mock_host'
            self.vars = {}
            self.groups = ['group1', 'group2']
    # Create a mock Host
    mock_host = MockHost()

    # Create a mock Task
    class MockTask(object):
        def __init__(self):
            self.action = 'mock_action'
            self.args = []

# Generated at 2022-06-23 12:56:21.729630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        args = ['-m', 'debug']
        print('>>> StrategyModule test start')
        sm = StrategyModule(args)
        print('>>> StrategyModule test end')
    except Exception as e:
        print(e)
        return 1
    return 0

# If this script is run directly, and not as an import, then run unit test.
if __name__ == "__main__":
    ret = test_StrategyModule()
    sys.exit(ret)

# Generated at 2022-06-23 12:56:23.750452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:25.419973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert(sm.debugger_active == True)



# Generated at 2022-06-23 12:56:34.476748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class TestStrategyModule(unittest.TestCase):
        def test_init(self):
            TestStrategyModule.test_tqm = []
            strategy = StrategyModule(TestStrategyModule.test_tqm)
            self.assertTrue(strategy is not None)
            
            self.assertTrue(strategy.tqm is TestStrategyModule.test_tqm)
            self.assertTrue(isinstance(strategy, LinearStrategyModule))

            self.assertTrue(strategy.debugger_active is True)

    def do_nothing_init(self):
        pass

    strategy_module_class_under_test = StrategyModule
    setattr(strategy_module_class_under_test, '__init__', do_nothing_init)

    unittest.main()

# Generated at 2022-06-23 12:56:37.525342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:56:39.122280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:42.782943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.display == 'debug'
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:45.753714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active is False

# The 'playbook' variable is set in action_plugins/setup.py


# Generated at 2022-06-23 12:56:47.369948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm).debugger_active == True


# Generated at 2022-06-23 12:56:51.237133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    debug.StrategyModule(sys.modules['ansible.plugins.strategy.debug'])
    assert True
# end of test_StrategyModule


# Generated at 2022-06-23 12:56:52.985749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {}
    sm = StrategyModule(mock_tqm)
    assert( sm.debugger_active )


# Generated at 2022-06-23 12:56:54.484355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:57.158428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule.__module__ == __name__

# From: https://docs.python.org/2/library/cmd.html#cmd.Cmd

# Generated at 2022-06-23 12:56:58.789932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 12:57:01.011907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('StrategyModule constructor')
    assert False


# Generated at 2022-06-23 12:57:10.674940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv.append('debug')
 
    class TestDebugger(cmd.Cmd):
        """
        Basic test class for testing the debugger
        """
        def __init__(self, host_data):
            cmd.Cmd.__init__(self)
            self.host_data = host_data

        # Fake tasks
        def run_task(self, play_context, show_content, task, host_data):
            print('Answer to the Ultimate Question of Life, the Universe, and Everything: 42')

        def run_play(self, play):
            print('Running play')
            super(TestDebugger, self).run_play(play)

            print('Done running play')
            return super(TestDebugger, self).run_play(play)

        def run(self):
            print('Running')


# Generated at 2022-06-23 12:57:16.449964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule
    # StrategyModule(self, tqm)
    # AnsibleStrategyModule.__init__(self, tqm)
    try:
        assert True
    except AssertionError as e:
        print("Error in test_StrategyModule constructor")
        raise e



# Generated at 2022-06-23 12:57:23.294852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, LinearStrategyModule)
    assert strategy_module.__class__.__name__ == "StrategyModule"
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:57:31.427410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

    context = {'playbook': 'My Play'}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info={"ansible_version": "2.9.2"})

    tqm = None

# Generated at 2022-06-23 12:57:33.490507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nTest for constructor of class StrategyModule')
    strategy_module = StrategyModule(tqm)



# Generated at 2022-06-23 12:57:36.745190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    e = StrategyModule(tqm)
    assert e.debugger_active == True


# Generated at 2022-06-23 12:57:37.500334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:47.211118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {
        'stats': {
            'dark': {}, 'failures': {}, 'ok': {},
            'processed': {}, 'skipped': {}, 'rescued': {}, 'ignored': {}
        }
    }
    strategy_module = StrategyModule(tqm)
    assert len(strategy_module.tqm['stats']['ok']) == 0
    assert len(strategy_module.tqm['stats']['dark']) == 0
    assert len(strategy_module.tqm['stats']['failures']) == 0
    assert len(strategy_module.tqm['stats']['ignore']) == 0
    assert len(strategy_module.tqm['stats']['processed']) == 0

# Generated at 2022-06-23 12:57:49.389035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import queue
    import unittest.mock
    tqm = unittest.mock.Mock()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:57:50.655584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm=None)


# Generated at 2022-06-23 12:57:53.630779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert(obj is not None)
    assert(obj.debugger_active is True)


# Generated at 2022-06-23 12:57:56.194378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule:
        def __init__(self, tqm):
            self.tqm = tqm
            self.result_queue = self.tqm._final_q
    return TestStrategyModule


# Generated at 2022-06-23 12:57:56.684235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:59.515093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    test = StrategyModule(tqm)
    assert test.tqm == tqm
    assert test.debugger_active
    assert test.tqm.stats
    assert not test.tqm.hostvars



# Generated at 2022-06-23 12:58:01.862436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Shouldn't raise an exception
    stm = StrategyModule(None)
    assert stm is not None



# Generated at 2022-06-23 12:58:11.472304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.hexversion >= 0x03000000:
        stdout = sys.stdout.buffer
    else:
        stdout = sys.stdout
    sys.stdout = open('/tmp/test.txt', 'w')

    tqm = 'tqm'
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.debugger_active == True
    assert sm.host_hash_rebuilt == False
    assert sm.host_hash == {}
    assert sm.task_should_run(tqm) == True
    
    sys.stdout.close()
    sys.stdout = stdout


# Generated at 2022-06-23 12:58:12.377294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


# Generated at 2022-06-23 12:58:13.817239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule('test')
    assert m.debugger_active == True


# Generated at 2022-06-23 12:58:15.592628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    StrategyModule(tqm)



# Generated at 2022-06-23 12:58:19.343592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == None


# Generated at 2022-06-23 12:58:20.054031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:22.047892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')


# Generated at 2022-06-23 12:58:29.536757
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:58:30.898237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pytest.fail('No test for strategy plugin yet')



# Generated at 2022-06-23 12:58:32.683110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqtm')
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:35.187212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from mock import Mock
    tqm = Mock()

    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:58:36.044123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule(0)


# Generated at 2022-06-23 12:58:37.709232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:58:38.364715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:40.382367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = 1
    _s = StrategyModule(_tqm)


# Generated at 2022-06-23 12:58:42.301582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=True) != None


# Generated at 2022-06-23 12:58:44.086184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:58:45.724979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule...", end="")
    assert StrategyModule(None)
    print("PASS")



# Generated at 2022-06-23 12:58:46.739461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-23 12:58:49.358840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # some arbitrary value
    tqm=123
    # Instantiate the class
    strategy = StrategyModule(tqm)
    # Check that expected attribute is initialised correctly
    assert strategy.debugger_active

# Generated at 2022-06-23 12:58:50.142850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 12:58:51.047450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == False


# Generated at 2022-06-23 12:58:53.413235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-23 12:58:54.414883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-23 12:58:54.881784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:56.561950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-23 12:59:03.913150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-23 12:59:11.790396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # To demonstrate below code, we need to mock out all
    # instances and methods, even the ones that are not used.
    # (To check if the constructor initialises properly).
    class Test_TQM:
        def __init__(self):
            self.shared_loader_obj = None
            self.inventory = None
        def __call__(self):
            return None
    tqm = Test_TQM()

    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.inventory == tqm.inventory
    assert sm.loader == tqm.shared_loader_obj
    assert sm.strategy == 'debug'
    assert sm.accelerate == 1
    assert sm.accelerate_port == 5099
    assert sm.accelerate_ipv6

# Generated at 2022-06-23 12:59:14.032531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class _tqm(object):
        pass
    s = StrategyModule(_tqm())
    assert isinstance(s, StrategyModule)



# Generated at 2022-06-23 12:59:14.699304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:59:23.512532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set the constants
    result = None
    error_1 = False
    error_2 = False
    expected_result = None

    ###########################################################################
    # NOTE: For the following test, I will just be checking that the
    # StrategyModule is correctly created and that the debugger is active
    # I will not be unit testing the debugger:
    #     - it would be too complicated
    #     - it would be irrelevant
    ###########################################################################

    # Create a temporary object that will allow us to unit test the debugger
    class Temp():
        def __init__(self):
            self.tmp = None

        def debug(self, msg=None, host=None):
            if msg is None:
                return
            elif msg.startswith('<v2_runner_'):
                return

# Generated at 2022-06-23 12:59:28.184442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module.debugger_active == True)

# Test whether the StrategyModule can be imported or not.
# If it can be imported, that means this plugin is loaded properly.

# Generated at 2022-06-23 12:59:32.953085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check if constructor of StrategyModule works correctly
    test_tqm = 1
    sm = StrategyModule(test_tqm)
    assert sm.debugger_active == True
    assert sm.tqm == test_tqm

# TODO: Probably this testfunction is not needed, since it is already implemented
# in the parent class

# Generated at 2022-06-23 12:59:36.198486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Initialize reloading
  if globals().has_key('StrategyModule'):
    del globals()['StrategyModule']
  from ansible.plugins.strategy import strategy_debug
  strategy_debug.StrategyModule(None)


# Generated at 2022-06-23 12:59:38.201949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Add test for constructor of class StrategyModule
    return


# Generated at 2022-06-23 12:59:41.147148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Executing test_StrategyModule")
    strategy = StrategyModule(tqm)
    print(strategy)
    assert strategy != None


# Generated at 2022-06-23 12:59:41.874314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:59:42.510188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:59:46.324400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module.debugger_active == True
    assert module.tqm != None


# TODO:
# * Fix the parsing skill of cmd.Cmd class
# * Add support of 'step' and 'until' to control task execution

# Generated at 2022-06-23 12:59:49.173837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_strategy = StrategyModule(tqm='test')
    assert obj_strategy.debugger_active == True



# Generated at 2022-06-23 12:59:51.213491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-23 12:59:51.952229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:59:54.693972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True
    assert isinstance(strategy_module, LinearStrategyModule)



# Generated at 2022-06-23 12:59:56.831982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is not None
    assert StrategyModule(None) is not None
    assert StrategyModule(None).debugger_active is True


# Generated at 2022-06-23 13:00:04.682711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule
    # INIT SCENARIO
    # Create a basic_mock object for class AnsibleTaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    basic_mock = TaskQueueManager()
    # END INIT SCENARIO
    StrategyModule(basic_mock)


    # Call to constructor of class StrategyModule, without arguments
    try:
        StrategyModule()
        assert False
    except TypeError:
        assert True
# End unit test



# Generated at 2022-06-23 13:00:07.985174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True


# Generated at 2022-06-23 13:00:09.839974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 13:00:12.523989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        strategy_module = StrategyModule(tqm)
    except Exception as e:
        sys.stderr.write(repr(e))
        assert False


# Generated at 2022-06-23 13:00:19.662773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class InputClass:
        def __init__(self):
            self._stdin_fd = 1
        def fileno(self):
            return self._stdin_fd
    class OutputClass:
        def __init__(self):
            self.data = ''
        def write(self, data):
            self.data += data
        def flush(self):
            pass
    class TqmClass:
        def __init__(self):
            self.stdin = InputClass()
            self.stdout = OutputClass()
    tm = StrategyModule(TqmClass())
    assert tm is not None
    assert tm.debugger_active is True


# Generated at 2022-06-23 13:00:23.685422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = True
    strategy = StrategyModule(test_tqm)
    assert(test_tqm == strategy.tqm)
    assert(strategy.debugger_active == True)

# Tests that the class StrategyModule is a subclass of LinearStrategyModule
# This test will fail if StrategyModule is not a subclass of LinearStrategyModule

# Generated at 2022-06-23 13:00:27.505592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule('tqm')
    assert my_strategy.tqm == 'tqm'
    assert not my_strategy.debugger_active


# Generated at 2022-06-23 13:00:29.757815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active

# Execute methods for two tasks

# Generated at 2022-06-23 13:00:35.126952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Constructor = 'def __init__(self, tqm):\n        super(StrategyModule, self).__init__(tqm)\n        self.debugger_active = True\n'
    tqm = ""
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active == True


# Generated at 2022-06-23 13:00:37.484174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    @param: tqm - task queue manager
    '''
    global StrategyModule
    StrategyModule(tqm)


# Generated at 2022-06-23 13:00:43.839098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:45.153095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active



# Generated at 2022-06-23 13:00:51.019194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}

    class TestStrategyModuleClass(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModuleClass, self).__init__(tqm)
            self.debugger_active = True

    TestStrategyModule = TestStrategyModuleClass(tqm)
    TestStrategyModule.__init__(tqm)



# Generated at 2022-06-23 13:00:52.534276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:00:53.938609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 13:00:57.585863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

    assert strategy
    assert isinstance(strategy, LinearStrategyModule)
    assert strategy.module_name == 'linear'
    assert strategy.debugger_active == True


# Generated at 2022-06-23 13:01:00.934477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert sm.debugger_active == True 
    assert type(sm) == StrategyModule



# Generated at 2022-06-23 13:01:01.714241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:01:11.551446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TqmWrapper():
        def __init__(self):
            self.tqm_debugger = None
        def __getattr__(self, name):
            return self.__dict__[name]
        def __setattr__(self, name, value):
            self.__dict__[name] = value
    test_tqm = TqmWrapper()
    sm = StrategyModule(test_tqm)
    assert hasattr(sm, 'tqm')
    assert sm.tqm is test_tqm
    assert hasattr(sm, 'tqm_rc')
    assert sm.tqm_rc == 0
    assert hasattr(sm, 'debugger_active')
    assert sm.debugger_active
    assert hasattr(sm, '_debugger_source')
   

# Generated at 2022-06-23 13:01:18.859579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    s = StrategyModule(tqm)
    assert tqm == s._tqm
    assert s.debugger_active
    # TODO: assert some attributes of self.stats
    # TODO: assert some attributes of self.variable_manager


# TODO: unit test for methods of class StrategyModule
#       run
#       get_host_keys_added
#       add_tqm_variables
#       save_load_vars_files
#       get_host_results
#       cleanup_tasks
#       load_callbacks
#       enable_shuffling
#       enable_subset
#       enable_threading

# TODO: unit test for class Debugger



# Generated at 2022-06-23 13:01:21.295166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    test_strategy = StrategyModule(test_tqm)
    assert test_strategy.debugger_active == True


# Generated at 2022-06-23 13:01:27.199181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Construct an instance of StrategyModule"""
    # Create a temporary file to avoid error
    # IOError: [Errno 2] No such file or directory
    test_file = open('tmp.txt', 'w')
    test_file.close()
    tqm = 'tqm'
    strate = StrategyModule(tqm)
    strate.execute()
    assert True
    assert strate.debugger_active == True




# Generated at 2022-06-23 13:01:28.310182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass



# Generated at 2022-06-23 13:01:32.440500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor
    test_strategy_module = StrategyModule(tqm=None)

    # Test variable
    assert test_strategy_module.debugger_active == True



# Generated at 2022-06-23 13:01:36.378761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    func_name = sys._getframe().f_code.co_name
    assert hasattr(StrategyModule, '__init__') and callable(getattr(StrategyModule, '__init__'))
    assert hasattr(StrategyModule, 'run') and callable(getattr(StrategyModule, 'run'))

    return


# Generated at 2022-06-23 13:01:39.621260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: how to unit test __init__?
    strategy = StrategyModule
    assert strategy.tqm != None

