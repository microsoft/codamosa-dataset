

# Generated at 2022-06-23 12:51:38.533398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 12:51:40.244737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(object)
    assert obj.debugger_active == True


# Generated at 2022-06-23 12:51:50.619700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Load module
    strategy_plugins = {}
    strategy_plugins['debug'] = "plugins/strategy/debug.py"
    loaded_plugins = dict(
        (k, p) for (p, k) in [(strategy_plugins[k], k) for k in strategy_plugins]
    )
    # from ansible.plugins.strategy import debug
    # from importlib import import_module
    # loaded_plugins = {'debug': import_module('plugins.strategy.debug')}
    import imp
    x = imp.load_source('debug', strategy_plugins['debug'])
    loaded_plugins['debug'] = x

    import ansible.utils.plugins as plugins
    plugins._strategy_plugins = loaded_plugins
    # New strategies module
    strategies = plugins.lookup_strategy_plugins()
    # Get strategy

# Generated at 2022-06-23 12:51:52.274216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None


# Generated at 2022-06-23 12:51:58.568714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Create TestStrategyModule class")
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self.debugger_active = True
    print("TestStrategyModule class is created")
    print("")
    print("Create TestStrategyModule object")
    TestStrategyModule(tqm=0)
    print("TestStrategyModule object is created")
    print("")
    print("Test end")


# Generated at 2022-06-23 12:51:59.800735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m.debugger_active


# Generated at 2022-06-23 12:52:01.888049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)



# Generated at 2022-06-23 12:52:04.599958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule constructor...")
    tqm = None
    strtgymodule = StrategyModule(tqm)
    assert strtgymodule.debugger_active == True



# Generated at 2022-06-23 12:52:05.212174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:52:06.981486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:52:09.153418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # cmd.Cmd is the parent of class StrategyModule
    assert issubclass(StrategyModule, cmd.Cmd)
    print("test_StrategyModule PASSED")


# Generated at 2022-06-23 12:52:10.980169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:52:12.603569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True


# TaskExecutor class is called from execute_tasks method of class StrategyModule

# Generated at 2022-06-23 12:52:13.413449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 12:52:15.918596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    result = StrategyModule(tqm)
    assert result.debugger_active == True


# Generated at 2022-06-23 12:52:18.041992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule('')
    y = pprint.pprint(vars(x))
    assert y is None

# Generated at 2022-06-23 12:52:28.756145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'

# End of unit tests for class StrategyModule

# Below class is from this site:
# http://stackoverflow.com/questions/6631299/generic-python-thread-class
# and for more info, look here:
# https://docs.python.org/2/library/threading.html#thread-objects
# and here:
# http://stackoverflow.com/questions/17089564/python-thread-class
#
# class AThread(threading.Thread):
#     """Thread class with a stop() method. The thread itself has to check
#     regularly for the stopped() condition."""
#
#     def __init__(self, target, **kwargs):
#         super(AThread, self).__init__(**

# Generated at 2022-06-23 12:52:30.652635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:31.204049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:32.854864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(object)
    assert test.debugger_active


# Generated at 2022-06-23 12:52:35.160224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    obj = StrategyModule(tqm)
    assert obj.debugger_active == True

#-------------------------------------------------------------------------------

# Generated at 2022-06-23 12:52:36.978460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: is there any way to write unit test for this class?
    assert 1 == 1


# Generated at 2022-06-23 12:52:38.177677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True

# Generated at 2022-06-23 12:52:41.695405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    try:
        assert sm.debugger_active
    except:
        raise AssertionError("Failed unit test for constructor of class StrategyModule")



# Generated at 2022-06-23 12:52:43.129036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:45.057683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debug = StrategyModule('tqm')
    assert(debug.debugger_active == True)


# Generated at 2022-06-23 12:52:46.301283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:53.649228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    assert StrategyModule.__bases__[0] == LinearStrategyModule
    assert StrategyModule.__doc__ == '''
    name: debug
    short_description: Executes tasks in interactive debug session.
    description:
        - Task execution is 'linear' but controlled by an interactive debug session.
    version_added: "2.1"
    author: Kishin Yagami (!UNKNOWN)
    '''

# end of class StrategyModule


# Generated at 2022-06-23 12:52:59.650220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TqmModule(object):
        def __init__(self):
            self.result_q = None
            self.tqm_destroy_flag = None
            self.connection_info = None
    tqm = TqmModule()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.host_results == {}
    assert sm.worker_threads == {}
    assert sm.put_host_queue == {}
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:53:02.632772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    assert isinstance(StrategyModule(tqm), StrategyModule)


# vim: set et ts=4 sw=4 sts=4 :

# Generated at 2022-06-23 12:53:06.164195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test if the task queue manager is instantiated')
    strategy_module = StrategyModule(123)
    assert strategy_module.tqm == 123
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:07.977004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    "Test constructor of class StrategyModule"
    pass


# Generated at 2022-06-23 12:53:13.544836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy_module = LinearStrategyModule()
    strategy_module = StrategyModule(linear_strategy_module.tqm)
    # Test correct class name
    assert strategy_module.__class__.__name__ == 'StrategyModule', \
        "StrategyModule class name is not correct."
    # Test correct inheritance
    assert isinstance(strategy_module, LinearStrategyModule), \
        "StrategyModule class does not inherit the correct class."


# Generated at 2022-06-23 12:53:18.025253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pp = pprint.PrettyPrinter()

    tqm = None
    s = StrategyModule(tqm)

    print(s)

# A debugger implementation.  It contains data and methods of class cmd.Cmd.

# Generated at 2022-06-23 12:53:19.991912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert isinstance(sm,StrategyModule)


# Generated at 2022-06-23 12:53:21.737837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:23.052223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-23 12:53:25.399390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'tqm'
    test_object = StrategyModule(test_tqm)
    assert test_object.debugger_active == True
################################################################################################



# Generated at 2022-06-23 12:53:31.914964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        def __init__(self):
            self.current_hosts = []
            self.stats = {}
            self.hostvars = {}

    strategy_module = StrategyModule(Tqm())
    assert strategy_module.debugger_active
    assert strategy_module.tqm
    assert strategy_module.tqm.current_hosts
    assert strategy_module.tqm.stats
    assert strategy_module.tqm.hostvars



# Generated at 2022-06-23 12:53:35.403388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        class FakeTaskQueueManager:
            pass
        tqm = FakeTaskQueueManager()
        StrategyModule(tqm)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 12:53:36.577647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not hasattr(StrategyModule, '__init__')


# Generated at 2022-06-23 12:53:39.579845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm,LinearStrategyModule)
    assert sm.debugger_active == True

##### Begin class Debugger #####



# Generated at 2022-06-23 12:53:41.178683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 12:53:44.544272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:53:46.363443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['ansible.plugins.strategy.debug'].StrategyModule(tqm)


# Generated at 2022-06-23 12:53:47.830470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert strategy.debugger_active == True

# Generated at 2022-06-23 12:53:54.142764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: this test is not valid but I don't have time to make it so
    # I am using it to take a closer look at the type information and
    # make sure it is correct in the docstring
    assert isinstance(StrategyModule(None), LinearStrategyModule)

# this and the debug module are imported by strategy/debug.py as a plugin
# to the StrategyModule class


# Generated at 2022-06-23 12:53:56.832731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm= object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:57.511918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:58.438612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:54:01.349449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'name': 'test'}
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:54:04.502550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nIn function: test_StrategyModule")
    test_module = StrategyModule(None)
    assert not test_module.debugger_active
    
    

# Generated at 2022-06-23 12:54:05.454419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 12:54:10.272340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            self.inventory = {
                'hosts': {
                    'host1': {}
                }
            }
    tqm = TQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:54:12.575345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule(tqm)
    assert res.debugger_active

# Generated at 2022-06-23 12:54:19.309567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule.__name__ == 'StrategyModule'
    except:
        assert False
    try:
        assert callable(StrategyModule)
    except:
        assert False
    try:
        assert StrategyModule(None).debugger_active
    except:
        assert False



# Generated at 2022-06-23 12:54:20.304540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return



# Generated at 2022-06-23 12:54:21.078678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:54:27.176418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)

    tqm = None
    tsm = TestStrategyModule(tqm)
    assert tsm.debugger_active is True



# Generated at 2022-06-23 12:54:29.647155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active == True

# class implementation only used for testing.

# Generated at 2022-06-23 12:54:32.808959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = []
    _strategy_module = StrategyModule(_tqm)
    assert _strategy_module.debugger_active == True
    assert _strategy_module.tqm == _tqm


# Generated at 2022-06-23 12:54:35.302970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    __import__('ansible.plugins.strategy.debug')
    __import__('ansible.plugins.strategy.linear')
    mqm = MockTQM()
    StrategyModule(mqm)
    return True


# Generated at 2022-06-23 12:54:39.554551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    strategy_module.debugger_active = True
    assert True

# This is simple debugger application.  It will be used to invoke
# breakpoints from ansible code.


# Generated at 2022-06-23 12:54:42.222504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['__main__'].debugger_active = False
    a = StrategyModule(None)
    assert a.debugger_active == True, a.debugger_active



# Generated at 2022-06-23 12:54:44.590861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("test")
    return strategy.debugger_active



# Generated at 2022-06-23 12:54:47.384908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(None)
    assert t.debugger_active == True

# Test
# Test
# Test
# Test
# Test
#

# Generated at 2022-06-23 12:54:53.715728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    reload(ansible.plugins.strategy.debug)
    type_ensure = type(StrategyModule) == type(ansible.plugins.strategy.debug.StrategyModule)
    import ansible.plugins.strategy.linear
    reload(ansible.plugins.strategy.linear)
    type_ensure = type_ensure and type(StrategyModule) == type(ansible.plugins.strategy.linear.StrategyModule)
    assert type_ensure


# Generated at 2022-06-23 12:54:55.351559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule()
    assert(test)


# Generated at 2022-06-23 12:55:05.126410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    inventory = Inventory(host_list=['localhost'])
    variable_manager = VariableManager()
    playbook = Playbook.load(playbooks=['./test/unit/utils/debug_test.yml'],
                             variable_manager=variable_manager,
                             loader=None)
    play = playbook.get_plays()[0]
    play._variable_manager = variable_manager

# Generated at 2022-06-23 12:55:08.205188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm=None
   assert (isinstance(StrategyModule(tqm),LinearStrategyModule))



# Generated at 2022-06-23 12:55:18.358367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm(object):
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.shared_loader_obj = None
            self.options = None
            self.stdout_callback = None
            self.stats = None
            self.tqm_vars = None
            self.extra_vars = None
            self.load_callbacks_loaded  = False

    dummy_tqm = DummyTqm()
    strategy_module = StrategyModule(dummy_tqm)

    # Unit test
    assert dummy_tqm.inventory is not None
    assert dummy_tqm.variable_manager is not None
    assert dummy_tqm.loader is not None
    assert dummy_tqm.shared_

# Generated at 2022-06-23 12:55:18.867406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:55:28.041501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.utils
    import ansible.inventory
    import ansible.vars
    import ansible.callbacks

    ansible.utils.VERBOSITY = 0
    tqm = ansible.playbook.playbook.PlaybookExecutor(playbooks=None, inventory=ansible.inventory.Inventory(), variable_manager=ansible.vars.VariableManager(), loader=None, options=None, passwords=None)
    sm = StrategyModule(tqm)
    assert type(sm) == StrategyModule
    assert sm.tqm == tqm
    assert sm.host_state == {}
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:55:29.373021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert True

# Generated at 2022-06-23 12:55:32.127038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule() is not None)
    # assert(StrategyModule(None) is not None)
    # assert(StrategyModule(tqm=None) is not None)


# Generated at 2022-06-23 12:55:37.405971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, LinearStrategyModule)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:55:37.988912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:55:44.710127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First, set up the constants
    LOOP_VAR_NAME = 'ansible_item_label'
    BATCH_NUM = 42
    # Set batch_num = BATCH_NUM for now for testing purposes
    batch_num = BATCH_NUM
    # Now it's time to start testing the class
    tqm = object()
    module = StrategyModule(tqm)
    # Make sure the variables have the correct value
    assert module.loop_var_name == LOOP_VAR_NAME
    assert module.batch_num == batch_num

# Generated at 2022-06-23 12:55:46.864154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:55:55.638531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        class Ansible(object):
            class Vars(object):
                def __init__(self, vars):
                    self.vars = vars
        
            def __init__(self):
                self.vars = self.Vars(vars={})
        def __init__(self):
            self.ansible = self.Ansible()

    tqm = TQM()
    strategy_module = StrategyModule(tqm)
    assert tqm == strategy_module.tqm
    assert tqm.ansible == strategy_module.tqm.ansible
    assert tqm.ansible.vars == strategy_module.tqm.ansible.vars
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:55:58.585199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # As StrategyModule inherits Cmd class,
    # the unit test will be written in the finish method.
    return StrategyModule("tqm")


# Generated at 2022-06-23 12:56:02.771212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule.__name__ = "test_StrategyModule"
    test_tqm = {'name':'test'}
    test_StrategyModule = StrategyModule(test_tqm)
    assert test_StrategyModule.debugger_active == True
    assert test_StrategyModule.name == 'debug'
    assert test_StrategyModule.variable_manager == None
    assert test_StrategyModule.loader == None
    assert test_StrategyModule.play == None
    assert test_StrategyModule.host_list == []
    assert test_StrategyModule.run_handlers == False
    assert test_StrategyModule.results_callback == None
    assert test_StrategyModule.shared_loader_obj == None
    assert test_StrategyModule.delegate_to == None
    assert test_Strategy

# Generated at 2022-06-23 12:56:04.002365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    return None
#
# Python debugger class

# Generated at 2022-06-23 12:56:05.660555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 12:56:08.298197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=0)
    assert a.debugger_active == True



# Generated at 2022-06-23 12:56:10.952837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    stm = StrategyModule(tqm)

    assert stm.tqm == tqm
    assert stm.debugger_active == True



# Generated at 2022-06-23 12:56:13.954009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    module = StrategyModule(tqm)
    assert module.tqm == tqm



# Generated at 2022-06-23 12:56:18.052710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = Tqm()
    result = StrategyModule(test_tqm)

    if result:
        print ('PASS: constructor of class StrategyModule')
    else:
        print ('FAIL: constructor of class StrategyModule')


# Generated at 2022-06-23 12:56:20.096066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def __init__(self):
            pass
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:28.604891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#
#
#

    def run(self, iterator, play_context):
        self.debugger = Debugger(self, iterator, play_context)
        self.iterator = iterator
        self.play_context = play_context

        self.loop()

    def loop(self):
        while self.debugger_active:
            try:
                res = super(StrategyModule, self).run(self.iterator, self.play_context)
                self.debugger.last_result_display()
            except AnsibleError as e:
                display.warning(to_text(e))

            self.debugger.cmdloop()

    def get_vars(self, loader, path, entities, cache=True):
        '''
        Override this method to load variables from the db
        '''

# Generated at 2022-06-23 12:56:32.664828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testTQM = None
    testObj = DebugStrategyModule(testTQM)
    assert testObj.debugger_active == True
    assert isinstance(testObj, LinearStrategyModule)



# Generated at 2022-06-23 12:56:35.972833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        def __init__(self):
            self.inventory = 'inventory'
            self.variable_manager = 'variable_manager'
            self.loader = 'loader'

    sm = StrategyModule(tqm())
    assert sm.tqm == tqm()


# Generated at 2022-06-23 12:56:37.583125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:39.545512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule("tqm")
    assert a.debugger_active == True


# Generated at 2022-06-23 12:56:42.120877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-23 12:56:46.730389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None, None)
    s = StrategyModule(tqm)
    assert s.debugger_active

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:56:47.797068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert 1==1


# Generated at 2022-06-23 12:56:48.949224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:56:52.106777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    t = StrategyModule(test_tqm)
    assert t.tqm == test_tqm
    assert isinstance(t, StrategyModule)
    assert isinstance(t, LinearStrategyModule)
    assert t.debugger_active == True


# Generated at 2022-06-23 12:56:54.960530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule running..')
    tqm = ''
    StrategyModule(tqm)
# Unit test ends here



# Generated at 2022-06-23 12:56:55.621449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:56:58.423496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('dummy_tqm') is not None

# This class is for unit testing of class StrategyModule.
# No actual interactive debug session is launched.

# Generated at 2022-06-23 12:57:06.848921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("## Running test_StrategyModule() ##")
    # print("Important! Make sure the ansible.cfg is configured as below")
    # print("[defaults]\nstrategy_plugins = /usr/share/ansible_plugins/strategy_plugins")
    # print("ansible_managed = Ansible managed: {file} modified on %Y-%m-%d %H:%M:%S by {uid} on {host}\n")
    from ansible.plugins.loader import strategy_loader
    strategy_loader.add_directory("./strategy_plugins")
    strategy_loader.write_cache()

    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-23 12:57:09.651969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm is not None

# Custom implementation of cmd.Cmd

# Generated at 2022-06-23 12:57:12.108815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor')
    print(StrategyModule.__bases__)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:57:15.674955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    print("sm.debugger_active = '%s'" % sm.debugger_active)
    assert sm.debugger_active

# Generated at 2022-06-23 12:57:23.449708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Load the StrategyModule class and confirm the constructor works."""
    class DummyTqm:
        def get_vars(self, varname):
            return None
        def get_host_failed_check(self, host):
            return None
        def get_host_failed_reconnect(self, host):
            return None
        def run_handlers(self, conn, play_context, proceed_with_check_mode=False):
            pass

    dummy = DummyTqm()
    x = StrategyModule(dummy)
    assert x
    assert x.name
    assert x.debugger_active
    assert x.inventory
    assert x.variable_manager
    assert x.loader
    assert x.host_list

# Unit tests for methods of class StrategyModule that are called by
# the playbook executor

# Generated at 2022-06-23 12:57:24.858662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = cmd.Cmd()
    c.onecmd("help")


# Generated at 2022-06-23 12:57:30.243256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)
    assert isinstance(sm, LinearStrategyModule)
    assert isinstance(sm.debugger(), Debugger)
    assert sm.debugger_active
    assert sm.debugger_active


# Generated at 2022-06-23 12:57:36.760172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        def __init__(self):
            self.hosts = {}
            self.hostvars = {}
    tqm = Tqm()
    strategy_module = StrategyModule(tqm)
    pass_msgs = ("The instance of StrategyModule is a LinearStrategyModule or it's sub class.",
                 "The instance of StrategyModule has property 'debugger_active'.")
    for pass_msg in pass_msgs:
        assert getattr(strategy_module, 'debugger_active'), pass_msg


# Generated at 2022-06-23 12:57:40.300566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    argv = ['ansible-playbook', 'test_debug.yml']
    tqm = setup_impl(argv)
    StrategyModule(tqm)


# Generated at 2022-06-23 12:57:41.109712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# Generated at 2022-06-23 12:57:41.815685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 12:57:43.926906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated from package ansible.plugins.strategy.debug

# Generated at 2022-06-23 12:57:46.001077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = type('test_tqm', (object,), {})()
    sm = StrategyModule(test_tqm)
    assert sm.tqm == test_tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:57:47.071689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test for constructor of class StrategyModule")
    StrategyModule()


# Generated at 2022-06-23 12:57:47.852376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:57:49.711866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(set)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:57:52.027110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 12:57:54.036318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule != LinearStrategyModule)


# Generated at 2022-06-23 12:57:56.555364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO(!UNKNOWN): find a way to unit test this module
    return True


# Generated at 2022-06-23 12:57:58.904645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:00.329463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:58:01.470446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 12:58:03.174771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm is not None


# Generated at 2022-06-23 12:58:13.643073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase

    class Debugger(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)

       

# Generated at 2022-06-23 12:58:26.022624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager:
        def __init__(self):
            self.hostvars = {'host1': {'var1': 'val1', 'var2': 'val2'},
                             'host2': {'var1': 'val3', 'var2': 'val4'}}
            self.inventory = [{'hosts': ['host1', 'host2']}]
            self.variable_manager = self
            self.all_hosts = ['host1', 'host2']

        def get_vars(self, play=None, host=None, task=None):
            return self.hostvars[host]

    tqm = TestTaskQueueManager
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm and sm.debugger_active is True


# Unit

# Generated at 2022-06-23 12:58:30.345410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.executor.task_queue_manager
    tqm = ansible.executor.task_queue_manager.TaskQueueManager()
    strategy = StrategyModule(tqm)
    print(strategy)


# Generated at 2022-06-23 12:58:31.949336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var = StrategyModule(None)
    assert var.debugger_active


# Generated at 2022-06-23 12:58:33.172443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    #assert StrategyModule() == "StrategyModule"


# Generated at 2022-06-23 12:58:41.241548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugins
    plugins.add_all_plugin_dirs()
    # Make tqm instance
    from ansible import context
    context._init_global_context(None)
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None
    )
    tqm.run = lambda x: None
    # Create a new instance
    strategy_module = StrategyModule(tqm)
    # Check that instance is created successfully
    assert isinstance(strategy_module, StrategyModule)
    # Check that instance is created successfully
    assert strategy_module.debugger_active is True



# Generated at 2022-06-23 12:58:42.081924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:58:43.166687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:58:44.118104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Constructor for class Debugger

# Generated at 2022-06-23 12:58:49.286913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins import strategy_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = strategy_loader.get('debug', class_only=True)
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    s = StrategyModule(tqm)
# Unit test end


# Generated at 2022-06-23 12:58:50.118572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:52.259305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert(str(isinstance(StrategyModule(tqm=None), LinearStrategyModule)) == "<class 'ansible.plugins.strategy.linear.StrategyModule'>")


# Generated at 2022-06-23 12:58:52.900423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-23 12:58:53.992589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # nothing to do
    pass



# Generated at 2022-06-23 12:58:54.665994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule # constructor exists


# Generated at 2022-06-23 12:59:02.167933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active is True
# End of unit test

    def run(self, iterator, play_context):

        '''
        The "run" method takes an iterator and a play context.  It iterates
        over the list of hosts in the play, and runs the tasks on each host
        in turn.  It returns a list of results, one for each host.

        If --step is specified, this will pause for interactive
        confirmation before continuing.
        '''

        active_hosts = self._queue_task(iterator, play_context)

        all_hosts = self._inventory.get_hosts(iterator._play.hosts)
        variable_manager = iterator._play.get_variable_manager()

        while active_hosts and not self._tqm._terminated:

            self

# Generated at 2022-06-23 12:59:03.667334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:59:05.810497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy.debugger_active


# Generated at 2022-06-23 12:59:07.264101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assertStrategyModule(StrategyModule)


# Generated at 2022-06-23 12:59:13.804969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule:
        def __init__(self, tqm):
            self.tqm = tqm
            self.host_name = ''

    try:
        test_StrategyModule = TestStrategyModule
        print(type(test_StrategyModule))
        assert type(test_StrategyModule) == type(StrategyModule)
    except AssertionError:
        print("test_StrategyModule failed")
    else:
        print("test_StrategyModule passed")



# Generated at 2022-06-23 12:59:16.537959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s, StrategyModule)
    assert s.debugger_active == True
    return

# Introduce a new callback class 

# Generated at 2022-06-23 12:59:17.642828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass



# Generated at 2022-06-23 12:59:19.499418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_result = StrategyModule.__init__(StrategyModule, None)
    assert test_result == None



# Generated at 2022-06-23 12:59:21.201112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cmd.Cmd().cmdloop()

#run_ansible_playbook_from_cmdline(sys.argv, 'linear')

# Generated at 2022-06-23 12:59:27.262756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        pass
    tqm = TestTQM()
    sm = StrategyModule(tqm)
    assert sm is not None


# Generated at 2022-06-23 12:59:28.874612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if StrategyModule != '':
        return True
    else:
        return False


# Generated at 2022-06-23 12:59:38.526306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        t = StrategyModule()
    except TypeError as e:
        print(e)
        print('TypeError: StrategyModule() takes exactly 1 argument (0 given)')
    else:
        print('ok')

#    def _run_play(self, play):
#        for taskblock in play.compile():
#            for task in taskblock:
#                self._run_task(task, play=play)
#
#        return True
#
#    def _run_task(self, task, play=None):
#        ''' run a task in a play '''
#
#        # create a copy of the internal variables to iterate over, as the
#        # regular list will be modified during iteration
#        host_list = self._inventory.list_hosts(task.get_name())
#        hosts

# Generated at 2022-06-23 12:59:47.811915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import debug_strategy_class;
    from ansible.executor.task_queue_manager import TaskQueueManager;
    from ansible.inventory.manager import InventoryManager;
    tqm = TaskQueueManager(
             inventory=InventoryManager(loader=None, sources='./test/test_data/test_inventory.ini'),
             variable_manager=None,
             loader=None,
             options=None,
             passwords=None,
             stdout_callback=None,
             run_additional_callbacks=None,
             run_tree=False,
    );
    dc = debug_strategy_class(tqm=tqm);
    test_result = isinstance(dc, StrategyModule);
    assert test_result == True, 'StrategyModule constructor test failed'



# Generated at 2022-06-23 12:59:50.034357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'debugger_active' in vars(StrategyModule)



# Generated at 2022-06-23 12:59:52.262300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = cmd.Cmd()
    strategy = StrategyModule(tqm)
    tqm.strategy = strategy

# Generated at 2022-06-23 13:00:00.226270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active

# Code from this tutorial
# http://www.onlamp.com/pub/a/python/2004/12/02/tdd_pyunit.html?page=2
    class MyCmd(cmd.Cmd):
        def __init__(self):
            cmd.Cmd.__init__(self)
    
        def do_EOF(self, line):
            return True
    
    prompt = MyCmd()
    try:
        result = prompt.onecmd("EOF")
    except SystemExit as e:
        result = e

    assert result


# This is a list of values that will be passed on to the host object later
# to update the its vars dictionary.
#
# It gets created by this task and updated in the debugger as we iterate through
# the tasks in the playbook.

# Generated at 2022-06-23 13:00:07.915879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit Test for StrategyModule")

    assert StrategyModule is not None
    assert cmd is not None
    assert pprint is not None
    assert sys is not None

    try:
        assert LinearStrategyModule is not None
    except NameError:
        print("Name Error: StrategyModule.py imports LinearStrategyModule.py")
        assert True

    assert StrategyModule.__init__ is not None
    assert StrategyModule.test_StrategyModule is not None

    assert StrategyModule.test_StrategyModule is not None
    assert StrategyModule.test_StrategyModule.__doc__ is not None


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:00:09.204231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This would be called from unittest.main()
    return StrategyModule()



# Generated at 2022-06-23 13:00:11.628884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 13:00:16.767844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # to test constructor of class StrategyModule,
    # create objects here.
    tqm = cmd.Cmd(stdin=sys.stdin, stdout=sys.stdout)
    strategy_module = StrategyModule(tqm)
    # to test if the variables are set to correct values
    assert(strategy_module.debugger_active)

# Generated at 2022-06-23 13:00:18.977370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule('tqm')
    assert test_module
    assert not test_module.tasks_to_run
    assert not test_module.task_queue
    assert not test_module.default_tasks


# Generated at 2022-06-23 13:00:21.761953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Test Queue Manager"
    strategy_module = StrategyModule(tqm)
    assert tqm == strategy_module.tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:23.718219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n\n--- Running debug.StrategyModule tests ---")
    StrategyModule(None)
    print("--- Finished testing ---\n\n")



# Generated at 2022-06-23 13:00:34.230131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module.debugger_active is True

if sys.version_info[0] < 3:
    class DebugInterpreter(cmd.Cmd):

        prompt = "ansible> "
        intro = 'Interactive ansible debug session.\n'\
                'Use the \'help\' or \'?\' command to see a list of available commands.\n'
        doc_header = "Available commands: (type 'help <command>' to see details)"
        misc_header = "Misc commands:"
        undoc_header = "Misc help topics:"
        ruler = "="
        lastcmd = ''
        task = None
        verbose = False
        pp = pprint.PrettyPrinter(indent=4)


# Generated at 2022-06-23 13:00:35.910617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule({'test': 'this'})
    assert S.debugger_active is True



# Generated at 2022-06-23 13:00:46.633327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if __name__ == '__main__':
        sys.path.insert(1, '..')
        from ansible.playbook import Playbook
        from ansible.inventory import Inventory
        from ansible.executor.task_queue_manager import TaskQueueManager

        inventory = Inventory(host_list="../../../examples/hosts")
        playbook = Playbook.load("../../../examples/sample.yml")
        loader, inventory, variable_manager = playbook.get_basedir()
        tqm = TaskQueueManager(
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader
        )
        strategy_module = StrategyModule(tqm)
        assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:00:48.050695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule(None), StrategyModule))



# Generated at 2022-06-23 13:00:52.109575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # print("Test output of constructor of class StrategyModule")
    # tqm = PlaybookExecutor()
    # obj = StrategyModule(tqm)
    # assert obj.tqm == False
    # print("Finished running test")



# Generated at 2022-06-23 13:00:53.873428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 13:00:55.180438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    sm = StrategyModule('')
    assert sm.debugger_active

# Generated at 2022-06-23 13:00:58.330185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm='tqm')
    assert s.name == 'linear'
    assert s.debugger_active == True

###
# TODO: make this into an interactive debug session class
###



# Generated at 2022-06-23 13:01:00.859105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        SM = StrategyModule()
    except:
        return False
    return True




# Generated at 2022-06-23 13:01:01.651549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:01:03.615417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule(tqm=None)
    assert instance.debugger_active



# Generated at 2022-06-23 13:01:06.494252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert(isinstance(StrategyModule(tqm), LinearStrategyModule))


# Generated at 2022-06-23 13:01:09.211301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("test")
    assert s.debugger_active == True


# Generated at 2022-06-23 13:01:11.304246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = ()
    StrategyModule(tqm)


# Generated at 2022-06-23 13:01:14.883998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    strategy.debugger_active = True
    tqm.inventory.get_groups('all')
    print(tqm.inventory.get_groups('all'))
    sys.exit(1)

# Generated at 2022-06-23 13:01:20.917434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Options():
        no_log = False
        step = None

    class HostManager():
        def __init__(self):
            self.inventory = []
            self.options = Options()

        def get_hosts(self, pattern):
            return []

    class Runner():
        def __init__(self):
            self._host_manager = HostManager()

        def get_host_manager(self):
            return self._host_manager

    class TQM():
        def __init__(self):
            self._final_q = None
            self._results_q = None
            self._unreachable_hosts = []
            self._done = False
            self._failed_hosts = []
            self._stats = None
            self.callbacks = None
            self.runner = Runner()


# Generated at 2022-06-23 13:01:25.330432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)
    # Unit test for __init__
    assert isinstance(strategy_module.debugger_active, bool)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 13:01:26.224692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass



# Generated at 2022-06-23 13:01:36.567809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_1 = Task()
    task_1._uuid = "a"
    task_2 = Task()
    task_2._uuid = "b"

    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'

    play = Play()
    play.name = "test play"
    play.hosts = "127.0.0.1"
    play.tasks = [task_1, task_2]
    play.context = play_context


# Generated at 2022-06-23 13:01:38.808441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a.debugger_active
