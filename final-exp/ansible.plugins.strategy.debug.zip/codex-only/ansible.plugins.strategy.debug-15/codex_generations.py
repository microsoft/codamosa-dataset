

# Generated at 2022-06-23 12:51:40.358020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:51:50.756679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = {'hack1': False, 'hack2': False}
        strategy = StrategyModule(tqm)
    except Exception as e:
        print('Error: %s' % e)
        return False

    if not isinstance(strategy, LinearStrategyModule):
        print('Error: constructor did not create instance of derived-class of LinearStrategyModule')
        return False
    if strategy.debugger_active != True:
        print("Error: debugger_active isn't initialized properly")
        return False
    if strategy.tqm != tqm:
        print("Error: tqm isn't initialized properly")
        return False
    if strategy.show_custom_stats != False:
        print("Error: show_custom_stats isn't initialized properly")
        return False

# Generated at 2022-06-23 12:51:52.320213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #mytest = StrategyModule(1)
    assert True

# Generated at 2022-06-23 12:51:53.406462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-23 12:51:57.489969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(object):
        def __init__(self):
            self.callbacks = None
    tqm = Test()
    pprint.pprint(StrategyModule.__doc__)
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:52:00.113769
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    strategy_module = StrategyModule('tqm') 
    assert 'debug' == strategy_module.get_name()
    assert 'Executes tasks in interactive debug session.' == strategy_module.get_doc()
    assert strategy_module.debugger_active is True

# Generated at 2022-06-23 12:52:01.845571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:52:02.912987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    return



# Generated at 2022-06-23 12:52:03.838761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:52:04.955514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:52:08.015030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = 'test'
    strategy_module = StrategyModule(task_queue_manager)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:52:10.155165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info < (2, 7):
        raise Exception('This is only to be used with Python 2.7 and above.')
    assert True

# Generated at 2022-06-23 12:52:20.428392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.utils.display
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["test/inventory"])

# Generated at 2022-06-23 12:52:21.021180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:22.064419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    SM = StrategyModule()


# Generated at 2022-06-23 12:52:27.335730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = {}
    result = StrategyModule(test_tqm)
    assert result.tqm == test_tqm, result.tqm
    assert result.debugger_active == True, result.debugger_active

###
# Mimic of class DebugCLI from strategy/linear.py to avoid circular import
###

# Generated at 2022-06-23 12:52:37.038107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError

# Generated at 2022-06-23 12:52:43.265692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    tqm = strategy_module.tqm
    assert tqm is None
    debugger_active = strategy_module.debugger_active
    assert debugger_active == True

# unit test for _get_next_task method and _get_new_active_step_results method

# Generated at 2022-06-23 12:52:49.316116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # my_tqm = TaskQueueManager
    my_tqm = type('TaskQueueManager', (), {'_final_q': '_final_q'})
    strategy_module = StrategyModule(my_tqm)
    assert '_final_q' == strategy_module.final_q
    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:52:53.712993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(None) != None)

# If 'host' is passed in params it will be used to output debug information
# about that host, otherwise the AIP will be output using the '_debug' task
# action.

# Generated at 2022-06-23 12:52:54.318803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:58.914425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active == True
    assert s.vars_files == []
    assert s.vars_prompt == {}
    assert s.vars_files_specified is True


# Generated at 2022-06-23 12:52:59.859403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'foo' == 'bar'


# Generated at 2022-06-23 12:53:03.257267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm_testing"
    result = StrategyModule(tqm)
    assert result.tqm == tqm and result.debugger_active == True



# Generated at 2022-06-23 12:53:07.550540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class tqm:
        def __init__(self, tqm):
            self.var = 1

    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:09.703306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock_tqm()
    sm = StrategyModule(tqm)
    assert sm.debugger_active


# Generated at 2022-06-23 12:53:11.058754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:12.474987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  StrategyModule(tqm)
  return True


# Generated at 2022-06-23 12:53:16.370928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Default constructor')
    tqm = None
    StrategyModule(tqm)

    StrategyModule()
    assert True

# class DebugStrategy

# Generated at 2022-06-23 12:53:18.025587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TODO: Implement constructor test
    assert False


# Generated at 2022-06-23 12:53:18.994042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)


# Generated at 2022-06-23 12:53:22.231969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 12:53:22.909651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:26.195603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = ['a', 'b']
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module.tqm == task_queue_manager
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:53:34.647101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    name = TaskInclude.load(dict(include='somestuff.yml'))
    handler_name = HandlerTaskInclude.load(dict(include='somestuff.yml'))
    state = StrategyModule(name)
    state1 = StrategyModule(handler_name)
    assert isinstance(state, StrategyModule) and isinstance(state1, StrategyModule)


# Generated at 2022-06-23 12:53:36.474929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s.debugger_active == True

# Generated at 2022-06-23 12:53:40.821260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nconstructor of class StrategyModule')
    ansible_playbook = 'test_playbook.yaml'
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:53:42.689339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule()
    assert stm.debugger_active


# Generated at 2022-06-23 12:53:51.363731
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:53:53.271492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = None
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module is not None



# Generated at 2022-06-23 12:53:55.448541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test Mode.StrategyModule.__init__(self, tqm)')
    pass


# Generated at 2022-06-23 12:53:58.896003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("\ntest_StrategyModule()")
    p = StrategyModule(None)
    assert p.debugger_active, "StrategyModule's constructor fail."



# Generated at 2022-06-23 12:54:02.556840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestPostCondition()
    strategy = StrategyModule(tqm)

    assert(strategy.debugger_active == True)

# TestPostCondition is a mock for ansible.plugins.loader.PostCondition

# Generated at 2022-06-23 12:54:04.792363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == True

    return


# Generated at 2022-06-23 12:54:07.816554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    try:
        StrategyModule(tqm)
    except UnboundLocalError:
        print('test_StrategyModule: Passed')


# Generated at 2022-06-23 12:54:08.884268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Generated at 2022-06-23 12:54:14.578426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.host_result_callback = None

    test_tqm = TestTqm()
    test_module = StrategyModule(test_tqm)
    print('test_module.debugger_active == True: %s' % test_module.debugger_active)
    assert test_module.debugger_active is True


# Generated at 2022-06-23 12:54:19.445434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule(tqm=None)
    assert isinstance(test_strategy_module, LinearStrategyModule)
    assert test_strategy_module.debugger_active == True


# Generated at 2022-06-23 12:54:22.339250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #tqm = TaskQueueManager()
    try:
        tqm = StrategyModule("tqm")
        assert tqm.debugger_active == True
    except NameError:
        assert 0


# Generated at 2022-06-23 12:54:27.589242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None)
    strategy = StrategyModule(tqm)

    assert not isinstance(strategy, LinearStrategyModule)


# Generated at 2022-06-23 12:54:32.716265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm is tqm
    assert len(strategy_module._stats) == 0
    assert isinstance(strategy_module._display, pprint.PrettyPrinter)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:54:35.458125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        c = StrategyModule('tqm')
        assert c.debugger_active == True, "test_StrategyModule: c.debugger_active is not true"

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 12:54:37.326487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    assert StrategyModule(tqm).debugger_active is True;


# Generated at 2022-06-23 12:54:40.377465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)

    assert strategymodule.debugger_active is True


# Generated at 2022-06-23 12:54:47.888410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class ansible:
        def __init__(self):
            self.callbacks = None
    class tqm:
        def __init__(self):
            self.at_start = None
            self.at_done = None
            self.global_vars = None
            self.inventory = None
            self.ansible = ansible()
    tqm = tqm()
    my_StrategyModule = StrategyModule(tqm)

test_StrategyModule()

# Generated at 2022-06-23 12:54:50.776078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    if strategy.debugger_active != True:
        raise Exception('Failed to initialize debugger_active')


# Generated at 2022-06-23 12:54:55.184846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sentinel = object()
    # tqm = sentinel
    sm = StrategyModule(tqm=sentinel)
    assert sm.debugger_active == True
    assert sm.tqm == sentinel


# Generated at 2022-06-23 12:54:55.738711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:54:56.674527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-23 12:54:59.134106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test for class StrategyModule")
    sm = StrategyModule(None)
    print("sm.debugger_active: " + str(sm.debugger_active))
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:55:03.487675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test assumption:
    # subclassing DynamicBrowser with constructor(self)
    # shall create an empty object with no attributes
    test_mod = StrategyModule(None)
    # pprint(vars(test_mod))
    assert vars(test_mod) == {}

# override of Ansible to prevent non-interactive exit

# Generated at 2022-06-23 12:55:04.169864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_tqm()
    StrategyModule(tqm)


# Generated at 2022-06-23 12:55:05.414422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:55:10.501856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert type(strategy_module) == StrategyModule
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:55:12.339193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()



# Generated at 2022-06-23 12:55:22.879526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    C = '''
    - hosts: all
      tasks:
      - name: do nothing
        command: /bin/true
    '''
    P = Play().load(C, variable_manager=VariableManager(), loader=DataLoader())
    I = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager()
    variable_manager.set_inventory(I)

# Generated at 2022-06-23 12:55:25.502048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass(object):
        def __init__(self):
            pass

    test = StrategyModule(TestClass())
    assert test.debugger_active == True



# Generated at 2022-06-23 12:55:35.163506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    assert sm.tqm == tqm
    assert sm.tqm_failed == False
    assert sm.tasks == []
    assert sm.task_queue == []
    assert sm.blocked_hosts == {}
    assert sm.results_callback == None
    assert sm.display.verbosity == 0
    assert sm.display.deprecated_warnings == True
    assert sm.display.skipped_hosts == set()
    assert sm.iterator == None
    assert sm.callbacks == None
    assert sm.remote_user == None
    assert sm.remote_pass == None
    assert sm.connection_user == None
    assert sm.connection_pass == None
    assert sm.become_method == None

# Generated at 2022-06-23 12:55:37.762226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_instance = StrategyModule('tqm')
    assert strategy_module_instance.debugger_active == True


# Generated at 2022-06-23 12:55:41.819869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        def __init__(self):
            self.var = 1

    tqm = TestTQM()
    module = StrategyModule(tqm)
    assert module.tqm == tqm
    assert module.debugger_active is True



# Generated at 2022-06-23 12:55:46.863406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creating an instance of class StrategyModule
    # This is a dummy class
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    # Calling __init__ of StrategyModule
    strategy_module.__init__(tqm)



# Generated at 2022-06-23 12:55:47.603775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:55:49.426559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 12:55:51.058695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert isinstance(strategy, LinearStrategyModule)

# Generated at 2022-06-23 12:55:54.684707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger = StrategyModule(None)
    assert debugger.debugger_active == True
    assert debugger.tqm == None


# Generated at 2022-06-23 12:56:00.132276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm(object):
        def __init__(self):
            self.hosts = {
                'host1': MockHost('host1')
            }
            self.all_hosts = [self.hosts['host1']]

        def enable_logging(self):
            pass


# Generated at 2022-06-23 12:56:03.001172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:56:04.270596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule.__doc__)


# Generated at 2022-06-23 12:56:13.156441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create instance of class StrategyModule
    #tqm = {'foo': 1, 'bar': '2', 'baz': [3, 2, 1]}
    tqm = {'foo': 1}
    stm = StrategyModule(tqm)
    assert isinstance(stm, StrategyModule)
    assert isinstance(stm, LinearStrategyModule)
    assert isinstance(stm.tqm, dict)
    assert isinstance(stm.debugger_active, bool)
    assert stm.debugger_active is True
    assert stm.tqm == {'foo': 1}
    assert stm.tqm['foo'] == 1
    assert stm.debugger_active is True


# Generated at 2022-06-23 12:56:17.127560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    print("Testing constructor")
    tqm = TaskQueueManager(None, None, None, None, None, False)
    obj = StrategyModule(tqm)
    print(obj)


# Generated at 2022-06-23 12:56:18.796259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    print(sm.__dict__)

    return sm


# Generated at 2022-06-23 12:56:28.066616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            import ansible.executor.task_queue_manager as task_queue_manager
            try:
                self.tqm = task_queue_manager.TaskQueueManager(inventory=None, variable_manager=None, loader=None,
                                                               options=None, passwords=None, stdout_callback=None)
                self.sm = StrategyModule(self.tqm)
            except:
                unittest.TestCase.fail("Failed to create strategy module.")

        def tearDown(self):
            pass

        def test_attributes(self):
            self.assertEqual(self.sm.debugger_active, True)

    test_case = TestStrategyModule()
    test_case.set

# Generated at 2022-06-23 12:56:29.766968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    #tqm = None
    #assert StrategyModule(tqm).debugger_active == True


# Generated at 2022-06-23 12:56:33.954230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM: pass
    TQM.hosts = { 'host1': {}, 'host2': {} }
    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:56:36.216842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == """Executes tasks in interactive debug session.

Task execution is 'linear' but controlled by an interactive debug session."""


# Generated at 2022-06-23 12:56:43.274692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug as debug_strategy_module
    strategy_module = debug_strategy_module.StrategyModule
    assert strategy_module.__name__ == "StrategyModule"
    assert issubclass(strategy_module, ansible.plugins.strategy.linear.StrategyModule)
    assert strategy_module.__doc__ == 'Debug Strategy Module Class'
# end of unit test for constructor of class StrategyModule


# Generated at 2022-06-23 12:56:51.484540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = ['ansible-playbook', '-i', 'hosts', 'playbooks/debug_strategy_playbook.yml', '--verbose']
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    from ansible.plugins import module_loader
    import ansible.module_utils.basic
    import ansible.vars
    import ansible.executor
    import ansible.vars.manager
    import ansible.cli.playbook
    import ansible.parsing.dataloader
    import ansible.utils.plugin_docs
    import ansible.utils.vars
    
    # Load modules

# Generated at 2022-06-23 12:56:52.073177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:58.024612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test for constructor of class StrategyModule")
    tqm = "tqm"
    test = StrategyModule(tqm)
    # tqm has to be set
    assert(test.tqm == tqm)
    # debugger_active has to be set to True
    assert(test.debugger_active == True)
# eof test_StrategyModule



# Generated at 2022-06-23 12:57:01.526284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Base class is "object", so inherits from it, but does not need to be tested
    # TODO: test for the constructor of super class
    pass


# Generated at 2022-06-23 12:57:02.643008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:57:03.321992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:06.437828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm
    assert hasattr(sm, 'debugger_active')
    assert sm.debugger_active


# Generated at 2022-06-23 12:57:11.316792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import __main__ as _main
    except ImportError:
        import __builtin__ as _main
    tqm = _main.tqm
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:57:18.422171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    task_queue_manager = object()
    strategymodule = ansible.plugins.strategy.debug.StrategyModule(task_queue_manager)
    print(strategymodule.__class__.__name__)
    assert strategymodule.__class__.__name__ == 'StrategyModule'
    assert strategymodule.debugger_active == True

# Run unit test
test_StrategyModule()

# Generated at 2022-06-23 12:57:23.571153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('StrategyModule constructor test')
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# The main Cmd subclass

# Generated at 2022-06-23 12:57:24.270009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:57:25.681029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'strategy.debug'


# Generated at 2022-06-23 12:57:26.298351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:35.909976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = tqmMock()
    sm = StrategyModule(test_tqm)
    assert(isinstance(sm, StrategyModule))
    assert(sm.tqm == test_tqm)
    assert(not sm.is_task_included(test_tqm, None))
    assert(not sm.is_task_included(test_tqm, {'debugger_active': False}))
    assert(sm.is_task_included(test_tqm, {'debugger_active': True}))
    assert(sm.is_task_included(test_tqm, {'tags': ['debugger']}))


# Generated at 2022-06-23 12:57:41.159833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.runner_name = "RunnerName"

    strategy_module = StrategyModule(TestTQM())

    assert strategy_module.runner_name == "RunnerName"
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:57:46.753635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.connections.local import Connection
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    def _hosts_list():
        return [
            'localhost'
        ]

    options = C.options
    options.module_path = ['.']
    options.forks = 1

    variable_manager = C.VariableManager()
    variable_manager.extra_vars = {'myvar': 'myvalue'}
    loader = C.DataLoader()
    inventory = C.Inventory(loader)
    connection = Connection()

    play_source

# Generated at 2022-06-23 12:57:49.711976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1: Test the default value of class variables
    t1 = StrategyModule("test_task_queue_manager")
    assert t1.debugger_active == True
    

# Generated at 2022-06-23 12:57:57.163789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    import ansible.plugins.loader as plugin_loader
    tqm = ansible.plugins.strategy.debug.TQM_Stub()
    strategy = ansible.plugins.strategy.debug.StrategyModule(tqm)
    assert not hasattr(strategy, '_debugger_active'), ("='%s'" % strategy._debugger_active)



# Generated at 2022-06-23 12:57:57.666216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:57:59.285437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:03.228180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    instance = StrategyModule(tqm)
    assert(tqm is instance.tqm)
    assert(instance.debugger_active is True)



# Generated at 2022-06-23 12:58:08.116674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None, "Unable to create StrategyModule object"
    assert strategy_module.debugger_active is True, "Debugger active was not enabled"


# Generated at 2022-06-23 12:58:10.687553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # different parameter for class StrategyModule
    strate = StrategyModule(1)
    print(type(strate))
    print(strate.__class__)
    print(str(strate.__str__()))
    strate.debugger_active=False




# Generated at 2022-06-23 12:58:14.298563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    the_list = []
    class TestS(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            the_list.append(1)
    tqm = TestS(tqm=None)
    assert 1 in the_list


# Generated at 2022-06-23 12:58:16.034359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)



# Generated at 2022-06-23 12:58:17.179739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c_StrategyModule = StrategyModule(0)
    assert(c_StrategyModule is not None)



# Generated at 2022-06-23 12:58:20.402412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    my_strategy_module = StrategyModule(tqm)
    assert my_strategy_module.debugger_active
    
    

# Generated at 2022-06-23 12:58:21.277144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("task_queue_manager") is not None


# Generated at 2022-06-23 12:58:22.100608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return None


# Generated at 2022-06-23 12:58:23.864911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = "test")
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:24.852837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 12:58:27.794577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert(strategy_module.debugger_active == True)

# Class to inherit from cmd.Cmd, so that we can use the default function to parse command.

# Generated at 2022-06-23 12:58:31.536193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    strategymodule = StrategyModule(tqm)
    assert tqm == strategymodule._tqm
    assert strategymodule.debugger_active == True


# Generated at 2022-06-23 12:58:32.550254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-23 12:58:35.715840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    strategy_module.run()

# Generated at 2022-06-23 12:58:36.670411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()



# Generated at 2022-06-23 12:58:37.813031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None



# Generated at 2022-06-23 12:58:48.257338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm(object):

        def __init__(self, *args, **kwargs):
            self.stats = dict(processed={}, ok={}, failures={}, dark={}, rescued={}, ignored={})

        def get_host_list(self):
            return ['localhost']

        def _tqm_make_passwords(self):
            return dict(conn_pass=None, become_pass=None)

        def _tqm_options(self):
            return dict(extra_vars=dict(), remote_user='user', remote_pass='pass')

        def all_vars(self, host):
            return dict(conn_pass=None, become_pass=None)

        def send_callback(self, type, host, result):
            self.stats[type][host] = result

    strategy = StrategyModule

# Generated at 2022-06-23 12:58:49.057877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:58:50.527741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm={})


# Generated at 2022-06-23 12:58:54.409010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm._shared_loader_obj = True
    tqm.loader = True
    tqm.inventory = True
    tqm.variable_manager = True
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.host_states == {}
    assert strategy_module.tqm == tqm



# Generated at 2022-06-23 12:58:56.060223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    server = StrategyModule({})
    assert isinstance(server, LinearStrategyModule)
    assert server.debugger_active == True


# Generated at 2022-06-23 12:59:01.771594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Mock tqm, since tqm.__init__() will fail without a config
    class MockTqm:
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)
    MockTqm.__init__.side_effect = lambda *args, **kwargs: None # nosec

    tqm = MockTqm()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:59:05.857139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'test_tqm'
    sm = StrategyModule(test_tqm)
    assert sm.tqm == test_tqm
    assert sm.debugger_active



# Generated at 2022-06-23 12:59:11.053454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #### Set up mock objects
    tqm = MockTaskQueueManager()
    strategyModule = StrategyModule( tqm )
    print("strategyModule.debugger_active=%s" % (strategyModule.debugger_active))
    assert strategyModule.debugger_active == True

#### Set up mock objects

# Generated at 2022-06-23 12:59:12.482470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)

# Generated at 2022-06-23 12:59:17.527308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.modules['__main__'].Tqm = type('Tqm', (object,), {})()
    sys.modules['__main__'].Tqm.hostvars = {}
    sys.modules['__main__'].Tqm.callbacks = ansible.plugins.callback.CallbackModule()
    strategy = StrategyModule(sys.modules['__main__'].Tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:59:22.987309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # If constructor of class StrategyModule is called successfully,
    # then return True
    try:
        StrategyModule(None)
        return True
    except Exception as err:
        print('Got exception when unit testing StrategyModule constructor.\n%s' % err)
        # If constructor of class StrategyModule is NOT called successfully,
        # then return False
        return False


# Implements a simple interactive debugger for Ansible

# Generated at 2022-06-23 12:59:26.421657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule("import")
    assert p.debugger_active, "Error in task execution is linear but controlled by an interactive debug session."



# Generated at 2022-06-23 12:59:32.872291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == test_tqm
    assert strategy_module.host_list == []
    assert strategy_module.inventory == None
    assert strategy_module.module_vars == {}
    assert strategy_module.variable_manager == None
    assert strategy_module.loader == None


# Generated at 2022-06-23 12:59:33.787881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)



# Generated at 2022-06-23 12:59:35.098226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testobj = StrategyModule(tqm="tqm")


# Generated at 2022-06-23 12:59:37.172943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = object()
    assert StrategyModule(t).tqm == t
    assert StrategyModule(t).debugger_active is True


# Generated at 2022-06-23 12:59:44.371914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #print("This is StrategyModule")

    class Test(object):
        def __init__(self, arg0):
            self.arg0 = arg0

    #print("\nTesting StrategyModule.__init__()")
    instance = StrategyModule(Test("TEST0"))
    #print("\n")
    
    #print("\nTesting StrategyModule.__init__()")
    instance = StrategyModule(Test("TEST1"))
    #print("\n")


# This class is a simple debugger for Ansible playbooks.

# Generated at 2022-06-23 12:59:44.960954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:46.685204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)

        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 12:59:50.781708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create new instance for testing
    test_tqm = 0
    strategy_module = StrategyModule(test_tqm)
    # Check value of variable
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:59:53.858683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Creating task queue and strategy module")
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:59:54.774694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 13:00:00.317004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestingStrategyModule(LinearStrategyModule):
        def __init__(self, tqm):
            super(TestingStrategyModule, self).__init__(tqm)
            self.debugger_active = True

    test_object = TestingStrategyModule()
    assert(type(test_object) == TestingStrategyModule)



# Generated at 2022-06-23 13:00:02.609506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Use interactive debugger for task execution."
    assert StrategyModule(tqm).debugger_active == True


# Generated at 2022-06-23 13:00:04.629594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        task_queue_manager = type
        StrategyModule(task_queue_manager)
        assert True
    except:
        assert False



# Generated at 2022-06-23 13:00:06.888143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("ansible.plugins.strategy.debugger")


# Generated at 2022-06-23 13:00:08.861049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert type(sm) is StrategyModule
    assert sm.debugger_active



# Generated at 2022-06-23 13:00:11.754509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = None
    # Act
    t = StrategyModule(tqm)
    # Assert
    pprint.pprint(t)



# Generated at 2022-06-23 13:00:18.534629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Dummy setup for testing.
    class TaskQueueManager:
        def __init__(self):
            self.stats = {}

    # Using TaskQueueManager class, initialize StrategyModule class.
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    
    # Show debug results.
    print('[StrategyModule] sm.debugger_active = ' + str(sm.debugger_active))


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0], '-v'])

# Generated at 2022-06-23 13:00:20.105513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#    test_module = StrategyModule(tqm)
    fake_tqm = {}
    StrategyModule(fake_tqm)


# Generated at 2022-06-23 13:00:27.252918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from .strategy_plugins.strategy_base import StrategyBase
        return StrategyBase
    except ImportError:
        return None

StrategyModule.__test__ = {
    'test_StrategyModule': test_StrategyModule
}


# Generated at 2022-06-23 13:00:28.304164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)


# Generated at 2022-06-23 13:00:38.236235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm(object):
        def __init__(self):
            self.host_key_checking = False
            self.remote_user = 'root'
            self.private_key_file = '/path/to/private_key'
            self.ssh_extra_args = []
            self.connection_plugins = []
            self.new_stdin = sys.stdin
            self.shared_loader_obj = None
            self.loader = None
            self.stats = None
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.callbacks = None
            self.result_callback = None
            self.options = None
            self.password = None
            self.subset = None


# Generated at 2022-06-23 13:00:39.421053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Unit tests for methods of class StrategyModule


# Generated at 2022-06-23 13:00:47.685954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import ansible.playbook
    import ansible.utils
    import ansible.callbacks
    import ansible.inventory.manager

    stats = ansible.callbacks.AggregateStats()
    runner_cb = ansible.callbacks.DefaultRunnerCallbacks()
    display = ansible.utils.display.Display()

# Generated at 2022-06-23 13:00:50.135820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("======StrategyModule======")
    print("test_StrategyModule")
#    s = StrategyModule()




# Generated at 2022-06-23 13:00:52.615473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [(0, 0)]
    strategy = StrategyModule(tqm)


# Class Debugger

# Generated at 2022-06-23 13:00:55.103993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert len(StrategyModule.__doc__) > 0
    except AssertionError:
        print('Failed to test StrategyModule.__doc__')
        raise



# Generated at 2022-06-23 13:00:56.157602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:00:57.656703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Class CmdInteract is subclassed from cmd.Cmd
# to support commandline interface of Ansible's debug strategy

# Generated at 2022-06-23 13:01:09.183522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.verbosity = -1
            self.stats = {}
            self.cur_task = None
            self.cur_worker_num = 0
            self.failed_hosts = {}
            self.cur_play = None
            self.cur_play_path = None
            self.stdout_callback = None
            self.hostvars = {}
            self.private_key_file = None
            self.password = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.inventory = None
            self.internal_poll_interval = None
            self.basedir = None
            self.conditional = None
            self.diff = None
            self.module_vars = None

# Generated at 2022-06-23 13:01:10.949472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)
    return True



# Generated at 2022-06-23 13:01:14.514894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm():
        def __init__(self):
            pass

    tqm = Tqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 13:01:15.160729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:01:20.211748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # This is not a good test case because a mock object is created and used.
    # class MockTaskQueueManager():
    #     def __init__(self):
    #         print('MockTaskQueueManager constructor')
    #
    # x = StrategyModule(MockTaskQueueManager())
    # print('test_StrategyModule() class test: object x =', x)


# Interactive debug session

# Generated at 2022-06-23 13:01:23.527213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestDebugger(object):
        pass
    tqm = TestDebugger()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:01:28.097639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class FakeTQM():
        # TODO: do we really need to stub TQM object to test constructor?
        pass

    tqm_object = FakeTQM()
    strategy_object = StrategyModule(tqm_object)
    assert strategy_object.debugger_active is True


# Generated at 2022-06-23 13:01:32.487208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test for constructor of StrategyModule.")
    # Construct
    S = StrategyModule(0)
    if isinstance(S, object) == False:
        print("Error, StrategyModule constructor failed.")
        return False

# Constructor test
test_StrategyModule()

# Generated at 2022-06-23 13:01:33.399967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-23 13:01:34.473324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:01:38.425799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    tqm = TaskQueueManager(
        inventory=InventoryManager(host_list='./tests/hosts'),
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None
    )
    sm = StrategyModule(tqm)
    assert sm


# Generated at 2022-06-23 13:01:45.159121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    # Create TaskQueueManager instance.
    from ansible import context
    from ansible.plugins.loader import callback_loader, action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    context._init_global_context(None, None)
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=callback_loader.get('normal'),
        run_additional_callbacks=True,
        run_tree=False
    )
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)