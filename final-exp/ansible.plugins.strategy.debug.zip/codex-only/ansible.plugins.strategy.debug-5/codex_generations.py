

# Generated at 2022-06-23 12:51:43.222027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'vars':{}}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:51:44.966223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:51:46.584351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    StrategyModule(tqm);


# Generated at 2022-06-23 12:51:50.756734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = 'host1'
    tqm = {host: 'Some data'}
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm, "tqm should match argument"
    assert strategy.debugger_active == True, "debugger active should be true"



# Generated at 2022-06-23 12:51:53.901478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class(StrategyModule)
    # TODO: Need setup
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)



# Generated at 2022-06-23 12:51:55.627495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:51:58.300788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MyTQM(object):
        pass
    tqm = MyTQM()
    tqm.stats = {}
    strategy = StrategyModule(tqm)
    assert(strategy.debugger_active)


# Generated at 2022-06-23 12:51:58.844826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:52:00.323485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:52:01.632500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:04.203219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'tasks': []}
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:52:05.498460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule(2)
    assert res.debugger_active


# Generated at 2022-06-23 12:52:07.422269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active == True
    assert hasattr(sm, 'tqm') == False


# Generated at 2022-06-23 12:52:11.507199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy = StrategyModule(tqm)
    assert (strategy is not None)
    assert (strategy.tqm == "")
    assert (strategy.debugger_active == True)
    assert (strategy.name == "debug")

# Execute tasks in "strategy": "debug" mode

# Generated at 2022-06-23 12:52:13.472998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test if strategy module class exists
    strategy_module = StrategyModule(None)
    assert strategyModule




# Generated at 2022-06-23 12:52:14.112515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:52:24.130429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple

    import ansible.constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler

    p = Play()
    r = Role()
    h = Handler()
    b = Block

# Generated at 2022-06-23 12:52:26.294507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 3
    module = StrategyModule(tqm)

    assert tqm == module.tqm
    assert True == module.debugger_active

# Execute tasks by using interactive debug session

# Generated at 2022-06-23 12:52:27.010363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:29.708151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_impl = StrategyModule(tqm)
    assert isinstance(strategy_impl, StrategyModule)
    assert strategy_impl.debugger_active



# Generated at 2022-06-23 12:52:30.432276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:52:33.051162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("executing")
    tqm = None
    #strategy_module_obj = StrategyModule(tqm)
    print("passed test")
    


# Command Debugger is a class used by the debugger which handles user input

# Generated at 2022-06-23 12:52:33.626533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:52:34.661614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__(None)


# Generated at 2022-06-23 12:52:41.685254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible import context
    # Load the inventory and get a list of hosts
    context.CLIARGS = {'inventory': 'inventory'}
    inventory = InventoryManager(loader=None, sources=[context.CLIARGS['inventory']])
    host_list = inventory.get_hosts()
    # Create a variable manager which will later save our variables
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # Create a list of tasks to be executed
    tasks_include = open('playbooks/test/test.task', 'r').read()
    # Create a list of roles to be executed

# Generated at 2022-06-23 12:52:43.506016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)




# Generated at 2022-06-23 12:52:52.004765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of the slector class
    class Tqm(object):
        def __init__(self):
            self.hostvars = dict()
    tqm = Tqm()
    lsm = StrategyModule(tqm)
    assert lsm.debugger_active
    assert hasattr(lsm, 'tqm')
    assert hasattr(lsm, '_vars_cache')
    assert hasattr(lsm, '_vars_per_host')
    assert hasattr(lsm, '_inventory')


# Generated at 2022-06-23 12:52:55.360151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM:
        pass
    tqm = DummyTQM()
    strategy = StrategyModule(tqm)
    assert(isinstance(strategy, LinearStrategyModule))
    assert(strategy.debugger_active)


# Generated at 2022-06-23 12:52:56.424883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:07.920530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.connection.network_cli import Connection as network_cli
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import Include
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars import VariableManager

    host1 = "localhost"
    host2 = "localhost"
    host3 = "localhost"

    play1 = Play().load({'name': 'test1', 'hosts': 'all'},
        variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-23 12:53:09.303303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-23 12:53:11.005824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    pass



# Generated at 2022-06-23 12:53:12.393438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)


# Generated at 2022-06-23 12:53:23.257176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM(object):
        def __init__(self):
            self.__result_callback = None

        @property
        def stats(self):
            return mock.Mock(return_value=None)

        def run(self):
            return

        def get_host_result(self):
            return

        def get_result_callback(self):
            return self.__result_callback

        def set_result_callback(self, result_callback):
            self.__result_callback = result_callback

        result_callback = property(fset=set_result_callback, fget=get_result_callback)

        @property
        def inventory(self):
            return mock.Mock(return_value=None)


# Generated at 2022-06-23 12:53:27.506425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit test for StrategyModule.__init__()')

    import mock
    
    tqm = mock.MagicMock()
    tqm = tqm.start
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True, 'Error: debugger_active error'


# Generated at 2022-06-23 12:53:32.448777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n --- Test StrategyModule() ---")
    sm = StrategyModule(None)
    print(sm)
    sm.debugger_active = True
    print(sm)
    sm.debugger_active = False
    print(sm)
    sm.debugger_active = True
    print(sm)



# Generated at 2022-06-23 12:53:39.093578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a task queue manager.
    try:
        from ansible.executor.task_queue_manager import TaskQueueManager
    except:
        from ansible.task.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        host_list=['alexandria.local'],
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )

    # Instantiate a strategy module.
    try:
        from ansible.utils import plugin_docs
    except:
        from ansible.plugins import plugin_docs
    fqn = 'ansible.plugins.strategy.linear'
    my_module = plugin_docs.get_strategy_plugins().get(fqn, None)()
    my_module

# Generated at 2022-06-23 12:53:46.257575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTqm(object):
        def __init__(self, module_name='test', background=0, module_args='', private_data_dir='', log_path='default'):
            self.module_name = module_name
            self.background = background
            self.module_args = module_args
            self.private_data_dir = private_data_dir
            self.log_path = log_path

    tqm = FakeTqm()
    strategy_module = StrategyModule(tqm)

    assert tqm.background == 0



# Generated at 2022-06-23 12:53:47.703197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestShell()
    sm = StrategyModule(tqm)


# Generated at 2022-06-23 12:53:50.273336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    s = StrategyModule(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:53:51.157816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:52.593182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('type of StrategyModule', type(StrategyModule))



# Generated at 2022-06-23 12:53:59.846167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import debug
    from ansible.template import Templar
    from ansible.vars.facts import Facts
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    debug_mod = debug.StrategyModule(None)
    assert debug_mod.debugger_active == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:54:03.203619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        pass
    obj_tqm = TQM()
    obj_StrategyModule = StrategyModule(obj_tqm)
    assert isinstance(obj_StrategyModule, StrategyModule)


# Generated at 2022-06-23 12:54:04.511600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()


# Generated at 2022-06-23 12:54:13.278191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM():
        def __init__(self):
            self.host_list = 1
            self.inventory = 2
            self.name = "tqm"
            self.stdout_callback = "json"
            self.options = 3
            self.variable_manager = 4
            self.shared_loader_obj = 5
            self.loader = 6
            self.callback_plugins = []
            self.stdout_callback = None
            self.stats = 8
            self.connection_users = {}
            self.passwords = {}
            self.stdout_callback = "json"

    tqm = FakeTQM()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm



# Generated at 2022-06-23 12:54:16.993660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:54:24.818426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play

    class TestStrategyModule(unittest.TestCase):
        def test_constructor(self):
            self.assertRaises(TypeError, StrategyModule)
            loader = DataLoader()
            variables = VariableManager()
            inventory = Inventory(loader=loader, variable_manager=variables)

# Generated at 2022-06-23 12:54:32.366338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__str__.__name__ == 'StrategyModule'
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__code__.co_argcount == 2

# Should be able to add to StrategyModule
test_module = StrategyModule.__dict__
assert 'debugger_active' in test_module

# Should be able to add to StrategyModule
test_StrategyModule()

# Generated at 2022-06-23 12:54:36.539292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    result = StrategyModule(tqm)
    assert result is not None
    assert result.selected_tasks == []
    assert result.tqm == tqm
    assert result.host_errors == {}
    assert result.host_results == {}
    assert result.debugger_active == True


# Generated at 2022-06-23 12:54:38.073635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule.__doc__)
    assert StrategyModule is not None



# Generated at 2022-06-23 12:54:42.830132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n Start the test_StrategyModule")
    StrategyModule()
    print("\n End the test_StrategyModule")

if __name__ == '__main__':
    # print("StrategyModule:%s", StrategyModule() )
    test_StrategyModule()

# Generated at 2022-06-23 12:54:48.043037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.var = "var"
    tqm = TestTQM()
    obj = StrategyModule(tqm)
    assert tqm == obj._tqm


# Generated at 2022-06-23 12:54:49.102765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = StrategyModule(tqm)


# Generated at 2022-06-23 12:54:59.345835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_dict = {'action': 'test_action', 'args': 'test_args', 
                 'async_val': 1, 'async_seconds': 1, 'changed_when': 'test_changed_when',
                 'connection': 'test_connection', 'delegate_to': 'test_delegate_to', 'failed_when': 'test_failed_when',
                 'notify': 'test_notify', 'poll': 1, 'register': 'test_register', 'retries': 1,
                 'until': 'test_until', 'when': 'test_when'}
    test_task = dict2obj(test_dict)
    test_tasks = [test_task]
    test_host = dict2obj({'name': 'test_host', 'connection': 'test_connection'})

# Generated at 2022-06-23 12:54:59.869050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:55:04.158698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTqm():
        def __init__(self):
            pass

    tqm = FakeTqm()
    sm = StrategyModule(tqm)
    import pprint
    pprint.pprint(sm.__dict__)



# Generated at 2022-06-23 12:55:06.724928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == __doc__
    assert StrategyModule.__init__.__doc__ == LinearStrategyModule.__init__.__doc__
    assert hasattr(StrategyModule, 'debugger_active')
# Test End
    



# Generated at 2022-06-23 12:55:07.897308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:55:14.455869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            StrategyModule.__init__(self, tqm)
            self.debugger_active = True

    test_class = TestStrategyModule(tqm=None)
    assert test_class.debugger_active == True

# unit test for execute module function of class StrategyModule

# Generated at 2022-06-23 12:55:24.401300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = __import__('unit_test')
    x = StrategyModule(tqm)
    d = dir(x)
    assert 'tqm' in d
    assert '_blocks' in d
    assert '_tqm' in d
    assert '_final_q' in d
    assert '_hooks' in d
    assert '_reset_queues' in d
    assert '_display' in d
    assert '_save_callbacks' in d
    assert '_stats' in d
    assert '_inventory' in d
    assert '_debugger_active' in d
    assert 'get_host_variables' in d
    assert 'get_variable' in d
    assert 'get_vars' in d
    assert 'add_tasks' in d
    assert 'run' in d

# Generated at 2022-06-23 12:55:25.912852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.debugger_active


# Generated at 2022-06-23 12:55:27.840713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:55:32.121748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestDebugger(cmd.Cmd):
        def help(self, *args):
            pass

        def ns(self):
            return dict(__builtins__=__builtins__)

    tqm = TestDebugger()

    StrategyModule(tqm)


# Load the module strategy plugin

# Generated at 2022-06-23 12:55:35.395448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # run empty __init__(tqm)
    strategy = StrategyModule(None)
    assert strategy
    return strategy



# Generated at 2022-06-23 12:55:37.130034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    debugger_active = StrategyModule(None).debugger_active
    assert debugger_active is True

# Generated at 2022-06-23 12:55:38.422613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None).debugger_active


# Generated at 2022-06-23 12:55:40.271361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = StrategyModule
    print(type(task_queue_manager))


# Generated at 2022-06-23 12:55:42.025271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Debugger for unit test

# Generated at 2022-06-23 12:55:43.940352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active
    return True


# Generated at 2022-06-23 12:55:45.513965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:55:47.511935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = "test"

    # Act
    obj = StrategyModule(tqm)

    # Assert
    assert obj.debugger_active == True



# Generated at 2022-06-23 12:55:48.211682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:55:50.622247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testValue = StrategyModule()
    assert testValue.debugger_active == True


# Generated at 2022-06-23 12:55:52.074744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    sm = StrategyModule(tqm)
    assert sm.debugger_active

# Generated at 2022-06-23 12:55:54.970636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__module__ == 'ansible.plugins.strategy'
    assert callable(StrategyModule)



# Generated at 2022-06-23 12:56:00.740124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock for class TaskQueueManager
    import mock
    tqm = mock.Mock()
    
    # Create an instance of class StrategyModule
    strategy = StrategyModule(tqm)
    
    # Test if attribute 'debugger_active' is initialized to True
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:56:03.464673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule(None), LinearStrategyModule))
    assert(isinstance(StrategyModule(None), cmd.Cmd))


# Generated at 2022-06-23 12:56:04.491182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# TODO:

# Generated at 2022-06-23 12:56:06.829120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:56:11.568379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        def __init__(self):
            self.hostvars = []
        def __getattr__(self, key):
            return self
        def __call__(self, *args, **kwargs):
            pass

    FakeTQM()
    test_strategy = StrategyModule(FakeTQM)
    assert test_strategy.debugger_active == True



# Generated at 2022-06-23 12:56:13.820247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Hello"
    test_object = StrategyModule(tqm)
    assert test_object.debugger_active == True


# Generated at 2022-06-23 12:56:18.271735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True
    assert sm.display.verbosity == 10
    assert sm.display.banner == "\nDEBUG RUNNING"


# Generated at 2022-06-23 12:56:21.233308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 12:56:22.315176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(some_arg)
    assert True


# Generated at 2022-06-23 12:56:30.953721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        class TestConfig(object):
            class TestRunner(object):
                pass
        class TestStats(object):
            pass
        class TestVarManager(object):
            pass
        class TestPlayContext(object):
            pass

    tqm = TestTqm()
    tqm.config = TestTqm.TestConfig()
    tqm.config.runner = TestTqm.TestConfig.TestRunner()
    tqm.stats = TestTqm.TestStats()
    tqm.var_manager = TestTqm.TestVarManager()
    tqm.play_context = TestTqm.TestPlayContext()
    StrategyModule(tqm)


# Generated at 2022-06-23 12:56:33.387919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type
    assert type(StrategyModule) != StrategyModule
    assert StrategyModule != None


# Generated at 2022-06-23 12:56:35.338050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initialize debugger
    s = StrategyModule(None)
    assert s.debugger_active is True

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 12:56:35.962546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:56:38.122136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-23 12:56:39.173241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 12:56:41.252917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strgmod = StrategyModule()
    assert strgmod.debugger_active == True

# Should return false

# Generated at 2022-06-23 12:56:43.363981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        pass
    except NameError:
        assert False


    if StrategyModule is None:
        assert False



# Generated at 2022-06-23 12:56:47.241908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    # Act
    linear_strategy_module = StrategyModule(tqm = None)
    # Assert
    assert linear_strategy_module.debugger_active == True

# Initializer for class Debugger

# Generated at 2022-06-23 12:56:48.705562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor of class StrategyModule called")
    pass


# Generated at 2022-06-23 12:57:00.093805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    play = Play().load(dict(
        name = "myplay",
        hosts = 'webservers',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=None, loader=None)

    block = Block.load(
        dict(
            tasks = play.tasks,
            rescue = list(),
            always = list()
        ),
        play=play,
    )

    task = Task()
    task.block = block
    task.play = play

# Generated at 2022-06-23 12:57:04.161984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = StrategyModule()
    assert str.name == 'linear'
    assert not str.noop_task_states
    assert str.noop_task_blocks_hosts
    assert not str.run_one_task_at_a_time
    assert not str.always_run_tags
    assert str.keep_remote_files
    assert str.debugger_active


# Generated at 2022-06-23 12:57:10.724370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeRunner:
        def __init__(self, name):
            self.name = name

        def set_stats(self, stats):
            pass

        def run(self, host, task, task_vars=dict(), play_context=dict(), new_stdin=None):
            return dict(ansible_facts=dict(ami_id='i-dummy'))

    class FakeTQM:
        def __init__(self, name):
            self.name = name
            self.hostvars = dict()

        def get_hosts(self, pattern='all'):
            return self.hostvars

        def get_vars(self, host):
            return self.hostvars[host]

        def add_host(self, host):
            self.hostvars[host.name] = host

       

# Generated at 2022-06-23 12:57:12.153120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-23 12:57:14.960917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule(tqm='tqm')
    assert strategy_instance.debugger_active == True


# Generated at 2022-06-23 12:57:16.357779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:57:17.768403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:57:19.925114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active is True

# Assemble class Debugger

# Generated at 2022-06-23 12:57:22.761651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule.__doc__)
    obj = StrategyModule(tqm)


# Generated at 2022-06-23 12:57:24.991443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True




# Generated at 2022-06-23 12:57:27.979864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    session = StrategyModule(tqm)
    print(str(session))
# End of unit test for constructor



# Generated at 2022-06-23 12:57:37.345643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import imp
    from ansible.plugins.strategy.debug import StrategyModule as StrategyModuleCls
    from ansible.executor.task_queue_manager import TaskQueueManager
    from collections import namedtuple

    task_data = namedtuple("TaskData", ["host", "task"])
    task_data.host = "test1.example.com"
    task_data.task = {"host": "test1.example.com", "runner_type": "dummy", "action": "dummy", "args": {}}
    tqm = TaskQueueManager()
    sm = StrategyModuleCls(tqm)
    assert(str(strategy_module) == '<class \'ansible.plugins.strategy.debug.StrategyModule\'>')

    #Exception test
    error_flag = False

# Generated at 2022-06-23 12:57:38.238329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).debugger_active == True


# Generated at 2022-06-23 12:57:41.102188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create stubs
    tqm = 'tqm'
    # create object
    obj = StrategyModule(tqm)

    assert obj is not None
    assert obj.tqm is tqm
    assert obj.stdin is sys.stdin
    assert obj.stdout is sys.stdout
    assert obj.debugger_active



# Generated at 2022-06-23 12:57:42.004820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)


# Generated at 2022-06-23 12:57:44.228551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        def __init__(*args, **kwargs):
            pass
    tqm = FakeTQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
# end of test_StrategyModule



# Generated at 2022-06-23 12:57:45.857067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(0)
    assert strategy.debugger_active


# Generated at 2022-06-23 12:57:49.016501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule should return an object
    assert isinstance(StrategyModule(None), object)
# End of unit test for constructor of class StrategyModule



# Generated at 2022-06-23 12:57:49.955414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    LinearStrategyModule()


# Generated at 2022-06-23 12:57:55.884273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.debugger_active = True
        def __str__(self):
            return "Test"

    _strat_mod = StrategyModule(tqm())
    assert _strat_mod.debugger_active



# Generated at 2022-06-23 12:58:01.476872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    sys.path.insert(0, '../../../lib')
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    class Cmd(cmd.Cmd):
        def do_exit(self, line):
            pass

    class TQM(object):
        def __init__(self):
            self.hostvars = {}
            self._final_q = []


    strategy = LinearStrategyModule(TQM())
    sim = Cmd()
    sim.tqm = TQM()


    assert isinstance(strategy, LinearStrategyModule)



# Generated at 2022-06-23 12:58:04.632204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    #assert StrategyModule.__init__.__doc__ is not None


# Generated at 2022-06-23 12:58:07.448476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True




# Generated at 2022-06-23 12:58:09.397602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Note: Ansible class 'TaskQueueManager' only appeared since Ansible v2.1
    assert StrategyModule('TaskQueueManager Class')



# Generated at 2022-06-23 12:58:11.714555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock_TQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True
    
    

# Generated at 2022-06-23 12:58:12.630903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_instance = StrategyModule()



# Generated at 2022-06-23 12:58:16.573950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructing a StrategyModule")
    task_queue_manager = object()

    strategy_module = StrategyModule(task_queue_manager)

    assert strategy_module.debugger_active



# Generated at 2022-06-23 12:58:22.796509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Case 1 - StrategyModule(tqm)
    tqm = {'tasks_counter': 1}
    strategy = StrategyModule(tqm)
    strategy.debugger_active = True
    assert tqm == {'tasks_counter': 1}
    assert strategy.debugger_active


# Generated at 2022-06-23 12:58:24.540626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an object of StrategyModule
    strategyModule = StrategyModule(None)

    assert strategyModule.debugger_active == True


# Generated at 2022-06-23 12:58:26.514726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)


# Generated at 2022-06-23 12:58:29.145161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_val = "test"
    sm = StrategyModule(test_val)
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:58:33.380500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Basic test.
    """
    test_tqm = type('DummyTestTQM', (object,), {})()
    test_obj = StrategyModule(test_tqm)
    assert test_obj.debugger_active


# Generated at 2022-06-23 12:58:34.867025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = []
    tqm = None
    assert StrategyModule(tqm) is not None


# Generated at 2022-06-23 12:58:35.390747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:35.921563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:45.454631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = variable_manager.loader
    loader.set_basedir('/')
    variable_manager.extra_vars = {"foo": "bar"}

    inventory = loader.load_from_file("/etc/ansible/hosts")
    variable_manager.set_inventory(inventory)

    tqm = TaskQueueManager(inventory = inventory, variable_manager = variable_manager, loader = loader)

    strategy_module = StrategyModule(tqm)
    pprint.pprint(vars(strategy_module))
    assert strategy_module.tqm == tqm
    assert strategy_module.debugger_active == True


# Generated at 2022-06-23 12:58:46.594941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')


# Generated at 2022-06-23 12:58:47.376983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 12:58:48.599344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:58:54.740155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class taskQueueMock():
        hosts = ['localhost']
        extra_vars = {}
        
    sm = StrategyModule(taskQueueMock())
    assert sm.debugger_active == True
    assert sm.noop_task_vars == {}
    assert sm.debugger == None
    assert sm.noop_on_check == True
    assert sm.noop_on_no_hosts == True
    assert sm.noop_on_failed_conditional == True
    assert sm._hosts_cache == ['localhost']
    assert sm._hosts_cache_with_network == ['localhost']

# Generated at 2022-06-23 12:58:56.961184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    assert issubclass(ansible.plugins.strategy.debug.StrategyModule, ansible.plugins.strategy.linear.StrategyModule)


# Generated at 2022-06-23 12:58:58.430272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert(stm.debugger_active == True)


# Generated at 2022-06-23 12:59:00.268461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, LinearStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == __module__



# Generated at 2022-06-23 12:59:01.783730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert_true(strategy_module.debugger_active)



# Generated at 2022-06-23 12:59:03.954926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)
    pass
    

# Generated at 2022-06-23 12:59:11.816649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
#    assert strategy is not None
    assert strategy.model._tqm == 'tqm'
    assert strategy.debugger_active == True
    assert strategy.current_task_name == 'Gathering Facts'
    assert strategy.current_task == None

    assert strategy.host_states == {}
    assert strategy.host_states_cache == {}

    assert strategy.need_to_wait == False

    assert strategy.result_queue.get() == 'STARTED'
    assert strategy.result_queue.get() == 'GATHERING_FACTS'

    assert strategy._play is not None
    assert len(strategy._play.tasks) == 2 # tasks = [setup, gather_facts]

    assert strategy.index == 0
    assert strategy.index_done == 0


# Generated at 2022-06-23 12:59:14.617520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = None
    strategy = StrategyModule(TASK_QUEUE_MANAGER)
    # Verify the result
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:59:16.735217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    executor = {}
    assert StrategyModule(executor)


#
# This class provides a command line interface to the playbook
#

# Generated at 2022-06-23 12:59:19.217015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    #sm = StrategyModule(None)
    #assert (sm.get_tqm() == None and sm.debugger_active == True)



# Generated at 2022-06-23 12:59:21.102777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.tasks == []


# Generated at 2022-06-23 12:59:23.776162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = type('MockTqm', (object,), {'send_callback': None})
    tqm = t()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:59:27.693484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # tqm = None
    # strategy_module = StrategyModule(tqm)
    # assert strategy_module.debugger_active



# Generated at 2022-06-23 12:59:28.313365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:59:32.059051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    strategy_module = StrategyModule(tqm={})
    strategy_module
    sys.stdout = temp_stdout


# Generated at 2022-06-23 12:59:41.570175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import time
    import unittest
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.host as host
    import ansible.playbook.task as task
    import ansible.playbook.task_include as task_include
    import ansible.vars.manager as var_manager
    import ansible.vars.host_variable as host_variable
    import ansible.vars.host_facts as host_facts

    class MockTaskQueueManager:
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.passwords = dict()
            self.stdout_callback = None

    class MockLoader:
        def get_basedir(self, hostname):
            return '.'


# Generated at 2022-06-23 12:59:42.214012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:59:44.068890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == tqm



# Generated at 2022-06-23 12:59:47.050751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager():
        var_manager = None
    task_queue_manager = TestTaskQueueManager()
    strategy_module = StrategyModule(task_queue_manager)

    # Debugger inactive
    assert strategy_module.debugger_active == False

# Unit test 1 for constructor of class Debugger

# Generated at 2022-06-23 12:59:49.391538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert True == strategy_module.debugger_active



# Generated at 2022-06-23 12:59:52.016156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 13:00:00.111483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import merge_hash
    import ansible.callbacks as callbacks
    import ansible.constants as C
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory as inventory
    import ansible.vars as vars
    import ansible.template as template

    class HostManager(object):
        def __init__(self):
            pass

    class Coordinator(object):
        def __init__(self):
            pass

    class TaskQueueManager():
        def __init__(self):
            self.stats = C.AGGREGATE_STATS
            self.datastore = vars.VariableManager()


# Generated at 2022-06-23 13:00:06.635038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('In test_StrategyModule()')
    tqm = ['tqm-test']
    obj_S = StrategyModule(tqm)
    print('obj_S')
    print(obj_S)
    print('obj_S.debugger_active')
    print(obj_S.debugger_active)
    print('obj_S.host_results')
    print(obj_S.host_results)
    print('obj_S.host_work_queue')
    print(obj_S.host_work_queue)



# Generated at 2022-06-23 13:00:07.449634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:00:11.842961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.executor.task_queue_manager import TaskQueueManager
    except Exception:
        pass
    else:
        tqm = TaskQueueManager(
            inventory=None,
            variable_manager=None,
            loader=None,
            options=None,
            passwords=None,
            stdout_callback=None,
        )
        sm = StrategyModule(tqm)
        assert sm.debugger_active


# Generated at 2022-06-23 13:00:15.623185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:00:17.077962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-23 13:00:19.350061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'tqm': None}
    strategyModule = StrategyModule(tqm)
    assert isinstance(strategyModule, StrategyModule) is True
    assert isinstance(strategyModule, LinearStrategyModule) is True
    


# Generated at 2022-06-23 13:00:24.791320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    strategy_module = StrategyModule(tqm)

    assert strategy_module.debugger_active == True
    assert strategy_module.tqm == tqm
    assert strategy_module.play == None
    assert strategy_module.play_context == None



# Generated at 2022-06-23 13:00:25.261129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:00:26.510139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:00:30.099748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        def run(self):
            return
    strategy_module = StrategyModule(TestTQM())
    assert (strategy_module)
    assert (strategy_module.debugger_active)


# Generated at 2022-06-23 13:00:36.000993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an instance of class StrategyModule
    strategy_module = StrategyModule(None)

    # check the value of variable debugger_active
    # TODO: how to test the value of variable debugger_active?
    # assert strategy_module.debugger_active == True

    # check the type of variable debugger_active
    assert type(strategy_module.debugger_active) == bool


# Generated at 2022-06-23 13:00:37.662642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test1 = StrategyModule(None)
    assert test1.debugger_active


# Generated at 2022-06-23 13:00:48.252260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class fake_task_queue_manager:
        def __init__(self):
            class fake_result_callback:
                def __init__(self):
                    self.host_results = {}
                def runner_on_ok(self, host, res):
                    self.host_results[host] = res
                    return self.host_results
                def runner_on_skipped(self, host, res):
                    self.host_results[host] = res
                    return self.host_results
                def runner_on_failed(self, host, res, ignore_errors=False):
                    self.host_results[host] = res
                    return self.host_results
                def runner_on_unreachable(self, host, res):
                    self.host_results[host] = res
                    return self.host_results


# Generated at 2022-06-23 13:00:49.776162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)


# Generated at 2022-06-23 13:00:53.564259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.debug
    obj = ansible.plugins.strategy.debug.StrategyModule(None)
    print(type(obj))
    print(type(obj).__bases__)
    print(dir(obj))


# Generated at 2022-06-23 13:00:55.117983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm = 'tqm')
    assert tqm.debugger_active == True


# Generated at 2022-06-23 13:00:57.431087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    sm = StrategyModule(tqm)
    assert isinstance(sm, StrategyModule)



# Generated at 2022-06-23 13:01:00.183560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    print(strategy.get_name())
    assert strategy.get_name() == 'debug'



# Generated at 2022-06-23 13:01:03.257694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    return strategy_module.tqm == tqm


# Generated at 2022-06-23 13:01:05.133622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 13:01:06.240373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:01:09.496145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        s = StrategyModule(None)
        assert True
    except Exception:
        assert False

#Unit test for method host_result

# Generated at 2022-06-23 13:01:10.394315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return


# Generated at 2022-06-23 13:01:18.671804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create mock task
    # Mock Task is class of TaskManager
    class MockTask:
        def __init__(self, task_id, args, task_vars, set_facts=None):
            self.task_id = task_id
            self.args = args
            self.task_vars = task_vars
            self.set_facts = set_facts
            self.notified_by = set()

        def __repr__(self):
            return "Task: %s" % self.task_id
            # TODO: create Mock_host
    # create mock host
    # Mock host is class of TaskManager
    class MockHost:
        def __init__(self, hostname):
            self.name = hostname
            self.vars = {}
            self.groups = []
            self.register = {}

# Generated at 2022-06-23 13:01:28.826693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            class TestPlay:
                def __init__(self):
                    self.hosts = {}
            class TestOptions:
                def __init__(self):
                    self.strategy = 'linear'
                    self.subset = None
                    self.subset_count = 0
                    self.subset_pattern = None
                    self.subset_file = None
                    self.subset_file_sort_order = None
                    self.subset_file_sort_attribute = None
                    self.subset_file_unique_variable = None
                    self.subset_file_unique_hash_variable = None
                    self.subset_src = None
                    self.subset_src_file = None
                    self.subset_src_group = None
                    self.sub

# Generated at 2022-06-23 13:01:37.889988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class SimpleTQM:
        def __init__(self, inventory):
            self.inventory = inventory
            self.stats = None

    inventory = {"_meta": {"hostvars": {}}}
    tqm = SimpleTQM(inventory)
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.inventory == inventory
    assert sm.host_results == {}
    assert sm.play_context.transport == 'smart'
    assert not sm.play_context.become
    assert sm.use_stepping
    assert not sm.use_task_blocks
    assert not sm.share_vars_on_any_host
    assert not sm.share_vars_on_any_host
    assert sm.debugger_active



# Generated at 2022-06-23 13:01:42.720381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up tqm_instance
    # tqm_instance is of class TaskQueueManager
    tqm_instance = None
    strategy_module_instance = StrategyModule(tqm_instance)
    assert strategy_module_instance.tqm == tqm_instance
    assert strategy_module_instance.debugger_active == True

