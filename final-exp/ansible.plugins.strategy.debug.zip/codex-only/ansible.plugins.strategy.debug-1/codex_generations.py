

# Generated at 2022-06-23 12:51:39.501333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:51:39.990866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:51:41.924008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm.debugger_active


# An implementation of Command Line Debugger for Strategy Plugin

# Generated at 2022-06-23 12:51:52.813354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class MockTaskQueueManager():
        def __init__(self):
            self.stats = {}
            self.fake_tqm = 10

    MockTQM = MockTaskQueueManager()
    strategy_module = StrategyModule(MockTQM)

    print ("test_StrategyModule: " + "StrategyModule.host_list" + ": " + str(strategy_module.host_list))
    print ("test_StrategyModule: " + "StrategyModule.current_host" + ": " + str(strategy_module.current_host))
    print ("test_StrategyModule: " + "StrategyModule.iterator" + ": " + str(strategy_module.iterator))

# Generated at 2022-06-23 12:51:55.257433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TQM'
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-23 12:51:56.677349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: actually test something
    sm = StrategyModule(None)



# Generated at 2022-06-23 12:52:05.505826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a_blob = {
        'name': 'test',
        'delegate_to': '127.0.0.1',
        'run_once': False,
        'hosts': ['127.0.0.1'],
        'tasks': [{
            'action': {
                'module': 'debug',
                'args': {
                    'msg': 'Hello'
                }
            },
            'name': 'Test'
        }]
    }
    tqm = None
    sm = StrategyModule(tqm)
    with pytest.raises(Exception):
        sm.run(play=a_blob)

# Unit test to execute the run method of class StrategyModule

# Generated at 2022-06-23 12:52:10.637570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructor of class StrategyModule
    """
    print("Constructor of class StrategyModule")
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, LinearStrategyModule)

test_StrategyModule()



# Generated at 2022-06-23 12:52:12.406621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.debugger_active is True


# Generated at 2022-06-23 12:52:13.473064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 12:52:18.247850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM():
        def __init__(self):
            self.fake_host_list = []
            self.hostvars = {}

    fake_tqm = FakeTQM()
    strategy = StrategyModule(fake_tqm)
    assert strategy.debugger_active == True
    assert strategy.tqm == fake_tqm


# Generated at 2022-06-23 12:52:19.739925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # How can I test this method?
    return True


# Generated at 2022-06-23 12:52:27.061737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.tasks import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
        run_additional_callbacks=True,
        run_tree=False,
        # TODO
        #all_vars=dict(
        #    environment=environment,
        #    ansible_play_hosts=self._play_hosts
        #),
    )
    strategy = StrategyModule(tqm)

# Generated at 2022-06-23 12:52:28.046161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:52:31.077419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("unit test:", __name__)
    tqm = object()
    strategy = StrategyModule(tqm)
    assert hasattr(strategy, "debugger_active")
    assert strategy.debugger_active


# Generated at 2022-06-23 12:52:33.147879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s
    assert s.debugger_active
    pass


# Generated at 2022-06-23 12:52:36.354092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if sys.version_info.major == 3:
        assert isinstance(type, type)
        assert issubclass(type(StrategyModule), StrategyModule)
    else:
        assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 12:52:38.230839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# For debugging
# import ipdb; ipdb.set_trace()


# reference in lib/ansible/parsing/vault/init.py

# Generated at 2022-06-23 12:52:45.449000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy'
    assert StrategyModule.__doc__ == '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'



# Generated at 2022-06-23 12:52:48.274991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a fake TQM object to pass to the strategy class
    test_tqm = ()
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module.debugger_active == True



# Generated at 2022-06-23 12:52:58.815484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_class:
        pass

    tqm = test_class()
    tqm.shared_loader_obj = test_class()
    tqm.shared_loader_obj._vars_cache = {"a": 1}
    tqm.shared_loader_obj._inventory = test_class()
    tqm.shared_loader_obj._inventory.groups = {"g": test_class()}
    tqm.tasks = [test_class()]
    tqm.tasks[0].action = 'ping'
    tqm.hostvars = {"h": test_class()}
    tqm.hostvars["h"].ansible_host = None

    s = StrategyModule(tqm)
    assert(s.name == 'debug')

# Generated at 2022-06-23 12:53:02.579746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm.strategy == 'debug'
    assert sm.debugger_active



# Generated at 2022-06-23 12:53:09.220516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'test_tqm'
    strategy = StrategyModule(test_tqm)
    assert strategy.tqm == test_tqm
    assert strategy.cur_block == 0
    assert strategy.cur_block_depth == 0
    assert strategy.cur_rescue is None
    assert strategy.cur_always is None
    assert strategy.cur_loop is None
    assert strategy.debugger_active is True


# Generated at 2022-06-23 12:53:13.309264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = FakeTQM()
    strategy_mod = StrategyModule(fake_tqm)
    assert strategy_mod.tqm == fake_tqm
    assert strategy_mod.debugger_active == True

#
# FakeTQM class used for unit test of class StrategyModule
#

# Generated at 2022-06-23 12:53:15.882980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # tqm = Dummy()
    # StrategyModule(tqm)



# Generated at 2022-06-23 12:53:19.796242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    strategy_module_obj = StrategyModule(tqm=None)
    strategy_module_obj.debugger_active = True
    assert(strategy_module_obj)


# Generated at 2022-06-23 12:53:21.676803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 12:53:30.621048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass

    class TestTQM():
        def __init__(self):
            self.stats = dict()
        def get_host_vars(self, host):
            return dict()
        def get_variables(self, play):
            return dict()
        def get_host(self, hostname):
            return dict()
        def get_hosts(self, pattern=None):
            return []

    # Initialize
    test_tqm = TestTQM()
    test_strategy_module = TestStrategyModule(test_tqm)

    # Result
    assert test_strategy_module.tqm == test_tqm
    assert test_strategy_module.queue_name == 'linear'

# Generated at 2022-06-23 12:53:32.931962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s.debugger_active == True


# Generated at 2022-06-23 12:53:34.774223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(task=None)
    assert stm.debugger_active == True


# Generated at 2022-06-23 12:53:36.911256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:53:37.622438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:53:38.997353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 12:53:41.426077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    module = StrategyModule(tqm)
    assert module


# Generated at 2022-06-23 12:53:44.402596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    _StrategyModule = StrategyModule(tqm)
    assert _StrategyModule.tqm == tqm
    assert _StrategyModule.debugger_active == True


# Generated at 2022-06-23 12:53:45.429492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:53:46.222798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#    StrategyModule()



# Generated at 2022-06-23 12:53:50.963973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize a StrategyModule instance
    test_StrategyModule = StrategyModule(tqm = [])
    # Make sure there are no tasks
    assert test_StrategyModule.tasks == []
    # Make sure that debugger is active
    assert test_StrategyModule.debugger_active


# Generated at 2022-06-23 12:53:55.849758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Debug interactive strategy'
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.debug'
    assert StrategyModule.__init__.__name__ == 'StrategyModule'
    assert StrategyModule.__init__.__doc__ == None


# Generated at 2022-06-23 12:53:59.946614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # create tqm
        tqm = object()

        # create instance of StrategyModule
        # check the constructor is called
        assert StrategyModule(tqm)
    except:
        # error in constructor
        assert False


# Generated at 2022-06-23 12:54:02.644020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock

    # Call the constructor of class StrategyModule
    StrategyModule(mock.Mock())

# TODO: make this more like the real debugger?

# Generated at 2022-06-23 12:54:04.510326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)

# Generated at 2022-06-23 12:54:05.504780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:54:08.022116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  obj=StrategyModule('test')
  assert obj.debugger_active == True

# Test for __init__ method of class StrategyModule

# Generated at 2022-06-23 12:54:09.663952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def tqm_mock():
        pass
    StrategyModule(tqm_mock)


# Generated at 2022-06-23 12:54:10.326256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:54:12.891052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm)
    assert a.debugger_active == True


# Generated at 2022-06-23 12:54:16.940252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    result = hasattr(strategy, 'debugger_active')
    assert result


# Generated at 2022-06-23 12:54:24.807685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule(tqm)
    assert c.debugger_active == True
    assert isinstance(c, StrategyModule)


    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Debug Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='hello world')))
             ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # Actually run it
    tqm = None

# Generated at 2022-06-23 12:54:26.009114
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:54:27.707592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm


# Generated at 2022-06-23 12:54:31.439554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, LinearStrategyModule)
    assert isinstance(strategy, object)



# Generated at 2022-06-23 12:54:33.578971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm.tqm == 'test'
    assert sm.debugger_active == True


# Generated at 2022-06-23 12:54:34.186308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:54:41.290692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for constructor of class StrategyModule
    sys.modules['ansible.modules.system.ping'] = sys.modules['__fake__.ansible.modules.system.ping']
    sys.modules['ansible.plugins.connection.local'] = sys.modules['__fake__.ansible.plugins.connection.local']
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.debugger_active == True


# Generated at 2022-06-23 12:54:42.556379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is not None

# unit test for self.debugger_active

# Generated at 2022-06-23 12:54:45.465003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule', 'Class StrategyModule is bad named'



# Generated at 2022-06-23 12:54:47.336885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO(kishin): Test this
    pass



# Generated at 2022-06-23 12:54:56.336458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), "../../test/test_utils"))
    from debug_print import debug_print
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import Facts
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    from ansible.plugins.strategy.debug import StrategyModule as DebugStrategyModule



# Generated at 2022-06-23 12:54:59.905971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    try:
        s = StrategyModule(test_tqm)
    except:
        print("Error occured in unit test for StrategyModule")



# Generated at 2022-06-23 12:55:01.766073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')



# Generated at 2022-06-23 12:55:02.423065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass


# Generated at 2022-06-23 12:55:04.987600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    # Test that 'super' is executed
    strategy_module = StrategyModule(tqm)
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:55:17.146372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.cleandir = False
            self.diff = False
            self.inventory = None
            self.basedir = '.'
            self.vars = {}
            self.verbosity = 1
            self.extra_vars = {}
            self.extra_vars_files = None
            self.playbook_path = None
            self.replay = False
            self.recursive = False
            self.loader = None
            self.ssh_common_args = None
            self.connect_timeout = 10
            self.timeout = 10
            self.module_path = None
            self.forks = 5
            self.remote_user = 'root'
            self.remote_pass = None
            self.private_key_file = None
            self.bec

# Generated at 2022-06-23 12:55:20.837190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # unit test for default init value of
    # class StrategyModule
    P = StrategyModule(None)
    assert P.debugger_active == True
    assert P.tqm == None


# Generated at 2022-06-23 12:55:22.690119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (LinearStrategyModule,)


# Generated at 2022-06-23 12:55:24.065715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

    return "OK"


# Generated at 2022-06-23 12:55:25.544608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-23 12:55:27.840682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = object
    sm = StrategyModule(task_queue_manager)
    assert sm.debugger_active == True



# Generated at 2022-06-23 12:55:29.991883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    strategy = StrategyModule(task_queue_manager)


# Generated at 2022-06-23 12:55:30.938983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #
    pass



# Generated at 2022-06-23 12:55:32.206650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')


# Generated at 2022-06-23 12:55:38.200729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule.TaskQueueManager()
    #assert(isinstance(StrategyModule(tqm), object))
    #assert(isinstance(StrategyModule(tqm), object))
    assert(isinstance(StrategyModule(tqm).debugger_active, bool))
# end of test_StrategyModule


# Generated at 2022-06-23 12:55:40.484949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    # tqm = _ansiballz.get_tqm()
    # StrategyModule(tqm)



# Generated at 2022-06-23 12:55:46.026327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('==== StrategyModule.__init__() ====')

# Generated at 2022-06-23 12:55:54.741575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module.debugger_active is True)

    assert(strategy_module.name == "linear")
    assert(strategy_module.tqm is None)
    assert(strategy_module.stopping is False)
    assert(strategy_module.results_counter["skipped"] == 0)
    assert(strategy_module.results_counter["failures"] == 0)
    assert(strategy_module.results_counter["ok"] == 0)
    assert(strategy_module.results_counter["dark"] == 0)
    assert(strategy_module.results_counter["processed"] == 0)
    assert(strategy_module.task_number == 0)

# Generated at 2022-06-23 12:55:56.092695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:56:05.429337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sys.argv = [sys.argv[0], 'ad-hoc', '-i', 'localhost,', '-m', 'ping']
    from ansible.cli.adhoc import AdHocCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    test_AdHocCLI = AdHocCLI(sys.argv)
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = test_AdHocCLI.args

    tqm = TaskQueueManager(
        inventory=test_AdHocCLI.inventory,
        variable_manager=variable_manager,
        loader=loader,
    )
   

# Generated at 2022-06-23 12:56:09.643662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = {'test':'test'}
        StrategyModule(tqm)
    except:
        print("Failed: In StrategyModule")
        assert False


# Generated at 2022-06-23 12:56:12.015307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check if the constructor of class StrategyModule can be called
    # If a NameError exception is thrown, it means that the constructor does not exist
    try:
        debugger = StrategyModule()
    # Any exception other than NameError is considered a success
    except NameError:
        return False



# Generated at 2022-06-23 12:56:15.770013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = []
    test_strategy = StrategyModule(test_tqm)
    assert test_strategy.playbook.play_basedirs == [], "StrategyModule() Fail"


# Generated at 2022-06-23 12:56:18.453507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   sys.stdout = open('/tmp/test_StrategyModule', 'w')
   print('In test_StrategyModule')
   sm = StrategyModule(tqm)
   print('sm =', sm)
   sys.stdout.close()



# Generated at 2022-06-23 12:56:20.766462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    assert StrategyModule



# Generated at 2022-06-23 12:56:29.228373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader


# Generated at 2022-06-23 12:56:33.089069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.hostvars = {'localhost': {}}
    debug = StrategyModule(TestTqm())
    assert debug.debugger_active is True


# Generated at 2022-06-23 12:56:37.318821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.linear import StrategyModuleTest
        strategy = StrategyModuleTest()
    except ImportError:
        import unittest

        class StrategyModuleTest:
            pass

        strategy = StrategyModuleTest()
    strategy.__class__ = StrategyModule
    return strategy


# Generated at 2022-06-23 12:56:40.853063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Ansible.Test.test_lib.test_tqm.TQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm


# Generated at 2022-06-23 12:56:45.688301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook

    config = {}
    tqm = Playbook(config, [])

    strategyModule = StrategyModule(tqm)

    assert strategyModule.debugger_active == True

if __name__ == '__main__':
    # Unit test for module StrategyModule
    #test_StrategyModule()
    pass

# Generated at 2022-06-23 12:56:48.167159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    # FIXME
    # sm = StrategyModule()
    # assert sm.debugger_active == True
    # assert sm.__class__.__base__ == LinearStrategyModule


# Generated at 2022-06-23 12:56:49.424055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TODO:
    pass



# Generated at 2022-06-23 12:57:00.449320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test for constructor of class StrategyModule
    '''
    q = test_class.get_queue_manager()
    s = StrategyModule(q)

    # assert: self.host = None
    assert s.host is None

    # assert: self.host_state = None
    assert s.host_state is None

    # assert: self.job = None
    assert s.job is None

    # assert: self.result = None
    assert s.result is None

    # assert: self.task = None
    assert s.task is None

    # assert: self.task_queue_manager = tqm
    assert s.task_queue_manager is q

    # assert: self.tmp = None
    assert s.tmp is None

    # assert: self.tqm = tqm
    assert s.t

# Generated at 2022-06-23 12:57:01.182615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:57:04.088168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_mgr = 1
    strategy_module = StrategyModule(task_queue_mgr)
    assert(strategy_module.debugger_active == True)


# Generated at 2022-06-23 12:57:12.490796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    print("Testing constructor with ansible.executor.task_queue_manager.TaskQueueManager")
    # Initialize TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
    )
    print(tqm)

    # Constructor of class StrategyModule
    debug_strategy = StrategyModule(tqm)
    print("debug_strategy.debugger_active:", debug_strategy.debugger_active)
    assert debug_strategy.debugger_active

# Generated at 2022-06-23 12:57:15.293402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm).debugger_active == True

#
# Override method run() to add debugger
#

# Generated at 2022-06-23 12:57:23.320607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        def __init__(self):
            self.host_failed_tasks = set()
            self.host_unreachable_tasks = set()
            self.host_skipped_tasks = set()

    class TestRunner():
        def __init__(self):
            self.tqm = TestTQM()
            self.task_vars = dict()
        def get_host_vars(self):
            return dict()
        def get_inventory(self):
            return []

    class TestPlaybook():
        def __init__(self):
            self.task_vars = dict()

    class TestPlay():
        def __init__(self):
            self.playbook = TestPlaybook()
            self.tasks = []


# Generated at 2022-06-23 12:57:24.359768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 12:57:34.469115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock class for TaskQueueManager, make sure tqm is not None
    class MockTaskQueueManager(object):
        def __init__(self):
            pass

    class MockRunner(object):
        def __init__(self, hosts, pattern, module_name, module_args, become, become_method, become_user, check, diff, *args, **kwargs):
            pass

    # Create a TaskQueueManager object
    tqm = MockTaskQueueManager()
    # Initilize debugger by creating a StrategyModule object
    debugger = StrategyModule(tqm)
    # Make sure debugger_active is True
    assert (debugger.debugger_active) == True


# Generated at 2022-06-23 12:57:40.997389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class Test(unittest.TestCase):
        def test_StrategyModule(self):
            class TaskQueueManager:
                pass
            a = TaskQueueManager()
            b = StrategyModule(a)
            self.assertIsInstance(b, LinearStrategyModule)

    unittest.main(argv=[''], exit=False)


# Generated at 2022-06-23 12:57:41.659874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:57:42.364639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:57:53.255362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self, hosts, inventory, variable_manager, loader, options, stdout_callback, run_additional_callbacks, run_tree):
            self.hosts = hosts
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.stdout_callback = stdout_callback
            self.run_additional_callbacks = run_additional_callbacks
            self.run_tree = run_tree
    class hosts:
        def __init__(self, list):
            self.list = list
    class inventory:
        def __init__(self):
            self.hosts = hosts('/test/test')
    class variable_manager:
        def __init__(self):
            self.br

# Generated at 2022-06-23 12:58:02.198605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm_instance = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None
    )
    strategy_module = StrategyModule(tqm=tqm_instance)
    assert strategy_module.debugger_active is True


# Interpreter to receive and execute commands dynamically.
# This class is referred to cmd.Cmd by C(python_interpreter.py)
#
# Links:
#   - https://docs.python.org/2/library/cmd.html

# Generated at 2022-06-23 12:58:13.080069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host_1 = Host(name='localhost')
    host_2 = Host(name='localhost')
    host_3 = Host(name='localhost')

    vm = VariableManager()
    vm.set_host_variable(host_1, 'hostvar', 3)
    vm.set_host_variable(host_2, 'hostvar', 5)
    vm.set_host_variable(host_3, 'hostvar', 7)

    # create play context
    play_context = PlayContext()

# Generated at 2022-06-23 12:58:16.117833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 12:58:19.285932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm():
        pass
    tqm = Tqm()
    x = StrategyModule(tqm)


# Generated at 2022-06-23 12:58:22.578764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active == True

# executable commands in interactive mode.

# Generated at 2022-06-23 12:58:23.547897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:58:25.680090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = __import__('unit_test_framework').Mock()
    tqm.tqm_debugger_timeout = 180
    StrategyModule(tqm)


# Generated at 2022-06-23 12:58:26.686159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
      StrategyModule(tqm)

# Generated at 2022-06-23 12:58:28.345562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert True


# Generated at 2022-06-23 12:58:30.582127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_var = StrategyModule(tqm = None)
    assert test_var.debugger_active


# Generated at 2022-06-23 12:58:32.466221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_StrategyModule = StrategyModule()
  assert test_StrategyModule.debugger_active == True



# Generated at 2022-06-23 12:58:33.338100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")



# Generated at 2022-06-23 12:58:35.834640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Cmd()
    strategy_module = StrategyModule(tqm)
    assert tqm == strategy_module.tqm
    assert strategy_module.debugger_active


# Generated at 2022-06-23 12:58:38.559050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        def __init__(self):
            self.name = name
    tqm = Tqm()
    str = StrategyModule(tqm)
    assert(str.debugger_active == True)



# Generated at 2022-06-23 12:58:46.348193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    dummy_variable_manager = {}
    dummy_loader = {}

    context.CLIARGS = {}
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=dummy_variable_manager,
        loader=dummy_loader,
        passwords=None,
        stdout_callback=display,
    )
    sm = StrategyModule(tqm)
    assert sm.debugger_active is True


# Generated at 2022-06-23 12:58:46.953266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:58:54.568833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import imp
    import sys
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def test_constructor(self):
            sys.path.insert(0, os.path.join(sys.path[0], '..', '..', '..', 'callback'))
            debugger_module = imp.load_source('debugger_module', '../../callback/debugger.py')
            sys.path.pop(0)

# Generated at 2022-06-23 12:58:55.063159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:58:57.636776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Execution
    class Test:
        def __init__(self):
            pass

    tqm = Test()
    strategy = StrategyModule(tqm)

    # Testing
    assert strategy.debugger_active == True



# Generated at 2022-06-23 12:59:04.182827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Unit test
  pp = pprint.PrettyPrinter(indent=2)

  print('\n' + '='*40)
  print('TEST: StrategyModule()')
  print('='*40)
  test = StrategyModule(ans_tqm)
  print(test)
  print(test.get_host_list('all'))
  print(test.get_host_list('all')[1])
  print(test.get_host_list('all')[2])
  # print(test.get_host_variables(vars(), test.get_host_list('all')[2]))

  # print(test.get_variable_manager().get_vars())
  # print(test.get_variable_manager().get_vars().get_vars_for_host(ans_host

# Generated at 2022-06-23 12:59:07.447111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # If constructor of class StrategyModule works correctly, class StrategyModule is created
    # and is an instance of cmd.Cmd.
    assert StrategyModule(None)
    assert isinstance(StrategyModule(None), cmd.Cmd)


# Generated at 2022-06-23 12:59:09.205736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)



# Generated at 2022-06-23 12:59:10.302528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#     assert 1 == 1


# Generated at 2022-06-23 12:59:14.045054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    strategy = StrategyModule(tqm)
    assert type(strategy) is StrategyModule



# Generated at 2022-06-23 12:59:22.870619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play
    from ansible.template import Templar

    tqm = strategy_loader.get('debug').get('strategy_instance')
    templar = Templar(tqm._loader, variables={})
    play_context = Play().set_loader(tqm._loader)
    task = TaskInclude(strategy='debug')
    task._role = {'path': 'test_path'}
    task._role_context = {}
    task._role_context['role_path'] = 'test_role_path'
    tqm.add_task(play_context, task, templar)



# Generated at 2022-06-23 12:59:33.761415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTaskQueue(object):
        def __init__(self):
            self.stats = {}

        def get_stats(self):
            return self.stats

    class MockTask(object):
        def __init__(self, name='taskname'):
            self.action = 'action'
            self.name = name
            self.args = []
            self.async_val = None
            self.notify = []
            self.changed_when = []
            self.always_run = []
            self.when = []
            self.register = None
            self.failed_when = []

    mock_tqm = MockTaskQueue()

    strategy_module = StrategyModule(mock_tqm)
    # Check that the debugger is active
    assert strategy_module.debugger_active

    mock_tqm

# Generated at 2022-06-23 12:59:35.451743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_StrategyModule"
    StrategyModule(tqm)


# Generated at 2022-06-23 12:59:37.813868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule.debugger_active is True, 'debugger_active must be True'


# Generated at 2022-06-23 12:59:38.457932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 12:59:39.116439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 12:59:42.409876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == 'StrategyModule')
    assert(StrategyModule.__doc__ == __doc__)
    assert(StrategyModule.__module__ == 'ansible.plugins.strategy')


# Generated at 2022-06-23 12:59:44.653799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)
    assert strategymodule.debugger_active == True


# Generated at 2022-06-23 12:59:47.232191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except:
        print(sys.exc_info())
        assert False
    else:
        assert True


# Generated at 2022-06-23 12:59:50.967149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = object()
    test_strategy = StrategyModule(test_tqm)
    assert test_strategy is not None


# Generated at 2022-06-23 12:59:58.362383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # method: __init__(self, tqm)
  #
  # This file is unit test for constructor of class StrategyModule
  #
  # definition of function:
  # def __init__(self, tqm):
  #     super(StrategyModule, self).__init__(tqm)
  #     self.debugger_active = True

  # prepare parameters
  tqm = 'tqm' 
  # run test
  strategyModule = StrategyModule(tqm)

  # print/run result
  # print(strategyModule)
  print(str(strategyModule))



# Generated at 2022-06-23 13:00:00.809564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:00:02.165066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:00:03.410580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object) == None


# Generated at 2022-06-23 13:00:03.968106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:00:08.536444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_result = StrategyModule()
  print("Testing Strategy module constructor:")
  if (isinstance(test_result, StrategyModule)):
    print("Passed")
  else:
    print("Failed")

test_StrategyModule()



# Generated at 2022-06-23 13:00:09.859562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # No test for now.
    assert True


# Generated at 2022-06-23 13:00:11.351757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    abc = StrategyModule(0)
    assert abc.debugger_active == True
    assert isinstance(abc, LinearStrategyModule)



# Generated at 2022-06-23 13:00:15.544903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == isinstance(StrategyModule({}), LinearStrategyModule)
    assert True == isinstance(StrategyModule({}), StrategyModule)
    assert True == StrategyModule({}).debugger_active


# Generated at 2022-06-23 13:00:19.631139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return '''
host_list = [dest]
task_list = [dict(action=dict(module='debug', args=dict(msg='Hello World')))]
'''


# Generated at 2022-06-23 13:00:27.274014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import defaultdict
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name="localhost")
    group = Group(name="group1")
    group.add_host(host)
    group.set_variable('ansible_ssh_host', 'host_hostname_or_ip')
    group.set_variable

# Generated at 2022-06-23 13:00:29.565830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)
    assert issubclass(StrategyModule, LinearStrategyModule)


# Generated at 2022-06-23 13:00:33.411272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTQM():
        pass
    tqm = DummyTQM()
    sm = StrategyModule(tqm)
    assert sm.debugger_active == True


# Generated at 2022-06-23 13:00:36.185559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__'), "Class 'StrategyModule' has no __init__ method"
    assert callable(StrategyModule.__init__), "__init__ is not callable"



# Generated at 2022-06-23 13:00:36.870043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:00:37.573401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True


# Generated at 2022-06-23 13:00:38.753706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != ''


# Generated at 2022-06-23 13:00:42.072654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = 'testhost'
    tqm = 'testtqm'
    sModule = StrategyModule(tqm)

    assert sModule.debugger_active == True


# Generated at 2022-06-23 13:00:47.523076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.constants import DEFAULT_DEBUG
        from ansible.plugins.strategy.debug import StrategyModule

    except ImportError:
        return False

    strategy_module = StrategyModule()
    assert strategy_module.debugger_active == DEFAULT_DEBUG

'''
    def run(self, iterator, play_context):
        super(StrategyModule, self).run(iterator, play_context)
        self.debugger_active = True
        while self.debugger_active:
            self.do('next').debugger()

'''


# Generated at 2022-06-23 13:00:49.220681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import tempfile
    tqm = tempfile.TemporaryFile()
    strategymodule = StrategyModule(tqm)


# Generated at 2022-06-23 13:00:51.026979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

    #tqm = AnsibleTaskQueueManager()
    #assert isinstance(StrategyModule(tqm), StrategyModule)



# Generated at 2022-06-23 13:00:52.534789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:00:53.644259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule(None)) == StrategyModule


# Generated at 2022-06-23 13:00:54.905409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert "__init__" in dir(StrategyModule)


# Generated at 2022-06-23 13:00:57.459361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #tqm = TaskQueueManager()
    #sm = StrategyModule(tqm)
    #print(sm)
    pass

# Returns an instance of a subclass of Cmd

# Generated at 2022-06-23 13:00:58.520982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True


# Generated at 2022-06-23 13:00:59.372788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return


# Generated at 2022-06-23 13:01:00.364441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:01:01.110840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:01:03.201704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.debugger_active is True


# Generated at 2022-06-23 13:01:06.822151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    linear_strategy_module = StrategyModule(None)
    if linear_strategy_module.debugger_active != True:
        raise AssertionError('StrategyModule constructor failed')


# Generated at 2022-06-23 13:01:17.004837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('--> test_strategy_debug_module')
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.template import Templar

    inventory = InventoryManager(loader=C.DEFAULT_LOADERS, sources=C.DEFAULT_HOST_LIST)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='setup', args=''))]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)
    tqm = None
    templar = Templar(loader=None, variables={})
    loader = module_loader

# Generated at 2022-06-23 13:01:25.769465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # copied from __main__ of strategy/debug.py
    from ansible.utils.color import colorize
    from ansible.utils import display
    from ansible import constants as C

    from ansible.color import ANSIBLE_COLOR, stringc
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    display.verbosity = 3
    display.deprecated_warning = False

    # inject my "debugger" callback
    C.DEFAULT_CALLBACK_WHITELIST = ['debugger']
    (options, args) = display.parse_cli([])

# Generated at 2022-06-23 13:01:27.396658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.debugger_active == True


# Generated at 2022-06-23 13:01:29.699683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    t = StrategyModule(tqm)
    assert t.debugger_active == True


# Generated at 2022-06-23 13:01:32.013555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp_class = StrategyModule(None)
    assert tmp_class.debugger_active == True
# End of unit test



# Generated at 2022-06-23 13:01:34.046420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm.debugger_active

sm = StrategyModule(None)


# Generated at 2022-06-23 13:01:35.177233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy = StrategyModule()
    assert isinstance(strategy, StrategyModule)


# Generated at 2022-06-23 13:01:41.255096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass():
        def __init__(self):
            self.host_key_checking = False
            self.result_q = []
            self.tqm_result_q = []
            self.background = 0

    tqm = TestClass()
    res = StrategyModule(tqm)
    assert res.debugger_active == True

