

# Generated at 2022-06-17 20:25:04.182211
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    r = requests.get('https://www.google.com')
    req = HTTPRequest(r.request)
    body = req.body

# Generated at 2022-06-17 20:25:13.070130
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from requests.utils import to_key_val_list
    from requests.compat import urlparse, OrderedDict
    from requests.cookies import RequestsCookieJar
    from requests.hooks import default_hooks
    from requests.structures import LookupDict
    from requests.packages.urllib3.fields import RequestField
    from requests.packages.urllib3.filepost import encode_multipart_formdata
    from requests.packages.urllib3.util import parse_url
    from requests.packages.urllib3.util import is_fp_closed
    from requests.packages.urllib3.exceptions import DecodeError
    from requests.packages.urllib3.exceptions import Read

# Generated at 2022-06-17 20:25:18.899050
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = 'http://httpbin.org/post'
    data = {'key1': 'value1', 'key2': 'value2'}
    r = requests.post(url, data=data)
    req = HTTPRequest(r.request)
    assert req.iter_body(1) == [b'key1=value1&key2=value2']


# Generated at 2022-06-17 20:25:25.014821
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    import io
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest

    class TestHTTPRequest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.server_port = 8888
            self.server_url = 'http://localhost:{}'.format(self.server_port)
            self.server_path = os.path.join(self.tempdir, 'server.py')

# Generated at 2022-06-17 20:25:30.713015
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    r = requests.get('https://httpbin.org/get')
    response = HTTPResponse(r)
    lines = list(response.iter_lines(chunk_size=1))
    assert len(lines) == 1
    assert lines[0][1] == b'\n'


# Generated at 2022-06-17 20:25:42.369178
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    import json
    import re
    import sys
    import os
    import time
    import datetime
    import logging
    import logging.handlers
    import argparse
    import socket
    import ssl
    import threading
    import queue
    import subprocess
    import signal
    import traceback
    import http.client
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urll

# Generated at 2022-06-17 20:25:44.091378
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for chunk in req.iter_body(chunk_size=1):
        print(chunk)


# Generated at 2022-06-17 20:25:48.854488
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests import Request
    req = Request('GET', 'http://www.example.com')
    req.body = b'Hello, world!'
    req = HTTPRequest(req)
    assert b''.join(req.iter_body(chunk_size=1)) == b'Hello, world!'


# Generated at 2022-06-17 20:25:52.346317
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    assert req.iter_body(1) == [b'']


# Generated at 2022-06-17 20:25:56.699591
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = 'http://httpbin.org/post'
    data = {'key1': 'value1', 'key2': 'value2'}
    r = requests.post(url, data=data)
    req = HTTPRequest(r.request)
    assert req.iter_body(1) == [b'key1=value1&key2=value2']


# Generated at 2022-06-17 20:26:13.453440
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from urllib.parse import urlparse
    from io import StringIO
    from unittest.mock import patch

    # Create a mock request object
    url = 'http://example.com/'
    method = 'GET'
    headers = CaseInsensitiveDict({'Content-Type': 'text/plain'})
    body = 'Hello World!'
    request = Request(method, url, headers=headers, data=body)

    # Create a mock response object
    response = StringIO()
    response.write('HTTP/1.1 200 OK\r\n')
    response.write('Content-Type: text/plain\r\n')
    response.write('\r\n')
    response.write(body)

# Generated at 2022-06-17 20:26:21.033336
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO
    req = Request('GET', 'http://example.com/')
    req.body = BytesIO(b'line1\nline2\nline3')
    req.headers['Content-Type'] = 'text/plain'
    req.headers['Content-Length'] = '15'
    req_msg = HTTPRequest(req)
    lines = [line for line, _ in req_msg.iter_lines(chunk_size=1)]
    assert lines == [b'line1', b'line2', b'line3']

# Generated at 2022-06-17 20:26:27.547924
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    req = Request('GET', 'http://example.com/')
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'', b'')]
    req = Request('GET', 'http://example.com/', data=b'foo')
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'foo', b'')]
    req = Request('GET', 'http://example.com/', data=b'foo\nbar')
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'foo', b'\n'), (b'bar', b'')]
    req = Request('GET', 'http://example.com/', data=b'foo\nbar\nbaz')


# Generated at 2022-06-17 20:26:31.330647
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests import Request
    req = Request(method='GET', url='http://www.google.com')
    req = HTTPRequest(req)
    assert next(req.iter_body(chunk_size=1)) == b''


# Generated at 2022-06-17 20:26:41.806873
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO
    from urllib.parse import urlparse
    from urllib.parse import parse_qs

    url = 'http://www.example.com/'
    method = 'GET'
    headers = {'Content-Type': 'application/json'}
    body = b'{"key": "value"}'

    req = Request(method, url, headers=headers, data=body)
    prepped = req.prepare()
    req = HTTPRequest(prepped)

    # Test iter_lines
    for line, line_feed in req.iter_lines(chunk_size=1):
        assert line == body
        assert line_feed == b''

    # Test iter_lines with chunk_size > len(body)

# Generated at 2022-06-17 20:26:45.585144
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('http://www.google.com')
    for line, line_feed in response.iter_lines():
        print(line)
        print(line_feed)


# Generated at 2022-06-17 20:26:49.773013
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://httpbin.org/get')
    prepared = req.prepare()
    req = HTTPRequest(prepared)
    for line, line_feed in req.iter_lines(chunk_size=1):
        print(line, line_feed)


# Generated at 2022-06-17 20:27:01.993611
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO
    from urllib.parse import urlparse

    url = 'https://www.google.com/'
    method = 'GET'
    headers = {'User-Agent': 'Mozilla/5.0'}
    data = b'{"key": "value"}'
    req = Request(method, url, headers=headers, data=data)
    preq = HTTPRequest(req)
    assert preq.body == data
    assert preq.headers == 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0\r\nHost: www.google.com'
    assert preq.encoding == 'utf8'
    assert preq.content_type == ''
    assert preq.iter_body(1) == [data]

# Generated at 2022-06-17 20:27:05.738737
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    r = requests.Request('GET', 'http://www.google.com')
    r = r.prepare()
    req = HTTPRequest(r)
    lines = [line for line, line_feed in req.iter_lines(chunk_size=1)]
    assert lines == [b'']

# Generated at 2022-06-17 20:27:13.743403
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for line, line_feed in req.iter_lines(chunk_size=1):
        print(line, line_feed)

if __name__ == '__main__':
    test_HTTPRequest_iter_lines()

# Generated at 2022-06-17 20:27:38.308405
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from requests import Response
    from io import BytesIO
    response = Response()
    response.raw = BytesIO(b'line1\nline2\nline3')
    response.raw.readline = response.raw.readline
    response.raw.read = response.raw.read
    response.raw.read1 = response.raw.read1
    response.raw.readinto = response.raw.readinto
    response.raw.readinto1 = response.raw.readinto1
    response.raw.readlines = response.raw.readlines
    response.raw.readall = response.raw.readall
    response.raw.tell = response.raw.tell
    response.raw.seek = response.raw.seek
    response.raw.seekable = response.raw.seekable
    response.raw.readable = response.raw

# Generated at 2022-06-17 20:27:49.350781
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    import sys
    import os
    import io
    import tempfile
    import unittest
    import unittest.mock

    class TestHTTPRequest(unittest.TestCase):

        def setUp(self):
            self.url = 'http://httpbin.org/post'
            self.data = {'key1': 'value1', 'key2': 'value2'}
            self.headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
            self.request = requests.Request('POST', self.url, data=self.data, headers=self.headers)
            self.prepared_request = self.request.prepare()
            self.http_request = HTTPRequest(self.prepared_request)


# Generated at 2022-06-17 20:27:55.353216
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for chunk in req.iter_body(1024):
        print(chunk)


# Generated at 2022-06-17 20:28:04.270759
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    import io
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import urllib.parse
    import http.server
    import socketserver
    import threading
    import random
    import string
    import unittest

    class TestHTTPRequest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempdir_path = os.path.join(self.tempdir, 'test.txt')
            self.tempdir_url = urllib.parse.urljoin('http://localhost:8000/', 'test.txt')
            self.tempdir_file = open(self.tempdir_path, 'w')

# Generated at 2022-06-17 20:28:10.364763
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for chunk in req.iter_body(1):
        print(chunk)


# Generated at 2022-06-17 20:28:14.839798
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('https://www.google.com')
    for line, line_feed in response.iter_lines(chunk_size=1):
        print(line, line_feed)

# Generated at 2022-06-17 20:28:23.366716
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('https://httpbin.org/get')
    assert isinstance(response, requests.models.Response)
    http_response = HTTPResponse(response)
    assert isinstance(http_response, HTTPResponse)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
    assert isinstance(http_response.iter_lines(1), Iterable)
   

# Generated at 2022-06-17 20:28:27.862404
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    r = requests.get('http://httpbin.org/get')
    response = HTTPResponse(r)
    lines = list(response.iter_lines(1))
    assert len(lines) == 1
    assert lines[0][0].startswith(b'{')
    assert lines[0][1] == b'\n'


# Generated at 2022-06-17 20:28:33.311264
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    request = Request(method='GET', url='http://example.com/')
    request.body = b'hello\nworld'
    http_request = HTTPRequest(request)
    assert list(http_request.iter_lines(chunk_size=1)) == [(b'hello\nworld', b'')]


# Generated at 2022-06-17 20:28:40.498151
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    url = 'http://httpbin.org/post'
    data = {'key': 'value'}
    r = requests.post(url, data=json.dumps(data))
    req = HTTPRequest(r.request)
    print(req.headers)
    print(req.body)
    print(req.encoding)
    for line, line_feed in req.iter_lines(chunk_size=1):
        print(line, line_feed)


# Generated at 2022-06-17 20:29:24.043471
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    import io
    import sys
    import os
    import time
    import subprocess
    import threading

    # Create a server
    server = subprocess.Popen(
        [sys.executable, '-m', 'http.server', '8080'],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=os.getcwd()
    )
    time.sleep(0.5)

    # Create a request

# Generated at 2022-06-17 20:29:35.089437
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    import time
    import random
    import string
    import hashlib
    import os
    import sys
    import datetime
    import time
    import logging
    import logging.handlers
    import threading
    import queue
    import traceback
    import re
    import socket
    import ssl
    import urllib3
    import urllib3.exceptions
    import urllib3.util
    import urllib3.util.connection
    import urllib3.util.retry
    import urllib3.util.timeout
    import urllib3.util.url
    import urllib3.util.request
    import urllib3.util.response
    import urllib3.util.ssl_
    import urllib3.util.connection
    import ur

# Generated at 2022-06-17 20:29:39.875983
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('http://www.google.com')
    lines = list(response.iter_lines())
    assert len(lines) > 0
    assert lines[0].startswith(b'<!doctype html>')
    assert lines[-1].startswith(b'</html>')


# Generated at 2022-06-17 20:29:51.657184
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from io import BytesIO
    from urllib.parse import urlparse

    url = 'http://example.com/'
    headers = CaseInsensitiveDict({'Content-Type': 'text/plain'})
    body = BytesIO(b'Hello\nWorld!\n')
    req = Request(method='POST', url=url, headers=headers, data=body)
    req = HTTPRequest(req)

    lines = list(req.iter_lines(chunk_size=1))
    assert lines == [(b'Hello\n', b'\n'), (b'World!\n', b'\n')]

    lines = list(req.iter_lines(chunk_size=2))

# Generated at 2022-06-17 20:29:53.750263
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('https://www.google.com')
    for line, line_feed in response.iter_lines():
        print(line)


# Generated at 2022-06-17 20:30:02.264360
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from io import BytesIO
    from urllib.parse import urlsplit
    from requests.structures import CaseInsensitiveDict
    request = Request(
        method='GET',
        url='http://www.example.com',
        headers=CaseInsensitiveDict({'Host': 'www.example.com'}),
        files={},
        data=b'',
        json=None,
        params={},
        auth=None,
        cookies={},
        hooks={},
        stream=False,
        verify=True,
        cert=None,
        json=None
    )
    request.body = BytesIO(b'Hello World!')
    request.prepare()
    http_request = HTTPRequest(request)

# Generated at 2022-06-17 20:30:06.392040
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for chunk in req.iter_body(1):
        print(chunk)


# Generated at 2022-06-17 20:30:14.043631
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO
    from urllib.parse import urlparse

    url = urlparse('http://localhost:8080/')

    request = Request(
        method='GET',
        url=url.geturl(),
        headers={'Host': url.netloc},
        data=b'Hello world',
        files={'file': BytesIO(b'Hello world')},
    )

    request = HTTPRequest(request)

    assert request.headers == '''\
GET / HTTP/1.1
Host: localhost:8080
Content-Length: 11
Content-Type: application/octet-stream
'''

    assert request.body == b'Hello world'

    assert list(request.iter_lines(chunk_size=1)) == [(b'Hello world', b'')]

# Generated at 2022-06-17 20:30:18.133659
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for i in req.iter_body(1):
        print(i)


# Generated at 2022-06-17 20:30:21.919445
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for chunk in req.iter_body(chunk_size=1):
        print(chunk)


# Generated at 2022-06-17 20:31:28.248775
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://httpbin.org/get')
    req = req.prepare()
    req = HTTPRequest(req)
    assert req.iter_body(1) == [b'']


# Generated at 2022-06-17 20:31:38.258573
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    import time
    import random
    import string
    import sys
    import os
    import subprocess
    import signal
    import socket
    import threading
    import http.server
    import socketserver
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import ssl
    import shutil
    import tempfile
    import io
    import contextlib
    import logging
    import re
    import base64
    import hashlib
    import hmac
    import binascii
    import datetime
    import time
    import math
    import copy
    import inspect
    import pprint
    import unittest
    import traceback
    import warnings
    import platform
    import pkg_

# Generated at 2022-06-17 20:31:48.217583
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://example.com')
    req = HTTPRequest(req)
    assert list(req.iter_body(1)) == [b'']
    req = requests.Request('GET', 'http://example.com', data=b'foo')
    req = HTTPRequest(req)
    assert list(req.iter_body(1)) == [b'foo']
    req = requests.Request('GET', 'http://example.com', data=b'foo')
    req = HTTPRequest(req)
    assert list(req.iter_body(2)) == [b'foo']
    req = requests.Request('GET', 'http://example.com', data=b'foo')
    req = HTTPRequest(req)

# Generated at 2022-06-17 20:31:56.170945
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = 'http://httpbin.org/post'
    data = {'key1': 'value1', 'key2': 'value2'}
    r = requests.post(url, data=data)
    req = HTTPRequest(r.request)
    for chunk in req.iter_body(chunk_size=1):
        print(chunk)


# Generated at 2022-06-17 20:32:02.891826
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    import io
    import sys
    import unittest

    class TestHTTPRequest(unittest.TestCase):
        def test_HTTPRequest_iter_body(self):
            # Create a request
            url = 'http://httpbin.org/post'
            data = {'key1': 'value1', 'key2': 'value2'}
            r = requests.post(url, data=data)

            # Create a HTTPRequest object
            req = HTTPRequest(r.request)

            # Test iter_body
            for chunk in req.iter_body(chunk_size=1):
                self.assertEqual(chunk, json.dumps(data).encode('utf8'))

    # Run the unit test

# Generated at 2022-06-17 20:32:08.562268
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests import Request
    from io import BytesIO
    req = Request('GET', 'http://example.com')
    req.body = BytesIO(b'foo')
    req = HTTPRequest(req)
    assert list(req.iter_body()) == [b'foo']


# Generated at 2022-06-17 20:32:13.094716
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests import Request
    req = Request('GET', 'http://example.com')
    req = HTTPRequest(req)
    assert list(req.iter_body(1)) == [b'']
    req = Request('GET', 'http://example.com', data=b'foo')
    req = HTTPRequest(req)
    assert list(req.iter_body(1)) == [b'foo']


# Generated at 2022-06-17 20:32:18.514997
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    req = HTTPRequest(req)
    for line, line_feed in req.iter_lines(1):
        print(line)
        print(line_feed)


# Generated at 2022-06-17 20:32:21.360277
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://example.com')
    req = req.prepare()
    req = HTTPRequest(req)
    lines = list(req.iter_lines(chunk_size=1))
    assert lines == [(b'', b'')]


# Generated at 2022-06-17 20:32:32.337495
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://example.com')
    req.prepare()
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'', b'')]
    req = requests.Request('GET', 'http://example.com', data='a')
    req.prepare()
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'a', b'')]
    req = requests.Request('GET', 'http://example.com', data='a\nb')
    req.prepare()
    req = HTTPRequest(req)
    assert list(req.iter_lines(1)) == [(b'a', b'\n'), (b'b', b'')]