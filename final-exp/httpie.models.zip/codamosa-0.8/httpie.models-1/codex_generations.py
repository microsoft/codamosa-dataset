

# Generated at 2022-06-11 23:37:48.789169
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests

    r = requests.get('https://google.com/')
    req = HTTPRequest(r.request)
    assert len(list(req.iter_body(chunk_size=1))) == 1

# Generated at 2022-06-11 23:37:53.357030
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = mock.Mock(spec=requests.Request)
    http_request = HTTPRequest(request)
    request.body = b'a'
    expected = [b'a']
    assert list(http_request.iter_body(1)) == expected


# Generated at 2022-06-11 23:38:05.155707
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    class TestHTTPRequest(HTTPRequest):
        def __init__(self, body):
            self._orig = Request()
            self._orig.body = body

    r = TestHTTPRequest(b'l1\nl2\nline3\nline4')
    lines = list(r.iter_lines(chunk_size=6))
    assert lines == [(b'l1\nl2\n', b'\n'), (b'line3\n', b'\n'), (b'line4', b'')]

    r = TestHTTPRequest(b'foo')
    lines = list(r.iter_lines(chunk_size=6))
    assert lines == [(b'foo', b'')]

# Generated at 2022-06-11 23:38:07.078267
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    """Test iter_body method of HTTPRequest class"""
    assert True

# Generated at 2022-06-11 23:38:18.932047
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from io import StringIO
    from requests import Request
    from urllib3.response import HTTPResponse
    from .client import default_user_agent

    # Prepare mock objects for the call to Request.prepare()
    request = Request('GET', 'http://localhost/', headers={'User-Agent':default_user_agent})
    urllib3_response = HTTPResponse(body=StringIO(u''), headers={}, status=200, version=1)

    # Get HTTPRequest object
    request.prepare(urllib3_response)
    http_request = HTTPRequest(request)

    # Test iter_lines
    for i, line in enumerate(http_request.iter_lines(chunk_size=1)):
        if i == 0:
            assert line == (b'', b'')


# Generated at 2022-06-11 23:38:26.825767
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    import pytest
    url = 'https://www.baidu.com'
    body = {
        "a": 1,
        "b": "中文"
    }
    headers = {
        "Content-Type": "application/json"
    }
    request = requests.Request(method='POST',url=url,data=json.dumps(body),headers=headers)
    prepped = request.prepare()
    lines = prepped.iter_lines()
    for line in lines:
        if isinstance(line, str):
            assert type(line) == str
        else:
            assert type(line) == bytes

# Generated at 2022-06-11 23:38:38.246848
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    def run(headers, body, expected_result):
        req = HTTPRequest(requests.models.Request(
            'GET',
            url='http://example.org',
            headers=headers,
            body=body
        ))
        result = list(req.iter_lines(1))
        assert result == expected_result

    headers = {'Content-Type': 'text/plain; charset=utf-8'}

    run(headers, '', [b'', b''])
    run(headers, 'hello', [b'hello', b''])
    run(headers, 'hello\nworld', [b'hello', b'\n', b'world', b''])
    run(headers, 'hello\n', [b'hello', b'\n', b''])

# Generated at 2022-06-11 23:38:46.947702
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    def to_bytes(s):
        return s.encode('utf8', errors='replace')
    test_url = 'https://example.com/test_url'
    test_method = 'GET'
    test_headers = {
            'Accept': 'text/html',
            'Accept-Charset': 'ISO-8859-1',
            'Host': 'example.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'
    }
    test_body = to_bytes('<html><body>test body</body></html>')
    req = requests.Request(test_method, test_url, headers=test_headers, data=test_body)

# Generated at 2022-06-11 23:38:53.875133
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response = requests.get("http://www.theguardian.com/world/2019/aug/09/british-cycling-olympic-hopeful-martha-thomas-told-to-delete-criticism-of-oprah-interview")
    response_obj = HTTPResponse(response)
    for line in response_obj.iter_lines(1):
        print("Line, Line feed is: ", line)

# Generated at 2022-06-11 23:38:54.552076
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass

# Generated at 2022-06-11 23:39:07.283070
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    session = requests.Session()
    req_options = session.request('GET', 'https://www.google.com')
    req = HTTPRequest(req_options)
    for line, line_feed in req.iter_lines(1):
        pass
    assert line_feed == b'\n'

# Generated at 2022-06-11 23:39:19.208634
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Test for plain request message
    message = b'GET / HTTP/1.1\r\nHost: foo.com\r\n'
    request = HTTPRequest(requests.models.Request('GET', '/', 
        headers={'Host': 'foo.com'}))
    lines = [line for line, line_feed in request.iter_lines(1024)]
    assert(message == b''.join(lines))

    # Test for request message with body
    message = b'POST / HTTP/1.1\r\nHost: foo.com\r\n\r\nThis is the message body!'
    request = HTTPRequest(requests.models.Request('POST', '/', 
        headers={'Host': 'foo.com'}, 
        data=b'This is the message body!'))

# Generated at 2022-06-11 23:39:30.750242
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test with messages with body chunks
    header_line_list = ['HTTP/1.1 200 OK\r\n', 
                        'Content-Type: text/html\r\n',
                        'Content-Length: 464\r\n',
                        'Connection: close\r\n',
                        'Proxy-Connection: Keep-Alive\r\n',
                        'Date: Thu, 10 May 2018 10:26:06 GMT\r\n',
                        'Server: Apache/2.4.10\r\n',
                        '\r\n']

# Generated at 2022-06-11 23:39:37.972927
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = "https://httpbin.org/post"
    data = {'key1': 'value1', 'key2': 'value2'}
    r = requests.post(url, data=data)
    # print(HTTPRequest(r).iter_body())
    print(type(HTTPRequest(r).iter_body(1)))


# Generated at 2022-06-11 23:39:45.739020
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    print("")
    print("TESTING HTTPRequest_iter_lines")
    first_call = 1
    class testing:
        def __init__(self, body):
            self.body = body
            self._body = body
            self._content = None
            self._content_consumed = False
            self._next = None
            self._content_consumed = False
            self._next = None
    def testing_iter_content(self,chunk_size):
        #print("inside iter_content")
        #print("chunk_size: ", chunk_size)
        #print("self._body: ", self._body)
        if not self._content_consumed:
            self._content_consumed = True
            return iter(self._body)
        return iter('')

# Generated at 2022-06-11 23:39:55.649453
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request, Session
    from urllib.parse import urlparse, urlunparse

    def build_request():
        session = Session()
        request = Request('GET', 'http://127.0.0.1')
        prepped = session.prepare_request(request)
        return HTTPRequest(prepped)
    request = build_request()

    # Unit test for test_HTTPRequest_iter_lines
    def iter_line_test(chunk_size):
        print('--- iter_line_test({}) ---'.format(chunk_size))
        for line, line_feed in request.iter_lines(chunk_size):
            print('line={}, line_feed={}'.format(line, line_feed))
            assert not isinstance(line, str)
            assert isinstance(line, bytes)

# Generated at 2022-06-11 23:40:08.015126
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    data = { "number": 1, "string": "Foo", "boolean": True }
    rqst = requests.Request('POST', 'http://httpbin.org/post', data=data)
    p = rqst.prepare()
    hrqst = HTTPRequest(p)
    for body in hrqst.iter_body(1024):
        print(body)
        print(type(body))
        print(hrqst.body)
        print(type(hrqst.body))
        print(json.dumps(data))
        print(type(json.dumps(data)))
        print(json.dumps(data).encode('utf8'))
        print(type(json.dumps(data).encode('utf8')))

# Generated at 2022-06-11 23:40:12.674562
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    testURL = 'http://hc1.reliablenetworkservices.com/tst.html'

    r = requests.Request('GET', testURL)
    req = HTTPRequest(r)
    rc = 0

    for c in req.iter_body(1):
        print(c)
        rc += 1

    assert rc == 198


# Generated at 2022-06-11 23:40:22.740357
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    from requests.auth import HTTPDigestAuth
    from requests.packages.urllib3.util.retry import Retry
    from requests.adapters import HTTPAdapter
    # Set up a requests session with retries
    s = requests.Session()
    s.mount('https://', HTTPAdapter(max_retries=Retry(total=2, backoff_factor=5)))
    s.auth = HTTPDigestAuth('user', 'password')
    r = s.put('https://httpbin.org/put', data=HTTPRequest({'url': 'https://httpbin.org/put'}))
    r.raise_for_status()
    assert r.status_code == 200
    # Data sent as a result of calling iter_body

# Generated at 2022-06-11 23:40:35.254756
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    example = b"""First line
Second line
Third line
"""
    assert list(HTTPResponse(None).iter_lines(1)) == [
        (b"First line", b'\n'),
        (b"", b'\n'),
        (b"Second line", b'\n'),
        (b"", b'\n'),
        (b"Third line", b'\n'),
        (b"", b'\n'),
    ]

# Generated at 2022-06-11 23:40:58.648206
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    req= Request('GET', 'http://example.com')
    req.headers['Host'] = 'www.example.com'
    hreq=HTTPRequest(req)
    lines=''
    for line, line_feed in hreq.iter_lines(10):
        lines+=line.decode('utf8')+line_feed.decode('utf8')
    print(lines==hreq.headers)

if __name__ == '__main__':
    test_HTTPRequest_iter_lines()

# Generated at 2022-06-11 23:41:03.449954
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get('https://httpbin.org/get')
    message = HTTPResponse(response)
    assert message.iter_lines(chunk_size=1) == message.iter_body(chunk_size=1)


# Generated at 2022-06-11 23:41:11.420417
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import sys
    import responses

    def test_func(resp):
        body = b"response body"
        resp.body = body
        return resp

    with responses.RequestsMock() as rsps:
        rsps.add_callback(responses.GET, 'http://example.com/',
                          content_type='text/html',
                          callback=test_func)

        resp = requests.get('http://example.com/')
        body = b"".join(HTTPRequest(resp.request).iter_body())
        assert body == b"response body"



# Generated at 2022-06-11 23:41:21.510805
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from responses import RequestsMock
    from requests import Session
    from requests.adapters import HTTPAdapter

    sess = Session()
    sess.mount('http://', HTTPAdapter(max_retries=0))
    sess.get('http://example.com')  # this should fail, but still load a response in responses
    with RequestsMock(assert_all_requests_are_fired=True) as rsps:
        rsps.add(rsps.GET, 'http://example.com/test.txt',
                 body='test\n', status=200, stream=True)
        r = sess.get('http://example.com/test.txt')
        resp = HTTPResponse(r)
        assert 'test\n' in resp.body.decode('utf-8')

# Generated at 2022-06-11 23:41:26.768316
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = mock.Mock(
        method='GET',
        url='http://foo/bar/baz?qux=quux',
        headers={
            'Content-Type': 'text/plain'
        },
        body=b'foo\nbar\r\n'
    )
    req = HTTPRequest(request)
    lines = [line for line, _ in req.iter_lines(1)]
    expected = [b'foo\n', b'bar\r\n']
    assert lines == expected



# Generated at 2022-06-11 23:41:33.487821
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    url = 'http://httpbin.org/post'
    data = {
        'key1': 'value1',
        'key2': 'value2'
    }
    r = requests.post(url, data=data)

    req = HTTPRequest(r.request)
    for b in req.iter_body(chunk_size=1):
        print(b)


# Generated at 2022-06-11 23:41:41.726350
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from .base import Data
    from .opener import Opener
    from .parser import Parser

    url = 'http://httpbin.org/post'
    data = 'name=John&surname=Smith'

    opener = Opener()
    response = opener.open(url, data=data)

    if not isinstance(response, HTTPResponse):
        raise RuntimeError('Expected HTTPResponse got %s' % type(response))

    req = HTTPRequest(response._orig.request)

    if not isinstance(req, HTTPRequest):
        raise RuntimeError('Expected HTTPRequest got %s' % type(req))

    parser = Parser(req, response)
    data = parser.next()


# Generated at 2022-06-11 23:41:47.624503
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from .helpers import test_request
    from .objects import HTTPRequest as HTTPRequestObj
    r = test_request()
    msg = HTTPRequest(r)
    for line, lf in msg.iter_lines(None):
        assert isinstance(line, bytes)
        assert isinstance(lf, bytes)
    # Check that it works for an empty request
    for i in range(100):
        r.body = ''
        msg = HTTPRequest(r)
        assert list(msg.iter_lines(None)) == [b'', b'']



# Generated at 2022-06-11 23:41:57.131881
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from urllib.parse import urlparse

    url_str = 'http://localhost/test_HTTPRequest_iter_lines'
    url = urlparse(url_str)
    req = Request(method='POST', url=url_str, data=b'test\n')

    class _HTTPRequest(HTTPRequest):
        def __init__(self):
            self._orig = req

    http_req = _HTTPRequest()
    print()
    for line, line_feed in http_req.iter_lines(1):
        print('{} {}'.format(line, line_feed))
#
#

# Generated at 2022-06-11 23:42:04.782816
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(requests.Request(url='http://www.example.com').prepare())
    lines_list = list(req.iter_lines(1))

    assert lines_list == [(b'', b'')]

    req = HTTPRequest(requests.Request(url='http://www.example.com', data='test_HTTPRequest_iter_lines').prepare())
    lines_list = list(req.iter_lines(1))

    assert lines_list == [(b'test_HTTPRequest_iter_lines', b'')]

# Generated at 2022-06-11 23:42:42.939505
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = requests.Request('GET', 'http://example.org',
        data="{'id': '1234567890', 'some_name': 'some value'}")
    prepped = req.prepare()
    br = HTTPRequest(prepped)
    body = b''
    for chunk in br.iter_body(chunk_size=10):
        body += chunk
    assert body == b"{'id': '1234567890', 'some_name': 'some value'}"
    print('Unit test for method iter_body of class HTTPRequest is OK.')



# Generated at 2022-06-11 23:42:49.852334
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    class Request(object):
        def __init__(self):
            self.body = b'abc'
            self.method = 'GET'
            self.url = 'http://example.com/'
            self.headers = {
                'Host': 'example.com',
            }

    req = HTTPRequest(Request())
    # assert req.iter_lines() == [(b'abc', b'')]
    assert next(req.iter_lines(1)) == (b'abc', b'')



# Generated at 2022-06-11 23:42:57.282148
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    url = "http://127.0.0.1:8080/test"
    headers = {'User-Agent': 'Mozilla/5.0'}
    data = {'msg': 'Hello World!'}
    request = HTTPRequest(requests.Request('post', url, data=data, headers=headers).prepare())
    for i in request.iter_body(1):
        print(i)
        print(type(i))

if __name__ == "__main__":
    test_HTTPRequest_iter_body()

# Generated at 2022-06-11 23:43:09.778062
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(requests.Request(
        method='GET',
        url='http://127.0.0.1:5000/v1/articles?page=1',
        headers={
            'Host': '127.0.0.1:5000',
            'User-Agent': 'python-requests/2.21.0',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        },
        data='{"username": "admin", "password": "123456"}',
    ))
    body = b''
    for line, lf in request.iter_lines(chunk_size=1):
        body += line + lf
    print(body)


# Generated at 2022-06-11 23:43:15.340410
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request

    req = Request('GET', 'https://google.com',
                  headers={'Content-Type': 'text/plain'})
    req = HTTPRequest(req)
    print('1 iteration')
    for line, line_feed in req.iter_lines(chunk_size=1024):
        print('len(line)=', len(line), 'line_feed=', line_feed)


# Generated at 2022-06-11 23:43:16.784611
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    a = HTTPRequest('')
    a.iter_lines()

# Generated at 2022-06-11 23:43:19.811594
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Create an object of class HTTPRequest
    obj = HTTPRequest()
    # Check type of object for class HTTPRequest
    assert isinstance(obj.iter_body(chunk_size=10), Iterable)


# Generated at 2022-06-11 23:43:26.578500
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = "test"
    request = requests.Request(
        'GET',
        'http://test.com/test',
        data=body,
        headers={'Content-type': 'plain/text'}
    )
    request = HTTPRequest(request)
    round_trip = bytearray()
    for chunk in request.iter_body(2):
        for byte in chunk:
            round_trip.append(byte)
    print(round_trip)



# Generated at 2022-06-11 23:43:34.764256
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from requests import session
    import logging
    # Setup logging
    logging.basicConfig()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    def iter_lines(self, chunk_size):
        for line, line_feed in self.iter_lines(chunk_size):
            yield line, line_feed


# Generated at 2022-06-11 23:43:44.455890
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Test data
    request = requests.Request('GET', 'https://google.fr')
    request.headers = {'Content-Type': 'application/json'}
    request.body = 'Test data'

    # Test HTTPRequest
    method_HTTPRequest_iter_body_test = HTTPRequest(request)

    # Test result
    expected_result = [b'Test data']
    result = [chunk for chunk in method_HTTPRequest_iter_body_test.iter_body()]
    assert len(result) == len(expected_result)
    assert expected_result == result
    print('test_HTTPRequest_iter_body PASSED')


# Generated at 2022-06-11 23:44:47.277861
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request, Session
    from delta.trivial_api import Delta

    session = Session()
    request = Request('POST', 'http://example.com', data='foo')
    req = HTTPRequest(request)
    prepped = session.prepare_request(request)

# Generated at 2022-06-11 23:44:51.917809
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_str = "The quick brown fox jumps over the lazy dog."
    test_bytes = test_str.encode('utf8')
    req = HTTPRequest(requests.Request('GET', '/path', data=test_bytes))
    body, feed = next(req.iter_lines(chunk_size=500))
    assert body == test_bytes
    assert feed == b''

# Generated at 2022-06-11 23:44:53.471992
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    a = HTTPRequest(1)
    for i in a.iter_body(1):
        print(i)


# Generated at 2022-06-11 23:45:02.415255
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(requests.Request('POST', 'http://localhost:5000'))
    assert list(request.iter_lines(0)) == [b'']
    assert list(request.iter_lines(1)) == [b'']
    assert list(request.iter_lines(10)) == [b'']

    request = HTTPRequest(requests.Request('POST', 'http://localhost:5000', data='foo'))
    assert list(request.iter_lines(0)) == [(b'foo', b'')]
    assert list(request.iter_lines(1)) == [(b'foo', b'')]
    assert list(request.iter_lines(10)) == [(b'foo', b'')]

# Generated at 2022-06-11 23:45:09.356622
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json
    import string
    import random
    import sys

    def random_string(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length))

    class RandomJsonGenerator:
        def __init__(self, json_dict=None, max_depth=1, max_lines=100,
                     max_char_per_line=100):
            self.json_dict = json_dict
            self.max_depth = max_depth
            self.max_lines = max_lines
            self.max_char_per_line = max_char_per_line


# Generated at 2022-06-11 23:45:09.911614
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    assert True

# Generated at 2022-06-11 23:45:17.000984
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """Unit test for method iter_lines  of class HTTPRequest"""
    from requests import models
    from pprint import pprint
    from miniworld import request_helper
    from miniworld.request_helper import payloads
    req = request_helper.requests_prepare(payloads.introspect_network_prepare, "PUT")
    print("req.body")
    pprint(req.body)
    data = http_request_wrapper(req).iter_lines(1)
    print("data")
    pprint(data)
    exit()


# Generated at 2022-06-11 23:45:20.877277
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b'1234'
    req = HTTPRequest(requests.Request('GET', 'http://example.com/', body=body))
    body_chunk = next(req.iter_body())
    assert body == body_chunk, 'Body of request must be equal to body of response'


# Generated at 2022-06-11 23:45:27.958042
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = b'GET / HTTP/1.0\r\n' \
          b'Host: example.com\r\n' \
          b'Content-Length: 11\r\n' \
          b'\r\n' \
          b'hello world'
    hreq = HTTPRequest(req)
    lreq = list(hreq.iter_lines(chunk_size=10))
    assert lreq[0][0] == b'hello world'

# Generated at 2022-06-11 23:45:30.666341
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest(request_obj)
    for body in req.iter_body(chunk_size=1):
        print(body)

