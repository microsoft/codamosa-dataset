

# Generated at 2022-06-11 23:37:53.303056
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    global request_headers
    global request_body
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from requests.packages.urllib3.util.url import parse_url

# Generated at 2022-06-11 23:38:04.363160
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import io
    import requests

    test_body = b"""
    request body
    with two lines
    """

    response = requests.Response()
    response.raw = io.BytesIO(test_body)
    response.encoding = 'utf8'
    response_wrapper = HTTPResponse(response)
    lines = list(response_wrapper.iter_lines())
    assert len(lines) == 2
    assert lines[0][0] == b'request body\n'
    assert lines[0][1] == b'\n'
    assert lines[1][0] == b'with two lines\n'
    assert lines[1][1] == b'\n'

# Generated at 2022-06-11 23:38:17.825064
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    # Given a request

    req = requests.Request(
        "POST",
        "http://httpbin.org/post",
        data="Test string\nSecond line",
        headers={
            "Accept": "application/json",
            "X-Test-Header": "header is here!",
            "Content-Type": "text/plain",
        }
    )
    req = req.prepare()

    c = HTTPRequest(req)

    # When we iterate over the lines of the body
    # Then we get a list of string
    nb_line = 0
    expected_line = ["Test string", "Second line"]

# Generated at 2022-06-11 23:38:22.360224
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = HTTPRequest(None)
    assert list(request.iter_body(chunk_size=1)) == [b'']
    assert list(request.iter_body(chunk_size=10)) == [b'']
    assert list(request.iter_body(chunk_size=100)) == [b'']



# Generated at 2022-06-11 23:38:26.333972
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    s = requests.Session()
    r = s.get('http://iai.uni-bonn.de/page/')
    r_iter_lines = r.iter_lines()
    for line in r_iter_lines:
        print(line)
        if b'</html>' in line:
            break


# Generated at 2022-06-11 23:38:37.492304
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # method iter_lines should return an iterator over the body yielding (`line`, `line_feed`).
    request = HTTPRequest(requests.models.Request('GET', 'http://localhost', data=b"line1\nline2\n"))
    assert list(request.iter_lines(chunk_size=1)) == [b'line1\n', b'line2\n', b'']
    assert list(request.iter_lines(chunk_size=2)) == [b'line1\n', b'line2\n', b'']
    assert list(request.iter_lines(chunk_size=3)) == [b'line1\n', b'line2\n', b'']

# Generated at 2022-06-11 23:38:44.315440
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    test_request = requests.models.Request(method="GET",
                                           url="http://localhost",
                                           headers={"host":"localhost"})
    test_HTTPRequest = HTTPRequest(test_request)
    assert list(test_HTTPRequest.iter_lines(1)) == [ (b"", b"") ]
    assert list(test_HTTPRequest.iter_lines(2)) == [ (b"", b"") ]
    assert list(test_HTTPRequest.iter_lines(3)) == [ (b"", b"") ]


# Generated at 2022-06-11 23:38:53.512939
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = bytearray(range(255))
    request = HTTPRequest(None)
    request._orig = Request("POST", "http://127.0.0.1", data = body)
    assert list(request.iter_body(chunk_size = 12)) == [body[0:12], body[12:25], body[25:38], body[38:51], body[51:64], body[64:77], body[77:90], body[90:103], body[103:116], body[116:129], body[129:142], body[142:155], body[155:168], body[168:181], body[181:194], body[194:207], body[207:220], body[220:233], body[233:246], body[246:],]


# Generated at 2022-06-11 23:39:00.437819
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(
        requests.Request(
            'GET', 'http://www.example.com',
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data='key=value',
        ).prepare(),
    )
    assert list(request.iter_lines(1)) == [(b'key=value', b'')]


# Generated at 2022-06-11 23:39:08.562805
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from io import BytesIO
    from requests.models import Request
    from requests.compat import urlparse

    from .common import TEST_FILE_PATH, TEST_FILES

    for filename, content in TEST_FILES.items():
        url = urlparse('http://localhost/')
        request = Request('GET', url, data=BytesIO(content))
        message = HTTPRequest(request)
        assert list(message.iter_lines(128)) == [(content, b'')]

        test_file = open(os.path.join(TEST_FILE_PATH, filename), 'rb')
        request = Request('GET', url, data=test_file)
        message = HTTPRequest(request)
        assert list(message.iter_lines(128)) == [(content, b'')]
        test_file.close()

# Generated at 2022-06-11 23:39:20.403241
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    r = requests.Request('GET', url='http://google.fr')
    orig = HTTPRequest(r.prepare())
    body = list(orig.iter_body(chunk_size=1))
    assert body == []
    body = list(orig.iter_body(chunk_size=1024))
    assert body == []


# Generated at 2022-06-11 23:39:29.508091
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    with patch('swagger_codegen.utils.http.URL_REGEX', '^http://test.com/test/$'):
        request = Request('http://test.com/test/test_service', 'post',
                          headers={'Content-Type': 'application/json'}, body='{"test": "test"}')

        req = HTTPRequest(request)
        res = next(req.iter_lines(1))
        assert res[0] == b'{"test": "test"}'
        assert res[1] == b''

# Generated at 2022-06-11 23:39:41.374165
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    r = HTTPRequest(
        requests.models.Request(
            'GET',
            url='http://httpbin.org/get',
            headers={'Host': 'httpbin.org'}
        )
    )
    lines = [
        line
        for line, _ in r.iter_lines(chunk_size=1)
    ]
    expected = [
        b'{\n', b'  "args": {}, \n', b'  "headers": {\n', b'    "Host": "httpbin.org"\n',
        b'  }, \n', b'  "origin": "34.194.125.86", \n', b'  "url": "http://httpbin.org/get"\n', b'}\n'
    ]
    assert lines == expected

# Generated at 2022-06-11 23:39:47.619112
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = requests.Request(method='GET', url='example.com')
    prep = request.prepare()
    prep.body = b'GET / HTTP/1.1\r\nHost: example.com\r\n\r\n'
    req = HTTPRequest(prep)
    assert req.headers == prep.body.decode('utf8')
    assert list(req.iter_body()) == [prep.body]
    

# Generated at 2022-06-11 23:39:56.466358
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    data = 'hello world'
    req = HTTPRequest(requests.Request('GET', 'http://example.com', data=data))
    assert req.body == data.encode('utf8')
    assert list(req.iter_body(chunk_size=1)) == [data.encode('utf8')]
    assert list(req.iter_body(chunk_size=20)) == [data.encode('utf8')]
    assert list(req.iter_body(chunk_size=5)) == [data.encode('utf8')]

    req = HTTPRequest(requests.Request('GET', 'http://example.com', data=''))
    assert list(req.iter_body(chunk_size=1)) == [b'']


# Generated at 2022-06-11 23:40:08.795858
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = 'https://en.wikipedia.org/wiki/Main_Page'
    r = requests.get(url)
    assert isinstance(r, requests.models.Response)
    response = HTTPResponse(r)
    for bytes_ in response.iter_body():
        assert isinstance(bytes_, bytes)

    # # test a string in body
    # data = {
    #     'key1': 'value1',
    #     'key2': 'value2',
    # }
    # r = requests.post(url, data)
    # assert isinstance(r, requests.models.Response)
    # response = HTTPResponse(r)
    # for bytes_ in response.iter_body():
    #     assert isinstance(bytes_, bytes)
    #
    # # test

# Generated at 2022-06-11 23:40:13.122989
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest('testing')
    assert req._orig.body == b'testing'
    assert list(req.iter_lines(1)) == [(b'testing', b'')]
    assert list(req.iter_lines(5)) == [(b'testing', b'')]
    assert list(req.iter_lines(7)) == [(b'testing', b'')]


# Generated at 2022-06-11 23:40:17.636006
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    url = 'https://github.com/pierreadriengiraud'
    req = requests.Request('GET', url)
    prep = req.prepare()
    HTTPRequest(prep).iter_lines(chunk_size=1)
    assert True


# Generated at 2022-06-11 23:40:24.490611
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Generate a response.
    req = requests.get('http://httpbin.org/bytes/16')
    resp = HTTPResponse(req)
    r = list(resp.iter_lines(5))
    num_lines = len(r)
    # Do test.
    assert (num_lines == 4), "The method iter_lines() from class HTTPResponse is not returning an iterator"



# Generated at 2022-06-11 23:40:35.960675
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from requests.compat import urlsplit
    from http.cookies import SimpleCookie
    from contextlib import contextmanager
    from io import BytesIO

    d = {'method': 'GET'}
    request = Request('http://localhost', data=d)
    response = BytesIO('\r\n'.join([
        'HTTP/1.1 200 OK',
        'content-length: 1',
        'content-type: text/html',
        '',
        'a',
    ]).encode('latin1')).read()
    assert list(HTTPRequest(request).iter_body(1)) == [b'a']

# Generated at 2022-06-11 23:41:03.916864
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from track.stubs import FakeResponse

    body = """
    <h1>This is a test</h1>
    <p>This is a test.</p>
    """
    res = FakeResponse(body)

    received_lines = []
    received_line_feeds = []
    for line, line_feed in HTTPResponse(res).iter_lines(2):
        received_lines.append(line)
        received_line_feeds.append(line_feed)


# Generated at 2022-06-11 23:41:13.867792
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    req = Request(
        method='GET',
        url="http://www.x.com",
        data="data1"
    )
    hreq = HTTPRequest(req)
    assert hreq.body == b"data1"
    assert list(hreq.iter_lines(1))[0] == (b"data1", b"")
    req = Request(
        method='GET',
        url="http://www.x.com",
    )
    hreq = HTTPRequest(req)
    assert hreq.body == b""
    assert list(hreq.iter_lines(2))[0] == (b"", b"")

# Generated at 2022-06-11 23:41:17.785987
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'http://example.com/')
    httpreq = HTTPRequest(req)
    lines = [line for line, _ in httpreq.iter_lines(chunk_size=1)]
    assert lines == [b'']

# Generated at 2022-06-11 23:41:23.423014
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    body = '''this is a test \r\nline feed\r\nline feed'''
    req = HTTPRequest(
        Mock(url='http://localhost:8080/',
             headers={'Host': 'localhost:8080'},
             body=body)
    )
    assert ''.join([line.decode('utf8')
                    for line, line_feed in req.iter_lines(8)]) == body
    assert req.headers == '''GET / HTTP/1.1
Host: localhost:8080'''

# Generated at 2022-06-11 23:41:34.827429
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from io import StringIO
    from urllib.request import Request
    from urllib.parse import urlencode
    from urllib.error import HTTPError, URLError
    import json

    class Request:
        def __init__(self, url):
            self.full_url = url
            self.headers = {}
            self.unredirected_hdrs = {}
            self.data = b''
            self.origin_req_host = None
            self.method = 'POST'

        def get_full_url(self):
            return self.full_url

        def get_host(self):
            return 'localhost'

        def get_origin_req_host(self):
            return self.origin_req_host

        def get_type(self):
            return 'http'


# Generated at 2022-06-11 23:41:37.602498
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    r = requests.get('http://httpbin.org/get')
    h = HTTPRequest(r)
    assert next(h.iter_body(chunk_size=1)) == b'{'

# Generated at 2022-06-11 23:41:47.446723
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request_url = urlsplit('http://www.google.com/')
    request_method = 'GET'
    request_headers = {'Accept': '*/*'}
    request_origin_req_host = 'www.google.com'
    request_path_url = '/'
    request_selector = ''
    request_body = b''
    request_kwargs = {}
    request = Request(
        request_method,
        request_url,
        headers=request_headers,
        origin_req_host=request_origin_req_host,
        unverifiable=True,
        **request_kwargs
    )
    request.path_url = request_path_url
    request.selector = request_selector
    request.body = request_body
    request.prepare()

    http_request

# Generated at 2022-06-11 23:41:54.446279
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    response = requests.get("https://httpbin.org/gzip")
    res = HTTPResponse(response)
    body = b""
    crlf = b'\r\n'
    for line, trailing in res.iter_lines(32):
        body += line + crlf + trailing
    assert body == b'\r\n'.join(response.iter_lines(32))

# Generated at 2022-06-11 23:42:00.019663
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO

    req = Request(
        method='POST',
        url='example.com',
        headers={'Content-Type': 'text/plain'},
        data=BytesIO(b'line one\nline two\n')
    )
    req = HTTPRequest(req)
    lines = list(req.iter_lines(chunk_size=1))
    assert lines == [(b'line one', b'\n'), (b'line two', b'\n')]


# Generated at 2022-06-11 23:42:11.288309
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # create a Request instance to mimic the Request class in HTTPRequest
    request = Request('GET', "http://example.com")
    # set the body of request
    request.body = u'{"key": "value"}'
    # set MockResponse instance to mimic the Response class in HTTPResponse
    resp = MockResponse()
    # set the request of resp
    resp.request = request
    # create an HTTPRequest instance
    http_request = HTTPRequest(request)
    # compare the body between request and http_request
    assert request.body == http_request.body
    # create a list to store the result of iter_body
    res = []
    # iterate the body of http_request and store each result into the list
    for i in http_request.iter_body(1):
        res.append(i)
    # compare

# Generated at 2022-06-11 23:42:49.222732
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import BytesIO
    from requests import Response
    resp = Response()
    resp.raw = BytesIO(b'First Line\nSecond Line\n')
    hresp = HTTPResponse(resp)
    lines = hresp.iter_lines(chunk_size=8)
    assert next(lines) == (b'First Line', b'\n')
    assert next(lines) == (b'Second Line', b'\n')

# Generated at 2022-06-11 23:42:59.996869
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # The HTTPResponse is not a real one, so it only has the iterable items that are being tested
    class Response:
        def __init__(self, iter_lines_items):
            self.iter_lines = iter_lines_items

    # The lines on a HTTP message are terminated by a line feed, regardless of the platform
    lines = ['Line 1\n', 'Line 2\n', 'Line 3\n', 'Line 4\n']
    http_response = HTTPResponse(Response(iter(lines)))
    lines_and_line_feed = [('Line 1', b'\n'), ('Line 2', b'\n'),
                           ('Line 3', b'\n'), ('Line 4', b'\n')]

    i = 0

# Generated at 2022-06-11 23:43:06.321614
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    res = requests.get('http://httpbin.org/range/26')
    resp = HTTPResponse(res)
    text = ''
    for b, crlf in resp.iter_lines(chunk_size=1):
        assert crlf == b'\n'
        text += b.decode()
    assert len(text) == 26

# Generated at 2022-06-11 23:43:10.754589
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    data = b'Hello World'
    request = HTTPRequest(None)
    request._orig = None
    request._orig.body = data
    assert request.iter_lines(1) == [(data,b'')]
    assert request.iter_lines(10) == [(data, b'')]

# Generated at 2022-06-11 23:43:16.385700
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    orig = Mock()
    orig.iter_lines = Mock(return_value=iter((b'line1\r\nline2', b'line3')))
    resp = HTTPResponse(orig)
    assert list(resp.iter_lines()) == [(b'line1\r\nline2', b'\r\n'), (b'line3', b'')]


# Generated at 2022-06-11 23:43:27.241365
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import json

    # Create and send a POST request
    req = requests.Request('POST', 'http://example.com', data=json.dumps({'para1': 'val1', 'para2': 'val2'})).prepare()
    print(req.body)
    print(json.dumps({'para1': 'val1', 'para2': 'val2'}))
    print(req.body == json.dumps({'para1': 'val1', 'para2': 'val2'}))
    print(type(req.body))
    req_wrapper = HTTPRequest(req)
    print(req_wrapper.headers)
    print(req_wrapper.body)

# Generated at 2022-06-11 23:43:35.046764
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    url = 'https://www.python.org/'
    r = requests.get(url)
    req = HTTPRequest(r.request)

    # str_1 = ""
    # for line, line_feed in req.iter_lines(chunk_size=1):
    #     str_1 += line.decode('utf8')
    #
    # print(str_1)

    print(url)
    print(req.headers)
    print('-'*80)
    for line, line_feed in req.iter_lines(chunk_size=1):
        print(line)
    print('-'*80)

    print('\n'.join(['-'*80]*3))

# Generated at 2022-06-11 23:43:43.790810
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    url = 'http://google.com'
    query = '?aa=1&bb=2'
    request = HTTPRequest(url + query, 'test', 'POST', b'a body')
    for line, line_feed in request.iter_lines(1):
        print(line.decode('utf8'))
    print()
    for line, line_feed in request.iter_lines(2):
        print(line.decode('utf8'))
    print()


if __name__ == '__main__':
    test_HTTPRequest_iter_lines()

# Generated at 2022-06-11 23:43:45.595867
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    a = HTTPResponse
    response = a(a)
    response.iter_lines()

# Generated at 2022-06-11 23:43:54.647144
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_str = "ABCDEFG"
    test_encoded_bytes = test_str.encode()

    test_request = requests.Request()
    test_request.method = "GET"
    test_request.url = "https://www.google.com"
    test_request.headers = {"Content-Type": "application/json"}
    test_request.body = test_encoded_bytes

    http_request = HTTPRequest(test_request)
    assert test_encoded_bytes == http_request.body

    lines = list(http_request.iter_lines(1))
    assert 1 == len(lines)
    assert test_encoded_bytes == lines[0][0]
    assert b"" == lines[0][1]


# Generated at 2022-06-11 23:45:00.029895
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    http_request = HTTPRequest('http://www.google.com/')
    print(http_request.body)
    print(http_request.iter_body(chunk_size=1))
    assert True == False

# Generated at 2022-06-11 23:45:06.674455
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    #  Initalize test data
    chunk_size = 1
    req = requests.Request(method='GET', url = 'http://httpbin.org/get')
    prepared = req.prepare()
    r = HTTPRequest(prepared)
    expected_data = prepared.body or b''
    expected_line_feed = b''
    #  Test iter_lines
    for line, line_feed in r.iter_lines(chunk_size):
        assert line == expected_data
        assert line_feed == expected_line_feed


# Generated at 2022-06-11 23:45:12.890205
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
  # Create a HTTPRequest object
  request = HTTPRequest()
  # Test the iter_lines method
  request.iter_lines()
  # See if the method returns a string
  assert isinstance(self.headers, str)
  # See if the method returns a string with 8 characters
  assert len(self.headers) == 8
  # See if the method returns an empty string
  assert not self.headers


# Generated at 2022-06-11 23:45:20.630085
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r = 'HTTP/1.0 200 OK\r\nContent-Length: 100\r\n\r\n' + 'a'*100
    r = HTTPResponse(requests.models.Response())
    r._orig.raw._original_response = requests.packages.urllib3.util.make_headers(
        r.headers)
    chunk_size = 8
    res = [i for i in r.iter_lines(chunk_size=chunk_size)]
    expected = [('a'*chunk_size, '\n')]*12 + [('a'*4, '\n')]
    assert res == expected
    res = [i for i in r.iter_lines(chunk_size=chunk_size + 3)]

# Generated at 2022-06-11 23:45:27.299906
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    print('test HTTPRequest iter_body')
    body = 'test'
    expect_body = b'test'
    req = HTTPRequest(Mock(body=body))
    for chunk in req.iter_body(1):
        actual_body = bytes(chunk)
        print('actual_body:', actual_body)
        print('expect_body:', expect_body)
        assert actual_body == expect_body



# Generated at 2022-06-11 23:45:36.435791
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from app import JSONEncoder
    import requests
    import json

    # Using request body as a string
    req = requests.Request(method='POST', url='https://httpbin.org/post',
                           data='{"k1": "v1", "k2": "v2"}')
    req.prepare()

    # Expect that iter_lines in class HTTPRequest 
    # will return a iterator over the body yielding (`line`, `line_feed`)
    for line, line_feed in HTTPRequest(req).iter_lines(chunk_size=1):
        assert line == '{"k1": "v1", "k2": "v2"}'
        assert line_feed == b''

    # Using request body as a dictionary

# Generated at 2022-06-11 23:45:48.844975
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

  data = "a line,\r\n another line\r\na final line"
  data = data.encode('utf-8')

  response = MockResponse(data = data)
  x = HTTPResponse(response)

  expected = [(b"a line,", b"\n"), (b" another line", b"\n"), (b"a final line", b"")]

  for i, v in zip( expected, x.iter_lines(1) ):
    assert v == i
    #print('received', v)
    #print('expected', i)

  print('test_HTTPResponse_iter_lines passed')

  # Uncomment the following code to see it fail to find the third line.
  #data = "a line,\r\n another line\ra final line"
  #data = data

# Generated at 2022-06-11 23:45:51.950568
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request(url='http://www.wikipedia.com')
    preq = HTTPRequest(req)
    for chunk in preq.iter_body(chunk_size=10):
        print(chunk)


# Generated at 2022-06-11 23:46:00.146414
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    msg = "jwnjqnq \r\n wjekqn\r\n wkjqnwjkqn\r\n\r\n"
    #msg = "jwnjqnq \r\nwjekqn\r\nwkjqnwjkqn\r\n\r\n"
    #msg = b"jwnjqnq \r\nwjekqn\r\nwkjqnwjkqn\r\n\r\n"
    #msg = b"jwnjqnq \n wjekqn\n wkjqnwjkqn\n\n"
    resp = requests.Response()
    resp._content = msg
    resp.encoding = 'utf8'
    response = HTTPResponse(resp)

# Generated at 2022-06-11 23:46:10.570461
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    url = 'http://localhost:8000/json/json_rpc'
    headers = {'Content-Type': 'application/json'}
    payload = {
        "jsonrpc": "2.0",
        "method": "add_2_numbers",
        "id": "1",
        "params": {
            "a": 1,
            "b": 2
        }
    }
    req = requests.Request(method='POST', url=url, headers=headers, json=payload)
    http_req = HTTPRequest(req)
    for body in http_req.iter_body():
        print(body.decode('utf-8'))
        print(json.loads(body.decode('utf-8')))
    return
# Test call:
#   pytest -s -v test