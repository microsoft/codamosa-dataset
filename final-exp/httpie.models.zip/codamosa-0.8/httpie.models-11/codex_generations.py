

# Generated at 2022-06-11 23:37:49.040525
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    msg = HTTPRequest(None)
    msg.body = b"Hello, world!"
    msg = msg.iter_lines(chunk_size=1)
    assert(next(msg) == (b"Hello, world!", b""))
    try:
        next(msg)
    except StopIteration:
        pass
    else:
        assert(False)

# Generated at 2022-06-11 23:37:53.435468
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests import Request
    req = Request('get', 'http://www.python.org')
    r = HTTPRequest(req)
    assert isinstance(r.iter_body(chunk_size=1), types.GeneratorType)
    return True


# Generated at 2022-06-11 23:38:05.921722
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Source of the sample request body:
    # https://developer.mozilla.org/en-US/docs/Web/HTTP/Messages
    test_body = b"""\
POST /test.html HTTP/1.1\r
From: yahoo.com\r
User-Agent: Mozilla 5.0\r
\r
A long time ago, in a galaxy far, far away...."""

    r = Mock(wraps=requests.Response())
    r.raw = BytesIO(test_body)
    r.headers = {'Content-Type': 'text/html'}
    r.raw._original_response = httplib.HTTPResponse(sock=None)
    r.raw._original_response.version = 11
    r.raw._original_response.status = 200
    r.raw._original_

# Generated at 2022-06-11 23:38:14.983069
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    orig = requests.Request(
        method='GET',
        url='http://localhost:80',
        headers={},
        files={},
        data=None,
        json=None,
        params=None,
        auth=None,
        cookies=None,
        hooks=None,
        json=None
    )
    expected = b""
    request = HTTPRequest(orig)
    actual = bytes(b"".join(request.iter_body()))
    assert actual == expected


# Generated at 2022-06-11 23:38:24.536499
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from . import request
    from .plumbing import HTTP_REQUEST_HEADER_FORMAT
    from .pycompat import urlparse

    req = request.HTTPRequest()
    req.parse_from_string("GET /unit/tests/files/?x=1&y=2 HTTP/1.1\n" + HTTP_REQUEST_HEADER_FORMAT + "\n\n")
    req_lines = []
    for line, LF in req.iter_lines(chunk_size=1):
        req_lines.append(line + LF)
    req_body = b''.join(req_lines)
    assert req_body == b'GET /unit/tests/files/?x=1&y=2 HTTP/1.1\r\nHost: localhost\r\n\r\n'

# Generated at 2022-06-11 23:38:35.341232
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    """Test that iter_body of HTTPRequest works as intended."""
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req = req.prepare()
    http_req = HTTPRequest(req)
    assert next(http_req.iter_body(1), None) == b''

    req = requests.Request('GET', 'http://www.google.com', data=b'123456789')
    req = req.prepare()
    http_req = HTTPRequest(req)
    assert next(http_req.iter_body(1), None) == b'123456789'

    req = requests.Request('GET', 'http://www.google.com', data=b'123456789',
                           headers={'Content-Encoding': 'test'})
    req = req

# Generated at 2022-06-11 23:38:43.003028
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(requests.Request('get', 'http://www.example.com', headers={'Content-Length': '7'}, data=b'ABC'))

    assert list(request.iter_lines(1)) == [(b'ABC', b''),]

    try:
        request = HTTPRequest(requests.Request('get', 'http://www.example.com', headers={'Content-Length': '4'}, data=b'ABCD'))

        raise AssertionError('At least one line must be yielded by iter_lines')
    except HTTPException as e:
        print(e)

# Generated at 2022-06-11 23:38:49.908718
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import json

    data = {
       'result': 'hello world'
    }

    req = requests.Request('GET', 'http://www.google.com', data=json.dumps(data))
    prepped = req.prepare()
    msg = HTTPRequest(prepped)

    body = []
    for line, line_feed in msg.iter_lines(1):
        body.append(line)
        body.append(line_feed)

    body = b''.join(body)
    assert body == json.dumps(data).encode('utf8')



# Generated at 2022-06-11 23:38:57.953971
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from http.client import HTTPResponse
    from io import BytesIO
    buffer = BytesIO(b'line1\nline2')
    response = HTTPResponse(buffer)
    response.begin()
    response2 = HTTPResponse(buffer)
    response2.begin()
    a = HTTPResponse(response)
    b = HTTPResponse(response2)
    assert a.iter_lines(1) == b.iter_lines(1)


# Generated at 2022-06-11 23:39:07.416944
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """Unit test for the function iter_lines of class HTTPRequest."""
    # Test for empty body
    class EmptyBodyTestCase(unittest.TestCase):
        def runTest(self):
            # Create a request with empty body
            url = 'https://example.com'
            method = 'GET'
            headers = {}
            data = {}
            # Create the request
            req = requests.Request(method, url, headers=headers, data=data)
            # Create a HTTPRequest object
            req_wrapper = HTTPRequest(req)
            # Test the result
            self.assertEqual(req_wrapper.body, b'')
            lines = [line for line, _ in req_wrapper.iter_lines(chunk_size=1)]
            self.assertEqual(lines, [b''])
    # Test for non-empty

# Generated at 2022-06-11 23:39:20.597432
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response = HTTPResponse(requests.get("https://www.google.com"))
    print([line for line in response.iter_lines(10)])
    # print(next(response.iter_lines(10)))
    # print(next(response.iter_lines(10)))
    # print(next(response.iter_lines(10)))


# Generated at 2022-06-11 23:39:30.856463
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    r = requests.Request(method='GET', url='https://www.google.com')
    r = r.prepare()
    orig = r.body
    h = HTTPRequest(r)

    assert h.iter_lines(1) == [(orig, None)]
    assert h.iter_lines(2) == [(orig, None)]
    assert h.iter_lines(2048) == [(orig, None)]
    assert h.iter_lines(len(orig)) == [(orig, None)]
    assert h.iter_lines(len(orig)-1) == [(orig, None)]

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 23:39:42.936743
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Case 1: ``response.encoding = None``
    response = Mock()
    response.encoding = None
    response.iter_lines = Mock()
    response.iter_lines.return_value = ('data1\n', 'data2\n', 'data3\n')
    response_obj = HTTPResponse(response)
    response_obj.iter_lines(2)
    assert isinstance(response_obj.iter_lines(), Iterable)
    assert response.iter_lines.called == True
    assert response.iter_lines.call_args[1]['chunk_size'] == 2

    # Case 2:  ``response.encoding = gbk``
    response.encoding = 'gbk'
    response_obj = HTTPResponse(response)
    response_obj.iter_lines(2)

# Generated at 2022-06-11 23:39:45.450537
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest(Request())
    for chunk in req.iter_body(chunk_size=0):
        print(chunk)

# Generated at 2022-06-11 23:39:53.192356
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(orig=requests.models.Request(
        method='GET', url='https://www.example.com', headers={'Host': 'example.com'}, body=b'Hello World!'))
    lines = list(request.iter_lines(32))
    assert lines == [(b'Hello World!', b'')]
    lines = list(request.iter_lines(5))
    assert lines == [(b'Hello', b''), (b' Worl', b''), (b'd!', b'')]


# Generated at 2022-06-11 23:39:58.573923
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    payload = 'aaa'
    r = HTTPRequest(requests.Request('POST', 'http://example.org', data=payload))
    assert r.body == b'aaa'
    assert [chunk for chunk in r.iter_body()] == [b'aaa']


# Generated at 2022-06-11 23:40:10.388741
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    # A test request
    request = requests.models.Request(
        method="GET",
        url="http://www.bing.com",
        headers={},
    )
    # A test HTTPRequest instance
    HTTPRequest_test = HTTPRequest(request)
    # A test body

# Generated at 2022-06-11 23:40:19.430125
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Setup test
    class MyResponse:
        def iter_lines(self, _):
            yield b'line1\n'
            yield b'line2\n'

        @property
        def raw(self):
            return MyResponse()

    response = MyResponse()

    # Execute test
    http_response = HTTPResponse(response)
    lines = http_response.iter_lines(0)

    # Test result
    assert list(lines) == [(b'line1', b'\n'), (b'line2', b'\n')]

# Generated at 2022-06-11 23:40:26.611368
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    '''Test for iter_lines method of class HTTPRequest.'''
    url = 'https://google.com'
    method = 'GET'

    r = requests.Request(method, url)
    self = HTTPRequest(r)

    expected = [b'', b'']
    actual = []
    for line, line_feed in self.iter_lines(chunk_size=1):
        actual.append(line_feed)
    
    assert expected == actual

# Generated at 2022-06-11 23:40:38.168468
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from urllib.parse import urlsplit
    from werkzeug.wrappers import Request
    string_body = 'test string'
    list_body = ['test string']
    # create a HTTPRequest object
    url = 'https://test.test'
    url = urlsplit(url)
    method = 'GET'
    args = ()
    data = None
    files = {}
    content_type = None
    host = url.netloc.split('@')[-1]
    environ_base = {}
    environ_base['SERVER_NAME'] = host
    environ_base['SERVER_PORT'] = '443'
    environ_base['HTTP_HOST'] = 'test'
    environ_base['REQUEST_METHOD'] = 'GET'

# Generated at 2022-06-11 23:40:55.355178
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from urllib.parse import urlunsplit
    from http import HTTPStatus
    from urllib.parse import urlparse
    from urllib.parse import parse_qs
    from urllib.parse import urlencode
    from requests.models import Request
    from requests.models import Response

    # create an HTTPRequest object
    method = "GET"
    url = "http://www.baidu.com"
    params = {"key": "value"}
    data = urlencode(params)
    headers = {"header-key": "value"}
    cookies = {"cookies-key": "value"}
    files = None
    auth = None
    timeout = 10
    allow_redirects = True
    proxies = None
    hooks = None
    stream = None
    verify = None
    cert = None
    json = None

# Generated at 2022-06-11 23:41:01.685318
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    url = "https://github.com/chaitanya-rapyuta/mitmproxy-http-tutorial/blob/master/mitmproxy2.py"
    message = HTTPRequest( requests.Request(method="GET", url=url).prepare())
    count = 0
    for body_part in message.iter_body():
        count += 1
    assert count == 1


# Generated at 2022-06-11 23:41:05.260822
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
	# HTTPRequest.iter_lines should return one line with only the blank line in it since body is empty
	assert b'' == list(HTTPRequest(requests.PreparedRequest()).iter_lines(1))[0][0]

# Generated at 2022-06-11 23:41:13.170560
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # data
    data = b'line1\nline2\n'

    # Request
    request = requests.Request(method='GET', url='http://example.com')
    request.headers['Host'] = 'example.com'

    # HTTPRequest
    http_request = HTTPRequest(request)

    # test
    lines = list(http_request.iter_lines(chunk_size=1))
    assert lines == [(data[:6], b'\n'), (data[6:], b'')]

# Generated at 2022-06-11 23:41:18.743702
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from string import ascii_letters
    from random import sample
    from requests import Request
    request = Request('GET', 'http://example.com', data=sample(ascii_letters, 8))
    response = HTTPRequest(request)
    actual = b''.join(response.iter_body(1))
    expected = b''.join(request.body)
    assert actual == expected



# Generated at 2022-06-11 23:41:21.975689
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = HTTPRequest(None)
    request._orig.body = "Hello"
    for i in request.iter_body(1):
        print(i)
        print(type(i))


# Generated at 2022-06-11 23:41:27.573625
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Arrange
    import requests
    r = requests.Request('GET', 'https://httpbin.org/get')
    http_request = HTTPRequest(r)

    # Sanity check
    assert str(http_request.headers) == 'GET /get HTTP/1.1\r\nHost: httpbin.org'

    # Act
    body = b''
    for c in http_request.iter_body(100):
        body += c

    # Assert
    assert body == b''

# Generated at 2022-06-11 23:41:38.625476
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import StringIO
    import pytest
    from http.client import HTTPResponse
    from httplib2 import Http
    from http.server import HTTPServer, BaseHTTPRequestHandler
    import threading
    import requests
    import re

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'123\n456\n789\n')

        def do_POST(self):
            # The response body is the request body.
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()

# Generated at 2022-06-11 23:41:46.329068
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    class MyRequest:
        def __init__(self):
            self.body = b'\x14\x15\x92I\x02\xf8\x01\x07\x9b\x1f\xa0\x00\x00\x01\xc0\x04\x03\x02\x00\x01\x00\x01\x00\x00\x0f\x00\x01'
    r = MyRequest()
    request = HTTPRequest(r)
    for line, line_feed in request.iter_lines(1):
        print(line, line_feed)



# Generated at 2022-06-11 23:41:54.552607
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import tempfile
    import requests
    req = requests.Request('GET', 'http://www.google.com')
    req_str = HTTPRequest(req)
    req_str.iter_lines(chunk_size=1)
    req_str.body
    with tempfile.NamedTemporaryFile() as f:
        for line, line_feed in req_str.iter_lines(chunk_size=10):
            f.write(line)
            f.write(line_feed)

# Generated at 2022-06-11 23:42:15.122049
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # When there is only one line in the body (no '\n' char)
    # we expect to receive the same line twice:
    # 1) as a line (with '\n' removed)
    # 2) as a line_feed
    req = HTTPRequest(object())
    req._orig = object()
    req._orig.body = b'abc'
    lines = req.iter_lines(chunk_size=1)
    try:
        line1, line_feed1 = next(lines)
    except StopIteration:
        fail("Iteration should continue")
    else:
        assertEqual(line1, b'abc')
        assertEqual(line_feed1, b'')


# Generated at 2022-06-11 23:42:18.617299
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = requests.get('http://httpbin.org/get')
    req_msg = HTTPRequest(req.request)
    lines = list(req_msg.iter_body(2))
    assert len(lines) == 1
    assert lines[0] == b'{}' or b'[]'

# Generated at 2022-06-11 23:42:24.089360
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = requests.Request(method='POST')
    request._enc_data = '{"a": 1, "b": 2}'

    http_request = HTTPRequest(request)
    actual_lines = []
    for line in http_request.iter_lines(chunk_size=2):
        actual_lines.append(line)

    assert actual_lines == [(b'{"a": 1, "b": 2}', b'')]


# Generated at 2022-06-11 23:42:33.484042
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-11 23:42:39.690993
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    """
    Test method iter_body of HTTPRequest class
    :return: Boolean
    """
    headers = {'Content-Type':  'text/html; charset=utf-8'}
    request = HTTPRequest(requests.Request('GET', 'http://localhost', data={'key': 'value'}, headers=headers).prepare())
    assert list(request.iter_body(10)) == [b'key=value']


# Generated at 2022-06-11 23:42:45.725595
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    r = requests.get('http://www.futebolada.net/')
    r.encoding = r.apparent_encoding
    obj = HTTPResponse(r)
    print(obj.body)
    print(obj.headers)
    sum_line = 0
    for item in obj.iter_lines(1):
        sum_line += len(item[0].decode('utf-8'))
    print(sum_line)



# Generated at 2022-06-11 23:42:49.462442
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.google.com/')
    req = req.prepare()
    req = HTTPRequest(req)
    response = list(req.iter_body())[0]
    assert(response == b'')


# Generated at 2022-06-11 23:42:56.893505
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    d = {'a':'a', 'b':'b'}
    json_data = json.dumps(d)
    r = request.Request('POST', 'http://httpbin.org/post', data=json_data.encode())
    http_request = HTTPRequest(r)
    
    assert next(http_request.iter_body(1)) == json_data.encode()
    assert next(http_request.iter_body(1)) == b''
    
test_HTTPRequest_iter_body()


# Generated at 2022-06-11 23:43:01.833592
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert list(HTTPRequest(requests.Request('GET', 'http://httpbin.org')).iter_body(1)) == [b'']
    assert list(HTTPRequest(requests.Request('POST', 'http://httpbin.org', data=b'abc123')).iter_body(1)) == [b'abc123']

# Generated at 2022-06-11 23:43:09.966582
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    data = {'key':'value'}
    r = requests.Request('GET', 'http://localhost/', data=data)
    req = HTTPRequest(r.prepare())
    assert b'key=value' == next(req.iter_lines(chunk_size=1))[0]
    assert b'' == next(req.iter_lines(chunk_size=1))[1]
    assert None == next(req.iter_lines(chunk_size=1), None)

# Generated at 2022-06-11 23:43:30.922822
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    request = requests.Request('POST', 'http://example.com')
    request = HTTPRequest(request)
    for chunk in request.iter_body(chunk_size=1):
        assert isinstance(chunk, bytes)
        assert chunk == b''

# Generated at 2022-06-11 23:43:41.322680
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import socket
    import http.server
    import requests
    import threading

    class MockHttpServer(http.server.BaseHTTPRequestHandler):
        encoding = 'utf-8'

        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write('a'.encode(self.encoding))
            self.wfile.write('💩'.encode(self.encoding))

    def http_server_method():
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Generated at 2022-06-11 23:43:51.885245
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_file_path = './test_message_body.txt'
    msg = HTTPResponse
    f = open(test_file_path, 'r')
    message = f.read().encode('utf-8')
    # Test boundary cases
    test_list = [1, 2, 4, 16, 32, 64, 128, 4*1024*1024]
    for i in test_list:
        result = list(msg.iter_lines(message, chunk_size=i))
        assert_true(result[0][0] == message)
    # Test wrong input
    test_list = [-1, 0, 1.4]
    for i in test_list:
        assert_raises(AssertionError, list, msg.iter_lines(message, chunk_size=i))


# Generated at 2022-06-11 23:43:56.527349
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests as req

    url = 'https://www.google.com/'
    resp = req.get(url)

    req = HTTPRequest(resp.request)
    assert resp.status_code == 200

    body = b''.join(req.iter_body(chunk_size=1))
    assert len(body) > 0
    assert body == resp.content


# Generated at 2022-06-11 23:43:59.557740
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest("abc")
    req.body = "123"
    assert next(req.iter_lines(bytes)) == ("123", b'\n')

if __name__ == '__main__':
    test_HTTPRequest_iter_lines()

# Generated at 2022-06-11 23:44:01.622191
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = requests.Request('GET', 'https://httpbin.org/get')
    req = HTTPRequest(req)
    assert next(req.iter_lines(1)) == (b'', b'')

# Generated at 2022-06-11 23:44:06.489721
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = HTTPRequest(None)
    request._orig = requests.Request(method='GET', url='')
    request._orig.body = b'this is a test case'
    for chunk in request.iter_body(5):
        assert isinstance(chunk, bytes)



# Generated at 2022-06-11 23:44:15.906825
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    headers = """
HTTP/1.0 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
ETag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

"""
    body = """
    <html>
    <head>
    <title>An Example Page</title>
    </head>
    <body>
    Hello World, this is a very simple HTML document.
    </body>
    </html>
    """
    message = headers + body
    lines = []

# Generated at 2022-06-11 23:44:25.304768
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import unittest

    content = b'Content of response body'
    url = 'http://example.com'
    headers = {'header': 'value'}
    body = b'Content of request body'
    request = requests.Request(
        'GET', url, headers=headers, data=body).prepare()
    response = requests.Response()
    response._content = content
    response.raw = requests.packages.urllib3.HTTPResponse(
        body=content, preload_content=False)
    response.raw._original_response = response
    response.request = request
    response.headers = headers


# Generated at 2022-06-11 23:44:31.045334
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    class MockRequest():
        def __init__(self, body):
            self.body = body
            
        def _enc_params(self, data):
            return data

        def _encode_params(self, data):
            return data

    body = 'this is a body'.encode()
    original_request = MockRequest(body)
    new_request = HTTPRequest(original_request)
    lines = list(new_request.iter_lines(None))

    assert lines[0] == (body, b'')

# Generated at 2022-06-11 23:45:09.950574
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    pre_request = requests.Request('GET', 'http://www.google.com')
    req = HTTPRequest(pre_request)
    assert req.iter_lines is not None
    for line in req.iter_lines(1024):
        assert line[0] == b''
        assert line[1] == b''


# Generated at 2022-06-11 23:45:15.716634
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    m = HTTPRequest(requests.Request(
        'GET',
        'https://test.test/testurl',
        headers={},
    ))
    l = m.iter_lines(2)
    for i, x in enumerate(l):
        assert x[1] == b'', f"Unexpected {i}-th line feed"
    assert i == 0, f"No line expected, but got {i}"


# Generated at 2022-06-11 23:45:22.763518
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests.models import Request
    from urllib.parse import urlparse
    from datetime import datetime
    now = datetime.now()
    data = {'c1':now, 'c2':'ok'}
    req = Request('POST', 'http://localhost:8080/demo', data=data)
    request = HTTPRequest(req)
    for line, _ in request.iter_lines(chunk_size=1):
        print(line)

# Generated at 2022-06-11 23:45:27.148362
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b'body'
    request = HTTPRequest(
        requests.Request(
            method='GET',
            url='https://www.google.com',
            data=body,
        ),
    )
    assert list(request.iter_body(1)) == [body]


# Generated at 2022-06-11 23:45:35.708297
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Test HTTPResponse.iter_lines()."""
    x = b'\n'.join([
        b'foo',
        b'bar',
        b'',
        b'baz',
        b'',
        b'',
        b'qux'
    ])

    req = requests.Response()
    req._content = x
    req._content_consumed = False

    res = HTTPResponse(req)

    actual = list(row for row, eol in res.iter_lines(1))
    assert actual == [
        b'foo',
        b'bar',
        b'',
        b'baz',
        b'',
        b'',
        b'qux'
    ]



# Generated at 2022-06-11 23:45:40.577569
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://httpbin.org/get')
    req = req.prepare()
    req = HTTPRequest(req)

    content = b''
    for chunk in req.iter_body(chunk_size=2):
        content += chunk

    assert content == req.body

# Generated at 2022-06-11 23:45:41.570261
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-11 23:45:47.078980
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(object())
    req._orig = requests.Request(method='GET', body='foo\nbar\n', url='http://localhost/')
    assert list(req.iter_lines(chunk_size=1)) == [(b'foo\n', b'\n'), (b'bar\n', b'\n')]

# Generated at 2022-06-11 23:45:51.541821
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b"Hello"
    request = requests.Request(method="GET", url="http://url.com", data=body)
    prepared = request.prepare()
    http_request = HTTPRequest(prepared)
    assert body == b''.join(http_request.iter_body())


# Generated at 2022-06-11 23:45:57.723321
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = Mock()
    request.method = 'method'
    request.url = 'url'
    request.headers = {'header': 'value'}
    request.body = 'body'

    request = HTTPRequest(request)
    # body, end
    assert next(request.iter_lines(1)) == (b'body', b'')
    try:
        next(request.iter_lines(1))
        assert False, "Should not be reached"
    except StopIteration:
        pass

# Generated at 2022-06-11 23:47:25.560346
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    class _FakeResponse:
        def __init__(self, data):
            self.content = data

        def iter_lines(self, chunk_size):
            return self.content.splitlines(1)

    data = b'''
one
two
three

four
supports-empty-lines
'''.strip()

    msg = HTTPResponse(_FakeResponse(data))

    lines = list(msg.iter_lines(1))
    assert len(lines) == 7
    assert lines[0] == (b'one\n', b'\n')
    assert lines[1] == (b'two\n', b'\n')
    assert lines[2] == (b'three\n', b'\n')
    assert lines[3] == (b'\n', b'\n')
    assert lines

# Generated at 2022-06-11 23:47:29.542567
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    r = requests.get("http://www.python.org")
    request = HTTPRequest(r.request)
    body = b""
    for chunk in request.iter_body(chunk_size=1):
        body += chunk
    assert request.body == body


# Generated at 2022-06-11 23:47:33.623871
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    r = requests.Request('GET', 'http://example.com')
    req = HTTPRequest(r)
    req_body = req.body
    for req_line, req_feed in req.iter_lines(chunk_size=1):
        assert req_line == req_body
        assert req_feed == b''