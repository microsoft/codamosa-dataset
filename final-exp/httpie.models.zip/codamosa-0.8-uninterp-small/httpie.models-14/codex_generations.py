

# Generated at 2022-06-25 18:26:12.332428
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print("Testing HTTPResponse.iter_lines()")
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    # Call method iter_lines of class HTTPResponse with parameter
    # str_0 and 'utf8'
    assert h_t_t_p_response_0.iter_lines('utf8') is not None


# Generated at 2022-06-25 18:26:16.184945
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    data = 'a\nb\nc\nd'

    with mock.patch('requests.models.Request.body', data):
        assert list(HTTPRequest(mock.Mock()).iter_lines(1)) == [
            (b'a', b'\n'),
            (b'b', b'\n'),
            (b'c', b'\n'),
            (b'd', b''),
        ]

#  Unit test for method iter_body of class HTTPRequest

# Generated at 2022-06-25 18:26:23.307988
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_0 = HTTPRequest(test_iter_lines_0)
    for _ in range(4):
        for body_0, line_feed_0 in h_t_t_p_request_0.iter_lines(chunk_size=test_iter_lines_1):
            pass


# Generated at 2022-06-25 18:26:30.335797
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r = mock.Mock()
    r.iter_lines.return_value = (
        b'abc', b'def', b'ghi', b'jkl', 
        b'mno', b'pqr', b'st', b'uvwx',
        b'yzABCDEFGHIJK', b'LMNOPQRSTUVWXYZ'
    )

    response = HTTPResponse(r)

    lines = []
    for line, line_feed in response.iter_lines(12):
        lines.append((line, line_feed))


# Generated at 2022-06-25 18:26:37.917627
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'GET / HTTP/1.1\r\nHost: www.bing.com\r\n\r\n'
    req_0 = HTTPRequest(str_0)

# Generated at 2022-06-25 18:26:42.469847
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests

    r = requests.get('https://httpbin.org/get')
    assert r.status_code == 200
    assert r.reason == 'OK'
    assert r.content
    req = HTTPRequest(r.request)
    req.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:26:46.409513
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ']+7v\t{\x0c\x1b'
    h_t_t_p_message_0 = HTTPRequest(str_0)
    int_0 = 4239
    h_t_t_p_message_0.iter_body(int_0)


# Generated at 2022-06-25 18:26:52.862378
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    url = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    r = requests.get(url)
    request = HTTPRequest(r.request)
    iter_lines = request.iter_lines()
    assert next(iter_lines) == (b'hello world', b'')


# Generated at 2022-06-25 18:27:00.381785
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'User-Agent'
    str_1 = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:58.0) Gecko/20100101 Firefox/58.0'
    str_2 = 'Accept-Encoding'
    str_3 = 'gzip, deflate'
    str_4 = 'Accept'
    str_5 = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    str_6 = 'Accept-Language'
    str_7 = 'en-US,en;q=0.5'
    str_8 = 'Referer'
    str_9 = 'https://www.google.com/'
    str_10 = 'Connection'

# Generated at 2022-06-25 18:27:08.157884
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_request_2 = HTTPRequest(str_0)
    h_t_t_p_request_2.iter_lines(1)
    h_t_t_p_request_3 = HTTPRequest(str_0)
    h_t_t_p_request_3.iter_lines(1)
    h_t_t_p_request_4 = HTTPRequest(str_0)
    h_t_t_p_request_4.iter_lines(1)


# Generated at 2022-06-25 18:27:20.911405
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    content_type = 'application/x-www-form-urlencoded'
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='


# Generated at 2022-06-25 18:27:31.772400
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_1 = 'aGVsbG8gd29ybGQ='
    bytes_0 = b'hello world'
    bytes_1 = b'hello\nworld\n'
    bytes_2 = b'hello\nworld'
    bytes_3 = b'hello world\n'
    bytes_4 = b'hello world\n\nHow are you today?'
    str_4 = 'aGVsbG8gd29ybGQKClRvZGF5J3MgbGlnaHQgaXMgZ3JlYXQu'
    tuple_0 = (1024, )
    tuple_1 = (str_0, )

# Generated at 2022-06-25 18:27:43.216797
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='

    # @type check
    assert isinstance(str_0, str)

    http_request = HTTPRequest(str_0)

    # @type check
    assert isinstance(http_request, HTTPRequest)

    # @type check
    assert isinstance(http_request.headers, str)

    # @type check
    assert isinstance(http_request.encoding, str)

    # @type check
    assert isinstance(http_request.body, bytes)

    # @type check
    assert isinstance(http_request.content_type, str)

    for i in http_request.iter_body(1024):
        # @type check
        assert isinstance(i, bytes)
        pass


# Generated at 2022-06-25 18:27:49.848680
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_1 = 'base64%3DaGVsbG8gd29ybGQ%3D'
    str_2 = 'base64'
    str_3 = 'http://httpbin.org/?base64=aGVsbG8gd29ybGQ='
    str_4 = 'http://httpbin.org/'
    str_5 = '%3DaGVsbG8gd29ybGQ%3D'
    str_6 = 'aGVsbG8gd29ybGQ='
    str_7 = '%3DaGVsbG8gd29ybGQ%3D'

# Generated at 2022-06-25 18:27:59.922995
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='

    # from: http://docs.python-requests.org/en/latest/user/quickstart/

    import requests
    r = requests.get(str_0)
    assert r.status_code == requests.codes.ok
    response = HTTPResponse(r)

    for line in response.iter_lines(1):
        print(line)

    content = response.body
    print(b'content: {}'.format(content))

    print(response.encoding)
    # assert response.encoding == 'utf8'

    assert r.text == 'aGVsbG8gd29ybGQ='
    assert r.text == content.decode(response.encoding)

#

# Generated at 2022-06-25 18:28:10.171340
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'http://httpbin.org/gzip'
    request_0 = requests.Request(str_0)
    response_0 = requests.HTTPAdapter().build_response(request_0)
    response_1 = requests.get(str_0)
    body_0 = response_1.iter_content()
    request_0 = responses.HTTPRequest(request_0)
    response_0 = responses.HTTPResponse(response_0)
    iter_lines_0 = response_0.iter_lines(1)
    i = 0
    for line, line_feed in iter_lines_0:
        assert not line_feed
        assert line == next(body_0)
        i += 1
        if i > 8:
            break


# Generated at 2022-06-25 18:28:19.005304
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from mock import Mock
    req = Request(method='GET', url='http://httpbin.org')
    req.body = b'hello world'
    test_obj = HTTPRequest(req)
    chunk_size = 1
    # __call__操作，没有实际意义
    mock_iterator = Mock()
    # 调用iter_lines方法
    ret_iterator = test_obj.iter_lines(chunk_size=chunk_size)
    assert ret_iterator.__next__() == (b'hello world', b'')
    # 调用iter_lines方法
    ret_iterator = test_obj.iter_lines(chunk_size=chunk_size)
    assert ret_iterator.__

# Generated at 2022-06-25 18:28:30.780107
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Create http response
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_1 = 'R0VU'
    str_2 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_3 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_4 = 'aGVsbG8gd29ybGQ='
    str_5 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    str_6 = 'aGVsbG8gd29ybGQ='
    hTTPRequest_0 = HTTPRequest(None)
    # hTTPRequest_

# Generated at 2022-06-25 18:28:35.395427
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    # Create HTTPRequest object
    http_request = HTTPRequest(requests.models.Request(url=str_0, headers={u'Content-Length': u'12'}, method=u'GET', body=b'Hello world'))
    assert type(http_request) == HTTPRequest
    # Test iter_body method
    result_iter_body = http_request.iter_body(10)
    assert result_iter_body == b'Hello world'


# Generated at 2022-06-25 18:28:38.046612
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='

    response = HTTPRequest(str_0)
    response.iter_body(str_0)


# Generated at 2022-06-25 18:28:59.587424
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    r_0 = requests.get('http://httpbin.org/base64/aGVsbG8gd29ybGQ=')
    req_0 = HTTPRequest(r_0.request)
    assert type(req_0.iter_body()) == '???'


# Generated at 2022-06-25 18:29:04.721808
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # HTTPRequest.body - http://httpbin.org/base64/SGVsbG8sIHdvcmxk
    req = HTTPRequest(requests.Request(
        'GET', 'http://httpbin.org/base64/aGVsbG8gd29ybGQ=',
        headers={'Content-Type': 'text/html'}
    ))
    assert list(req.iter_lines(1)) == [(b'hello world', b'')]



# Generated at 2022-06-25 18:29:09.935490
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    case_name, str_0 = ('HTTPRequest.iter_lines', 'http://httpbin.org/base64/aGVsbG8gd29ybGQ=')
    http_request = HTTPRequest(str_0)
    http_response = HTTPResponse(requests.get(http_request))

    #print(http_response.headers)
    #print(http_response.encoding)
    #print(http_response.body)

    print(f'{case_name} case 0: ')


# Generated at 2022-06-25 18:29:14.275488
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from pprint import pprint
    # Create an instance of class HTTPRequest
    # http_request_0 = HTTPRequest()

    # TODO: Add test cases for iter_lines method
    print('Test iter_lines of class HTTPRequest')
    pprint(HTTPRequest)

# Generated at 2022-06-25 18:29:16.395454
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    m_0 = HTTPRequest(str_0)
    b_0 = m_0.iter_body()

    assert str(b_0) == None


# Generated at 2022-06-25 18:29:19.367909
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():

    test_HTTPRequest_iter_lines_0()


# Generated at 2022-06-25 18:29:21.676866
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    chunks = [1]
    data = b'foo bar'
    result = HTTPRequest(None).iter_body(chunks)
    assert next(result) == b'foo bar'


# Generated at 2022-06-25 18:29:26.231722
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
#

# Generated at 2022-06-25 18:29:30.155299
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'http://httpbin.org/base64/aGVsbG8gd29ybGQ='
    r = HTTPRequest(requests.get(str_0))
    s = b''.join(r.iter_body(1))
    assert s == b'aGVsbG8gd29ybGQ='

# Generated at 2022-06-25 18:29:30.921552
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass

# Generated at 2022-06-25 18:29:47.016721
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    int_0 = 4
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = '*1V\x1d\x7f/\t%u\r\'8qF\x1eX[\x1e\x1d;L\x1fh\r\r'
    int_1 = 3
    h_t_t_p_response_1 = HTTPResponse(str_1)
    str_2 = '\x04Xy\x1bA\x1d:_\x1b7\r\r'
    int_2 = 5
    h_t_t_p_response_2 = HTTPResponse(str_2)
   

# Generated at 2022-06-25 18:29:50.909959
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '`+6~MQDl\r'
    HTTPRequest_0 = HTTPRequest(str_0)
    chunk_size_0 = chunk_size = 100
    HTTPRequest_0.iter_lines(int_0 = chunk_size_0)


# Generated at 2022-06-25 18:30:03.355230
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    str_1 = '1ZzpH[9'
    str_2 = 'j#r~7l}'
    str_3 = '\r'
    str_4 = 'H!?8XS'
    str_5 = 'n@*!}\''
    str_6 = '+s?\x7f'
    str_7 = 'b{]|\x7f'
    str_8 = 'zDlA+6'
    str_9 = '\x7f2}w'
    int_0 = 0
    int_1 = 0
    str_10 = 'm_r7l'
    # Creation of HTTPResponse

# Generated at 2022-06-25 18:30:05.907661
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_message_0.iter_lines(1)


# Generated at 2022-06-25 18:30:16.727428
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n'
    str_1 = 'Z^Ie{|bF1\r'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0_iter_lines = h_t_t_p_request_0.iter_lines(int_0)
    for x_0 in h_t_t_p_request_0_iter_lines:
        str_2 = 'x*P'
        str_3 = 'a5\x0c%H\x0b'
        str_4 = 'MQG3f6F&'
        str_5 = '$>'
        str_6 = '\n'
        str_7 = 'C\r'

# Generated at 2022-06-25 18:30:22.108819
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'test_value'
    int_0 = 1
    h_t_t_p_response_0 = HTTPResponse(str_0)
    for line, line_feed in h_t_t_p_response_0.iter_lines(int_0):
        pass


# Generated at 2022-06-25 18:30:27.928024
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    for h_t_t_p_message_0 in h_t_t_p_response_0.iter_lines(int_arg_0):
        int_0 = h_t_t_p_message_0[0]
        str_1 = h_t_t_p_message_0[1]


# Generated at 2022-06-25 18:30:31.460455
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(chunk_size=15, test=True)


# Generated at 2022-06-25 18:30:32.739083
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_HTTPResponse_iter_lines_0()
    test_HTTPResponse_iter_lines_1()


# Generated at 2022-06-25 18:30:38.823942
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 0
    tuple_1 = (b'`+6~MQDl\r', b'')
    tuple_0 = (tuple_1,)
    assert tuple_0 == tuple(h_t_t_p_request_0.iter_lines(int_0))


# Generated at 2022-06-25 18:30:51.827148
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print(test_HTTPResponse_iter_lines.__name__)
    int_0 = 2
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    for h_t_t_p_message_0 in h_t_t_p_response_0.iter_lines(int_0):
        print(h_t_t_p_message_0)


# Generated at 2022-06-25 18:30:56.290386
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'http://demo.com'
    response = requests.get(url)
    assert isinstance(response, requests.models.Response)

    h_t_t_p_response_0 = HTTPResponse(response)



# Generated at 2022-06-25 18:31:00.609490
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Make a simple request, then return the first 4 lines.
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_message_0.iter_lines


# Generated at 2022-06-25 18:31:08.667328
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'http://127.0.0.1:5000/test?a=1'
    r = requests.get(url, headers={'X-Test': 'value'})
    response_0 = HTTPResponse(r)
    assert isinstance(response_0.iter_lines(1024), Iterable)
    data = list(response_0.iter_lines(1024))
    assert data[1][1] == b'\n'


# Generated at 2022-06-25 18:31:13.261765
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_message_0 = HTTPMessage('')
    h_t_t_p_message_0._orig = ''
    str_0 = '\x1c!\x1b>\x0b\x1e'
    int_0 = 2
    # h_t_t_p_message_0.iter_lines(int_0)
    # h_t_t_p_message_0.iter_lines(str_0)


# Generated at 2022-06-25 18:31:14.982925
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # No need to test with `unittest`.
    # This method is abstract.
    pass


# Generated at 2022-06-25 18:31:19.923473
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    http_response_0 = HTTPResponse('`+6~MQDl\r')
    bool_0 = http_response_0.iter_lines()


# Generated at 2022-06-25 18:31:23.421171
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # init instance of HTTPResponse class
    h_t_t_p_response_0 = HTTPResponse('')
    # call iter_lines
    h_t_t_p_response_0.iter_lines('u;{G4q')


# Generated at 2022-06-25 18:31:28.207014
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_response_1 = HTTPResponse(h_t_t_p_message_0)
    h_t_t_p_response_1.iter_lines(16)


# Generated at 2022-06-25 18:31:33.491724
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_var_0 = str_0
    str_var_1 = str_0
    str_var_2 = str_0
    str_var_3 = str_0
    str_var_4 = str_0
    str_var_5 = str_0
    str_var_6 = str_0

# Generated at 2022-06-25 18:31:50.041360
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    result = h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:31:51.828059
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert False


# Generated at 2022-06-25 18:32:03.259328
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '1.1'
    str_1 = '302'
    str_2 = 'Found'
    str_3 = 'date: Fri, 01 Dec 2017 18:28:17 GMT'
    str_4 = 'content-type: text/html; charset=utf-8'
    str_5 = 'content-length: 547'
    str_6 = 'cache-control: private'
    str_7 = 'location: https://www.google.com/'
    str_8 = 'content-security-policy: default-src \'none\'; script-src \'self\'; connect-src \'self\'; img-src \'self\'; style-src \'self\';'
    str_9 = 'x-content-type-options: nosniff'

# Generated at 2022-06-25 18:32:06.659622
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    self_0 = HTTPResponse()
    str_0 = ''
    string_0 = str_0[:]
    int_0 = -1
    self_0.iter_lines(int_0)


# Generated at 2022-06-25 18:32:10.698287
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_message_0 = HTTPResponse(str_0)
    test_HTTPResponse_iter_lines_0 = h_t_t_p_message_0.iter_lines(1)


# Generated at 2022-06-25 18:32:13.713263
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_r_0 = HTTPResponse(str_0)
    int_0 = 52283
    h_t_t_p_r_0.iter_lines(int_0)


# Generated at 2022-06-25 18:32:22.448277
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = 'Pm_V7'
    str_2 = 'U*%c;NAJ\t'
    str_3 = '8{9[g(~^]\x14'
    str_4 = 'gd4|Y'
    str_5 = '\x1c'
    str_6 = '^M+'
    str_7 = '4Y(,}'
    str_8 = '{!^/n'
    str_9 = '?%=m)@b'
    str_10 = 'M9(h{'
    str_11 = 'P}'
    str_12 = '\t'

# Generated at 2022-06-25 18:32:27.183871
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ',A0b2QH5c\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = h_t_t_p_response_0.iter_lines(15)
    assert(int_0 == 1)


# Generated at 2022-06-25 18:32:28.789192
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print('Testing iter_lines of class HTTPResponse')


# Generated at 2022-06-25 18:32:39.171176
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import BytesIO
    from http.client import HTTPMessage
    from http.client import HTTPResponse
    from requests.models import Response

    resp = Response()

    body = b'line 1'
    orig = HTTPResponse(BytesIO(body))
    orig.msg = HTTPMessage()
    orig.msg.headers = [b'Header: Value']
    orig.version = 11
    orig.status = 200
    orig.reason = 'OK'
    resp.raw = orig
    resp.raw._original_response = orig

    h_t_t_p_response_0 = HTTPResponse(resp)
    h_t_t_p_response_0.orig = resp

# Generated at 2022-06-25 18:33:07.467923
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass



# Generated at 2022-06-25 18:33:14.296551
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'http://127.0.0.1:5000/'
    str_1 = 'G'
    response_0 = requests.get(str_0, str_1)
    h_t_t_p_response_0 = HTTPResponse(response_0)
    expect_0 = [b'G'] * 5
    result_0 = list(h_t_t_p_response_0.iter_lines(5))
    result_0 = [line[0] for line, _ in result_0 ]
    assert expect_0 == result_0


# Generated at 2022-06-25 18:33:21.581536
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import BytesIO

    response = Mock(headers={'content-type': 'text/plain'})
    response.raw = BytesIO(b'Hello\r\nworld\r\r')

    chunk_size = 1

    lines = list(HTTPResponse(response).iter_lines(chunk_size))

    assert len(lines) == 3
    assert lines[0] == b'Hello\r'
    assert lines[1] == b'\n'
    assert lines[2] == b'world\r'



# Generated at 2022-06-25 18:33:24.914326
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse("Mohammed")
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:36.097738
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    print('Testing HTTPResponse.iter_lines()... ', end='')

    def iter_lines_0(h_t_t_p_message_0, chunk_size_1):
        return iter(h_t_t_p_message_0.iter_lines(chunk_size_1))

    def iter_lines_1(h_t_t_p_message_0, chunk_size_1):
        return h_t_t_p_message_0.iter_lines(chunk_size_1)

    callables = dict()
    callables[iter_lines_0] = 'iter'
    callables[iter_lines_1] = 'iter'

# Generated at 2022-06-25 18:33:45.474067
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    c_h_a_r_s_0 = '`+6~MQDl\r'
    c_h_a_r_s_1 = '`+6~MQDl\r'
    l_n_0 = 5
    l_n_1 = 5
    _list_0 = ['`+6~MQDl\r', '`+6~MQDl\r']
    h_t_t_p_response_0 = HTTPResponse(c_h_a_r_s_0)
    for _list_1 in h_t_t_p_response_0.iter_lines(l_n_0):
        assert (_list_1 == _list_0)

# Generated at 2022-06-25 18:33:56.064875
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ']w`\x0e[\x0e\x0f\x0e\x0f\x0f\x10\x0f\x11\x01\x1d\x1fv\x01'
    str_1 = '\r\n'
    str_2 = '\x02'

# Generated at 2022-06-25 18:34:01.198771
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '1SQ-k\n'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    dump_0 = None
    for dump_0 in h_t_t_p_response_0.iter_lines(5):
        pass



# Generated at 2022-06-25 18:34:06.201118
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = '+6%cMQDl\r'
    h_t_t_p_response_0.iter_lines(str_1)


# Generated at 2022-06-25 18:34:10.949088
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # Set up test fixture
    response_0 = requests.Response()

    h_t_t_p_response_0 = HTTPResponse(response_0)

    # Invoke method
    actual_output = h_t_t_p_response_0.iter_lines()

    # Verify outcome
    assert actual_output == iter([])


# Generated at 2022-06-25 18:35:08.753290
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '<%c!_C42tQXy4z\x00\x16\x07\x0c\r\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1: bytes = '\n\n[D6\x10\x03\x11\x14\x1b\x12\b,\x13\x02'
    str_2: str
    print(h_t_t_p_response_0.iter_lines(str_1, str_2))


# Generated at 2022-06-25 18:35:12.418656
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r_0 = requests.get("http://www.google.com")
    h_t_t_p_response_0 = HTTPResponse(r_0)
    h_t_t_p_response_0.iter_lines(10)


# Generated at 2022-06-25 18:35:17.341469
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_message_0 = HTTPMessage('f1')
    str_0 = '4.4.4'
    h_t_t_p_message_0._orig = str_0
    h_t_t_p_message_1 = HTTPResponse(h_t_t_p_message_0._orig)
    int_0 = 1
    h_t_t_p_message_1.iter_lines(int_0)


# Generated at 2022-06-25 18:35:28.607903
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    http_response_0 = HTTPResponse(requests.get('https://google.com'))
    for h_t_t_p_message_0 in http_response_0.iter_lines(5):
        assert isinstance(h_t_t_p_message_0, tuple), \
            "iter_lines returned {} instead of tuple".format(
                type(h_t_t_p_message_0))
        assert isinstance(h_t_t_p_message_0[0], bytes), \
            "iter_lines returned {} instead of bytes".format(
                type(h_t_t_p_message_0[0]))

# Generated at 2022-06-25 18:35:30.515411
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(str_0)


# Generated at 2022-06-25 18:35:35.579893
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`+6~MQDl\r'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = '`+6~MQDl\r'
    int_2 = 0
    str_3 = '`+6~MQDl\r'
    h_t_t_p_response_0.iter_lines(int_2)



# Generated at 2022-06-25 18:35:37.891610
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with HTTPResponse(None) as h_t_t_p_response_0:
        h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:35:45.687801
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'http://httpbin.org/get?a=b'
    http_response_0 = requests.get(url, auth=HTTPKerberosAuth())
    chunk_size_0 = 24
    http_response_1 = HTTPResponse(http_response_0)
    for line, line_feed in http_response_1.iter_lines(chunk_size_0):
        print(str(str(line), 'utf8'))
    class_instance = HTTPResponse(http_response_0)
    result = class_instance.iter_lines(chunk_size_0)
    assert result is not None
    assert isinstance(result, types.GeneratorType)
    for item in result:
        assert isinstance(item, tuple)
        assert len(item) == 2
        assert isinstance

# Generated at 2022-06-25 18:35:53.478490
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    data = b'abcdef'
    response = requests.Response()
    response._content = data
    http_response_0 = HTTPResponse(response)
    h_t_t_p_response_0 = HTTPResponse(http_response_0)
    for line, line_feed in h_t_t_p_response_0.iter_lines(1):
        assert line == b'a'
    for line, line_feed in h_t_t_p_response_0.iter_lines(2):
        assert line == b'ab'
    for line, line_feed in h_t_t_p_response_0.iter_lines(3):
        assert line == b'abc'