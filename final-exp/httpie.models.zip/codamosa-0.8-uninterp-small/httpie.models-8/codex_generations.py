

# Generated at 2022-06-25 18:26:09.468542
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'fH[jG\t'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:26:16.816052
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():

    # h_t_t_p_request_0 = HTTPRequest(response_0)
    # Test iter_lines(None)
    # http_request_0 = HTTPRequest( response_0 )
    # expected = iter_lines(None)
    # actual = http_request_0.iter_lines(None)
    # assert actual == expected
    
    # Test iter_lines(chunk_size=None)
    # http_request_1 = HTTPRequest( response_0 )
    # expected = iter_lines(20)
    # actual = http_request_1.iter_lines(20)
    # assert actual == expected
    
    # Test iter_lines(chunk_size=1)
    http_request_2 = HTTPRequest( response_0 )
    expected = iter_lines(1)
    actual = http_request

# Generated at 2022-06-25 18:26:27.803511
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = -173
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)
    long_int_0 = 202871488
    bytes_0 = bytearray(long_int_0)
    bytes_0 = bytes_0.replace(ord(' '), ord('/'))
    bytes_1 = bytes_0.replace(ord('\n'), ord('`'))
    bytes_2 = bytes_1.replace(ord('\x00'), ord('@'))
    # Replace all whitespace characters with the slash character.

# Generated at 2022-06-25 18:26:32.572221
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert_equals(list(h_t_t_p_response_0.iter_lines()), [])


# Generated at 2022-06-25 18:26:34.006944
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:26:40.715954
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    with pytest.raises(NotImplementedError):
        str_1 = 'q,`\tx9l'
        h_t_t_p_request_0 = HTTPRequest(str_1)
        h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:26:43.781424
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    HTTPRequest_0 = HTTPRequest(str_0)
    try:
        HTTPRequest_0.iter_body(1)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:26:47.781169
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'q,`\tx9l'
    http_request_0 = HTTPRequest(str_0)
    assert isinstance(http_request_0.iter_lines(), collections.Iterable)
    assert True
    assert isinstance(http_request_0.iter_lines(''), collections.Iterable)
    assert True

# Generated at 2022-06-25 18:26:58.422313
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    class_ = HTTPResponse

    def str_0():
        return 'q,`\tx9l'

    def test_body():
        return b'[{{}}]'

    def test_chunk_size():
        return 1

    def msg_0():
        return email.message.Message()

    def req_0():
        return urllib.request.Request(msg_0())

    def resp_0():
        return urllib.request.urlopen(req_0())

    def h_t_t_p_response_0():
        return HTTPResponse(str_0())

    def h_t_t_p_response_1():
        return HTTPResponse(resp_0())


# Generated at 2022-06-25 18:27:02.380423
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    
    http_request = HTTPRequest('foo')
    
    result = http_request.iter_body()
    assert result == 'foo'



# Generated at 2022-06-25 18:27:17.248919
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'q,`\tx9l'
    http_request_0 = HTTPRequest(str_0)
    chunk_size_0 = -1
    http_message_0 = HTTPMessage(str_0)
    iterable_0 = http_request_0.iter_lines(chunk_size_0)
    chunk_size_1 = -1
    iterable_1 = http_message_0.iter_lines(chunk_size_1)


# Generated at 2022-06-25 18:27:22.636807
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert re.findall('\r\n', h_t_t_p_response_0.headers, re.DOTALL) is not None


# Generated at 2022-06-25 18:27:26.821454
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = 2
    h_t_t_p_response_0 = None
    assert_equal(h_t_t_p_response_0.iter_lines(int_0), list(map(bytes.fromhex, [])))


# Generated at 2022-06-25 18:27:30.594386
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_request_1 = HTTPRequest(str_0)
    str_1 = 'i'
    h_t_t_p_request_1.iter_lines(str_1)

# Generated at 2022-06-25 18:27:39.604471
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    class_type_0 = 'HTTPRequest'
    method_type_0 = 'iter_body'
    # list_0 = ['q,`\tx9l']
    list_0 = []
    list_0.append('q,`\tx9l')
    # Arrange
    # Act
    result = getattr(h_t_t_p_response_0, method_type_0)()
    # Assert
    assert list_0 == list(result)


# Generated at 2022-06-25 18:27:47.783682
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Method to test: iter_lines()

    # Test variables:
    str_0 = 'l\r9'
    int_0 = 2
    float_0 = float(1.19)
    str_1 = 'Q\tw'
    dict_0 = {}

    # Test method: iter_lines()
    h_t_t_p_request_0 = HTTPRequest(str_0)
    # Line: x.iter_lines(chunk_size)
    #       x.iter_lines(chunk_size)
    h_t_t_p_request_0.iter_lines(int_0)
    h_t_t_p_request_0.iter_lines(float_0)
    # Line: x.iter_lines()
    #       x.iter_lines()
    h_t_t

# Generated at 2022-06-25 18:27:52.925698
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(1) is not None
    assert True


# Generated at 2022-06-25 18:27:55.787155
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'u+7'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:28:01.718550
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_1 = HTTPRequest(None)  # Type ignored
    h_t_t_p_request_1_iter_lines = h_t_t_p_request_1.iter_lines(None)  # Type ignored
    h_t_t_p_request_1_iter_lines_next = next(h_t_t_p_request_1_iter_lines)  # Type ignored
    str_1 = '@FKy}b'
    assert h_t_t_p_request_1_iter_lines_next == str_1


# Generated at 2022-06-25 18:28:05.850601
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '`T\t6dw'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(chunk_size=1308)



# Generated at 2022-06-25 18:28:17.313617
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    http_request_0 = HTTPRequest(str_0)
    str_1 = '_0XV7~u\\r\r'
    http_request_0.iter_body(str_1)


# Generated at 2022-06-25 18:28:29.103156
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '?X~\x00[@N\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 18:28:31.771495
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_body()

# Generated at 2022-06-25 18:28:34.558866
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    http_request_0 = HTTPRequest(str_0)

    assert http_request_0.iter_body() == http_request_0.iter_body()


# Generated at 2022-06-25 18:28:41.617526
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    string_0 = ':0'
    http_request_0 = HTTPRequest(string_0)
    string_1 = ':0'
    http_request_1 = HTTPRequest(string_1)
    string_2 = ':0'
    http_request_2 = HTTPRequest(string_2)
    string_3 = ':0'
    http_request_3 = HTTPRequest(string_3)
    string_4 = ':0'
    http_request_4 = HTTPRequest(string_4)
    string_5 = ':0'
    http_request_5 = HTTPRequest(string_5)
    string_6 = ':0'
    http_request_6 = HTTPRequest(string_6)
    string_7 = ':0'
    http_request_7 = HTTPRequest(string_7)

# Generated at 2022-06-25 18:28:45.962338
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert len(str_0) > 0
    assert len(str_0) > 0
    assert len(str_0) > 0


# Generated at 2022-06-25 18:28:48.872585
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)

    h_t_t_p_response_0.get_body(0)


# Generated at 2022-06-25 18:28:56.124934
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'l|\x14\x1an\x1e\x18\x1a\x1f'
    h_t_t_p_response_0 = HTTPResponse(str_0)

    int_0 = 5
    list_0 = []
    for element in h_t_t_p_response_0.iter_body(int_0):
        list_0.append(element)
    if len(list_0) > 0:
        assert  (isinstance(list_0, list))




# Generated at 2022-06-25 18:29:05.023901
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # FIXME: Use a fixture (e.g., `requests_mock`) to replace `requests.get()`.
    response = requests.get('https://httpbin.org/get?foo=bar')
    http_message = HTTPResponse(response)
    body = b''.join(http_message.iter_body(1))

# Generated at 2022-06-25 18:29:16.047726
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(1)

    str_1 = 'q,`\tx9l'
    h_t_t_p_response_1 = HTTPResponse(str_1)
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_1.iter_lines(1)

    str_2 = 'q,`\tx9l'
    h_t_t_p_response_2 = HTTPResponse(str_2)

# Generated at 2022-06-25 18:29:32.119403
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # assert cmp(HTTPRequest.iter_body(), NotImplemented) == 0
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:29:36.868559
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
  #
  # Test case 0
  str_0 = 'q,`\tx9l'
  http_request_0 = HTTPRequest(str_0)
  body_iter_0 = iter(http_request_0.iter_body())
  assert next(body_iter_0) == b''


# Generated at 2022-06-25 18:29:41.182295
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:50.433807
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    chunk_size_0 = 16130
    h_t_t_p_response_1 = HTTPResponse(str_0)
    chunk_size_1 = 17059
    h_t_t_p_response_2 = HTTPResponse(str_0)
    chunk_size_2 = 14392

    #   def iter_lines(self, chunk_size=1):
    #       return ((line, b'\n') for line in self._orig.iter_lines(chunk_size))


# Generated at 2022-06-25 18:29:55.068305
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '$!\x00\x01\x00'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = -10
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)

# Generated at 2022-06-25 18:29:56.099803
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()

# Generated at 2022-06-25 18:29:57.105209
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert True


# Generated at 2022-06-25 18:30:00.761437
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'q,`\tx9l'
    http_request_0 = HTTPRequest(str_0)
    assert list(http_request_0.iter_body(1)) == [b'q,`\tx9l']


# Generated at 2022-06-25 18:30:02.738835
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse('')
    h_t_t_p_response_0.iter_lines(10)

# Generated at 2022-06-25 18:30:05.786808
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Simple test
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    for iter_body in h_t_t_p_response_0.iter_body():
        # iter_body: List[int]
        break


# Generated at 2022-06-25 18:30:26.999558
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    str_1 = '  +:{wJS]1L\x00\x10\x00\x00'
    str_2 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(17)
    h_t_t_p_response_0.iter_lines(str_1)
    h_t_t_p_response_0.iter_lines(str_2)


# Generated at 2022-06-25 18:30:34.340883
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
   params_0 = '\x8c\xe4;1\xeb\x84\x7f\x8a'

# Generated at 2022-06-25 18:30:38.419669
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(str_0)


# Generated at 2022-06-25 18:30:42.331190
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:30:45.349929
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:30:53.351197
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    httpprincipal_0 = int_0 = 0
    assert len(list(h_t_t_p_response_0.iter_lines(int_0))) == 0
    int_0 = 0
    str_0 = 'p+fj'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    httpprincipal_0 = int_0 = 0
    assert len(list(h_t_t_p_response_0.iter_lines(int_0))) == 0
    str_1 = 'http.response'
    h_t_t_p_response_0 = HTTPResponse

# Generated at 2022-06-25 18:31:04.950573
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:31:09.787379
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    i_t_e_r_0 = h_t_t_p_response_0.iter_lines(chunk_size = 1)


# Generated at 2022-06-25 18:31:19.214060
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from typing import Any
    import requests
    headers = {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Encoding': 'gzip',
    }
    body = b"This is a test\nLine 2\nLine 3\n\nLine 5"
    response = requests.Response()
    response.url = "https://www.example.com"
    response.headers = headers
    response.raw = response.content = body


# Generated at 2022-06-25 18:31:27.060294
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = "abcdefghijklmnopqrstuvwxyz"
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = "abcdefghijklmnopqrstuvwxyz"
    h_t_t_p_response_1 = HTTPResponse(str_1)
    
    chunk_size = 10
    assert list(h_t_t_p_response_1.iter_lines(chunk_size)) == list(h_t_t_p_response_0.iter_lines(chunk_size))


# Generated at 2022-06-25 18:31:55.556042
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bytes_0 = b'\x00\xff\x89\xb7\x1f\x00\xff\xec\xff\x0b\xc3\xfb\xdd'
    h_t_t_p_response_0 = HTTPResponse(bytes_0)


# Generated at 2022-06-25 18:32:07.545539
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Set up test data
    method_under_test_name = 'iter_lines'
    arg_0 = None
    arg_1 = None

    arg_2 = None

    # Perform the test
    try:
        test_object = HTTPResponse(arg_0)
    except Exception:
        print(f'exception encountered while setting up the test for '
              f'HTTPResponse.{method_under_test_name}')
        raise

    try:
        result = getattr(test_object, method_under_test_name)(arg_1, arg_2)
    except Exception:
        print(f'exception encountered while testing '
              f'HTTPResponse.{method_under_test_name}')
        raise

    # Return the result.
    result


# Generated at 2022-06-25 18:32:12.231618
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)

# Generated at 2022-06-25 18:32:13.171074
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # TODO: test actual behaviour
    return True


# Generated at 2022-06-25 18:32:19.801290
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    http_response_0 = HTTPResponse(str_0)
    try:
        http_response_0.iter_lines()
        raise AssertionError()
    except TypeError:
        pass

    try:
        http_response_0.iter_lines(5)
        raise AssertionError()
    except RuntimeError:
        pass

    try:
        http_response_0.iter_lines(1)
        raise AssertionError()
    except RuntimeError:
        pass


# Generated at 2022-06-25 18:32:22.288798
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = test_case_0()
    h_t_t_p_response_0.iter_lines(chunk_size=8)


# Generated at 2022-06-25 18:32:25.954716
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_message_0 = h_t_t_p_response_0
    # Test if a TypeError is raised
    with pytest.raises(TypeError):
        h_t_t_p_message_0.iter_lines(None)


# Generated at 2022-06-25 18:32:30.328248
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    for _ in range(1000):
        h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:33.850440
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:39.124667
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'biN\x04\x12\x1d,p[\x1a'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert len(list(h_t_t_p_response_0.iter_lines(1))) == 0


# Generated at 2022-06-25 18:33:29.875183
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(128)


# Generated at 2022-06-25 18:33:33.808654
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '~5F5IT'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    # Don't need to assert anything
    h_t_t_p_response_0.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:33:38.747742
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with patch('requests.models.Response', spec=True):
        str_0 = 'q,`\tx9l'
        h_t_t_p_response_0 = HTTPResponse(str_0)
        h_t_t_p_response_0.iter_lines(chunk_size=16)


# Generated at 2022-06-25 18:33:44.790838
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    val_0 = HTTPResponse(str_0)
    res_0 = None
    try:
        res_0 = list(val_0.iter_lines(32))
    except Exception as exc_0:
        print('Error: %s' % repr(exc_0))
    assert res_0 == None


# Generated at 2022-06-25 18:33:55.567074
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    response_0 = generate_response()

    stream_0 = test_HTTPResponse_iter_lines_get_stream(response_0)

    assert isinstance(stream_0, io.BytesIO)

    stream_0.seek(0)
    chunk = stream_0.read()

    h_t_t_p_response_0 = HTTPResponse(response_0)

    iter_0 = h_t_t_p_response_0.iter_lines(len(chunk) + 1)
    assert isinstance(iter_0, types.GeneratorType)

    for line, line_feed in iter_0:
        assert isinstance(line, bytes)
        assert isinstance(line_feed, bytes)
        assert len(line_feed) == 1
        assert line_feed == b'\n'



# Generated at 2022-06-25 18:33:57.363883
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:34:01.654204
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines() == ((),)


# Generated at 2022-06-25 18:34:11.949781
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    chunk_size_0 = 1
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(chunk_size_0)
    chunk_size_1 = 1
    str_1 = 'M5JfAG'
    h_t_t_p_response_1 = HTTPResponse(str_1)
    h_t_t_p_response_1.iter_lines(chunk_size_1)
    chunk_size_2 = 1
    str_2 = 'W`[D;i4'
    h_t_t_p_response_2 = HTTPResponse(str_2)
    h_t_t_

# Generated at 2022-06-25 18:34:12.782155
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert True



# Generated at 2022-06-25 18:34:16.476085
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'q,`\tx9l'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(chunk_size=1)
