

# Generated at 2022-06-25 18:26:07.893376
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_1 = None
    h_t_t_p_request_0 = HTTPRequest(int_1)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:26:12.833410
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'eI63J1&Y#?'
    str_1 = '9dzC'
    int_0 = None
    HTTPRequest_0 = HTTPRequest(int_0)
    HTTPRequest_0.iter_lines(str_0 + str_1)


# Generated at 2022-06-25 18:26:14.361331
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with pytest.raises(NotImplementedError):
        HTTPResponse('').iter_lines(None)


# Generated at 2022-06-25 18:26:21.097063
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_1 = None
    http_request_0 = HTTPRequest(int_1)
    int_2 = None
    for http_message_0 in http_request_0.iter_body(int_2):
        print(http_message_0)


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-25 18:26:27.887934
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_0 = None
    h_t_t_p_request_0 = HTTPRequest(int_0)
    int_1 = 1
    expect = None
    actual = h_t_t_p_request_0.iter_body(int_1)
    assert expect == actual
    int_2 = 2
    expect = None
    actual = h_t_t_p_request_0.iter_body(int_2)
    assert expect == actual
    int_3 = 3
    expect = None
    actual = h_t_t_p_request_0.iter_body(int_3)
    assert expect == actual


# Generated at 2022-06-25 18:26:32.953137
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(None)
    it = req.iter_lines(0)
    x = next(it)
    assert(x == (b'', b''))
    assert(len(x) == 2)
    try:
        next(it)
        assert(False)
    except StopIteration:
        assert(True)


# Generated at 2022-06-25 18:26:38.391515
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    class_0 = HTTPResponse
    kwargs_0 = {'chunk_size': 42}

    # Iterator case
    h_t_t_p_response_0 = class_0(None)
    try:
        class_0.iter_lines(h_t_t_p_response_0, **kwargs_0)
    except NotImplementedError:
        pass

    # Iterator case
    h_t_t_p_response_0 = class_0(None)
    try:
        class_0.iter_lines(h_t_t_p_response_0, **kwargs_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:26:42.281677
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_message_0 = HTTPMessage(int_0)
    chunk_size_0 = 1
    h_t_t_p_message_0.iter_lines(chunk_size_0)



# Generated at 2022-06-25 18:26:46.874917
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Test request
    int_0 = None
    h_t_t_p_message_0 = HTTPRequest(int_0)
    int_1 = None
    iterator = h_t_t_p_message_0.iter_lines(int_1)
    # Will raise StopIteration if loop reaches end
    iterator.__next__()


# Generated at 2022-06-25 18:26:48.754364
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    url = "http://www.yahoo.com"
    response = requests.get(url)
    HTTPResponse(response).iter_lines(5)


# Generated at 2022-06-25 18:27:04.436494
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    int_1 = 1
    h_t_t_p_response_0 = HTTPResponse(int_0)
    assert_equal(h_t_t_p_response_0.iter_lines(int_1), h_t_t_p_response_0.iter_lines(int_1))


# Generated at 2022-06-25 18:27:11.505771
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_0 = None
    h_t_t_p_request_0 = HTTPRequest(int_0)
    int_0 = 0
    actual = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:27:15.414858
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r = requests.get('https://httpbin.org/stream/5')
    h_t_t_p_response_0 = HTTPResponse(r)
    chunk_size_0 = None
    assert isinstance(h_t_t_p_response_0.iter_lines(chunk_size_0), Iterable)


# Generated at 2022-06-25 18:27:18.222116
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_0 = None
    h_t_t_p_request_0 = HTTPRequest(int_0)
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:27:24.701975
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_0 = None
    test_http_request_0 = HTTPRequest(int_0)
    int_0 = 1
    test_iter_0 = test_http_request_0.iter_body(int_0)
    int_0 = 1
    test_list_0 = list(test_iter_0)
    test_list_1 = test_list_0


# Generated at 2022-06-25 18:27:29.652846
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'http://pybee.org/'
    res_0 = requests.get(url)
    h_t_t_p_response_0 = HTTPResponse(res_0)
    int_0 = 1
    result = h_t_t_p_response_0.iter_lines(int_0)
    assert type(result) == Iterable

# Generated at 2022-06-25 18:27:33.083426
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    int_0 = None
    h_t_t_p_message_0 = HTTPRequest(int_0)
    # should not raise any exception
    len(list(h_t_t_p_message_0.iter_body(1)))


# Generated at 2022-06-25 18:27:37.638806
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    def expected_0():
        assert False

    with expected_0:
        body_0, chunk_size_0 = None, None
        http_request_0 = HTTPRequest(body_0)
        http_request_0.iter_body(chunk_size_0)


# Generated at 2022-06-25 18:27:44.298907
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    import io

    response = requests.Response()
    response.encoding = None
    response.headers = {
        'Content-Type': 'text/plain',
        'Content-Length': '10'
    }
    response.raw = io.BytesIO(b'foo\nbar\r\nbazz\r\rquux\r\r\n')
    response.request = requests.Request()

    for line, lf in HTTPResponse(response).iter_lines():
        print(line)


# Generated at 2022-06-25 18:27:46.160444
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert True


# Generated at 2022-06-25 18:27:58.932741
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = utils.MockResponse(400, b'line1\nline2')
    h_t_t_p_response_0 = HTTPResponse(int_0)
    var_0 = [e for e in h_t_t_p_response_0.iter_lines(0)]
    utils.assertEqual('line1\n', var_0[0])
    utils.assertEqual('line2', var_0[1])


# Generated at 2022-06-25 18:28:04.255746
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    int_0 = 0
    # TypeError: iter_lines() takes 1 positional argument but 2 were given
    # h_t_t_p_response_0.iter_lines(int_0, int_0)


# Generated at 2022-06-25 18:28:10.611911
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    unit_test_request = "http://www.google.com"
    unit_test_response = requests.get(unit_test_request)
    h_t_t_p_response_0 = HTTPResponse(unit_test_response)
    assert hasattr(h_t_t_p_response_0, 'iter_lines')
    assert callable(h_t_t_p_response_0.iter_lines)
    assert isinstance(h_t_t_p_response_0.iter_lines(None), Iterable)


# Generated at 2022-06-25 18:28:13.305939
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    assert isinstance(h_t_t_p_response_0.iter_lines(), Iterable) is True


# Generated at 2022-06-25 18:28:15.003599
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_request_0 = HTTPRequest(int_0)
    assert h_t_t_p_request_0.iter_lines(12)


# Generated at 2022-06-25 18:28:20.223231
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response = requests.get("https://example.com")
    assert isinstance(response, requests.models.Response)
    h_t_t_p_response_0 = HTTPResponse(response)
    i_t_e_r_0 = h_t_t_p_response_0.iter_lines(None)
    assert isinstance(i_t_e_r_0, Iterable)


# Generated at 2022-06-25 18:28:26.046009
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_1 = 3
    h_t_t_p_response_0.iter_lines(int_1)


# Generated at 2022-06-25 18:28:29.710993
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = None
    list_0 = list(h_t_t_p_response_0.iter_lines(int_0))


# Generated at 2022-06-25 18:28:34.318952
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = 1
    int_1 = 1
    list_0 = list(h_t_t_p_response_0.iter_lines(chunk_size=int_0))
    list_1 = [(b'', b'\n')]
    assert list_0 == list_1


# Generated at 2022-06-25 18:28:38.819878
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # This test only checks if the function doesn't crash.
    # It's not possible to check if the iterator is working correctly.
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_iter_lines_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:28:53.862018
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert True


# Generated at 2022-06-25 18:28:58.524305
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    for _ in h_t_t_p_response_0.iter_lines(int_0):
        pass


# Generated at 2022-06-25 18:29:01.928996
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    value = 1
    response = requests.get('https://httpbin.org/status/418')
    assert isinstance(response, requests.models.Response)

    response_h_t_t_p_message = HTTPResponse(response)
    assert isinstance(response_h_t_t_p_message, HTTPMessage)

    # test
    lines = list(response_h_t_t_p_message.iter_lines(value))
    assert type(lines) == list


# Generated at 2022-06-25 18:29:05.661129
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:29:12.911512
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    body_0 = b''
    iter_content_0 = [body_0]
    resp_0 = requests.models.Response(Body=iter_content_0)
    orig_0 = HTTPResponse(resp_0)
    h_t_t_p_response_0 = HTTPResponse(orig_0)
    h_t_t_p_response_0.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:29:16.086284
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    result = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:29:18.612291
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = 1
    for _ in h_t_t_p_response_0.iter_lines(int_0):
        pass


# Generated at 2022-06-25 18:29:25.909754
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    r_e_s_u_l_t_0 = h_t_t_p_response_0.iter_lines(int_0)
    assert r_e_s_u_l_t_0 is not None


# Generated at 2022-06-25 18:29:30.156500
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_r_0 = HTTPResponse(int_0)
    with open('raw_response.txt','r') as f:
        response =f.read().encode()
    

    l = list(h_t_t_r_0.iter_lines(response))
    print(l)


# Generated at 2022-06-25 18:29:31.241978
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert False


# Generated at 2022-06-25 18:30:01.317363
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_1 = 0
    iter_0 = h_t_t_p_response_0.iter_lines(int_1)
    assert iter_0 == None


# Generated at 2022-06-25 18:30:03.845079
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_message_0 = HTTPMessage(None)
    int_0 = None
    int_0 = h_t_t_p_message_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:10.234194
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # Test the iter_lines method with multiple data points.

    # First we create a few objects of the HTTPResponse class.
    HTTPResponse_objects = [
        HTTPResponse(
            'Original message 1.'
        ),
        HTTPResponse(
            'Original message 2.'
        ),
        HTTPResponse(
            'Original message 3.'
        )
    ]

    # Then we generate a few expected outputs for the method given these inputs.
    expected_outputs = [
        (
            'Original message 1.',
            '\n'
        ),
        (
            'Original message 2.',
            '\n'
        ),
        (
            'Original message 3.',
            '\n'
        )
    ]


# Generated at 2022-06-25 18:30:13.225241
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Set up fixture
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    # Return value of iter_lines
    iter_lines_rv = None
    iter_lines_rv = h_t_t_p_response_0.iter_lines(iter_lines_rv)


# Generated at 2022-06-25 18:30:16.198479
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test method with different return types

    # Test method with different argument types
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:30:23.135786
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests

    url_0 = 'http://httpbin.org/get'
    r_0 = requests.get(url_0)
    h_t_t_p_message_0 = HTTPResponse(r_0)
    chunk_size_0 = None
    r_0 = h_t_t_p_message_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:30:33.521812
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'input'
    path_0 = 'input'
    int_0 = 5
    dict_0 = dict(**{})
    int_1 = 2
    int_3 = 1
    int_4 = 0
    list_0 = [int_0, int_1, int_3, int_4]
    int_6 = 3
    float_0 = float(str_0)
    float_1 = float(str_0)
    float_2 = float(str_0)
    float_3 = float(str_0)
    float_4 = float(str_0)
    float_5 = float(str_0)
    float_6 = float(str_0)
    float_7 = float(str_0)
    float_8 = float(str_0)
    float_9

# Generated at 2022-06-25 18:30:38.181168
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = 1
    h_t_t_p_response_iter_lines_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:47.671380
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = "X"

# Generated at 2022-06-25 18:30:52.229616
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    str_0 = h_t_t_p_response_0.iter_lines(1)
    str_1 = next(str_0)
    int_0 = isinstance(str_1, tuple)
    str_2 = next(str_0)
    int_1 = isinstance(str_2, tuple)


# Generated at 2022-06-25 18:31:49.248954
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    http_response_0 = HTTPResponse(None)
    http_response_0.iter_lines(1)
    return 'unit_test_success'


# Generated at 2022-06-25 18:31:51.968000
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Builtin type, no test
    pass


# Generated at 2022-06-25 18:31:56.636892
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test-case 0
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    chunk_size_0 = 1
    h_t_t_p_response_0.iter_lines(chunk_size_0) # Expected: [(b'', b'\n')]


# Generated at 2022-06-25 18:32:08.842285
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # IMPORTS
    import requests

    # SETUP
    url = 'http://httpbin.org/'
    request = requests.get
    r = request(url=url + 'get')
    h_t_t_p_response_0 = HTTPResponse(r)
    next_0 = next

    # TEST
    lines = list(h_t_t_p_response_0.iter_lines(1))
    assert lines[0] == b'{'
    assert lines[-2] == b'  "headers": {'
    assert next_0(h_t_t_p_response_0.iter_lines(1)) == b'    '
    assert next_0(h_t_t_p_response_0.iter_lines(1)) == b'    '

# Generated at 2022-06-25 18:32:15.222142
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_1 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_2 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_3 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_4 = HTTPResponse(int_0)
    int_0 = None
    h_t_t_p_response_5 = HTTPResponse(int_0)
    int_0 = None
    h_t_t

# Generated at 2022-06-25 18:32:20.382047
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_message_1 = HTTPMessage(None)
    def get_chunk_size():
        return 1000
    assert h_t_t_p_message_1.iter_lines(get_chunk_size())
    assert h_t_t_p_message_1.iter_lines(1000)
    assert h_t_t_p_message_1.iter_lines(1)


# Generated at 2022-06-25 18:32:24.196012
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    http_response_0 = HTTPResponse(int_0)
    # Execute the code to be tested
    iter_lines_0 = http_response_0.iter_lines(1)
    # Check the state of the object after the test
    assert_not_isinstance(iter_lines_0, Iterable)


# Generated at 2022-06-25 18:32:27.990393
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test arguments
    h_t_t_p_response_0 = None
    int_0 = None
    # Method to test
    h_t_t_p_response_0.iter_lines(chunk_size = int_0)


# Generated at 2022-06-25 18:32:31.733475
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    int_0 = None
    _list_0 = list(h_t_t_p_response_0.iter_lines(int_0))


# Generated at 2022-06-25 18:32:33.581166
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)


# Generated at 2022-06-25 18:34:30.750178
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # type: () -> None
    """Test method iter_lines of class HTTPResponse"""
    int_0 = None
    h_t_t_p_message_0 = HTTPResponse(int_0)
    list_0 = list()
    for _ in range(10):
        list_0.append(_)
    for _ in list_0:
        str_0 = str(_)


# Generated at 2022-06-25 18:34:34.933919
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    h_t_t_p_message_0 = HTTPMessage(int_0)
    assertNotEquals(h_t_t_p_response_0.iter_lines(1), h_t_t_p_message_0.iter_lines(1))

# Generated at 2022-06-25 18:34:38.672770
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_1 = None
    assert_raises(NotImplementedError, h_t_t_p_response_0.iter_lines, int_1)


# Generated at 2022-06-25 18:34:45.164542
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    response_0 = None
    h_t_t_p_response_1 = HTTPResponse(response_0)
    response_1 = None
    h_t_t_p_response_2 = HTTPResponse(response_1)
    response_2 = None
    h_t_t_p_response_3 = HTTPResponse(response_2)
    response_3 = None
    h_t_t_p_response_4 = HTTPResponse(response_3)
    response_4 = None
    h_t_t_p_response_5 = HTTPResponse(response_4)
    response_5 = None
    h_t_t

# Generated at 2022-06-25 18:34:48.603508
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """
    # Set up
    int_0 = None
    h_t_t_p_response_0 = HTTPResponse(int_0)
    int_0 = None
    chunks_0 = h_t_t_p_response_0.iter_lines(int_0)
    """
    pass


# Generated at 2022-06-25 18:34:57.219399
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_arg_0 = "a"
    str_arg_1 = "a"
    str_arg_2 = "a"
    str_arg_3 = "a"
    str_arg_4 = "a"
    str_arg_5 = "a"
    str_arg_6 = "a"
    str_arg_7 = "a"
    str_arg_8 = "a"
    str_arg_9 = "a"
    int_arg_0 = 0
    float_arg_0 = 0.0
    dict_arg_0 = {}
    dict_arg_1 = {}
    list_arg_0 = []
    list_arg_1 = []
    bool_arg_0 = False
    obj_arg_0 = HTTPResponse()
    int_0 = None
    int_

# Generated at 2022-06-25 18:35:05.462042
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    int_0 = None
    http_response_0 = HTTPResponse(int_0)
    exception = None

# Generated at 2022-06-25 18:35:07.612197
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response = requests.get('https://www.google.com')
    h_t_t_p_response_0 = HTTPResponse(response)
    res = h_t_t_p_response_0.iter_lines(1)
    assert res is not None


# Generated at 2022-06-25 18:35:16.417150
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from mod_pbxproj import xcrun
    from codecs import decode
    from itertools import chain
    from requests.models import Response
    from _bisect import bisect_left
    from io import StringIO
    from copy import copy
    from urllib.parse import quote
    from pkg_resources import iter_entry_points
    from collections import OrderedDict
    from _collections import deque
    from _weakrefset import WeakSet
    from json.decoder import JSONDecodeError
    from functools import reduce
    from json.encoder import JSONEncoder
    from json.decoder import JSONDecoder
    from sys import maxsize as maxint
    from json.encoder import INFINITY
    from json.encoder import NaN
    from json.encoder import encode_basestring_asci

# Generated at 2022-06-25 18:35:22.680196
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    status = 200
    int_0 = None
    response_0 = requests.Response()
    response_0.status_code = status
    h_t_t_p_response_0 = HTTPResponse(response_0)
    int_0 = 1
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)
    line_0, line_feed_0 = next(iter_0)
