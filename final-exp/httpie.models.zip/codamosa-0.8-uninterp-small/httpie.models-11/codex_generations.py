

# Generated at 2022-06-25 18:26:09.773918
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    class HTTPRequest_Mock(HTTPRequest):
        def __init__(self):
            self.orig = None
        def iter_lines_(self, chunk_size):
            pass

    HTTPRequest_object_0 = HTTPRequest_Mock()

    HTTPRequest_object_0.iter_lines_ = HTTPRequest_object_0.iter_lines
    HTTPRequest_object_0.iter_lines_(1)


# Generated at 2022-06-25 18:26:16.980917
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Creating an instance of Request class with URL, method and headers.
    test_request = Request('http://www.google.com', 'GET', None, None, None)
    # Creating an instance of HTTPRequest class
    test_HTTPRequest = HTTPRequest(test_request)
    # Creating an instance of HTTPResponse class
    test_HTTPResponse = HTTPResponse(test_request)
    # Beginning of unit test
    # Asserting that both the objects are iterables
    assert_true(isinstance(test_HTTPRequest.iter_lines(), Iterable))
    assert_true(isinstance(test_HTTPResponse.iter_lines(), Iterable))
    # Asserting that both the objects do not yield lines

# Generated at 2022-06-25 18:26:24.194841
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    # Iterator should be raised
    try: next(iter(h_t_t_p_response_0.iter_lines(1)))
    except Exception as exp:
        assert isinstance(exp, NotImplementedError)



# Generated at 2022-06-25 18:26:28.499403
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:26:35.180714
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b"hello world"
    method = "GET"
    url = "http://example.com"
    request = requests.Request(method=method, url=url)
    prepared_request = request.prepare()
    prepared_request.body = body
    http_request = HTTPRequest(prepared_request)
    result = http_request.iter_body(1)
    expected = [body]

    assert result == expected


# Generated at 2022-06-25 18:26:40.476593
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    test_value_3 = sys.maxsize
    h_t_t_p_request_0.iter_body(test_value_3)


# Generated at 2022-06-25 18:26:42.193470
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Test iter_lines method of HTTPResponse class."""
    test_case_0()


# Generated at 2022-06-25 18:26:45.548872
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    h_t_t_p_request_0.iter_lines(0)

# Generated at 2022-06-25 18:26:47.587364
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_request_0 = HTTPRequest(False)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:26:58.246436
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    i_0 = iter(h_t_t_p_response_0.iter_body())
    # print(repr(i_0))
    for e_i_0 in i_0:
        pass
        # print(e_i_0)
        # print(repr(e_i_0))
    # print('\n')
    i_0 = iter(h_t_t_p_response_0.iter_body(65536))
    # print(repr(i_0))
    for e_i_0 in i_0:
        pass
        # print(e_i_0)
        # print(repr(e_i_0))
    # print

# Generated at 2022-06-25 18:27:17.242325
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    HTTPRequest_0 = HTTPRequest(orig='foo')
    http_response_0 = HTTPResponse(orig='foo')
    HTTPRequest_0.headers = {}
    HTTPRequest_0.body = 'Test iter_lines method of HTTPRequest class.'
    HTTPRequest_0._orig = http_response_0
    HTTPRequest_0._orig.headers = {}
    HTTPRequest_0._orig.body = 'Test iter_lines method of HTTPRequest class.'
    HTTPRequest_0._orig.iter_content = lambda chunk_size: [HTTPRequest_0._orig.body]
    HTTPRequest_0._orig.iter_lines = lambda chunk_size: [HTTPRequest_0._orig.body]
    for data_0 in HTTPRequest_0.iter_lines(chunk_size=1):
        pass


# Generated at 2022-06-25 18:27:20.139550
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request_0 = HTTPRequest()
    request_1 = HTTPRequest(str_0)
    iter(request_0)
    iter(request_1)


# Generated at 2022-06-25 18:27:31.158412
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    resp = requests.get('https://httpbin.org/image/png')
    req = resp.request
    req = HTTPRequest(req)
    line_list = []
    for line in req.iter_body(5):
        line_list.append(line)
    

# Generated at 2022-06-25 18:27:42.468600
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'Test iter_lines method of HTTPResponse class.'
    resp = requests.Response()
    resp._content = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<html>\r\nfoo\r\nbar\r\n</html>'.encode('utf8')
    response = HTTPResponse(resp)
    result = True
    try:
        result = True
        for body, line_feed in response.iter_lines(chunk_size = 1):
            print(body, line_feed)
    except Exception as e:
        result = False
        print(e)

    if not result:
        print('FAIL')
        print('Expected: ' + str_0)

# Generated at 2022-06-25 18:27:44.921546
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Create a new HTTPRequest object.
    str_0 = 'Test iter_lines method of HTTPRequest class.'
    http_request_0 = HTTPRequest(str_0)
    # Iterate over the lines in the body of the given HTTPRequest object.
    http_request_0.iter_lines(1)


# Generated at 2022-06-25 18:27:55.876283
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    req_0 = HTTPResponse(
        b'{"type": "op", "id": 1, "method": "get_account", "params": [{"account": "1.2.106"}]}'
    )

    list_0 = []

    str_0 = '{"type": "op", "id": 1, "method": "get_account", "params": [{"account": "1.2.106"}]}'
    list_1 = [
        '{"type": "op", "id": 1, "method": "get_account", "params": [{"account": "1.2.106"}]}'
    ]
    for i in req_0.iter_lines(1):
        list_0.append(i)

    assert list_0 == list_1

# Generated at 2022-06-25 18:28:06.881877
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request = HTTPRequest(None)
    result = request.iter_lines(1)

# Generated at 2022-06-25 18:28:12.540169
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str = 'Test iter_lines method of class HTTPRequest.'
    request = HTTPRequest(str)
    iterator = request.iter_lines(512)
    for i in iterator:
        print("i: ", i)
        print("len(i): ", len(i))


# Generated at 2022-06-25 18:28:17.518692
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    res = HTTPRequest()
    body = "abcd\nefgh\nijkl"
    body_bytes = body.encode('utf8')
    req = requests.Request('PUT', 'http://example.com/', data=body)
    req = req.prepare()
    res._orig = req
    lines_gen = res.iter_lines(chunk_size=1)
    lines = [i for i in lines_gen]
    assert lines[0][0] == body_bytes, 'Test case failed: Expected body bytes, actual body bytes'
    assert lines[0][1] == bytes("", 'utf8'), 'Test case failed: Expected line feed bytes, actual line feed bytes'


# Generated at 2022-06-25 18:28:19.760504
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    payload = 'Hello, world'

    request = HTTPRequest(request_0)
    response = HTTPRequest(requests.get(request.url))

    assert list(response.iter_body(chunk_size=1)) == [payload]


# Generated at 2022-06-25 18:28:42.310238
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    try:
        url = 'http://httpbin.org/get'

        # Make a GET request
        r = requests.get(url)
        req = HTTPRequest(r)

        for line in req.iter_lines(1024):
            print (line)

    except Exception as e:
        print ('Exception: ' + str(e))


# Generated at 2022-06-25 18:28:44.355763
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert len(list(HTTPResponse(HTTPRequest(None)).iter_body(None))) == 1


# Generated at 2022-06-25 18:28:48.387981
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Test case 0
    str_0 = 'Test iter_body method of HTTPRequest class.'
    assert(str_0=='Test iter_body method of HTTPRequest class.')


# Generated at 2022-06-25 18:28:56.190696
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'https://httpbin.org/get'
    response = requests.get(url)
    res = HTTPResponse(response)
    #print('\n'+ repr(list(res.iter_lines(1000)) ) )
    for i in res.iter_lines(1000):
        for j in (i[0], i[1]):
                # a single line from the reponse is returned
                # as a single byte string, and each line is ended
                # by the line feed character.
                #print('\n'+repr(j) )
                return True



# Generated at 2022-06-25 18:28:58.513071
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    http_req_0 = HTTPRequest(None)
    http_req_0.iter_lines(1, 2)


# Generated at 2022-06-25 18:29:00.438745
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest()
    assert [req.iter_body()] == [[req.body]]

test_case_0()

# Generated at 2022-06-25 18:29:01.017294
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    requests.get


# Generated at 2022-06-25 18:29:01.810593
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:29:05.178454
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    data_0 = 'data_0'
    http_request = HTTPRequest(data_0)
    # Test exception raises
    try:
        http_request.iter_lines(chunk_size = 1)
    except NotImplementedError:
        print('Test not implemented.')


# Generated at 2022-06-25 18:29:16.125216
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = '''
GET / HTTP/1.1
Host: httpbin.org
Connection: keep-alive
Cache-Control: no-cache
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36
Postman-Token: e4ac34b2-f234-7fde-49a5-91a8a54250f1
Accept: */*
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.8,sv;q=0.6

'''

# Generated at 2022-06-25 18:29:40.395442
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'Test iter_lines method of HTTPResponse class.'
    req_0 = HTTPRequest(str_0)

    # Test case: iter_lines method call
    for line in req_0.iter_lines():
        pass


# Generated at 2022-06-25 18:29:42.653597
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest('Test iter_body method of HTTPRequest class')
    assert req.iter_body() == 'Test iter_body method of HTTPRequest class'


# Generated at 2022-06-25 18:29:45.847563
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Instantiation of HttpRequest
    request = HTTPRequest(urllib.request.Request(url='http://www.python.org'))

    # Test iter_lines
    for i in request.iter_lines():
        it = iter(i)


# Generated at 2022-06-25 18:29:54.549642
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Create a request from a file
    data = open(this_dir + "/test_case_0.txt", 'rb').read()
    response = requests.models.Request(method='GET', url='http://example.com/', headers={'User-Agent': 'Mozilla/5.0'}, data=data)
    try:
        httpRequest = HTTPRequest(response)
    except:
        assert False

    # Get iterator of response body
    iter_body = httpRequest.iter_lines(1)
    result = []
    for chunk in iter_body:
        result.append(chunk)
    assert result == [(data, b'')]



# Generated at 2022-06-25 18:29:56.828160
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Setup
    req_0 = HTTPRequest()
    # Assertion
    with pytest.raises(AttributeError):
        req_0.iter_lines()


# Generated at 2022-06-25 18:30:05.353692
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with open('UnitTestFile/unit_test_file_HTTPResponse.txt', 'rb') as file:
        file_lines = file.readlines()
    file_string = b''
    for line in file_lines:
        file_string = file_string + line
    # Create an instance of class HTTPResponse.
    response = HTTPResponse(None)
    # Set the value of member _orig to file.
    response._orig = file_string
    # Call the iter_lines method and obtain the iterator.
    iter_lines = response.iter_lines(128)
    # Read all lines of the file.
    all_lines = ''

# Generated at 2022-06-25 18:30:16.511814
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'http://example.com'
    import requests

    x = requests.get(url)
    # x = requests.post(url, data = {'key':'value'})            # uncomment this line to test POST HTTP response
    body_lines = []
    for line, line_feed in HTTPResponse(x).iter_lines(chunk_size=1):
        body_lines.append(line)
        assert line_feed == b'\n'

    from requests.packages.urllib3.response import  HTTPResponse

    # import ssl
    # import urllib3
    # urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    # ctx = ssl.create_default_context()
    # ctx.check_hostname =

# Generated at 2022-06-25 18:30:24.120777
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_str_0 = 'Test iter_lines method of class HTTPRequest.'
    test_bytes_0 = bytes(test_str_0, 'utf-8')
    test_stream_0 = io.BytesIO(test_bytes_0)
    test_request_0 = HTTPRequest(test_stream_0)
    for line, eof in test_request_0.iter_lines(len(test_bytes_0)):
        assert line == test_bytes_0
        assert eof == b''



# Generated at 2022-06-25 18:30:26.543966
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:30:29.934950
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    print('Test iter_lines method of HTTPRequest class.')
    req = http.client.HTTPConnection('www.iherb.com')
    req.request('POST', '/')
    res = req.getresponse()
    hReq = HTTPRequest(res)
    for x in hReq.iter_lines(10):
        print(x)


# Generated at 2022-06-25 18:30:54.506645
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)


# Generated at 2022-06-25 18:31:00.949191
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    int_0 = 1
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)
    int_0 = 0
    while (int_0 < 5):
        try:
            next(iter_0)
        except StopIteration:
            None
        int_0 += 1


# Generated at 2022-06-25 18:31:05.043288
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
  bool_0 = False
  h_t_t_p_response_0 = HTTPResponse(bool_0)
  test_case_0()

test_HTTPResponse_iter_lines()

# Generated at 2022-06-25 18:31:09.410866
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = True
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    chunk_size = 3
    h_t_t_p_response_0.iter_lines(chunk_size)


# Generated at 2022-06-25 18:31:15.505677
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    chunk_size_0 = 1
    h_t_t_p_request_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:31:20.307761
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(0)
    # assert_equal (h_t_t_p_response_0.iter_lines(), 0)


# Generated at 2022-06-25 18:31:23.055793
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    http_request_0 = HTTPRequest(None)
    h_t_t_p_request_iter_lines_0 = http_request_0.iter_lines(1)


# Generated at 2022-06-25 18:31:25.368468
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Signature: name(self: HTTPRequest, chunk_size: int) -> Iterable[bytes]
    assert True # TODO


# Generated at 2022-06-25 18:31:31.908634
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    h_t_t_p_request_1 = HTTPRequest(bool_0)
    h_t_t_p_request_2 = HTTPRequest(bool_0)
    h_t_t_p_request_3 = HTTPRequest(bool_0)
    h_t_t_p_request_4 = HTTPRequest(bool_0)
    h_t_t_p_request_5 = HTTPRequest(bool_0)
    h_t_t_p_request_6 = HTTPRequest(bool_0)
    h_t_t_p_request_7 = HTTPRequest(bool_0)
    h_t_t_p_request_8 = HTTPRequest(bool_0)
    h_

# Generated at 2022-06-25 18:31:41.671430
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Create a test HTTPRequest object
    http_request_0 = HTTPRequest(None)
    http_request_0.body = b''

    # Check if the iterator returns the correct values
    assert [line for line, line_feed in http_request_0.iter_lines(1)] == []
    assert [line_feed for line, line_feed in http_request_0.iter_lines(1)] == []

    http_request_0.body = b'a'
    assert [line for line, line_feed in http_request_0.iter_lines(1)] == [b'a']
    assert [line_feed for line, line_feed in http_request_0.iter_lines(1)] == [b'']

    http_request_0.body = b'a\nb'

# Generated at 2022-06-25 18:32:05.613498
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Setup
    HTTPRequest_1 = HTTPRequest(bool)

    # Assertion
    assert_equal(HTTPRequest_1.iter_body(int), Iterable[bytes].__iter__(HTTPRequest_1))


# Generated at 2022-06-25 18:32:07.931518
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    

# Generated at 2022-06-25 18:32:08.840731
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()


# Generated at 2022-06-25 18:32:11.565273
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = True
    HTTPRequest_0 = HTTPRequest(bool_0)
    HTTPRequest_0.iter_body()


# Generated at 2022-06-25 18:32:13.709698
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Data
    req_0 = create_HTTPRequest()

    # Test
    for chunk in req_0.iter_body(1024):
        assert(chunk == b'Hello World!')


# Generated at 2022-06-25 18:32:22.448208
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    a_i_0 = HTTPResponse(True)
    h_t_t_p_response_0 = HTTPResponse(a_i_0)
    a_i_0 = HTTPResponse('')
    h_t_t_p_response_0 = HTTPResponse(a_i_0)
    a_i_0 = HTTPResponse(['', '', ''])
    h_t_t_p_response_0 = HTTPResponse(a_i_0)
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    h_t_t_p_response_0 = HTTPResponse(None)
    a_i_0 = HTTPResponse(True)


# Generated at 2022-06-25 18:32:26.247555
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    int_0 = 0
    bytes_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:32:29.523125
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    try:
        test_case_0()
    except NotImplementedError:
        print('Not implemented error captured')
    else:
        print('Expected error did not happen')



# Generated at 2022-06-25 18:32:32.170910
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    source_code_info_0 = HTTPRequest(0)
    assert source_code_info_0.iter_body(1) == [0]


# Generated at 2022-06-25 18:32:38.306319
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # test_HTTPRequest_iter_body
    # Setup
    str_0 = 'test_HTTPRequest_iter_body'
    str_1 = str_0.encode('utf8')
    http_request_0 = HTTPRequest(str_0)
    # test
    for i, chunk in enumerate(http_request_0.iter_body(1)):
        assert chunk == str_1
    # teardown
    pass


# Generated at 2022-06-25 18:33:24.464532
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Init a HTTPRequest object with request_0
    request_0 = test_HTTPRequest_request_0()
    http_request_0 = HTTPRequest(request_0)
    
    # Call method iter_body of the HTTPRequest object
    # First parameter is the chunk size
    list_0 = []
    for byte in http_request_0.iter_body(10):
        # Append the result to a list
        list_0.append(byte)
    # Check if the list is empty
    assert list_0 != []


# Generated at 2022-06-25 18:33:36.071591
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    _body_0_0 = b"\x00\x01\x02\x03\x04\x05\x06\x07\n\x0b\x0c\r\x0e\x0f"
    _body_0_iter_0 = iter([_body_0_0])
    _body_1_0 = b"\x00\x01\x02\x03\x04\x05\x06\x07\n\x0b\x0c\r\x0e\x0f"
    _body_1_iter_0 = iter([_body_1_0])

# Generated at 2022-06-25 18:33:38.345583
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)


# Generated at 2022-06-25 18:33:40.472096
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    int_0 = -11
    h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:33:41.932516
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert True


# Generated at 2022-06-25 18:33:44.429175
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    byte_0 = h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:33:50.495988
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    return_value_0 = None
    return_value_1 = True
    int_0 = 0
    h_t_t_p_request_0 = HTTPRequest(return_value_0)
    return_value_2 = h_t_t_p_request_0.iter_body(int_0)
    return_value_3 = list(return_value_2)
    assert return_value_1 == return_value_3


# Generated at 2022-06-25 18:33:54.797945
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)

    try:
        h_t_t_p_request_0.iter_body(i_0=1)
    except Exception as e_0:
        print(e_0)


# Generated at 2022-06-25 18:33:58.198745
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    # Currently does not work, as iter_body is not a method or staticmethod of
    # HTTPRequest
    h_t_t_p_request_0.iter_body(bool_0)


# Generated at 2022-06-25 18:34:01.654327
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bool_0 = False
    h_t_t_p_request_0 = HTTPRequest(bool_0)
    int_0 = h_t_t_p_request_0.iter_body()
    print(int_0)


# Generated at 2022-06-25 18:34:41.303163
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    h_t_t_p_response_0.iter_lines(chunk_size=0)


# Generated at 2022-06-25 18:34:44.588118
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    # Note: the following line is expected to fail
    #       with TypeError in line 78 of ologolib.py
    #       TypeError: 'bool' object is not iterable
    h_t_t_p_response_0.iter_lines(bool(1))



# Generated at 2022-06-25 18:34:47.341753
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    for _ in h_t_t_p_response_0.iter_lines(1):
        pass

# Generated at 2022-06-25 18:34:49.921709
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    int_0 = 0
    for _ in h_t_t_p_response_0.iter_lines(int_0):
        break


# Generated at 2022-06-25 18:34:51.182699
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:34:56.070926
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Unit test for method iter_lines of class HTTPResponse
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    # expected: true
    try:
        h_t_t_p_response_0.iter_lines(True)
        passed_test = True
    except Exception:
        passed_test = False
    assert passed_test


# Generated at 2022-06-25 18:35:00.423136
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    for _ in h_t_t_p_response_0.iter_lines(1):
        pass


# Generated at 2022-06-25 18:35:01.805431
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:35:03.257868
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    bool_0 = False
    h_t_t_p_response_0 = HTTPResponse(bool_0)


# Generated at 2022-06-25 18:35:08.120667
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import datetime
    import random
    chunk = random.randint(0, 1000)
    bool_0 = datetime.datetime(7, 21, 15, 1, 55, 43, 122)
    h_t_t_p_message_0 = HTTPMessage(bool_0)
    h_t_t_p_response_0 = HTTPResponse(bool_0)
    h_t_t_p_response_0.iter_lines(chunk)
    h_t_t_p_message_0.iter_lines(chunk)
