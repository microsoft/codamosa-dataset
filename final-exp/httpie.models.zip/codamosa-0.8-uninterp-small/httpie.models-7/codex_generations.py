

# Generated at 2022-06-25 18:26:10.990388
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    int_0 = 1
    str_0 = h_t_t_p_request_0.headers
    bytes_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:26:17.205369
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    h_t_t_p_request_1 = HTTPRequest(tuple_0)
    h_t_t_p_request_0.iter_body()
    # __add__ is not implemented for this class
    # h_t_t_p_request_1 + h_t_t_p_request_0
    # try:
    #     h_t_t_p_request_2 = h_t_t_p_request_1 + h_t_t_p_request_0
    # except TypeError:
    #     return
    # raise RuntimeError, "Shouldn't reach this line"


# Generated at 2022-06-25 18:26:27.831717
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)

    # str
    str_1 = h_t_t_p_response_0.headers
    assert isinstance(str_1, str)
    # bytes
    bytes_0 = h_t_t_p_response_0.body
    assert isinstance(bytes_0, bytes)
    # str
    str_2 = h_t_t_p_response_0.content_type
    assert isinstance(str_2, str)
    # int
    int_0 = 1
    # Iterable[str]
    iterable_str_0 = h_t_t_p_response_0.iter_lines(int_0)

# Generated at 2022-06-25 18:26:35.110830
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    # body is a bytes type of len 1
    # It's hard to verify the content of bytes, we just check its type and length
    assert type(next(h_t_t_p_request_0.iter_body(1))).__name__ == 'bytes'
    assert len(next(h_t_t_p_request_0.iter_body(1))) == 1


# Generated at 2022-06-25 18:26:39.125207
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    http_request_0 = HTTPRequest(tuple_0)
    int_0 = http_request_0.iter_lines(4)
    

# Generated at 2022-06-25 18:26:48.538311
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # TODO: Rewrite these tests to not use generated data.
    for chunk_size in [1, 2, 3, 4, 5]:
        test_method_response_0 = b'b' * chunk_size
        test_method_response_1 = (b'c' * chunk_size) + b'\n' + b'd' * chunk_size
        string_0 = 'z'
        tuple_0 = requests.Request(string_0, data=test_method_response_0)
        tuple_1 = requests.Request(string_0, data=test_method_response_1)
        h_t_t_p_request_0 = HTTPRequest(tuple_0)
        h_t_t_p_request_1 = HTTPRequest(tuple_1)

# Generated at 2022-06-25 18:26:53.324277
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines


# Generated at 2022-06-25 18:26:54.248423
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert True == True


# Generated at 2022-06-25 18:26:58.484590
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # Uncomment the following line to return a proper test result.
    # return h_t_t_p_response_0.iter_lines(10)

if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-25 18:27:04.131503
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    tuple_1 = None
    h_t_t_p_response_1 = HTTPResponse(tuple_1)
    h_t_t_p_response_1.iter_body(chunk_size_0=0)


# Generated at 2022-06-25 18:27:17.357535
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    #arrange
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)

    #act
    actual = h_t_t_p_response_0.iter_lines(1)

    #assert
    assert actual == None


# Generated at 2022-06-25 18:27:20.748601
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:27:25.420146
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    for r_4 in h_t_t_p_response_0.iter_lines(512):
        pass


# Generated at 2022-06-25 18:27:31.468586
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    int_0 = None
    # Call method iter_lines (line 32)
    iter_lines_0 = h_t_t_p_request_0.iter_lines(int_0)
    test_iter_lines_0 = next(iter_lines_0)
    assert test_iter_lines_0 is not None


# Generated at 2022-06-25 18:27:42.884339
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    var_0 = HTTPRequest(None, None)
    var_1 = var_0.iter_lines(1)
    var_2 = Iterable[bytes].__iter__(var_1)
    var_3 = (bytes, bytes).__iter__(var_2)
    var_4 = bytes.__eq__(var_3, None)
    var_5 = bool.__eq__(var_4, True)
    var_6 = not var_5
    if var_6:
        var_7 = (bytes, bytes).__iter__(var_2)
        var_8 = bytes.__eq__(var_7, None)
        var_9 = bool.__eq__(var_8, False)
        var_10 = not var_9
        if var_10:
            var_11 = NotIm

# Generated at 2022-06-25 18:27:45.553073
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    list_0 = list(h_t_t_p_request_0.iter_lines(1))


# Generated at 2022-06-25 18:27:49.472478
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    str_0 = h_t_t_p_response_0.encoding
    int_0 = 2
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:27:54.327489
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_1 = None
    h_t_t_p_response_1 = HTTPResponse(tuple_1)
    h_t_t_p_response_1.iter_lines(1)



# Generated at 2022-06-25 18:27:56.676933
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    http_request_0 = HTTPRequest(tuple_0)

    http_request_0.iter_lines(1)


# Generated at 2022-06-25 18:27:59.957608
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    tuple_0 = None
    h_t_t_p_request_0 = HTTPRequest(tuple_0)
    int_0 = 0
    # None check
    assert h_t_t_p_request_0.iter_lines(int_0) is not None


# Generated at 2022-06-25 18:28:10.626246
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # TODO: add test cases
    assert True


# Generated at 2022-06-25 18:28:13.572455
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size_0 = 0
    var_0 = h_t_t_p_response_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:28:16.996295
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(chunk_size=0)


# Generated at 2022-06-25 18:28:23.982529
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    assert h_t_t_p_response_0.iter_lines(i=42) is not None
    assert h_t_t_p_response_0.iter_lines(chunk_size=0) is not None


# Generated at 2022-06-25 18:28:26.238391
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # later

# Queries

# Generated at 2022-06-25 18:28:29.867638
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    int_0 = 0
    iterable_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:28:32.888532
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    int_0 = 0
    iterator_0 = h_t_t_p_response_0.iter_lines(int_0)
    

# Generated at 2022-06-25 18:28:40.214489
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    t = True
    f = False
    f_e = False
    undefined = None
    tuple_0 = None
    try:
        h_t_t_p_response_0 = HTTPResponse(tuple_0)
        h_t_t_p_response_0.iter_lines()
        h_t_t_p_response_0.iter_lines(undefined)
        h_t_t_p_response_0.iter_lines(t)
        h_t_t_p_response_0.iter_lines(f_e)
        h_t_t_p_response_0.iter_lines(f)
    except BaseException as e:
        f_e = True
    assert f_e == False


# Generated at 2022-06-25 18:28:44.075961
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:28:47.100271
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert h_t_t_p_response_0.iter_lines(chunk_size=4)


# Generated at 2022-06-25 18:29:01.743826
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    iter_lines = h_t_t_p_response_0.iter_lines(chunk_size=int_0)


# Generated at 2022-06-25 18:29:06.500356
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    str_0 = None
    int_0 = None
    result = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:29:12.830580
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    str_0 = 'default.htm'
    integer_0 = int('-db', 16)
    assert_match(h_t_t_p_response_0.iter_lines(integer_0), str_0)


# Generated at 2022-06-25 18:29:15.696783
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:18.063583
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:29:21.570135
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:27.651146
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size_0 = 0
    for tuple_0 in h_t_t_p_response_0.iter_lines(chunk_size_0):
        pass


# Generated at 2022-06-25 18:29:30.578389
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:32.995519
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    test_case_0()


# Generated at 2022-06-25 18:29:37.099970
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    list_0 = list(h_t_t_p_response_0.iter_lines(1))


# Generated at 2022-06-25 18:30:03.672033
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    int_0 = 100
    return_value_0 = h_t_t_p_response_0.iter_lines(int_0)



# Generated at 2022-06-25 18:30:10.083417
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_1 = HTTPResponse(tuple_0)
    h_t_t_p_response_2 = HTTPResponse(tuple_0)
    h_t_t_p_response_3 = HTTPResponse(tuple_0)
    h_t_t_p_response_4 = HTTPResponse(tuple_0)
    h_t_t_p_response_5 = HTTPResponse(tuple_0)
    h_t_t_p_response_6 = HTTPResponse(tuple_0)
    h_t_t_p_response_7 = HTTPResp

# Generated at 2022-06-25 18:30:12.488179
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    chunk_size_0 = 1
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(chunk_size_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:30:18.683033
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    cases = {
        'test_0': (1, test_case_0)
    }
    # Try to avoid non-deterministic ORM tests
    # 'test_1': (1, test_case_1),
    # 'test_2': (1, test_case_2)

    for case in cases:
        print(f'== TEST CASE: {case} ==')
        cases[case][1]()

# Generated at 2022-06-25 18:30:24.120374
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # `self._orig.iter_lines` returns an iterator; we must evaluate the result
    # in order to trigger the mocking.

    h_t_t_p_response_0 = HTTPResponse(None)
    assert len(list(h_t_t_p_response_0.iter_lines(1))) == 1


# Generated at 2022-06-25 18:30:32.034756
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size_0 = 1
    for s_0 in h_t_t_p_response_0.iter_lines(chunk_size_0):
        h_t_t_p_response_1 = HTTPResponse(tuple_0)
        chunk_size_1 = 1
        for s_1 in h_t_t_p_response_1.iter_lines(chunk_size_1):
            pass



# Generated at 2022-06-25 18:30:34.765616
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)

# Generated at 2022-06-25 18:30:45.000934
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    int_0 = 0
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None
    str_17 = None
    str_18 = None
   

# Generated at 2022-06-25 18:30:51.118964
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    ###########################################################################
    # Test case0

    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)

    res = h_t_t_p_response_0.iter_lines(1)

    ###########################################################################
    # Test case1
    tuple_1 = (None, None)
    h_t_t_p_response_1 = HTTPResponse(tuple_1)

    res = h_t_t_p_response_1.iter_lines(1)



# Generated at 2022-06-25 18:30:57.660522
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Test iter_lines"""
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    result = h_t_t_p_response_0.iter_lines(1)
    assert result.__next__() == ('', '')
    assert result.__next__() is None


# Generated at 2022-06-25 18:31:49.643314
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size = 1
    assert_equal(h_t_t_p_response_0.iter_lines(chunk_size), h_t_t_p_response_0.iter_body(chunk_size))


# Generated at 2022-06-25 18:31:53.239237
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:31:56.594840
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:08.419495
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    _test_tuple_0 = None
    _test_HTTPResponse_0 = HTTPResponse(_test_tuple_0)
    _test_tuple_1 = 1
    _test_HTTPResponse_0.iter_lines(_test_tuple_1)
    _test_tuple_2 = None
    _test_HTTPResponse_0 = HTTPResponse(_test_tuple_2)
    _test_tuple_3 = 1
    _test_iter_0 = _test_HTTPResponse_0.iter_lines(_test_tuple_3)
    _test_list_0 = list(_test_iter_0)
    assert _test_list_0 == []


# Generated at 2022-06-25 18:32:13.971063
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0_iter_lines_0 = iter(h_t_t_p_response_0.iter_lines(1))
    h_t_t_p_response_0_iter_lines_1 = iter(h_t_t_p_response_0.iter_lines(1))
    assert h_t_t_p_response_0_iter_lines_0 == h_t_t_p_response_0_iter_lines_1


# Generated at 2022-06-25 18:32:18.432769
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # Input Parameters:
    chunk_size = 1
    # Return value:
    return_value_0 = h_t_t_p_response_0.iter_lines(chunk_size)
    # Assertion
    assert True


# Generated at 2022-06-25 18:32:21.635557
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size_0 = 1
    h_t_t_p_response_0.iter_lines(chunk_size_0)

# Generated at 2022-06-25 18:32:27.441235
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Python 3.7.x
    # Test 1
    tuple_1 = None
    h_t_t_p_response_1 = HTTPResponse(tuple_1)
    h_t_t_p_response_1.iter_lines(1)
    # Test 2
    tuple_2 = None
    h_t_t_p_response_2 = HTTPResponse(tuple_2)
    h_t_t_p_response_2.iter_lines(1)
    # Test 3
    tuple_3 = None
    h_t_t_p_response_3 = HTTPResponse(tuple_3)
    h_t_t_p_response_3.iter_lines(1)



# Generated at 2022-06-25 18:32:31.822314
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:40.638703
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # First argument of HTTPResponse() is the original object, for which we
    # don't care about here.
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    chunk_size = 5
    result = h_t_t_p_response_0.iter_lines(chunk_size)
    assert isinstance(result, Iterable)
    with pytest.raises(NotImplementedError):
        # iter_lines is an abstract method so this test should fail.
        result = h_t_t_p_response_0.iter_lines(chunk_size)


# Generated at 2022-06-25 18:34:22.533837
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_1 = HTTPResponse(tuple_0)
    argument_0 = 42
    list_0 = list(h_t_t_p_response_1.iter_lines(argument_0))



# Generated at 2022-06-25 18:34:25.461556
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:34:28.952614
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    try:
        h_t_t_p_response_0.iter_lines(1)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 18:34:33.382494
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    headers = {'Content-Type': 'text/plain'}
    resp = HTTPResponse(requests.get('http://httpbin.org/get', headers=headers))
    with open('iter_lines.txt', 'w') as f:
        for line, line_feed in resp.iter_lines(1):
            f.write(line)


# Generated at 2022-06-25 18:34:38.341635
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Instances of this class are created by responses.
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # In this case, both iter_body and iter_lines return the same value.
    iterable_0 = h_t_t_p_response_0.iter_lines(100)
    iterable_0.__next__()

# Generated at 2022-06-25 18:34:41.479166
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    int_0 = 1
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    for _ in h_t_t_p_response_0.iter_lines(int_0):
        pass


# Generated at 2022-06-25 18:34:44.107259
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    # Call method iter_lines of class HTTPResponse
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:34:46.881198
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:34:49.503528
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    assert h_t_t_p_response_0.iter_lines(1).__class__ is types.GeneratorType


# Generated at 2022-06-25 18:34:52.707833
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    tuple_0 = None
    h_t_t_p_response_0 = HTTPResponse(tuple_0)
    str_0 = h_t_t_p_response_0.iter_lines(1)
    assert str_0 is not None
