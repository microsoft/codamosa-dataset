

# Generated at 2022-06-25 18:26:07.859239
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 1
    assert_true(isinstance(h_t_t_p_request_0.iter_lines(int_0), Iterable))


# Generated at 2022-06-25 18:26:13.105024
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)

    i_t_e_r_0 = h_t_t_p_request_0.iter_body(1)
    assert isinstance(i_t_e_r_0, Iterable)


# Generated at 2022-06-25 18:26:17.414057
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    # NoneType cannot be used as int
    # test case: 0
    # expected result: None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    try:
        # NoneType cannot be used as int
        h_t_t_p_request_0.iter_body(None)
    except TypeError as e:
        # expected exception
        assert str(e) == "iter_body() missing 1 required positional argument: 'chunk_size'"
    else:
        assert False, 'ExpectedTypeError not raised'


# Generated at 2022-06-25 18:26:22.119576
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:26:25.042587
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:26:34.741412
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print('testing method iter_lines of class HTTPResponse')
    mock = requests.Response()
    mock.raw = mock = Mock()
    mock._original_response = mock = Mock()
    mock.version = 11
    mock.status = 200
    mock.reason = 'OK'
    mock.msg = mock = Mock()
    mock._headers = [('content-type', 'text/html'), ('date', 'Fri, 21 Dec 2018 15:30:00 GMT')]
    response = HTTPResponse(mock)
    assert isinstance(response.iter_lines(chunk_size=1), Iterable)


# Generated at 2022-06-25 18:26:40.367443
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    with pytest.raises(NotImplementedError):
        h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:26:44.375088
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    # Iterator over the body yielding (`line`, `line_feed`).
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:26:46.255616
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)


# Generated at 2022-06-25 18:26:51.482200
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with mock.patch('requests.models.Response') as mock_response:
        sample_get_item = mock_response.get_item.return_value
        sample_get_item.iter.return_value = sample_get_item.iter_lines
        h_t_t_p_response_0 = HTTPResponse(mock_response)
        sample_get_item.iter.side_effect = Exception('boom')
        h_t_t_p_response_0.iter_lines(str_0='chunk_size')


# Generated at 2022-06-25 18:27:02.872146
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert not True


# Generated at 2022-06-25 18:27:09.416935
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    i_0 = h_t_t_p_request_0.iter_lines(1)
    assert_equal(list(i_0), [])


# Generated at 2022-06-25 18:27:15.082740
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    str_1 = 1
    assert_equal(list(h_t_t_p_request_0.iter_lines(str_1)), [])


# Generated at 2022-06-25 18:27:23.485128
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    path = Path(__file__).parent / 'data' / 'http-request.txt'
    request = requests.Request(
        method='GET', url=f'http://localhost:{PORT}/documents', params={
            'page': 1,
            'pageSize': 10,
        }
    )
    with path.open('rb') as f:
        prepared = request.prepare()
        # noinspection PyArgumentEqualDefault
        request = HTTPRequest(prepared)
        result_0 = request.iter_lines(f.read(8))
        assert result_0 != None


# Generated at 2022-06-25 18:27:27.157131
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    httpresponse_0 = HTTPResponse(str_0)
    chunk_size_0 = None
    httpresponse_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:27:31.600215
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 1
    iter_0 = h_t_t_p_request_0.iter_lines(int_0)
    iter_0.__next__()
    iter_0.__next__()


# Generated at 2022-06-25 18:27:38.126338
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    b_0 = None
    int_0 = None
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_1 = None
    i_0 = h_t_t_p_request_0.iter_body(int_1)
    for b_1 in i_0:
        pass
    b_2 = h_t_t_p_request_0.body
    assert b_0 == b_2


# Generated at 2022-06-25 18:27:39.118688
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:27:42.468184
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:27:45.750157
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 0
    for bytes_0 in h_t_t_p_request_0.iter_body(int_0):
        assert isinstance(bytes_0, bytes)


# Generated at 2022-06-25 18:28:01.368718
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    h_t_t_p_request_0 = HTTPRequest("F3")
    h_t_t_p_request_1 = HTTPRequest("http://0.0.0.0:5000/simple/pip")
    h_t_t_p_request_2 = HTTPRequest("http://0.0.0.0:5000/simple/pathlib2")
    h_t_t_p_request_3 = HTTPRequest("http://0.0.0.0:5000/simple/socks")
    h_t_t_p_request_4 = HTTPRequest("http://0.0.0.0:5000/simple/pathlib2")
    h_t_t_p_request_5 = HTTPRequest("{http://0.0.0.0:5000/simple/pip}k>")
    str_

# Generated at 2022-06-25 18:28:05.046385
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:28:09.030519
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    p_o_s_t_0 = None
    str_1 = h_t_t_p_request_0.iter_body(p_o_s_t_0)


# Generated at 2022-06-25 18:28:12.870507
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body(15)
    h_t_t_p_request_0.iter_body(5)


# Generated at 2022-06-25 18:28:14.707216
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
  str_0 = None
  assert HTTPRequest(str_0).iter_body(1) == None


# Generated at 2022-06-25 18:28:26.237587
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests

    url = 'https://httpbin.org/get'
    r = requests.get(url, headers={'Accept': 'application/json'})

    # First check that the content-type is what we expect.
    ct = r.headers.get('Content-Type')
    assert ct == 'application/json'

    # Then check that the body is what we expect.
    response = HTTPResponse(r)
    body = b''
    for line, line_feed in response.iter_lines(chunk_size=1):
        body += line + line_feed
    print("Body is: ", body)

# Generated at 2022-06-25 18:28:29.867506
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 0
    list_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:28:32.187556
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    chunk_size_0 = 1
    # Class HTTPRequest does not have method iter_body


# Generated at 2022-06-25 18:28:33.067982
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:28:35.475569
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:28:58.428864
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 1
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')
    assert_equal(next(iter_0)[0], b'')

# Generated at 2022-06-25 18:29:00.698177
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    #self.assertEqual(expected, HTTPResponse.iter_lines(self, chunk_size))
    assert False # TODO: implement your test here


# Generated at 2022-06-25 18:29:02.453155
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    http_request_0 = HTTPRequest(str_0)

    chunk_size_0 = 0
    result = http_request_0.iter_body(chunk_size_0)
    assert result == None


# Generated at 2022-06-25 18:29:07.579536
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import io
    import urllib.request
    response = urllib.request.urlopen('http://example.com/')

    # fileobj = io.BytesIO(response.read())
    # self.assertEqual(response.read(), fileobj.read())

    # and now again, with the new iterator:
    # fileobj = io.BytesIO(response.read())
    # self.assertEqual(response.read(), b''.join(fileobj.chunk()))



# Generated at 2022-06-25 18:29:13.039251
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 0
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:29:17.074425
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    b_y_t_e_s_0 = None
    s_t_r_0 = None
    h_t_t_p_request_0 = HTTPRequest(s_t_r_0)
    i_n_t_0 = h_t_t_p_request_0.iter_body(b_y_t_e_s_0)


# Generated at 2022-06-25 18:29:25.527705
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 1
    iterable_0 = h_t_t_p_request_0.iter_body(int_0)
    assert iterable_0 is not None
    assert iterable_0 != 0
    # h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:29:27.321759
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)


# Generated at 2022-06-25 18:29:28.141615
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    test_case_0()

# Generated at 2022-06-25 18:29:32.974566
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from typing import Iterable
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    chunk_size_0 = 4
    i_t_e_r_a_b_l_e_0 = h_t_t_p_request_0.iter_body(
        chunk_size_0
    )
    assert isinstance(i_t_e_r_a_b_l_e_0, Iterable)

# Test Cases for class HTTPRequest

# Generated at 2022-06-25 18:30:00.973482
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    assert h_t_t_p_request_0.iter_body(0) == None


# Generated at 2022-06-25 18:30:03.216032
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 0
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:05.521366
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    assert_equal(h_t_t_p_request_0.iter_body(), ())


# Generated at 2022-06-25 18:30:11.542649
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert type(h_t_t_p_response_0.iter_lines(1)) == type((lambda: (yield))())


# Generated at 2022-06-25 18:30:14.951571
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    assert iterator_equals(h_t_t_p_request_0.iter_body(0), [b''])


# Generated at 2022-06-25 18:30:20.435376
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # TODO replace this with test case
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:30:22.078514
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)

    str_1 = None
    h_t_t_p_request_0.iter_body(str_1)



# Generated at 2022-06-25 18:30:25.926082
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    int_0 = 0
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:28.903824
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:30:31.691886
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = h_t_t_p_response_0.iter_lines(int(0))


# Generated at 2022-06-25 18:31:26.802647
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body(1)

# Generated at 2022-06-25 18:31:34.112211
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 1
    assert (iter(h_t_t_p_request_0.iter_body(int_0))) == iter(h_t_t_p_request_0.iter_body(int_0))


# Generated at 2022-06-25 18:31:38.638436
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 0
    it_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:31:41.392327
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    result = h_t_t_p_request_0.iter_body(1)
    assert type(result) == type(h_t_t_p_request_0)


# Generated at 2022-06-25 18:31:45.081185
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    try:
        h_t_t_p_request_0.iter_body(1)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:31:53.498959
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    str_1 = None
    h_t_t_p_request_0.iter_body(str_1)
    h_t_t_p_request_1 = HTTPRequest(str_0)
    str_2 = None
    h_t_t_p_request_1.iter_body(str_2)
    str_3 = None
    h_t_t_p_request_1.iter_body(str_3)
    h_t_t_p_request_2 = HTTPRequest(str_0)
    str_4 = None
    h_t_t_p_request_2.iter_body(str_4)

# Generated at 2022-06-25 18:31:56.971012
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    str_1 = None
    assert list(h_t_t_p_request_0.iter_body(str_1)) == [b'']


# Generated at 2022-06-25 18:32:02.535920
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    test_HTTPRequest_iter_body_var_0 = h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:32:06.771124
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    int_0 = 1
    h_t_t_p_request_0 = HTTPRequest(str_0)
    iter_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:32:09.864225
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = None
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = 0
    h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:33:08.352961
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r_line_0 = ""
    int_0 = 2
    assert r_line_0 == HTTPResponse.iter_lines(int_0)


# Generated at 2022-06-25 18:33:10.752314
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:14.150500
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Inputs
    chunk_size_0 = None
    object_0 = HTTPResponse(object)
    assert not (object_0.iter_lines(chunk_size_0) != None)



# Generated at 2022-06-25 18:33:18.155664
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    resp = _HTTPResponse(status=200, body='foo\nbar\n')
    assert resp.iter_lines(1) == [
        (b'foo\n', b'\n'),
        (b'bar\n', b'\n'),
        (b'', b''),
    ]



# Generated at 2022-06-25 18:33:27.146272
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # Test for method iter_lines of class HTTPResponse
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(0) is not None

    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(0) is not None

    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(0) is not None

# Generated at 2022-06-25 18:33:29.069380
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:33:31.356911
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    # Line coverage is 100%.
    assert h_t_t_p_response_0.iter_lines(0) is not None
    # Branch coverage is 100%.


# Generated at 2022-06-25 18:33:34.844992
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    request = requests.post('http://localhost:8081/', data=b'a')
    response = HTTPResponse(request)
    assert list(response.iter_lines(chunk_size=1)) == (
        [(b'a', b'\n')]
    )


# Generated at 2022-06-25 18:33:37.652020
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with pytest.raises(NotImplementedError): HTTPResponse(0).iter_lines();


# Generated at 2022-06-25 18:33:40.008899
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response_0 = None
    chunk_size_0 = 1
    result = response_0.iter_lines(chunk_size_0)
    assert result is not None
    # Assignment value
    assert result is not None


# Generated at 2022-06-25 18:35:39.630405
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # PyLint cannot properly find names for the objects in the code, which are
    # imported from another module
    # pylint: disable=no-name-in-module
    from requests.models import Response
    from io import BytesIO

    resp = Response()
    resp._content = BytesIO(b'\n\n\n1\n2\n3\n\n\n\n')

    http_response_0 = HTTPResponse(resp)
    s_t_r_0 = u''
    for bytes_0, bytes_1 in http_response_0.iter_lines(1024):
        s_t_r_0 += bytes_0.decode('utf8')

# Generated at 2022-06-25 18:35:42.245121
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:35:45.243105
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    a_str_0 = None
    h_t_t_p_response_0 = HTTPResponse(a_str_0)
    int_0 = 0
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:35:47.736227
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = None
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)



# Generated at 2022-06-25 18:35:51.111393
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_1 = None
    h_t_t_p_response_0 = HTTPResponse(str_1)
    h_t_t_p_response_0.iter_lines
