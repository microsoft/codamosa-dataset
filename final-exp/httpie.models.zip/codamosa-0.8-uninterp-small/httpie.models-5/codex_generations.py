

# Generated at 2022-06-25 18:26:03.710229
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:26:07.894875
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert isinstance(h_t_t_p_response_0.iter_lines(1), Iterable[bytes])


# Generated at 2022-06-25 18:26:11.384081
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'Response'
    http_request_0 = HTTPRequest(str_0)
    int_0 = 1
    http_request_0.iter_lines(int_0)


# Generated at 2022-06-25 18:26:17.759420
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '1\xA7\x9B\x96\xB6\xB6\x8A\xB6'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_body(1)
    # AssertionError: [<type 'ValueError'>]

    str_0 = '\xEE\x95\xD4\x85x:\xE4\x93\xD4\xEE\x8B'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_body(1)
    # AssertionError: [<type 'ValueError'>]

    str_

# Generated at 2022-06-25 18:26:26.469692
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    # Test:
    # - No arguments
    # Expect:
    # - TypeError

    # Arrange
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    expected_0 = 't'


    # Act
    try:
        h_t_t_p_request_0.iter_body()
    except TypeError as exception_0:
        actual_0 = 't'
    else:
        actual_0 = 'f'

    # Assert
    assert actual_0 == expected_0



# Generated at 2022-06-25 18:26:29.285480
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    print("Testing method: iter_body of class HTTPResponse")

    test_obj_0 = HTTPResponse(str)
    test_obj_0.iter_body(chunk_size=1)
    assert True


# Generated at 2022-06-25 18:26:35.689173
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = [0, 1, 2, 3]
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)
    # check to make sure that the list str_0 hasn't changed
    assert str_0 == [0, 1, 2, 3]


# Generated at 2022-06-25 18:26:41.242009
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)

    try:
        h_t_t_p_request_0.iter_lines(1)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:26:42.193097
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    assert True == __nullstub__

# Generated at 2022-06-25 18:26:51.442581
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    url_0 = 'www.google.com/'
    headers_0 = {'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36'}
    h_t_t_prequest_0 = HTTPRequest(url_0,headers_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_prequest_0)
    h_t_t_p_response_0.iter_body()

# Generated at 2022-06-25 18:27:07.832945
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    global str_1
    str_1 = ':>E9Kn%R'
    global h_t_t_p_request_0
    h_t_t_p_request_0 = HTTPRequest(str_1)
    global int_1
    int_1 = 2
    global method_return_0
    method_return_0 = h_t_t_p_request_0.iter_body(int_1)
    global var_0
    var_0 = isinstance(method_return_0, Iterable)
    assert var_0 == True


# Generated at 2022-06-25 18:27:13.899811
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Initialize an instance of class HTTPRequest
    req = requests.Request('GET', 'http://httpbin.org/headers')
    h_t_t_p_request_0 = HTTPRequest(req)

    # Retrieve the value of property body of object h_t_t_p_request_0
    # Call method iter_lines of class HTTPRequest with argument 1
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:27:18.576689
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    with pytest.raises(NotImplementedError):
        str_0 = ':>E9Kn%R'
        h_t_t_p_response_0 = HTTPRequest(str_0)
        int_0 = -118199821
        str_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:27:23.584095
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 9
    iter_1 = h_t_t_p_response_0.iter_body(int_0)


# Generated at 2022-06-25 18:27:24.320382
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass

# Generated at 2022-06-25 18:27:27.157766
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '5y'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    str_1 = 'oCv'
    str_2 = 'c%+'
    int_0 = -14
    h_t_t_p_request_0.iter_body(int_0)
    h_t_t_p_request_0._orig._generate_content_length(str_1, str_2)


# Generated at 2022-06-25 18:27:31.643175
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_c = ':>E9Kn%R'
    HTTPRequest_0 = HTTPRequest(str_c)

    bytes_c = b'7ydh5_%JY7z"'

    with pytest.raises(TypeError):
        HTTPRequest_0.iter_lines(bytes_c)


# Generated at 2022-06-25 18:27:33.416748
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_0 = HTTPRequest('public')
    h_t_t_p_request_0.iter_lines(1)

# Generated at 2022-06-25 18:27:39.554854
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    int_0 = 1
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:27:42.854531
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_body()



# Generated at 2022-06-25 18:28:02.259520
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # TBD: implement test
    assert(False)


# Generated at 2022-06-25 18:28:05.947283
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = h_t_t_p_request_0.iter_body()



# Generated at 2022-06-25 18:28:11.567473
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_1 = '@dD^'
    h_t_t_p_response_1 = HTTPResponse(str_1)


# Generated at 2022-06-25 18:28:12.724636
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    print('Testing method iter_lines')
    assert False


# Generated at 2022-06-25 18:28:18.389574
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    class_0 = HTTPRequest(str_0)
    method = class_0.iter_body()
    for var_0 in method:
        str_1 = '%c'
        str_2 = var_0
        str_3 = str_1 % str_2
        str_4 = str_3
        str_5 = ''
        assert(str_4 != str_5)


# Generated at 2022-06-25 18:28:25.109330
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = ':>E9Kn%R'
    str_body_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines(str_body_0)


# Generated at 2022-06-25 18:28:28.814435
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)

    h_t_t_p_response_0.iter_lines(chunk_size=0)


# Generated at 2022-06-25 18:28:31.861561
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest('')
    req = iter(req)
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    pass


# Generated at 2022-06-25 18:28:34.638911
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'HttpRequest.iter_lines'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines()
    pass


# Generated at 2022-06-25 18:28:41.665343
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None: None:

# Generated at 2022-06-25 18:29:16.871014
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = ':>E9Kn%R'
    http_request_0 = HTTPRequest(str_0)
    int_0 = 0
    list_0 = list(http_request_0.iter_lines(int_0))
    assert list_0 == [b':\x3EE9Kn%R', b'']


# Generated at 2022-06-25 18:29:28.950010
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = json.loads('{"query":"PREFIX dbpedia2: <http://dbpedia.org/property/>\\nPREFIX dbpedia: <http://dbpedia.org/resource/>\\nSELECT ?s ?p ?o\\nWHERE {\\n  ?s ?p ?o .\\n  FILTER regex(str(?s), \"^http://dbpedia.org/resource/\").\\n  FILTER regex(str(?p), \"^http://dbpedia.org/property/\").\\n}\\n"}')
    h_t_t_p_response_0 = HTTPResponse(str_0)
    tuples_0 = h_t_t_p_response_0.iter_lines(10)
    assert list(tuples_0)[0] == (b'', b'\n')


# Generated at 2022-06-25 18:29:34.981313
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = -83974427
    str_1 = 'Ag@I^T'
    str_2 = '<e6Hm'
    str_3 = '^|\n'
    str_4 = '@gDM+'
    str_5 = 'J),[;'
    str_6 = 'z/7x*w'
    str_7 = '&@!5V'
    str_8 = '9\r\n'
    str_9 = '1-O|2'
    str_10 = '`6U)7'
    str_11 = 'R&P\r\n'

# Generated at 2022-06-25 18:29:45.725657
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:29:49.942820
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 0
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:29:55.642906
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'Hello, World!'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    for _ in range(10):
        for _ in h_t_t_p_request_0.iter_body(1):
            pass
    for _ in range(10):
        for _ in h_t_t_p_request_0.iter_body(1):
            pass


# Generated at 2022-06-25 18:30:01.531475
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = 'cW|\\'
    b_t_e_s_0 = (84, 101, 115, 116)
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.body = b_t_e_s_0
    for _ in h_t_t_p_request_0.iter_body(chunk_size = 1):
        # pass
        pass


# Generated at 2022-06-25 18:30:04.039724
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:30:05.352980
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request_1 = HTTPRequest()
    assert request_1.iter_body() == None

# Generated at 2022-06-25 18:30:11.586244
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'ишъ'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = -2
    iterable = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:41.953926
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    int_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:30:44.297062
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert h_t_t_p_response_0 is not None
    assert h_t_t_p_response_0.iter_lines(1) is not None


# Generated at 2022-06-25 18:30:52.582483
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    str_1 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_1)
    h_t_t_p_request_0.iter_body(0)

# Generated at 2022-06-25 18:30:57.062270
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    # Invoke method
    actual = h_t_t_p_response_0.iter_lines(1)



# Generated at 2022-06-25 18:31:09.296891
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)

# Generated at 2022-06-25 18:31:15.639812
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)

    assert_equal(list(h_t_t_p_request_0.iter_body(1)),\
                 [b'\xff\xfe\x00:', b'>\x00E', b'9\x00K',\
                  b'n\x00%', b'R\x00'])
    assert_equal(list(h_t_t_p_request_0.iter_body(2)),\
                 [b'\xff\xfe\x00:>\x00E', b'9\x00Kn', b'\x00%R\x00'])

# Generated at 2022-06-25 18:31:27.154067
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Intentionally invalid.
    str_0 = ':>E9Kn%R'  # we don't know the type (str, bytes, int)
    h_t_t_p_response_0 = HTTPResponse(str_0)
    assert h_t_t_p_response_0.iter_lines(4) == (None, '\n')
    h_t_t_p_response_1 = HTTPResponse(9)
    assert h_t_t_p_response_1.iter_lines(4) == (None, '\n')
    h_t_t_p_response_2 = HTTPResponse(b'\x00\x00')
    assert h_t_t_p_response_2.iter_lines(4) == (None, '\n')

# Generated at 2022-06-25 18:31:30.025358
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    for chunk_size_0 in range(8, 8 + 1):
        h_t_t_p_response_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:31:34.179402
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    http_request_0 = HTTPRequest(str_0)
    int_0 = 1
    iterable_0 = http_request_0.iter_body(int_0)
    for str_1 in iterable_0:
        print(str_1)


# Generated at 2022-06-25 18:31:38.334482
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = ':>E9Kn%R'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    assert h_t_t_p_request_0.iter_body() is not None



# Generated at 2022-06-25 18:32:11.828552
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:32:12.493580
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()


# Generated at 2022-06-25 18:32:15.553072
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:24.043568
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = 'xNb8\x7F*'
    str_2 = '^oI\x7Fd7V'
    chunk_size_0 = 0
    h_t_t_p_response_0.iter_lines(chunk_size_0)
    h_t_t_p_response_0.iter_lines(str_1)
    h_t_t_p_response_0.iter_lines(str_2)
    str_3 = '127.0.0.1'
    h_t_t_p_response_0.iter_lines(str_3)
    h_t_t_p_response

# Generated at 2022-06-25 18:32:25.082779
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert False


# Generated at 2022-06-25 18:32:33.852101
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from http.client import HTTPResponse
    from io import BytesIO

    raw_data = (
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: text/plain\r\n'
        b'\r\n'
        b'test\r\n'
    )
    raw_response = BytesIO(raw_data)

    # noinspection PyProtectedMember
    response = HTTPResponse(raw_response)
    response.begin()

    assert list(HTTPResponse.iter_lines(response, 1)) == [
        (b'test\r\n', b'\n')
    ]


# Generated at 2022-06-25 18:32:38.806299
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    int_0 = 1
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)

# Generated at 2022-06-25 18:32:43.142729
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    str_1 = ':>E9Kn%R'
    h_t_t_p_response_0.iter_lines(str_1)


# Generated at 2022-06-25 18:32:46.668156
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1);


# Generated at 2022-06-25 18:32:53.642373
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from HTTPResponse import HTTPResponse

    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_1 = HTTPResponse(str_0)

    # Argument h_t_t_p_message_2 is not an instance of HTTPResponse
    with pytest.raises(Exception):
        str_1 = ':>E9Kn%R'
        h_t_t_p_response_2 = str_1
        h_t_t_p_response_1.iter_body(h_t_t_p_response_2)

# Generated at 2022-06-25 18:33:49.504479
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Set up a test case:
    test_case_0()
    # Get expected result:
    expected = None
    # Get actual result:
    actual = h_t_t_p_response_0.iter_lines(chunk_size=None)
    # Assert they are equal:
    assert actual == expected, f'\nExpected: {expected}\nActual: {actual}'


# Generated at 2022-06-25 18:33:58.507545
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '{"token-type":"Bearer","access-token":"mock_token"}'
    request_0 = requests.Request('POST', 'http://www.google.com/', data=str_0)
    prepped_request_0 = request_0.prepare()
    str_1 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_1)
    iterator_0 = h_t_t_p_response_0.iter_lines(prepped_request_0)
    str_2 = ':>E9Kn%R'
    try:
        str_3 = ':>E9Kn%R'
        next(iterator_0)
    except StopIteration:
        pass

# Generated at 2022-06-25 18:34:01.149216
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    arg_0 = ':>E9Kn%R'
    ret_val_0 = HTTPResponse.iter_lines(arg_0)


# Generated at 2022-06-25 18:34:06.160304
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = 'n$xq3!8<g/p'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    num_0 = 7
    assert(len(list(h_t_t_p_response_0.iter_lines(num_0))) == 5)


# Generated at 2022-06-25 18:34:09.222454
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:34:18.719251
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:34:23.992045
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    array_0 = [None, None]
    array_0[0] = str_0
    array_0[1] = str_0
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(*array_0)


# Generated at 2022-06-25 18:34:26.647943
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from unittest import TestCase
    from unittest.mock import MagicMock

    request = MagicMock()
    request.return_value = 'some test message'
    HTTPResponse(request).iter_lines()



# Generated at 2022-06-25 18:34:33.243570
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    long_0 = 7
    iterator_0 = h_t_t_p_response_0.iter_lines(long_0)
    byte_0 = iterator_0.next()
    byte_1 = iterator_0.next()
    byte_2 = iterator_0.next()
    byte_3 = iterator_0.next()
    byte_4 = iterator_0.next()


# Generated at 2022-06-25 18:34:38.492899
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = ':>E9Kn%R'
    h_t_t_p_response_0 = HTTPResponse(str_0)
    chunk_size_0 = -3
    for line_0, line_feed_0 in h_t_t_p_response_0.iter_lines(chunk_size_0):
        str(line_0)
        str(line_feed_0)
