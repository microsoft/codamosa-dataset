

# Generated at 2022-06-25 18:26:09.553481
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    http_request_0 = HTTPRequest(set_0)
    int_0 = 1
    # iter_body of class HTTPRequest
    http_request_0.iter_body(int_0)
    # The only purpose of this method is to test it using its parent class


# Generated at 2022-06-25 18:26:14.333124
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<HTML>\r\n'
    request_0 = HTTPRequest(str_0)
    int_0 = 1
    for line, line_feed in request_0.iter_lines(int_0):
        print(line, line_feed)


# Generated at 2022-06-25 18:26:18.803902
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    test_HTTPRequest_0 = HTTPRequest(set())
    test_HTTPRequest_1 = HTTPRequest(set())
    response = test_HTTPRequest_1.iter_body(set())
    assert response == test_HTTPRequest_0.iter_body(set())


# Generated at 2022-06-25 18:26:24.732767
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    http_request_0 = HTTPRequest(set_0)
    h_t_t_p_message_0 = HTTPMessage(set_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_HTTPRequest_iter_body()



# Generated at 2022-06-25 18:26:35.974587
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    _4 = 4

    # Mock the request library.
    def iter_content(chunk_size):
        yield b"1\n"
        yield b"2\n"
        yield b"3\n"
        yield b"4\n"

    def iter_lines(chunk_size):
        yield b"1\n"
        yield b"2\n"
        yield b"3\n"
        yield b"4\n"

    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    assertion_error_0 = AssertionError()
    try:
        h_t_t_p_response_0.iter_lines(chunk_size=_4)
    except AssertionError:
        raise assertion_error_

# Generated at 2022-06-25 18:26:41.789697
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    http_request_0 = HTTPRequest(set_0)
    http_request_1 = HTTPRequest(http_request_0)
    http_request_2 = HTTPRequest(http_request_1)
    for b_0 in http_request_1.iter_lines(1):
        pass


# Generated at 2022-06-25 18:26:44.848955
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    HTTPRequest_0 = HTTPRequest(set())
    # Type-checking the result
    Iterable[bytes]
    # The full body must be yielded
    assert iter(HTTPRequest_0.iter_body())


# Generated at 2022-06-25 18:26:53.523303
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPRequest(set_0)
    iterator = h_t_t_p_message_0.iter_lines(64)
    expected = (
        ('', ''),
    )

    for expected_line, expected_line_feed in expected:
        # noinspection PyUnresolvedReferences
        line, line_feed = next(iterator)
        assert line == expected_line
        assert line_feed == expected_line_feed
    else:
        assert False  # iterator didn't stop at the expected number of lines



# Generated at 2022-06-25 18:26:59.419507
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    url_0 = url('http://example.com/')
    url_1 = url(url_0)
    url_2 = url(url_1)
    url_3 = url(url_2)
    url_4 = url(url_3)
    url_5 = url(url_4)
    url_6 = url(url_5)
    url_7 = url(url_6)
    url_8 = url(url_7)
    http_request_0 = HTTPRequest(url_8)
    str_0 = http_request_0.iter_body(1)


# Generated at 2022-06-25 18:27:09.610456
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Cookie': 'JSESSIONID=node01b1njv9gqvk15dz2i2wj3qe2.node0',
        'Host': 'www.google.com',
        'User-Agent': 'HTTPie/0.9.9'
    }
    url = 'http://www.google.com'
    http_request_0 = HTTPRequest('')
    method = 'GET'
    http_request_0._orig.headers = headers
    http_request_0._orig.url = url
    http_request_0._orig.method = method
    body = 'Test'
    http_request_0._orig.body

# Generated at 2022-06-25 18:27:20.856875
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    try:
        h_t_t_p_response_0.iter_lines(None)
        assert None
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:27:26.721168
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Creating a HTTPRequest object instance
    h_t_t_p_request_0 = HTTPRequest(None)
    # Asserting that the call of the iter_body method of the HTTPRequest class instance
    # returns a iterable
    assert isinstance(h_t_t_p_request_0.iter_body(1), Iterable)


# Generated at 2022-06-25 18:27:28.084539
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    HTTPRequest(None).iter_body(None)


# Generated at 2022-06-25 18:27:32.412326
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    int_0 = 17
    result = iter(h_t_t_p_request_0.iter_body(int_0))
    assert isinstance(result, types.GeneratorType)


# Generated at 2022-06-25 18:27:37.077002
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_message_0 = HTTPRequest(set_0)
    h_t_t_p_message_0.iter_body()


# Generated at 2022-06-25 18:27:40.699140
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_1 = set()
    h_t_t_p_response_0 = HTTPResponse(set_1)
    h_t_t_p_response_0.iter_lines(7)


# Generated at 2022-06-25 18:27:48.372835
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Setup
    requests_0 = requests
    requests_0.post = mock.Mock()
    with requests_0.post as method:
        requests_0.post.return_value = 'requests.post'
        requests_0.post.__class__ = requests_0.Response
        # requests_0.post.status_code = 200
        requests_0.post.text.return_value = 'requests.post.text'
        requests_0.post.iter_lines.return_value = ['requests.post.iter_lines']
        requests_0.post.headers.get.return_value = 'requests.post.headers.get'
        requests_0.post.encoding = 'requests.post.encoding'
        requests_0.post.content = 'requests.post.content'
        requests_

# Generated at 2022-06-25 18:27:49.513588
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # TODO implement this test
    pass


# Generated at 2022-06-25 18:27:51.731201
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_case_0()


# Generated at 2022-06-25 18:27:56.009106
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    int_0 = 1
    i_t_e_r_0 = h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:28:12.232636
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    assert list(h_t_t_p_request_0.iter_body(1)) == [b'']



# Generated at 2022-06-25 18:28:14.626504
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    int_0 = 0
    output = h_t_t_p_request_0.iter_body(int_0)
    assert output is not None
    assert len(output) == 0


# Generated at 2022-06-25 18:28:20.266527
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    chunk_size_int_0 = 0
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    #   Verify that h.iter_lines(chunk_size) raises an exception.
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(chunk_size=chunk_size_int_0)


# Generated at 2022-06-25 18:28:23.652867
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:28:26.271514
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    i_n_t_variable_0 = 1
    method_iter_body_0 = h_t_t_p_message_0.iter_body(i_n_t_variable_0)


# Generated at 2022-06-25 18:28:34.917933
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    content_0 = ( 2, b'abcdefghijklmnopqrstuvwxyz')
    bytes_0 = bytearray()
    bytes_0.extend(content_0)
    content_1 = ( 8192, bytes_0)
    content_2 = ( 1, b'0')
    content_3 = ( 1, b'1')
    content_4 = ( 1, b'2')
    content_5 = ( 1, b'3')
    content_6 = ( 1, b'4')
    content_7 = ( 1, b'5')
    content_8 = ( 1, b'6')
    content_9 = ( 1, b'7')
    content_10 = ( 1, b'8')
    content_11 = ( 1, b'9')

# Generated at 2022-06-25 18:28:38.160790
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest(
        requests.Request(
            'POST',
            url='http://example.com/',
            headers={'Content-Type': 'application/json'},
            data='{"name": "Frank"}'
        )
    )
    n = 0
    for chunk in req.iter_body(chunk_size=1):
        assert len(chunk) == 1
        n += 1
    assert n == 17


# Generated at 2022-06-25 18:28:45.885727
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    data_0 = {'Set-Cookie': 'session=abcdefghi', 'Content-Type': 'text'}
    response_0 = requests.get('http://localhost/api/status', headers=data_0)
    h_t_t_p_response_0 = HTTPResponse(response_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:28:49.543467
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    str_0 = str()
    str_1 = str()
    assert h_t_t_p_request_0.iter_lines(str_0) == h_t_t_p_request_0.iter_lines(str_1)


# Generated at 2022-06-25 18:28:52.842724
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = dict()
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    int_0 = 5
    HTTPRequest.iter_body(h_t_t_p_request_0, int_0)


# Generated at 2022-06-25 18:29:02.007942
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(set())
    yield h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:08.329831
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    h_t_t_p_request_0 = HTTPRequest(set_0)
    chunk_size = 1234567890
    # Tests of the method iter_lines of class HTTPMessage
    assert isinstance(h_t_t_p_message_0.iter_lines(chunk_size), Iterable)
    # Tests of the method iter_lines of class HTTPRequest
    assert isinstance(h_t_t_p_request_0.iter_lines(chunk_size), Iterable)


# Generated at 2022-06-25 18:29:11.532878
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    h_t_t_p_message_1 = HTTPResponse(h_t_t_p_message_0)
    h_t_t_p_message_1.iter_lines(1)

# Generated at 2022-06-25 18:29:19.387164
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = "1\r\n2\r\n3\n4\n5\r6\r\n"
    bytes_0 = str_0.encode('utf8')
    
    request_0 = Request( 
    "http://data.pr4e.org/page1.htm", bytes_0, headers={"Content-Type":"text/html"})
    
    # Test the case when the body contains all the line endings
    req = HTTPRequest(request_0)
    req_iter = req.iter_lines(len(str_0) + 1)
    for i in range(1, 7):
        line, _ = req_iter.__next__()
        exp = str(i).encode('utf8')
        assert line is not None
        assert line == exp
        assert line is not exp

# Generated at 2022-06-25 18:29:30.362240
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)

# Generated at 2022-06-25 18:29:34.152646
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:40.324975
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    test_HTTPRequest_iter_lines_0 = HTTPRequest(h_t_t_p_message_0)
    test_HTTPRequest_iter_lines_0.iter_lines(None)


# Generated at 2022-06-25 18:29:49.322740
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    from requests.models import Response
    from io import BytesIO

    response = Response()
    response.request = response.request
    response.status_code = 200
    response.reason = 'OK'
    response.encoding = 'utf8'

    content = 'a\nb\nc'
    response.raw = BytesIO(content.encode('utf8'))
    response.raw.read = response.raw.read

    try:
        h_t_t_p_response_0 = HTTPResponse(response)
    except:
        return

    # Test iter_lines
    h_t_t_p_response_0.iter_lines(1)

    # Test iter_lines
    h_t_t_p_response_0.iter_lines(1)

    # Test iter_lines
    h

# Generated at 2022-06-25 18:29:52.195016
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # test_HTTPRequest_iter_lines()
    # assert HTTPRequest.iter_lines() == ...
    raise NotImplementedError()


# Generated at 2022-06-25 18:30:01.135497
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_response_0)
    h_t_t_p_response_1 = HTTPResponse(h_t_t_p_request_0)
    h_t_t_p_response_1.iter_lines(h_t_t_p_request_0)


# Generated at 2022-06-25 18:30:21.892586
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """ Unit test for method iter_lines of class HTTPRequest """
    try:
        set_1 = set()
        h_t_t_p_request_0 = HTTPRequest(set_1)
        chunk_size = 1
        h_t_t_p_message_0 = HTTPMessage.iter_lines(h_t_t_p_request_0, chunk_size)
    except Exception:
        import traceback
        traceback.print_exc()


# Generated at 2022-06-25 18:30:27.021208
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    iter_lines_0 = h_t_t_p_response_0.iter_lines(23)
    # Testing the exception
    try:
        iter_lines_0.__iter__()
    except RuntimeError as e:
        print(str(e))


# Generated at 2022-06-25 18:30:33.223848
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)

    # Method iter_lines of class HTTPResponse
    iter_0 = h_t_t_p_response_0.iter_lines(1)
    next_0 = next(iter_0)
    next_1 = next(iter_0)
    next_2 = next(iter_0)
    next_3 = next(iter_0)
    next_4 = next(iter_0)


# Generated at 2022-06-25 18:30:37.895439
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_1 = set()
    h_t_t_p_response_0 = HTTPResponse(set_1)
    assert h_t_t_p_response_0.iter_lines(1) is not None and h_t_t_p_response_0.iter_lines(1) is not None



# Generated at 2022-06-25 18:30:42.586150
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(tuple())
    # In Python 3.7, this function call should be replaced by 
    # h_t_t_p_response_0.iter_lines()
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:30:51.196373
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Pre-condition
    # Create a HTTPResponse instance with the following parameters:
    set_0 = set()
    http_response_0 = HTTPResponse(set_0)
    int_0 = 0
    # Expected result:
    #   An iterator returning all the lines in the response body, followed by b'\n'
    # Post-condition
    # Call the iter_lines method with the following parameters:
    #   http_response_0 (instance of HTTPResponse)
    #   int_0 (instance of int)
    # The result should be the following:
    #   An iterator returning all the lines in the response body, followed by b'\n'
    assert http_response_0.iter_lines(int_0) == set_0.iter_lines(int_0)


# Generated at 2022-06-25 18:30:54.140932
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert callable(HTTPResponse.iter_lines)


# Generated at 2022-06-25 18:30:59.344119
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response_0 = HTTPResponse(set())
    str_0 = response_0.headers
    str_0 = response_0.encoding
    bytes_0 = response_0.body
    str_0 = response_0.content_type
    for _ in response_0.iter_body(1):
        pass
    for _ in response_0.iter_lines(1):
        pass


# Generated at 2022-06-25 18:31:06.008378
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    chunk_size = 0
    h_t_t_p_response_1 = HTTPResponse(set_0)
    h_t_t_p_response_1.iter_lines(chunk_size)


# Generated at 2022-06-25 18:31:12.518807
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = str()
    str_1 = str()
    dict_0 = dict()
    dict_0['Host'] = str_0
    dict_0['encoding'] = str_1
    dict_0['Connection'] = 'Keep-Alive'
    int_0 = int()
    set_0 = {int_0, dict_0}
    hTTPResponse_0 = HTTPResponse(set_0)
    set_0 = {int_0}
    hTTPRequest_0 = HTTPRequest(set_0)


# Generated at 2022-06-25 18:31:27.923058
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    class_0 = HTTPRequest(set())

    # The call to iter_lines() is just to exercise the function
    # No assertions here.
    try:
        class_0.iter_lines(1)
    except NotImplementedError:
        pass

# Generated at 2022-06-25 18:31:39.739367
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    request_0 = HTTPRequest(set_0)
    set_0 = set()
    bytes_0 = bytes(set_0)
    int_0 = int(bytes_0)
    list_0 = list()
    bytes_0 = bytes(list_0)
    int_1 = int(bytes_0)
    b'' == bytes_0
    bytes_0 == b''
    # Exception raised
    try:
        for i_0, i_1 in request_0.iter_lines(int_1):
            pass
    except NotImplementedError:
        pass
    # Exception raised
    try:
        for i_0, i_1 in request_0.iter_lines(int_0):
            pass
    except NotImplementedError:
        pass

# Generated at 2022-06-25 18:31:40.502047
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert True


# Generated at 2022-06-25 18:31:50.646998
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(csv_0)
    line_feed_1 = 0
    def iter_lines_0():
        while True:
            yield b'', b'\r\n'
    iter_lines_1 = iter_lines_0()
    line_feed_0 = b'\n'
    def iter_lines_1():
        while True:
            yield b'\r\n', b'\r\n'
    iter_lines_0 = iter_lines_1()
    a_r_r_0 = h_t_t_p_response_0.iter_lines(0)
    for line_feed_2 in a_r_r_0:
        i_f_0 = line_feed_2
        i_f_0 = line_

# Generated at 2022-06-25 18:31:51.922050
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    assert False, "Not yet implemented"


# Generated at 2022-06-25 18:31:57.472901
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    strings = ('a', 'c', 'd')
    def str_func(s): return (s + 'b')

    it = map(str_func, strings)
    it = list(it)
    try:
        assert 'ab' in it
    except Exception:
        pass

    strings.remove('b')
    for s in strings:
        try:
            assert 'b' not in s
        except Exception:
            break


# Generated at 2022-06-25 18:31:59.223215
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Iterable[tuple[bytes, bytes]]
    pass


# Generated at 2022-06-25 18:32:05.814509
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    int_0 = h_t_t_p_response_0.iter_lines(int())


# Generated at 2022-06-25 18:32:09.786199
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    int_0 = 1
    iter_lines_0 = h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:32:18.637713
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from io import BytesIO
    from struct import pack
    from typing import List, Optional
    h_t_t_p_request_0 = HTTPRequest({'key': 'value'})
    # An example of a response body

# Generated at 2022-06-25 18:32:48.417179
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_6 = set()
    h_t_t_p_message_4 = HTTPMessage(set_6)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_4)
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_response_0)

    h_t_t_p_request_0.iter_lines()



# Generated at 2022-06-25 18:32:50.859340
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    message_1 = HTTPRequest('foo')
    message_1.body = 'bar'
    lines = list(HTTPRequest(message_1).iter_lines(1))
    assert lines == [('bar', '')]


# Generated at 2022-06-25 18:32:56.528683
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_0 = set()
    h_t_t_p_request_0 = HTTPRequest(set_0)
    chunk_size = -1
    # Test the first branch of the if condition in the method
    assert h_t_t_p_request_0.iter_lines(chunk_size) == [b'', b'']


# Generated at 2022-06-25 18:32:58.894146
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_HTTPResponse_iter_lines_0()


# Generated at 2022-06-25 18:33:01.658178
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Test for method iter_lines of class HTTPRequest
    req = HTTPRequest(requests.Request(url='http://example.com', method='GET'))
    req.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:33:03.883408
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    set_1 = set()
    h_t_t_p_request_0 = HTTPRequest(set_1)

    h_t_t_p_request_0.iter_lines()


# Generated at 2022-06-25 18:33:09.064722
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    try:
        h_t_t_p_request_0 = HTTPRequest(tuple())
        for l in h_t_t_p_request_0.iter_lines(int()):
            pass
    except TypeError:
        pass



# Generated at 2022-06-25 18:33:10.810808
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_HTTPRequest_iter_lines_0 = HTTPRequest(BASE_REQUEST, )
    test_HTTPRequest_iter_lines_0.iter_lines()




# Generated at 2022-06-25 18:33:13.005709
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    http_request_0 = HTTPRequest(str())
    assert isinstance(http_request_0.iter_lines(1), Iterable)

# Generated at 2022-06-25 18:33:23.534472
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import BytesIO

    body = b'Hello World'
    response = HTTPResponse(requests.Response())
    response._orig.raw = BytesIO(body)
    response._orig.status_code = 200
    response._orig.encoding = 'ascii'

    it = response.iter_lines(chunk_size=3)
    assert next(it) == (b'Hel', b'\n')
    assert next(it) == (b'lo ', b'\n')
    assert next(it) == (b'Wor', b'\n')
    assert next(it) == (b'ld', b'')
    try:
        next(it)
    except StopIteration:
        pass



# Generated at 2022-06-25 18:33:52.564989
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_1 = set()
    h_t_t_p_response_0 = HTTPResponse(set_1)
    h_t_t_p_response_1 = HTTPResponse(h_t_t_p_response_0)
    h_t_t_p_response_0.iter_lines(0)
    h_t_t_p_response_1.iter_lines(1)


# Generated at 2022-06-25 18:33:56.724358
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Given
    set_1 = set()
    h_t_t_p_response_0 = HTTPResponse(set_1)
    # When
    iter_lines_0 = h_t_t_p_response_0.iter_lines(0)
    # Then
    assert(False)


# Generated at 2022-06-25 18:34:00.727659
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    assert h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:34:03.180823
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    file_0 = str()
    response_0 = HTTPResponse(file_0)
    result = response_0.iter_lines()
    assert isinstance(result, Iterable)


# Generated at 2022-06-25 18:34:08.837426
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Initialize
    lst0 = [1, 2, 3]
    inp0 = bytes(lst0)

    h_t_t_p_response_0 = HTTPResponse(inp0)
    ret0 = h_t_t_p_response_0.iter_lines(None)
    assert ret0 == lst0



# Generated at 2022-06-25 18:34:17.126038
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print("running Test: test_HTTPResponse_iter_lines")

    chunk_size = 1
    HTTPResponse.iter_lines(self, chunk_size)

    # Test random inputs & output
    a = HTTPResponse(3776)
    assert(a.iter_lines(chunk_size) == False)

    a = HTTPResponse(True)
    assert(a.iter_lines(chunk_size) == True)

    a = HTTPResponse(None)
    assert(a.iter_lines(chunk_size) == False)

    print("Finished Test: test_HTTPResponse_iter_lines")


# Generated at 2022-06-25 18:34:25.744544
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    import http_utils
    import requests_mock
    import urllib3
    import certifi
    import urllib3.contrib.pyopenssl
    urllib3.contrib.pyopenssl.inject_into_urllib3()
    import pyopenssl
    pyopenssl.suppress_ragged_eofs()
    import chardet
    import idna
    import idna.core

    # Make an HTTP request to get a response
    set_0 = set()

    with requests_mock.Mocker() as m:
        # Mock an HTTP response to parse
        m.get('https://www.google.com', text='Successful response!')
        response = requests.get('https://www.google.com')

    # Create a response object
    response_obj = HT

# Generated at 2022-06-25 18:34:30.074266
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test case 0:
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    iter_0 = h_t_t_p_response_0.iter_lines(1)
    assert isinstance(iter_0, Iterable)


# Generated at 2022-06-25 18:34:34.331172
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_message_0 = HTTPMessage(set_0)

    requests_0 = requests.Request(method='POST', url='http://hyperlinkcode.com/http-status-codes.php')
    http_request_0 = HTTPRequest(requests_0)
    http_request_0.iter_lines(chunk_size=3)



# Generated at 2022-06-25 18:34:42.647532
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    import io

    res = requests.Response()
    res.content = b'foo\nbar'
    res.encoding = 'utf8'
    res._content_consumed = True

    resp = HTTPResponse(res)
    assert list(resp.iter_lines(5)) == [(b'foo\n', b'\n'), (b'bar', b'')]

    # Test for empty response
    res = requests.Response()
    res.content = b''
    res._content_consumed = True
    resp = HTTPResponse(res)
    assert list(resp.iter_lines(5)) == [(b'', b'')]

    # Test for empty response with chunk size > 1
    res = requests.Response()
    res.raw = io.BufferedReader(io.BytesIO())


# Generated at 2022-06-25 18:35:37.774159
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    chunk_size_0 = int()
    h_t_t_p_response_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:35:45.202839
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)

    array_0 = ['div', 'cont']
    i_0 = 0
    for line, line_feed in h_t_t_p_response_0.iter_lines(array_0[i_0]):
        print(f'{line=} {line_feed} {line_feed=}')

    print(f'{h_t_t_p_response_0.encoding=}')
    print(f'{h_t_t_p_response_0.content_type=}')


if __name__ == "__main__":
    # test_HTTPResponse_iter_lines()
    pass

# Generated at 2022-06-25 18:35:47.697444
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    set_0 = set()
    h_t_t_p_response_0 = HTTPResponse(set_0)
    h_t_t_p_response_0.iter_lines(chunk_size = 0)


# Generated at 2022-06-25 18:35:54.809503
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # noinspection PyProtectedMember
    response = requests.Response()
    response._content = b'Hello\nWorld\n'
    response._content_consumed = False
    response.raw._original_response.status = 200
    response.raw._original_response.reason = 'OK'
    response.raw._original_response.version = 11
    response.raw._original_response.msg._headers = (
        ('Content-Type', 'text/plain; charset=utf-8'),
    )
    http_response_0 = HTTPResponse(response)
    h_t_t_p_message_0 = HTTPMessage(http_response_0)
    http_response_0 = HTTPResponse(h_t_t_p_message_0)