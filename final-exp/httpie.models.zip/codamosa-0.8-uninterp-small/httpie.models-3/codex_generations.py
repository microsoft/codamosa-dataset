

# Generated at 2022-06-25 18:26:07.037436
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    HTTPRequest_0 = HTTPRequest(dict_0)
    HTTPRequest_0.iter_body(1)


# Generated at 2022-06-25 18:26:10.882348
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(int_0_0)


# Generated at 2022-06-25 18:26:13.706508
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = []
    args_0 = [dict_0]
    if __name__ == '__main__':
        HTTPResponse._orig.iter_lines(dict_0)


# Generated at 2022-06-25 18:26:21.573083
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {
        "method": "OPTIONS",
    }
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    chunk_size_0 = 1
    iter_lines_0 = h_t_t_p_request_0.iter_lines(chunk_size_0)
    assert iter_lines_0 == None


# Generated at 2022-06-25 18:26:26.469354
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    new_iter = h_t_t_p_response_0.iter_lines(10)
    assert h_t_t_p_response_0.iter_lines(10) is new_iter
    assert list(new_iter) is not []


# Generated at 2022-06-25 18:26:32.362438
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_response_0)
    # int_0 = h_t_t_p_request_0.iter_lines(1)
    # assert int_0 == 1


# Generated at 2022-06-25 18:26:37.664014
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    int_0 = 1
    h_t_t_p_request_0.iter_body(int_0)
    str_0 = ""
    h_t_t_p_request_0.headers
    str_1 = "utf8"
    str_0 = h_t_t_p_request_0.encoding
    int_1 = len(str_1)
    int_2 = len(str_0)
    assert int_1 == int_2


# Generated at 2022-06-25 18:26:40.829213
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 18:26:44.649720
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Test for iter_lines of class HTTPResponse."""
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    # AssertionError: Expected not to raise an exception.


# Generated at 2022-06-25 18:26:48.407073
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    max_0 = random.randint(0, 100)
    for chunk in h_t_t_p_request_0.iter_lines(chunk_size=max_0):
        pass


# Generated at 2022-06-25 18:27:05.750443
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    # Iterator[bytes]
    dict_1 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_1)
    for val_0, val_1 in zip(h_t_t_p_request_0.iter_body(), h_t_t_p_response_0.iter_body()):
        pass
    assert True


# Generated at 2022-06-25 18:27:13.169716
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    # `assert_raises` on Python 2.6 requires a callable as its second
    # argument, but on Python 2.7+ it requires an exception class.
    try:
        h_t_t_p_request_0.iter_lines()
        assert False
    except NotImplementedError:
        pass



# Generated at 2022-06-25 18:27:18.075169
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """Check HTTPRequest.iter_lines returns the expected output"""
    h_t_t_p_response_0 = HTTPResponse({})
    sys.argv.append(h_t_t_p_response_0)
    h_t_t_p_request_0 = HTTPRequest(str)
    assert h_t_t_p_request_0.iter_lines({}) == {}


# Generated at 2022-06-25 18:27:23.889863
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {'Content-Type': 'text/html; charset=iso-8859-1'}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_body(1)
    # TODO: Improve on this test
    return None


# Generated at 2022-06-25 18:27:27.551692
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    iter_body_0 = h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:27:29.305344
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert iter(HTTPResponse({}).iter_lines(1)) is not None


# Generated at 2022-06-25 18:27:38.957068
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_1 = HTTPRequest(dict_0)
    dict_1 = {}
    h_t_t_p_request_1._orig = dict_1
    str_0 = '\xFF'
    str_1 = '\xFF'
    h_t_t_p_request_1._orig['body'] = str_0
    h_t_t_p_request_1._orig['encoding'] = str_1
    h_t_t_p_request_1._orig['headers'] = {}
    h_t_t_p_request_1._orig['method'] = 'GET'
    h_t_t_p_request_1._orig['url'] = 'http://localhost'
    int_0 = 0

# Generated at 2022-06-25 18:27:47.342223
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    dict_1 = {}
    h_t_t_p_response_1 = HTTPResponse(dict_1)
    dict_2 = {}
    h_t_t_p_response_2 = HTTPResponse(dict_2)
    dict_3 = {}
    h_t_t_p_response_3 = HTTPResponse(dict_3)
    dict_4 = {}
    h_t_t_p_response_4 = HTTPResponse(dict_4)
    dict_5 = {}
    h_t_t_p_response_5 = HTTPResponse(dict_5)
    dict_6 = {}
    h_t_t

# Generated at 2022-06-25 18:27:51.309750
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(chunk_size=0)


# Generated at 2022-06-25 18:27:54.928667
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(int_0=1)


# Generated at 2022-06-25 18:28:26.467140
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    # Test on an empty HTTP Response
    list_0 = []
    for _ in h_t_t_p_response_0.iter_lines(10):
        list_0.append(1)
    assert len(list_0) == 0




# Generated at 2022-06-25 18:28:35.115767
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    test_iter_body_0 = h_t_t_p_request_0.iter_body(1)
    test_iter_body_1 = h_t_t_p_request_0.iter_body(2)
    test_iter_body_2 = h_t_t_p_request_0.iter_body(3)
    test_iter_body_3 = h_t_t_p_request_0.iter_body(4)
    test_iter_body_4 = h_t_t_p_request_0.iter_body(5)
    test_iter_body_5 = h_t_t_p_request_0.iter_body(6)
    test_

# Generated at 2022-06-25 18:28:41.942792
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    dict_1 = {}
    dict_0["request_0"] = dict_1
    dict_1["_orig"] = dict_0
    dict_1["chunk_size"] = BYTE_0x00
    dict_1["body"] = bytes_0x00
    dict_1["headers"] = dict_0
    dict_1["encoding"] = None
    request_0 = HTTPRequest(dict_1)
    result = request_0.iter_body(BYTE_0x00)
    assert result is not None
    assert id(result) != id(dict_1["_orig"]["request_0"]["headers"]["_orig"]["request_0"])

# Generated at 2022-06-25 18:28:46.529084
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    try:
        h_t_t_p_response_0.iter_lines(1)
        raise RuntimeError("Failed")
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:28:50.225569
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    r = h_t_t_p_request_0.iter_lines(1)
    for line in r:
        print(line)


# Generated at 2022-06-25 18:28:51.139047
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert True


# Generated at 2022-06-25 18:28:52.287358
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 18:28:58.211938
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    # setup
    test_HTTPRequest_iter_body_request_0 = requests.get('http://example.com/')

    # expected

# Generated at 2022-06-25 18:29:00.819688
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    print(h_t_t_p_request_0.iter_lines(1))


# Generated at 2022-06-25 18:29:03.979196
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    for bs in h_t_t_p_request_0.iter_body(1024):
        assert bs[-1] == 0



# Generated at 2022-06-25 18:29:36.368346
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)

    assert list(h_t_t_p_request_0.iter_lines(0)) == [(b'', b'')]



# Generated at 2022-06-25 18:29:39.717109
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    http_request_0 = HTTPRequest(dict_0)
    http_request_0.iter_lines(dict_0)


# Generated at 2022-06-25 18:29:43.396788
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():

    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    chunk_size_0 = 1
    iterable_0 = h_t_t_p_request_0.iter_body(chunk_size_0)


# Generated at 2022-06-25 18:29:53.418543
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Input arguments
    chunk_size = 1
    # Output arguments
    b_y_t_e_s_0 = b'bytes'
    # Additional arguments
    headers = b'headers'
    method = b'method'
    url = b'url'
    _dict_0 = {'headers': headers, 'method': method, 'url': url}
    _request_0 = HTTPRequest(_dict_0)
    # Call method
    _iter_0 = _request_0.iter_lines(chunk_size)
    _iter_1 = iter(_iter_0)
    b_y_t_e_s_1, b_y_t_e_s_2 = next(_iter_1)


# Generated at 2022-06-25 18:29:55.641823
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    assert 0 == 0


# Generated at 2022-06-25 18:30:01.828527
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    # Value of the str parameter of iter_lines is not checked, so just make up an arbitrary value
    str_0 = "An arbitrary string"
    # TODO: Should check if the str parameter is passed properly to the method
    iter_0 = h_t_t_p_request_0.iter_lines(str_0)
    # Broken: Iterator is not checked here


# Generated at 2022-06-25 18:30:05.892508
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    xd_0 = {}
    h_t_t_p_request_0 = HTTPRequest(xd_0)
    instanciator0 = h_t_t_p_request_0.iter_body(0)
    for v_i_0 in instanciator0:
        assert isinstance(v_i_0, bytes)
        print(v_i_0)
        break


# Generated at 2022-06-25 18:30:16.727025
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    c_0 = 0
    # String data
    s_0 = 'chunk_size'
    # String data
    s_1 = 'chunk_size'
    dict_1 = {}
    dict_1[s_0] = s_1
    # String data
    s_2 = 'method'
    # String data
    s_3 = 'method'
    dict_1[s_2] = s_3
    # String data
    s_4 = 'body'
    # String data
    s_5 = 'body'
    dict_1[s_4] = s_5
    # String data
    s_6 = 'headers'
    # String data

# Generated at 2022-06-25 18:30:19.094347
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)


# Generated at 2022-06-25 18:30:22.364013
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = { }
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    assert True


# Generated at 2022-06-25 18:30:48.633674
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 1
    expected_result = dict_0
    h_t_t_p_response_0.iter_lines()
    assert h_t_t_p_response_0.iter_lines() == expected_result


# Generated at 2022-06-25 18:30:49.439471
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    test_case_0()


# Generated at 2022-06-25 18:30:52.157543
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    for i in range(10):
        assert h_t_t_p_request_0.iter_body(i)


# Generated at 2022-06-25 18:30:56.659593
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    int_0 = 1
    for _ in h_t_t_p_request_0.iter_body(int_0):
        pass



# Generated at 2022-06-25 18:30:58.390044
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(int(1))


# Generated at 2022-06-25 18:31:02.195101
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    assert next(h_t_t_p_request_0.iter_body(1)) == b''


# Generated at 2022-06-25 18:31:08.340804
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # x is a HTTPResponse
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    assert h_t_t_p_response_0.iter_lines(chunk_size=3)


# Generated at 2022-06-25 18:31:12.819716
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # See `test_HTTPRequest.json`
    request = {
        "body": b"{\"a\":1}\n",
        "headers": {},
        "method": "GET",
        "url": "http://localhost:80/",
    }
    http_request_0 = HTTPRequest(request)
    chunk_size = 1
    for body_0 in http_request_0.iter_body(chunk_size):
        pass


# Generated at 2022-06-25 18:31:16.615721
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Setup
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    # Testing
    h_t_t_p_response_0.iter_lines(chunk_size=1)

    # Teardown
    # No cleanup needed


# Generated at 2022-06-25 18:31:20.355316
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_body()


# Generated at 2022-06-25 18:31:43.705716
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 10
    assert h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:31:47.638409
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(0)
    test_case_0()

# Generated at 2022-06-25 18:31:54.336641
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    print("Calling getattr(h_t_t_p_response_0, 'body')")
    print(getattr(h_t_t_p_response_0, 'body'))
    print("Calling h_t_t_p_response_0.iter_lines(1)")
    for i_0 in h_t_t_p_response_0.iter_lines(1):
        print(i_0)
        print("Calling getattr(h_t_t_p_response_0, 'body')")
        print(getattr(h_t_t_p_response_0, 'body'))

# Generated at 2022-06-25 18:31:58.658621
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    chunk_size_0 = 1
    v_0 = h_t_t_p_response_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:32:08.291935
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    out = StringIO()
    for (line, line_feed) in h_t_t_p_response_0.iter_lines(1):
        out.write(line.decode(h_t_t_p_response_0.encoding))
        out.write(line_feed.decode(h_t_t_p_response_0.encoding))
    expected = ''
    if expected != out.getvalue():
        raise Exception('AssertionError')


# Generated at 2022-06-25 18:32:10.781588
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:13.050341
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(0)



# Generated at 2022-06-25 18:32:17.255100
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    chunk_size = 1
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    for line, line_feed in h_t_t_p_response_0.iter_lines(chunk_size):
        print(line, line_feed)


# Generated at 2022-06-25 18:32:22.720695
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    chunk_size_0 = 42
    actual = h_t_t_p_response_0.iter_lines(chunk_size_0)
    expected = (
        (line, b'\n') for line in dict_0.iter_lines(chunk_size_0=chunk_size_0)
    )
    assert actual == expected



# Generated at 2022-06-25 18:32:33.008865
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    # Test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:32:49.900592
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    chunk_size = 1
    assert h_t_t_p_response_0.iter_lines(chunk_size)


# Generated at 2022-06-25 18:32:52.352177
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    assert ~(list(h_t_t_p_response_0.iter_lines(1)) == [])


# Generated at 2022-06-25 18:33:03.316648
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    def lambda_0():
        for line_feed in h_t_t_p_response_0.iter_lines(1):
            print(line_feed)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p

# Generated at 2022-06-25 18:33:11.776459
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    def func(self):
        assert False
        return None

    def test_case_0():
        str_0 = 'test'
        int_0 = 1
        slice_0 = slice(int_0, int_0, int_0)
        bytes_0 = b''
        iterable_0 = [bytes_0, bytes_0]
        iterable_1 = iterable_0
        tuple_0 = (iterable_0, slice_0)
        tuple_1 = tuple_0
        h_t_t_p_response_0 = HTTPResponse(dict_0)

    def test_case_1():
        str_0 = 'test'
        int_0 = 1
        slice_0 = slice(int_0, int_0, int_0)
        bytes_0 = b''
        bytes

# Generated at 2022-06-25 18:33:23.080168
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    # The first statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The second statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The third statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The fourth statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The fifth statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The sixth statement in the function is a call to the iter method of a generator.
    # NOP on generators
    # The seventh statement in

# Generated at 2022-06-25 18:33:24.726628
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)


# Generated at 2022-06-25 18:33:30.950589
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(5)


# Generated at 2022-06-25 18:33:34.083202
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:37.891093
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:41.037752
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    iter_lines_0 = h_t_t_p_response_0.iter_lines(dict_0)
    value_0_0 = type(iter_lines_0)
    assert isinstance(value_0_0, Iterable)


# Generated at 2022-06-25 18:34:09.371469
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    assert h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:34:12.746033
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(int())


# Generated at 2022-06-25 18:34:16.749151
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

# Generated at 2022-06-25 18:34:17.417554
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:34:21.556352
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    logger.info('Test of method iter_lines of class HTTPResponse')
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    test_case_0()


if __name__ == '__main__':
    test_HTTPResponse_iter_lines()

# Generated at 2022-06-25 18:34:25.078374
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    chunk_size_0 = 10
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    assert isinstance(h_t_t_p_response_0.iter_lines(chunk_size_0), Iterable)


# Generated at 2022-06-25 18:34:28.444315
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 0
    list_str_0 = [h_t_t_p_response_0.iter_lines(int_0)]


# Generated at 2022-06-25 18:34:31.715558
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:34:34.158532
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:34:39.034098
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # Set up test data
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    # Call tested method
    result = h_t_t_p_response_0.iter_lines(chunk_size=12)

    # Check test results
    assert isinstance(result, bytes),\
    "Unexpected type of the tested method result"


# Generated at 2022-06-25 18:35:42.827342
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 1
    list_0 = list(h_t_t_p_response_0.iter_lines(int_0))
    list_1 = []
    assert(list_0 == list_1)


# Generated at 2022-06-25 18:35:47.658224
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    http_response_0 = HTTPResponse()
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0 = HTTPResponse()
    for h_t_t_p_message_0 in h_t_t_p_response_0.iter_lines(chunk_size_0):
        print(h_t_t_p_message_0)


# Generated at 2022-06-25 18:35:51.348926
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = {}
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    assert isinstance(h_t_t_p_response_0._orig, Response)
