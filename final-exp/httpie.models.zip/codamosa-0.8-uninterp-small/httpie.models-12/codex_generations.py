

# Generated at 2022-06-25 18:26:11.170285
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    list_0 = []
    h_t_t_p_message_0 = HTTPMessage(list_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:26:15.109108
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    http_request_0 = HTTPRequest(list_0)
    list_1 = []
    http_request_1 = HTTPRequest(list_1)
    # TODO: "assert ''.join(map(str, http_request_0.iter_lines())) == ''".format(): do not know how to format the repr


# Generated at 2022-06-25 18:26:22.535736
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Sample test for method `iter_lines` of class `HTTPResponse`."""
    # Build a dummy object for testing
    list_1 = []
    h_t_t_p_response_0 = HTTPResponse(list_1)
    # Call the method under test
    result = h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:26:25.571393
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest('GET http://www.httpbin.org/ HTTP/1.1')
    for line, _ in req.iter_lines(chunk_size=16):
        print("line='{}'".format(line))


# Generated at 2022-06-25 18:26:29.845628
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Test body
    http_message_0 = HTTPResponse()
    # AssertionError: None
    try:
        # Test body
        http_message_1 = HTTPMessage()
        http_message_1.iter_lines()
    except AssertionError:
        pass


# Generated at 2022-06-25 18:26:36.476062
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    change_0 = '<script>alert(1)</script>'
    list_0 = ['Content-Type: text/html', change_0]
    h_t_t_p_request_0 = HTTPRequest(list_0)
    list_1 = []
    h_t_t_p_response_0 = HTTPResponse(list_1)
    assert h_t_t_p_request_0.iter_lines(1) == h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:26:41.105405
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    http_request_0 = HTTPRequest(list_0)
    int_0 = randint(-2147483648, 2147483647)
    iter_lines_0 = http_request_0.iter_lines(int_0)


# Generated at 2022-06-25 18:26:48.125389
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():

    # Test case with url=https://github.com/sqreen/sqreen-sdk-python
    url_0 = "https://github.com/sqreen/sqreen-sdk-python"
    request_0 = requests.Request(url=url_0)
    prepared_request_0 = request_0.prepare()
    HTTPRequest_0 = HTTPRequest(prepared_request_0)
    h_t_t_p_response_0 = HTTPRequest_0.iter_lines()
    assert_equal(h_t_t_p_response_0, None)


# Generated at 2022-06-25 18:26:55.328730
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    http_request_0 = HTTPRequest(list_0)

    assert http_request_0.iter_lines(None) is not None

    http_request_0.body = b'test'
    assert http_request_0.iter_lines(None) is not None

    http_request_0.body = None
    assert http_request_0.iter_lines(None) is not None


# Generated at 2022-06-25 18:26:57.997417
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    h_t_t_p_message_0 = HTTPRequest(list_0)
    assert_equals(h_t_t_p_message_0.iter_lines(1), [])


# Generated at 2022-06-25 18:27:09.455304
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    a = HTTPRequest()
    chunk_size = 0
    a.iter_lines(chunk_size)


# Generated at 2022-06-25 18:27:18.578896
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    with HTTPMessage() as msg:
        assert ("http://example.com/index.html?q=1", "", "http", "example.com", "80",
                "/index.html", "q=1", "", "") == urlparse("http://example.com/index.html?q=1")
        assert ("http://example.com/index.html", "", "http", "example.com", "80", "/index.html",
                "", "", "") == urlparse("http://example.com/index.html")

# Generated at 2022-06-25 18:27:23.635959
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    original_response = ''
    h_t_t_p_response_0 = HTTPResponse(original_response)
    h_t_t_p_response_0.iter_lines(chunk_size=3)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:27:26.098230
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_request_0 = HTTPRequest()
    h_t_t_p_request_0.body = 'foo'
    it_body_0 = h_t_t_p_request_0.iter_body()
    assert 'foo' in it_body_0


# Generated at 2022-06-25 18:27:27.499265
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_0 = HTTPRequest()

# Generated at 2022-06-25 18:27:30.061430
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_message_0 = HTTPRequest()
    _iter_body_0 = h_t_t_p_message_0.iter_body()



# Generated at 2022-06-25 18:27:31.810147
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_request_0 = HTTPRequest()
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:27:33.894408
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0.iter_lines(7)


# Generated at 2022-06-25 18:27:36.997131
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:27:40.565452
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_request_0 = HTTPRequest(orig)
    # Failed to type-annotate the return value of HTTPRequest.iter_body()
    # h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:27:54.376341
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:27:57.357468
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    b_t_t_p_request_0 = HTTPRequest(list_0)
    string_0 = b_t_t_p_request_0.iter_lines("W8(v")



# Generated at 2022-06-25 18:27:59.418988
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Simple creation test
    r_0 = HTTPResponse._orig
    assert_equal(r_0.iter_lines, r_0.iter_lines)


# Generated at 2022-06-25 18:28:05.047152
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    # AssertionError: TypeError not raised
    with pytest.raises(TypeError):
        h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:28:09.634370
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    h_t_t_p_message_0 = HTTPRequest(list_0)
    chunk_size_0 = 1
    list_1 = [None]
    for _ in h_t_t_p_message_0.iter_body(chunk_size_0):
        list_1[0] += 1


# Generated at 2022-06-25 18:28:10.823048
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Execute operation

    # Verify operation
    assert True


# Generated at 2022-06-25 18:28:14.058038
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    hTTPResponse_0 = HTTPResponse(list_0)
    hTTPRequest_0 = HTTPRequest(hTTPResponse_0)
    test_HTTPRequest_iter_lines_0(hTTPRequest_0)


# Generated at 2022-06-25 18:28:19.478211
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(None)
    req._orig = Mock()
    req._orig.method = 'GET'
    req._orig.url = 'http://localhost:8080/path'
    req._orig.headers = {}
    req._orig.body = 'line 1\nline 2\nline 3\nline 4'
    req._orig.encoding = 'utf8'

    assert sum(1 for _ in req.iter_lines(10)) == 4


# Generated at 2022-06-25 18:28:20.926420
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:28:24.982614
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    h_t_t_p_respone_0 = HTTPResponse(list_0)


# Generated at 2022-06-25 18:28:50.377433
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():

    list_0 = [
        1,
        2,
        3,
        4,
        5
    ]

    h_t_t_p_message_0 = HTTPMessage(list_0)
    HTTPRequest_0 = HTTPRequest(h_t_t_p_message_0)

    # Field `_orig` of class `HTTPRequest` is assigned to an instance of class `HTTPMessage`
    if not hasattr(HTTPRequest_0._orig, 'body'):
        raise RuntimeError()

    if not hasattr(HTTPRequest_0._orig, 'headers'):
        raise RuntimeError()

    if not hasattr(HTTPRequest_0._orig, 'iter_content'):
        raise RuntimeError()

    if not hasattr(HTTPRequest_0._orig, 'iter_lines'):
        raise RuntimeError

# Generated at 2022-06-25 18:28:54.784493
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Test case from requests/models.py: 963
    body = b'Test'
    h_t_t_p_request_0 = HTTPRequest(body)
    for h_t_t_p_request_1 in h_t_t_p_request_0.iter_body(1):
        assert isinstance(
            body, bytes)
        break


# Generated at 2022-06-25 18:28:59.503568
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests

    response = requests.get('https://httpbin.org/get')

    http_response = HTTPResponse(response)

    for line, line_feed in http_response.iter_lines(2):
        print(line, line_feed)

    response.close()


# Generated at 2022-06-25 18:29:04.905498
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)

    assert tuple(h_t_t_p_request_0.iter_lines(1)) == ((b'',),)
    assert tuple(h_t_t_p_request_0.iter_lines(1)) == ((b'',),)
    assert isinstance(h_t_t_p_request_0.iter_lines(1)[0], tuple)


# Generated at 2022-06-25 18:29:12.580044
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    body = b'line1\nline2\n'
    request = HTTPRequest(HTTPRequest(body))

    lines = list(request.iter_lines(1))
    assert lines == [
        (b'line1\n', b'\n'),
        (b'line2\n', b'\n'),
    ]

    lines = list(request.iter_lines(len(body)))
    assert lines == [(body, b'')]



# Generated at 2022-06-25 18:29:18.930639
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    requests_0 = requests.Session()
    requests_0.url = 'https://httpbin.org/post'
    requests_0.method = 'POST'
    requests_0.headers['Content-Type'] = 'text/plain'
    requests_0.body = bytes(bytearray(range(256)))
    requests_0.headers['Host'] = 'httpbin.org'
    h_t_t_p_request_0 = HTTPRequest(requests_0)
    test_iter_body_0 = h_t_t_p_request_0.iter_body(1)


test_case_0()
test_HTTPRequest_iter_body()

# Generated at 2022-06-25 18:29:30.013287
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests

    r_0 = requests.Request(method='GET', url='http://test.test.test', params={})
    r_0.headers['Content-Type'] = 'text/html'
    r_0.headers['Content-Length'] = '3'
    r_0.body = "foo"
    h_t_t_p_request_0 = HTTPRequest(r_0)
    list_0 = h_t_t_p_request_0.iter_lines(1)
    value_0 = list_0.__next__()[0]
    value_1 = value_0.decode('utf8')
    assert value_1 == "foo"
    value_2 = list_0.__next__()
    assert_is_equal(value_2, StopIteration)


# Generated at 2022-06-25 18:29:41.705565
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Test the method iter_lines of class HTTPRequest
    print("Test the method iter_lines of class HTTPRequest")
    list_0 = []

    request_0 = requests.Request(
        'GET',
        'https://httpbin.org/get',
        headers={'User-Agent': 'http-kitty'},
    )
    prepared_request_0 = request_0.prepare()
    h_t_t_p_request_0 = HTTPRequest(prepared_request_0)
    print(h_t_t_p_request_0.encoding)
    print(h_t_t_p_request_0.iter_body(1))
    print(h_t_t_p_request_0.iter_lines(1))

# Generated at 2022-06-25 18:29:46.575341
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)
    h_t_t_p_request_0.iter_body(int_0)


# Generated at 2022-06-25 18:29:49.187855
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    http_request_0 = HTTPRequest(list_0)
    http_request_0.iter_body(0)


# Generated at 2022-06-25 18:30:04.902892
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)
    h_t_t_p_request_0.iter_body(5)



# Generated at 2022-06-25 18:30:11.183974
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # TODO: Improve unit test
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)
    h_t_t_p_message_0 = HTTPMessage(list_0)
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:30:18.384172
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_message_0 = HTTPMessage(list_0)
    list_1 = []
    h_t_t_p_response_0 = HTTPResponse(list_1)
    list_1.append(h_t_t_p_response_0)
    for i in h_t_t_p_response_0.iter_lines(1):
      print(i)
    list_2 = []
    h_t_t_p_response_1 = HTTPResponse(list_2)
    for i in h_t_t_p_response_1.iter_lines(0):
      print(i)
    list_3 = []

# Generated at 2022-06-25 18:30:27.567436
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = ['', '', 'b:a:d', 'c', 'a', 'b', 'a', 'b', 'c', 'd', '', 'a', '','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','a','b','c','d']
    h_t_t_p_response_0 = HTTPResponse(list_0)
    result = h_t_t_p_response_0.iter_lines(1)
    print(result)


# Generated at 2022-06-25 18:30:30.495256
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines(1)



# Generated at 2022-06-25 18:30:33.249529
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)
    print("Test case 0")
    #test case 0
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:30:38.285467
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:30:47.752897
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    byte_0 = b'\xaa\xaa'
    byte_1 = b'\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb'

# Generated at 2022-06-25 18:30:52.302639
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    with patch('requests.models.Request') as m_0, patch('requests.models.Response') as m_1:
        requests_request_0 = m_0.return_value = Request()
        requests_response_0 = m_1.return_value = Response()
        HTTPResponse(requests_response_0).iter_lines()
        requests_response_0.iter_lines.assert_called_once_with()



# Generated at 2022-06-25 18:31:02.099525
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Test if the response body is downloaded in chunks
    import os
    import responses

    url = 'https://example.com/big-file'
    fpath = os.path.join(os.path.dirname(__file__), 'big-file')
    with open(fpath, 'rb') as f:
        expected = f.read()
        responses.add(responses.GET, url, body=expected)

    response = requests.get(url)
    resp = HTTPRequest(response.request)
    chunks = list(resp.iter_body(chunk_size=16))
    assert len(chunks) == len(expected) // 16 + 1
    assert b''.join(chunks) == expected



# Generated at 2022-06-25 18:31:29.243972
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_1 = []
    h_t_t_p_request_0 = HTTPRequest(list_1)
    h_t_t_p_request_0.iter_body(1)


# Generated at 2022-06-25 18:31:30.124441
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    a = HTTPRequest(None)
    a.iter_body()



# Generated at 2022-06-25 18:31:33.253155
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Initial
    request_0 = HTTPRequest(requests.Request())
    # Body
    with pytest.raises(NotImplementedError):
        request_0.iter_body(chunk_size=1)


# Generated at 2022-06-25 18:31:37.809133
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    http_request_0 = HTTPRequest(list_0)
    http_request_0.iter_body
    try:
        http_request_0.iter_body(1)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:31:40.225131
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    HTTPRequest_0 = HTTPRequest(list)
    chunk_size_0 = int()
    iterable = HTTPRequest_0.iter_body(chunk_size_0)


# Generated at 2022-06-25 18:31:43.339820
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = []
    h_t_t_p_request_0 = HTTPRequest(list_0)
    assert h_t_t_p_request_0 != None



# Generated at 2022-06-25 18:31:49.408616
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_message_0 = HTTPMessage(list_0)
    list_1 = []
    h_t_t_p_response_0 = HTTPResponse(list_1)
    h_t_t_p_message_1 = HTTPMessage(list_0)
    h_t_t_p_response_0.iter_lines(int_0)
# expected output: None


# Generated at 2022-06-25 18:31:54.216348
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    http_response_0 = HTTPResponse(0)
    for line, line_feed in http_response_0.iter_lines(1):
        # None
        int(len(line))
        assert line_feed == b'\n'


# Generated at 2022-06-25 18:31:57.572972
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    list_0 = [1, 2, 3]
    h_t_t_p_message_0 = HTTPRequest(list_0)
    h_t_t_p_message_0.iter_body(100)


# Generated at 2022-06-25 18:32:09.461046
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    def test_case_1():
        list_0 = []
        h_t_t_p_response_0 = HTTPResponse(list_0)
        int_0 = 2
        gen_0 = h_t_t_p_response_0.iter_lines(int_0)
        list_1 = []
        list_1.append(gen_0)
        list_2 = []
        list_2.append(h_t_t_p_response_0)
        list_2.append(int_0)

    def test_case_2():
        list_0 = []
        h_t_t_p_response_0 = HTTPResponse(list_0)
        int_0 = 0

# Generated at 2022-06-25 18:33:07.406920
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    test_case_0()


# Generated at 2022-06-25 18:33:10.562146
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    list_1 = []
    h_t_t_p_response_0.iter_lines(list_1)


# Generated at 2022-06-25 18:33:15.757626
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_r_e_s_p_o_n_s_e_1 = HTTPResponse(0)
    h_t_t_p_r_e_s_p_o_n_s_e_0 = HTTPResponse(0)
    h_t_t_p_r_e_s_p_o_n_s_e_0.iter_lines(0)


# Generated at 2022-06-25 18:33:20.977136
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:22.393265
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    HTTPRequest('').iter_body(5)


# Generated at 2022-06-25 18:33:23.534547
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:33:32.486834
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    list_0_0 = []
    h_t_t_p_message_0 = h_t_t_p_response_0.iter_lines(list_0_0)
    for obj in h_t_t_p_message_0:
        pass


# Generated at 2022-06-25 18:33:34.770868
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    HTTPRequest.iter_body()

# Generated at 2022-06-25 18:33:38.165375
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b''
    req = HTTPRequest(object())
    req._orig.body = body
    chunks = list(req.iter_body(1024))
    assert chunks == [body]


# Generated at 2022-06-25 18:33:39.202180
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # No call to method iter_body()
    pass


# Generated at 2022-06-25 18:34:34.124538
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    request_1 = requests.get("http://httpbin.org")
    h_t_t_p_response_0 = HTTPResponse(request_1)
    # Create a list from the iterable
    list_0 = [x for x in h_t_t_p_response_0.iter_lines(1)]
    list_0_length = len(list_0)
    print(list_0_length)


# Generated at 2022-06-25 18:34:42.464314
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # This is an interesting one, it uses quite a lot of the utils implemented
    # in this class.
    request = requests.get('http://httpbin.org/post', data={'a': '1'},
                           headers={'User-Agent': 'test case'})
    h_t_t_p_message_0 = HTTPResponse(request)
    str_0 = h_t_t_p_message_0.headers
    bytearray_0 = bytearray(str_0, 'utf-8')
    byte_0 = bytes(bytearray_0)
    list_0 = list(byte_0)
    int_0 = len(list_0)
    for int_1 in range(int_0):
        pass

# Generated at 2022-06-25 18:34:43.303598
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass



# Generated at 2022-06-25 18:34:46.125052
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    response_0 = HTTPResponse(list_0)
    # This should not cause any error
    response_0.iter_lines(1)


# Generated at 2022-06-25 18:34:48.159076
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines()


# Generated at 2022-06-25 18:34:56.223858
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    class TestRequestsResponse:
        def iter_lines(self, chunk_size):
            pass

    class TestRequestsRaw:
        def __init__(self):
            self._original_response = TestHTTPResponse()
        
    class TestHTTPResponse:
        def __init__(self):
            self.version = 11
            self.status = 200
            self.reason = 'OK'
            self.msg = TestHTTPMessage()
    
    class TestHTTPMessage:
        def __init__(self):
            self._headers = (("test name", "test value"),)
    
    list_0 = [TestRequestsResponse(), TestRequestsRaw()]
    h_t_t_p_response_0 = HTTPResponse(list_0)


# Generated at 2022-06-25 18:35:00.605289
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_4 = []
    h_t_t_p_response_0 = HTTPResponse(list_4)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:35:04.142746
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_1 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_1.iter_lines(1)


# Generated at 2022-06-25 18:35:08.313140
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    response_0 = requests.Response()
    h_t_t_p_response_0 = HTTPResponse(response_0)
    assert_equal(h_t_t_p_response_0.iter_lines(1), (line for line in response_0.iter_lines(1)))
    assert_equal(h_t_t_p_response_0.iter_lines(1), (b'line', b'\n'))


# Generated at 2022-06-25 18:35:13.915523
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    list_0 = []
    h_t_t_p_response_0 = HTTPResponse(list_0)
    h_t_t_p_response_0.iter_lines(0)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(2)
    h_t_t_p_response_0.iter_lines(3)
