

# Generated at 2022-06-25 18:26:14.043080
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # A Request object
    request_obj = Request('GET', 'https://github.com')
    request_obj.headers['content-type'] = 'text/plain'
    request_obj.body = "This is a test request body"
    
    # Create a wrapper HTTPRequest object
    http_request_object = HTTPRequest(request_obj)
    http_request_body = http_request_object.body
    http_request_body_iterator = http_request_object.iter_body()
    # Compare the values of body and iteration of the body
    assert http_request_body_iterator == http_request_body


# Generated at 2022-06-25 18:26:16.025168
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r_0 = HTTPResponse(HTTPResponse)
    r_0.iter_lines()


# Generated at 2022-06-25 18:26:21.730405
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_1 = ''
    h_t_t_p_message_1 = HTTPResponse(str_1)
    assert not hasattr(h_t_t_p_message_1, 'chunk_size')



# Generated at 2022-06-25 18:26:28.909957
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_message_0._orig = str_0
    str_1 = 'This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0._orig = str_1
    assert 'This processor that applies syntax highlighting' in h_t_t_p_message_0.headers


# Generated at 2022-06-25 18:26:35.549435
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    assert isinstance(h_t_t_p_message_0.iter_lines(0), Iterable)


# Generated at 2022-06-25 18:26:41.605842
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    HTTPRequest_0 = HTTPRequest(str_0)
    HTTPRequest_0.iter_lines(1)


# Generated at 2022-06-25 18:26:46.599367
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    str_1 = h_t_t_p_message_0.iter_lines()


# Generated at 2022-06-25 18:26:53.755372
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    str_1 = str_0.join(h_t_t_p_message_0.iter_body(1))


# Generated at 2022-06-25 18:27:00.710634
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    bytes_0 = b'\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    h_t_t_p_message_0 = HTTPRequest(bytes_0)
    #Test for method iter_body of class HTTPMessage
    #test for h_t_t_p_message_0.iter_body
    #test for h_t_t_p_message_0.iter_body


# Generated at 2022-06-25 18:27:01.814960
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    test_case_0()


# Generated at 2022-06-25 18:27:15.586383
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    body = b'This is a test'
    request = HTTPRequest(lambda: None)
    request._orig.body = body
    assert list(request.iter_body()) == [body]


# Generated at 2022-06-25 18:27:22.217138
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Build a HTTPRequest object, then call iter_lines on it
    h_t_t_p_request_0 = HTTPRequest("POST", "https://httpbin.org/post")
    h_t_t_p_request_0.headers = {"X-Header": "Value"}
    h_t_t_p_request_0.data = "foo=bar"
    iterator_0 = h_t_t_p_request_0.iter_lines(1)



# Generated at 2022-06-25 18:27:32.198402
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    # Call method iter_body with arguments chunk_size=int(24) on instance h_t_t_p_message_0
    generator_0 = h_t_t_p_message_0.iter_body(int(24))
    try:
        """for i in range(int(1)):
            print(next(generator_0))"""
        while True:
            print(next(generator_0))
    except StopIteration:
        pass


# Generated at 2022-06-25 18:27:40.473273
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_request_0 = HTTPRequest(str_1)
    h_t_t_p_request_0.iter_body(chunk_size=1)


# Generated at 2022-06-25 18:27:42.800375
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    h_t_t_p_response_0.iter_lines(None)


# Generated at 2022-06-25 18:27:43.667574
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    pass


# Generated at 2022-06-25 18:27:48.368494
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    http_request_0 = HTTPRequest(str_0)
    http_request_0.iter_lines(1)


# Generated at 2022-06-25 18:27:55.609975
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    int_0 = randint(1, 14)
    assert h_t_t_p_message_0.iter_body(int_0)


# Generated at 2022-06-25 18:27:59.345511
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    r_e_q_u_e_s_t_0 = HTTPRequest('POST', 'https://httpbin.org/post', data={ 'foo': 'bar' })
    for line in r_e_q_u_e_s_t_0.iter_lines(1024):
        print(line)


# Generated at 2022-06-25 18:28:09.980408
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    chunk_size_0 = 1024
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_message_0)

# Generated at 2022-06-25 18:28:30.817216
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_message_0 = HTTPRequest()
    http_message_0_iter_lines_0_0 = h_t_t_p_message_0.iter_lines(32)
    http_message_0_iter_lines_0_0_0 = iter(http_message_0_iter_lines_0_0)
    http_message_0_iter_lines_0_0_1 = next(http_message_0_iter_lines_0_0_0)
    h_t_t_p_message_0_body_0 = h_t_t_p_message_0.body
    http_message_0_iter_lines_0_0_2 = http_message_0_iter_lines_0_0_1[0]
    h_t_t_p_message_

# Generated at 2022-06-25 18:28:38.774076
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_1)
    int_0 = 1
    set_0 = {h_t_t_p_message_0.iter_lines(int_0)}

# Generated at 2022-06-25 18:28:43.989679
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req_0 = HTTPRequest(HTTPRequest(HTTPRequest(HTTPRequest(None))))
    res_0 = req_0.iter_lines(None)
    bytes_0 = b''
    assert(res_0 == res_0)


# Generated at 2022-06-25 18:28:50.447772
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:28:52.640009
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    s = HTTPResponse()
    resp = s.iter_lines()


# Generated at 2022-06-25 18:28:55.635795
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_0 = HTTPRequest(0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:29:04.674635
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_1)
    int_0 = 0
    iter_0 = h_t_t_p_response_0.iter_lines(int_0)

# Generated at 2022-06-25 18:29:11.931388
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_1)

# Generated at 2022-06-25 18:29:19.530939
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import io
    import zlib
    f_i_o_0 = io.BytesIO(b'GIF87a\x01\x00\x01\x00\x80\x01\x00\x00\x00\x00ccc,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;')
    f_i_o_1 = io.BytesIO(zlib.compress(b'a' + b'\r' + b'\n'))
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_

# Generated at 2022-06-25 18:29:26.513741
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    r_h_t_t_p_request_0 = HTTPRequest('\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    ')
    with raises(NotImplementedError):
        r_h_t_t_p_request_0.iter_lines(-1)


# Generated at 2022-06-25 18:29:49.986833
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    message_iter_lines = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(message_iter_lines)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:29:56.755406
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:30:05.319471
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_0)
    # TypeError: unsupported operand type(s) for //=: 'int' and 'NoneType'
    h_t_t_p_response_1 = h_t_t_p_response_0.iter_lines(None)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_2 = HTTPR

# Generated at 2022-06-25 18:30:10.147611
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPRequest(str_0)
    c_h_u_n_k_s_i_z_e_0 = 1
    # h_t_t_p_message_0.iter_lines() -> fails: AttributeError: 'str' object has no attribute 'iter_lines'
    pass


# Generated at 2022-06-25 18:30:13.437744
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(23)


# Generated at 2022-06-25 18:30:20.168753
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    body = str_0.encode('utf-8')
    request_0 = HTTPRequest(body)
    for line in request_0.iter_lines(chunk_size=1):
        print(line)


# Generated at 2022-06-25 18:30:26.542631
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:30:32.586917
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_message_0)
    # The following call to h_t_t_p_response_0.iter_lines() throws a NotImplementedError
    h_t_t_p_response_0.iter_lines()

# Generated at 2022-06-25 18:30:42.374530
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    # Test error
    with pytest.raises(NotImplementedError):
        str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
        h_t_t_p_message_1 = HTTPMessage(str_1)
        h_t_t_p_message_1.iter_lines()


# Generated at 2022-06-25 18:30:44.384022
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    instance = HTTPMessage(None)
    chunk_size = 1
    print(instance.iter_lines(chunk_size))

# Generated at 2022-06-25 18:31:24.238540
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    with pytest.raises(NotImplementedError):
        str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
        h_t_t_p_message_0 = HTTPRequest(str_0)
        h_t_t_p_message_0.iter_lines()


# Generated at 2022-06-25 18:31:27.922823
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    responses = requests.get('http://172.20.0.6/')
    h_t_t_p_response_0 = HTTPResponse(responses)
    for i in h_t_t_p_response_0.iter_lines(1):
        pass


# Generated at 2022-06-25 18:31:34.429143
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPResponse(str_0)
    h_t_t_p_message_0.iter_lines(1)


# Generated at 2022-06-25 18:31:40.192389
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:31:50.351510
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    iter_lines_0 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")
    iter_lines_1 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")
    iter_lines_2 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")
    iter_lines_3 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")
    iter_lines_4 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")
    iter_lines_5 = HTTPMessage("HTTP/1.1 200 OK\r\n\r\n")

# Generated at 2022-06-25 18:31:56.017280
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    http_request_0 = HTTPRequest(str_0)
    assert http_request_0.iter_lines(0) == http_request_0.iter_body(1)


# Generated at 2022-06-25 18:32:02.536705
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request_0 = HTTPRequest('\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    ')
    iter_lines_0 = request_0.iter_lines(1)
    line_feed_0 = b'\n\n'


# Generated at 2022-06-25 18:32:08.028065
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    http_request_0 = HTTPRequest(str_0)
    assert http_request_0.iter_lines(1).next()[0] == str_0


# Generated at 2022-06-25 18:32:11.613268
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from unittest import mock

    # Call the method, such that it will yield a generator.
    iter_lines = HTTPResponse.iter_lines(mock.MagicMock(), 1)

    # Consume the generator, to ensure that all the assertions pass.
    for _ in iter_lines:
        pass



# Generated at 2022-06-25 18:32:20.002395
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = pygments_dump_1()
    str_1 = [str_0]
    stringio_0 = StringIO(str_0)
    h_t_t_p_request_0 = HTTPRequest(stringio_0)
    result_0 = h_t_t_p_request_0.iter_lines()
    result_1 = h_t_t_p_request_0.iter_lines(2)
    assert result_0 == [("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 56\r\n\r\n", b'')]

# Generated at 2022-06-25 18:33:37.969110
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_1 = HTTPMessage(str_1)
    str_2 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '


# Generated at 2022-06-25 18:33:40.006373
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from unittest import mock

    request = HTTPRequest(mock.Mock())
    lines = list(request.iter_lines(1))

    assert lines[0] == (b'', b'')


# Generated at 2022-06-25 18:33:48.521002
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    # verify the var content
    assert str_0 == '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    # verify the var content

# Generated at 2022-06-25 18:33:53.670760
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    method_ret_var_0 = h_t_t_p_message_0.iter_lines(8)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    HTTPRequest_inst_0 = HTTPRequest(str_1)
    method_ret_var_1 = HTTPRequest_inst_0.iter_lines(8)
    assert method_ret_var

# Generated at 2022-06-25 18:34:00.116588
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    HTTPRequest_0 = HTTPRequest(str_0)
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    HTTPRequest_0 = HTTPRequest(str_0)
    int_0 = 1
    t_tuple_0 = (str_0, str_0)
    assert HTTPRequest_0.iter_lines(int_0) == t_tuple_0


# Generated at 2022-06-25 18:34:10.194452
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_response_0 = HTTPResponse(str_1)
    h_t_t_p_response_0.iter_lines(1)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:34:15.571522
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    body_0 = '\n\n        Colorize using Pygments\n\n        This processor that applies syntax highlighting to the headers,\n        and also to the body if its content type is recognized.\n\n    '
    test_req_0 = HTTPRequest(body_0)
    # test_req_0.iter_lines()
    # print('iter_lines_0:', test_req_0.iter_lines())



# Generated at 2022-06-25 18:34:22.427380
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    h_t_t_p_message_0 = HTTPMessage(str_0)
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_message_0)
    h_t_t_p_request_0.iter_lines(1)
    h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:34:27.126236
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
  str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
  h_t_t_p_message_0 = HTTPMessage(str_0)
  assert_equal(h_t_t_p_message_0.iter_lines(), expected, message='')


# Generated at 2022-06-25 18:34:35.975235
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
  str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
  str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
  str_2 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '