

# Generated at 2022-06-25 18:26:02.254345
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    assert False


# Generated at 2022-06-25 18:26:14.010772
# Unit test for method iter_lines of class HTTPRequest

# Generated at 2022-06-25 18:26:15.807220
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Should not raise exception
    HTTPRequest.iter_lines(None, -1)


# Generated at 2022-06-25 18:26:21.535983
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    assert isinstance(h_t_t_p_request_0.iter_lines(1), Iterable)


# Generated at 2022-06-25 18:26:22.800700
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    pass


# Generated at 2022-06-25 18:26:30.007105
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPMessage(dict_0)
    h_t_t_p_request_0 = HTTPRequest(h_t_t_p_message_0)
    h_t_t_p_request_iter_body_0 = h_t_t_p_request_0.iter_body(1024)
    h_t_t_p_request_iter_body_1 = h_t_t_p_request_0.iter_body(1025)
    h_t_t_p_request_iter_body_2 = h_t_t_p_request_0.iter_body(1024)
    h_t_t_p_request_iter_body_3 = h_t_t_p_request_0.iter_

# Generated at 2022-06-25 18:26:31.688492
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    pass


# Generated at 2022-06-25 18:26:35.111077
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    string_0 = h_t_t_p_response_0.iter_lines(42)


# Generated at 2022-06-25 18:26:43.005317
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPMessage(dict_0)
    # Unit test for method iter_body of class HTTPRequest
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    # Unit test for method iter_body of class HTTPRequest
    class_0 = StringIO()
    assert h_t_t_p_request_0.iter_body(class_0)



# Generated at 2022-06-25 18:26:52.191378
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_dict = {}
    test_method = "POST"
    test_url = "www.example.com"
    test_headers = None
    test_data = "test"
    test_request = Request(test_method, test_url, headers=test_headers, data=test_data)
    test_http_request = HTTPRequest(test_request)

    # Catch exceptions from invalid inputs
    # Normal behavior
    result = test_http_request.iter_lines(1)
    assert isinstance(result, types.GeneratorType)
    result = list(result)
    assert len(result) == 1
    assert isinstance(result[0][0], bytes)
    assert isinstance(result[0][1], bytes)


# Generated at 2022-06-25 18:27:09.809775
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPMessage(dict_0)
    class_inst_0 = HTTPRequest(h_t_t_p_message_0)
    unit_test_0_0 = class_inst_0.iter_body(None)
    unit_test_0_1 = class_inst_0.iter_body(None)
    unit_test_0_2 = class_inst_0.iter_body(None)
    unit_test_0_3 = class_inst_0.iter_body(None)
    i = 0
    while (i < 4):
        i += 1
        unit_test_0_i = class_inst_0.iter_body(None)



# Generated at 2022-06-25 18:27:14.853448
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    with pytest.raises(NotImplementedError):
        HTTPRequest(dict_0).iter_body(1)


# Generated at 2022-06-25 18:27:17.409836
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPRequest(dict_0)
    chunk_size_0 = 0

    for line in h_t_t_p_message_0.iter_lines(chunk_size_0):
        pass


# Generated at 2022-06-25 18:27:19.482774
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-25 18:27:26.269693
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPRequest(dict_0)

    # Test for Exception
    # The method: iter_body does not actually return a Iterable and is not compatible with the test
    # try:
    #     iter_0 = h_t_t_p_message_0.iter_body(1)
    # except TypeError as e:
    #     print(e)
    

# Generated at 2022-06-25 18:27:29.602392
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    h_t_t_p_request_0.iter_body(chunk_size=10)


# Generated at 2022-06-25 18:27:37.709547
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from io import BytesIO
    from requests.models import Request

    request = Request(
        'GET',
        'https://httpbin.org/get'
    )
    message = HTTPRequest(request)
    body = b''.join(message.iter_body())
    with BytesIO(body) as fp:
        assert json.load(fp) == {
            "args": {},
            "headers": {
                "Host": "httpbin.org",
            },
            "origin": "127.0.0.1",
            "url": "https://httpbin.org/get"
        }


# Generated at 2022-06-25 18:27:38.928790
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    pass


# Generated at 2022-06-25 18:27:41.963857
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    __test_iter_body(h_t_t_p_request_0)


# Generated at 2022-06-25 18:27:45.339940
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    chunk_size_0 = 1
    ret = h_t_t_p_request_0.iter_lines(chunk_size_0)
    assert ret == ((b'', ''),)

# Generated at 2022-06-25 18:28:04.683234
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    h_t_t_p_request_0.iter_body()


# Generated at 2022-06-25 18:28:10.706918
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    chunk_size_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_message_0 = h_t_t_p_response_0
    h_t_t_p_message_0.iter_lines(chunk_size=chunk_size_0)
    h_t_t_p_response_0.iter_lines(chunk_size=chunk_size_0)


# Generated at 2022-06-25 18:28:14.381524
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    try:
        h_t_t_p_request_0.iter_body(8)
        assert False
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-25 18:28:18.115552
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = None
    dict_0 = None
    h_t_t_p_response_0.iter_lines(int_0, dict_0)


# Generated at 2022-06-25 18:28:23.417374
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    chunk_size_0 = None
    http_request_0 = HTTPRequest(dict_0)
    http_request_0.iter_lines(chunk_size_0)


# Generated at 2022-06-25 18:28:32.405832
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0._orig)
    h_t_t_p_message_0 = HTTPMessage(h_t_t_p_request_0._orig)
    h_t_t_p_message_0.iter_lines(3)
    h_t_t_p_request_0.iter_lines(3)
    # Output:
    # b'\x00\x00\x00\x00'
    # b'\x00\x00\x00\x00'


# Generated at 2022-06-25 18:28:37.388008
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    req = requests.Request('GET', 'https://httpstat.us/200')
    prep = req.prepare()

    class HTTPRequest0(HTTPRequest):
        def __init__(self):
            self._orig = prep
    with pytest.raises(NotImplementedError):
        h_t_t_p_request_0 = HTTPRequest0()
        h_t_t_p_request_0.iter_lines(1)


# Generated at 2022-06-25 18:28:41.240987
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(FakeMessage())
    assert req.iter_lines(126) == [('Hello world!', '\n')]


# Generated at 2022-06-25 18:28:46.903232
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_1 = None
    h_t_t_p_request_0 = HTTPRequest(dict_1)
    # The next line is to silence the static type checker and
    # force the code to be executed
    try:
        chunk_size_0 = None
        h_t_t_p_request_0.iter_lines(chunk_size_0)
    except TypeError:
        pass


# Generated at 2022-06-25 18:28:50.183233
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests

    res = requests.get('http://example.com/')
    res_wrapper = HTTPResponse(res)

    for line in res_wrapper.iter_lines():
        print(line)


# Generated at 2022-06-25 18:29:26.393102
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    body_0 = None
    http_request_0 = HTTPRequest(dict_0)

    # Wrong type of argument
    try:
        http_request_0.iter_lines(body_0)
    except TypeError as e:
        pass


# Generated at 2022-06-25 18:29:29.080099
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    h_t_t_p_request_0 = HTTPRequest('{"data":{"foo":"bar"}}')
    for i in h_t_t_p_request_0.iter_body(1024):
        print(i)


# Generated at 2022-06-25 18:29:34.390778
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = "test"
    assert isinstance(HTTPRequest(dict_0).iter_lines(1),Iterable)
    assert isinstance(HTTPRequest(dict_0).iter_lines(1),Iterable)
    assert not isinstance(HTTPRequest(dict_0).iter_lines(1),Iterable)


# Generated at 2022-06-25 18:29:40.800486
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 0
    # Iterator over the body yielding (`line`, `line_feed`).
    for x in h_t_t_p_response_0.iter_lines(int_0):
        pass


# Generated at 2022-06-25 18:29:49.098258
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    stream = io.BytesIO(b'foo\nbar\nbaz')
    request = requests.Request('GET', 'https://httpbin.org/bytes/12')
    response = requests.Session().send(request.prepare())
    response.raw.decode_content = True
    response.raw.read = stream.read
    # Set the Content-Length header to 0
    response.headers['Content-Length'] = '0'
    h_t_t_p_message_0 = HTTPResponse(response)
    for line, line_feed in h_t_t_p_message_0.iter_lines(3):
        assert line == b'foo'
        assert line_feed == b'\n'
        break


# Generated at 2022-06-25 18:29:53.709605
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    def fn_0(arg_0):
        return h_t_t_p_request_0.iter_lines(arg_0)
    fn_0(1)


# Generated at 2022-06-25 18:29:58.736059
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPRequest(dict_0)
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    iter_body_1 = h_t_t_p_request_0.iter_body()
    assert iter_body_1 is not None
    body_0 = next(iter_body_1)
    assert body_0 is not None



# Generated at 2022-06-25 18:30:01.928382
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    int_0 = 0
    for i in h_t_t_p_request_0.iter_lines(int_0):
        print(i)


# Generated at 2022-06-25 18:30:05.752975
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    http_request_0 = HTTPRequest(dict_0)
    dict_1 = None
    dict_2 = None
    http_request_0.iter_lines(dict_2, dict_1)
    dict_1 = None
    dict_2 = None
    http_request_0.iter_lines(dict_2, dict_1)


# Generated at 2022-06-25 18:30:12.009130
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    h_t_t_p_request_0 = HTTPRequest(None)
    h_t_t_p_request_0.body = "REQUEST BODY"
    print(h_t_t_p_request_0.body)
    h_t_t_p_request_0.iter_lines(1)
    print(len(h_t_t_p_request_0.body))
    print(str((h_t_t_p_request_0.body[0])))
    print(str((h_t_t_p_request_0.body[1])))
    print(str((h_t_t_p_request_0.body[2])))
    print(str((h_t_t_p_request_0.body[3])))

# Generated at 2022-06-25 18:30:48.943261
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None
    dict_11 = None
    dict_12 = None
    dict_13 = None
    dict_14 = None
    dict_15 = None
    dict_16 = None
    dict_17 = None
    dict_18 = None
    dict_19 = None
    dict_20 = None
    dict_21 = None
    dict_22 = None
    dict_23 = None
    dict_24 = None
    dict_25 = None
    dict_26 = None
    dict_27 = None
    dict_

# Generated at 2022-06-25 18:30:54.574058
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    case_0 = HTTPMessage(None)
    case_0.iter_lines(1)
    try:
        raise ValueError()
    except:
        pass

test_HTTPRequest_iter_lines()


# Generated at 2022-06-25 18:31:01.001645
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req_0 = None
    h_t_t_p_request_0 = HTTPRequest(req_0)
    try:
        chunk_size_0 = 0
        for __ in range(4):
            h_t_t_p_request_0.iter_lines(chunk_size_0)
        h_t_t_p_request_0.iter_lines(chunk_size_0)
    except:
        pass


# Generated at 2022-06-25 18:31:11.091185
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = requests.Request(
        'GET', 'https://datascience.quantecon.org/',
        headers={'User-Agent': 'PyCaretTest'}
    )
    prepared_request = req.prepare()
    # print(prepared_request.headers)
    http_request_0 = HTTPRequest(prepared_request)
    # print(http_request_0._orig)
    for line in http_request_0.iter_lines(chunk_size=1):
        print(line)
    # Raises an error if the body is accessed, because we're
    # testing a request object and the body is not set.
    # http_request_0.body


# Generated at 2022-06-25 18:31:14.432418
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_message_0 = HTTPMessage(dict_0)

    chunk_size_0 = 1
    HTTPRequest_iter_body_ret_val_0 = h_t_t_p_message_0.iter_body(chunk_size_0)

    assert HTTPRequest_iter_body_ret_val_0 == None



# Generated at 2022-06-25 18:31:19.669348
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    h_t_t_p_message_0 = HTTPMessage(dict_0)
    i_o_e_0 = IOError()
    h_t_t_p_message_0._orig = i_o_e_0
    h_t_t_p_request_0._orig = i_o_e_0
    try:
        for i_0 in h_t_t_p_request_0.iter_body():
            pass
    except IOError as e_0:
        assert type(e_0).__name__ == 'IOError'


# Generated at 2022-06-25 18:31:23.157885
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    chunk_size_0 = 2
    h_t_t_p_request_0.iter_body(chunk_size_0)


# Generated at 2022-06-25 18:31:26.687784
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    h_t_t_p_request_0.iter_body(chunk_size = 1)


# Generated at 2022-06-25 18:31:32.676751
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:31:37.661845
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    chunk_size_0 = 1
    iter_0 = h_t_t_p_request_0.iter_body(chunk_size_0)
    next(iter_0)


# Generated at 2022-06-25 18:32:08.117365
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    
    with pytest.raises(NotImplementedError):
        h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:32:14.822106
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import BytesIO
    from tests.test_utils import create_response

    response = create_response(
        status_code=200,
        content=(
            'line 1\n'
            'line 2\r\n'
            'line 3\r'
            'line 4\r\n'
            'line 5\n'
            'line 6\r\n'
        ).encode('utf8'),
        is_json=False,
    )
    response = BytesIO(str(response).encode('utf8'))
    h_t_t_p_response_0 = HTTPResponse(response)
    actual_1 = list(h_t_t_p_response_0.iter_lines(chunk_size=1))

# Generated at 2022-06-25 18:32:16.486944
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    HTTPRequest_0 = HTTPRequest(dict)
    HTTPRequest_0.iter_lines()


# Generated at 2022-06-25 18:32:19.109819
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request_0 = HTTPRequest(None)
    # TODO(rsp): Implement this test
    # assert isinstance(request_0.iter_lines(chunk_size=1), Iterable)


# Generated at 2022-06-25 18:32:22.953111
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 0
    list_0 = list(h_t_t_p_response_0.iter_lines(int_0))
    assert len(list_0) == 0


# Generated at 2022-06-25 18:32:26.337889
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPRequest(dict_0)
    h_t_t_p_message_0.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:32:29.620001
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_1 = None
    http_request_1 = HTTPRequest(dict_1)
    assert len(list(http_request_1.iter_lines(1))[0]) == 2


# Generated at 2022-06-25 18:32:40.112906
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead code
    # These lines should not be dead

# Generated at 2022-06-25 18:32:43.492612
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    dict_0 = None
    h_t_t_p_request_0 = HTTPRequest(dict_0)
    dict_0 = 1
    h_t_t_p_request_0.iter_lines(dict_0)
    assert True


# Generated at 2022-06-25 18:32:48.603341
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    http_request_0 = HTTPRequest(None)
    list_0 = list(http_request_0.iter_lines(None))
    list_1 = list(http_request_0.iter_lines(None))
    list_0.clear()
    list_2 = list(list_1)
    assert list_0 == list_2

# Unit tests for method iter_lines of class HTTPResponse

# Generated at 2022-06-25 18:33:21.789801
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPResponse(dict_0)
    chunk_size_0 = 1
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    # TypeError: super(type, obj): obj must be an instance or subtype of type
    # TypeError: super(type, obj): obj must be an instance or subtype of type
    object_0 = next(h_t_t_p_response_0.iter_lines(chunk_size_0))
    assert object_0 != None


# Generated at 2022-06-25 18:33:25.098337
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    r = requests.get('https://www.google.com')
    response_0 = HTTPResponse(r)
    h_t_t_p_message_0 = HTTPMessage(dict_0)


# Generated at 2022-06-25 18:33:30.987218
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict = None
    h_t_t_p_response_0 = HTTPResponse(dict)
    int_0 = 1
    h_t_t_p_response_0.iter_lines(int_0)


# Generated at 2022-06-25 18:33:36.593669
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    # Should be None
    assert h_t_t_p_response_0.iter_lines(chunk_size=1) is None


# Generated at 2022-06-25 18:33:40.365261
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    iter_0 = h_t_t_p_response_0.iter_lines(3)
    v_0 = None
    v_1 = None
    v_0, v_1 = next(iter_0)


# Generated at 2022-06-25 18:33:44.819549
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    buf_0 = None
    size_0 = 0
    result_0 = h_t_t_p_response_0.iter_lines(buf_0, size_0)


# Generated at 2022-06-25 18:33:48.553519
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_1 = None
    h_t_t_p_response_0 = HTTPResponse(dict_1)
    h_t_t_p_response_0.iter_lines(1)


# Generated at 2022-06-25 18:33:52.564685
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    dict_0 = 1
    h_t_t_p_response_0.iter_lines(dict_0)


# Generated at 2022-06-25 18:34:00.069283
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPResponse(dict_0)

    dict_1 = None
    h_t_t_p_message_1 = HTTPResponse(dict_1)

    dict_2 = None
    h_t_t_p_message_2 = HTTPResponse(dict_2)

    dict_3 = None
    h_t_t_p_message_3 = HTTPResponse(dict_3)

    dict_4 = None
    h_t_t_p_message_4 = HTTPResponse(dict_4)

    dict_5 = None
    h_t_t_p_message_5 = HTTPResponse(dict_5)

    dict_6 = None
    h_t_t

# Generated at 2022-06-25 18:34:06.201783
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    print("Testing method iter_lines of class HTTPResponse")
    # Test code written to test method iter_lines
    # Path of file that is to be used to test the method
    path = None
    # Variable that stores the file object
    file = None
    # Tested function call for method iter_lines
    iter_lines_val = HTTPResponse.iter_lines(file, chunk_size = 1)


# Generated at 2022-06-25 18:34:58.951893
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    http_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    h_t_t_p_response_0.iter_lines(h_t_t_p_response_0)



# Generated at 2022-06-25 18:35:02.652390
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    chunk_size = 1
    assert h_t_t_p_response_0.iter_lines(chunk_size) == h_t_t_p_response_0.iter_lines(chunk_size)



# Generated at 2022-06-25 18:35:06.367029
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)
    int_0 = 0
    actual = list(h_t_t_p_response_0.iter_lines(int_0))
    expected = []
    if actual != expected:
        print("FAILED: Expected '%s' but got '%s'" % (expected, actual))


# Generated at 2022-06-25 18:35:09.156997
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():

    # Define the class attributes required by the method under test
    dict_0 = None
    h_t_t_p_response_0 = HTTPResponse(dict_0)

    # Invoke the method under test
    iter_lines_response = h_t_t_p_response_0.iter_lines(1)

    # Check the response
    assert(isinstance(iter_lines_response, Iterable))


# Generated at 2022-06-25 18:35:13.801986
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url_0 = 'https://dev.httpbin.org/ip'
    result_0 = requests.get(url=url_0)
    h_t_t_p_response_0 = HTTPResponse(result_0)
    h_t_t_p_response_0.iter_lines(chunk_size=1)


# Generated at 2022-06-25 18:35:16.327069
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_response_5 = HTTPResponse(dict_0)
    h_t_t_p_response_5.iter_lines(1)


# Generated at 2022-06-25 18:35:17.908322
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    h_t_t_p_response_0 = HTTPResponse(None)
    h_t_t_p_response_0.iter_lines(0)


# Generated at 2022-06-25 18:35:21.741768
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPResponse(dict_0)
    assert_raises(NotImplementedError, h_t_t_p_message_0.iter_lines, 1)


# Generated at 2022-06-25 18:35:29.017571
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPMessage(dict_0)
    # Test for the new exception type.
    try:
        h_t_t_p_message_0.iter_lines()
        #self.assertRaises("NotImplementedError", h_t_t_p_message_0.iter_lines)
    except NotImplementedError as e:
        pass



# Generated at 2022-06-25 18:35:30.830608
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    dict_0 = None
    h_t_t_p_message_0 = HTTPResponse(dict_0)
    h_t_t_p_message_0.iter_lines()
