

# Generated at 2022-06-21 13:50:43.802137
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    req = HTTPRequest(original_request)
    assert isinstance(req, HTTPMessage)


# Generated at 2022-06-21 13:50:53.026735
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from unittest.mock import MagicMock

    response = MagicMock()
    response.iter_lines = MagicMock(return_value=['line0', 'line1', 'line2', 'line3'])
    response.headers = {'Content-Type': 'text/plain'}

    http_response = HTTPResponse(response)
    assert tuple(http_response.iter_lines(1)) == (
        (b'line0', b'\n'),
        (b'line1', b'\n'),
        (b'line2', b'\n'),
        (b'line3', b''),
    )

    response.iter_lines.assert_called_once_with(1)

# Generated at 2022-06-21 13:51:01.451533
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    class MockHTTPMessage(HTTPMessage):
        def __init__(self, chunks):
            self.chunks = chunks

        def iter_body(self, chunk_size):
            return self.chunks

    assert list(MockHTTPMessage([b'12345']).iter_lines(chunk_size=10)) == [
        (b'12345', b'')]
    assert list(MockHTTPMessage([b'12', b'345']).iter_lines(chunk_size=10)) == [
        (b'12', b''), (b'345', b'')]

# Generated at 2022-06-21 13:51:09.009768
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests
    url = "http://eecs.oregonstate.edu/education/undergraduate-programs/"
    response = requests.get(url)
    counter = 0
    for chunk in response.iter_content(chunk_size=200):
        counter += 1
        f = open("eecs_chunks_req.html", 'wb')
        f.write(chunk)
    print(counter)


if __name__ == '__main__':
    test_HTTPResponse_iter_body()

# Generated at 2022-06-21 13:51:17.717729
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    from io import BytesIO
    from unittest.mock import Mock
    from .request import Response
    from .response import _iter_lines

    response = Mock()
    response.headers = {}
    # chunk_size=3
    response.raw = BytesIO(b'1234567890')
    response.status_code = 200
    response.reason = 'OK'
    response.url = None
    response = Response(response)
    # Test the __next__ method of the iterator returned by iter_lines
    l = _iter_lines(response, 3)
    assert list(l) == [
        b'123', b'456', b'789', b'0', b'',
    ]
    response.raw = BytesIO(b'123\r\n456\r\n789\r\n0')


# Generated at 2022-06-21 13:51:18.513676
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert HTTPMessage

# Generated at 2022-06-21 13:51:29.004275
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests

    # Without iter_lines
    res = requests.get("https://www.google.com")
    res_body = res.text
    #print("res_body:", res_body,type(res_body))
    #print("res_body:", res_body.encode('utf-8'),type(res_body.encode('utf-8')))

    # With iter_lines
    htr = HTTPResponse(res)
    htr_body = ""
    for line, line_feed in htr.iter_lines(1):
        htr_body = htr_body + line.decode('utf-8') + line_feed.decode('utf-8')
    #print("htr_body:", htr_body,type(htr_body))
    #print("htr

# Generated at 2022-06-21 13:51:40.044105
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    url = "http://httpbin.org/ip"
    response = requests.get(url, verify=False)
    my_response = HTTPResponse(response)
    print(my_response.content_type)
    for b in my_response.iter_body(10):
        print(b)
    for b in my_response.iter_lines(10):
        print(b)
    print(my_response.headers)
    print(my_response.encoding)
    print(my_response.body)
    print(response.content)

    # Unit test for constructor of class HTTPRequest
    url = "http://httpbin.org/post"
    my_data = {'key1': 'value1'}
    response = requests.post(url, data=my_data, verify=False)
    my_

# Generated at 2022-06-21 13:51:51.387426
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    """Unit test for iter_lines method"""

    # Create HTTP request and response
    resp = requests.Response()
    req = requests.Request('GET', 'http://www.site.com')
    req.prepare()

    # Set the request body
    req.body = 'test'

    # Set the response body
    resp._content = b'one\r\n'
    resp._content += b'two\r\n'
    resp._content += b'three\r\n'
    resp._content += b'four'

    # Wrap both request and response
    http_request = HTTPRequest(req)
    http_response = HTTPResponse(resp)

    # Get content
    request_content = ''
    response_content = ''

# Generated at 2022-06-21 13:52:02.377039
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    url = 'abc'
    encoding = 'utf8'
    content_type = 'abc'
    method = 'GET'
    url = 'abc'
    headers = []
    redirection = False
    history = []
    connection = []
    cookies = []
    elapsed = []
    request = []
    raw = 1

    # create response object
    response = requests.models.Response()
    response.encoding = encoding
    response.url = url
    response.url = url
    response.status_code = 1
    response.headers = headers
    response.cookies = cookies
    response.redirects = redirection
    response.history = history
    response.raw = raw
    response.connection = connection
    response.elapsed = elapsed
    response.request = request

    headers = ['HTTP/1.1 200 OK']

# Generated at 2022-06-21 13:52:15.281524
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest(Request(url='http://httpbin.org/get', method='GET'))
    assert next(req.iter_body()) == b''

    req = HTTPRequest(Request(url='http://httpbin.org/post', method='POST', body='Test'))
    assert next(req.iter_body()) == b'Test'



# Generated at 2022-06-21 13:52:22.452974
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r = requests.get('http://httpbin.org/range/1024', stream=True)
    print(r)
    r = HTTPResponse(r)
    assert r.headers == """\
HTTP/1.1 206 Partial Content
Server: gunicorn/19.6.0
Date: Thu, 30 Mar 2017 10:22:35 GMT
Connection: keep-alive
Content-Range: bytes 0-1023/2048
Content-Type: application/octet-stream
Content-Length: 1024
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true"""
    assert r.encoding is None

# Generated at 2022-06-21 13:52:32.039960
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    resp = requests.get("http://www.mocky.io/v2/5b73f8d8350000a80d9c7fb9")
    print("Request URL: ", resp.url)
    print("Response status code: ", resp.status_code)
    print("Response headers: ", resp.headers)
    print("Response encoding: ", resp.encoding)
    print("Response text: ", resp.text)
    print("Response content type: ", resp.headers['Content-Type'])
    print("Response body: ", resp.content)
    for chunk in resp.iter_lines(decode_unicode=True):
        print("Response chunk: ", str(chunk), " end")

    req = requests.Request(resp.request)
    print("Request URL: ", req.url)

# Generated at 2022-06-21 13:52:34.795215
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    """Testing to iterate body of a HTTPRequest object."""
    httprequest = HTTPRequest(None)
    httprequest.body = "this is the body text"
    for line in httprequest.iter_body():
        print(line)
        assert line == "this is the body text"


# Generated at 2022-06-21 13:52:36.674764
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    #data = HTTPResponse(data)
    #print(data.headers)
    pass

# Generated at 2022-06-21 13:52:41.719216
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    response = requests.get('http://www.python.org')
    r = HTTPResponse(response)
    assert r._orig == response
    assert r.headers is not None
    assert r.encoding is not None
    assert r.body is not None
    assert r.content_type is not None
    response.close()


# Generated at 2022-06-21 13:52:52.383981
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    # Create a dummy response class
    class DummyResponse:
        @property
        def iter_content(self):
            return iter(['a', 'b', 'c'])
        @property
        def headers(self):
            return 'a b c'
        @property
        def raw(self):
            return '123'
        @property
        def encoding(self):
            return 'utf8'
        @property
        def content(self):
            return 'content'
    dummy_response = DummyResponse()
    # Create a HTTPResponse Object
    response = HTTPResponse(dummy_response)
    # Call iter_body
    iter_body = response.iter_body()
    # Test the body of HTTPResponse

# Generated at 2022-06-21 13:52:58.812051
# Unit test for method iter_lines of class HTTPResponse

# Generated at 2022-06-21 13:53:00.766392
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
	assert (HTTPRequest(HTTPRequest).body==None)
	#print(HTTPRequest.encoding)


# Generated at 2022-06-21 13:53:07.988340
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    # Initialization of the Request object
    request1 = HTTPRequest(orig=b'a')
    request2 = HTTPRequest(orig=[1, 2])

    # Expected value
    expected1 = [b'a']
    expected2 = [b'[1, 2]']

    # Iterate over the body of the request
    # Check whether the expected values are returned
    result1 = [x for x in request1.iter_body()]
    result2 = [x for x in request2.iter_body()]

    assert result1 == expected1
    assert result2 == expected2


# Generated at 2022-06-21 13:53:34.039528
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    import requests
    import json

    # test with URL
    resp = requests.get('https://httpbin.org/get')
    assert resp.status_code == 200
    http_message = HTTPResponse(resp)
    for chunk in http_message.iter_body(1):
        print(chunk)

    # test with Request
    request = requests.Request('GET', 'https://httpbin.org/get',
                               headers={'from': 'pytest'})
    http_request = HTTPRequest(request)
    for chunk in http_request.iter_body(1):
        print(chunk)

if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-21 13:53:39.402030
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from nameko_tracer import Tracer

    class Service:
        name = "service"

        @Tracer()
        def test(self, arg1, arg2, arg3):
            return arg1

    service = Service()
    print(service.test("1", "2", "3"))

# Generated at 2022-06-21 13:53:49.929209
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import sys
    from io import BytesIO
    from . import RequestBuilder
    from .request import Request
    from .request import HTTPRequest
    from .options import default_options

    options = default_options().__dict__

    request = Request(options)
    request.startswith('get https://httpbin.org')

    request_builder = RequestBuilder(request)
    request_data = request_builder.build()
    original_request = request_data['request']
    http_request = HTTPRequest(original_request)

    # Manually set body to a non-empty string
    original_request.body = "foo bar"

    # Call iter_lines
    lines = list(http_request.iter_lines(8))
    (line, line_feed) = lines[0]

    # Check that line contains the same value as what

# Generated at 2022-06-21 13:53:55.990294
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    mock_socket = Mock()
    mock_socket.recv.return_value = b'hello'
    mock_connection = Mock()
    mock_connection.get_socket.return_value = mock_socket
    mock_tls_socket = Mock()
    mock_tls_socket.connection = mock_connection
    mock_stream = Mock()
    mock_stream.get_extra_info.return_value = mock_tls_socket
    request = HTTPRequest(Mock(url='https://www.google.com'))
    request.iter_body()
    mock_tls_socket.connection.get_socket().recv.assert_called_once()



# Generated at 2022-06-21 13:53:58.011171
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    # TODO
    print("MTODO")


# Generated at 2022-06-21 13:54:01.317824
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    line = b'a\n'
    request = HTTPRequest(Request('GET', line))
    assert list(request.iter_lines(1)) == [(line, b'')]
    # TODO: add a test for the case request.body == ''

# Generated at 2022-06-21 13:54:09.700628
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from io import BytesIO

    class FakeStream:
        def read(self, n=None):
            return b"ab\ncd"

    class FakeResponse:
        def __init__(self):
            self.raw = FakeStream()

    request = HTTPRequest(FakeResponse())
    lines = [line for line in request.iter_lines(chunk_size=1)]
    assert lines == [b"ab\n", b"cd"]
    try:
        lines = [line for line in request.iter_lines(chunk_size=None)]
        # This condition should be unachieved
        assert lines == [b"ab\n", b"cd"]
    except Exception as e:
        assert str(e) == 'Use a positive chunk size'

# Generated at 2022-06-21 13:54:14.077798
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    r = requests.Request('GET', 'https://example.com')
    r = HTTPRequest(r)
    for i in r.iter_body(10):
        print(i)
        if i == b'help':
            break

# Generated at 2022-06-21 13:54:20.596729
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    #class HTTPResponse(HTTPMessage):
    body = """
    '''
        line 1
        line 2
        line 3
        line 4
        line 5
        line 6
    '''
    """
    res = HTTPResponse(body)

    cnt = 0
    for line, LF in res.iter_lines(1):
        cnt = cnt + 1

    assert cnt == 6



# Generated at 2022-06-21 13:54:21.938173
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    req = HTTPRequest()
    assert(req is not None)

# Generated at 2022-06-21 13:55:02.753420
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = requests.Request(method='GET', url='http://example.com/')
    prepared = request.prepare()
    # prepared.body is a io.BytesIO object
    body = prepared.body
    body.read()
    body.seek(0)
    # Each time the body is read, the content is reset to the initial position.
    # The next time the body is read, it will return the same content.
    assert body.read() == body.read()

    body.seek(0)
    req = HTTPRequest(prepared)
    # The iterator is not a dynamic generator
    assert req.iter_body() == req.iter_body()

    # req.iter_body() returns an iterable object which has a length equal to its container.
    # The iterable object can be converted to a list.
    body_chunk

# Generated at 2022-06-21 13:55:07.431262
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    original = 'www.google.com.vn'
    r = HTTPResponse(original)
    http_request = HTTPRequest(r)
    a = r.iter_body(1)
    b = http_request.iter_body(1)
    print(a == b)
    print(a)
    print(b)
    for i in a:
        print(i)
    for i in b:
        print(i)
        

# Generated at 2022-06-21 13:55:08.465526
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert HTTPMessage is not None

# Generated at 2022-06-21 13:55:14.018924
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    import requests
    request = requests.Request('GET', 'http://0.0.0.0/', data={'key': 'value'})
    prepared = request.prepare()
    http = HTTPRequest(prepared)
    print(http.headers)
    print(http.body)

if __name__ == '__main__':
    test_HTTPRequest()

# Generated at 2022-06-21 13:55:15.441197
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    # TODO: add tests for HTTPMessage.iter_lines
    pass

# Generated at 2022-06-21 13:55:20.439356
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    # Create an instance of the HTTPMessage class with a requests.models.Response as an argument
    assert isinstance(HTTPMessage(requests.models.Response()), HTTPMessage)
    # Create an instance of the HTTPMessage class with a requests.models.Request as an argument
    assert isinstance(HTTPMessage(requests.models.Request()), HTTPMessage)

# Unit tests for constructor of class HTTPResponse

# Generated at 2022-06-21 13:55:25.652171
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    req = requests.Request('GET', 'http://www.baidu.com')
    prepared = req.prepare()

    http_message = HTTPRequest(prepared)
    for chunk in http_message.iter_body(chunk_size=10000):
        print(chunk)


# Generated at 2022-06-21 13:55:37.034624
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests.models import Request
    class test_request(Request):
        def __init__(self, body: bytes, headers: dict, method: str, url: str,
                     ):
            super().__init__(method=method, url=url, headers=headers)
            self.request = None
            self.method = method
            self.body = body
            self.url = url
            self.headers = headers

    body = b'test body'
    headers = {'Content-Type': 'application/octet-stream'}
    method = 'POST'
    url = 'http://127.0.0.1:8080/'
    request = test_request(body, headers, method, url)
    http_message = HTTPRequest(request)

    assert body == http_message.body
    chunk_size = 1
   

# Generated at 2022-06-21 13:55:40.886578
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests
    response = requests.get('http://httpbin.org/get')
    httpresponse = HTTPResponse(response)

    response_body = b''
    for body_chunk in httpresponse.iter_body(1):
        response_body += body_chunk
    assert response_body == response.content


# Generated at 2022-06-21 13:55:41.686217
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    assert True


# Generated at 2022-06-21 13:57:02.761244
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """ Unit test for method iter_lines of class HTTPResponse """
    fake_response = FakeResponse()
    response = HTTPResponse(fake_response)
    # First test with a body with \n
    # This should yield a list of lines with \n
    body_with_n = '<!DOCTYPE HTML>\n<html lang="en">\n\n<head>\n    <meta charset="utf-8">\n    <title>Test</title>\n</head>\n\n<body>\n\n</body>\n\n</html>\n'
    with patch('requests.models.Response') as mock:
        mock.return_value = FakeResponse(body=body_with_n)
        response = HTTPResponse(mock.return_value)


# Generated at 2022-06-21 13:57:06.938763
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    from requests_mock import Mock
    m = Mock()
    m.get('http://www.google.com')
    response = m.get('http://www.google.com')
    message = HTTPResponse(response)
    message.iter_body(1)

# Generated at 2022-06-21 13:57:16.274345
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    import requests

    request = requests.Request('GET', 'http://example.com')
    req = HTTPRequest(request)
    assert req.body == b''
    assert isinstance(req.body, bytes)
    assert req.encoding == 'utf8'
    assert req.headers.strip() == (
        'GET / HTTP/1.1\nHost: example.com'
    )
    assert req.content_type == ''

    request = requests.Request(
        'POST',
        'http://example.com',
        json={'hello': 'world'},
        headers={'Content-Type': 'application/json; charset=utf-8'},
    )
    req = HTTPRequest(request)
    assert req.body == b'{"hello": "world"}'
    assert isinstance(req.body, bytes)

# Generated at 2022-06-21 13:57:22.676381
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():

    def get_mock_request():
        response = urllib.request.Request(
            url='http://www.baidu.com',
            headers={'Connection': 'keep-alive', 'User-Agent': 'Mozilla', 'Accept-Charset': 'utf-8',
                     'Accept-Language': 'zh-CN,zh;q=0.8', 'Accept-Encoding': 'gzip, deflate',
                     'Accept': 'text/html,application/xhtml+xml', 'Cookie': 'test_cookie'})
        return response

    request = get_mock_request()
    response = urllib.request.urlopen(request)
    httprn = HTTPResponse(response)
    print(httprn.headers)


# Generated at 2022-06-21 13:57:27.191034
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    request = HTTPResponse()
    assert isinstance(request, HTTPMessage)
    assert isinstance(request, HTTPResponse)
    assert request.__init__(orig)


# Generated at 2022-06-21 13:57:37.504161
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    import json
    from requests.models import Request
    url = 'http://example.com/test'
    req = Request('GET', url)
    req.headers['Authorization'] = 'Basic c3VwZXJ1c2VyNzo0NkxlQ2Q1dU5C'
    req.headers['Accept'] = 'application/json'
    req.headers['Content-Type'] = 'application/json'
    req.data = json.dumps({'test': 'test2'})
    req.prepare()
    req.body = '{"test": "test2"}'
    req_msg = HTTPRequest(req)
    for line in req_msg.iter_body(chunk_size=1):
        print(line)
    print(req_msg.headers)

# Unit

# Generated at 2022-06-21 13:57:49.815810
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    mock_response = lambda: None
    mock_response.headers = {b'Content-Type': b'image/jpeg'}
    mock_response.raw = lambda: None
    mock_response.raw._original_response = lambda: None
    mock_response.raw._original_response.status = 200
    mock_response.raw._original_response.reason = b'OK'
    mock_response.raw._original_response.version = 11
    mock_response.raw._original_response.msg = lambda: None
    mock_response.raw._original_response.msg._headers = [(b'Host', b'127.0.0.1')]
    mock_response.encoding = 'utf-8'
    # mock_response.body = b'hello, world!'

# Generated at 2022-06-21 13:57:53.090055
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    resp = requests.get('https://www.google.com')
    resp2 = HTTPResponse(resp)
    chunk_size = 1
    assert(len(list(resp2.iter_body(chunk_size))) == len(resp.content))


# Generated at 2022-06-21 13:57:55.113092
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    try:
        HTTPMessage()
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-21 13:57:59.790155
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    file = open('../data/test.txt', 'r')
    response = requests.Response()
    response.iter_content = file.read()
    httpresponse = HTTPResponse(response)
    assert list(httpresponse.iter_body(1)) == ['line1\n', 'line2\n', 'line3']


# Generated at 2022-06-21 14:00:26.755883
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    class HTTPMessage_iter_body(HTTPMessage):
        def iter_body(self, chunk_size):
            yield self.body

    class HTTPMessage_iter_body_2(HTTPMessage):
        def iter_body(self, chunk_size):
            yield self.body

    http_message = HTTPMessage_iter_body('orig')
    assert list(http_message.iter_body(100)) == ['orig']

    http_message_2 = HTTPMessage_iter_body_2('')
    assert list(http_message_2.iter_body(100)) == ['']



# Generated at 2022-06-21 14:00:34.310660
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
	# Test 1 : implicitly test the constructor of class HTTPRequest given a not encoded request
	request = 'GET /hello HTTP/1.1\r\nHost: www.example.net\r\n\r\n'
	res = HTTPRequest(request)
	assert res.body == b''
	assert res.encoding == 'utf8'
	assert res.headers == 'GET /hello HTTP/1.1\r\nHost: www.example.net'
	assert res.iter_lines(1) == [(b'', b'')]
	# Test 2 : implicitly test the constructor of class HTTPRequest given an encoded request
	request = 'GET /hello HTTP/1.1\r\nHost: www.example.net\r\n\r\n{"login": "admin"}'
	res = HTTPRequest(request)