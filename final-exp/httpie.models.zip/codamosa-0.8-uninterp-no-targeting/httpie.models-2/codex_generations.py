

# Generated at 2022-06-21 13:50:50.339555
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    url = 'https://httpbin.org/get'
    res = requests.get(url)
    response = HTTPResponse(res)
    for chunk in response.iter_body():
        print(chunk)
    for chunk in response.iter_body(8):
        print(chunk)

# Generated at 2022-06-21 13:50:51.568505
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert HTTPMessage

# Generated at 2022-06-21 13:50:55.038062
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    a = HTTPRequest(requests.Request('GET', 'http://www.google.com'))
    for x in a.iter_body():
        print(x.decode('utf8'))
        break


# Generated at 2022-06-21 13:51:01.297504
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    request = HTTPRequest(requests.models.Request)
    request._orig.url = 'http://example.com'
    request._orig.method = 'GET'
    request._orig.headers = {
        'Content-Type': 'application/json',
        'Content-Length': 13
    }
    request._orig.body = b'{"username": "foo"}'

    request_iter = iter(request.iter_body(chunk_size=1))
    request_list = list(request_iter)
    assert request_list == [b'{"username": "foo"}']



# Generated at 2022-06-21 13:51:12.650094
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    # creating HTTPMessage object
    from requests import models
    response = models.Response()
    response.encoding = 'utf8'
    response.raw = models.RawResponse()

    class http_client_HTTPMessage:
        def __init__(self, headers):
            self._headers = headers

    class httplib_HTTPMessage:
        def __init__(self, headers):
            self.headers = headers

    from http import client
    response.raw._original_response = client.HTTPResponse(
        client.HTTPConnection('localhost'),
    )
    response.raw._original_response.version = 11
    response.raw._original_response.status = 200
    response.raw._original_response.reason = 'OK'
    response.raw._original_response.msg = http_client_HTT

# Generated at 2022-06-21 13:51:24.297132
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    request_text = b'\r\n'.join([
        b'PUT /some/path HTTP/1.1',
        b'Host: localhost:8080',
        b'User-Agent: curl/7.29.0',
        b'Accept: */*',
        b'X-some-header: with-a-value',
        b'Content-Length: 7',
        b'',
        b'content'
    ])

    request = requests.Request(
        method='PUT',
        url='http://localhost:8080/some/path',
        headers={'X-some-header': 'with-a-value'},
        data='content'
    )
    request = request.prepare()
    #print('request.body==', request.body)
    req = HTTPRequest(request)


# Generated at 2022-06-21 13:51:31.180407
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    text = "foo\nbar\n"
    response = get_response_object(text)
    result = list(response.iter_lines(chunk_size=1))
    expected = [
        (b'foo\n', b'\n'),
        (b'bar\n', b'\n'),
    ]
    assert result == expected, result



# Generated at 2022-06-21 13:51:34.881438
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = requests.get('http://www.google.com')
    assert isinstance(req, requests.models.Response)
    assert isinstance(HTTPResponse(req), HTTPResponse)


# Generated at 2022-06-21 13:51:40.307008
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    try:
        response = requests.get("https://github.com/")
        if response.status_code == 200:
            http_message = HTTPResponse(response)
            assert http_message._orig == response
            assert http_message.headers == response.raw._original_response.msg.headers
            assert http_message.encoding == response.encoding 
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-21 13:51:45.793538
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    body = b"TOTAL CALORIES: 690 TOTAL SODIUM: 1460 mg TOTAL CARBS: 50 g TOTAL FAT: 0 g TOTAL PROTEIN: 45 g"
    headers = {'Content-Type': 'text/plain'}
    orig = requests.models.Response()
    orig.headers = headers
    orig._content = body
    test_HTTPMessage = HTTPResponse(orig)
    resp = test_HTTPMessage.iter_lines(chunk_size=1)
    resp = list(resp)
    assert resp == [(line, b'\n') for line in orig.iter_lines(chunk_size=1)]


# Generated at 2022-06-21 13:52:00.953695
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    """Test for method iter_body of class HTTPMessage."""

    # Create an instance of HTTPMessage.
    orig = b'foo bar body'
    http_message = HTTPMessage(orig)

    # Test iter_body, a method of HTTPMessage.
    for chunk in http_message.iter_body(0):
        print(chunk)
        assert chunk == b'foo bar body'



# Generated at 2022-06-21 13:52:01.916883
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    assert(True)


# Generated at 2022-06-21 13:52:04.802771
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    txt = "test"
    b = txt.encode("utf-8")
    response = Mock()
    response.content = b
    message = HTTPResponse(response)
    lines = list(message.iter_lines(chunk_size=1))
    assert lines[0][0] == b
    assert lines[0][1] == b''
    assert len(lines) == 1


# Generated at 2022-06-21 13:52:11.122643
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    resp = HTTPResponse(requests.get('https://github.com/'))
    gen = resp.iter_lines(10)
    assert next(gen) == (b'<!DOCTYPE html>', b'\n')
    assert next(gen) == (b'<html lang="en">', b'\n')
    assert next(gen)[1] == b' '
    assert next(gen) == (b'<meta charset="utf-8">', b'\n')



# Generated at 2022-06-21 13:52:20.118667
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
  from inspect import getfullargspec
  from functools import reduce
  from pytest import raises
  from hypothesis import given
  from hypothesis.strategies import characters, integers, lists, text
  with raises(NotImplementedError):
    HTTPMessage(None).iter_lines(1)
  class TestHTTPMessage(HTTPMessage):
    def __init__(self,orig):
      self._orig = orig
    def iter_body(self, chunk_size):
      return self._orig.iter_content(chunk_size=chunk_size)
    @property
    def headers(self):
      return self._orig.headers
    @property
    def encoding(self):
      return self._orig.encoding
    @property
    def body(self):
      return self._orig.content

# Generated at 2022-06-21 13:52:30.374456
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from io import IOBase
    from io import BytesIO
    from io import StringIO
    from requests.models import Response

    line1 = b'Some text.\n'
    line2 = b'And some more.\n'
    line3 = b'And more...\n'

    response = Response()

    # Test #1: no body
    response.raw = IOBase()
    response.raw._original_response = type('Original', (object,), {})
    response.raw._original_response.version = 11
    response.raw._original_response.status = 200
    response.raw._original_response.reason = 'OK'
    response.raw._original_response.msg = type('Original', (object,), {})

# Generated at 2022-06-21 13:52:33.567256
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    import requests
    r = requests.get(bot.wikipedia.api_url + '?action=query&format=json&list=random&rnnamespace=0')
    http = HTTPResponse(r)
    assert(http.headers)
    assert(http.body)


# Generated at 2022-06-21 13:52:35.668718
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
        assert(HTTPResponse is not None)


# Generated at 2022-06-21 13:52:41.548335
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    response = requests.get("https://www.w3.org/TR/PNG/iso_8859-1.txt")
    response_body = response.content
    httpresponse_object = HTTPResponse(response)
    data_received = b''    
    for data in httpresponse_object.iter_body():
        data_received += data
    assert data_received == response_body


# Generated at 2022-06-21 13:52:43.294659
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = 'http://httpbin.org/get'
    HTTPRequest(url)

# Generated at 2022-06-21 13:53:03.112421
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    '''
    This unit test is created to test the method iter_body of class HTTPResponse.

    The function will return None
    '''

    return None


# Generated at 2022-06-21 13:53:04.114957
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert HTTPMessage()

# Generated at 2022-06-21 13:53:08.329667
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    import requests
    r = requests.get("http://www.python.org")
    assert isinstance(r, requests.models.Response), "r should be an instance of Response"
    httpResponse = HTTPResponse(r)
    assert isinstance(httpResponse, HTTPResponse), "httpResponse should be an instance of HTTPResponse"



# Generated at 2022-06-21 13:53:13.842565
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    a = 'line 1\nline 2\nline 3\n'
    b = bytearray(a, 'utf-8')
    c = io.BytesIO(b)
    d = urllib3.response.HTTPResponse(c, headers={'Content-Type': 'text/plain'})
    e = HTTPResponse(d)

    expected_result = [
        (b'line 1', b'\n'),
        (b'line 2', b'\n'),
        (b'line 3', b'\n'),
    ]

    assert list(e.iter_lines(None)) == expected_result

# Generated at 2022-06-21 13:53:23.087774
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    r = requests.get("http://vinta.ws")
    response = HTTPResponse(r)
    n = 0
    while n < 10:
        n += 1
        lines = response.iter_lines(chunk_size=1)
        for line, line_feed in lines:
            assert len(line) > 0
            if sys.version_info.major == 2:
                print(line, line_feed)
            else:
                print(line.decode('utf8'), line_feed.decode('utf8'))

# test_HTTPResponse_iter_lines()

# Generated at 2022-06-21 13:53:34.537957
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    response = requests.Response()
    response._content = b'this is a test\r\nwith line feeds\r\n'
    response._content_consumed = True
    http_message = HTTPResponse(response)

    # Test case 1
    # Check if line==b'this is a test\r\n' and line_feed==b'\n'
    test_line, test_line_feed = next(http_message.iter_lines(0))
    assert (test_line == b'this is a test\r\n')
    assert (test_line_feed == b'\n')

    # Test case 2
    # Check if line==b'with line feeds\r\n' and line_feed==b'\n'

# Generated at 2022-06-21 13:53:46.418999
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    filename = 'test/fixtures/log_request_response.json'
    with open(filename, 'r', encoding='utf8') as f:
        objects = json.load(f)

    request_objects = objects['entries'][0]['request']
    req = HTTPRequest(request_objects)
    req_lines = list(req.iter_lines(chunk_size=0))
    assert req_lines[0][0] == '{"message":"test"}'
    assert req_lines[0][1] == b''

    response_objects = objects['entries'][0]['response']
    res = HTTPResponse(response_objects)
    res_lines = list(res.iter_lines(chunk_size=0))
    assert res_lines[0][0] == '{"message":"ok"}'


# Generated at 2022-06-21 13:53:54.708666
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    import requests
    import functools

    test_url = "https://httpbin.org/"
    response = requests.get(test_url+'uuid')
    test_uuid = response.json()['uuid']

    iter_size = 1000
    result_list = []

    def test_body_chunk_size(iter_size):
        test_body_chunk_size = functools.partial(HTTPResponse.iter_body, chunk_size=iter_size)
        expected_result = [iter_size * b'0' for i in range(12)]
        for i, chunk in enumerate(test_body_chunk_size(HTTPResponse(requests.get(test_url+'bytes/%d'%iter_size)))):
            result_list.append(chunk)


# Generated at 2022-06-21 13:54:00.205851
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    r = requests.post(url='http://httpbin.org/post', data={"key": "value"})
    origin = r.request
    request = HTTPRequest(origin)
    print(request.headers)
    print(list(request.iter_body(chunk_size=None)))
    print(''.join(iter(request.iter_body(chunk_size=None))))


# Generated at 2022-06-21 13:54:08.351675
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """Test the method iter_lines of class HTTPRequest."""

    request = HTTPRequest('hello')

    # check the result is the same as body
    assert bytes(request.iter_lines()) == b'hello'

    # check result is a iter of tuple
    assert isinstance(request.iter_lines(), tuple)

    # check the length of result is 2
    assert len(request.iter_lines()) == 2

    # check the first element of iter is the same as body
    assert bytes(request.iter_lines()[0]) == b'hello'

    # check the second element of iter is b''
    assert request.iter_lines()[1] == b''

# Generated at 2022-06-21 13:54:46.409039
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    from requests import models
    try:
        HTTPMessage(models.Response())
        HTTPMessage(models.Request())
    except NotImplementedError:
        print("You did not Test HTTPMessage constructors")
    else:
        print("You tested HTTPMessage constructors")
        return True
    return False


# Generated at 2022-06-21 13:54:53.865075
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    """Test functions."""
    import requests
    import json
    r = requests.post('http://httpbin.org/post', json=dict(a='b'))
    assert r.status_code == 200
    response = HTTPResponse(r)
    result = bytearray()
    for line, line_feed in response.iter_lines(1024):
        result.extend(line)
        result.extend(line_feed)
    assert json.loads(result)['data'] == '{"a": "b"}'


# Generated at 2022-06-21 13:55:03.921723
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    class HTTPMessageTest(HTTPMessage):
        def iter_body(self, chunk_size: int) -> Iterable[bytes]:
            return self._orig.iter_content(chunk_size=chunk_size)
        def iter_lines(self, chunk_size: int) -> Iterable[bytes]:
            return ((line, b'\n') for line in self._orig.iter_lines(chunk_size))
        @property
        def headers(self):
            raise NotImplementedError()
        @property
        def encoding(self):
            return None
        @property
        def body(self):
            return self._orig.content

    class HTTPMessageTest2(HTTPMessageTest): 
        def iter_body(self, chunk_size: int) -> Iterable[bytes]:
            return self

# Generated at 2022-06-21 13:55:05.914778
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    try:
        return HTTPMessage("a")
    except NotImplementedError:
        pass


# Generated at 2022-06-21 13:55:16.719887
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    from http.client import HTTPResponse
    from io import BytesIO
    message = BytesIO(b'abc\r\nabc\r\nabc')
    response = HTTPResponse(message)
    response.begin()
    lines_iterator = response.iter_lines(chunk_size=1)
    line1, delim1 = next(lines_iterator)
    assert line1 == b'abc'
    assert delim1 == b'\r\n'
    line2, delim2 = next(lines_iterator)
    assert line2 == b'abc'
    assert delim2 == b'\r\n'
    line3, delim3 = next(lines_iterator)
    assert line3 == b'abc'
    assert delim3 == b''

# Generated at 2022-06-21 13:55:23.857842
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests
    import json
    import sys
    import io

    # Save stdout
    stdout = sys.stdout
    # Stream to capture stdout
    stream = io.StringIO()
    # Redirect stdout
    sys.stdout = stream

    # Send a request
    response = requests.get('https://api.github.com/users/requests/repos')
    if response.status_code == 200:
        # Process response
        response = HTTPResponse(response)
        # For each body of the response ...
        for body in response.iter_body():
            # ... convert the body to object
            json_body = json.loads(body)
            # Print name of repository
            print(json_body["name"])
   
    # Reset stdout
    sys.stdout = stdout
   

# Generated at 2022-06-21 13:55:35.201922
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    resp = requests.Response()
    resp.request = requests.Request()
    resp.encoding = 'utf8'
    resp.status_code = 200
    resp.request.method = 'GET'
    resp.request.url = 'http://example.com'
    resp.raw.version = 11
    resp.raw.reason = 'OK'
    resp._content = b'a\r\nb\r\n\r\nc\r\n\r\n'
    http_respons = HTTPResponse(resp)

    lines = list(http_respons.iter_lines(10))
    assert len(lines) == 4
    assert lines[0] == (b'a', b'\r\n')
    assert lines[1] == (b'b', b'\r\n')
    assert lines[2]

# Generated at 2022-06-21 13:55:35.835740
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert True

# Generated at 2022-06-21 13:55:44.543135
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    # test with normal inputs, method iter_lines.
    assert list(HTTPResponse(1).iter_lines(1)) == [1]
    assert list(HTTPResponse(2).iter_lines(1)) == [2]
    assert list(HTTPResponse(3).iter_lines(1)) == [3]

    # test with normal inputs, method iter_lines.
    assert list(HTTPRequest(1).iter_lines(1)) == [1]
    assert list(HTTPRequest(2).iter_lines(1)) == [2]
    assert list(HTTPRequest(3).iter_lines(1)) == [3]

    # test with unusual inputs, method iter_lines.
    assert list(HTTPResponse(1).iter_lines(0)) == [1]

# Generated at 2022-06-21 13:55:47.793079
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    r = HTTPRequest(requests.Request('GET', 'https://www.google.com.hk'))
    print(r)
    for line, line_feed in r.iter_lines(chunk_size=None):
        print(line)
    print(r.body)

# Generated at 2022-06-21 13:57:02.760581
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    url = 'https://google.com'
    response = requests.get(url)
    http_response = HTTPResponse(response)
    for line in http_response.iter_lines():
        if not line:
            break
        print(line)


# Generated at 2022-06-21 13:57:10.201034
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    # r = requests.get('https://www.google.com/')
    r = requests.get('file:///tmp/file')
    lines = []
    for line, line_feed in HTTPResponse(r).iter_lines(10):
        lines.append((line, line_feed))

    assert lines == [
        (b'first line', b'\n'),
        (b'second line', b'\n'),
        (b'third line', b'\n'),
        (b'fourth line', b'')
    ]

# Generated at 2022-06-21 13:57:12.865814
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    orig = request.Request('https://google.com')
    http_request = HTTPRequest(orig)
    content = http_request.iter_body(1)
    assert list(content) == []


# Generated at 2022-06-21 13:57:20.780537
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    # Create a mock object
    response_mock = MagicMock()
    # Mock the iter_lines method that return an iterable object
    response_mock.iter_lines.return_value = iter([
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'])
    # Create a HTTPResponse object
    response = HTTPResponse(response_mock)
    assert list(response.iter_lines(2)) == [
        (b'0\n1', b'\n'), (b'2\n3', b'\n'), (b'4\n5', b'\n'), (b'6\n7', b'\n'), (b'8\n9', b'')]



# Generated at 2022-06-21 13:57:23.140306
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    # TODO: Create a dummy request object 
    # to test the constructor of class HTTPMessage
    pass

# Unit tests for property `headers` of class HTTPMessage

# Generated at 2022-06-21 13:57:28.659589
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    import requests
    response = requests.get('https://github.com')
    assert isinstance(response,requests.models.Response)
    print(response)
    response_wrapper = HTTPResponse(response)
    assert isinstance(response_wrapper,HTTPResponse)

# Generated at 2022-06-21 13:57:39.849842
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from .base import wrap_command
    from .base import get_argv
    import sys
    import os
    sys.argv = get_argv(sys.argv)
    from . import main
    import requests
    from .base import wrap_command
    from .base import get_argv
    from .base import wrap_command
    from .base import get_argv
    import sys
    import os
    sys.argv = get_argv(sys.argv)
    from . import main
    import requests
    response = requests.get("https://httpie.org")
    assert response.status_code == 200
    assert response.text == "Hello world!"
    response = requests.get("https://httpie.org")
    assert response.status_code == 200
    assert response.text == "Hello world!"


# Generated at 2022-06-21 13:57:47.444690
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    import requests
    r = requests.get('http://httpbin.org/')

    lines = list(r.iter_lines())

    # The last line is ''
    assert lines[-1] == b''

    # The other lines should be followed by a linefeed
    for line in lines[:-1]:
        assert line.endswith(b'\n')

    # Check the content, should contain 'HTTPBin'
    content = b''.join(lines)
    assert b'HTTPBin' in content

# Generated at 2022-06-21 13:57:50.873821
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    response = requests.get("http://www.baidu.com")
    b = HTTPResponse(response)
    for i in b.iter_body(1):
        print(i,end="")


# Generated at 2022-06-21 13:57:57.642838
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    try:
        import requests
    except ImportError:
        print('Requests library is not installed')

    print('Constructor of class HTTPRequest')
    test_url = 'http://www.domain.com'
    r = requests.Request(method='GET', url=test_url, data={3: '3'},
                         params={1: '1'})
    assert r.method == 'GET'
    assert r.url == test_url + '?1=1'
    assert r.data == '3=3'

    # Unit test for body property of class HTTPRequest
    print('Body property of class HTTPRequest')
    assert HTTPRequest(r).body == b'3=3'

    # Unit test for headers property of class HTTPRequest
    print('Headers property of class HTTPRequest')

# Generated at 2022-06-21 14:00:27.438658
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    from requests import Response
    resp = Response()
    resp._content = b'Hello World'
    resp.status_code = 200
    x = HTTPResponse(resp)
    assert x.headers == 'HTTP/1.1 200 OK'


# Generated at 2022-06-21 14:00:34.829293
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://httpbin.org/anything?a=b&c=d"
    method = "POST"
    headers = {
        "Host": "httpbin.org",
        "Accept-Encoding": "gzip, deflate"
    }
    request = requests.Request(method, url, headers=headers)
    prepared_request = requests.Session().prepare_request(request)
    http_request = HTTPRequest(prepared_request)

    assert request.url == http_request._orig.url
    assert request.method == http_request._orig.method
    assert request.headers == http_request._orig.headers
    assert "Host: httpbin.org" in http_request.headers
    assert "Accept-Encoding: gzip, deflate" in http_request.headers