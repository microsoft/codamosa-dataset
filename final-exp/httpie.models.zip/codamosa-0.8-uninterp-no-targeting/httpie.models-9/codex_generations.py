

# Generated at 2022-06-21 13:50:48.451624
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    """Test method iter_body of class HTTPMessage."""
    message = 'foo bar baz'
    message = HTTPMessage(message)

    assert [b'foo bar baz'] == list(message.iter_body(0))
    assert [b'foo ', b'bar ', b'baz'] == list(message.iter_body(5))


# Generated at 2022-06-21 13:50:56.756962
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = requests.Request('GET', 'http://httpbin.org/get')
    req = req.prepare()
    hreq = HTTPRequest(req)
    assert hreq.content_type == 'application/x-www-form-urlencoded'
    assert hreq.encoding == 'utf8'
    assert hreq.body == b''
    assert hreq.headers == '''GET /get HTTP/1.1
Host: httpbin.org'''
    assert len(list(hreq.iter_body(2))) == 1
    assert list(hreq.iter_body(2))[0] == b''

# Generated at 2022-06-21 13:50:57.871953
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert True

# Generated at 2022-06-21 13:51:03.481154
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from requests.models import Request
    r = Request('GET', 'https://api.github.com/search/code?q=addClass+user:mozilla')
    r = HTTPRequest(r)

    # Should not iter over the body, but only return the body once.
    assert list(r.iter_body(10)) == [b'']



# Generated at 2022-06-21 13:51:06.123072
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    msg = HTTPMessage(1)
    assert msg.iter_body(1) == NotImplementedError()


# Generated at 2022-06-21 13:51:11.758518
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """Test for iter_lines method of HTTPMessage class."""
    r = requests.Request('POST', 'http://127.0.0.1:8080', data={}, headers={})
    s = HTTPRequest(r)
    assert list(s.iter_lines(1)) == [(b'', b'')]
    assert list(s.iter_lines(2)) == [(b'', b'')]

# Generated at 2022-06-21 13:51:13.096762
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    test_body = 'hello'
    test_iter_body = HTTPMessage.iter_body(None, 1)
    assert next(test_iter_body) == test_body


# Generated at 2022-06-21 13:51:24.555317
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    import requests

    url = 'https://httpbin.org/status/200'
    r = requests.get(url, verify=False)

    # check the var r's type
    assert type(r) == requests.models.Response

    # Test the class HTTPResponse
    r_message = HTTPResponse(r)
    assert r_message.headers == 'HTTP/1.1 200 OK\r\n'
    assert r_message.encoding == 'utf-8'
    assert len(r_message.body) == 0

    # Test the class HTTPRequest (not so useful)
    req = HTTPRequest(r.request)
    assert req.headers == 'GET /status/200 HTTP/1.1\r\n'
    assert req.encoding == 'utf8'
    assert req.body == b''

# Generated at 2022-06-21 13:51:35.529372
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    import requests
    from urllib.parse import urljoin

    base = "http://127.0.0.1:9323/"
    url = urljoin(base, "test/test_HTTPResponse.txt")
    res = requests.get(url)
    print(HTTPResponse(res).headers)
    print(HTTPResponse(res).encoding)
    print(HTTPResponse(res).body)
    print(HTTPResponse(res).content_type)

if __name__ == '__main__':
    print("Test of class HTTPResponse:")
    test_HTTPResponse()

# Generated at 2022-06-21 13:51:42.191784
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    '''
    This test checks if the iter_lines method of class HTTPRequest works correctly.
    The iter_lines method is assumed to work correctly if it returns an empty string.

    Note: This test is not an actual unittest. It is a small, manually executed ad-hoc test.
    '''

    # create an empty HTTPRequest object
    request_object = HTTPRequest('')
    # check if the iter_lines method works correctly
    result = request_object.iter_lines('')
    print(result)

# call the test
test_HTTPRequest_iter_lines()

# Generated at 2022-06-21 13:51:56.649711
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    # Test code
    class _c(HTTPMessage):
        def iter_lines(self, chunk_size: int) -> Iterable[bytes]:
            return iter(['DDD', 't', 'e', 's', 't'])

    for line, line_feed in _c(None).iter_lines(1):
        print(line)
        print(line_feed)
test_HTTPMessage_iter_lines()

# Generated at 2022-06-21 13:51:59.616661
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    import requests
    
    request = requests.Request('GET', 'https://www.google.com')
    req = HTTPRequest(request)
    print(req.headers)
    print(req.body)


# Generated at 2022-06-21 13:52:04.829696
# Unit test for constructor of class HTTPResponse

# Generated at 2022-06-21 13:52:10.952289
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests

    #: :type: requests.models.Response
    resp = requests.get('https://httpbin.org/get')
    assert isinstance(resp, requests.models.Response)

    #: :type: HTTPResponse
    hresp = HTTPResponse(resp)
    assert isinstance(hresp, HTTPResponse)
    assert isinstance(hresp.body, bytes)
    assert isinstance(hresp.body.decode('UTF-8'), str)
    assert isinstance(hresp.iter_body(0), Iterable)
    #print("resp=" + hresp.body.decode('UTF-8'))



# Generated at 2022-06-21 13:52:12.305716
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    req = HTTPRequest(None)
    assert req.iter_lines(0) is not None

# Generated at 2022-06-21 13:52:13.769089
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    msg = HTTPMessage('')
    assert msg is not None


# Generated at 2022-06-21 13:52:20.056853
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    try:
        from requests.models import Request
    except ImportError:
        return

    request = Request(
        method='GET',
        url='http://example.org/',
        headers={
            'X-Foo': 'bar',
        },
    )
    message = HTTPRequest(request)

    assert message.headers == (
        'GET / HTTP/1.1\r\n'
        'X-Foo: bar\r\n'
        'Host: example.org'
    )

    assert message.body == b''



# Generated at 2022-06-21 13:52:23.624893
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    string = b'Hello world\nthis is a test'
    lines = HTTPMessage(None).iter_lines(1)
    assert string == b''.join(chunk for chunk, _ in lines)


# Generated at 2022-06-21 13:52:30.561025
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    try:
        with requests.get('https://www.google.com') as response:
            response.encoding = 'utf-8'
            print(response.text)
            print(response.status_code)
            print(response.cookies)
        #r = HTTPResponse(response)
        r = HTTPResponse(requests.get('https://www.google.com'))
        assert r.headers
        assert r.body
        assert r.encoding
        print(r)
    except Exception as e:
        print(e)


# Generated at 2022-06-21 13:52:31.493563
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    http_message = HTTPMessage()
    assert http_message is not None

# Generated at 2022-06-21 13:52:59.326808
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from requests import Request, session
    from datetime import timedelta
    import http.cookies
    from requests.utils import to_native_string
    from werkzeug.datastructures import Headers
    from werkzeug.urls import Href
    method = 'POST'
    url = 'http://127.0.0.1:9090/aaa'
    headers = {'a': 'b'}
    data = 'aaa'
    json = None
    files = None
    params = None
    auth = None
    cookies = None
    hooks = None

    # cookies is a string, but it is not normal in requests.
    cookies = "a=bb"

# Generated at 2022-06-21 13:53:04.119606
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from requests import Request
    req = Request(method="GET", url="https://httpbin.org/get", headers={})
    assert isinstance(HTTPRequest(req), HTTPRequest)
    assert isinstance(req.method, str)
    assert isinstance(req.url, str)
    assert isinstance(req.headers, dict)

# Generated at 2022-06-21 13:53:12.231367
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    class MockHTTPMessage(HTTPMessage):
        def __init__(self, orig, body):
            HTTPMessage.__init__(self, orig)
            self._body = body
        def iter_body(self, chunk_size):
            return self._body.__iter__()
    f = 'random_string'
    body = f.split('_')
    mock_request = MockHTTPMessage(None, body)
    mock_body = mock_request.iter_body(chunk_size=None)
    for x in mock_body:
        assert x in body


# Generated at 2022-06-21 13:53:23.979745
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    from requests import Request, Response
    from requests.structures import CaseInsensitiveDict
    from http.client import HTTPMessage
    from http.cookies import SimpleCookie
    from http.server import BaseHTTPRequestHandler

    class Obj(object):
        def __init__(self):
            self.status = '200'
            self.reason = 'OK'
            self.version = 11
            self.msg = HTTPMessage()
            self.msg._headers = [('Content-Type', 'text/html')]
            self.msg.headers = ['Content-Type: text/html']
            self.msg.dict = CaseInsensitiveDict(
                [('Content-Type', 'text/html')])
            self.msg.headers = [('Content-Type', 'text/html')]


# Generated at 2022-06-21 13:53:34.875609
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    body = b'\n'.join(b'Line %d' % i for i in range(10))

    # Unit test for method iter_body of class HTTPResponse
    class FakeResponse(object):
        def __init__(self, body: bytes, chunk_size: int) -> None:
            self.body = body
            self.chunk_size = chunk_size

        def iter_content(self, chunk_size: int) -> Iterable[bytes]:
            yield self.body[: self.chunk_size]

        @property
        def headers(self):
            return {}

    hm0 = HTTPResponse(FakeResponse(body, chunk_size=5))
    assert list(hm0.iter_body()) == [b'Line 0']


# Generated at 2022-06-21 13:53:42.533622
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    from requests.models import Response
    response = Response()
    response.headers = {'Content-Type':'application/json'}
    response.content = b'{"foo":"bar"}'
    response.raw = {'version':'1.1', 'status':'200', 'reason':'OK'}
    assert HTTPResponse(response).headers == 'HTTP/1.1 200 OK\r\nContent-Type: application/json'


# Generated at 2022-06-21 13:53:52.227638
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    import requests
    import http
    import mock

    # Create a mock request
    with mock.patch.object(requests.models.Request, 'prepare') as mock_prepare:
        ct = 'content-type'
        method = 'method'
        body = 'body'
        request = requests.Request(method, 'url', data=body, headers={ct:ct})
        prepared_request = request.prepare()
        mock_prepare.return_value = prepared_request

        # Create a mock response
        response = requests.Response()
        response.request = mock.MagicMock()
        response.request.method = method
        response.status_code = http.HTTPStatus.OK
        response.reason = 'OK'
        response.request.url = 'url'
        response.headers = {ct:ct}
       

# Generated at 2022-06-21 13:53:53.264574
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    assert HTTPResponse(None) != 0


# Generated at 2022-06-21 13:53:57.353233
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    lines = [b"Hello", b"World", b"!"]
    class MockHTTPMessage:
        def iter_content(self, chunk_size=1):
            for line in lines:
                yield line
                yield b"\n"
    htm = HTTPMessage(MockHTTPMessage())
    for index, (line, line_feed) in enumerate(htm.iter_lines(0)):
        assert lines[index] == line
        assert b"\n" == line_feed


# Generated at 2022-06-21 13:54:04.170078
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    response = requests.get("http://www.google.com")
    message = HTTPResponse(response)
    assert message._orig == response
    assert isinstance(message.iter_body(1), Iterable)
    assert isinstance(message.iter_lines(1), Iterable)
    assert message.encoding == 'ISO-8859-1'
    assert isinstance(message.body, bytes)
    assert isinstance(message.headers, str)
    assert isinstance(message.content_type, str)

# Generated at 2022-06-21 13:54:41.224820
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    import requests
    data = {'key1': 'value1', 'key2': 'value2'}
    r = requests.Request('POST', 'http://httpbin.org/post', data=data)
    req = HTTPRequest(r)
    body = req.body
    assert(body == b'key1=value1&key2=value2')
    for chunk in req.iter_body(4):
        assert(chunk == b'key1=value1&key2=value2')

# Generated at 2022-06-21 13:54:45.478114
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    response = HTTPResponse('original')
    # raise NotImplementedError()
    body = response.iter_body(1)
    assert isinstance(body, Iterable)
    try:
        for i in body:
            assert 1
    except NotImplementedError:
        assert 0


# Generated at 2022-06-21 13:54:51.980628
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    request = Request('POST', 'http://example.com/path')
    request.headers['Content-type'] = 'text/plain'
    request.data = "hey\nthere\n"
    wrapped_request = HTTPRequest(request)
    for line, lineterminator in wrapped_request.iter_lines(chunk_size=1):
        assert line == line + lineterminator
    return


# Generated at 2022-06-21 13:55:00.280217
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests
    import json

    with requests.post("http://httpbin.org/post", json={"key": "value"}) as resp:
        htm = HTTPResponse(resp)
        htm1 = HTTPResponse(resp)
        body = list(htm.iter_body(chunk_size=1))
        body1 = resp.content

    assert(body == [body1])
    #Check if chunks are created
    assert(len(body) != len(body1))
    #Check if chunks are of same length
    assert(all(len(i) == 1 for i in body))


# Generated at 2022-06-21 13:55:04.945783
# Unit test for method iter_body of class HTTPResponse
def test_HTTPResponse_iter_body():
    import requests
    r = requests.get("https://www.google.com/")

    test_resp = HTTPResponse(r)
    chunk_size = 1
    body_list = []
    for b in test_resp.iter_body(chunk_size=chunk_size):
        body_list.append(b)
    assert len(body_list) > 0


# Generated at 2022-06-21 13:55:09.304224
# Unit test for method iter_lines of class HTTPResponse
def test_HTTPResponse_iter_lines():
    req = requests.get('https://httpbin.org/get')
    # Initialization
    response = HTTPResponse(req)
    # Test the method iter_lines
    i = 0
    for j in response.iter_lines(10):
        i = i + 1
    assert i > 0


# Generated at 2022-06-21 13:55:17.433217
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    import requests
    import io

    response = requests.Response()
    response.headers['Content-Type'] = 'text/plain; charset=ISO-8859-1'
    response.raw = io.BytesIO(b'one\r\ntwo\r\n\r\n')
    response._content_consumed = True

    hrm = HTTPResponse(response)
    lines = list(hrm.iter_lines(1))
    assert lines == [(b'one', b'\r\n'), (b'two', b'\r\n'), (b'', b'\r\n')]

# Generated at 2022-06-21 13:55:21.093330
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from requests.models import Request
    r = Request('GET', 'https://github.com/')
    httpRequest = HTTPRequest(r)
    headers = httpRequest.headers
    print(headers)
    encoding = httpRequest.encoding
    print(encoding)
    body = httpRequest.body
    print(body)


# Generated at 2022-06-21 13:55:26.311057
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    # Setup
    http_request = HTTPRequest(1)
    http_request._orig = 'test'
    http_request._orig.body = 'test'
    # Exercise and Verify
    for line in http_request.iter_lines(1):
        assert line == (b'test', b'')


# Generated at 2022-06-21 13:55:37.532164
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from unittest import TestCase
    from httpie.core import main
    from httpie.output.streams import BytesIOBytes

    class _TestHTTPResponse(TestCase):
        def test_default_chunk_size(self):
            class TestHTTPRequest(HTTPRequest):
                def _gen_body(self):
                    for i in range(2):
                        yield b'ciao'
                @property
                def body(self):
                    return b''.join(self._gen_body())
            r = TestHTTPRequest(None)
            result = [chunk for chunk in r.iter_body()]
            self.assertEqual(result, [b'ciao', b'ciao'])


# Generated at 2022-06-21 13:56:49.458736
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
  req = HTTPRequest(Response)
  print(HTTPRequest.headers)


# Generated at 2022-06-21 13:57:01.280258
# Unit test for method iter_body of class HTTPMessage
def test_HTTPMessage_iter_body():
    def test_type_error():
        try:
            HTTPMessage.iter_body(1)
        except TypeError as e:
            assert str(e) == 'iter_body() missing 1 required positional argument: \'chunk_size\''
    
    test_type_error()

    # Unit test for method iter_body of class HTTPResponse
    def test_HTTPResponse_iter_body():
        response = requests.get('http://httpbin.org/get')
        content = ''
        for c in HTTPResponse(response).iter_body(1024):
            content += c.decode('utf-8')

        assert content == response.text

    test_HTTPResponse_iter_body()

    # Unit test for method iter_body of class HTTPRequest

# Generated at 2022-06-21 13:57:09.556259
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    with pytest.raises(NotImplementedError): HTTPMessage(None).iter_body()
    with pytest.raises(NotImplementedError): HTTPMessage(None).iter_lines()
    with pytest.raises(NotImplementedError): HTTPMessage(None).headers
    with pytest.raises(NotImplementedError): HTTPMessage(None).encoding
    with pytest.raises(NotImplementedError): HTTPMessage(None).body
    with pytest.raises(NotImplementedError): HTTPMessage(None).content_type

# Generated at 2022-06-21 13:57:11.726242
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert isinstance(HTTPMessage(None), (HTTPMessage))


# Generated at 2022-06-21 13:57:14.506600
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    req = HTTPRequest(requests.models.Request('GET', 'http://www.google.fr'))
    assert(next(req.iter_body(1024)) == b'')


# Generated at 2022-06-21 13:57:15.969075
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    msg = HTTPMessage('orig')
    assert msg._orig == 'orig'


# Generated at 2022-06-21 13:57:25.145676
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    from requests import Request
    from io import BytesIO
    from collections import namedtuple

    response = namedtuple('Response', 'raw headers')
    # Make a socket that returns responses on request.
    def sock(data):
        def _sock(whattodo, whatever):
            return BytesIO(data)
        return _sock

    tst_data = b"HTTP/1.1 200 OK\r\nContent-type:text/html;charset=utf-8\r\nContent-length:11\r\n\r\nhello world"
    # Create a test case
    tst_request = Request(method='GET', url='', data=dict(), headers=dict(), params=dict())
    tst_response = response(raw=None, headers=dict())
    tst_response.raw = sock

# Generated at 2022-06-21 13:57:26.932179
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    pass


# Generated at 2022-06-21 13:57:37.374066
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    from http_prompt.exceptions import CancelCommandException
    from http_prompt.input import CommandProcessor
    from http_prompt.requests_utils import RequestsSession
    from http_prompt import settings
    from plumbum import local

    cp = CommandProcessor(settings)
    session = RequestsSession()
    cp.register_command('request', session.request)
    cp.session = session
    try:
        cp.cmdloop()
        assert False
    except CancelCommandException:
        # Command cancelled by Ctrl-C
        pass
    # Enter new request
    cp.cmdloop(['request', '-X', 'GET', 'https://httpbin.org/image/png'])
    # follow in the request, to get the response
    cp.cmdloop(['follow'])

# Generated at 2022-06-21 13:57:41.845370
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    """
        To test the constructor of the class HTTPResponse.
    """
    # Create an instance of HTTPResponse
    response = HTTPResponse("test")
    assert response != None


# Generated at 2022-06-21 14:00:06.286675
# Unit test for method iter_body of class HTTPRequest
def test_HTTPRequest_iter_body():
    from .errors import HTTPError

    # Test normal case
    # test data from http://httpbin.org/html
    request = {
        'method': 'GET',
        'url': 'http://httpbin.org/html',
        'headers': {},
        'content': b''
    }
    r = HTTPRequest(request)
    body = b''
    for b in r.iter_body(1024):
        body += b
    try:
        assert body == b'<html><head><title>Html</title></head><body><p>Html page</p></body></html>\n'
    except AssertionError:
        raise HTTPError("Test for HTTPRequest failed")
    
    # Test for if content is string and error

# Generated at 2022-06-21 14:00:08.859432
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    import requests
    r = requests.Request("GET", "https://www.wikipedia.org")
    req = HTTPRequest(r)
    req.headers
    return req.headers

# Generated at 2022-06-21 14:00:20.844316
# Unit test for method iter_lines of class HTTPRequest
def test_HTTPRequest_iter_lines():
    """ Unit test for method iter_lines() of class HTTPRequest."""
    from requests import Request
    from io import BytesIO
    from agent import HTTPRequest
    from agent import HTTPResponse

    # case: request with no body
    request = Request('GET', 'http://example.com/', headers={'Foo': 'bar'})
    prequest = HTTPRequest(request)
    body, line_feed = next(prequest.iter_lines(1))
    assert body == b''
    assert line_feed == b''

    # case: request with body
    request = Request('POST', 'http://example.com/', data='payload')
    prequest = HTTPRequest(request)
    body, line_feed = next(prequest.iter_lines(1))
    assert body == b'payload'
    assert line

# Generated at 2022-06-21 14:00:29.188789
# Unit test for method iter_lines of class HTTPMessage
def test_HTTPMessage_iter_lines():
    # TODO(typing): fix type when b'' is bytes instead of str
    def f(chunk_size):
        return lambda x: iter(
            # noinspection PyTypeChecker
            b''.join(y[0] for y in x.iter_lines(chunk_size=chunk_size)),
            b'')

    text = 'hello'
    request = requests.Request('GET', 'https://httpbin.org/get')
    request.prepare()
    http_request = HTTPRequest(request)
    assert list(http_request.iter_lines(chunk_size=1)) == [(b'hello', b'')]
    assert list(http_request.iter_lines(chunk_size=2)) == [(b'hello', b'')]

# Generated at 2022-06-21 14:00:29.987996
# Unit test for constructor of class HTTPMessage
def test_HTTPMessage():
    assert issubclass(HTTPMessage,object)

# Generated at 2022-06-21 14:00:32.850457
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    """Test the constructor of class HTTPResponse"""
    # Make a fake response
    response = requests.Response()
    response.headers = {'foo': 'bar'}
    assert(isinstance(HTTPResponse(response).headers, str))
    return True
