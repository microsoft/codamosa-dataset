

# Generated at 2022-06-11 08:43:54.068754
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method `ModuleArgsParser.parse`
    '''
    # setup
    loader = DataLoader()
    task_ds = yaml.safe_load('''
        action: {module: copy, src: a, dest: b}
        ''')
    obj = ModuleArgsParser(task_ds)
    # perform action
    actual = obj.parse()
    # assert
    assert actual == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-11 08:44:01.803893
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_thing is an instance of ModuleArgsParser
    test_thing = ModuleArgsParser()
    # Initialized test variables
    action = 'setup'
    delegate_to = 'localhost'
    thing = dict()
    args = dict()
    action, args, delegate_to = test_thing.parse(skip_action_validation=False)
    # assert action == 'setup'
    # assert delegate_to == 'localhost'
    # assert thing == {}, "Expected {}, but got {}".format(dict(), thing)
    # assert args == {}, "Expected {}, but got {}".format(dict(), args)



# Generated at 2022-06-11 08:44:04.531738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser()
    module_name = 'shell'
    module_args = {'module': module_name}
    print(mp.parse(module_name, module_args))

# Generated at 2022-06-11 08:44:05.173459
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  pass

# Generated at 2022-06-11 08:44:15.830061
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(BASE_ACTION_PLUGIN_PATH)
    action_loader.add_directory(BASE_ACTION_PLUGIN_PATH2)
    action_loader.add_directory(MODULE_PATH)

    # test that this doesn't raise an exception
    imp.reload(action_loader)

    task_ds = dict(
        module='copy',
        src='source/path',
        dest='dest/path',
        owner='dan',
        group='dan',
        mode='0644'
    )
    map_ = ModuleArgsParser(task_ds).parse()

    print(map_)


# Generated at 2022-06-11 08:44:19.237468
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = {'async': 10000, 'module': 'async_status'}
    t = ModuleArgsParser({'action': thing})
    t.parse()


# end class ModuleArgsParser


# Generated at 2022-06-11 08:44:23.911608
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    result = module_args_parser.parse(skip_action_validation=False)
    assert result == (None, dict(), Sentinel)


# ===========================================
# Subclass of AnsibleModule to add support for
# multiple return values
# ===========================================


# Generated at 2022-06-11 08:44:26.870328
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader = AnsibleModuleLoader("/tmp")
    action_loader = AnsibleActionLoader("/tmp")
    pass

# class containing the return values of module methods

# Generated at 2022-06-11 08:44:37.322205
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize object as in main function
    collection_loader = CollectionLoader()
    collection_list = collection_loader.get(['ansible.builtin'])

    task_ds = {'action': {'module': ''}}
    task = ModuleArgsParser(task_ds, collection_list)

    # Test first branch
    assert task.parse() == ('', {}, None)

    task_ds = {'action': None}
    task = ModuleArgsParser(task_ds, collection_list)
    # Test second branch
    assert task.parse() == ('', {}, None)

    # Test third branch
    task_ds = {'action': 'shell echo hi'}
    task = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-11 08:44:39.176693
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(None, None)
    assert parser.parse() == (None, {}, None)



# Generated at 2022-06-11 08:44:56.493575
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:00.902458
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action="shell", delegate_to="localhost", args="echo hi")
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == "shell"
    assert args == {"args": "echo hi"}
    assert delegate_to == "localhost"


# Generated at 2022-06-11 08:45:09.751910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    if PY3:
        import io as io_package
        StringIO = io_package.BytesIO
        to_bytes = (lambda x, *args, **kwargs: x)
        to_text = (lambda x, *args, **kwargs: x)

    task_ds = {"action": "shell echo hi"}
    module_args = ModuleArgsParser(task_ds=task_ds, collection_list=[])
    assert module_args.resolved_action is None
    (action, args, delegate_to) = module_args.parse()
    assert action == "command"
    assert args['creates'] == None
   

# Generated at 2022-06-11 08:45:13.631871
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy', 'src': 'a', 'dest': 'b'}
    collection_list = []
    actual_result = ModuleArgsParser(task_ds, collection_list).parse()
    expected_result = ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert actual_result == expected_result



# Generated at 2022-06-11 08:45:17.449626
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds='shell',collection_list='action')
    action, args, delegate_to = module_args_parser.parse()
    print(action)
    print(args)
    print(delegate_to)

test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:45:27.248949
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader = None
    collection_list = None
    task_ds = {}
    with pytest.raises(AnsibleAssertionError) as excinfo:
        # no code, just a test that an exception is raised
        thing = ModuleArgsParser(module_loader, collection_list, task_ds).parse()
    assert "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>" in str(excinfo.value)

    # set task_ds to a dict with wrong action key:
    # - copy: src=a dest=b
    task_ds = {}

# Generated at 2022-06-11 08:45:35.837446
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()
    inventory = InventoryManager(loader=None, sources=os.path.join(os.path.dirname(__file__), "data/hosts"))

    def __get_task_data_structure(path):
        loader = DataLoader()
        inventory.clear_pattern_cache()
        all_vars = Variables(loader=loader, inventory=inventory)
        play_source = dict(
            name="Ansible Play",
            hosts="all",
            gather_facts="no",
            tasks=[dict(action=dict(module="ping"))]
        )
        play = Play().load(play_source, loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))
        tqm._unserialize_queued

# Generated at 2022-06-11 08:45:46.405711
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.task

    # Supports action and module with additional_args
    module_args_parser = ModuleArgsParser(
        task_ds={
            'action': 'test-module',
            'delegate_to': 'localhost'
        },
        collection_list=[
            './test/ansible/collections/ansible_collections/test_collection/plugins/modules/test_module'
        ]
    )
    assert module_args_parser.parse() == (
        'test-module',
        {
            '_ansible_version': ansible.__version__,
            '_ansible_delegate_to': 'localhost'
        },
        'localhost'
    )

    # Supports action and module without additional_args

# Generated at 2022-06-11 08:45:56.239579
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:56.824643
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-11 08:46:11.677352
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            module='shell',
            args=dict(
                chdir='/tmp',
            ),
            _raw_params='echo hi',
        )
    )
    collection_list = None
    m = ModuleArgsParser(task_ds, collection_list)
    res = m.parse()
    assertEqual(res, ('shell', {'chdir': '/tmp', '_raw_params': 'echo hi'}, None))
test_ModuleArgsParser_parse.unittest = ['modules']


# Generated at 2022-06-11 08:46:20.445406
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fakeLoader = DictDataLoader({"/path/to/some/file.yml": """
        - hosts: abc:80
          tasks:
            - shell: "echo hi"
    """})
    fake_vars = dict(
        ansible_user='honggfuzz',
        ansible_inventory=InventoryManager(loader=fakeLoader, sources=["/path/to/some/file.yml"]),
        ansible_play_hosts=C.DEFAULT_HOST_LIST,
    )
    fake_play_context = PlayContext()
    fake_play_context.remote_addr = '127.0.0.1'

# Generated at 2022-06-11 08:46:28.973028
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # initialize
    task_ds = {"action": {"module": "shell", "_raw_params": "echo 'hi'", "chdir": "~/test"}}
    parser = ModuleArgsParser(task_ds)
    # parse
    action, args, delegate_to = parser.parse()
    # check result
    assert action == "shell"
    assert args == {"_raw_params": "echo 'hi'", "chdir": "~/test"}
    assert delegate_to is None

    # initialize
    task_ds = {"action": {"module": "shell", "args": {"_raw_params": "echo 'hi'", "chdir": "~/test"}}}
    parser = ModuleArgsParser(task_ds)
    # parse
    action, args, delegate_to = parser.parse()
    # check result
    assert action

# Generated at 2022-06-11 08:46:38.195486
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 08:46:47.784536
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict()
    ds['foo'] = 'bar'
    ds['bar'] = 'foo'
    ds['action'] = 'baz'

    ds2 = dict()
    ds2['biog'] = 'foo'
    ds2['action'] = 'baz'

    ds3 = dict()
    ds3['action'] = 'baz'

    ds4 = dict()
    ds4['foo'] = 'bar'
    ds4['action'] = 'baz'

    p = ModuleArgsParser(ds)

    (action, args, delegate_to) = p.parse()
    assert action == 'baz'
    assert len(args) == 0
    assert delegate_to is None

    p2 = ModuleArgsParser(ds2)


# Generated at 2022-06-11 08:46:57.031986
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:46:58.553735
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser()
    module_parser.parse('shell hi')
    assert True is True

# Generated at 2022-06-11 08:47:07.144298
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = AnsibleModule(
        argument_spec=dict(
            task=dict(required=True)
        )
    )
    task_ds = m.params['task']
    collection_list = m.params.get('collection_list', [])
    # task_ds = dict(
    #     shell="ls",
    #     local_action=dict(
    #         module="shell",
    #         args=dict(
    #             chdir="/tmp"
    #         )
    #     )
    # )
    # task_ds = dict(
    #     local_action=dict(
    #         module="shell",
    #         args=dict(
    #             chdir="/tmp"
    #         )
    #     )
    # )
    # task_ds = dict(local_action="shell

# Generated at 2022-06-11 08:47:15.682704
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class UnitTest_ModuleArgsParser(unittest.TestCase):
        def setUp(self):
            pass
        # unique to this method
        def test_parse_no_args(self):
            task_ds = {'action': {'module': 'ec2', 'x': 1}}
            mdep = ModuleArgsParser(task_ds=task_ds)
            action, args, delegate_to = mdep.parse()
            self.assertEqual(action, 'ec2')
            self.assertEqual(args, {'x': 1})
            self.assertIs(delegate_to, Sentinel)
        # common to all test_parse* methods
        def test_parse_action_module_name(self):
            task_ds = {'action': {'module': 'ec2', 'x': 1}}
            mdep

# Generated at 2022-06-11 08:47:25.084766
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize needed variables.
    task_ds = {}
    collection_list = []

    # Create a new ModuleArgsParser object using task_ds and collection_list.
    test = ModuleArgsParser(task_ds, collection_list)

    # Call method to be tested.
    result = test.parse()

    # Test result.
    assert result[0] == None
    assert result[1] == {}
    assert result[2] == Sentinel

    # Test a non-dict task_ds.
    task_ds = 'test'
    test = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleAssertionError):
        test.parse()

    # Initialize task_ds again.
    task_ds = {}

    # Test task_ds 'action'.

# Generated at 2022-06-11 08:47:46.744900
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = None
    obj = ModuleArgsParser(task)
    res = obj.parse()
    assert res[0] is None
    assert res[1] == {}
    assert res[2] is None
    task = {'delegate_to': 'c'}
    obj = ModuleArgsParser(task)
    res = obj.parse()
    assert res[0] is None
    assert res[1] == {}
    assert res[2] == 'c'
    task = {'delegate_to': 'c', 'action': 'a'}
    obj = ModuleArgsParser(task)
    res = obj.parse()
    assert res[0] == 'a'
    assert res[1] == {}
    assert res[2] == 'c'

# Generated at 2022-06-11 08:47:52.749617
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    task_ds = {'local_action': {'module': 'win_stat', 'path': 'c:\\windows'}}
    assert m.parse(task_ds) == ("win_stat", {}, 'localhost')
    task_ds = {'action': 'win_stat path=c:\\windows'}
    assert m.parse(task_ds) == ("win_stat", {'path': 'c:\\windows'}, None)
    task_ds = {'action': {'module': 'win_stat', 'path': 'c:\\windows'}}
    assert m.parse(task_ds) == ("win_stat", {'path': 'c:\\windows'}, None)
    task_ds = {'win_stat': {'path': 'c:\\windows'}}

# Generated at 2022-06-11 08:47:57.552108
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    ModuleArgsParser.parse()
    '''
    parser = ModuleArgsParser(task_ds={'_raw_params': '', 'action': 'get_url', 'args': {'timeout': 30}, '_uses_shell': True},
                              collection_list=[])
    assert parser.parse() == ('get_url', {'timeout': 30}, None)



# Generated at 2022-06-11 08:48:00.836036
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser({})
    (action, args, delegate_to) = module_arg_parser.parse()
    assert action == None
    assert args == dict()
    assert delegate_to == Sentinel


# Generated at 2022-06-11 08:48:10.223550
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:48:20.615134
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict()
    ds['action'] = 'copy'
    ds['local_action'] = 'copy'
    ds['delegate_to'] = 'copy'
    ds['copy'] = 'src=dest'
    ds['args'] = 'copy'

    ds['action'] = 'copy'
    ds['local_action'] = 'copy'
    ds['delegate_to'] = 'copy'
    ds['copy'] = {'src': 'a', 'dest': 'b'}
    ds['args'] = 'copy'

    ds['action'] = 'copy'
    ds['local_action'] = 'copy'
    ds['delegate_to'] = 'copy'
    ds['copy'] = 'src=a dest=b'

# Generated at 2022-06-11 08:48:29.778393
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'shell'
    module_args_dict = {}
    delegate_to = 'localhost'
    additional_args = {}

    test_task = {}
    test_task['action'] = module_name + ' ' + ' '.join([('%s=%s' % (k, v)) for k, v in module_args_dict.items()])
    test_task['delegate_to'] = delegate_to
    test_task['args'] = additional_args

    module_parser = ModuleArgsParser(task_ds=test_task)
    action, args, delegate_to = module_parser.parse()

    assert action == 'shell'
    assert args == {}



# Generated at 2022-06-11 08:48:31.197613
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    TestModuleArgsParser._TestModuleArgsParser__parse()

# Generated at 2022-06-11 08:48:32.595366
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import doctest
    doctest.testmod()



# Generated at 2022-06-11 08:48:42.831811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # unit test for ModuleArgsParser(dict) -> parse

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude

    task_ds = {}
    src = os.path.join(os.path.dirname(__file__), './module_args_data/*.yml')
    for f in glob.glob(src):
        y = YAML(typ='safe')
        y.default_flow_style = False
        ds = y.load(open(f, 'rb').read())
        # the YAML files use blocks and handlers to be able to show the
        # parameters being passed in multiple ways, while the parser
        # parses tasks

# Generated at 2022-06-11 08:49:07.854316
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_task = dict(
            action = "command ",
            local_action = "shell",
            shell = "echo hello",
            echo = "hi",
            delegate_to = "localhost"
        )
    parser = ModuleArgsParser(test_task)
    action, args, delegate_to = parser.parse()

    assert "echo" == action
    assert args == dict()


# Generated at 2022-06-11 08:49:13.204154
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  dump_data = """{
          "task": {
            "module": "command",
            "args": {
              "warn": "true",
              "_raw_params": "ls -la",
              "_uses_shell": "true"
            }
          },
          "delegated_vars": {

          }
        }"""

  dump_data = yaml.load(dump_data)
  module = ModuleArgsParser(dump_data)
  module.parse()
  pass


# Generated at 2022-06-11 08:49:16.074514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # test for case when ansible.utils.module_docs.ActionsDocs.get_action_deprecation_text()
  # raises RuntimeError
  # TODO: Implement test.
  pass


# Generated at 2022-06-11 08:49:26.566125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser(task_ds={'action': 'shell echo hi'}, collection_list='/foo')
    assert p.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    p = ModuleArgsParser(task_ds={'action': 'shell'}, collection_list='/foo')
    assert p.parse() == ('shell', {'_uses_shell': True}, None)
    p = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'a': 1}}, collection_list='/foo')
    assert p.parse() == ('shell', {'a': 1, '_uses_shell': True}, None)

# Generated at 2022-06-11 08:49:36.310350
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    action = 'action1'
    delegate_to = 'localhost'
    args = {'action': 'action2',
            'delegate_to': delegate_to,
            'local_action': 'action3',
            'module': 'action4'}
    non_task_ds = {'action1': {'module': 'action2'}}
    task_ds = {'action': 'action1', 'delegate_to': delegate_to, 'local_action': 'action3', 'module': 'action4'}

    # Create the object that stores task attributes
    task_attr_obj = Task._valid_attrs
    # Create the object that stores handler attributes
    handler_attr_obj = Handler._valid_attrs
    #

# Generated at 2022-06-11 08:49:43.841829
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {}
    skip_action_validation = False
    ModuleArgsParser_obj = ModuleArgsParser(task_ds=ds, skip_action_validation=skip_action_validation)
    try:
        ModuleArgsParser_obj.parse()
    except SystemExit as e:
        # Any type of exception will be caught here.
        # "-i" may cause SystemExit with value 0.
        # This part should be improved in future.
        if e.code == 0:
            pass
        else:
            raise
    else:
        raise Exception("SystemExit should be raised")
    return True

# Generated at 2022-06-11 08:49:54.851909
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method ModuleArgsParser.parse of class ModuleArgsParser
    '''

    # tests for _normalize_parameters
    parser = ModuleArgsParser()
    assert parser._normalize_parameters({'x': 1}, action='local_action') == (None, {'x': 1})
    assert parser._normalize_parameters('copy: src=a dest=b', action='local_action') == (None, {'dest': 'b', 'src': 'a'})
    assert parser._normalize_parameters('x=1 y=2', action='local_action') == (None, {'y': '2', 'x': '1'})

# Generated at 2022-06-11 08:50:03.445842
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.reserved import ALLOWED_INTERNAL_KEYS
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader
    from ansible.vars.reserved import Reserved
    from ansible.errors import AnsibleError
    import ansible.constants as C
    display = Display()
    loader = DataLoader()

    reserved_vals = Reserved(loader=loader, variable_manager=None, templar=None)

    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)

# Generated at 2022-06-11 08:50:13.159039
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    m = ModuleArgsParser(task_ds)
    assert m.parse() == (None, {}, None)


# class IncludeRoles(CommandLine):
#     """
#     Include a list of roles as if they had been set at the command line, using the same format.
#     """

#     VALID_MODES = frozenset(['push', 'insert', 'prepend'])

#     def parse(self, args):
#         '''
#         Override of super class method to allow for a "special" keyword "all", which
#         will cause all the roles in the roles/ directory to be included.
#         '''

#         # remove role_path prefix, if in use
#         if args and ':all' in args[0]:
#             tmp = args[0].

# Generated at 2022-06-11 08:50:23.926032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    os.system("rm -rf /var/ose-tools/ansible-client/f5/test/test_data/test_ModuleArgsParser_parse/")
    os.makedirs("/var/ose-tools/ansible-client/f5/test/test_data/test_ModuleArgsParser_parse/")
    with open("/var/ose-tools/ansible-client/f5/test/test_data/test_ModuleArgsParser_parse/example_task.yaml","w") as file:
        file.write("""- name: example task 
  action: copy src=a dest=b 
  delegate_to: worker1
""")

# Generated at 2022-06-11 08:50:43.293891
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    example_task = {
        'action': "shell echo hello world"
    }
    task_parser = ModuleArgsParser(example_task)
    (action_name, parsed_args, delegate_to) = task_parser.parse()
    assert action_name == "shell"
    assert parsed_args == {
        "_raw_params": "echo hello world",
        "_uses_shell": True
    }
    assert delegate_to == None

    example_task = {
        'module': 'shell',
        'args': 'echo hello world'
    }
    task_parser = ModuleArgsParser(example_task)
    (action_name, parsed_args, delegate_to) = task_parser.parse()
    assert action_name == "shell"

# Generated at 2022-06-11 08:50:52.545682
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vars import merge_hash
    ds = {
        'action': {'module': 'ec2', 'region': 'xyz'}
    }
    parser = ModuleArgsParser(task_ds=ds)
    print(parser.parse())
    print(AnsibleDumper(default_flow_style=False).dump(parser.parse()[1], default_style='"'))
    ds = {
        'action': 'copy src=a dest=b'
    }
    parser = ModuleArgsParser(task_ds=ds)
    print(parser.parse())
    print(AnsibleDumper(default_flow_style=False).dump(parser.parse()[1], default_style='"'))
    d

# Generated at 2022-06-11 08:51:02.525996
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from units.mock.loader import DictDataLoader

    module_name = None
    action_name = 'copy'
    module_args = {'src': 'a', 'dest': 'b'}
    delegate_to = None

    task_ds = action_name + ': ' + ' src=a dest=b '
    yaml_ds = to_text(task_ds).strip()
    task_ds = AnsibleLoader(DictDataLoader({})).load(yaml_ds)[0]

    task_ds_kwargs_

# Generated at 2022-06-11 08:51:12.918445
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({'action':'copy src=a dest=b','delegate_to':'localhost','args':{'src':'a','dest':'b'},'copy':'copy src=a dest=b'},None)
    assert module_args_parser.parse()==('copy',{'src': 'a', 'dest': 'b'},'localhost')
    module_args_parser = ModuleArgsParser({'local_action':'copy src=a dest=b','delegate_to':'localhost','args':{'src':'a','dest':'b'},'copy':'copy src=a dest=b'},None)
    assert module_args_parser.parse()==('copy',{'src': 'a', 'dest': 'b'},'localhost')

# Generated at 2022-06-11 08:51:20.966638
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import string_types

    m1 = ModuleArgsParser(task_ds={'action': {'module': 'command', 'args': 'ls -l /'}})
    assert m1.parse() == ('command', {'_raw_params': 'ls -l /'}, Sentinel)
    assert type(m1.parse()[1]) == dict

    m2 = ModuleArgsParser(task_ds={'local_action': 'shell echo hi'})
    assert m2.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    assert type(m2.parse()[1]) == dict

    m3 = ModuleArgsParser(task_ds={'action': 'shell echo hi'})

# Generated at 2022-06-11 08:51:25.377118
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    ModuleArgsParser_i = ModuleArgsParser(task_ds, collection_list)
    # No args are required, so we can call it w/o an error
    try:
        ModuleArgsParser_i.parse()
    except Exception as e:
        print('An unexpected Exception occurred: {0}'.format(e))

# Generated at 2022-06-11 08:51:34.983568
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''test_module_args_parser_parse'''
    action = 'file'
    module_args = {'dest': '/usr/local/bin', 'src': 'my_binary'}
    task_ds = {'action': 'file dest=/usr/local/bin src=my_binary' }
    module_args_parser = ModuleArgsParser(task_ds)
    (result_action, result_args, result_delegate_to) = module_args_parser.parse()
    if (action != result_action) or (str(module_args) != str(result_args)):
        print("Did not get expected result")
        print("Action: %s" % action)
        print("Result Action: %s" % result_action)
        print("Args: %s" % module_args)

# Generated at 2022-06-11 08:51:44.846506
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Ensure a dictionary with `args` is parsed as expected
    arg_test_dict = {
        'test_dict': {
            'args': {
                'foo': 'bar',
                'baz': 'bat'
            }
        }
    }
    task_ds = arg_test_dict
    collection_list = []
    expected = ('test_dict', {'foo': 'bar', 'baz': 'bat'}, Sentinel)
    actual = ModuleArgsParser(task_ds, collection_list).parse()
    assert_equal(expected, actual)

    # Ensure a dictionary without `args` is parsed as expected
    arg_test_dict = {
        'test_dict': {
            'foo': 'bar',
            'baz': 'bat'
        }
    }
    task_ds = arg_test_dict

# Generated at 2022-06-11 08:51:55.783679
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    args = dict(command=list(['echo hi']), register=list(['result']), free_form=list(['echo hi']))
    delegate_to = None
    ds = dict(action='shell echo hi', register='result')
    p = ModuleArgsParser(task_ds=ds)
    result = p.parse()
    if result != (action, args, delegate_to):
        print("expected: %s" % (action, args, delegate_to))
        print("received: %s" % result)

    ds = dict(action='shell', echo=list(['hi']), register='result')
    action = 'shell'
    args = dict(echo=list(['hi']), register=list(['result']))
    delegate_to = None

# Generated at 2022-06-11 08:52:06.029446
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.module_utils._text import to_text

    task_ds = dict()
    assert to_text(ModuleArgsParser(task_ds=task_ds).parse) == to_text("(None, {}, sentinel)")

    task_ds = {u'action': None}
    assert to_text(ModuleArgsParser(task_ds=task_ds).parse) == to_text("(None, None, sentinel)")

    task_ds = {u'action': u'copy src=a dest=b'}
    assert to_text(ModuleArgsParser(task_ds=task_ds).parse) == to_text("('copy', {'dest': 'b', 'src': 'a'}, sentinel)")


# Generated at 2022-06-11 08:52:27.564329
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Create a task_ds to test parse method
    task_ds = {'action': {'module': 'copy'}, 'args': {'a': 1, 'b': 2}, 'delegate_to': 'localhost', 'register': 'copy1'}
    task_ds['notify'] = ['handlers']
    task_ds['changed_when'] = 'any'
    task_ds['until'] = 'retries > 0'
    task_ds['when'] = 'always'
    task_ds['retries'] = 3
    task_ds['delay'] = 3
    task_ds['environment'] = {'ANSIBLE_CONFIG': '/tmp'}
    task_ds['become'] = True

# Generated at 2022-06-11 08:52:35.605206
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # test case #1
    #
    task_ds = {
        'module': 'setup',
        'gather_facts': 'no',
        'register': 'var_facts'
    }
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert_equal(parser.parse(skip_action_validation=True), ('setup', {'gather_facts': 'no', 'register': 'var_facts'}, None))
    
    #
    # test case #2
    #
    task_ds = {
        'module': 'include',
        'name': 'fail2ban_jail_conf.j2',
        'check_mode': 'no',
        'register': 'file_copy'
    }

# Generated at 2022-06-11 08:52:45.587772
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:52:48.329885
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'name': 'test', 'action': {'ping': 'pong'}}
    module_parser = ModuleArgsParser(task_ds=task_ds)
    action_result, args, delegate_to = module_parser.parse()
    assert action_result == 'ping'
    assert args == {'ping': 'pong'}
    assert delegate_to is Sentinel



# Generated at 2022-06-11 08:52:55.464651
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    
    # test case 1
    task_ds1 = dict()
    task_ds1['action'] = dict()
    task_ds1['action']['module'] = 'command'
    task_ds1['action']['args'] = dict()
    task_ds1['action']['args']['chdir'] = '/tmp'
    task_ds1['action']['args']['_raw_params'] = 'echo "hello world"'
    
    map1 = ModuleArgsParser(task_ds1)
    assert map1.parse() == ('command', {'chdir': '/tmp', '_raw_params': 'echo "hello world"'}, Sentinel)

    # test case 2
    task_ds2 = dict()
    task_ds2['action'] = 'copy src=a dest=b'
    
   

# Generated at 2022-06-11 08:52:59.482514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': '{{ _power_of_2 }} {{ _cn_name }}', 'args': {'_raw_params': '{{ _power_of_2 }} {{ _cn_name }}'}}
    args = ModuleArgsParser(task_ds).parse()
    assert args[1] == {'_raw_params': '{{ _power_of_2 }} {{ _cn_name }}'}

# Generated at 2022-06-11 08:53:07.586351
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Find the arg spec for action module ping in ansible.cfg
    config, parser, options = ansible.cli.cli.create_parser()
    options = parser.parse_args(['ping'], namespace=options)
    my_vars = ansible.cli.cli.get_default_vars(options)
    config, options, args = ansible.cli.cli.parse_cli_vars(options, my_vars)

    plugin = action_loader.get('ping', my_vars=my_vars, collection_list=options.collections_paths)
    params = plugin.get_default_requirement_set()
    print(params)

    # Test input data

# Generated at 2022-06-11 08:53:15.459950
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    text_file_path =  os.path.join(os.path.dirname(__file__), 'data', 'module_args_parser_test_data.yml')
    text_file = open(text_file_path, 'r')
    raw_data = yaml.safe_load(text_file)
    text_file.close()

    for item in raw_data:
        args_parser = ModuleArgsParser(item['raw_input'])
        action, args, delegate_to = args_parser.parse()
        assert action == item['expected_action']
        assert args == item['expected_args']
        assert delegate_to == item['expected_delegate_to']


# Generated at 2022-06-11 08:53:17.503937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    name = 'test value'
    action = ModuleArgsParser(name).parse()
    assert action == ('echo', {}, None)

# Generated at 2022-06-11 08:53:28.773821
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None)

    task_ds = {'action': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {u'_raw_params': u'hi'}, None)

    task_ds = {'action': 'echo hi', 'args': 'host={{inventory_hostname}}'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {'host': u'{{inventory_hostname}}', u'_raw_params': u'hi'}, None)
