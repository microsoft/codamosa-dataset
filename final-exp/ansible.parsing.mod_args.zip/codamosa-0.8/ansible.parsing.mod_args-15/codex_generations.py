

# Generated at 2022-06-11 08:43:52.083603
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action_name, module_args, delegate_to = module_args_parser.parse()
    assert action_name is None and module_args == {} and delegate_to is None and isinstance(module_args_parser, object)

test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:43:59.124037
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    
    task_ds = {
                "first":
                  {
                    "module": "copy",
                    "src": "test.txt",
                    "dest": "./",
                    "delegate_to": "localhost"
                  },
                  "action": "copy src=/tmp/test.yml dest=/tmp/test.yml",
                  "local_action": {"module": "copy", "src": "./", "dest": "./"},
                  "second":
                  {
                    "module": "copy",
                    "src": "test.txt",
                    "dest": "./",
                    "delegate_to": "localhost"
                  }
                }
    collection_list = [Collection("test.test_collection"), Collection("test_collection2")]
    # test exception

# Generated at 2022-06-11 08:44:09.361734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Tests concerning an action statement
    task_ds = dict(action=dict(module='ping', data='pong'))
    module_args = ModuleArgsParser(task_ds=task_ds).parse()
    assert module_args == ('ping', dict(), None)

    # Tests concerning a module statement with module name
    task_ds = dict(ping=dict(data='pong'))
    module_args = ModuleArgsParser(task_ds=task_ds).parse()
    assert module_args == ('ping', dict(), None)

    # Tests concerning a module statement with a module name alias
    task_ds = dict(ansible_builtin=dict(module='copy', data='copy'))
    module_args = ModuleArgsParser(task_ds=task_ds).parse()

# Generated at 2022-06-11 08:44:16.012798
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # Create a test parser
    parser = ModuleArgsParser({})
    # Create a test action
    action = 'testaction'
    # Call the parse method
    action, args, delegate_to = parser.parse(action)
    # Assert that the returned values are equal to what we expect
    assert action == action
    assert args == {}
    assert delegate_to is Sentinel


# Generated at 2022-06-11 08:44:22.670254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'foo',
        'delegate_to': 'delegate_to',
        'with_items': [
            '1'
        ]
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'foo'
    assert delegate_to == 'delegate_to'



# Generated at 2022-06-11 08:44:33.290023
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Prepare test data
    ds = dict()
    collection_list = dict()
    mp = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
    args = dict()

    # Execute the code to be tested
    ret = mp.parse()

    # Verfiy the expected results
    assert ret[0] is None
    assert ret[1] == dict()
    assert ret[2] is None

    # Prepare test data
    ds = dict(action='action')
    collection_list = dict()
    mp = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
    args = dict()

    # Execute the code to be tested
    ret = mp.parse()

    # Verfiy the expected results
    assert ret[0] is None
    assert ret[1]

# Generated at 2022-06-11 08:44:44.157955
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    templar = Templar()
    hostvars = {}
    self = AnsibleTaskVars("task_vars", templar, hostvars, hostvars)
    assert self.parse({'fail': 'msg={{ ansible_hostname }}'}) == ('fail', {u'msg': u'{{ ansible_hostname }}'}, Sentinel)
    assert self.parse({'local_action': 'fail msg={{ ansible_hostname }}'}) == ('fail', {u'msg': u'{{ ansible_hostname }}'}, 'localhost')
    assert self.parse({'action': 'fail msg={{ ansible_hostname }}'}) == ('fail', {u'msg': u'{{ ansible_hostname }}'}, Sentinel)

# Generated at 2022-06-11 08:44:51.055090
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method ModuleArgsParser.parse
    '''
    #
    ### YOU CAN ADD MULTIPLE TASKS HERE
    #
    # Test 1 - Test parsing of a string "action"
    task_ds = {
        'action': {
            'module': 'shell',
            'args': 'echo hello'
        }
    }
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse(skip_action_validation=True)
    assert action == 'shell'
    assert delegate_to == None
    assert args['_raw_params'] == 'echo hello'
    assert parser.resolved_action == 'ShellModule'

    #
    # Test 2 - Test parsing of a dict "action"

# Generated at 2022-06-11 08:45:00.593368
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid module name
    task_ds = {'action': {'module': 'copy src=a dest=b'}}
    expected = ('copy', {'src': 'a', 'dest': 'b'})
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    actual = module_args_parser.parse()
    assert actual[0] == expected[0]
    assert actual[1] == expected[1]
    assert actual[2] is None

    # Test with an invalid module name
    task_ds = {'action': {'module': 'echo src=a dest=b'}}
    expected = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    actual = module_args_parser.parse()
    assert actual is expected

# Generated at 2022-06-11 08:45:09.599384
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'shell': 'echo hi'}
    mp = ModuleArgsParser(task_ds)
    assert(mp.parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None))

    task_ds = {'command': 'echo hi'}
    mp = ModuleArgsParser(task_ds)
    assert(mp.parse() == (None, {}, None))

    task_ds = {'action': 'shell echo hi'}
    mp = ModuleArgsParser(task_ds)
    assert(mp.parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None))

    task_ds = {'action': 'echo hi'}
    mp = ModuleArgsParser(task_ds)

# Generated at 2022-06-11 08:45:33.846566
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from collections import namedtuple

    import pytest
    from textwrap import dedent
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestModuleArgsParser(ModuleArgsParser):
        '''
        Subclasses ModuleArgsParser to use a loader that reads data from a string,
        to make it more amenable to tests.
        '''

# Generated at 2022-06-11 08:45:44.071935
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    actions = dict(action=dict(), local_action=dict(), module=dict())

    def _check(task_ds, expected_action, expected_args, expected_delegate_to):
        task_ds = dict(task_ds)
        task_ds['action'] = dict(action=task_ds.get('action'))
        task_ds['local_action'] = dict(local_action=task_ds.get('local_action'))
        task_ds['module'] = dict(module=task_ds.get('module'))

        for action in actions:
            if action in task_ds:
                task_ds.update(task_ds[action])
            else:
                del task_ds[action]

        parser = ModuleArgsParser(task_ds)
        action, args, delegate_to = parser.parse()

       

# Generated at 2022-06-11 08:45:53.979970
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    # Note: This test method runs via unit test module_utils.module_arg_spec
    def validate_task_ds():
        ''' validate the arguments of task_ds and return a resolvable task '''
        task_ds = dict()
        module_name = 'copy'
        action = module_name
        args = dict(src='a', dest='b')
        task_ds.update({'src':'a', 'dest':'b'})
        args.update(task_ds)
        task_ds = dict(action=args)
        return (task_ds, action, args)

    # define a dict for input task_ds
    task_ds, expected_action, expected_args = validate_task_ds()

    # create an object of ModuleArgsParser class

# Generated at 2022-06-11 08:46:03.104361
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import random
    import pytest
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes, to_text

    pseudo_random = [random.random() for i in range(10)]
    pseudo_random_bytes = [to_bytes(to_text(random.random())) for i in range(10)]

    def _test(task_ds, action, args, delegate_to=None):
        assert(ModuleArgsParser(task_ds).parse() == (action, args, delegate_to))

    def _test_exception(task_ds,
                        msg='',
                        exception=AnsibleParserError):
        assert_raises_regexp(exception,
                             msg,
                             ModuleArgsParser(task_ds).parse)

    _

# Generated at 2022-06-11 08:46:11.881031
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    output = {
        'action': None,
        'args': {},
        'delegate_to': None
    }
    assert ModuleArgsParser().parse() == output
    output = {
        'action': 'shell',
        'args': {
            '_raw_params': 'echo $HOME',
            '_uses_shell': True
        },
        'delegate_to': None
    }
    assert ModuleArgsParser(task_ds=dict(action='shell echo $HOME')).parse() == output
    output = {
        'action': 'shell',
        'args': {
            '_raw_params': 'echo $HOME',
            '_uses_shell': True
        },
        'delegate_to': None
    }

# Generated at 2022-06-11 08:46:15.897899
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'delegate_to': 'localhost', 'action': ['shell', 'echo hi']}
    my_obj = ModuleArgsParser(task_ds=task_ds)
    parsed_output = my_obj.parse()
    assert  parsed_output == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

# Generated at 2022-06-11 08:46:20.893684
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None

    #NOTE: model class is not a parametric model
    #      no test data available

    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert isinstance(module_args_parser, ModuleArgsParser)

    with pytest.raises(AnsibleParserError):
        module_args_parser.parse()

# Generated at 2022-06-11 08:46:25.383740
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME
    task_ds = {
        'action': 'shell',
        'args': {
            'foo': 'bar',
            '_raw_params': 'baz'
        }
    }
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('shell', {'foo': 'bar', '_raw_params': 'baz'}, None)



# Generated at 2022-06-11 08:46:29.984627
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'name': 'test task', 'action': 'shell', 'args': 'ls /tmp'}
    obj = ModuleArgsParser(task_ds)
    assert obj.parse() == ('shell', {'_raw_params': 'ls /tmp'}, None)

if __name__ == "__main__":
    # execute only if run as a script
    test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:46:39.356988
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'command1 arg1 arg2',
        'delegate_to': 'localhost'
    }
    test_obj = ModuleArgsParser(task_ds)
    expected_action, expected_args, expected_delegate_to = 'command1', {'arg1': None, 'arg2': None}, 'localhost'
    (actual_action, actual_args, actual_delegate_to) = test_obj.parse()
    assert actual_action == expected_action
    assert actual_args == expected_args
    assert actual_delegate_to == expected_delegate_to

    task_ds = {
        'action': {
            'command1': 'a=1 b=2',
            'delegate_to': 'localhost'
        }
    }

# Generated at 2022-06-11 08:46:53.108319
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {'delegate_to': 'localhost', 'local_action': 'shell echo hi'}

    obj = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert obj._task_ds == task_ds
    assert obj._collection_list is None
    assert obj.resolved_action is None

    obj.parse()
    assert obj._split_module_string('copy src=a dest=b') == ('copy', 'src=a dest=b')
    assert obj.resolved_action is None

    assert obj._normalize_parameters('shell echo hi', action='shell') == (
        'shell', {'_raw_params': 'echo hi', '_uses_shell': True})


# Generated at 2022-06-11 08:47:00.458984
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # disabled until we have a better way to set up class instances
    return
    task_ds = {}
    collection_list = {}
    # Instantiate an instance of ModuleArgsParser
    # parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # Specify the return value(s) for mocked function calls
    # Call method parse on the instance
    # parser.parse()
    # assert_equal(expected, parser.parse())
    # assert_equal(expected, parser.parse(skip_action_validation=skip_action_validation))
    raise SkipTest  # TODO: implement your test here



# Generated at 2022-06-11 08:47:08.442673
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create the test object
    task_ds = {
            "register": "foo",
            "local_action": "copy src=/a dest=/b"
        }
    parser = ModuleArgsParser(task_ds)
    action, args, dest = parser.parse()
    if action == "copy" and len(args) == 1 and dest == "localhost":
        print(test_result_success + "ModuleArgsParser parses args properly with local_action")
    else:
        print(test_result_failure + "ModuleArgsParser parses args properly with local_action")
    # Test the case with action
    task_ds = {
            "register": "foo",
            "action": "copy src=/a dest=/b"
        }

# Generated at 2022-06-11 08:47:15.514951
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict()
    args["action"] = dict()
    args["action"]["module"] = "test_module"
    args["action"]["test_module_key"] = "test_module_key_value"
    task_ds = {"task": "test_task",
               "action": "test_module test_module_key=test_module_key_value"}
    module_args_parser = ModuleArgsParser(task_ds)
    assert(module_args_parser.parse() == (
        "test_module",
        {"test_module_key": "test_module_key_value"},
        None
    ))



# Generated at 2022-06-11 08:47:25.001700
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Parse a task with a module (legacy form)
    task_ds = dict(action='shell', args='echo hi')
    args_parser = ModuleArgsParser(task_ds=task_ds)
    rval = args_parser.parse()
    assert rval == ('shell', dict(_raw_params='echo hi', _uses_shell=True), None)

    # Parse a task with a module (complex args form)
    task_ds = dict(action='shell', args=dict(_raw_params='echo hi'))
    args_parser = ModuleArgsParser(task_ds=task_ds)
    rval = args_parser.parse()
    assert rval == ('shell', dict(_raw_params='echo hi', _uses_shell=True), None)

    # Parse a task with a module (complex args form)
   

# Generated at 2022-06-11 08:47:35.260599
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    class FakeActionLoader:
        def find_plugin_with_context(self, name, collection_list=None):
            return ActionModuleLoaderContext(name, collection_list)

    class FakeModuleLoader:
        def find_plugin_with_context(self, name, collection_list=None):
            return ModuleLoaderContext(name, collection_list)

    class ActionModuleLoaderContext:
        def __init__(self, name, collection_list=None):
            self.name = name
            self.redirect_list = 'action_plugin'
            self.resolved_fqcn = 'core'

# Generated at 2022-06-11 08:47:45.782182
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test_module_args_parser_parse(task_ds=None, collection_list=None, skip_action_validation=False):
        if task_ds is None:
            task_ds = ansible_fixture()
        if collection_list is None:
            collection_list = []

        instance = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
        res = instance.parse(skip_action_validation=skip_action_validation)
        return res
    # From test_action_plugins.py::test_action_module_args_parser_canonicalize
    # Case 1: no args
    task_ds = {
        'action': 'ping'
    }

# Generated at 2022-06-11 08:47:52.215666
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m_dict = dict({"action": "rds_instance", "args": "name={{rds_name}}", "_ansible_foo": "bar"})
    m = ModuleArgsParser(m_dict)

    (action, args, delegate_to) = m.parse()
    assert action == "rds_instance"
    assert args == {"name": "{{rds_name}}"}
    assert delegate_to == 'localhost'

    m_dict = dict({"action": dict({"module": "rds_instance", "name": "{{rds_name}}", "_ansible_foo": "bar"})})
    m = ModuleArgsParser(m_dict)

    (action, args, delegate_to) = m.parse()
    assert action == "rds_instance"

# Generated at 2022-06-11 08:48:01.779097
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # create temporary file like:
    # action:
    #   module: my_module
    #   x: 1
    #   y: 2
    (fd, path) = tempfile.mkstemp()

# Generated at 2022-06-11 08:48:11.170241
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module in task
    task_ds = {}
    collection_list = ''
    obj = ModuleArgsParser(task_ds, collection_list)
    (action, args, delegate_to) = obj.parse()
    # For now we assume the exception is caught somewhere else.
    # assert action is None
    # assert delegate_to is Sentinel
    # assert args == {}

    # Test with one module in task
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = ''
    obj = ModuleArgsParser(task_ds, collection_list)
    (action, args, delegate_to) = obj.parse()
    assert action == 'copy'
    assert delegate_to is Sentinel
    assert args == {'dest': 'b', 'src': 'a'}

    # Test with

# Generated at 2022-06-11 08:48:25.406827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    unit test for method parse of class ModuleArgsParser
    '''

    print('**********\nTESTING ModuleArgsParser.parse()')

    from ansible.module_utils.six import string_types

    d = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    p = ModuleArgsParser(d)
    (action, args, delegate_to) = p.parse()
    assert action == 'shell'
    assert isinstance(args, dict)
    assert delegate_to == 'localhost'

    d = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    p = ModuleArgsParser(d)
    (action, args, delegate_to) = p.parse()
    assert action == 'copy'

# Generated at 2022-06-11 08:48:35.863504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # dir_results = os.path.join(os.getcwd(), "tests/sanity/testcases/functional/linear/action_plugin/")
    # with open(os.path.join(dir_results, "action_plugin.json")) as fp:
    #     results = json.load(fp)
    with open(os.path.join(os.path.dirname(__file__), "testcase-result.json")) as fp:
        results = json.load(fp)
    for test in results["testcases"]:
        print("testcase name:", test["name"])
        task_ds = test["task"]
        task_ds["_ansible_verbosity"] = 0
        task_ds["_ansible_version"] = "2.9.15"

# Generated at 2022-06-11 08:48:45.522374
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class AnsibleCoreVars:
        MODULE_CACHE= {}
        MODULE_REQUIRE_ARGS= {}
        MODULE_COMPLEX_ARGS= {}
        MODULE_LANGUAGE= 'python'
        MODULE_LANGUAGE_PATH= 'ansible.modules'
        MODULE_LANGUAGE_SINGLETON_VARIABLE= 'ansible_module_instance'
        MODULE_LANGUAGE_SINGLETON= True
        MODULE_LANGUAGE_SINGLETON_WARN_LIST= ['set_fact', 'raw', 'script', 'command', 'shell']
        MODULE_NO_JSON= {}
        MODULE_NO_JSON_REPLACEMENT= {}
        MODULE_REPLACEMENTS= {}

# Generated at 2022-06-11 08:48:53.460306
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    td = dict(
        name="test1",
        action="/bin/echo '{{ erb }}'",
        register="echo",
        changed_when="False",
        failed_when="True"
    )

    actual = ModuleArgsParser(td).parse()

    expected = ('command',
                {'argv': ['/bin/echo', '{{ erb }}'],
                 'chdir': None,
                 'creates': None,
                 'executable': None,
                 'removes': None,
                 'stdin': None,
                 'warn': True})

    assert actual == expected


# Generated at 2022-06-11 08:49:05.146542
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'module_name': 'shell', 'module_args': 'echo hello world'}
    task = ModuleArgsParser(task_ds)
    result = task.parse()
    assert result == ('shell', {'_raw_params': 'echo hello world', '_uses_shell': True}, None)
    task_ds = {'module_name': 'shell', 'module_args': 'echo hello world', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    task = ModuleArgsParser(task_ds)
    result = task.parse()
    assert result == ('shell', {'_raw_params': 'echo hello world', '_uses_shell': True, 'chdir': '/tmp'}, 'localhost')

# Generated at 2022-06-11 08:49:12.874687
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.utils.convert_bool import boolean
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.playbook.play import Play

    array = [u'echo hi', u'pwd']
    array_str = u'echo hi\npwd'
    class RecursiveMock(object):
        pass
    RecursiveMock.thing = RecursiveMock()
    str_output = u'echo hi'
    everything = {u'static': RecursiveMock, u'delegate_to': u'localhost', u'local_action': u'shell echo hi', u'other_options': [u'echo hi', u'pwd']}

# Generated at 2022-06-11 08:49:23.313245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()

# Generated at 2022-06-11 08:49:33.074340
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    print("\n\nTESTING 'parse()'\n")

    # Test will generate a parser and then parse the representation of the module.
    # If a module is passed the correct action name and args, then true is returned.
    # If a module is passed an incorrect action name or args, then false is returned.
    # If a module is passed an incorrect action name and args, then false is returned.


    ############################################################################################################
    # TEST #1
    ############################################################################################################
    # action: shell /bin/echo hello
    # Passes through the script correctly.
    print("TEST #1")
    print("action: shell /bin/echo hello")
    test_task_1 = {"action": "shell /bin/echo hello"}
    test_task_1_parser = ModuleArgsParser(test_task_1)

# Generated at 2022-06-11 08:49:40.001436
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # testing that the method parse works with arguments that are strings
    module_args_parser1 = ModuleArgsParser({'action': 'shell echo hi'}, collection_list=None)
    assert module_args_parser1.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    # testing that the method parse works with arguments that are dictionaries
    module_args_parser2 = ModuleArgsParser({'action': {'module': 'shell', '_raw_params': 'echo hi'}}, collection_list=None)
    assert module_args_parser2.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    # testing that the method parse works with arguments that are dictionaries and arguments that are strings

# Generated at 2022-06-11 08:49:51.073850
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    task_ds = { 'when': u'True' }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.resolved_action == None
    action = 'ping'
    thing = None
    delegate_to = None
    (valid_action, valid_args, valid_delegate_to) = ('ping', {}, None)
    (test_action, test_args, test_delegate_to) = module_args_parser.parse()
    assert valid_action == test_action
    assert valid_args == test_

# Generated at 2022-06-11 08:50:11.738633
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import mock
    import unittest
    from ansible.parsing.plugin_docs import read_docstring

    class TestModuleArgsParser(unittest.TestCase):
        def setUp(self):
            self.mock_loader = mock.Mock()
            self.mock_collection_list = mock.Mock()



# Generated at 2022-06-11 08:50:16.143612
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # just check that it works and that we recognize the new style
    # task definition: module: copy src=a dest=b
    ds = dict(
        module='shell echo hi',
    )
    mpp = ModuleArgsParser(ds)
    mpp.parse()
    assert mpp.resolved_action == 'shell'

# Generated at 2022-06-11 08:50:22.489576
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = ''
    obj = ModuleArgsParser()
    assert obj.parse(thing) == (None, None, None)

    thing = 'none'
    obj = ModuleArgsParser()
    assert obj.parse(thing) == (None, None, None)

    thing = 'none'
    obj = ModuleArgsParser({})
    assert obj.parse(thing) == (None, None, None)


TASK_PARSER = TaskParser()

# Generated at 2022-06-11 08:50:25.466179
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # TODO: add logic here.
    assert False

    # TODO: make assertions about the result.
    assert False # Did not return from method as expected



# Generated at 2022-06-11 08:50:33.774549
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # create ModuleArgsParser instance m
    m = ModuleArgsParser(collection_list=['foo.bar', 'one', 'two'])
    # set m._task_ds
    m._task_ds = dict(
        delegate_to='test',
        action=dict(
            module='foo.bar.test',
            x=1,
        )
    )
    # test parse method
    action, args, delegate_to = m.parse()
    assert action == 'test'
    assert args == dict(x=1)
    assert delegate_to == 'test'
    action, args, delegate_to = m.parse()
    assert action == 'test'
    assert args == dict(x=1)
    assert delegate_to == 'test'
   

# Generated at 2022-06-11 08:50:37.240432
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert {'action': None, 'args': None, 'delegate_to': None} == result

# Generated at 2022-06-11 08:50:45.598021
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
      'async': 10,
      'poll': 0,
      'when': 'always'
    }
    collection_list = None
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    res = obj.parse()
    # Tests for multiple return values 
    assert len(res) == 3

    # Test returned value type
    assert isinstance(res[0], string_types)
    assert isinstance(res[1], dict)
    if res[2] is None:
        assert res[2] is None
    elif res[2] is Sentinel:
        assert res[2] is Sentinel
    else:
        assert isinstance(res[2], string_types)


# Generated at 2022-06-11 08:50:53.527697
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    module_manager = ModuleManager(0)
    task_ds = {'action': 'shell echo hi',
               'delegate_to': 'xyz',
               'args': {'region': 'xyz'}}
    collection_list = []
    module_class = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_class.parse()
    assert (action == 'shell')
    assert (args.get('_raw_params') == 'echo hi')

# Generated at 2022-06-11 08:50:59.116835
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
   module_args_parser = ModuleArgsParser(task_ds = vs['task_ds'])
   module_args_parser.parse(skip_action_validation = False)

# CONSOLE DEBUGGING:
#
# module_args_parser = ModuleArgsParser(task_ds = t['task_ds'])
# module_args_parser.parse(skip_action_validation = False)

### ---------------------------------------------------------------


# Generated at 2022-06-11 08:51:09.317150
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser()
    task_ds = {}
    results = module_parser.parse(task_ds)
    assert results == (None, {}, None)

    task_ds = {'delegate_to': 'localhost', 'action': 'shell echo hi'}
    results = module_parser.parse(task_ds)
    assert results == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'delegate_to': 'localhost', 'action': {'module': 'shell', 'args': 'echo hi'}}
    results = module_parser.parse(task_ds)
    assert results == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'action': 'shell echo hi'}

# Generated at 2022-06-11 08:51:38.012663
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_hosts = "test_hosts"
    test_tasks = [{"action": {"module": "copy", "src": "a", "dest": "b"}}]
    test_ds = {"action": {"module": "copy", "src": "a", "dest": "b"}}

    def test_ModuleArgsParser_parse_result():
        return [{'action': 'copy', 'delegate_to': None, 'args': {'src': 'a', 'dest': 'b'}}]

    result = ModuleArgsParser(test_ds).parse()
    assert result == test_ModuleArgsParser_parse_result(), "Ansible failed to load args!"
    #assert result == ('copy', {'src': 'a', 'dest': 'b'}, None), "Ansible failed to parse action!!"

# Generated at 2022-06-11 08:51:45.853989
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    ################################################################
    # Tests for the method ModuleArgsParser.parse
    #  of the class ModuleArgsParser
    ################################################################

    # inputs for the method ModuleArgsParser.parse

    # scenario 1
    task_ds = {'action': {'module': 'copy', 'src': 'test', 'dest': 'test'}}
    skip_action_validation = False
    collection_list = dict()
    ModuleArgsParser(task_ds, collection_list).parse()

    task_ds = {'action': {'module': 'copy', 'src': 'test', 'dest':'test'}}
    skip_action_validation = False
    collection_list = dict()
    ModuleArgsParser(task_ds, collection_list).parse()


# Generated at 2022-06-11 08:51:49.790891
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_obj = ModuleArgsParser()
    assert my_obj.parse() == ('', {}, Sentinel)
    assert my_obj.parse() == ('', {}, Sentinel)
    assert my_obj.parse() == ('', {}, Sentinel)


# Generated at 2022-06-11 08:51:51.492281
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    unittest.TestCase()
# test case for module_args_parser

# Generated at 2022-06-11 08:52:01.324579
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'shell': 'ls -l'}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to is None

    task_ds = {'include_role': {'name': 'my_role', 'tasks_from': 'main.yml'}}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'include_role'
    assert args == {'name': 'my_role', 'tasks_from': 'main.yml'}


# Generated at 2022-06-11 08:52:05.405661
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    assert obj.parse(skip_action_validation) == (None, None, None)



# Generated at 2022-06-11 08:52:15.516846
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    def mock_loader_find_plugin_with_context(name, collection_list):
        pass

    def mock__normalize_new_style_args(thing, action):
        return thing

    def mock__normalize_old_style_args(thing):
        return thing

    def mock__normalize_parameters(thing, action=None, additional_args=None):
        return thing

    def mock_parse_kv(thing, check_raw=False):
        return thing

    # Save the original Method
    ModuleArgsParser__normalize_new_style_args = ModuleArgsParser._normalize_new_style_args
    ModuleArgsParser__normalize_old_style_args = ModuleArgsParser._normalize_old_style_args
    ModuleArgsParser__normalize_

# Generated at 2022-06-11 08:52:26.638209
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_obj = ModuleArgsParser()
    # Not sure if we need to test this case as it is not cover in our code
    # try:
    #     test_obj.parse()
    # except Exception as e:
    #     assert(str(e) == "global name 'ActionModuleLoader' is not defined")
    # try:
    #     test_obj.parse()
    # except Exception as e:
    #     assert(str(e) == "global name 'ModuleLoader' is not defined")
    # test_obj = ModuleArgsParser()
    test_obj.action_loader = ActionModuleLoader()
    test_obj.module_loader = ModuleLoader()
    result = test_obj.parse()
    assert(result == (None, {}, None))
    test_obj = ModuleArgsParser({'action': 'echo hello'})

# Generated at 2022-06-11 08:52:34.461897
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    m = ModuleArgsParser()

    class DummyModuleReturn(object):
        pass

    m_return = DummyModuleReturn()
    m_return.resolved = True
    m_return.redirect_list = []
    m_return.resolved_fqcn = [('test_module', '/Users/danswenwang/Workspace/ansible-devel/lib/ansible/modules/test_module.py')]

    def fake_find_plugin(name, *args, **kwargs):
        return m_return

    with patch.object(action_loader, 'find_plugin', side_effect=fake_find_plugin):
        thing = 'test_module args'
        action, args, delegate_to = m.parse(thing)
        assert action == 'test_module'

# Generated at 2022-06-11 08:52:44.807063
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError) as ee:
        module_args_parser._split_module_string('')
    assert str(ee.value) == "the type of 'module_string' should be a string, but is None"
    with pytest.raises(AnsibleAssertionError) as ee:
        module_args_parser._split_module_string(None)
    assert str(ee.value) == "the type of 'module_string' should be a string, but is None"
    assert module_args_parser._split_module_string('echo hi "abc"') == ('echo', 'hi "abc"')
    assert module_args_parser._split_module_string('') == ('', '')
    # test _

# Generated at 2022-06-11 08:53:32.098637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Bug: https://github.com/ansible/ansible/issues/47069
    # In this case, the blacklisting should not affect the production of args
    if module_loader.find_plugin('command'):
        ds1 = dict(
            action=dict(
                module='command',
                chdir='/my/path',
                args='ls'),
            delegate_to='myhost',
        )
        data = ModuleArgsParser(task_ds=ds1, collection_list=None).parse()
        assert data[0] == 'command'
        assert data[1] == {'_raw_params': 'ls', 'chdir': '/my/path'}
        assert data[2] == 'myhost'
