

# Generated at 2022-06-11 08:43:45.152730
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    collector = ModuleArgsParser(task_ds={})
    assert collector.parse() == (None, None, None)


# Generated at 2022-06-11 08:43:55.389451
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    task_ds = dict(
        action=dict(
            module='i_am_a_string',
            x=1,
            y=2,
        )
    )
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'i_am_a_string'
    assert delegate_to is None
    assert args == dict(
        x=1,
        y=2,
    )

    task_ds = dict(
        i_am_a_string=dict(
            x=1,
            y=2,
        )
    )
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-11 08:44:03.535084
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {
        'name': 'my task',
        'notify': ['handlers'],
        'tags': ['debug'],
        'when': True,
        'local_action': 'ec2',
        'delegate_to': 'otherhost',
    }

    # expected result
    action = 'ec2'
    args = {}
    delegate_to = 'otherhost'

    # test
    parser = ModuleArgsParser(task_ds=task_ds)
    actual = parser.parse()

    assert action == actual[0]
    assert args == actual[1]
    assert delegate_to == actual[2]

# Generated at 2022-06-11 08:44:14.132746
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # From ansible/test/units/module_utils/module_common.py
    # test_parse_module_args
    assert ModuleArgsParser({'foo': 1}, 'ansible').parse() == ('ansible', {'foo': 1}, None)
    assert ModuleArgsParser({'foo': 1, 'bar': 2}, 'ansible').parse() == ('ansible', {'foo': 1, 'bar': 2}, None)
    assert ModuleArgsParser({'args': {'foo': 1}, 'delegate_to': 'localhost'}, 'ansible').parse() == ('ansible', {'foo': 1}, 'localhost')
    assert ModuleArgsParser({'ansible': {'foo': 1, 'bar': 2}}, 'ansible').parse() == ('ansible', {'foo': 1, 'bar': 2}, None)
    assert ModuleArgs

# Generated at 2022-06-11 08:44:24.364189
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    assert (module_args_parser.parse(skip_action_validation) == (None, {}, None))

    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    assert (module_args_parser.parse(skip_action_validation) == ('echo', {'_raw_params': 'hi'}, None))

    task_ds = {'args': '_raw_params=hi'}
    collection_list = None

# Generated at 2022-06-11 08:44:30.074817
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = dict(
        action = dict(
            copy = dict(
                src = "a",
                dest = "b"
            ),
            delegate_to = "xyz"
        )
    )
    parser = ModuleArgsParser(task_ds=t, collection_list=None)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'xyz')

# Generated at 2022-06-11 08:44:40.852185
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(remote_addr='127.0.0.1')
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

# Generated at 2022-06-11 08:44:47.513182
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = {'delegate_to': None, 'args': {}, 'action': 'shell', '_ansible_verbosity': 0, '_ansible_no_log': False, '_ansible_diff': False}
    parser = ModuleArgsParser(fake_task_ds, None)

    type_action, type_args, type_delegate_to = parser.parse()

    assert type(type_action) == str
    assert type(type_args) == dict
    assert type(type_delegate_to) == type(None)

# Generated at 2022-06-11 08:44:52.580746
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser()
    result = args_parser.parse()
    assert result == ((None, dict(), 'localhost'), (None, dict(), 'localhost'))
    action, args, delegate_to = result[0]
    assert action == None
    assert args == dict()
    assert delegate_to == 'localhost'
# end of test_ModuleArgsParser_parse method


# Generated at 2022-06-11 08:44:56.618531
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    # Call method
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    res = module_args_parser.parse()
    # Check result
    assert(res == (None, {}, None))


# Generated at 2022-06-11 08:45:33.160860
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with all valid parameters
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result == expected
    # Test with default parameters
    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)
    result = parser.parse()
    assert result == expected

# class used to normalize various formats of block values

# Generated at 2022-06-11 08:45:39.852170
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 's3'
    delegate_to = None
    # arguments can be fuzzy.  Deal with all the forms.
    args = {'s3_acl': 'bucket-owner-full-control'}
    loader = None
    task_ds = dict(args=args, action=action, delegate_to=delegate_to)
    expected = (action, args, delegate_to)
    collection_list = None

    obj = ModuleArgsParser(task_ds, collection_list)
    actual = obj.parse()
    assert expected == actual


# Generated at 2022-06-11 08:45:44.947679
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = None
    action = "echo"
    delegate_to = "localhost"
    args = []
    forwarded_args = []

    assert (action, args, delegate_to) == ModuleArgsParser._parse(thing=thing, action=action, args=args, delegate_to=delegate_to, forwarded_args=forwarded_args)


# Generated at 2022-06-11 08:45:48.208104
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(action="shell", args="echo hello", delegate_to="localhost")
    m = ModuleArgsParser(args)
    assert m.parse() == ('shell', {'_raw_params': 'echo hello'}, 'localhost')

# Generated at 2022-06-11 08:45:49.000315
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-11 08:45:58.507676
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestModuleArgsParser(unittest.TestCase):

        def setUp(self):
            self._task_ds = {}
            self._parser = ModuleArgsParser(self._task_ds)

        def test_normalize_parameters(self):
            module_string = 'systemd name=httpd state=restarted'
            expected_result = ('systemd', {'name': 'httpd', 'state': 'restarted'})
            result = self._parser._normalize_parameters(module_string)
            self.assertEqual(result, expected_result)

            (action, args, delegate_to) = self._parser.parse()
            result = (action, args)
            self.assertEqual(result, expected_result)

            module_args = {'name': 'httpd', 'state': 'restarted'}

# Generated at 2022-06-11 08:46:01.193884
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a simple Ansible task that includes module and it's arguments
    task_ds = {'action': 'shell name=echo Hi'}
    # Create ModuleArgsParser instance including task_ds for parsing
    parser = ModuleArgsParser(task_ds)
    # Parse the task and check that it returns action, args and delegate_to as expected
    assert parser.parse() == ('shell', {'name': 'echo Hi'}, None)


# Generated at 2022-06-11 08:46:09.877456
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:46:18.479767
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # This was a test for the exepected error, no longer used.
    # def test_ModuleArgsParser_parse_exception(self):
    """Unit test for ModuleArgsParser.parse."""
    # Set up a test ds with a dictionary and example args.
    # We can't use the builtin ds in the method parser because it
    # refers to AnsibleParserError, which we do not have here.
    test = {}
    test_args = {}
    # Create a parser and call the parse method.
    test_parser = ModuleArgsParser(test, None)
    with pytest.raises(AnsibleParserError) as exc_info:
        test_parser.parse()
    assert exc_info.value.obj == test
    assert "action" in exc_info.value.obj
    assert "module" in exc_

# Generated at 2022-06-11 08:46:22.953060
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(
        task_ds=dict(
            module='command',
            args=dict(
                chdir='/tmp',
                warn=False,
            )
        )
    )
    assert m.parse() == ('command', {'_raw_params': u'', 'chdir': '/tmp', 'warn': True}, None)


# Generated at 2022-06-11 08:46:36.993989
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # method parse normal
    td = {'action': 'shell', 'args': 'echo hello'}
    parser = ModuleArgsParser(td)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hello'}
    assert delegate_to == Sentinel

    # method parse local_action
    td = {'local_action': 'shell', 'args': 'echo hello'}
    parser = ModuleArgsParser(td)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hello'}
    assert delegate_to == 'localhost'

    # method parse non-task statement
    td = {'module': 'shell', 'args': 'echo hello'}
   

# Generated at 2022-06-11 08:46:46.408047
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
   parser = ModuleArgsParser()
   assert parser.parse({'action': {'module': 'ec2', 'x': 1}}) == ('ec2', {'x':1}, None)
   assert parser.parse({'local_action': 'shell echo hi'}) == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
   assert parser.parse({'delegate_to': 'localhost', 'action': 'copy src=a dest=b'}) == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
   assert parser.parse({'ansible_facts': {'data':'foo'}}) == ('ansible_facts', {'data':'foo'}, None)

# Generated at 2022-06-11 08:46:55.740062
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    dump_data = {'delegate_to': 'localhost', 'local_action': 'command ls'}
    expected_result = ('command', {'_raw_params': 'ls'}, 'localhost')
    actual_result = ModuleArgsParser(dump_data).parse()

    assert_equal(expected_result, actual_result)

    # This test case is too complex. I haven't got the time to fix it.
    # dump_data = {'args': {u'_raw_params': u'echo hi'},
    #              'delegate_to': 'localhost',
    #              'local_action': 'command'}
    # expected_result = (u'command', {u'_raw_params': u'echo hi'}, 'localhost')
    # actual_result = ModuleArgsParser(dump_data).parse()

    # assert

# Generated at 2022-06-11 08:46:58.439232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(task_ds=dict(action=dict(module='ping', args='pam'), delegate_to="localhost"))
    assert m.parse() == ('ping', {'pam': None}, 'localhost')

# Generated at 2022-06-11 08:47:01.152947
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ipdb
    ipdb.set_trace()
    a = ModuleArgsParser()
    print(a.parse())

# ---------------------------------------------------------
# Parser
# ---------------------------------------------------------


# Generated at 2022-06-11 08:47:08.934758
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # Invalid task_ds
    task_ds = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    try:
        result = module_args_parser.parse(skip_action_validation=False)
    except Exception as exception:
        assert isinstance(exception, AnsibleAssertionError)
        assert exception.message == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"
    # Invalid task_ds
    task_ds = []

# Generated at 2022-06-11 08:47:17.609852
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    # Load the module

    module = AnsibleModule(
        argument_spec = dict(
            task_ds = dict(type='dict', default={}),
            collection_list = dict(type='list', default=[]),
        ),
        supports_check_mode=True
    )

    task_ds = module.params['task_ds']
    collection_list = module.params['collection_list']
    #Parse the result
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    # Validate the result
    assert action == ""
    assert args == {}
    assert delegate_to is None


# Generated at 2022-06-11 08:47:19.086451
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: have to be implemented, but not used anywhere
    pass

# Generated at 2022-06-11 08:47:23.802813
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    output = parse_playbook("""
        - name: create cronjob
          cron: name="test" minute="*/15" job="date > /tmp/date"
    """)
    item = ModuleArgsParser(output[0][0].get_block().block[0])
    return item.parse()

NOTable = namedtuple('NOTable', ['value', 'use_jinja', 'origin'])



# Generated at 2022-06-11 08:47:30.340205
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tester = ModuleArgsParser(task_ds={})
    result = tester.parse()
    assert result is not None
    assert type(result) is tuple
    assert len(result) == 3
    assert result[0] is None
    assert type(result[1]) is dict
    assert not result[1]
    assert result[2] is sentinel

# =================================================================================
# ==== CollectionLoader: dynamic collections, able to filter results on version ====
# =================================================================================


# Generated at 2022-06-11 08:47:48.675488
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a dummy action_loader and module_loader
    action_loader = DummyActionModuleLoader()
    module_loader = DummyModuleLoader()
    # Create an instance of ModuleArgsParser
    module_args_parser = ModuleArgsParser(collection_list=None)
    # Construct a valid complex args task
    task_ds = { 'module': 'debug', 'msg': 'Hello World', '_raw_params': 'msg=Hello World' }
    # Parse the task and verify results
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    assert action == 'debug'
    assert isinstance(args, dict)
    assert args == {'msg': 'Hello World', '_raw_params': 'msg=Hello World' }
    assert delegate_to == Sentinel

# Generated at 2022-06-11 08:47:59.692919
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # simple new style action
    task_ds = dict(action='command', args='foo')
    task_ds_normalized = ModuleArgsParser(task_ds=task_ds).parse()
    assert task_ds_normalized == ('command', {'_raw_params': 'foo'}, None)

    # - name: this is my raw command
      # action: command "this is my raw command"
    task_ds = dict(action='command "this is my raw command"')
    task_ds_normalized = ModuleArgsParser(task_ds=task_ds).parse()
    assert task_ds_normalized == ('command', {'_raw_params': '"this is my raw command"'} , None)

    # - name: this is my raw command
      # action: "echo {{ foo }}"

# Generated at 2022-06-11 08:48:09.334811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    c = AnsibleJSONConfigParser()
    # setup test environment
    # with patch('ansible.module_utils.common.missing_required_lib':
    #   module_utils.common.missing_required_lib = mock.MagicMock()
    for action in ('command', 'shell', 'raw'):
        for cmd in ('ls', 'echo "value1" > ~/file1'):
            task1 = dict(
                action=dict(
                    testcase='action',
                    action='%s' % action,
                    args=cmd
                )
            )
            task2 = dict(
                local_action=dict(
                    testcase='local_action',
                    action='%s' % action,
                    args=cmd
                )
            )

# Generated at 2022-06-11 08:48:11.289941
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(task_ds=dict(action="ping"))
    assert m.parse() == ('ping', {}, Sentinel)

# Generated at 2022-06-11 08:48:22.073598
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:48:28.270618
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # setup test
    task_ds = {'a':'1'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    # execute test
    actual_result = module_args_parser.parse()

    assert actual_result[0] == 'a'
    assert actual_result[1] == {'_raw_params': '1'}
    assert actual_result[2] == Sentinel

# Test case for parse: task_ds value is None

# Generated at 2022-06-11 08:48:34.654582
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # type: () -> None
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    module_ds = dict()
    task_ds = dict()
    module_args_parser = ModuleArgsParser(task_ds, collection_list=None)
    module_args_parser.parse()
    module_args_parser.resolved_action
    module_args_parser.parse()
    module_args_parser.resolved_action



# Generated at 2022-06-11 08:48:44.567413
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
                "ec2":{
                    "region": "xyz",
                    "instance": "i-12345678",
                    "wait": "yes",
                    "args":{
                        "state": "stopped"
                    }
                }
            }
    action, args, delegate_to = ModuleArgsParser(task_ds=task_ds, collection_list=None).parse()
    assert action == 'ec2'
    assert args == {"instance":"i-12345678","region":"xyz","wait":"yes","state":"stopped"}
    assert delegate_to is None

    task_ds = {
                "module": "shell echo hi",
                "args": {
                    "chdir": "/tmp"
                },
                "register": "shell_out"
            }

# Generated at 2022-06-11 08:48:50.338692
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method parse of class ModuleArgsParser.
    """
    # Arrange
    task_ds = {'action': 'shell echo hi'}
    # Act
    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    # Assert
    assert('shell' == result[0])
    assert(dict() == result[1])
    assert(None == result[2])

# Generated at 2022-06-11 08:49:01.902756
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # monkey-patching template strings
    templar = Templar(loader=None)
    def _is_template(line):
        return True
    templar.is_template = _is_template
    # test parsing a string with delegate_to
    test_ds = {
        "delegate_to": "localhost",
        "action": {
            "module": "ec2",
            "x": 1,
            "y": 2,
            "z": 3
        }
    }
    map = ModuleArgsParser(test_ds)
    (module_name, args, delegate_to) = map.parse()
    assert module_name == "ec2"
    assert args == {"x": 1, "y": 2, "z": 3, "_variable_params": "x=1 y=2 z=3"}
   

# Generated at 2022-06-11 08:49:22.686957
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:49:23.372381
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Generated at 2022-06-11 08:49:33.133548
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import collections

    class AnsibleAssertionError(Exception): pass
    class AnsibleParserError(Exception): pass
    class AnsibleError(Exception): pass
    class AnsibleUndefinedVariable(object): pass
    class ActionLoader(object): pass
    class ModuleLoader(object): pass

    module_loader = ModuleLoader()
    action_loader = ActionLoader()

    class NativeLoader(object):
        def __init__(self):
            self.shell = 'shell'

    class Templar(object):
        def __init__(self, loader=None):
            self.loader = loader

        def is_template(self, path):
            if self.loader:
                if self.loader.path_exists(path):
                    return False
            return True

    class Sentinel(object):
        __nonzero__ = lambda self: False


# Generated at 2022-06-11 08:49:34.691289
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# ---------------------------------------------------------------------------------------------------
# helper method for normalizing default values of various types

# Generated at 2022-06-11 08:49:38.907296
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'echo hi',
               'delegate_to': 'localhost',
               'args': {'chdir': '/tmp'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('echo', {'_ansible_syslog_facility': 'LOG_USER',
                                       '_raw_params': 'hi',
                                       '_uses_shell': True}, 'localhost')



# Generated at 2022-06-11 08:49:49.471430
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # pylint: disable=protected-access
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert (module_args_parser._normalize_parameters('copy src=a dest=b') == ('copy', {'src': 'a', 'dest': 'b'}))
    assert (module_args_parser._normalize_parameters('copy src=a dest=b', 'copy') ==
            ('copy', {'src': 'a', 'dest': 'b'}))

# Generated at 2022-06-11 08:49:59.377455
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.errors as ansible_errors
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    ds = DataLoader()
    variable_manager = VariableManager()

    parser = ModuleArgsParser()

    # type: ansible.playbook.play.Play

# Generated at 2022-06-11 08:50:08.777168
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing_string = 'echo hi'  # String
    action = 'shell'  # String
    additional_args = {}  # Dictionary
    testString = 'testString'  # String

    # Test with above variables
    print('# Test with above variables')

    _task_ds = {'shell': 'echo hi'}  # Dictionary

    parser = ModuleArgsParser(task_ds=_task_ds)
    action, args, delegate_to = parser.parse()
    
    print('action: {0}, args: {1}, delegate_to: {2}'.format(action, args, delegate_to)) # result: action: shell, args: {}, delegate_to: <ansible.utils.sentinel.Sentinel object at 0x7f4b28c4fe80>    
    

test_ModuleArgsParser_parse()


# Generated at 2022-06-11 08:50:11.600624
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = []

    args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    args_parser.parse()



# Generated at 2022-06-11 08:50:22.027059
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)
    task_ds = dict(action=dict())
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)
    task_ds = dict(local_action=dict())
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, 'localhost')
    task_ds = dict(local_action='', delegate_to='foo')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, 'foo')
    task_ds = dict(local_action=dict(module='foo'))
   

# Generated at 2022-06-11 08:50:40.302423
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleAssertionError
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleError
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    result = module_args_parser.parse()
    assert 'action' not in result[1]
    assert 'module' not in result[1]

# Generated at 2022-06-11 08:50:49.180122
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    r = ModuleArgsParser(task_ds, collection_list).parse()
    assert_equal(r, ('', {}, None))

    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list = None
    r = ModuleArgsParser(task_ds, collection_list).parse()
    assert_equal(r, ('copy', {'src': 'a', 'dest': 'b'}, None))

    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    r = ModuleArgsParser(task_ds, collection_list).parse()

# Generated at 2022-06-11 08:50:58.889501
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test string-form args
    thing = {'action': 'shell echo test', 'other_attr': 'other'}
    parser = ModuleArgsParser(thing)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args['_raw_params'] == 'echo test'
    assert 'other_attr' not in args
    assert delegate_to is None

    thing = {'action': {'module': 'shell', 'args': 'echo test'}, 'other_attr': 'other'}
    parser = ModuleArgsParser(thing)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args['_raw_params'] == 'echo test'
    assert 'other_attr' not in args
    assert delegate_to is None

   

# Generated at 2022-06-11 08:51:03.701260
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {
        'module': 'shell',
        'delegate_to': 'localhost',
        'args': {
            'command': 'uname'
        }
    }
    parser = ModuleArgsParser(task_ds=args)
    assert parser.parse() == ('shell', {'command': 'uname'}, 'localhost')



# Generated at 2022-06-11 08:51:14.414117
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # Test args parsing with example input.
  module_arg_parser = ModuleArgsParser()
  assert module_arg_parser._split_module_string('shell echo hi') == ('shell', 'echo hi')
  assert module_arg_parser._split_module_string('shell') == ('shell', '')
  assert module_arg_parser._split_module_string('shell echo hi more') == ('shell', 'echo hi more')
  assert module_arg_parser._split_module_string('shell echo "hi more"') == ('shell', 'echo "hi more"')
  assert module_arg_parser._split_module_string('shell echo "hi more') == ('shell', 'echo "hi more')
  assert module_arg_parser._split_module_string('shell echo hi more=thing') == ('shell', 'echo hi more=thing')
 

# Generated at 2022-06-11 08:51:21.964902
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parameters = dict()
    parameters.update({'task_ds': {}})
    parameters.update({'collection_list': ['ansible.builtin']})
    # Act
    actual_result = ModuleArgsParser(**parameters).parse()
    # Assert
    parameters = dict()
    expected_result = (None, {}, None)
    assert_equal(expected_result, actual_result)

    # Act
    parameters['task_ds'] = {'module': 'something'}
    actual_result = ModuleArgsParser(**parameters).parse()
    # Assert
    parameters = dict()
    expected_result = (None, {}, None)
    assert_equal(expected_result, actual_result)

    # Act

# Generated at 2022-06-11 08:51:24.115285
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={})
    assert module_args_parser.parse() == (None, {}, Sentinel) == (None, dict(), Sentinel)

# Generated at 2022-06-11 08:51:33.829341
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys
    import os.path
    test_dir = os.path.dirname(__file__)
    sys.path.append(test_dir)
    test_yaml_dir = os.path.join(test_dir, 'yaml')
    task_ds = load_yaml_file(os.path.join(test_yaml_dir, "test_ModuleArgsParser.yaml"))

    #test case 1: skip action validation is False
    expected_result_1 = ('test_module', {u'a': u'abc', u'b': u'123'}, None)
    module_arg_parser = ModuleArgsParser(task_ds, None)
    actual_result_1 = module_arg_parser.parse(False)
    assert_equal(expected_result_1, actual_result_1)

    #

# Generated at 2022-06-11 08:51:44.265729
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task_ds = {
        'name': 'this is a test',
        'local_action': 'shell echo "{{x}}"',
        'register': 'shell_out'
    }
    parser.parse(task_ds)
    assert parser._task_ds == task_ds

# Generated at 2022-06-11 08:51:55.224847
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Load input data from a JSON file
    # Subsequently, we will serialize the data to YAML and use it for testing
    input_file = "test/integration/targets/inventory_from_export/host_vars/.ansible/tmp/ansible-local-11582dM4ST4/tmpa_c4_nz/module_args_raw"
    with open(input_file, "r") as f:
        input_data = json.load(f)

    # We need to fix up the input data.
    input_data["task"]["include_role"]["name"] = "role_name"
    input_data["task"]["import_role"]["name"] = "role_name"
    input_data["task"]["wait_for"]["delay"] = "1"


# Generated at 2022-06-11 08:52:23.586381
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    myarg = dict(
        action="shell",
        args=dict(_raw_params="echo hi", x=1)
    )
    module_args_parser = ModuleArgsParser(myarg, None)
    module_args_parser.parse()
    assert module_args_parser.parse() == ('shell', {'x': 1, '_raw_params': 'echo hi'}, None)
    myarg = dict(
        copy="src=a dest=b"
    )
    module_args_parser = ModuleArgsParser(myarg, None)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    myarg = dict(
        local_action="copy src=a dest=b"
    )

# Generated at 2022-06-11 08:52:27.605947
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:52:35.649184
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ds_noraml_dict_delegate_to_is_normalized
    simple_raw_dict = dict(
        delegate_to='localhost'
    )
    test_ds = copy.deepcopy(simple_raw_dict)
    module_args_parser = ModuleArgsParser(task_ds=test_ds)
    test_result = module_args_parser.parse(skip_action_validation=True)
    assert test_result[0] is None
    assert test_result[1] == {}
    assert test_result[2] == 'localhost'
    # test_ds_noraml_dict_delegate_to_is_normalized_and_overriden
    test_ds = copy.deepcopy(simple_raw_dict)
    test_ds['delegate_to'] = 'other_host'
   

# Generated at 2022-06-11 08:52:45.587906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'module': 'ec2', 'x': 1}}
    collection_list = []
    module_args = ModuleArgsParser(task_ds, collection_list).parse()
    assert module_args == ('ec2', {'x': 1}, None)

    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = []
    module_args = ModuleArgsParser(task_ds, collection_list).parse()
    assert module_args == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = []
    module_args = ModuleArgsParser(task_ds, collection_list).parse()

# Generated at 2022-06-11 08:52:46.949514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {}
    parser = ModuleArgsParser(task_ds=ds)
    assert parser.parse() == (None, dict(), Sentinel)



# Generated at 2022-06-11 08:52:54.637347
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # caller must pass in a task_ds
    def parse(task_ds):
        obj = ModuleArgsParser(task_ds)
        return obj.parse()
    # test with a good task_ds
    task_ds = { 
        "action" : "copy", 
        "args" : { 
            "dest" : "b"
        }, 
        "delegate_to" : "127.0.0.1", 
        "module" : "copy src=a"
    }
    r = parse(task_ds)
    assert type(r) == tuple
    action, args, delegate_to = r
    assert action == 'copy'
    assert type(args) == dict
    assert args == { 'dest': 'b' }
    assert delegate_to == '127.0.0.1'
   

# Generated at 2022-06-11 08:52:58.177833
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    argument_dict = dict(
        delegate_to='localhost',
        action='shell',
        args='echo hi'
    )
    
    module_args_parser = ModuleArgsParser(
        task_ds=argument_dict
    )

    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

# Generated at 2022-06-11 08:53:06.269945
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"args": "", "local_action": {"module": "copy src=a dest=b"}}
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
    task_ds = {"args": "", "action": {"module": "copy src=a dest=b"}}
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = {"args": "", "action": "copy src=a dest=b"}
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)

# Generated at 2022-06-11 08:53:15.086689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_task_ds = {'action': 'shell echo hi'}
    my_collection_list = None

    my_obj = ModuleArgsParser(task_ds=my_task_ds, collection_list=my_collection_list)
    result = my_obj.parse()

    assert result == ('shell', {'_raw_params': 'echo hi'}, None)

    my_task_ds = {'action': 'shell echo hi'}
    my_collection_list = ['test_module']

    my_obj = ModuleArgsParser(task_ds=my_task_ds, collection_list=my_collection_list)
    result = my_obj.parse()

    assert result == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-11 08:53:25.423767
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Unit test for method 'parse' of class ModuleArgsParser.
    """
    ModuleArgsParser.parse('action: copy src=a dest=b')
    assertEqual(u'echo hi', ModuleArgsParser(action='shell', echo_hi='echo hi'))
    assertEqual(u'echo hi', ModuleArgsParser(action='shell', echo_hi='echo hi'))
    assertEqual(u'echo hi', ModuleArgsParser(action='shell', echo_hi='echo hi'))
    # Check exceptions
    # Exception: no module/action detected in task.
    ModuleArgsParser.parse('')
    # Exception: conflicting action statements: copy, shell
    ModuleArgsParser.parse('action: copy src=a dest=b')
    # Exception: bad_action
    ModuleArgsParser.parse(action='bad_action')

