

# Generated at 2022-06-11 08:44:02.801813
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    collection_list = []
    args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    expected = ('shell', {'args': 'echo hi'}, None)
    actual = args_parser.parse(skip_action_validation=False)
    assert expected == actual

# Generated at 2022-06-11 08:44:06.224420
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = list()

    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    module_args_parser.parse()

    return


# Generated at 2022-06-11 08:44:11.324254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser()
    argv = {}
    argv['task_ds'] = {'action': 'shell echo hi'}
    argv['skip_action_validation'] = False
    res = obj.parse(**argv)
    assert res == ('shell', {'_raw_params': 'echo hi'}, None)



# Generated at 2022-06-11 08:44:11.982741
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-11 08:44:16.735598
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'echo',
        'args': 'hello'
    }
    collection_list = ['all', 'collections/ansible/builtin']
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    module_args_parser.parse()

# Generated at 2022-06-11 08:44:27.036685
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test case for parse method of class ModuleArgsParser
    """
    #print ("Executing test_ModuleArgsParser_parse")
    import os
    import json
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.errors import AnsibleAssertionError, AnsibleParserError, AnsibleError
    from ansible.playbook.role.include import Include
    from ansible.plugins.action import ActionBase

    include = Include()
    action_base = ActionBase()
    t = Task()
    task_ds = {}
    t.load(task_ds)
    collection_list = ['ansible.builtin.ping']

# Generated at 2022-06-11 08:44:37.454137
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task = dict(
        module = 'command'
    )

    obj = ModuleArgsParser(
        task_ds = _task,
        collection_list = None
    )
    
    if obj.parse() != (
        'command',
        {},
        None
    ):
        raise AssertionError()

    _task = dict(
        action = 'command'
    )
    obj = ModuleArgsParser(
        task_ds = _task,
        collection_list = None
    )
    
    if obj.parse() != (
        'command',
        {},
        None
    ):
        raise AssertionError()

    _task = dict(
        command = 'command'
    )
    obj = ModuleArgsParser(
        task_ds = _task,
        collection_list = None
    )

# Generated at 2022-06-11 08:44:47.734321
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1
    data = {'name': 'test_arg', 'with_items': [1, 2, 3], 'action': 'test_arg', 'args': {'_raw_params': 'text={{item}}', '_uses_shell': True, '_uses_delegate': True, '_raw_params': 'text={{item}}'}, 'delegate_to': 'localhost', 'register': 'foo'}
    result = ModuleArgsParser(data).parse()
    assert result == ('test_arg', {'_uses_delegate': True, '_uses_shell': True, '_raw_params': 'text={{item}}'}, 'localhost')
    # test case 2

# Generated at 2022-06-11 08:44:57.431772
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DictDataLoader({})
    collection_list = CollectionList()
    collection_list.extend(Collections(loader=loader, collections=['test_collections/test_module_utils/module_utils']))


    # test for no module
    parser = ModuleArgsParser(task_ds={}, collection_list=collection_list)
    assert parser.parse(skip_action_validation=True) == (None, dict(), Sentinel)

    # test for action module
    parser = ModuleArgsParser(task_ds={'raw_module': 'shell echo hi'}, collection_list=collection_list)
    action, args, delegate_to = parser.parse(skip_action_validation=True)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}

# Generated at 2022-06-11 08:45:00.639379
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    MAP = ModuleArgsParser(task_ds)
    module_string = 'echo hi'
    tokens = MAP._split_module_string(module_string)
    assert tokens[0] == module_string


# Generated at 2022-06-11 08:45:29.391780
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:36.719764
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_task_ds_1 = {'local_action': 'shell echo hi'}
    module_args_task_ds_2 = {'action': {'module': 'shell', '_raw_params': 'echo hi'}}
    module_args_task_ds_3 = {'action': 'shell echo hi'}
    module_args_task_ds_4 = {'module': 'shell echo hi'}
    module_args_task_ds_5 = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    module_args_task_ds_6 = {'copy': 'src=a dest=b'}
    module_args_task_ds_7 = {'module': 'copy src=a dest=b'}
    module_args_task_ds_8

# Generated at 2022-06-11 08:45:47.373596
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    host_vars = dict()
    task_ds = dict(action='command', args={'chdir': '/tmp'})
    task = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert task == ('command', {'chdir': '/tmp'}, False)

    task_ds = dict(action='command', args='{{var}}')
    task = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert task == ('command', {'_variable_params': '{{var}}'}, False)

    task_ds = dict(action='command', args={'test': '{{var}}'})
    task = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert task == ('command', {'test': '{{var}}'}, False)


# Generated at 2022-06-11 08:45:57.085572
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs = frozenset(task_attrs)

    # create an instance of ModuleArgsParser for testing
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'}, collection_list=None)

    # invoke the tested method, and assert the expected results

    # form is like:  action: copy src=a dest=b
    # form is like:  action: { module: 'copy', src: 'a', dest: 'b' }
    # form is like:

# Generated at 2022-06-11 08:46:05.876744
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from ansible.compat.tests import unittest
  from ansible.module_utils._text import to_bytes

  # mock _task_ds
  _task_ds = dict()
  
  # instantiate parser
  parser = ModuleArgsParser(_task_ds)
  
  # test parse when _split_module_string is called and case when normalize_parameters is called with (raw_params, shell)
  thing = "shell echo hi"
  action = "shell"
  additional_args = ""
  tokens = ['shell', 'echo hi']
  assert parser._split_module_string(thing) == (tokens[0].strip(), " ".join(tokens[1:]))

# Generated at 2022-06-11 08:46:14.753293
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': "command  echo  'hello world'   chdir=/tmp  creates=/tmp/file",
               'with_sequence': [1, 2, 3, 4],
               'with_subelements': [{'name': 'example1'}, {'name': 'example2'}],
               'args': {'test': 'arg', 'test2': 'arg'},
               'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('command', {'_raw_params': "echo 'hello world'",
                                          'chdir': '/tmp', 'creates': '/tmp/file',
                                          'test': 'arg', 'test2': 'arg'}, 'localhost')

# Generated at 2022-06-11 08:46:21.300508
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"with_items": ["{{vars[item]}}"], "include_vars": "host_vars/{{inventory_hostname}}",
               "action": "manage_file", "args": "src={{item}} dest=/etc/foo/{{item}}", "args.mode": "0777",
               "args.owner": "root", "args.group": "root"}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    module_args_parser.parse()



# Generated at 2022-06-11 08:46:29.709557
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_arg_parser = ModuleArgsParser(task_ds={}, collection_list = [])
    # Test with some non_task_ds
    task_ds = {
        ModuleArgsParser._task_ds :{
            'action' : {
                'module': 'echo',
                'static': ['foo'],
                'args' : 'bar',
                'local_action' : {
                    'module': 'echo',
                    'static': ['foo'],
                    'args' : 'bar',
                    'delegate_to' : 'localhost',
                    'noop': True
                }
            },
            'noop': True
        }
    }

    # Test with some non_task_ds

# Generated at 2022-06-11 08:46:34.626260
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  module_args_parser = ModuleArgsParser( task_ds = { 'name': 'test_ModuleArgsParser_parse', 'action': 'test_ModuleArgsParser_parse' } )
  assert module_args_parser.parse()[0] == 'echo'
  assert module_args_parser.parse()[1] is None
  assert module_args_parser.parse()[2] == Sentinel


# Generated at 2022-06-11 08:46:43.006073
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = dict(
        action = None,
        args = dict(),
        delegate_to = Sentinel
    )
    module_args_parser = ModuleArgsParser(
        task_ds=dict(
            action=dict(
                module='copy',
                src='a',
                dest='b'
            ),
            args=dict(
                umask=0o22,
                validate='no'
            )
        ),
        collection_list=None
    )
    result = module_args_parser.parse(skip_action_validation=False)
    assert result == module_args, 'ModuleArgsParser.parse returns %s, not %s' % (result, module_args)



# Generated at 2022-06-11 08:47:00.542295
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'plugins', 'modules'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'plugins', 'modules', 'local'))


# Generated at 2022-06-11 08:47:08.538515
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m_parse_args = dict(thing=None, skip_action_validation=False)
    m_parse_ds = dict()
    m_parse_task_ds = {"action": "shell echo hi",
                       "delegate_to": "localhost",
                       "args": {"chdir": "/tmp"}}
    m_parse_loader = None
    m_parse_task_attrs = {"name", "with_items", "with_items", "with_fileglob",
                          "with_first_found", "with_sequence", "with_dict", "with_file",
                          "when", "async_val", "poll", "ignore_errors", "free_form",
                          "notify", "register", "until", "retries", "local_action", "static"}

# Generated at 2022-06-11 08:47:10.216995
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AssertionError):
        parser = ModuleArgsParser('thing')
        parser.parse()


# Generated at 2022-06-11 08:47:19.612550
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1 :
    # input
    task_args = {'action':'shell echo hello'}

    #expected outputs
    action = 'shell'
    args = {
              "_raw_params": "echo hello"
            }
    delegate_to = None

    # testing
    module_parser = ModuleArgsParser(task_ds=task_args)
    result = module_parser.parse()
    assert(result[0] == action)
    assert(result[1] == args)
    assert(result[2] == delegate_to)

    # test case 2 :
    # input
    task_args = {'action':'shell echo hello', 'delegate_to': 'localhost'}

    #expected outputs
    action = 'shell'
    args = {
              "_raw_params": "echo hello"
            }


# Generated at 2022-06-11 08:47:20.209555
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-11 08:47:23.548069
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds={}
    collection_list=[]
    expect_res=('include_tasks', {}, 'localhost')
    obj = ModuleArgsParser(task_ds, collection_list)
    res = obj.parse()
    assert res == expect_res


# Generated at 2022-06-11 08:47:33.814497
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # case 1
    task_ds = {'action': 'copy src=abc dest=/tmp',
               'name': 'my_task'}

    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    expected_args = {'src': 'abc', 'dest': '/tmp'}
    assert args == expected_args
    assert delegate_to is None

    # case 2
    task_ds = {'local_action': 'copy src=abc dest=/tmp',
               'name': 'my_task'}

    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    expected_args = {'src': 'abc', 'dest': '/tmp'}
    assert args

# Generated at 2022-06-11 08:47:36.073191
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={})
    assert parser._task_ds == {}
    parser.parse()


# Generated at 2022-06-11 08:47:46.287223
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.inventory.host import Host
    from ansible.parsing.task_ds import TaskData
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    host = Host('host')
    # test when action is specified in task_ds
    module_args = {
        'action': {
            'module': 'test_module'
        },
        'delegate_to': 'test_host'
    }
    t = ModuleArgsParser(module_args, collection_list=['test_collection']).parse(skip_action_validation=True)
    assert t[0] == 'test_module'
    assert t[1] == {}
    assert t[2] == 'test_host'



# Generated at 2022-06-11 08:47:48.935863
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create task_ds
    task_ds = dict()

    # Create instance of class ModuleArgsParser with task_ds and call method parse
    instance = ModuleArgsParser(task_ds=task_ds)
    instance.parse()



# Generated at 2022-06-11 08:48:06.542618
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'shell': 'echo hi'})
    assert parser.parse() == ('shell', {u'_raw_params': u'echo hi'}, None)
    parser = ModuleArgsParser(task_ds={'module': 'shell', 'echo': 'hi'})
    assert parser.parse() == ('shell', {u'echo': u'hi'}, None)
    parser = ModuleArgsParser(task_ds={'module': 'shell', 'args': 'echo hi'})
    assert parser.parse() == ('shell', {u'echo': u'hi'}, None)
    parser = ModuleArgsParser(task_ds={'module': 'shell', 'args': {'echo': 'hi'}})
    assert parser.parse() == ('shell', {u'echo': u'hi'}, None)
    parser

# Generated at 2022-06-11 08:48:14.225287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    expected_results = ('ec2', {'x': 1}, 'localhost')

    test_cases = dict()
    test_cases["""action: shell echo hi"""] = expected_results
    test_cases["""action: { module: ec2, x: 1}"""] = expected_results
    test_cases["""action: ec2 x=1"""] = expected_results
    test_cases["""local_action: ec2 x=1"""] = expected_results

    for case in test_cases:
        ds = yaml.load(dedent(case))
        assert ModuleArgsParser(ds).parse() == test_cases[case]



# Generated at 2022-06-11 08:48:20.358279
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Check for common case
    task_ds = {'action': 'shell', 'args': {'free_form': True, 'creates': '/tmp/test.tmp'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (u'shell', {u'creates': u'/tmp/test.tmp', u'_raw_params': u'', u'free_form': True}, None)



# Generated at 2022-06-11 08:48:31.026423
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Note: module_loader.find_plugin_with_context and action_loader.find_plugin_with_context
    # are mocked by touching the context.resolved attribute, so a plugin can be found or not
    # depending on the value of this attribute.
    task_ds = {}

    # no module/action detected in task.
    task_ds = {'other': 'value'}
    parser = ModuleArgsParser(task_ds)
    assert_raises(AnsibleParserError, parser.parse)

    # more than one module name is a problem
    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}, 'local_action': {'module': 'shell', 'args': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-11 08:48:41.216577
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(a=1, b=2)
    module_args_parser = ModuleArgsParser(dict(module="foo", args=args))
    assert args == module_args_parser._normalize_new_style_args(args, "foo")

    # Test _normalize_parameters with args as dict
    module_args_parser = ModuleArgsParser(dict(module="foo", args=args))
    assert args == module_args_parser._normalize_parameters(args, "foo")

    # Test _normalize_parameters with args as dict with a dict in 'args' key
    args = dict(a=1, args=dict(b=2, c=3))
    module_args_parser = ModuleArgsParser(dict(module="foo", args=args))

# Generated at 2022-06-11 08:48:50.562307
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # init arguments
    task_ds = {
        "action": 'copy src=/tmp/{{ src_filename }} dest=/tmp/{{ dest_filename }}',
        "register": "result"
    }
    task_ds = {
        "action": 'copy src={{SRC_FILE}} dest={{DEST}}',
        "register": "result"
    }
    additional_args = {
        "_raw_params": "src={{SRC_FILE}} dest={{DEST}}",
        "_uses_shell": True,
        "dest": "{{DEST}}",
        "src": "{{SRC_FILE}}"
    }
    # init logger
    log = logging.getLogger()
    # create target object
    target_obj = ModuleArgsParser(task_ds)
    # perform test
    action, args

# Generated at 2022-06-11 08:49:02.183580
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    arguments = {
        'module': {
            'options': {
                'option': {
                    'required': True,
                    'type': 'str'
                }
            }
        }
    }


# Generated at 2022-06-11 08:49:11.535514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = 'shell echo hi'
    expected_result = ('shell', {'_raw_params': 'echo hi'}, None)
    parser = ModuleArgsParser(task_ds=data)
    result = parser.parse()
    assert_equal(result, expected_result)

    data = 'copy src=a dest=b'
    expected_result = ('copy', {'dest': 'b', 'src': 'a'}, None)
    parser = ModuleArgsParser(task_ds=data)
    result = parser.parse()
    assert_equal(result, expected_result)

    data = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    expected_result = ('copy', {'dest': 'b', 'src': 'a'}, None)

# Generated at 2022-06-11 08:49:15.914486
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = parser_cls.parse(skip_action_validation=True)
    assert args == ('shell',
                    {'_raw_params': 'echo hi', 'creates': '/tmp/ansible', 'removes': '/tmp/ansible'},
                    None)

# test_ModuleArgsParser_parse()



# Generated at 2022-06-11 08:49:20.177582
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test = dict(action=dict(module="test" , args="value"))
    task_ds = ModuleArgsParser(task_ds=test, collection_list=None)
    result = task_ds.parse()
    assert result== ('test', {'args': 'value'}, Sentinel)


# Generated at 2022-06-11 08:49:36.786965
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    for action, kwarg in (
            ('shell', 'command'),
            ('command', 'cmd'),
            ('debug', 'msg'),
            ('pause', 'message'),
            ('wait_for', 'msg'),
            ('fail', 'msg'),
            ('unarchive', 'src'),
            ('assert', 'msg'),
            ('wait_for_connection', 'msg'),
            ('set_fact', '_raw_params'),
            ('deprecate', 'msg'),
    ):
        yield check_parse, action, kwarg


# Generated at 2022-06-11 08:49:47.057232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'setup'
    collection_name = 'community.general'
    collection = collections.AnsibleCollection(name=collection_name, version='1.0')
    collection_manager = collections.AnsibleCollectionManager()
    collection_manager._collections = {collection_name: collection}

    class FakeLoader():
        def get(self, name):
            fqcn = '{}.{}'.format(collection_name, module_name)
            if name == fqcn:
                return MagicMock()

    fake_loader = FakeLoader()
    module_loader.add_collection_plugin(fake_loader, collection)

    # test legacy form
    legacy_form = dict(action=dict(module=module_name))

# Generated at 2022-06-11 08:49:54.080544
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = dict(
        action='halite',
        delegate_to='localhost',
        args=dict(module_args='salt=halite'),
        not_an_attribute='nope'
    )
    parser = ModuleArgsParser(module_args)
    action, args, delegate_to = parser.parse()
    assert action == 'halite'
    assert args == dict(module_args='salt=halite')
    assert delegate_to == 'localhost'



# Generated at 2022-06-11 08:50:02.808000
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleUnicode
    task_ds = AnsibleUnicode(b"{u'action': u'copy src=a dest=b'}")
    collection_list = ImmutableDict(module_loader.module_finder.module_utils_finder.all())
    obj = ModuleArgsParser(task_ds, collection_list)
    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)
    obj._normalize_new_style_args = MagicMock(return_value={'src': 'a', 'dest': 'b'})
    assert obj.parse() == expected
    obj._normalize_new_

# Generated at 2022-06-11 08:50:11.116821
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    task_ds = {'delegate_to': 'localhost',
               'action': 'copy src=a dest=b',
               'args': {'_raw_params': 'echo hi'}}
    collection_list = []
    module_parser = ModuleArgsParser(task_ds, collection_list)
    action = 'copy'
    args = {'_raw_params': 'echo hi', 'src': 'a', 'dest': 'b'}
    delegate_to = 'localhost'
    assert module_parser.parse() == (action, args, delegate_to)


# Generated at 2022-06-11 08:50:13.896322
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # call test function and check result with expected result

    # check that the method raises the desired exceptions
    pass


# Generated at 2022-06-11 08:50:24.453052
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Test cases for method parse of class ModuleArgsParser"""
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.plugins.loader
    task_ds_test1 = {'action': 'shell echo hi', 'local_action': 'copy: src=a dest=b', 'delegate_to': 'localhost', 'args': 'shell echo hi', '_variable_params': '{{ var }}'}

# Generated at 2022-06-11 08:50:28.003830
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create object instance of class ModuleArgsParser for testing
    parser = ModuleArgsParser(task_ds={'action': 'copy',
                                       'local_action': 'shell',
                                       'args': {'arg_dict': 'test'}})
    # Test method parse of class ModuleArgsParser
    assert parser.parse() == ('copy', {'arg_dict': 'test'}, None)

# Generated at 2022-06-11 08:50:36.743335
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy', 'name': 'foo', 'src': 'abc', 'dest': '/etc/xyz/'}
    (action, args, delegate_to) = ModuleArgsParser(task_ds).parse()
    assert action == 'copy'
    assert args == {'name': 'foo', 'src': 'abc', 'dest': '/etc/xyz/'}
    assert delegate_to is None

    task_ds = {'module': 'copy', 'name': 'foo', 'src': 'abc', 'dest': 'def'}
    (action, args, delegate_to) = ModuleArgsParser(task_ds).parse()
    assert action == 'copy'
    assert args == {'name': 'foo', 'src': 'abc', 'dest': 'def'}
    assert delegate_to is None

   

# Generated at 2022-06-11 08:50:45.404300
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest

    ModArgsParseObj = ModuleArgsParser(collection_list=['test_collection'])
    # raw_params used to have ansible prefix, but now uses _ansible_ internally
    assert ModArgsParseObj.parse({'action': {'module': 'shell', '_ansible_foo': 'a', '_ansible_bar': 'b'}}) == ('shell', {'_ansible_foo': 'a', '_ansible_bar': 'b'}, None)
    assert ModArgsParseObj.parse({'action': 'shell'}) == ('shell', {}, None)
    assert ModArgsParseObj.parse({'action': {'shell': 'echo hi'}}) == ('shell', {}, None)

# Generated at 2022-06-11 08:51:00.585085
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
# end of test_ModuleArgsParser_parse()



# Generated at 2022-06-11 08:51:05.411056
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create object
    collection_list = []
    m = ModuleArgsParser(task_ds={'ping': 'pong'}, collection_list=collection_list)
    (action, args, delegate_to) = m.parse()
    assert action == 'ping'
    assert args == {'pong': None}
    assert delegate_to == Sentinel



# Generated at 2022-06-11 08:51:15.738880
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from yaml.constructor import ConstructorError

    try:
        import yaml
    except ImportError:
        # TODO: add pyyaml to requirements.txt and balsam's deps
        pass

    # TODO: this will be hard to unit test, as it needs to know about playbooks/tasks, etc.
    # instead, add integration tests which use the playbook.  Currently playbook uses this
    # so there are currently integration tests for this

    # test parsing using a valid yaml syntax

# Generated at 2022-06-11 08:51:22.937522
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser(dict(action=dict(module='name', args='value')))
    assert p.parse() == ('name', {'args': 'value'}, None)

    p = ModuleArgsParser(dict(action="name arg1=1 arg2=2"))
    assert p.parse() == ('name', {'arg1': '1', 'arg2': '2'}, None)

    p = ModuleArgsParser(dict(local_action=dict(module='name', args='value')))
    assert p.parse() == ('name', {'args': 'value'}, 'localhost')

    p = ModuleArgsParser(dict(local_action="name arg1=1 arg2=2"))
    assert p.parse() == ('name', {'arg1': '1', 'arg2': '2'}, 'localhost')


# Generated at 2022-06-11 08:51:24.515344
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tested_object = ModuleArgsParser()
    assert tested_object is not None


# Generated at 2022-06-11 08:51:34.341024
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:51:40.105243
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method parse of class ModuleArgsParser
    """
    # data
    task_ds = {}

    # action
    a = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    a.parse()


# Class used to represent a plugin name (plugin_name) and its
# parameters (param_args)

# Generated at 2022-06-11 08:51:44.429379
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    loader_test = None # This is a latent argument; will be set elsewhere
    m_test = ModuleArgsParser(loader_test)

    loader_test = None
    skip_action_validation_test = True
    m_test.parse(skip_action_validation_test)



# Generated at 2022-06-11 08:51:55.393219
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'shell': 'echo hi'}
    additional_args = {'dest': '/tmp/hi'}
    collection_list = [
        {'action': {'module': 'command', 'args': 'echo hi'}},
        {'action': {'name': 'echo', 'args': 'echo hi'}}
    ]
    with patch('ansible.plugins.action.ActionModule') as action_mock:
        action_mock.get_instance.return_value = 'command'
        module_include = ModuleArgsParser(task_ds, collection_list)
        assert (module_include.parse() == ('command',
                                           {'_raw_params': 'echo hi',
                                            'dest': '/tmp/hi'}))
        assert module_include.resolved_action == 'command'


# Generated at 2022-06-11 08:52:05.564668
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    ModuleArgsParser.parse
    """
    module_args_parser = ModuleArgsParser()

    # NOTE: not sure if this test case is valid anymore, the _normalize_parameters method
    # seems to have changed quite a bit.

    # In some cases, we want to test against specific code branches. The below code
    # demonstrates how to do so.

    # /////////////////////////////////////////////////////////////////////
    # branch 1 TEST CASE
    # This branch is executed if the following conditions are all true:
    #     1. What were the conditions?
    # /////////////////////////////////////////////////////////////////////
    # module_args_parser = ModuleArgsParser()
    # ds = {
    #     'action': 'copy src=/etc/hosts dest=/tmp',
    #     'delegate_to': 'localhost',
    #     'register': 'my_copy_results'

# Generated at 2022-06-11 08:52:28.075150
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialization of test data
    task = dict()
    task['action'] = dict()
    task['action']['module'] = 'shell'
    task['action']['args'] = 'cat /tmp/test.txt'
    parser = ModuleArgsParser(task_ds=task)
    result = parser.parse()
    assert result == ('shell', dict(), Sentinel)
    del parser
    del task

    task = dict()
    task['action'] = 'shell cat /tmp/test.txt'
    parser = ModuleArgsParser(task_ds=task)
    result = parser.parse()
    assert result == ('shell', dict(), Sentinel)
    del parser
    del task
    
    task = dict()
    task['action'] = 'sleep 1'
    task['register'] = 'out'

    parser = ModuleArgsParser

# Generated at 2022-06-11 08:52:36.114665
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class MockActionLoader(ActionBase):
        def __init__(self, collection_list):
            self.collection_list = collection_list

        def get_plugin(self, name):
            return None

        def find_plugin_with_context(self, name, collection_list=None):
            return None

    class mock_context(object):
        resolved = None
        resolved_fqcn = None

    class MockModuleLoader(object):
        def find_plugin_with_context(self, name, collection_list=None):
            module_loader.find_plugin_with_context(name, collection_list)

    monkeypatch.setattr(ansible.utils.plugin_docs, 'ActionBase', MockActionLoader)
    monkeypatch.setattr(ansible.utils.plugin_docs, 'module_loader', MockModuleLoader)

   

# Generated at 2022-06-11 08:52:46.028387
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager()

    parser = ModuleArgsParser({'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': 'localhost'}, None)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')


# Generated at 2022-06-11 08:52:48.506617
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = []
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert parser
    # TODO: implement test
    pass

# Generated at 2022-06-11 08:52:55.543705
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_cases = dict()

    task_ds = dict(
        local_action = dict(module = 'shell', _raw_params = 'echo hi'),
    )
    expected_result = (('shell', dict(_raw_params = 'echo hi'), 'localhost'))

    test_cases[1] = dict(task_ds = task_ds,
                         expected_result = expected_result,
                         )

    task_ds = dict(
        local_action = dict(module = 'shell', _raw_params = 'echo hi'),
        delegate_to = 'localhost',
    )
    expected_result = (('shell', dict(_raw_params = 'echo hi'), 'localhost'))

    test_cases[2] = dict(task_ds = task_ds,
                         expected_result = expected_result,
                         )

    task_ds

# Generated at 2022-06-11 08:53:03.250838
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:53:11.875948
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    import sys
    import random


# Generated at 2022-06-11 08:53:13.127512
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    c = ModuleArgsParser()
    assert c is not None


# Generated at 2022-06-11 08:53:22.670380
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleMapping

    d = dict()
    d["action"] = "copy src=a dest=b"
    d["local_action"] = "copy src=a dest=b"
    d["module"] = "copy src=a dest=b"
    d["args"] = {"foo": "bar"}
    d["with_items"] = ["a", "b"]

    u = dict()
    u["action"] = {"module": "copy src=a dest=b"}
    u["local_action"] = "copy src=a dest=b"
    u["args"] = {"foo": "bar"}
    u["delegate_to"] = "x"

    n = dict()

# Generated at 2022-06-11 08:53:24.749814
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(dict())
    module_args_parser.parse()