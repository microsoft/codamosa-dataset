

# Generated at 2022-06-11 08:43:55.242236
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser({'delegate_to': 'localhost', 'action': 'shell', '_raw_params': 'pwd'})
    assert m.parse() == ('shell', {'_uses_shell': True}, 'localhost')
    assert m.resolved_action is None
    m = ModuleArgsParser({'delegate_to': 'localhost', 'local_action': 'shell pwd'})
    assert m.parse() == ('shell', {'_raw_params': 'pwd', '_uses_shell': True}, 'localhost')
    assert m.resolved_action is None
    m = ModuleArgsParser({'delegate_to': 'localhost', 'copy': 'src=a dest=b'})
    assert m.parse() == ('copy', {'dest': 'b', 'src': 'a'}, 'localhost')

# Generated at 2022-06-11 08:43:59.004600
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():dict1 = dict(action="shell")
err1 = None
ret1 = None
try:
    ret1 = parse(dict1)
except Exception as e:
    err1 = e
assert(err1 == None)
assert(ret1 == None)


# Generated at 2022-06-11 08:44:09.269332
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case: when keys
    # expected_result:
    assert ModuleArgsParser().parse(skip_action_validation=True) == (None, None, -7)

    # test case: when keys
    # expected_result:
    assert ModuleArgsParser().parse(skip_action_validation=False) == (None, None, -7)

    # test case: when keys
    # expected_result:
    assert ModuleArgsParser(task_ds={'action': '', 'args': '', 'delegate_to': '', 'local_action': '', 'static': ''}).parse() == ('', {}, -7)

    # test case: when keys
    # expected_result:

# Generated at 2022-06-11 08:44:18.054238
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    d = {
      "name": "Hostname is {{ hostname }}",
      "action": "debug msg=\"Hostname is {{ hostname }}\"",
      "args": {"msg": "Hostname is {{ hostname }}"},
      "delegate_to": "localhost",
      "local_action": "debug msg=\"Hostname is {{ hostname }}\"",
      "register": "hostname"
    }
    parser = ModuleArgsParser(task_ds=d, collection_list=None)
    assert parser.parse() == ('debug', {'msg': 'Hostname is {{ hostname }}'}, 'localhost')

# Test class ModuleArgsParser

# Generated at 2022-06-11 08:44:24.079945
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    res = ModuleArgsParser({'action': 'geoip_facts', 'args': {'query': 'me', 'exclude_paths': ['geoip.dat']}}).parse()
    assert res[0] == 'geoip_facts'
    assert res[1] == {'exclude_paths': ['geoip.dat'], '_raw_params': 'query=me', 'query': 'me'}
    assert res[2] is None


# Generated at 2022-06-11 08:44:34.840808
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def assert_parse(ds, action, args, delegate_to=None, additional_args=None):
        additional_args = {} if additional_args is None else additional_args
        actual = ModuleArgsParser(ds, collection_list=[]).parse()
        assert_that(actual[0], equal_to(action))
        assert_that(actual[1], equal_to(args))
        assert_that(actual[2], equal_to(delegate_to))

    assert_parse({'action': {'module': 'foo', 'x': '1', 'y': '2'}},
                 'foo',
                 {'x': '1', 'y': '2'})

# Generated at 2022-06-11 08:44:37.772979
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    collection_list = list()
    task_ds = dict()
    map_ = ModuleArgsParser(collection_list = collection_list, task_ds = task_ds)
    action, args, delegate_to = map_.parse()

# Generated at 2022-06-11 08:44:47.938900
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.plugins.action
    action_loader.add_directory(ansible.plugins.action.__path__[0])
    ds = dict(ec2=dict(x=1, y=2), delegate_to='foo')
    the_object = ModuleArgsParser(ds, None)
    the_object.parse()
    assert the_object._task_ds['ec2'].keys() == dict(x=1, y=2).keys()
    ds = dict(action=dict(module='ec2', x=1, y=2), delegate_to='foo')
    the_object = ModuleArgsParser(ds, None)
    the_object.parse()
    assert the_object._task_ds['action'].keys() == dict

# Generated at 2022-06-11 08:44:57.711944
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    
    # Create the ModuleArgsParser and Task objects
    TaskObj = Task()
    MapObj = ModuleArgsParser(task_ds=TaskObj)

    # Assert that the TaskObject is empty
    assert not TaskObj
    
    # Test the ModuleArgsParser with the below inputs
    for case in TestModuleArgsParser_parse.testcases:
        try:
            (action, args, delegate_to) = MapObj.parse(skip_action_validation=case['skip_action_validation'])
            assert action == case['action']
            assert args == case['args']
            assert delegate_to == case['delegate_to']
        except (AssertionError, AnsibleParserError) as myerror:
            if case['expect'] != "success":
                # Should get an exception and it is expected
                continue

# Generated at 2022-06-11 08:45:07.202677
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = { 'ping': 'pong' }
    ds = {'name': 'test', 'args': args.copy(), 'action': 'ping', 'local_action': 'ping'}
    # should be able to use either 'action' or 'local_action'
    for a in ('action', 'local_action'):

        # check that the 'thing' key is set correctly
        for k, v in iteritems(args):
            ds[a][k] = v
            (parsed_action, parsed_args, parsed_delegate_to) = ModuleArgsParser(ds).parse()
            assert v == parsed_args[k]
            del ds[a][k]

        # check that the 'thing' key is set correctly, even if it has a space
        for k, v in iteritems(args):
            d

# Generated at 2022-06-11 08:45:20.109684
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Instantiate an instance of ModuleArgsParser class
    module_args_parser = ModuleArgsParser(task_ds={'action': 'ec2',
                                                   'region': 'us-east-1',
                                                   'key_name': 'mykey'})
    module_args_parser.parse()
    #test_ModuleArgsParser_parse run from class AnsibleParser
    #test_ModuleArgsParser_parse executed successfully for class AnsibleParser


# Generated at 2022-06-11 08:45:30.393397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # To-Do: Fill this with some meaningful tests and remove the
    # skip and xfail
    from ansiblelint.ansible_linter import MockModule, MockLintConfig

    # pylint: disable=protected-access
    module_parser = ModuleArgsParser()

    ds = {'name': '1',
          'action': 'ping'}
    assert module_parser.parse(ds) == ('ping', {}, Sentinel)

    ds = {'name': '1',
          'delegate_to': 'localhost',
          'action': 'ping'}
    assert module_parser.parse(ds) == ('ping', {}, 'localhost')


# Generated at 2022-06-11 08:45:39.367322
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'myaction', 'tags': 'test_tags', 'ignore_errors': False, 'async': 'test_async', 'poll': 'test_poll'}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=['ansible.builtin'])
    action, args, delegate_to = parser.parse()
    if action != 'myaction' or args != {'_raw_params': 'myaction'} or  delegate_to != None:
        raise AssertionError('Failed to parse the module action properly')

    task_ds = {'action': 'shell echo hi', 'tags': 'test_tags', 'ignore_errors': False, 'async': 'test_async', 'poll': 'test_poll'}

# Generated at 2022-06-11 08:45:42.192170
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    dict_in = dict()
    dict_expected = dict()
    parser = ModuleArgsParser()
    out = parser.parse(dict_in)
    assert out == dict_expected, out
    pass


# Generated at 2022-06-11 08:45:52.872602
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    # Instantiate an object of class Task
    test_task = Task()

    # Test the case "action and local_action are mutually exclusive"
    parser = ModuleArgsParser({'action': 'shell', 'local_action': 'shell1'})
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test the case "conflicting action statements: <action>,<item>"
    parser = ModuleArgsParser({'action': 'shell', 'module1': 'shell1'})
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test the case "no module/action detected in task "
    parser = ModuleArgsParser({'action1': 'shell'})

# Generated at 2022-06-11 08:45:56.805123
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_dp = ModuleArgsParser()
    task_ds = {}
    collection_list = None
    assert module_dp.parse(task_ds=task_ds,collection_list=collection_list) == (None, {}, Sentinel)
# End of function test_ModuleArgsParser_parse


# Generated at 2022-06-11 08:46:01.453205
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    action_plugin = ActionBase()
    cls = getattr(sys.modules[__name__], 'ModuleArgsParser')
    module_parser = cls()
    args = {u'name': u'test', u'path': u'test'}
    module_parser.parse()

# Generated at 2022-06-11 08:46:10.128816
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Verify initializing ModuleArgsParser class with empty task_ds raises an exception
    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser()
    assert "the type of 'task_ds' should be a dict, but is a" in str(excinfo.value)
    # Verify initializing ModuleArgsParser class with task_ds in wrong type raises an exception
    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds="test")
    assert "the type of 'task_ds' should be a dict, but is a" in str(excinfo.value)

    # Verify initializing ModuleArgsParser class with correct args and values
    parser = ModuleArgsParser(task_ds={'action': 'shell', 'args': 'echo hello'})

# Generated at 2022-06-11 08:46:18.720193
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.vars import merge_hash
    # this one breaks, because it's missing a delegate_to
    d = dict(
        local_action=dict(
            module=dict(
                name="foo",
                args=dict(
                    a=1,
                    b=2,
                )
            )
        )
    )
    with pytest.raises(AnsibleParserError):
        assert ModuleArgsParser(task_ds=d, collection_list=list()).parse()

    # Fix it
    d["delegate_to"] = "localhost"
    action, args, delegate_to = ModuleArgsParser(task_ds=d, collection_list=list()).parse()
    assert action == 'foo'
    assert args == dict(a=1, b=2)

# Generated at 2022-06-11 08:46:25.421470
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # GIVEN
    task_ds = {}
    collection_list = None
    m = ModuleArgsParser(task_ds, collection_list)

    # WHEN
    # m.parse()

    # THEN
    assert True

#####################################################################################
import contextlib
from ansible.plugins.loader import action_loader
from ansible.errors import AnsibleError
from ansible.playbook.play_context import PlayContext
from ansible.playbook.task_include import TaskInclude
from ansible.template import Templar
from ansible.utils.collection_loader import get_collection_mount_point



# Generated at 2022-06-11 08:46:44.938099
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a raw module name
    task_ds = dict(name="some module", action="shell")
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ("shell", {}, None)

    # Test with old style action/args
    task_ds = dict(name="some module", action="shell echo hi")
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ("shell", {"args": "echo hi"}, None)

    # Test with old style action/args containing vars
    task_ds = dict(name="some module", action="shell {{some_var}}")
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ("shell", {"_variable_params": "{{some_var}}"}, None)

    # Test with old style action/args containing kw

# Generated at 2022-06-11 08:46:49.608770
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser()
    try:
        args_parser.parse()
    except AnsibleAssertionError as e:
        if "the type of 'task_ds' should be a dict" in to_text(e):
            assert True
        else:
            assert False
    else:
        assert False



# Generated at 2022-06-11 08:46:53.619046
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'name': 'test', 'tags': ['tag'], 'action': 'copy', 'args': {'a': '1', 'b': '2'}}

    parser = ModuleArgsParser(task_ds)
    res = parser.parse()

    assert res == ('copy', {'a': '1', 'b': '2'}, None)

# Generated at 2022-06-11 08:47:02.723882
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        # Test with wrong type for task_ds
        parser = ModuleArgsParser(task_ds = [])
        parser.parse()
    assert 'the type of \'task_ds\' should be a dict, but is a <class \'list\'>' in to_text(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        # Test with complex args containing variables and bare variable
        parser = ModuleArgsParser(task_ds = { 'action': { 'service': 'tomcat state={{ tomcat_state }}', 'name': '{{ service }}' } })
        parser.parse()

# Generated at 2022-06-11 08:47:06.482641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = [ "ansible_collections.ansible.builtin" ]
    obj = ModuleArgsParser(task_ds=task_ds,
                           collection_list=collection_list)

    with pytest.raises(AnsibleError):
        obj.parse()

#####

# Generated at 2022-06-11 08:47:14.771412
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'local_action': u'', u'static': u'all', u'action': u'', u'tags': [u'foo', u'bar', u'baz']}
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    _ = obj.parse()
    try:
        thing = None
        obj._normalize_old_style_args(thing)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
        assert e.obj == task_ds
        assert e.data == {}
        assert e.obj == task_ds
        assert e.task_ds == task_ds
        assert u'no module/action detected in task.' in str(e)
    except Exception as e:
        assert False

    task

# Generated at 2022-06-11 08:47:23.938513
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_bytes, to_text

    task_ds = {'action': 'copy content="{{ var }}" dest=/tmp/test'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'content': '{{ var }}', 'dest': '/tmp/test'}, None)

    task_ds = {'action': 'copy src=/tmp/src dest=/tmp/dest mode=0644'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': '/tmp/src', 'dest': '/tmp/dest', 'mode': '0644'}, None)

   

# Generated at 2022-06-11 08:47:34.250218
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ##
    # Prepare test env
    #
    # load a test playbook
    p = load_fixture_playbook('task_tests.yml')
    # load a task from the playbook
    t = load_fixture_task('task_tests.yml', 'test_action')
    # get the 'module args' to test
    task_ds = t._attributes

    action = None
    additional_args = None
    thing = None
    skip_action_validation = False

    ##
    # Test normalize_parameters()
    #
    # use module args to construct a ModuleArgsParser object
    m = ModuleArgsParser(task_ds, collection_list=None)
    # test normalize_parameters

# Generated at 2022-06-11 08:47:44.681586
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:47:51.582862
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    yaml_simple = '''
- copy:
    src: a
    dest: b
- name: foo
  shell: echo hi
'''
    yaml_dict = '''
- name: foo
  shell:
    x: 1
    y: 2
'''
    yaml_fuzzy = '''
- action: shell echo hi
- local_action: command echo hi
- ping:
'''
    yaml_not_a_task = '''
- name: foo
  something:
'''


# Generated at 2022-06-11 08:48:11.128844
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #task_ds = {'with_items': [1, 2], 'args': {'_raw_params': 'echo hi', 'a': 1, 'b': 2, '_uses_shell': True}, 'when': 'a == b', 'name': 'Testing taking args as a dictionary'}
    task_ds = {'with_items': [1, 2], 'args': {'_raw_params': 'echo hi'}, 'when': 'a == b', 'name': 'Testing taking args as a dictionary'}
    mapr = ModuleArgsParser(task_ds, collection_list=[])
    assert mapr._task_ds == task_ds
    assert mapr._collection_list is None
    assert mapr._task_attrs is None
    assert mapr.resolved_action is None
    action, args, delegate_to = mapr

# Generated at 2022-06-11 08:48:20.113688
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action='copy', _raw_params='src=test.txt dest=new.txt', with_dict=None, with_items=None, with_first_item=None, with_sequence=None, with_subelements=None, with_together=None, with_home=None, with_nested=None)
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == dict(src='test.txt', dest='new.txt')
    assert delegate_to is sentinel


# Generated at 2022-06-11 08:48:30.704994
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {'action': 'shell echo "hi"'}
    collection_list = []

    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    result = module_args_parser.parse()

    assert result == ('shell', {'_raw_params': 'echo "hi"'}, None)
    assert module_args_parser.resolved_action == 'ansible.builtin.shell'

    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    result = module_args_parser.parse()
    assert result == (None, None, None)
    assert module_args_parser.resolved_action is None


# Generated at 2022-06-11 08:48:32.902287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    instance = ModuleArgsParser()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 08:48:43.120521
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser(None, None)
    task_ds = {
        'module': 'test1',
        'args': {'arg1': 'test2' }
    }
    skip_validation = True
    result = mp.parse(skip_validation)
    assert result[0] == 'test1'
    assert result[1]['arg1'] == 'test2'

    task_ds = {
        'module': 'test1',
        'args': 'arg1=test2'
    }
    result = mp.parse(skip_validation)
    assert result[0] == 'test1'
    assert result[1]['arg1'] == 'test2'

    task_ds = {
        'module': { 'module': 'test1', 'arg1': 'test2' }
    }


# Generated at 2022-06-11 08:48:52.526356
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Search module 'copy' with loader
    loader = DataLoader()
    paths = ':'.join(C.DEFAULT_MODULE_PATH)
    collection_list = None
    my_collection_list = ['/usr/local/lib/python3.6/site-packages/ansible']
    collection_loader = CollectionLoader()
    collection_resolver = CollectionRequirementResolver(collection_loader=collection_loader)
    action_loader = ActionLoader(collection_requirement_resolver=collection_resolver)
    # Test ModuleArgsParser with simple task
    task_ds = {'action': 'echo hi',
               'delegate_to': 'localhost',
               'args': {'some_args': 'abc'}}

# Generated at 2022-06-11 08:49:04.426306
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Creation of a YAML input
    task_ds = {
        "name": "test module args parser module 1",
        "action": "test module args parser module",
    }
    # init ModuleArgsParser
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    # parse
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'test module args parser module'
    assert args == {}
    assert delegate_to is None


# Creation of a YAML input
task_ds = {
    "name": "test module args parser module 2",
    "action": {
        "module": "test module args parser module",
        "arg1": "arg1 test",
        "arg2": "arg2 test",
    },
}
# check of the method

# Generated at 2022-06-11 08:49:12.493315
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # prepare the test context
    test_context = dict()
    # prepare the expected result
    expected_result = dict()

    # about testcase 1:
    # when there's no module,
    # case 1.1: action is null and there's local_action
    # case 1.2: action is null and there's nothing
    # In both cases, the error will be raised.
    current_test_case_name = "case 1.1: action is null and there's local_action"
    new_task_ds = dict()
    new_task_ds['local_action'] = "shell echo 'hello'"
    new_task_ds['delegate_to'] = 'localhost'
    test_context['task_ds'] = new_task_ds
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser

# Generated at 2022-06-11 08:49:22.794655
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # setup test environment
    # construct what we expect to get back from the call(s)
    expected_action = 'setup'
    expected_delegate_to = None
    expected_args = {'all_facts': True}
    expected_rval = (expected_action, expected_args, expected_delegate_to)
    
    test_ds = {'action': 'setup', 'args': {'all_facts': True}}
    test_ModuleArgsParser = ModuleArgsParser(task_ds=test_ds)
    print(test_ModuleArgsParser._task_attrs)
    assert test_ModuleArgsParser._task_attrs == set(Task._valid_attrs.keys()) | set(Handler._valid_attrs.keys())

# Generated at 2022-06-11 08:49:32.599716
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import unittest
    import ansible.plugins.loader as loader_module
    from ansible.config.manager import ConfigManager

    class TestModuleArgsParser(unittest.TestCase):
        def setUp(self):
            self.config_manager = ConfigManager()
            self.config_manager.initialize()
            loader_module.set_collection_paths([self.config_manager.get_config_value('DEFAULT', 'roles_path')])
            self.task_ds = dict()
            self.map = ModuleArgsParser(task_ds=self.task_ds,
                                        collection_list=None)

        def tearDown(self):
            pass

        def test_parse(self):
            task_ds = dict()
            collection_list = None

# Generated at 2022-06-11 08:49:45.730389
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Unit test case body
    pass

# Generated at 2022-06-11 08:49:54.604725
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(
        task_ds={
            'action': 'base64 encode',
            'local_action': 'base64 decode',
            'delegate_to': '',
            'args': {'in_file': 'my_file', 'out_file': 'my_file_b64'},
            'register': 'the_b64'
        },
        collection_list=[]
    )
    assert m.parse() == ('base64',
                         {'in_file': 'my_file', 'out_file': 'my_file_b64', '_raw_params': 'encode'},
                         'localhost')


# Generated at 2022-06-11 08:50:03.255983
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={})
    assert parser.parse() == (None, dict(), Sentinel)

    parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    parser.resolved_action = 'action'
    assert parser.parse() == ('action', {'src': 'a', 'dest': 'b'}, Sentinel)

    parser = ModuleArgsParser(task_ds={'action': {'module': 'copy src=a dest=b'}})
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    parser = ModuleArgsParser(task_ds={'action': {'module': 'copy src=a dest=b', 'x': 1}})

# Generated at 2022-06-11 08:50:12.958988
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Both dict and args are null
    ap = AnsibleModuleArgumentSpec()
    parser = ModuleArgsParser(dict(), None)
    action, args, delegate_to = parser.parse(True)
    assert action is None
    assert args == {}
    assert delegate_to == Sentinel

    # Valid dict and args
    ap = AnsibleModuleArgumentSpec()
    parser = ModuleArgsParser(dict(), None)
    action, args, delegate_to = parser.parse(True)
    assert action is None
    assert args == {}
    assert delegate_to == Sentinel

    # Invalid dict and args
    dict_ = dict()
    dict_['action1'] = dict()
    dict_['action1']['module'] = "test"
    dict_['action2'] = dict()

# Generated at 2022-06-11 08:50:18.444357
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Read yaml file
    with open('parse_data.yml', 'r') as stream:
        data_loaded = yaml.safe_load(stream)

    # Run test
    parser = ModuleArgsParser()
    result = parser.parse(**data_loaded['test_args'])

    assert result == data_loaded['expected']
    print('Module parse_data.yml test passed')




# Generated at 2022-06-11 08:50:27.633660
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # args:
    # An Ansible dict to parse.
    test_dict = dict(action="copy", src="a", dest="b")
    # skip_action_validation:
    # Whether we should skip action validation.
    # Needs to be False

    mp = ModuleArgsParser(test_dict)
    res = mp.parse()
    assert res == ("copy", dict(src="a", dest="b"), None)

    # args:
    # An Ansible dict to parse.
    test_dict = dict(action="copy", src="a", dest="b")
    # skip_action_validation:
    # Whether we should skip action validation.
    # Needs to be True

    mp = ModuleArgsParser(test_dict)
    res = mp.parse(skip_action_validation=True)

# Generated at 2022-06-11 08:50:36.392065
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # simple test case
    parser = ModuleArgsParser(task_ds={
        'action': 'copy src=/etc/a dest=/etc/b mode=foo'
    })
    action, args, delegate_to = parser.parse()
    assert_equal(action, "copy")
    assert_equal(delegate_to, None)
    assert_equal(args["src"], "/etc/a")
    assert_equal(args["dest"], "/etc/b")
    assert_equal(args["mode"], "foo")


    # Test with more complex arguments that can be passed.

# Generated at 2022-06-11 08:50:44.805708
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(
        action = dict(shell = "echo hi"),
        with_items = '1 2 3'),
    additional_args = dict(
        chdir = '/tmp')
    obj = ModuleArgsParser(task, collection_list = ['*'])
    action, args, delegate_to = obj.parse(skip_action_validation = True)
    assert action == 'shell'
    assert args['_raw_params'] == 'echo hi'
    assert args['chdir'] == '/tmp'
    assert delegate_to == Sentinel

    task = dict(
        action = 'echo',
        local_action = 'echo hi',
        with_items = '1 2 3'),
    additional_args = dict(
        chdir = '/tmp')
    obj = ModuleArgsParser(task, collection_list = ['*'])
    action

# Generated at 2022-06-11 08:50:46.225384
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  pass


# pylint: disable=too-many-locals

# Generated at 2022-06-11 08:50:55.128174
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:51:15.650558
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # Class data
    #
    # Legacy form:
    # - action: copy src=a dest=b
    # Normal form:
    # - copy: src=a dest=b
    # Complex
    # - copy:
    #     src: a
    #     dest: b
    # Gross:
    # - action:
    #     module: copy
    #     args:
    #       src: a
    #       dest: b
    # Standard YAML form
    # - command: 'pwd'
    #   args:
    #     chdir: '/tmp'
    #
    #
    #
    # Legacy form - action: copy src=a dest=b
    #
    task_ds = {
        'action': 'copy src=a dest="b c" d=e',
    }

# Generated at 2022-06-11 08:51:22.851906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    fake_verbosity = 0
    fake_inventory = object()
    fake_variable_manager = object()
    fake_loader = object()
    fake_task_vars = dict()
    fake_task_name = 'fake_task_name'

    fake_action = 'fake_action'
    fake_module_name = 'fake_module_name'
    fake_module_name_resolved = 'fake_module_name_resolved'
    fake_module_args = dict()
    fake_task_ds = dict(action=dict(module=fake_module_name, args=fake_module_args))

    expected_result = dict(action=fake_module_name, args=fake_module_args)

    fake_play_context = object()
    fake_play_context.verbosity = fake_verbosity

    fake_

# Generated at 2022-06-11 08:51:32.183439
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    cls = ModuleArgsParser()
    # need raw arg
    cls.set_loader(DictDataLoader({}))

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    result = cls.parse(task_ds=task_ds, skip_action_validation=True)
    assert result == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'local_action': 'shell echo hi'}
    result = cls.parse(task_ds=task_ds, skip_action_validation=True)
    assert result == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'local_action': {'module': 'shell', 'args': 'echo hi'}}


# Generated at 2022-06-11 08:51:43.205113
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # stub out
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'library'))

    def _test(task_ds, collection_list=None, expected_action=None, expected_args=None, expected_delegate_to=None):
        actual_action, actual_args, actual_delegate_to = ModuleArgsParser(task_ds, collection_list).parse()

        # fixup things to look the same
        if not isinstance(expected_args, dict):
            expected_args = dict()

        if not isinstance(actual_args, dict):
            actual_args = dict()

        # compare
        assert expected_action == actual_action
        assert expected_args == actual_args


# Generated at 2022-06-11 08:51:54.128683
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    global action_loader
    # setup globals
    fake_loader = DictDataLoader({
        "mod.yml": """---
        doc: |
          A test module that doesn't do anything
        author: Ansible Core Team
        requirements:
          - Ansible modules should fit this format
        options:
          key1:
            required: no
            default: ""
            aliases: []
            type: str
            description: a string value
    """
    })

# Generated at 2022-06-11 08:52:04.028277
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import json
    import uuid

    tmpfile = tempfile.NamedTemporaryFile(mode='w')
    test_value = str(uuid.uuid4())
    msg = '{"password": "%s"}' % test_value
    tmpfile.write(msg)
    tmpfile.flush()
    vault_secret = VaultSecret(None, None, test_value)
    vault = VaultLib([tmpfile.name])
    vault.secrets.append(vault_secret)

# Generated at 2022-06-11 08:52:14.450342
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def create_instance(task_ds, collection_list):
        return ModuleArgsParser(task_ds, collection_list)

    parser = create_instance(None, None)
    action, args, delegate_to = parser.parse()

    assert action is None
    assert args == {}
    assert delegate_to is sentinel

    # case 1: set all args
    task_ds = {
        'local_action': 'shell echo hi',
        'delegate_to': 'xx'
    }
    parser = create_instance(task_ds, None)
    action, args, delegate_to = parser.parse()

    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'xx'

    # case 2: only set local_action

# Generated at 2022-06-11 08:52:25.515180
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test `parse`
    fake_task_ds = {'action': 'shell echo hey', 'delegate_to': 'xyz', 'args': {'xyz': 123}}
    x = ModuleArgsParser(task_ds=fake_task_ds)
    assert x.parse() == ('shell', {'echo hey'}, 'xyz')

    fake_task_ds = {'action': 'shell echo hey', 'local_action': 'shell echo hey'}
    x = ModuleArgsParser(task_ds=fake_task_ds)
    assert x.parse() == ('shell', {'echo hey'}, 'localhost')

    fake_task_ds = {'local_action': 'shell echo hey'}
    x = ModuleArgsParser(task_ds=fake_task_ds)

# Generated at 2022-06-11 08:52:33.643855
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action is None
    assert args == dict()
    assert delegate_to is None

    task_ds = dict(action=dict())
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action is None
    assert args == dict()
    assert delegate_to is None

    task_ds = dict(action="ping")
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == "ping"
    assert args == dict()
    assert delegate_to is None

    task_ds = dict(action="ping with_foo=bar")
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()

# Generated at 2022-06-11 08:52:34.716018
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass # TODO: write tests for ModuleArgsParser


# Generated at 2022-06-11 08:53:25.677629
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    args = dict(x='1', y='2')
    delegate_to = 'abc'
    task_ds = dict(action=action, args=args, delegate_to=delegate_to)
    task_ds_instance = ModuleArgsParser(task_ds)
    assert task_ds_instance.parse() == (action, args, delegate_to)

# Generated at 2022-06-11 08:53:28.442712
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds=None, collection_list=None)
    assert False # TODO: implement your test here
