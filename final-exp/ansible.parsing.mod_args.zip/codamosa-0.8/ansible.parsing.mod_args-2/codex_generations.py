

# Generated at 2022-06-11 08:44:01.753636
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'module': 'collectd_conf', 'config': '/etc/collectd/collectd.conf'}}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    print(action)
    print(args)
    print(delegate_to)

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:44:12.459481
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    arguments = {"role_to_be_run": "path_to_role"}
    ansible_playbook = "path_to_playbook.yml"
    arguments["ansible_playbook"] = ansible_playbook
    arguments["task"] = "task_to_be_run"
    arguments["name"] = "run_role"
    arguments["dir_roles_default"] = "path_to_roles"
    playbook_path = "/etc/ansible/playbooks"
    arguments["playbook_path"] = playbook_path
    arguments["role_path"] = "/etc/ansible/roles"

# Generated at 2022-06-11 08:44:22.710627
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.parsing.convert_bool import boolean
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    with pytest.raises(AnsibleParserError) as execinfo:
        module_args_parser.parse(skip_action_validation=False)
    assert "no module/action detected in task." in str(execinfo.value)
    task_ds = {"a": "b"}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

# Generated at 2022-06-11 08:44:33.334417
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from ansible.inventory.host import Host
  from ansible.vars.manager import VariableManager

  host = Host("127.0.0.1", port=2222)
  variable_manager = VariableManager()

  task_ds = {
    "include_tasks": {
        "name": "dummy.yaml"
    }
  }
  collection_list = []
  module_arg_parser = ModuleArgsParser(task_ds, collection_list)

  action, args, delegate_to = module_arg_parser.parse(skip_action_validation=False)
  
  assert action == 'include_tasks'
  assert args == {"name": "dummy.yaml"}
  assert delegate_to == None

  task_ds = {"include_tasks": "dummy.yaml"}

  module_arg

# Generated at 2022-06-11 08:44:44.158475
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tm = Task()
    m = ModuleArgsParser(tm, collection_list=None)
    assert m.parse(skip_action_validation=False) == (None, {}, Sentinel)
    tm.action='ping'
    m = ModuleArgsParser(tm)
    assert m.parse(skip_action_validation=False) == ('ping', {}, Sentinel)
    tm.action={'module':'ping'}
    assert m.parse(skip_action_validation=False) == ('ping', {}, Sentinel)
    tm.action={'module':'ping', 'foo':'bar'}
    assert m.parse(skip_action_validation=False) == ('ping', {'foo': 'bar'}, Sentinel)

# Generated at 2022-06-11 08:44:50.892676
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('--- test_ModuleArgsParser_parse')
    # first, the old-style 'action' invocation
    task_ds = dict(action='mymodule x=1')
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'mymodule'
    assert args == dict(x=1)
    assert delegate_to is Sentinel
    # new style invocation
    task_ds = dict(funnymodule='xyz=3')
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'funnymodule'
    assert args == dict(xyz=3)
    assert delegate_to is Sentinel
    # new style with args

# Generated at 2022-06-11 08:45:00.321428
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()

    # test_parse_1
    task_ds = { 'action': 'test action={{test_var}}', 'args': 'test arg={{test_val}}'}
    res = m.parse(task_ds)
    assert res == ('test', {'action': '{{test_var}}', 'arg': '{{test_val}}'}, None)

    # test_parse_2
    task_ds = {'action': 'test action={{test_var}}'}
    res = m.parse(task_ds)
    assert res == ('test', {'action': '{{test_var}}'}, None)

    # test_parse_3
    task_ds = { 'action': 'test', 'args': 'test arg={{test_val}}'}

# Generated at 2022-06-11 08:45:04.172557
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"name": "Test Task", "remote_user": "root"}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()


# Generated at 2022-06-11 08:45:12.253707
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:21.154519
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task

    # case 1
    task_ds = dict()
    expected_action = None
    expected_args = dict()
    expected_delegate_to = None
    collection_list = None

    m = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    actual_action, actual_args, actual_delegate_to = m.parse()

    assert actual_action == expected_action, "Actual: %s, Expected: %s" % (actual_action, expected_action)
    assert actual_args == expected_args, "Actual: %s, Expected: %s" % (actual_args, expected_args)
    assert actual_delegate_to == expected_delegate_to, "Actual: %s, Expected: %s"

# Generated at 2022-06-11 08:45:49.893583
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action = dict(
            module = 'shell', 
            args = 'echo hi'
        ), 
        delegate_to = 'localhost'
    )
    collection_list = []

    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is Sentinel


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-11 08:45:55.644242
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    expected = None
    actual = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list).parse()
    assert expected == actual

    task_ds = {}
    collection_list = None
    expected = (None, {}, Sentinel)
    actual = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list).parse()
    assert expected == actual

# Generated at 2022-06-11 08:46:04.491707
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    assert ModuleArgsParser(task_ds, collection_list).parse() == (None, {}, None)

    task_ds = {'a': 1}
    collection_list = None
    assert ModuleArgsParser(task_ds, collection_list).parse() == (None, {}, None)

    task_ds = {'a': [1]}
    collection_list = None
    assert ModuleArgsParser(task_ds, collection_list).parse() == (None, {}, None)

    task_ds = {'a': ['a',1]}
    collection_list = None
    assert ModuleArgsParser(task_ds, collection_list).parse() == (None, {}, None)

    task_ds = {'a': ['a',1,3]}
    collection_list = None


# Generated at 2022-06-11 08:46:13.329490
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'action': u'module: name=test value={{lookup(foo, bar)}}', u'tags': [u'test']}
    result = ModuleArgsParser(task_ds, None).parse()
    assert result[0] == u'module'
    assert result[1] == {u'name': u'test value={{lookup(foo, bar)}}'}
    assert result[2] is None
    task_ds = {u'local_action': u'module: name=test value={{lookup(foo, bar)}}', u'tags': [u'test']}
    result = ModuleArgsParser(task_ds, None).parse()
    assert result[0] == u'module'

# Generated at 2022-06-11 08:46:21.208408
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Example task_ds
    task_ds = {"action": {'lookup': 'lookup_test', 'terms': [1, 2], 'default': '3'}}
    module_args_parser = ModuleArgsParser(task_ds)

    (action, args, delegate_to) = module_args_parser.parse()

    # assert action == action_name
    assert action == 'lookup'

    # assert args == expected_args
    expected_args = {'default': '3', 'terms': [1, 2]}
    assert args == expected_args

    # assert delegate_to == expected_delegate_to
    expected_delegate_to = None
    assert delegate_to == expected_delegate_to


# Generated at 2022-06-11 08:46:25.283219
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    expected = (u'copy', {'src': 'a', 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds)

    actual = parser.parse()

    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)



# Generated at 2022-06-11 08:46:27.732827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser({'module': 'mymodule'}).parse()
    assert result == ('mymodule', {}, None), "Parse result: %s" % result

# Generated at 2022-06-11 08:46:28.579530
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "No test"

# Generated at 2022-06-11 08:46:37.703276
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader

    # example test data
    task_ds = {
        'action': 'copy src={{testvar}} dest={{testvar2}}',
        'args': {'test1': 'arg1', 'test3': 'arg3'},
        'delegate_to': 'localhost',
        'with_items': '{{testvar}}'
    }

    # create an instance of the class under test
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    (action, args, delegate_to) = module_args_parser.parse()

    assert action == 'copy'
    assert args['src'] == '{{testvar}}'
    assert args['dest'] == '{{testvar2}}'

# Generated at 2022-06-11 08:46:47.167378
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser({
          'shell': '/usr/bin/whoami',
          'with_items': [
            'foo',
            'bar',
            'baz'
          ]
        })
    assert parser.parse() == ('shell', {'_raw_params': '/usr/bin/whoami',
                                        '_uses_shell': True},
                                        Sentinel)

    parser = ModuleArgsParser({
          'shell': '/usr/bin/whoami',
          'with_items': [
            'foo',
            'bar',
            'baz'
          ]
        })
    assert parser.parse(skip_action_validation=True) == ('shell', {'_raw_params': '/usr/bin/whoami',
                                                                   '_uses_shell': True},
                                                                   Sentinel)



# Generated at 2022-06-11 08:47:10.870823
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement this test
    pass # tested in test_parser.py

# Generated at 2022-06-11 08:47:20.278275
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    example_task_ds = {
        'no_block': True, 'no_log': False, 'remote_user': None, 'remote_uid': None,
        'register': None, 'become': False, 'become_method': None, 'become_user': None, 'environment': None,
        'any_errors_fatal': False, 'serial': 1, 'changed_when': True, 'failed_when': False, 'always_run': True,
        'poll': 0, 'until': None, 'retries': 0, 'delay': 0, 'first_available_file': None, 'when': True,
        'tags': [], 'run_once': False}

    ds_parser = ModuleArgsParser()
    action, args, delegate_to = ds_parser.parse(example_task_ds)
    assert action

# Generated at 2022-06-11 08:47:27.940797
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = {
        'action': 'copy',
        'delegate_to': 'localhost',
        'args': {'dest': 'roles/test1/files', 'src': 'files'},
        'name': 'Copy Directory',
        'register': 'destdir'
    }

    parser = ModuleArgsParser(task_ds=data)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'dest': 'roles/test1/files', 'src': 'files'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-11 08:47:33.623045
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # given
    task_ds = {'action': {'module': 'foo', 'arg1': 'baz'}}
    module_args_parser = ModuleArgsParser(task_ds)

    # when
    action, args, delegate_to = module_args_parser.parse()

    # then
    assert action == 'foo'
    assert args == {'arg1': 'baz'}
    assert delegate_to == None


# Generated at 2022-06-11 08:47:37.342383
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = dict(
        action='command',
        delegate_to='all',
        args=dict()
    )
    ModuleArgsParser(task_ds=module_args, collection_list=None)

# END class ModuleArgsParser



# Generated at 2022-06-11 08:47:47.198370
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(None, None)
    try:
        module_args_parser._split_module_string('echo hshshsh')
    except AnsibleParserError:
        assert False
    except:
        assert True
    # test _split_module_string() class instance
    try:
        module_args_parser._split_module_string('echo hshshsh')
    except AnsibleParserError:
        assert False
    except:
        assert True
    # test _split_module_string() class instance
    try:
        module_args_parser._split_module_string('echo hi')
    except AnsibleParserError:
        assert False
    except:
        assert True
    # test _normalize_parameters() class instance

# Generated at 2022-06-11 08:47:52.984658
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    loader = DictDataLoader({
        'data/test.yml': """
        - hosts: all
          tasks:
          - name: task 1
            action: copy chdir=no src=a dest=b
        """
    })

    collection_list = mock_collections(loader)

    def get_tasks(play):
        play_ds, play_basedir = play._ds[0], play._basedir
        tqm = DummyTaskQueueManager(
            inventory=play.get_inventory(loader),
            variable_manager=play.get_variable_manager(loader),
            loader=loader,
            options=Options(),
            passwords=None,
        )

# Generated at 2022-06-11 08:48:02.740175
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'test_module_name'
    task_param_dict = {
        module_name: 'test_module_param'
    }
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(task_param_dict)
    assert action == module_name
    assert args == {'_raw_params': 'test_module_param'}
    assert delegate_to == 'localhost'

    module_name = 'test'
    task_param_dict = {
        'action': module_name
    }
    action, args, delegate_to = module_args_parser.parse(task_param_dict)
    assert action == module_name
    assert args == {'_raw_params': ''}
    assert delegate_to == 'localhost'



# Generated at 2022-06-11 08:48:11.917662
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(
        task_ds={'shell': 'ls -al'},
        collection_list=None)

    assert (('shell', {'_raw_params': 'ls -al'}, None) ==
            module_args_parser.parse())

    module_args_parser = ModuleArgsParser(
        task_ds={'shell': 'ls -al', 'name': 'user'},
        collection_list=None)

    assert (('shell', {'_raw_params': 'ls -al', 'name': 'user'}, None) ==
            module_args_parser.parse())

    module_args_parser = ModuleArgsParser(
        task_ds={'shell': 'ls -al', 'args': {'name': 'user'}},
        collection_list=None)


# Generated at 2022-06-11 08:48:22.640615
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    kwargs = {}
    kwargs['task_ds'] = {'action': 'copy src=a dest=b'}
    m = ModuleArgsParser(**kwargs)
    assert m.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    kwargs['task_ds'] = {'action': 'shell echo hi', 'delegate_to': 'foo'}
    m = ModuleArgsParser(**kwargs)
    assert m.parse() == ('shell', {'_raw_params': 'echo hi'}, 'foo')
    kwargs['task_ds'] = {'module': 'shell echo hi', 'delegate_to': 'foo'}
    m = ModuleArgsParser(**kwargs)

# Generated at 2022-06-11 08:48:56.297856
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # ModuleArgsParser.parse(self, skip_action_validation=False)
    # TODO: fix this test
    pass

if __name__ == '__main__':
    # Unit test for class ModuleArgsParser
    # TODO: fix this test
    pass

# Generated at 2022-06-11 08:49:07.530808
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook import task_include
    from ansible.playbook.play_context import PlayContext

    task_ds = dict(action=dict(module='shell', args='ls -al'))
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == dict(args='ls -al')
    assert delegate_to == None

    task_ds = dict(action=dict(module='shell', args=dict(stdin='ls -al')))
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = module_args_parser.parse()

# Generated at 2022-06-11 08:49:09.251087
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(None, None)
    module_args_parser.parse()



# Generated at 2022-06-11 08:49:17.751563
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            delegate_to='localhost',
            module='test_module',
            a=1,
            b=2
        )
    )
    args_parser = ModuleArgsParser(task_ds)
    assert args_parser.parse() == ('test_module', dict(a=1, b=2), 'localhost')

    # test with skip_action_validation
    args_parser = ModuleArgsParser(task_ds, skip_action_validation=True)
    assert args_parser.parse() == ('test_module', dict(a=1, b=2), 'localhost')

    # test with delegate_to

# Generated at 2022-06-11 08:49:28.656400
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method ModuleArgsParser.parse of class ModuleArgsParser
    '''

    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    for cls in (Handler, RoleInclude, Task):
        s = '''copy: src=a dest=b'''
        t = cls.load(s)
        parser = ModuleArgsParser(task_ds=t._attributes, collection_list=None)
        result = parser.parse()
        assert result == ('copy', {'dest': 'b', 'src': 'a'}, None)

        s = '''action: echo hi'''
        t = cls.load(s)

# Generated at 2022-06-11 08:49:37.739056
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {"with_dict": {"name": "world"}, "module": "shell", "_raw_params": "echo hello {{name}}"}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    print(action, args, delegate_to)
    assert isinstance(action, str)
    assert isinstance(args, dict)

    task_ds = {"with_dict": {"name": "world"}, "local_action": "shell", "_raw_params": "echo hello {{name}}"}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert isinstance(action, str)
    assert isinstance(args, dict)


# Generated at 2022-06-11 08:49:47.836615
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    sample_ds = {
        'action': 'shell echo "Hello"',
        'local_action': {'module': 'shell', 'args': 'echo "Hello"'},
        'delegate_to': '{{ hostvars[inventory_hostname].ansible_host }}',
        'loop_control': {'loop_var': 'item'}
    }
   

# Generated at 2022-06-11 08:49:58.401112
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    module_loader.add_directory(t.TEST_DIR)
    context = module_loader.find_plugin_with_context('raw', collection_list=['my_collection'])
    assert context.resolved_fqcn == 'my_collection.tasks.raw'
    assert context.resolved 


# Generated at 2022-06-11 08:50:05.333425
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {u'become': False, u'become_user': None, u'changed': False, u'connection': u'local', u'delegate_to': None, u'free_form': u'echo "Home testing 123"', u'gather_facts': u'yes', u'name': u'Home'}
    obj = ModuleArgsParser(ds, collection_list=[])
    (action, args, delegate_to) = obj.parse()
    assert action == "shell"
    assert args == {'_raw_params': u'echo "Home testing 123"'}
    assert delegate_to is None



# Generated at 2022-06-11 08:50:14.891086
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if
    if 0:
        pass

    # FIXME: tests should be added for all three branches of the following if

# Generated at 2022-06-11 08:51:38.350367
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method ModuleArgsParser.parse
    '''
    obj_ModuleArgsParser = ModuleArgsParser(task_ds=dict())
    assert False, "No test written for ModuleArgsParser.parse yet"
# end class ModuleArgsParser


# Generated at 2022-06-11 08:51:43.652017
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mapper = Mapper()
    ds = mapper.compile({
        'a': {
            'b': '{{ var }}'
        },
        'c': '{{ var_2 }}'
    })

    module_args_parser = ModuleArgsParser(task_ds=ds)
    module_args_parser.parse()

    assert module_args_parser.resolved_action is None


# Generated at 2022-06-11 08:51:49.852711
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task_ds = {'action': 'shell', 'args': {'executable': '/bin/sh', '_raw_params': 'ansible -m ping localhost'}}
    assert parser.parse(task_ds=task_ds, skip_action_validation=True) == ('shell', {'executable': '/bin/sh', '_raw_params': 'ansible -m ping localhost'}, None)



# Generated at 2022-06-11 08:51:53.184543
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser()
    (action, args, delegate_to) = p.parse(skip_action_validation=True)
    # TODO: add unit test here
    assert False


# Generated at 2022-06-11 08:52:03.064937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import json
    import ansible.plugins.loader
    # Fetching all the collections installed in the system
    collection_list = [x for x in os.listdir(ansible.plugins.loader._find_collections_paths()) if not x.startswith(".")]
    # Test - module: copy src=a dest=b
    task_ds = {'action': 'copy src=a dest=b'}
    x = ModuleArgsParser(task_ds, collection_list)
    assert x.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    # Test - module: copy src=a dest=b
    task_ds = {'action': 'command echo hi', 'args': 'chdir=/tmp'}

# Generated at 2022-06-11 08:52:13.432405
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test a dictionary input
    module_args_parser = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test a string input
    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy: src=a dest=b'})
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test the local_action input
    module_args_parser = ModuleArgsParser(task_ds={'local_action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})

# Generated at 2022-06-11 08:52:24.608090
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(
        action='copy',
        src='x',
        dest='y')
    args = dict()
    delegate_to = None
    results = ModuleArgsParser(task).parse()
    assert results == (action, args, delegate_to)

    task = dict(
        ec2=dict(
            x=1)
    )
    results = ModuleArgsParser(task).parse()
    assert results == ('ec2', dict(x=1), None)

    task = dict(
        action='ec2',
        x=1
    )
    results = ModuleArgsParser(task).parse()
    assert results == ('ec2', dict(x=1), None)

    task = dict(
        action='ec2',
        delegate_to='localhost'
    )
    results = ModuleArgsParser(task).parse()

# Generated at 2022-06-11 08:52:32.420923
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    taskds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost'}
    collection_list = {
        'tests/ansible_collections/openstack/os_server': 'tests/ansible_collections/openstack/os_server/plugins/modules'}
    args_parser = ModuleArgsParser(task_ds=taskds, collection_list=collection_list)
    action, args, delegate_to = args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'
    return True


# Generated at 2022-06-11 08:52:38.184557
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # the following code is used for unit test ModleArgsParser.parse method
    test_task = dict(
        module = "copy",
        src = "./",
        dest = "/tmp/",
        local_action = "copy",
        args = "src=./ dest=/tmp/",
        delegate_to = 10.0,
        some_other_arg = "foo"
    )
    # the instance's _task_ds is set to test_task
    p = ModuleArgsParser(task_ds=test_task)
    # parse the task using method parse
    r = p.parse()
    # assert if the method return is as expected
    assert r == ('copy', {'src': './', 'dest': '/tmp/'}, 'localhost')
    # assert if the module name is parsed correctly
    assert p.resolved_action

# Generated at 2022-06-11 08:52:47.399091
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    monkeypatch.setattr(AnsibleLoader, 'resolve_aliases', mock.MagicMock(return_value='mock_resolve_aliases'))
    task_ds = dict()
    collection_list = list()
    obj = ModuleArgsParser(task_ds, collection_list)
    # monkeypatch.setattr(obj, '_split_module_string', mock.MagicMock(return_value=('mock_args', 'mock_string')))
    # monkeypatch.setattr(obj, '_normalize_parameters', mock.MagicMock(return_value=('mock_action', 'mock_args')))
    # monkeypatch.setattr(obj, '_normalize_new_style_args', mock.MagicMock(return_value='mock_args'))
    # monkeypatch.