

# Generated at 2022-06-11 08:44:07.317006
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = 'echo hi'
    action = 'shell'
    task_ds = {'action': module_args}
    x = ModuleArgsParser(task_ds)
    expected_result = (action, 'echo hi', None)
    received_result = x.parse()

    assert  received_result == expected_result


# Generated at 2022-06-11 08:44:18.154842
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    os.environ['ANSIBLE_ROLES_PATH'] = '../'


# Generated at 2022-06-11 08:44:28.447761
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {}

    # New style invocation
    # form like:  action: { module: 'copy', src: 'a', dest: 'b' }
    task_ds = {'action': {'module': 'shell echo hi'}}
    m = ModuleArgsParser(task_ds)
    assert m.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    # form like:  action: copy src=a dest=b
    task_ds = {'action': 'shell echo hi'}
    m = ModuleArgsParser(task_ds)
    assert m.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    task_ds = {'action': 'command ls -a'}

# Generated at 2022-06-11 08:44:38.765745
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a = dict(
        action = 'test',
        args = dict(
            action = 'test',
            module = 'test',
            local_action = 'test',
            delegate_to = 'test',
            delegate_facts = 'test: else',
            X = dict(
                action = 'test',
                module = 'test',
                local_action = 'test',
                delegate_to = 'test',
                delegate_facts = 'test: else',
            )
        )
    )
    b = ModuleArgsParser(a)
    c = b.parse()
    assert c[0] == 'test', 'Action is not set correctly'
    assert c[2] == 'test', 'Delegate is not set correctly'

# Generated at 2022-06-11 08:44:48.546855
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    try:
        results = parser.parse()
        assert False
    except:
        assert True

    # action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    results = parser.parse()
    assert results[0] == 'echo'
    assert results[1] == {'_raw_params': 'hi'}
    assert results[2] is None

    # shell is a RAW_PARAM_MODULES, so _raw_params can be in args
    task_ds = {'action': 'shell echo hi'}


# Generated at 2022-06-11 08:44:58.206602
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test no task_ds
    task_ds=None
    collection_list=None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert str(module_args_parser.parse()) == "(None, {}, None)"
    del module_args_parser
    # test with arrays
    task_ds={'name': 'add something', 'args': ['1','2']}
    collection_list=['ansible.builtin','ansible.bultin.math']
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert str(module_args_parser.parse()) == "('add', {'args': ['1', '2']}, None)"
    del module_args_parser
    # test with boolean

# Generated at 2022-06-11 08:45:07.740774
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert AnsibleModuleArgSpec.parse({}) == (None, {}, None)
    assert AnsibleModuleArgSpec.parse({'action': 'echo hi'}) == ('echo', {'_raw_params': 'hi'}, None)
    assert AnsibleModuleArgSpec.parse({'local_action': 'echo hi'}) == ('echo', {'_raw_params': 'hi'}, 'localhost')
    assert AnsibleModuleArgSpec.parse({'module': 'echo', 'arg1': 'hi'}) == ('echo', {'arg1': 'hi'}, None)
    assert AnsibleModuleArgSpec.parse({'module': 'echo arg1=hi'}) == ('echo', {'arg1': 'hi'}, None)

# Generated at 2022-06-11 08:45:15.886362
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:17.946095
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser({}).parse() == (None,{},None), "Invalid parse() result in test_ModuleArgsParser_parse"

# Generated at 2022-06-11 08:45:28.059519
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.utils.module_docs as module_docs
    from ansible.plugins.action import ActionBase

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.module_utils.six import PY3

    @unittest.skipIf(PY3, "Python 2 only")
    def test_module_docs(parser):
        """
            Class AnsibleModuleDocsTestCase
        """
        # Lookup ansible modules
        self.modules = module_loader.all(class_only=True)
        self.modules = dict([(x.__name__, x) for x in self.modules])

        # ensure that lookup modules are skipped

# Generated at 2022-06-11 08:45:44.790742
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "action": {
            "module": "ping",
            "name": "localhost"
        }
    }

    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_args_parser.parse()

    assert action == 'ping'
    assert args['name'] == 'localhost'
    assert delegate_to is Sentinel

# Generated at 2022-06-11 08:45:51.074827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  ds = {"action": {"module": "users", "name": "foo", "password": "no",
                   "state": "present"},
        "delegate_to": "localhost",
        "with_dict": "users_foo"}
  parser = ModuleArgsParser(ds)
  result = parser.parse()
  assert_equal(result, ("action",
                        {"module": "users", "name": "foo", "password": "no",
                         "state": "present"},
                        "localhost"))


# Generated at 2022-06-11 08:46:00.794024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    params = {
        'delegate_to': 'localhost',
        'action': 'shell echo hi',
    }
    result = module_args_parser.parse(params)
    assert result == ('shell', {}, 'localhost')

    params = {
        'delegate_to': 'localhost',
        'local_action': 'shell echo hi',
    }
    result = module_args_parser.parse(params)
    assert result == ('shell', {}, 'localhost')

    params = {
        'delegate_to': 'localhost',
        'local_action': 'copy src=a dest=b',
    }
    result = module_args_parser.parse(params)
    assert result == ('copy', {'dest': 'b', 'src': 'a'}, 'localhost')

# Generated at 2022-06-11 08:46:09.143516
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_ds = {'name': 'test', 'action': {'module': 'ec2', 'x': 1}}
    task_ds = {} if task_ds is None else task_ds
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'ec2'
    assert args['x'] == 1
    assert delegate_to == Sentinel

# Generated at 2022-06-11 08:46:17.780213
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible import context
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils._text import to_text

    module_loader.add_directory(data_context().content.collection_path)


# Generated at 2022-06-11 08:46:26.701172
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:46:35.322992
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	from ansible.playbook.play_context import PlayContext
	from ansible.template import Templar
	from ansible.vars.unsafe_proxy import AnsibleUnsafeText
	from ansible.vars.manager import VariableManager

	my_play_context = PlayContext()
	my_play_context.become = False
	my_play_context.become_method = None
	my_play_context.become_user = None
	my_play_context.prompt = None
	my_play_context.remote_user = "root"
	my_play_context.password = None
	my_play_context.port = None
	my_play_context.connection = "ssh"
	my_play_context.timeout = 10

	my_var_manager = VariableManager()

	my_templar = Templar

# Generated at 2022-06-11 08:46:44.781715
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser().parse(task_ds=dict(action='copy src=a dest=b')) == ('copy', dict(src='a', dest='b'), None)
    assert ModuleArgsParser().parse(task_ds=dict(action='copy: src=a dest=b')) == ('copy', dict(src='a', dest='b'), None)
    assert ModuleArgsParser().parse(task_ds=dict(action=dict(module='copy src=a dest=b'))) == ('copy', dict(src='a', dest='b'), None)
    assert ModuleArgsParser().parse(task_ds=dict(action=dict(module='copy'))) == ('copy', dict(), None)
    assert ModuleArgsParser().parse(task_ds=dict(action='shell echo hi')) == ('shell', dict(positional='echo hi'), None)


# Generated at 2022-06-11 08:46:54.331511
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test if we can pass in a non-dict
    task_ds = None
    parser = ModuleArgsParser(task_ds)
    try:
        parser.parse()
    except AnsibleAssertionError:
        pass
    else:
        assert False, "AnsibleAssertionError not raised"

    # Test if we can have conflicting action and local_action
    task_ds = dict(action="foo", local_action="bar")
    parser = ModuleArgsParser(task_ds)
    try:
        parser.parse()
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised"
    # Test if we can have action and local_action
    task_ds = dict(action="foo", local_action="bar", delegate_to="localhost")
    parser = Module

# Generated at 2022-06-11 08:46:54.883389
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	pass

# Generated at 2022-06-11 08:47:11.502734
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:47:12.623499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser().parse() == None

# Generated at 2022-06-11 08:47:21.906905
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'file', 'dest': '/tmp/foo', 'mode': '0644'}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'file'
    assert args == {'dest': '/tmp/foo', 'mode': '0644'}
    assert delegate_to == None

    task_ds = {'local_action': 'file', 'dest': '/tmp/foo', 'mode': '0644'}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'file'
    assert args == {'dest': '/tmp/foo', 'mode': '0644'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-11 08:47:32.069344
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(
        task_ds={'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost', 'become': False, 'become_user': 'root', 'become_method': 'sudo', '_ansible_check_mode': True, '_ansible_no_log': False, '_ansible_verbosity': 0, '_ansible_diff': True, '_ansible_socket': '/var/tmp/ansible.socket', '_ansible_selinux_special_fs': True, '_ansible_diff_peek': False},
        collection_list=['ansible.builtin']
    )


# Generated at 2022-06-11 08:47:42.829544
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # IMPORTANT: the test dicts must be ordered dicts, so that the
    # ansible-playbook invocation below is deterministic.

    # We're going to test taking a bunch of dictionaries, each
    # representing a task, and ensure that they all get normalized
    # to the same thing ...

    # use a simple task to make sure the basics work out
    task_ds = OrderedDict(
        action=dict(
            module=dict(
                name='shell',
                args='echo hi',
            ),
            delegate_to='{{inventory_hostname}}',
        ),
    )

    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = parser.parse()

    assert action == 'shell'

# Generated at 2022-06-11 08:47:50.533912
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    We don't do a full mutation test here, because it's nearly the same code
    which is tested with the modules. We do take a quick look at different
    argument styles and make sure they get parsed properly.
    '''

    # Just test the code path for positional args, should be "echo" and "hi"
    test_arg1 = ArgSpec(args=dict(
        _raw_params='echo hi'
    ))
    test_arg2 = ArgSpec(args=dict(
        _raw_params='echo "hi"',
        _uses_shell=True
    ))

    # This is what we expect when we give a single value to a module
    test_arg3 = ArgSpec(args=dict(
        message='hi'
    ))

    # This is the new-style with some arguments.
    test_arg4

# Generated at 2022-06-11 08:47:57.685248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ansible_task_json_obj = """{
        "action": "ping",
        "kwargs": {
            "foo": "bar"
        },
        "loop_control": {},
        "register": "test",
        "when": "test"
    }"""
    parser = ModuleArgsParser()
    (action, args, delegate_to) = parser.parse(skip_action_validation=False)
    assert action == "ping"
    assert args == {"foo": "bar"}
    assert delegate_to is None



# Generated at 2022-06-11 08:48:07.188798
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:48:17.238265
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class MockModule(object):
        pass

    class Args(object):
        pass

    module = MockModule()
    module.argument_spec = dict()
    module.argument_spec['something'] = dict()
    module.argument_spec['something']['default'] = 42

    args = Args()
    args.something = 1

    # ActionModule uses ``argument_spec`` to build a parser. It returns an
    # object with an ``option_strings`` member that contains a ``--`` entry.
    # It does not contain optional arguments.
    parser = ActionModule(module, task_vars=dict(), args=args).build_parser()
    assert '--' in parser.option_strings
    assert 'something' not in parser.option_strings

    # raw_params

# Generated at 2022-06-11 08:48:23.146556
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    parser = ModuleArgsParser(task_ds={})
    action, args, delegate_to = parser.parse()
    assert action == 'ping'
    assert args == {}
    assert delegate_to == 'default'
    # After
    assert action == 'ping'
    assert args == {}
    assert delegate_to == 'default'


# Generated at 2022-06-11 08:48:44.567360
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=None)

    # test normalize_old_style_args
    (action, args) = parser._normalize_old_style_args(thing="shell echo hi")
    assert action == "shell" and args == {u'_raw_params': u'echo hi'}
    (action, args) = parser._normalize_old_style_args(thing={'shell' : 'echo hi'})
    assert action == "shell" and args == {u'_raw_params': u'echo hi'}
    (action, args) = parser._normalize_old_style_args(thing={'module': 'ec2', 'x': 1})
    assert action == "ec2" and args == {u'x': 1}

# Generated at 2022-06-11 08:48:48.660088
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task_ds = {}
    playbook = MagicMock()
    playbook.host_list = []
    res = parser.parse(task_ds,playbook)
    if res[0] != None:
        raise AssertionError("parse(task_ds) return None, but should return '{0}'".format(type(None)))
    task_ds1 = {'action': None,}
    res = parser.parse(task_ds1,playbook)
    if res[0] != None:
        raise AssertionError("parse(task_ds1) return None, but should return '{0}'".format(type(None)))
    task_ds2 = {'action': '',}
    res = parser.parse(task_ds2,playbook)

# Generated at 2022-06-11 08:48:53.903157
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(
        action='a',
        delegate_to='b',
    )

    parser = ModuleArgsParser(args)
    (action, args, delegate_to) = parser.parse()

    assert action == 'a'
    assert args == {}
    assert delegate_to == 'b'
    print("test_ModuleArgsParser_parse OK")



# Generated at 2022-06-11 08:49:05.528437
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test with action specified
    module_args = dict(action='my_action')
    map = ModuleArgsParser(task_ds=module_args)
    action, args, delegate_to = map.parse()
    assert action == 'my_action'
    assert args == dict()

    # Test with action specified but with args
    module_args = dict(action='my_action some_arg=some_value')
    map = ModuleArgsParser(task_ds=module_args)
    action, args, delegate_to = map.parse()
    assert action == 'my_action'
    assert args == dict(some_arg='some_value')

    # Test with local_action specified
    module_args = dict(local_action='my_action')
    map = ModuleArgsParser(task_ds=module_args)
    action, args

# Generated at 2022-06-11 08:49:13.044168
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    class MyTaskInclude(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(MyTaskInclude, self).__init__(block=block, role=role, task_include=task_include)
            self._role_name = 'test_role'
            self._parent_role = None
            self._task = None
            self._dependency = None
            self._parent_block = None
            self._depth = 0
            self._all_blocks = []
            self._notify_handler_task = None
            self._role_params = {}
            self._task_vars = {}


# Generated at 2022-06-11 08:49:23.524715
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:49:26.040320
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    load_fixture('test_ModuleArgsParser_parse')



# ===========================================
# Parser that deals with 'tags' attribute
# ===========================================

# Generated at 2022-06-11 08:49:28.966864
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:49:34.026392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ###
    # Test method parse with args (action, args, delegate_to) of class ModuleArgsParser
    ###

    module_args_parser = ModuleArgsParser()

    with pytest.raises(AnsibleError):
        module_args_parser.parse()

    with pytest.raises(AnsibleError):
        module_args_parser.parse(dict())



# Generated at 2022-06-11 08:49:40.309086
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = {
      'action': 'ping',
      'delegate_to': '{{my_delegate}}',
      'register': 'my_result',
      'with_items': '{{my_items}}'}
  result = ModuleArgsParser(task_ds).parse()
  assert result == (
      'ping', {
        '_raw_params': '',
        '_uses_shell': False
      },
      '{{my_delegate}}')

  task_ds = {
      'module': 'copy src=a dest=b',
      'delegate_to': '{{my_delegate}}',
      'register': 'my_result',
      'with_items': '{{my_items}}'}
  result = ModuleArgsParser(task_ds).parse()

# Generated at 2022-06-11 08:50:07.848431
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-11 08:50:17.602364
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.collections import ImmutableDict
    path_name_ds = ImmutableDict(path='/path/to/file', name='file')
    path_name_ds_specific_files = ImmutableDict(path='/path/to/file', name='file', specific_files=['a'])
    specific_files = ImmutableDict(specific_files=['a'])
    src = ImmutableDict(src='/path/to/file', dest='/path/to/dest')
    src_specific_files = ImmutableDict(src='/path/to/file', dest='/path/to/dest', specific_files=['a'])
    dest = ImmutableDict(dest='/path/to/dest')

# Generated at 2022-06-11 08:50:26.954977
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # simple case
    result = module_args_parser.parse(task_ds={'module': 'shell', 'args': {'_raw_params': 'echo hi'}})
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)

    # simple case
    result = module_args_parser.parse(task_ds={'action': 'shell echo hi'})
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)

    # simple case
    result = module_args_parser.parse(task_ds={'action': {'module': 'shell', 'args': '_raw_params=echo hi'}})
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)

    # simple

# Generated at 2022-06-11 08:50:35.642334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for parse
    '''
    task_ds = {'max_fail_percentage': None, 'name': 'Run ps', 'delegate_to': None, 'action': 'command ps',
               'no_log': False, 'changed_when': 'False', 'when': 'True', 'async': 0, 'poll': 0, 'until': None,
               'register': 'shell_out', 'ignore_errors': True, 'tags': ['always'], 'run_once': True}

    parser = ModuleArgsParser(task_ds, None)
    action, args, delegate_to = parser.parse()

    assert action == 'command'
    args_dict = {}
    args_dict['_uses_shell'] = True
    args_dict['warn'] = True
    args_dict['executable'] = None

# Generated at 2022-06-11 08:50:38.389611
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleAssertionError):
        parser.parse()


# Generated at 2022-06-11 08:50:47.251541
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text
    from ansible.collection import convert_collection_to_ansible_collections
    from ansible.collections.ansible.community.plugins.module_utils import _common_tests
    from ansible.plugins.loader import action_loader, module_loader
    module_loader.all_plugin_classes = []
    action_loader.all_plugin_classes = []
    module_loader.get_all_plugin_loaders()
    action_loader.get_all_plugin_loaders()
    collection_list = ['']

# Generated at 2022-06-11 08:50:54.819199
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    This function is the unit test for parse()
    '''
    #import lib_args_parser
    from lib_args_parser import ModuleArgsParser
    t = dict(action=dict(shell='echo hi'), delegate_to='test_delegate_to', other_val=True)
    p = ModuleArgsParser(task_ds=t)
    (e1, e2, e3) = ('shell', {'_raw_params': 'echo hi'}, 'test_delegate_to')
    (a1, a2, a3) = p.parse()
    assert (a1, a2, a3) == (e1, e2, e3)

# Generated at 2022-06-11 08:50:59.397889
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_collection = 'ansible_collections.not.a.real.collection'
    kwargs = {'task_ds':{}, 'collection_list':[module_collection]}
    module_args_parser = ModuleArgsParser(**kwargs)
    assert module_args_parser.parse() == (None,{}, Sentinel)


# Generated at 2022-06-11 08:51:09.594310
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'set_fact',
               'name': 'test_name',
               'value': 'test_value'}

    args_parser = ModuleArgsParser(task_ds=task_ds)
    result = args_parser.parse()
    assert result == ('set_fact', {'value': 'test_value', 'name': 'test_name'}, None), result

    task_ds = {'action': 'set_fact',
               'args': {'name': 'test_name',
                        'value': 'test_value'}}

    args_parser = ModuleArgsParser(task_ds=task_ds)
    result = args_parser.parse()
    assert result == ('set_fact', {'name': 'test_name', 'value': 'test_value'}, None), result


# Generated at 2022-06-11 08:51:12.310321
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse('') == (None, None, None)

# Generated at 2022-06-11 08:51:35.299979
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser().parse()



# Generated at 2022-06-11 08:51:44.920925
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_1 = {
        'name': 'test task',
        'action': 'ping'
    }

    action, args, delegate_to = ModuleArgsParser(task_ds_1).parse()
    print("action: {}".format(action))
    print("args: {}".format(args))
    print("delegate_to: {}".format(delegate_to))
    print("--------")

    task_ds_2 = {
        'name': 'test task',
        'action': 'shell',
        'args': {
            '_uses_shell': True,
            '_raw_params': 'echo "{{ ansible_facts["all"]["ansible_mounts"] }}"'
        }
    }

    action, args, delegate_to = ModuleArgsParser(task_ds_2).parse()
   

# Generated at 2022-06-11 08:51:55.867413
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    md = ModuleArgsParser({'action': 'copy src=a dest=b', 'delegate_to': '127.0.0.1', 'args': 'xyz'})
    assert md.parse() == ('copy', {'dest': 'b', 'src': 'a', '_raw_params': 'xyz'}, '127.0.0.1')
    assert md.parse(skip_action_validation=True) == ('copy', {'dest': 'b', 'src': 'a', '_raw_params': 'xyz'}, '127.0.0.1')

    md = ModuleArgsParser({'action': 'ping', 'delegate_to': '127.0.0.1'})
    assert md.parse() == ('ping', {}, '127.0.0.1')


# Generated at 2022-06-11 08:51:58.880229
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'module': 'ec2', 'x': 1, 'args': {'a': 1, 'b': 2}})
    parser.parse(skip_action_validation=False)
    assert True



# Generated at 2022-06-11 08:52:09.578511
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test empty input
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test invalid inputs
    parser = ModuleArgsParser({'action': 10})
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test the case of action
    parser = ModuleArgsParser({'action': 'shell echo hi'})
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test the case of action as dict and action is not set as a task attribute

# Generated at 2022-06-11 08:52:12.721975
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    assert parser.parse() == ('copy', {'dest': 'b', 'src': 'a'}, None)


# Generated at 2022-06-11 08:52:24.061876
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic

    module = AnsibleModule(
        argument_spec=dict(
            action=dict(type='dict'),
            args=dict(type='dict'),
            delegate_to=dict(type='str'),
            local_action=dict(type='str'),
            module=dict(type='str'),
            static=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    module._ansible_module_list = [basic, ]
    module.init_temp_path()

    test

# Generated at 2022-06-11 08:52:27.355166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = dict(action=dict(copy=dict(src='a', dest='b')))
  module_args_parser = ModuleArgsParser(task_ds)
  module_args_parser.parse()


# Generated at 2022-06-11 08:52:35.370985
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

# Generated at 2022-06-11 08:52:45.388837
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # We use the setUp method to prepare the data
    # and use it in the tests that follow
    def setUp():
        # When checking the content of the fixtures, we can see that
        # one of the tasks contains 'local_action' and the other
        # contains 'action'
        #
        # For each of the 3 possible cases we want to test that:
        #
        # 1. Action name is properly extracted
        # 2. Arguments are properly extracted
        # 3. Right value is extracted for 'delegate_to'
        #
        with open(fixture_loader.get_fixture_path('args_parser/main.yml'), 'r') as fixture_file:
            fixture_data = yaml.safe_load(fixture_file)
            tasks = []
            for task in fixture_data:
                tasks.append

# Generated at 2022-06-11 08:53:15.197169
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    valid_task_dss = [
        {"name": "task1", "action": "shell echo hi"},
        {"name": "task2", "action": {"module": "ping", "data": "pong"}},
        {"name": "task3", "local_action": "shell echo hi"},
        {"name": "task4", "local_action": {"module": "ping", "data": "pong"}},
        {"name": "task5", "shell": "pwd"},
        {"name": "task6", "ping": {"data": "pong"}},
    ]

# Generated at 2022-06-11 08:53:25.574186
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.splitter import split_args
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    task_ds = {}
    collection_list = None

    module_obj = ModuleArgsParser(task_ds, collection_list)
    assert module_obj

    task_ds = {}
    collection_list = None

    module_obj = ModuleArgsParser(task_ds, collection_list)
    assert module_obj

    task_ds = {u'args': {u'foo': u'bar'}}
    collection_list = None

    module_obj = ModuleArgsParser(task_ds, collection_list)
    action = 'action'
    args = {}
    delegate_to = None
    actual_

# Generated at 2022-06-11 08:53:35.070128
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, Sentinel)

    task_ds = dict(action='raw', reboot='')
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=['community.general', 'ansible.builtin'])
    assert parser.parse() == ('raw', {u'reboot': u''}, Sentinel)

    task_ds = dict(action='copy src=a dest=b')
    parser = ModuleArgsParser(task_ds)