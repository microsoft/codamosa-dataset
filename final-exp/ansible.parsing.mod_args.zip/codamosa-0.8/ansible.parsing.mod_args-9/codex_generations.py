

# Generated at 2022-06-11 08:43:53.861557
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # SETUP
    loader = DataLoader()
    task_ds = {}
    task_ds[u'action'] = u'python module.py'
    task_ds[u'tags'] = [u'test']
    task_ds[u'when'] = u'False'
    task_ds[u'register'] = u'output'
    # caller = Task.load(task_ds)
    # parser = ModuleArgsParser(task_ds)
    # parser.parse()
    assert True == True


# Generated at 2022-06-11 08:44:03.535366
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    task_ds = dict(action=dict(shell='echo hi'))
    out = m.parse(task_ds, skip_action_validation=True)
    assert out == ('shell', {u'_raw_params': u'echo hi'}, Sentinel), out

    task_ds = dict(action='shell echo hi')
    out = m.parse(task_ds, skip_action_validation=True)
    assert out == ('shell', {u'_raw_params': u'echo hi'}, Sentinel), out

    task_ds = dict(action=dict(module='shell', args='echo hi'))
    out = m.parse(task_ds, skip_action_validation=True)
    assert out == ('shell', {u'_raw_params': u'echo hi'}, Sentinel), out

# Generated at 2022-06-11 08:44:09.043024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "action": {"module": "copy",
                   "src": "a",
                   "dest": "b"}
    }
    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    print(result)
    assert result == ("copy", {"src": "a", "dest": "b"}, None)


# Generated at 2022-06-11 08:44:20.044056
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = dict(
        action = dict(
            module = "copy",
            src = "file.txt",
            dest = "/tmp",
        )
    )
    collection_list = None
    test = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    expected = ("copy", dict(src="file.txt", dest="/tmp"), None)
    actual = test.parse()
    assert expected == actual, 'The expected %s but got %s.' % (expected, actual)


    task_ds = dict(
        action = dict(
            module = "shell",
            _raw_params = "echo hello world",
        )
    )
    collection_list = None
    test = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    expected

# Generated at 2022-06-11 08:44:30.212972
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1: assert function return nothing
    try:
        task_ds = TASK_DICT_EMPTY
        collection_list = None
        parser = ModuleArgsParser(task_ds, collection_list)
        parser.parse()
    except Exception as e:
        assert type(e) == AnsibleParserError
        assert str(e) == "no module/action detected in task."
    
    # test case 2: assert function return nothing
    try:
        task_ds = TASK_DICT_ACTION
        collection_list = None
        parser = ModuleArgsParser(task_ds, collection_list)
        parser.parse()
    except Exception as e:
        assert type(e) == AnsibleParserError
        assert str(e) == "conflicting action statements: shell, debug"

    # test case 3:

# Generated at 2022-06-11 08:44:34.689025
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Unit test ModuleArgsParser.parse")

# Generated at 2022-06-11 08:44:45.340289
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

# Generated at 2022-06-11 08:44:51.465050
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestModuleArgsParser_parse(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_parse(self):
            parser = ModuleArgsParser()

            d = dict()
            skip_action_validation = False
            # normalize_old_style_args
            d = dict(local_action='command')
            module, args, delegate_to = parser.parse(d, skip_action_validation)
            self.assertEqual(module, 'command')
            self.assertEqual(args, None)
            self.assertEqual(delegate_to, 'localhost')

            d = dict(local_action='copy')
            module, args, delegate_to = parser.parse(d, skip_action_validation)
            self.assertE

# Generated at 2022-06-11 08:45:01.482778
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:09.908254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    #self.assertRaises(AssertionError, module_args_parser.parse)
    assert module_args_parser.parse() == ('ping', {}, None)
    assert module_args_parser.parse(skip_action_validation=True) == ('ping', {}, None)
    module_args_parser = ModuleArgsParser(task_ds={'action': {'copy': 'src=a dest=b'}})
    assert module_args_parser.parse() == ('copy', {'dest': 'b', 'src': 'a'}, None)
    module_args_parser = ModuleArgsParser(task_ds={'action': {'shell': 'echo hi'}})

# Generated at 2022-06-11 08:45:28.147211
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # normal example using default k/v parsing
    task_ds = dict(
        module="copy",
        delegate_to="xyz",
        src="a",
        dest="b",
        original_basename="c",
        follow=True
    )
    m = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = m.parse()
    assert (action == "copy")
    assert (len(args) == 5)
    assert (delegate_to == "xyz")

    # normal example using default k/v parsing, example taken from Ansible git repository.
    task_ds = dict(
        module="async_wrapper",
        async_seconds=1
    )
    m = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = m.parse()


# Generated at 2022-06-11 08:45:33.875323
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    task_ds = {
        'action': 'copy src=a dest=b',
    }
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == dict(src="a", dest="b")


# Generated at 2022-06-11 08:45:44.070610
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:45:50.420334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.play 
    from ansible.parsing.dataloader import DataLoader
    from ansible import constants as C
    import json
    module = "command"
    args = {'chdir': '/tmp'}
    ds = {"command": "pwd", "args": args}
    parser = ModuleArgsParser(ds)
    action, params, delegate_to = parser.parse()
    assert action == module
    assert params == args
    assert delegate_to == None


# Generated at 2022-06-11 08:46:00.157039
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.compat.tests import unittest
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class UnitTestCase(unittest.TestCase):
        def setUp(self):
            ''' setup the test'''
            self.parser = ModuleArgsParser()

        def test_parse_action_module(self):
            '''make sure the parse method can parse action modules
            '''
            task_ds = dict(action=dict(module='copy', src='/tmp/a', dest='/tmp/b'))
            action, module_args, delegate_to = self.parser.parse(task_ds)
            self.assertTrue(action == 'copy')
            self.assertTrue(isinstance(module_args, dict))

# Generated at 2022-06-11 08:46:08.819906
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:46:13.446221
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = "shell"
    args = {'chdir': '/tmp', '_raw_params': 'pwd'}
    delegate_to = None
    task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}}
    test = ModuleArgsParser(task_ds=task_ds).parse()
    assert (action, args, delegate_to) == test



# Generated at 2022-06-11 08:46:15.484684
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()

# -----------------------------------Abstract TaskQueueManager -----------------------------------

# Generated at 2022-06-11 08:46:24.083868
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from units.mock.loader import DictDataLoader
    from jinja2 import Template

    data = read_data_file(os.path.join(os.path.dirname(__file__), 'action_plugin.yml'))
    for test in yaml.load(data):
        loader = DictDataLoader({'playbook.yml': Template(yaml.dump(test['playbook'])).render(**test['vars'])})
        variable_manager = VariableManager()
        variable_manager.set_inventory(Inventory(loader=loader))


# Generated at 2022-06-11 08:46:33.015981
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class AnsibleOptions(object):
        verbosity = 1

    template_data = {
        'var1': 'foo',
        'var2': 'bar',
        'var3': 'baz',
    }

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    removed = templar_modules.pop('localaction')
    removed = templar_modules.pop('action')
    module_loader.register_plugins(templar_modules)
    module_loader.register_

# Generated at 2022-06-11 08:46:44.054219
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert "Not Yet Implemented" == "Need to implement"
# Unit tests for class ActionBase

# Generated at 2022-06-11 08:46:51.686906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = dict()
    mock_task_ds['delegate_to'] = 'foo'
    mock_task_ds['action'] = 'bar'
    mock_task_ds['args'] = 'baz'
    mock_collection_list = list()
    mock_collection_list.append('qux')

    mock_module_args_parser = ModuleArgsParser(task_ds=mock_task_ds, collection_list=mock_collection_list)

    # call the method under test
    result = mock_module_args_parser.parse()

    # assert
    assert(result == ('bar', 'baz', 'foo'))

# Generated at 2022-06-11 08:47:00.782808
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with empty dict
    task_ds = {}
    result = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert result == (None, {}, Sentinel)

    # Test with task_ds with no module
    task_ds = { 'delegate_to': 'localhost', 'foo': 'bar' }
    result = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert result == (None, {}, 'localhost')

    # Test with task_ds with action
    task_ds = { 'action': { 'module': 'copy', 'src': 'a', 'dest': 'b' } }
    result = ModuleArgsParser(task_ds, collection_list=None).parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

   

# Generated at 2022-06-11 08:47:08.659701
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    d = {'action': 'shell wc -l', 'delegate_to': 'localhost'}
    p = ModuleArgsParser(task_ds=d)
    (action, args, delegate_to) = p.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'wc -l'}
    assert delegate_to == 'localhost'

    d = {'local_action': 'shell echo hi'}
    p = ModuleArgsParser(task_ds=d)
    (action, args, delegate_to) = p.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    d = {'shell': 'echo hi'}
    p = ModuleArgsParser(task_ds=d)

# Generated at 2022-06-11 08:47:17.654268
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:47:27.241716
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestModuleArgsParser(unittest.TestCase):
        def test_no_module(self):
            with self.assertRaises(AnsibleParserError) as context:
                task_ds = {}
                ModuleArgsParser(task_ds).parse()
            self.assertEqual(context.exception.message, "no module/action detected in task.")

        def test_no_module_found(self):
            with self.assertRaises(AnsibleParserError) as context:
                task_ds = {
                    "foo_module": ""
                }
                ModuleArgsParser(task_ds).parse()
            self.assertEqual(context.exception.message, "couldn't resolve module/action 'foo_module'. This often indicates a misspelling, missing collection, or incorrect module path.")

        # module: <stuff> is

# Generated at 2022-06-11 08:47:37.606237
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _module_name = 'test_module_name'

    class TestParser(ModuleArgsParser):  # pylint: disable=too-many-ancestors
        ''' class to override parse method '''
        def parse(self, skip_action_validation=True):
            return super(TestParser, self).parse(skip_action_validation=skip_action_validation)

    # Test parse with valid _task_ds without involving collections
    obj = TestParser({'module': _module_name})
    assert (obj.parse(skip_action_validation=False) == (_module_name, dict(), None))

    # Test parse with invalid _task_ds
    obj = TestParser({})
    with pytest.raises(AnsibleParserError):
        obj.parse(skip_action_validation=False)



# Generated at 2022-06-11 08:47:47.393444
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    cls = ModuleArgsParser()
    x = dict(action="echo hi", delegate_to="test")
    action, args, delegate_to = cls.parse(x)
    assert action == "shell"
    assert args == {"_raw_params": "echo hi"}
    assert delegate_to == "test"

    x = dict(action={"module": "echo hi", "x": 1}, delegate_to="test")
    action, args, delegate_to = cls.parse(x)
    assert action == "shell"
    assert args == {"x": 1, "_raw_params": "echo hi"}
    assert delegate_to == "test"

    x = dict(local_action="echo hi")
    action, args, delegate_to = cls.parse(x)
    assert action == "shell"

# Generated at 2022-06-11 08:47:59.651152
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser()
    args = dict(a=1, b=2)
    res = p._split_module_string("module args=foo")
    assert res == ('module', 'args=foo')
    res = p._split_module_string("copy a=1 b=2")
    assert res == ('copy', 'a=1 b=2')
    res = p._split_module_string("some_module")
    assert res == ('some_module', '')
    res = p._normalize_parameters(args, 'foo')
    assert res == ('foo', dict(a=1, b=2))
    res = p._normalize_parameters(args, 'foo', dict(a=1, b=2))
    assert res == ('foo', dict(a=1, b=2))

# Generated at 2022-06-11 08:48:09.289382
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory"])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    # get a baseline template
    module_args_parser = ModuleArgsParser(dict())
    # make sure our parser doesn't choke on any of the freeform
    # actions

# Generated at 2022-06-11 08:48:26.790133
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()


# Generated at 2022-06-11 08:48:37.525811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils import basic

    # Create a test module and associated task.
    test_module_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_fake_test_module')
    os.makedirs(test_module_path)
    with open(os.path.join(test_module_path, 'test_module.py'), 'w+') as f:
        f.write("#!/usr/bin/python\nexec('print \"called test_module\"')\n")
    task_ds = dict(action=dict(module='test_module', test_param='value'))

    # Create a parser, parsing the test task, and collect the result.
    parser = ModuleArgsParser()

# Generated at 2022-06-11 08:48:38.230174
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  pass


# Generated at 2022-06-11 08:48:47.692573
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text, to_native

    # Arrange
    task_ds = dict(
        action=dict(
            module="an_action",
            args=dict(
                x=1,
                y=2
            )
        )
    )
    mp = ModuleArgsParser(task_ds=task_ds)

    # Act
    actual = mp.parse()

    # Assert
    assert actual == ("an_action", dict(x=1, y=2), None)
    assert mp.resolved_action == "an_action"


    # Arrange
    task_ds = dict(
        action=dict(
            module="an_action"
        )
    )
    mp = ModuleArgsParser

# Generated at 2022-06-11 08:48:50.175922
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = []
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)



# Generated at 2022-06-11 08:49:01.385290
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:49:11.224229
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test different format of action statements
    def assert_parse_action(ds, expected_action, expected_args, expected_delegate_to=None):
        m = ModuleArgsParser(ds)
        result = m.parse()
        assert result == (expected_action, expected_args, expected_delegate_to)

    # test the simplest case, with module name
    ds = dict(action=dict(module='shell', args='echo hi'))
    assert_parse_action(ds, expected_action='shell', expected_args=dict(args=[u'echo', u'hi']))

    # more legacy forms

    ds = dict(action='shell echo hi')
    assert_parse_action(ds, expected_action='shell', expected_args=dict(args=[u'echo', u'hi']))


# Generated at 2022-06-11 08:49:16.503621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds1 = 'copy src=a dest=b'
    task_ds2 = '{name: a}'
    obj1 = ModuleArgsParser(task_ds1)
    obj2 = ModuleArgsParser(task_ds2)
    assert obj1.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert obj2.parse() == ('name', {'a': None}, None)


# Generated at 2022-06-11 08:49:27.120257
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_task_ds = {}
    assert ModuleArgsParser(my_task_ds).parse() == (None, {}, Sentinel)

    my_task_ds = {'delegate_to': 'foo'}
    assert ModuleArgsParser(my_task_ds).parse() == (None, {}, 'foo')

    my_task_ds = {'action': 'copy src=a dest=b'}
    assert ModuleArgsParser(my_task_ds).parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    my_task_ds = {'action': {'module': 'copy src=a dest=b'}}
    assert ModuleArgsParser(my_task_ds).parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    my_task_ds

# Generated at 2022-06-11 08:49:36.716657
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_ModuleArgsParser = ModuleArgsParser(
        task_ds={
            'action': {
                'module': 'shell echo hi',
                'not_module': 'not_a_module'
            }
        }
    )
    assert my_ModuleArgsParser.parse() == ('shell', {
        '_raw_params': 'echo hi'
    }, None)
    del my_ModuleArgsParser

    my_ModuleArgsParser = ModuleArgsParser(
        task_ds={
            'module': 'shell echo hi'
        }
    )
    assert my_ModuleArgsParser.parse() == ('shell', {
        '_raw_params': 'echo hi'
    }, None)
    del my_ModuleArgsParser


# Generated at 2022-06-11 08:49:58.024444
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': '{{ action }}',
        'delegate_to': '{{ delegate_to }}',
        'args': '{{ args }}'
    }
    parser = ModuleArgsParser(task_ds)

    # test with skip_action_validation=True
    action, args, delegate_to = parser.parse(skip_action_validation=True)
    assert action == '{{ action }}'
    assert args == '{{ args }}'
    assert delegate_to == '{{ delegate_to }}'

    # test with skip_action_validation=False
    action, args, delegate_to = parser.parse(skip_action_validation=False)
    assert action == '{{ action }}'
    assert args == '{{ args }}'
    assert delegate_to == '{{ delegate_to }}'

# Generated at 2022-06-11 08:50:07.454334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude

    # valid tasks
    # assert ModuleArgsParser()._normalize_parameters({'shell': 'echo hi'}, action='shell') == ({'_raw_params': 'echo hi'}, True)
    # assert ModuleArgsParser()._normalize_parameters({'raw': 'echo hi'}, action='shell') == ('echo hi', False)
    # assert ModuleArgsParser()._normalize_parameters({'raw': 'echo hi', '_uses_shell': True}, action='shell') == ('echo hi', True)
    # assert ModuleArgsParser()._normalize_parameters({'raw': 'echo hi', '_uses_shell': False}, action='shell') == ('echo hi', False)
    # assert ModuleArgsParser()._normalize_parameters('echo hi', action='shell

# Generated at 2022-06-11 08:50:11.642848
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Fix 'ModuleArgsParser'
    raise SkipTest 
    # module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    # action, args, delegate_to = module_args_parser.parse(skip_action_validation=False)
    raise NotImplementedError()


# Generated at 2022-06-11 08:50:22.078611
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    host = HostVars({})
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')
    variable_manager.set_host_variable(host, 'ansible_python_interpreter', 'python')
    variable_manager.set_host_variable(host, 'ansible_playbook_python', 'python')
    variable_manager.set_host_variable(host, 'ansible_remote_tmp', '/tmp/ansible')
    variable_manager.extra_vars = {'foo': 'bar'}

    # test for parsing "module"
    task = {"action": {"module": "copy", "src": "abc", "dest": "xyz"}, "delegate_to": "localhost"}
    action, args, delegate_

# Generated at 2022-06-11 08:50:26.559601
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(dict(action={'module': 'echo hi'},
                                                              args='2',
                                                              delegate_to='localhost'))
    assert action == 'echo'
    assert args['hi'] == '2'
    assert delegate_to == 'localhost'


# Generated at 2022-06-11 08:50:29.880554
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    parser = ModuleArgsParser({'action': 'copy src=a dest=b', 'delegate_to': 'remote_host'})
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'remote_host')



# Generated at 2022-06-11 08:50:38.125492
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    unit test for method parse of class ModuleArgsParser
    '''
    # test with empty args
    raw_args = {}
    expected_action = None
    expected_args = {}
    expected_delegate_to = Sentinel
    
    m = ModuleArgsParser({'action': raw_args})
    assert m.parse() == (expected_action, expected_args, expected_delegate_to)

    # test with raw_args contains invalid ansible task, it should raise an error
    invalid_ansible_task = 'copy src=a dest='
    m = ModuleArgsParser({'action':invalid_ansible_task})
    with pytest.raises(AnsibleParserError):
        m.parse()
    
    # test with raw_args is valid ansible task

# Generated at 2022-06-11 08:50:38.952591
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True == True



# Generated at 2022-06-11 08:50:39.868417
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: test cannot be executed
    pass

# Generated at 2022-06-11 08:50:48.726455
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    mp = ModuleArgsParser(task_ds, collection_list)
    result = mp._normalize_old_style_args('')
    assert result == (None, None)

    result = mp.parse()
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    mp = ModuleArgsParser(task_ds, collection_list)
    result = mp.parse()
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-11 08:51:17.706496
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    run_in_legacy = [False, True]
    for legacy in run_in_legacy:
        with pytest.raises(AnsibleError) as exec_info:
            task_ds = {'action': {'_raw_params': 'echo hi', '_uses_shell': True}}
            ModuleArgsParser(task_ds, collection_names=None).parse(skip_action_validation=legacy)
        assert exec_info.value.message == "invalid parameter specified for action 'echo': '_raw_params'"

    task_ds = {'become': True, 'become_user': 'test_user'}
    action, args, delegate_to = ModuleArgsParser(task_ds, collection_names=None).parse(skip_action_validation=True)
    assert delegate_to is Sentinel

# Generated at 2022-06-11 08:51:23.932984
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DictDataLoader({})
    task_ds = dict(action='shell', args=dict(chdir='/tmp'))
    collection_list = [AnsibleCollectionRef('ansible.builtin')]
    args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = args_parser.parse()
    assert action == 'shell'
    assert args == dict(chdir='/tmp')
    assert delegate_to is None

    task_ds = dict(action='shell', args=dict(chdir='/tmp'), delegate_to='localhost')
    collection_list = [AnsibleCollectionRef('ansible.builtin')]
    args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
   

# Generated at 2022-06-11 08:51:31.933668
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict()
    args['test'] = "echo hi"
    task_ds = {}
    task_ds["action"] = args
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('echo', {'test': 'hi'}, None), "Testing ModuleArgsParser parse method failed!"

    args = dict()
    args['test'] = "{{echo}} hi"
    task_ds = {}
    task_ds["action"] = args
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('echo', {'test': '{{echo}} hi'}, None), "Testing ModuleArgsParser parse method failed!"

test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:51:42.921684
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.task
    import ansible.playbook.handler
    from ansible.module_utils.common.collections import ImmutableDict

    obj = ansible.playbook.task.Task()
    obj.itervars = lambda: {}
    obj.vars = ImmutableDict()
    obj.block = None
    obj.play = None
    obj.role = None
    obj.playbook = None
    obj._ds = {'name': 'test name', 'delegate_to': 'test delegate_to', 'static': 'test static', 'block': 'test block'}
    obj.dump = lambda: {}
    obj.update_block_vars = lambda: {}
    obj.get_vars = lambda: {}
    task_ds = obj._ds

# Generated at 2022-06-11 08:51:48.131246
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    thing = 'shell echo hi'
    action = None
    skip_action_validation = False
    expected =  action, args, delegate_to = 'shell', 'echo hi', None
    results = module_args_parser.parse(skip_action_validation)
    assert results == expected, results


# Generated at 2022-06-11 08:51:56.226934
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {}
    collection_list = None
    module_args_parser.__init__(task_ds=task_ds, collection_list=collection_list)

    action, args, delegate_to = module_args_parser.parse(skip_action_validation=True)

    print("args:\n%s" % args)
    print("action:\n%s" % action)
    print("delegate_to:\n%s" % delegate_to)

# main
if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-11 08:52:06.559217
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:52:16.998241
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser()
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    skip_action_validation = False

# Generated at 2022-06-11 08:52:27.562610
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # instantiate class for testing
    module_args_parser = ModuleArgsParser()
    
    # define test input
    task_ds = {'action': 'command pwd'}
    
    assert_equal(module_args_parser.parse(task_ds), ('command', {'_raw_params': 'pwd'}, None))

    # define test input
    task_ds = {'action': 'command pwd', 'args': 'chdir=/test'}
    
    assert_equal(module_args_parser.parse(task_ds), ('command', {'chdir': '/test', '_raw_params': 'pwd'}, None))

    # define test input
    task_ds = {'action': {'module': 'command'}}
    

# Generated at 2022-06-11 08:52:33.896159
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # make args parsing consistent in Python2/3
    if PY2:
        _test_ModuleArgsParser_parse()
    else:
        import types
        import unittest
        class TestModuleArgsParserParse(unittest.TestCase):
            def test(self):
                self.maxDiff = None
                _test_ModuleArgsParser_parse(self)
        suite = unittest.TestLoader().loadTestsFromTestCase(TestModuleArgsParserParse)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        sys.exit(not result.wasSuccessful())



# Generated at 2022-06-11 08:52:54.062765
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    ModuleArgsParser unit test stubs
    """
    pass


# Generated at 2022-06-11 08:52:58.212379
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    MOCK_INPUT_1 = dict(action='copy : src=a dest=b')
    MOCK_INPUT_2 = dict(action={'module': 'copy', 'src':'a', 'dest':'b'})

    parser_1 = ModuleArgsParser(MOCK_INPUT_1)
    parser_2 = ModuleArgsParser(MOCK_INPUT_2)

    assert parser_1.parse() == parser_2.parse()

# Generated at 2022-06-11 08:53:02.455813
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    ModuleArgsParser_instance = ModuleArgsParser(task_ds, collection_list)
    # Parses the given task into its component parts: action, module args, delegate_to
    action, args, delegate_to = ModuleArgsParser_instance.parse()


"""
Parse a task into its component parts: action, module args, delegate_to
"""

# Generated at 2022-06-11 08:53:11.083990
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:53:19.956024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Create an instance of class ModuleArgsParser
    obj_ModuleArgsParser = ModuleArgsParser()

    # call action: parse
    ans = obj_ModuleArgsParser.parse()

    # assert the return type
    assert isinstance(ans, tuple), "{0} should be of type tuple, got: {1}".format(ans, type(ans))

    # assert return value
    assert ans == (None, {}, None), "{0} should be: Tuple(None, {}, None), got: {1}".format(ans, type(ans))

    # Create an instance of class ModuleArgsParser
    obj_ModuleArgsParser = ModuleArgsParser({"action": "shell", "test": "vim"})

    # call action: parse
    ans = obj_ModuleArgsParser.parse()

    # assert the return type

# Generated at 2022-06-11 08:53:30.345039
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.task
    test_obj = ansible.playbook.task.Task()
    test_obj.module_args = {
        'args': {},
        'action': {
            'module': 'command',
            'args': {
                '_raw_params': 'uptime',
                'warn': False
            }
        }
    }
    test_obj.action = 'command'
    test_obj.action_args = {
        '_raw_params': 'uptime',
        'warn': False
    }
    test_obj.delegate_to = None
    res = test_obj.parse()
    assert res is True


# pylint: disable=too-few-public-methods