

# Generated at 2022-06-11 08:43:53.864691
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = dict(
        action=dict(
            action=dict(
                module='shell',
                args='echo "This is a test"',
            )
        ),
        not_action=dict(
            name='shell',
            command='echo "This is a test"',
        ),
        multiple=dict(
            name='shell',
            command='echo "This is a test"',
            delegate_to='local',
            action=dict(
                module='shell',
                args='echo "This is a test"',
            ),
        ),
    )

# Generated at 2022-06-11 08:44:03.535906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test of correct, simplest usage with dict.
    # create a dict with the keys and values which you want
    input_dict = dict(local_action=dict(module='copy', src='a', dest='b'))
    test_obj = ModuleArgsParser(task_ds=input_dict, collection_list=['ansible.builtin'])
    (action, args, delegate_to) = test_obj.parse(skip_action_validation=True)
    assert isinstance(action, string_types) == True
    assert isinstance(args, dict) == True
    assert isinstance(delegate_to, string_types) == True
    # Test of correct usage with string.
    # create a dict with the keys and values which you want
    input_dict = dict(local_action='copy src=a dest=b')
    test

# Generated at 2022-06-11 08:44:14.132982
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser({'module': 'foo', 'args': {'bar': 1}})

    assert parser.parse() == ('foo', {'bar': 1}, Sentinel)

    parser = ModuleArgsParser({'module': 'foo bar', 'args': {'bar': 1}})

    assert parser.parse() == ('foo', {'bar': 1, '_raw_params': 'bar'}, Sentinel)

    parser = ModuleArgsParser({'module': 'foo', 'args': {'bar': 1, '_raw_params': 'baz'}})

    with pytest.raises(AnsibleParserError):
        parser.parse()

    parser = ModuleArgsParser({'module': 'foo', 'args': 'bar=baz'})

    assert parser.parse() == ('foo', {'bar': 'baz'}, Sentinel)



# Generated at 2022-06-11 08:44:16.577306
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    input_dict = {'action': 'copy: src=a dest=b'}
    ModuleArgsParser(input_dict).parse()



# Generated at 2022-06-11 08:44:24.265872
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser()
    # setup
    thing = {'a': 1, 'b': 2}
    module_parser._task_ds['a'] = 1
    # test
    assert module_parser.parse() == (None, dict(), Sentinel)
    module_parser._task_ds['local_action'] = thing
    assert module_parser.parse() == ('a', dict(b=2), None)
    module_parser._task_ds['local_action'] = 'shell echo hi'
    assert module_parser.parse() == ('shell', dict(echo='hi'), None)



# Generated at 2022-06-11 08:44:35.021763
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # scenario 1.
    #
    #   input
    #     task_ds:
    #       action: copy src=a dest=b
    #
    #   expected
    #     [
    #       'action' : 'copy',
    #       'args'   : { 'src' : 'a', 'dest' : 'b' }
    #     ]
    #
    task_ds = dict(action='copy src=a dest=b')
    spec = dict(type='action')
    obj = ActionModule(task_ds, spec=spec)
    expected = dict(action='copy', args=dict(src='a', dest='b'))
    results = [obj.action, obj.args]

    assert results == expected

    #
    # scenario 2.
    #
    #   input
    #

# Generated at 2022-06-11 08:44:45.573686
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parse_obj = ModuleArgsParser()
    assert parse_obj._task_attrs == frozenset({'local_action', 'static', 'name', 'tags', 'register', 'until', 'notify', 'failed_when', 'delegate_to', 'ignore_errors', 'run_once'})

    assert parse_obj._normalize_new_style_args(thing={'region': 'xyz'}, action='ec2') == {'region': 'xyz'}
    assert parse_obj._normalize_new_style_args(thing='echo hi', action='shell') == {'_raw_params': 'echo hi', '_uses_shell': True}
    with pytest.raises(AnsibleParserError) as excinfo:
        parse_obj._normalize_new_style_args(thing=None, action='ping')

# Generated at 2022-06-11 08:44:49.881413
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'setup'
    data = dict(
        gather_subset=dict(hardware=True, default=True),
    )
    module_args_parser = ModuleArgsParser(task_ds=data)
    action, args, delegate_to = module_args_parser.parse()
    assert action == module_name
    assert args == data
    assert delegate_to is None
# Test class for module: setup

# Generated at 2022-06-11 08:44:59.781928
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = {"action" : 'shell', "_raw_params" : "/usr/bin/ls -la ", "chdir" : "/tmp/"}
    module_args_parser = ModuleArgsParser(task)
    assert module_args_parser._task_ds == task
    # Test with valid input
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args['chdir'] == "/tmp/"
    assert args['_raw_params'] == "/usr/bin/ls -la "
    assert delegate_to == None
    # Test with invalid input
    task['action'] = 'invalid_action'
    with pytest.raises(AnsibleParserError):
        action, args, delegate_to = module_args_parser.parse()
    task['action'] = 'shell'


# Generated at 2022-06-11 08:45:09.022629
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
        Unit test for method parse of class ModuleArgsParser
    '''
    task_ds = {'action': {'src': 'a', 'dest': 'b'}}
    add_args = 'args'
    ans_obj = ModuleArgsParser(task_ds)
    ans_obj.action_loader = Mock()
    ans_obj.action_loader.find_plugin_with_context.return_value = Mock()
    ans_obj.action_loader.find_plugin_with_context.return_value.resolved = False

    ans_obj.module_loader = Mock()
    ans_obj.module_loader.find_plugin_with_context.return_value = Mock()
    ans_obj.module_loader.find_plugin_with_context.return_value.resolved = False
    ans_obj.module_loader

# Generated at 2022-06-11 08:45:38.478449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, None)
    module_args_parser = ModuleArgsParser(task_ds=dict())
    assert module_args_parser.parse() == (None, None)
    module_args_parser = ModuleArgsParser(task_ds=dict(delegate_to=None))
    assert module_args_parser.parse() == (None, None)
    module_args_parser = ModuleArgsParser(task_ds=dict(delegate_to=Sentinel))
    assert module_args_parser.parse() == (None, None)

    # _normalize_parameters(self, thing, action=None, additional_args=None)
    module_args_parser = ModuleArgsParser()
    (action, args) = module_args_parser._normal

# Generated at 2022-06-11 08:45:40.594718
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert m.parse() == (None, {}, Sentinel)



# Generated at 2022-06-11 08:45:51.031990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    # Arrange
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader)
    variable_manager.set_inventory(inventory_manager)

    play_context = PlayContext()
    play_context.network_os = 'default'

    task = Task()
    task.action = 'ping'
    task.args = {'_raw_params': '', '_uses_shell': True}

    # Act

# Generated at 2022-06-11 08:46:00.754390
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser()
    try:
        args_parser.parse()
    except Exception as exc:
        assert isinstance(exc, AnsibleAssertionError)
        assert 'the type of \'task_ds\' should be a dict, but is a <class \'NoneType\'>' in to_text(exc)
    # Test case with task_ds= {'action': 'shell', '_raw_params': '''echo "{{ user }}"''', 'delegate_to': 'local'},
    #                   collection_list=['ansible_collections.mycollection','ansible_collections.myothercollection']

# Generated at 2022-06-11 08:46:09.428980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test for 'normal' execution
    test_data = dict()
    test_data['action'] = {}
    test_data['action']['module'] = 'ec2'
    test_data['action']['args'] = {}
    test_data['action']['args']['x'] = 1
    test_data['action']['args']['y'] = 2
    test_data['delegate_to'] = 'localhost'
    ma = ModuleArgsParser(task_ds=test_data)
    ma.parse()
    assert ma._task_ds == test_data
    assert ma.resolved_action is None
    # Test for exception
    test_data = dict()
    test_data['action'] = 123
    test_data['delegate_to'] = 'localhost'
    ma = ModuleArgsParser

# Generated at 2022-06-11 08:46:18.051061
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  args_parser = ModuleArgsParser(collection_list=None)
  # test case 1:
  #   1. thing: 'shell echo hi'
  #   1. action: None
  #   1. additional_args: dict()
  #   1. expected result: ('shell', {'echo hi'}, None)
  thing = 'shell echo hi'
  action = None
  additional_args = dict()
  test_result = args_parser.parse(thing, action, additional_args)
  assert test_result == ('shell', {'echo hi'}, None)
  # test case 2:
  #   1. thing: 'shell: echo hi'
  #   1. action: None
  #   1. additional_args: dict(foo=bar, foobar=baz)
  #   1. expected result: ('shell

# Generated at 2022-06-11 08:46:26.995426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'action': {u'src': u'asdf', u'dest': u'asdf'}}
    mod = ModuleArgsParser(task_ds)
    (p1, p2, p3) = mod.parse()
    assert p1 == u'action', "The method 'parse' of class 'ModuleArgsParser' must return a tuple in the format [action, args, delegate_to]"
    assert p1 == 'action', "The method 'parse' of class 'ModuleArgsParser' must return a tuple in the format [action, args, delegate_to]"
    assert p3 is None, "The method 'parse' of class 'ModuleArgsParser' must return a tuple in the format [action, args, delegate_to]"

# Generated at 2022-06-11 08:46:31.476025
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser_obj = ModuleArgsParser()
    action_module_obj = {'task': u'5', 'local_action': u'copy src=a dest=b', 'action': 42}
    result = args_parser_obj.parse(action_module_obj)
    assert result == (42, {'dest': 'b', 'src': 'a'}, u'localhost')


# Generated at 2022-06-11 08:46:39.357297
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # Testing with normal case
  task_ds = dict({'test_key': 'test_value'})
  collection_list = ['test_collection']
  parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
  result = parser.parse()
  assert result == (None, None, None)
  # Testing with false case
  task_ds = dict({'action': 'test_value'})
  collection_list = ['test_collection']
  parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
  result = parser.parse()
  assert result == ('test_value', None, None)


# Generated at 2022-06-11 08:46:43.973230
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {
        'action': {
            'foobar': 'baz'
        },
        'local_action': {
            'foobar': {
                'ansible_connection': 'local'
            }
        }
    }
    obj = ModuleArgsParser(task_ds)
    assert obj is not None
    obj.parse()


# Generated at 2022-06-11 08:47:04.627864
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler


# Generated at 2022-06-11 08:47:08.423107
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': 'region',
    }
    map = ModuleArgsParser(task_ds)
    r = map.parse()
    assert r == ('copy', {'src': 'a', 'dest': 'b', 'region': 'region'}, 'localhost'), r



# Generated at 2022-06-11 08:47:12.461403
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.parsing.dataloader
    loader_mock = MagicMock(ansible.parsing.dataloader.DataLoader)
    instance = ModuleArgsParser({'name': 'task1', 'become_user': 'root', 'action': {'module': 'ping', 'args': {'data': 'pong'} }}, loader_mock)
    assert (('ping', ['args', 'delegate_to', 'free_form', 'name'], 'root') == instance.parse()) 


# ===========================================
# Subclass: DictDataLoader
# ===========================================

# Generated at 2022-06-11 08:47:21.747893
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test the `action` keyword
    task_ds = dict(action=dict(module="ec2", region="xyz"))
    obj =  ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = obj.parse()
    assert action == "ec2"
    assert args == dict(region="xyz")
    assert delegate_to == Sentinel

    # test the new style module invocation:
    # module: ping
    task_ds = dict(ping=dict())
    obj =  ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = obj.parse()
    assert action == "ping"
    assert args == dict()
    assert delegate_to == Sentinel

    # test the new style module invocation:
    # module: setup

# Generated at 2022-06-11 08:47:31.910738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    import types

    class MockActionLoader:
        def __init__(self):
            self.was_called = False
            self.original_find_plugin_with_context = action_loader.find_plugin_with_context
            action_loader.find_plugin_with_context = self.find_plugin_with_context

        def find_plugin_with_context(self, *args, **kwargs):
            context = self.original_find_plugin_with_context(*args, **kwargs)
            if not context.resolved:
                context.resolved = True

# Generated at 2022-06-11 08:47:42.548950
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:47:47.963297
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for the method parse of the class ModuleArgsParser
    '''

    task_ds = {'action': 'foo bar=baz', 'delegate_to': 'localhost', 'args': 'yes'}

    expected_results = ('foo', {'bar': 'baz', '_raw_params': ''}, 'localhost')

    parser = ModuleArgsParser(task_ds)
    actual_result = parser.parse()

    assert actual_result == expected_results

# Generated at 2022-06-11 08:47:59.694219
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    print("")
    
    # Case 1:
    task_ds = dict(module='./foo.py')
    print("Tests case 1")
    print("input:")
    pprint(task_ds)
    
    result = module_args_parser.parse(task_ds)
    expected = ('', dict(), None)
    print("result:")
    pprint(result)
    assert(result == expected)
    
    
    # Case 2:
    task_ds = dict(action='./foo.py')
    print("Tests case 2")
    print("input:")
    pprint(task_ds)
    
    result = module_args_parser.parse(task_ds)
    expected = ('', dict(), None)

# Generated at 2022-06-11 08:48:06.131403
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = "synchronize"
    args = {"exclude": "\"{{ exclude_files }}\""}
    delegate_to = "localhost"
    task = {"synchronize": args, "delegate_to": delegate_to}
    module_args_parser = ModuleArgsParser(task)
    actual_result = module_args_parser.parse()

    assert actual_result[0] == action
    assert actual_result[1] == args
    assert actual_result[2] == delegate_to



# Generated at 2022-06-11 08:48:16.114980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Define the fixture used to generate the 'foo' task
    task_ds = dict(action=dict(module='foo'))
    # Define the expected action, args and delegate_to values
    expected_action = 'foo'
    expected_args = dict()
    expected_delegate_to = Sentinel
    # Create a ModuleArgsParser object
    m = ModuleArgsParser(task_ds=task_ds)
    # Execute the method 'parse' of the ModuleArgsParser object
    actual_action, actual_args, actual_delegate_to = m.parse()
    assert actual_action == expected_action
    assert actual_args == expected_args
    assert expected_delegate_to is actual_delegate_to
    # Define the fixture used to generate the 'foo' task

# Generated at 2022-06-11 08:48:31.597512
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict(
        delegate_to="{{ localhost }}",
        action=dict(
            module="shell",
            x=1,
            y=2,
            z=3
        )
    )
    for collection_list in [None, list()]:
        parser = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
        expected = (
            'shell',
            dict(x=1, y=2, z=3),
            "{{ localhost }}",
        )
        actual = parser.parse()
        assert actual == expected



# ---------------------------------------------
# ansible.module_utils.common.is_executable
# ---------------------------------------------


# Generated at 2022-06-11 08:48:41.823313
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test(m, e):
        if isinstance(m, dict):
            m = dict((to_text(k), v) for k, v in iteritems(m))
        if isinstance(e, dict):
            e = dict((to_text(k), v) for k, v in iteritems(e))
        t = ModuleArgsParser(task_ds=m)
        assert t.parse() == tuple(e)
    #
    # dict
    yield test, dict(module='copy dest=src src=foo'), ('copy', {'dest': 'src', 'src': 'foo'}, None)
    yield test, dict(module='copy src=foo dest=src'), ('copy', {'src': 'foo', 'dest': 'src'}, None)

# Generated at 2022-06-11 08:48:51.037541
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a module_data object of class ModuleArgsParser
    module_data = ModuleArgsParser()

    # Create an action_data object of class ModuleArgsParser
    action_data = ModuleArgsParser()

    # Create a module_data object of class ModuleArgsParser
    action_data_new = ModuleArgsParser()

    # Create a module_data object of class ModuleArgsParser
    action_data_new_style = ModuleArgsParser()

    # Create a module_data object of class ModuleArgsParser
    action_data_old_style = ModuleArgsParser()

    action_data_old_style.module_parser = ModuleArgsParser()
    # Create a module_data object of class ModuleArgsParser
    module_data_old_style = ModuleArgsParser()

    module_data_old_style.module_parser = ModuleArgsParser()
    # Create a module

# Generated at 2022-06-11 08:49:03.099539
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class MockModuleReturn(object):
        def __init__(self, **kwargs):
            self.params={}
            for k,v in kwargs.items():
                self.params[k] = v
        def get_args(self):
            return self.params
    from ansible.plugins.loader import module_loader
    task_ds = {
        'action': 'command echo 123',
        'args': {'chdir': '/root', '_raw_params': '123'}
    }
    module_loader.add_directory('./')
    map = ModuleArgsParser(task_ds=task_ds)
    module_name, task_args, delegate_to = map.parse()
    assert module_name == 'test_action'
    assert task_args['chdir'] == '/root'
    assert task

# Generated at 2022-06-11 08:49:06.295949
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    task_ds = dict(action=action)
    parser = ModuleArgsParser()
    result = parser.parse(task_ds)
    assert result[0] == action

# Generated at 2022-06-11 08:49:13.349238
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.yaml import yaml_dumps

    module_name = u'shell'
    delegate_to = u'localhost'
    shell = u'echo 1'

    result = ModuleArgsParser(task_ds={u'local_action': {module_name: shell}, u'delegate_to': delegate_to}).parse()
    expected = (u'shell', {u'_raw_params': u'echo 1'}, u'localhost')

    assert module_name in result
    assert delegate_to in result
    assert result == expected

    # test the dumper with UnsafeProxy(ValidationError)

# Generated at 2022-06-11 08:49:16.463327
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = {}
    _collection_list=[]
    _ModuleArgsParser = ModuleArgsParser(_task_ds,_collection_list)
    p = property(_ModuleArgsParser.parse)
    assert p == (None, {}, Sentinel)

# Generated at 2022-06-11 08:49:20.965254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = load_fixture('playbooks/playbook.yml')
    task_ds = data[2]['tasks'][0]
    parser = ModuleArgsParser(task_ds)
    parser.parse()
    assert parser.resolved_action == 'ansible.builtin.ping'


# Generated at 2022-06-11 08:49:31.055572
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method ansible.module_utils.common._args.ModuleArgsParser.parse
    """

    import copy
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.module_utils.common._collections_compat import Mapping

    task_ds = {'delegate_to': 'localhost', 'local_action': {'module': 'copy', 'delegate_to': {'module': 'copy'}}}
    map_ = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        map_.parse()

    task_ds = {'action': {'module': 'copy', 'delegate_to': {'module': 'copy'}}}
    map_ = Module

# Generated at 2022-06-11 08:49:39.126101
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils import scope_vars
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins import mock_action_loader, mock_module_loader
    def setup_loader(loader, action_loader, module_loader):
        loader.set_basedir(os.getcwd())
        templar = Templar(loader, variables={})
        collection_loader = None
        if action_loader:
            action_loader._templar = templar
            action_loader._add_directory(os.path.join(os.getcwd(), 'test/unit/plugins/action'))
        if module_loader:
            module_loader._templar = templar


# Generated at 2022-06-11 08:49:54.774183
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()

    action = None

    # Test 1:
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleAssertionError) as excinfo:
        parser.parse()
    assert "the type of 'task_ds' should be a dict, but is a %s" in str(excinfo.value)

    # Test 2:
    task_ds = dict(action = dict())

    # Test 2.1:
    action = None
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (action, dict(), None)

    # Test 2.2:
    action = 'shell'
    parser = ModuleArgsParser(task_ds, collection_list=[action])
    assert parser.parse() == (action, dict(), None)

    # Test 2

# Generated at 2022-06-11 08:50:03.375844
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'copy'
    args = {'src': 'a', 'dest': 'b'}

    task_ds = {'action': 'copy: src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert (action, args, None) == parser.parse()

    task_ds = {'action': {'copy': 'src=a dest=b'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert (action, args, None) == parser.parse()

    task_ds = {'action': {'copy': {'src': 'a', 'dest': 'b'}}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert (action, args, None) == parser.parse()


# Generated at 2022-06-11 08:50:13.122232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.template import Templar

    # First test
    task_ds = {
        'name': 'hello world',
        'action': 'shell echo hello'
    }
    context = PlayContext()
    loader = AnsibleLoader(basedir='/home/cristian/projects/ansible/parsing')
    collection_list = [col for col in module_loader.all(class_only=True) if hasattr(col, '__rushing__') and getattr(col, '__rushing__')]
    parser = ModuleArgsParser(task_ds, collection_list)
    result = parser.parse()

# Generated at 2022-06-11 08:50:20.140084
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # creating an instance of the class ModuleArgsParser inorder to test the
    # method parse

    parser = ModuleArgsParser()
    # creating a dummy task inorder to test the method parse
    task = {
            "when": "pass",
            "name": "create user",
            "shell": {"command": "useradd -m -s /bin/bash -p"+
                      " {{App_user_password}} {{App_user}}"}}

    # calling the method parse inorder to test
    parser.parse(task)

# Generated at 2022-06-11 08:50:23.306759
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    # test the method
    args, kwargs = parser.parse()
    assert (args == ())
    assert (kwargs == {})

# Generated at 2022-06-11 08:50:31.618502
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # for more test cases, see the unit tests in test/unit/test_utils.py
    # for the parse_kv method. This just covers the fuzzier forms of
    # module invocation.

    def assertTask(task, expected_action, expected_args, expected_delegate_to='localhost'):
        p = ModuleArgsParser(task)
        (action, args, delegate_to) = p.parse()
        assert action == expected_action, "Expected action '%s', got '%s' for task %s" % (expected_action, action, task)
        assert args == expected_args, "Expected args '%s', got '%s' for task %s" % (expected_args, args, task)

# Generated at 2022-06-11 08:50:39.834023
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  parser = ModuleArgsParser()
  # Test for TypeError:
  test_task_ds = {'action': {'copy': 'src=a dest=b'}}
  result = parser.parse(test_task_ds)
  # Test for ValueError:
  test_task_ds = {'action': 'copy src=a dest=b'}
  result = parser.parse(test_task_ds)
  # Test for IndexError:
  test_task_ds = {'action': {'copy': {'ansible_ssh_pass': 'xyz'}}}
  result = parser.parse(test_task_ds)
  # Test for None:
  test_task_ds = {'action': {'copy': None}}
  result = parser.parse(test_task_ds)
  # Test for AssertionError:

# Generated at 2022-06-11 08:50:48.725463
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell', 'args': 'ls', 'delegate_to': 'localhost'}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to == 'localhost'

    task_ds = {'action': {'module': 'shell', 'args': 'ls', 'chdir':'/'}}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {'chdir': '/'}
    assert delegate_to is None

    task_ds = {'action': 'shell ls', 'delegate_to': 'localhost'}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action

# Generated at 2022-06-11 08:50:58.279031
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    run_test = LoaderModuleMock(None, [], True, False)

    test_data_arguments = {
        "action": "shell",
        "delegate_to": "{{ inventory_hostname }}",
        "args": {
            "chdir": "/tmp",
            "warn": False,
            "creates": "/tmp/test",
            "executable": "/bin/sh",
            "removes": "/tmp/test"
        }
    }

    module_args_parser = ModuleArgsParser(test_data_arguments, run_test)
    action, args, delegate_to = module_args_parser.parse()

    assert action == 'shell'

# Generated at 2022-06-11 08:51:08.291134
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    factory = Factory()
    loader = DataLoader()

    task_ds = {
        "action": {
            "module": "ec2",
            "foo": "bar"
        },
        "delegate_to": "foo",
        "args": "foobar",
        "register": "foo"
    }

    expected_action = 'ec2'
    expected_args = {'delegate_to': 'foo', 'args': 'foobar', 'register': 'foo', 'foo': 'bar'}
    expected_delegate_to = 'foo'

    p = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = p.parse()

    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to

# Generated at 2022-06-11 08:51:14.453119
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser(task_ds={})
    module_args_parser.parse()
    return

# Generated at 2022-06-11 08:51:16.600062
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # This test doesn't make sense. Should be removed.
    # Raises AssertionError("unexpected parameter type in action: %s" % type(thing))
    pass


# Generated at 2022-06-11 08:51:23.407372
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # ansible/lib/ansible/plugins/loader.py
    def load_plugins(directory, class_name, package=''):
      return []

    # ansible/lib/ansible/modules/__init__.py
    builtin_module_names = []

    # ansible/lib/ansible/module_utils/__init__.py
    # noop

    # ansible/lib/ansible/module_utils/six/__init__.py
    class MetaPathImporter(object):
        def find_module(self, fullname, path=None):
          if fullname == 'ansible.module_utils':
            return self
          return None
        def load_module(self, name):
          if name == 'ansible.module_utils':
            import ansible.module_utils
            return ansible.module

# Generated at 2022-06-11 08:51:25.567347
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse()
    assert (True) # built in test


# Generated at 2022-06-11 08:51:32.931339
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_plugin_loader.add_directory(os.path.join(DATA_PATH, 'test_action_plugin'))
    module_loader.add_directory(DATA_PATH)
    task_string = u"""
    {
        "action": "test.action_plugin"
    }
    """
    task = AnsibleTask.load(task_string)
    parser = ModuleArgsParser(task_ds=task._attributes, collection_list=[])
    action, args, delegate_to = parser.parse()
    assert action == "test.action_plugin"
    assert args == {}
    assert delegate_to is None


# Generated at 2022-06-11 08:51:43.787635
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:51:54.574869
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.utils.addresses import parse_address

    # unit testing parse method
    def test_parse_method(expect, input_dict):
        parser = ModuleArgsParser(task_ds=input_dict)
        output = parser.parse()
        assert output == expect

    test_parse_method(expect=('debug', {'msg': 'parsed'}, Sentinel),
                      input_dict={'action': {'module': 'debug msg=parsed'}})

    test_parse_method(expect=('set_fact', {'ansible_host': 'all'}, 'remote'),
                      input_dict={'set_fact': {'ansible_host': 'all'},
                                  'delegate_to': 'remote'})

    test

# Generated at 2022-06-11 08:52:04.661751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # Call method parse of class ModuleArgsParser
    obj = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': 'default'})
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'default'
    # Call method parse of class ModuleArgsParser
    obj = ModuleArgsParser(task_ds={'action': 'shell echo hi', 'delegate_to': 'default'})
    action, args, delegate_to = obj.parse()
    assert action == 'shell'

# Generated at 2022-06-11 08:52:14.912324
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class args:
        pass

    args.collection_paths = '/home/ansible/collections'

    the_task = dict(action=dict(module='copy', src='a', dest='b'))
    module_parser = ModuleArgsParser(the_task, collection_list=[])
    result = module_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    the_task = dict(action='copy src=a dest=b')
    module_parser = ModuleArgsParser(the_task, collection_list=[])
    result = module_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    the_task = dict(action=dict(module='copy', src='a', dest='b'))

# Generated at 2022-06-11 08:52:25.998479
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up mock objects
    loader = Mock()
    loader.load_from_file.return_value = dict(task_ds=None, collection_list=None)

    # Test all paths through parse in class ModuleArgsParser
    testargs = [dict(task_ds=None, collection_list=None)]
    for args in testargs:
        # Instantiate the parser
        parser = ModuleArgsParser(**args)

    # Instantiate loader
    loader = DataLoader()
    action_loader = ActionModuleLoader(loader=loader, class_cache={})
    module_loader = ModuleLoader(loader=loader, class_cache={})

    # Load task1.yaml
    task_data = loader.load_from_file('./test/integration/targets/templates/task1.yaml')

    # Test all paths through

# Generated at 2022-06-11 08:52:44.363559
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    
    a = dict(action='copy', src='{{ src }}')
    t = ModuleArgsParser(a, None)
    assert t.parse() == ('copy', {u'src': u'{{ src }}'}, None)
    
    a = dict(action='copy src={{ src }} dest={{ dest }}')
    t = ModuleArgsParser(a, None)
    assert t.parse() == ('copy', {u'src': u'{{ src }}', u'dest': u'{{ dest }}'}, None)
    
    a = dict(action='copy', args=dict(src='{{ src }}', dest='{{ dest }}'))
    t = ModuleArgsParser(a, None)
    assert t.parse() == ('copy', {u'src': u'{{ src }}', u'dest': u'{{ dest }}'}, None)

# Generated at 2022-06-11 08:52:50.405397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

        from ansible.parsing.yaml.objects import AnsibleUnicode
        from ansible.errors import AnsibleParserError
        from ansible.vars.unsafe_proxy import AnsibleUnsafeText
        from units.mock.loader import DictDataLoader

        # Arrange
        task_ds = dict(action='shell', args='name=git')
        # Act
        module_parser = ModuleArgsParser(task_ds=task_ds,
                                                 collection_list=None)
        # Assert
        assert module_parser.parse() == ('shell', {}, None)

# Generated at 2022-06-11 08:52:55.568987
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = dict(
        action='ec2',
        delegate_to='localhost',
        args='region=xyz',
        with_items='manifest'
    )
    p = module_args_parser.parse(task_ds)
    assert p == ('ec2',{'region': 'xyz'}, 'localhost')
    module_args_parser = ModuleArgsParser()
    p = module_args_parser.parse(task_ds, skip_action_validation=True)
    assert p == ('ec2',{'region': 'xyz'}, 'localhost')

# Generated at 2022-06-11 08:53:03.325358
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ''' Unit test for method parse of class ModuleArgsParser. '''

    # Test with more conditions.
    # Test with different values.
    # Test with more exceptions.
    # Test with more arguments.
    # Test with more class interactions.

    # Test with more exception.
    with pytest.raises(AnsibleParserError) as excinfo:
        parser = ModuleArgsParser(None, None)
        parser.parse()
    assert 'unexpected parameter type' in str(excinfo.value)

    # Test with ModuleArgsParser()
    with pytest.raises(AnsibleParserError) as excinfo:
        ModuleArgsParser()
    assert '__init__() takes at' in str(excinfo.value)

    # Test with a valid task_ds.

# Generated at 2022-06-11 08:53:03.958346
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-11 08:53:10.239400
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = u'command'
    args = {'testargs': {'chdir': u'/tmp'}}
    delegate_to = u'localhost'
    test_ds = {
        'action': {
            'command': 'pwd',
            'args': {
                'chdir': '/tmp'
            }
        },
        'delegate_to': delegate_to
    }
    test_parser = ModuleArgsParser(test_ds)
    result = test_parser.parse()
    assert result == (action, args, delegate_to)

# Generated at 2022-06-11 08:53:16.575208
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: method name is changed
    # FIXME: item is changed
    # FIXME: action is changed
    # FIXME: value is changed
    # FIXME: item is changed
    # FIXME: thing is changed
    # FIXME: action is changed
    # FIXME: skip_action_validation is changed
    # FIXME: value is changed
    # FIXME: item is changed
    # FIXME: thing is changed
    # FIXME: context is changed
    # FIXME: is_action_candidate is changed
    # FIXME: bad_action is changed
    pass

# Generated at 2022-06-11 08:53:21.870399
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task_ds = {u'apt': {u'name': u'tor', u'update_cache': u'yes'}}
    (action, args, delegate_to) = parser.parse(task_ds)
    assert action == u'apt'
    assert args['name'] == u'tor'
    assert args['update_cache'] == u'yes'

# Generated at 2022-06-11 08:53:32.677075
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'cmd': 'echo 123', 'register': 'shell_output'},
                                          collection_list={})
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'command'
    assert args.get('_raw_params') == 'echo 123'
    assert delegate_to == Sentinel

    module_args_parser = ModuleArgsParser(task_ds={'static': 'yes', 'local_action': 'command echo 123'},
                                          collection_list={})
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'command'
    assert args.get('_raw_params') == 'echo 123'
    assert delegate_to == 'localhost'
