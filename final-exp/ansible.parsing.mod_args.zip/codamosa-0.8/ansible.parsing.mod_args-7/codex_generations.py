

# Generated at 2022-06-11 08:43:49.569361
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = dict(
        action='shell',
        args='echo hi',
        local_action='shell',
        delegate_to='localhost',
        module='shell',
        abc='echo hi'
    )
    parser = ModuleArgsParser(data, None)

    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')


# Generated at 2022-06-11 08:43:56.132040
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = None
    actions = ('action', 'local_action')
    action = actions[0]
    delegate_to = None
    additional_args = dict()

    for action in actions:
        thing = dict(action=dict(module=action))
        parser = ModuleArgsParser(thing)
        ret = parser.parse()
        assert ret == (action, None, None)

    thing = dict(action=dict(module='shell', echo='hi', no_log=True))
    parser = ModuleArgsParser(thing)
    ret = parser.parse()
    assert ret == ('shell', dict(echo='hi', no_log=True), None)

    thing = dict(action=dict(module='shell', echo='hi', no_log=True))
    parser = ModuleArgsParser(thing)
    ret = parser.parse()

# Generated at 2022-06-11 08:44:05.104094
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    task_ds = get_mock_task_ds()
    task_ds = {'action': 'shell echo hi'}
    collection_list = get_mock_collection_list()
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    res = module_args_parser.parse()
    assert res[0] == 'shell'
    assert res[1]['_raw_params'] == 'echo hi'


# ===========================================
# Main section


# Generated at 2022-06-11 08:44:09.361705
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(not_task=dict(a=1, b=2, c=3), not_task2=dict(d=4, e=5, f=6))
    module_args_parser = ModuleArgsParser(task)
    module_args_parser.parse(skip_action_validation=True)

# Generated at 2022-06-11 08:44:16.355567
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from ansible.errors import AnsibleParserError
  from ansible.module_utils._text import to_text
  task_ds=None
  parser=ModuleArgsParser(task_ds,collection_list=None)
  if parser.parse(skip_action_validation=False) is None:
    return False
  if parser.parse(skip_action_validation=True) is None:
    return False
  return True

__all__ = ['ModuleArgsParser','test_ModuleArgsParser_parse']

# Generated at 2022-06-11 08:44:26.726980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Input data
    # 1st test case
    task_ds_1 = {
        'tasks': [{
            'action': {
                'module': 'copy',
                'src': 'a',
                'dest': 'b'
            }
        }]
    }
    # 2nd test case
    task_ds_2 = {
        'tasks': [{
            'action': 'copy src=a dest=b'
        }]
    }
    # 3rd test case
    task_ds_3 = {
        'tasks': [{
            'action': {
                'module': 'copy',
                'src': 'a',
                'dest': 'b'
            },
            'args': '{{test_args}}'
        }]
    }
    # 4th test case
    task

# Generated at 2022-06-11 08:44:30.648475
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    # Test the case when task_ds is None
    assert parser.parse() == ('', '', None)
    # Test the case when task_ds is empty dict
    assert parser.parse(task_ds={}) == ('', '', None)


# Generated at 2022-06-11 08:44:41.567438
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with raw_param modules
    fake_loader = DictDataLoader({
        'hosts': '''
        [local]
        localhost

        [database]
        192.0.2.2

        [web]
        example1.com
        example2.com
        ''',
    })
    inventory = Inventory(loader=fake_loader)

# Generated at 2022-06-11 08:44:49.678292
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    assert parser._split_module_string('copy src=a dest=b') == ('copy', 'src=a dest=b')
    assert parser._split_module_string('copy src=a') == ('copy', 'src=a')
    assert parser._split_module_string('copy') == ('copy', '')
    assert parser._normalize_parameters('echo hi') == ('echo', {'_raw_params': 'hi'})
    assert parser._normalize_parameters('echo hi', 'shell') == ('shell', {'_raw_params': 'hi'})
    assert parser._normalize_parameters({'region': 'xyz'}, 'ec2') == ('ec2', {'region': 'xyz'})

# Generated at 2022-06-11 08:44:51.405794
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('Testing ModuleArgsParser.parse()')
    assert False

# Generated at 2022-06-11 08:45:15.035815
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    argument_spec = dict(
        action = dict(required = True),
        args = dict(
            type = dict(),
            default = dict()
        ),
        delegate_to = dict(required = False)
    )

    module = AnsibleModule(argument_spec = argument_spec, supports_check_mode = False)

    raw = dict(
        module = 'shell',
        args = dict(
            chdir = 'c:\\',
            executable = 'C:\\Windows\\system32\\cmd.exe'
        )
    )
    parser = ModuleArgsParser(raw)

    endpoint = parser.parse(skip_action_validation=True)

    assert (endpoint == ('shell', dict(chdir='c:\\', executable='C:\\Windows\\system32\\cmd.exe'), None))


# Generated at 2022-06-11 08:45:19.990051
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'module': 'user', 'name': 'root'}
    action = None
    delegate_to = None
    args = {'name': 'root'}

    parser = ModuleArgsParser(task_ds, collection_list=None)
    result = parser.parse()
    assert result[0] == action
    assert result[1] == args
    assert result[2] == delegate_to


# Generated at 2022-06-11 08:45:30.226468
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
      Unit test to check method ModuleArgsParser.parse()
    '''
    # Set the method,ModuleArgsParser.parse() input parameters
    # and the expected results.

# Generated at 2022-06-11 08:45:34.983081
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = dict(
        __ansible_module_name__='test',
        __ansible_arguments__=dict(
            shell='echo hello world',
        ),
        _ansible_action=None,
        _ansible_no_log=False
    )

    module_args_parser = ModuleArgsParser(task_ds=dict(
            action=module_args
        ))

    module_args_parser.parse()



# Generated at 2022-06-11 08:45:45.425915
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    host_list = [
        { 'hostname':'server1', 'ip':'1.1.1.1', 'port':'22' },
        { 'hostname':'server2', 'ip':'2.2.2.2', 'port':'22' },
        { 'hostname':'server3', 'ip':'3.3.3.3', 'port':'22' },
        { 'hostname':'server4', 'ip':'4.4.4.4', 'port':'22' }
    ]

    inventory = AnsibleInventory(host_list)
    pattern = 'server[1:2]'
    hosts = inventory.get_hosts(pattern)
    assert(len(hosts) == 2)

    # parse

# Generated at 2022-06-11 08:45:55.383248
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:46:01.685174
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = {u'action': {u'module': u'file', u'path': u'/tmp/file_mode0644'}, u'name': u'Change mode of /tmp/file_mode0644'}
  collection_list = [u'collections']
  parser = ModuleArgsParser(task_ds, collection_list)
  action, args, delegate_to = parser.parse()
  assert action == 'file'
  #assert args == {'path': '/tmp/file_mode0644'}
  assert delegate_to == 'localhost'

# Generated at 2022-06-11 08:46:10.374438
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ######################################################################
    #  test case 1, simple format
    ######################################################################
    # test whether the 'ping' task can be resolved as a module
    task_ds = dict(action="ping")
    args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = args_parser.parse()
    expected_action = "ping"
    expected_args = None
    expected_delegate_to = None
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to

    ######################################################################
    #  test case 2, basic format
    ######################################################################
    # test whether the 'copy' module can be resolved as a module

# Generated at 2022-06-11 08:46:13.928641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # set up
    task_ds = {}
    collection_list = None
    instance = ModuleArgsParser(task_ds, collection_list)
    # action
    action, args, delegate_to = instance.parse()
    # assert
    assert action is None
    assert args == {}
    assert delegate_to is None

# Generated at 2022-06-11 08:46:22.793030
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = {'action': 'echo "Hello World"',
            'args': {'warn': 'no'},
            'delegate_to': 'localhost'}
    module_loader = MockModuleLoader()
    collection_list = None
    module_args_parser = ModuleArgsParser(task,
                                          collection_list=collection_list)
    assert ['echo "Hello World"', {'warn': 'no'}, 'localhost'] == module_args_parser.parse()

    task = {'action': 'copy src={{ var_source }} dest={{ var_dest }}',
            'args': {'warn': 'no'},
            'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task,
                                          collection_list=collection_list)

# Generated at 2022-06-11 08:46:42.678649
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser({
        'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'ignore_errors': True
    })
    assert parser._split_module_string('copy src=a dest=b') == ('copy', 'src=a dest=b')
    assert parser._normalize_parameters(
        {'module': 'copy', 'src': 'a', 'dest': 'b'},
        action='copy', additional_args={}
    ) == ('copy', {'src': 'a', 'dest': 'b'})
    assert parser._normalize_new_style_args(
        {'module': 'copy', 'src': 'a', 'dest': 'b'}, action='copy'
    ) == {'src': 'a', 'dest': 'b'}
    assert parser

# Generated at 2022-06-11 08:46:52.097591
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tokens = dict(
        shell='ping 127.0.0.1',
        raw_shell='ping 127.0.0.1',
        complex=dict(
            src='/tmp/source.txt',
            dest='/tmp/destination.txt',
        ),
        command='/usr/bin/uptime',
    )
    # Test with delegate_to
    task_ds = dict(
        delegate_to='localhost',
        shell=tokens['shell'],
    )
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict()
    assert delegate_to == 'localhost'
    # Test without delegate_to

# Generated at 2022-06-11 08:46:57.760532
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({
        'module': 'copy',
        'args': {'src':'a', 'dest': 'b'},
        'names': ['name1', 'name2']
        })
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src':'a', 'dest': 'b'}
    assert delegate_to is None


# Generated at 2022-06-11 08:47:02.270363
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action='some_action')
    thing = None
    action = None
    delegate_to = 'localhost'
    args = dict()
    obj = ModuleArgsParser(task_ds=task_ds, collection_list='collection_list')
    assert (obj.parse()) == (action, args, delegate_to)
# Test for class ModuleArgsParser



# Generated at 2022-06-11 08:47:08.444162
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {
            'module': 'shell',
            'args': 'pwd'
        },
        'become': True,
        'become_user': 'user'
    }
    collection_list = ['ansible.builtin.shell']

    ds = ModuleArgsParser(task_ds, collection_list=collection_list)
    (action, args, delegate_to) = ds.parse()

    assert action == 'shell'
    assert args == {'_uses_shell': True, '_raw_params': 'pwd'}
    assert delegate_to == Sentinel

# Generated at 2022-06-11 08:47:17.362857
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# class Loader:
#     '''
#     loaders are responsible for discovering and loading data from a given
#     path.  They know how to find data given a set of variables, and they
#     also know how to write that data.
#     '''
#
#     CACHE_PLUGINS = C.DEFAULT_CACHE_PLUGIN
#
#     def __init__(self, module_cache=False, cache_max_age=C.DEFAULT_CACHE_PLUGIN_CONNECTION, *args, **kwargs):
#         self._module_cache = module_cache
#         self.cache_plugin = self.CACHE_PLUGINS
#         self._cache_max_age = cache_max_age
#         self._module_name_from_path_cache =

# Generated at 2022-06-11 08:47:26.931937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'debug'
    args = dict(_raw_params='msg={{ inventory_hostname }}')
    delegate_to = 'localhost'
    task_ds = {
        'action': action,
        'args': args
    }
    parser = ModuleArgsParser(task_ds)
    normalize_action, normalize_args, normalize_delegate_to = parser.parse()
    assert action == normalize_action
    assert args == normalize_args
    assert delegate_to == normalize_delegate_to

    action = 'debug'
    args = dict(_raw_params='msg={{ inventory_hostname }}')
    delegate_to = 'localhost'
    task_ds = {
        'local_action': action,
        'args': args
    }
    parser = ModuleArgsParser(task_ds)
   

# Generated at 2022-06-11 08:47:37.442689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    things = (
        dict(action=dict(module='copy', src='a', dest='b')),
        dict(action='copy src=a dest=b'),
        dict(module='copy src=a dest=b'),
        dict(module='copy', args=dict(src='a', dest='b')),
        dict(copy='src=a dest=b'),
        dict(module='shell', args='cd /tmp; pwd'),
        dict(module='shell', args='{{inventory_dir}}'),
        dict(module='shell', cd='/tmp', args='pwd'),
        dict(module='shell', _raw_params='{{ inventory_dir }}')
    )

    for thing in things:
        parser = ModuleArgsParser(task_ds=thing)
        (action, args, delegate_to) = parser.parse()
       

# Generated at 2022-06-11 08:47:47.279772
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict(
        action=dict(
            module="ping",
            _raw_params="a=b c=d",
            _uses_shell=True
        ),
        name="ping",
        register="pong",
        ignore_errors=True
    )
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse()
    assert isinstance(action, sentinel.Missing)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, sentinel.Missing)
    action, args, delegate_to = parser.parse(ds)
    assert isinstance(action, sentinel.Missing)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, sentinel.Missing)

# Generated at 2022-06-11 08:47:59.607884
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # mock up module loader
    mock_module_loader = Mock()
    mock_module_loader.find_plugin_with_context = Mock(return_value='check_mode')
    mock_module_loader.module_name_for_class_name = Mock(return_value='check_mode')
    

# Generated at 2022-06-11 08:48:17.107323
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': 'shell'})
    assert parser.parse() == ('shell', {}, None)

    parser = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'chdir': '/tmp'}})
    assert parser.parse() == ('shell', {'chdir': '/tmp'}, None)

    parser = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'chdir': '/tmp'}})
    assert parser.parse() == ('shell', {'chdir': '/tmp'}, None)

    parser = ModuleArgsParser(task_ds={'action': 'shell', 'args': 'chdir=/tmp'})
    assert parser.parse() == ('shell', {'chdir': '/tmp'}, None)


# Generated at 2022-06-11 08:48:26.528569
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict()
    ds['delegate_to'] = 'localhost'
    ds['action'] = 'shell'
    ds['local_action'] = 'copy src=a dest=b'

    m = ModuleArgsParser(task_ds=ds)
    m._normalize_old_style_args = mock.MagicMock()
    m._normalize_parameters = mock.MagicMock()
    m.parse()

    assert m._normalize_old_style_args.call_count == 0

    assert m._normalize_parameters.call_count == 2
    assert m._normalize_parameters.call_args_list[0] == mock.call('shell', action='shell')

# ==============================================================================


# Generated at 2022-06-11 08:48:37.298236
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Instantiate a MockTask
    task = MockTask()

    # Instantiate a ModuleArgsParser with valid task_ds
    parser = ModuleArgsParser(task_ds=task.task_ds, collection_list=task.collection_list)

    # Test the positive case
    assert parser.parse() == ('command', {'_ansible_check_mode': True, '_ansible_no_log': False, '_uses_shell': True, '_raw_params': 'pwd', 'chdir': '/tmp'}, Sentinel)

    # Test the negative case where task_ds is None
    try:
        ModuleArgsParser(task_ds=None)
    except AnsibleAssertionError as err:
        assert str(err) == "the type of 'task_ds' should be a dict, but is a NoneType"

# Unit test

# Generated at 2022-06-11 08:48:42.272699
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    testargs = {}
    testargs[0] = ModuleArgsParser()
    testargs[1] = ModuleArgsParser(task_ds=None)
    testargs[2] = ModuleArgsParser(task_ds=None, collection_list=None)

    for i in range(0, 3):
        obj = testargs[i]
        assert obj.parse() is None


# Generated at 2022-06-11 08:48:43.906395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # assert ModuleArgsParser.parse('params') == 'params'
    assert True # TODO: implement your test here



# Generated at 2022-06-11 08:48:53.959041
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common._collections_compat import MutableMapping, Mapping
    from ansible.playbook.play_context import PlayContext

    def create_instance(task_ds=None, collection_list=None):
        if task_ds is None:
           task_ds = {}
        if collection_list is None:
           collection_list = []
        return ModuleArgsParser(task_ds, collection_list)

    # test the sanity of the test case data
    # ensure that the test case data matches the validation function's signature
    def is_valid_ModuleArgsParser_parse_arguments(task_ds, collection_list):
        if not isinstance(task_ds, MutableMapping):
            return False

        if not isinstance(collection_list, list):
            return False

        return True


# Generated at 2022-06-11 08:49:05.582559
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser()
    data = dict()
    data["action"] = "shell echo hi"
    data["local_action"] = "shell echo hi"
    data["module"] = "shell echo hi"
    data["args"] = "echo 'echo hi'"
    cl = CollectionLoader()
    data["collection_list"] = cl
    data["skip_action_validation"] = False


# Generated at 2022-06-11 08:49:07.043171
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser()
    mp.parse()

# Generated at 2022-06-11 08:49:15.602286
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    from ansible.plugins.action import ActionBase
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)

    tc = TestCase()

    testdir = os.path.dirname(__file__)
    testdir = os.path.abspath(testdir)
    testdir = os.path.join(testdir, 'fixtures', 'test_module_args_parse', '')

    # test action plugins
    for fixture in glob.glob(os.path.join(testdir, 'action', '*.json')):
        target_func = os.path.splitext(os.path.basename(fixture))[0]

# Generated at 2022-06-11 08:49:17.085755
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    raise NotImplementedError


# Generated at 2022-06-11 08:49:30.702902
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("testing: ModuleArgsParser parse")
    module_args_parser = ModuleArgsParser(task_ds={'module': 'shell',
                                                   'args': 'pwd'})
    try:
        result = module_args_parser.parse()
        assert result == ('shell', {'_raw_params': 'pwd'}, None), "result is wrong"
    except Exception as err:
        print("UNEXPECTED EXCEPTION RAISED: " % err)
        assert False, "unexpected exception"
    print("SUCCESS: ModuleArgsParser parse")


# Generated at 2022-06-11 08:49:38.959975
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_module_args_parser_parse: task: PlaybookTask(name=action, action=None, args=dict(), delegate_to=None)
    task = PlaybookTask(name='action', action=None, args=dict(), delegate_to=None)
    task._ds = {'action': 'shell echo hi'}
    task.hostvars = None
    # test_module_args_parser_parse: action: shell
    # test_module_args_parser_parse: args: {'_raw_params': 'echo hi'}
    # test_module_args_parser_parse: delegate_to: None
    action, args, delegate_to = ModuleArgsParser(task_ds=task._ds).parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
   

# Generated at 2022-06-11 08:49:42.179538
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = list()
    obj = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleAssertionError):
        obj.parse()


# Generated at 2022-06-11 08:49:53.525511
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
      unit test for method parse of class ModuleArgsParser
    '''
    m = ModuleArgsParser(task_ds={'action': 'echo hi'})
    assert m.parse() == ('echo hi', {}, None)

    m = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert m.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    m = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b',
                                  'args': {'mode': '0700'}})
    assert m.parse() == ('copy', {'src': 'a', 'dest': 'b', 'mode': '0700'}, None)


# Generated at 2022-06-11 08:50:02.317116
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """ Test for ModuleArgsParser.parse """
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    ModuleArgsParser.parse()

    # Invalid type for task_ds
    task_ds=["a", "b", "c"]
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser.parse(task_ds)

    # If we didn't see any module in the task at all, it's not a task really
    task_ds={}
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser.parse(task_ds)

    # If we didn't see any module in the task at all, it's not a task really
    task_ds={"task": "a_valid_task"}

# Generated at 2022-06-11 08:50:10.078270
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test for method parse(self, skip_action_validation=False)
    # of class ModuleArgsParser
    # Test with a task to copy with local_action and src=a dest=b
    task = {}
    task['delegate_to'] = ''
    task['args'] = ''
    task['action'] = ''
    task['local_action'] = 'copy src=a dest=b'
    module_args_parser = ModuleArgsParser(task)
    module_args_parser.parse()
    assert module_args_parser._task_ds["local_action"] == 'copy src=a dest=b'


# Generated at 2022-06-11 08:50:11.072926
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass  # noqa


# Generated at 2022-06-11 08:50:21.514667
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:50:26.690734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Fixtures for the test in the form ((task_ds, collection_list, skip_action_validation), expected_result)
    '''
    test_cases = (
        ({"action": "shell echo hi"}, 0),
    )
    for test_case, expected_result in test_cases:
        module_args_parser = ModuleArgsParser(test_case)
        result = module_args_parser.parse()
        assert result == expected_result


# Generated at 2022-06-11 08:50:29.693009
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    module_args_parser = ModuleArgsParser()
    parser_result = module_args_parser.parse()
    assert parser_result is None


# Generated at 2022-06-11 08:50:50.972686
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method ModuleArgsParser.parse 
    Coverage: 100%
    """
    # prepare test data
    task_ds = dict()
    collection_list = list()
    # test prepare data above
    assert isinstance(task_ds, dict)
    assert isinstance(collection_list, list)
    # run test
    parser = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(parser, ModuleArgsParser)
    # test method parse
    (action, args, delegate_to) = parser.parse()
    assert action == None
    assert isinstance(args, dict)
    assert delegate_to == Sentinel
    # test method parse with special data
    parser = ModuleArgsParser()
    (action, args, delegate_to) = parser.parse()
    assert action == None
    assert isinstance

# Generated at 2022-06-11 08:51:00.669185
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()

    # Test parsing with correct formats
    assert parser.parse({'action': 'shell echo hi'}) == ('shell', {'_raw_params': 'echo hi'}, None)
    assert parser.parse({'action': 'command /tmp'}) == ('command', {'_raw_params': '/tmp'}, None)
    assert parser.parse({'action': 'command echo hi'}) == ('command', {'_raw_params': 'echo hi'}, None)
    assert parser.parse({'action': 'command chdir=/tmp echo hi'}) == ('command', {'chdir': '/tmp', '_raw_params': 'echo hi'}, None)

# Generated at 2022-06-11 08:51:05.099214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  _task_ds = {
      'action': 'shell',
      'args': 'echo 1'
  }
  module_args_parser = ModuleArgsParser(_task_ds)
  assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo 1'}, None)


# Generated at 2022-06-11 08:51:15.521138
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test original implementation
    task_ds = { 'action': { 'module': 'copy', 'src': 'a', 'dest': 'b' }}
    expected = ('copy', { 'src': 'a', 'dest': 'b'}, None)
    assert expected == ModuleArgsParser(task_ds).parse()

    # Test the case that there is localtion
    task_ds = { 'local_action': { 'module': 'copy', 'src': 'a', 'dest': 'b' }}
    expected = ('copy', { 'src': 'a', 'dest': 'b'}, 'localhost')
    assert expected == ModuleArgsParser(task_ds).parse()

    # Test the case that there is localtion
    task_ds = { 'local_action': { 'copy': { 'src': 'a', 'dest': 'b' }}}
   

# Generated at 2022-06-11 08:51:16.758308
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    collection_list = None
    instance = ModuleArgsParser()
    instance.parse()

# Generated at 2022-06-11 08:51:23.493547
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():# pylint: disable=no-self-use
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    _task_attrs = set(Task._valid_attrs.keys())
    _task_attrs.update(set(Handler._valid_attrs.keys()))
    _task_attrs.update(['local_action', 'static'])
    _task_attrs = frozenset(_task_attrs)
    object_ = ModuleArgsParser()
    args = {'arg1': 'arg1 val'}
    # Check if type error raised when arg1 type is not dict

# Generated at 2022-06-11 08:51:29.569691
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Setup for test
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    parser = ModuleArgsParser(task_ds)
    # Test parse method
    assert parser.parse() == ('shell', {'chdir': '/tmp', '_raw_params': 'echo hi'}, 'localhost')
    # Teardown for test
    del task_ds
    del parser



# Generated at 2022-06-11 08:51:40.202928
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-11 08:51:47.265669
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    module_args_parser = ModuleArgsParser(task_ds={'module':'module', 'delegate_to':'localhost',
                                                   'args':'args', 'action':'action', 'local_action':'local_action'})
    assert module_args_parser.parse(skip_action_validation=True) == ('local_action', {}, 'localhost'), (module_args_parser.parse(skip_action_validation=True))



# Generated at 2022-06-11 08:51:55.696801
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {
        'action': 'copy src={{ src_dir }} dest={{ dest_dir }}',
        'delegate_to': '{{ delegate_to }}'
    }
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'shell'  # expected result
    assert args == {'dest': '{{ dest_dir }}', 'src': '{{ src_dir }}'}  # expected result
    assert delegate_to == '{{ delegate_to }}'  # expected result


# create module args

# Generated at 2022-06-11 08:52:18.421920
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    basic_task_ds = dict(
        delegate_to='{{inventory_hostname}}',
        action=dict(
            module='shell',
            args='mkdir /etc/ansible/roles',
            creates='/etc/ansible/roles',
            become=True
        )
    )

# Generated at 2022-06-11 08:52:28.712740
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs = frozenset(task_attrs)
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])

    task_ds = { "a": 1, "b": 2, "c": 3, "action": "copy: src=a dest=b" }
    p = ModuleArgsParser(task_ds, collection_list=None)
    (action, args, delegate_to)

# Generated at 2022-06-11 08:52:34.917600
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test of the general parse method
    module = ModuleArgsParser(task_ds = {'foo': 'bar'})

    (actual_action, actual_args, actual_delegate_to) = module.parse()

    assert actual_action == None
    assert actual_args == dict()
    assert actual_delegate_to == None

    module = ModuleArgsParser(task_ds = {'action': 'not a real command'})
    with pytest.raises(AnsibleParserError) as excinfo:
        (actual_action, actual_args, actual_delegate_to) = module.parse()

    assert 'couldn\'t resolve module/action' in str(excinfo)
    assert 'This often indicates a misspelling' in str(excinfo)
    assert 'module/action' in str(excinfo)

    module = Module

# Generated at 2022-06-11 08:52:45.024809
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = dict(
        action='command',
        args=dict(
            warn=True,
            _raw_params='/bin/false',
        ),
        delegate_to='localhost',
    )
    parser = ModuleArgsParser(task_ds=t, collection_list=None)

    action, args, delegate_to = parser.parse()

    f = 'test_ModuleArgsParser.test_parse'
    assert action == 'command', "%s: got: %s" % (f, action)
    assert args == {'_raw_params': '/bin/false', 'warn': True}, "%s: got: %s" % (f, args)
    assert delegate_to == 'localhost', "%s: got: %s" % (f, delegate_to)

    # now try an old-style task, with "action: copy src

# Generated at 2022-06-11 08:52:45.597288
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-11 08:52:51.054093
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class_ = ModuleArgsParser
    method = 'parse'
    # Expecting: (action, args, delegate_to)
    thing = None
    action = None
    additional_args = None
    delegate_to = None

    # Mock tasks module
    patcher = patch("ansible.module_utils.common.task.tasks.tasks")
    mock_tasks = patcher.start()
    # Mock action_loader
    patcher = patch("ansible.module_utils.common.task.action_loader")
    mock_action_loader = patcher.start()
    # Mock module_loader
    patcher = patch("ansible.module_utils.common.task.module_loader")
    mock_module_loader = patcher.start()
    # Mock _task_ds

# Generated at 2022-06-11 08:52:57.140392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock

    test_module_loader = mock.MagicMock(spec_set=ModuleLoader)
    test_module_loader.get_all_plugin_loaders.return_value = []
    test_action_loader = mock.MagicMock(spec_set=ActionModuleLoader)
    test_action_loader.get_all_plugin_loaders.return_value = []
    test_collection_list = mock.MagicMock()


# Generated at 2022-06-11 08:53:02.899914
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {'local_action': {'shell': 'echo hi'}, 'delegate_to': 'me'}
    cap = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = cap.parse()

    assert action == 'shell'
    assert delegate_to == 'me'
    assert args == {}

ds = {'local_action': {'shell': 'echo hi'}, 'delegate_to': 'me'}
cap = ModuleArgsParser(task_ds=ds)
action, args, delegate_to = cap.parse()

# Generated at 2022-06-11 08:53:11.502277
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.cli.adhoc
    import ansible.module_utils.basic
    from ansible.module_utils.common.collections import ImmutableDict
    # Setup
    m = ModuleArgsParser()

    # Check that _split_module_string method works if we pass a valid module string
    # thing = { region: {x: 2, y: 3} }
    test_str = 'ec2 region=us-east-1'
    module_name, args_str = m._split_module_string(test_str)
    assert module_name == 'ec2'
    assert args_str == 'region=us-east-1'

    # Check that _normalize_new_style_args method works if we pass a valid dictionary
    thing = {'x': 1}
    normalized_thing = m._normalize_new

# Generated at 2022-06-11 08:53:20.516165
# Unit test for method parse of class ModuleArgsParser