

# Generated at 2022-06-23 04:50:35.699789
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(action=dict(module='copy', args='src=a dest=b'))
    parser = ModuleArgsParser(task_ds=data)
    assert parser._task_ds['action'] == dict(args='src=a dest=b', module='copy')
    assert parser._task_attrs == frozenset([u'run_once', u'name', u'action', u'first_available_file', u'until', 'static', 'local_action'])
    assert parser._task_ds == {u'action': {u'args': u'src=a dest=b', u'module': u'copy'}}

    data = dict(action='copy src=a dest=b')
    parser = ModuleArgsParser(task_ds=data)

# Generated at 2022-06-23 04:50:48.680049
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = []

    parser = ModuleArgsParser(task_ds, collection_list)
    x = parser.parse()
    assert x[0] is None

    task_ds = {'delegate_to': 'foo'}
    parser = ModuleArgsParser(task_ds, collection_list)
    x = parser.parse()
    assert x[0] is None

    task_ds = {'action': {'shell': 'echo hi'}}
    parser = ModuleArgsParser(task_ds, collection_list)
    x = parser.parse()
    assert x[0] == 'shell'

    task_ds = {'local_action': {'shell': 'echo hi'}}
    parser = ModuleArgsParser(task_ds, collection_list)
    x = parser.parse()
    assert x

# Generated at 2022-06-23 04:51:02.230861
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    task_include_ds = dict()
    task_include_ds['static'] = 'yes'
    task_include_ds['name'] = 'test'
    task_include_ds['action'] = 'copy src=a dest=b'
    task_include_ds['loop'] = '{{test}}'
    task_include_ds['loop_control'] = dict()
    task_include_ds['loop_control']['loop_var'] = 'item'
    task_include_ds['when'] = 'test'
    task_include_ds['delegate_to'] = 'localhost'

# Generated at 2022-06-23 04:51:03.399446
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:51:12.293231
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class Obj:
        def __init__(self):
            self.module_name = 'shell'
            self.action = 'command'
            self.module_args = None
            self.delegate_to = 'localhost'
            self.register = 'ping_result'
            self.raw = False
            self.notify = []

    import sys
    import os
    import json
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    ##################################################################################
    #   FILE    :   test_module_args_parser.py
    #   PURPOSE :   test the functionality of ModuleArgsParser class
    ##################################################################################

    # mock classes for ansible.module_utils.basic.AnsibleModule and
    # ansible.module_utils.parsing.convert_bool


# Generated at 2022-06-23 04:51:17.139015
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser(task_ds={u'action': u'ping'})
    rtn = p.parse()
    assert (rtn == (u'ping', {}, None))

# class AnsibleModule

# Generated at 2022-06-23 04:51:26.528539
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action=dict(action='echo', msg='hello'))
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_str = parser.parse()

    assert action == 'echo', 'The action parsed should be "echo" but is %s' % action
    assert delegate_str is None, 'The delegate should be None but is %s' % delegate_str
    assert len(args) == 1, 'the args length should be 1 but is %s' % len(args)
    assert args['msg'] == 'hello', 'the args msg value should be hello but is %s' % args['msg']


# Generated at 2022-06-23 04:51:38.820276
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds_action = dict(action='shell')
    ds_action_list = dict(action=list('shell'))
    ds_action_int = dict(action=1)
    ds_action_dict = dict(action={})
    ds_action_complex = dict(action={'args': 'echo hi'})
    ds_action_complex_list = dict(action=[{'args': 'echo hi'}])
    ds_shell_dict = dict(shell={'echo': 'hi'})
    ds_shell_list = dict(shell=[{'echo': 'hi'}])
    ds_shell_tup = dict(shell=('echo', 'hi'))
    ds_shell = dict(shell='echo hi')

# Generated at 2022-06-23 04:51:48.634407
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser()

    # testing normalize_parameters
    # testing normalize_old_style_args
    (action, args) = module_arg_parser._normalize_old_style_args("shell echo hi")
    assert action == "shell"
    assert args is None

    (action, args) = module_arg_parser._normalize_old_style_args("shell echo hi")
    assert action == "shell"
    assert args == {}

    # testing normalize_new_style_args
    (action, args) = module_arg_parser._normalize_new_style_args("shell echo hi", "shell")
    assert action == "shell"
    assert args == {"_raw_params": "echo hi"}

    # testing parse
    (action, args, delegate_to) = module_arg

# Generated at 2022-06-23 04:51:57.983996
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"shell": "echo hi"}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is None

    task_ds = {"action": "echo hi"}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is None

    task_ds = {"shell": "echo hi"}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'

# Generated at 2022-06-23 04:52:04.895932
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import module_loader
    from ansible.parsing.yaml import objects
    from ansible.playbook.task import Task
    task_ds = {
        "action": "ping",
        "name": "ping"
    }
    task = Task.load(task_ds, None, None)
    task.validate()
    module_name, args, delegate_to = task.action

    assert module_name == "ping"
    assert args == {}
    assert delegate_to is None

task_ds = {
    "action": "ping",
    "name": "ping"
}
task = Task.load(task_ds, None, None)
task.validate()

# Generated at 2022-06-23 04:52:17.473461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class obj:
        pass

    task_ds = obj()
    task_ds.action = 'command'

    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'command'
    assert args == {}
    assert delegate_to is None

    task_ds.action = 'copy a'
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'
    assert args == {'a': None}
    assert delegate_to is None

    task_ds.action = 'command echo a'
    (action, args, delegate_to) = parser.parse()
    assert action == 'command'
    assert args == {'echo': 'a'}
    assert delegate_to is None


# Generated at 2022-06-23 04:52:28.944496
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task

    task_ds1 = Task.load(dict(action=dict(module='copy', src='/tmp/file1', dest='/tmp/file2')))
    map1 = ModuleArgsParser(task_ds=task_ds1)
    result1 = map1.parse()
    assert result1[0] == 'copy'
    assert result1[1]['src'] == '/tmp/file1'
    assert result1[1]['dest'] == '/tmp/file2'

    task_ds2 = Task.load(dict(action='shell echo hi'))
    map2 = ModuleArgsParser(task_ds=task_ds2)
    result2 = map2.parse()
    assert result2[0] == 'shell'
    assert result2[1]['_raw_params']

# Generated at 2022-06-23 04:52:31.197845
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({})
    assert module_args_parser.parse() == ('ping', {}, None)

# Generated at 2022-06-23 04:52:39.371713
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:46.638936
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:48.454282
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None


# Generated at 2022-06-23 04:53:02.992676
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_task_ds = {}
    my_task_ds_2 = {
        'action': 'shell echo hi',
        'args': 'arg1=val1 arg2=val2',
        'delegate_to': 'localhost'
    }
    my_task_ds_3 = {
        'action': {
            'shell': 'echo hi'
        },
        'delegate_to': 'localhost'
    }
    my_task_ds_4 = {
        'action': 'shell: echo hi',
        'delegate_to': 'localhost'
    }
    my_task_ds_5 = {
        'action': 'shell',
        'local_action': 'shell echo hi'
    }

# Generated at 2022-06-23 04:53:05.323053
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test the constructor of class ModuleArgsParser
    assert ModuleArgsParser()



# Generated at 2022-06-23 04:53:16.609863
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestModuleArgsParser(ModuleArgsParser):
        def __init__(self, task_ds=None, collection_list=None):
            task_ds = {} if task_ds is None else task_ds
            if not isinstance(task_ds, dict):
                raise AnsibleAssertionError("the type of 'task_ds' should be a dict, but is a %s" % type(task_ds))
            self._task_ds = task_ds
            self._collection_list = collection_list
            # delayed local imports to prevent circular import
            from ansible.playbook.task import Task
            from ansible.playbook.handler import Handler
            # store the valid Task/Handler attrs for quick access
            self._task_attrs = set(Task._valid_attrs.keys())

# Generated at 2022-06-23 04:53:22.609363
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = dict(action="ping")
    args_parser = ModuleArgsParser(task_ds)
    assert args_parser._task_ds == task_ds
    assert args_parser._task_attrs == frozenset(['task_include_vars', 'task_has_loop', 'action', 'tags', 'local_action', 'static'])
    assert args_parser.resolved_action is None


# Generated at 2022-06-23 04:53:32.502481
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tester = ModuleArgsParser(
        task_ds={'action': 'copy src=a dest=b'})
    tester.parse()
    assert tester is not None

    tester = ModuleArgsParser(
        task_ds={'action': {'module': 'copy src=a dest=b'}})
    tester.parse()
    assert tester is not None

    tester = ModuleArgsParser(
        task_ds={'action': {'module': 'copy', 'args': 'src=a dest=b'}})
    tester.parse()
    assert tester is not None

    tester = ModuleArgsParser(
        task_ds={'action': {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}}})
    tester.parse()

# Generated at 2022-06-23 04:53:43.324005
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class LoaderMock(object):
        def __init__(self, plugin_list):
            self.plugin_list = plugin_list

        def find_plugin(self, name, class_only=False):
            if isinstance(self.plugin_list, tuple):
                class_only, self.plugin_list = self.plugin_list
                if not class_only:
                    raise Exception('Expected find_plugin to be called with class_only=True')
            if name in self.plugin_list:
                return True
            return False

    def _resolve_action(self, action, templar, all_vars, skip_enable_conditions=False):
        return action_loader.find_plugin(action)

    action_loader.find_plugin_with_context = _resolve_action

    # test of first branch


# Generated at 2022-06-23 04:53:53.798944
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    results = dict()
    obj = ModuleArgsParser(task_ds=None, collection_list=None)
    def mock_parse_kv(thing, check_raw=False):
        if check_raw:
            if thing == 'src=a dest=b':
                return {'src': 'a', 'dest': 'b'}
        else:
            if thing == 'src=a dest=b':
                return {'_raw_params': 'src=a dest=b'}
        return None
    setattr(obj, '_normalize_parameters', lambda a, b, c: (a, b))
    setattr(obj, '_normalize_new_style_args', lambda x, action: (action, x))

# Generated at 2022-06-23 04:53:55.703405
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser



# Generated at 2022-06-23 04:54:00.651506
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert_equal(action_loader.__class__, module_args_parser.action_loader.__class__)
    assert_equal(module_loader.__class__, module_args_parser.module_loader.__class__)



# Generated at 2022-06-23 04:54:09.686709
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    arguments = dict(
        action="shell",
        delegate_to=None,
    )
    m = ModuleArgsParser(arguments, None)
    test = m.parse()
    assert m._task_ds["action"] == "shell"
    assert test == (arguments["action"], dict(), None)


#############################################################################################
#                                   ModuleExtractor
#############################################################################################
# This class is responsible for extracting the data from the action and return it as a dict
# it also check if the action is supported by the framework and if yes return the name of the
# module and the action as a tuple.
# if the action is not supported it will return None.
# ModuleExtractor.extract() is the main function of this class.
# Unit tests: test_ModuleExtractor_extract() is both unit test and example for this class and

# Generated at 2022-06-23 04:54:15.017517
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'chdir': '/tmp', 'creates': '/tmp/foo'}})
    assert type(m) is ModuleArgsParser

    m = ModuleArgsParser(task_ds={'action': 'shell'})
    assert type(m) is ModuleArgsParser


# Generated at 2022-06-23 04:54:19.693933
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    def _compare_arg(a, b):
        # debug
        if a != b:
            print("Expected: %s" % b)
            print("Actual  : %s" % a)
        assert a == b

    _o = ModuleArgsParser()
    assert isinstance(_o, ModuleArgsParser)
    _o.parse()

# Generated at 2022-06-23 04:54:35.525258
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:45.262265
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test class_init empty
    task_ds = {}
    a = ModuleArgsParser(task_ds)
    assert isinstance(a, ModuleArgsParser)
    assert a._task_ds == task_ds

# Generated at 2022-06-23 04:54:50.219583
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:54.676389
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    return module_args_parser


# Generated at 2022-06-23 04:54:57.847611
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser(task_ds={'a':'b', 'module':'c', 'action':'d', 'args':{'a':1}}).parse() == ('d', {'a': 1}, None)
 


# Generated at 2022-06-23 04:55:09.152787
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser()
    module_parser.parse(thing='')
    module_parser.parse(thing=[])
    with pytest.raises(AnsibleParserError):
        module_parser.parse(thing={'x':'y'})
    with pytest.raises(AnsibleParserError):
        module_parser.parse(thing={'action':'x'})
    action, args, delegate_to = module_parser.parse(thing={'action':{'module':'x'}})
    assert action == 'x' and args == {} and delegate_to == Sentinel
    action, args, delegate_to = module_parser.parse(thing={'action':{'module':'x','a':'b'}})

# Generated at 2022-06-23 04:55:18.456649
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test case 1: `local_action` is not in `task_ds`
    task_ds = {'action': 'ec2', 'args': {'region': 'xyz'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_ds == task_ds
    assert parser._collection_list is None
    # FIXME: why does the below statement not work?
    # assert parser._task_attrs == set(Task._valid_attrs.keys()) & set(Handler._valid_attrs.keys())
    assert parser.resolved_action is None

    # Test case 2: `local_action` is in `task_ds`
    task_ds = {'action': 'ec2', 'args': {'region': 'xyz'}, 'local_action': 'ec2'}
   

# Generated at 2022-06-23 04:55:23.781954
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # valid task dicts that are expected to pass the constructor
    valid_task_ds_list = [
        dict(action=dict(module='shell', args='/bin/false')),
        dict(local_action=dict(module='shell', args='/bin/false')),
        dict(shell='/bin/false'),
        dict(action='shell /bin/false'),
        dict(local_action='shell /bin/false'),
        dict(local_action=AnsibleUnsafeText(b"echo '{{ lookup('pipe', 'echo 1') }}'")),
    ]

    # invalid task dicts that are expected to throw AnsibleParserError during the constructor

# Generated at 2022-06-23 04:55:25.956715
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # The function is implemented in a complicated way.
    # We will not test it.
    pass

# Generated at 2022-06-23 04:55:36.568494
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {'name': 'test task', 'foo': 'bar'}
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {'name': 'test task', 'foo': 'bar', 'delegate_to': 'blah'}
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {'name': 'test task', 'foo': 'bar', 'delegate_to': 'meh'}
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {'name': 'test task', 'foo': 'bar', 'delegate_to': 'localhost'}
    ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-23 04:55:48.785061
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleAssertionError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted

    # initializing required objects
    module_parser = ModuleArgsParser()
    vault_secret = VaultSecret('$ANSIBLE_VAULT;1.1;AES256')

    # reading vault secret from file
    with open('/tmp/vault_test_file', 'rb') as f:
        vault_bytes = to_bytes(f.read())
        vault_secret.load(vault_bytes)

    # Reading data from vault_test_file

# Generated at 2022-06-23 04:55:58.107557
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:56:01.542742
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Validate the ModuleArgsParser class constructor
    '''
    assert ModuleArgsParser()
    assert ModuleArgsParser({})


# Generated at 2022-06-23 04:56:12.590208
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'echo hi'
    }
    collection_list = []
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('echo', {'_raw_params': 'hi'}, None)
    task_ds = {
        'action': {
            'echo': 'hi'
        }
    }
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('echo', {'_raw_params': 'hi'}, None)
    task_ds = {
        'action': {
            'echo ': 'hi'
        }
    }
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-23 04:56:13.380813
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass

# Generated at 2022-06-23 04:56:16.295395
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None


if __name__ == '__main__':
    # Unit test
    test_ModuleArgsParser()

# Generated at 2022-06-23 04:56:20.857132
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	with pytest.raises(AnsibleAssertionError):
		ModuleArgsParser()
	with pytest.raises(AnsibleParserError):
		ModuleArgsParser().parse()
	with pytest.raises(AnsibleParserError):
		ModuleArgsParser().parse(skip_action_validation=True)

# Generated at 2022-06-23 04:56:27.410554
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    parser = ModuleArgsParser()

    ansible_parse = {"key1": "value1", "key2": "value2", "key3": "value3"}
    actions = [TaskInclude, IncludeRole, Block, HandlerTaskInclude]
    for action in actions:
        action_obj = action()
        action_obj.vars = ansible_parse
        module_name, args, delegate_to = parser.parse(action_obj.vars)
        assert_equal(delegate_to, Sentinel)

# Generated at 2022-06-23 04:56:28.847254
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    print(ModuleArgsParser.__dict__)


# Generated at 2022-06-23 04:56:38.764041
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # When action is not None, the code goes to else block.
    # When action is not None and there is multiple module names
    action = "action"

# Generated at 2022-06-23 04:56:39.716698
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass


# Generated at 2022-06-23 04:56:50.067126
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit test for constructor of class ModuleArgsParser
    '''

    # Task contains no module name
    test_task_ds = {"delegate_to": "local", "with_file": "file.txt", "when": "check_value"}
    my_module_args_parser = ModuleArgsParser(task_ds=test_task_ds, collection_list='foo')
    assert not my_module_args_parser.parse()

    # Task contains a module name, which is not a valid module
    test_task_ds = {"delegate_to": "local", "new_action": {"x": 1}, "when": "check_value"}
    my_module_args_parser = ModuleArgsParser(task_ds=test_task_ds, collection_list='foo')
    assert not my_module_args_parser.parse()

# Generated at 2022-06-23 04:57:04.741287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    args_parser = ModuleArgsParser

    task = {'module': 'shell echo hi', 'action': 'shell echo hi'}
    result = args_parser(task).parse()
    assert result[0] == ('shell', {'_raw_params': 'echo hi'})

    task = {'module': 'shell echo hi', 'action': 'shell echo hi', 'args': '-v'}
    result = args_parser(task).parse()
    assert result[0] == ('shell', {'_raw_params': 'echo hi -v'})

    task = {'module': 'shell echo hi', 'action': 'shell echo hi', 'args': {'v': None}}
    result = args_parser(task).parse()

# Generated at 2022-06-23 04:57:06.353255
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement unit tests
    return False


GRAINS_CACHE = {}



# Generated at 2022-06-23 04:57:07.069867
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True



# Generated at 2022-06-23 04:57:16.538927
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # testing dict constructor
    task_ds = dict(
        action=dict(
            module='copy',
            src=dict(
                dir='/tmp',
                file='a_file.txt'
            ),
            dest='/etc/ansible/ABC'
        )
    )
    map = ModuleArgsParser(task_ds)
    assert map._task_ds == task_ds
    assert map._collection_list is None
    assert map.resolved_action is None

    # test dict and collection_list constructor
    task_ds = dict(
        action=dict(
            module='copy',
            src=dict(
                dir='/tmp',
                file='a_file.txt'
            ),
            dest='/etc/ansible/ABC'
        )
    )

# Generated at 2022-06-23 04:57:19.286732
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    t = ModuleArgsParser()
    assert isinstance(t, ModuleArgsParser)


# Generated at 2022-06-23 04:57:29.804223
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.splitter import split_args

    TestInclude = namedtuple('TestInclude', ['action', 'task_ds', 'collection_list'])
    task_ds = {'include': 'tasks/other.yml'}
    test_include = TestInclude(action='include', task_ds=task_ds, collection_list=None)
    task_args = task_ds.copy()
    task_args['include'] = TaskInclude.parse_from_task(task_args, task_ds, 'include', action=test_include.action, collection_list=test_include.collection_list)

# Generated at 2022-06-23 04:57:40.408337
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test to check if no module/action detected in task,
    # then it raises AnsibleParserError
    task_ds = { }
    collection_list = None
    duplicate_action = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    with pytest.raises(AnsibleParserError):
        duplicate_action.parse()

    # test to check if more than one module name is a problem,
    # then it raises AnsibleParserError
    task_ds = {'action': 'first_module', 'local_action': 'second_action'}
    collection_list = None
    duplicate_action = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    with pytest.raises(AnsibleParserError):
        duplicate_action.parse()

    #

# Generated at 2022-06-23 04:57:52.277163
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TaskDS:
        def __init__(self, tasks):
            self._tasks = tasks
            self.tasks = tasks
        def get(self, key, default = None):
            return self._tasks.get(key, default)
        def __getitem__(self, key):
            return self._tasks[key]

# Generated at 2022-06-23 04:58:02.242433
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:58:06.113934
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_ds = {'shell': 'echo "haha"'}
    parser = ModuleArgsParser(task_ds=test_ds)
    assert parser._task_ds == test_ds
    assert parser._collection_list == None
    assert parser._task_attrs is not None
    assert parser.resolved_action == None


# Generated at 2022-06-23 04:58:10.799342
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test ModuleArgsParser.parse()
    result = ModuleArgsParser().parse()
    assert result == (None, dict(), None)

    # Test ModuleArgsParser.parse() for the second time
    result = ModuleArgsParser().parse()
    assert result == (None, dict(), None)



# Generated at 2022-06-23 04:58:12.252680
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: ModuleArgsParser.parse is currently untestable
    pass

# Generated at 2022-06-23 04:58:22.552587
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    fake_loader = DictDataLoader({
        u"/playbook": b"",
    })
    runner = any_missing_required_vars = has_unsupported_tags = None
    callback = CallbackModule()


# Generated at 2022-06-23 04:58:28.357937
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    test_ModuleArgsParser
    '''

    # ModuleArgsParser should work with {}
    parser = ModuleArgsParser(task_ds={})
    # ModuleArgsParser should work with { 'delegate_to': 'foo' }
    parser = ModuleArgsParser(task_ds={'delegate_to': 'foo'})
    # ModuleArgsParser should not work with None
    try:
        ModuleArgsParser(task_ds=None)
    except Exception as exception:
        assert isinstance(exception, AnsibleAssertionError)



# Generated at 2022-06-23 04:58:36.729586
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Tags to enable the task parsers
    enable_tags = ['action', 'shell', 'command', 'raw']
    # Configuration
    config = AnsibleConfig(DEFAULT_CONFIG_DATA)

    modules = ModuleLoader(config.get_config_value('DEFAULT_MODULE_PATH'))
    plugins = PluginLoader(config.get_config_value('DEFAULT_MODULE_PATH'))
    for dir_path in config.get_config_value('DEFAULT_MODULE_PATH'):
        if os.path.isdir(dir_path) and not dir_path.endswith('.py'):
            plugins.add_directory(dir_path)

    # Action plugins
    action_plugins = PluginLoader(config.get_config_value('DEFAULT_ACTION_PLUGIN_PATH'))

# Generated at 2022-06-23 04:58:42.978980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fixture = dict(action='ec2', args=dict(region='us-west-2', instance_type='m3.large'))
    expected = ('ec2', dict(region='us-west-2', instance_type='m3.large'), None)

    parser = ModuleArgsParser(task_ds=fixture, collection_list=None)
    result = parser.parse()

    assert result == expected


# Generated at 2022-06-23 04:58:52.133862
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def _make_ds(mod, args):
        return {'action': {mod:args}}
    def _make_ds2(mod, args):
        return {'action': mod + ' ' + args}

    p = ModuleArgsParser(collection_list=['col'])

    # module name only
    action, args, delegate_to = p.parse()
    assert action == 'say'
    assert delegate_to == Sentinel
    assert args == {}

    # module name only, with action loader
    action, args, delegate_to = p.parse()
    assert action == 'say'
    assert delegate_to == Sentinel
    assert args == {}

    # module name only, with collection
    action, args, delegate_to = p.parse()
    assert action == 'say'
    assert delegate_to == Sentinel
    assert args == {}

# Generated at 2022-06-23 04:59:00.805280
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = dict(
        action=dict(
            module='shell',
            _raw_params='echo hi',
            args=dict(
                chdir='/tmp',
                executable='/bin/sh'
            )
        ),
        delegate_to='targethost',
        somekey=42
    )

    loader = DataLoader()
    variable_manager = VariableManager()

    # make sure we get back the right args and no errors
    parser = ModuleArgsParser(ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(chdir='/tmp', executable='/bin/sh')

# Generated at 2022-06-23 04:59:12.711510
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    task_ds = {
        'action': {
            'module': 'shell',
            'args': 'echo hi',
        },
        'delegate_to': 'localhost',
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'args': 'echo hi'}, 'localhost')

    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    task_ds = {
        'local_action': 'copy src=a dest=b'
    }
    parser = Module

# Generated at 2022-06-23 04:59:24.150591
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import string_types

    # load unit test config, params, and expected results
    from .unit.modules.utils.arg_spec_test_cases import ArgumentSpecTestCases
    config = ArgumentSpecTestCases.config
    module_name = config['module_name']
    test_cases = config['test_cases']

    # initialize AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # load module code
    module_path = module_utils.plugins.module_finder.get_module_path(module_name, mod_type="module")
    sys.path.append(os.path.dirname(module_path))

# Generated at 2022-06-23 04:59:35.095627
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Without collection_list, no extra directives are recognised as modules
    task_ds = dict(
        action=dict(module='win_copy', src='foo', dest='bar')
    )
    x = ModuleArgsParser(task_ds=task_ds)
    assert x.parse() == ('win_copy', dict(src='foo', dest='bar'), None)

    task_ds = dict(
        action=dict(module='gobble_de_gook', src='foo', dest='bar')
    )
    x = ModuleArgsParser(task_ds=task_ds)
    fail_msg = r'couldn\'t resolve module/action \'gobble_de_gook\'. This often indicates a misspelling, missing collection, or incorrect module path\.'

# Generated at 2022-06-23 04:59:44.703408
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:59:53.074297
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'notify': 'notify-some-handler'}
    expected = ('notify', {}, Sentinel)
    marp = ModuleArgsParser(task_ds)
    result = marp.parse()
    assert result == expected

    task_ds = {'notify': {'name': 'notify-some-handler'}}
    expected = ('notify', {'name': 'notify-some-handler'}, Sentinel)
    marp = ModuleArgsParser(task_ds)
    result = marp.parse()
    assert result == expected

    task_ds = {'notify': 'name=notify-some-handler'}
    expected = ('notify', {'name': 'notify-some-handler'}, Sentinel)
    marp = ModuleArgsParser(task_ds)

# Generated at 2022-06-23 05:00:03.581965
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 05:00:13.618425
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import combine_vars
    import json
    import yaml


   

# Generated at 2022-06-23 05:00:22.489050
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test ModuleArgsParser.__init__()
    parser = ModuleArgsParser()

    if parser._task_ds != {}:
        raise AssertionError('Unexpected parser._task_ds: %s, expected: {}' % parser._task_ds)

    if parser._collection_list is not None:
        raise AssertionError('Unexpected parser._collection_list: %s, expected: None' % parser._collection_list)

    if not isinstance(parser._task_attrs, frozenset):
        raise AssertionError('Unexpected parser._task_attrs: %s, expected: <frozenset()>' % parser._task_attrs)


# Generated at 2022-06-23 05:00:23.813749
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser()
    assert m is not None