

# Generated at 2022-06-23 04:50:20.939853
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert ModuleArgsParser().parse('ping') == ('ping', {}, None)

# Generated at 2022-06-23 04:50:34.965497
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.handler import Handler
    def test_parse_with_args(task_ds, result):
        parser = ModuleArgsParser(task_ds)
        assert parser._task_ds == task_ds
        assert parser.parse() == result

    def test_parse_with_exception(task_ds):
        parser = ModuleArgsParser(task_ds)
        assert parser._task_ds == task_ds
        with pytest.raises(AnsibleParserError) as excinfo:
            parser.parse()
        assert "module name '%s' not found in" % task_ds in str(excinfo.value)

    # This is the standard YAML form for command-type modules.
    # We grab the args and pass them in as additional arguments, which can/will be overwritten via dict
    # updates from the

# Generated at 2022-06-23 04:50:48.518424
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, action_loader
    test_module_args_parser = ModuleArgsParser(task_ds={}, collection_list=[])

    ##################### TEST CASE 1 #####################
    # action: copy src=a dest=b
    #                                                     #
    # Standized outputs like:                             #
    # { _raw_params: 'echo hi', _uses_shell: True }       #
    #######################################################
    test_task_ds = {'action': 'copy src=a dest=b'}
    test_module_args_parser._task_ds = test_task_ds
    action_loader.add_directory(path='/fake_directory')

# Generated at 2022-06-23 04:50:58.135952
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    test the parse method of the Class ModuleArgsParser
    '''
    # Test case 1
    # Test case 1.1 action: yum
    task_ds_test_case_11 = {
        "name": "yum",
        "action": "yum -y install httpd"
    }
    fqcn_test_case_11 = "ansible.builtin.yum"
    test_case_11_result = ModuleArgsParser(task_ds_test_case_11).parse()
    assert test_case_11_result[0] == "yum"
    assert test_case_11_result[1] == {"args": " -y install httpd"}
    assert test_case_11_result[2] is sentinel.object

# Generated at 2022-06-23 04:51:04.215123
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    args = dict()
    kwargs = dict()
    op = ModuleArgsParser(**kwargs)
    assert op.parse(**args) == ('copy', {}, None)



# Generated at 2022-06-23 04:51:05.177499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Generated at 2022-06-23 04:51:13.479951
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import json
    import copy

    # Build mock object for arguments and call method under test
    test_task_ds = {"args": {"path": "/etc/ansible"}, "delegate_to": "localhost", "freeform": "ls -l /tmp", "name": "foo"}
    task_parser = ModuleArgsParser(task_ds=test_task_ds)
    test_action, test_args, test_delegate_to = task_parser.parse()

    # Verify results
    assert(test_action == "freeform")
    assert(test_args == {"_raw_params": "ls -l /tmp", "path": "/etc/ansible"})
    assert(test_delegate_to == "localhost")

    # Build mock object for arguments and call method under test

# Generated at 2022-06-23 04:51:19.901694
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    model = AnsibleModel(dict(name=None, tasks=[]))
    ansible_version_info = AnsibleVersionInfo(version='2.8.3',
                                              gitinfo=None)
    loader = None
    play = Play(loader=loader,
                name='Test Play',
                hosts=[],
                vars={},
                tasks=[],
                handlers=[],
                roles=[],
                stop_on_error=False,
                any_errors_fatal=False,
                auto_handlers=False,
                auto_tasks=False,
                tags=[],
                skip_tags=[],
                restrictions=[],
                defaults=dict())
    play.set_loader(loader)
    PlayContext.set_model(model)
    PlayContext.set_play(play)
    PlayContext.set_ansible

# Generated at 2022-06-23 04:51:26.778531
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)

    assert parser._task_ds == task_ds
    assert parser._task_attrs == frozenset({'register', 'tags', 'environment', 'any_errors_fatal', 'always_run', 'local_action', 'static', 'when'})
    assert parser._collection_list is None
    assert parser.resolved_action is None



# Generated at 2022-06-23 04:51:35.710760
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.base import Base

    # The default constructor
    m = ModuleArgsParser()
    assert isinstance(m, ModuleArgsParser)

    # No 'task_ds'
    try:
        m = ModuleArgsParser(task_ds='not dict')
        assert False
    except AnsibleAssertionError as e:
        pass

    # No 'collection_list'
    try:
        m = ModuleArgsParser(task_ds={})
        assert False
    except AnsibleAssertionError as e:
        pass

    # Pass in dict for 'task_ds' and None for 'collection_list'
    m = ModuleArgsParser(task_ds={}, collection_list=None)
    assert isinstance(m, ModuleArgsParser)

    # Pass in dict for 'task_ds' and Base for 'collection_list

# Generated at 2022-06-23 04:51:44.562207
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test module args parser.

    Returns:
        None

    """
    task_ds = {
        'action': 'ping',
        'with_items': '{{a}}',
        'register': 'a',
        'loop_control': {
            'loop_var': 'a'
        }
    }

    module_arg_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'ping'
    assert args == {'_raw_params': ''}
    assert delegate_to is Sentinel


# Generated at 2022-06-23 04:51:54.920125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test that templated action strings are handled properly
    task_dict = {'action': '{{test_action_var}}'}
    loader = DictDataLoader({'test_action_var': 'shell echo "test"'})
    t = Task.load(task_dict, loader=loader, variable_manager=VariableManager())
    assert t.action == 'shell'
    assert t.args == 'echo "test"'

    # Test that "action" can't be defined at the same time as "local_action"
    task_dict = {'action': 'shell echo "test1"', 'local_action': 'shell echo "test2"'}
    loader = DictDataLoader()
    with pytest.raises(AnsibleParserError):
        Task.load(task_dict, loader=loader, variable_manager=VariableManager())



# Generated at 2022-06-23 04:52:01.179252
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_task_ds = {
        'delegate_to': None,
        'action': 'copy',
        'args': {
            'dest': '/dest/path',
            'src': '/src/path'
        }
    }

    test_ModuleArgsParser = ModuleArgsParser(task_ds=test_task_ds)
    assert isinstance(test_ModuleArgsParser._task_ds, dict)
    assert test_ModuleArgsParser.resolved_action is None



# Generated at 2022-06-23 04:52:14.171176
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ITYPE = type  # For Python 3.x.x
    class AnsibleModule:
        def __init__(self, module_name, params, skip_action_validation=False):
            self.collection_list = None
            self.action, self.args, self.delegate_to = ModuleArgsParser(
                task_ds=params, collection_list=self.collection_list).parse(
                skip_action_validation=skip_action_validation)

    # Testing case where:
    # - module name is correct
    # - no arguments for module
    action = 'ping'
    params = {action: None}
    ansible = AnsibleModule(action, params)
    assert ansible.action == 'ping'
    assert ansible.args is None
    assert ansible.delegate_to is None

    #

# Generated at 2022-06-23 04:52:17.106631
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    unit test for method parse of class ModuleArgsParser
    '''
    module_arg_parser = ModuleArgsParser()
    print(module_arg_parser.parse())

# Generated at 2022-06-23 04:52:25.286757
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test for correct type of task_ds param
    try:
        foo = ModuleArgsParser(task_ds=None)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleAssertionError for invalid type of task_ds param")

    foo = ModuleArgsParser(task_ds={})
    my_task_ds = dict(action=dict(args=dict(a='b')))
    bar = ModuleArgsParser(task_ds=my_task_ds)


# Generated at 2022-06-23 04:52:30.485997
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_dict = dict(action='shell echo hi')
    args_parser = ModuleArgsParser(task_ds=task_dict)
    assert isinstance(args_parser, ModuleArgsParser)


# Unit tests for methods of class ModuleArgsParser

# Generated at 2022-06-23 04:52:38.806233
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'command', 'args': {'chdir': '/tmp'}}
    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    assert result == ('command', {'chdir': '/tmp'}, sentinel.Sentinel) or \
           result == ('command', {'chdir': '/tmp'}, 'localhost')

    task_ds = {'action': 'command', 'args': {'chdir': '/tmp'}, 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    # result will be a tuple of (action, args, delegate_to)
    assert result == ('command', {'chdir': '/tmp'}, 'localhost')

   

# Generated at 2022-06-23 04:52:49.942149
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:56.561425
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        m = ModuleArgsParser(task_ds=None)
        assert 'the type of task_ds should be a dict' in str(excinfo.value)


# Generated at 2022-06-23 04:53:01.399741
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(
        action=dict(
            module='find',
            paths='/',
            pattern='*.txt',
        ),
        delegate_to='localhost',
    )
    module_args_parser = ModuleArgsParser(ds)
    assert module_args_parser is not None, 'Not able to instantiate ModuleArgsParser'


# Generated at 2022-06-23 04:53:12.143637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.display import Display
    d = Display()
    ansible_stderr = {'failed': False, 'msg': ''}

    def _mock_ansible_module(name, module_args=None, **kwargs):
        mock_module = MagicMock()
        mock_module.__dict__ = kwargs
        mock_module.ansible_stderr = ansible_stderr
        mock_module.ansible_module_args = module_args
        mock_module.get_bin_path = lambda x, y: x

# Generated at 2022-06-23 04:53:16.365317
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = {'action': 'copy src=a dest=b'}
    expected = 'copy', {'src': 'a', 'dest': 'b', '_raw_params': ''}, Sentinel
    actual = ModuleArgsParser(data).parse()
    assert actual == expected


# Generated at 2022-06-23 04:53:18.802476
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ga = ModuleArgsParser()
    assert isinstance(ga, ModuleArgsParser)



# Generated at 2022-06-23 04:53:27.600998
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=dict())
    assert module_args_parser.parse(skip_action_validation=False) == (None, dict(), Sentinel)
    module_args_parser = ModuleArgsParser(task_ds=dict(action=dict(module='copy', src='a', dest='b')))
    assert module_args_parser.parse(skip_action_validation=False) == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    module_args_parser = ModuleArgsParser(task_ds=dict(action='copy src=a dest=b'))
    assert module_args_parser.parse(skip_action_validation=False) == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    module_args_parser = ModuleArgs

# Generated at 2022-06-23 04:53:31.575241
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Only create the class instance for this test
    module_args_parser=ModuleArgsParser()
    assert module_args_parser


# Generated at 2022-06-23 04:53:39.192379
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module = 'shell'
    args = 'echo $HOME'
    task_ds = {'action': {module: args}}
    # task_ds = dict(action=dict(module=args))
    args_parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleAssertionError):
        args_parser.parse()

    task_ds = {'action': {module: 'echo $HOME', 'arbitrary_arg': 'hello world'}}
    args_parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        args_parser.parse()

    task_ds = {module: args}
    args_parser = ModuleArgsParser(task_ds)
    args_parser.parse()

# Generated at 2022-06-23 04:53:39.993892
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True

# Generated at 2022-06-23 04:53:44.189220
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(action=dict(module='shell', args='whoami', _raw_params=''))
    with pytest.raises(AnsibleError):
        x = ModuleArgsParser(data)


# Generated at 2022-06-23 04:53:54.735981
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # task_ds: dict
    # collection_list: list
    task = dict()
    collection_list = list()

    # ~~~
    # Empty task
    # ~~~
    map = ModuleArgsParser(task_ds=task, collection_list=collection_list)
    (action, args, delegate_to) = map.parse(skip_action_validation=False)

    assert action is None
    assert args is None
    assert delegate_to is None

    # ~~~
    # Local action with one argument
    # ~~~

    task = dict(local_action=dict(module='ping', args='data=foo value={{bar}}'))
    map = ModuleArgsParser(task_ds=task, collection_list=collection_list)

# Generated at 2022-06-23 04:54:05.026862
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test the constructor of the ModuleArgsParser class
    '''

    test_example_1 = dict(action=dict(module='shell', args='echo "Hello World"'))
    test_example_2 = dict(action='shell echo "Hello World"')
    test_example_3 = dict(action='shell', args='echo "Hello World"')
    test_example_4 = dict(shell='echo "Hello World"')

    parser = ModuleArgsParser(task_ds=test_example_1)
    assert parser

    parser = ModuleArgsParser(task_ds=test_example_2)
    assert parser

    parser = ModuleArgsParser(task_ds=test_example_3)
    assert parser


# Generated at 2022-06-23 04:54:10.740060
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Unit test with no optionals passed
    parser = ModuleArgsParser()
    assert parser._task_ds == {}

    # Unit test with optionals passed
    parser = ModuleArgsParser(task_ds=None)
    assert parser._task_ds == {}


# Generated at 2022-06-23 04:54:21.557627
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {"action": "echo hi"}
    parser = ModuleArgsParser(task_ds)
    res, args, delegate_to = parser.parse()
    assert res == "echo" and args == {"_raw_params": "hi"} and delegate_to is Sentinel
    task_ds = {"action": {"module": "shell", "x": "1", "args": "y=2"}}
    parser = ModuleArgsParser(task_ds)
    res, args, delegate_to = parser.parse()
    assert res == "shell" and args == {"x": "1", "_raw_params": "y=2"} and delegate_to is Sentinel
    task_ds = {"action": {"module": "shell echo hi"}}
    parser = ModuleArgsParser(task_ds)
    res, args, delegate_to = parser.parse()
   

# Generated at 2022-06-23 04:54:30.296619
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # TODO: This test is only checking exceptions.  Need to add more tests.
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

    # test dictionary type
    task_ds = {}
    parser = ModuleArgsParser(task_ds, collection_list)
    try:
        parser.parse()
        raise Exception('This should not happen')
    except AnsibleParserError:
        pass

    # test string type
    task_ds = 'test'
    parser = ModuleArgsParser(task_ds, collection_list)
    try:
        parser.parse()
        raise Exception('This should not happen')
    except AnsibleParserError:
        pass


# Interface class used by PlaybookInclude to parse and
# process an included file.

# Generated at 2022-06-23 04:54:33.098235
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  obj = ModuleArgsParser()
  action, args, delegate_to = obj.parse(skip_action_validation=True)
  assert action == None
  assert args == dict()
  assert delegate_to ==None


# Generated at 2022-06-23 04:54:43.506751
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:54:46.694047
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(dict(action=dict(module='command', args='whoami')))
    assert module_args_parser._task_ds == dict(action=dict(module='command', args='whoami'))


# Generated at 2022-06-23 04:54:51.688834
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Ensure that we get a class back
    assert isinstance(ModuleArgsParser(), ModuleArgsParser)

# Generated at 2022-06-23 04:54:58.903104
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskDefinition
    Task.load = lambda x, y: TaskDefinition()
    module_arg_parser = ModuleArgsParser(task_ds={'meta': '1.0', 'name': 'test', 'action': 'shell echo hi'})
    assert module_arg_parser.parse() == ('shell', {'_raw_params': u'echo hi', '_uses_shell': True}, None)
    module_arg_parser = ModuleArgsParser(task_ds={'meta': '1.0', 'name': 'test', 'action': 'shell echo hi', 'become': 'yes'})
    assert module_arg_parser.parse() == ('shell', {'_raw_params': u'echo hi', '_uses_shell': True}, None)

# Generated at 2022-06-23 04:55:09.736589
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # No delegation
    task = dict(
        action='shell',
        args='echo hi'
    )
    m = ModuleArgsParser(task)
    (action, args, delegate_to) = m.parse()
    assert action == "shell"
    assert delegate_to == None
    assert args == dict(
        _raw_params='echo hi'
    )

    # With delegation
    task = dict(
        action='shell',
        args='echo hi',
        delegate_to='127.0.0.1'
    )
    m = ModuleArgsParser(task)
    (action, args, delegate_to) = m.parse()
    assert action == "shell"
    assert delegate_to == '127.0.0.1'
    assert args == dict(
        _raw_params='echo hi'
    )

# Generated at 2022-06-23 04:55:21.974738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(task_ds=None)
    # test when thing is dict
    print('test when thing is dict')
    action, args, delegate_to = m.parse(skip_action_validation=False)
    print('action: %s, args: %s, delegate_to: %s' % (action, args, delegate_to))
    # test when thing is string
    print('test when thing is string')
    m = ModuleArgsParser(task_ds={'module': 'stat path=/etc/group'})
    action, args, delegate_to = m.parse(skip_action_validation=False)
    print('action: %s, args: %s, delegate_to: %s' % (action, args, delegate_to))
    # test when thing is dict
    print('test when thing is dict')

# Generated at 2022-06-23 04:55:33.694170
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ##############################################################################
    # The purpose of this test is to ensure that the module arguments can be    #
    # parsed correctly irrespective of the style of module invocation.          #
    # The test does so by invoking the 'parse' method on ModuleArgsParser for   #
    # a variety of module styles and comparing the parsed output against a      #
    # pre-determined expected output.                                           #
    ##############################################################################
    ##############################################################################
    # Test case 1                                                                #
    ##############################################################################
    # Initialize task_ds
    task_ds = dict(action="command",
                   args=["echo", "hello world"])
    # Create a class instance
    obj = ModuleArgsParser(task_ds)
    # Execute the action under test
    (action, args, delegate_to)

# Generated at 2022-06-23 04:55:42.522409
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:55:53.869756
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    kwargs = dict(
        task_ds=dict(
            action=dict(
                module="copy",
                src="abc",
                dest="abc")
        )
    )
    module_args_parser = ModuleArgsParser(**kwargs)
    result = module_args_parser.parse()
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert result[0] == "copy"
    assert isinstance(result[1], dict)
    assert "src" in result[1]
    assert isinstance(result[2], type(None))

    kwargs = dict(
        task_ds="echo hi"
    )
    module_args_parser = ModuleArgsParser(**kwargs)

# Generated at 2022-06-23 04:56:01.777654
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class Sentinel:
        def __init__(self):
            pass

    action = None
    args = None
    delegate_to = Sentinel()

    # Test case 1
    thing = 'echo hi'
    action = 'shell'
    testparser = ModuleArgsParser()
    result = testparser._normalize_parameters(thing, action)
    assert result == ('shell', "{'_raw_params': 'echo hi', '_uses_shell': True}")

    # Test case 2
    thing = {'module': 'ec2'}
    action = None
    testparser = ModuleArgsParser()
    result = testparser._normalize_parameters(thing, action)
    assert result == ('ec2', "{}")

    # Test case 3
    thing = {'module': 'echo hi'}
    action = None
    testparser

# Generated at 2022-06-23 04:56:03.450258
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass


# Generated at 2022-06-23 04:56:04.616499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False


# Generated at 2022-06-23 04:56:07.336931
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # task_ds is a dict of task data structure
    # collection_list is a list of AnsibleCollectionRef objects
    ModuleArgsParser(task_ds={}, collection_list=None)

# Generated at 2022-06-23 04:56:14.681424
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    testparser = ModuleArgsParser()
    testparser._task_ds = "test"
    try:
        testparser.parse()
# Negative test case: throw TypeError excpetion
# when _task_ds is not a dict
    except TypeError:
        assert True
    else:
        assert False
    testparser.resolved_action = "test"
    try:
        testparser.parse(1)
# Negative test case: throw value error excpetion
# when skip_action_validation is not boolean
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 04:56:17.444814
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    for action in BUILTIN_TASKS:
        args = dict()
        task = dict()
        task[action] = args
        ModuleArgsParser(task)


# Generated at 2022-06-23 04:56:27.027952
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': u'foo bar=baz', 'delegate_to': '127.0.0.1'}
    collection_list = ['foo']
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'foo'
    assert args == {'bar': 'baz'}
    assert delegate_to == '127.0.0.1'

    task_ds = {'action': u'foo bar=baz', 'delegate_to': '127.0.0.1'}
    collection_list = ['foo']
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'foo'

# Generated at 2022-06-23 04:56:33.189982
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_module_name = 'fake_module_name'
    fake_task_ds = {
        'action': fake_module_name,
        'delegate_to': 'foo',
    }

    parser = ModuleArgsParser(fake_task_ds)
    action, args, delegate_to = parser.parse()

    assert action == fake_module_name, action
    assert args == {}, args
    assert delegate_to == 'foo', delegate_to



# Generated at 2022-06-23 04:56:34.322550
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    return parser

# Generated at 2022-06-23 04:56:37.339907
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds=dict())
    assert isinstance(parser._task_ds, dict) and isinstance(parser._collection_list, list)


# Generated at 2022-06-23 04:56:48.395876
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test empty task_ds data
    module_args_parser = ModuleArgsParser(task_ds={})
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # test action in task_ds data
    task_ds_action = {'action': 'echo hello'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds_action)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hello'}, Sentinel)

    task_ds_action1 = {'action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds_action1)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)



# Generated at 2022-06-23 04:56:59.530890
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.release import __version__

    task_ds = dict()
    collection_list = None

    parser = ModuleArgsParser(task_ds, collection_list)

    assert(isinstance(parser, ModuleArgsParser))

    if __version__ < '2.8':
        assert("local_action" in parser._task_attrs)
    else:
        assert("local_action" not in parser._task_attrs)

    assert("action" in parser._task_attrs)
    assert("static" in parser._task_attrs)


# Generated at 2022-06-23 04:57:10.712789
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # with_items
    # format 1
    d = dict(
        action = dict(shell = 'ls'),
        with_items = "{{mylist}}"
    )
    parser = ModuleArgsParser(task_ds=d)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert delegate_to is None
    assert args == dict(command='ls', _raw_params='ls')

    # format 2
    d = dict(
        local_action = dict(shell = dict(command='{{item}}')),
        with_items = "{{mylist}}"
    )
    parser = ModuleArgsParser(task_ds=d)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert delegate_to == "localhost"

# Generated at 2022-06-23 04:57:24.821662
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:57:30.775407
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    for obj in Task.__dict__:
        if isinstance(getattr(Task, obj), FieldAttribute):
            assert obj in ModuleArgsParser._valid_attrs

    for obj in Handler.__dict__:
        if isinstance(getattr(Handler, obj), FieldAttribute):
            assert obj in ModuleArgsParser._valid_attrs

# Generated at 2022-06-23 04:57:35.704565
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # old style action and args
    module_args_parser = ModuleArgsParser()
    task_ds = {'action':'command /usr/bin/uptime'}
    action, args, delegate_to = module_args_parser.parse(task_ds)

    assert action == 'command'
    assert args == {'_raw_params':'/usr/bin/uptime'}
    assert delegate_to == None

    # new style action and args
    module_args_parser = ModuleArgsParser()
    task_ds = {'command': '/usr/bin/uptime'}
    action, args, delegate_to = module_args_parser.parse(task_ds)

    assert action == 'command'
    assert args == {'_raw_params':'/usr/bin/uptime'}
    assert delegate_to == None

   

# Generated at 2022-06-23 04:57:40.060307
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yaml_data = {'action': 'git'}
    parser = ModuleArgsParser(task_ds=yaml_data)
    action, args, delegate_to = parser.parse()
    assert action == 'git'
    assert args == {}
    assert delegate_to is None
# END test_ModuleArgsParser_parse

# Generated at 2022-06-23 04:57:52.033724
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import collections

    task_ds = collections.OrderedDict()
    task_ds.update({'action': {'module': 'copy', 'dest': 'a', 'src': 'b'}})
    task_ds.update({'delegate_to': 'localhost'})

    _normalize_parameters = mock.Mock(return_value=('copy', {'dest': 'a', 'src': 'b'}))
    _split_module_string = mock.Mock(return_value=('copy', {'dest': 'a', 'src': 'b'}))


# Generated at 2022-06-23 04:57:53.049736
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass
# end unit test


# Generated at 2022-06-23 04:57:58.546426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = dict(
        action = dict(
            module = 'cowsay',
            cow = 'foo',
            msg = 'bar'
        )
    )

    module_args_parser = ModuleArgsParser(fake_task_ds)
    result = module_args_parser.parse()

    assert result == ('cowsay', dict(cow='foo', msg='bar'), None)

# Generated at 2022-06-23 04:58:07.836779
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser({}, [])
    assert module_args_parser.resolved_action is None

    module_args_parser = ModuleArgsParser({'a': 'b'}, [])
    assert module_args_parser.resolved_action is None

    module_args_parser = ModuleArgsParser({'action': {'module': 'shell echo hi'}}, [])
    assert module_args_parser.resolved_action is None


# Generated at 2022-06-23 04:58:09.451879
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser
    assert isinstance(parser, ModuleArgsParser)


# Generated at 2022-06-23 04:58:11.917528
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test the constructor
    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert parser is not None


# Generated at 2022-06-23 04:58:19.799533
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class_instance = None
    ansible_module_name = None
    ansible_module_args = None

    if False:
        # TODO: Not yet implemented
        class_instance = ModuleArgsParser()
        assert class_instance != None
        ansible_module_name = None
        ansible_module_args = None

    else:
        pass

    return ansible_module_name, ansible_module_args

# Generated at 2022-06-23 04:58:31.367345
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = 'ssh_args="-o ProxyCommand=\'ssh -W %h:%p -q user@bastionhost\'"'
    module = 'ec2'

    # Case 1
    module_args_dict_input = {'args': args}
    module_args_dict_input['module'] = module

    action_parser = ModuleArgsParser(task_ds=module_args_dict_input)
    (action, parsed_args, delegate_to) = action_parser.parse()
    assert action == module
    assert parsed_args['ssh_args'] is not None
    assert delegate_to is None

    # Case 2
    module_args_dict_input = {'action': module_args_dict_input}
    action_parser = ModuleArgsParser(task_ds=module_args_dict_input)

# Generated at 2022-06-23 04:58:43.323433
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task

    test_task = Task()

    test_task_ds = {'action':{'module':'command', 'chdir':'/var/lib/awx'},
                    'name': 'test',
                    'args': {'creates': 'test'}
    }

    # create ModuleArgsParse instance
    mad = ModuleArgsParser(test_task_ds)
    mad_instance = mad._normalize_parameters(test_task_ds['action'])
    assert mad_instance[1]['chdir'] == '/var/lib/awx'
    assert mad_instance[1]['_raw_params'] == 'command'
    assert mad_instance[1]['creates'] == 'test'

# Generated at 2022-06-23 04:58:48.747904
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = "copy"
    args = dict()
    delegate_to = "localhost"
    thing = action + ':' + to_text(args)
    _task_ds = dict()
    _task_ds['action'] = thing

    parser = ModuleArgsParser(task_ds=_task_ds, collection_list=None)
    assert parser.parse() == (action, args, delegate_to)



# Generated at 2022-06-23 04:58:59.522383
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a = {'action': 'shell echo hi',
         'delegate_to': 'me',
         'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(a, collection_list=None)
    expected_result = ('shell', {'_uses_shell': True, '_raw_params': 'echo hi'}, 'me')
    assert parser.parse() == expected_result
    del a['action']
    a['local_action'] = 'shell echo hi'
    expected_result = ('shell', {'_uses_shell': True, '_raw_params': 'echo hi'}, 'localhost')
    assert parser.parse() == expected_result
    a = {'shell': 'echo hi'}
    parser = ModuleArgsParser(a, collection_list=None)

# Generated at 2022-06-23 04:59:10.958038
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test arg parsing with a valid argument, 'action'
    module_arg_parser = ModuleArgsParser(dict(action='echo hi', delegate_to='localhost'))
    assert module_arg_parser.parse() == ('echo', {'_raw_params': 'hi', '_uses_shell': True}, 'localhost')

    # test with a valid argument, 'module' and 'delegate_to'
    module_arg_parser = ModuleArgsParser(dict(module='echo hi', delegate_to='localhost'))
    assert module_arg_parser.parse() == ('echo', {'_raw_params': 'hi', '_uses_shell': True}, 'localhost')

    # test with a valid argument, 'local_action'
    module_arg_parser = ModuleArgsParser(dict(local_action='echo hi'))
    assert module_arg_

# Generated at 2022-06-23 04:59:20.640546
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.module_docs_fragments import get_docstring
    from ansible.module_utils import basic

    for name in basic.MODULE_REQUIREMENTS:
        doc, plainexamples, returndocs, metadata = get_docstring(basic, name)
        parser = ModuleArgsParser(task_ds=plainexamples[0])
        (action, args, delegate_to) = parser.parse()
        assert type(action) is str
        assert type(args) is dict
        assert type(delegate_to) is str or delegate_to == None


# Generated at 2022-06-23 04:59:32.495137
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(action='shell echo hi')
    action, args, delegate_to = ModuleArgsParser(ds).parse()
    assert action == 'shell'
    assert not args
    assert delegate_to is None

    ds = dict(action='shell', _raw_params='echo hi')
    action, args, delegate_to = ModuleArgsParser(ds).parse()
    assert action == 'shell'
    assert not args
    assert delegate_to is None

    ds = dict(action='shell', args='echo hi')
    action, args, delegate_to = ModuleArgsParser(ds).parse()
    assert action == 'shell'
    assert not args
    assert delegate_to is None

    ds = dict(action=dict(module='shell', args='echo hi'))

# Generated at 2022-06-23 04:59:37.919308
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # create a new task dictionary of 2 items
    task_ds = dict(a=1, b=2)
    # create a new ModuleArgsParser with an empty collection_list
    args_parser = ModuleArgsParser(task_ds, None)

    # check that the task_ds is correct
    assert args_parser._task_ds == task_ds

# Generated at 2022-06-23 04:59:46.794782
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit test for constructor of class ModuleArgsParser
    '''
    # Task with local_action
    task = {'local_action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task, collection_list=None)
    result = module_args_parser.parse()
    assert result[0] == 'copy'
    assert result[1] == {'src': 'a', 'dest': 'b'}
    assert result[2] == 'localhost'
    # Task with action
    task = {'action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task, collection_list=None)
    result = module_args_parser.parse()
    assert result[0] == 'copy'

# Generated at 2022-06-23 04:59:57.876279
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # -> TaskExecutor()
    task_ds = {'delegate_to': None,
               'with_first_found': {},
               'name': 'Get facts',
               'action': {'module': 'setup'}}
    module_path = 'ansible/parsing/tasks/task_executor.py'

    # -> _normalize_new_style_args()
    # -> _normalize_old_style_args()
    # -> _split_module_string()
    # action -> module
    # thing -> {'module': 'setup'}
    module_string = 'setup'
    assert ModuleArgsParser(task_ds)._split_module_string(module_string) == ('setup', '')
    action = 'setup'

    # additional_args -> {}
    additional_args = {}

    #

# Generated at 2022-06-23 04:59:59.026674
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_with_non_task_ds
    # TODO: implement
    pass



# Generated at 2022-06-23 05:00:08.104287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser()

    class Dummy:
        def __init__(self, data):
            self.data = data

    class BadDummy:
        def __init__(self, data):
            self.data = data

    fake_dict = dict()
    fake_dict['a'] = 1

    if obj.parse(Dummy('')) != ('', {}, None):
        raise AssertionError('Failed to parse')
    if obj.parse(Dummy({})) != ('', {}, None):
        raise AssertionError('Failed to parse')
    if obj.parse(Dummy(fake_dict)) != ('', {}, None):
        raise AssertionError('Failed to parse')
    if obj.parse(Dummy('a')) != ('', {}, None):
        raise AssertionError

# Generated at 2022-06-23 05:00:13.468962
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def assert_module_args_parser_parse(module_args, task_ds, action, args, delegate_to, no_args=None, no_assertion=False):
        try:
            module_args_parser = get_module_args_parser(module_args, task_ds)
            actual_action, actual_args, actual_delegate_to = module_args_parser.parse()
        except:
            if not no_assertion:
                raise AssertionError("Exception calling ModuleArgsParser.parse(%s, %s)" % (module_args, task_ds))
        else:
            if no_assertion:
                raise AssertionError("Exception not raised calling ModuleArgsParser.parse(%s, %s)" % (module_args, task_ds))
            assert actual_action == action
            assert actual_args

# Generated at 2022-06-23 05:00:25.458496
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    constructor of ModuleArgsParser
    '''

    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list = ['a', 'b', 'c']
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._collection_list == collection_list
    # delayed local imports to prevent circular import
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access