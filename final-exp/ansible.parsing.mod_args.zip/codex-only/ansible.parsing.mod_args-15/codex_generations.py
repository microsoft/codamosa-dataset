

# Generated at 2022-06-23 04:50:29.823480
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'with_items': '1 2 3',
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args.get('_raw_params', '') == 'echo hi'
    assert delegate_to == 'localhost'
    assert parser.resolved_action is None



# Generated at 2022-06-23 04:50:40.324672
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Verify that we can parse the full range of module invocations
    # and end up with a dict of arguments that can be used to execute
    # the module

    # local_action: module: args=here
    # will result in
    # action: module
    # delegate_to: localhost
    # args: { 'args': 'here' }

    x = dict(
        local_action="ec2",
        args=dict(
            x=1,
            y=2,
        )
    )
    module_parser = ModuleArgsParser(task_ds=x)
    action, args = module_parser.parse()
    assert action == "ec2"
    assert args == dict(
        x=1,
        y=2,
    )


# Generated at 2022-06-23 04:50:49.391914
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:50:58.590734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError) as execinfo:
        module_args_parser.parse()
    assert 'the type of \'task_ds\' should be a dict' in str(execinfo.value)
    module_args_parser = ModuleArgsParser(task_ds = {})
    action, args, delegate_to = module_args_parser.parse()
    assert action == None
    assert args == {}
    assert delegate_to == None

# Generated at 2022-06-23 04:51:06.976986
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Test ModuleArgsParser constructor"""
    # data structure of normal task
    task_ds = dict(action=dict(module='shell', args='echo hello'), delegate_to='localhost')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args.get('args') == 'echo hello'
    assert delegate_to == 'localhost'

    # data structure of task with local_action
    task_ds = dict(local_action=dict(module='shell', args='echo hello'), delegate_to='localhost')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args.get('args') == 'echo hello'
    assert delegate_to == 'localhost'

# Generated at 2022-06-23 04:51:09.913291
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = None
    _collection_list = None
    x = ModuleArgsParser(task_ds=_task_ds, collection_list=_collection_list )
    x.parse()

# unit test for ModuleArgsParser

# Generated at 2022-06-23 04:51:14.003698
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test constructor and member functions
    module_arg_parser = ModuleArgsParser(task_ds=dict(), collection_list=list())
    assert (isinstance(module_arg_parser, ModuleArgsParser))
    assert (isinstance(module_arg_parser._task_ds, dict))
    assert (isinstance(module_arg_parser._collection_list, list))
    assert (isinstance(module_arg_parser._task_attrs, frozenset))
    assert (module_arg_parser.resolved_action == None)

# Generated at 2022-06-23 04:51:19.904506
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser({
        'name': 'test',
        'action': 'copy src=a dest=b',
        'args': {1: 2},
        'foo': 'bar',
        'delegate_to': 'baz'
    })
    assert module_args_parser is not None


# Generated at 2022-06-23 04:51:26.286177
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert (parser._task_ds == {})
    assert (parser._task_attrs == frozenset(['local_action', 'static', 'async', 'delegate_to', 'notify', 'register', 'poll', 'when', 'until', 'retries', 'delay', 'failed_when', 'ignore_errors']))
    assert (parser.resolved_action is None)


# Generated at 2022-06-23 04:51:30.296911
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mock_task_ds = dict(
        name='test',
        module='test_module',
        args=dict(arg1='val1')
    )
    parser = ModuleArgsParser(mock_task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'test_module'
    assert delegate_to == Sentinel
    assert args == dict(arg1='val1')

# Generated at 2022-06-23 04:51:32.619032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({'role': 'Webserver'})
    module_args_parser._split_module_string('shell echo hi')

# Generated at 2022-06-23 04:51:40.954564
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_valid_attrs = set(Task._valid_attrs.keys())
    task_valid_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_valid_attrs.update(['local_action', 'static'])
    task_valid_attrs = frozenset(task_valid_attrs)

    # test case 1
    # test for inputs:
    #   delegate_to: localhost
    #   args:
    #     - x: 10
    #     - y: 20
    #   module: copy src={{

# Generated at 2022-06-23 04:51:52.970695
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class Stub():
        def __init__(self, loader, **args):
            self.args = args
            self.args['loader'] = loader
        def __getattr__(self, attr):
            return self.args.get(attr)
    fake_loader = Stub('fake_loader')
    t = Task(dict(action="ping"), loader=fake_loader)
    # test the constructor
    p = ModuleArgsParser(t, collection_list=None)
    assert p is not None
    assert p._task_ds == dict(action="ping")
    assert p._collection_list == None

# Generated at 2022-06-23 04:52:01.857945
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.module_utils.common.collections import Dictable
    class Dict(Dictable):
        _valid_attrs = frozenset()
    from ansible.plugins.loader.action import ActionBase
    from ansible.plugins.action import ActionModule

    parser = ModuleArgsParser()
    # test _split_module_string
    _split_module_string_tmpl = {
        (u'copy src=a dest=b',): (u'copy', u'src=a dest=b'),
        (u'module: copy src=a dest=b',): (u'copy', u'src=a dest=b'),
    }

# Generated at 2022-06-23 04:52:15.069656
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import ROLE_CACHE
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import plugin_loader

    ROLE_CACHE.clear()

    loader = DataLoader()
    collection_loader = AnsibleCollectionLoader(loader=loader, play=None, inventory=None)
    plugin_loader.add_directory(collection_loader._collection_base_paths[0])

    # old-style action, delegate_to and variables
    current_task_ds = {
        'action': {'module': 'ec2', 'region': 'xyz'},
        'delegate_to': 'xyz'
    }

# Generated at 2022-06-23 04:52:27.209548
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    import json
    import os

    # ModuleArgsParser.parse()
    # Test a simple line
    task_ds = {}
    action = 'copy'
    args = {'src': '/path/to/src', 'dest': '/path/to/dest'}
    delegate_to = 'some_host'
    task_ds.update({
        'action': action,
        'args': args,
        'delegate_to': delegate_to
    })
    res = ModuleArgsParser(task_ds=task_ds).parse()
    assert (res[0] == action) and (res[1] == args) and (res[2] == delegate_to)
    # Test with

# Generated at 2022-06-23 04:52:31.155374
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = {}
    mock_collection_list = {}
    task_data = ModuleArgsParser(mock_task_ds, mock_collection_list)
    result = task_data.parse()
    assert result == (None, {}, Sentinel)


# Generated at 2022-06-23 04:52:39.338317
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.plugins.action.normal import ActionModule as normal_action_plugin

    task_ds = {'action': 'command echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'command'
    assert '_raw_params' in args
    assert not delegate_to

    task_ds = {'action': 'command echo hi', 'delegate_to': 'test'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'command'
    assert '_raw_params' in args
    assert delegate_to == 'test'

    task_ds = {'action': {'module': 'command echo hi'}}

# Generated at 2022-06-23 04:52:50.392668
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    # Local action
    module_args = 'mock local_action=something'
    assert parser._normalize_parameters(module_args) == ('something', {})
    module_args = 'mock local_action="something else"'
    assert parser._normalize_parameters(module_args) == ('something else', {})
    module_args = 'local_action=something'
    assert parser._normalize_parameters(module_args) == ('something', {})
    module_args = 'local_action="something else"'
    assert parser._normalize_parameters(module_args) == ('something else', {})
    module_args = 'mock'
    assert parser._normalize_parameters(module_args) == ('mock', {})

# Generated at 2022-06-23 04:53:03.062135
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from test.unit.playbook.test_helpers import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class TestModuleArgsParser(ModuleTestCase):
        module = None

        def setUp(self):
            super(TestModuleArgsParser, self).setUp()
            self.mock_action_loader = ActionBase._construct_action_loader()

        def tearDown(self):
            # we're stubbing out the module finder, so make sure it's restored
            self.mock_action_loader = None
            ActionBase._construct_action_loader = self._orig_action_loader
            super(TestModuleArgsParser, self).tearDown()


# Generated at 2022-06-23 04:53:15.193528
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    p = ModuleArgsParser(dict(action='shell echo hi'))
    assert (p.parse() == ('shell', 'echo hi', None))
    assert (p.resolved_action is None)
    p = ModuleArgsParser(dict(action='shell', args='echo hi'))
    assert (p.parse() == ('shell', 'echo hi', None))
    assert (p.resolved_action is None)
    p = ModuleArgsParser(dict(action='shell', args=dict(arg1='val1', arg2='val2')))
    assert (p.parse() == ('shell', dict(arg1='val1', arg2='val2'), None))
    assert (p.resolved_action is None)
    p = ModuleArgsParser(dict(action='debug', args='msg=\'hi mom\''))

# Generated at 2022-06-23 04:53:26.091171
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    tester = '''
    foo:
      action: shell echo hello
    bar:
      action:
        module: ping
    baz:
      local_action: ping
    foobar:
      copy: src=a dest=b
    foobarbaz:
      ping:
    foobarbaz:
      ping: {{ host }}
    '''

    tasks = yaml.load(tester)

    parser = ModuleArgsParser(task_ds=tasks[0]['foo'])
    assert parser.parse() == ('shell', {'_raw_params': 'echo hello'}, None)
    parser = ModuleArgsParser(task_ds=tasks[0]['bar'])
    assert parser.parse() == ('ping', None, None)

# Generated at 2022-06-23 04:53:36.418896
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-23 04:53:49.844561
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_action = 'shell'
    test_args = "echo 'hello'"
    test_input = {'action': {test_action: test_args}}
    ret = ModuleArgsParser(task_ds=test_input).parse()
    assert ret == (test_action, {'_raw_params': test_args}, None)
    test_input = {'action': {test_action: {'_raw_params': test_args}}}
    ret = ModuleArgsParser(task_ds=test_input).parse()
    assert ret == (test_action, {'_raw_params': test_args}, None)
    test_input = {'action': {test_action: {'_uses_shell': True, '_raw_params': test_args}}}
    ret = ModuleArgsParser(task_ds=test_input).parse()


# Generated at 2022-06-23 04:53:58.954417
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    load_fixture(('./fixtures/collect_facts.yml', './fixtures/delegate_to.yml', './fixtures/meta_maintenance.yml', './fixtures/block.yml', './fixtures/raw_param_modules.yml'))
    parser = ModuleArgsParser(dict(), None)
    # Case 1: simple
    result = parser.parse()
    assert result == ('setup', {}, None)

    # Case 2: simple
    result = parser.parse()
    assert result == ('debug', {'msg': 'Task fields must be strings'}, None)

    # Case 3: simple
    result = parser.parse()
    assert result == ('command', {'_raw_params': 'echo hi', 'creates': '/tmp/myfile', 'executable': None}, 'other')



# Generated at 2022-06-23 04:54:02.905891
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    initial_task_ds = {'action': {'module': 'ec2', 'region': 'xyz'}}
    collection_list = []
    obj = ModuleArgsParser(initial_task_ds, collection_list)
    assert isinstance(obj, ModuleArgsParser)


# Generated at 2022-06-23 04:54:07.250729
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Should accept dict
    mug = ModuleArgsParser({})
    assert isinstance(mug, ModuleArgsParser)
    # Should not accept other parameters
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(None)

# Generated at 2022-06-23 04:54:08.100214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:54:19.693632
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:54:35.525456
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  action = 'debug'
  module_args = 'var=foo'
  m = {'action': {'module': 'debug', 'args': 'var=foo'}}

  # check inputs
  if not isinstance(m, dict):
    raise TypeError('m should be of type dict, but is a %s' % type(m))
  if not isinstance(action, string_types):
    raise TypeError('action should be of type string, but is a %s' % type(action))
  if not isinstance(module_args, string_types):
    raise TypeError('module_args should be of type string, but is a %s' % type(module_args))

  # check output
  _, args, _ = parse_action_args(m, action, module_args, None)

# Generated at 2022-06-23 04:54:43.303042
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'command', 'register': 'result', 'ignore_errors': True}
    mod_args_parser = ModuleArgsParser(task_ds=task_ds)

    action, args, delegate_to = mod_args_parser.parse(skip_action_validation=False)

    assert action == 'command'
    assert args == {'register': 'result', 'ignore_errors': True}
    assert delegate_to is Sentinel



# Generated at 2022-06-23 04:54:51.157240
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:58.730777
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook import task_ds
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleParserError

    # test parse behavior for pre-defined tasks
    for test in task_ds:
        parser = ModuleArgsParser(task_ds[test])
        (action, args, delegate_to) = parser.parse(skip_action_validation=False)
        assert action is not None
        assert isinstance(args, dict)
        assert delegate_to is not None

    # test parse behavior for RAW_PARAM_MODULES
    for module in RAW_PARAM_MODULES:
        task_dict = {'action': {'module': module, '_raw_params': '_param'}}
        parser = ModuleArgsParser(task_dict)

# Generated at 2022-06-23 04:55:08.030468
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class TestModuleArgsParser(object):
        def __init__(self, *args, **kwargs):
            self.ds = dict(*args, **kwargs)

        def parse(self, *args, **kwargs):
            parser = ModuleArgsParser(self.ds, *args, **kwargs)
            return parser.parse()

    # test_ds1 is an old-style invocation
    test_ds1 = dict(action=dict(module='mod1', a=1, b=2))
    assert TestModuleArgsParser(test_ds1, collection_list=None).parse() == ('mod1', {'a': 1, 'b': 2}, None)
    test_ds1 = dict(action='mod1 a=1 b=2')

# Generated at 2022-06-23 04:55:17.039010
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs = frozenset(task_attrs)

    test_task_ds = {}
    assert ModuleArgsParser(task_ds=test_task_ds)._task_attrs == task_attrs
    with pytest.raises(AnsibleAssertionError,
                       message="the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"):
        ModuleArgsParser(task_ds=None)

# Generated at 2022-06-23 04:55:27.621396
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'src': 'a', 'dest': 'b', 'file': 'c'}
    collection_list = None
    module_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_parser._task_ds == {'src': 'a', 'dest': 'b', 'file': 'c'}
    assert module_parser._task_attrs == frozenset(['any_errors_fatal', 'changed_when', 'failed_when', 'lambda', 'local_action', 'loop', 'loop_args', 'module', 'name', 'notify', 'register', 'retries', 'run_once', 'until', 'with_*', 'static'])
    assert module_parser.resolved_action is None


# Generated at 2022-06-23 04:55:38.692316
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # pytest only wants positional arguments
    obj = ModuleArgsParser(task_ds={})
    assert not obj.parse()
    obj = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert obj.parse() == ('shell', {}, Sentinel)
    obj = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    obj = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

# Generated at 2022-06-23 04:55:46.965942
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test Case: 1
    # Constructor of ModuleArgsParser Class should not throw any exception
    # and return the object of ModuleArgsParser class.
    mod_args_parser = ModuleArgsParser()
    assert isinstance(mod_args_parser, ModuleArgsParser)

    # Test Case: 2
    # Constructor of ModuleArgsParser Class should not throw any exception
    # and return the object of ModuleArgsParser class.
    mod_args_parser = ModuleArgsParser({})
    assert isinstance(mod_args_parser, ModuleArgsParser)



# Generated at 2022-06-23 04:55:56.872624
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:56:10.134164
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = ''
    # test non-dictionary task_ds
    mp = ModuleArgsParser(task_ds=None, collection_list='')
    with pytest.raises(AnsibleAssertionError):
        mp.parse()

    # test empty dictionary task_ds
    mp = ModuleArgsParser(task_ds={}, collection_list='')
    with pytest.raises(AnsibleParserError):
        mp.parse()

    # test normal task_ds
    mp = ModuleArgsParser(task_ds={'module': 'i18n'}, collection_list='')
    assert mp.parse() == ('i18n', {}, None)


# Generated at 2022-06-23 04:56:11.032284
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert 1

# Generated at 2022-06-23 04:56:21.486874
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict()
    data['action'] = 'shell echo hi'
    data['delegate_to'] = 'localhost'
    data['args'] = dict()
    data['args']['chdir'] = '/tmp'
    action, args, delegate_to = ModuleArgsParser(data).parse()
    assert action == 'shell'
    assert delegate_to == 'localhost'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True, 'chdir': '/tmp'}
    data['action'] = {'module': 'shell', 'chdir': '/tmp'}
    action, args, delegate_to = ModuleArgsParser(data).parse()
    assert action == 'shell'
    assert delegate_to == 'localhost'

# Generated at 2022-06-23 04:56:29.363295
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test good cases
    for task_ds in GOOD_PARSE_ARGS:
        action_vars = dict()
        module_args_parser = ModuleArgsParser(task_ds, action_vars)
        module_args_parser.parse()

    # test bad cases
    for task_ds in BAD_PARSE_ARGS:
        try:
            action_vars = dict()
            module_args_parser = ModuleArgsParser(task_ds, action_vars)
            module_args_parser.parse()
        except AnsibleParserError:
            pass
        else:
            raise Exception('Failed to catch expected parser error for bad task ' + repr(task_ds))

# Generated at 2022-06-23 04:56:40.176481
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {'shell': 'echo hi'},
        'delegate_to': 'localhost',
        'register': 'shell_output'
    }
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to == 'localhost'

    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'register': 'shell_output'
    }
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to == 'localhost'


# Generated at 2022-06-23 04:56:46.271839
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test ModuleArgsParser init
    task_ds = dict(action='echo hi')
    m_args_parser = ModuleArgsParser(task_ds)
    assert task_ds == m_args_parser._task_ds

    class FooCollection(object):
        def __init__(self):
            pass

    collection_list = [FooCollection()]
    m_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert task_ds == m_args_parser._task_ds
    assert collection_list == m_args_parser._collection_list


# Generated at 2022-06-23 04:56:54.773263
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Set the delegate_to to the value of the `delegate_to` argument of the 
    # constructor
    delegate_to = None
    # The following should be a valid basic task list.
    task_ds = dict(action='shell', args='/bin/false')

    # The following should be a valid basic task list.
    task_ds = dict(action='shell', args='/bin/false')
    # Expected result from the payload
    expected_results = ('shell', dict(args='/bin/false'),
                        None)

    module_args_parser = ModuleArgsParser(task_ds,collection_list=None)
    actual_results = module_args_parser.parse()

    assert actual_results == expected_results, "Expected %s, but got %s" % (expected_results, actual_results)

# Generated at 2022-06-23 04:56:55.858481
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-23 04:57:06.918861
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:57:16.423527
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("testing: test_ModuleArgsParser_parse")
    ds = {'name': 'test1', 'action': {'shell': 'ls -ltr'}}
    m = ModuleArgsParser(task_ds=ds)
    result = m.parse()
    assert result[0] == 'shell' and result[1] == {'_raw_params': 'ls -ltr'} and result[2] is None
    ds = {'name': 'test1', 'action': {'module': 'shell', 'args': {'chdir': '/tmp'}, 'freeform': 'ls -ltr'}}
    m = ModuleArgsParser(task_ds=ds)
    result = m.parse()

# Generated at 2022-06-23 04:57:28.439931
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser

    '''

    # Parsing a bare module name
    obj = ModuleArgsParser({'name': 'test-module'})
    assert obj.parse() == ('test-module', {}, None)

    # Parsing an action, with a single parameter
    obj = ModuleArgsParser({'name': 'test-module', 'action': {'module': 'test-module param=foo'}})
    assert obj.parse() == ('test-module', {'param': 'foo'}, None)

    # Parsing an action with a single parameter, and a delegate_to
    obj = ModuleArgsParser({'name': 'test-module', 'action': {'module': 'test-module param=foo'}, 'delegate_to': 'bar'})

# Generated at 2022-06-23 04:57:36.677590
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    expected_type = ('shell', {u'_uses_shell': True, u'_raw_params': u'echo hi'}, Sentinel)
    test_value = module_args_parser.parse({'action': 'shell: echo hi'})
    assert isinstance(test_value, tuple)
    assert test_value == expected_type
    expected_type = ('shell', {u'_uses_shell': True, u'_raw_params': u'echo hi'}, Sentinel)
    test_value = module_args_parser.parse({'local_action': 'shell: echo hi'})
    assert isinstance(test_value, tuple)
    assert test_value == expected_type

# Generated at 2022-06-23 04:57:40.907112
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # make sure we get the right exception for weird input
    ds = dict(action=1)
    try:
        ModuleArgsParser(task_ds=ds)
        assert False, "should have thrown an error"
    except AnsibleAssertionError as e:
        assert "should be a dict" in to_native(e)



# Generated at 2022-06-23 04:57:48.368270
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser({"action": {"module": "shell", "args": {"_raw_params": "echo hi", "chdir": "/tmp"}}}, ["ansible_collections.org.myorg.mycollection"])

    assert module_arg_parser.parse() == ('shell',
                                         {'chdir': '/tmp', '_raw_params': 'echo hi'},
                                         None)

# Generated at 2022-06-23 04:57:59.427765
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action='echo hi',
        delegate_to='127.0.0.1',
        args=dict(
            key1='val1',
            key2='val2'
        )
    )
    module_arg_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'echo hi'
    assert args == dict(
        key1='val1',
        key2='val2'
    )
    assert delegate_to == '127.0.0.1'

    task_ds = dict(
        module='echo hi',
        delegate_to='127.0.0.1',
        args=dict(
            key1='val1',
            key2='val2'
        )
    )


# Generated at 2022-06-23 04:58:12.608997
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test old style invocations
    # test module: <stuff>
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test module: <stuff>
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test local_action: <stuff>

# Generated at 2022-06-23 04:58:21.954801
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # initialize an object of class ActionModule
    action = ActionModule(None, 'ping', None, None)
    # initialize an object of class ModuleArgsParser
    module_arg_parser = ModuleArgsParser(action.task_ds, action.collection_list)
    # validate if the parser object is initialized
    assert isinstance(module_arg_parser, ModuleArgsParser)
    # parse and validate the action
    action.action, action.args, action.delegate_to = module_arg_parser.parse()
    assert action.action == 'ping'



# Generated at 2022-06-23 04:58:32.847816
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import PlaybookIncludeSpec
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    task_ds1 = {}
    task_ds2 = {'var': 'foo'}
    task_ds3 = {'local_action': 'shell echo hi'}
    task_ds4 = {'action': 'copy src=a dest=b'}

# Generated at 2022-06-23 04:58:43.082330
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    unit test for constructor of class ModuleArgsParser
    '''
    task_ds = {'name': 'test task', 'delegate_to': 'abc'}
    collection_list = [ 'a', 'b' ]
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser._task_ds == task_ds
    assert parser._collection_list == collection_list
    assert parser.resolved_action is None

    parser = ModuleArgsParser()
    assert parser._task_ds == {}
    assert parser._collection_list is None
    assert parser.resolved_action is None


# Generated at 2022-06-23 04:58:47.578873
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    class Object(object): pass
    collection_list = Object()
    collection_list.collection_directory_paths = []
    collection_list.collections = ['import_playbook']
    parser = ModuleArgsParser(task_ds, collection_list)
    parser.parse()

# Generated at 2022-06-23 04:58:59.112299
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Create an instance of ModuleArgsParser
    module_args_parser = ModuleArgsParser()

    assert(module_args_parser._task_ds == {})
    assert(module_args_parser._task_attrs == frozenset(['name', 'local_action', 'static', 'tags', 'async_val', 'async_seconds', 'poll', 'ignore_errors', 'register', 'notify', 'when', 'first_available_file', 'sudo', 'sudo_user', 'sudo_pass', 'become', 'become_user', 'become_method', 'become_flags', 'become_ask_pass']))
    assert(module_args_parser._collection_list is None)
    assert(module_args_parser.resolved_action is None)

    # Create an instance of ModuleArgsParser
    module_args

# Generated at 2022-06-23 04:59:10.770790
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:59:14.001722
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    
    # Arrange

    # Act
    moduleArgsParser = ModuleArgsParser()

    # Assert
    assert moduleArgsParser



# Generated at 2022-06-23 04:59:24.829445
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test the constructor of the class ModuleArgsParser, the method parse()
    # is not tested here since the parse() method will be called in class
    # TaskInclude.
    task_invalid_ds1 = {
        'action': {'module': 'shell'},
    }

    task_invalid_ds2 = {
        'action': 'shell',
        'local_action': 'command',
    }

    task_invalid_ds3 = {
        'action': 'shell',
        'module': 'command',
    }

    # Test for invalid task_ds.
    try:
        ModuleArgsParser(task_ds=task_invalid_ds1)
    except AnsibleParserError:
        pass


# Generated at 2022-06-23 04:59:28.863928
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'test': 'value'
    }
    module_args = ModuleArgsParser(task_ds, None)
    action, _, _ = module_args.parse()
    assert action == 'test'


# Generated at 2022-06-23 04:59:40.840707
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from os.path import join, dirname, abspath
    data_path = join(dirname(abspath(__file__)), 'data')
    action_loader.add_directory(join(data_path, 'action_plugins'))
    module_loader.add_directory(join(data_path, 'modules'))
    collection_loader.set_collection_paths([join(data_path, 'collections')])
    task = Task(dict(), collection_list=collection_loader.get_collections())

    # test parse shell module
    with open(join(data_path, 'test_data', 'task_parse_shell_module.yml')) as shell_module:
        task._ds = yaml.safe_load

# Generated at 2022-06-23 04:59:52.388788
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 05:00:00.222213
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    from ansible.playbook import Task
    task = Task()
    task._ds = {}
    (action, args, delegate_to) = parser.parse(task._ds)
    # assertEquals(expected, actual)
    raise NotImplementedError()

# for testing purposes, we want to also include items in namespace
# when we're doing isinstance, so we'll patch that
init = object.__init__

# Generated at 2022-06-23 05:00:08.041003
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.attribute import FieldAttribute

    field = FieldAttribute(
        names={'action', 'local_action'} ,
        private=True,
        expected_type=dict,
        fallback=dict(module='noop', args=dict(), delegate_to=None)
    )
    check = ModuleArgsParser(dict(module='ping', args=dict(data='pong')))
    assert check.parse() == ('ping', {'data': 'pong'}, None)

    check = ModuleArgsParser(dict(action=dict(module='shell', args='echo hi', chdir='/tmp')))
    assert check.parse() == ('shell', {'args': 'echo hi', 'chdir': '/tmp'}, None)


# Generated at 2022-06-23 05:00:17.044785
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # test our constructor with valid arguments
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert isinstance(parser, ModuleArgsParser)

    # test our constructor with invalid arguments
    try:
        parser = ModuleArgsParser(1)
        raise AssertionError('Expected to receive an instance of AnsibleAssertionError')
    except AnsibleAssertionError:
        pass

    # ensure that the constructor correctly set the "_task_ds" attribute
    assert isinstance(parser._task_ds, dict)
    assert parser._task_ds == task_ds

    # ensure that the constructor correctly set the "_task_attrs" attribute
    assert isinstance(parser._task_attrs, frozenset)


# Generated at 2022-06-23 05:00:23.620145
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit test for constructor of class ModuleArgsParser
    '''
    # WIP: AssertionError: unexpected parameter type in action: <class 'str'>
    pass
