

# Generated at 2022-06-23 04:50:23.480620
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None


# Generated at 2022-06-23 04:50:36.139847
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # empty task
    task = {}
    map = ModuleArgsParser(task_ds=task, collection_list=None)
    assert map._task_ds == task
    assert map._collection_list is None
    assert map._task_attrs is not None
    assert map.resolved_action is None

    # task with delegate_to
    task['delegate_to'] = 'xxx'
    map = ModuleArgsParser(task_ds=task, collection_list=None)
    assert map._task_ds == task
    assert map._collection_list is None
    assert map._task_attrs is not None
    assert map.resolved_action is None


# Generated at 2022-06-23 04:50:39.948740
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        "shell": "some_long_command",
        "delegate_to": "localhost"
    }
    obj = ModuleArgsParser(task_ds)
    assert len(obj._task_attrs) > 0



# Generated at 2022-06-23 04:50:43.506968
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module = ModuleArgsParser(task_ds={'action': 'shell whoami'})
    assert module is not None

# Generated at 2022-06-23 04:50:54.882405
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:50:59.533054
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()

    # Empty task_ds
    module_args_parser._task_ds = dict()
    with pytest.raises(AnsibleAssertionError):
        module_args_parser.parse()


# Generated at 2022-06-23 04:51:10.428770
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action, args, delegate_to = ActionModule._parse_action_args({'foo': 'bar'}, collection_list=None)
    assert action == 'foo' and len(args) == 1 and args.get('foo') == 'bar'
    assert delegate_to is None

    action, args, delegate_to = ActionModule._parse_action_args({'action': 'foo bar'}, collection_list=None)
    assert action == 'foo' and len(args) == 1 and args.get('bar') is True
    assert delegate_to is None

    action, args, delegate_to = ActionModule._parse_action_args({'local_action': 'foo bar'}, collection_list=None)
    assert action == 'foo' and len(args) == 1 and args.get('bar') is True
    assert delegate_to == 'localhost'

# Generated at 2022-06-23 04:51:23.942808
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    simple_task_ds = dict(
        action=dict(
            module='ping',
            args=dict(
                data='pong',
            ),
        ),
    )

    parser = ModuleArgsParser(task_ds=simple_task_ds)
    assert isinstance(parser, ModuleArgsParser)

    assert parser._task_ds == simple_task_ds
    assert parser._task_attrs == frozenset(['action'])
    assert parser.resolved_action is None

    # This is currently broken, because the loader is not mocked out
    # simple_task_ds = dict(
    #     command=dict(
    #         module='echo',
    #         args=dict(
    #             data='pong',
    #         ),
    #     ),
    # )
    # parser = ModuleArgsParser(task

# Generated at 2022-06-23 04:51:30.015496
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a new instance of class ModuleArgsParser
    obj = ModuleArgsParser()

    # The task_ds is a dict
    task_ds = {
        'action': '{{ variable }}',
        'delegate_to': 'localhost',
        'args': {
            'another_variable': '{{ variable }}'
        }
    }
    # Check we raise the error if the type of task ds is not a dict
    with pytest.raises(AnsibleAssertionError):
        # Call the method parse
        args = obj.parse(task_ds=task_ds)

# Generated at 2022-06-23 04:51:38.743212
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {"action": "shell echo hi"}
    # not raise AnsibleAssertionError
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {"local_action": "shell echo hi"}
    # not raise AnsibleAssertionError
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {"shell": "shell echo hi"}
    # not raise AnsibleAssertionError
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {"action": {"module": "shell echo hi"}}
    # not raise AnsibleAssertionError
    ModuleArgsParser(task_ds=task_ds)
    task_ds = {"action": {"module": "shell echo hi"}, "delegate_to": "localhost"}
    # not raise AnsibleAssertionError


# Generated at 2022-06-23 04:51:41.258506
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None


# Unit tests for parse() in class ModuleArgsParser

# Generated at 2022-06-23 04:51:53.220904
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test with an empty task_ds
    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._collection_list == None
    assert isinstance(module_args_parser._task_attrs, frozenset)
    assert module_args_parser.resolved_action == None

    # test with task_ds, collection_list
    task_ds = {'key': 'value'}
    collection_list = ['collections']
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._collection_list == collection_list
    assert isinstance

# Generated at 2022-06-23 04:52:02.982837
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test_invalid_task_ds_type():
        task_ds = [1]
        parser = ModuleArgsParser(task_ds=task_ds)
        parser.parse()

    with pytest.raises(AnsibleAssertionError) as exec_info:
        test_invalid_task_ds_type()
    print('Exception expected from calling parse() with invalid task_ds: {0}.'.format(exec_info.value))

    def test_empty_task_ds():
        task_ds = {}
        parser = ModuleArgsParser(task_ds=task_ds)
        action, args, delegate_to = parser.parse()
        assert action == None
        assert args == None
        assert delegate_to == None


# Generated at 2022-06-23 04:52:07.779703
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser()
    assert module_arg_parser.parse(skip_action_validation=False) == (None, {}, 'localhost')
    assert module_arg_parser.parse(skip_action_validation=False) == (None, {}, 'localhost')



# Generated at 2022-06-23 04:52:19.563236
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # The following module definitions were found in an ansible repository
    # ds = {}
    ds = {'action': {'module': 'shell', 'executable': '/bin/sh'}}
    # ds = {'action': {'module': 'ec2', 'region': 'us-east-1', 'ec2_url': 'https://ec2.us-east-1.amazonaws.com', 'validate_certs': True, 'aws_secret_key': '<secret>', 'aws_access_key': '<secret>'}}
    # ds = {'action': {'module': 'ec2', 'region': 'us-east-1', 'ec2_url': 'https://ec2.us-east-1.amazonaws.com', 'validate_certs': True, 'aws_secret_key': '

# Generated at 2022-06-23 04:52:28.118079
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    result_dict = {
        "fail": {
            "msg": "This is a fail example!"
        },
        "local_action": {
            "args": {
                "hostname": "{{ inventory_hostname }}"
            },
            "module": "shell"
        }
    }
    for _, value in iteritems(result_dict):
        # Test the __init__ of class ModuleArgsParser
        if not isinstance(value, dict):
            raise AnsibleAssertionError("the type of 'task_ds' should be a dict, but is a %s" % type(value))

        # Test the parse of class ModuleArgsParser
        if 'module' in value:
            if not isinstance(value, dict):
                raise AnsibleParserError("unexpected parameter type in action: %s" % type(value))


# Generated at 2022-06-23 04:52:36.807355
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import unittest

    class TestModuleArgsParser(unittest.TestCase):
        def test_parser_canonical(self):
            task = {"action": "copy",
                    "args": {
                        "src": "a",
                        "dest": "b"
                    }
                    }
            module_args_parser = ModuleArgsParser(task)
            (action, args, delegate_to) = module_args_parser.parse()
            self.assertEqual(action, "copy")
            self.assertEqual(args, {"src": "a", "dest": "b"})

        def test_parser_legacy_action(self):
            task = {"action": "copy src={{ src_path }} dest={{ dest_path }}"}
            module_args_parser = ModuleArgsParser(task)

# Generated at 2022-06-23 04:52:48.222244
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'local_action': {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}},
               'delegate_to': 'localhost'}

    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    task_ds = {'local_action': {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}, 'x': 'y'},
               'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-23 04:52:59.149836
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:53:08.236250
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Provides code coverage for the __init__ method of the
    # ModuleArgsParser class.
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    test_module_args_parser = ModuleArgsParser()
    assert set(test_module_args_parser._task_attrs) == set(Task._valid_attrs.keys())
    assert set(test_module_args_parser._task_attrs) == set(Handler._valid_attrs.keys())


# Generated at 2022-06-23 04:53:11.595507
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_args_parser = args_parser.ModuleArgsParser()
    my_args_parser.parse(skip_action_validation=False)


# -----------------------------------------------------
# Base class for modules
# -----------------------------------------------------


# Generated at 2022-06-23 04:53:15.222392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    result = ModuleArgsParser(task_ds, collection_list).parse()
    assert result == (None, {}, None)



# Generated at 2022-06-23 04:53:23.914926
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Unit test for the parse method of the ModuleArgsParser class."""
    # Given
    task_ds = dict(
        action='echo hi',
        delegate_to='xyz',
        static='yes'
    )
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    # When
    action, args, delegate_to = module_args_parser.parse()

    # Then
    assert action == 'echo'
    assert 'hi' in args
    assert delegate_to == 'xyz'

    # Given
    task_ds = dict(
        module='copy src=a dest=b',
        static='yes'
    )
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    # When

# Generated at 2022-06-23 04:53:33.530787
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    my_task_ds = {'name': 'test_task'}
    # test case 1
    test_task_ds1 = {'name': 'test_task', 'action': 'copy src=a dest=b'}
    my_task_ds.update(test_task_ds1)
    mod_args_parser = ModuleArgsParser(task_ds=my_task_ds)
    action, args, delegate_to = mod_args_parser.parse(skip_action_validation=False)
    assert action == 'copy'

# Generated at 2022-06-23 04:53:43.943359
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from collections import namedtuple

    args = namedtuple('args', [])
    args.extra_vars = dict()
    args.enable_plugins = ['nope']
    args.playbook_dir = None
    args.inventory = './tests/units/inventory.{}'.format(__inventory_filetype__)
    args.inventory_basedir = './tests/units'

    # Initialize with an empty dict as configured plugin list
    config = Configuration(args)
    plugin_loader = PluginLoader('./lib/ansible/plugins/', './lib/plugins/', config.enable_plugins)
    module_loader = PluginLoader('./lib/ansible/modules/', './lib/ansible_modules/', config.enable_plugins)

# Generated at 2022-06-23 04:53:54.538673
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader = None
    data = dict()
    data['action'] = dict()
    data['action']['module'] = 'module'
    data['action']['args'] = 'args'
    data['action']['delegate_to'] = None
    data['action']['args'] = 'args'
    data['action']['_raw_params'] = 'raw_params'
    data['action']['_variable_params'] = ''
    data['action']['_uses_shell'] = True
    data['action']['_raw_module'] = 'module2'
    data['action']['local_action'] = dict()
    data['action']['local_action']['module'] = 'module'

# Generated at 2022-06-23 04:54:04.247304
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    include_ds = dict(
        include_tasks='some_include',
        static='some static value'
    )
    for ds in [
        dict(action='some_action'),
        dict(local_action='some_local_action'),
        dict(block=include_ds),
        dict(rescue=include_ds),
        dict(always=include_ds),
        dict(
            include_tasks='some_include',
            static='some static value'
        )
    ]:
        # Test constructor
        x = ModuleArgsParser(ds)


# Generated at 2022-06-23 04:54:12.704269
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    arguments = dict(
        action='foo',
        delegate_to='localhost',
        y='123',
        args=dict(
            foo='bar',
            baz='qux',
        ),
    )
    expected = ('foo', dict(foo='bar', baz='qux', y='123'), 'localhost')

    parser = ModuleArgsParser(task_ds=arguments)
    result = parser.parse()

    assert result == expected

# Generated at 2022-06-23 04:54:25.488462
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test parse function of class ModuleArgsParser
    """

    ########################
    # action: copy src=a b c dest=/tmp
    ########################
    task_ds = {'action': 'copy src=a b c dest=/tmp'}
    obj = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = obj.parse()
    assert action == 'copy'
    assert args['src'] == 'a b c'
    assert args['dest'] == '/tmp'
    assert delegate_to is None

    ########################
    # action: copy "src=a b c" dest=/tmp
    ########################
    task_ds = {'action': 'copy "src=a b c" dest=/tmp'}
    obj = ModuleArgsParser(task_ds)

# Generated at 2022-06-23 04:54:34.556301
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_module_args_parser_parse = {
        "delegate_to": None,
        "local_action": None,
        "module": "command",
        "args": {
            "chdir": "/tmp"
        }
    }
    map = ModuleArgsParser(task_ds=test_module_args_parser_parse, collection_list=[])
    action, args, delegate_to = map.parse()
    assert action == "command"
    assert args == {'chdir': '/tmp'}
    assert delegate_to is None
    return

# Generated at 2022-06-23 04:54:37.005329
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    assert parser


# Generated at 2022-06-23 04:54:46.469639
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def _check_result(result, action, args, delegate_to):
        assert result[0] == action
        assert result[1] == args
        assert result[2] == delegate_to

    def _check(task_ds, action, args, delegate_to):
        parser = ModuleArgsParser(task_ds)
        result = parser.parse()
        _check_result(result, action, args, delegate_to)

    _check(task_ds={'action': 'copy src=a dest=b'},
           action='copy', args={'src': 'a', 'dest': 'b'}, delegate_to=None)

    _check(task_ds={'module': 'copy src=a dest=b'},
           action='copy', args={'src': 'a', 'dest': 'b'}, delegate_to=None)

# Generated at 2022-06-23 04:54:53.188827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser=ModuleArgsParser()
    action, args, delegate_to=module_args_parser.parse(skip_action_validation=True)
    
    print(action, args, delegate_to)


# Generated at 2022-06-23 04:54:56.223917
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert module_args_parser


# Unit tests for _normalize_new_style_args()

# Generated at 2022-06-23 04:55:06.315377
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test 'action' parser
    task_ds = {
        'action': 'ec2_group name=nginx description=nginx access rules={{ rules }}'
    }
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('ec2_group', dict(name='nginx', description='nginx access', rules='{{ rules }}'), None)

    # test 'action' parser - multiple arguments
    task_ds = {
        'action': 'ec2_group name=nginx rules={{ rules }}'
    }
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('ec2_group', dict(name='nginx', rules='{{ rules }}'), None)

    # test 'action' parser - complex arguments

# Generated at 2022-06-23 04:55:17.962404
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Constructor test case
    with pytest.raises(AnsibleAssertionError) as exc:
        m = ModuleArgsParser(task_ds = [])
    assert "the type of 'task_ds' should be a dict" in to_text(exc.value)

    # Constructor test case
    with pytest.raises(AnsibleAssertionError) as exc:
        m = ModuleArgsParser(task_ds = None)
    assert "the type of 'task_ds' should be a dict" in to_text(exc.value)

    # Parse method test case
    m = ModuleArgsParser(collection_list=[])
    m._task_ds = dict(action=dict(module='shell', _raw_params='ls', delegate_to='localhost'))
    action, args, delegate_to = m.parse

# Generated at 2022-06-23 04:55:28.622900
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse_0
    assert 'dict' == ModuleArgsParser(task_ds = dict()).parse()[0]
    # test_ModuleArgsParser_parse_1
    assert 'list' == ModuleArgsParser(task_ds = list()).parse()[0]
    # test_ModuleArgsParser_parse_2
    assert 'ping' == ModuleArgsParser(task_ds = dict(action = dict(module = 'ping'))).parse()[0]
    # test_ModuleArgsParser_parse_3
    assert 'ping' == ModuleArgsParser(task_ds = dict(action = 'ping')).parse()[0]
    # test_ModuleArgsParser_parse_4
    assert 'ping' == ModuleArgsParser(task_ds = dict(ping = dict())).parse()[0]
    # test_Module

# Generated at 2022-06-23 04:55:31.027240
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    results = ModuleArgsParser({}).parse()

    assert(results == (None, dict(), None)), 'module args parser did not return correct result for given task'

# Generated at 2022-06-23 04:55:40.589158
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = None
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_ds == {}
    assert parser._collection_list is None

    task_ds = []
    with pytest.raises(AnsibleAssertionError) as excinfo:
        parser = ModuleArgsParser(task_ds=task_ds)
    assert 'should be a dict, but is a ' in to_text(excinfo)

    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'dest': 'b', 'src': 'a'}
    assert delegate_to is Sentinel


# Generated at 2022-06-23 04:55:42.924191
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser().parse()
    assert result is not None

# Generated at 2022-06-23 04:55:54.181074
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"action": "shell", "_ansible_verbosity": 0, "delegate_to": "", "become": False, "become_method": "sudo",
               "become_user": "root", "environment": "", "run_once": False, "no_log": False, "rc": 0, "sudo": True,
               "sudo_user": "root", "warn": True}
    t = ModuleArgsParser(task_ds)
    action, args, delegate_to = t.parse()
    assert_equal(action, "shell")
    assert_equal(args, {})
    assert_equal(delegate_to, "")


# Generated at 2022-06-23 04:56:03.487897
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert parser.parse() == (None, {}, Sentinel)

    # test_dict_arg

# Generated at 2022-06-23 04:56:13.739426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import datetime

# Generated at 2022-06-23 04:56:20.539206
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a new object instance named t_ModuleArgsCopy
    t_ModuleArgsCopy = ModuleArgsParser(task_ds={
        'action': 'copy'
    })
    # Execute the method parse of the class ModuleArgsParser
    result = t_ModuleArgsCopy.parse()
    # Get the expected value from stdout
    expected = (u'copy', {}, None)
    # Check if the result is the expected one
    assert result == expected, "result: %s. expected: %s" % (result, expected)

# Generated at 2022-06-23 04:56:28.789283
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    global_task_vars = VariableManager()
    inventory = InventoryManager(loader=None, sources=[])
    play_context = PlayContext()
    loader = DataLoader()
    templar = Templar(loader, variables=global_task_vars)

# Generated at 2022-06-23 04:56:37.753436
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = dict(
        delegate_to = 'localhost',
        action = 'copy',
        args = dict(
            src = 'a',
            dest = 'b'
        )
    )
    module_args_parser = ModuleArgsParser(dict(action="copy src=a dest=b", args=dict(src="a", dest="b")))
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'copy'
    assert args == dict(src="a", dest="b")
    assert delegate_to == 'localhost'


# Generated at 2022-06-23 04:56:48.666183
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def do_test(task_ds, collection_list, expected_action, expected_args, expected_delegate_to):
        module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
        action, args, delegate_to = module_args_parser.parse()
        assert (action, args, delegate_to) == (expected_action, expected_args, expected_delegate_to)

    delegate_to = 'xyz'
    assert_results = dict(action=None, args=dict(), delegate_to=None)


# Generated at 2022-06-23 04:56:50.127850
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    assert isinstance(ModuleArgsParser(), ModuleArgsParser)


# Generated at 2022-06-23 04:56:56.314706
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(
        task_ds={'shell': 'echo hi'},
        collection_list=[])
    assert(module_args_parser)


# Generated at 2022-06-23 04:56:58.678890
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "Need to implement unit test for method parse of class ModuleArgsParser"

# Generated at 2022-06-23 04:57:10.155743
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Parser supports all the types of module names specified in the WHO_CAN_I_RESOLVE section
    # of the add_action method in the plugins/action/__init__.py file
    # No errors raised by parser, when correct module_name is passed in the task
    assert ModuleArgsParser().parse(task_ds={'module_name':'echo'}, skip_action_validation=True) == ('module_name','','localhost')
    # Error raised by parser, when incorrect module_name is passed in the task
    with pytest.raises(AnsibleParserError) as error:
        ModuleArgsParser().parse(task_ds={'action_name':'echo'}, skip_action_validation=True)  

# Generated at 2022-06-23 04:57:22.083133
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test basic instantiation of class
    task_data = dict()
    parser = ModuleArgsParser(task_ds=task_data)
    assert len(parser._task_ds) == 0
    assert parser.resolved_action is None

    actual = parser._split_module_string("echo hi")
    assert actual == ("echo", "hi")

    actual = parser._split_module_string("echo hi there")
    assert actual == ("echo", "hi there")

    actual = parser._split_module_string("echo")
    assert actual == ("echo", "")

    actual = parser._split_module_string("")
    assert actual == ("", "")

# Generated at 2022-06-23 04:57:34.305665
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._options = Options()

    loader = DataLoader()


# Generated at 2022-06-23 04:57:43.429992
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_spec = dict(
        action=dict(type='str', required=True),
        delegate_to=dict(type='str'),
        args=dict(type='dict')
    )

    # Test invalid action in task
    task_ds1 = dict(
        name='test1',
        action='invalid_action',
    )
    with raises(AnsibleParserError):
        ModuleArgsParser(task_ds1, collection_list=None).parse()

    # Test task without action or invalid action
    task_ds2 = dict(
        name='test2',
    )
    with raises(AnsibleParserError):
        ModuleArgsParser(task_ds2, collection_list=None).parse()

    # Test valid task with 'ping' builtin action

# Generated at 2022-06-23 04:57:52.349703
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # a fake task with a 'shell' argument
    data = {'task':
                {'action': 'shell',
                 'something': 'echo {{fqdn}}',
                 'args': {'chdir': '/tmp/xyz'}}}
    task_ds = data.get('task')
    module_args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = module_args_parser.parse()
    # value of variable 'action' seems right
    assert action == 'shell'
    assert args == {'chdir': '/tmp/xyz'}
    assert delegate_to == None


# Generated at 2022-06-23 04:58:02.327566
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs = frozenset(task_attrs)
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)
    task_ds = {'action': {'module': 'copy', 'src': 'a'}, 'delegate_to': 'localhost', 'args': {}}
    # test module name was detected, but no

# Generated at 2022-06-23 04:58:14.078738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    parser = ModuleArgsParser(task_ds=None)
    assert isinstance(parser, ModuleArgsParser)
    with pytest.raises(AnsibleParserError):
        parser._split_module_string(module_string=None)
    with pytest.raises(AnsibleParserError):
        parser._normalize_parameters(thing=None, action=None, additional_args=None)
    assert (parser._normalize_new_style_args(thing=None, action=None) == None)

# Generated at 2022-06-23 04:58:24.122514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test task being parsed
    test_task_old_style_action_string = '''
    - action: copy src=a dest=b
    '''
    test_task_old_style_action_dict = '''
    - action:
        module: copy src=a dest=b
    '''
    test_task_old_style_action_dict_2 = '''
    - action:
        module: copy
        args:
          src: a
          dest: b
    '''
    test_task_new_style_action_string = '''
    - copy: src=a dest=b
    '''
    test_task_new_style_action_dict = '''
    - copy:
        src: a
        dest: b
    '''
    test_task_old_style_local_action

# Generated at 2022-06-23 04:58:33.939999
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser(None)
    module_args = {'get_url': {'dest': '/etc/foo', 'url': 'https://www.example.com/foo.gz', 'force': 'yes'}}
    with pytest.raises(AnsibleParserError) as excinfo:
        result = args_parser._normalize_old_style_args(module_args)
    assert 'unexpected parameter type in action: <class' in to_text(excinfo)

    module_args = {'get_url': {'dest': '/etc/foo', 'url': 'https://www.example.com/foo.gz', 'force': 'yes'},
                   'action': 'get_url'}

# Generated at 2022-06-23 04:58:46.323965
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.display import Display
    display = Display()

    # 1. task_ds is not a dict
    # No need to check

    # 2. task_ds is a dict
    display.display("Test task_ds is a dict")
    task_ds = {"a": 1}
    assert ModuleArgsParser(task_ds=task_ds)._task_ds == task_ds

    # 3. task_ds is a dict but is None
    display.display("Test task_ds is a dict but is None")
    assert ModuleArgsParser(task_ds=None)._task_ds == {}
    assert ModuleArgsParser()._task_ds == {}

    # 4. task_ds is no_log attribute
    task_ds = dict(no_log=True)

# Generated at 2022-06-23 04:58:57.851026
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test normal cases
    task_ds = {}
    map = ModuleArgsParser(task_ds=task_ds)
    assert map._task_ds == task_ds
    assert map._collection_list is None

    task_ds = { 'foo': 'bar' }
    collection_list = ['list-item']
    map = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert map._task_ds == task_ds
    assert map._collection_list == collection_list

    # Test expected exceptions
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=['list', 'item'])

    # Test expected exception when invalid type is passed

# Generated at 2022-06-23 04:59:09.806262
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:59:23.066423
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    my_task_ds = dict(action=dict(module='copy', src='a', dest='b'), local_action='shell echo hi', delegate_to='localhost')
    loader = DictDataLoader({
        'hello.yml': """
            - ping:
            - local_action:
                module: copy
                src: a
                dest: b
            - shell: echo hi
            - local_action: shell echo hi
            - action: shell echo hi
            - action: copy src=a dest=b
            - action:
              - shell: echo hi
            - action:
              - copy: src=a dest=b
            - action:
              - copy: { src: a, dest: b }
        """
    })
    m = Module

# Generated at 2022-06-23 04:59:24.765523
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass



# Generated at 2022-06-23 04:59:35.514224
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # A task dictionary containing key 'action':
    task_ds = dict(action='copy src=a dest=b')
    # Initialize parser with task dictionary:
    parser = ModuleArgsParser(task_ds, None)
    # Check if module is using _split_module_string:
    assert parser._split_module_string('copy src=a dest=b') == ('copy', 'src=a dest=b')
    # Check if module is using _normalize_parameters:
    assert parser._normalize_parameters('echo hi', 'shell') == ('shell', dict(_raw_params='echo hi', _uses_shell=True))
    assert parser._normalize_parameters('something', 'shell') == ('shell', dict(_raw_params='something', _uses_shell=True))
    # Check if module is using _normalize_old_

# Generated at 2022-06-23 04:59:43.710271
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = ['ansible_collections.ansible.builtin',
                       'ansible_collections.my_namespace.my_collection',
                       'ansible.builtin']

    parser = ModuleArgsParser(task_ds, collection_list)
    # Get the result, without actually executing the method
    with patch.object(ModuleArgsParser,
                      '_normalize_old_style_args',
                      return_value=('shell', 'echo hi')):
        result = parser.parse()
    # Asserts
    assert result == ('shell', 'echo hi', NoValue)


# Generated at 2022-06-23 04:59:52.772843
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    simple_task = dict(action="shell echo hi")
    simple_module_args_parser = ModuleArgsParser(task_ds=simple_task)
    simple_module_args_parser.parse()

    complex_task = dict(action=dict(module="shell", _raw_params="echo hi"))
    complex_module_args_parser = ModuleArgsParser(task_ds=complex_task)
    complex_module_args_parser.parse()

    raw_task = dict(action=dict(module="shell", _raw_params="echo hi", _uses_shell=True))
    raw_module_args_parser = ModuleArgsParser(task_ds=raw_task)
    raw_module_args_parser.parse()


# Generated at 2022-06-23 05:00:04.432572
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 05:00:14.127052
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds_list = [
        # test non-dict type
        'not-a-dict',

        # test invalid 'delegate_to' type
        {'delegate_to': 123},

        # test valid 'delegate_to' type
        {'delegate_to': 'invalid.host'},
    ]

    for task_ds in task_ds_list:
        if not isinstance(task_ds, dict):
            try:
                ModuleArgsParser(task_ds)
                assert False, "Expected AnsibleAssertionError for unexpected type of 'task_ds'"
            except AnsibleAssertionError:
                pass
        else:
            parser = ModuleArgsParser(task_ds)
            if 'delegate_to' in task_ds:
                assert parser._task_ds['delegate_to']

# Generated at 2022-06-23 05:00:20.233908
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict()
    args['action'] = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    args['local_action'] = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    args['module'] = 'copy'
    parser = ModuleArgsParser(task_ds=args)
    result = parser.parse()
    assert  result[2] is None
    result = parser.parse(skip_action_validation=True)
    assert  result[2] is None

# Generated at 2022-06-23 05:00:29.806097
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.play_context import PlayContext

    class FakeTask(object):
        def __init__(self, action, args, delegate_to=None):
            self.action = action
            self.args = args
            self.delegate_to = delegate_to

    class TestTask(object):
        def __init__(self):
            self.async_val = 60
            self.async_poll_interval = 15
            self.args = {}
            self.action = ""

        def _load_args(self, ds):
            return ModuleArgsParser(ds).parse()

        def _load_async(self, ds):
            if ds.get('async', None) is not None:
                self.async_val = int(ds['async'])