

# Generated at 2022-06-23 04:50:29.656032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'debug': 'msg="{{foo}}"',
        'action': "setup",
        'args': {
            'filter': "ansible_*_ipv4",
        },
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse(skip_action_validation=False) == ('setup', {'filter': 'ansible_*_ipv4'}, None)

# Generated at 2022-06-23 04:50:37.707002
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {
            'module': 'ansible.builtin.copy',
            'args': {
                'src': 'dest',
                '_raw_params': 'echo hi',
            },
        }
    }
    parser = ModuleArgsParser(task_ds=task_ds)
    parser.parse()

    # action, args, delegate_to = (action, args, delegate_to)

    print('action: {0}'.format(action))
    print(args)
    print(delegate_to)

################################################################################
# class ModuleShim


# Generated at 2022-06-23 04:50:50.912899
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test the ModuleArgsParser.parse method on different task_ds
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse(task_ds={'module': 'shell', 'args': 'echo hi'})
    assert action == 'shell'
    assert isinstance(args, dict)
    assert args == {'echo hi': ''}
    assert delegate_to == Sentinel
    action, args, delegate_to = parser.parse(task_ds={"action": {"module": "shell", "args": "echo hi"}})
    assert action == 'shell'
    assert isinstance(args, dict)
    assert args == {'echo hi': ''}
    assert delegate_to == Sentinel
    action, args, delegate_to = parser.parse(task_ds={'module': 'ping'})

# Generated at 2022-06-23 04:50:54.577128
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    result = parser.parse()
    assert result == (None, None, None)


# Generated at 2022-06-23 04:51:05.752945
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test(task_ds, collection_list, expected):
        result = ModuleArgsParser(task_ds, collection_list).parse()
        assert result == expected, "expected '%s' instead of '%s'" % (expected, result)

    ##### action tests
    test(
        task_ds=dict(action='copy a b'),
        collection_list=[],
        expected=(
            'copy',
            dict(src='a', dest='b'),
            None
        )
    )

    test(
        task_ds=dict(action='copy a b', args='c d'),
        collection_list=[],
        expected=(
            'copy',
            dict(src='a', dest='b', c=True, d=True),
            None
        )
    )


# Generated at 2022-06-23 04:51:11.790820
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = load_fixture('test_action_plugin_test.yaml')
    extra_args = dict()
    extra_args['debug'] = dict()
    collection_list = list()
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    actual_value = module_args_parser.parse(skip_atcion_validation=True)
    assert actual_value == ('test_action', dict(), 'localhost')


# Generated at 2022-06-23 04:51:23.642949
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # mock up some fixture data
    task_ds = {
        'action': 'shell echo hi',
        'delegated_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds=task_ds)
    result = parser.parse()
    # verify the results
    assert isinstance(result, tuple)
    assert len(result) == 3
    action, args, delegated_to = result
    assert isinstance(action, string_types)
    assert isinstance(args, dict)
    assert isinstance(delegated_to, string_types)

# pylint: disable=too-many-ancestors

# Generated at 2022-06-23 04:51:30.466806
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = dict(action=dict(module='ec2', region='xyz'))
    m = ModuleArgsParser(task_ds)
    assert m.is_valid() is False, "expected task_ds to be invalid"

    task_ds = dict(module='ec2', region='xyz')
    m = ModuleArgsParser(task_ds)
    assert m.is_valid() is True, "expected task_ds to be valid"

    task_ds = dict(action='shell echo hi')
    m = ModuleArgsParser(task_ds)
    assert m.is_valid() is True, "expected task_ds to be valid"


# Generated at 2022-06-23 04:51:35.786931
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {
            'module': 'copy',
            'src': 'a',
            'dest': 'b'
        }
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    parser.parse()
    print('Test of method parse of class ModuleArgsParser is passed!')



# Generated at 2022-06-23 04:51:43.273040
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': 'chdir=/tmp'}
    fake_collection_list = ['collection_list']

    # Test (action, args, delegate_to) = parse(fake_task_ds)
    module_args_parser = ModuleArgsParser(fake_task_ds, fake_collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi', 'chdir': '/tmp'}, 'localhost')

    fake_task_ds = {'action': 'shell', 'delegate_to': 'localhost', 'args': 'chdir=/tmp'}
    module_args_parser = ModuleArgsParser(fake_task_ds, fake_collection_list)
    assert module_args_parser.parse

# Generated at 2022-06-23 04:51:53.379358
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # primitive types passed to ModuleArgsParser constructor
    k = frozenset(['action', 'delegate_to', 'local_action', 'static'])
    assert ModuleArgsParser(42)._task_attrs == k
    assert ModuleArgsParser({'action': 42, 'delegate_to': 42, 'local_action': 42, 'static': 42})._task_attrs == k
    assert ModuleArgsParser(42, 42)._task_attrs == k

    # complex object passed ModuleArgsParser constructor
    # class PlaybookInclude does not provide _valid_attrs, so we cannot use it
    from ansible.playbook.task_include import TaskInclude
    obj = TaskInclude()
    k = frozenset(['tasks', 'static'])

# Generated at 2022-06-23 04:52:03.125799
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'name': 'test_task',
        'action': 'copy src={{ test_dir }}/foo dest={{ test_dir }}/bar',
    }

    map = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = map.parse()
    assert action == 'copy'
    assert delegate_to is None
    assert isinstance(args, dict)
    assert args['src'] == '{{ test_dir }}/foo'
    assert args['dest'] == '{{ test_dir }}/bar'


# Generated at 2022-06-23 04:52:14.171844
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Unit test for constructor of class ModuleArgsParser
    """
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser is not None
    assert parser._task_ds is not None
    assert len(parser._task_ds) == 0
    assert parser._collection_list is None
    assert isinstance(parser._task_attrs, frozenset)
    assert len(parser._task_attrs) > 0
    assert parser.resolved_action is None

# Test code and results
# code, result = ModuleArgsParser._normalize_parameters(None, action='shell')
# print(code)
# print(result)

# Generated at 2022-06-23 04:52:24.196206
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(
        action = dict(
            module = 'ping',
            args = dict(data='pong')
        ),
        local_action = dict(
            module = 'ping',
            args = dict(data='pong')
        ),
        module = 'ping',
        args = dict(data='pong'),
        delegate_to = 'localhost',
        loop = 'ping',
        loop_args = dict(data='pong'),
    )

    assert ModuleArgsParser(task).parse() == ('ping', dict(data='pong'), 'localhost')

# ==============================================================================
# Methods related to parsing tasks



# Generated at 2022-06-23 04:52:34.759551
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    task_ds = dict(action='copy', src='/tmp/a', dest='/tmp/b')
    collection_list = []

    task_parser = ModuleArgsParser(task_ds, collection_list)
    assert task_parser._task_ds == task_ds
    assert task_parser._collection_list == collection_list
    assert task_parser._task_attrs == frozenset(['action', 'local_action', 'name', 'tags', 'register', 'ignore_errors', 'delegate_to',
                                                 'run_once', 'until', 'retries', 'delay', 'become', 'become_user', 'become_method',
                                                 'environment', 'args', 'static', 'when'])


# Generated at 2022-06-23 04:52:45.913686
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(dict(module='shell', args='echo hi'), collection_list=None)
    assert parser.parse() == ('shell', {}, sentinel.Sentinel)

    parser = ModuleArgsParser(dict(module='shell', args='echo hi', delegate_to="localhost"), collection_list=None)
    assert parser.parse() == ('shell', {}, "localhost")

    parser = ModuleArgsParser(dict(module='shell', args=dict(cmd='echo hi'), delegate_to="localhost"), collection_list=None)
    assert parser.parse() == ('shell', {'cmd': 'echo hi'}, "localhost")

    with pytest.raises(AnsibleParserError):
        parser = ModuleArgsParser(dict(module="shell", args=[], delegate_to="localhost"), collection_list=None)
        assert parser.parse()

# Generated at 2022-06-23 04:52:54.996210
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser({
        "when": "this.is.true",
        "become": False,
        "freeform": "action_that module_name param1=value1 param2=value2",
    }, collection_list=None)
    print(parser.parse())
    print(parser.resolved_action)
    # ('action_that', {'param1': 'value1', 'param2': 'value2'}, None)

    parser = ModuleArgsParser({
        "when": "this.is.true",
        "become": False,
        "action": {'module': 'action_that module_name param1=value1 param2=value2'}
    }, collection_list=None)
    print(parser.parse())
    print(parser.resolved_action)
    # ('action_that',

# Generated at 2022-06-23 04:52:57.243020
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser()
    assert module_parser is not None


# Generated at 2022-06-23 04:53:04.025384
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Setup
    test_data = dict(action=dict(module=dict(shell='echo hi')), delegate_to='localhost', local_action='shell')
    # Construct ModuleArgsParser

    # Test
    module_args_parser = ModuleArgsParser(test_data)
    psr = module_args_parser.parse()

    # Verify
    assert psr[0] == 'shell'
    assert psr[1]['_raw_params'] == 'echo hi'
    assert psr[1]['_uses_shell'] is True
    assert psr[2] == 'localhost'

# Generated at 2022-06-23 04:53:15.962143
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test ModuleArgsParser.parse:
    #   dict input, old args style
    #   dict input, new args style
    #   string input, old args style

    module_args_dict = dict(action='test a=1 b=2')
    map = ModuleArgsParser()
    assert map.parse(module_args_dict) == ('test', dict(a='1', b='2'), Sentinel)

    module_args_dict = dict(action=dict(module='test a=1 b=2'))
    map = ModuleArgsParser()
    assert map.parse(module_args_dict) == ('test', dict(a='1', b='2'), Sentinel)

    module_args_dict = dict(test='a=1 b=2')
    map = ModuleArgsParser()

# Generated at 2022-06-23 04:53:20.454661
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ac = ModuleArgsParser(task_ds={'action': 'test'})
    assert ac._task_ds == {'action': 'test'}, "ModuleArgsParser Class object properties test failed."

    ac = ModuleArgsParser(task_ds=None)
    assert ac._task_ds == {}, "ModuleArgsParser Class object properties test failed."


# Generated at 2022-06-23 04:53:26.587124
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    d1 = dict(action='shell', args='echo hi')
    m1 = ModuleArgsParser(task_ds=d1)
    assert m1._task_ds == d1
    assert m1._task_attrs == frozenset({'args', 'action'})

    d2 = dict(my_action='shell', args='echo hi')
    m2 = ModuleArgsParser(task_ds=d2)
    assert m2._task_ds == d2
    assert m2._task_attrs == frozenset({'args', 'my_action'})



# Generated at 2022-06-23 04:53:29.430089
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''Unit test for constructor of class ModuleArgsParser'''
    # TODO: write this
    pass



# Generated at 2022-06-23 04:53:31.575259
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={})
    assert parser.resolved_action is None



# Generated at 2022-06-23 04:53:34.676307
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    collection_list = [
        CollectionRequirement('my.collection', '1.0.0', None)
    ]
    m = ModuleArgsParser(task_ds={
        'action': 'custom_module command={{cmd}}',
        'delegate_to': 'localhost',
        'when': True,
    }, collection_list=collection_list)
    result = m.parse()
    assert result == ('custom_module', {'command': '{{cmd}}'}, 'localhost')
    assert m.resolved_action == 'my.collection.custom_module'

# Generated at 2022-06-23 04:53:38.557674
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test constructor with a task name and an empty task dictionary
    task_name = 'test_task'
    task_ds = {}
    result = ModuleArgsParser(task_name, task_ds)
    assert isinstance(result, ModuleArgsParser)
    assert result._task_name == task_name
    assert result._task_ds == task_ds


# Generated at 2022-06-23 04:53:48.186763
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser(task_ds=None, collection_list=None)
    yaml_elements = ('shell', 'echo hi', 'action', 'copy src=a dest=b')
    for y in yaml_elements:
        print (mp.parse(y))

# Create a ModuleArgsParser instance and run the tests
#mp = ModuleArgsParser(task_ds=None, collection_list=None)
#test_ModuleArgsParser_parse()

##############################################################################
#
# Parser.py tests related to class Requirement
#
##############################################################################


# Generated at 2022-06-23 04:53:56.990525
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # This is a very trivial test to just make sure that we can construct the objects even
    # with the various input formats we support.
    # This isn't meant to be a complete test.

    # Generic "Task" example
    task = {}
    parser = ModuleArgsParser(task)
    assert parser is not None

    task = {'action': 'insert-value'}
    parser = ModuleArgsParser(task)
    assert parser is not None

    task = {'action': {'key': 'value'}}
    parser = ModuleArgsParser(task)
    assert parser is not None

    task = {'insert-value': {'key': 'value'}}
    parser = ModuleArgsParser(task)
    assert parser is not None

    task = {'action': 'insert-value action-arg=action-value'}
    parser = ModuleArgs

# Generated at 2022-06-23 04:54:06.849158
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test basic parsing
    mp = ModuleArgsParser({"shell": "echo 'hi there'"})
    (action, args, delegate_to) = mp.parse()
    assert action == 'shell'
    assert isinstance(args, dict)
    assert delegate_to == Sentinel

    mp = ModuleArgsParser({"shell": { "echo": "'hi there'" }})
    (action, args, delegate_to) = mp.parse()
    assert action == 'shell'
    assert isinstance(args, dict)
    assert delegate_to == Sentinel

    mp = ModuleArgsParser({"local_action": { "shell": { "echo": "'hi there'" }}})
    (action, args, delegate_to) = mp.parse()
    assert action == 'shell'
    assert isinstance(args, dict)

# Generated at 2022-06-23 04:54:09.477990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser =  ModuleArgsParser()
    res = parser.parse()
    print(res)



# Generated at 2022-06-23 04:54:13.597954
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={}, collection_list=None)
    task_ds = {}
    skip_action_validation= False
    module_args_parser.parse(skip_action_validation)




# Generated at 2022-06-23 04:54:23.628280
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit test for ModuleArgsParser for all possible inputs (constructor)
    '''

    # Check for exception when action is not a dict or string
    for var in [None, 1.4, ['dog', 'cat']]:
        caught = False
        try:
            ModuleArgsParser(var)
        except AnsibleAssertionError:
            caught = True
        assert caught

    # Check for valid case
    assert isinstance(ModuleArgsParser({}), ModuleArgsParser)
    assert isinstance(ModuleArgsParser({'a': 'b'}), ModuleArgsParser)



# Generated at 2022-06-23 04:54:25.832956
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser()

    action = obj.parse()

    assert action == (None, None, Sentinel)

## TaskExecutor ##

# Unit tests for class TaskExecutor

# Generated at 2022-06-23 04:54:37.268966
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # construct ModuleArgsParser object without task_ds
    m = ModuleArgsParser()
    assert m.parse({'args': {'key1': 'value1', 'key2': 'value2'}}) == ('', {'key1': 'value1', 'key2': 'value2'}, None)
    assert m.parse({'module': 'apt', 'args': {'key1': 'value1', 'key2': 'value2'}}) == ('apt', {'key1': 'value1', 'key2': 'value2'}, None)
    assert m.parse({'action': 'apt', 'args': {'key1': 'value1', 'key2': 'value2'}}) == ('apt', {'key1': 'value1', 'key2': 'value2'}, None)

# Generated at 2022-06-23 04:54:41.759586
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action=dict(module='command', args='pwd'))
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'command'
    assert delegate_to == DEFAULT_DELEGATE_TO
    assert args['args'] == 'pwd'

# Generated at 2022-06-23 04:54:50.627417
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils.common.collections import ImmutableDict

    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'bar'}
    expected_action = 'copy'
    expected_args = {'src': 'a', 'dest': 'b'}
    expected_delegate_to = 'bar'
    output_action, output_args, output_delegate_to = ModuleArgsParser(task_ds).parse()
    assert output_action == expected_action
    assert output_args == expected_args
    assert output_delegate_to == expected_delegate_to

    task_ds = {'action': {'copy': 'src=a dest=b'}, 'delegate_to': 'bar'}
    expected_action = 'copy'

# Generated at 2022-06-23 04:55:01.847501
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.system.distribution as ansible_distribution
    loader_mock = MagicMock(spec=DataLoader)
    inventory_mock = MagicMock(spec=InventoryManager)
    variable_manager_mock = MagicMock(spec=VariableManager)
    collection_loader_mock = MagicMock(spec=CollectionLoader)
    task_vars = dict()
    play_context_mock = MagicMock(spec=PlayContext)
    loader_mock.load_from_file.return_value = dict(name='test', tasks=[dict(action=dict(module='command', args=dict(cmd='uptime')))])
    variable_manager_mock.get_vars.return_value = task_vars
    variable

# Generated at 2022-06-23 04:55:02.476016
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass
#
#

# Generated at 2022-06-23 04:55:10.804953
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError, AnsibleError

# Generated at 2022-06-23 04:55:23.321836
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test 1.
    json_dict = {
        "action": {
            "module": "ec2",
            "region": "xyz"
        },
        "delegate_to": "s3_bucket"
    }
    module_args_parser = ModuleArgsParser(task_ds=json_dict, collection_list=None)
    (action, args, delegate_to) = module_args_parser.parse()
    assert (action == "ec2")
    assert (args == {'region': 'xyz'})
    assert (delegate_to == "s3_bucket")

    # Test 2.
    json_dict = {
        "action": {
            "module": "ec2",
            "region": "xyz"
        }
    }

# Generated at 2022-06-23 04:55:24.561418
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:55:32.308566
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test with non-supported attrs
    t_dict = dict(name="test task", action="test_module.yaml")
    parser = ModuleArgsParser(task_ds=t_dict)
    action, args, delegate_to = parser.parse()
    assert action == "test module.yaml"
    assert args == {}
    assert delegate_to is Sentinel

    # Test with non-supported attrs
    t_dict = dict(name="test task", action="test_module.yaml",
                  test="test")
    parser = ModuleArgsParser(task_ds=t_dict)
    action, args, delegate_to = parser.parse()
    assert action == "test module.yaml"
    assert args == {}
    assert delegate_to is Sentinel

    # action, local_action with non-intrinsic module
   

# Generated at 2022-06-23 04:55:39.704455
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = dict(
        name="test_module_args_parser",
        action=dict(module="test_module", arg1="val1"),
        # local_action=dict(module="local_test_module", arg2="val2", arg3="val3"),
    )

    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

    assert action == "test_module"
    assert args["arg1"] == "val1"
    assert delegate_to == "Sentinel"
    assert parser.resolved_action == "Ansible.builtin.test_module"

# Generated at 2022-06-23 04:55:52.001675
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # store the valid Task/Handler attrs for quick access
    attrs = set(Task._valid_attrs.keys())
    attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    attrs.update(['local_action', 'static'])
    attrs = frozenset(attrs)

    assert 'local_action' in attrs
    assert 'static' in attrs
    assert 'static_facts' not in attrs
    assert 'static' not in BUILTIN_TASKS
    assert 'static_facts' in BUILTIN_TASKS
    assert 'when' not in RAW_

# Generated at 2022-06-23 04:55:54.271316
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass
# end class ModuleArgsParser


# name: AnsibleModule
# description: base class for all ansible module scripts.

# Generated at 2022-06-23 04:56:02.401916
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader = ModuleLoader()
    action_loader = ActionModuleLoader()
    testing_task_ds = {'name': 'test task', 'sudo': True, 'sudo_user': 'root', 'delegate_to': 'localhost', 'register': 'test_task_result', 'hosts': '127.0.0.1', 'action': 'copy', 'args': {'src': 'test_template', 'dest': '/tmp/test_template.out'}}
    parser = ModuleArgsParser(testing_task_ds, collection_list=[])
    parser._normalize_new_style_args(testing_task_ds, 'copy')


# end class ModuleArgsParser


# Generated at 2022-06-23 04:56:13.054301
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:56:23.213239
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test several cases with the expected output to validate parse method
    # https://github.com/ansible/ansible/issues/29904
    # Test when no action defined
    task_ds = {
                "delegate_to": "localhost",
                "args": "shell echo hi",
        }
    expected_output = ModuleArgsParser(task_ds=task_ds)
    assert expected_output.parse() == ('shell', {}, 'localhost')

    # Test for multiple actions defined and 'action' present
    task_ds = {
                "action": "copy src=a dest=b",
                "delegate_to": "localhost",
                "args": "shell echo hi",
        }
    expected_output = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-23 04:56:27.786209
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'asserts': {
            "equals": {
                "thing": "left right"
            }
        }
    }
    map = ModuleArgsParser(task_ds)
    assert map._task_ds == task_ds


# Generated at 2022-06-23 04:56:37.418125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.template import Templar
    import os
    import json

    # Load data from fixture
    data = None
    path = os.path.dirname(os.path.abspath(__file__))
    file_ = os.path.join(path, '..', '..', '..', '..', 'test', 'integration',
                         'targets', 'test_module_match', 'fixture_module_args_parser_parse.json')

# Generated at 2022-06-23 04:56:48.448093
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # configuring empty module_utils dir
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')
    module_utils_path = os.path.abspath(module_utils_path)
    module_loader.add_directory(module_utils_path)

    module_loader.load_plugin_providers()

    # Test Case 1: args is specified
    task_ds = {
        'action': {
            'args': {
                'x': 'a'
            }
        },
        'args': {
            'y': 'b'
        }
    }
    args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = args_parser.parse()

# Generated at 2022-06-23 04:57:02.898136
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  import json
  import yaml
  ds = {
    'action': 'copy',
    'args': {
      'src': 'a',
      'dest': 'b'
    }
  }
  parser = ModuleArgsParser(ds)
  ret = parser.parse()
  assert (('copy', {'src': 'a', 'dest': 'b'}, None) == ret)
  ds = {
    'action': 'copy src=a dest=b'
  }
  parser = ModuleArgsParser(ds)
  ret = parser.parse()
  assert (('copy', {'src': 'a', 'dest': 'b'}, None) == ret)

# Generated at 2022-06-23 04:57:07.173628
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # no params
    ds = dict()
    m1 = ModuleArgsParser(ds)
    assert ds == dict()

    # no valid params
    ds = dict(k1='v1', k2='v2')
    m2 = ModuleArgsParser(ds)
    assert ds == dict(k1='v1', k2='v2')

# Generated at 2022-06-23 04:57:17.948886
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # simple args
    task_ds = dict()
    task_ds['action'] = 'copy src=a dest=b'
    task_ds['delegate_to'] = 'localhost'
    a = ModuleArgsParser(task_ds)
    assert a is not None
    action, args, delegate_to = a.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None
    # local_action
    task_ds = dict()
    task_ds['local_action'] = 'copy src=a dest=b'
    task_ds['delegate_to'] = 'localhost'
    a = ModuleArgsParser(task_ds)
    assert a is not None
    action, args, delegate_to = a.parse()
    assert action

# Generated at 2022-06-23 04:57:21.929816
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    
    a = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    a.parse()

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-23 04:57:34.068281
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # first example is with a freeform action
    ds = {"action": "copy src=/a/b/c dest=/d/e/f"}
    m = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = m.parse(skip_action_validation=True)
    assert action == 'copy'
    assert args['src'] == '/a/b/c'
    assert args['dest'] == '/d/e/f'

    # second example is an action that does not require shell
    ds = {"action": "copy a=b x=y"}
    m = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = m.parse(skip_action_validation=True)
    assert action == 'copy'
    assert args['a'] == 'b'

# Generated at 2022-06-23 04:57:43.287476
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Make sure the ModuleArgsParser works correctly
    '''
    # intentional local import to prevent circular imports
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task = Task()
    task.set_loader(DictDataLoader({
        'get_url': """#!/usr/bin/python
import sys
if len(sys.argv) == 2 and sys.argv[1] == "--version":
    print("3.2.1")
    sys.exit(0)
else:
    sys.stderr.write("Invalid arguments passed")
    sys.exit(1)
"""
    }))
    handler = Handler()

# Generated at 2022-06-23 04:57:46.247461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass
# /Unit test for method parse of class ModuleArgsParser



# Generated at 2022-06-23 04:57:54.764851
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {}, None)

    task_ds = {
        'local_action': 'shell echo hi'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {}, 'localhost')

    task_ds = {
        'ec2': 'region=us-east-1'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('ec2', {'region': 'us-east-1'}, None)

    task_ds = {
        'ec2': {'region': 'us-east-1'}
    }
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-23 04:57:59.271053
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(
        action=dict(
            module='shell',
            args='ls -alF'
        ),
        delegate_to='localhost',
        register='shell_out'
    )
    obj = ModuleArgsParser(task_ds=data)
    assert obj._task_ds == data



# Generated at 2022-06-23 04:58:01.726882
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    t = dict(action=dict(module='shell', args='echo hi'))
    m = ModuleArgsParser(t)
    assert m is not None



# Generated at 2022-06-23 04:58:10.359910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: refactor into a proper unit test
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    task_ds = loader.load('---\n- name: test_module_args\n  shell: echo foo')[0]['tasks'][0]
    parser = ModuleArgsParser(task_ds, collection_list=[])
    assert parser.parse() == ('shell', {'_raw_params': 'echo foo', '_uses_shell': True}, None)

# Generated at 2022-06-23 04:58:17.043422
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing import vault

    args_parser = ModuleArgsParser()

    assert isinstance(args_parser, ModuleArgsParser)

    # Test if args_parser._task_ds is a MutableMapping.
    assert isinstance(args_parser._task_ds, MutableMapping)

    # Test if args_parser._collection_list is None.
    assert args_parser._collection_list is None

    # Test if args_parser._task_attrs is a frozenset.
    assert isinstance(args_parser._task_attrs, frozenset)

    # Test if args_parser._task_attrs contains 'no_log'.
    assert 'no_log' in args_parser._task_attrs

    # Test

# Generated at 2022-06-23 04:58:29.699316
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:58:31.084757
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None


# Generated at 2022-06-23 04:58:44.076372
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={'module': 'shell', 'args': {'chdir': '/tmp', '_raw_params': 'ls -al'}})
    assert parser._task_ds == {'module': 'shell', 'args': {'chdir': '/tmp', '_raw_params': 'ls -al'}}

# Generated at 2022-06-23 04:58:52.946165
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # basic execution
    assert ModuleArgsParser(task_ds={'action': 'copy', 'src': 'a', 'dest': 'b'}).parse()[1] == {'src': 'a', 'dest': 'b'}
    assert ModuleArgsParser(task_ds={'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}).parse()[1] == {'src': 'a', 'dest': 'b'}
    assert ModuleArgsParser(task_ds={'action': 'copy', 'args': 'src=a dest=b'}).parse()[1] == {'src': 'a', 'dest': 'b'}

# Generated at 2022-06-23 04:59:06.138077
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    bootstrap_task_ds = collections.Mapping()
    c1_task_ds = {
        'action': {
            'module': 'copy',
            'src': 'c1_src',
            'dest': 'c1_dest'
        },
        'name': 'c1'
    }
    c2_task_ds = {
        'action': {
            'module': 'copy',
            'src': 'c2_src',
            'dest': 'c2_dest'
        },
        'name': 'c2'
    }
    c3_task_ds = {
        'action': {
            'module': 'copy',
            'src': 'c3_src',
            'dest': 'c3_dest'
        },
        'name': 'c3'
    }
    c

# Generated at 2022-06-23 04:59:16.527609
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.template import Templar
    mock_task_ds = {} # some data
    mock_collection_list = 'default' # some data

    mock_self = ModuleArgsParser(mock_task_ds, mock_collection_list)

    mock_skip_action_validation = False # some data

    mock_thing = {} # some data
    mock_action = 'echo' # some data
    mock_additional_args = {} # some data
    mock_return_value_1 = (mock_action, mock_additional_args)

    with patch.object(ModuleArgsParser, '_normalize_parameters', return_value=mock_return_value_1) as mock_method:
        assert mock_self._normalize_new_style_args(mock_thing, mock_action) == mock_return_value_

# Generated at 2022-06-23 04:59:20.262209
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(action=dict(module='copy', src='a', dest='b'))
    map = ModuleArgsParser(ds)
    assert isinstance(map, object)


# Generated at 2022-06-23 04:59:32.290853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_service_task_ds = {
        "action": "service name=httpd state=restarted",
        "async": 10000
    }

    action_ping_task_ds = {
        "action": "ping"
    }

    action_ping_with_extra_args_task_ds = {
        "action": "ping arg1 arg2 arg3"
    }

    action_template_task_ds = {
        "action": "template src=/path/to/file.j2 dest=/path/to/dest"
    }

    module_template_task_ds = {
        "template": "src=/path/to/file.j2 dest=/path/to/dest"
    }

    action_user_task_ds = {
        "action": "user name=bob state=present"
    }



# Generated at 2022-06-23 04:59:40.141539
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test creation of the class with empty task_ds
    mp = ModuleArgsParser(task_ds={})
    assert isinstance(mp, ModuleArgsParser)
    # Test creation of the class with task_ds
    mp_task_ds = dict()
    mp_task_ds['args'] = {'one': 'two'}
    mp_task_ds['action'] = 'copy src=a dest=b'
    mp = ModuleArgsParser(task_ds=mp_task_ds)
    assert isinstance(mp, ModuleArgsParser)



# Generated at 2022-06-23 04:59:50.493589
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(None)

    task = dict(
        action=dict(module='test', args=dict(test='test'))
    )
    action, args, delegate_to = parser.parse()
    assert action == 'test'
    assert args == {'test': 'test', '_raw_params': ''}
    assert delegate_to is None

    task = dict(
        action=dict(module='test', args=dict(test='test'))
    )
    action, args, delegate_to = parser.parse()
    assert action == 'test'
    assert args == {'test': 'test', '_raw_params': ''}
    assert delegate_to is None

    task = dict(
        command='pwd',
        args=dict(chdir='/tmp')
    )
    action, args,

# Generated at 2022-06-23 04:59:52.286801
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_parser = ModuleArgsParser()

    assert my_parser.parse("") != ""

# Generated at 2022-06-23 04:59:57.142749
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    moduleArgs = {'action': 'shell echo hi'}
    m = ModuleArgsParser(moduleArgs)
    assert m._task_ds == {'action': 'shell echo hi'}
    assert m._task_attrs == frozenset({'action'})
    assert m.resolved_action is None


# Generated at 2022-06-23 05:00:01.431086
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'x': {'x': 1, 'y': 2}, 'action': 'abc x=1 y=2', 'module': 'ec2 x=1 y=2'}
    module_args_parser = ModuleArgsParser(task_ds)

    module_args_parser.parse()

# Generated at 2022-06-23 05:00:13.297852
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ap = ModuleArgsParser(dict(action='shell', args="name='/usr/local/bin/'"))
    (name, args, delegate_to) = ap.parse()
    assert name == 'shell'
    assert args == dict(name='/usr/local/bin/')
    assert delegate_to is None

    ap = ModuleArgsParser(dict(action='shell', arg='name=/usr/local/bin/'))
    (name, args, delegate_to) = ap.parse()
    assert name == 'shell'
    assert args == dict(name='/usr/local/bin/')
    assert delegate_to is None

    ap = ModuleArgsParser(dict(action='shell', arg='name=/usr/local/bin/', delegate_to='localhost'))
    (name, args, delegate_to) = ap.parse()


# Generated at 2022-06-23 05:00:22.156847
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    known good:
    { 'action': {'module': 'modu', 'arg1': 'val1', 'args': 'arg2'} }
    """

    # returns (action, args, delegate_to)