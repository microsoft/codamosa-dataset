

# Generated at 2022-06-23 04:50:35.795484
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    args = dict(
        action='shell',
        args=dict(
            _raw_params='echo hi',
            chdir='/tmp'
        )
    )
    # parser = ModuleArgsParser(task_ds=args)
    # like the previous example, but we pass in a dict for action, so
    # this is really a new-style invocation
    args = dict(
        action=dict(
            _raw_params='echo hi',
            chdir='/tmp'
        )
    )
    # parser = ModuleArgsParser(task_ds=args)
    # another new-style invocation, but with a dictionary of args
    args = dict(
        action=dict(
            module='echo hi',
            chdir='/tmp'
        )
    )
    # parser = ModuleArgsParser(task_ds=args)

# Generated at 2022-06-23 04:50:48.681177
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # setup test
    test_object = ModuleArgsParser()

    # AssertionError: the type of 'task_ds' should be a dict, but is a <type 'NoneType'>
    with pytest.raises(AnsibleAssertionError):
        test_object.parse()

    # ValueError: could not assemble formatter
    with pytest.raises(AnsibleParserError):
        test_object.parse({})

    # AnsibleParserError: 'action' or 'local_action' is required for task: aoeu
    with pytest.raises(AnsibleParserError):
        test_object.parse({'aoeu': 'htns'})

    # AnsibleParserError: conflicting action statements: 'template', 'copy'
    with pytest.raises(AnsibleParserError):
        test_

# Generated at 2022-06-23 04:51:02.230124
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={})
    (action, args, delegate_to) = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    parser = ModuleArgsParser(task_ds={'foo': 'bar'})
    (action, args, delegate_to) = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    parser = ModuleArgsParser(task_ds={'action': {'module': 'bar'}})
    (action, args, delegate_to) = parser.parse()
    assert action == 'bar'
    assert args == {}
    assert delegate_to is None

    parser = ModuleArgsParser(task_ds={'action': 'bar'})
    (action, args, delegate_to) = parser.parse

# Generated at 2022-06-23 04:51:11.941205
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:25.665165
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(obj._task_ds, dict)
    assert isinstance(obj._collection_list, type(None))
    assert obj._task_ds == {}
    assert obj._collection_list is None
    # check that we can call parse method with no arguments
    assert isinstance(obj.parse(), tuple)
    # check that we can call parse method with one argument having default value
    assert isinstance(obj.parse(skip_action_validation=False), tuple)
    # check that we can call parse method with one argument having non-default value
    assert isinstance(obj.parse(skip_action_validation=True), tuple)
    # test using the scenario from issue #29556

# Generated at 2022-06-23 04:51:38.637608
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:51:48.517657
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-23 04:51:59.239239
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from cStringIO import StringIO

    module_args = """
    - shell: echo hi

    - local_action: shell echo hi

    - copy: src=a dest=b

    - action: copy src=a dest=b

    - copy:
        src: a
        dest: b

    - action:
        module: copy
        args:
          src: a
          dest: b

    - command: 'pwd'
      args:
        chdir: '/tmp'

    - action: abc
      args:
        chdir: '/tmp'
    """

    for yaml in [module_args]:
        fd = StringIO(yaml)

# Generated at 2022-06-23 04:52:10.479134
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:22.936299
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:33.051539
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Parameter task_ds is mandatory
    try:
        parser = ModuleArgsParser()
        assert False, "ModuleArgsParser did not throw an exception when task_ds was not specified"
    except AssertionError as e:
        raise e
    except:
        pass

    # Parameter task_ds must be a dictionary
    try:
        parser = ModuleArgsParser("a lot of words")
        assert False, "ModuleArgsParser did not throw an exception when task_ds was not a dictionary"
    except AssertionError as e:
        raise e
    except:
        pass

    # Parameter collection_list is optional
    try:
        parser = ModuleArgsParser({})
    except:
        assert False, "ModuleArgsParser threw an exception when collection_list was not specified"



# Generated at 2022-06-23 04:52:41.941137
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test 1: no argument passed
    test1 = ModuleArgsParser()
    assert test1._task_ds == {}

    # test 2: non-dict argument passed
    task_ds = []
    try:
        test2 = ModuleArgsParser(task_ds=task_ds)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("non-dict argument is accepted")

    task_ds = {}
    test3 = ModuleArgsParser(task_ds=task_ds)
    assert test3._task_ds == {}


# Generated at 2022-06-23 04:52:51.904930
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:57.448630
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'ping'}
    test_ModuleArgsParser = ModuleArgsParser(task_ds)
    assert len(test_ModuleArgsParser._task_attrs) == 7

    task_ds = None
    test_ModuleArgsParser = ModuleArgsParser(task_ds)
    assert len(test_ModuleArgsParser._task_attrs) == 7



# Generated at 2022-06-23 04:53:01.593616
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module='shell', args='echo hi'), delegate_to='localhost')
    parsed = ModuleArgsParser(task_ds).parse(skip_action_validation=True)
    assert parsed == ('shell', {'args': 'echo hi'}, 'localhost')



# Generated at 2022-06-23 04:53:12.294319
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test case 1
    test1_task_ds = {'action': 'get_http_01_challenge'}
    test1_collection_list = None
    parse1 = ModuleArgsParser(test1_task_ds, collection_list=test1_collection_list)
    # test case 2
    test2_task_ds = {'action': 'get_http_01_challenge', 'delegate_to': 'localhost'}
    test2_collection_list = None
    parse2 = ModuleArgsParser(test2_task_ds, collection_list=test2_collection_list)
    # test case 3

# Generated at 2022-06-23 04:53:23.052649
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Remove this when ModuleArgsParser is refactored to use a proper argument parser
    m = collections.defaultdict(dict)
    # Test no args
    (action, args, delegate_to) = ModuleArgsParser(m).parse()
    assert action is None
    assert args is None
    assert delegate_to is None
    # Test one action
    m['action'] = 'action_name action_args'
    (action, args, delegate_to) = ModuleArgsParser(m).parse()
    assert action == 'action_name'
    assert args == dict(action_args='')
    assert delegate_to is None
    # Test two actions
    m['local_action'] = 'local_action_name local_action_args'
    (action, args, delegate_to) = ModuleArgsParser(m).parse()

# Generated at 2022-06-23 04:53:27.617000
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    t = ModuleArgsParser(task_ds=dict(), collection_list=None)
    task_ds = dict(
        local_action=dict(
            ec2=dict(
                region='xyz'
            )
        )
    )

    t._normalize_old_style_args(task_ds)



# Generated at 2022-06-23 04:53:33.483178
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    # all the parameters are empty, so should return (None, dict(), None)
    module_args_parser = ModuleArgsParser(task_ds)
    parser = module_args_parser.parse()
    assert parser is not None


# Generated at 2022-06-23 04:53:43.903707
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # this is the method under test
    parser = ModuleArgsParser(task_ds={'foo': 1, 'bar': 2, 'delegate_to': 'localhost', 'local_action': None, 'static': False})
    assert parser._task_ds == {'foo': 1, 'bar': 2, 'delegate_to': 'localhost', 'local_action': None, 'static': False}

# Generated at 2022-06-23 04:53:48.798342
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = Task.load(dict(action=dict(module="test", args="test_arg")), collection_list=None)
    assert parser._task_ds['action']['module'] == 'test'
    assert parser._task_ds['action']['args'] == 'test_arg'
    assert parser._collection_list is None


# Generated at 2022-06-23 04:53:57.444419
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # given
    task = dict(action='shell', echo="{{ hello }}", args=dict(_raw_params="ls", _uses_shell=True))
    parser = ModuleArgsParser(task)

    # when
    action, args, delegate_to = parser.parse()

    # then
    assert parser.resolved_action is None
    assert '_raw_params' in args
    assert action == "shell"
    assert delegate_to is None
    assert args['echo'] == '{{ hello }}'

    # given
    task = dict(action='shell echo {{ hello }}', args=dict(_raw_params="ls", _uses_shell=True))
    parser = ModuleArgsParser(task)

    # when
    action, args, delegate_to = parser.parse()

    # then
    assert parser.resolved_action is None
   

# Generated at 2022-06-23 04:54:05.595794
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test that it should raise an exception if the task is not a dict
    try:
        ModuleArgsParser(task_ds='task')
        raise AssertionError('ModuleArgsParser() must raise AnsibleAssertionError if the task is not a dict')
    except AnsibleAssertionError:
        pass

    args_parser = ModuleArgsParser()

    # Test that the parser does not accept an 'action' key if a 'module'
    # key is present

# Generated at 2022-06-23 04:54:18.246228
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg_parser = ModuleArgsParser(task_ds={'hellow_world': 'hello_world: msg=hello_world'},
                                         collection_list=None)
    action, args, delegate_to = module_arg_parser._normalize_old_style_args({'hellow_world': 'hello_world: msg=hello_world'})
    assert action == 'hello_world'
    assert args == {'msg': 'hello_world'}
    assert delegate_to is None

    module_arg_parser = ModuleArgsParser(task_ds={'action': {'module': 'hello_world: msg=hello_world'}},
                                         collection_list=None)

# Generated at 2022-06-23 04:54:19.329433
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True == False



# Generated at 2022-06-23 04:54:35.471815
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # test dict form, module with k=v params
    task_ds = dict(action='copy src=a dest=b')
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', dict(src='a', dest='b'), None)

    # test dict form, module with dict params
    task_ds = dict(action=dict(module='copy', src='a', dest='b'))
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', dict(src='a', dest='b'), None)

    # test dict

# Generated at 2022-06-23 04:54:37.363769
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert isinstance(m, ModuleArgsParser)


# Generated at 2022-06-23 04:54:45.093426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task = dict(name="test-task", local_action=dict(shell="ls"), delegate_to="localhost")
    action, args, delegate_to = parser.parse()
    assert action == "shell"
    assert args == {"_raw_params": "ls"}
    assert delegate_to == "localhost"

    task = dict(name="test-task", action=dict(shell="ls"), delegate_to="localhost")
    action, args, delegate_to = parser.parse()
    assert action == "shell"
    assert args == {"_raw_params": "ls"}
    assert delegate_to == "localhost"


# Generated at 2022-06-23 04:54:57.659756
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    parser = ModuleArgsParser({})
    assert parser._task_ds == {}
    assert parser._collection_list == None
    parser = ModuleArgsParser({'module': 'copy'})
    assert parser._task_ds == {'module': 'copy'}
    assert parser._collection_list == None
    parser = ModuleArgsParser({'module': 'copy'}, ['mycol'])
    assert parser._task_ds == {'module': 'copy'}
    assert parser._collection_list == ['mycol']
    parser = ModuleArgsParser({'module': 'copy', 'action': 'debug'})
    assert parser._task_ds == {'module': 'copy', 'action': 'debug'}
    assert parser._collection_list == None


# Generated at 2022-06-23 04:55:00.837119
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {}
    m = ModuleArgsParser(task_ds=args)
    m.parse()
    assert m.resolved_action is None
    assert args == {}



# Generated at 2022-06-23 04:55:07.923231
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Constructor args
    task_ds = dict(action='echo hi')
    collection_list = None
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # Method args
    skip_action_validation = False
    # Expected return value
    expected = ('echo', dict(), None)
    # Call the method
    actual = obj.parse(skip_action_validation)
    # Assertions
    assert actual == expected, "Actual: {0} != Expected: {1}".format(actual, expected)
    # Return value
    return actual

# Generated at 2022-06-23 04:55:18.264552
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # testing both init and parse

    task_ds = dict(action=dict(module='some_mod', var=23))
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'some_mod'
    assert args == dict(var=23)
    assert delegate_to is Sentinel

    task_ds = dict(action='some_mod')
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'some_mod'
    assert len(args) == 0
    assert delegate_to is Sentinel

    task_ds = dict(action='some_mod var=23')
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse

# Generated at 2022-06-23 04:55:23.273626
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Validate module args parser instantiation.
    '''
    loader = DictDataLoader(dict())

    # test invalid argument types
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(loader, None, None)
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(loader, None, 1)
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(loader, None, "string")
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(loader, None, [])

    # test valid argument types
    ModuleArgsParser(loader, dict(), None)



# Generated at 2022-06-23 04:55:27.811175
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # given
    task_ds = {
        'action': 'shell',
        'args': {
            'chdir': '/tmp',
        }
    }

    # when
    map = ModuleArgsParser(task_ds)

    # then
    assert True

# Generated at 2022-06-23 04:55:31.482350
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'module':'command', 'args': 'echo foo'})
    assert module_args_parser._task_ds == {'module':'command', 'args': 'echo foo'}
    assert module_args_parser._task_attrs == frozenset(['module', 'args'])


# Generated at 2022-06-23 04:55:35.123181
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Create a TaskDS
    TaskDS = dict(action='something')
    # Make the parser
    parser = ModuleArgsParser(TaskDS)
    # Shouldn't raise an Error
    parser.parse(skip_action_validation=True)
    # FIXME: add more tests

# Generated at 2022-06-23 04:55:40.855440
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test task_ds with fields for action, local_action, and module
    task_ds = {
        'action': 'copy src=a dest=b',
        'local_action': 'shell echo hi',
        'module': 'sync src=a dest=b'
    }
    mp = ModuleArgsParser(task_ds)
    assert mp


# Generated at 2022-06-23 04:55:47.629268
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader

    # Test ModuleArgsParser.parse() with 'action' style
    ds = {'name': 'hello', 'action': 'copy src=a dest=b'}
    loader = DataLoader()
    args_parser = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = args_parser.parse()
    assert action == 'copy'
    assert delegate_to is None
    assert args['src'] == 'a'
    assert args['dest'] == 'b'

    # Test ModuleArgsParser.parse() with 'local_action' style
    ds = {'name': 'hello', 'local_action': 'copy src=a dest=b'}
    loader = DataLoader()

# Generated at 2022-06-23 04:55:54.696516
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader

    task_ds = dict()
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert not module_args_parser.parse(skip_action_validation=False)

    task_ds = dict(action="shell")
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert not module_args_parser.parse(skip_action_validation=False)

# Generated at 2022-06-23 04:56:03.773421
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='echo hi', delegate_to='127.0.0.1')
    assert task_ds == ModuleArgsParser(task_ds=task_ds)._task_ds

    task_ds = dict(action='echo hi', delegate_to='127.0.0.1')
    assert task_ds == ModuleArgsParser(task_ds=task_ds)._task_ds

    try:
        task_ds = dict()
        ModuleArgsParser(task_ds=task_ds)
    except AnsibleAssertionError:
        pass
    except Exception as e:
        assert False, e

    try:
        ModuleArgsParser(task_ds=None)
    except AnsibleAssertionError:
        pass
    except Exception as e:
        assert False, e


# Generated at 2022-06-23 04:56:13.560223
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # test constructor with no params
    parser = ModuleArgsParser()
    assert parser._task_ds == {}

    # test constructor with some params
    parser = ModuleArgsParser(task_ds=dict(x=2, y=3))
    assert parser._task_ds == {'x': 2, 'y': 3}

    # test explicit setters/getters of ModuleArgsParser._task_ds to avoid
    # changing the value of the internal field after set
    parser.task_ds = dict(x=3)
    assert parser._task_ds == {'x': 3}
    assert parser.task_ds == {'x': 3}

    # test constructor with a wrong type of params

# Generated at 2022-06-23 04:56:18.891117
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # test parse(skip_action_validation=False)
    assert isinstance(module_args_parser.parse(), tuple)
    # test parse(skip_action_validation=True)
    assert isinstance(module_args_parser.parse(skip_action_validation=True), tuple)


# class ActionBase(object):

# Generated at 2022-06-23 04:56:27.803386
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_task_ds = dict(
        name='Test task',
        action='ping'
    )
    parser = ModuleArgsParser(my_task_ds)
    action, args, delegate_to = parser.parse()
    assert "ping" == action

    my_task_ds = dict(
        name='Test task',
        local_action='shell echo hi'
    )
    parser = ModuleArgsParser(my_task_ds)
    action, args, delegate_to = parser.parse()
    assert "shell" == action
    assert {"cmd": "echo hi"} == args

    my_task_ds = dict(
        name='Test task',
        action='copy',
        src='source_file',
        dest='dest_file',
        mode='644'
    )

# Generated at 2022-06-23 04:56:28.556661
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:56:37.934884
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    task_ds = {}
    collection_list = []

    task_ds.update({"action" : ""})
    collection_list.append("")
    test = ModuleArgsParser(task_ds, collection_list).parse()

    assert_equal(test, (None, None, None))

    task_ds.update({"action" : "shell"})
    collection_list.append("shell")
    test = ModuleArgsParser(task_ds, collection_list).parse()

    assert_equal(test, ('shell', None, None))


# Generated at 2022-06-23 04:56:48.797106
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell "echo hi"',
        'args': 'chdir=/tmp'
    }
    obj = ModuleArgsParser(task_ds)
    assert obj.parse() == ('shell', {'_raw_params': '"echo hi"', 'chdir': '/tmp'}, None)

    task_ds = {
        'local_action': 'shell echo hi',
        'shell': 'echo hi',
        'args': 'chdir=/tmp'
    }
    obj = ModuleArgsParser(task_ds)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi', 'chdir': '/tmp'}, 'localhost')

    task_ds = {
        'shell': 'echo hi',
        'args': 'chdir=/tmp'
    }

# Generated at 2022-06-23 04:57:03.262217
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    instance = ModuleArgsParser()

    # Test 'action' entry for task
    test_dict = dict(action='shell echo hi', delegate_to='myhost')
    action, args, delegate_to = instance.parse(task_ds=test_dict)
    assert action == 'shell'
    assert args == 'echo hi'
    assert delegate_to == 'myhost'
    # Test that 'local_action' and 'action' cannot be specified simultaneously
    test_dict = dict(action='shell echo hi', local_action='shell echo hi', delegate_to='myhost')
    with pytest.raises(AnsibleParserError):
        (action, args, delegate_to) = instance.parse(task_ds=test_dict)
    # Test that 'action' key must be specified
    test_dict = dict(shell='echo hi')

# Generated at 2022-06-23 04:57:12.907126
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    task_ds['action'] = dict()
    task_ds['action']['module'] = 'copy'
    task_ds['action']['args'] = dict()
    task_ds['action']['args']['src'] = 'test/test_module_utils.py'
    task_ds['action']['args']['dest'] = '/tmp/test_module_utils.py'
    a = ModuleArgsParser(task_ds, collection_list)
    assert a.parse() == ('copy', {'src': 'test/test_module_utils.py', 'dest': '/tmp/test_module_utils.py'}, Sentinel)


# Generated at 2022-06-23 04:57:25.466252
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import unittest
    import collections

    # helper function to compare actual dictionary to expected dictionary
    def validatedict(actual, expected):
        for key, value in expected.items():
            if key != '_raw_params':
                if isinstance(value, collections.Mapping):
                    validatedict(actual[key], value)
                elif isinstance(value, collections.Iterable):
                    for item in value:
                        if item not in actual[key]:
                            assert (False)
                else:
                    try:
                        assert (actual[key] == value)
                    except:
                        assert (False)

    # Test cases


# Generated at 2022-06-23 04:57:36.474567
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleError, AnsibleAction, AnsibleAssertionError
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader, module_loader

    # basic case with all the different forms of invocation
    # test early return when non of action, local_action, module is present
    test_task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds=test_task_ds)
    assert module_args_parser.parse() == (None, {}, Sentinel), \
        "unit test: ModuleArgsParser.parse()"

    # test early return when task_ds is not a dict instance
    test_task_ds = []
    module

# Generated at 2022-06-23 04:57:49.512551
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(obj, ModuleArgsParser)
    assert isinstance(obj._task_ds, dict)
    assert obj._task_ds == {}
    assert isinstance(obj._collection_list, (type(None), list))
    assert obj._collection_list == None
    assert isinstance(obj._task_attrs, frozenset)
    assert obj._task_attrs == frozenset()
    assert obj.resolved_action is None
    skip_action_validation = False
    assert obj.parse(skip_action_validation) == (None, dict(), Sentinel)
# Replacing above method's

# Generated at 2022-06-23 04:57:51.054458
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert isinstance(ModuleArgsParser(), ModuleArgsParser)



# Generated at 2022-06-23 04:58:00.202960
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # pylint: disable=unused-variable,unused-argument
    def mock_redirect_list(self):
        return ['<from-module>']

    class MockedActionContext(ActionModuleLoader._create_action_context('<from-module>')):
        @classmethod
        def redirect_list(cls):
            return ['<from-module>']

    ds = dict(
        action=dict(
            module=dict(
                ssh_host='host',
                ssh_port=22,
                ssh_user='user',
            ),
            args=dict(
                _raw_params='find /foo/bar',
            ),
        )
    )
    module_args_parser = ModuleArgsParser(ds)

# Generated at 2022-06-23 04:58:09.408218
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test parsing of action (string-type) with args
    action, args, delegate_to = ModuleArgsParser().parse(task_ds=dict(action='copy src=a dest=b'))
    assert action == "copy"
    assert args['src'] == 'a'
    assert args['dest'] == 'b'

    # test parsing of action (string-type) without args
    action, args, delegate_to = ModuleArgsParser().parse(task_ds=dict(action='pwd'))
    assert action == "pwd"
    assert args == {}

    # test parsing of action with complex args
    action, args, delegate_to = ModuleArgsParser().parse(task_ds=dict(action={'copy': {'src': 'a', 'dest': 'b'}}))
    assert action == "copy"

# Generated at 2022-06-23 04:58:10.497529
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    p = ModuleArgsParser()



# Generated at 2022-06-23 04:58:18.192021
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m1 = ModuleArgsParser(task_ds=None, collection_list=None)
    m1.resolved_action = None
    assert m1._task_attrs == frozenset(['static', 'tags', 'register', 'listen', 'environment', 'remote_user', 'local_action'])
    assert m1._task_ds == {}
    assert m1._collection_list is None
    assert m1.resolved_action is None
    assert m1.parse(skip_action_validation=True) == (None, dict(), None)



# Generated at 2022-06-23 04:58:30.390404
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:58:36.954121
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'},
                                          collection_list=None)
    args = module_args_parser.parse()
    assert args == ('copy',
                    {'src': 'a',
                     'dest': 'b'},
                    None)

# Generated at 2022-06-23 04:58:48.059080
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:58:59.207073
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test normal usage
    task_ds = dict(
            action=dict(
                module='copy',
                src='{{ src_path_1 }}',
                dest='dest'
            )
    )
    ModuleArgsParser(task_ds=task_ds).parse()

    # test with local_action
    task_ds = dict(
        local_action=dict(
            module='copy',
            src='{{ src_path_1 }}',
            dest='dest'
        )
    )
    ModuleArgsParser(task_ds=task_ds).parse()

    # test with module
    task_ds = dict(
        module=dict(
            module='copy',
            src='{{ src_path_1 }}',
            dest='dest'
        )
    )

# Generated at 2022-06-23 04:59:10.503909
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: could use some more testing here
    # create an instance of the class under test
    task_ds = {'action': 'ec2'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'ec2'
    assert args == {}
    assert delegate_to is None

    task_ds = {'action': 'ec2'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'ec2'
    assert args == {}
    assert delegate_to is None

    task_ds = {'action': 'ec2 region=xyz'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action

# Generated at 2022-06-23 04:59:18.907155
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    testdata = dict(
        echo='hi',
        local_action='echo hi'
    )
    for k, v in iteritems(testdata):
        m = ModuleArgsParser(task_ds={k: v})
        (action, args, delegate_to) = m.parse()
        assert action == 'shell'
        assert args == dict(
            _raw_params='echo hi'
        )
        assert delegate_to == 'localhost'

# Generated at 2022-06-23 04:59:26.178054
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Make sure all the supported constructor parameters are accepted.
    '''

    parser1 = ModuleArgsParser()
    assert parser1._task_ds is not None

    parser2 = ModuleArgsParser(task_ds={})
    assert parser2._task_ds is not None

    parser3 = ModuleArgsParser(task_ds=dict())
    assert parser3._task_ds is not None

    parser4 = ModuleArgsParser(task_ds=None)
    assert parser4._task_ds is not None

    parser5 = ModuleArgsParser({})
    assert parser5._task_ds is not None

    with pytest.raises(AnsibleAssertionError):
        parser6 = ModuleArgsParser([])



# Generated at 2022-06-23 04:59:36.616642
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    r = m.parse(skip_action_validation=True)
    assert (r[0] is None)

    task_ds = {}
    task_ds['action'] = 'shell echo hi'
    m = ModuleArgsParser(task_ds)
    r = m.parse()
    assert r[0] == 'shell'
    assert r[1] == {'_raw_params': 'echo hi'}

    task_ds = {}
    task_ds['action'] = {'module': 'shell', 'echo': 'hi'}
    task_ds['register'] = 'output'
    task_ds['ignore_errors'] = True
    task_ds['tags'] = ['run']
    task_ds['failed_when'] = 'output.rc != 0'

# Generated at 2022-06-23 04:59:38.180943
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "TODO: Write this test"



# Generated at 2022-06-23 04:59:47.597190
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_task_ds = {
        'name': 'ping',
        'action': 'ping',
        'register': 'pong',
        'run_once': True
    }

    parser = ModuleArgsParser(test_task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert args == None
    assert delegate_to is None

    test_task_ds = {
        'name': 'ping',
        'action': 'ping'
    }

    parser = ModuleArgsParser(test_task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert args == None
    assert delegate_to is None


# Generated at 2022-06-23 04:59:53.118187
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import re
    task_ds = {'name': u'Read the messages', 'args': {}, 'action': u'win_shell', 'register': u'win_shell_output'}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    # Expecting thing to be None
    assert_equals(None, parser.parse())


# Generated at 2022-06-23 05:00:02.149736
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yaml_data = {
        "action": {
            "module": "aws_ec2  region=us-east-1  x=3"
        }
    }
    ds = yaml.safe_load(yaml.dump(yaml_data))
    task = ModuleArgsParser(ds).parse()
    # parsed action should be 'aws_ec2'
    assert task[0] == 'aws_ec2'
    # parsed args should be {'region': 'us-east-1', 'x': 3}
    assert task[1] == {'region': 'us-east-1', 'x': '3'}
    # delegate_to should be None
    assert task[2] == None


# Generated at 2022-06-23 05:00:05.466406
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ##############
    # Test setup #
    ##############
    class PlaybookLoader:
        pass

    playbook_loader = PlaybookLoader()
    ###################################
    # Test execution of parse method #
    ###################################
    module_args_parser = ModuleArgsParser(task_dict)
    module_args_parser.parse()

# Generated at 2022-06-23 05:00:14.780055
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test case 1
    data = dict(
        action="copy",
        src="a",
        dest="b"
    )
    obj = ModuleArgsParser(data)
    assert obj._normalize_old_style_args(data) == (u'copy', {u'src': u'a', u'dest': u'b'})

    # test case 2
    data = dict(
        action=dict(
            module="copy",
            src="a",
            dest="b"
        )
    )
    obj = ModuleArgsParser(data)
    assert obj._normalize_old_style_args(data) == (u'copy', {u'src': u'a', u'dest': u'b'})

    # test case 3

# Generated at 2022-06-23 05:00:26.655702
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    args_data = '''
    - a
    - b
    '''
    args_list = loader.load(args_data, '', '', '', '', True)

    kvps_data = '''
    - copy:
        src: a
        dest: b
    '''
    kvps_list = loader.load(kvps_data, '', '', '', '', True)

    one_arg_data = '''
    - shell
    '''
    one_arg_list = loader.load(one_arg_data, '', '', '', '', True)
