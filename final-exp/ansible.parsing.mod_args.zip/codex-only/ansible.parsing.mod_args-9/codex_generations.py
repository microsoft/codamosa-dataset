

# Generated at 2022-06-23 04:50:34.098984
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    unit test for the ModuleArgsParser class
    '''
    from ansible.cli.arguments import options as cli_opts
    cli_opts['syntax'] = True
    task_ds = dict(action='shell', args='echo hi')
    p = ModuleArgsParser(task_ds, [])
    results = p.parse()
    assert (results[0] == 'shell')
    assert (results[2] is None)
    assert (results[1]['_raw_params'] == 'echo hi')
    task_ds = dict(action='shell', args='echo hi')
    p = ModuleArgsParser(task_ds, [])
    results = p.parse(skip_action_validation=True)
    assert (results[0] == 'shell')

# Generated at 2022-06-23 04:50:39.647634
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # _task_ds = None
    # collection_list = None
    moduleargs = ModuleArgsParser()
    # test_task_ds = None
    # test_collection_list = None
    # expected = None
    # result = moduleargs._split_module_string()
    # assert result == expected
    return



# Generated at 2022-06-23 04:50:52.130283
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import six
    parser = ModuleArgsParser()
    task_ds = {
        "action": "python",
        "args": "{{ lookup('path', 'file1') }}",
        "_ansible_lineage": "x",
        "name": "xxx"
    }
    (action, args, delegate_to) = parser.parse(task_ds, [])
    assert action == u'python'
    assert args == {'_variable_params': u'{{ lookup(\'path\', \'file1\') }}'}
    assert delegate_to == None

    # test action
    # args is a dict

# Generated at 2022-06-23 04:51:04.498871
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': u'ec2'}

# Generated at 2022-06-23 04:51:06.866179
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-23 04:51:14.020957
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # These are all invalid tasks
    test_cases = [
        {},  # No action at all
        {'action': 1},  # action value is not a dict or a string
        {'local_action': 1},  # local_action value is not a dict or a string
    ]

    # Break the loop at the first invalid task
    for test_case in test_cases:
        parser = ModuleArgsParser(task_ds=test_case)

        # Test that an error is raised
        with pytest.raises(AnsibleParserError):
            parser.parse()
        # Test that parsing stops at the first invalid task
        assert test_case == test_cases[-1]


# Generated at 2022-06-23 04:51:21.577286
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Empty input
    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(None)
    assert 'task_ds' in to_text(excinfo)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(1)
    assert 'task_ds' in to_text(excinfo)

    task_ds = dict(action='shell echo hello world')
    map = ModuleArgsParser(task_ds)
    assert map._task_ds == task_ds
    assert map._collection_list == None
    assert map.resolved_action is None

    task_ds = dict(action='shell echo hello world')
    map = ModuleArgsParser(task_ds, ['test_collection'])
    assert map._task_ds == task_ds

# Generated at 2022-06-23 04:51:30.889679
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:37.018690
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args = {'action': 'set_fact', 'delegate_to': 'localhost', 'args': {'ansible_facts': {'ansible_hello': 'world'}}}
    action, args, delegate_to = ModuleArgsParser().parse(module_args)
    assert action == 'set_fact'
    assert delegate_to == 'localhost'
    assert args == {'ansible_facts': {'ansible_hello': 'world'}}

# Generated at 2022-06-23 04:51:45.913233
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test an empty dict is ok
    parser = ModuleArgsParser({})
    assert parser is not None
    assert not parser._task_ds

    # Test an integer is not ok
    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(2)

    # Test a string is not ok
    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser('echo hi')



# Generated at 2022-06-23 04:51:56.422259
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.parsing.yaml.objects
    import ansible.playbook.task

# Generated at 2022-06-23 04:52:07.873088
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # delegate_to: test
    test_dict = dict(delegate_to='test')
    parser = ModuleArgsParser(task_ds=test_dict)
    # the task_ds of parser should be the input test_dict
    assert parser._task_ds == test_dict
    assert parser.resolved_action is None

    # action: shell echo hi
    test_dict = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds=test_dict)
    # the task_ds of parser should be the input test_dict
    assert parser._task_ds == test_dict
    assert parser.resolved_action is None

    # local_action: shell echo hi
    test_dict = dict(local_action='shell echo hi')
    parser = ModuleArgsParser(task_ds=test_dict)
    #

# Generated at 2022-06-23 04:52:14.785954
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    variables = VariableManager(loader=loader, inventory=inv_manager)
    module_parser = ModuleArgsParser(task_ds={}, collection_list={})
    assert module_parser.parse() == (None, dict(), None)

# Generated at 2022-06-23 04:52:19.891694
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {}
    ds['local_action'] = 'shell echo hi'
    ds['register'] = 'result'
    ds['remote_user'] = 'root'
    map = ModuleArgsParser(ds)
    assert map._task_ds == ds


# Generated at 2022-06-23 04:52:30.764641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': {'module': 'command', 'args': 'pwd', 'chdir': '/tmp'}}, collection_list=None)
    assert parser.parse() == ('command', {'chdir': '/tmp'}, None)

    parser = ModuleArgsParser(task_ds={'action': {'module': 'command', 'args': 'pwd', 'chdir': '/tmp'}, 'delegate_to': 'local'}, collection_list=None)
    assert parser.parse() == ('command', {'chdir': '/tmp'}, 'local')

    parser = ModuleArgsParser(task_ds={'action': 'command pwd', 'delegate_to': 'local'}, collection_list=None)
    assert parser.parse() == ('command', {}, 'local')

    parser = ModuleArgs

# Generated at 2022-06-23 04:52:32.991024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    m=ModuleArgsParser()
    assert m.parse() == (None, (), None)

# Generated at 2022-06-23 04:52:44.889929
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test for fuzziness in the forms of module invocations
    # the ModuleArgsParser expects the module name to be known,
    # so this is kinda cheating by expanding the test data
    # to include the name of the module in each case, but it
    # avoids having to create a second parser implementation

    module_parser = ModuleArgsParser()

    parse_result = module_parser.parse({'local_action': 'ping'})
    assert parse_result == ('ping', {}, 'localhost')

    parse_result = module_parser.parse({'local_action': {'module': 'ping', 'data': 'pong'}})
    assert parse_result == ('ping', {'data': 'pong'}, 'localhost')

    parse_result = module_parser.parse({'local_action': 'ping data=pong'})
    assert parse_

# Generated at 2022-06-23 04:52:53.267223
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import pytest

    with pytest.raises(AssertionError):
        ModuleArgsParser("")
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds="")
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=["action1", "action2"])
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=("action1", "action2"))
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=dict(action1="", action2=""))

# Unit tests for _split_module_string

# Generated at 2022-06-23 04:52:56.190859
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # _parse_action_module_string_args should return an array
  # assert type(_parse_action_module_string_args() is list)
  raise NotImplementedError()

# Generated at 2022-06-23 04:53:05.022933
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class MockModule:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class MockModuleLoader:
        def is_valid_module_path(self):
            pass

        def find_module(self, args):
            MockModule(args.get('a'), args.get('b'))

    task_ds = dict(
        action=dict(
            module=dict(
                module=MockModule,
                args=dict(
                    a=1,
                    b=2
                    )
                )
            )
        )
    module_loader = MockModuleLoader()
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    module_args_parser.module_loader = module_loader
    action, args, delegate

# Generated at 2022-06-23 04:53:05.673017
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True

# Generated at 2022-06-23 04:53:16.962845
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    creates a sample task and calls the constructor and
    parse() method of class ModuleArgsParser
    '''

    my_task = {
        'action': {
            'module': 'copy',
            'src': '/tmp/doc1',
            'dest': '/usr/local/doc1'
        },
        'delegate_to': 'localhost'
    }

    my_task1 = {
        'action': {
            'module': 'shell',
            '_raw_params': 'cat /etc/ansible/hosts',
            'foo': 'bar'
        }
    }

    my_task2 = {
        'action': {
            'module': 'shell',
            '_raw_params': '{{ var }}',
            'foo': 'bar'
        }
    }

    result, result

# Generated at 2022-06-23 04:53:23.801069
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # empty dictionary
    parser = ModuleArgsParser(task_ds=dict())
    assert parser._task_ds == {}

    # null
    parser = ModuleArgsParser(task_ds=None)
    assert parser._task_ds == {}

    # integer
    parser = ModuleArgsParser(task_ds=42)
    assert parser._task_ds == 42

    # string
    parser = ModuleArgsParser(task_ds='foo')
    assert parser._task_ds == 'foo'

    # list
    parser = ModuleArgsParser(task_ds=['foo', 'bar'])
    assert parser._task_ds == ['foo', 'bar']



# Generated at 2022-06-23 04:53:28.644704
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()
    collection_list = list()

    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert "the type of 'task_ds' should be a dict, but is a" in str(excinfo.value)



# Generated at 2022-06-23 04:53:40.414585
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args_parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert args_parser.parse() == (None, {}, None)
    args_parser = ModuleArgsParser(task_ds={'action': '', 'delegate_to': 'x'}, collection_list=None)
    assert args_parser.parse() == (None, {}, 'x')
    args_parser = ModuleArgsParser(task_ds={'module': '', 'delegate_to': 'x'}, collection_list=None)
    assert args_parser.parse() == (None, {}, 'x')
    args_parser = ModuleArgsParser(task_ds={'local_action': ''}, collection_list=None)
    assert args_parser.parse() == (None, {}, 'localhost')

# Generated at 2022-06-23 04:53:43.957501
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # task_ds is a dict type
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds
    assert parser._task_attrs
    assert parser.resolved_action is None

    # task_ds is not a dict type
    task_ds = list()
    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(task_ds)

    # task_ds is None
    parser = ModuleArgsParser()
    assert parser._task_ds
    assert parser._task_attrs
    assert parser.resolved_action is None

# Generated at 2022-06-23 04:53:54.675365
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:04.981399
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    module_args_parser = ModuleArgsParser(task_ds={'action': 'template', 'local_action': 'copy', 'delegate_to': 'localhost', 'args': {'a': 'b'}})
    assert module_args_parser._task_attrs == frozenset(task_attrs)
    assert module_args_parser._task_ds['action'] == 'template'
    assert module_args_parser._task_ds['local_action'] == 'copy'
    assert module_args_parser._

# Generated at 2022-06-23 04:54:17.702652
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = {}
    map = ModuleArgsParser(task_ds, collection_list)
    result = map.parse()
    assert result == (None, dict(), None)


    task_ds = {'module': 'ec2', 'x': 1}
    collection_list = {}
    map = ModuleArgsParser(task_ds, collection_list)
    result = map.parse()
    assert result == (None, dict(), None)


    task_ds = 'copy src=a dest=b'
    collection_list = {}
    map = ModuleArgsParser(task_ds, collection_list)
    result = map.parse()
    assert result == (None, dict(), None)


    task_ds = {'shell': 'echo hi'}
    collection_list = {}
    map = Module

# Generated at 2022-06-23 04:54:34.067531
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Run unit test with the following:
    # python3 -m pytest lib/ansible/playbook/play_context.py -k test_ModuleArgsParser_parse

    from pprint import pprint

    # Execute the parse method
    parser = ModuleArgsParser(task_ds=None)
    results_1 = parser.parse()
    print("\nDictionary displayed using pprint:\n")
    pprint(results_1)
    print("\nTuple displayed using tuple:\n")
    print(results_1)

    parser = ModuleArgsParser(task_ds={})
    results_2 = parser.parse()
    print("\nDictionary displayed using pprint:\n")
    pprint(results_2)
    print("\nTuple displayed using tuple:\n")
    print(results_2)

    # Exec

# Generated at 2022-06-23 04:54:40.484304
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yaml_str = '''
- name: shell
  local_action: shell echo hi
  become: false
  become_user: root
  register: output_shell
  tags:
  - testing
'''
    task_ds = yaml.safe_load(yaml_str)[0]
    parser = ModuleArgsParser(task_ds)
    actual_result = parser.parse()
    expected_result = ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    assert actual_result == expected_result

# Generated at 2022-06-23 04:54:50.033154
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Initialize the class and pass in arguments to the constructor
    # that would normally be passed in via ansible task.
    parser = ModuleArgsParser()

    # Test the parser.parse() method
    # Case 1: Test that local_action key works
    # Case 2: Test that action key works
    # Case 3: Test that module key works
    # Case 4: Test that meta key works
    task_ds1 = dict(
        local_action = dict(
            module = 'some_action',
            task_args=dict(
                a=1,
                b=2
            )
        )
    )

    task_ds2 = dict(
        action = dict(
            module = 'some_action',
            task_args=dict(
                a=1,
                b=2
            )
        )
    )

   

# Generated at 2022-06-23 04:55:01.768570
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(dict())
    assert m.parse() == (None, dict(), None)
    m = ModuleArgsParser({'action': {'module': 'copy', 'args': 'src=a dest=b', 'x': 1}})
    assert m.parse() == ('copy', {'src': 'a', 'dest': 'b', 'x': 1}, None)
    m = ModuleArgsParser({'local_action': {'module': 'copy', 'args': 'src=a dest=b', 'x': 1}})
    assert m.parse() == ('copy', {'src': 'a', 'dest': 'b', 'x': 1}, 'localhost')

# Generated at 2022-06-23 04:55:04.473053
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'module': 'shell'}, collection_list=None)
    assert isinstance(module_args_parser, ModuleArgsParser)

# Generated at 2022-06-23 04:55:08.796641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_item = dict()
    args_item['action'] = ''
    task_ds = dict()
    task_ds['action'] = ''
    parser = ModuleArgsParser(task_ds)
    assert_equals(parser.parse(), ('', {}, None))

# Generated at 2022-06-23 04:55:11.550055
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # no arg
    parser = ModuleArgsParser()
    assert isinstance(parser, ModuleArgsParser)

    # with args
    parser = ModuleArgsParser()
    assert isinstance(parser, ModuleArgsParser)


# Generated at 2022-06-23 04:55:24.485089
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    ansible_mod_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)

    # It is expect to raise a AnsibleParserError excetion
    assert_raises(AnsibleParserError, ansible_mod_args_parser.parse)

    task_ds = dict()
    task_ds['action'] = ""
    task_ds['args'] = ""
    task_ds['re'] = ""
    task_ds['fail_json'] = ""

    # It is expect to raise a AnsibleParserError excetion
    assert_raises(AnsibleParserError, ansible_mod_args_parser.parse)

    task_ds = dict()
    task_ds['action'] = ""
    task_ds['args'] = dict()
    task_ds

# Generated at 2022-06-23 04:55:32.246934
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    :return:
    """

    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Struct(dict):
        def __getattr__(self, item):
            return self[item]

        def __setattr__(self, key, value):
            self[key] = value

        def __delattr__(self, item):
            del self[item]

    class StructMut(Struct, MutableMapping):
        pass

    EmptyStruct = Struct()
    EmptyStructMut = StructMut()

    class EmptyClass:
        """
        """


# Generated at 2022-06-23 04:55:41.293379
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test empty
    # FIXME
    #action, args, delegate_to = ModuleArgsParser(task_ds={}).parse()
    # AssertionError: the type of 'task_ds' should be a dict, but is a <class 'NoneType'>

    # test simple
    action, args, delegate_to = ModuleArgsParser(task_ds={'action': 'test'}).parse()
    assert action == 'test'
    assert args == {}
    assert delegate_to == Sentinel

    # test dict
    action, args, delegate_to = ModuleArgsParser(task_ds={'module': {'module': 'test', 'args': 'a=b'}}).parse()
    assert action == 'test'
    assert args == {'a': 'b'}
    assert delegate_to == Sentinel

    # test dict with args


# Generated at 2022-06-23 04:55:44.772298
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={"module": "shell", "args": "some-param"})
    assert module_args_parser



# Generated at 2022-06-23 04:55:45.701562
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # TODO
  pass


# Generated at 2022-06-23 04:55:55.679017
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from ansible.errors import AnsibleError
  from ansible.errors import AnsibleParserError
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.block import Block
  from ansible.playbook.role import Role
  from ansible.playbook.role.include import RoleInclude
  from ansible.utils.display import Display
  from ansible.utils.vars import combine_vars

  display = Display()

  variables = {
    'test1': 'value1',
    'test2': 2,
    'test3': {
      'key1': 'val1',
      'key2': 'val2',
      'key3': {
        'key3_1': 'val3_1'
      }
    }
  }

  # case when action is None


# Generated at 2022-06-23 04:56:04.324041
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # input is a single action, correctly specified
    # (action and params)
    task_ds_one = dict(action=dict(module='shell', _raw_params='ls -l'))
    args_parser = ModuleArgsParser(task_ds_one)
    (action, args, delegate_to) = args_parser.parse()
    assert action == "shell"
    assert args == {'_raw_params': 'ls -l'}
    assert delegate_to is None

    # input is a single action, with module and args specified
    # the output should be the same
    task_ds_two = dict(action=dict(module='shell', _raw_params='ls -l', _uses_shell=True))
    args_parser = ModuleArgsParser(task_ds_two)

# Generated at 2022-06-23 04:56:14.261329
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(dict(action=dict(module='shell', source='foo', dest='bar')))
    action, args, delegate_to = m.parse()
    assert action == 'shell'
    assert delegate_to is None
    assert set(args.keys()) == set(['source', 'dest'])
    assert args['source'] == 'foo'
    assert args['dest'] == 'bar'

    m = ModuleArgsParser(dict(action='shell echo hi'))
    action, args, delegate_to = m.parse()
    assert action == 'shell'
    assert delegate_to is None
    assert set(args.keys()) == set(['_raw_params'])
    assert args['_raw_params'] == 'echo hi'


# Generated at 2022-06-23 04:56:18.704510
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert parser.resolved_action is None
    assert parser._task_ds == {}
    assert parser._collection_list is None
    assert parser._task_attrs == frozenset([])
    assert parser.resolved_action is None


# Generated at 2022-06-23 04:56:24.184222
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    original_task_ds = dict(
        action='shell',
        args='echo hi',
        delegate_to='{{ foo }}',
        become='yes',
    )

    module_args_parser = ModuleArgsParser(original_task_ds, collection_list=None)

# Generated at 2022-06-23 04:56:36.395028
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)

    # Case 1
    assert module_args_parser.parse(skip_action_validation=True) == (None,dict(),Sentinel)

    # Case 2
    task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert module_args_parser.parse(skip_action_validation=True) == ('copy',{'dest': 'b', 'src': 'a'},Sentinel)

    # Case 3
    task_ds={'action': 'copy src=a dest=b'}

# Generated at 2022-06-23 04:56:47.444585
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task

    mod_class = Task.load_task_plugins(['shell'])
    task = Task()
    task.action = 'shell'
    task.args['shell_type'] = 'csh'
    mod = task.get_action_handler()
    arg_parser = mod.load_args()

    task_ds = {}
    task_ds['action'] = 'shell'
    task_ds['args'] = {'shell_type': 'sh'}

    module_arg_parser = ModuleArgsParser(task_ds,
                                         collection_list=None)
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'shell'
    assert args['shell_type'] == 'sh'
    assert delegate_to is None



# Generated at 2022-06-23 04:56:55.873638
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict()
    ds['delegate_to'] = 'localhost'
    ds['action'] = 'test'
    ds['args'] = 'test'
    ds['_raw_params'] = 'test'
    ds['module'] = 'test'
    task_ds = ds
    collection_list = None
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert obj._task_ds == ds
    assert obj._collection_list is None
    assert obj._task_attrs == frozenset({'static', 'register', 'poll', 'local_action', 'ignore_errors', 'become', 'when', 'become_user', 'become_method', 'async'})
    assert obj.resolved_action is None
    skip_

# Generated at 2022-06-23 04:56:57.145189
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ModuleArgsParser()


# Generated at 2022-06-23 04:57:09.232915
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    def test_block():
        dataloader = DataLoader()
        yaml_obj = AnsibleLoader(dataloader, {}).load('action: shell echo hi')
        task_parsed = ModuleArgsParser(task_ds=yaml_obj).parse(skip_action_validation=False)
        assert task_parsed[0] == 'shell'
        assert task_parsed[1]['_raw_params'] == 'echo hi'

    test_block()
    dataloader = DataLoader()
    yaml_obj = AnsibleLoader(dataloader, {}).load('action: pwd args: chdir: /tmp')
    task_p

# Generated at 2022-06-23 04:57:14.140066
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.utils.vars import isidentifier

    # Task and Handler attributes are valid for a Task Dict so make sure
    # we have them all by checking field names
    task_ds = dict()
    for attr in Task._valid_attrs:
        task_ds[attr] = "test"
    for attr in Handler._valid_attrs:
        task_ds[attr] = "test"

    parser = ModuleArgsParser(task_ds=task_ds)

    # We should have attributes corresponding to all Task and Handler attributes.
    assert parser._task_attrs == frozenset(task_ds.keys())

    # Task name is an identifier and is not a valid attribute.

# Generated at 2022-06-23 04:57:20.525774
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        action=dict(
            module="shell",
            echo=True,
            args=dict(
                _raw_params="echo '{{inventory_hostname}}'",
            ),
        )
    )
    obj = ModuleArgsParser(task_ds=task_ds)
    assert obj



# Generated at 2022-06-23 04:57:30.661334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext

    # The following methods are defined in the module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    module.exit_json = lambda **args: sys.exit(0)
    module.fail_json = lambda **args: sys.exit(1)

    # Begin testing
    task_ds = dict()
    collection_list = list()

    task_ds['action'] = dict()
    task_ds['action']['module'] = 'shell'
    task_ds['action']['args'] = 'echo hi'

    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

# Generated at 2022-06-23 04:57:38.895488
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'delegate_to': 'localhost', 'local_action': 'copy src=a dest=b'}
    null_collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=null_collection_list)
    assert(module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost'))
    assert(module_args_parser.resolved_action is not None)


# Generated at 2022-06-23 04:57:43.631165
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook import PlaybookInclude
    task_ds = dict(action='ping')
    mp = ModuleArgsParser(task_ds, PlaybookInclude.COLLECTION_PATHS)
    assert mp._task_ds == task_ds


# Generated at 2022-06-23 04:57:53.882053
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:57:55.849883
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # a = ModuleArgsParser()
    # assert a.parse() == (None)
    pass

# Generated at 2022-06-23 04:57:59.746411
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task = dict(action='shell echo hi')
    module_args_parser = ModuleArgsParser(task)
    assert 'shell' == module_args_parser._split_module_string(task['action'])[0]

    task = dict(action='shell')
    module_args_parser = ModuleArgsParser(task)
    assert '' == module_args_parser._split_module_string(task['action'])[1]



# Generated at 2022-06-23 04:58:13.061518
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  def test_data(arg):
    return {'action': arg}, {'action': arg}, 'localhost'


# Generated at 2022-06-23 04:58:22.226912
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    action = ActionModule(None, execute_task=True, loader_name='null', task_vars={})
    result = action.run(dict(action=dict(module='test_module', args=dict(test_arg1='test_value1', test_arg2='test_value2'))),
                        play_context=dict(basedir='/path/to/my/ansible/playbooks'))
    result.get('skipped')  # if no exception is raised, the test is OK



# Generated at 2022-06-23 04:58:27.872913
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'delegate_to': 'xxx', 'should_skip_tags': True, 'args': {'raw': False}, 'action': {'src': 'xyz'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ("{'src': 'xyz'}", {}, 'xxx')


# Generated at 2022-06-23 04:58:36.464967
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser({})
    assert parser.resolved_action is None

    with pytest.raises(AnsibleAssertionError):
        _ = ModuleArgsParser(123)

    # test _task_ds is empty
    with pytest.raises(AnsibleError):
        _ = parser.parse(skip_action_validation=False)

    # test local_action without delegate_to
    parser = ModuleArgsParser({'local_action': []})
    assert parser.resolved_action is None
    assert parser.parse(skip_action_validation=False) == (None, dict(), 'localhost')

    parser = ModuleArgsParser({'local_action': ''})
    assert parser.resolved_action is None

# Generated at 2022-06-23 04:58:46.829545
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test parsing a file
    ds = dict(
        action=dict(
            module='foo',
            x=5,
            y=8
        )
    )
    parser = ModuleArgsParser(ds)
    (action, args, delegate_to) = parser.parse()
    assert_equal(delegate_to, None)
    assert_equal(action, 'foo')
    assert_equal(args, {'x': 5, 'y': 8})

    # test parsing a dict
    ds = dict(
        action=dict(
            module='foo',
            x=5,
            y=8
        )
    )
    parser = ModuleArgsParser(ds)
    (action, args, delegate_to) = parser.parse()
    assert_equal(delegate_to, None)

# Generated at 2022-06-23 04:58:58.393851
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds1 = {
        'action': 'echo a={{a}} b={{b}}'
    }

    task_ds2 = {
        'action': {
            'module': 'echo',
            'args': 'a={{a}} b={{b}}'
        }
    }

    task_ds3 = {
        'action': {
            'module': 'echo',
            'a': '{{a}}',
            'b': '{{b}}'
        }
    }

    task_ds4 = {
        'action': {
            'module': 'echo',
            'a': '{{a}}',
            'b': '{{b}}',
            '_raw_params': 'c={{c}}'
        }
    }


# Generated at 2022-06-23 04:59:09.027414
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=dict(
        delegate_to='localhost',
        action=dict(
            module='shell',
            args=dict(
                _raw_params='chdir=/root && echo {{ ansible_hostname }}',
            ),
        ),
    ))
    assert parser.parse() == ('shell', dict(
        _raw_params='chdir=/root && echo {{ ansible_hostname }}',
    ), 'localhost')
    assert parser.parse() == ('shell', dict(
        _raw_params='chdir=/root && echo {{ ansible_hostname }}',
    ), 'localhost')
# END Unit test for method parse of class ModuleArgsParser


# Generated at 2022-06-23 04:59:11.212670
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()
    mp = ModuleArgsParser(task_ds)
    assert isinstance(mp, ModuleArgsParser)


# Generated at 2022-06-23 04:59:23.274744
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils.common._collections_compat import Mapping

    assert issubclass(ModuleArgsParser, object)
    assert isinstance(ModuleArgsParser(task_ds={}, collection_list=None), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds=dict(), collection_list=None), ModuleArgsParser)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds='hi')
    assert 'the type of \'task_ds\' should be a dict, but is a str' in str(excinfo.value)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds=['hi'])

# Generated at 2022-06-23 04:59:34.772356
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template.safe_eval import unsafe_eval

    # create the class
    map = ModuleArgsParser()

    # test the constructor
    assert isinstance(map, ModuleArgsParser)
    assert map._task_ds == {}
    assert map._collection_list is None
    assert isinstance(map._task_attrs, frozenset)
    assert map.resolved_action is None

    # testing the _split_module_string() method
    # old style
    assert map._split_module_string('') == ('', '')
    assert map._split_module_string(None) == ('', '')

# Generated at 2022-06-23 04:59:43.506110
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # task without module
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # task with not supported module
    task_ds = dict(notexistmodule='something')
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # task with valid module
    task_ds = dict(shell='something')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert delegate_to == Sentinel
    assert args['_raw_params'] == 'something'
    assert parser.resolved_action == 'ansible.builtin.shell'

    # task

# Generated at 2022-06-23 04:59:52.645970
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    task_ds = Task.load(
        dict(
            name="test task name",
            action="copy src=a dest=b",
            delegate_to="foohost",
            become=True,
            become_user="susan",
            become_method="sudo",
        )
    )

    module_args_parser = ModuleArgsParser(task_ds)
    assert(isinstance(module_args_parser, ModuleArgsParser))


# Generated at 2022-06-23 05:00:02.265117
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_data = {}
    expected = set(Task._valid_attrs.keys())
    expected.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    expected.update(['local_action', 'static'])
    expected = frozenset(expected)
    obj = ModuleArgsParser(task_ds=task_data)
    result = obj._task_attrs
    assert_equals.__self__.maxDiff = None
    assert_equals(result, expected)


# Generated at 2022-06-23 05:00:05.854089
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    r = ModuleArgsParser(task_ds=dict(action=dict(module="test_module_name")))
    r.parse()


# Generated at 2022-06-23 05:00:15.022680
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    assert_raises(AssertionError, ModuleArgsParser, task_ds=None, collection_list=[])
    assert_raises(AssertionError, ModuleArgsParser, task_ds=1, collection_list=[])
    assert_raises(AssertionError, ModuleArgsParser, task_ds=[], collection_list=[])
    assert_raises(AssertionError, ModuleArgsParser, task_ds="", collection_list=[])

    assert_raises(AnsibleParserError, ModuleArgsParser, task_ds={}).parse()

    # task with invalid action
    task_ds = dict(action='copy src=xyz dest=abc')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert_raises(AnsibleParserError, parser.parse)

    # task with action: echo, without

# Generated at 2022-06-23 05:00:26.915060
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # first, exercise the different supported forms the args can come in

    # new form:
    #  - name: test
    #    action: module args
    task_ds = dict(action='module args')
    res = ModuleArgsParser(task_ds).parse()
    assert res == ('module', {'_raw_params': 'args'}, Sentinel)

    # old form:
    #  - name: test
    #    action: module=args
    task_ds = dict(action='module=args')
    res = ModuleArgsParser(task_ds).parse()
    assert res == ('module', {'args': 'args'}, Sentinel)

    # old form:
    #  - name: test
    #    action: module args
    task_ds = dict(action='module args')