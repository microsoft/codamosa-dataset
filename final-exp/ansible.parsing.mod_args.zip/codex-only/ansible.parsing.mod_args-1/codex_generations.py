

# Generated at 2022-06-23 04:50:28.924392
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task = dict()
    task['module'] = 'module name'
    task['args'] = 'arg1=val1 arg2=val2'
    task['other_arg'] = 'other_arg'
    p = ModuleArgsParser(task_ds=task, collection_list=None)
    assert p is not None


# Generated at 2022-06-23 04:50:39.348507
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # Test with old-style 'action' specified and no module/action conflict
  with pytest.raises(AnsibleError) as excinfo:
    task = dict(action = dict(module = 'shell', args = dict(a=1)))
    module_args_parser = ModuleArgsParser(task_ds=task, collection_list=None)
    module_args_parser.parse(skip_action_validation=False)
  assert 'invalid parameter specified for action \'shell\': \'_ansible_a\'' in str(excinfo.value)
  # Test with new-style 'action' specified and no module/action conflict
  task = dict(action = 'command echo hi there')
  module_args_parser = ModuleArgsParser(task_ds=task, collection_list=None)
  action, args, delegate_to = module_

# Generated at 2022-06-23 04:50:40.233353
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Generated at 2022-06-23 04:50:47.616690
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    # NOTE: test is skipped for now.
    # action_loader is not initialized, so the following code
    # will raise attribute error

# Generated at 2022-06-23 04:50:55.458032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('test_ModuleArgsParser_parse: START')
    args_parser = ModuleArgsParser({})
    action, arguments, delegate_to = args_parser.parse()
    print('action=%s' % action)
    print('Arguments=%s' % json.dumps(arguments))
    print('delegate_to=%s' % delegate_to)
    print('test_ModuleArgsParser_parse: END')


if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-23 04:50:58.611428
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert parser is not None
    assert parser._task_ds == {}


# Generated at 2022-06-23 04:51:01.001668
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    obj = ModuleArgsParser(task_ds={'action': 'copy xyz'})
    assert obj is not None


# Generated at 2022-06-23 04:51:11.339864
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:25.220141
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import lib.ansible_test_result as ans_test_result

    m = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'}, collection_list=None)
    m.parse()
    assert m.resolved_action == 'copy.copy'

    m = ModuleArgsParser(task_ds={'action': 'file state=directory path=/test'}, collection_list=None)
    m.parse()
    assert m.resolved_action == 'file.file'

    m = ModuleArgsParser(task_ds={'action': 'file_attributes'}, collection_list=None)
    m.parse()
    assert m.resolved_action == 'lookup.file_attributes'


# Generated at 2022-06-23 04:51:29.526397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yaml_task = dict(local_action='sl module=name')
    task = VarsModule.load(None, task_ds=yaml_task)
    parser = ModuleArgsParser(task_ds=task)
    action, args, delegate_to = parser.parse()
    assert action == 'sl'
    assert args['module'] == 'name'
    assert delegate_to == 'localhost'



# Generated at 2022-06-23 04:51:39.694847
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Arguments to ModuleArgsParser constructor
    valid_task_ds = dict(action='action', delegate_to='delegate_to', args='args')
    invalid_task_ds = list()
    valid_collection_list = ['col1', 'col2']
    invalid_collection_list = dict()
    # Call constructor without any argument
    parser_noargs = ModuleArgsParser()
    assert parser_noargs._task_ds == dict() and parser_noargs._collection_list is None and parser_noargs._task_attrs is None
    # Call constructor with task_ds argument
    parser_task_ds = ModuleArgsParser(task_ds=valid_task_ds)
    assert parser_task_ds._task_ds == valid_task_ds and parser_task_ds._collection_list is None and parser_task_ds._task_

# Generated at 2022-06-23 04:51:52.060330
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.module_utils.common.collections
    import ansible.parsing.yaml.objects

    # Test idempotence
    yaml_dict1 = ansible.parsing.yaml.objects.AnsibleUnicode()
    task_ds1 = [yaml_dict1, 'key1', 'value1']
    collection_list1 = ansible.module_utils.common.collections.AnsibleCollectionRef()
    module_arg_parser1 = ModuleArgsParser(task_ds=task_ds1, collection_list=collection_list1)
    yaml_dict2 = ansible.parsing.yaml.objects.AnsibleUnicode()
    task_ds2 = [yaml_dict2, 'key2', 'value2']

# Generated at 2022-06-23 04:51:55.938991
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parsed = ModuleArgsParser({"action": {"module": "ping", "_raw_params": "data=blah"}}).parse()

    assert parsed[0] == "ping"
    assert parsed[1] == {"data": "blah"}
    assert parsed[2] == Sentinel



# Generated at 2022-06-23 04:52:04.036665
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    t = dict(action = dict(module = 'shell', args = 'hi there'), delegate_to = 'localhost')
    p = ModuleArgsParser(t)
    assert p.parse() == ('shell', dict(args = 'hi there'), 'localhost')

    t = dict(action = dict(module = 'shell', args = 'hi there'), delegate_to = 'localhost')
    p = ModuleArgsParser(t)
    assert p.parse() == ('shell', dict(args = 'hi there'), 'localhost')

    t = dict(action = 'shell echo hi')
    p = ModuleArgsParser(t)
    assert p.parse() == ('shell', dict(), None)


# Generated at 2022-06-23 04:52:16.792473
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    bad_form_0_task_ds = {"action":"xyz", "other":["this_should_not_be_here"]}
    bad_form_5_task_ds = {"action":"xyz", "args":"this_should_not_be_here"}
    good_form_5_task_ds = {"action":"xyz", "args":"this_should_be_here"}
    bad_form_6_task_ds = {"action":["this_should_not_be_here"]}
    good_form_6_task_ds = {"action":"xyz", "args":"this_should_be_here"}
    good_form_7_task_ds = {"action":"xyz", "args":{"key":"value"}}

    # test for bad input

# Generated at 2022-06-23 04:52:19.227324
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # Test with module_loader
  # Test with action_loader
  # Test with not valid actions
  pass


# Generated at 2022-06-23 04:52:30.273473
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_set1 = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'x': 'y'
        }
    }

    test_set2 = {
        'action': 'copy src=a dest=b',
        'args': 'y',
    }

    test_set3 = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
    }

    test_set4 = {
        'action': {
            'module': 'copy src=a dest=b'
        },
        'delegate_to': 'localhost',
    }


# Generated at 2022-06-23 04:52:32.560377
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(task_ds={}, collection_list=[])
    assert m


__all__ = ['ModuleArgsParser', 'test_ModuleArgsParser']

# Generated at 2022-06-23 04:52:37.735245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'ping'
    args = {}
    delegate_to = None
    thing = None
    skip_action_validation = False
    task_ds = {}

    ar = ModuleArgsParser(task_ds=task_ds)
    ar.parse(skip_action_validation=skip_action_validation)


# Generated at 2022-06-23 04:52:48.193699
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():


    #Incorrect module name
    task_ds = {
        "module": "pw",
    }
    with pytest.raises(AnsibleParserError):
        parser = ModuleArgsParser(task_ds=task_ds)
        parser.parse()

    #Incorrect module with Right action
    task_ds = {
        "module": "pw",
        "action": "copy",
    }
    with pytest.raises(AnsibleParserError):
        parser = ModuleArgsParser(task_ds=task_ds)
        parser.parse()

    #Incorrect module with Right action
    task_ds = {
        "module": "pw",
        "action": "copy",
    }

# Generated at 2022-06-23 04:52:59.288782
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser_1 = ModuleArgsParser(task_ds=dict())
    assert module_args_parser_1
    assert module_args_parser_1._task_ds == dict()
    assert module_args_parser_1._collection_list == None

# Generated at 2022-06-23 04:53:08.279236
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Test the ModuleArgsParser constructor."""
    assert ModuleArgsParser({'action': 'copy', 'dest': 'b'})
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser('a')

# Unit tests for _split_module_string()

# Generated at 2022-06-23 04:53:18.755962
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.play_context import PlayContext
    task = dict(action=dict(module='command', args='ls'))
    fork_args = dict(action=dict(module='fork', args='echo "bar"'))
    no_fork_args = dict(action=dict(module='debug', args='msg="bar"'))
    no_delegate_to = dict(action=dict(module='debug', args='msg={{inventory_hostname}}'))
    delegate_to_inventory = dict(action=dict(module='debug', args='msg={{inventory_hostname}}'), delegate_to='{{inventory_hostname}}')
    delegate_to_variable = dict(action=dict(module='debug', args='msg=foo'), delegate_to='{{delegate_var}}')
    delegate_to_localhost_with_unused

# Generated at 2022-06-23 04:53:27.565998
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-23 04:53:40.364543
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test using a method of the mock object

    import unittest.mock as mock

    class mock_ModuleArgsParser:

        def __init__(self, task_ds=None, collection_list=None):
            pass

        def parse(self, skip_action_validation=False):
            return 'mock parse method'

    with mock.patch.object(ModuleArgsParser, 'parse', new_callable=mock_ModuleArgsParser):
        module_args_parser = ModuleArgsParser()
        assert module_args_parser.parse() == 'mock parse method'

    # Test using a decorator of the mock object

    class mock_ModuleArgsParser:

        def __init__(self, task_ds=None, collection_list=None):
            pass


# Generated at 2022-06-23 04:53:48.717686
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = dict(
        action=dict(
            module='shell',
            _raw_params='ls -la /root',
            creates='/root/file.ext'
        )
    )
    p = ModuleArgsParser(dict(
        action=dict(
            module='shell',
            _raw_params='ls -la /root',
            creates='/root/file.ext'
        )
    ))

    # Test 1
    assert p.parse() == ('shell', {'_raw_params': 'ls -la /root', 'creates': '/root/file.ext'}, Sentinel)

    # Test 2
    t = dict(
        action=dict(
            module='shell',
            _raw_params='ls -la /root',
            creates='/root/file.ext'
        )
    )
    p

# Generated at 2022-06-23 04:53:54.801082
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    sample_task_ds = {
        "action": "shell",
        "args": {
            "foo": "bar"
        }
    }
    module_args_parser = ModuleArgsParser(task_ds=sample_task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'foo': 'bar'}
    assert delegate_to is None


# Generated at 2022-06-23 04:54:05.113498
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    thing = dict(action=dict(module='ping', attribute='hello'))
    parser = ModuleArgsParser(thing)
    assert parser.parse() == ('ping', dict(attribute='hello'), None)

    thing = dict(local_action='ping')
    parser = ModuleArgsParser(thing)
    assert parser.parse() == ('ping', dict(), 'localhost')

    # this is a combination of some old and new style stuff
    thing = dict(action=dict(shell='echo hello', _uses_shell='true'), local_action='ping')
    parser = ModuleArgsParser(thing)
    assert parser.parse() == ('ping', dict(), 'localhost')

    thing = dict(action=dict(module='shell', answer=42), ping='ping')
    parser = ModuleArgsParser(thing)

# Generated at 2022-06-23 04:54:11.860393
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds={'action': 'ec2', 'with_sequence': ['1', '2', '3'], 'with_fileglob': ['file1', 'file2']})
    assert obj.parse() == ('ec2', {}, None)
# END class ModuleArgsParser

# START class Conditional

# Generated at 2022-06-23 04:54:25.133354
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    def test(data, action=None, args=None):
        print("input: %s" % data)
        if 'delegate_to' in data:
            print("delegate_to: %s" % data['delegate_to'])
        if 'when' in data:
            print("when: %s" % data['when'])
        obj = ModuleArgsParser(data)
        (res_action, res_args, res_delegateto) = obj.parse()
        print("result: action=%s, args=%s" % (res_action, res_args))
        assert action == res_action
        assert args == res_args
        if obj._task_ds.get('delegate_to', Sentinel) is not Sentinel:
            assert obj._task_ds['delegate_to'] == res_deleg

# Generated at 2022-06-23 04:54:31.611979
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

    assert_raises(AnsibleAssertionError, ModuleArgsParser, [])
    assert_raises(AnsibleAssertionError, ModuleArgsParser, 'string')
    assert_raises(AnsibleAssertionError, ModuleArgsParser, 42)


# Generated at 2022-06-23 04:54:43.070005
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.play_context import PlayContext
    ds = dict(
        action = 'shell echo hi',
        local_action = 'shell echo hi',
        delegate_to = 'localhost',
        remote_user = 'testuser',
        become_user = 'testuser',
        become = 'yes',
        args = {
            '_raw_params': 'echo hi',
            '_uses_shell': True,
        },
        x = 1,
        y = 2
    )
    parser = ModuleArgsParser(task_ds=ds)
    assert parser != None

    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args['_raw_params'] == 'echo hi'

    # test constructor with a ModuleArgsParser object

# Generated at 2022-06-23 04:54:51.029412
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test old_style action with single kw
    parser = ModuleArgsParser(dict(action='ping'))
    assert parser.parse() == ('ping', {}, Sentinel)

    # test old_style action with multiple kw
    parser = ModuleArgsParser(dict(action='ping count=1'))
    assert parser.parse() == ('ping', {'count': '1'}, Sentinel)

    # test old_style action with multiple kw and dict
    parser = ModuleArgsParser(dict(action='ping count=1'))
    assert parser.parse() == ('ping', {'count': '1'}, Sentinel)

    # test old_style action with dict
    parser = ModuleArgsParser(dict(action={'module': 'ping', 'count': 1}))
    assert parser.parse() == ('ping', {'count': 1}, Sentinel)



# Generated at 2022-06-23 04:54:58.679076
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    ModuleArgsParser.parse()
    """
    with pytest.raises(Exception) as excinfo:
        ModuleArgsParser().parse()
    assert 'the type of \'task_ds\' should be a dict, but is a <class \'NoneType\'>' in str(excinfo.value)

    # initialize
    task_ds = {}
    collection_list = {}
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    with pytest.raises(Exception) as excinfo:
        module_args_parser.parse()
    assert 'no module/action detected in task.' in str(excinfo.value)

    # initialize
    task_ds = {'arg1': 'value1'}
    collection_list = {}

# Generated at 2022-06-23 04:55:09.508785
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={})
    assert module_args_parser.parse() == (None, dict(), Sentinel)
    # test 1
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)
    # test 2
    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)
    # test 3

# Generated at 2022-06-23 04:55:21.508560
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six.moves import cStringIO

    h = ModuleArgsParser()
    task_ds = {'module': 'command cat /dev/null', 'sudo': False, 'delegate_to': '127.0.0.1', 'remote_user': 'root', 'args': '', 'delegate_facts': None, 'sudo_user': 'root', 'register': 'my_result', 'no_log': False}
    h.parse(task_ds)

# Generated at 2022-06-23 04:55:33.383737
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Test ModuleArgsParser constructor
    :return:
    """
    # Test with dict
    module_args_parser = ModuleArgsParser(
        task_ds={
            "action": {
                "module": "command",
                "args": (
                    "cowsay",
                    "hello world"
                )
            }
        },
        collection_list=[
            "ansible_collections.misc"
        ]
    )
    module_args_parser.parse()

    # Test with string
    module_args_parser = ModuleArgsParser(
        task_ds={
            "action": "command cowsay hello world"
        },
        collection_list=[
            "ansible_collections.misc"
        ]
    )
    module_args_parser.parse()

    # Test with not-supported type
   

# Generated at 2022-06-23 04:55:35.000046
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Testing the class constructor
    # No exception expected
    module_args_parser = ModuleArgsParser()



# Generated at 2022-06-23 04:55:42.382739
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test = dict(foo=1, bar='test', baz='yay')
    module_args_parser = ModuleArgsParser(test)

    assert isinstance(module_args_parser._task_ds, dict)
    assert isinstance(module_args_parser._task_attrs, frozenset)
    assert module_args_parser._collection_list is None
    assert module_args_parser.resolved_action is None



# Generated at 2022-06-23 04:55:44.771854
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test = ModuleArgsParser()
    test.parse()
# ---------------------------------------------------------------------------------------------------
# Class DynamicInclude


# Generated at 2022-06-23 04:55:55.330203
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # We're not going to do a comprehensive unit test here, as we're mostly
    # just testing the parsing/normalization logic, which is already tested
    # in the module_utils/argspec.py unit tests.
    #
    # Instead, we'll just test the wrapping/integration of that code here to
    # ensure the output of this function looks correct
    def _test_case(task_ds):
        # Helper function for creating a test case easily
        # We can't do this in the test decorator as the decorated functions
        # don't have any metadata set on them, which we need for the test
        # description, so we need a helper
        parser = ModuleArgsParser(task_ds)
        action, args, delegate_to = parser.parse()
        assert action == task_ds['expected_action']
        assert args == task_ds

# Generated at 2022-06-23 04:56:04.116775
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    _task_ds = {'action': 'stat path=/usr/lib mode'}
    _retval = (
        'stat', {
            'path': '/usr/lib',
            'mode': ''
        }
    )
    _test_func = lambda x: isinstance(x[0], AnsibleUnsafeText) and \
                           isinstance(x[1], dict) and \
                           x[1]['ansible_facts']['stat']['path'] == AnsibleUnsafeText("/usr/lib")
    _patch_func = lambda x: (AnsibleUnsafeText(x[0]), x[1])	
    _module = ModuleArgsParser(
        task_ds = _task_ds
    )
    _retval

# Generated at 2022-06-23 04:56:13.811690
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            module='copy',
            src='/tmp/src',
            dest='/tmp/dest'
        )
    )
    m = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = m.parse()
    assert action == 'copy'
    assert delegate_to is None
    assert args['src'] == '/tmp/src'
    assert args['dest'] == '/tmp/dest'

    task_ds = dict(action='copy src=/tmp/src dest=/tmp/dest')
    m = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = m.parse()
    assert action == 'copy'
    assert delegate_to is None
    assert args['src'] == '/tmp/src'

# Generated at 2022-06-23 04:56:22.268863
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_data = dict(
      action=dict(
        action='setup',
        delegate_to='{{ delegate }}',
        args=dict(
          filter='ansible_local'
        ),
        local_action='setup',
        with_items='{{ delegate }}'
      ),
      expected=dict(
        action='setup',
        args=dict(
          delegate='{{ delegate }}',
          filter='ansible_local'
        ),
        delegate_to='localhost'
      )
    )

    parser = ModuleArgsParser()
    result = parser.parse(**test_data['action'])
    assert result == test_data['expected']

# Generated at 2022-06-23 04:56:34.376645
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # pylint: disable=too-many-locals
    tds = dict(action=dict(module='shell', args='ls'), delegate_to='other')
    ap = ModuleArgsParser(task_ds=tds)
    action, args, delegate_to = ap.parse()
    assert action == 'shell'
    assert args == dict(args='ls', _raw_params='ls')
    assert delegate_to == 'other'

    tds = dict(action=dict(module='shell', x='y'), delegate_to='other')
    ap = ModuleArgsParser(task_ds=tds)
    action, args, delegate_to = ap.parse()
    assert action == 'shell'
    assert args == dict(x='y')
    assert delegate_to == 'other'


# Generated at 2022-06-23 04:56:42.567626
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mock_loader = MockLoader()
    collection_list = CollectionList(mock_loader)
    for task_dict in iteritems(task_ds_to_test):
        assert isinstance(task_dict[1], dict)
        parser = ModuleArgsParser(task_dict[1], collection_list)
        action, args, delegate_to = parser.parse()

        assert isinstance(action, string_types)
        assert isinstance(args, dict)
        assert isinstance(delegate_to, string_types) or delegate_to is None

task_ds_to_test = dict(
    basic_string=dict(action="shell echo hello world",)
)

# Generated at 2022-06-23 04:56:50.302704
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(action=dict(module='shell', args=dict(x=1, y=2)), delegate_to='localhost')
    ma = ModuleArgsParser(task_ds=ds)
    try:
        (action, args, delegate_to) = ma.parse()
    except Exception as e:
        raise AssertionError('Failed to parse action: {0}'.format(e))
    assert action == "shell", "Module action should be 'shell'"
    assert isinstance(args, dict), "Module args should be dictionary"
    assert args == dict(x=1, y=2), "Module args should be {'x': 1, 'y': 2}"
    assert delegate_to == "localhost", "Module delegate_to should be 'localhost'"


# Generated at 2022-06-23 04:57:04.918357
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:57:12.707485
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Test constructor of class ModuleArgsParser."""

    parser = ModuleArgsParser(task_ds={'module_name1': 'args1', 'module_name2': 'args2'},
                              collection_list=['module_name1', 'module_name2'])
    assert parser._task_ds == {'module_name1': 'args1', 'module_name2': 'args2'}
    assert parser._collection_list == ['module_name1', 'module_name2']

# Generated at 2022-06-23 04:57:25.422886
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:57:36.428341
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:57:49.459693
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import Include
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-23 04:57:58.987322
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:58:06.470922
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # create object instance
    object_instance = ModuleArgsParser(task_ds=None, collection_list=None)

    # Check if has attribute parse
    result = hasattr(object_instance, 'parse')

    # Check if result is true
    assert result is True, "Expected: True, but got: %s" % result


# Generated at 2022-06-23 04:58:17.322921
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	args = {}
	module_name = 'test module'
	local_action = 'test local_action'
	delegate_to = 'test delegate'

	task_data = {}
	parser = ModuleArgsParser(task_data)
	args, delegate_to = parser.parse()
	assert args == {}
	assert delegate_to is None

	task_data = {'module': module_name}
	parser = ModuleArgsParser(task_data)
	args, delegate_to = parser.parse()
	assert args == {}
	assert delegate_to is None

	task_data = {'action': module_name}
	parser = ModuleArgsParser(task_data)
	args, delegate_to = parser.parse()
	assert args == {}
	assert delegate_to is None


# Generated at 2022-06-23 04:58:29.981802
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    import ansible.playbook
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.task
    import ansible.playbook.handler
    module_loader = ansible.plugins.loader.module_loader
    action_loader = ansible.plugins.loader.action_loader
    module_loader._find_plugins(ansible.module_utils)
    action_loader._find_plugins(ansible.module_utils)
    collection_list = ansible.utils.collection_loader.get_collections_from_list_of_paths([])
    module_arg_parser = ModuleArgsParser(
        task_ds={},
        collection_list=collection_list)
    module_arg_parser.parse()

# Generated at 2022-06-23 04:58:42.879150
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:58:52.920463
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test conversion of old style action to new style action
    data = dict(
        action='copy a b',
        delegate_to='test_host',
    )
    obj = ModuleArgsParser(task_ds=data)
    result = obj.parse()
    assert result == ('copy', {'a': None, 'b': None}, 'test_host')

    # Test conversion of old style local_action to new style local_action
    data = dict(
        local_action='copy a b',
        delegate_to='test_host',
    )
    obj = ModuleArgsParser(task_ds=data)
    result = obj.parse()
    assert result == ('copy', {'a': None, 'b': None}, 'localhost')

    # Test conversion of new style action to new style action

# Generated at 2022-06-23 04:58:56.100153
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Unit test for constructor of class ModuleArgsParser
    """

    parser = ModuleArgsParser()
    assert parser.resolved_action is None

# Generated at 2022-06-23 04:59:08.468130
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils._text import to_text

    t = dict(
        action=dict(
            module='command',
            args='/bin/foo'
        ),
        delegate_to='localhost'
    )
    p = ModuleArgsParser(task_ds=t)
    assert p.parse() == ('command', dict(_raw_params='/bin/foo'), 'localhost')

    t = dict(
        action=dict(
            module='shell',
            args='/bin/foo'
        ),
        delegate_to='localhost'
    )
    p = ModuleArgsParser(task_ds=t)
    assert p.parse() == ('shell', dict(_raw_params='/bin/foo'), 'localhost')


# Generated at 2022-06-23 04:59:14.833502
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  module_args_parser = ModuleArgsParser(task_ds={'module': 'copy', 'src': 'a', 'dest': 'b', 'delegate_to': 'localhost'})
  assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')


# Generated at 2022-06-23 04:59:23.347217
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test all possible combinations
    task_ds = {}
    mp = ModuleArgsParser(task_ds)
    assert mp.resolved_action == None
    mp = ModuleArgsParser(task_ds, collection_list=None)
    assert mp.resolved_action == None

    task_ds = {'test': '1'}
    mp = ModuleArgsParser(task_ds)
    assert mp.resolved_action == None
    mp = ModuleArgsParser(task_ds, collection_list=None)
    assert mp.resolved_action == None

    task_ds = {'test': '1', 'action': 'echo 1'}
    mp = ModuleArgsParser(task_ds)
    assert mp.resolved_action == None
    mp = ModuleArgsParser(task_ds, collection_list=None)
    assert mp.res

# Generated at 2022-06-23 04:59:34.821827
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:59:41.905495
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit tests for constructor of class ModuleArgsParser
    '''
    constructor_inputs = (
        # test case 1
        dict(
            task_ds=dict(
                action=dict(
                    module='foo'
                ),
                delegate_to='localhost'
            )
        ),
        # test case 2: validates that task_ds is a dictionary
        dict(
            task_ds=list()
        )
    )
    for input in constructor_inputs:
        with pytest.raises(AnsibleAssertionError):
            ModuleArgsParser(**input)

# Unit tests for method _split_module_string

# Generated at 2022-06-23 04:59:52.324476
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def mock_parse_kv(data, check_raw=False, errors_fatal=True):
        return {}

    data = {
        "args": "cirros-0.3.4-x86_64-uec",
        "disk_format": "qcow2",
        "container_format": "bare",
        "delegate_to": "localhost",
        "name": "cirros-0.3.4-x86_64-uec"
    }
    task_ds = {}
    if 'args' in data:
        task_ds.update(data)
        del task_ds['args']

# Generated at 2022-06-23 05:00:02.998055
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # 1. test: parameter 'task_ds' is missing, expecting an AnsibleAssertionError
    try:
        parser = ModuleArgsParser(None)
    except AnsibleAssertionError:
        pass
    except Exception as e:
        assert False, "Unexpected exception '%s' raised, expecting an AnsibleAssertionError" % str(e)

    # 2. test: parameter 'task_ds' is not a dict, expecting an AnsibleAssertionError
    try:
        parser = ModuleArgsParser(dict())
    except AnsibleAssertionError:
        pass
    except Exception as e:
        assert False, "Unexpected exception '%s' raised, expecting an AnsibleAssertionError" % str(e)

    # 3. test: parameter 'task_ds' is a valid dict, expecting no exception

# Generated at 2022-06-23 05:00:13.577410
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.constants import TASK_ATTRIBUTE_WARNINGS
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    # gather argument keys for validating unique construction in task_ds
    valid_attrs = set(Task._valid_attrs)
    valid_attrs.update(set(Handler._valid_attrs))
    valid_attrs.remove('vars')
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    valid_attrs.update(['local_action', 'static'])
    # filter out invalid keys for the task_ds

# Generated at 2022-06-23 05:00:25.565067
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Setup the default task_ds to be parsed
    task_ds = dict()

    # Test the default case, in which no module was found (parsable by the parser)
    action_results = dict()
    args_results = dict()
    delegate_to_results = dict()
    parser = ModuleArgsParser(task_ds)
    (action_results, args_results, delegate_to_results) = parser.parse()
    assert action_results is None
    assert args_results is None
    assert delegate_to_results is None
    # Test the case, in which action is found in the task_ds
    task_ds = dict(action = dict(name = 'echo', args = 'hi'))
    action_results = dict()
    args_results = dict()
    delegate_to_results = dict()
    parser = ModuleArgs