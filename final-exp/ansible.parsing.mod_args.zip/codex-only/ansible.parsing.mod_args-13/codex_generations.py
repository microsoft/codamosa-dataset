

# Generated at 2022-06-23 04:50:35.469799
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    class EmptyModuleLoader(object):
        def find_plugin(self, name, mod_type=None, ignore_deprecated=False, check_aliases=True):
            if name in Expect:
                return Expect[name]
        def find_plugin_with_context(self, name, mod_type=None, ignore_deprecated=False, check_aliases=True):
            if name in Expect:
                return Expect[name]
    class EmptyActionLoader(object):
        def find_plugin(self, name, mod_type=None, ignore_deprecated=False):
            if name in Expect:
                return Expect[name]

# Generated at 2022-06-23 04:50:48.601593
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Basic parsing of parameters as a list of key-value pairs
    task_ds = dict(action='shell', args='echo hi')
    parser = ModuleArgsParser(task_ds=task_ds)
    (resolved_action, resolved_args, resolved_delegate_to) = parser.parse(skip_action_validation=True)
    assert resolved_action == 'shell'
    assert resolved_args == dict(args='echo hi')
    assert resolved_delegate_to is Sentinel

    # Basic parsing of parameters as a dictionary of key-value pairs
    task_ds = dict(action='shell', args=dict(args='echo hi'))
    parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-23 04:50:58.998584
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds={'module': 'copy', 'src': 'a', 'dest': 'b'}
    module_arg_parser = ModuleArgsParser(task_ds)
    assert isinstance(module_arg_parser,ModuleArgsParser)

# Generated at 2022-06-23 04:51:00.801777
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass



# Generated at 2022-06-23 04:51:11.212725
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    try:
        # create a instance for ModuleArgsParser
        module_args_parser = ModuleArgsParser()
        assert False, "AnsibleAssertionError is not raised"
    except AssertionError:
        pass

    # pass in invalid type of task_ds
    task_ds_list = ['list_type', (1, 2, 3)]
    for task_ds in task_ds_list:
        try:
            module_args_parser = ModuleArgsParser(task_ds)
            assert False, "AnsibleAssertionError is not raised"
        except AssertionError:
            pass

    # initialize task_ds
    task_ds = {'action': {'module': 'copy', 'x': 1}}


# Generated at 2022-06-23 04:51:25.072037
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Create a ModuleArgsParser object
    myModuleArgsParser = ModuleArgsParser()

    # Test with invalid task_ds
    try:
        myModuleArgsParser.parse()
    except AnsibleAssertionError as e:
        assert(str(e) == "the type of 'task_ds' should be a dict, but is a <type 'NoneType'>")

    # Test with invalid task_ds
    try:
        myModuleArgsParser.parse(task_ds=True)
    except AnsibleAssertionError as e:
        assert(str(e) == "the type of 'task_ds' should be a dict, but is a <type 'bool'>")

    # Test with invalid task_ds

# Generated at 2022-06-23 04:51:32.872666
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.callback import DefaultCallbackModule
    from ansible.vars.reserved import Reserved, DEFAULT_VAULTS
    import os
    import shutil
    import sys

    args = dict

# Generated at 2022-06-23 04:51:41.431687
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # since this is parsing from the module_utils namespace, we'll need to
    # add that to the module search path
    module_name = 'ansible_test_utils.compat.unittest'
    module_args = ['first_argument=updated', 'second_argument=updated', 'third_argument=updated']
    tmp = dict(ANSIBLE_MODULE_ARGS={'first_argument': 'unchanged', 'second_argument': 'unchanged', 'third_argument': 'unchanged'})
    with mock.patch.dict(os.environ, tmp):
        module_args_parser = ModuleArgsParser(module_name, module_args)
        (final_args, is_template) = module_args_parser.parse()
    assert final_args['first_argument'] == 'updated'

# Generated at 2022-06-23 04:51:53.368121
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import json
    task_ds = json.loads('''{
  "action1": {
    "module": "copy",
    "args": {
      "src": "a",
      "dest": "b"
    }
  }
}''')
    runner = ModuleArgsParser(task_ds, None)
    assert runner.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = json.loads('''{
  "action2": {
    "module": "copy src=a dest=b"
  }
}''')
    runner = ModuleArgsParser(task_ds, None)
    assert runner.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

# Generated at 2022-06-23 04:52:03.090022
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.playbook.play_context import PlaybookCLI
    PlayContext.CLI = PlaybookCLI

    ds = DataLoader()


# Generated at 2022-06-23 04:52:15.733245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        module_arg_parser.parse()
        assert False
    except:
        pass
    try:
        module_arg_parser.parse(None)
        assert False
    except:
        pass
    module_arg_parser.parse({})
    module_arg_parser.parse({
        'action': 'shell echo hi'
    })
    assert module_arg_parser.parse({
        'action': 'shell echo hi'
    }) == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    module_arg_parser.parse({
        'action': {
            'module': 'shell echo hi'
        }
    })
    assert module_arg_parser.parse({
        'action': {
            'module': 'shell echo hi'
        }
    })

# Generated at 2022-06-23 04:52:27.835722
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    # Get the module.__init__.__globals__, so that we have access
    # to the load_list so we can modify it
    module_globals = sys.modules['ansible.module_utils.basic'].__dict__['__globals__']
    module_defaults = module_globals['DEFAULT_MODULE_UTILS_PATH']
    module_utils_paths = module_globals['MODULE_UTILS_PATH']

    # create an inventory, because we need a Host for the task
    test_host = HostVars()
    test_host

# Generated at 2022-06-23 04:52:28.411300
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:52:37.215670
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import json # this is just to get the type of an empty dict when printing, should really just be using the empty dict type directly

    print("\n------- Testing ModuleArgsParser constructor -------")
    arguments = dict()

    # Test if an empty dict object is passed in
    print("\nTest 1")
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)

    # Test if a dict object containing a module name and args is passed in
    print("\nTest 2")
    task_ds = dict(action=dict(module='test', args=dict(test='test')))
    parser = ModuleArgsParser(task_ds)

    # Test if a dict object containing a local action and args is passed in
    print("\nTest 3")

# Generated at 2022-06-23 04:52:40.694983
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test input
    # parser = ModuleArgsParser(task_ds=None, collection_list=None)

    # test output
    # return_value = parser.parse()
    # assert return_value is None

    pass

# Generated at 2022-06-23 04:52:42.560752
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    M = ModuleArgsParser()
    assert type(M) is ModuleArgsParser


# Generated at 2022-06-23 04:52:52.136734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import yaml
    # Input arguments for the unittest

    data = '''
    - name: test
      actions:
        - role: role
          sudo: True
        - role: role
          sudo_user: root
          sudo: True
        - role: role
          sudo_user: root
          sudo: True
          become_user: "{{become_user}}"
        - role: role
          sudo: True
          become_user: "{{become_user}}"
        - role: role
          become_user: "{{become_user}}"
    '''
    task_ds = yaml.safe_load(data)[0]
    collection_list = []
    # Run the unittest

    #Initialize the parser class with the task_ds

# Generated at 2022-06-23 04:53:03.126336
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test the __init__() function of ModuleArgsParser class.
    # This test is to test the input type of task_ds.
    task_ds = {'hosts': 'all'}
    collection_list = []

    args = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(args, ModuleArgsParser)

    # This test is to test the input type of task_ds.
    task_ds = {'hosts': 'all'}
    collection_list = None

    args = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(args, ModuleArgsParser)

    # This test is to test the input type of task_ds.
    task_ds = {'hosts': 'all'}

    args = ModuleArgsParser(task_ds)

# Generated at 2022-06-23 04:53:12.950043
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:53:19.924869
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    task_ds = {'action': {'module': 'command', 'args': 'ifconfig'}}
    collection_list = None
    ds = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    actual_result = ds.parse()
    expected_result = ('command', {'args': 'ifconfig'})
    assert expected_result == actual_result


# Generated at 2022-06-23 04:53:30.240740
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:53:34.337240
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds={"action": {"module": "copy", "x": 1}, "delegate_to": Sentinel})
    assert obj.parse() == ("copy", {"x": 1}, Sentinel)


# Generated at 2022-06-23 04:53:42.196605
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_data = {
        'name': 'test_module',

        'action': 'test_action',
        'local_action': 'test_local_action',
        'args': {'arg1': 'val1', '_raw_params': 'arg2=val2'},
        'module': 'test_module',
        'delegate_to': 'localhost',
        'with_items': ['tests'],

        'unknown_key': 'unknown_value',
    }
    module_args_parser = ModuleArgsParser(module_data)
    assert module_args_parser is not None

# Generated at 2022-06-23 04:53:43.874131
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 04:53:54.591889
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'with_file': ['/dev/null'], 'meta': {'hostvars': ['host1', 'host2']}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)
    task_ds = {'with_sequence': [1, 2, 3], 'meta': {'hostvars': ['host1', 'host2']}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)
    task_ds = {'name': 'test', 'meta': {'hostvars': ['host1', 'host2']}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)
   

# Generated at 2022-06-23 04:54:04.312436
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={'action': {'module': 'test_module', 'arg': 'test_arg'}})
    action = 'test_module'
    args = {'arg': 'test_arg'}
    delegate_to = None

    assert parser.parse() == (action, args, delegate_to)

    parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    action = 'shell'
    args = {'_raw_params': 'echo hi'}
    delegate_to = None

    assert parser.parse() == (action, args, delegate_to)

    parser = ModuleArgsParser(task_ds={'local_action': 'shell echo hi'})
    action = 'shell'
    args = {'_raw_params': 'echo hi'}
    delegate_to

# Generated at 2022-06-23 04:54:17.444339
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    # test different action types
    task_ds = dict()
    task_ds_1 = dict()
    task_ds_2 = dict()
    task_ds_3 = dict()
    task_ds_4 = dict()
    task_ds_5 = dict()
    task_ds_6 = dict()
    task_ds_7 = dict()
    task_ds_8 = dict()
    task_ds_9 = dict()
    task_ds_10 = dict()
    task_ds_11 = dict()
    task_ds_12 = dict()
    task_ds

# Generated at 2022-06-23 04:54:18.923422
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert ModuleArgsParser()



# Generated at 2022-06-23 04:54:26.218493
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    helper method to aid in unit test construction
    '''
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None


# Generated at 2022-06-23 04:54:37.584001
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:40.369217
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args = {'action': {'module': 'ec2', 'x': 1 }}
    parser = ModuleArgsParser(task_ds=args, collection_list=[])
    assert parser._task_ds == args


# Generated at 2022-06-23 04:54:46.838285
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
    }
    module_args_parser = ModuleArgsParser(task_ds=ds)
    action_name, action_args, delegate_to = module_args_parser.parse()

    assert action_name == 'shell'
    assert action_args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-23 04:54:53.347047
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert not parser.resolved_action
    (action, args, delegate_to) = parser.parse()
    assert action is None
    assert args == dict()
    assert delegate_to == Sentinel



# Generated at 2022-06-23 04:55:02.572167
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Tests for _split_module_string function
    (module_name, args) = ModuleArgsParser(_task_ds=dict())._split_module_string("copy src=a dest=b")
    assert module_name == 'copy'
    assert args == 'src=a dest=b'

    (module_name, args) = ModuleArgsParser(_task_ds=dict())._split_module_string("shell echo hi")
    assert module_name == 'shell'
    assert args == 'echo hi'

    (module_name, args) = ModuleArgsParser(_task_ds=dict())._split_module_string("mysql_db name={{ dbname }} state=absent")
    assert module_name == 'mysql_db'
    assert args == 'name={{ dbname }} state=absent'



# Generated at 2022-06-23 04:55:07.461999
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    parser = ModuleArgsParser()
    assert parser

    # basic setup
    module_args_data = {"action": "shell", "foo": "bar", "delegate_to": "localhost"}

    # test parse
    (action, args, delegate_to) = parser.parse(module_args_data)
    assert action == "shell"
    assert delegate_to == 'localhost'
    assert args["foo"] == "bar"

# Generated at 2022-06-23 04:55:16.691553
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize test variables
    play_context = {
        "become": False,
        "become_method": None,
        "become_user": None,
        "connection": "local",
        "diff": False,
        "private_key_file": None,
        "gather_facts": "smart",
        "module_lang": "en_US.UTF-8",
        "module_set_locale": False,
        "module_name": "command",
        "pattern": "*",
        "playbook_dir": "/etc/ansible/playbooks",
        "remote_addr": None,
        "remote_user": None,
        "response_file": None,
        "shell": None,
        "stdout": False,
        "verbosity": 0
    }
    set_module_

# Generated at 2022-06-23 04:55:28.385305
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    loader = DataLoader()
    # No module_name specified, but "command" used. 'command' is ignored,
    # and the first token will be taken as the module name.
    test = ModuleArgsParser(task_ds={'command': 'shell echo hi'})
    (action, args, delegate_to) = test.parse()
    assert action == 'shell'
    assert args == dict()
    assert delegate_to is None

    # Bad module name
    test = ModuleArgsParser(task_ds={'command': 'foobar echo hi'})
    with pytest.raises(AnsibleParserError):
        test.parse()

    # module: key not specified, but the old 'action' key used. The module
    # name will be taken from 'action'.

# Generated at 2022-06-23 04:55:38.632692
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Unit tests for the ModuleArgsParser constructor
    """

    collection_list = None

    print("Testing constructor of ModuleArgsParser class:")
    print("Test case 1:")
    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(module_args_parser, ModuleArgsParser)

    print("Test case 2:")
    task_ds = {}
    collection_list = None
    with pytest.raises(AssertionError) as excinfo:
        module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-23 04:55:44.919496
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    from ansible.module_utils.common.process import get_bin_path

    adds = {}
    adds['ansible_python_interpreter'] = sys.executable
    adds['ansible_module_name'] = os.path.basename(sys.executable)
    adds['ansible_module_version'] = '0.0.0'
    adds['ansible_module_args'] = ''

    class ParserTestCase(unittest.TestCase):
        def _test_parse(self, task, expected_action, expected_args, expected_delegate_to=None):
            if expected_delegate_to is None:
                expected_delegate_to = Sentinel
            map = ModuleArgsParser(task)
           

# Generated at 2022-06-23 04:55:55.412011
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_task_ds = dict()
    test_collection_list = list()
    test_ModuleArgsParser = ModuleArgsParser(test_task_ds, test_collection_list)

    # assert test_ModuleArgsParser._task_ds == dict()
    # assert test_ModuleArgsParser._collection_list == list()
    assert test_ModuleArgsParser.resolved_action is None

    test_task_ds = dict(test1='test1')
    test_collection_list = list(test2='test2')
    test_ModuleArgsParser = ModuleArgsParser(test_task_ds, test_collection_list)

    assert test_ModuleArgsParser.resolved_action is None

    test_task_ds = dict(action='echo hi', delegate_to='localhost', args=dict(orignal_args='orignal_args'))

# Generated at 2022-06-23 04:56:04.171585
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    assert module_args_parser.parse({"action": "command echo hi"}) == ('command', {'_raw_params': 'echo hi'},None)
    assert module_args_parser.parse({"local_action": "command echo hi"}) == ('command', {'_raw_params': 'echo hi'}, 'localhost')
    assert module_args_parser.parse({"test": "command echo hi"}) == ('test', {'_raw_params': 'echo hi'}, None)
    assert module_args_parser.parse({"command": "echo"}) == ('command', {'_raw_params': 'echo'}, None)

# Generated at 2022-06-23 04:56:10.449398
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import find_plugin, find_action_plugin
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    cls = ModuleArgsParser
    # self._task_attrs
    expected = set(Task._valid_attrs.keys())
    expected.update(set(Handler._valid_attrs.keys()))
    expected.update(['local_action', 'static'])
    assert cls._task_attrs == expected


# Generated at 2022-06-23 04:56:11.271742
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-23 04:56:17.911394
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_data = {}
    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(task_ds=test_data)
    test_data = dict()
    parser = ModuleArgsParser(task_ds=test_data)
    assert parser._task_ds == {}
    assert parser._collection_list is None
    assert parser._task_attrs == frozenset()
    assert parser.resolved_action is None



# Generated at 2022-06-23 04:56:24.449846
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an empty instance of the class
    # module_args_parser = ModuleArgsParser()
    # Check that the the parse method raises an exeption if the task_ds argument is not a dictionary
    # with pytest.raises(Exception) as excinfo:
    #     task_ds = []
    #     module_args_parser.parse(task_ds)
    # assert 'the type of \'task_ds\' should be a dict, but is a list' in str(excinfo.value)
    pass


# Generated at 2022-06-23 04:56:36.701748
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    Parser = ModuleArgsParser

    assert Parser({'module': 'shell', 'args': 'echo foo'}, None).parse() == ('shell', {'_raw_params': 'echo foo'}, Sentinel)
    assert Parser({'module': 'cookbook', 'args': 'echo foo'}, None).parse() == ('cookbook', {'_raw_params': 'echo foo'}, Sentinel)
    assert Parser({'module': 'shell', 'args': {'foo': 'bar'}}, None).parse() == ('shell', {'foo': 'bar'}, Sentinel)
    assert Parser({'module': 'shell', 'args': {'foo': 'bar'}}, None).parse() == ('shell', {'foo': 'bar'}, Sentinel)

# Generated at 2022-06-23 04:56:37.360051
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:56:48.397483
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # empty task
    task_ds = dict()
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser is not None

    # a task with old module syntax
    task_ds = dict()
    task_ds['action'] = dict()
    task_ds['action']['module'] = 'test'
    task_ds['action']['args'] = dict()
    task_ds['action']['args']['arg1'] = 'val1'
    task_ds['action']['args']['arg2'] = 'val2'
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser is not None

    # a task with new module syntax
    task_ds = dict()

# Generated at 2022-06-23 04:57:02.852972
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of class ModuleArgsParser
    args_parser = ModuleArgsParser(None)

    # Check if the given input returns the expected result
    assert (args_parser._normalize_old_style_args(dict(shell='echo hi')) == ('shell', dict(cmd='echo hi')))

    # Check if the given input returns the expected result
    assert (args_parser._normalize_old_style_args('shell echo hi') == ('shell', dict(cmd='echo hi')))

    # Check if the given input returns the expected result
    assert (args_parser._normalize_old_style_args(dict(module='ec2', x=1)) == ('ec2', dict(x=1, module=None)))

    # Check if the given input returns the expected result

# Generated at 2022-06-23 04:57:05.256406
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Ensure the constructor for class ModuleArgsParser
    does not throw an exception
    '''

    ModuleArgsParser()



# Generated at 2022-06-23 04:57:16.245115
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for ansible.module_utils.common.ModuleArgsParser.parse()
    '''

    # one randomized task to parse
    task_ds = {
        'ignore_errors': 'yes',
        'gather_facts': 'no',
        'shell': 'cat /etc/passwd',
        'register': 'shell_out',
        'run_once': 'yes',
        'name': 'Display contents of /etc/passwd'
    }

    module_args_parser = ModuleArgsParser(task_ds)

    module_args = module_args_parser.parse()

    assert module_args == (u'shell', {'_raw_params': u'cat /etc/passwd', '_uses_shell': True}, None)

# Generated at 2022-06-23 04:57:26.740188
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'shell': 'echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    task_ds = {'shell': {'_raw_params': 'echo hi'}}
    parser = Module

# Generated at 2022-06-23 04:57:27.878970
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser()
    assert m

# Generated at 2022-06-23 04:57:36.268335
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert parser._split_module_string('shell echo hi') == ('shell', 'echo hi')
    assert parser._split_module_string('shell') == ('shell', '')
    assert parser._split_module_string('shell echo hi there') == ('shell', 'echo hi there')
    assert parser._split_module_string('shell echo hi=there') == ('shell', 'echo hi=there')
    assert parser._split_module_string('shell echo hi=there extra params') == ('shell', 'echo hi=there extra params')
    # test legacy form
    assert parser._normalize_old_style_args(thing='shell echo hi there') == ('shell', {'_raw_params': 'echo hi there'})
    assert parser._normalize_old_style

# Generated at 2022-06-23 04:57:44.952826
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:57:49.797157
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    thing = ModuleArgsParser(task_ds={})
    assert isinstance(thing, ModuleArgsParser)
    assert thing._task_ds == {}
    assert thing._task_attrs == frozenset(['local_action', 'static'])
    assert thing._collection_list is None
    assert thing.resolved_action is None


# Generated at 2022-06-23 04:57:59.277937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test typical usage
    task_ds = {
        'shell' : 'echo hi',
        'delegate_to' : 'otherhost'
    }
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to == 'otherhost'
    assert parser.resolved_action is None

    # Test typical usage
    task_ds = {
        'local_action' : {
            'shell' : 'echo hi',
        },
    }
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()

# Generated at 2022-06-23 04:58:07.795388
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        action=dict(module='shell', args='echo hello', chdir='/tmp'),
        delegate_to='foo',
    )
    parser = ModuleArgsParser(task_ds, collection_list=[])
    results = parser.parse()
    assert results[0] == 'shell'
    assert results[1] == dict(_raw_params='echo hello', chdir='/tmp')
    assert results[2] == 'foo'

# Generated at 2022-06-23 04:58:18.543883
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test ModuleArgsParser with valid task_ds
    ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds=ds)
    try:
        parser.parse()
    except Exception as e:
        raise AssertionError("unexpected exception {}".format(e))

    ds = dict(local_action=dict(module='echo', args='goodbye'))
    parser = ModuleArgsParser(task_ds=ds)
    try:
        parser.parse()
    except Exception as e:
        raise AssertionError("unexpected exception {}".format(e))

    # test invalid task_ds

# Generated at 2022-06-23 04:58:20.979395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # We do not need to test this method, as we call the original one.
    pass


# Generated at 2022-06-23 04:58:32.186391
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {
        'action': {'module': 'copy', 'src': 'a', 'dest': 'b'},
        'args': {'content': 'answer', 'backup': 'yes'}
    }
    parser = ModuleArgsParser(task_ds=ds, collection_list=None)
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    assert delegate_to == 'localhost'

    # make sure we get errors in the right place
    ds = {
        'action': {'module': 'copy', 'src': 'a', 'dest': 'b'},
        'local_action': {'content': 'answer', 'backup': 'yes'}
    }

   

# Generated at 2022-06-23 04:58:34.694169
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert module_args_parser is not None


# Generated at 2022-06-23 04:58:46.792166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class FakeDS(object):
        def __init__(self, d):
            self.d = d
        def __getitem__(self, k):
            return self.d[k]
    import ansible.plugins.action as action_loader
    module_loader = action_loader
    task_ds = FakeDS({
        'action': 'command echo hi',
        'delegate_to': 'localhost',
        'args': 'echo hi'
    })
    collection_list = None
    x = ModuleArgsParser(task_ds, collection_list)
    (action, args, delegate_to) = x.parse()
    assert action == 'command', "list returned has an unexpected value for action"
    assert args == {'_raw_params':'echo hi'}, "list returned has an unexpected value for args"
    assert delegate_

# Generated at 2022-06-23 04:58:55.169426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up test environment
    import ansible.playbook.task
    module = ansible.playbook.task.ModuleArgsParser({'action': 'echo hi', 'delegate_to': 'joe'}, collection_list=None)

    # Test the method
    assert module._ModuleArgsParser__split_module_string('copy local_dest=/etc') == ('copy', 'local_dest=/etc')

    assert module._ModuleArgsParser__normalize_parameters('a=b c=d', 'pip') == ('pip', {'a': 'b', 'c': 'd'})

    assert module._ModuleArgsParser__normalize_parameters({'b': {'a': 'b', 'c': 'd'}}, 'pip') == ('pip', {'a': 'b', 'c': 'd'})


# Generated at 2022-06-23 04:58:56.289457
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert 0

# Generated at 2022-06-23 04:59:08.652314
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()
    # BEGIN TASK_DS #
    task_ds = dict(
        delegate_to = None,
        
        action = dict(
            module = dict(),
            delegate_to = None,
            args = dict(),
            
        ),
    )
    # END TASK_DS #
    
    # BEGIN EXPECTED RESULT #
    expected_result = dict(
        action = None,
        args = dict(),
        delegate_to = None,
    )
    # END EXPECTED RESULT #
    
    # BEGIN CALL TO METHOD #
    result = module_args_parser.parse(task_ds)
    # END CALL TO METHOD #
    
    assert expected_result == result
    


# Generated at 2022-06-23 04:59:17.624806
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    c = PlayContext()
    ds = dict()
    collection_list = None
    m = ModuleArgsParser(ds, collection_list)
    # test that an assertion is raised if the task_ds is not a dict
    ds = 'hi'
    with pytest.raises(AnsibleAssertionError):
        m._task_ds = ds
        ModuleArgsParser.parse(m)
    # test that the k=v string of the args is parsed to a dict and
    # assigned to the args attribute, and
    # assign the value of the args dict as the value of the args
    # attribute
    ds = dict(action='copy src=a dest=b')
    m._task_ds = ds

# Generated at 2022-06-23 04:59:26.286697
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    basic_ds = dict(action=dict(module='shell', args='ls /'))
    action, args, delegate_to = ModuleArgsParser(basic_ds).parse()
    assert dict(args='ls /', module='shell') == args

    action_ds = dict(action='shell ls /')
    action, args, delegate_to = ModuleArgsParser(action_ds).parse()
    assert dict(args='ls /', _raw_params='ls /') == args

    action_string_arg_ds = dict(action='shell ls /', args=dict(chdir='/tmp'))
    action, args, delegate_to = ModuleArgsParser(action_string_arg_ds).parse()
    assert dict(args='ls /', _raw_params='ls /', chdir='/tmp') == args

    module_string_arg_ds

# Generated at 2022-06-23 04:59:39.074325
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    templar = Templar(loader=None)

    # Test multiple module names in task_ds
    task_ds = {'action': "shell echo hi", 'module': "shell echo hi"}
    with pytest.raises(AnsibleParserError) as exc:
        module_arg_parser = ModuleArgsParser(task_ds=task_ds, collection_list=[])
    assert "conflicting action" in to_text(exc)
    task_ds = {'action': "shell echo hi", 'local_action': "shell echo hi"}
    with pytest.raises(AnsibleParserError) as exc:
        module_arg_parser = ModuleArgsParser(task_ds=task_ds, collection_list=[])
    assert "conflicting action" in to_text(exc)

# Generated at 2022-06-23 04:59:49.237758
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test ModuleArgsParser.parse()
    print("Testing ModuleArgsParser.parse()")
    test_parser = ModuleArgsParser({'action': 'command', 'args': {'chdir': '/tmp'}}, collection_list=['test'])
    # Test ModuleArgsParser.parse() when action parameter is not None
    with pytest.raises(AnsibleError) as excinfo:
        test_parser.parse(skip_action_validation=True)
    assert 'invalid parameter specified for action \'command\': \'_ansible_\'' in to_native(excinfo.value)
    assert 'AnsibleError' in to_native(excinfo.value)
    # Test ModuleArgsParser.parse() when action parameter is None

# Generated at 2022-06-23 04:59:51.295421
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # TODO: stub out the task_ds to verify it's not an error
    ModuleArgsParser()



# Generated at 2022-06-23 04:59:58.718941
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'echo': 'I', 'shell': True, 'become': True, 'become_user': 'root'}}
    action, args, delegate_to = ModuleArgsParser(task_ds=task_ds).parse()
    print(action, args, delegate_to)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo I', 'become': True, 'become_user': 'root'}
    assert delegate_to == Sentinel

# Generated at 2022-06-23 05:00:07.752056
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Task with 'action' and 'module'
    with pytest.raises(AnsibleError) as e:
        action = {
            'action': 'foo',
            'module': 'bar'
        }
        ModuleArgsParser(action)
    assert to_text(e.value) == "conflicting action statements: foo, module"

    # Task with 'action' and 'local_action'
    with pytest.raises(AnsibleError) as e:
        action = {
            'action': 'foo',
            'local_action': 'bar'
        }
        ModuleArgsParser(action)
    assert to_text(e.value) == "action and local_action are mutually exclusive"

    # Task with only 'local_action' and 'args'

# Generated at 2022-06-23 05:00:13.246928
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up mock
    class MockObj(object):
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)

    mock_task_ds = MockObj(action={'test': 'foo'}, args={'test': 'bar'}, delegate_to={'test': 'baz'})
    
    # Invoke method
    module_args_parser = ModuleArgsParser(mock_task_ds)
    module_args_parser.parse()

    # Check instance attributes
    assert module_args_parser._task_ds == {'action': {'test': 'foo'}, 'args': {'test': 'bar'}, 'delegate_to': {'test': 'baz'}}
    assert module_args_parser.resolved_action == None
    
    # Check return value


# Generated at 2022-06-23 05:00:28.476937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Use an actual task definition
    #      : run every unit-test in a subprocess to ensure isolated environment
    #      : use https://github.com/ansible/ansible/tree/devel/test/units/parsing/test_module_compat.py
    task_ds = {
        'gather_facts': 'no',
        'local_action': {
            'module': 'command',
            'args': {
                'warn': True,
                '_raw_params': 'uptime',
                '_uses_shell': True,
            }
        },
        'name': 'Show uptime',
    }

    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()

    assert module_args_parser.resolved_action == 'command'
