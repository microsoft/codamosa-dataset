

# Generated at 2022-06-23 04:50:30.104274
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test cases of constructor (__init__) of ModuleArgsParser
    parser = ModuleArgsParser()
    assert parser is not None

    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(task_ds=1)

    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(collection_list=1)

    parser = ModuleArgsParser(task_ds={}, collection_list="some_collections")
    assert parser is not None
    assert parser._collection_list == "some_collections"
    assert parser._task_ds == {}



# Generated at 2022-06-23 04:50:32.413130
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert parser



# Generated at 2022-06-23 04:50:44.078846
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test a basic block
    print('')
    ds = dict(action=dict(module='setup', args=dict(filter='ansible_distribution')))

    ap = ModuleArgsParser(ds)
    action, args, delegate_to = ap.parse()
    assert action == 'setup'
    assert 'module' not in args
    assert args['filter'] == 'ansible_distribution'
    assert delegate_to == Sentinel

    # Test a block with complex args
    print('')
    ds = dict(action=dict(module='template', args="src={{ inventory_dir }}/templates/template.j2 dest={{ inventory_dir }}/outputs/test.conf"))

    ap = ModuleArgsParser(ds)
    action, args, delegate_to = ap.parse()
    assert action == 'template'


# Generated at 2022-06-23 04:50:51.648694
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    obj = {}
    test_obj = ModuleArgsParser(obj)  
    assert test_obj.parse() == (None, {}, None)

    # Note: In this case, the test case is not complete, 
    #       since we don't have the complete method '_normalize_parameters' to run. 
    #       The above assert is not correct for this test case.  
    obj = {'test1': 'test1', 'test2': 'test2'}
    test_obj = ModuleArgsParser(obj)
    assert test_obj.parse() == (None, {}, None)


# Generated at 2022-06-23 04:51:04.274086
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:10.968865
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    args:
        thing:
            description: Arg to test
    '''

    # test args
    action = 'shell'
    thing = 'echo hi'
    module_args = 'echo hi'
    additional_args = {}

    parser = ModuleArgsParser()
    (action, args, delegate_to) = parser.parse()

    # test args
    action = 'shell'
    thing = 'echo hi'
    module_args = 'echo hi'
    additional_args = {}

    parser = ModuleArgsParser()
    (action, args, delegate_to) = parser.parse()

# Generated at 2022-06-23 04:51:24.738983
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  # test with example data
  example_data={...}
  ansible_task_tuple = ModuleArgsParser(task_ds=example_data).parse()
  assert ansible_task_tuple[0] == expected
  # check action and module arguments
  assert ansible_task_tuple[1] == expected
  # check delegate_to
  assert ansible_task_tuple[2] == expected

# Generated at 2022-06-23 04:51:32.528546
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(
        action='shell',
        name='echo hi',
        delegate_to='localhost',
        register='out1',
        with_items=['a', 'b', 'c'],
        ignore_errors=True,
        changed_when='False',
        when='False',
        loop_control='loop_var: outer',
        _raw_params='abc -d def',
        _variable_params='abc -d {{def}}',
        loop_args=dict(a=1, b=2)
    )
    task_ds = dict()
    for k, v in iteritems(args):
        task_ds[k] = v

    parser = ModuleArgsParser(task_ds=task_ds, collection_list=[])
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-23 04:51:34.885070
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    ret = parser.parse()
    assert isinstance(ret, tuple)
    assert len(ret) == 3


# Generated at 2022-06-23 04:51:39.313583
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser(task_ds=None)
    module_parser2 = ModuleArgsParser(task_ds=dict())
    assert isinstance(module_parser, ModuleArgsParser)
    assert isinstance(module_parser2, ModuleArgsParser)
    assert module_parser._task_attrs == module_parser2._task_attrs


# Generated at 2022-06-23 04:51:42.597010
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_ds = {"action": "ping"}
    obj = ModuleArgsParser(task_ds=test_ds)
    assert obj._task_ds     == test_ds


# Generated at 2022-06-23 04:51:54.402244
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    args = dict(
        module='copy',
        src='a',
        dest='b'
    )

    task_ds = dict(
        module='copy',
        args=args
    )

    p = ModuleArgsParser(task_ds)
    assert p._task_ds == task_ds

# Generated at 2022-06-23 04:51:56.422006
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    map = ModuleArgsParser(task_ds)
    assert map



# Generated at 2022-06-23 04:52:03.376567
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser_parser = ModuleArgsParser();
    task_ds = {'name': 'register /etc/motd in ansible', 'action': 'template src=/opt/motd dest=/etc/motd'}
    assert module_arg_parser_parser.parse('', task_ds=task_ds) == ('template', {'src': '/opt/motd', 'dest': '/etc/motd', 'name': 'register /etc/motd in ansible'}, None)

# Generated at 2022-06-23 04:52:04.363149
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True



# Generated at 2022-06-23 04:52:17.033607
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Given a task in one of the supported forms, parses and returns
    # returns the action, arguments, and delegate_to values for the
    # task, dealing with all sorts of levels of fuzziness.

    # the constructor of class ModuleArgsParser returns:
    #   _task_ds (Task dictionary)
    #   _collection_list (nothing - not used in parsing)
    #   _task_attrs (Task and Handler attributes)
    #   resolved_action (nothing - not used in parsing)
    # the return the action, arguments, and delegate_to values for the
    # task
    assert issubclass(ModuleArgsParser, object)

# Generated at 2022-06-23 04:52:28.605660
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Miscellaneous function to test the ModuleArgsParser class with a few sample inputs
    """

    # arguments can be fuzzy.  Deal with all the forms.

# Generated at 2022-06-23 04:52:33.152580
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds= {'action': 'copy src=a dest=b'}
    obj = ModuleArgsParser(task_ds=task_ds)
    ret = obj.parse()

    assert ret == ('copy', {u'src': u'a', u'dest': u'b'}, None)
    assert obj.resolved_action is None


# Generated at 2022-06-23 04:52:41.582043
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
       "postgresql_db": {
          "name": "mydb",
          "login_user": "postgres",
          "login_password": "",
          "login_host": "127.0.0.1",
          "login_unix_socket": "/var/run/postgresql",
          "encoding": "UTF8",
          "template": "template0",
          "state": "present"
       }
    }
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result[0] == 'postgresql_db'

# Generated at 2022-06-23 04:52:51.441916
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'local_action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', ('src', 'a'), ('dest', 'b'), 'localhost')
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', ('src', 'a'), ('dest', 'b'), None)
    task_ds = {'action': {'module': 'copy src=a dest=b'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', ('src', 'a'), ('dest', 'b'), None)

# Generated at 2022-06-23 04:52:55.843156
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args = dict()
    args['task_ds'] = {'action': ''}
    args['collection_list'] = None
    module_arg_parser = ModuleArgsParser(task_ds=args['task_ds'], collection_list=args['collection_list'])
    assert module_arg_parser is not None



# Generated at 2022-06-23 04:53:06.299768
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={})
    assert parser.parse(skip_action_validation=False) == ('', {}, None)
    # action: ec2 key_name=xyz other_param=abc
    task_ds = {'action': 'ec2 key_name=xyz other_param=abc'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse(skip_action_validation=False) == ('ec2', {'key_name': 'xyz', 'other_param': 'abc'}, None)
    # action: copy src=a dest=b
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-23 04:53:14.544481
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_task_ds = {'action': {'_variable_params': '{{ list_server }}', 'name': '{{ name }}'}, 'delegate_to': '{{ delegate }}', 'loop': '{{ list_server }}', 'when': '{{ server.external_ip != local_ip }}'}
    test_collection_list = ['ansible.builtin']
    module_args_parser = ModuleArgsParser(task_ds=test_task_ds, collection_list=test_collection_list)
    res = module_args_parser.parse()
    assert res[0] == '_variable_params'
    assert '_variable_params' in res[1]
    assert 'loop' in res[1]
    assert res[2] == '{{ delegate }}'

# Generated at 2022-06-23 04:53:23.421899
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  test_ansible_module_args_file_path = os.path.dirname(os.path.abspath(__file__)) + '/test-data/action/module_utils_shell.py'
  shutil.copy(os.path.dirname(os.path.abspath(__file__)) + '/../ansible/module_utils/shell.py',
              test_ansible_module_args_file_path)
  test_yaml_file_path = os.path.dirname(os.path.abspath(__file__)) + '/test-data/action/test.yml'
  shutil.copy(os.path.dirname(os.path.abspath(__file__)) + '/../playbooks/play_template.yml',
              test_yaml_file_path)
 

# Generated at 2022-06-23 04:53:28.379677
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    TASK_DS = dict()
    COLLECTION_LIST = ['ansible.builtin.copy', 'ansible.builtin.paramiko_ssh']
    TASK = ModuleArgsParser(task_ds=TASK_DS, collection_list=COLLECTION_LIST)
    assert TASK.parse()[0] is None
test_ModuleArgsParser_parse()



# Generated at 2022-06-23 04:53:40.414744
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    assert ModuleArgsParser().parse({'action': 'action1', 'local_action': 'local_action1', 'ignore_errors': 'yes', 'shell': 'ls', 'when': 'test1'}) == ('shell', {'ignore_errors': 'yes', '_raw_params': 'ls'}, 'localhost')
    assert ModuleArgsParser().parse({'action': 'action1', 'local_action': 'local_action1', 'ignore_errors': 'yes', 'shell': 'ls', 'when': 'test1', 'ignore_errors': 'yes'}, True) == ('shell', {'ignore_errors': 'yes', '_raw_params': 'ls'}, 'localhost')

# Generated at 2022-06-23 04:53:45.081971
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser_ = None
    try:
        parser_ = ModuleArgsParser(task_ds=None)
    except AnsibleAssertionError as e:
        assert e.args[0] == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"
    else:
        raise AssertionError('AnsibleAssertionError not raised. should raise')


# Generated at 2022-06-23 04:53:55.126788
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    class YAMLDataset(AnsibleBaseYAMLObject):

        def __init__(self, data):
            self.data = data

    loader = AnsibleLoader({},
                           variable_manager=None,
                           loader=None,
                           md5sum_hash=None
                           )

    # case1: takes a dict as task_ds

# Generated at 2022-06-23 04:53:57.084100
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None


# Generated at 2022-06-23 04:54:02.659992
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    for test_number in range(1, 8):
        print("{0}".format(test_number))
        filename = "./test/units/parsing/constructor_test_{}.yml".format(test_number)
        task_ds = yaml.safe_load(open(filename))
        module_args_parser = ModuleArgsParser({}, collection_list=None)
        module_args_parser.parse()

# Generated at 2022-06-23 04:54:15.224488
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:54:24.875234
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    # test without task_ds
    parser = ModuleArgsParser({})
    assert isinstance(parser._task_ds, dict)
    assert parser._task_ds == {}

    task_ds = {
        'shell': "echo hi",
        'copy': {
            'src': 'a',
            'dest': 'b'
        },
        'unreachable': {
            'action': '{{reach}}'
        }
    }
    # test with task_ds
    parser = ModuleArgsParser(task_ds)
    assert isinstance(parser._task_ds, dict)
    assert parser._task_ds == task_ds

    # Test that various values for 'task_ds' raise an AnsibleAssertionError

# Generated at 2022-06-23 04:54:30.919308
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:54:42.878458
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:54:50.917694
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test check_raw
    if ModuleArgsParser._normalize_new_style_args({'shell': 'echo hi'}, 'shell') != {'_raw_params': 'echo hi', '_uses_shell': True}:
        raise AssertionError("Error, mangled output of args")

    if ModuleArgsParser._normalize_new_style_args({'shell': {'cmd': 'echo hi'}}, 'shell') != {'cmd': 'echo hi', '_uses_shell': True}:
        raise AssertionError("Error, mangled output of args")


# Generated at 2022-06-23 04:54:52.408493
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    result = ModuleArgsParser()
    assert result.resolved_action == None

# Unit tests for method parse() of class ModuleArgsParser

# Generated at 2022-06-23 04:55:01.885164
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    # Test with action and args with shell echo hi
    task_ds['action'] = 'shell echo hi'
    task_ds['args'] = '''
    hosts
    - shell echo hi
    '''
    retriever = ModuleArgsParser(task_ds = task_ds)
    assert retriever.resolved_action == None
    assert retriever._task_ds == task_ds
    assert retriever.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    assert retriever.resolved_action != None
    # Test with local_action, action and args with shell echo hi
    task_ds['action'] = 'shell echo hi'
    task_ds['local_action'] = 'shell echo hi'

# Generated at 2022-06-23 04:55:10.320360
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import TaskBlock
    task = Task()
    task_ds = {'action': 'shell echo hi'}
    task.from_dict(task_ds)
    task1 = Task()
    task_ds1 = {'local_action': 'shell echo hi'}
    task1.from_dict(task_ds1)
    handler = Handler()
    handler.from_dict(task_ds)
    task_block = TaskBlock()
    task_block.from_dict(task_ds)
    task_include = TaskInclude()

# Generated at 2022-06-23 04:55:22.587052
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test with empty dictionary
    try:
        mp = ModuleArgsParser()
        assert False
    except AnsibleAssertionError:
        pass

    # test with dict containing 'action': {'module': 'echo hi'}
    try:
        mp = ModuleArgsParser({'action': {'module': 'echo hi'}})
        assert False
    except AnsibleAssertionError:
        pass

    # test with dict containing 'action': 'copy src=a dest=b'
    try:
        mp = ModuleArgsParser({'action': 'copy src=a dest=b'})
        assert False
    except AnsibleAssertionError:
        pass

    # test with dict containing 'action': 'copy src=a dest=b' and collection

# Generated at 2022-06-23 04:55:28.117430
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # single line parameters string
    module_name = 'copy'
    args_string = 'src=test.txt dest=test.txt.copied'
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse(skip_action_validation=True)
    assert action == module_name
    assert args == args


# Generated at 2022-06-23 04:55:38.626103
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()
    m = ModuleArgsParser(task_ds={"module": "copy", "xyz": "zyx", "args": {"src": "a.txt"}}, collection_list=collection_loader.all())
    assert m.parse() == ("copy", {"src": "a.txt"}, None)
    m = ModuleArgsParser(task_ds={"module": "copy src=a.txt", "xyz": "zyx", "args": {"src": "a.txt"}}, collection_list=collection_loader.all())
    assert m.parse() == ("copy", {"src": "a.txt"}, None)

# Generated at 2022-06-23 04:55:41.237263
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'args': {'x': 1}, 'module': 'ec2'})
    assert parser.parse() == ('ec2', {'x': 1}, None)

# Generated at 2022-06-23 04:55:53.003896
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(task_ds={'action': 'ec2', 'region': 'us-east-1'},
                         collection_list=None)
    assert m._task_ds == {'action': 'ec2', 'region': 'us-east-1'}
    assert m._collection_list is None
    assert m._task_attrs == frozenset(['loop', 'poll', 'until', 'retries', 'delay',
        'async_status', 'async_jid', 'run_once', 'ignore_errors', 'first_available_file',
        'local_action', 'static', 'when', 'become', 'become_user', 'become_method', 'tags',
        'register', 'ignore_unreachable', 'name'])
    assert m.resolved_action is None

#

# Generated at 2022-06-23 04:56:03.203255
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    def make_resolver(args):
        return ModuleArgsParser(args).parse()

    # Empty args should return error
    assert_raises(AnsibleParserError, make_resolver, dict())

    # Basic valid args
    assert_equal(make_resolver(dict(action='pwd')), ('pwd', dict(), None))
    assert_equal(make_resolver(dict(action='pwd', args=dict(chdir='/tmp'))), ('pwd', dict(chdir='/tmp'), None))
    assert_equal(make_resolver(dict(action='pwd', args="chdir='/tmp'")), ('pwd', dict(chdir='/tmp'), None))

# Generated at 2022-06-23 04:56:13.488575
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # case
    task_ds = {}
    collection_list = ['collections/ansible_collections/acme/my_collection']
    module_parser = ModuleArgsParser(task_ds)
    assert isinstance(module_parser, ModuleArgsParser)

    # case
    task_ds = 'test_string'
    collection_list = ['collections/ansible_collections/acme/my_collection']
    try:
        from ansible.playbook.task import Task
        from ansible.playbook.handler import Handler
        module_parser = ModuleArgsParser(task_ds, collection_list)
        assert isinstance(module_parser, ModuleArgsParser)
    except AnsibleAssertionError as e:
        assert isinstance(e, AnsibleAssertionError)


# Generated at 2022-06-23 04:56:23.449554
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_data_dir/parse.yml data
    test_data = load_fixture('parse.yml')
    # execute the test steps in parse.yml
    for step in test_data:
        with Context(step):
            # template method
            if step.get('when'):
                continue

            # skip this test for now
            if step.get('tags'):
                if 'meta' in step.get('tags'):
                    continue
            if step.get('skip'):
                continue

            # init setup
            skip_action_validation = False
            task_ds = step.get('task_ds')
            collection_list = step.get('collection_list')
            mod_args = ModuleArgsParser(task_ds, collection_list)

            # step setup

# Generated at 2022-06-23 04:56:35.615007
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up mock objects
    class Sentinel:
        pass
    mock_task_ds = {
        'action': 'copy',
        'args': 'arg1'
    }
    mock_collection_list = ['my_collection']
    module_args_parser = ModuleArgsParser(mock_task_ds, mock_collection_list)
    module_args_parser.resolved_action = 'my_collection.my_collection'
    expected_action = 'copy'
    expected_args = {
        '_raw_params': 'arg1',
        '_uses_shell': True
    }
    expected_delegate_to = None
    assert expected_action == module_args_parser.parse()[0]
    assert expected_args == module_args_parser.parse()[1]

# Generated at 2022-06-23 04:56:43.604947
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(task_ds={'a': 'b'}, collection_list=['col1'])
    assert isinstance(m, ModuleArgsParser)
    assert m._task_ds == {'a': 'b'}
    assert m._collection_list == ['col1']
    assert m._task_attrs == frozenset(['static', 'local_action', 'free_form', 'delegate_to', 'no_log', 'register', 'until', 'notify', 'async', 'poll'])
    assert m.resolved_action is None


# Generated at 2022-06-23 04:56:46.613313
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser(task_ds={'module': 'shell', 'args': 'echo hi'},
                                     collection_list=None)
    module_parser.parse()


# Generated at 2022-06-23 04:56:54.400468
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    fake_task_ds = {
        'action': 'some text',
        'local_action': 'test text',
        'test_module': {
            'test_arg1': 'test_arg1_text'
        },
        'another_test_module': 'test_arg2_text',
        'args': {
            'test_arg3': 'test_arg3_text'
        },
        'delegate_to': 'localhost'
    }

    parser = ModuleArgsParser(task_ds=fake_task_ds, collection_list=None)

    # assert that ModuleArgsParser raises a TypeError when 'task_ds' is not of type dict

# Generated at 2022-06-23 04:56:59.887142
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        action='copy',
        src='/etc/hosts', dest='/etc/ansible/hosts'
    )
    task_mgr = ModuleArgsParser(task_ds=task_ds)
    assert task_mgr is not None


# Generated at 2022-06-23 04:57:07.673235
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Should not throw exceptions
    module_arg = {'action': 'awesome.module'}
    action_loader = ActionModuleLoader()
    parser = ModuleArgsParser(module_arg, [])
    assert parser.resolved_action is None

    # Should not throw exceptions
    module_arg = {'action': 'awesome.module', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(module_arg, [])
    assert parser.resolved_action is None

# Unit tests for method parse in class ModuleArgsParser

# Generated at 2022-06-23 04:57:12.617656
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = dict()
    fake_collection_list = list()
    _module_args_parser = ModuleArgsParser(fake_task_ds, fake_collection_list)

    assert(_module_args_parser.parse() == (None, {}, 'localhost'))
    return True



# Generated at 2022-06-23 04:57:23.622697
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    # test when thing is string
    action, args, delegate_to = parser.parse()
    assert isinstance(action, type(None))
    assert delegate_to is None
    assert isinstance(args, dict)
    assert args == {}

    # test when thing is dict
    parser = ModuleArgsParser(task_ds, collection_list=None)
    action, args, delegate_to = parser.parse()
    assert isinstance(action, type(None))
    assert delegate_to is None
    assert isinstance(args, dict)
    assert args == {}

# Generated at 2022-06-23 04:57:35.246805
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n===== test_ModuleArgsParser_parse =====")
    # Setup
    module_string = ''
    task_ds = {
        'when': '1',
        'args': {
            'direct_arg': 'test'
        },
        'action': 'echo {{ item }}',
        'with_items': [
            'one',
            'two',
            'three'
        ]
    }
    module_args = {
        'direct_arg': 'test'
    }
    action = 'echo {{ item }}'

    # Exercise
    parser = ModuleArgsParser(task_ds)
    parser.parse(skip_action_validation=True)
    actual_module_args, actual_action = parser.parse(skip_action_validation=True)

    # Verify

# Generated at 2022-06-23 04:57:39.661499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()
    # Test the parse method of a ModuleArgsParser object
    assert_equal(module_args_parser.parse(), (None, dict(), None))
    assert_equal(module_args_parser.parse(skip_action_validation=True), (None, dict(), None))

# Generated at 2022-06-23 04:57:50.774607
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'xyz'}
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser._task_attrs == frozenset(['action', 'handler', 'local_action', 'static',
                                            'async_val', 'async_poll_interval', 'become', 'become_user', 'become_method',
                                            'become_flags', 'become_exe', 'become_info', 'delegate_to', 'listen', 'tags',
                                            'register', 'run_once', 'ignore_errors', 'until', 'retries', 'delay', 'environment',
                                            'run_once_with_watch'])

# Generated at 2022-06-23 04:58:00.008948
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # noinspection PyUnresolvedReferences
    module_parser = ModuleArgsParser(task_ds=dict())
    assert module_parser._task_ds == dict()
    assert module_parser._collection_list is None
    assert module_parser._task_attrs == frozenset(['action', 'local_action', 'ignore_errors', 'always_run', 'async_val', 'poll',
                                                   'register', 'ignore_unknown_errors', 'notify', 'first_available_file', 'until',
                                                   'retries', 'delay', 'delegate_to', 'run_once', 'become', 'become_user',
                                                   'become_method', 'environment',
                                                   'static', 'tags', 'vars', 'when'])

    # noinspection PyUnresolvedReferences
    module

# Generated at 2022-06-23 04:58:13.292308
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # arguments are sent as string, int (standard)
    assert isinstance(ModuleArgsParser(task_ds={'action':'command pwd'}).parse(), tuple)
    # No module name in input task
    assert isinstance(ModuleArgsParser(task_ds={}).parse(), tuple)
    # arguments are sent as dict (compact yml)
    assert isinstance(ModuleArgsParser(task_ds={'action':{'command':'pwd'}}).parse(), tuple)
    # arguments are sent as dict (complex)
    assert isinstance(ModuleArgsParser(task_ds={'action':{'module':'command pwd'}}).parse(), tuple)
    # arguments are sent as dict (complex)
    assert isinstance(ModuleArgsParser(task_ds={'action':{'command':'pwd'}}).parse(), tuple)

# Generated at 2022-06-23 04:58:14.186534
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True

# Generated at 2022-06-23 04:58:24.212097
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.plugins import module_loader
    from ansible.playbook.task_include import TaskInclude

    def assert_is_parser_exception(e):
        assert isinstance(e, AnsibleParserError)
        assert e.obj is not None
        assert isinstance(e.obj, TaskInclude)

    parser = ModuleArgsParser(task_ds={}, collection_list=())

    # Test that the constructor fails on invalid input
    invalid_types = [
        None,
        [],
        '',
        1,
        1.0
    ]
    for t in invalid_types:
        try:
            parser = ModuleArgsParser(t, collection_list=())
            assert False
        except AnsibleAssertionError as e:
            pass


# Generated at 2022-06-23 04:58:31.516348
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test constructor with task ds None
    with pytest.raises(AssertionError):
        ModuleArgsParser(task_ds=None, collection_list=None)

    # Test constructor with task ds not a dict
    with pytest.raises(AssertionError):
        ModuleArgsParser(task_ds='', collection_list=None)

    # Test constructor with task ds is a dict
    ModuleArgsParser(task_ds={'module': 'test', 'action': 'test'}, collection_list=None)

# Generated at 2022-06-23 04:58:39.371590
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    for test in ModuleArgsParserTestCases:
        module_args_parser = ModuleArgsParser(test.task_ds, None)
        (action, args, delegate_to) = module_args_parser.parse()
        print (action)
        print (args)
        print (delegate_to)
        assert action == test.expected_action
        assert args == test.expected_args
        assert delegate_to == test.expected_delegate_to

# Generated at 2022-06-23 04:58:49.724689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('::: TEST: test_ModuleArgsParser_parse()')
    module_name = 'setup'
    hostname = '127.0.0.1'
    hostvars = {'my-host': {}}
    fake_loader = DictDataLoader({
        '/etc/ansible/ansible.cfg': '',
        '/path/to/my/file': 'the config file contents go here',
    })
    variable_manager = VariableManager(loader=fake_loader, inventory=Inventory(host_list=[]))
    variable_manager.extra_vars = {
        'hostvars': hostvars
    }
    play_context = PlayContext()
    # play_context.remote_addr = hostname  # 127.0.0.1
    # play_context.remote_user = 'bob'


# Generated at 2022-06-23 04:58:56.585731
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'ping'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser._task_ds == {'action': 'ping'}
    assert module_args_parser.resolved_action == 'ping'
    assert module_args_parser._task_attrs == ('action',)

# Generated at 2022-06-23 04:59:07.386014
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Variables used in test
    args = {
        'a': 'b'
    }
    additional_args = {
        'c': 'd'
    }
    action = 'action'

    # Init
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

    # Test function
    # Action: action, Args: args, delegate_to: localhost
    assert parser._normalize_parameters(args, action) == ('action', {'a': 'b'})
    # Action: action, Args: args, additional_args, delegate_to: localhost
    assert parser._normalize_parameters(args, action, additional_args) == ('action', {'a': 'b', 'c': 'd'})
    # Action: action, Ar

# Generated at 2022-06-23 04:59:13.082484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action = 'ec2'
    args = {'region': 'xyz', 'profile': 'xyz'}
    delegate_to = 'localhost'
    task_ds = {'module': 'ec2 region=xyz profile=xyz'}
    assert module_args_parser.parse(task_ds) == (action, args, 'localhost')

# Generated at 2022-06-23 04:59:14.535023
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert isinstance(ModuleArgsParser(), ModuleArgsParser)

# Generated at 2022-06-23 04:59:25.050836
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude

    test_data = dict(
        action=dict(
            module='shell',
            args='rm -rf /tmp/test',
        ),
        local_action=dict(
            module='shell',
            args='rm -rf /tmp/test',
        ),
        action_on_invalid_module='shell',
        task_include=dict(
            include=dict(
                tasks='test_module_argparser_tasks.yml',
            ),
        ),
    )

    assert ModuleArgsParser(test_data['action']).parse() == ('shell', {'_raw_params': 'rm -rf /tmp/test'}, Sentinel)

# Generated at 2022-06-23 04:59:38.284624
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    include_ds = TaskInclude.load({
        "action": {
            "include": "greeting.yml"
        },
        "name": "include greeting",
        "tags": ['test'],
        "when": "false"
    })


# Generated at 2022-06-23 04:59:47.057777
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test '_normalize_new_style_args'
    task_ds = {'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args = parser._normalize_new_style_args(task_ds, 'shell')
    assert action == 'shell'
    assert args is None

    task_ds = {'module': 'shell', '_raw_params': 'echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args = parser._normalize_new_style_args(task_ds, 'shell')
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}

    task_ds = {'module': 'copy src=a dest=b'}
    parser = ModuleArgs

# Generated at 2022-06-23 04:59:49.806935
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser_object = ModuleArgsParser()
    assert module_args_parser_object is not None



# Generated at 2022-06-23 04:59:51.781786
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert(False)


# Generated at 2022-06-23 04:59:57.093163
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(args)
    # The following two test case to confirm that the instance
    # of class ModuleArgsParser has correct attributes and
    # methods after __init__()
    assert module_args_parser._task_ds
    assert module_args_parser.parse

# Generated at 2022-06-23 05:00:05.984940
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class TestModuleArgsParser(unittest.TestCase):

        # test case for constructor of class ModuleArgsParser
        def test_ModuleArgsParser(self):
            ds = dict(action='shell', args='echo hi')
            parser = ModuleArgsParser(task_ds=ds)
            self.assertTrue(parser)

    # create a test suite
    suite = unittest.TestSuite()
    suite.addTest(TestModuleArgsParser("test_ModuleArgsParser"))

    # run the test suite
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.errors or result.failures:
        sys.exit(1)


# Generated at 2022-06-23 05:00:15.109062
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 05:00:27.018874
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # Unit test with the following:
    # ```
    # yaml_ds = {
    #     'action': 'copy src=a dest=b',
    #     'delegate_to': 'localhost',
    # }
    # ```
    # should return a `ModuleArgsParser` object with:
    # ```
    # self._task_ds = yaml_ds
    # self.resolved_action = None
    # self._task_attrs = {'static', 'action', 'local_action'}
    # self._collection_list = None
    # ```
    module_args_parser.parse()
    assert module_args_parser.resolved_action is None

    # Unit test with the following:
    # ```
    # yaml_ds