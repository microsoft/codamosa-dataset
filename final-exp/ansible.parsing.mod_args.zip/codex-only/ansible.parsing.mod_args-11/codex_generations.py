

# Generated at 2022-06-23 04:50:27.015542
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:50:37.945384
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.handler_task_include import HandlerTaskInclude
  from ansible.playbook.role.include import RoleInclude

  task_ds1 = {
    'module':
    'ping',
    'args':
    'abc'
  }

  task_ds2 = {
    'module':
    'ping',
    'args':
    'abc',
    'action':
    'ping'
  }

  task_ds3 = {
    'module':
    'ping',
    'args':
    'abc',
    'action':
    'ping',
    'delegate_to':
    'local',
    'args':
    'abc'
  }


# Generated at 2022-06-23 04:50:46.371477
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={})
    assert isinstance(parser, ModuleArgsParser)
    assert parser._task_attrs == frozenset(Task._valid_attrs.keys())

    try:
        parser = ModuleArgsParser(task_ds="example")
        raise AssertionError('Allowed invalid task_ds')
    except AnsibleAssertionError:
        pass


# Generated at 2022-06-23 04:50:58.041305
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # create an instance of the class we are testing
    module_args_parser = ModuleArgsParser()

    # the arguments that would normally be provided by the ansible cmd line
    arguments = dict(
        connection='local',
        module_path=['/to/mymodules'],
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
    )

    # the ansible parser.  This is not normally done as a test,
    # but is handy for tests
    parser = CommandLineParser(args=arguments)
    # parse the command line args
    # args = parser.parse_args()
    # print

# Generated at 2022-06-23 04:51:06.948980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing the case:
    # Input:
    #   _task_ds = collections.OrderedDict(
    #    [('action', 'copy src=a dest=b'), ('delegate_to', Sentinel)])
    # Expected output:
    #   ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    module_args_parser = ModuleArgsParser()
    _task_ds = collections.OrderedDict(
        [('action', 'copy src=a dest=b'), ('delegate_to', Sentinel)])
    expected_output = ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    assert expected_output == module_args_parser.parse(_task_ds)

    # Testing the case:
    # Input:
    #   _task_ds = collections

# Generated at 2022-06-23 04:51:14.974525
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:26.727616
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = dict(action=dict(shell="echo hello"))
    p = ModuleArgsParser(task_ds=t)
    m, a, d = p.parse()
    assert m == 'shell'
    assert a == dict(echo="hello")
    assert d is None

    t = dict(action=dict(test_module=True))
    p = ModuleArgsParser(task_ds=t)
    m, a, d = p.parse()
    assert m == 'test_module'
    assert a is True
    assert d is None

    t = dict(action=dict(test_module=dict(arg1=1, arg2=2)))
    p = ModuleArgsParser(task_ds=t)
    m, a, d = p.parse()
    assert m == 'test_module'

# Generated at 2022-06-23 04:51:27.901441
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args_parser = ModuleArgsParser(task_ds=None)



# Generated at 2022-06-23 04:51:38.114240
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Empty dictionary should raise error
    # test just module since it branches out to other classes
    module = "Testing ModuleArgsParser"
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert parser._task_attrs == frozenset(['delegate_to', 'notify', 'loop', 'changed_when', 'run_once', 'local_action', 'args',
                                            'register', 'tags', 'ignore_errors', 'until', 'static', 'retries', 'failed_when',
                                            'delay'])
    assert parser.resolved_action is None
    # Test for strings
    task_ds = ''
    with pytest.raises(AnsibleAssertionError) as excinfo:
        Module

# Generated at 2022-06-23 04:51:50.925072
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    This test will go through all the possible permutations of
    argument usage for a module and make sure it parses into
    the expected result
    """


# Generated at 2022-06-23 04:52:01.795504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    assert issubclass(Mapping, collections.Mapping)


    # date: 2020/06/16
    def get_mock_data(path):
        mock_data_path = os.path.join(os.path.dirname(__file__), 'mock_data', path)
        mock_data = None

        with open(mock_data_path, 'r') as f:
            mock_data = f.read()

        if not mock_data: # if file is empty
            mock_data = ''

        return mock_data



# Generated at 2022-06-23 04:52:09.234251
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Requires a single file as input.  If multiple files are passed, assume the last
    # file is the one we want
    parser = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'_raw_params': 'echo hi', '_uses_shell': True, 'chdir': None, 'creates': None, 'executable': None}, 'delegate_to': None})
    ret = parser.parse()
    assert 'action' == ret[0]


# Generated at 2022-06-23 04:52:21.571853
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:30.954700
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:52:43.329374
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    import ansible.plugins.loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    # test args
    task_ds = {
        'action': 'copy',
        'local_action': 'shell echo hi',
        'monkey': 'validation',
        'args': 'src=a dest=b',
        'delegate_to': 'localhost'
    }
    collection_list = None

    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse(skip_action_validation=False)
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'


# Generated at 2022-06-23 04:52:45.708097
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    taskDict = {"action": "shell echo hi"}
    assert ModuleArgsParser(taskDict).parse()[0] == "shell"


# Generated at 2022-06-23 04:52:49.340959
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = 'copy src=a dest=b'
    action, args, delegate_to = ModuleArgsParser().parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None


# Generated at 2022-06-23 04:53:02.992353
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:53:15.189395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # We need to mock a couple things
    class MockInventory():
        def __init__(self):
            pass
    class MockTask():
        def __init__(self):
            self.name = "MockTask"
            self.item = {}
            self.loop = []
            self.pagination = [False]
            self.when = None
            self.any_errors_fatal = False
            self.tags = []
            self.register = []
            self.ignore_errors = False
            self.notify = []
            self.delegate_to = None
            self.error_on_undefined_vars = True
            self.failed_when_result = []
            self.always_run = False
            self.run_once = False
            self.check_mode = False
            self.auto_remove

# Generated at 2022-06-23 04:53:26.182014
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    default_vars = VariableManager(loader=DataLoader()).get_vars({}, play=Play().load(cur_dir + "/../../../test/units/data/test_play.yml", variable_manager=VariableManager(), loader=DataLoader()))
    default_vars['ansible_user'] = 'root'
    default_vars['ansible_password'] = 'password'

    parser = ModuleArgsParser(None, collection_list=None)
    parser.resolved_action = None

    parser._task_ds = {}
    assert parser._normalize_parameters(None) == (None, dict())
    assert parser.resolved_action is None

    parser._task_ds = {}
    assert parser._normalize

# Generated at 2022-06-23 04:53:28.964953
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


#
# Text file reader for shell blockinfile tasks
#


# Generated at 2022-06-23 04:53:40.462320
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:53:48.498312
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'name': 'test_module_args_parser',
        'action': 'test_module action=action-value a=a-value b=b-value c=c-value',
        'delegate_to': 'localhost',
        'when': '1'
    }
    collection_list = None

    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'test_module'
    assert args == {'action': 'action-value', 'a': 'a-value', 'b': 'b-value', 'c': 'c-value'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-23 04:53:58.183184
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no given "args", expect an error
    task_ds = {}
    map = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        map.parse()

    # Test with an invalid task_ds, expect an error
    task_ds = "test"
    map = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleAssertionError):
        map.parse()

    # Test with given "action", expect a tuple of (action, args, delegate_to)
    task_ds = {'action': 'test'}
    map = ModuleArgsParser(task_ds)
    expected = ('test',
                {},
                Sentinel)
    result = map.parse()
    assert result == expected

    # Test with given "local_action", expect

# Generated at 2022-06-23 04:54:00.207789
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser({})
    assert module_args_parser

# Generated at 2022-06-23 04:54:04.374105
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mp = ModuleArgsParser()
    # test that constructor set the attributes
    assert (mp._task_ds == {}), "constructor for ModuleArgsParser failed to set task_ds"
    assert (mp._task_attrs == frozenset(['action', 'local_action', 'static', 'args'])), \
        "constructor for ModuleArgsParser failed to set task_attrs"


# Generated at 2022-06-23 04:54:13.213660
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    t = Task()
    t.action = 'setup'
    t.name = None
    t.delegate_to = None
    t.delegate_facts = None
    t.async_val = None
    t.poll = None
    t.tags = ['all']
    t._context = dict()
    m = ModuleArgsParser(t._attributes)
    assert m.parse() == ('setup', {}, None)

# Generated at 2022-06-23 04:54:25.693083
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Arrange
    task_ds = {'delegate_to': 'localhost'}
    collection_list = ['ansible.builtin']
    # Act
    module_args_parser = ModuleArgsParser(task_ds=task_ds,
                                          collection_list=collection_list)
    # Assert
    assert isinstance(module_args_parser, ModuleArgsParser)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._collection_list == collection_list

# Generated at 2022-06-23 04:54:35.714897
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Given that I create a task_ds in a form of
    task_ds = {'action': 'shell echo hi'}

    # and that I create a collection_list
    collection_list = ''

    # When I create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    # and that I invoke the method parse()
    result = module_args_parser.parse()

    # Then the result should contain the expected
    expected = ('shell', {'_raw_params': 'echo hi'}, Sentinel)
    assert result == expected, "result=%s expected=%s" % (result, expected)



# Generated at 2022-06-23 04:54:47.200861
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    #
    # test 1: action: abc x=1
    #
    task = dict()
    task['action'] = 'abc x=1'
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds='')
    task_ds = task
    aap = ModuleArgsParser(task_ds=task_ds)
    assert(aap is not None)
    assert(aap._task_ds == task_ds)
    #
    # test 2: action: abc x=1
    #
    (action, args, delegate_to) = aap.parse()
    assert(action == 'abc')
    assert(args == {'x': '1'})
    assert(delegate_to is None)
    #
    # test 3: action: abc x

# Generated at 2022-06-23 04:54:55.097418
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hello world', 'delegate_to': 'remote'},
                                           collection_list=['collections/ansible_namespace/package/'])
    assert 'shell' == module_args_parser.parse()[0]
    assert 'remote' == module_args_parser.parse()[2]



# Generated at 2022-06-23 04:55:06.212341
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    a = ModuleArgsParser(task_ds=None, collection_list=None)
    assert a._task_ds == {}
    assert a._collection_list == None

# Generated at 2022-06-23 04:55:12.675386
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({u'delegate_to': u'localhost', u'raw': u'some arbitrary data to be sent to the raw module', u'action': u'raw'})
    module_args_parser._normalize_new_style_args = MagicMock()
    module_args_parser._normalize_parameters = MagicMock()
    module_args_parser.parse()
    # module_args_parser._normalize_parameters.assert_called_once_with()


# Generated at 2022-06-23 04:55:25.457917
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {
        'module': 'xyz',
        'x': 1,
        'y': 2,
    }
    results = ModuleArgsParser(ds).parse()[1]
    assert results == {'x': 1, 'y': 2}
    assert results is not ds

    ds = {
        'module': 'xyz x=1 y=2',
    }
    results = ModuleArgsParser(ds, collection_list=[]).parse()[1]
    assert results == {'x': 1, 'y': 2}

    ds = {
        'action': 'xyz',
        'x': 1,
        'y': 2,
    }
    results = ModuleArgsParser(ds).parse()[1]
    assert results == {'x': 1, 'y': 2}

# Generated at 2022-06-23 04:55:31.340381
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    task_ds = {'action': 'shell'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_ds == task_ds
    assert parser._task_attrs == set(Task._valid_attrs.keys())
    assert parser.resolved_action is None

# Constructor test for ModuleArgsParser

# Generated at 2022-06-23 04:55:33.279030
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # Test for ModuleArgsParser().parse()
    #
    pass

# Generated at 2022-06-23 04:55:42.361383
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:55:45.690746
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test code
    args_dict = {}
    collection_list = []
    parser = ModuleArgsParser(args_dict, collection_list)
    parser.parse()

# Generated at 2022-06-23 04:55:50.864519
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    result = ModuleArgsParser(task_ds=None).parse()
    assert result == (None, dict(), Sentinel)

    # Don't care about the default value
    task_ds = {'args': 'test'}
    result = ModuleArgsParser(task_ds=task_ds).parse()
    assert result == (None, dict(), Sentinel)

# Generated at 2022-06-23 04:56:01.227106
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser._collection_list is None
    assert module_args_parser._task_ds == {}
    assert module_args_parser._task_attrs == frozenset(['meta', 'name', 'tags', 'args', 'when', 'when_block', 'become', 'become_user',
                                                        'become_flags', 'become_method', 'become_ask_pass', 'block', 'block_sticky',
                                                        'block_errored', 'block_failed', 'local_action', 'static'])

# Generated at 2022-06-23 04:56:05.105008
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'test action'})
    assert module_args_parser._task_ds == {'action': 'test action'}


# Generated at 2022-06-23 04:56:14.938299
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # These are static variables taken from an example playbook
    task_ds = dict(
        name='foo',
        action='shell echo hi'
    )
    parser = ModuleArgsParser(task_ds)
    assert parser._task_attrs == frozenset(['action', 'local_action', 'static', 'name'])
    assert isinstance(parser._task_ds, dict)
    assert parser.resolved_action is None

    # Test the _normalize_old_style_args() method with good data
    action, args = parser._normalize_old_style_args('shell echo hi')
    assert action == 'shell'
    assert args['_raw_params'] == 'echo hi'

    action, args = parser._normalize_old_style_args(dict(module='shell echo hi'))
    assert action == 'shell'

# Generated at 2022-06-23 04:56:24.449476
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.module_utils.six as six
    from ansible.errors import AnsibleParserError
    from ansible.utils.sentinel import Sentinel
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    def test_parser(task_ds, expected_action, expected_args=None, expected_delegate_to=None):
        expected_args = {} if expected_args is None else expected_args
        expected_delegate_

# Generated at 2022-06-23 04:56:36.702102
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor test 1
    # Input: task_ds=None
    # Expected Result: raise AnsibleAssertionError
    try:
        ModuleArgsParser(task_ds=None, collection_list=[])
        assert False
    except AnsibleAssertionError:
        assert True

    # Constructor test 2
    # Input: task_ds="test"
    # Expected Result: raise AnsibleAssertionError
    try:
        ModuleArgsParser(task_ds="test", collection_list=[])
        assert False
    except AnsibleAssertionError:
        assert True

    # Constructor test 3
    # Input: task_ds=""
    # Expected Result: raise AnsibleAssertionError

# Generated at 2022-06-23 04:56:47.340212
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    from ansible.parsing.task_parser import ModuleArgsParser
    mp = ModuleArgsParser(
        dict(action=dict(module='command', args=dict(chdir='/tmp')),
             delegate_to='localhost'
             ),
        collection_list=[
            '1'
        ]
    )
    action, args, delegate_to = mp.parse()
    assert action == "command"
    assert args == {'_raw_params': '', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'
    action, args, delegate_to = mp.parse()
    assert action == "command"
    assert args == {'_raw_params': '', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-23 04:56:55.764766
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    current_test = sys._getframe().f_code.co_name
    print(current_test)

# Generated at 2022-06-23 04:57:06.879921
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {'action':'key=value', 'delegate_to': 'localhost', 'args': {"_raw_params": "ls", 'cwd': '/root'}}
    _collection_list = None
    obj = ModuleArgsParser(task_ds, _collection_list)
    assert obj.parse() == ('key', {'value': True}, 'localhost')

    task_ds = {'action': {'module': 'shell', '_raw_params': 'ls', '_uses_shell': 'True'}}
    _collection_list = None
    obj = ModuleArgsParser(task_ds, _collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'ls', '_uses_shell': 'True'}, Sentinel)


# Generated at 2022-06-23 04:57:13.006337
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Testing that parsing task lines works:
    task_ds = dict(action="shell echo hi")
    assert isinstance(task_ds, dict)
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert isinstance(action, string_types)
    assert action == 'shell'
    assert isinstance(args, dict)
    assert args == dict(_raw_params='echo hi')
    assert delegate_to is None

# Generated at 2022-06-23 04:57:20.973420
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser1 = ModuleArgsParser(task_ds={'action': {'module': "ec2", 'region': "xyz"}})
    action, args = parser1.parse()
    assert action == 'ec2'
    assert args == {'region': 'xyz'}

    parser2 = ModuleArgsParser(task_ds={'action': 'ec2 region=xyz'})
    action, args = parser2.parse()
    assert action == 'ec2'
    assert args == {'region': 'xyz'}

    parser3 = ModuleArgsParser(task_ds={'action': {'module': 'shell', 'executable': '/bin/sh'}})
    action, args = parser3.parse()
    assert action == 'shell'
    assert args == {'executable': '/bin/sh'}


# Generated at 2022-06-23 04:57:30.779868
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action: module_name
    task = ansible.playbook.task.Task()
    task._ds = {'action': 'module_name'}
    module_args_parser = ModuleArgsParser(task)
    assert module_args_parser.parse() == ('module_name', {}, None)

    # Test with action: module_name arg1=val1 arg2=val2
    task._ds = {'action': 'module_name arg1=val1 arg2=val2'}
    module_args_parser = ModuleArgsParser(task)
    assert module_args_parser.parse() == ('module_name', {'arg1': 'val1', 'arg2': 'val2'}, None)

    # Test with action: module_name arg1=val1 arg2=

# Generated at 2022-06-23 04:57:35.360160
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds='task_ds', collection_list='collection_list')
    assert module_args_parser._task_ds == {}
    assert module_args_parser._collection_list == 'collection_list'
    assert module_args_parser._task_attrs == frozenset(['local_action', 'static',
                                                        'notify', 'register', 'ignore_errors',
                                                        'tags', 'until', 'async_val',
                                                        'async_seconds', 'poll', 'when'])
    assert module_args_parser.resolved_action is None

    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=list())

# Generated at 2022-06-23 04:57:39.043013
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Init
    task_ds=None
    collection_list = None

    # Arrange
    # Act
    module_args_parser = ModuleArgsParser(task_ds, collection_list).parse()

    # Assert
    assert module_args_parser == None

# Generated at 2022-06-23 04:57:51.003475
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Unit test for constructor of class ModuleArgsParser
    '''
    module_args_parser_dict = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    module_args_parser_list = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    module_args_parser_func = ModuleArgsParser(task_ds={'action': 'copy', 'args': {'dest': 'b', 'src': 'a'}})
    module_args_parser_module = ModuleArgsParser(task_ds={'action': 'copy', 'src': 'a', 'dest': 'b'})

# Generated at 2022-06-23 04:58:01.071329
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('\n==== test_ModuleArgsParser_parse ====\n')
    # Given a task in one of the supported forms, parses and returns
    # returns the action, arguments, and delegate_to values for the
    # task, dealing with all sorts of levels of fuzziness.
    task_ds = {"action": "copy", "args": {"_raw_params": "src=/etc/hosts", "dest": "/tmp/z", "backup": "yes",
                   "remote_src": True, "force": False}, "changed_when": False, "register": "dest", "when": "inventory_hostname=='127.0.0.1'"}
    obj = ModuleArgsParser(task_ds)
    action, args, delegate_to = obj.parse()
    print('action: {0}'.format(action))
    print

# Generated at 2022-06-23 04:58:10.204451
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Make sure ModuleArgsParser is able to handle all of our args forms.
    """
    # module: <stuff> is the more new-style invocation
    # This is the standard YAML form for command-type modules. We grab
    # the args and pass them in as additional arguments, which can/will
    # be overwritten via dict updates from the other arg sources below
    task_ds_1 = dict(action='shell', args=dict(chdir='/tmp'), module='echo hi', delegate_to='boo')
    x = ModuleArgsParser(task_ds=task_ds_1)
    (action, args, delegate_to) = x.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'hi', 'chdir': '/tmp'}

    # module: <stuff> is the

# Generated at 2022-06-23 04:58:20.764427
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    test_dicts = []

    #test 1:
    test_dicts.append(
        dict(
            insp_dict=dict(
                action=dict(
                    module='copy',
                    src='myfile',
                    dest='/tmp/myfile',
                    args=dict(content='Hello\n')
                )
            ),
            exp_action='copy',
            exp_args=dict(
                src='myfile',
                dest='/tmp/myfile',
                content='Hello\n'
            ),
            exp_delegate_to=None
        )
    )

    #test 2:

# Generated at 2022-06-23 04:58:21.953875
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True == True

    

# Generated at 2022-06-23 04:58:32.846860
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test the method parse of class ModuleArgsParser
    """
    # case 1
    task_ds = {
        'action': 'shell echo hi'
    }
    collection_list = []
    map = ModuleArgsParser(task_ds, collection_list)
    actual = map.parse()
    expected = ('shell', {'_raw_params': 'echo hi'}, None)

    assert actual == expected

    # case 2
    task_ds = {
        'local_action': 'echo hi'
    }
    collection_list = []
    map = ModuleArgsParser(task_ds, collection_list)
    actual = map.parse()
    expected = ('echo', {}, 'localhost')

    assert actual == expected

    # case 3

# Generated at 2022-06-23 04:58:34.031744
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()



# Generated at 2022-06-23 04:58:46.421537
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-23 04:58:51.184416
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    doc = "TODO"
    assert isinstance(doc, str)
    assert doc, 'doc is an empty string'
    # TODO: Implement this test, see https://github.com/ansible/ansible/pull/52605#discussion_r434520103

# Generated at 2022-06-23 04:59:00.468369
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Initialize ModuleArgsParser object
    parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'}, collection_list=None)

    # Initialize _task_ds attribute of ModuleArgsParser object
    assert parser._task_ds == {'action': 'shell echo hi'}

    # Initialize _collection_list attribute of ModuleArgsParser object
    assert parser._collection_list is None

    # Initialize _task_attrs attribute of ModuleArgsParser object
    assert set(parser._task_attrs) == set(Task._valid_attrs)

    # Initialize _task_attrs attribute of ModuleArgsParser object

# Generated at 2022-06-23 04:59:03.150883
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    v = ModuleArgsParser(None).parse()
    assert v == (None, {}, None)


# Generated at 2022-06-23 04:59:07.441252
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_test = {'module': 'shell', 'args': 'echo hi'}
    mod_args_parse = ModuleArgsParser(task_ds=task_test, collection_list=None)
    mod_args_parse.parse()

import unittest


# Generated at 2022-06-23 04:59:18.039696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleParserError) as exc_info:
        parser = ModuleArgsParser()
    assert str(exc_info.value) == "unexpected parameter type in action: <class 'NoneType'>"
    # NOTE: The test above seems to be buggy.  If we don't call
    #       ModuleArgsParser constructor with a dict value, the
    #       value of _task_ds is not None but {}.  So the above
    #       exception message should be
    #       "unexpected parameter type in action: <class 'dict'>"
    #       instead of "unexpected parameter type in action: <class 'NoneType'>".
    #       See comment in setUp of test_module.py for details.

    parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
   

# Generated at 2022-06-23 04:59:26.233687
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = {'ignore_errors': True, 'local_action': 'copy content="hi" dest="{{ dest }}"', 'delegate_to': 'localhost', 'name': 'this is a test'}
    # first use empty collection list
    collection_list = []
    module_arg_parser = ModuleArgsParser(task_ds=_task_ds, collection_list=collection_list)
    assert 'copy' == module_arg_parser.parse()[0]

    # second use collection list contains one cloud.aws
    collection_list = [CloudAwsCollection()]
    module_arg_parser = ModuleArgsParser(task_ds=_task_ds, collection_list=collection_list)
    assert 'cloud.aws.ec2' == module_arg_parser.parse()[0]

# Generated at 2022-06-23 04:59:31.282123
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.constants as C
    import ansible.module_utils.common.removed as removed


# Generated at 2022-06-23 04:59:36.242287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    map = ModuleArgsParser(task_ds)
    action, args, delegate_to = map.parse()
    assert action is None
    assert args is None
    assert delegate_to is None


# Generated at 2022-06-23 04:59:40.903092
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = {
        'action': 'copy',
        'src': '/tmp/a',
        'dest': '/tmp/b',
        'mode': '0644',
        'content': 'hello'
    }
    module_parser = ModuleArgsParser(data)
    assert module_parser._task_ds == data


# Generated at 2022-06-23 04:59:52.389911
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    # empty task
    ds = {}
    parser = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = parser.parse()
    assert parser.resolved_action is None
    assert not action
    assert not args
    assert not delegate_to
    # check action name/args
    task_ds = dict(action='test_action')
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'test_action'
    assert not args
    assert not delegate_to
    # check delegation
    task_ds = dict(action='test_action', delegate_to='localhost')
   

# Generated at 2022-06-23 05:00:03.049104
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Example of the old format:
    task_ds = dict(action='shell', args='echo "hello"')
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result == ('shell', dict(args='echo "hello"'), None)

    # Example of the new format:
    task_ds = dict(action=dict(module='shell', args='echo "hello"'))
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result == ('shell', dict(args='echo "hello"'), None)

    # Example of the new format with complex args:
    task_ds = dict(action=dict(module='shell', args=dict(arg1='echo "hello"', arg2=5)))
    parser = ModuleArgsParser(task_ds)
    result = parser

# Generated at 2022-06-23 05:00:06.816680
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser(task_ds='{"shell": "echo hi"}')
    result = mp.parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

# Class: TaskExecutor
# Description of this class
#

# Generated at 2022-06-23 05:00:09.390247
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    ds = ModuleArgsParser(task_ds)
    assert isinstance(ds, ModuleArgsParser)


# Generated at 2022-06-23 05:00:10.748033
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None

# Generated at 2022-06-23 05:00:20.164026
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import sys
    import json
    import unittest

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.plugins.action import ActionBase
    from ansible.parsing.splitter import parse_kv
    from ansible.plugins.constructing import get_platform_specific_plugin_loader
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    class TestModule(object):
        """
        fake test module
        """

# Generated at 2022-06-23 05:00:31.581926
# Unit test for method parse of class ModuleArgsParser