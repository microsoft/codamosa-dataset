

# Generated at 2022-06-23 04:50:30.661024
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    datastructure = {
        'module': 'test_module',
        'args': 'test_args',
        'delegate_to': 'test_delegate_to'
    }
    parser = ModuleArgsParser(datastructure)

    assert parser._task_attrs == frozenset(['local_action', 'static'])
    assert parser._task_ds == datastructure
    assert parser._collection_list is None
    assert parser.resolved_action is None



# Generated at 2022-06-23 04:50:39.386751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = dict(action=dict(module="module_name"))
    module_args_parser_instance = ModuleArgsParser(task_ds=mock_task_ds)
    assert module_args_parser_instance.parse() == ('module_name', {}, None)
    module_args_parser_instance = ModuleArgsParser(task_ds=dict(action='echo hi'))
    assert module_args_parser_instance.parse() == ('echo', {'_raw_params': 'hi'}, None)
    module_args_parser_instance = ModuleArgsParser(task_ds=dict(action='shell'))
    assert module_args_parser_instance.parse() == ('shell', {}, None)

# Generated at 2022-06-23 04:50:51.474006
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-23 04:51:04.094642
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()

    task_ds = {'action': 'copy src=a dest=b'}
    module_args_parser.parse(task_ds=task_ds)

    task_ds = {'action': {'module': 'echo "hello"'}}
    module_args_parser.parse(task_ds=task_ds)


# Generated at 2022-06-23 04:51:05.535232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing handling original parameter type?
    assert False



# Generated at 2022-06-23 04:51:12.537231
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # create instance of ModuleArgsParser
    parser = ModuleArgsParser(task_ds={
        'name': 'test task',
        'action': {
            'module': 'shell',
            'args': {
                'chdir': '/tmp',
                'creates': '/tmp/test_file'
            }
        }
    })
    # call method parse
    action, args, delegate_to = parser.parse()
    # assert that the value returned is what is expected
    assert action == 'shell'
    assert args == {
        'creates': '/tmp/test_file',
        'chdir': '/tmp'
    }
    assert delegate_to is None



# Generated at 2022-06-23 04:51:25.707874
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.compat.tests import unittest

    task_ds_list = []
    # TEST CASE 1: action: echo hello
    task_ds_list.append(dict(action="echo hello"))
    # TEST CASE 2: action: shell echo hello
    task_ds_list.append(dict(action="shell echo hello"))
    # TEST CASE 3: action: copy src=a dest=b
    task_ds_list.append(dict(action="copy src=a dest=b"))
    # TEST CASE 4: action:
    #   module: copy
    #   args:
    #     src: a
    #     dest: b
    task_ds

# Generated at 2022-06-23 04:51:38.636947
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.errors

    param = {"action": "command"}
    parser = ModuleArgsParser(param, collection_list=None)
    assert (parser.parse(skip_action_validation=False) == ("command", ImmutableDict(), Sentinel)) == True

    param = {"action": {"module": "command", "something": "command"}}
    parser = ModuleArgsParser(param, collection_list=None)
    assert (parser.parse(skip_action_validation=False) == ("command", {"something": "command"}, Sentinel)) == True

    param = {"action": {"module": "command", "something": "command"}, "delegate_to": "localhost"}
    parser = ModuleArgsParser(param, collection_list=None)

# Generated at 2022-06-23 04:51:41.585599
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(dict(a='b', module='ec2', b='c'))
    assert module_args_parser._task_ds == dict(a='b', module='ec2', b='c')


# Generated at 2022-06-23 04:51:50.368610
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'args': {'delegate_to':'localhost', 'headers': 'a,b,c'},
        'register': 'result'
    }
    map = ModuleArgsParser(task_ds=task_ds)
    expected = ('copy', {'src': 'a', 'dest': 'b', 'headers': 'a,b,c'}, 'localhost')
    actual = map.parse()
    assert actual == expected


# Generated at 2022-06-23 04:51:55.518078
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'pwd', 'chdir': '/tmp'}}
    args = ModuleArgsParser(task_ds).parse()
    assert actions._asdict(args) == {'action': 'shell', 'delegate_to': None, 'args': {'_raw_params': 'pwd', 'chdir': '/tmp'}}



# Generated at 2022-06-23 04:52:04.189542
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'local_action': {u'command': u'pwd'}, u'args': {u'chdir': u'/tmp'}}
    obj = ModuleArgsParser(task_ds)
    assert obj.parse() == (u'command', {u'chdir': u'/tmp'}, u'localhost')
    task_ds = {u'local_action': {u'module': u'command', u'args': u'pwd'}, u'args': {u'chdir': u'/tmp'}}
    obj = ModuleArgsParser(task_ds)
    assert obj.parse() == (u'command', {u'chdir': u'/tmp'}, u'localhost')

# Generated at 2022-06-23 04:52:16.962310
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ''' test_ModuleArgsParser_parse.py: Unit test for method parse of class ModuleArgsParser

    Test with the following inputs:

        # 1 - Use a case study file as input with no additional dictionary
        # 2 - Use a case study file as input with empty additional dictionary
        # 3 - Use a case study file as input with additional dictionary containing key/value pairs
        # 4 - Use a case study file as input with additional dictionary containing key/value pairs. key = module
        # 5 - Use a case study file as input with additional dictionary containing key/value pairs. key = action
        # 6 - Use a case study file as input with additional dictionary containing key/value pairs. key = local_action
        # 7 - Use a case study file as input with additional dictionary containing key/value pairs. key = delegate_to
    '''


# Generated at 2022-06-23 04:52:20.716330
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task = {'module': 'copy',
            'src': 'xyz',
            'dest': 'xyz'
            }
    parser = TaskParser(task)
    assert parser is not None



# Generated at 2022-06-23 04:52:21.470108
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-23 04:52:25.540887
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars

    # for some modules like command the default is true, for others like
    # copy the default is false, so we can't really tell here
    # TODO: clean up this usage of skip_action_validation in the module
    # arguments parser
    def check_result(expected_args, expected_delegate_to, expected_action, the_action, skip_action_validation=False):
        (action, args, delegate_to) = ModuleArgsParser(the_action, collection_list=None).parse(skip_action_validation=skip_action_validation)
        assert action == expected_action, 'action "%s" != "%s"' % (action, expected_action)

# Generated at 2022-06-23 04:52:31.873413
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Load ModuleArgsParser class and test it."""

    # Test the constructor
    module_args_parser = ModuleArgsParser(task_ds={})
    assert hasattr(module_args_parser, 'parse')

    # Test the parse method
    module_args_parser = ModuleArgsParser(task_ds={})
    assert module_args_parser.parse() is not None

# Generated at 2022-06-23 04:52:41.760724
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()
    collection_loader._set_collection_paths(['./stdlib'])
    task_ds = {'action':'copy', 'src':'h1', 'dest':'h2', 'args':{'asdf':'asdf'}}
    map_ = ModuleArgsParser(task_ds, collection_loader)
    assert map_.parse() == ('copy', {'dest': 'h2', 'src': 'h1', 'asdf': 'asdf'}, Sentinel)


# Generated at 2022-06-23 04:52:42.936042
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 04:52:52.789696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DataLoader()
    hosts = set([])
    variable_manager = VariableManager()
    loader.set_variable_manager(variable_manager)
    variable_manager.extra_vars = {'ansible_connection': 'local'}
    mock_callback = MagicMock()
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=dict()))
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 04:53:03.098177
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test module args parser
    parser = ModuleArgsParser()

    # test normal behavior
    action = 'shell'
    args = {'A': '1', 'B': '2'}
    task = {'action': 'shell A=1 B=2'}
    res = parser.parse(task)
    assert res == (action, args, None)

    action = 'shell'
    args = {'A': '1', 'B': '2'}
    task = {'action': 'shell', 'args': 'A=1 B=2'}
    res = parser.parse(task)
    assert res == (action, args, None)

    action = 'shell'
    args = {'A': '1', 'B': '2'}

# Generated at 2022-06-23 04:53:12.914767
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    target_task_ds = dict(module=dict(module_name=dict(a=None)), action=dict(test=None))
    parser = ModuleArgsParser(target_task_ds)
    assert dict(action=dict(test=None)) == parser._task_ds
    parser = ModuleArgsParser(target_task_ds, collection_list=['test'])
    assert dict(action=dict(test=None)) == parser._task_ds
    parser = ModuleArgsParser({'action': 'test', 'module_name': dict(a=None)})
    assert dict(action='test') == parser._task_ds
    # Temporary fix until we figure out how to skip validation
    parser = ModuleArgsParser(target_task_ds, skip_action_validation=True)
    assert dict(action=dict(test=None)) == parser._task

# Generated at 2022-06-23 04:53:24.143636
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    fake_task1 = {'action': 'shell echo hi'}
    fake_task2 = {'action': 'shell', 'args': 'echo hi'}
    fake_task3 = dict(action='shell', args=dict(arg1='echo', arg2='hi'))
    fake_task4 = dict(action='shell', arg1='echo', arg2='hi')
    fake_task5 = dict(action='shell', arg1='echo', arg2='hi')
    fake_task6 = dict(action='shell', args='echo hi')
    fake_task7 = {'local_action': 'shell echo hi'}
    fake_task8 = {'local_action': 'shell', 'args': 'echo hi'}

# Generated at 2022-06-23 04:53:31.513579
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_dict = dict()
    collection_list = None

    # Run module
    task_ds_dict = dict()

    # Test 1:
    task_ds_dict = {"action": "ec2", "region": "xyz"}
    obj=ModuleArgsParser(task_ds_dict, collection_list)
    res=obj.parse()
    assert (res[0], {"region": "xyz"}) == ('ec2', {'region': 'xyz'})

    # Test 2:
    task_ds_dict = {"action": "ec2", "ec2": "xyz"}
    obj=ModuleArgsParser(task_ds_dict, collection_list)
    res=obj.parse()

# Generated at 2022-06-23 04:53:39.504059
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    test_module_args = {'name': 'test_module'}
    test_task_ds = {
        'action': 'test_action',
        'local_action': 'local_test_action',
        'args': 'test_args',
        'any_of_task_attrs': True,
        'with_items': ['item1', 'item2'],
    }
    test_block_ds = {
        'block': [
            {
                'name': 'test_block',
                'task': [test_task_ds, test_task_ds],
            },
        ],
    }

# Generated at 2022-06-23 04:53:51.657183
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={'region': 'xyz'}, collection_list=['test_collections', 'test_collections2'])
    assert parser._task_ds == {'region': 'xyz'}
    assert parser._collection_list == ['test_collections', 'test_collections2']
    assert parser.resolved_action is None
    assert parser._task_attrs == frozenset([
        'block', 'block_error', 'block_var', 'changed_when', 'changed_when_val', 'continue_on_error',
        'failed_when', 'failed_when_val', 'ignore_errors', 'name', 'no_log', 'notify', 'register', 'tags', 'until', 'retries',
        'delegate_to', 'local_action', 'static'])



# Generated at 2022-06-23 04:54:03.379788
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test the ModuleArgsParser class
    # in task normalization, the 'shell' module should be carried over as _raw_params,
    # if a shell module task was originally defined like this:
    #   shell: 'echo foo'
    # which is equivalent to:
    #   shell: echo foo
    if not os.path.exists('/tmp/ansible_test_dir'):
        os.mkdir('/tmp/ansible_test_dir')
    f = open('/tmp/ansible_test_dir/test_task.yml','w')
    f.write('---\nshell: echo foo')
    f.close()

    # first try to pass a test file without collection_list parameter

# Generated at 2022-06-23 04:54:16.230658
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    parser = ModuleArgsParser(task_ds=dict())
    assert not parser

    parser = ModuleArgsParser(task_ds=dict())
    assert not parser

    parser = ModuleArgsParser(task_ds=dict(action='echo hi'))
    assert not parser

    parser = ModuleArgsParser(task_ds=dict(local_action='echo hi'))
    assert not parser

    parser = ModuleArgsParser(task_ds=dict(action='copy src=a dest=b'))
    assert not parser

    parser = ModuleArgsParser(task_ds=dict(local_action='copy src=a dest=b'))
    assert not parser

    parser = ModuleArgsParser(task_ds=dict(action=dict(module='copy src=a dest=b')))
    assert not parser


# Generated at 2022-06-23 04:54:28.316397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialization
    text = '''
    - name: Install Ansible
      action: shell echo hi
    '''
    context = setup_context()
    parser = ModuleArgsParser(yaml.safe_load(text))

    # Method parse
    action, args, delegate_to = parser.parse()

    # Results
    assert action == 'shell'
    assert len(args) == 1
    assert args == {"_raw_params": 'echo hi'}
    assert delegate_to is None



# Generated at 2022-06-23 04:54:38.523147
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Validate ModuleArgsParser constructor
    '''

    # we expect to receive a task dictionary as argument
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser('not_a_dict')

    # we can pass an empty task dictionary too
    ModuleArgsParser({}, [])

    # a task dictionary with a non-dict should raise an AnsibleParserError
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser({'not_a_dict': False})

    # a task dictionary with a non-dict should raise an AnsibleParserError
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser({'not_a_dict': {'key': 'value'}})

# Generated at 2022-06-23 04:54:52.234433
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test basic parsing
    test_data = {'action': 'shell /bin/example command={{testarg}}'}
    module_args_parser = ModuleArgsParser(task_ds=test_data)

    expected_action = 'shell'
    expected_args = dict(
        _raw_params='/bin/example',
        command='{{testarg}}'
    )
    expected_delegate_to = Sentinel

    (parsed_action, parsed_args, parsed_delegate_to) = module_args_parser.parse()

    assert expected_action == parsed_action, 'module_args_parser.parse() parses action incorrectly'
    assert expected_args == parsed_args, 'module_args_parser.parse() parses args incorrectly'

# Generated at 2022-06-23 04:54:57.000384
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set test input
    task_ds = dict(
        static='true',
        delegate_to=None,
        local_action='shell echo hi'
    )

    # Create a ModuleArgsParser object to test
    test_input = ModuleArgsParser(task_ds)

    # Get test result
    res = test_input.parse()

    assert res == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')



# Generated at 2022-06-23 04:55:08.439592
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert parser.resolved_action == 'ansible.modules.files.copy'
    assert action == 'copy'
    assert args == {
        'src': 'a',
        'dest': 'b'
    }
    assert delegate_to == 'localhost'

    task_ds = {
        'delegate_to': 'localhost',
        'local_action': 'copy src=a dest=b'
    }
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse()
    assert parser.resolved_action

# Generated at 2022-06-23 04:55:17.345279
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # The first argument is task_ds (dictionary of data structure)
    # and the second argument is collection_list

    # 1. test if task_ds is None
    try:
        ModuleArgsParser(task_ds=None, collection_list=None)
    except AnsibleAssertionError as e:
        assert str(e) == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"

    # 2. test if task_ds is a string
    try:
        ModuleArgsParser(task_ds='string', collection_list=None)
    except AnsibleAssertionError as e:
        assert str(e) == "the type of 'task_ds' should be a dict, but is a <class 'str'>"

# Unit tests for parse method of class ModuleArgsParser

# Generated at 2022-06-23 04:55:20.609651
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'a': 'A', 'b': 'B'}
    test_parser = ModuleArgsParser(task_ds)
    assert test_parser._task_ds == task_ds



# Generated at 2022-06-23 04:55:27.552453
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Setup
    module_args_parser = ModuleArgsParser(task_ds=['module'], collection_list=['module', 'action'])
    # Invoke
    response = module_args_parser.parse(skip_action_validation=True)
    # Check
    assert response[0] == 'module'
    assert response[1] == {}
    assert response[2] == None



# Generated at 2022-06-23 04:55:37.955900
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test YAML form with command-type module
    task_ds = dict(
        command='pwd',
        args=dict(
            chdir='/tmp'
        )
    )
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser is not None
    assert task_ds == parser._task_ds
    assert set(['command', 'args']) == parser._task_attrs
    assert {} == parser._normalize_parameters('', additional_args='')
    assert ('pwd', {'chdir': '/tmp'}) == parser._normalize_parameters('', additional_args=task_ds['args'])
    action_args, args, delegate_to = parser.parse()
    assert action_args == 'command'

# Generated at 2022-06-23 04:55:49.046247
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    task_ds = {"action": "shell", "args": "uname -a", "delegate_to": "wherever", "_ansible_no_log": False, "local_action": "shell",
               "foo": "bar"}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    # Act
    (action, args, delegate_to) = module_args_parser.parse(skip_action_validation=False)
    # Assert
    assert action == "shell"
    assert args == {"_ansible_no_log": False, "args": "uname -a"}
    assert delegate_to == "wherever"


# Generated at 2022-06-23 04:55:56.063968
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_task_ds = dict()
    test_collection_list = list()
    obj = ModuleArgsParser(task_ds=test_task_ds, collection_list=test_collection_list)

    assert isinstance(obj, ModuleArgsParser)
    with pytest.raises(AnsibleAssertionError) as exc:
        ModuleArgsParser(task_ds=[], collection_list=test_collection_list)
    assert to_native(exc.value) == "the type of 'task_ds' should be a dict, but is a <class 'list'>"


# Generated at 2022-06-23 04:56:05.716175
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'local_action': 'dirname a/b', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'dirname'
    assert args == {'path': 'a/b'}
    assert delegate_to == 'localhost'

    task_ds = {'action': "get_url url=https://raw.github.com/ansible/ansible/devel/examples/ansible.cfg dest=/etc/ansible/ansible.cfg validate_certs=no"}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'get_url'

# Generated at 2022-06-23 04:56:15.363793
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initializing the ArgSpec Object with empty args
    argget = ModuleArgsParser(None, None)

    # Creating a list of all the valid kwargs of the module
    # Here, the list will be empty
    keys = []
    # Creating the dictionary of kwargs to pass to the parse method
    kwargs = {}

    # Normalizing the Args
    argget._normalize_parameters(kwargs, keys)

    # Initializing the Basic variables to pass to the parse method
    module = 'shell'
    closure = {'shell': '/bin/sh'}
    ansible_vars = {}
    task_vars = {}
    args = {'chdir': '/'}

    # Asserting the type of the Output of the parse method

# Generated at 2022-06-23 04:56:24.708705
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-23 04:56:29.837054
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    _task_ds = {
        "delegate_to": "localhost",
        "action": "copy"
    }
    module_args_parser = ModuleArgsParser(_task_ds, collection_list=None)
    assert module_args_parser


# Generated at 2022-06-23 04:56:40.538235
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = {
        'delegate_to': 'test'
    }

    parser = ModuleArgsParser(_task_ds)
    assert parser._task_ds == _task_ds
    assert parser._task_attrs == frozenset(['local_action', 'static'])

    assert parser.parse() == ('test', {}, 'test')

    _task_ds = {
        'delegate_to': 'test',
        'action': 'shell'
    }
    parser = ModuleArgsParser(_task_ds)
    assert parser._task_ds == _task_ds
    assert parser._task_attrs == frozenset(['local_action', 'static'])

    assert parser.parse() == ('test', {}, 'test')


# Generated at 2022-06-23 04:56:48.828175
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'delegate_to': 'localhost', 'shell': 'echo hi', 'with_items': 'world'}
    task_ds2 = {'shell': 'echo hi'}
    task_ds3 = "echo hi"
    task_ds4 = {'action': {'default_input': {'input_text': 'test'}} }

    parser = ModuleArgsParser(task_ds)
    assert isinstance(parser, ModuleArgsParser)
    assert isinstance(parser._task_ds, dict)

    parser2 = ModuleArgsParser(task_ds2)
    assert isinstance(parser2, ModuleArgsParser)

    with pytest.raises(AnsibleAssertionError):
        parser3 = ModuleArgsParser(task_ds3)


# Generated at 2022-06-23 04:57:03.521748
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.compat.tests import mock
    mock_task_ds = dict()
    mock_task_ds['action'] = dict()
    mock_task_ds['action']['module'] = 'shell echo hi'
    mock_task_ds['delegate_to'] = 'localhost'
    mock_task_ds['args'] = dict()
    mock_task_ds['args']['chdir'] = '/tmp'

    m_instance = mock.Mock()
    m_instance.__getitem__.return_value = mock_task_ds

    m_task_ds = mock.Mock()
    m_task_ds.__getitem__.return_value = m_instance
    m_task_ds.__getitem__.return_value.__getitem__.return_value = str()

    mock_

# Generated at 2022-06-23 04:57:05.512346
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # NOTE: This test is disabled because it requires a fake PlayContext, which is not directly accessible
    pass


# Generated at 2022-06-23 04:57:13.170623
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test specifying the action as the key
    task_ds = dict(module='copy', src='a', dest='b')
    module_args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None

    # test specifying the action inline like 'copy src=a dest=b'
    task_ds = dict(action='copy src=a dest=b', delegate_to='foobar')
    module_args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')


# Generated at 2022-06-23 04:57:19.912438
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task

    task_ds = dict(action=dict(module='foo', args='this is baz'))
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_attrs == set(Task._valid_attrs.keys())
    assert parser._task_ds == dict(action=dict(module='foo', args='this is baz'))

    task_ds = dict(action=dict(module='foo', args='this is baz'))
    parser = ModuleArgsParser(task_ds=task_ds, collection_list='collections')
    assert parser._task_attrs == set(Task._valid_attrs.keys())
    assert parser._task_ds == dict(action=dict(module='foo', args='this is baz'))
    assert parser._

# Generated at 2022-06-23 04:57:21.391571
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser

# Generated at 2022-06-23 04:57:30.935228
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict()
    task['action'] = 'shell echo hi'
    task['delegate_to'] = None
    task['args'] = None
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    parser = ModuleArgsParser(task_ds=task, collection_list=[])
    assert expected_result == parser.parse()
    task['action'] = 'shell'
    task['args'] = 'echo hi'
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    parser = ModuleArgsParser(task_ds=task, collection_list=[])
    assert expected_result == parser.parse()
    task['action'] = 'shell'
    task['args'] = dict()
    task

# Generated at 2022-06-23 04:57:39.147581
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser({'action': 'copy src=a dest=b'}, collection_list=[])
    assert module_parser._task_ds == {'action': 'copy src=a dest=b'}
    assert module_parser._collection_list == []

    with pytest.raises(AnsibleAssertionError) as exc:
        ModuleArgsParser([])
    assert exc.value.args[0] == "the type of 'task_ds' should be a dict, but is a <class 'list'>"



# Generated at 2022-06-23 04:57:49.045149
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  tasks = [
    '{"local_action": "shell echo no args"}',
    '{"action": "shell echo no args"}',
    '{{local_action}}',
    '{{action}}'
  ]

  additional_args = {}

  for task in tasks:
    # create instance of the class to test
    task = ModuleArgsParser(task, collection_list=None)

    # call method to test
    action, args, delegate_to = task.parse()

    # make test assertions
    assert isinstance(action, string_types)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, string_types)



# Generated at 2022-06-23 04:57:59.737490
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.task_include
    import ansible.utils
    c = ModuleArgsParser({'action': 'shell', 'delegate_to': 'localhost'})
    assert c.parse() == ('shell', {}, 'localhost')
    c = ModuleArgsParser({'action': 'shell', 'delegate_to': 'localhost', 'args': 'echo hello'})
    assert c.parse() == ('shell', {'echo hello': None}, 'localhost')
    c = ModuleArgsParser({'action': 'shell', 'delegate_to': 'localhost', 'args': 'echo hello', 'register': 'registered'})
    assert c.parse() == ('shell', {'echo hello': None, 'register': 'registered'}, 'localhost')

# Generated at 2022-06-23 04:58:13.021906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    args = 'echo hi'
    additional_args = 'arg1=1 arg2=2'
    non_task_ds = {}
    non_task_ds[action] = args
    task_ds = {}
    task_ds.update(non_task_ds)
    task_ds['args'] = additional_args
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds = task_ds, collection_list = collection_list)
    # test with action and args
    res = module_args_parser.parse()
    assert res[0] == action
    assert res[1]['_raw_params'] == args
    assert res[1]['arg1'] == '1'
    assert res[1]['arg2'] == '2'

# Generated at 2022-06-23 04:58:15.932946
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = '"echo hi"'
    m = ModuleArgsParser(task_ds)
    assert m is not None


# Generated at 2022-06-23 04:58:17.012002
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None

# Generated at 2022-06-23 04:58:28.356910
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mock_task_ds = dict()
    mock_task_ds.update(dict(action='shell', delegate_to='localhost', args='pwd'))
    obj = ModuleArgsParser(task_ds=mock_task_ds)
    assert obj
    mock_task_ds_1 = {}
    obj = ModuleArgsParser(task_ds=mock_task_ds_1)
    assert obj
    collection_list = collections.namedtuple("Collections", ["list"])
    mock_collection_list = collection_list(list=[])
    obj = ModuleArgsParser(task_ds=mock_task_ds, collection_list=mock_collection_list)
    assert obj



# Generated at 2022-06-23 04:58:38.013637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    args_to_test = {
        'module': 'setup',
        'action': 'setup',
        'local_action': 'setup'
    }

    for arg_to_test in args_to_test:

        task_ds = {
            'test_loop': dict(),
            arg_to_test: dict(
                filter=dict(
                    fqdn='*',
                    ipv4=dict(
                        interface='eth0',
                        address='*',
                    )
                )
            )
        }

        # test_loop is expected to be removed
        expected_task_ds = task_ds.copy()
        expected_task_ds.pop('test_loop')

        # *** test the method ***
        module_args_parser = ModuleArgsParser(task_ds=task_ds)
        action, args, _

# Generated at 2022-06-23 04:58:41.982301
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # make sure that we can initialize ModuleArgsParser with valid values
    ModuleArgsParser({"delegate_to": "example.com"})
    ModuleArgsParser({"delegate_to": "example.com"}, ["Example_collection"])
    assert True

# Generated at 2022-06-23 04:58:52.218699
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_dict_1 = {
        'action': {
            'module': 'ec2',
            'x': 1
        }
    }
    task_ds_dict_2 = {
        'action': {
            'module': 'this is arg1 arg2',
            'x': 1
        }
    }
    task_ds_dict_3 = {
        'action': 'this is arg1 arg2',
    }
    task_ds_dict_4 = {
        'local_action': 'this is arg1 arg2',
    }
    task_ds_dict_5 = {
        'local_action': 'this is arg1 arg2',
        'x': 1,
    }

# Generated at 2022-06-23 04:59:00.833222
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.executor.module_common import ActionModule

    # Test case #1
    # Testing with task ds is None and delegate_to is None.
    # Expected result: an error raised
    test_module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        test_module_args_parser.parse()

    excinfo.match("the type of 'task_ds' should be a dict, but is a")

    # Test case #2
    # Testing with task ds is a dict and delegate_to is None.
    # Expected result: a dict returned
    test_module_args_parser

# Generated at 2022-06-23 04:59:06.784999
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=None,
                                  collection_list=None)
    with pytest.raises(AnsibleAssertionError) as error:
        parser.parse()
    assert 'the type of \'task_ds\' should be a dict, but is a NoneType' in str(error.value)


# Generated at 2022-06-23 04:59:14.860935
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser(None).parse() is None
    assert ModuleArgsParser('').parse() is None
    assert ModuleArgsParser({}).parse() is None
    assert ModuleArgsParser({'action': 'action_module'}).parse() is not None
    # assert ModuleArgsParser(None,None).parse() is None
    # assert ModuleArgsParser('','').parse() is None
    # assert ModuleArgsParser({},{}).parse() is None
    # assert ModuleArgsParser({'action': 'action_module'},{'action': 'action_module'}).parse() is not None


# Generated at 2022-06-23 04:59:23.480896
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg = 'src=x dest=y'
    # module_arg = 'localhost'
    # module_arg = 'echo hi'
    # module_arg = {'src': 'x', 'dest': 'y'}
    # module_arg = {'module': 'get_url', 'url': 'https://google.com'}
    # module_arg = None
    # module_arg = 'echo hi'
    parser = ModuleArgsParser(thing=module_arg)
    result = parser.parse()
    print(result)

if __name__ == "__main__":
    test_ModuleArgsParser()

# Generated at 2022-06-23 04:59:31.566614
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'setup',
               'delegate_to': 'master'}
    m = ModuleArgsParser(task_ds=task_ds)
    assert m._task_ds == task_ds
    assert m._task_attrs == frozenset(['action', 'delegate_to', 'local_action', 'static'])
    assert m.resolved_action is None

# Generated at 2022-06-23 04:59:35.375837
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser(None)
    assert module_parser.parse(None) == (None, None, None)


# Generated at 2022-06-23 04:59:42.230044
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_task_ds = dict()
    my_collection_list = list()
    my_skip_action_validation = False
    my_task_ds['action'] = 'bash echo hi'
    parser = ModuleArgsParser(my_task_ds, my_collection_list)
    (action, args, delegate_to) = parser.parse(my_skip_action_validation)
    print(action)
    print(args)
    print(delegate_to)


# creating a global instance of the object
module_args_parser = ModuleArgsParser()


# Generated at 2022-06-23 04:59:52.521703
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence

    # call with no args
    p = ModuleArgsParser()
    assert p is not None

    # call with some args
    fake_ds = {'_ansible_no_log': True, 'async': 10, 'poll': 0}
    p = ModuleArgsParser(task_ds=fake_ds)
    assert p is not None

    # call with args, should not accept this
    fake_ds = {'_ansible_no_log': True, 'async': 10, 'poll': 0, 'action': {'shell': 'echo hi'}}

# Generated at 2022-06-23 04:59:56.552633
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task = {
        'delegate_to': 'localhost',
        'action': 'ec2',
    }
    module_args_parser = ModuleArgsParser(fake_task)
    module_args_parser.parse()

# Generated at 2022-06-23 05:00:05.670890
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(dict(), collection_list=[])
    assert_equal(m._task_ds, {})
    assert_equal(m._collection_list, [])
    assert_equal(m.resolved_action, None)

    m = ModuleArgsParser(dict(a=1), collection_list=[('a', 'b')])
    assert_equal(m._task_ds, {'a': 1})
    assert_equal(m._collection_list, [('a', 'b')])
    assert_equal(m.resolved_action, None)

    # module name, action, delegate_to
    m = ModuleArgsParser(dict(a=1), collection_list=[])
    assert_equal(m._split_module_string('copy src=a dest=b'), ('copy', 'src=a dest=b'))

# Generated at 2022-06-23 05:00:09.113264
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={})
    result = module_args_parser.parse(skip_action_validation=True)
    assert result == (None, {}, None)


# Generated at 2022-06-23 05:00:19.325183
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    # simple test
    task_ds = dict(
        action=dict(module='shell', args='ls -la'),
        local_action=dict(module='shell', args='ls -la'),
    )
    assert m.parse(task_ds) == ('shell', {'args': 'ls -la'}, 'localhost')

    # Test argument checking
    task_ds = dict(
        action=dict(module='shell', args='ls -la'),
        local_action=dict(module='shell', args='ls -la'),
        bad_kw='bad_kw'
    )
    with pytest.raises(AnsibleParserError):
        m.parse(task_ds)

    # Test argument checking

# Generated at 2022-06-23 05:00:30.661241
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # We use _ansible_item_label to report error messages in this test
    # because we use the same error message in AnsibleParserError
    name = "_ansible_item_label"

    data1 = dict()
    data1["action"] = dict()
    data1["action"]["module"] = "test"
    data1["args"] = dict(test="test")

    data2 = dict()
    data2["action"] = "test"

    data3 = dict()
    data3["local_action"] = dict()
    data3["local_action"]["module"] = "test"

    data4 = dict()
    data4["local_action"] = "test"

    data5 = dict()
    data5["test"] = dict()
    data5["test"]["module"] = "test"

   