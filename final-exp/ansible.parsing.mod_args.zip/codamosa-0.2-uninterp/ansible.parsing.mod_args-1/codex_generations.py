

# Generated at 2022-06-17 06:02:28.477301
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 06:02:39.065484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert "no module/action detected in task." in str(excinfo.value)

    # Test with action
    task_ds = dict(action='shell echo hi')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi')
    assert delegate_to

# Generated at 2022-06-17 06:02:43.552811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == None


# Generated at 2022-06-17 06:02:57.904325
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    parser = ModuleArgsParser()
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with task_ds and delegate_to
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with task_ds and additional_args

# Generated at 2022-06-17 06:03:00.910369
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)


# Generated at 2022-06-17 06:03:16.254985
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module and args
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module and args and delegate_to
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}

# Generated at 2022-06-17 06:03:32.545449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b',
        }
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with task_ds

# Generated at 2022-06-17 06:03:44.537465
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:45.252613
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass

# Generated at 2022-06-17 06:03:56.083790
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with no action
    task_ds = {}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert "no module/action detected in task." in str(excinfo.value)

    # Test with a task with an action
    task_ds = {'action': 'shell echo hi'}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    #

# Generated at 2022-06-17 06:04:26.251517
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_vars import TaskVars
    from ansible.playbook.task_vars import TaskVars
    from ansible.playbook.task_vars import TaskVars
    from ansible.playbook.task_vars import TaskVars
    from ansible.playbook.task_vars import TaskVars

# Generated at 2022-06-17 06:04:32.728034
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()

    # Create a task dictionary
    task_ds = {'action': 'shell echo hi'}

    # Call the method parse of class ModuleArgsParser
    result = module_args_parser.parse(task_ds)

    # Assert the result
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:04:42.279189
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_task_ds_with_action_and_local_action_and_module
    task_ds = {'action': 'shell echo hi', 'local_action': {'module': 'ec2', 'x': 1}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # test_task_ds_with_action_and_local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse

# Generated at 2022-06-17 06:04:51.546867
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.vault_password_include import VaultPasswordInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:04:58.540656
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:05:07.001732
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:20.859399
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:05:30.302409
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a test object
    test_obj = ModuleArgsParser()
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    assert test_obj.parse(task_ds) == ('shell', {'_raw_params': 'echo hi'}, None)
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost'}
    assert test_obj.parse(task_ds) == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost', 'other_key': 'other_value'}
    assert test_

# Generated at 2022-06-17 06:05:40.281270
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy', 'args': 'src=a dest=b'}
    collection_list = None
   

# Generated at 2022-06-17 06:05:48.234638
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has 'action'
    task_ds = dict(action='shell echo hi')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi')
    assert delegate_to is None

    # Test with a task_ds that has 'local_action'
    task_ds = dict(local_action='shell echo hi')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:06:08.031248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:06:15.328473
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with empty task_ds
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with task_ds with local_action

# Generated at 2022-06-17 06:06:26.015600
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:06:37.688103
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')


# Generated at 2022-06-17 06:06:53.281877
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "action and local_action are mutually exclusive" in to_text(excinfo.value)

    # Test with action and module
    task_ds = {'action': 'shell echo hi', 'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "conflicting action statements: shell, module" in to_text(excinfo.value)

    # Test with local_action and module


# Generated at 2022-06-17 06:07:01.508587
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None

# Generated at 2022-06-17 06:07:14.116510
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None



# Generated at 2022-06-17 06:07:26.732699
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:32.636946
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:07:38.988461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    result = module_args_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-17 06:07:54.845235
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test case 1
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser

# Generated at 2022-06-17 06:08:00.461451
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test for method parse(self, skip_action_validation=False)
    # of class ModuleArgsParser
    #
    # This test is not implemented
    #
    # TODO: Implement this test
    pass

# Generated at 2022-06-17 06:08:06.565330
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:13.144570
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:26.412943
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:34.096383
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with a module and args
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task with a module and args
    task_ds = {'action': 'copy: src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task with a module and args


# Generated at 2022-06-17 06:08:43.575688
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with a local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to == 'localhost'

    # Test with a task with a local_action and delegate_to
    task_ds = {'local_action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}


# Generated at 2022-06-17 06:08:54.196127
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:09:02.539414
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:08.300159
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has a module name in it
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a task_ds that has a module name in it
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action

# Generated at 2022-06-17 06:09:26.035634
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:40.202959
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 06:09:48.307585
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:54.806498
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:57.574563
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:10:07.247639
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vault_included_file import VaultIncludedFile
    from ansible.playbook.role_dependency import Role

# Generated at 2022-06-17 06:10:17.207479
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    expected_result = (None, {}, None)
    result = ModuleArgsParser(task_ds, collection_list).parse()
    assert result == expected_result

    # Test with args
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    expected_result = ('shell', {'_raw_params': 'echo hi'}, None)
    result = ModuleArgsParser(task_ds, collection_list).parse()
    assert result == expected_result

    # Test with args
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    expected_result = ('shell', {'_raw_params': 'echo hi'}, 'localhost')

# Generated at 2022-06-17 06:10:27.020053
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:38.896125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with no action
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert "no module/action detected in task." in str(excinfo.value)

    # Test with a task with an action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_

# Generated at 2022-06-17 06:10:45.399021
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has no action
    task_ds = {'delegate_to': 'localhost', 'args': {'_raw_params': 'echo hi', '_uses_shell': True}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, 'localhost')

    # Test with a task_ds that has action
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'_raw_params': 'echo hi', '_uses_shell': True}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:11:12.893732
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with module
    task_ds = {'shell': 'echo hi'}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:11:19.664678
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:25.088423
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task_ds
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task_

# Generated at 2022-06-17 06:11:30.851969
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:11:43.948056
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that uses the 'action' key
    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi')
    assert delegate_to is None

    # Test with a task that uses the 'local_action' key
    task_ds = dict(local_action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi')
    assert delegate_to == 'localhost'

    # Test with a task that uses the 'module' key

# Generated at 2022-06-17 06:11:54.979058
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    collection_list = [
        'ansible.builtin',
        'ansible_collections.community.general'
    ]
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:12:09.422706
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    #