

# Generated at 2022-06-17 06:02:48.232005
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:02:58.860300
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == (None, {}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None
    module_

# Generated at 2022-06-17 06:03:14.237825
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    collection_list = [
        'ansible.builtin',
        'ansible_collections.testns.testcoll',
        'ansible_collections.testns.testcoll.plugins.modules'
    ]
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'
    assert parser.resolved_action == 'ansible.builtin.shell'


# Generated at 2022-06-17 06:03:19.183048
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:03:34.201177
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_dict_with_action_and_local_action
    task_ds = dict(action=dict(module='copy', src='a', dest='b'), local_action=dict(module='copy', src='a', dest='b'))
    with pytest.raises(AnsibleParserError) as excinfo:
        ModuleArgsParser(task_ds).parse()
    assert 'action and local_action are mutually exclusive' in str(excinfo.value)

    # test_dict_with_action_and_module
    task_ds = dict(action=dict(module='copy', src='a', dest='b'), module='copy', src='a', dest='b')
    with pytest.raises(AnsibleParserError) as excinfo:
        ModuleArgsParser(task_ds).parse()

# Generated at 2022-06-17 06:03:45.402316
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and collection_list
    task_ds = {'action': 'shell echo hi'}
    collection_list = ['ansible_collections.ansible.builtin']
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:03:56.234863
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:09.796877
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:24.144009
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import ROLE_CACHE
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base

# Generated at 2022-06-17 06:04:33.817046
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module name
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert "no module/action detected in task." in str(excinfo.value)

    # Test with module name
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with module name and

# Generated at 2022-06-17 06:04:56.734585
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:07.344711
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:08.944952
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Implement test for method parse of class ModuleArgsParser
    pass


# Generated at 2022-06-17 06:05:19.551715
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:29.542681
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:41.594349
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None

    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:05:48.851372
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:06:01.178251
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}


# Generated at 2022-06-17 06:06:14.642128
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test with action
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'

    # test with module

# Generated at 2022-06-17 06:06:20.071016
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to

# Generated at 2022-06-17 06:06:34.266988
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:06:38.392755
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:06:53.872976
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds as dict
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds as string
    task_ds = 'test'
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds as

# Generated at 2022-06-17 06:07:02.779092
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:07:13.823072
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsIn

# Generated at 2022-06-17 06:07:26.640183
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no delegate_to
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with delegate_to
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:07:38.194768
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.task_include import TaskInclude as Include
    from ansible.playbook.handler_task_include import HandlerTaskInclude as HandlerInclude
    from ansible.playbook.block import Block as BlockInclude

# Generated at 2022-06-17 06:07:47.520652
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a simple task
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a task with delegate_to
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with a task with delegate_to and complex args

# Generated at 2022-06-17 06:08:02.699490
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:09.130377
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:25.652622
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:08:33.816633
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:42.580601
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with valid input
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with invalid input
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:08:50.268965
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:54.473017
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:09:02.682714
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

# Generated at 2022-06-17 06:09:08.378153
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:09:20.988342
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:24.982536
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:09:39.367638
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:05.682287
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'

    # Test with a valid task
    task_ds = {
        'action': {
            'module': 'copy src=a dest=b'
        },
        'delegate_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'

# Generated at 2022-06-17 06:10:18.058673
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:27.532024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with empty task_ds
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with task_ds with

# Generated at 2022-06-17 06:10:38.915222
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vault_include import VaultInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
   

# Generated at 2022-06-17 06:10:45.995214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # Test with module
    task_ds = {'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    # Test with args
    task_ds = {'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:10:58.567253
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:13.425085
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    expected_action = None
    expected_args = {}
    expected_delegate_to = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    expected_action = 'copy'
    expected_args = {'src': 'a', 'dest': 'b'}
    expected_delegate_to = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_

# Generated at 2022-06-17 06:11:27.699459
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:38.844622
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:40.062737
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:12:09.483276
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task_ds
    task_ds = {'action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with an invalid task_ds
    task_ds = {'action': 'copy src=a dest=b', 'local_action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        module_args_parser.parse()

    # Test with a valid task_ds
    task_ds = {'local_action': 'copy src=a dest=b'}
    module_args_