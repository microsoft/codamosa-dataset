

# Generated at 2022-06-17 06:02:37.739009
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module name and a dictionary of arguments
    task_ds = {'module': {'region': 'xyz'}}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'module'
    assert args == {'region': 'xyz'}
    assert delegate_to is None

    # Test with a task that has a module name and a string of arguments
    task_ds = {'module': 'region=xyz'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'module'
    assert args == {'region': 'xyz'}
    assert delegate_to is None

   

# Generated at 2022-06-17 06:02:45.530807
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:02:52.357094
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-17 06:03:01.667764
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, None, None)

    # Test with task_ds
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, None, None)

    # Test with task_ds and collection_list
    task_ds = {}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, None, None)

    # Test with task_ds and collection_list

# Generated at 2022-06-17 06:03:16.913197
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:26.968992
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-17 06:03:38.196382
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'echo'
    assert args == {'_raw_params': 'hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'echo'
   

# Generated at 2022-06-17 06:03:44.142866
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'shell'


# Generated at 2022-06-17 06:03:56.851239
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    parser = ModuleArgsParser(task_ds=None)
    assert parser.parse() == (None, dict(), None)

    # Test with task_ds
    task_ds = dict()
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, dict(), None)

    # Test with task_ds and action
    task_ds = dict(action='test')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('test', dict(), None)

    # Test with task_ds and local_action
    task_ds = dict(local_action='test')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('test', dict(), 'localhost')

    # Test

# Generated at 2022-06-17 06:04:10.082985
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleT

# Generated at 2022-06-17 06:04:30.031401
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
   

# Generated at 2022-06-17 06:04:44.599183
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:51.940202
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:55.567687
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-17 06:05:06.852863
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with module
    task_ds = {'module': 'shell echo hi'}

# Generated at 2022-06-17 06:05:13.407461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test for method parse(self, skip_action_validation=False)
    # of class ModuleArgsParser
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test for action: copy src=a dest=b
    task_ds = {'action': 'copy src=a dest=b'}

# Generated at 2022-06-17 06:05:24.235896
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None

# Generated at 2022-06-17 06:05:32.022824
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and delegate_to
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with task_ds

# Generated at 2022-06-17 06:05:43.729756
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:57.913842
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, Sentinel)

    # Test with task_ds with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:06:15.348819
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse()
    #
    #   Test the parse() method of the ModuleArgsParser class
    #
    # Inputs
    # ------
    #    @param: task_ds - the task dictionary to parse
    #    @param: collection_list - list of collections to search for modules
    #
    # Returns
    # -------
    #    @return: (action, args, delegate_to)
    #
    # Raises
    # ------
    #    @raises: none
    #
    #-----------------------------------------------------------------------

    #-----------------------------------------------------------------------
    # Test 1:
    #
    #-----------------------------------------------------------------------
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost'
    }
    collection_list = None

# Generated at 2022-06-17 06:06:26.040333
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    parser = ModuleArgsParser(task_ds=None)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds with action
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with task_ds with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with task_ds with module


# Generated at 2022-06-17 06:06:36.253836
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:06:44.205853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    # Call method parse
    result = module_args_parser.parse()
    # Verify the result
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:06:56.919571
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:07:05.703697
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:07:16.631706
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:07:26.557053
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:38.082204
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = dict(action=dict(module='copy', src='a', dest='b'), local_action='shell echo hi')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert 'action and local_action are mutually exclusive' in str(excinfo.value)

    # Test with action and module
    task_ds = dict(action=dict(module='copy', src='a', dest='b'), module='shell echo hi')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()


# Generated at 2022-06-17 06:07:48.697525
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:07.157105
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a valid task with a module
    task_ds = {'copy': 'src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a valid task with a module and args

# Generated at 2022-06-17 06:08:19.510097
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'module': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse

# Generated at 2022-06-17 06:08:32.528557
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:34.727245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 06:08:44.047306
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:08:55.174591
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds as dict
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with task_ds as dict
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None
    module_

# Generated at 2022-06-17 06:08:59.455006
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:09:01.131246
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:09:09.054021
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:09:23.030698
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'args': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task
    task_ds = dict(action=dict(module='shell', args='echo hi'), delegate_to='localhost')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'args': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a valid task

# Generated at 2022-06-17 06:09:45.460601
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'copy src=a dest=b', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with module
    task_ds = {'module': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with action and module
    task_ds = {'action': 'copy src=a dest=b', 'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse()

# Generated at 2022-06-17 06:09:59.648491
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task_ds
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': {'echo': 'hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'echo': 'hi'}, None)

   

# Generated at 2022-06-17 06:10:08.328538
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:10:22.635327
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            module='copy',
            src='a',
            dest='b'
        )
    )
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None

    task_ds = dict(
        action='copy src=a dest=b'
    )
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None


# Generated at 2022-06-17 06:10:34.164603
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:44.043327
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:57.673104
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task_ds
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi', '_uses_shell': True}}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:11:04.013249
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    task_ds = {'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:11:15.979859
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:11:28.103809
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:45.126043
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:52.460910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that contains a module name and a module argument
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task_ds that contains a module name and a module argument
    # with a variable
    task_ds = {'action': 'copy src={{a}} dest={{b}}'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'

# Generated at 2022-06-17 06:12:07.345170
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with empty task_ds
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-17 06:12:14.058381
# Unit test for method parse of class ModuleArgsParser