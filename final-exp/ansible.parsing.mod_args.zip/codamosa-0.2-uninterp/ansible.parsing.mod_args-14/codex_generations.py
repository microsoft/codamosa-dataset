

# Generated at 2022-06-17 06:02:38.610297
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:02:44.361889
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:02:58.466728
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:13.639242
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    module

# Generated at 2022-06-17 06:03:22.037164
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has action, local_action, and module
    task_ds = {'action': 'copy src=a dest=b', 'local_action': 'shell echo hi', 'module': 'ec2 region=xyz'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('ec2', {'region': 'xyz'}, 'localhost')

    # Test with a task_ds that has action and local_action
    task_ds = {'action': 'copy src=a dest=b', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with a task_ds that has action

# Generated at 2022-06-17 06:03:31.304452
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': {'module': 'shell', 'args': {'_raw_params': 'echo hi'}}}
    collection_list = None

# Generated at 2022-06-17 06:03:38.958938
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:03:51.546363
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:58.619795
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {}
    assert delegate_to == 'localhost'

    # Test with a task that has a module
    task_ds = {'module': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args

# Generated at 2022-06-17 06:04:01.370419
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:04:27.544320
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:36.201414
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:49.865250
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:04:57.337975
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 1
    task_ds = {
        'action': {
            'module': 'copy',
            'src': 'a',
            'dest': 'b'
        }
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test case 2
    task_ds = {
        'action': 'copy src=a dest=b'
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test case

# Generated at 2022-06-17 06:05:00.017490
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'shell'


# Generated at 2022-06-17 06:05:07.359082
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds with a local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')
    assert parser.parse() == expected_result

    # Test with a task_ds with a module
    task_ds = {'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    assert parser.parse() == expected_result

    # Test with a task_ds with a module and delegate_to

# Generated at 2022-06-17 06:05:19.497955
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a task_ds
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    # Create a ModuleArgsParser
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    # Call method parse
    action, args, delegate_to = module_args_parser.parse()
    # Asserts
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:05:29.007753
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:05:39.141437
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', 'chdir': '/tmp'}, 'localhost')

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': 'chdir=/tmp'}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:05:48.144370
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': '_raw_params=echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser

# Generated at 2022-06-17 06:06:05.789204
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module name
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert_raises(AnsibleParserError, module_args_parser.parse)

    # Test with invalid module name
    task_ds = {'action': 'invalid_module_name'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert_raises(AnsibleParserError, module_args_parser.parse)

    # Test with valid module name
    task_ds = {'action': 'ping'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args

# Generated at 2022-06-17 06:06:15.203965
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)
    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:06:25.940392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with action and local_action
    task_ds = dict(action='shell echo hi', local_action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a task with action and local_action
    task_ds = dict(action='shell echo hi', local_action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a task with

# Generated at 2022-06-17 06:06:37.620448
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with task_ds
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with task_ds and collection_list
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = ['ansible_collections.ansible.builtin']


# Generated at 2022-06-17 06:06:53.224092
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:02.756676
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:13.823486
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:07:25.165603
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:07:37.348793
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has no action
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "no module/action detected in task." in to_text(excinfo.value)

    # Test with a task_ds that has a valid action
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task_ds that has a valid action and delegate_to

# Generated at 2022-06-17 06:07:46.682439
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with args
    task_ds = dict(action='shell echo hi')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with args
    task_ds = dict(action='shell echo hi', delegate_to='localhost')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse

# Generated at 2022-06-17 06:08:08.046964
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with valid data
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with invalid data
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() != ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with invalid data
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser

# Generated at 2022-06-17 06:08:20.951741
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    parser = ModuleArgsParser()
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and skip_action_validation
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse(skip_action_validation=True) == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and delegate_to

# Generated at 2022-06-17 06:08:28.938689
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:41.151460
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:47.406680
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:09:01.789581
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:09.412334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no action
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)


# Generated at 2022-06-17 06:09:21.965300
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module and an action
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(args='echo hi')
    assert delegate_to is Sentinel

    # Test with a task that has a module and an action
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(args='echo hi')
    assert delegate_to is Sentinel

    # Test with a task that has a module and

# Generated at 2022-06-17 06:09:27.479713
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None

# Generated at 2022-06-17 06:09:41.465039
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a valid module
    task_ds = {'shell': 'echo hi'}
    parser = Module

# Generated at 2022-06-17 06:10:07.325470
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # Test with a task that has action and module
    task_ds = {'action': 'shell echo hi', 'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    # Test with a task that has local_action and module

# Generated at 2022-06-17 06:10:17.206972
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}

# Generated at 2022-06-17 06:10:22.255595
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:33.788853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with a valid task
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with a valid task
    task_ds = {'action': 'copy', 'args': 'src=a dest=b'}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:10:44.015577
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vault import VaultSecret
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole

# Generated at 2022-06-17 06:10:57.673249
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:03.986368
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:15.979232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:11:21.725530
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_finder._file_system_finder import AnsibleCollectionFileSystemFinder

# Generated at 2022-06-17 06:11:35.530252
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:12:06.911561
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:12:13.224940
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {
        'name': 'test',
        'action': 'shell echo hi',
        'delegate_to': 'localhost'
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a valid task
    task_ds = {
        'name': 'test',
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {'chdir': '/tmp'}
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()