

# Generated at 2022-06-17 06:02:26.879946
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:02:37.277100
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:02:48.203433
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:03:01.001902
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test case 2
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # test case 3
    task_ds = {'action': 'copy src=a dest=b'}

# Generated at 2022-06-17 06:03:10.023915
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:03:21.082388
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with task_ds
    task_

# Generated at 2022-06-17 06:03:30.104408
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:03:36.309685
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:03:46.476760
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:03:57.240696
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:09.962509
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:21.488334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:04:33.949898
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with a valid task
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with a valid task
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost', 'args': {'test': 'test'}}

# Generated at 2022-06-17 06:04:47.126020
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:56.214951
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with args
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with

# Generated at 2022-06-17 06:05:06.538102
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    # Test with a valid task
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args,

# Generated at 2022-06-17 06:05:13.200619
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module_name
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with module_name
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with module_name and delegate_to
    task_ds

# Generated at 2022-06-17 06:05:24.073010
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:31.932698
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task
    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task
    task_ds = {'action': {'module': 'shell', 'args': {'_raw_params': 'echo hi'}}}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:05:35.504911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    module_args_parser.parse()


# Generated at 2022-06-17 06:05:59.503108
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module and args
    task_ds = {'action': 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module and args
    task_ds = {'action': 'copy', 'args': 'src=a dest=b'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'

# Generated at 2022-06-17 06:06:13.477592
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b'
        }
    }
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b'
        }
    }
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()

# Generated at 2022-06-17 06:06:23.999275
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module and args
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module and args
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

   

# Generated at 2022-06-17 06:06:36.584402
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:41.641605
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()
    # Test the parse method
    module_args_parser.parse()


# Generated at 2022-06-17 06:06:51.416154
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:06:59.741933
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:13.411710
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has action and local_action
    task_ds = {'action': 'echo hi', 'local_action': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "action and local_action are mutually exclusive" in str(excinfo.value)

    # Test with a task that has action and module
    task_ds = {'action': 'echo hi', 'module': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "conflicting action statements" in str(excinfo.value)

    # Test with a task that has local_action and module


# Generated at 2022-06-17 06:07:26.437083
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None

# Generated at 2022-06-17 06:07:37.687710
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    task_ds = {
        'action': {
            'module': 'copy src=a dest=b'
        },
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action

# Generated at 2022-06-17 06:08:02.758810
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {
        'name': 'test',
        'action': 'shell echo hi'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task with a module
    task_ds = {
        'name': 'test',
        'shell': 'echo hi'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task with a module and args

# Generated at 2022-06-17 06:08:09.130919
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}

# Generated at 2022-06-17 06:08:22.100742
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:08:32.990899
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:35.464606
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Implement unit test for method parse of class ModuleArgsParser
    pass


# Generated at 2022-06-17 06:08:44.538192
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == (None, {}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:51.059012
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:09:03.517885
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:17.642781
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    collection_list = None

# Generated at 2022-06-17 06:09:26.147695
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:43.107935
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:58.788290
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = dict(action='shell echo hi')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser.parse() == ('shell', dict(_raw_params='echo hi', _uses_shell=True), Sentinel)

    # Test with task_ds and skip_action_validation
    task_ds = dict(action='shell echo hi')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-17 06:10:08.135637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

# Generated at 2022-06-17 06:10:17.263529
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:10:29.048865
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'echo'
    assert args == {'_raw_params': 'hi'}
    assert delegate_to is None

    # Test with local_

# Generated at 2022-06-17 06:10:32.501980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:10:43.910697
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test with empty task_ds
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, {}, None)

    # test with task_ds with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # test with task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # test with task_ds with module
    task_ds = {'module': 'shell echo hi'}

# Generated at 2022-06-17 06:10:57.603911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds that has action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # Test with a task_ds that has action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # Test with a task_ds that has action and local_action

# Generated at 2022-06-17 06:11:13.111812
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:17.000027
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:11:33.039972
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action and args
    task_ds = {
        'action': 'copy src=a dest=b'
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with action and args


# Generated at 2022-06-17 06:11:43.168018
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task_ds with action and delegate_to
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}

# Generated at 2022-06-17 06:11:47.389836
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == None


# Generated at 2022-06-17 06:11:56.671127
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:12:10.455055
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)