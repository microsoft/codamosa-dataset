

# Generated at 2022-06-17 06:02:27.310031
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:02:37.752033
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 06:02:43.434248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse()
    #
    # Test the parse method of the ModuleArgsParser class.
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    ###########################################################################
    #
    # Test the parse method of the ModuleArgsParser class.
    #
    ###########################################################################

    # Create a task dictionary.
    task_ds = dict()

    # Create an instance of the ModuleArgsParser class.
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    # Test the parse method.
    #
    # The parse method should raise an AnsibleParserError exception because
    # the task dictionary is empty.
    with pytest.raises(AnsibleParserError) as exception_info:
        module_args_parser

# Generated at 2022-06-17 06:02:57.791121
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:05.239828
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:13.802266
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:21.383504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # Test with a valid task_ds
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi', 'chdir': '/tmp'}, 'localhost')

    # Test with an invalid task_ds

# Generated at 2022-06-17 06:03:30.507669
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with empty task_ds
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser

# Generated at 2022-06-17 06:03:36.603901
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleT

# Generated at 2022-06-17 06:03:46.624680
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:09.642846
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with valid input
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with invalid input
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:04:17.120005
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None

# Generated at 2022-06-17 06:04:28.211051
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_task_ds_is_not_dict
    task_ds = []
    collection_list = None
    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds, collection_list).parse()
    assert "the type of 'task_ds' should be a dict, but is a <class 'list'>" in to_text(excinfo.value)

    # test_thing_is_dict
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list = None
    action, args, delegate_to = ModuleArgsParser(task_ds, collection_list).parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}


# Generated at 2022-06-17 06:04:36.224312
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:04:45.843184
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.template import Templar
   

# Generated at 2022-06-17 06:04:55.708130
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:00.637478
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError):
        parser.parse()
    # Test with a module
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None
    # Test with a module and a delegate_to
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
   

# Generated at 2022-06-17 06:05:09.017497
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)
    # test case 1
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:05:19.622273
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:05:29.573083
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:05:48.036578
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:00.391126
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:14.422350
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has no module specified
    task_ds = {}
    parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError) as excinfo:
        parser.parse()
    assert "no module/action detected in task." in str(excinfo.value)

    # Test with a task that has a module specified
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is Sentinel

    # Test with a task that has a module specified and a delegate_to

# Generated at 2022-06-17 06:06:20.049011
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('echo', {'_raw_params': 'hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:06:34.269058
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:40.811205
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:06:42.803248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:06:55.739557
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:10.763974
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:25.219488
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:06.731942
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.when import When
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.filevars import FileVars
    from ansible.playbook.vars.groupvars import GroupVars

# Generated at 2022-06-17 06:08:13.143888
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:24.681488
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:08:30.630805
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b'
        }
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')


# Generated at 2022-06-17 06:08:44.746051
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no action
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None


# Generated at 2022-06-17 06:08:51.143596
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module_name
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with module_name
    task_ds = {'action': 'shell echo hi', 'module_name': 'shell'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action

# Generated at 2022-06-17 06:09:02.128621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:09:09.556869
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:23.580792
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    task_ds = {
        'action': {
            'module': 'shell',
            'args': 'echo hi'
        },
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }

# Generated at 2022-06-17 06:09:39.065229
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:07.406567
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')
    # Test with action and local_action and delegate_to
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')
    # Test with action and delegate_to

# Generated at 2022-06-17 06:10:17.233271
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    module

# Generated at 2022-06-17 06:10:27.046350
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

# Generated at 2022-06-17 06:10:38.883621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import to

# Generated at 2022-06-17 06:10:45.375357
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with args
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with args

# Generated at 2022-06-17 06:10:58.377708
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:13.357954
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:11:19.841125
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:25.229064
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:33.398526
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    obj = ModuleArgsParser(task_ds=task_ds)