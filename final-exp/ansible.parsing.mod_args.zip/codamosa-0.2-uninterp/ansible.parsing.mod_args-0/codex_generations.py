

# Generated at 2022-06-17 06:02:42.019583
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with a valid task
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}, 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    # Test with a valid task

# Generated at 2022-06-17 06:02:50.648296
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:03:00.673886
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action and local_action
    task_ds = {'action': 'shell echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:03:16.004646
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = []
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = []
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': {'echo': 'hi'}}
    collection_list = []
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:03:32.307433
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:39.565068
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has no module specified
    task_ds = {
        'name': 'test task',
        'tags': ['test']
    }
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test with a task that has an invalid module specified
    task_ds = {
        'name': 'test task',
        'tags': ['test'],
        'invalid_module': 'test'
    }
    parser = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        parser.parse()

    # Test with a task that has a valid module specified

# Generated at 2022-06-17 06:03:52.059367
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with args
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with args
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module

# Generated at 2022-06-17 06:03:56.256219
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(args='echo hi')
    assert delegate_to is None

    # Test with a valid task
    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(args='echo hi')
    assert delegate_to is None

    # Test with a valid task
    task_ds = dict(action=dict(module='shell', args='echo hi'))
   

# Generated at 2022-06-17 06:04:02.617230
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:13.308857
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with module
    task_ds = {'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with module and args

# Generated at 2022-06-17 06:04:23.894197
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    res = module_args_parser.parse()

# Generated at 2022-06-17 06:04:33.638637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost', 'args': {'x': 1}}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:04:46.651272
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a task that has a local_action and a delegate_to
    task_ds = {'local_action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse

# Generated at 2022-06-17 06:04:56.029488
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:06.853591
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    module

# Generated at 2022-06-17 06:05:13.177627
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:05:24.021311
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:26.722483
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:05:29.405855
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:05:41.536449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test case 1
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:05:59.820935
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:06.201203
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:06:15.229053
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:25.937449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi', 'delegate_to': 'localhost', 'other': 'value'}
    parser = ModuleArgsParser(task_ds)
   

# Generated at 2022-06-17 06:06:37.620267
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:06:53.223639
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method
    assert module_args_parser.parse() == (None, None, None)
    # Test the parse method

# Generated at 2022-06-17 06:07:02.755701
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module name and some arguments
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module name and some arguments, but the
    # arguments are in a dictionary
    task_ds = {'action': {'module': 'copy src=a dest=b'}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}


# Generated at 2022-06-17 06:07:15.356364
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:07:25.712706
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:37.377729
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:07:48.998628
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:04.205797
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:17.764493
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module name
    task_ds = {}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with no module name and args
    task_ds = {'args': {'a': 'b'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with module name and no args
    task_ds = {'action': 'shell'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', dict(), Sentinel)

    # Test with module name and args
    task_ds = {'action': 'shell echo hi'}

# Generated at 2022-06-17 06:08:26.270846
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:34.032507
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 06:08:38.468270
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:48.411471
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module name and a dictionary of arguments
    task_ds = {'module': {'x': 1}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'module'
    assert args == {'x': 1}
    assert delegate_to is None

    # Test with a task that has a module name and a string of arguments
    task_ds = {'module': 'x=1'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'module'
    assert args == {'x': 1}
    assert delegate_to is None

    # Test with a task that has a module name and a string of arguments

# Generated at 2022-06-17 06:09:02.135886
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == Sentinel

    # test case 2
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == Sentinel

    # test

# Generated at 2022-06-17 06:09:08.016204
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:20.587245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module and args
    task_ds = {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module and args and delegate_to
    task_ds = {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}, 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'

# Generated at 2022-06-17 06:09:39.308962
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b'
        }
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')

    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': 'src=a dest=b'
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:09:47.730159
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:01.218255
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': 'echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task

# Generated at 2022-06-17 06:10:03.522523
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:10:16.637177
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:10:18.096273
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:10:30.776226
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:39.414861
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:45.755849
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:58.533461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vault_include import VaultInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 06:11:12.830621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with args

# Generated at 2022-06-17 06:11:19.639090
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None
    module

# Generated at 2022-06-17 06:11:34.037173
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:43.984365
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:11:52.192967
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:12:02.336906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'x': 1,
            'y': 2
        }
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b', 'x': 1, 'y': 2}, 'localhost')


# Generated at 2022-06-17 06:12:12.418578
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import split_args
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import iter