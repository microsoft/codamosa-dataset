

# Generated at 2022-06-17 06:02:39.065332
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:02:44.387837
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.handlers import Handlers
    from ansible.playbook.role.defaults import Defaults
    from ansible.playbook.role.vars import Vars

# Generated at 2022-06-17 06:02:54.854432
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

# Generated at 2022-06-17 06:03:02.980371
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None

# Generated at 2022-06-17 06:03:17.030937
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'test'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'test'
    assert args == {}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'test'}
    collection_list = None
    module

# Generated at 2022-06-17 06:03:27.615361
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:03:38.285616
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:51.485796
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:04:05.097728
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    #

# Generated at 2022-06-17 06:04:14.263448
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with task_ds

# Generated at 2022-06-17 06:04:35.551425
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-17 06:04:49.480543
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module specified
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with module specified
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with module specified
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse

# Generated at 2022-06-17 06:04:57.089572
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy', 'args': 'src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-17 06:05:07.691903
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:21.081691
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test 1
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # test

# Generated at 2022-06-17 06:05:30.423939
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module name
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, None)

    # Test with module name
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with module name and delegate_to
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:05:40.366050
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None

# Generated at 2022-06-17 06:05:41.937384
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 06:05:48.651993
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:06:00.646470
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:23.668747
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task

# Generated at 2022-06-17 06:06:35.527829
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of ModuleArgsParser
    module_args_parser = ModuleArgsParser()

    # Create a task_ds
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
        'args': {
            'src': 'a',
            'dest': 'b'
        }
    }

    # Call method parse of class ModuleArgsParser
    action, args, delegate_to = module_args_parser.parse(task_ds)

    # Asserts
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-17 06:06:51.056484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    # test case 1
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

# Generated at 2022-06-17 06:07:05.102485
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None

# Generated at 2022-06-17 06:07:16.255393
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid task
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a valid task

# Generated at 2022-06-17 06:07:27.592265
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no action
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    #

# Generated at 2022-06-17 06:07:37.788866
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:47.350666
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:02.519285
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:08:10.957950
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, dict(), Sentinel)
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, Sentinel)
    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy', 'args': 'src=a dest=b'})

# Generated at 2022-06-17 06:08:35.464082
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:08:44.538436
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs = frozenset(task_attrs)

    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_attrs.update(['local_action', 'static'])

    # We can have one of action, local_action, or module specified
    # action
    if 'action' in task_attrs:
        # an old school 'action' statement
        thing = task_attrs['action']
        action, args = self._normalize_

# Generated at 2022-06-17 06:08:56.177080
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse()
    #
    #   Unit test for method parse of class ModuleArgsParser
    #

    # Create a ModuleArgsParser object
    parser = ModuleArgsParser()

    # Test case 1:
    #   action: copy src=a dest=b
    #   expected result:
    #       action: copy
    #       args:
    #           src: a
    #           dest: b
    task_ds = {'action': 'copy src=a dest=b'}
    action, args, delegate_to = parser.parse(task_ds)
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test case 2:
    #   action: copy
    #   args:
    #       src

# Generated at 2022-06-17 06:09:06.565064
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a dict
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a string
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'copy'

# Generated at 2022-06-17 06:09:13.107231
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:09:24.982832
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 06:09:39.435805
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no module specified
    task_ds = {}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, Sentinel)

    # Test with action specified
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action specified
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with module specified

# Generated at 2022-06-17 06:09:48.087630
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:09:58.213137
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a mock task_ds
    task_ds = {'action': 'shell echo hi'}
    # Create a mock collection_list
    collection_list = None
    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    # Call method parse
    action, args, delegate_to = module_args_parser.parse()
    # Assert the result
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None


# Generated at 2022-06-17 06:10:07.505168
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and collection_list
    task_ds = {'action': 'shell echo hi'}
    collection_list = ['ansible.builtin']
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:10:33.028530
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:10:43.949901
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    result = obj.parse()
    assert result == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    result = obj.parse()
    assert result == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    collection_list = None

# Generated at 2022-06-17 06:10:57.638801
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}, 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'chdir': '/tmp'}
    assert delegate_to is None

   

# Generated at 2022-06-17 06:11:13.112893
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:19.742798
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': 'echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None

# Generated at 2022-06-17 06:11:25.171745
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with no module
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, {}, None)

    # Test with a task with a module and no args
    task_ds = {'action': 'ping'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('ping', {}, None)

    # Test with a task with a module and args
    task_ds = {'action': 'ping', 'args': {'data': 'foo'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('ping', {'data': 'foo'}, None)

    # Test with a task with a module and args

# Generated at 2022-06-17 06:11:37.200425
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:49.326610
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with task_ds and collection_list
    task_ds

# Generated at 2022-06-17 06:11:57.463415
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:12:10.604008
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with args
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with args