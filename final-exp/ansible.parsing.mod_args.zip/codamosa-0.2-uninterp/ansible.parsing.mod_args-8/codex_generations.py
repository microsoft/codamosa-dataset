

# Generated at 2022-06-17 06:02:33.825412
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == (None, {}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with args
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:02:43.826942
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:02:51.974871
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-17 06:03:01.329342
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:03:16.669412
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:03:32.961974
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has an action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with a task that has a local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with a task that has a module
    task_ds = {'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    #

# Generated at 2022-06-17 06:03:44.742710
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:03:55.548935
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:04:09.561813
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:04:24.120738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': 'chdir=/tmp'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', 'chdir': '/tmp'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:04:47.127236
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with local_action

# Generated at 2022-06-17 06:04:54.430673
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:04:59.967627
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:07.277794
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    task_ds = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

# Generated at 2022-06-17 06:05:10.322262
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-17 06:05:11.593029
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass

# Generated at 2022-06-17 06:05:24.535152
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with task_ds as dict
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with task_ds as string
    task_ds = 'test'
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, Sentinel)

    # Test with task_ds as dict

# Generated at 2022-06-17 06:05:32.870405
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:44.616262
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:05:58.818400
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:18.003069
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse()
    # Test the parse method of the ModuleArgsParser class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    #
    # Examples:
    #     None
    #
    # TODO:
    #     None

    ################################################################################
    # Test the parse method of the ModuleArgsParser class
    ################################################################################

    # Create a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()

    # Test the parse method of the ModuleArgsParser class
    # Test the parse method of the ModuleArgsParser class
    # Test the parse method of the ModuleArgsParser class
    # Test the parse method of the ModuleArgsParser class
    # Test the parse

# Generated at 2022-06-17 06:06:31.222688
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with valid data
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with invalid data
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() != ('shell', {'_raw_params': 'echo hi'}, 'localhost')


# Generated at 2022-06-17 06:06:39.717647
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:06:54.101816
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:08.841303
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:07:18.228592
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:28.165411
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = obj.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-17 06:07:37.953195
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:07:48.622663
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:08:03.803016
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    task_ds = dict(action='shell echo hi')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', dict(_raw_params='echo hi', _uses_shell=True), Sentinel)

    task_ds = dict(action='shell echo hi', delegate_to='localhost')
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:08.935834
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:08:21.863028
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid task
    task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}, 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    # Test with a valid task
    task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'chdir': '/tmp'}
   

# Generated at 2022-06-17 06:08:32.906723
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, None, None)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:08:43.442411
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    task_ds = {
        'action': {
            'module': 'shell',
            'args': 'echo hi'
        },
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args,

# Generated at 2022-06-17 06:08:53.881125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid action
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    # Test with a valid local_action
    task_ds = {'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # Test with a valid module
    task_ds = {'shell': 'echo hi'}
    parser = Module

# Generated at 2022-06-17 06:09:02.481269
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_finder import _get_collection_artifact_dirs
    from ansible.utils.collection_loader._collection_finder import _get_collection_artifact_dirs_from_paths
    from ansible.utils.collection_loader._collection_finder import _get_collection_artifact_dirs_from_env
    from ansible.utils.collection_loader._collection_finder import _get_collection_artifact_dirs_from_config
    from ansible.utils.collection_loader._collection_finder import _get_collection_art

# Generated at 2022-06-17 06:09:08.255905
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', 'chdir': '/tmp'}
    assert delegate_to == 'localhost'

    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'

# Generated at 2022-06-17 06:09:20.811911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task that has a module name and args
    task_ds = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test with a task that has a module name and args
    task_ds = {'action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

# Generated at 2022-06-17 06:09:26.948351
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    parser = ModuleArgsParser()
    assert parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and skip_action_validation
    task_ds = {'action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse(skip_action_validation=True) == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds and delegate_to

# Generated at 2022-06-17 06:09:41.126464
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'shell'
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
    module_args

# Generated at 2022-06-17 06:09:57.897682
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-17 06:09:59.158352
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:10:08.296761
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse()
    #
    # Test the parse method of the ModuleArgsParser class.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test 1:
    #
    # Test the parse method of the ModuleArgsParser class with a task
    # that has no action.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Setup
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    # Test

# Generated at 2022-06-17 06:10:17.284776
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:18.855625
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: this test is incomplete
    pass

# Generated at 2022-06-17 06:10:29.898747
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == (None, dict(), Sentinel)

    # Test with args
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test with args
    task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:10:39.100599
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    task_ds = None
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == (None, {}, None)

    # Test with task_ds with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test with task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:10:45.554460
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:10:58.441809
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no task_ds
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with task_ds with action
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with task_ds with local_action
    task_ds = {'local_action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert module_args_parser.parse()

# Generated at 2022-06-17 06:11:13.357141
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-17 06:11:33.105782
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None

# Generated at 2022-06-17 06:11:43.249985
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, dict(), Sentinel)

    # Test with action
    task_ds = {'action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)

    # Test with local_action
    task_ds = {'local_action': 'shell echo hi'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

# Generated at 2022-06-17 06:11:49.465132
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleT

# Generated at 2022-06-17 06:11:57.464339
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a task with action and local_action
    task_ds = {'action': 'echo hi', 'local_action': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {'_raw_params': 'hi'}, 'localhost')

    # Test with a task with action and module
    task_ds = {'action': 'echo hi', 'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {'_raw_params': 'hi'}, Sentinel)

    # Test with a task with local_action and module
    task_ds = {'local_action': 'echo hi', 'module': 'shell echo hi'}
    parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-17 06:12:10.604186
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with no args
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == (None, {}, None)

    # Test with action
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test with local_action
    task_ds = {'local_action': 'copy src=a dest=b'}
    collection_list = None