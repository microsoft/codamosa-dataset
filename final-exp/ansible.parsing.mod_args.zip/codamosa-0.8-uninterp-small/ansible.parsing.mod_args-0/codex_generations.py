

# Generated at 2022-06-25 03:48:35.071594
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()

# Generated at 2022-06-25 03:48:38.336780
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    pass

# Generated at 2022-06-25 03:48:48.864810
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    thing_0 = {}

    # test case 0
    additional_args_0 = {}
    action_0 = None
    args_0 = module_args_parser_0._normalize_parameters(thing_0, action=action_0, additional_args=additional_args_0)
    assert(args_0[0] == 'null')
    assert(args_0[1] == {})

    thing_1 = ''

    # test case 1
    additional_args_1 = {}
    action_1 = None
    args_1 = module_args_parser_0._normalize_parameters(thing_1, action=action_1, additional_args=additional_args_1)
    assert(args_1[0] == 'null')

# Generated at 2022-06-25 03:48:52.915972
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # construct a object
    module_args_parser_1 = ModuleArgsParser()

    # test attribute assignment
    module_args_parser_1.resolved_action = None

    # construct a object
    module_args_parser_2 = ModuleArgsParser()

    # test attribute assignment
    module_args_parser_2.resolved_action = None

    # test method call
    assert module_args_parser_2.parse() == module_args_parser_1.parse()
    print("ModuleArgsParser_parse() passed")


# Generated at 2022-06-25 03:48:55.337374
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    casepath = os.getcwd()
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {}
    action, args = module_args_parser_0.parse(skip_action_validation=True)

# Generated at 2022-06-25 03:48:59.508775
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = dict()
    skip_action_validation_0 = False
    attributes_0 = module_args_parser_0.parse(task_ds_0, skip_action_validation_0)


# Generated at 2022-06-25 03:49:05.339475
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    arg1_0 = ''
    arg2_0 = ''
    arg3_0 = ''

    try:
        result_0 = module_args_parser_0.parse(arg1_0, arg2_0, arg3_0)
        assert isinstance(result_0, tuple)
    except error.AnsibleParserError as e:
        print('Error:', e.message)
        return False
    else:
        return True


# Generated at 2022-06-25 03:49:14.613174
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # testcase 1:
    # For the following dict:
    #   dict = {'action': {'module': 'echo hello', 'x': 1}}
    # The expected module name: 'echo'
    # The expected args dict: {'x': 1, '_raw_params': 'hello'}
    module_args_parser = ModuleArgsParser()
    test_dict = {'action': {'module': 'echo hello', 'x': 1}}
    action, args, delegate_to = module_args_parser.parse(test_dict)
    assert action == 'echo'
    assert args['x'] == 1
    assert args['_raw_params'] == 'hello'

    # testcase 2:
    # For the following dict:
    # dict

# Generated at 2022-06-25 03:49:20.005235
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Task definition
    task_ds_0 = dict(action=dict(module=dict(action='echo hi', delegate_to='localhost')))

    # ModuleArgumentsParser instanciation
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_0)

    # Parsing the task_ds_0
    (action, args, delegate_to) = module_args_parser_1.parse()

    assert action == 'echo'
    assert args == {'action': 'hi'}
    assert delegate_to == 'localhost'



# Generated at 2022-06-25 03:49:28.413569
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action="action1")
    parser_0 = ModuleArgsParser(task_ds)
    tuple_0 = parser_0.parse()
    assert tuple_0[0] == "action1"
    assert tuple_0[1] == {}
    assert tuple_0[2] == Sentinel


# Generated at 2022-06-25 03:49:59.337661
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    print(module_args_parser.parse())


if __name__ == '__main__':
    # test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:50:06.229832
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

# Generated at 2022-06-25 03:50:15.511238
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {}
    collection_list_0 = []
    module_args_parser_0.parse(skip_action_validation=False)
    assert module_args_parser_0.parse(skip_action_validation=False, ) == (None, None, None)
    task_ds_1 = {'action': 'copy src=a dest=b'}
    module_args_parser_1 = ModuleArgsParser(task_ds_1, collection_list_0)
    assert module_args_parser_1.parse(skip_action_validation=False, ) == ('copy', {'dest': 'b', 'src': 'a'}, None)

# Generated at 2022-06-25 03:50:20.408316
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_ds = {
        "module": "shell",
        "args": "echo hello",
    }
    module_args_parser = ModuleArgsParser(task_ds=fake_ds)
    # call the tested method
    module_args_parser.parse()
    assert module_args_parser._task_ds["module"] == 'shell'
    assert module_args_parser._task_ds["args"] == 'echo hello'

# Generated at 2022-06-25 03:50:20.863779
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert(False)

# Generated at 2022-06-25 03:50:26.003133
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Starting with the simplest case for an action
    task_dict = {'action': 'shell', 'args': {'_raw_params': 'echo hi'}}
    task = ModuleArgsParser(task_ds=task_dict)
    assert task.parse() == ('shell', {'_raw_params': 'echo hi'}, None)

    # Test simple modules with a mix of named and positional args
    task_dict = {'module': 'file', 'args': {'path': '/tmp/foo'}}
    task = ModuleArgsParser(task_ds=task_dict)
    assert task.parse() == ('file', {'path': '/tmp/foo'}, None)

    task_dict = {'module': 'file', 'args': {'path': '/tmp/foo', 'owner': 'root', 'group': 'wheel'}}
    task

# Generated at 2022-06-25 03:50:29.366290
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser_1 = ModuleArgsParser({'module': 'copy', 'args': 'src=a dest=b'},
        collection_list={'ansible.builtin': {'module': {'copy': 'ansible.builtin.copy'}, 'module_utils': {}}})
    (action_1, args_1, delegate_to) = module_args_parser_1.parse()
    assert(action_1 == 'copy')
    assert(args_1['src'] == 'a')
    assert(args_1['dest'] == 'b')


# Generated at 2022-06-25 03:50:40.274263
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # --verbosity=1
    module_args_parser_1 = ModuleArgsParser()
    dict_test_case_1 = {'name': 'foo', 'action': {'shell': 'echo hi'}}
    (action, args, delegate_to) = module_args_parser_1.parse(dict_test_case_1)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None
    # --verbosity=1
    module_args_parser_2 = ModuleArgsParser()
    dict_test_case_2 = {'name': 'foo', 'action': {'module': 'shell', 'args': {'_raw_params': 'echo hi'}}}

# Generated at 2022-06-25 03:50:43.627084
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Testing with dict as input of method parse
    task_ds = dict()
    result = module_args_parser_0.parse(task_ds)
    assert result == (None, {}, Sentinel)


# Generated at 2022-06-25 03:50:51.837850
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.path.join(os.path.dirname(__file__), "data/ansible_collections")
    collection_list = AnsibleCollectionRef.load_collections(os.path.join(os.path.dirname(__file__), "data/ansible_collections"))

    # Test the following module args
    # action: shell echo "foo"
    kwargs = dict(
        task_ds = dict(action = 'shell echo "foo"'),
        collection_list = collection_list
    )
    module_args_parser_0 = ModuleArgsParser(**kwargs)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == 'shell'

# Generated at 2022-06-25 03:51:06.677505
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser_0 = ModuleArgsParser()

    res = module_args_parser_0.parse(skip_action_validation=False)
    assert res == {'_uses_shell': True}

    module_args_parser_1 = ModuleArgsParser()
    res = module_args_parser_1.parse(skip_action_validation=True)
    assert res is None

    # Unit test for method normalize_old_style_args of class ModuleArgsParser
    # fixture test_case_0()
    test_case_0()
    res = module_args_parser_0.normalize_old_style_args('shell echo hi')
    assert res == [
        'shell', {'_raw_params': 'echo hi', '_uses_shell': True}
    ]



# Generated at 2022-06-25 03:51:12.788290
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}, 'delegate_to': 'localhost'}
    result = module_args_parser_1.parse(task_ds)
    assert_equals(result[0], 'shell')
    assert len(result[1]) == 3
    assert_equals(result[1]['_raw_params'], 'echo hi')
    assert_equals(result[1]['_uses_shell'], True)
    assert_equals(result[1]['chdir'], '/root')
    assert_equals(result[2], 'localhost')


# Generated at 2022-06-25 03:51:20.228006
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    d = dict()
    d['action'] = '{"module": "shell", "_uses_shell": "true", "_raw_params": "echo hi"}'
    d['delegate_to'] = 'localhost'
    d['args'] = '{"_raw_params": "echo bye"}'

    module_args_parser = ModuleArgsParser(task_ds=d)
    (action, args, delegate_to) = module_args_parser.parse()

    assert action == 'shell'
    assert args['_uses_shell'] == 'true'
    assert args['_raw_params'] == 'echo bye'
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:51:30.107215
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def module_args_parser_parse_check(task_ds):
        module_args_parser = ModuleArgsParser(task_ds)
        return module_args_parser.parse()

    # Case 0
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, {}, None)

    # Case 1
    task_ds_1 = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    assert module_args_parser_parse_check(task_ds_1) == ('copy', {'dest': 'b', 'src': 'a'}, None)

    # Case 2
    task_ds_2 = {'action': 'copy src=a dest=b'}

# Generated at 2022-06-25 03:51:43.144034
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser(task_ds={'action': {'module': 'shell', 'warn': False}})
    module_args_parser_1.parse()
    assert module_args_parser_1._task_ds == {'action': {'module': 'shell', 'warn': False}}
    assert module_args_parser_1._collection_list == None

    module_args_parser_2 = ModuleArgsParser(task_ds={'action': {'module': 'shell', 'warn': False}}, collection_list=['/home/mubarak/ansible/mubaraks-ansible-awx/awx/plugins/collections'])
    module_args_parser_2.parse()

# Generated at 2022-06-25 03:51:50.897013
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test data for method parse of class ModuleArgsParser
    things_0 = {}
    things_0['skip_action_validation'] = True
    things_0['test'] = {'action': 'test-module', 'args': {'_raw_params': 'echo hi', '_uses_shell': True}, 'delegate_to': 'localhost'}
    things_0['test-module'] = {'args': {'_raw_params': 'echo hi', '_uses_shell': True}}
    things_0['shell'] = {'args': {'_raw_params': 'echo hi', '_uses_shell': True}}
    things_0['command'] = {'args': {'chdir': '/tmp'}}

# Generated at 2022-06-25 03:51:54.838291
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    parser_out_1 = module_args_parser_1.parse()


# Generated at 2022-06-25 03:51:56.668176
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser()
    assert 'ping' == module_arg_parser.parse()[0]


# Generated at 2022-06-25 03:52:00.311093
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # - module: echo hi
    #   args:
    #     chdir: /tmp
    #
    #   - shell: echo hi
    #     args:
    #       chdir: /tmp
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()


# Generated at 2022-06-25 03:52:07.018495
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    test_cases = [
        (
            {'action': 'shell echo hi'},
            ('shell', {'_raw_params': 'echo hi'}, None)
        )
    ]

    for test_case in test_cases:

        module_args_parser = ModuleArgsParser(task_ds=test_case[0])
        actual_result = module_args_parser.parse()

        assert actual_result == test_case[1]

# Generated at 2022-06-25 03:52:18.126204
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # set up for the test.
    module_args_parser_1 = ModuleArgsParser()
    # test for the case when 'action' is specified in the task_ds.
    task_ds_1 = {'name': 'Task 19', 'ignore_errors': 'yes', 'delegate_to': 'localhost', 'action': 'copy src=a dest=b'}
    actual_result_1 = module_args_parser_1.parse(task_ds_1)
    expected_result_1 = ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
    assert actual_result_1 == expected_result_1
    # test for the case when 'local_action' is specified in the task_ds.

# Generated at 2022-06-25 03:52:24.028218
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # test case 0
    task_ds_0 = dict(action='shell echo hi')
    (action_0, args_0, delegate_to_0) = module_args_parser.parse(task_ds_0)
    assert (action_0, args_0, delegate_to_0)  == ('shell', { '_raw_params': 'echo hi' }, Sentinel)

    # test case 1
    task_ds_1 = dict(action=dict(module='shell echo hi'))
    (action_1, args_1, delegate_to_1) = module_args_parser.parse(task_ds_1)
    assert (action_1, args_1, delegate_to_1)  == ('shell', { '_raw_params': 'echo hi' }, Sentinel)



# Generated at 2022-06-25 03:52:29.855016
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    test parse method of class ModuleArgsParser
    '''
    # initialize test data
    with open('test/unittest/files/ModuleArgsParser.yml') as f:
        ModuleArgsParser_test_data = yaml.safe_load(f)
    # initialize test object
    module_args_parser_0 = ModuleArgsParser()
    # check
    for action_item in ModuleArgsParser_test_data['action_list']:
        module_args_parser_0.parse(action_item)


# Generated at 2022-06-25 03:52:37.605853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a module_args_parser_obj of class ModuleArgsParser
    module_args_parser_obj = ModuleArgsParser()


# Generated at 2022-06-25 03:52:48.942403
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test 1: test with dictionary as input.
    '''
    module_args_parser_1 = ModuleArgsParser()
    expected_action = 'shell'
    expected_args = { '_raw_params': 'echo hi' }
    expected_delegate_to = 'localhost'
    action, args, delegate_to = module_args_parser_1.parse(skip_action_validation=True)
    # Test 1: ModuleArgsParser.parse()
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to
    # Test 2: ModuleArgsParser.parse()
    expected_action = 'shell'
    expected_args = { '_raw_params': 'echo hi', 'a': 'b' }
    expected_delegate_to = 'localhost'


# Generated at 2022-06-25 03:52:56.967193
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Set up test objects
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_2 = ModuleArgsParser()
    module_args_parser_3 = ModuleArgsParser()
    module_args_parser_4 = ModuleArgsParser()
    module_args_parser_5 = ModuleArgsParser()
    module_args_parser_6 = ModuleArgsParser()
    module_args_parser_7 = ModuleArgsParser()
    module_args_parser_8 = ModuleArgsParser()
    module_args_parser_9 = ModuleArgsParser()
    module_args_parser_10 = ModuleArgsParser()
    module_args_parser_11 = ModuleArgsParser()
    module_args_parser_12 = ModuleArgsParser()
    module_args_parser_13 = Module

# Generated at 2022-06-25 03:53:02.560377
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_1 = ModuleArgsParser()
    # Test using invalid type for argument skip_action_validation
    try:
        module_args_parser_1.parse("skip_action_validation")
    except:
        pass
    else:
        print("Passed test with skip_action_validation = \"skip_action_validation\"")


# Generated at 2022-06-25 03:53:06.761956
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test parse method of class ModuleArgsParser
    """
    # Testing ModuleArgsParser.parse using test case 0
    dict_0 = {'action': 'shell echo hi'}
    action_0, args_0, delegate_to_0 = ModuleArgsParser(task_ds=dict_0).parse()
    assert action_0 == 'shell'
    assert args_0 == {'_raw_params': 'echo hi'}
    assert delegate_to_0 is Sentinel


# Generated at 2022-06-25 03:53:12.705917
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # This is the standard YAML form for command-type modules. We grab
    # the args and pass them in as additional arguments, which can/will
    # be overwritten via dict updates from the other arg sources below
    additional_args = dict()
    additional_args['chdir'] = '/tmp'

    task_ds = dict()
    # an old school 'action' statement
    thing = 'echo hi'
    task_ds['action'] = thing

    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse()
    
    assert action == 'echo hi'
    assert args == dict()
    assert delegate_to == Sentinel

    del task_ds['action']
    del additional_args['chdir']

    # local_action is similar but also implies a delegate_to

# Generated at 2022-06-25 03:53:24.383262
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #print("\n\n")
    #print("======== test_ModuleArgsParser_parse ========")

    module_args_parser_0 = ModuleArgsParser()
    action, module_args, delegate_to = module_args_parser_0.parse({"copy": {"dest": "a", "src": "b"}})
    print("delegate_to: " + str(delegate_to))
    print("action: " + action)
    for key, value in module_args.items():
        print("{}: {}".format(key, value))

    assert action == "copy"
    assert module_args["dest"] == "a"
    assert module_args["src"] == "b"

    # TODO: test with_items
    # TODO: test _raw_params


# Generated at 2022-06-25 03:53:43.670149
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # input data for testcase
    test_case_0_task_ds = {}
    test_case_0_skip_action_validation = False
    test_case_0_expected_output = ('test6', {}, Sentinel())

    # Input data for testcase
    test_case_1_task_ds = {'action': 'test3 module_args=a1=1'}
    test_case_1_skip_action_validation = False
    test_case_1_expected_output = ('test3', {'module_args': 'a1=1'}, Sentinel())

    # Input data for testcase
    test_case_2_task_ds = {'local_action': 'test4  module_args=a1=1'}
    test_case_2_skip_action_validation = False
    test

# Generated at 2022-06-25 03:53:55.022998
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:06.452652
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict(action=dict(module='shell', args='echo hi'))
    parsed_args = ModuleArgsParser().parse(ds)
    assert parsed_args == (None, 'echo hi', None)

    ds = dict(action=dict(module='shell', args='echo hi'))
    parsed_args = ModuleArgsParser(ds).parse()
    assert parsed_args == (None, 'echo hi', None)

    ds = dict(action=dict(module='stuff', args='echo hi'))
    with pytest.raises(AnsibleParserError) as excinfo:
        parsed_args = ModuleArgsParser(ds).parse()
    assert "conflicting action statements: stuff, shell" in str(excinfo)

    ds = dict(action=dict(module='shell', args='echo hi', shell=None))

# Generated at 2022-06-25 03:54:08.129364
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()



# Generated at 2022-06-25 03:54:11.570640
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, {}, None)


if __name__ == '__main__':
    test_case_0()

    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:54:13.460165
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

# Generated at 2022-06-25 03:54:15.433061
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, None, None)


# Generated at 2022-06-25 03:54:25.398018
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # create an instance of the class to be tested
    module_args_parser = ModuleArgsParser()

    # test the parse method for an action: shell echo hi
    test_input = dict()
    test_input['action'] = 'shell echo hi'
    expected_output = ('shell', dict(_raw_params='echo hi', _uses_shell=True))
    actual_output = module_args_parser.parse(self=None, task_ds=test_input)
    assert actual_output == expected_output

    # test the parse method for an action: shell echo hi -a
    test_input = dict()
    test_input['action'] = 'shell echo hi -a'
    expected_output = ('shell', dict(_raw_params='echo hi -a', _uses_shell=True))

# Generated at 2022-06-25 03:54:32.266405
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = {
        'action': {
            'module': 'command'
        },
        'name': 'Check Process',
        'register': 'shell_out'
    }
    module_args_parser_0 = ModuleArgsParser(task_ds_0)
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse()
    assert action_0 == 'command'
    assert args_0 == {}
    assert delegate_to_0 == Sentinel


# Generated at 2022-06-25 03:54:33.526060
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    expected = None
    actual = None
    assert actual == expected


# Generated at 2022-06-25 03:54:58.354006
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    ###############
    # CASE 0
    ###############
    # setting up the task_ds
    task_ds_0_0 = 'echo hi'
    task_ds_0_1 = 'shell'
    task_ds_0_2 = {}
    task_ds_0_3 = {}
    task_ds_0_4 = None
    task_ds_0_5 = None
    task_ds_0_6 = None
    task_ds_0_7 = [
        '- name: Test task_ds 0',
        '  data:',
        '    a: 1',
        '    b: 2',
        '  action: shell echo hi',
        '  args:',
        '    chdir: /tmp',
        '  delegate_to: localhost'
    ]

    # creating the

# Generated at 2022-06-25 03:55:05.469605
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # module_data = {'yum': 'name=vsftpd state=present', 'raw': 'name=vsftpd state=present', 'ignore_errors': False, 'remote_user': 'root', 'register': 'vftp_pckg'}
    module_data = {}
    module_data_standardized = {'delegate_to': 'localhost'}
    module_args_parser_0 = ModuleArgsParser(module_data)
    result_0 = module_args_parser_0.parse()
    assert result_0 == module_data_standardized


# Generated at 2022-06-25 03:55:15.692504
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:55:19.110500
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    obj = ModuleArgsParser()
    skip_action_validation = False

    # Act
    obj.parse(skip_action_validation=skip_action_validation)


# Generated at 2022-06-25 03:55:25.304907
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task

    # Method call here
    module_args_parser = ModuleArgsParser()
    task = Task()
    task.register_loader()
    task.add_action('ping')
    result = module_args_parser.parse()
    assert result == ('ping', None, Sentinel)


# Generated at 2022-06-25 03:55:29.961723
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action = 'test'
    args = {'a': 'A', 'b': 'B', 'c': 'C'}
    delegate_to = 'fake_delegate_to'
    task_ds = {'delegate_to': delegate_to, 'action': args}
    action_result, args_result, delegate_to_result = module_args_parser.parse(task_ds)
    assert action_result == action
    assert args_result == args
    assert delegate_to_result == delegate_to


# Generated at 2022-06-25 03:55:37.549992
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test Case 0
    # Test Case 0
    # module_args_parser_0 = ModuleArgsParser()
    # initialize module_args_parser_0
    from ansible.module_utils.six import PY2
    if PY2:
      from collections import MutableMapping
      import UserDict
      class Dict(MutableMapping):
          ''' Dictionary with read-only access '''
          def __init__(self, *args, **kwargs):
              self.__dict__.update(*args, **kwargs)
          def __getitem__(self, item):
              return self.__dict__[item]
          def __setitem__(self, key, value):
              self.__dict__[key] = value

# Generated at 2022-06-25 03:55:49.551181
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {
            'module': 'copy',
            'src': '/etc/hosts',
            'dest': '/tmp/test_case_0'
        },
        'delegate_to': 'foo'
    }
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == "ansible.builtin.copy"

#@patch('ansible.cli.adhoc.AdHocCLI.run')
#def test_main(ansible_cli_adhoc_run):
#    ansible_cli_adhoc.main([])
#    assert ansible_cli_adhoc_run.called

if __name__ == '__main__':
    test_ModuleArgsParser_

# Generated at 2022-06-25 03:55:56.196632
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.action.normal import ActionModule
    from ansible.utils.import_module import import_module
    import ansible.module_utils
    module = 'ansible.module_utils.basic'
    loaded_module = import_module(module)
    assert isinstance(loaded_module, ModuleType)
    loaded_module_vars = vars(loaded_module)
    assert 'load_params' in loaded_module_vars

    action_module_vars = vars(ActionModule)
    assert 'run' in action_module_vars

    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1._task_ds = {'action': 'pwd'}
    action, args, delegate_to = module_args_parser_1.parse()

# Generated at 2022-06-25 03:56:05.116744
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Define a test task
    test_task_0      = {'with_items': '{{ items }}', 'action': {'module': 'ec2', 'region': 'xyz'}, 'local_action': {'module': 'ec2', 'region': 'xyz'}, 'delegate_to': 'localhost'}
    module_args_parser_0 = ModuleArgsParser(task_ds=test_task_0)
    expected_action_0      = 'ec2'
    expected_args_0       = {'region': 'xyz'}
    expected_delegate_to_0 = 'localhost'
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse()
    assert action_0 == expected_action_0
    assert args_0 == expected_args_0


# Generated at 2022-06-25 03:57:28.954535
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create the following task to be parsed:
    # - action: command
    #   args:
    #      creates: filepath
    #      chdir: /tmp
    #      executable: /bin/bash
    #      removes: /path/to/file
    task = {'action': 'command', 'args': {'creates': 'filepath', 'chdir': '/tmp', 'executable': '/bin/bash', 'removes': '/path/to/file'}}
    module_args_parser_0 = ModuleArgsParser(task)
    (action, args, delegate_to) = module_args_parser_0.parse()

    assert action == 'command'

# Generated at 2022-06-25 03:57:38.663326
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(task_ds={'module': 'shell', 'delegate_to': 'localhost', 'args': {'argv': 'echo hi'}})
    result = module_args_parser_0.parse()
    # assert that the result is of the correct type
    if not isinstance(result, tuple):
        raise AssertionError("'parse' should return a tuple, but returned a {0}".format(type(result)))
    if len(result) != 3:
        raise AssertionError("'parse' should return a tuple of length 3, but returned a tuple of length {0}".format(len(result)))
    assert type(result) == tuple
    assert len(result) == 3
    assert result[0] == 'shell'

# Generated at 2022-06-25 03:57:48.106082
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Checking for action without module_args
    module_args_parser_1 = ModuleArgsParser({"action": "copy"})
    action, module_args, delegate_to = module_args_parser_1.parse()
    assert action == "copy"
    assert module_args == {}

    module_args_parser_1 = ModuleArgsParser({"action": "copy action_args"})
    action, module_args, delegate_to = module_args_parser_1.parse()
    assert action == "copy"
    assert module_args == {"action_args": ""}

    # Checking for local_action with module_args
    module_args_parser_2 = ModuleArgsParser({"local_action": "copy"})
    action, module_args, delegate_to = module_args_parser_2.parse()

# Generated at 2022-06-25 03:57:59.868432
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:58:09.587164
# Unit test for method parse of class ModuleArgsParser