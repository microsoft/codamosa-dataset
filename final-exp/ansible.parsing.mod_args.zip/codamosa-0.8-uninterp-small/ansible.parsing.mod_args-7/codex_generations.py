

# Generated at 2022-06-25 03:48:56.713920
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser(
        task_ds={'action': {'module': 'something', 'args': 'arg1 arg2'},
                 'delegate_to': 'localhost'})
    result = module_args_parser_1.parse()
    assert result == ('something', {'args': 'arg1 arg2'}, 'localhost')
    module_args_parser_9 = ModuleArgsParser(
        task_ds={'action': 'something arg1 arg2', 'delegate_to': 'localhost'})
    result = module_args_parser_9.parse()
    assert result == ('something', {'arg1': 'arg2'}, 'localhost')

# Generated at 2022-06-25 03:49:04.190204
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test of method parse of class ModuleArgsParser.
    """
    module_args_parser_1 = ModuleArgsParser()
    with pytest.raises(AnsibleError) as err:
        task_ds_1 = {'action': 'command /usr/bin/example -a 1 -b 2', 'delegate_to': '127.0.0.1', 'run_once': True}
        module_args_parser_1.parse(task_ds_1)
    assert 'unexpected parameter type in action' in str(err)

    module_args_parser_2 = ModuleArgsParser()

# Generated at 2022-06-25 03:49:12.147214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Init
    parse_param_0 = 'shell echo hi'
    parse_param_1 = False
    module_args_parser_0 = ModuleArgsParser()

    # Test
    parse_0 = module_args_parser_0.parse(parse_param_0)

    # Assertions

    if parse_0[0] is None:
        raise AssertionError()
    if parse_0[1] is None:
        raise AssertionError()
    if parse_0[2] is not None:
        raise AssertionError()

test_case_0()
test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:49:23.061870
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:31.819540
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_name = 'ping'
    module_arguments = dict()
    delegate_to = None
    task_ds = dict()
    task_ds['action'] = 'ping'

    module_args_parser_0 = ModuleArgsParser(task_ds)

    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == module_name
    assert args == module_arguments
    assert delegate_to == None


# Generated at 2022-06-25 03:49:41.511785
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    class ModuleArgsParserTest(unittest.TestCase):
        def test_normal_parse(self):
            module_args_parser = ModuleArgsParser()
            input_data = {'module': 'shell', '_raw_params': 'echo hi', '_uses_shell': True, 'delegate_to': 'localhost', 'args': {'chdir': '/tmp'}}
            expected_data = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')
            self.assertEqual(module_args_parser.parse(input_data), expected_data)

        def test_module_and_local_action_parse_invalid(self):
            module_args_parser = ModuleArgsParser()
            input_data = {'module': 'shell', 'local_action': 'shell'}


# Generated at 2022-06-25 03:49:46.615801
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # Test case 0
    task_ds = dict(action=dict(module=dict(module="win_ping")))
    module_args_parser.parse(task_ds)

    # Test case 1
    task_ds = dict()
    module_args_parser.parse(task_ds)

    # Test case 2
    task_ds = dict(action=dict(module=dict(module="win_ping")))
    module_args_parser.parse(task_ds)

    # Test case 3
    task_ds = dict(action="action_args")
    module_args_parser.parse(task_ds)

    # Test case 4
    task_ds = dict(action=["module_name", "module_args"], delegate_to="win_ping")
    module_args_

# Generated at 2022-06-25 03:49:52.839130
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds0 = None
  collection_list0 = None
  module_args_parser0 = ModuleArgsParser(task_ds0, collection_list0)
  action0, args0, delegate_to0 = module_args_parser0.parse()
  assert action0 == None
  assert args0 == dict()
  assert delegate_to0 == None


# Generated at 2022-06-25 03:49:59.294268
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    #
    # Test 0
    #
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {u'args': u'this_is_raw_params_not_allowed', u'action': u'file'}
    expected_output_0 = (u'file', {u'_raw_params': u'this_is_raw_params_not_allowed'}, Sentinel)
    (actual_output_0,actual_output_1,actual_output_2) = module_args_parser_0.parse(task_ds_0)
    assert_equals(actual_output_0, expected_output_0)
    assert_equals(actual_output_1, expected_output_1)
    assert_equals(actual_output_2, expected_output_2)

    #
    #

# Generated at 2022-06-25 03:50:12.929217
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test for the case the module_args is a dict
    test_case = {
        'module': 'ec2',
        'region': 'xyz'
    }
    result = ModuleArgsParser(task_ds=test_case).parse()
    expect = ('ec2', {'region': 'xyz'}, None)
    if result == expect:
        print("[OK] ModuleArgsParser.parse works with dict as input")
    else:
        print("[ERROR] ModuleArgsParser.parse doesn't work with dict as input")

    # Test for the case the module_args is a dict with the key 'module'
    test_case = {
        'module': 'shell echo hi',
        'region': 'xyz'
    }
    result = ModuleArgsParser(task_ds=test_case).parse()

# Generated at 2022-06-25 03:50:28.341993
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Init
    MODULE_ARGS_PARSER_0 = ModuleArgsParser()

    # Static Method
    assert MODULE_ARGS_PARSER_0.parse({'action': 'shell echo hi', 'delegate_to': 'foo'}) == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'foo')
    assert MODULE_ARGS_PARSER_0.parse({'action': 'shell echo hi', 'delegate_to': 'foo'}) == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'foo')
    assert MODULE_ARGS_PARSER_0.parse({'action': 'shell echo hi'}) == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, Sentinel)
    assert MODULE_ARGS_

# Generated at 2022-06-25 03:50:37.984808
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test #1
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()
    assert type(action) == str
    assert type(args) == dict
    assert args == {}
    assert type(delegate_to) == Sentinel

    # Test #2
    module_args_parser_1 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_1.parse()
    assert type(action) == str
    assert type(args) == dict
    assert args == {}
    assert type(delegate_to) == Sentinel



# Generated at 2022-06-25 03:50:43.174504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: Test Description
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation_0 = False
    expected_0 = (None, None, Sentinel)
    actual_0 = module_args_parser_0.parse(skip_action_validation=skip_action_validation_0)
    assert expected_0 == actual_0



# Generated at 2022-06-25 03:50:54.136608
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    task_ds = {}

    if C.DEFAULT_MODULE_LANG is None:
        raise Exception("C.DEFAULT_MODULE_LANG is None")
    try:
        action, args, delegate_to = module_args_parser_0.parse()
    except AnsibleParserError as e:
        raise Exception("Unexpected error: %s" % e)

    if action is None:
        raise Exception("Expected action to be the value 'None', got '%s'" % action)

    if args is None:
        raise Exception("Expected args to be the value 'None', got '%s'" % args)

    if delegate_to is None:
        raise Exception("Expected delegate_to to be the value 'None', got '%s'" % delegate_to)

# Generated at 2022-06-25 03:51:06.283926
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Tests for the parse method of class ModuleArgsParser.
    '''

    parser = ModuleArgsParser()

    # Test 'action: copy src=a dest=b'
    task_ds_1 = {'action': 'copy src=a dest=b'}
    actual_action_1, actual_args_1, actual_delegate_to_1 = parser.parse(task_ds_1)
    expected_action_1 = 'copy'
    expected_args_1 = {'src': 'a', 'dest': 'b'}
    expected_delegate_to_1 = None
    assert actual_action_1 == expected_action_1
    assert actual_args_1 == expected_args_1
    assert actual_delegate_to_1 == expected_delegate_to_1

    # Test 'action: copy

# Generated at 2022-06-25 03:51:15.802083
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test cases:
    # Skeleton test case, no assertions expected
    module_args_parser_0 = ModuleArgsParser()
    with pytest.raises(AssertionError):
        module_args_parser_0.parse()
    # Test case with assertions
    module_args_parser_1 = ModuleArgsParser()
    with pytest.raises(AssertionError):
        module_args_parser_1.parse()

# Generated at 2022-06-25 03:51:23.546799
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test 1: All params set (no repeats)
    args_1 = dict(
        action='copy',
        src='a',
        dest='b'
    )

    task_ds_1 = dict(
        action=args_1,
    )

    expected_1 = dict(
        action='copy',
        args=args_1,
        delegate_to=None
    )

    module_args_parser_1 = ModuleArgsParser(task_ds_1)
    result_1 = module_args_parser_1.parse()

    assert result_1 == expected_1, "Expected %s, but got %s" % (expected_1, result_1)

    # Test 2: All params set (repeat)
    # ACTION and LOCAL_ACTION can be different
    # MODULE and arguments are not

    args_1

# Generated at 2022-06-25 03:51:34.642136
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.urls import urlparse

# Generated at 2022-06-25 03:51:37.689802
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse()[0] is None

# Generated at 2022-06-25 03:51:46.875818
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, {}, None)
    assert module_args_parser_0.parse() == (None, {}, None)
    assert module_args_parser_0.parse() == (None, {}, None)
    action = 'ping'
    module_args_parser_0._task_ds['action'] = action
    assert module_args_parser_0.parse() == (action, {}, None)
    module_args_parser_0._task_ds['action'] = action
    assert module_args_parser_0.parse() == (action, {}, None)
    action = module_args_parser_0._task_ds['action']
    module_args_parser_0._task_ds['action'] = action
   

# Generated at 2022-06-25 03:51:54.865859
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0()

# Check if ansible.module_utils.common.module_args_parser.ModuleArgsParser class has member functions

# Generated at 2022-06-25 03:52:03.934198
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create task data struct as a dictionary
    task_ds = dict()
    task_ds['action'] = 'copy src=a dest=b'

    # Create object instance of class ModuleArgsParser
    module_args_parser_0 = ModuleArgsParser()

    # Call method parse of class ModuleArgsParser
    output = module_args_parser_0.parse(skip_action_validation=False)

    # Check to make sure output is correct type
    assert isinstance(output, tuple)

    # Check server_name
    assert output[0] == 'copy'

    # Check to make sure dictionary is correct
    assert output[1]['src'] == 'a'
    assert output[1]['dest'] == 'b'
    assert len(output) == 3


# Generated at 2022-06-25 03:52:07.861264
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # It is not possible to test that this method raises any exception
    module_args_parser_0 = ModuleArgsParser()
    # Test no arguments
    # Test return value with no argument
    module_args_parser_0.parse()



# Generated at 2022-06-25 03:52:11.955473
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 1: test_case_0
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = True
    result_0 = module_args_parser_0.parse(skip_action_validation)

# Run the unit tests
if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:24.741354
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    args = {'executable': '/bin/sh', '_raw_params': '/sbin/reboot now'}
    delegate_to = None
    module_args_parser = ModuleArgsParser()
    assert (action, args, delegate_to) == module_args_parser._normalize_parameters('/sbin/reboot now', action='shell')
    assert (action, args, delegate_to) == module_args_parser._normalize_new_style_args('/sbin/reboot now', action='shell')
    assert (action, args) == module_args_parser._normalize_old_style_args({'shell': '/sbin/reboot now'})
    assert (action, args, delegate_to) == module_args_parser.parse()

# Generated at 2022-06-25 03:52:30.891526
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = { 'action' : 'copy src=a dest=b', }
    result_0 = module_args_parser_0.parse(task_ds_0)
    result_0['action']
    result_0['delegate_to']
    result_0['args']


# Generated at 2022-06-25 03:52:43.751913
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:48.767883
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_parse_0 = ModuleArgsParser()
    ds = {'action': 'command', 'args': {'_raw_params': 'sudo nohup service hadoop-0.20-mapreduce-tasktracker start', '_uses_shell': True}}
    ansible_module, args, delegate_to = module_args_parser_parse_0.parse()
    assert ansible_module == 'command'
    assert args == {'_raw_params': 'sudo nohup service hadoop-0.20-mapreduce-tasktracker start', '_uses_shell': True}
    assert delegate_to is None

# Generated at 2022-06-25 03:52:56.820902
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    with pytest.raises(AnsibleAssertionError):
        module_args_parser = ModuleArgsParser(None, None)
        module_args_parser.parse()

    task_ds = {}

    # local_action, action and module are mutually exclusive
    task_ds = {'local_action': 'copy'}
    with pytest.raises(AnsibleParserError):
        module_args_parser = ModuleArgsParser(task_ds, None)
        module_args_parser.parse()

    task_

# Generated at 2022-06-25 03:53:03.811774
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds1 = dict(action='shell echo hi', delegate_to='localhost')
    module_args_parser_1 = ModuleArgsParser(task_ds=ds1)
    assert module_args_parser_1.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    ds2 = dict(local_action='shell echo hi')
    module_args_parser_2 = ModuleArgsParser(task_ds=ds2)
    assert module_args_parser_2.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    ds3 = dict(action='copy src=a dest=b', delegate_to='localhost')
    module_args_parser_3 = ModuleArgsParser(task_ds=ds3)
    assert module_args_parser_3.parse()

# Generated at 2022-06-25 03:53:17.524017
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    module args parse test
    '''
    module_args_parser_0 = ModuleArgsParser()
    # set up required parameters
    # module_args_parser_0._task_ds = {}

    res = module_args_parser_0.parse()

    assert res != None, "test_ModuleArgsParser_parse: parse is None"
    assert type(res) == tuple, "test_ModuleArgsParser_parse: parse is not a tuple"
    assert len(res) == 3, "test_ModuleArgsParser_parse: should return 3 items"
    assert type(res[0]) == str, "test_ModuleArgsParser_parse: first item should be str"
    assert type(res[1]) == dict, "test_ModuleArgsParser_parse: second item should be dict"


# Generated at 2022-06-25 03:53:28.852743
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Load the task yaml into a dict
    with open(os.path.join(os.path.dirname(__file__), 'fixtures', 'task0.yaml'), 'r') as task_file:
        input_task_dict = yaml.load(task_file)

    # Create a parser
    module_args_parser = ModuleArgsParser(input_task_dict, collection_list=None)

    # Call parse and verify the results
    action, args, delegate_to = module_args_parser.parse(skip_action_validation=False)
    assert action == 'debug'
    assert args[0] == 'msg'
    assert args[1] == 'test message'
    assert delegate_to is Sentinel

# Generated at 2022-06-25 03:53:31.228307
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    x = ModuleArgsParser('whatever', 'whatever')
    x.parse(skip_action_validation=False)
    assert True

# Generated at 2022-06-25 03:53:43.433499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ###################################################################################################
    ####
    ####                             Test cases for ModuleArgsParser.parse()
    ####
    ###################################################################################################
    ####
    #### test_case_0:
    ####
    #### Parse Valid Modules
    ####
    ####
    test_name = "parse valid modules"
    task_ds = {}


# Generated at 2022-06-25 03:53:50.024821
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'name': 'test0', 'local_action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    module_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_parser.parse()
    assert action == 'copy' and isinstance(args, dict) and delegate_to == 'localhost'

# Generated at 2022-06-25 03:53:59.389546
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    with pytest.raises(AnsibleParserError):
        action, args, delegate_to = parser.parse({})

    # some simple valid actions, with various formats
    action, args, delegate_to = parser.parse("action: user ssn=secret private=yes")
    assert isinstance(action, string_types)
    assert action == u'user'
    assert isinstance(args, dict)
    assert isinstance(delegate_to, Sentinel)
    assert args == dict(ssn=u'secret', private=u'yes')

    action, args, delegate_to = parser.parse("action: user ssn=secret")
    assert isinstance(action, string_types)
    assert action == u'user'
    assert isinstance(args, dict)

# Generated at 2022-06-25 03:54:02.949755
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    (action, args, delegate_to) = parser.parse(True)
    assert action == 'debug'
    assert args == {'msg': 'This is a test module.', 'var': 'test'}
    assert delegate_to == None



# Generated at 2022-06-25 03:54:09.168220
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Simple positive test
    case_0 = {
        'name': 'test task 0',
        'action': 'copy src=a dest=b'
    }
    module_args_parser_0 = ModuleArgsParser()
    result_0 = module_args_parser_0.parse()
    assert result_0 == (None, {}, None)
    result_1 = module_args_parser_0.parse(skip_action_validation=True)
    assert result_1 == ('copy', {}, None)

    # Simple negative test
    bad_action = 'not_a_real_module'
    case_1 = {
        'name': 'test task 1',
        bad_action: 'copy src=a dest=b'
    }
    module_args_parser_1 = ModuleArgsParser(case_1)

# Generated at 2022-06-25 03:54:16.734402
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # instantiate test obj
    module_args_parser = ModuleArgsParser()
    # call the method under test
    with pytest.raises(AnsibleAssertionError, match="the type of 'task_ds' should be a dict, but is a <class 'str'>"):
        module_args_parser.parse(task_ds='a string')
    assert module_args_parser.resolved_action is None
    # call the method under test
    result = module_args_parser.parse(task_ds={'something': 'some_value'})
    assert result == (None,dict(),None)
    assert module_args_parser.resolved_action is None
    # call the method under test
    result = module_args_parser.parse(task_ds={'shell': 'some_value'})

# Generated at 2022-06-25 03:54:26.585180
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # Answer the action, arguments and delegate_to value in the form of a tuple
    task_ds = {'stat': '/etc/passwd', 'delegate_to': 'localhost'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'stat'
    task_ds = {'local_action': 'stat src=/etc/passwd dest=/home/vagrant/foo.txt'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'stat'
    task_ds = {'shell': 'ls'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'shell'

# Generated at 2022-06-25 03:54:44.796964
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 0
    args_ds = dict(action=dict(), args=dict())
    action = module_args_parser_0.parse(args_ds)
    if action != ('ping', dict(), None):
        return (1, False, "Unexpected result:\n\t{}\nExpected:\n\t{}".format(action, ('ping', dict(), None)))
    return (0, True)


# Generated at 2022-06-25 03:54:48.023555
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: make a test case
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse()



# Generated at 2022-06-25 03:54:57.660841
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_result = module_args_parser_0.parse(skip_action_validation=False)
    assert isinstance(task_ds_result, tuple)
    assert isinstance(task_ds_result[0], str)
    assert isinstance(task_ds_result[1], dict)
    assert isinstance(task_ds_result[2], Sentinel)
    assert str(task_ds_result[2]) == "Copy from a remote file to a local file."

# Generated at 2022-06-25 03:54:59.001010
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # Test cases for the ModuleArgsParser.parse
    module_args_parser.parse()

    module_args_parser.parse(True)

# Generated at 2022-06-25 03:55:00.708409
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == ()


# Generated at 2022-06-25 03:55:04.679096
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Implement
    task_ds={}
    ModuleArgsParser = ModuleArgsParser(task_ds)
    parser_result = ModuleArgsParser.parse()
    print(parser_result)
    pass

# Special test to make sure the test infra is working
# No test name field test_case_0

# Generated at 2022-06-25 03:55:09.172793
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_model = dict()
    module_args_parser_1 = ModuleArgsParser(action_model)

    # TODO: test non-default values of action_model
    #module_args_parser_1.parse()

# Generated at 2022-06-25 03:55:17.213814
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # Case 0
    # Input:
    #   task_ds = dict(action = dict(module = 'command', args = 'ls'))
    #   skip_action_validation = False
    # Output:
    #   action = 'command'
    #   args = dict()
    #   delegate_to = None
    task_ds = dict(action = dict(module = 'command', args = 'ls'))
    (action, args, delegate_to) = module_args_parser.parse(task_ds, False)
    assert action == 'command'
    assert args == dict()
    assert delegate_to is None

    # Case 1
    # Input:
    #   task_ds = dict(action = 'command', args = 'ls')
    #   skip_action_

# Generated at 2022-06-25 03:55:25.386521
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    task_ds_0 = dict(action='ping')
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse(task_ds_0)
    assert action_0 == 'ping'
    assert args_0 == {}
    assert delegate_to_0 is Sentinel


# Generated at 2022-06-25 03:55:28.233763
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse(skip_action_validation=True) is not None

if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:55:50.669509
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # call of parse() with task dictionary

    kb_j4k2_dict_0 = {'name': 'test_kernel_burst', 'args': 'msg=test_kernel_burst'}
    assert module_args_parser_0.parse(task_ds=kb_j4k2_dict_0) == ('debug', {u'msg': u'test_kernel_burst'}, None)

    # call of parse() with task dictionary

    kb_j4k2_dict_1 = {'name': 'test_kernel_burst', 'args': 'msg=test_kernel_burst'}

# Generated at 2022-06-25 03:55:53.732790
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Generated at 2022-06-25 03:56:04.518286
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Testing method parse of class ModuleArgsParser")
    # Since we can't pass different values to constructor, We are using below class with
    # custom parameterized constructor
    class MyModuleArgsParser_4(ModuleArgsParser):
        def __init__(self, task_ds=None, collection_list=None):
            ModuleArgsParser.__init__(self, task_ds, collection_list)
    module_args_parser_0 = MyModuleArgsParser_4(
        {"action": "copy src=a dest=b"},
        None,
    )
    print(module_args_parser_0.parse())
    module_args_parser_1 = MyModuleArgsParser_4(
        {"action": "copy", "dest": "b", "src": "a"},
        None,
    )

# Generated at 2022-06-25 03:56:12.123821
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Test for presence of resolve action

    # Test for case 0
    try:
        module_args = module_args_parser_0.parse(skip_action_validation=True)
    except Exception as e:
        assert False, "Missing test case? {0}".format(e)
    else:
        assert True

    # Test for case 1
    try:
        module_args = module_args_parser_0.parse(skip_action_validation=False)
    except Exception as e:
        assert False, "Missing test case? {0}".format(e)
    else:
        assert True


if __name__ == "__main__":
    test_case_0()

    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:56:17.299831
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    for task_ds in TASKS_DATA:
        module_args_parser = ModuleArgsParser(task_ds)
        action, args, delegate_to = module_args_parser.parse()
        assert action in task_ds
        task_args = task_ds[action]

        if isinstance(task_args, dict):
            assert args == task_args
        else:
            assert args['_raw_params'] == to_text(task_args)

        if 'delegate_to' in task_ds:
            assert delegate_to == task_ds['delegate_to']
        else:
            assert delegate_to is Sentinel

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 03:56:28.048120
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_1 = {'action': {'module': 'shell echo hi'}}
    task_ds_2 = '/tmp/ansible_9QZuQ8'
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    assert (module_args_parser_1.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None))
    module_args_parser_2 = ModuleArgsParser(task_ds=task_ds_2)
    with pytest.raises(AnsibleAssertionError):
        module_args_parser_2.parse()
    task_ds_3 = {'action': {'dest': 'world', 'module': 'copy src=hello', 'mode': '0644'}}
    module_args

# Generated at 2022-06-25 03:56:39.943435
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # For this task, we should see 'hello' as the module being parsed,
    # and the arguments being 'world'
    test_task_0 = dict(
        action='hello',
        args=dict(
            msg='world',
            b=True,
        )
    )
    expected_result_0 = (
        'hello',
        dict(
            msg='world',
            b=True,
        ),
        None,
    )
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse(**test_task_0)
    assert result == expected_result_0

    # For this task, we should see 'hello' as the module being parsed,
    # and the arguments being 'world'

# Generated at 2022-06-25 03:56:42.677685
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test to return the action, arguments and delegate_to value, dealing with
    all sorts of levels of fuzziness in the task.
    '''
    # TODO
    pass


# Generated at 2022-06-25 03:56:52.350504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    test_cases = list()

    # Test case 0
    task_ds = dict()
    test_cases.append((task_ds, 'Action = None, args = {}, delegate_to = None'))

    # Test case 1
    task_ds = dict(action='ping')
    test_cases.append((task_ds, 'Action = ping, args = {}, delegate_to = None'))

    # Test case 2
    task_ds = dict(action='ping', args='data=foo')
    test_cases.append((task_ds, 'Action = ping, args = {data: foo}, delegate_to = None'))

    # Test case 3
    task_ds = dict(action='ping', args=dict(data='foo'))

# Generated at 2022-06-25 03:56:57.217898
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # TODO: add tests for parse

if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:57:30.390259
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    with pytest.raises(AnsibleParserError):
        result = module_args_parser.parse()


# Generated at 2022-06-25 03:57:34.835320
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    dict_0 = dict({
        'action': 'shell echo hi',
    })
    (action, args, delegate_to) = module_args_parser_0.parse(dict_0)
    print('action: %s' % action)
    print('args: %s' % args)
    print('delegate_to: %s' % delegate_to)


# Generated at 2022-06-25 03:57:46.161434
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    import os
    import stat

    curr_dir = os.getcwd()
    test_dir = os.path.dirname(os.path.abspath(__file__))

    # Copy task plugins to ansible local plugins directory
    ansible_plugins_dir = os.path.join(curr_dir, 'lib', 'ansible', 'plugins')
    src_plugins_dir = os.path.join(test_dir, '..', '..', 'unit', 'lib', 'ansible', 'plugins')
    for filename in os.listdir(src_plugins_dir):
        if filename.endswith("py"):
            shutil.copy(os.path.join(src_plugins_dir, filename), ansible_plugins_dir)

    # Copy collections to ansible local collections directory
    ans

# Generated at 2022-06-25 03:57:54.987754
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser._task_attrs is not None
    assert module_args_parser._task_ds is not None
    assert module_args_parser._collection_list is None
    assert module_args_parser.resolved_action is None
    assert module_args_parser.parse() == ('command', {}, None)
    assert module_args_parser.parse(skip_action_validation=True) == ('command', {}, None)
    assert module_args_parser.resolved_action == 'ansible.builtin.command'


# Generated at 2022-06-25 03:58:01.712616
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {}
    skip_action_validation_0 = False
    assert module_args_parser_0.parse(task_ds_0, skip_action_validation_0) == (None, None, None)


# Generated at 2022-06-25 03:58:08.988537
# Unit test for method parse of class ModuleArgsParser