

# Generated at 2022-06-25 03:48:32.921749
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()



# Generated at 2022-06-25 03:48:35.911700
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse()

    assert action == ''
    assert args == {}
    assert delegate_to == Sentinel

# Generated at 2022-06-25 03:48:40.010226
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('-> ModuleArgsParser.parse')
    result = module_args_parser_0.parse()
    print('<- ModuleArgsParser.parse')
    return result

test_class_0 = [ModuleArgsParser, test_case_0, test_ModuleArgsParser_parse]
test_class_list = [test_class_0]


# Generated at 2022-06-25 03:48:42.321582
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test Cases
    # Case 0:
    # test_case_0()
    test_case_0()

if __name__ == "__main__":
    # test_ModuleArgsParser_parse()
    ModuleArgsParser().parse()

# Generated at 2022-06-25 03:48:43.443217
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0()


# Generated at 2022-06-25 03:48:50.762761
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    task_ds_dict = {'name': 'Test module_args_parser', 'action': {'module': 'copy', 'x': 'y', 'a': 'b'}}
    (action, args, delegate_to) = module_args_parser_1.parse()
    assert action == None, "Expected action: None, Actual action: %s"%(action)
    assert args == dict(), "Expected args: {}, Actual args: %s"%(args)
    assert delegate_to == Sentinel, "Expected delegate_to: %s, Actual delegate_to: %s"%(Sentinel,delegate_to)


# Generated at 2022-06-25 03:49:02.432429
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:12.933601
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_2 = ModuleArgsParser()
    module_args_parser_3 = ModuleArgsParser()
    module_args_parser_4 = ModuleArgsParser()
    module_args_parser_5 = ModuleArgsParser()
    # Test 1 with arguments: {'module': 'copy'}
    print("Test 1 with arguments: {'module': 'copy'}")
    assert module_args_parser_1.parse({'module': 'copy'}) == ('copy', {}, None)
    # Test 2 with arguments: {'action': 'copy'}
    print("Test 2 with arguments: {'action': 'copy'}")
    assert module_args_parser_2.parse({'action': 'copy'}) == ('copy', {}, None)
    # Test 3 with

# Generated at 2022-06-25 03:49:13.744955
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0()

# Generated at 2022-06-25 03:49:23.486102
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    module_args_parser = ModuleArgsParser()

    # Create variable load_from_file_args
    load_from_file_args = {
        "async": "20",
        "poll": "0",
        "static": "yes",
        "delegate_to": "{{delegate_foo}}",
        "run_once": "true",
        "free-form": "this is a free form string"
    }

    # Create variable action
    action = None

    # Create variable args
    args = {}

    # Create variable delegate

# Generated at 2022-06-25 03:49:55.644912
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True, "Unit test for method 'parse' of class 'ModuleArgsParser' not implemented"


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

    print(ModuleArgsParser.__doc__)

    print("No asserts in the unit test for 'ModuleArgsParser' so far.")

    print('End of test for ModuleArgsParser')

# Generated at 2022-06-25 03:49:58.177946
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    parse_output = module_args_parser.parse()
    assert parse_output == (None, None, Sentinel)


# Generated at 2022-06-25 03:50:06.119023
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_a = ModuleArgsParser()

    # Set up data for test_case_0
    task_ds_a = {}

    # TestCase_0
    task_ds_a = {'arguments': {'lookup': 'password', 'key': 'value'}}
    expected_a = 'password'
    actual_a = module_args_parser_a.parse(task_ds_a)
    assert task_ds_a == expected_a

    # Set up data for test_case_1
    task_ds_b = {}

    # TestCase_1
    task_ds_b = {'arguments': {'lookup': 'password', 'key': 'value'}}
    expected_b = 'password'
    actual_b = module_args_parser_a.parse(task_ds_b)

# Generated at 2022-06-25 03:50:10.254608
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Testing ModuleArgsParser.parse")

    parser = ModuleArgsParser()
    assert parser.parse() == (None, dict(), None)



# Generated at 2022-06-25 03:50:19.669964
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            module=dict(
                hello_world=dict(
                    name='Nagaraj',
                ),
            ),
        ),
    )
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'hello_world'
    assert args == {'name': 'Nagaraj'}
    assert delegate_to is Sentinel


# Generated at 2022-06-25 03:50:21.575682
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # module_args_parser.parse(skip_action_validation=False)

# Generated at 2022-06-25 03:50:24.060346
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse()

################################################################################

# Generated at 2022-06-25 03:50:26.426340
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() == (None, {}, 'Sentinel')


# Generated at 2022-06-25 03:50:38.933823
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    # action: copy src=a dest=b
    task_ds_1 = {'action': 'copy src=a dest=b'}
    action, args, delegate_to = module_args_parser_1.parse(task_ds_1)
    if action != 'copy':
        raise AssertionError("Expected 'copy' but got {0}".format(action))
    if 'src' not in args or args['src'] != 'a':
        raise AssertionError("Expected src: 'a' but got {0}".format(args.get('src', 'undefined')))

# Generated at 2022-06-25 03:50:47.388166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest

# Generated at 2022-06-25 03:51:18.654050
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser({'action': 'shell echo hi'})
    # test case of None
    action, args, delegate_to = module_args_parser_1.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel
    # test case of action: shell echo hi
    action, args, delegate_to = module_args_parser_1.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-25 03:51:23.041654
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing case 0
    module_args_parser_0 = ModuleArgsParser()

    # Testing case 1
    module_args_parser_1 = ModuleArgsParser()

    with pytest.raises(AnsibleParserError):
        module_args_parser_1.parse()


# Generated at 2022-06-25 03:51:34.194238
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n\n=== test_ModuleArgsParser_parse ===\n")
    module_args_parser_1 = ModuleArgsParser()
    test_case_data_0_dict = {"shell": "echo 'Hello, Ansible'"}
    test_case_data_1_dict = {"action": {"module": "shell",
                                        "args": "-c 'echo Hello, Ansible'"}}
    test_case_data_2_dict = {"local_action": {"module": "shell",
                                              "args": "-c 'echo Hello, Ansible'"}}
    test_case_data_3_dict = {"action": "shell echo 'Hello, Ansible'"}
    test_case_data_4_dict = {"local_action": "shell echo 'Hello, Ansible'"}

# Generated at 2022-06-25 03:51:44.105192
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser(
        task_ds={'action': 'copy src=a dest=b'}
    )
    assert module_args_parser_1.parse(skip_action_validation=True) == ('copy',
                                                    {'dest': 'b', 'src': 'a'},
                                                    None)

    module_args_parser_2 = ModuleArgsParser(
        task_ds={'module': 'copy src=a dest=b'}
    )
    assert module_args_parser_2.parse(skip_action_validation=True) == ('copy',
                                                    {'dest': 'b', 'src': 'a'},
                                                    None)


# Generated at 2022-06-25 03:51:47.011967
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_parse = ModuleArgsParser()
    assert module_args_parser_parse.parse() == None

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:51:53.264522
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:01.352249
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    with pytest.raises(AnsibleError) as ansible_error:
        module_args_parser_0.parse()
    assert ansible_error.value.args[0] == "Invalid direct call to parse() without 'task_ds' argument"
    with pytest.raises(AnsibleError) as ansible_error:
        module_args_parser_0.parse(task_ds=dict_0)
    assert ansible_error.value.args[0] == "Invalid direct call to parse() without 'collection_list' argument"

# Generated at 2022-06-25 03:52:12.410595
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:24.923067
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:35.297250
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing case is n/a.
    module_args_parser = ModuleArgsParser()
    actual_result = module_args_parser.parse()
    assert actual_result == ('n/a', {}, 'n/a')
    module_args_parser = ModuleArgsParser()
    actual_result = module_args_parser.parse()
    assert actual_result == ('n/a', {}, 'n/a')
    module_args_parser = ModuleArgsParser()
    actual_result = module_args_parser.parse()
    assert actual_result == ('n/a', {}, 'n/a')
    module_args_parser = ModuleArgsParser()
    actual_result = module_args_parser.parse()
    assert actual_result == ('n/a', {}, 'n/a')
    module_args_parser = ModuleArgs

# Generated at 2022-06-25 03:53:11.437618
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert True

# Generated at 2022-06-25 03:53:19.782890
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    passed = 0
    failed = 0

    num_tests = 0

    task_ds = {}
    collection_list = None

    module_args_parser = ModuleArgsParser()


# Generated at 2022-06-25 03:53:31.042187
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize the test case
    task_ds = { 'action': 'shell echo hi' }
    module_args_parser = ModuleArgsParser( task_ds=task_ds )
    expected_action = 'shell'
    expected_args = { 'echo': 'hi' }
    expected_delegate_to = None
    observed_action, observed_args, observed_delegate_to = module_args_parser.parse()

    assert expected_action == observed_action
    assert expected_args == observed_args
    assert expected_delegate_to == observed_delegate_to

    task_ds = { 'action': { 'module': 'shell', 'echo': 'hi' } }
    module_args_parser = ModuleArgsParser( task_ds=task_ds )
    expected_action = 'shell'

# Generated at 2022-06-25 03:53:37.560611
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    thing = None

    action = None
    delegate_to = module_args_parser._task_ds.get('delegate_to', Sentinel)
    args = dict()

    # This is the standard YAML form for command-type modules. We grab
    # the args and pass them in as additional arguments, which can/will
    # be overwritten via dict updates from the other arg sources below
    additional_args = module_args_parser._task_ds.get('args', dict())

    # We can have one of action, local_action, or module specified
    # action
    if 'action' in module_args_parser._task_ds:
        # an old school 'action' statement
        thing = module_args_parser._task_ds['action']
        action, args = module_args_

# Generated at 2022-06-25 03:53:45.334901
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    ###########
    # STATE 0 #
    ###########
    # Task: '/home/vagrant/projects/ansible-base/lib/ansible/modules/system/user.py'
    task_ds0 = dict(
      action='user',
      name='foo',
      state='absent',
      # with_items=['foo']
      # with_items=ansible_play_hosts
    )

    action0, args0, delegate_to0 = module_args_parser.parse(task_ds0)
    assert action0 == 'user'
    assert args0['name'] == 'foo'
    assert args0['state'] == 'absent'

    ###########
    # STATE 1 #
    ###########
    # Task: '/home/vagrant

# Generated at 2022-06-25 03:53:53.252876
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # Test the case where parser is given an invalid type of task_ds
    try:
        module_args_parser_0.parse(sentinel.invalid)
    except AnsibleAssertionError as ae_e:
        assert "the type of 'task_ds' should be a dict" in str(ae_e)
    except Exception as e:
        assert False, "Unexpected exception raised: {0}".format(str(e))

    # Test the case where parser given an invalid type of task_ds

# Generated at 2022-06-25 03:53:57.736095
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    print("\n test_case_0")
    assert module_args_parser_0.parse() == ('ping', {}, Sentinel)



# Generated at 2022-06-25 03:54:07.821868
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_task = dict(
        action=dict(
            module="shell",
            args="echo hello",
            x=5,
        ),
    )

    # simple test
    module_args_parser_0 = ModuleArgsParser(test_task)
    assert module_args_parser_0.parse() == ("shell", dict(_raw_params="echo hello"), None)

    # test with a dict of args
    test_task = dict(
        action=dict(
            module="shell",
            args={"arg1": 1, "arg2": "hello"},
            x=5,
        ),
    )

    module_args_parser_0 = ModuleArgsParser(test_task)
    assert module_args_parser_0.parse() == ("shell", dict(_raw_params="arg1=1 arg2=hello"), None)

# Generated at 2022-06-25 03:54:15.495908
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {
        'delegate_to': 'localhost',
        'local_action': 'set_fact',
        'args': {
            'a': 'b',
            'c': 'd'
        }
    }
    (action, args, delegate_to) = module_args_parser_0.parse(task_ds_0)
    assert action == 'set_fact'
    assert type(args) == dict
    assert len(args) == 2
    assert args.get('a') == 'b'
    assert args.get('c') == 'd'
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:54:22.237785
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Set up test data
    parse_task_ds = {'action': {'b': 1, 'module': 'b=1 a=2', 'a': 2}}
    parse_action_0 = 'b=1 a=2'

    # Init method of the class
    module_args_parser_0 = ModuleArgsParser(parse_task_ds)

    # Test with valid arguments
    result = module_args_parser_0.parse()
    assert result[0] == parse_action_0

# Generated at 2022-06-25 03:54:38.381708
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_1 = ModuleArgsParser()

    # test "task_ds" not being a dict
    try:
        module_args_parser_0.parse(task_ds="test", collection_list=None)
    except AnsibleAssertionError as e:
        assert "the type of 'task_ds' should be a dict" in e.args[0]
    else:
        raise Exception("Expected failure")

    # test test_ModuleArgsParser_parse_case_0
    task_ds_0 = dict()
    task_ds_0['action'] = 'shell echo hi'
    task_ds_0['args'] = 'ls'
    collection_list_0 = None


# Generated at 2022-06-25 03:54:51.330751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case = [{'action': 'test_action', 'args': {"test_arg": "test_arg_value"}},
                 {'action': 'test_action', 'local_action': {'test_arg': "test_arg_value"}},
                 {'action': 'test_action', 'test_arg': "test_arg_value"}]
    results = []
    for i in test_case:
        module_args_parser = ModuleArgsParser(i)
        results.append(module_args_parser.parse())
    assert len(results) == len(test_case)
    assert results[0][0] == 'test_action'
    assert results[0][1]['test_arg'] == 'test_arg_value'
    assert results[1][0] == 'test_action'

# Generated at 2022-06-25 03:54:57.116034
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    debug_print()
    module_args_parser_0 = ModuleArgsParser()
    test_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    result = module_args_parser_0.parse(skip_action_validation=False)
    assert result[0] == 'shell'
    assert result[1] == {'echo hi'}
    assert result[2] == None


# Generated at 2022-06-25 03:54:59.555433
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_0.parse()


# Generated at 2022-06-25 03:55:03.081598
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    skip_action_validation = False
    result = module_args_parser.parse(skip_action_validation)
    assert result == (None, dict(), Sentinel)


# Generated at 2022-06-25 03:55:11.922248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # Task with no actions
    task_ds_0 = dict()
    expect_action_0 = None
    expect_args_0 = dict()
    expect_delegate_to_0 = None
    a,b,c = module_args_parser_0.parse(task_ds_0)
    if a != expect_action_0:
        print("[Task with no actions]: invalid action:  expect {},  actual {}".format(expect_action_0, a))
    if b != expect_args_0:
        print("[Task with no actions]: invalid args:  expect {},  actual {}".format(expect_args_0, b))

# Generated at 2022-06-25 03:55:18.901308
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.errors
    try:
        test_ModuleArgsParser_parse_0()
    except Exception as e:
        print("Testcase 0: " + str(e))
    try:
        print("Testcase 1: ModuleArgsParser_parse")
        # FIXME
        #module_args_parser_0 = ModuleArgsParser()
        #module = ModuleArgsParser()
        #module.parse(module_args_parser_0, skip_action_validation=True)
    except ansible.errors.AnsibleError as e:
        print("exception caught: " + str(e))
        raise
    except Exception as e:
        print("exception caught: " + str(e))
        raise


# Generated at 2022-06-25 03:55:30.259012
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test the ModuleArgsParser class parse method
    '''

    # Test the case where no action is specified
    task_ds_0 = { }
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0, collection_list=None)
    try:
        module_args_parser_0.parse()
    except AnsibleParserError as exc:
        assert str(exc) == "no module/action detected in task."
    else:
        assert False

    # Test the case where multiple action are specified
    task_ds_1 = { "action": "", "local_action": "" }
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1, collection_list=None)

# Generated at 2022-06-25 03:55:40.800021
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # test with 'action' key
    task_0 = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost'
    }
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse(task_0)
    assert action_0 == 'shell'
    assert args_0['_raw_params'] == 'echo hi'
    assert delegate_to_0 == 'localhost'

    # test with 'local_action' key
    task_1 = {
        'local_action': 'copy src=a dest=b'
    }
    (action_1, args_1, delegate_to_1) = module_args_parser_0.parse(task_1)
    assert action_1

# Generated at 2022-06-25 03:55:45.731637
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    global module_args_parser_0
    ret_value = module_args_parser_0.parse()

    # check that the returned value is equal to the expected value
    assert ret_value == (u'gather_facts', {u'_raw_params': u'', u'_uses_shell': False}, None)


# Generated at 2022-06-25 03:56:11.458065
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = dict(my_var='my value', my_list=[1, 2, 3], my_dict=dict(name='georgia'))
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    action, args, delegate_to = module_args_parser_0.parse()
    if action != 'shell' and args == {'_raw_params': 'echo hi'} and delegate_to == 'localhost':
        raise RuntimeError('Unexpected behavior in parse method of class ModuleArgsParser. Expected (\'shell\', {\'_raw_params\': \'echo hi\'}, \'localhost\'), got {0}'.format([action, args, delegate_to]))


# Generated at 2022-06-25 03:56:21.445207
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_2 = ModuleArgsParser(task_ds={u'action': u'copy file=/tmp/sample.txt dest=/tmp/sample1.txt'}, collection_list=None)
    results_2 = module_args_parser_2.parse(skip_action_validation=False)
    assert isinstance(results_2, tuple)
    assert len(results_2) == 3
    assert results_2[0] == u'copy'
    assert isinstance(results_2[1], dict)
    assert len(results_2[1]) == 2
    assert results_2[1][u'file'] == u'/tmp/sample.txt'
    assert results_2[1][u'dest'] == u'/tmp/sample1.txt'
    assert results_2[2] == Sentinel
    module_args_parser

# Generated at 2022-06-25 03:56:30.033745
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Declare the inputs used by the ModuleArgsParser.parse() method
    task_ds = {}
    collection_list = {}
    # Make a ModuleArgsParser object
    module_args_parser_obj = ModuleArgsParser(task_ds, collection_list)
    # Call the instance method ModuleArgsParser.parse()
    module_args_parser_parse_rtn = module_args_parser_obj.parse()
    # Assert the return of the call is the expected return of the method
    assert module_args_parser_parse_rtn == None


# Generated at 2022-06-25 03:56:40.143434
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # create an instance of the class
    module_args_parser = ModuleArgsParser()

    # define the input and expected outputs for the test
    test_input_0 = {'action': {'module': 'shell', '_raw_params': 'pwd'}}
    expected_output_0 = ('shell', {'_raw_params': 'pwd'}, None)

    test_input_1 = {'action': {'module': 'command', '_raw_params': 'pwd'}}
    expected_output_1 = ('command', {'_raw_params': 'pwd'}, None)

    # call the method with the test inputs
    result_0 = module_args_parser._normalize_new_style_args(test_input_0, 'shell')
    result_1 = module_args_parser._normalize_new_

# Generated at 2022-06-25 03:56:45.714978
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()

    if delegate_to != None:
        raise AssertionError("Delegate_to Should be None")

    if action != None:
        raise AssertionError("Action should be None")

    if args != dict():
        raise AssertionError("Args should be empty dict")


# Generated at 2022-06-25 03:56:51.110474
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse()
    assert type(result) is tuple, "The value is not of type: tuple"
    assert len(result) == 3, "The value does not meet the expected length of 3"
    assert type(result[0]) is str, "The value is not of type: string"
    assert type(result[1]) is dict, "The value is not of type: dictionary"
    assert type(result[2]) is Sentinel, "The value is not of type: Sentinel"


# Generated at 2022-06-25 03:56:59.337164
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # No file provided

    # Create instance of ModuleArgsParser class
    module_args_parser = ModuleArgsParser()

    # Call parse method
    try:
        module_args_parser.parse()
    except AnsibleAssertionError as e:
        assert e.message == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"


# Generated at 2022-06-25 03:57:10.279974
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    invalid_task_ds_1 = {'invalid_key': 'invalid_value'}
    test_error_msg = "unexpected parameter type in action: %s"
    expected_results_1 = (None, None, None)
    assert_equal(ModuleArgsParser(invalid_task_ds_1).parse(), expected_results_1)

    invalid_task_ds_2 = {}
    assert_equal(ModuleArgsParser(invalid_task_ds_2).parse(), expected_results_1)

    invalid_task_ds_3 = 'not_a_dict'
    assert_equal(ModuleArgsParser(invalid_task_ds_3).parse(), expected_results_1)

# Generated at 2022-06-25 03:57:21.525823
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:57:29.368271
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # setup the test case
    test_case_0()

    # setup the arguments (args) to run the module against
    args_0 = {}

    # setup the return value(s)
    # the return values are in a tuple
    return_value_0 = {}
    return_value_0['return_value'] = (return_value_0['return_value'], None)

    # setup the expected results
    expected_return_0 = {}
    expected_return_0['return_value'] = (expected_return_0['return_value'], None)

    # run the module code
    results_0 = ModuleArgsParser(args_0)

    # compare the actual return value(s) against the expected value(s)
    for key_0 in return_value_0:
        assert results_0[key_0] == expected

# Generated at 2022-06-25 03:58:04.898612
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert (True)
