

# Generated at 2022-06-25 03:48:33.856035
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class
    :func:`ansible.playbook.task_include.ModuleArgsParser`
    '''
    # Setup:

# Generated at 2022-06-25 03:48:42.588169
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test with valid input
    module_args_parser_obj = ModuleArgsParser()
    task_dict = {}
    task_dict['action'] = 'command echo hello'
    action, args, delegate_to = module_args_parser_obj.parse(task_dict)
    assert (action == 'command' and args == {'_raw_params': 'echo hello'} and not delegate_to)
    assert (module_args_parser_obj.resolved_action == 'command')

    task_dict = {}
    task_dict['local_action'] = 'command echo hello'
    action, args, delegate_to = module_args_parser_obj.parse(task_dict)
    assert (action == 'command' and args == {'_raw_params': 'echo hello'} and delegate_to == 'localhost')

# Generated at 2022-06-25 03:48:45.120033
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #Test 0 for ModuleArgsParser().parse
    test_case_0()


# Generated at 2022-06-25 03:48:51.560430
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys
    import inspect
    import unittest
    module_args_parser_0 = ModuleArgsParser()
    task_ds_1 = { 'foo': 1, 'bar': 2, 'baz': 3, 'fooz': 4 }
    _result = module_args_parser_0.parse(task_ds_1)
    assert _result == (None, None, None)


# Generated at 2022-06-25 03:49:03.838842
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:06.290529
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, dict(), Sentinel)


# Generated at 2022-06-25 03:49:13.439397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    #
    # call parse
    #
    (action, args, delegate_to) = module_args_parser_0.parse()

    #
    #
    #

# Generated at 2022-06-25 03:49:23.387342
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    script to run for testing
    python parsers/yaml/test_module_args.py parsers.yaml.ModuleArgsParser.parse
    '''
    test_cases = [
        # Test case 0
        test_case_0(),
    ]
    test_module_args = ModuleArgsParser()

# Generated at 2022-06-25 03:49:28.965330
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse('local_action', {'local_action': None})
    module_args_parser.parse('local_action', {'local_action': 'shell echo hi',
                                              'delegate_to': 'me'})
    module_args_parser.parse('local_action', {'local_action': {'shell': 'echo hi'},
                                              'delegate_to': 'me'})
    module_args_parser.parse('action', {'action': 'copy src=a dest=b'})
    module_args_parser.parse('action', {'action': {'copy': 'src=a dest=b'}})

# Generated at 2022-06-25 03:49:40.328349
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # 1 
    # pass:
    # task_ds = {'action': 'shell echo hi'}, skip_action_validation = False
    # return: ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': 'shell echo hi'}
    skip_action_validation = False
    (action, args, delegate_to) = module_args_parser.parse(task_ds, skip_action_validation)
    assert (action == 'shell')
    assert (args == {'_raw_params': 'echo hi'})
    assert (delegate_to == None)

    # 2
    # pass:
    # task_ds = {'action': {'module': 'shell', 'args': 'echo hi'}},

# Generated at 2022-06-25 03:50:01.867026
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # ModuleArgsParser.__init__(self, task_ds=None, collection_list=None)
    module_args_parser = ModuleArgsParser()
    # ModuleArgsParser.parse(self, skip_action_validation=False)
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == None
    assert args == None
    assert delegate_to == None


# Generated at 2022-06-25 03:50:07.928871
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    thing = { 'command' : 'echo hi' }
    action, args = module_args_parser._normalize_old_style_args(thing)
    assert (action == 'shell') and (args == {'_raw_params': 'echo hi'}), "Failed to parse args correctly"

    thing = 'shell echo hi'
    action, args = module_args_parser._normalize_old_style_args(thing)
    assert (action == 'shell') and (args == {'_raw_params': 'echo hi'}), "Failed to parse args correctly"

    thing = {'module': 'ec2', 'x': 1 }
    action, args = module_args_parser._normalize_old_style_args(thing)

# Generated at 2022-06-25 03:50:13.450024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of ModuleArgsParser
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds)

    # Call parse on the instance and save it to module_args_parser_0.parse
    module_args_parser_0.parse()

    # Test if module_args_parser_0.parse is equal to the expected result
    assert module_args_parser_0.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-25 03:50:23.068208
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    task_ds = {}
    action = None
    delegate_to = 'localhost'
    args = dict()

    collection_list = None
    # String test
    # static_vars = dict()
    # static_vars = dict(action = 'foo')
    static_vars = dict(local_action = 'foo')

    action, args, delegate_to = module_args_parser_1.parse(task_ds)


# Generated at 2022-06-25 03:50:24.214094
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True

# Generated at 2022-06-25 03:50:28.755742
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser(task_ds=dict(action=dict(module='debug', msg='hi')))
    assert module_args_parser_1.parse()[0] == 'debug'
    assert module_args_parser_1.parse()[1]['msg'] == 'hi'
    module_args_parser_2 = ModuleArgsParser(task_ds=dict(action='debug msg="hi"'))
    assert module_args_parser_2.parse()[0] == 'debug'
    assert module_args_parser_2.parse()[1]['msg'] == 'hi'
    module_args_parser_3 = ModuleArgsParser(task_ds=dict(action='debug', msg='hi'))
    assert module_args_parser_3.parse()[0] == 'debug'
    assert module

# Generated at 2022-06-25 03:50:39.884741
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0_data = {}
    module_args_parser_0 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == '_ansible_internal_action'
    assert args == {'_ansible_internal_only_module': '_setup', '_ansible_internal_action': '_command'}

    data = {}
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == '_ansible_internal_action'
    assert args == {'_ansible_internal_only_module': '_setup', '_ansible_internal_action': '_command'}

    data = {'action': 'ping'}
    module_args_

# Generated at 2022-06-25 03:50:46.025212
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'foo'
    args = {'arg1': '1', 'arg2': '2'}
    delegate_to = 'my-server'
    test_inputs = {'0': {'action': 'foo: arg1=1 arg2=2', 'local_action': 'foo: arg1=1'},
                   '1': {'foo': 'arg1=1 arg2=2', 'local_action': 'foo: arg1=1'},
                   '2': {'action': {'module': 'foo: arg1=1 arg2=2', 'delegate_to': 'my-server'}, 'local_action': {'module': 'foo: arg1=1'}}}

# Generated at 2022-06-25 03:50:53.256813
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task = dict(action=dict(module='command', args='{{test_var}}'))
    expected_task = dict(action='command', args=dict(_variable_params='{{test_var}}'))
    actual_task = module_args_parser.parse(task)
    assert actual_task == expected_task


# Generated at 2022-06-25 03:50:54.415492
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0()

try:
    import __builtin__ as builtins
except ImportError:
    import builtins


# Generated at 2022-06-25 03:51:17.799446
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test for syntax
    test_module_args_parser_1 = ModuleArgsParser({'action': 'command'})
    assert module_args_parser_0.parse() ==  (u'command', {'_uses_shell': False}, None)
    # test for syntax
    test_module_args_parser_2 = ModuleArgsParser({'action': 'command', 'args': 'command'})
    assert module_args_parser_0.parse() ==  (u'command', {'_uses_shell': False}, None)
    # test for syntax
    test_module_args_parser_3 = ModuleArgsParser({'action': 'command', 'args': {'command': 'ls'}})
    assert module_args_parser_0.parse() ==  (u'command', {'command': u'ls'}, None)
    #

# Generated at 2022-06-25 03:51:23.417080
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    action_arg = 'file'

    task_dict = {action_arg: 'copy src=a dest=b'}
    module_args_parser = ModuleArgsParser()

    # Act
    actual = module_args_parser.parse()

    # Assert
    expected = ('file', 'copy src=a dest=b', None)
    assert(type(actual) == tuple)
    assert(len(actual) == 3)
    assert(actual == expected)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:51:34.529737
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    import sys
    from ansible.module_utils.six import PY3

    if PY3:
        long = int

    # Copy the test file for use in the task
    fd_write, temp_task_file = tempfile.mkstemp()
    with open(temp_task_file, "w") as wfh:
        with open(TEST_DATA_ROOT + '/parse_module_args.yaml', "r") as fh:
            wfh.write(fh.read())

    # Read the file
    try:
        task_ds = Task.load(temp_task_file).get_data()
    finally:
        os.close(fd_write)

# Generated at 2022-06-25 03:51:41.402334
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test input
    args = dict()

    # Expected output
    expected_action, expected_arguments, expected_delegate_to = ("module_name", dict(), None)

    # Result
    result_action, result_arguments, result_delegate_to = ("module_name", dict(), None)

    # Check if expected and result are the same
    assert expected_action == result_action
    assert expected_arguments == result_arguments
    assert expected_delegate_to == result_delegate_to

# Generated at 2022-06-25 03:51:49.624355
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test parse
    '''
    module_args_parser_0 = ModuleArgsParser()
    arg1 = dict(action=dict(module='copy', src='a', dest='b'))
    arg2 = dict(action='shell echo hi')
    arg3 = dict(action=dict(module='ping', data='pong'))
    arg4 = dict(module='shell', args='echo hi')
    arg5 = dict(module='shell', args={'CHDIR': '/tmp'})
    arg6 = dict(action=dict(module='shell', args='echo hi', CHDIR='/etc'))
    arg7 = dict(action=dict(module='shell', _raw_params='echo hi', _uses_shell=False))

# Generated at 2022-06-25 03:52:00.989590
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # print("Unit test for Method parse of class ModuleArgsParser")

    # Case 0:
    module_args_parser_0 = ModuleArgsParser(task_ds={}, collection_list=None)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == None
    assert args == None
    assert delegate_to == None

    # Case 1:
    module_args_parser_1 = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'}, collection_list=None)
    action, args, delegate_to = module_args_parser_1.parse()
    assert action == 'copy'
    assert args == {'dest': 'b', 'src': 'a'}
    assert delegate_to == None

    # Case 2:
    module_args_parser_2

# Generated at 2022-06-25 03:52:11.957166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Test ModuleArgsParser_parse")
    task_ds = {'action': 'pwd'}
    module_args_parser_0 = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == 'pwd'
    assert args == {}
    assert delegate_to is None
    task_ds = {'action': 'pwd', 'args': {'chdir': '/tmp'}}
    module_args_parser_0 = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == 'pwd'
    assert args == {'chdir': '/tmp'}
    assert delegate_to is None

# Generated at 2022-06-25 03:52:24.741126
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n# Unit test for method parse of class ModuleArgsParser")
    task_ds = {
        "action": {
            "module": "test_module_1"}
        }

    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0.parse()

    module_args_parser_1 = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = module_args_parser_1.parse()
    # since the 'thing' is only a { _raw_params: 'echo hi' } dictionary, it should be None
    assert action is None
    # since the 'thing' is only a { _raw_params: 'echo hi' } dictionary, it should be None
    assert args is None
    assert delegate_to == Sentinel


# Generated at 2022-06-25 03:52:27.376250
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() is not None



# Generated at 2022-06-25 03:52:40.028285
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fixture_0 = open('./test/fixtures/unittest_module_args_parser_parse_fixture_0.yml', 'r')
    fixture_0_task_ds = yaml.safe_load(fixture_0)
    fixture_0.close()
    module_args_parser_0 = ModuleArgsParser(fixture_0_task_ds)
    assert module_args_parser_0.parse() == ('setup', {'filter': 'ansible_distribution'}, 'localhost')

fixture_1 = open('./test/fixtures/unittest_module_args_parser_parse_fixture_1.yml', 'r')
fixture_1_task_ds = yaml.safe_load(fixture_1)
fixture_1.close()
module_args_parser_1

# Generated at 2022-06-25 03:53:01.295760
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # AnsibleModuleArgsParser.parse should return (dict(action="shell", args=dict(free_form="echo hi")), None)
    # for task_ds=dict(action="shell echo hi")
    module_args_parser_0 = ModuleArgsParser()
    task_ds = dict(action="shell echo hi")
    action, args, delegate_to = module_args_parser_0.parse(task_ds)
    assert (action, args, delegate_to) == ("shell", dict(free_form="echo hi"), None)

    # AnsibleModuleArgsParser.parse should return (dict(action="ec2", args=dict(region="xyz")), None)
    # for task_ds=dict(ec2=dict(region="xyz"))
    module_args_parser_0 = ModuleArgsParser()

# Generated at 2022-06-25 03:53:06.302568
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # simple no args
    task_ds_0 = {"action":"module1"}
    module_args_parser_0 = ModuleArgsParser(task_ds_0)
    assert (module_args_parser_0.parse() == ("module1",{},Sentinel))

    # simple no args
    task_ds_0 = {"action":"module1","delegate_to":"1.2.3.4"}
    module_args_parser_0 = ModuleArgsParser(task_ds_0)
    assert (module_args_parser_0.parse() == ("module1",{},"1.2.3.4"))

    # simple
    task_ds_0 = {"action":"module1","arg1":"value1"}
    module_args_parser_0 = ModuleArgsParser(task_ds_0)

# Generated at 2022-06-25 03:53:12.342803
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    options = {"action": 'shell echo hi', "delegate_to": 'localhost', "args": {"x": "y"}}
    task_ds = dict()
    task_ds.update(options)
    module_args_parser_0 = ModuleArgsParser(task_ds)
    assert isinstance(module_args_parser_0, ModuleArgsParser)
    excepted_result = ('shell', {'x': 'y', '_raw_params': 'echo hi'}, 'localhost')
    real_result = module_args_parser_0.parse()
    assert real_result == excepted_result
    options = {"action": {'module': 'shell', 'x': 'y'}, "delegate_to": None, "args": {"x": "y"}}
    task_ds = dict()
    task_ds.update(options)

# Generated at 2022-06-25 03:53:15.485800
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_2 = ModuleArgsParser()
    skiptest = False
    try:
        module_args_parser_2.parse()
    except:
        skiptest = True
    assert skiptest == False


# Generated at 2022-06-25 03:53:19.176241
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action, args, delegate = module_args_parser.parse()
    print('action = ', action, ' args = ', args, ' delegate = ', delegate)


# Generated at 2022-06-25 03:53:21.599453
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0.parse()


# Generated at 2022-06-25 03:53:29.153811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # This is the json data structure to be converted into python object
    input_dict = {
        "action": "copy src=a dest=b",
        "delegate_to": "localhost",
        "args": ""
    }

    expected_result = ("copy", {"src": "a", "dest": "b"}, "localhost")

    expected = expected_result
    actual = ModuleArgsParser(collection_list=[], task_ds=input_dict).parse()

    assert expected == actual, "Testcase passed"


# Generated at 2022-06-25 03:53:41.001110
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test examples from module_args_parser.py
    module_args_parser_0 = ModuleArgsParser()
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse()
    assert action_0 is None
    assert args_0 is None
    assert delegate_to_0 is None

    args_1 = dict(
        foo=dict(
            bar='baz',
        ),
        bar='baz',
    )
    module_args_parser_1 = ModuleArgsParser(args_1)
    (action_1, args_2, delegate_to_1) = module_args_parser_1.parse()
    assert action_1 is None
    assert args_2 == args_1
    assert delegate_to_1 is None


# Generated at 2022-06-25 03:53:52.361143
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\nTest ModuleArgsParser_parse\n")
    # TEST CASE 1
    # Test case of args with Module name set to 'shell' and its args to 'echo hi'
    task_ds = dict([('action', '[shell] echo hi')])
    module_args_parser_1 = ModuleArgsParser(task_ds)
    expected_action = 'shell'
    expected_args = dict()
    expected_delegate_to = None
    result_action, result_args, result_delegate_to = module_args_parser_1.parse()
    assert_equals(expected_action, result_action)
    assert_equals(expected_args, result_args)
    assert_equals(expected_delegate_to, result_delegate_to)

    # TEST CASE 2
    # Test case of args with Module

# Generated at 2022-06-25 03:54:05.171574
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:17.621438
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    expected_result = ('setup', {'filter': 'ansible_distribution'}, None)
    actual_result = module_args_parser_1.parse(skip_action_validation=True)
    assert expected_result == actual_result


# Generated at 2022-06-25 03:54:21.069869
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    # test 1
    if (not True):
        raise AssertionError("test_ModuleArgsParser_parse: test 1")


# Generated at 2022-06-25 03:54:28.325739
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Test the ModuleArgsParser::parse() method

    #
    # TODO: Test the module name parsing (removed from method parse)
    #

    #
    # Test the normalization of parameters
    #
    parser = ModuleArgsParser()

    #
    # Module is ping and the task takes no parameters
    #
    action_name = 'ping'
    args = None
    action_arg = None
    (mod_name, parsed_args, delegate_to) = parser._normalize_parameters(action_arg, action_name)
    assert mod_name == action_name
    assert parsed_args == {}

    #
    # Module is ping and the task takes a single parameter
    #
    action_name = 'ping'
    args = {'data': 'foo'}
    action_arg = args
   

# Generated at 2022-06-25 03:54:31.685335
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse(skip_action_validation=False) == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)


# Generated at 2022-06-25 03:54:45.194319
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:47.143994
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert 1 == 1

# Generated at 2022-06-25 03:55:00.228106
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #Test case 1:
    module_args_parser_1 = ModuleArgsParser()
    #get the status of module_args_parser_1

# Generated at 2022-06-25 03:55:03.124657
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, None, None)


# Generated at 2022-06-25 03:55:11.949391
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task = dict(action=dict(module="copy", src="a", dest="b", force=False))
    action, args, delegate_to = module_args_parser_0.parse(task)
    assert action == "copy"
    assert args["dest"] == "b"
    assert args["src"] == "a"
    assert args["force"] is False
    assert delegate_to is None

    module_args_parser_1 = ModuleArgsParser()
    task = dict(local_action=dict(module="copy", force=True, src="a", dest="b"))
    action, args, delegate_to = module_args_parser_1.parse(task)
    assert action == "copy"
    assert args["dest"] == "b"

# Generated at 2022-06-25 03:55:19.704696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    test parse method of ModuleArgsParser class
    '''
    module_args_parser = ModuleArgsParser()

    action_dict_0 = {
        "module": "setup",
        "template": "{{ inventory_hostname }}",
        "fact": "ansible_all_ipv4_addresses",
        "path": "/tmp/ansible_facts"
    }

    action_dict_1 = {
        "module": "setup",
        "template": "{{ inventory_hostname }}",
        "fact": "ansible_all_ipv4_addresses",
        "path": "/tmp/ansible_facts"
    }

# Generated at 2022-06-25 03:55:50.628358
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys

    if sys.version_info[0] < 3:
        task_ds = {'shell': 'ls', 'name': 'list files'}
        module_args_parser = ModuleArgsParser(task_ds)
        (action, args, delegate_to) = module_args_parser.parse()
        assert type(action) is str, "unexpected action %s %s" % (action.__class__.__name__, repr(action))
        assert action == 'shell', "unexpected action %s %s" % (action.__class__.__name__, repr(action))
        assert type(args) is dict, "unexpected args %s %s" % (args.__class__.__name__, repr(args))

# Generated at 2022-06-25 03:55:54.234751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Instantiate a task dict like: { 'action': { 'shell': 'echo hi' } }
    task_ds_0 = dict(action={'shell': 'echo hi'})
    # Instantiate ModuleArgsParser instance
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    # Confirm no exception raised when calling parse without parameters
    g = module_args_parser_0.parse()
    assert True


# Generated at 2022-06-25 03:56:04.542265
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # module is deprecated and not used anymore
    # assert_equal(module_args_parser.parse(command='pwd', module=True), (u'command', {u'_raw_params': u'pwd', u'_uses_shell': True}, None))
    assert_equal(module_args_parser.parse(command='pwd'), (u'command', {u'_raw_params': u'pwd', u'_uses_shell': True}, None))
    assert_equal(module_args_parser.parse(action=dict(module='command', args='pwd')), (u'command', {u'_raw_params': u'pwd', u'_uses_shell': True}, None))
    # legacy no longer supported
    # assert_equal(module_args_parser.

# Generated at 2022-06-25 03:56:06.884273
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # No test for parse in ModuleArgsParser
    pass


# Generated at 2022-06-25 03:56:09.658516
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse()
    assert(action) == None
    assert(args) == {}
    assert(delegate_to) == None


# Generated at 2022-06-25 03:56:20.599911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test basic parsing
    ds = dict(action="test-action --test-arg=test-val")
    parser = ModuleArgsParser(task_ds=ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'test-action'
    assert delegate_to is None
    assert 'test-arg' in args
    assert args['test-arg'] == 'test-val'

    # Test complex args
    ds = dict(action="test-action --test-arg-1=test-val-1 --test-arg-2=test-val-2")
    parser = ModuleArgsParser(task_ds=ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'test-action'
    assert delegate_to is None

# Generated at 2022-06-25 03:56:31.477833
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    (action, args, delegate_to) = ModuleArgsParser().parse(task_ds={'module': 'setup'}, collection_list=None)
    assert(action == 'setup')
    assert(args == {})
    (action, args, delegate_to) = ModuleArgsParser().parse(task_ds={'action': 'setup', 'args': {'x': 1}}, collection_list=None)
    assert(action == 'setup')
    assert(args == {'x': 1})
    (action, args, delegate_to) = ModuleArgsParser().parse(task_ds={'action': 'setup', 'delegate_to': 'localhost'}, collection_list=None)
    assert(action == 'setup')
    assert(args == {})

# Generated at 2022-06-25 03:56:37.866975
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    test_input_task_ds = {'action': 'shell', 'args': {'chdir': '/tmp'}, 'delegate_to': Sentinel, 'test_input_task_ds_key_0': 'test_input_task_ds_val_0', 'test_input_task_ds_key_1': 'test_input_task_ds_val_1', 'test_input_task_ds_key_2': 'test_input_task_ds_val_2'}
    test_input_skip_action_validation = True
    expected_result = (True, True, True)
    result = module_args_parser_0.parse(test_input_task_ds, test_input_skip_action_validation)

# Generated at 2022-06-25 03:56:47.190971
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # argument initialization
    thing = 'copy'
    skip_action_validation = False
    # expected = ('copy', {}, None)
    ans = module_args_parser_0.parse(thing, skip_action_validation)
    # print(module_args_parser_0._task_ds)
    assert ans == ('copy', None, None)


    thing = 'shell'
    skip_action_validation = False
    # expected = ('shell', {}, None)
    ans = module_args_parser_0.parse(thing, skip_action_validation)
    # print(module_args_parser_0._task_ds)
    assert ans == ('shell', {}, None)



# Generated at 2022-06-25 03:56:54.503968
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    module_args_parser = ModuleArgsParser()
    task_ds = {
        'task1': {
            'action': {
                'module': 'copy',
                'src': 'file1',
                'dest': 'file2'
            }
        }
    }

    expected_action = 'copy'
    expected_args = {
        'src': 'file1',
        'dest': 'file2'
    }
    expected_delegate_to = Sentinel

    # Act
    (action, args, delegate_to) = module_args_parser.parse(task_ds['task1'])

    # Assert
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to

# Generated at 2022-06-25 03:57:36.627548
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_string0 = 'shell echo hi'
    task_ds0 = {'action': args_string0}
    module_args_parser0 = ModuleArgsParser(task_ds0)
    action0, args0, delegate_to0 = module_args_parser0.parse()
    assert (action0 == 'shell')
    assert (args0['_raw_params'] == args_string0)


# Generated at 2022-06-25 03:57:39.809103
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # initial object
    test_parser = ModuleArgsParser()
    # test unmarshalled object
    test_parser.parse()

if __name__ == "__main__":
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:57:41.778866
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # case 0
    test_case_0()


# Generated at 2022-06-25 03:57:46.850288
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yaml_str = '''
    - name: Create log directory
      file:
        state: directory
        path: /var/log/ansible
    '''

    from ansible.parsing.yaml.objects import AnsibleUnicode
    result_0 = ModuleArgsParser.parse(yaml_str)

# Generated at 2022-06-25 03:57:57.154976
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    yml_string_0 = """
    - name: Test name on_any
      block:
        - name: Test name on_changed
          block:
            - debug:
                msg: Test msg
          rescue:
            - debug:
                msg: Test msg
          always:
            - debug:
                msg: Test msg
          when: A == B
      rescue:
        - debug:
            msg: Test msg
      always:
        - debug:
            msg: Test msg
      when: A == B
    """
    task_ds_0 = yaml.load(yml_string_0, Loader=yaml.FullLoader)
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    # Parses a task in one of the supported forms, returns the action, arguments, and

# Generated at 2022-06-25 03:58:01.330351
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse()
