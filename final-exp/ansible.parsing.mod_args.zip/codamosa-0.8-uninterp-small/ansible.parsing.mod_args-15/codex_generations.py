

# Generated at 2022-06-25 03:48:45.140211
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_data = dict(
        action='shell echo hi',
        module='shell echo hi',
        local_action='shell echo hi',
        thing='shell echo hi',
        module_args='shell echo hi',
        module_arguments='shell echo hi',
        arguments='shell echo hi',
    )

    module_args_parser = ModuleArgsParser(task_ds=test_data)
    parse = module_args_parser.parse()
    assert parse[0] == 'shell'
    assert parse[1] == {'_raw_params': 'echo hi'}
    assert parse[2] == Sentinel


# Generated at 2022-06-25 03:48:55.177698
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # The test case
    parser = ModuleArgsParser(task_ds={'action': 'shell echo "hi" | mail -s "test" joe@joe.com'})
    (action, args, delegate_to) = parser.parse()
    print("action: " + action)
    print("args: " + str(args))
    print("delegate_to: " + delegate_to)

    parser = ModuleArgsParser(task_ds={'action': {'module': 'shell', 'args': 'echo "hi" | mail -s "test" joe@joe.com'}})
    (action, args, delegate_to) = parser.parse()
    print("action: " + action)
    print("args: " + str(args))
    print("delegate_to: " + delegate_to)

# Unit

# Generated at 2022-06-25 03:48:59.434716
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    try:
        module_args_parser_0.parse()
    except TypeError as e:
        if "parse() takes at least 2 arguments (1 given)" in to_text(e):
            pass
        else:
            raise


# Generated at 2022-06-25 03:49:05.963695
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0.parse()

if __name__ == '__main__':
    args = sys.argv[1:]
    if len(args) == 0:
        print ("test_ModuleArgsParser.py -a test_case_0")
        sys.exit(2)

    if args[0] == "-a":
        test_case_name = args[1]
        if test_case_name == "test_case_0":
            test_case_0()
        if test_case_name == "test_ModuleArgsParser_parse":
            test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:49:12.693081
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser

    # Note: when calling ModuleArgsParser.parse() we do not pass _task_ds,
    # _collection_list. This is because _task_ds is unused in ModuleArgsParser.parse()
    # and we have not implemented _collection_list yet.
    (action, args, delegate_to) = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

# Generated at 2022-06-25 03:49:20.197397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # User defined parameters
    thing = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    action = None
    additional_args = {'chdir': '/tmp'}
    action_module = 'copy'
    args_dict = {'src': 'a', 'dest': 'b', 'chdir': '/tmp'}
    delegate_to = None
    expect_action = action_module
    expect_args_dict = args_dict
    expect_delegate_to = delegate_to

    # Ansible return data
    raw_params_to_args_dict = {'_raw_params': 'src=a dest=b',
                               'src': 'a', 'dest': 'b'}

    # The code to be tested
    module_args_parser_1 = ModuleArgsParser()
    result

# Generated at 2022-06-25 03:49:27.682910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    input = {'hosts': 'localhost'}
    action, args, delegate_to = module_args_parser.parse(input)

    assert action == 'setup'
    assert not args
    assert delegate_to == Sentinel


# Generated at 2022-06-25 03:49:31.272486
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_1.parse()

    assert(False)


# Generated at 2022-06-25 03:49:37.862166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser({'local_action': 'wait_for host=127.0.0.1 port=22 search_regex=OpenSSH state=started'})
    result = module_args_parser.parse()
    assert result == ('wait_for', {'host': '127.0.0.1', 'port': '22', 'search_regex': 'OpenSSH', 'state': 'started'}, 'localhost'), "The method parse returned an unexpected result: %s" % result


# Generated at 2022-06-25 03:49:42.637326
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method parse of class ModuleArgsParser
    """
    module_args_parser = ModuleArgsParser()
    task_ds = {
        "action": {"module": "shell", "echo": "hi", "_uses_shell": "True"}
    }
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    assert action == "shell"


# Generated at 2022-06-25 03:50:04.076392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = None
    args = ALLOWED_ARGS + ['test_host']
    module_args_parser_1 = ModuleArgsParser()
    res_1 = module_args_parser_1.parse(
        dict(action=dict(action='test_action', test_host=dict()), delegate_to='delegate_to')
    )
    assert isinstance(res_1, tuple)
    assert isinstance(res_1[0], str)
    assert res_1[0] == 'test_action'
    assert isinstance(res_1[1], dict)
    assert not OrderedSet(res_1[1].keys()).difference(args)
    assert isinstance(res_1[2], str)
    assert res_1[2] == 'delegate_to'

    args = ALLOWED_AR

# Generated at 2022-06-25 03:50:06.211400
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(task_ds={'a': 1, 'b': 2})
    module_args_parser_0.parse()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:50:13.176823
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test method parse of class ModuleArgsParser
    '''
    # Test for standard YAML command-type modules.
    module_args_parser_1 = ModuleArgsParser(task_ds={'command':'pwd','args':{'chdir':'/tmp'}})
    action, args, delegate_to = module_args_parser_1.parse()
    assert action is not None, 'expect action to be not None'
    assert args is not None, 'expect args is not None'
    assert args['chdir'] == '/tmp', 'expect args["chdir"] is "/tmp"'


# Generated at 2022-06-25 03:50:26.501910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # Create the parser object.
    #
    module_args_parser = ModuleArgsParser()

    #
    # Test with a good command
    #
    cmd = "shell echo hola"
    good_arg = dict()
    good_arg['action'] = 'shell'
    good_arg['args'] = dict()
    good_arg['args']['_raw_params'] = 'echo hola'
    good_arg['args']['_uses_shell'] = True
    (action, args) = module_args_parser._normalize_parameters(cmd, action=None)
    assert good_arg == {'action': action, 'args': args}

    #
    # Test with a good command, with the 'shell' as the module
    #
    cmd = "echo hola"
    good_arg

# Generated at 2022-06-25 03:50:39.057810
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:50:41.348620
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    test_case_0()


# Generated at 2022-06-25 03:50:43.627368
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    with pytest.raises(AnsibleParserError):
        module_args_parser_1.parse()

# Generated at 2022-06-25 03:50:45.700452
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse()
    assert(result == None)



# Generated at 2022-06-25 03:50:53.072803
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test_case_0():
        task_ds_0 = dict(action=dict(module='test-module', args=dict(a='test-a', b='test-b')))
        module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
        module_action_resolved_0, module_args_resolved_0, module_delegate_to_resolved_0 = module_args_parser_0.parse()
        print(module_action_resolved_0)
        print(module_args_resolved_0)
        print(module_delegate_to_resolved_0)

    def test_case_1():
        task_ds_1 = dict(action='test-module test-name')

# Generated at 2022-06-25 03:50:55.366598
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert_raises(AnsibleAssertionError, ModuleArgsParser, None)

    module_args_parser_0 = ModuleArgsParser()

    assert_raises(AnsibleParserError, module_args_parser_0.parse)


if __name__ == "__main__":
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:51:07.171557
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    tested_file = 'tests/unit/parser/fixtures/test_ModuleArgsParser_parse.yml'

# Generated at 2022-06-25 03:51:18.374086
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Assert failure when not able to resolve module because of missing keyword 'action'.
    '''
    with pytest.raises(AnsibleParserError):
        task = {"ec2_key": "{{ec2_key_pair.key_name}}", "delegate_to": "localhost"}
        parser = ModuleArgsParser(task_ds=task)
        parser.parse()
    '''
    Assert failure when more than one action is found in the same task.
    '''
    with pytest.raises(AnsibleParserError):
        task = {"action": "one", "local_action": "two"}
        parser = ModuleArgsParser(task_ds=task)
        parser.parse()
    '''
    Assert failure when action is defined as keyword and as action itself.
    '''

# Generated at 2022-06-25 03:51:25.468553
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('test_ModuleArgsParser_parse')
    module_args_parser = ModuleArgsParser()
    task = {'name': 'copy', 'action': 'copy src=a dest=b'}
    (module_args_parser_return_action, args, delegate_to) = module_args_parser.parse(task_ds=task)
    assert module_args_parser_return_action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    assert delegate_to == None


# Generated at 2022-06-25 03:51:35.411046
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:51:45.298472
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:51:51.985014
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_dict = {'remote_user': None, '_raw_params': '', 'name': 'test_shell.py', 'register': 'shell_out', 'action': 'shell echo hello', 'ignore_errors': False, 'args': {}, 'delegate_to': None}
    module_args_parser.parse(True)

if __name__ == '__main__':
    import inspect
    import types
    # inspect.isclass(E)
    # inspect.ismethod(E)
    # inspect.isfunction(E)
    # inspect.isroutine(E)
    # isinstance(E, types.NoneType)

# Generated at 2022-06-25 03:52:01.202113
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of ModuleArgsParser class
    module_args_parser_1 = ModuleArgsParser()
    # Create an instance of class AnsibleParserError
    ansible_parser_error_obj_1 = AnsibleParserError()
    # Create an instance of class AnsibleError
    ansible_error_obj_1 = AnsibleError()

    # Create a dictionary
    task_ds_1 = dict()
    try:
        # Test case for parsing empty dictionary
        module_args_parser_1.parse(task_ds_1)
        # Expected None
    except AnsibleParserError as ansible_parser_error_obj_1:
        pass
    except AnsibleError as ansible_error_obj_1:
        pass

    # Create a dictionary

# Generated at 2022-06-25 03:52:09.308264
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up
    task_ds_0 = {}
    collection_list_0 = {}
    module_args_parser_0 = ModuleArgsParser(task_ds_0, collection_list_0)

    # Test
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse(skip_action_validation=False)

    # Verify
    assert action_0 is None
    assert args_0 == {}
    assert delegate_to_0 is None

# Generated at 2022-06-25 03:52:11.837790
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: This will raise an Exception if module_args is None. Need to handle that case
    output = module_args_parser_0.parse()
    assert(isinstance(output, tuple))


# Generated at 2022-06-25 03:52:17.776028
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {'action': {'shell': 'echo hi'},
               'delegate_to': 'localhost',
               'args': {'chdir': '/tmp'},
               'module': 'copy',
               'src': 'src_file',
               'dest': 'dest_file',
               'friends': 'yes'}
    skip_action_validation = False
    (action, args, delegate_to) = module_args_parser.parse(task_ds, skip_action_validation)
    assert action == 'copy'
    assert args == {'src': 'src_file',
                    'dest': 'dest_file'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:52:25.795540
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation = True)
    
    assert action == None
    assert args == None
    assert delegate_to == None


# Generated at 2022-06-25 03:52:33.281589
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    dict_input = {'ping': {'data': 'pong'}}
    # Instantiate ModuleArgsParser class
    module_args_parser = ModuleArgsParser(dict_input)
    # Call method parse on instance
    result = module_args_parser.parse()
    # Test result:
    assert result == ('ping', {'data': 'pong'}, None)
    # Test result:
    assert module_args_parser.resolved_action == 'ping'


# Generated at 2022-06-25 03:52:40.192616
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    try:
        module_args_parser_0.parse()
    except Exception as e:
        if e.args[0] != "no module/action detected in task.":
            raise RuntimeError(str(e))
    else:
        raise RuntimeError("Test failed")


# Generated at 2022-06-25 03:52:41.270964
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    print(module_args_parser.parse())

# Generated at 2022-06-25 03:52:47.334040
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Unit test for ModuleArgsParser, method parse
    module_args_parser = ModuleArgsParser()

    task_ds = {
        "action": {
            "module": "copy",
            "args": "src=a dest=b"
        },
        "delegate_to": "example.com"
    }
    action, args, delegate_to = module_args_parser.parse()

    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'example.com'

# Generated at 2022-06-25 03:52:56.478165
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    context = ansible.context.CLIARGS._store
    context['ANSIBLE_CONFIG'] = dirname(__file__) + "/../../module_utils/module_args_parser.cfg"
    module_args_parser_0 = ModuleArgsParser()

    def test_case_1():
        task_ds = {"action": "ec2", "region": "xyz"}
        delegate_to = None
        ModuleArgsParser_parse(module_args_parser_0, task_ds, delegate_to)

    def test_case_2():
        task_ds = {"action": "ec2", "region": "xyz"}
        delegate_to = 'localhost'
        ModuleArgsParser_parse(module_args_parser_0, task_ds, delegate_to)


# Generated at 2022-06-25 03:53:05.524156
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 1:
    # parse parameters:
    # action: shell echo hi
    # expected value:
    # ('shell', {u'_raw_params': u'echo hi'}, Sentinel)
    test_case_1_task_ds = {}
    test_case_1_task_ds['action'] = 'shell echo hi'
    # test_case_1_task_ds['delegate_to'] = 'localhost'
    test_case_1_expected = ('shell', {'_raw_params': 'echo hi'}, Sentinel)
    module_args_parser_1 = ModuleArgsParser(test_case_1_task_ds)
    test_case_1_actual = module_args_parser_1.parse()
    assert test_case_1_expected == test_case_1_actual

    # Test case 2:

# Generated at 2022-06-25 03:53:11.679402
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    json_data = {
            'action': 'copy',
            'local_action': 'shell echo hi',
            'module': 'ec2',
            'src': 'a',
            'dest': 'b'
    }
    module_args_parser_1 = ModuleArgsParser(task_ds=json_data)
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:53:14.888549
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print ("\n========== test_ModuleArgsParser_parse ==========")
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse()
    #print ("\nresult:", result)


# Generated at 2022-06-25 03:53:22.767999
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with open(REAL_TASK_YAML, 'rb') as real_task_fd:
        real_task_dict = yaml.safe_load(real_task_fd)

    for test_case in real_task_dict:
        try:
            test_case_obj = TestCase(test_case)
            test_case_obj.run()
        except Exception as e:
            raise AnsibleAssertionError(e)


# Generated at 2022-06-25 03:53:30.952338
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:53:37.476033
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Data setup
    parser = ModuleArgsParser()
    action = ''
    args = ''
    delegate_to = ''


    # Test 0: No arguments

    action, args, delegate_to = parser.parse()
    assert isinstance(action, string_types)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, Sentinel)

    # Test 1:

    action, args, delegate_to = parser.parse(skip_action_validation=True)

    assert isinstance(action, string_types)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, Sentinel)


# Test data setup
target_action_0 = ("pwd", {}, Sentinel)
target_action_1 = ('echo', {'_variable_params': '"{{ foo }}"'}, Sentinel)


# Generated at 2022-06-25 03:53:50.391849
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:53:59.814232
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:06.790987
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # inputs
    task_ds = dict(action='shell', local_action='copy', delegate_to='xyz', args='echo hi', xyz='echo $PATH')
    # output
    (action, args, delegate_to) = (None, None, None)

    # test
    module_args_parser_1 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_1.parse()

    assert action == 'shell'
    assert args == None
    assert delegate_to == None



# Generated at 2022-06-25 03:54:15.141980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = {
        'delegate_to': 'localhost',
        'module': 'powershell',
        'args': 'Get-ComputerInfo',
        'register': 'comp_info'
    }

    module_args_parser_0 = ModuleArgsParser(task_ds_0)

    if C.DEFAULT_MODULE_LANG:
        module_args_parser_0.parse()
        assert (module_args_parser_0.resolved_action == 'powershell_module')
    else:
        assert (module_args_parser_0.parse() == ('powershell', 'Get-ComputerInfo', 'localhost'))


# Generated at 2022-06-25 03:54:17.996913
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
        given a task in one of the supported forms, parses and returns
        returns the action, arguments, and delegate_to values for the
        task, dealing with all sorts of levels of fuzziness.
    '''
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == None
    assert args == None
    assert delegate_to == None



# Generated at 2022-06-25 03:54:26.939525
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case data
    thing_0 = {'module': 'ec2', 'x': 1}
    skip_action_validation_0 = False
    thing_1 = {'module': 'ec2', 'x': 1}
    skip_action_validation_1 = True
    thing_2 = {'module': 'ec2', 'x': 1}
    skip_action_validation_2 = False
    thing_3 = {'module': 'ec2', 'x': 1}
    skip_action_validation_3 = True
    thing_4 = {'module': 'ec2', 'x': 1}
    skip_action_validation_4 = False
    thing_5 = {'module': 'ec2', 'x': 1}
    skip_action_validation_5 = True

# Generated at 2022-06-25 03:54:31.169338
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {}
    action, args, delegate_to = module_args_parser.parse(task_ds=task_ds,
                                                         collection_list=None)
    assert action is None
    assert args == {}
    assert delegate_to is None


# Generated at 2022-06-25 03:54:38.493433
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse({'module': 'shell', 'args': {'chdir': '/tmp', 'creates': '/tmp/foo.txt'}})
    assert action == 'shell'
    assert args == {'chdir': '/tmp', 'creates': '/tmp/foo.txt'}
    assert delegate_to is None

    action, args, delegate_to = parser.parse({'module': 'shell', 'chdir': '/tmp', 'creates': '/tmp/foo.txt'})
    assert action == 'shell'
    assert args == {'chdir': '/tmp', 'creates': '/tmp/foo.txt'}
    assert delegate_to is None


# Generated at 2022-06-25 03:54:59.938717
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # Test with normal input:
    # task has one attribute
    task_ds_0 = {'action': 'copy src=a dest=b'}
    result = module_args_parser.parse(task_ds_0)
    module_args_parser_parse_result = ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert module_args_parser.resolved_action is None
    assert result == module_args_parser_parse_result, ("Results do not match expected results "
                                                       "for 'parse' method of class ModuleArgsParser")

    # Test with normal input:
    # Task_ds has multiple attributes
    task_ds_1 = {'action': 'copy src=a dest=b'}
    result = module_args_parser

# Generated at 2022-06-25 03:55:02.785280
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    md_parser = ModuleArgsParser()

    # test case 0
    action, args, delegate_to = md_parser.parse(skip_action_validation=False)


# Generated at 2022-06-25 03:55:11.806896
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()


# Generated at 2022-06-25 03:55:19.580491
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:55:21.566541
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse()
    assert result is None


# Generated at 2022-06-25 03:55:25.383990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 0
    module_args_parser_0 = ModuleArgsParser()
    result_0 = module_args_parser_0.parse()
    assert result_0 == (None, None, None)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:55:30.736771
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Clear data
    module_args_parser_0 = ModuleArgsParser()

    # Testcase 1:
    task_ds_1 = {
        'module': 'command',
        'args': '{{module_args}}',
    }
    actual_result_1 = module_args_parser_0.parse(task_ds=task_ds_1)
    expected_result_1 = ('command', {'_variable_params': '{{module_args}}'}, None)
    assert actual_result_1 == expected_result_1, "Actual result '%s', does not match expected result '%s'." % (actual_result_1, expected_result_1)



# Generated at 2022-06-25 03:55:32.484457
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert module_args_parser_0.parse() == (None, {}, None)

# Unit tests for method __init__ of class ModuleArgsParser

# Generated at 2022-06-25 03:55:42.851450
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    action = None
    delegate_to = None
    args = None
    task_ds = {
        'action': 'ec2_key',
        'name': 'key_name',
        'region': 'us-east-1',
        'register': 'ec2_key',
        'aws_access_key': 'access_key',
        'aws_secret_key': 'secret_key'
    }
    action, args, delegate_to = module_args_parser_0.parse(task_ds)
    print('action: %s' % action)
    print('args: %s' % args)
    assert action == 'ec2_key'

# Generated at 2022-06-25 03:55:49.080918
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    #  Arrange.
    #

    # During the test, we want to test the method parse of class
    # ModuleArgsParser.
    # So, we create the following object, to use it for testing the
    # method:
    module_args_parser_0 = ModuleArgsParser()

    # 'action' is a string which represents the action that the user
    # wants to perform (ex: file, copy, ...)

    # Now, we simulate that the user specified the action 'copy'
    action = 'copy'

    # 'thing' is the args associated to the action.
    # The following dictionary is the value associated to the key 'copy'
    # of the dictionary 'task_ds'.
    # Let's call this dictionary 'thing'
    thing = {'dest': 'test_dest', 'content': 'test_content'}

# Generated at 2022-06-25 03:56:09.290106
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    module_args_parser_0.parse()


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 03:56:14.201645
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test instantiation of ModuleArgsParser
    module_args_parser_0 = ModuleArgsParser()

    # Test code for normal case

    task_ds = {'action': 'copy', 'dest': 'b', 'src': 'a'}
    ModuleArgsParser.parse(module_args_parser_0, task_ds)


# Generated at 2022-06-25 03:56:20.263144
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Unit tests for ModuleArgsParser._split_module_string
    def test_ModuleArgsParser__split_module_string():
        module_args_parser = ModuleArgsParser()

        test_cases = [
            {
                'input': 'shell echo hi',
                'expected': ('shell', "echo hi"),
            },
            {
                'input': 'test',
                'expected': ('test', ""),
            },
        ]
        for test_case in test_cases:
            result = module_args_parser._split_module_string(test_case['input'])

            assert type(result) is tuple
            assert len(result) == 2
            assert result == test_case['expected']

    # Unit tests for ModuleArgsParser._normalize_parameters
    def test_ModuleArgsParser__normalize_parameters():
        module

# Generated at 2022-06-25 03:56:23.248014
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()


# Generated at 2022-06-25 03:56:33.977336
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {'name': 'test', 'some_action': 'some_arg', 'some_other_action': 'some_other_arg'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'some_action'
    assert args == {'some_arg': None}
    assert delegate_to == Sentinel


    task_ds = {'name': 'test', 'some_action': 'arg1=val1 arg2=val2'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'some_action'
    assert args == {'arg1': 'val1', 'arg2': 'val2'}
    assert delegate_to == Sentinel

   

# Generated at 2022-06-25 03:56:45.714084
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 0: action: shell echo arg1 arg2 arg3
    task_ds_0 = {'action': 'shell echo arg1 arg2 arg3'}
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert isinstance(action_0, string_types)
    assert isinstance(args_0, dict)
    assert isinstance(delegate_to_0, Sentinel)
    assert action_0 == 'shell'
    assert args_0['_raw_params'] == 'echo arg1 arg2 arg3'
    assert delegate_to_0 == Sentinel()

    # Test case 1: action: shell echo arg1 arg2 arg3

# Generated at 2022-06-25 03:56:55.219416
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Case 1--nested args form (see docs)
    module_args_parser_1 = ModuleArgsParser(dict(
        module='s3',
        bucket='my_bucket',
        object='my_object',
        mode='put',
        args=dict(
            src='/etc/hosts',
            dest='/tmp/hosts'
        )
    ))
    (action, args, delegate_to) = module_args_parser_1.parse()

    assert action == 's3'
    assert delegate_to is None
    assert len(args) == 2
    assert args['src'] == '/etc/hosts'
    assert args['dest'] == '/tmp/hosts'

    # Case 2--simple string form (see docs)

# Generated at 2022-06-25 03:57:03.592085
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:57:12.240994
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create instance
    module_args_parser = ModuleArgsParser()
    # Test with valid inputs
    test_inputs = [
        # Test case 0
        {
            'action': ['shell', 'echo hi']
        },
        {
            'action': ['shell', 'echo hi']
        },
    ]
    # Expected result
    expected_results = [
        # Expected result for test case 0
        (
            'shell',
            {'_raw_params': 'echo hi', '_uses_shell': True},
            None
        ),
        (
            'shell',
            {'_raw_params': 'echo hi', '_uses_shell': True},
            None
        )
    ]

    # Count number of test cases
    num_test_cases = len(test_inputs)

# Generated at 2022-06-25 03:57:15.265515
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_module_args_parser = ModuleArgsParser()

    # Test of normal case.
    result = test_module_args_parser.parse()

    return

# Generated at 2022-06-25 03:57:46.506578
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up
    task_ds = {
        'action': 'copy src=a dest=b',
        'delegate_to': 'localhost',
    }
    module_args_parser = ModuleArgsParser(task_ds)

    # Exercise
    result = module_args_parser.parse()

    # Assertion
    expected_result = ('copy', {'src': u'a', 'dest': u'b'}, 'localhost')
    assert result == expected_result



# Generated at 2022-06-25 03:57:49.934846
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Calling object of class ModuleArgsParser
    module_args_parser = ModuleArgsParser()
    # Calling method handle of class ModuleArgsParser
    module_args_parser.parse()


# Generated at 2022-06-25 03:57:59.997480
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test method parse of class ModuleArgsParser
    """
    # Test with params action, args  action='shell', args={'_raw_params': 'pwd', 'chdir': '/tmp', 'removes': [], '_uses_shell': True}
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {'action': 'shell pwd'}
    (action_1, args_1, delegate_to_1) = module_args_parser_1.parse(task_ds_1)
    assert action_1 == 'shell'
    assert args_1 == {'_raw_params': 'pwd', 'chdir': '', 'removes': [], '_uses_shell': True}
    assert delegate_to_1 is Sentinel
    # Test with params action, args  action='command

# Generated at 2022-06-25 03:58:10.415895
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # test action statement
    assert ('copy', dict(), Sentinel) == module_args_parser.parse({'action': 'copy'})
    assert ('copy', dict(src='a', dest='b'), Sentinel) == module_args_parser.parse({'action': 'copy src=a dest=b'})
    assert ('copy', dict(src='a', dest='b'), Sentinel) == module_args_parser.parse({'action': 'copy', 'src': 'a', 'dest': 'b'})
    assert ('copy', dict(), Sentinel) == module_args_parser.parse({'action': 'copy', 'src': 'a', 'dest': 'b', 'something': 'else'})
    assert ('copy', dict(src='a', dest='b'), Sentinel) == module_args_parser.parse