

# Generated at 2022-06-25 03:48:43.641106
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME:
    # This is the 'unexpected parameter type in action' error.
    # The unit tests actually expect it and
    # not sure if this is a bug or not
    with pytest.raises(AnsibleParserError) as exc:
        ModuleArgsParser(task_ds='action: "ec2"').parse()
    assert "unexpected parameter type in action: <class 'str'>" in to_text(exc.value)


# Generated at 2022-06-25 03:48:51.571100
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    action_task_ds1 = {
        'action': 'copy src=a dest=b'
    }
    action_task_ds2 = {
        'action': 'copy',
        'args': 'src=a dest=b'
    }
    action_task_ds3 = {
        'action': 'copy'
    }
    action_task_ds4 = {
        'action': {
            'module': 'copy',
            'src': 'a',
            'dest': 'b'
        }
    }
    task_ds = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    task_ds5 = {'copy': 'src=a dest=b'}
    task_ds6 = {'copy': {'src': 'a', 'dest': 'b'}}


# Generated at 2022-06-25 03:49:03.871497
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:09.464778
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    result_1 = module_args_parser_1.parse()
    print ("result_1 is %s" % result_1)
    assert result_1 is None, "result_1 is %s" % result_1


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:49:14.812124
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = dict()
    _collection_list = list()
    module_args_parser = ModuleArgsParser(_task_ds, _collection_list)
    module_args_parser.parse()


# Generated at 2022-06-25 03:49:23.850396
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:30.017938
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task = {'module': 'shell', 'args': 'greeting=hello'}
    expected = ('shell', {'_raw_params': 'greeting=hello'})
    assert parser.parse(task) == expected


# Generated at 2022-06-25 03:49:40.444387
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # [1] test case: with task_ds = {'action': 'shell echo "hello"'} and additional_args = {}, expect results: return example with action: 'shell', args: {'echo': '"hello"'}
    task_ds_0 = {'action': 'shell echo "hello"'}
    additional_args_0 = {}
    module_args_parser_0 = ModuleArgsParser()
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse(task_ds_0, additional_args_0)

    expected_action_0 = 'shell'
    expected_args_0 = {'echo': '"hello"'}
    expected_delegate_to_0 = None

    assert_equal(action_0, expected_action_0)

# Generated at 2022-06-25 03:49:45.006744
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {u'delegate_to': u'localhost', u'local_action': u'shell echo me'}
    action, args, delegate_to = module_args_parser_1.parse(task_ds_1)
    assert action == u'shell'
    assert args == {u'message': u'me'}
    assert delegate_to == u'localhost'


# Generated at 2022-06-25 03:49:52.518913
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_validation = True
    task_ds_0 = dict(action="asdf")
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0, collection_list=None)
    try:
        (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=action_validation)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)


# Generated at 2022-06-25 03:50:29.733325
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = task
    # parse method of ModuleArgsParser
    # The task is copied, so later usage in fixtures will not change the
    # task dict, leading to problems in later tests.
    task_copy = t.copy()
    module_args_parser_0 = ModuleArgsParser(task_copy)
    # parse the task and check if the action and the delegate are resolved correctly
    ret = module_args_parser_0.parse()
    assert ret[0] == "setup"
    assert ret[2] == "{{inventory_hostname_short}}"
    assert ret[1] == dict()

    # module_name is given in task dict as action
    task_copy = t.copy()
    task_copy.update({'action': {'module': 'service', 'name': '{{service_name}}'}})
    module_args

# Generated at 2022-06-25 03:50:42.535176
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    ### 1st example: string_arg, module_name and delegate_to are provided

    # Test 1.1: action - module_name and string_arg are provided
    task_ds_1_1 = {'action': 'ping', 'args': 'abc'}
    module_args_parser_1_1 = ModuleArgsParser(task_ds=task_ds_1_1)
    (action_1_1, args_1_1, delegate_to_1_1) = module_args_parser_1_1.parse()
    assert not (action_1_1 is None)
    assert action_1_1 == 'ping'
    assert not (args_1_1 is None)
    assert args_1_1 == parse_kv('abc', check_raw=False)
    assert delegate_to_1_1 is None



# Generated at 2022-06-25 03:50:51.554772
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser({'action': {'module': 'shell', 'executable': 'echo'}})
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == {'executable': 'echo'}
    assert delegate_to is None

    parser = ModuleArgsParser({'action': 'copy', 'args': 'src=a dest=b'})
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    parser = ModuleArgsParser({'action': 'shell', 'args': {'executable': 'echo'}})
    action, args, delegate_to = parser.parse()
    assert action == 'shell'

# Generated at 2022-06-25 03:51:02.984365
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    testmodule_args = 'src=/tmp/a dest=/tmp/b mode=444'
    expected = ('copy', {'src': '/tmp/a', 'dest': '/tmp/b', 'mode': '444'}, None)
    parsed_args = module_args_parser._normalize_parameters(testmodule_args)
    assert expected == parsed_args, "expected %s, got %s" % (expected, parsed_args)

    testmodule_args = {'shell': 'echo hi && ls -alh', 'chdir': '/tmp'}
    expected = ('shell', {'chdir': '/tmp', '_raw_params': 'echo hi && ls -alh'}, None)
    parsed_args = module_args_parser._normalize_parameters(testmodule_args)

# Generated at 2022-06-25 03:51:09.965099
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    args = dict()
    delegate_to = Sentinel
    action = 'copy'
    thing = dict(src='a', dest='b')
    action, delegate_to = module_args_parser_1.parse()


# Generated at 2022-06-25 03:51:15.311767
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_1.parse()
    assert (action == None)
    assert (args == None)
    assert (delegate_to == None)


# Generated at 2022-06-25 03:51:23.120720
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

# Generated at 2022-06-25 03:51:34.255929
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 0
    print("Test case 0: Normal operation")

    # arg_0 contains a string
    arg_0 = {"action": "shell",
             "args": "echo foo",
             "delegate_to": "foo"}

    task_ds_0 = copy.deepcopy(arg_0)

    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)

    expected_0 = (
        "shell",
        {"_raw_params": "echo foo"},
        "foo"
    )

    (actual_0, actual_1, actual_2) = module_args_parser_0.parse()

    assert actual_0 == expected_0[0], 'Expected: %s, Actual: %s' % (expected_0[0], actual_0)
    assert actual_1

# Generated at 2022-06-25 03:51:41.486865
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Act
    # the method is called with arguments:
    # - self: instance of the calling class, of type ModuleArgsParser
    # - skip_action_validation: variable of type bool
    #
    # Note: The output of the method is discarded in the unit tests, so
    #       this is not taken into account.
    #
    # Arrange
    step = 'Arrange'
    module_args_parser_0 = ModuleArgsParser()

    # Assert
    step = 'Assert'
    assert(True)


# Generated at 2022-06-25 03:51:43.636406
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {}
    collection_list_0 = []
    module_args_parser_0.parse(task_ds=task_ds_0, collection_list=collection_list_0)


# Generated at 2022-06-25 03:52:22.012004
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: added
    module_args_parser_0 = ModuleArgsParser()
    # test arguments
    task_ds = "copy src=a dest=b"
    # expected result:
    # copy ['src=a', 'dest=b']
    expected_0 = (
        "copy",
        {"src": "a", "dest": "b"},
        None
    )
    try:
        result_0 = module_args_parser_0.parse(task_ds)
    except Exception as e:
        e = e
        print("Failed to parse module arguments due to: %s" % e)
    else:
        assert result_0 == expected_0


# Generated at 2022-06-25 03:52:30.871019
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:43.778545
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # To test parse() method of class ModuleArgsParser
    module_args_parser = ModuleArgsParser()

    # Case 1:
    # To test when action is invalid
    task_ds_0 = {'action': 'invalid'}
    result_0 = module_args_parser.parse(skip_action_validation=False, task_ds=task_ds_0)
    assert result_0 == (None, None, None)

    # Case 2:
    # To test when task_ds is None
    task_ds_1 = None
    result_1 = module_args_parser.parse(skip_action_validation=False, task_ds=task_ds_1)
    assert result_1 == (None, None, None)

    # Case 3:
    # To test when delegate_to is not in the task_ds


# Generated at 2022-06-25 03:52:46.972585
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    task_ds = dict()
    collection_list = ['name', 'collection_name']
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    # Act
    action, args, delegate_to = module_args_parser.parse()

    # Assert
    assert action == None


# Generated at 2022-06-25 03:52:56.677772
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'action: shell echo hi',
        'a': '1',
        'b': '2',
        'args': 'c=3',
        'delegate_to': '4'
        }
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = module_args_parser.parse()
    message = """
    Parse task: {{action: shell echo hi}} a=1 b=2 {args:c=3} delegate_to=4
    should return (action='shell', args={'echo':'hi', 'a':'1', 'args':'c=3', 'b':'2'}, delegate_to='4')
    """

    if action != 'shell':
        print("Test failed." + message)

# Generated at 2022-06-25 03:52:59.886111
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert action_0 == None
    assert args_0 == {}
    assert delegate_to_0 == None


# Generated at 2022-06-25 03:53:11.457150
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    module_args_parser.parse(skip_action_validation=False)

    Test case for method parse of class ModuleArgsParser

    Parameters:
        skip_action_validation=False

    Returns:
        (action, args, delegate_to)

    Raises:
        Exception
    '''
    # Initialise test data
    #
    # parameter for method parse
    skip_action_validation = False
    #
    # class constructor args
    task_ds = {}
    collection_list = None
    #
    module_args_parser = ModuleArgsParser(task_ds, collection_list)

    # Execute
    try:
        ret = module_args_parser.parse(skip_action_validation)
    except Exception as e:
        raise e


# Generated at 2022-06-25 03:53:12.024915
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False


# Generated at 2022-06-25 03:53:23.751265
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    string_0 = 'echo hi'
    string_1 = 'shell'
    dict_0 = {'region': 'xyz'}
    string_2 = 'ec2'
    dict_1 = {'region': 'xyz'}
    string_3 = 'ec2'
    string_4 = 'copy src=a dest=b'
    string_5 = 'ping'
    dict_2 = {'_raw_params': 'echo hi', '_uses_shell': True}
    dict_3 = {'module': 'ec2', 'x': 1}
    string_6 = 'ec2'
    dict_4 = {'x': 1}
    dict_5 = {'action': {'copy': 'src=a dest=b'}}
    dict_

# Generated at 2022-06-25 03:53:29.613405
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # The function ModuleArgsParser.parse() is tested from test_case_6()

    # Returns none
    return None


# Generated at 2022-06-25 03:54:05.401099
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        # Create the object for class ModuleArgsParser
        module_args_parser_0 = ModuleArgsParser()

        # Test method parse with the arguments provided
        (action, args, delegate_to) = module_args_parser_0.parse()
    except Exception as e:
        print("Exception in test_ModuleArgsParser_parse(): ")
        print(e)
        print(e.args)



# Generated at 2022-06-25 03:54:16.123331
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    #
    # Test action key with value as a dictionary type
    #
    thing_0={'ec2_key': {'order_id': '12345', 'xyz': 'abc'}}
    expected_result_0 = ('ec2_key', {'order_id': '12345', 'xyz': 'abc'}, Sentinel)
    task_ds_0 = thing_0
    module_args_parser_0 = ModuleArgsParser(task_ds_0)
    result_0 = module_args_parser_0.parse()
    assert isinstance(result_0, tuple)
    assert len(result_0) == 3
    assert result_0 == expected_result_0

    #
    # Test action key with value as a dictionary type.
    # And with delgate_to set, then delgate_to is sent back.

# Generated at 2022-06-25 03:54:25.833090
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create object of class ModuleArgsParser
    module_args_parser_0 = ModuleArgsParser()

    # Create instance of resource type dictionary
    task_ds_0 = {}

    defaults_0 = {}

    # Test case with invalid inputs
    # def parse(task_ds, skip_action_validation=False):
    # return (action, args, delegate_to)

    # Test case with valid inputs
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {'action': {'_ansible_no_log': 'true', '_ansible_verbosity': '4'}, 'delegate_to': 'inventory_hostname'}
    defaults_0 = {}

    # Excepcted error
    err_0 = ''
    # Actual error
    err_1 = ''

# Generated at 2022-06-25 03:54:35.154513
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # 1. Task contains no module names

    task_ds = dict(
        action = dict(
            module = 'copy',
            src = 'a',
            dest = 'b'
        )
    )
    try:
        module_args_parser = ModuleArgsParser(task_ds)
        action, args, delegate_to = module_args_parser.parse()
        assert False, 'There is no exception raised'
    except AnsibleParserError as e:
        assert True, 'AnsibleParserError is raised'
        assert e.obj == task_ds, 'The error contains equal task_ds'
        assert e.message == "no module/action detected in task."

    # 2. Task contains more than one module names

    task_ds = dict

# Generated at 2022-06-25 03:54:40.585396
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = dict()
    collection_list_0 = list()
    action_0, args_0, delegate_to_0 = ModuleArgsParser(task_ds_0, collection_list_0).parse()


# Generated at 2022-06-25 03:54:53.128968
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:59.864623
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
   

# Generated at 2022-06-25 03:55:07.932003
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Create an instance of the ModuleArgsParser class
    module_args_parser = ModuleArgsParser()

    # Create a variable to hold the actions
    actions = []

    # Create a variable that contains a task with an action
    task = {'action': {'module': 'copy', 'src': 'file.txt', 'dest': '/etc/file.txt'}}

    # Create a variable that contains the action expected to be parsed
    expected = "copy"

    # Parse the task
    (action, args, delegate_to) = module_args_parser.parse(task)

    # Append the action parsed to the actions variable
    actions.append(action)

    # Check if the actions variable contains the expected variable
    assert expected in actions


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgs

# Generated at 2022-06-25 03:55:14.911429
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Arrange
    module_args_parser = ModuleArgsParser()
    task_ds = {'module_name': 'test-module', 'args': {'arg1': 'arg1-value'}}
    skip_action_validation = True

    # Act
    action, args, delegate_to = module_args_parser.parse(task_ds, skip_action_validation)

    # Assert
    assert action == 'test-module'
    assert args == {'arg1': 'arg1-value'}
    assert delegate_to is None



# Generated at 2022-06-25 03:55:24.898447
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_ds = dict(name="foobar", action="ping")
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == "ping"
    assert delegate_to is None
    assert args == dict()

    task_ds = dict(name="foobar", ping="")
    module_args_parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert action == "ping"
    assert delegate_to is None
    assert args == dict()


# Generated at 2022-06-25 03:56:43.170454
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # The class ModuleArgsParser is expected to be tested before this method as it
    # creates an instance of ModuleArgsParser to be used in this method
    module_args_parser = ModuleArgsParser()

    # Tests for case 0, not valid task format expected to return error
    task_test_case_0 = {}
    try:
        module_args_parser.parse(task_test_case_0)
    except:
        pass
    else:
        assert False

    # Tests for case 1, action:module input_arg=value format with no delegate_to
    task_test_case_1 = {'action': 'apt: name=nginx state=present'}
    assert module_args_parser.parse(task_test_case_1) == ('apt', {'name': 'nginx', 'state': 'present'}, None)

   

# Generated at 2022-06-25 03:56:47.714419
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

# Generated at 2022-06-25 03:56:55.074774
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test case 0: No action/task specified (empty task_ds)
    task_ds = {}
    module_args_parser_0 = ModuleArgsParser(task_ds)
    assert module_args_parser_0.parse() == (None, {}, Sentinel)

    # Test case 1: action and local_action specified (conflicting action statements)
    task_ds = {'action': 'copy src=a dest=b', 'local_action': 'shell echo hi'}
    module_args_parser_1 = ModuleArgsParser(task_ds)
    with pytest.raises(AnsibleParserError):
        assert module_args_parser_1.parse() == (('copy', {'src': 'a', 'dest': 'b'}, 'localhost'))

    # Test case 2: action specified (multiple tasks specified in task_ds

# Generated at 2022-06-25 03:57:04.812248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case = '{"yum": "name=httpd state=latest"}'
    module_args_parser = ModuleArgsParser()
    # module_args_parser = ModuleArgsParser(test_case)
    module_args_parser.parse()
    # rt = json.loads(module_args_parser.parse())
    # rt = module_args_parser.parse()
    # assert rt == 'yum'


# Generated at 2022-06-25 03:57:13.474181
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.module_utils._text import to_text
    import json
    import ansible.constants as C
    from collections import MutableMapping

    module_args_parser_0 = ModuleArgsParser()
    # normalize a simple new style module invocation
    action, parsed_args, delegate_to = module_args_parser_0.parse({'module': 'copy', 'src': 'a', 'dest': 'b'})
    assert action == 'copy'
    assert parsed_args == {'src': 'a', 'dest': 'b'}
    assert not delegate_to

    # normalize a complex args declaration

# Generated at 2022-06-25 03:57:23.913281
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test attempt to parse null dict
    module_args_parser_0 = ModuleArgsParser()
    try:
        module_args_parser_0.parse()
    except AnsibleAssertionError as e:
        pass

    # Test attempt to parse dict with string key
    module_args_parser_1 = ModuleArgsParser({"action": "echo hi", "delegate_to": "localhost"})
    (action, args, delegate_to) = module_args_parser_1.parse()

    if action != 'echo' or args.get('msg') != 'hi' or delegate_to != 'localhost':
        raise Exception("TEST FAILURE: ModuleArgsParser_parse()")

    # Test attempt to parse dict with dict key
    module_args_parser_2 = ModuleArgsParser({"action": {'echo': "hi"}})

# Generated at 2022-06-25 03:57:37.730118
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1
    task_ds_1 = dict()
    task_ds_1['action'] = 'copy'
    task_ds_1['args'] = 'src=a dest=b'
    module_args_parser_1 = ModuleArgsParser(task_ds_1)
    (action_1, args_1, delegate_to_1) = module_args_parser_1.parse()
    assert action_1 == 'copy'
    assert args_1 == dict()
    assert delegate_to_1 is Sentinel
    # test case 2
    task_ds_2 = dict()
    task_ds_2['action'] = 'copy'
    task_ds_2['static'] = 'src=a dest=b'
    module_args_parser_2 = ModuleArgsParser(task_ds_2)

# Generated at 2022-06-25 03:57:47.601223
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_parse_0 = ModuleArgsParser()
    module_args_parser_parse_1 = ModuleArgsParser()
    module_args_parser_parse_2 = ModuleArgsParser()
    module_args_parser_parse_3 = ModuleArgsParser()
    module_args_parser_parse_4 = ModuleArgsParser()
    module_args_parser_parse_5 = ModuleArgsParser()
    module_args_parser_parse_6 = ModuleArgsParser()
    module_args_parser_parse_7 = ModuleArgsParser()
    # Unit test for method parse of class ModuleArgsParser
    # Testing for case where action is not None
    module_args_parser_parse_0.parse()
    # Testing for case where action is not None
    module_args_parser_parse_1.parse()
    # Testing for case where action is

# Generated at 2022-06-25 03:57:59.841362
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action, args, delegate_to = ModuleArgsParser().parse({'action': 'shell echo hi'})
    assert action == 'shell'
    assert args == {u'_raw_params': u'echo hi'}
    assert delegate_to == Sentinel

    action, args, delegate_to = ModuleArgsParser().parse({'action': {'module': 'shell', 'args': 'echo hi'}})
    assert action == 'shell'
    assert args == {u'_raw_params': u'echo hi'}
    assert delegate_to == Sentinel

    action, args, delegate_to = ModuleArgsParser().parse({'action': 'ec2 x=1'})
    assert action == 'ec2'
    assert args == {u'x': u'1'}
    assert delegate_to == Sentinel

    action, args, delegate_to = Module

# Generated at 2022-06-25 03:58:10.426132
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    success = True
    for test_case in [test_case_0]:
        try:
            test_case()
        except:
            success = False