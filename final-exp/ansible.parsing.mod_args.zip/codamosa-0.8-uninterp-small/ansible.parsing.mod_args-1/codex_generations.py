

# Generated at 2022-06-25 03:48:54.166220
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() == ('setup', {}, None)
    module_args_parser_2 = ModuleArgsParser({'module': 'copy', 'src': 'src', 'dest': 'dest'})
    assert module_args_parser_2.parse() == ('copy', {'src': 'src', 'dest': 'dest'}, None)
    module_args_parser_3 = ModuleArgsParser({'action': 'copy src=src dest=dest'})
    assert module_args_parser_3.parse() == ('copy', {'src': 'src', 'dest': 'dest'}, None)
    module_args_parser_4 = ModuleArgsParser({'action': {'module': 'copy', 'src': 'src', 'dest': 'dest'}})


# Generated at 2022-06-25 03:49:00.379032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_dict = dict(action = dict(shell = "echo hi"))
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(test_dict)
    assert(action == "shell")
    assert("echo hi" in args.values())
    assert(delegate_to == None)

    test_dict = dict(local_action = dict(shell = "echo hi"))
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(test_dict)
    assert(action == "shell")
    assert("echo hi" in args.values())
    assert(delegate_to == "localhost")

    test_dict = dict(shell = "echo hi")
    module_args_parser = ModuleArgsParser()
    action

# Generated at 2022-06-25 03:49:07.239345
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:14.195091
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # testing arguments
    action = None
    args = []
    delegate_to = None
    additional_args = {}

    (ret_action, ret_args, ret_delegate_to) = module_args_parser_0.parse(action, args, delegate_to, additional_args)

    assert isinstance(ret_action, unicode)
    assert isinstance(ret_args, dict)
    assert isinstance(ret_delegate_to, unicode)


# Generated at 2022-06-25 03:49:23.661932
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    ######################################################################################
    # Unit test for parsing the task yaml file in the default location.
    #######################################################################################

    module_args_parser = ModuleArgsParser()

    with open('_test/unit/module_utils/ansible_module_args_parser/echo.yml', 'r') as task_file:
        task = yaml.safe_load(task_file)

    action, args, delegate_to = module_args_parser.parse(task)

    assert action == 'command'
    assert delegate_to == 'localhost'

    ##########################################################################################
    # Unit test for parsing the task yaml file in the specified location.
    ##########################################################################################

    module_args_parser = ModuleArgsParser()



# Generated at 2022-06-25 03:49:31.920665
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    unit test for parse of class ModuleArgsParser
    '''
    print

# Generated at 2022-06-25 03:49:33.669784
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {}
    collection_list = None
    result = module_args_parser.parse(task_ds, collection_list)
    assert result == (None, {}, None)

# Generated at 2022-06-25 03:49:36.425402
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # parent attrs
    test_case0 = dict(action=dict(module='ec2', region='us-east-1'))
    module_parser = ModuleArgsParser(test_case0)
    assert module_parser.parse()[0] == 'ec2'

if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-25 03:49:37.696967
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()


# Generated at 2022-06-25 03:49:43.320532
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        task_ds = []
        collection_list = None
        module_args_parser = ModuleArgsParser(task_ds, collection_list)
        target_action, target_args, target_delegate_to = module_args_parser.parse()
    assert excinfo.value.args[0] == "the type of 'task_ds' should be a dict, but is a <type 'list'>"


# Generated at 2022-06-25 03:50:06.027981
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj_0 = ModuleArgsParser()
    try:
        obj_0.parse()
    except AnsibleParserError as e:
        assert e.message == "no module/action detected in task."
        assert e.obj == obj_0._task_ds
        assert e.exception == None
    except Exception as e2:
        fail("test_ModuleArgsParser_parse: unexpected exception")

    obj_1 = ModuleArgsParser({})
    try:
        obj_1.parse()
    except AnsibleParserError as e:
        assert e.message == "no module/action detected in task."
        assert e.obj == obj_1._task_ds
        assert e.exception == None
    except Exception as e2:
        fail("test_ModuleArgsParser_parse: unexpected exception")

    ###############################################################################
    #

# Generated at 2022-06-25 03:50:14.265418
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    # case 1
    task_ds_1 = {'action': 'test', 'with_items': 'test'}
    result_1 = module_args_parser_1.parse(task_ds_1)
    assert result_1[0] == 'test'

    # case 2
    task_ds_2 = {'action': 'test', 'with_items': 'test', 'args': {'1': '1', '2': '2'}}
    result_2 = module_args_parser_1.parse(task_ds_2)
    assert result_2[0] == 'test'

    # case 3

# Generated at 2022-06-25 03:50:23.593470
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:50:29.095811
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # unit tests for parse method
    module_args_parser = ModuleArgsParser()

    task_dict = { "action": "copy src=a dest=b" }
    (action, args, delegate_to) = module_args_parser.parse(task_ds = task_dict)
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    assert delegate_to == None

    task_dict = { "action": "copy src=a dest=b" }
    (action, args, delegate_to) = module_args_parser.parse(task_ds = task_dict, skip_action_validation=True)
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'

# Generated at 2022-06-25 03:50:31.181449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()



# Generated at 2022-06-25 03:50:36.462212
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # arrange
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = False

    # act
    actual = module_args_parser_0.parse(skip_action_validation)

    # assert
    assert actual is not None


# Generated at 2022-06-25 03:50:46.722484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    log_test_name("test_ModuleArgsParser_parse")

    # module_args_parser_1 - should be a valid task
    # module_args_parser_2 - should be a valid task
    # module_args_parser_3 - should be a valid task
    # module_args_parser_4 - should be a valid task
    # module_args_parser_5 - should be a valid task
    # module_args_parser_6 - should be a valid task
    # module_args_parser_7 - should be a valid task
    # module_args_parser_8 - should be a valid task
    # module_args_parser_9 - should be a valid task
    # module_args_parser_10 - should be a valid task
    # module_args_parser_11 - should be a valid task
    # module_args_parser

# Generated at 2022-06-25 03:50:52.653065
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    ds = dict(action='debug', msg='hello world')
    r_action, r_args, r_delegate_to = parser.parse(ds)
    assert r_action == 'debug'
    assert r_args == {'msg': 'hello world'}
    assert r_delegate_to == None


# Generated at 2022-06-25 03:51:05.220284
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test the case where args is empty
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, {}, None)

    # Test the case where args is not a dict
    with pytest.raises(AnsibleAssertionError) as e_info:
        module_args_parser = ModuleArgsParser(task_ds=1.0)
        assert e_info.value.message == _(r"the type of \'task_ds\' should be a dict, but is a <class \'float\'>")
        assert module_args_parser.parse() == (None, {}, None)

    # Test the case where args has more than one valid actions

# Generated at 2022-06-25 03:51:12.624856
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create the test object
    module_args_parser_1 = ModuleArgsParser()

    # Perform the test computation
    try:
        # This should raise
        module_args_parser_1.parse()
    except AnsibleAssertionError as e:
        print("AssertionException: " + str(e) + "\n")


# Generated at 2022-06-25 03:51:30.768539
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    #Case 1
    print("Testing ModuleArgsParser class - case 1")
    module_args_parser_0.parse()
    #Case 2
    print("Testing ModuleArgsParser class - case 2")
    module_args_parser_0.parse("skip_action_validation=True")
    #Case 3
    print("Testing ModuleArgsParser class - case 3")
    module_args_parser_0.parse("skip_action_validation = True")
    #Case 4
    print("Testing ModuleArgsParser class - case 4")
    module_args_parser_0.parse("skip_action_validation=false")
    #Case 5
    print("Testing ModuleArgsParser class - case 5")
    module_args_parser_0.parse("skip_action_validation = False")

# Generated at 2022-06-25 03:51:41.099539
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Parse a task definition for the module name and arguments
    '''
    # Setup loader and task data structure
    module_args_parser_0 = ModuleArgsParser()
    task_ds = {"action": "shell echo hi"}
    # Exercise parse
    result = module_args_parser_0.parse(skip_action_validation=False)
    ### Assert result
    assert result[0] == 'shell'
    assert result[1] == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert result[2] is None


# Generated at 2022-06-25 03:51:45.069367
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Test the module args parser.
    """
    parser = ModuleArgsParser(
        task_ds={
            'shell': 'echo test',
            'args': 'list'
        }
    )
    module_args = parser.parse()

    assert module_args == ('shell', {'list': True})


# Generated at 2022-06-25 03:51:46.838660
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    for tc in TESTCASES:
        yield check_ModuleArgsParser_parse, tc

# Test runner for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:51:53.117301
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(dict(action='echo hi', delegate_to='localhost'))
    result = module_args_parser_0.parse()
    assert result == ('echo', {'msg': 'hi'}, 'localhost')
    module_args_parser_0 = ModuleArgsParser(dict(action='copy src=foo dest=bar', delegate_to='localhost'))
    result = module_args_parser_0.parse()
    assert result == ('copy', {'src': 'foo', 'dest': 'bar'}, 'localhost')
    module_args_parser_0 = ModuleArgsParser(dict(action='copy dest=bar src=foo'))
    result = module_args_parser_0.parse()
    assert result == ('copy', {'src': 'foo', 'dest': 'bar'}, None)
   

# Generated at 2022-06-25 03:51:57.780476
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        # Prepare data for test
        task_ds = {'action': {'module': 'copy src=/opt dest=/opt2', 'args': ''}}

        module_args_parser_1 = ModuleArgsParser(task_ds)
        # Execute method parse
        module_args_parser_1.parse()
        assert(False)
    except AnsibleParserError:
        assert(True)

    try:
        # Prepare data for test
        task_ds = {'action': {'module': 'copy src=/opt dest=/opt2', 'args': ''}}

        module_args_parser_2 = ModuleArgsParser(task_ds)
        # Execute method parse
        module_args_parser_2.parse()
        assert(False)
    except AnsibleParserError:
        assert(True)


# Generated at 2022-06-25 03:51:58.577408
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    if __name__ == '__main__':
        test_case(0)

# Generated at 2022-06-25 03:52:08.740213
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # test case 1
    task_ds = {'module': 'setup',
               'args': {'filter': 'ansible_distribution'}}
    action, args, delegate_to = module_args_parser.parse(task_ds=task_ds)
    assert action == 'setup'
    assert args == {'filter': 'ansible_distribution'}, "unexpected args: %s" % args
    assert delegate_to is None, "unexpected delegate_to: %s" % delegate_to
    # test case 2
    task_ds = {'action': 'copy src=a dest=b'}
    action, args, delegate_to = module_args_parser.parse(task_ds=task_ds)
    assert action == 'copy'

# Generated at 2022-06-25 03:52:10.886795
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    try:
        assert module_args_parser_0.parse() == (None, None, None)
    except:
        assert False, 'Expected no error'

    test_case_0()
    test_ModuleArgsParser_parse()


# Generated at 2022-06-25 03:52:24.064173
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import PY3
    def mock_find_plugin_with_context(item, collection_list=None):
        class MockContext(object):
            def __init__(self, resolved=None, resolved_fqcn=None, redirect_list=None):
                self.resolved = resolved
                self.resolved_fqcn = resolved_fqcn
                self.redirect_list = redirect_list
        context = MockContext(resolved=True, resolved_fqcn='/mock/resolved/ansible.module_utils.network.common.ios.ios.ios_command', redirect_list=['/mock/resolved/ansible.module_utils.network.common.ios.ios.ios_command'])
        return context

# Generated at 2022-06-25 03:52:37.420029
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing one case:
    module_args_parser = ModuleArgsParser()
    task_ds = {
        'action': {
            'module': 'file',
            'path': '/etc/hosts',
            'state': 'absent'
        }
    }
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    assert action == 'file'
    assert args == {
        'path': '/etc/hosts',
        'state': 'absent'
    }
    assert delegate_to is None
    print("test_ModuleArgsParser_parse: "
          "method parse of class ModuleArgsParser for case 0: PASSED")

# Run all tests for ModuleArgsParser

# Generated at 2022-06-25 03:52:49.793711
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    my_input = {
        'fail': {
            'msg': '{{fay}}'
        },
        'become': 'yes'
    }
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    module_args_parser = ModuleArgsParser(my_input, collection_list=[])
    actual_result = module_args_parser.parse()
    expected_result = ('ping', {'data': 'pong'}, Sentinel)
    assert actual_result == expected_result

# Generated at 2022-06-25 03:53:01.081777
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:53:07.994318
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_action_0
    module_args_parser_0 = ModuleArgsParser()
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    if (action_0 is not None):
        raise AssertionError("test_action_0: Expected {}, Got {}".format("None", repr(action_0)))
    if (args_0 != dict()):
        raise AssertionError("test_action_0: Expected {}, Got {}".format("{}", repr(args_0)))
    if (delegate_to_0 is not None):
        raise AssertionError("test_action_0: Expected {}, Got {}".format("None", repr(delegate_to_0)))

    # test_action_1
    module_args_parser_1 = Module

# Generated at 2022-06-25 03:53:16.320716
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Gets a tuple of module name and module args
    # This is a case when 'action' key is provided in the _task_ds
    # 'action' key is used to provide the module name
    # the dictionary formed by 'action' key is used to provide the
    # module args
    action, args, deligate_to = ModuleArgsParser(task_ds={'action': {'module': 'mymodule', 'other_arg': 'some_value'}}).parse()
    assert action == 'mymodule'
    assert args['other_arg'] == 'some_value'
    assert deligate_to == None

    # This is a case when 'local_action' key is provided in the _task_ds
    # 'local_action' key is used to provide the module name
    # the dictionary formed by 'local_action' key is used to provide the

# Generated at 2022-06-25 03:53:25.788174
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    module_args_parser_0  = ModuleArgsParser()
    task_ds_0 = {}
    collection_list_0 = None
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse(skip_action_validation = False)

    assert(action_0 is None)
    assert(isinstance(args_0, dict))
    assert(delegate_to_0 is Sentinel)


if __name__ == '__main__':
    # test_case_0()

    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:53:29.758644
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test = 'test'
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0.parse(test)

# Generated at 2022-06-25 03:53:41.548837
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # create a task with an action
    yaml_0 = '''\
    - hosts: localhost
      tasks:
        - name: task 1
          action: ping
    '''

    # create an empty module_ds structure
    module_ds_0 = dict()

    # create an empty task_ds structure
    task_ds_0 = dict()

    # set the action to 'ping' in the task_ds structure
    task_ds_0['action'] = 'ping'

    # create a ModuleArgsParser
    module_args_parser_0 = ModuleArgsParser()

    # assign the task_ds structure to a task in the module_ds structure
    module_ds_0['tasks'] = list()
    module_ds_0['tasks'].append(task_ds_0)

    # parse the task in the module_

# Generated at 2022-06-25 03:53:53.308794
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # test standard, basic action in the form module: args
    (action, args, delegate_to) = module_args_parser.parse(task_ds={'shell': 'echo hi'})
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is Sentinel

    # test old style action: args
    (action, args, delegate_to) = module_args_parser.parse(task_ds={'action': {'shell': 'echo hi'}})
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is Sentinel

    # test a more complex named argument

# Generated at 2022-06-25 03:54:05.544232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a valid action dictionary with delegate_to
    module_args_parser_0 = ModuleArgsParser({'action': {'module': 'shell', 'args': 'ls'}, 'delegate_to': 'localhost'})
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == 'shell'
    assert args == {'args': 'ls'}
    assert delegate_to == 'localhost'

    # Test with a valid action dictionary with with_items
    module_args_parser_0 = ModuleArgsParser({'action': {'module': 'shell', 'args': 'ls'}, 'with_items': 'localhost'})
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == 'shell'

# Generated at 2022-06-25 03:54:24.570448
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # set up the test
    module_args_parser = ModuleArgsParser()

    # test the pre-validated, good use cases
    results = module_args_parser.parse({'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    assert (results == ('copy', {'dest': 'b', 'src': 'a'}, None))

    results = module_args_parser.parse({'action': 'copy src=a src=b'})
    assert (results == ('copy', {'src': 'b'}, None))

    results = module_args_parser.parse({'action': {'module': 'shell', '_raw_params': 'echo hi'}})
    assert (results == ('shell', {'_raw_params': 'echo hi'}, None))

    results = module_

# Generated at 2022-06-25 03:54:34.566737
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:46.332748
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # input must be a dict
    test_case_1_input = "testcase_input"
    test_case_1_result = -1
    try:
        result = ModuleArgsParser(test_case_1_input).parse()
    except AnsibleAssertionError as e:
        print("AssertionError: %s" % e)
        test_case_1_result = 0

    # Expect an assertion error
    test_case_2_input = "local_action: testcase_input"
    test_case_2_result = -1
    try:
        result = ModuleArgsParser(test_case_2_input).parse()
    except AnsibleAssertionError as e:
        print("AssertionError: %s" % e)
        test_case_2_result = 0

    # Expect an

# Generated at 2022-06-25 03:54:51.187833
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Unit case 0
    module_args_parser_0 = ModuleArgsParser()

    # Test with skip_action_validation=False
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=False)
    assert (action is None) and (args == {}) and (delegate_to is Sentinel)

    # Test with skip_action_validation=True
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=True)
    assert (action is None) and (args == {}) and (delegate_to is Sentinel)


# Generated at 2022-06-25 03:54:58.991373
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # set values for test_case_1
    test_case_1__task_ds = "shell echo 'hello world'"

    # set values for test_case_2
    test_case_2__task_ds = {'shell': 'echo "hello world"'}
    test_case_2__collection_list = ['ansible.builtin']

    # set values for test_case_3
    test_case_3__task_ds = {'action': {'module': 'shell', 'args': 'echo "hello world"'}}

    # set values for test_case_4
    test_case_4__task_ds = {'action': 'shell echo "hello world"'}

    # set values for test_case_5
    test_case_5__task_ds = {'action': '{{foo}}'}

    # set values

# Generated at 2022-06-25 03:55:07.360289
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:55:10.986635
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #Arrange
    module_args_parser_0 = ModuleArgsParser()

    #Act
    result = module_args_parser_0.parse()

    #Assert
    assert type(result) == tuple
    assert len(result) == 3


# Generated at 2022-06-25 03:55:11.903055
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement
    pass


# Generated at 2022-06-25 03:55:19.645094
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test ModuleArgsParser.parse
    '''

    # Create an instance of class ModuleArgsParser
    module_args_parser_1 = ModuleArgsParser()

    # attempt to parse dict with missing mandatory key -> raises AnsibleParserError
    expected = AnsibleParserError
    try:
        result = module_args_parser_1.parse(skip_action_validation=False)
    except Exception as e:
        assert type(e) == expected

    # attempt to parse dict with invalid type of key -> raises AnsibleParserError
    expected = AnsibleParserError
    try:
        result = module_args_parser_1.parse(skip_action_validation=False)
    except Exception as e:
        assert type(e) == expected

    # valid dict with missing optional key -> returns expected result with default value

# Generated at 2022-06-25 03:55:26.896398
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # test_case_0
    task_ds_0 = dict()
    task_ds_0['action'] = dict()
    task_ds_0['action']['module'] = 'copy'
    task_ds_0['action']['src'] = 'a'
    task_ds_0['action']['dest'] = 'b'
    task_ds_0['delegate_to'] = 'localhost'
    task_ds_0['args'] = dict()
    task_ds_0['args']['arg1'] = 'val1'
    task_ds_0['args']['arg2'] = 'val2'

# Generated at 2022-06-25 03:55:51.315060
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_data = {
        'action': '{{foo}}'
    }

    module_args_parser = ModuleArgsParser()

    try:
        action, args, delegate_to = module_args_parser.parse(task_data)
    # We should catch the exception here and assert true for this test case
    except AnsibleParserError:
        return True

    assert False


# Generated at 2022-06-25 03:55:55.507736
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO
    pass


# Generated at 2022-06-25 03:56:03.406203
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # Testing case: ModuleArgsParser.parse
    # args: {'action': None, 'delegate_to': None, 'args': None}
    # expected_output:
    #   (action, args, delegate_to) = ('', {}, None)
    #   assert: action == '' and args == {} and delegate_to is None
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == '' and args == {} and delegate_to is None


# Generated at 2022-06-25 03:56:12.033207
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of ModuleArgsParser
    module_args_parser_1 = ModuleArgsParser()

    # Test with thing = {'module' : 'copy', 'src' : 'a', 'dest' : 'b'}
    # Expected outcome: action = "copy", args = {'src': 'a', 'dest': 'b'}
    thing = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    assert module_args_parser_1._normalize_new_style_args(thing) == {'src': 'a', 'dest': 'b'}

    # Test with thing = 'copy src=a dest=b'
    # Expected outcome: action = "copy", args = {'src': 'a', 'dest': 'b'}
    thing = 'copy src=a dest=b'

# Generated at 2022-06-25 03:56:17.003404
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # A function in the module may call parse method of ModuleArgsParser object
    # to parse the action.
    config_data = { 'action': {'module': 'copy src=a dest=b'},
                    'delegate_to': '127.0.0.1',
                    'args': {'shell': '/bin/sh', 'warn': 'no'}
                  }

    module_args_parser = ModuleArgsParser(config_data)
    action, args, delegate_to = module_args_parser.parse()
    print("action: {0}".format(action))
    print("args: {0}".format(args))
    print("delegate_to: {0}".format(delegate_to))


# Generated at 2022-06-25 03:56:22.724239
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # input: {'_ansible_bash_callbacks': [], '_ansible_diff': True, '_ansible_keep_remote_files': False, '_ansible_verbosity': 0, '_uses_shell': True, 'action': {'module': 'shell', 'echo hi'}, 'args': {}, 'changed': False, 'comment': 'shell echo hi', 'delegate_to': 'localhost', 'invocation': {'module_args': {'_raw_params': 'echo hi', '_uses_shell': True, 'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True}, 'module_name': 'shell'}, 'item': '', 'register': 'shell_out'}
    # expected: ['echo

# Generated at 2022-06-25 03:56:32.106002
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()

    for value in [
            {'action': 'shell echo hi'},
            {'local_action': 'shell'},
            {'local_action': 'shell echo hi'},
            {'action': 'copy', 'args': {'src': 'a', 'dest': 'b', 'r': True}},
            {'action': 'copy', 'args': {'src': 'a', 'dest': 'b', 'r': True}},
            {'action': 'copy', 'args': {'src': 'a', 'dest': 'b', 'r': False}},
            {'action': 'pause', 'pause': {'seconds': 10}}
    ]:
        action = value.get('action')
        args = value.get('args', {})


# Generated at 2022-06-25 03:56:43.888395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "action": "ping",
        "delegate_to": "localhost",
        "args": "",
        "shell": True
    }

    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser_1.parse() == ('ping', {}, 'localhost')

    # Test corner cases
    default_task_ds = {"action": None}
    module_args_parser = ModuleArgsParser(task_ds=default_task_ds)
    module_args_parser.parse()

    task_ds = {
        "action": {
            "module": "ping",
            "args": "1"
        },
        "delegate_to": "localhost",
        "args": "",
        "shell": True
    }

    module_

# Generated at 2022-06-25 03:56:46.705958
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # type: () -> None
    module_args_parser = ModuleArgsParser()
    action_0 = module_args_parser.parse()
    assert not action_0


# Generated at 2022-06-25 03:56:53.201678
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None

    # Test non-task
    result = module_args_parser.parse({"foo": "bar"})
    assert result is None

    # Test empty input
    result = module_args_parser.parse({})
    assert result is None

    result = module_args_parser.parse({"action": "shell", "foo": "bar"})
    assert result == ("shell", {}, None)

    result = module_args_parser.parse({"action": "shell", "args": "something", "foo": "bar"})
    assert result == ("shell", {"something": None}, None)

    result = module_args_parser.parse({"action": "shell", "args": "something", "foo": "bar"})

# Generated at 2022-06-25 03:57:32.431138
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_result_0 = None
    if test_ModuleArgsParser_parse.cache:
        test_result_0 = test_ModuleArgsParser_parse.cache

    else:
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-25 03:57:39.393320
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # case1: test for success
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {
        'module': 'shell',
        'args': 'echo hi',
    }
    (action, args, delegate_to) = module_args_parser_1.parse(task_ds=task_ds_1)
    assert action == 'shell'
    assert args == {}
    assert delegate_to is None

    # case2: test for success
    module_args_parser_2 = ModuleArgsParser()
    task_ds_2 = {
        'action': 'copy src=1 dest=2',
    }
    (action, args, delegate_to) = module_args_parser_2.parse(task_ds=task_ds_2)
    assert action == 'copy'

# Generated at 2022-06-25 03:57:49.180990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    class DummyClass(object):
        def __init__(self):
            self.resolved = True
            self.resolved_fqcn = "mymod"
    class DummyLoader:
        def find_plugin_with_context(self,foo):
            return DummyClass()
    action_loader._loader = DummyLoader()
    module_loader._loader = DummyLoader()
    task_ds = dict(action='mymod arg_a=b arg_c=d')
    module, args, delegate_to = module_args_parser.parse(task_ds)
    assert module == 'mymod'
    assert args == dict(arg_a='b', arg_c='d')
    assert delegate_to is None

    # test with local_action
    task_ds

# Generated at 2022-06-25 03:57:57.421741
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('Testing ModuleArgsParser parse...')

    lines = ["- name: test",
             "  action: shell echo 'hi'",
             ""]
    lines.reverse()
    task_ds = yaml.safe_load('\n'.join(lines))
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'ansible.legacy.shell'
