

# Generated at 2022-06-25 03:48:31.338780
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: make a test
    return True

# Generated at 2022-06-25 03:48:33.110827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(task_ds={'args': {'chdir': '/tmp'}})
    print(module_args_parser_0)
    assert not (module_args_parser_0.parse())



# Generated at 2022-06-25 03:48:37.768308
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text

    parser = ModuleArgsParser()
    # Test various ways module arguments may be passed.
    # Note: '-a' is the same as 'command' or 'shell'.
    # Note: We can't use pytest.param here because we need to check the error too
    # and it doesn't seem to like that.

# Generated at 2022-06-25 03:48:48.829853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test parse with action, module and args.
    params_0 = dict(
        action="template",
        src="{{ src }}",
        dest="{{ dest }}",
        delegate_to="localhost"
    )
    parser_0 = ModuleArgsParser(params_0)
    result0 = parser_0.parse()
    assert result0 == ("template", {'src': '{{ src }}', 'dest': '{{ dest }}'}, 'localhost')

    # test parse with local_action and args.
    params_1 = dict(
        local_action="debug",
        msg="ansible2"
    )
    parser_1 = ModuleArgsParser(params_1)
    result1 = parser_1.parse()
    assert result1 == ("debug", {'msg': 'ansible2'}, 'localhost')

    # test parse with

# Generated at 2022-06-25 03:48:59.451578
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:09.657612
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test 1
    module_args_parser = ModuleArgsParser()
    task_ds = dict(action=dict(module='shell', _raw_params='ls', _uses_shell=False), delegate_to='worker')
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'shell'
    assert args == dict(_raw_params='ls', _uses_shell=False)
    assert delegate_to == 'worker'

    # Test 2
    module_args_parser = ModuleArgsParser()
    task_ds = dict(action='shell ls')
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'shell'
    assert args == dict(_raw_params='ls', _uses_shell=False)

# Generated at 2022-06-25 03:49:16.891103
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse()
    # Tests true/false condition
    assert result != None, "Couldn't parse"

# Generated at 2022-06-25 03:49:18.121578
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _test_case_0()

test_case_0()

# Generated at 2022-06-25 03:49:27.381731
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    parsed_dict = {'_raw_params': '',
                   '_uses_shell': False,
                   'chdir': '/tmp'}

    task_ds = {'action': '', 'args': {'chdir': '/tmp'}, 'delegate_to': None}
    action, args, delegate_to = module_args_parser_0.parse(task_ds)
    assert action == '' and args == parsed_dict and delegate_to == None

    task_ds = {'action': '', 'args': {'chdir': '/tmp'}}
    action, args, delegate_to = module_args_parser_0.parse(task_ds)
    assert action == '' and args == parsed_dict and delegate_to == None


# Generated at 2022-06-25 03:49:30.392318
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == None


# Generated at 2022-06-25 03:50:13.734467
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test data
    input_task_ds = {
        'action': {
            'module': 'shell',
            'args': 'echo hello',
            'chdir': '/home'
        }
    }
    input_action = 'shell'
    expected_result = (
        'shell',
        {
            'args': 'echo hello',
            'chdir': '/home'
        },
        None
    )

    # Call to parse method
    action, args, delegate_to = ModuleArgsParser(input_task_ds).parse()

    # Test
    assert action == expected_result[0]
    assert args == expected_result[1]
    assert delegate_to == expected_result[2]

# Generated at 2022-06-25 03:50:26.724372
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = dict(action=dict(x=2))
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert (action_0 == 'x')
    assert (args_0 == dict(x=2))
    assert (delegate_to_0 is Sentinel)

    task_ds_1 = dict(action='copy src=a dest=b')
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    action_1, args_1, delegate_to_1 = module_args_parser_1.parse()
    assert (action_1 == 'copy')

# Generated at 2022-06-25 03:50:39.305810
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    This tests the parse method of ModuleArgsParser class
    """

# Generated at 2022-06-25 03:50:47.651290
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # simple
    ds = {'shell': 'foo'}
    r = module_args_parser.parse(ds)
    assert r == ('shell', 'foo', None)

    # more complex
    ds = {'shell': "var=foo"}
    r = module_args_parser.parse(ds)
    assert r == ('shell', 'var=foo', None)

    # simple local action
    ds = {'local_action': 'foo'}
    r = module_args_parser.parse(ds)
    assert r == ('foo', '', 'localhost')

    # more complex local action
    ds = {'local_action': "var=foo"}
    r = module_args_parser.parse(ds)

# Generated at 2022-06-25 03:51:00.261526
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    import inspect
    import types
    import os.path

    current_path = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-25 03:51:07.366949
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Task 0
    parser = ModuleArgsParser()
    task_ds = OrderedDict()
    task_ds['name'] = 'test task 0'
    task_ds['action'] = {'module': 'shell', 'args': 'echo hello world'}
    action, args, delegate_to = parser.parse(task_ds)
    print(action, args, delegate_to)
    assert action == 'shell'
    assert args == {'args': 'echo hello world'}
    assert delegate_to is None

    # Task 1
    parser = ModuleArgsParser()
    task_ds = OrderedDict()
    task_ds['name'] = 'test task 1'
    task_ds['action'] = {'shell': 'echo hello world'}
    action, args, delegate_to = parser.parse(task_ds)


# Generated at 2022-06-25 03:51:15.886389
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with old style call
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0._task_ds = {
        'tasks': 'tasks.yml',
        'action': 'copy src=a dest=b'
    }
    module_args_parser_0.parse()
    assert module_args_parser_0.resolved_action == 'ansible.builtin.copy'


# Generated at 2022-06-25 03:51:23.639854
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # type: () -> None

    # Setup
    task_ds_0 = dict()
    collection_list_0 = None
    module_args_parser_0 = ModuleArgsParser(task_ds_0, collection_list_0)
    task_ds_1 = dict()
    collection_list_1 = None
    module_args_parser_1 = ModuleArgsParser(task_ds_1, collection_list_1)
    task_ds_2 = dict()
    collection_list_2 = None
    module_args_parser_2 = ModuleArgsParser(task_ds_2, collection_list_2)
    task_ds_3 = dict()
    collection_list_3 = None
    module_args_parser_3 = ModuleArgsParser(task_ds_3, collection_list_3)

# Generated at 2022-06-25 03:51:28.340356
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()

# Generated at 2022-06-25 03:51:35.640291
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    ensure valid task parsing
    '''

    # test case 0: dict arg
    task_ds = dict()
    task_ds['action'] = dict()
    task_ds['action']['copy'] = dict()
    task_ds['action']['copy']['src'] = 'source'
    task_ds['action']['copy']['dest'] = 'dest'
    module_args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': 'source', 'dest': 'dest'}

    # test case 1: string arg
    task_ds = dict()
    task_ds['action'] = 'copy src=src dest=dest'
    module_args

# Generated at 2022-06-25 03:51:54.614449
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:03.975588
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # set up object
    module_args_parser = ModuleArgsParser()
    # set up context

    # Test 1: no action specified
    task_ds = dict()
    # Run the code to be tested
    result = module_args_parser.parse(task_ds)

    # Check the results
    assert result == (None, dict(), None), 'Expected: (%s, %s, %s), Actual: %s' % (None, dict(), None, result)

    # Test 1: action specified
    task_ds = dict(action='ping')
    # Run the code to be tested
    result = module_args_parser.parse(task_ds)

    # Check the results

# Generated at 2022-06-25 03:52:13.461611
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n")
    pprint("Testing ModuleArgsParser.parse():")

    module_args_parser = ModuleArgsParser()

    # Test case 1
    print("\n")
    test_case_name = "Test case 1"
    thing = "shell echo hi"
    action = None
    additional_args = dict()
    pprint("Inputs: %s" % test_case_name)
    pprint("thing: %s" % thing)
    pprint("action: %s" % action)
    pprint("additional_args: %s" % additional_args)
    action, args = module_args_parser._normalize_parameters(thing, action=action, additional_args=additional_args)
    pprint("Test case name: %s" % test_case_name)

# Generated at 2022-06-25 03:52:19.420306
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Instantiating the class
    module_args_parser_0 = ModuleArgsParser()

    # Calling parse method with some value to be passed in
    module_args_parser_0.parse(skip_action_validation=False)


# Generated at 2022-06-25 03:52:30.529047
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # setup test fixture(s)
    module_args_parser = ModuleArgsParser()

    # test invocation
    # test action: copy, expected: module=copy, args={u'src': u'a', u'dest': u'b'}
    task_ds = {'action': 'copy src=a dest=b'}
    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'copy'
    assert delegate_to is None
    assert args['src'] == 'a'
    assert args['dest'] == 'b'

    # test action: copy, expected: module=copy, args={u'src': u'a', u'dest': u'b'}
    task_ds = {'action': {'module': 'copy src=a dest=b'}}

# Generated at 2022-06-25 03:52:38.020163
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser

    Test parse method of class ModuleArgsParser
    with input from file test/units/test_module_args_parser__input.yaml
    '''

    # input from file test/units/test_module_args_parser__input.yaml
    input = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': 'localhost', 'local_action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'args': {'src': 'a', 'dest': 'b'}}
    module_args_parser_1 = ModuleArgsParser()

    # Testing
    # Calling method parse of class ModuleArgsParser
    (action, args, delegate_to) = module_args_parser_

# Generated at 2022-06-25 03:52:51.560005
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {'action': 'shell echo hi'}
    print(ModuleArgsParser(args).parse())
    args = {'action': {'shell': 'echo hi'}}
    print(ModuleArgsParser(args).parse())
    args = {'local_action': {'shell': 'echo hi'}}
    print(ModuleArgsParser(args).parse())
    args = {'shell': 'echo hi'}
    print(ModuleArgsParser(args).parse())
    args = {'action': 'copy src=a dest=b'}
    print(ModuleArgsParser(args).parse())
    args = {'action': {'module': 'copy src=a dest=b'}}
    print(ModuleArgsParser(args).parse())
    args = {'local_action': {'module': 'copy src=a dest=b'}}


# Generated at 2022-06-25 03:53:01.208378
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    expected_action_1 = 'copy'
    expected_action_2 = 'shell'
    expected_action_3 = 'command'
    expected_action_4 = 'win_copy'
    expected_action_5 = 'copy'
    expected_action_6 = 'script'
    expected_action_7 = 'copy'
    expected_action_8 = 'win_robocopy'
    expected_action_9 = 'command'
    expected_action_10 = 'copy'
    expected_action_11 = 'command'
    expected_action_12 = 'copy'
    expected_action_13 = 'copy'
    expected_action_14 = 'copy'
    expected_action_15 = 'copy'

    expected_args_1 = {'dest': 'b', 'src': 'a'}
    expected_args_2

# Generated at 2022-06-25 03:53:04.073506
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {
        'action': {
            'module': 'copy'
        }
    }
    action, args, delegate_to = module_args_parser.parse()
    print(action, args, delegate_to)

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:53:09.891979
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()


# End class ModuleArgsParser


# Generated at 2022-06-25 03:53:29.678516
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    task_ds = dict(action='copy', src='a', dest='b')
    action, args, delegate_to = parser.parse(task_ds)
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None

    task_ds = dict(local_action='copy', src='a', dest='b')
    action, args, delegate_to = parser.parse(task_ds)
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to == 'localhost'

    task_ds = dict(copy=dict(src='a', dest='b'))
    action, args, delegate_to = parser.parse(task_ds)
    assert action == 'copy'

# Generated at 2022-06-25 03:53:41.437755
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    thing_c_0 = {}
    action_c_0 = None
    additional_args_c_0 = {}
    action_c_0, args_c_0 = module_args_parser_0._normalize_parameters(thing_c_0, action_c_0, additional_args_c_0)
    assert action_c_0 is None
    assert args_c_0 == {}
    thing_c_1 = 'echo hi'
    action_c_1 = None
    additional_args_c_1 = {}
    action_c_1, args_c_1 = module_args_parser_0._normalize_parameters(thing_c_1, action_c_1, additional_args_c_1)

# Generated at 2022-06-25 03:53:47.334214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 03:53:53.662244
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_1 = {
        'action': {
            'module': 'ping',
            'something': 'else',
            'something': 'else'
        },
        'delegate_to': '2'
    }
    collection_list_1 = [
        'ansible.builtin.ping',
        'ansible.builtin.raw'
    ]
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1, collection_list=collection_list_1)
    module_args_parser_1.parse()
    task_ds_2 = {
        'action': {
            'shell': 'ping',
            'something': 'else',
            'something': 'else'
        },
        'delegate_to': '2'
    }

# Generated at 2022-06-25 03:53:56.164815
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert module_args_parser_0.parse() == ('setup', {}, Sentinel)


# Generated at 2022-06-25 03:54:00.093666
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    result_0 = module_args_parser_0.parse()
    assert result_0 == (None, None, None)


# Generated at 2022-06-25 03:54:03.399134
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    module_args_parser = ModuleArgsParser()
    x = module_args_parser.parse(skip_action_validation=False)
    assert x==('ping', {}, None)
    """


# Generated at 2022-06-25 03:54:15.371685
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test 1: Test with simple tasks in different formats
    ds_1 = dict(
        action=dict(module='copy', src='file1', dest='file2'),
        module='ping',
        local_action='shell echo hi',
        action_1='copy src=file3 dest=file4'
    )

    parsed_hash_1 = dict(
        action=('copy', {'src': 'file1', 'dest': 'file2'}, None),
        module=('ping', {}, None),
        local_action=('shell', {'_raw_params': 'echo hi'}, 'localhost'),
        action_1=('copy', {'src': 'file3', 'dest': 'file4'}, None)
    )

    for key in parsed_hash_1.keys():
        module_args_parser = ModuleArgs

# Generated at 2022-06-25 03:54:20.868173
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleAssertionError):
        module_args_parser_0 = ModuleArgsParser()
        # bad input
        assert module_args_parser_0.parse() == ("test_case_0", "failed")
    with pytest.raises(AnsibleParserError):
        module_args_parser_0 = ModuleArgsParser()
        # bad input
        assert module_args_parser_0.parse() == ("test_case_1", "failed")
    with pytest.raises(AnsibleError):
        module_args_parser_0 = ModuleArgsParser()
        # bad input
        assert module_args_parser_0.parse() == ("test_case_2", "failed")
    with pytest.raises(AnsibleError):
        module_args_parser_0 = Module

# Generated at 2022-06-25 03:54:23.816129
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = True
    returned_value = module_args_parser_0.parse(skip_action_validation)
    assert returned_value is not None


# Generated at 2022-06-25 03:54:38.792358
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Case 0
    logger.info("Test Case 0: Unit test for method parse of class ModuleArgsParser")

    module_args_parser_0 = ModuleArgsParser({})
    action, args, delegate_to = module_args_parser_0.parse()
    assert delegate_to == None
    assert args == {}
    assert action == None

    module_args_parser_1 = ModuleArgsParser({'delegate_to': 'localhost'})
    action, args, delegate_to = module_args_parser_1.parse()
    assert delegate_to == 'localhost'
    assert args == {}
    assert action == None

    module_args_parser_2 = ModuleArgsParser({'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    action, args, delegate_to = module_args_parser

# Generated at 2022-06-25 03:54:42.822620
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Build a testcase for ModuleArgsParser.parse
    #
    # Testcase 1
    #
    # Input:
    # self._task_ds = {}
    # self._collection_list = None
    #
    # Expected result:
    # res = None

    module_args_parser_1 = ModuleArgsParser()
    res = module_args_parser_1.parse()

    if res is not None:
        print("\n\nFailure in ModuleArgsParser.parse() testcase 1.\n" +
              "Expected result: None" +
              "\nActual result: " + str(res))


# Generated at 2022-06-25 03:54:50.693347
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    module_args_parser_0 = ModuleArgsParser()
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert type(action_0) is str
    assert type(args_0) is dict
    assert type(delegate_to_0) is Sentinel

# Generated at 2022-06-25 03:55:00.600722
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # check that parser cannot parse an invalid task
    with pytest.raises(AnsibleParserError):
        module_args_parser.parse({})

    # check that the parser can parse the supported task forms
    (action, args, delegate_to) = module_args_parser.parse({'action': 'shell echo hi'})
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to is None

    (action, args, delegate_to) = module_args_parser.parse({'action': 'shell'})
    assert action == 'shell'
    assert args == {}
    assert delegate_to is None


# Generated at 2022-06-25 03:55:04.295565
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True == True


# # Test 1
#
# Calling ModuleArgsParser.parse with inputs
#     d = {'delegate_to': 'somehost', 'action': {'shell': 'echo hi'}}
# should return
#     (True, True)
#

# Generated at 2022-06-25 03:55:12.031153
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Case 1:
    # ModuleArgsParser.parse()
    # test with correct input and correct default values
    module_args_parser_1 = ModuleArgsParser()
    ActionModule.add_module_args_using_key_value(action='a', module_name='b')
    res = module_args_parser_1.parse()
    assert res == ('a', {'module_name': 'b'}, None)


# Generated at 2022-06-25 03:55:19.764226
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

# Generated at 2022-06-25 03:55:30.348169
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case 1:
    task_ds = dict()
    task_ds['action'] = 'copy'
    task_ds['src'] = 'a'
    task_ds['dest'] = 'b'

    module_args_parser_1 = ModuleArgsParser(task_ds)
    action, args, delegate_to = module_args_parser_1.parse()
    assert (action, args, delegate_to) == ('copy', {'src': 'a', 'dest': 'b'}, None)

    # Test case 2:
    task_ds = dict()
    task_ds['local_action'] = 'copy'
    task_ds['src'] = 'a'
    task_ds['dest'] = 'b'

    module_args_parser_2 = ModuleArgsParser(task_ds)
    action, args, delegate_

# Generated at 2022-06-25 03:55:32.081830
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 03:55:39.254734
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:55:55.072792
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Normal case
    module_args_parser_p0 = ModuleArgsParser()
    assert module_args_parser_p0.parse() == (None, None, Sentinel)

    # Normal case
    module_args_parser_p1 = ModuleArgsParser()
    assert module_args_parser_p1.parse(skip_action_validation=False) == (None, None, Sentinel)

    # Normal case
    module_args_parser_p2 = ModuleArgsParser()
    assert module_args_parser_p2.parse(skip_action_validation=True) == (None, None, Sentinel)


# Generated at 2022-06-25 03:56:01.929483
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """ModuleArgsParser:parse test case"""
    tester = ModuleArgsParser()
    ds = dict()
    skip_action_validation = False
    #result = tester.parse(ds, skip_action_validation)
    #assert result == expected, "result:\n%s\nexpected:\n%s" % (result, expected)
    # Write your own test here


# Generated at 2022-06-25 03:56:11.625319
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action is None
    assert args == {}
    assert delegate_to is None

    assert task_ds is not None

    task_ds = {'tasks': []}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action is None
    assert args == {}
    assert delegate_to is None

    assert task_ds is not None

    task_ds = {'action': 'ping'}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    assert action == 'ping'
    assert args == {}
    assert delegate_to is None


# Generated at 2022-06-25 03:56:17.251897
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('')
    print('Testing ModuleArgsParser.parse')

    test_cases = dict()
    test_cases['0'] = dict()
    test_cases['0']['task_ds'] = dict()
    test_cases['0']['task_ds']['action'] = 'copy src=a dest=b'
    test_cases['0']['task_ds']['action'] = 'copy src=a dest=b'
    test_cases['0']['expected_result'] = ('copy', {'dest': 'b', 'src': 'a'}, None)

    test_cases['1'] = dict()
    test_cases['1']['task_ds'] = dict()

# Generated at 2022-06-25 03:56:28.037304
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

# Generated at 2022-06-25 03:56:38.121993
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = False

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()


# Generated at 2022-06-25 03:56:40.388641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse()
    assert result is None


# Generated at 2022-06-25 03:56:44.622534
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()


# if __name__ == '__main__':
#     test_case_0()

# Generated at 2022-06-25 03:56:52.538774
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing for different modules
    for mod in MODULE_ARGS_COMMAND:
        task_ds = {'action': mod}
        module_args_parser_0 = ModuleArgsParser()
        (action, args, delegate_to) = module_args_parser_0.parse()
        if args == {}:
            assert False
        else:
            assert True
    # Testing for different modules which takes no parameters
    for mod in MODULE_ARGS_COMMAND_NORMAL:
        task_ds = {'action': mod}
        module_args_parser_0 = ModuleArgsParser()
        (action, args, delegate_to) = module_args_parser_0.parse()
        if args == {}:
            assert True
        else:
            assert False
    # Testing for AnsibleShell

# Generated at 2022-06-25 03:56:55.805410
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None

    module_args_parser_0 = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action is None
    assert delegate_to == Sentinel


# Generated at 2022-06-25 03:57:14.861250
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    input_1 = ('command', 'do something', 'localhost')
    assert ModuleArgsParser().parse(dict(action=dict(command='do something'))) == input_1

    assert ModuleArgsParser().parse(dict(local_action=dict(command='do something'))) == input_1
    assert ModuleArgsParser().parse(dict(command='do something')) == input_1
    assert ModuleArgsParser().parse(dict(action='command do something')) == input_1
    assert ModuleArgsParser().parse(dict(local_action='command do something')) == input_1

    input_2 = ('command', dict(do=1, something=2), 'localhost')
    assert ModuleArgsParser().parse(dict(action=dict(command=dict(do=1, something=2)))) == input_2

# Generated at 2022-06-25 03:57:17.469119
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser({'delegate_to': 'localhost'}, ['ansible.builtin', 'ansible_collections.ansible.builtin'])
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert action_0 == None
    assert args_0 == {}
    assert delegate_to_0 == 'localhost'


# Generated at 2022-06-25 03:57:22.949712
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #from ansible.module_utils.six.moves import StringIO as six_StringIO
    #from ansible.module_utils.six.moves import builtins as six_builtins
    #six_builtins.open = lambda x, y: six_StringIO().open(x, y)
    module_args_parser_0 = ModuleArgsParser()
    #module_args_parser_0.parse()
    assert True


# Generated at 2022-06-25 03:57:27.391111
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    for tc in [{'action': 'shell echo hi'},
               {'action': {'module': 'shell', 'args': 'echo hi'}},
              ]:
        try:
            module_args_parser_0.parse(tc)
        except Exception as ex:
            print("Exception: %s" % (ex))
            raise
        assert True


# Generated at 2022-06-25 03:57:37.096504
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (
        None, {}, Sentinel)

    task_ds = {'action': None}
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser_1.parse() == (
        None, {}, Sentinel)

    task_ds = {'action': 'shell echo hehe'}
    module_args_parser_2 = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser_2.parse() == (
        'shell', {'_raw_params': 'echo hehe'}, Sentinel)

    task_ds = {'action': 'shell'}

# Generated at 2022-06-25 03:57:43.937284
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Inputs
    # task_ds = dict()
    # collection_list = dict()
    # skip_action_validation = None
    # expected = (None, None, None)

    module_args_parser_0 = ModuleArgsParser()

    task_ds = dict()
    collection_list = dict()
    skip_action_validation = None

    expected = (None, None, None)
    actual = module_args_parser_0.parse(skip_action_validation)
    assert actual == expected



# Generated at 2022-06-25 03:57:51.056889
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()

    # Test case 1: Parse local_action style task using a module
    # that is a builtin module
    task_1 = {'local_action': 'command echo hello', 'name': 't1'}
    action, args, delegate_to = parser.parse(task_ds=task_1)
    assert action == 'command'
    assert delegate_to == 'localhost'
    assert args == {'_raw_params': 'echo hello', '_uses_shell': True}

    # Test case 2: Parse local_action style task using a module that is
    # in some collection (and is not a builtin module)
    task_2 = {'local_action': 'my_module arg1=val1', 'name': 't2'}
    action, args, delegate_to = parser.parse

# Generated at 2022-06-25 03:57:53.683495
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert module_args_parser_0.parse() == ('shell', {'echo': 'hi'},)


# Generated at 2022-06-25 03:57:58.799593
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()


# Generated at 2022-06-25 03:58:10.720689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Test basic functionality
    print("====== Test basic functionality ======")
    task_ds = {'action': 'copy src=a dest=b'}
    (action, args, delegate_to) = module_args_parser_0.parse(task_ds=task_ds)
    print("Return value is: " + repr((action, args)))
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test the case where the input argument is not a dictionary
    print("====== Test the case where the input argument is not a dictionary ======")
    task_ds = []