

# Generated at 2022-06-25 03:48:48.797065
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    (action, args, delegate_to) = ModuleArgsParser().parse({"action": "shell", "args": "ls -ld /"})
    assert action == 'shell'
    assert args == {}
    (action, args, delegate_to) = ModuleArgsParser().parse({"shell": "ls -ld /", "ignore_errors": True})
    assert action == 'shell'
    assert args == {}
    (action, args, delegate_to) = ModuleArgsParser().parse({"local_action": "shell", "args": "ls -ld /"})
    assert action == 'shell'
    assert args == {}

# Generated at 2022-06-25 03:48:54.339002
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # action=None, delegate_to=None, args={}
    task_ds_0_expected = ('setup', {}, 'host0')
    task_ds_0 = {
        'tasks': [
            {
                'action': 'setup',
                'delegate_to': 'host0'
            }
        ]
    }
    task_ds_0_actual = module_args_parser_0._ModuleArgsParser__parse(task_ds_0['tasks'][0])
    assert task_ds_0_expected == task_ds_0_actual, "task_ds_0_expected={}, task_ds_0_actual={}".format(task_ds_0_expected, task_ds_0_actual)

    # action='setup', delegate_to

# Generated at 2022-06-25 03:49:00.265075
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    args_0 = module_args_parser_0.parse()
    assert args_0 == ('', dict(), None)


# Generated at 2022-06-25 03:49:03.356717
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(action=dict(module='command', args='echo hello'))
    module_args_parser_0 = ModuleArgsParser(task, None)
    module_args_parser_0.parse()
    assert module_args_parser_0.resolved_action == 'ansible.builtin.command'


# Generated at 2022-06-25 03:49:13.521278
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(dict(action=dict(module='ec2', x=1, y=2), delegate_to='127.0.0.1', flush_cache=dict(when='changed')))
    assert module_args_parser_0.parse() == ('ec2', dict({'y': 2, 'x': 1}), '127.0.0.1')
    module_args_parser_0 = ModuleArgsParser(dict(action=dict(module='shell', command='ls'), delegate_to='127.0.0.1', flush_cache='yes'))
    assert module_args_parser_0.parse() == ('shell', dict({'command': 'ls'}), '127.0.0.1')

# Generated at 2022-06-25 03:49:23.412070
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    src_data = dict(
        action='shell',
        module='echo hi')

    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(src_data)

    assert action == 'shell'
    assert isinstance(args, dict)
    assert delegate_to is None

    src_data = dict(
        action='shell',
        module='echo hi',
        delegate_to='localhost')

    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(src_data)

    assert action == 'shell'
    assert isinstance(args, dict)
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:49:30.769580
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser_0 = ModuleArgsParser()

    #This is the first test
    my_task_ds = dict()
    my_task_ds['action'] = {'module': 'ping'}
    my_thing = module_args_parser.parse(my_task_ds)

    #This is the second test
    my_task_ds = dict()
    my_task_ds['local_action'] = {'module': 'ping'}
    my_thing = module_args_parser.parse(my_task_ds)

# Generated at 2022-06-25 03:49:40.520468
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:43.729518
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Setup test environment
    module_args_parser_1 = ModuleArgsParser()

    # Run method to be tested
    module_args_parser_1.parse()

    # Check results

    # Teardown test environment
    module_args_parser_1 = None

# Generated at 2022-06-25 03:49:54.597514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.module_utils.six import string_types

    for arg in [Task(), IncludeRole()]:
        assert isinstance(arg, dict)

    # action: 'echo hi'
    task_ds = dict(action='shell echo hi')
    module_args_parser = ModuleArgsParser(task_ds)
    expected_action, expected_args, expected_delegate_to = 'shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None
    actual_action, actual_args, actual_delegate_to = module_args_parser.parse()
    assert actual_action == expected_action
    assert actual_args == expected_args
    assert actual_delegate_to == expected_

# Generated at 2022-06-25 03:50:20.105207
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # First test: action: copy src=a dest=b
    task_ds = {'action': "copy src=a dest=b"}
    module_args = ModuleArgsParser(task_ds=task_ds)
    parsed_args = module_args.parse()
    expected_parsed_args = ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert parsed_args == expected_parsed_args
    assert module_args.resolved_action == 'ansible.parsing.mod_args.copy'


# Generated at 2022-06-25 03:50:25.948421
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # ModuleArgsParser.parse with args (self, skip_action_validation=False)
    # with scope module
    module_args_parser.parse()
    # with scope function
    module_args_parser.parse(skip_action_validation=False)
    module_args_parser.parse(skip_action_validation=True)


# Generated at 2022-06-25 03:50:36.175333
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    testcase = {
        "module": {
            "ec2": {
                "region": "xyz"
            }
        }
    }

    module_args_parser_0 = ModuleArgsParser()

    modules = module_args_parser_0.parse(skip_action_validation=True)
    assert type(modules) == tuple
    assert len(modules) == 3

    assert modules[0] == 'ec2'

    assert type(modules[1]) == dict
    assert modules[1].get('region') == 'xyz'

    assert modules[2] == Sentinel


# Generated at 2022-06-25 03:50:45.365412
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for ModuleArgsParser.parse
    '''
    module_args_parser = ModuleArgsParser()
    assert isinstance(module_args_parser, ModuleArgsParser)

    # parse empty task
    task = dict()
    (action, args, delegate_to) = module_args_parser.parse(task)
    assert action is None
    assert args == dict()
    assert delegate_to is None

    # parse task with just an action, but no arguments
    task = dict(action='locale')
    (action, args, delegate_to) = module_args_parser.parse(task)
    assert action == 'locale'
    assert args == dict()
    assert delegate_to is None

    # parse task with an action and arguments

# Generated at 2022-06-25 03:50:52.868800
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.template import Templar
    import ansible.constants as C
    C.DEFAULT_COMPLEX_ARGS_ERROR = True
    # initialization
    task_0 = dict()
    result = ModuleArgsParser(task_ds=task_0, collection_list=None).parse()
    assert (result == (None, dict(), Sentinel))
    # initialization
    task_0 = dict(action='ping')
    result = ModuleArgsParser(task_ds=task_0, collection_list=None).parse()
    assert (result == ('ping', dict(), Sentinel))
    # initialization
    task_0 = dict(action='ping', delegate_to='localhost')

# Generated at 2022-06-25 03:51:05.370573
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() == (None, None, None)
    assert module_args_parser_1.parse(True) == (None, None, None)

    module_args_parser_2 = ModuleArgsParser({'include': 'Playbook.yml'})
    assert module_args_parser_2.parse() == (None, None, None)
    assert module_args_parser_2.parse(True) == (None, None, None)

    module_args_parser_3 = ModuleArgsParser({'include': {'vars': {'var1': 'value1', 'var2': 'value2'}}})
    assert module_args_parser_3.parse() == (None, None, None)

# Generated at 2022-06-25 03:51:18.813810
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Test with param 'skip_action_validation=False'

    obj_module_args_parser_0_0 = module_args_parser_0.parse()
    assert obj_module_args_parser_0_0 is None

    # Test with param 'skip_action_validation=True'
    skip_action_validation = True
    obj_module_args_parser_0_1 = module_args_parser_0.parse(skip_action_validation=skip_action_validation)
    assert obj_module_args_parser_0_1 is None

    # Test with param 'task_ds'
    task_ds = {"action": {"module": "shell", "args": [{"debug": True}, "echo 123"]}}

# Generated at 2022-06-25 03:51:21.820337
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        action = 'ping'
        thing = 'shell echo hi'
        module_args_parser = ModuleArgsParser()
        module_args_parser.parse()
    except Exception as e:
        raise e


# Generated at 2022-06-25 03:51:31.291828
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Build args from YAML
    thing_0 = dict(
        action=dict(
            module='ec2',
            x=dict(
                y=dict(
                    z='value'
                )
            )
        )
    )

    # Build dict for args
    args = dict()

    # Call method
    (action_0, args_0, delegate_to_0) = ModuleArgsParser().parse(thing_0)

    # Check results
    assert action_0 == 'ec2'
    assert args_0 == dict(
        x=dict(
            y=dict(
                z='value'
            )
        )
    )

    # Build args from YAML
    thing_1 = dict(
        action='ec2 x=2',
        delegate_to='localhost'
    )

    # Build

# Generated at 2022-06-25 03:51:43.184087
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:04.995525
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:10.087716
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_dict_0 = dict()
    task_ds_dict_0['foo'] = undecorate_module_name('lineinfile')
    task_ds_dict_0['bar'] = 'c'
    task_ds_dict_0['zoo'] = None
    test_dict_0 = dict()
    test_dict_0['foo'] = undecorate_module_name('lineinfile')
    test_dict_0['bar'] = {'c': 'd'}
    module_name_0, parsed_args_0, delegate_to_0 = module_args_parser_0.parse(task_ds=test_dict_0, collection_list=[])
    test_dict_1 = dict()

# Generated at 2022-06-25 03:52:17.006646
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import PY3

    # Simple parse test
    task_ds_0 = dict(action='echo hi')
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    assert module_args_parser_0.parse() == ('echo', {'_raw_params': 'hi'}, None)

    # Simple Parse with action_wrapper
    # NOTE: this is a hack to support the legacy arg form with the shell module.
    # In 2.11, we may want to move the shell module to a wrapper that only allows
    # the special shell: arg form that it currently supports.
    task_ds_1 = dict(action='shell echo hi')
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    assert module

# Generated at 2022-06-25 03:52:23.010624
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialization
    # Run method parse
    #assert module_args_parser_0.parse() == (action, args, delegate_to)

    assert True == True


# Generated at 2022-06-25 03:52:29.801513
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    thing = None
    additional_args = {}
    action = 'copy'
    args = {'src': 'a', 'dest': 'b'}
    (action_return, args_return, delegate_to_return) = module_args_parser._normalize_parameters(thing, action, additional_args)
    assert action_return == action, "_normalize_parameters() did not return the expected value"
    assert args_return == args, "_normalize_parameters() did not return the expected value"

# vim: filetype=python tabstop=8 expandtab

# Generated at 2022-06-25 03:52:37.545691
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:51.248261
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Read input file
    filename = os.path.dirname(os.path.realpath(__file__)) + '/module_args_parser.json'
    with open(filename, 'r') as f:
        input_lines = f.readlines()
        test_cases = [json.loads(line) for line in input_lines]

    # Loop through test cases
    for i in range(len(test_cases)):
        input_data = test_cases[i]
        print("Test Case " + str(i))

# Generated at 2022-06-25 03:52:55.790190
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = ModuleArgsParser()
    task_ds = dict()
    action = 'aws_ec2'
    args = dict()
    delegate_to = None
    # verification of results
    (actual_action, actual_args, actual_delegate_to) = module_args.parse()
    assert (actual_action == action) and (actual_args == args) and (actual_delegate_to == delegate_to)


# Generated at 2022-06-25 03:53:01.114853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    print("\nSTART OF TEST 1 ****************************")
    print("Placeholder test, do nothing!")
    print("\n**************************** END OF TEST 1")

    #logger.error('No unit test available')
    #assert False

if __name__ == '__main__':
    if not os.path.exists('./log'):
        os.makedirs('./log')
    logging.config.fileConfig('./logging.conf')
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:53:06.058674
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Stub a ModuleArgsParser object
    module_args_parser = ModuleArgsParser()
    # Try to parse a task using the parse method
    try:
        thing = None
        module_args_parser.parse(thing)
    except AnsibleParserError as e:
        # We caught an exception, but did not expect it
        solve_etree_namespace_issue()
        return False, "Task without action raised an exception"
    # We did not catch any exception, and parse should have returned
    return True, "Task without action passed"


# Generated at 2022-06-25 03:53:25.991343
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mo = ModuleArgsParser()
    task_ds = dict()
    (action, args, delegate_to) = mo._split_module_string('copy src=a dest=b')
    assert (action == 'copy')
    assert (args == 'src=a dest=b')
    (action, args, delegate_to) = mo.parse()
    assert (action is None)
    assert (args is None)
    assert (delegate_to == Sentinel)
    task_ds = dict()
    (action, args, delegate_to) = mo._split_module_string('copy src=a')
    assert (action == 'copy')
    assert (args == 'src=a')
    (action, args, delegate_to) = mo.parse()
    assert (action is None)
    assert (args is None)

# Generated at 2022-06-25 03:53:29.974997
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = dict()
    collection_list_0 = None
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=False)
    assert action == 'None'
    assert args == dict()
    assert delegate_to == 'host'



# Generated at 2022-06-25 03:53:41.663808
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    thing = { "action" : "copy src=a dest=b" }
    print("thing = %s" % thing)
    (action, args, delegate_to) = module_args_parser.parse(thing, skip_action_validation=True)
    assert(action == "copy")
    assert(args == {"src":"a","dest":"b"})

if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='ad-hoc', add_help=False)
    testcase = parser.add_subparsers(title='testcases')
    testcase_0 = testcase.add_parser('0')
    testcase.set_defaults(func='test_case_0')

    args = parser.parse_args()


# Generated at 2022-06-25 03:53:53.735784
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # Testing input tuple of data:
    # test_data[0] is input dict
    # test_data[1] is expected action
    # test_data[2] is expected args
    # test_data[3] is expected delegate_to
    test_data = [
        dict(action='test', args=dict(a=1, b=2)),
        'test',
        dict(a=1, b=2),
        Sentinel,
    ]

    action, args, delegate_to = module_args_parser.parse(skip_action_validation=True)

    assert (action, args, delegate_to) == test_data[1:]

import pytest


# Generated at 2022-06-25 03:54:05.851614
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    # create a test case for runnning unit test
    task_ds_0 = dict()
    task_ds_0['action'] = dict()
    task_ds_0['action']['module'] = 'ping'
    task_ds_0['action']['args'] = dict()
    task_ds_0['action']['args']['data'] = 'test_data'
    task_ds_0['action']['args']['test_arg'] = 'test_value'

    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    module_args_dict_0 = module_args_parser_0.parse()


# Generated at 2022-06-25 03:54:14.958518
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result == ('', {}, None)

    task_ds = {'action': 'copy src=a dest=b'}
    result = module_args_parser.parse(skip_action_validation=True)
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task_ds = {'action': {'module': 'ec2', 'x': '1'}}
    result = module_args_parser.parse(skip_action_validation=True)
    assert result == ('ec2', {'x': '1'}, None)


# Generated at 2022-06-25 03:54:21.596914
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test 0
    task_ds0 = { 'action': 'foo' }
    module_args_parser_0 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_0.parse(task_ds0)
    if not (action == 'foo' and args == None and delegate_to == None):
        raise AssertionError("ModuleArgsParser.parse did not return correct arguments")


# Generated at 2022-06-25 03:54:31.860761
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # A builtin action with a raw module and raw parameter
    task_ds_0 = dict(action=dict(module='raw', parameters='sleep 10'))
    module_args_parser_0 = ModuleArgsParser(task_ds_0)
    action, args, delegate_to = module_args_parser_0.parse()
    assert(action == 'raw')
    assert(args == dict(parameters='sleep 10'))
    assert(delegate_to == Sentinel)
    # action has a module and a raw parameter
    task_ds_1 = dict(action='raw parameters=sleep 10')
    module_args_parser_1 = ModuleArgsParser(task_ds_1)
    action, args, delegate_to = module_args_parser_1.parse()
    assert(action == 'raw')

# Generated at 2022-06-25 03:54:38.898310
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {}
    collection_list_1 = []
    try:
        result_1 = module_args_parser_1.parse(task_ds=task_ds_1, collection_list=collection_list_1)
        # noinspection PyUnreachableCode
        assert False, "AnsibleParserError not raised"
    except AnsibleParserError as e:
        assert str(e) == "no module/action detected in task."
        assert e.obj is task_ds_1

    module_args_parser_2 = ModuleArgsParser()
    task_ds_2 = {'action': {'module': 'ping'}}
    collection_list_2 = []

# Generated at 2022-06-25 03:54:51.730995
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    rhs = dict({'action': 'my_action src=/tmp/{{ item }} dest=/here/' }, **{'register': 'my_result', 'with_items': '{{ list_of_files }}' })
    task_ds = dict(**{'name': 'my_task', 'local_action': 'my_action src=/tmp/{{ item }} dest=/here/' }, **{'register': 'my_result', 'with_items': '{{ list_of_files }}' })
    action1, args1, delegate_to1 = ModuleArgsParser(rhs).parse()
    action2, args2, delegate_to2 = ModuleArgsParser(task_ds).parse()

    assert(action1 == 'my_action')
    assert(action2 == 'my_action')

# Generated at 2022-06-25 03:55:10.898231
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser_0 = ModuleArgsParser()
    args = module_args_parser_0.parse()
    assert args == ("ping", {}, "default")

if __name__ == "__main__":
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:55:17.116873
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize ModuleArgsParser
    parser = ModuleArgsParser()
    # Call method parse with valid values
    action, args, delegate_to = parser.parse(skip_action_validation=True)
    
    # Check if action is None
    assert action is None, 'ModuleArgsParser_parse: action is not None'
    # Check if args is None
    assert args is None, 'ModuleArgsParser_parse: args is not None'
    # Check if delegate_to is None
    assert delegate_to is None, 'ModuleArgsParser_parse: delegate_to is not None'

if __name__ == '__main__':
    # Run test cases
    test_case_0()

# Generated at 2022-06-25 03:55:21.850734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # WORKS: get the module name out of the action
    test_ds = dict(action="shell blah blah blah")
    (action, args, delegate_to) = ModuleArgsParser(task_ds=test_ds).parse()
    assert action == "shell"

    # WORKS: get the module name out of the action, strip off the 'action: '
    test_ds = dict(action="shell blah blah blah")
    (action, args, delegate_to) = ModuleArgsParser(task_ds=test_ds).parse()
    assert action == "shell"

    # WORKS: get the module name out of the action, strip off the 'action: '
    test_ds = dict(action="shell foo=bar")
    (action, args, delegate_to) = ModuleArgsParser(task_ds=test_ds).parse()

# Generated at 2022-06-25 03:55:30.093400
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:55:32.170004
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse(arg="") == ("", dict(), None)

# Generated at 2022-06-25 03:55:42.467621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test params
    test_args = dict()

    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Example of actual task dictionary
    task_ds = dict()
    task_ds['local_action'] = {'module': 'shell', 'args': 'echo'}
    task_ds['delegate_to'] = 'localhost'
    task_ds['register'] = 'shell_out'
   

# Generated at 2022-06-25 03:55:48.707127
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #def parse(self, skip_action_validation=False):
    """
    Test to parse the module args into a hash of the form
    """

# Generated at 2022-06-25 03:55:54.522543
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds= {'action': {'module': 'raw', '_raw_params': 'getenforce', 'follow': False}}
    collection_list = []
    module_args_parser_0 = ModuleArgsParser(task_ds, collection_list)
    (action, args, delegate_to) = module_args_parser_0.parse()

# endregion

# region AnsibleModule


# Generated at 2022-06-25 03:55:56.159579
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser('foo')
    print(json.dumps(module_args_parser.parse(), indent=4))


# Generated at 2022-06-25 03:56:00.109999
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser({'action': 'ec2'})
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:57:14.667108
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, None, None)
    assert module_args_parser_0.parse() == (None, None, None)
    assert module_args_parser_0.parse() == (None, None, None)

# ---------- END ----------

# Generated at 2022-06-25 03:57:24.491740
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    LOG.info("test_ModuleArgsParser_parse")

    def run_test(module_task, expected_action, expected_args, expected_delegate_to):
        """ Tests the parse method of the ModuleArgsParser class given a task and expected results """
        LOG.info("Testing task {task}".format(task=module_task))
        parser = ModuleArgsParser(module_task)
        (action, args, delegate_to) = parser.parse()
        assert action == expected_action
        assert args == expected_args
        assert delegate_to == expected_delegate_to

    # Local action test
    module_task = {
        "name" : "test_task_0",
        "local_action" : "shell echo hello"
    }

# Generated at 2022-06-25 03:57:32.387514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleAssertionError
    import os
    import sys
    import pytest

    # without mocks: unit test module_args_parser.parse()
    #####################################################################################################
    # test 'pwd' scenario
    #####################################################################################################

    # inputs
    my_task_ds = {}
    my_task_ds['command'] = 'pwd'
    my_task_ds['args'] = {}
    my_task_ds['args']['chdir'] = '/tmp'

    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(my_task_ds)
    assert action == 'command'

# Generated at 2022-06-25 03:57:39.018595
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case with assert_equal
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23

# Generated at 2022-06-25 03:57:47.800314
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_1.parse()
    print (action, args, delegate_to)
    (action, args, delegate_to) = module_args_parser_1.parse()
    print (action, args, delegate_to)
    (action, args, delegate_to) = module_args_parser_1.parse()
    print (action, args, delegate_to)
    (action, args, delegate_to) = module_args_parser_1.parse()
    print (action, args, delegate_to)


# Generated at 2022-06-25 03:57:54.124013
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action, args, delegate_to = ModuleArgsParser().parse()
    assert action == 'noop'
    assert args == dict()
    assert delegate_to is None


# Generated at 2022-06-25 03:58:05.301587
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    expected_action = None
    expected_args = {}
    expected_delegate_to = None

    action, args, delegate_to = module_args_parser_1.parse()
    assert_equals(action, expected_action)
    assert_equals(args, expected_args)
    assert_equals(delegate_to, expected_delegate_to)
