

# Generated at 2022-06-25 03:48:44.150918
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test case 0
    #
    # This is the standard YAML form for command-type modules. We grab
    # the args and pass them in as additional arguments, which can/will
    # be overwritten via dict updates from the other arg sources below
    additional_args = {
        'x' : 1,
        'y' : 2,
        'z' : {
            'a':'b',
            'c':'d',
            'f':'g'
        }
    }

    # We can have one of action, local_action, or module specified
    # action
    action = 'action'
    args = 'echo hi'
    args = {
        'a': 1,
        'b': 2
    }

    # local_action
    local_action = 'local_action'

# Generated at 2022-06-25 03:48:54.129827
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    class TestModule(object):
        """This class contains the unit test for ModuleArgsParser.parse"""
        # Test case for when task_ds is None
        def test_case_0(self):
            module_args_parser_0 = ModuleArgsParser(None)
            assert module_args_parser_0.parse() == ('setup', {}, None)

        # Test case for when task_ds is not a dict instance
        def test_case_1(self):
            module_args_parser_1 = ModuleArgsParser("")
            assert module_args_parser_1.parse() == ('setup', {}, None)

        # Test case for when task_ds is not of dict type
        def test_case_2(self):
            task_ds = dict()
            module_args_parser_2 = ModuleArgsParser(task_ds)
           

# Generated at 2022-06-25 03:49:02.261413
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser({'action': 'ping', 'delegate_to': 'localhost'})
    (action, args, delegate_to) = module_args_parser_1.parse()
    assert action == 'ping'
    assert args == {}
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:49:12.943955
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # First test case
    task_ds_0 = {"module": "shell", "args": "command='echo 1'"}
    collection_list_0 = None
    module_args_parser_0 = ModuleArgsParser(task_ds_0, collection_list_0)
    (action, args, delegate_to) = module_args_parser_0.parse()

    # Expected result of first test case
    action_0 = "shell"
    args_0 = {"args": "command='echo 1'"}
    delegate_to_0 = None

    # Second test case
    task_ds_1 = {"module": "shell", "args": "command='echo 1'"}
    collection_list_1 = None
    module_args_parser_1 = ModuleArgsParser(task_ds_1, collection_list_1)

# Generated at 2022-06-25 03:49:17.345127
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    example_arg_dict = dict(arg1="value1", arg2="value2")
    example_task_dict = dict(action="action_name", module_args=example_arg_dict)
    module_args_parser = ModuleArgsParser()
    expected = ("action_name", example_arg_dict, None)
    actual = module_args_parser.parse(example_task_dict)
    assert expected == actual, "Result of ModuleArgsParser.parse() is incorrect."


# Generated at 2022-06-25 03:49:27.354083
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test module name followed by action + key value args in same string
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(dict(action = 'copy src=a dest=b'))
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to == None

    # test module name followed by action + key value args in same string, with a shell command
    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(dict(action = 'shell echo hi'))
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi')
    assert delegate_to == None

    # test module name followed by action + key value args in same string,

# Generated at 2022-06-25 03:49:37.900309
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # Parse the task data
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action == 'ping'

    # Parse the task data
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=True)
    assert action == 'ping'

    # Parse the task data
    module_args_parser_1 = ModuleArgsParser(task_ds=dict(action='ping'))
    (action, args, delegate_to) = module_args_parser_1.parse()
    assert action == 'ping'

    # Parse the task data
    module_args_parser_2 = ModuleArgsParser(task_ds=dict(module='ping'))

# Generated at 2022-06-25 03:49:44.674432
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'first_name': 'John',
               'last_name': 'Doe',
               'local_action': 'command echo hi',
               'action': {'module': 'shell echo hi', 'x': 'y'},
               'no_action': 'shell echo hi',
               'action1': 'shell echo hi',
               'action2': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    try:
        module_args_parser.parse()
    except AnsibleParserError as e:
        assert e.args[0] == "action and local_action are mutually exclusive"


# Generated at 2022-06-25 03:49:55.122453
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:49:58.537351
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=None)
    action, args, delegate_to = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is not None
    assert delegate_to is Sentinel


# Generated at 2022-06-25 03:50:15.382935
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up the test case
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {}
    collection_list_1 = {}
    module_args_parser_1._task_ds = task_ds_1
    module_args_parser_1._collection_list = collection_list_1
    skip_action_validation_1 = False
    # Run the method under test
    action_result_1, args_result_1, delegate_to_result_1 = module_args_parser_1.parse(skip_action_validation_1)
    # Check the results
    assert action_result_1 == None
    assert args_result_1 == {}
    assert delegate_to_result_1 == Sentinel


# Generated at 2022-06-25 03:50:24.160694
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    action = 'copy'
    delegate_to = 'localhost'
    args = dict()

    task_ds = {'local_action': 'copy src=a dest=b'}
    action_0, args_0, delegate_to_0 = module_args_parser.parse(task_ds)
    assert action == action_0
    assert args == args_0
    assert delegate_to == delegate_to_0

    task_ds = {'local_action': 'copy', 'args': {'src': 'a', 'dest': 'b'}}
    action_0, args_0, delegate_to_0 = module_args_parser.parse(task_ds)
    assert action == action_0
    assert args == args_0
    assert delegate_to == delegate_to_0

# Generated at 2022-06-25 03:50:36.468984
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # standard YAML task definition with module args
    task_string = '''- name: test module_args
  command: "pwd"
  args:
    chdir: /tmp'''
    task = AnsibleModule._load_task_from_data(yaml.safe_load(task_string))
    action, args, delegate_to = module_args_parser_0.parse(task.copy())
    assert action == 'command'
    assert isinstance(args, dict)
    assert delegate_to is None
    new_task_string = '''- name: test module_args
  {{ module }}: "pwd"'''
    new_task = AnsibleModule._load_task_from_data(yaml.safe_load(new_task_string))


# Generated at 2022-06-25 03:50:43.509140
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {
        'action': {'module': 'shell echo hi'},
        'local_action': {'module': 'copy src=a dest=b'},
        'action': 'shell echo hi',
        'local_action': 'copy src=a dest=b',
        'shell': 'echo hi',
        'echo': 'hi',
    }

    for case in ds:
        module_args_parser_1 = ModuleArgsParser({'action': case})
        module_args_parser_1.parse()

if __name__ == "__main__":
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:50:48.210857
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # set up test case
    module_args_parser_0 = ModuleArgsParser()

    # set up test input
    task_ds = {}

    # call method under test
    (action, args, delegate_to) = module_args_parser_0.parse()

    # assert results
    assert (action == None)
    assert (args == None)
    assert (delegate_to == None)


# Generated at 2022-06-25 03:50:52.175930
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    
    # Test function with multiple arguments
    args = {}
    to_pass_in_args = {}
    skip_action_validation = True
    result = parser.parse(thing=args, action=None, delegate_to=None, additional_args=to_pass_in_args, skip_action_validation=skip_action_validation)
    assert result != None


# Generated at 2022-06-25 03:51:04.786866
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Assumption: input of task_ds is a dictionary and is of proper format
    # Case 1: action and delegate_to are defined in the task_ds
    task_ds = {'action': 'shell', 'delegate_to': 'localhost'}
    module_args_parser_1 = ModuleArgsParser(task_ds)
    result = module_args_parser_1.parse()
    expected_result = ('shell', {}, 'localhost')
    assert result == expected_result

    # Case 2: local_action and delegate_to are defined in the task_ds
    # Input: task_ds = {'local_action': 'shell', 'delegate_to': 'localhost'}
    # Output: ('shell', {}, 'localhost')
    task_ds = {'local_action': 'shell', 'delegate_to': 'localhost'}

# Generated at 2022-06-25 03:51:18.788725
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Check valid action
    # Variables
    test_ds = {
        "action": "copy",
        "src": "a",
        "dest": "b"
    }
    module_args_parser = ModuleArgsParser(test_ds)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    # Check valid local_action
    # Variables
    test_ds = {
        "local_action": "copy",
        "src": "a",
        "dest": "b"
    }
    module_args_parser = ModuleArgsParser(test_ds)
    assert module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
    # Check valid local_action & module


# Generated at 2022-06-25 03:51:28.700204
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():       
    test_parser_1 = ModuleArgsParser({'action':'ping', 'delegate_to':'localhost'})
    assert test_parser_1.parse() == ('ping', dict(), 'localhost')

    test_parser_2 = ModuleArgsParser({'action':'ping', 'delegate_to':'localhost', 'args':{'data':'dummy_data'}})
    assert test_parser_2.parse() == ('ping', {'data':'dummy_data'}, 'localhost')

    test_parser_3 = ModuleArgsParser({'action':'copy', 'args':'src=/tmp/test dest=/tmp/test2'})
    assert test_parser_3.parse() == ('copy', {'src':'/tmp/test', 'dest':'/tmp/test2'}, None) 


# Generated at 2022-06-25 03:51:35.832057
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test a regular task
    raw_dict = dict(action='test')
    parser = ModuleArgsParser(raw_dict)
    module, args, delegate_to = parser.parse()
    assert module == 'test'
    assert args == dict({})
    assert delegate_to == Sentinel

    # Test parsing of a task with module arguments
    raw_dict = dict(action='test args="test param"')
    parser = ModuleArgsParser(raw_dict)
    module, args, delegate_to = parser.parse()
    assert module == 'test'
    assert args == dict(args='test param')
    assert delegate_to == Sentinel

    # Test an edge case where an action is declared as a dict containing a 'module' key
    raw_dict = dict(action=dict(module='test args="test param"'))
    parser = ModuleArgsParser

# Generated at 2022-06-25 03:51:49.080661
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:51:54.892061
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Unit test for method parse of class ModuleArgsParser
    """
    module_args_parser_0 = ModuleArgsParser(
        task_ds={
            'action': {
                'module': 'shell',
                'args': 'echo hi',
            },
        },
    )
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert (action == 'shell')
    assert (args == {'args': 'echo hi'})
    assert (delegate_to == Sentinel)
    module_args_parser_1 = ModuleArgsParser(
        task_ds={
            'local_action': {
                'module': 'shell',
                'args': 'echo hi',
            },
        },
    )
    (action, args, delegate_to) = module_args_parser_1

# Generated at 2022-06-25 03:51:58.827282
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_2 = ModuleArgsParser()

    # Sys.exit is called below to halt the test.
    # This ensures that the following message is logged to the console
    print('Test parse of class ModuleArgsParser: ERROR: No test implemented yet')
    sys.exit(1)



# Generated at 2022-06-25 03:52:01.427149
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = bool()
    object_0 = object()
    object_0 = module_args_parser_0.parse(skip_action_validation)
    print(object_0)

test_case_0()

test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:12.518016
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:52:14.741036
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    print(type(module_args_parser_0))
    print(module_args_parser_0)


# Generated at 2022-06-25 03:52:24.801762
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    # enum module_name_1:
    #   MODULE_NAME_SHELL
    #   MODULE_NAME_COPY
    module_name_1 = "shell"
    # dict args_1:
    #   "echo hi"
    # str delegate_to:
    #   localhost
    delegate_to = "localhost"
    actual_1 = module_args_parser_1.parse(module_name_1, args_1, delegate_to)
    assert(actual_1 == expect_1)


# Generated at 2022-06-25 03:52:33.599894
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task1 = dict(
        action=dict(
            module='copy',
            src='some_source',
            dest='some_dest'),
        delegate_to='some_delegate'
    )
    p = ModuleArgsParser(task1)
    assert p.parse() == ('copy', dict(src='some_source', dest='some_dest'), 'some_delegate')


task2 = dict(
    action='copy src=some_source dest=some_dest',
    delegate_to='some_delegate'
)
p = ModuleArgsParser(task2)
test_ModuleArgsParser_1 = p.parse()


# Generated at 2022-06-25 03:52:39.904159
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up parameters
    # module_args_parser_0 = ModuleArgsParser()
    task_ds = {}

    # Call function being tested
    # module_args_parser_0.parse(task_ds)
    module_args_parser_0 = ModuleArgsParser()


# Define a main() function.

# Generated at 2022-06-25 03:52:51.665232
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook_objects import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    pc = PlayContext()
    collection_list = {}
    task_ds = AnsibleBaseYAMLObject()
    task_ds.yaml_data = {'action': {'other_var': '{{ other_var }}',
                                    'env': '{{ env_value }}',
                                    'hosts': '{{ inventory_hostname }}'},
                         'name': 'task-name'}

# Generated at 2022-06-25 03:53:11.424564
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # Setup args, kwargs, and expected result
    task_0 = {
        'action': 'copy src=a dest=b'
    }
    task_1 = {
        'module': 'copy src=a dest=b'
    }
    task_2 = {
        'action': {
            'shell': 'echo hi'
        }
    }
    task_3 = {
        'module': {
            'shell': 'echo hi'
        }
    }
    task_4 = {
        'action': {
            'module': 'copy src=a dest=b'
        }
    }

# Generated at 2022-06-25 03:53:19.780359
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Check if method parse raises a ValueError exception when dict is passed as arg
    module_args_parser_test_0 = ModuleArgsParser()
    module_args={'delegate_to': None, 'args': {}, 'action': {'uri': {'url': 'https://www.ansible.com', 'status_code': 200}}}
    with pytest.raises(AnsibleParserError):
        module_args_parser_test_0.parse(module_ds=module_args)

    # Check if method parse raises a ValueError exception when list is passed as arg
    module_args_parser_test_1 = ModuleArgsParser()

# Generated at 2022-06-25 03:53:31.042216
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    action = 'ping'
    args = {}
    delegate_to = 'localhost'

    # ModuleArgsParser() creates an empty task_ds
    (action, args, delegate_to) = module_args_parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is Sentinel

    # Create a task_ds with a local_action statement and test with that
    task_ds = dict()
    task_ds.update({'local_action': 'ping'})
    module_args_parser = ModuleArgsParser(task_ds)

    (action, args, delegate_to) = module_args_parser.parse()
    assert action == 'ping'
    assert args == {}
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:53:43.352777
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # test passing an empty dictionary
    task_ds_0 = {}
    # result of calling function parse on module_args_parser_0
    (action, args, delegate_to) = module_args_parser_0.parse()
    assert action is None
    assert args is None
    assert delegate_to is Sentinel

    # test passing different values
    task_ds_1 = {'action': 'echo hi'}
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    (action, args, delegate_to) = module_args_parser_1.parse()
    assert action == 'echo'
    assert args == {}
    assert delegate_to is Sentinel


# Generated at 2022-06-25 03:53:50.025952
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = dict(action=dict(module='shell', args='echo hi'))
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    result_0 = module_args_parser_0.parse()
    assert result_0 == ('shell', {'args': 'echo hi'}, None)



# Generated at 2022-06-25 03:53:51.980527
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse()
    # FIXME
    # AnsibleParserError: conflicting action statements: shell, shell


# Generated at 2022-06-25 03:54:05.136248
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Tests method ModuleArgsParser.parse()"""
    print("Testing ModuleArgsParser.parse()")

    # case 0
    print("  case 0")

    task_ds = dict(name="test-task", module='copy', args={'src': '{{extra}}', 'dest': '{{destination}}'})

    module_args_parser = ModuleArgsParser(task_ds)
    assert_equal((module_args_parser.parse()), ('copy', {'src': '{{extra}}', 'dest': '{{destination}}'}, None))

    # case 1
    print("  case 1")

    task_ds = dict(name="test-task", module='copy', args='src={{extra}} dest={{destination}}')

    module_args_parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-25 03:54:09.896609
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_obj = ModuleArgsParser()
    module_args_parser_obj.parse()

# Generated at 2022-06-25 03:54:13.998619
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0 = { 'tasks' : [{ 'module' : 'shell', 'command' : 'echo hi', 'args' : { 'chdir' : '/tmp' } }] }
    assert ModuleArgsParser(task_ds_0).parse().action == ('shell', {'command': 'echo hi', 'chdir': '/tmp'}, None)


# Generated at 2022-06-25 03:54:19.918369
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(
        action=dict(
            module='win_ping',
            msg='Hello World'
        )
    )
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'win_ping'
    assert args == dict(msg='Hello World')
    assert delegate_to is Sentinel

    task_ds = dict(
        action=dict(
            module='win_ping',
            msg='Hello World'
        ),
        delegate_to='localhost'
    )
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'win_ping'
    assert args == dict(msg='Hello World')
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:54:36.883585
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0= {"args": {"linear": "true"}, "when": {"var1": "1", "var2": "2"}, "name": "test_task_0", "local_action": {"action": "command", "args": {"_raw_params": "ls -ltr", "free_form": true}, "with_items": ["test_item_0", "test_item_1", "test_item_2"]}}
    result_0 = module_args_parser_0.parse(task_ds_0)
    assert("ansible.builtin.command" == result_0[0])
    assert("true" == result_0[1]["linear"])
    assert("1" == result_0[1]["var1"])

# Generated at 2022-06-25 03:54:45.961840
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    target_module = module_args_parser._split_module_string("using module args and module name")
    assert target_module[0] == "module"
    assert target_module[1] == "args and module name"

    (action, args, delegate_to) = module_args_parser.parse({"action": "echo 'hello world'"})
    assert action == "shell"
    assert args["_raw_params"] == "echo 'hello world'"
    assert delegate_to is Sentinel

    (action, args, delegate_to) = module_args_parser.parse({"local_action": "echo 'hello world'"})
    assert action == "shell"
    assert args["_raw_params"] == "echo 'hello world'"
    assert delegate_to == "localhost"

   

# Generated at 2022-06-25 03:54:54.964693
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    dict_ds_1 = {'name': 'test_task', 'delegate_to': 'localhost', 'action': 'shell', 'args': 'echo hi'}
    task = module_args_parser_1.parse(skip_action_validation=True)
    assert task == (None, {}, None)
    assert module_args_parser_1._task_ds == dict_ds_1
    assert module_args_parser_1._task_ds.keys() == dict_ds_1.keys()
    assert module_args_parser_1._task_ds.values() == dict_ds_1.values()
    assert module_args_parser_1._task_ds.get('action') == dict_ds_1.get('action')


# Generated at 2022-06-25 03:55:03.196109
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create an instance of ModuleArgsParser
    module_args_parser_1 = ModuleArgsParser()
    # Create the task_ds argument
    task_ds_1 = dict(action=dict())
    task_ds_2 = dict(local_action=dict())
    task_ds_3 = dict()
    task_ds_4 = dict(action='shell')
    task_ds_5 = dict(local_action='shell')
    task_ds_6 = dict(action='shell args={{ not_used }}')
    task_ds_7 = dict(local_action='shell args={{ not_used }}')
    task_ds_8 = dict(action='shell args={{ not_used }}, test={{ foo }}')
    task_ds_9 = dict(action='shell', args=dict(test='{{ foo }}'))


# Generated at 2022-06-25 03:55:06.426569
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleParserError):
        args = {}
        module_args_parser = ModuleArgsParser(args)
        module_args_parser.parse()


# Generated at 2022-06-25 03:55:11.576208
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('Unit test for method parse of class ModuleArgsParser.\n')

    module_args_parser = ModuleArgsParser()

    # Test case 0
    print('Test case 0:')
    task_ds = {}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    print('action: ' + action)
    print('args: ' + str(args))
    print('delegate_to: ' + delegate_to)

    # Test case 1
    print('Test case 1:')
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    action, args, delegate_to = module_args_parser.parse(task_ds)
    print('action: ' + action)
    print('args: ' + str(args))

# Generated at 2022-06-25 03:55:19.516810
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # First test case
    # Prepare test data and expected result
    task_ds = {'shell': 'echo hi'}
    expected_result = ('shell', 'echo hi')
    module_args_parser = ModuleArgsParser(task_ds = task_ds)
    # Run function parse
    actual_result = module_args_parser.parse()
    # Check result and expected result
    assert actual_result == expected_result
    # Second test case
    # Prepare test data and expected result
    task_ds = {'action': 'shell echo hi'}
    expected_result = ('shell', 'echo hi')
    module_args_parser2 = ModuleArgsParser(task_ds = task_ds)
    # Run function parse
    actual_result = module_args_parser2.parse()
    # Check result and expected result
    assert actual_

# Generated at 2022-06-25 03:55:24.015078
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, {}, None)
    assert module_args_parser_0.parse() == (None, {}, None)


# Generated at 2022-06-25 03:55:32.045879
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Unit test for parsing old-style task/module combination
    task_ds_0 = dict(shell='ls /')

    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse()
    assert action_0 == 'shell'
    assert args_0 == dict(cmd='ls /')
    assert delegate_to_0 is None

    # Unit test for parsing old-style local_action task/module combination
    task_ds_1 = dict(local_action='shell ls')

    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    action_1, args_1, delegate_to_1 = module_args_parser_1.parse()

# Generated at 2022-06-25 03:55:39.225794
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {'action': {'module': 'include_vars', 'name': 'groups'}, 'name': 'creating groups vars'}
    parsed = ModuleArgsParser(ds).parse()
    assert parsed == ('include_vars', {'name': 'groups'}, None)

    ds = {'action': 'set_fact', 'db_servers': ['192.168.10.1', '192.168.10.2'], 'name': 'set db servers var'}
    parsed = ModuleArgsParser(ds).parse()
    assert parsed == ('set_fact', {'db_servers': ['192.168.10.1', '192.168.10.2']}, None)


# Generated at 2022-06-25 03:55:55.615036
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Setup the class and it's dependencies

    # Create a test case with the following datastructure
    test_case = dict()
    test_case['action'] = 'copy'
    test_case['keys'] = 'src=a dest=b'

    module_args_parser_0 = ModuleArgsParser()
    # Run the "parse" method
    result = module_args_parser_0.parse(test_case)

    # assert that the result corresponds to what we expect
    assert result == {'action': 'copy', 'keys': 'src=a dest=b'}


# Generated at 2022-06-25 03:56:02.499388
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_ds = {'args': {'an_argument': 'foo'}, 'action': 'ping', 'name': 'ping ansible'}
    test_collection_list = []
    module_args_parser=ModuleArgsParser(task_ds=test_ds, collection_list=test_collection_list)
    assert module_args_parser.parse() == ('ping', {'an_argument': 'foo'}, None)


# Generated at 2022-06-25 03:56:08.571093
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = None
    args = dict()
    delegate_to = None
    module_args_parser_0 = ModuleArgsParser()
    task_ds = dict()
    (action, args, delegate_to) = module_args_parser_0.parse(task_ds)
    print(action)
    print(args)
    print(delegate_to)


# Generated at 2022-06-25 03:56:20.533596
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print ('Testing ModuleArgsParser.parse')
    # Change the following values to test
    task_ds_0 = {}
    collection_list_0 = None
    module_args_parser_0 = ModuleArgsParser(task_ds_0, collection_list_0)
    result_0 = module_args_parser_0.parse()
    # Check the equality of expected value and actual value
    assert result_0 == (None, None, None)
    # Change the following values to test
    task_ds_1 = {}
    collection_list_1 = None
    module_args_parser_1 = ModuleArgsParser(task_ds_1, collection_list_1)
    result_1 = module_args_parser_1.parse()
    # Check the equality of expected value and actual value

# Generated at 2022-06-25 03:56:31.223275
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser({u'action': {u'ec2': u'region=us-east-1'}, u'tags': {u'Name': u'foo.example.com'}}).parse()
    assert result[0] == u'ec2'
    assert result[1][u'region'] == u'us-east-1'
    assert result[2] == None

    result = ModuleArgsParser({u'action': {u'delegate_to': u'localhost', u'ec2': u'region=us-east-1'}, u'tags': {u'Name': u'foo.example.com'}}).parse()
    assert result[0] == u'ec2'
    assert result[1][u'region'] == u'us-east-1'
    assert result[2] == None



# Generated at 2022-06-25 03:56:37.116327
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    for thing in BAD_INVOCATIONS:
        try:
            output = ModuleArgsParser(thing)
            output.parse()
        except AnsibleParserError:
            pass
        else:
            assert False, "AnsibleParserError was not raised."
    for thing in GOOD_INVOCATIONS:
        try:
            output = ModuleArgsParser(thing)
            output.parse()
        except:
            assert False, "An unexpected exception was raised."


# Generated at 2022-06-25 03:56:42.506484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert isinstance(module_args_parser_1, ModuleArgsParser)
    assert not module_args_parser_1.parse()
    assert not module_args_parser_1.parse({})
    assert not module_args_parser_1.parse({"action":"ping","args":"pong"})
    assert module_args_parser_1.parse({"action":"ping","args":"pong"})[0] == "ping"
    assert module_args_parser_1.parse({"action":"ping","args":"pong"})[1] == {"args":"pong"}

# Generated at 2022-06-25 03:56:52.421974
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # Case 0
    task_ds_0 = {}
    result_0 = module_args_parser.parse(task_ds_0)
    assert result_0 == (None, {}, 'Sentinel')
    # Case 1
    task_ds_1 = {'action': 'copy src=a dest=b'}
    result_1 = module_args_parser.parse(task_ds_1)
    assert result_1 == ('copy', {'src': 'a', 'dest': 'b'})
    # Case 2
    task_ds_2 = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    result_2 = module_args_parser.parse(task_ds_2)

# Generated at 2022-06-25 03:56:58.828298
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:57:04.245300
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Test class ModuleArgsParser"""
    module_args_parser = ModuleArgsParser()

    # Test with happy flow inputs
    action_parser_output = module_args_parser.parse()
    assert action_parser_output == (None, dict(), Sentinel), \
        "Error in class ModuleArgsParser: method parse failed."


# Generated at 2022-06-25 03:57:18.448583
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Setup test environment
    module_args_parser_1 = ModuleArgsParser()

    # Create task data structures
    task_ds_1 = {}
    task_ds_1['action'] = 'echo hi, I am testing the parsing of action'
    task_ds_1['delegate_to'] = 'localhost'
    task_ds_1['args'] = dict()
    task_ds_1['args']['_raw_params'] = {'echo hi, I am testing the parsing of action'}

    # Testing parse method
    # Assertion that parse returns correct values for action and args

# Generated at 2022-06-25 03:57:28.754160
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: Get rid of this, use the actual objects.
    class Task(object):
        def __init__(self, task_ds):
            self._task_ds = task_ds

    class Module(object):
        def __init__(self, module_name, module_args):
            self.name = module_name
            self.args = module_args

    class ModuleLoader(object):
        def __init__(self, module_name, collection_list=None):
            self.module_name = module_name
            self.collection_list = collection_list
            self.name = module_name
            self.args = ''

        def find_plugin(self):
            return True

    class ActionLoader(ModuleLoader):
        def find_plugin(self):
            return True

    module_loader = ModuleLoader(None)

# Generated at 2022-06-25 03:57:38.504536
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # test 1
    task_ds = dict()
    task_ds['str1'] = "hello world"
    task_ds['int1'] = 123
    task_ds['list1'] = [1,2,3,4]
    task_ds['dict1'] = {'dict1_key1': 1, 'dict1_key2': 2}
    task_ds['list2'] = [1,2,3,4]
    task_ds['list4'] = [1,2,3,4]
    task_ds['dict2'] = {'dict2_key1': 1, 'dict2_key2': 2}
    task_ds['module'] = "module_name echo hello"


# Generated at 2022-06-25 03:57:47.753689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = ['']
    module_args_parser_0 = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser_0.parse(skip_action_validation=False)
    assert action is None
    assert args == {}
    assert delegate_to is None

    task_ds = {'action': {"module":""} }
    collection_list = ['']
    module_args_parser_1 = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser_1.parse(skip_action_validation=False)
    assert action is None
    assert args == {}
    assert delegate_to is None



# Generated at 2022-06-25 03:57:54.122088
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser().parse() == {'action': 'name', 'local_action': 'module',
                                          'action': 'value'}


# Generated at 2022-06-25 03:58:08.087579
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task = {}

    (action, args) = module_args_parser._normalize_old_style_args(task)
    assert action is None
    assert args == None

    task = {'action': {'module': 'xyz'}}

    (action, args) = module_args_parser._normalize_old_style_args(task)
    assert action == 'xyz'
    assert args == None

    task = {'action': 'copy: src=a dest=b'}

    (action, args) = module_args_parser._normalize_old_style_args(task)
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}

    task = {'action': 'copy src=a dest=b'}