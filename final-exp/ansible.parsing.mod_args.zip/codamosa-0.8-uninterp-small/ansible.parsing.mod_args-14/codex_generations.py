

# Generated at 2022-06-25 03:48:52.187951
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    # test case 1
    task_ds_1 = {'action': 'shell', '_ansible_verbosity': 0, '_ansible_no_log': False}

    expected_action_1 = 'shell'
    expected_args_1 = {}
    expected_delegate_to_1 = Sentinel
    (parsed_action_1, parsed_args_1, parsed_delegate_to_1) = module_args_parser_1._parse(task_ds_1)

    assert expected_action_1 == parsed_action_1
    assert expected_args_1 == parsed_args_1
    assert expected_delegate_to_1 == parsed_delegate_to_1

    # test case 2

# Generated at 2022-06-25 03:48:57.846240
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m_a_parser = ModuleArgsParser()
    action, args, delegate_to = m_a_parser.parse()
    print (action, args, delegate_to)


# Generated at 2022-06-25 03:49:04.682162
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1_1 = ModuleArgsParser()
    task_ds_1_1 = {'action': 'copy src=a dest=/root/b'}
    skip_action_validation_1_1 = True
    actual_result_1_1 = module_args_parser_1_1.parse( task_ds_1_1, skip_action_validation_1_1)
    expected_result_1_1 = ('copy', {'src': 'a', 'dest': '/root/b'}, None)
    assert actual_result_1_1 == expected_result_1_1

    module_args_parser_1_2 = ModuleArgsParser()
    task_ds_1_2 = {'action': 'debug', 'args': {'msg': '1 is one'}}
    skip_action_validation

# Generated at 2022-06-25 03:49:08.587575
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # create object
    module_args_parser_1 = ModuleArgsParser()
    # test parse method
    assert module_args_parser_1.parse() is not None

if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:49:21.500015
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # 1. Create a sample action module
    from ansible.plugins.action import ActionBase
    action_api = ActionBase()

    # 2. Use ModuleArgsParser to parse the action module,
    # and test whether the action module can be parsed correctly
    action_name = "TestAction"
    test_case_1 = {}
    test_case_1['action'] = 'TestAction param=abc'

    task_ds_1 = test_case_1
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds_1)
    (action, args, delegate_to) = module_args_parser_1.parse()

    assert(action == action_name)
    assert(args.get('param') == 'abc')


# Generated at 2022-06-25 03:49:33.146387
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Testing the file ./test/modules/test_module_args_parser.py.
    # Make sure the source s3 bucket exists:
    # 'test/test_module_args_parser.py' exists
    # Fetching remote file contents:
    # 'test/tests/units/modules/test_module_args_parser.py' for local host
    # Copying remote file:
    # 'test/tests/units/modules/test_module_args_parser.py' =>
    # './test/modules/test_module_args_parser.py'
    pass


# Generated at 2022-06-25 03:49:42.275739
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # A test case for when dict is passed and a delegate_to is specified
    test_case_0 = dict(action=dict(module='ec2', x=1), delegate_to='xyz')
    out = module_args_parser.parse(test_case_0)
    actual = out
    expected = ('ec2', {u'x': 1}, 'xyz')
    assert actual == expected

    # A test case for when a string is passed for action,
    # with a delegate_to specified
    test_case_1 = dict(action='echo hello', delegate_to='xyz')
    out = module_args_parser.parse(test_case_1)
    actual = out

# Generated at 2022-06-25 03:49:45.874950
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # When: called with no parameters
    # Then: return tuple with 3 elements
    m_ap = ModuleArgsParser()
    x1 = m_ap.parse()
    assert len(x1)==3, "Fail: expect length of return to be 3"


if __name__ == '__main__':

    print("testing ModuleArgsParser class ...")

    # test default initialization of class ModuleArgsParser
    test_case_0()

    # test method parse of class ModuleArgsParser
    test_ModuleArgsParser_parse()
    print("pass")

# Generated at 2022-06-25 03:49:56.038317
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test 1: simple
    module_args_parser_1 = ModuleArgsParser()
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    action, args, delegate_to = module_args_parser_1.parse(task_ds)
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to is None

    # Test 2: simple
    module_args_parser_2 = ModuleArgsParser()
    task_ds = {'action': 'copy src=a dest=b'}
    action, args, delegate_to = module_args_parser_2.parse(task_ds)
    assert action == 'copy'

# Generated at 2022-06-25 03:49:58.796807
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        module_args_parser_0 = ModuleArgsParser()
        # Call parse of module_args_parser_0
        module_args_parser_0.parse()
    except:
        pass


# Generated at 2022-06-25 03:50:20.189225
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse(skip_action_validation=False)
    print("module_args_parser.resolved_action = %s" % module_args_parser.resolved_action)


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:50:31.900624
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    not_task_attrs = dict()
    module_args_parser_0.class_0 = ModuleArgsParser
    task_ds = dict()
    thing = dict()
    action = 'get_url'
    delegate_to = None
    args = dict()
    additional_args = dict()
    task_ds['action'] = 'get_url'
    thing['dest'] = 'dest'
    thing['url'] = 'url'
    module_args_parser_0._task_ds = task_ds
    module_args_parser_0._task_attrs = not_task_attrs
    module_args_parser_0._task_ds['action'] = thing

# Generated at 2022-06-25 03:50:42.967182
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing for case 1
    # action is None, thing is not None
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() is None
    # Testing for case 2
    # action is None, thing is None
    # action is {'hello': 'world'}, thing is None
    # action is 'a' and, thing is None
    # action is 'a' and {'hello': 'world'}, thing is None
    # Testing for case 3
    # action is {'hello': 'world'}, thing is not None
    # action is 'a' and, thing is not None
    # action is 'a' and {'hello': 'world'}, thing is not None
    # Testing for case 4
    # action is {'hello': 'world'}, thing is {'hello': 'world

# Generated at 2022-06-25 03:50:49.476656
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_cases = []
    test_cases.append((['action', 'echo', 'something'], dict(), dict(), dict(action='echo', args={'something'}), dict(), dict()))
    test_cases.append((['action', 'echo', 'something'], dict(), dict(), dict(action='echo', args={'something'}), dict(), dict()))
    test_cases.append((['action', 'echo', 'something'], dict(), dict(), dict(action='echo', args={'something'}), dict(), dict()))
    test_cases.append((['action', 'echo', 'something'], dict(), dict(), dict(action='echo', args={'something'}), dict(), dict()))

# Generated at 2022-06-25 03:51:01.356122
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # things that should fail:
    # 1. parse with unexpected arg (para_1)
    # 2. parse with unexpected arg (para_2)
    # 3. parse with unexpected arg (para_3)
    # 4. parse with unexpected arg (para_4)
    # 5. parse with unexpected arg (para_5)
    # 6. parse with unexpected arg (para_6)
    # 7. parse with unexpected arg (para_7)

# Generated at 2022-06-25 03:51:10.010689
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    input_0 = {"task_ds": {"action": {"module": "copy", "src": "/home/ansible/test.txt", "dest": "/tmp/test.txt"}}}
    module_args_parser_0 = ModuleArgsParser(task_ds=input_0, collection_list=None)
    result = module_args_parser_0.parse()
    assert result == ('copy', {'src': '/home/ansible/test.txt', 'dest': '/tmp/test.txt'}, None)

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:51:13.579030
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test case 0
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, {}, None)


# Generated at 2022-06-25 03:51:22.313590
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    task_ds = {'action': {'module': 'shell', 'args': 'ls'}}
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    print(action, args, delegate_to)
    assert action == 'shell'
    assert args == {'args': 'ls'}
    assert delegate_to is None

    # Test that we can find the action parser context
    assert module_args_parser.resolved_action == 'ansible.builtin.shell'

    task_ds = {'action': {'shell': 'ls'}}
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    print(action, args, delegate_to)
    assert action == 'shell'
   

# Generated at 2022-06-25 03:51:31.400992
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    logging.basicConfig(stream=sys.stderr)

    # Test 'module' attribute with valid value
    task_ds0 = dict()
    task_ds0['module'] = 'shell'
    task_ds0['args'] = "echo hi"
    task_ds0['delegate_to'] = 'localhost'
    task_ds0['become'] = False
    task_ds0['become_user'] = 'root'
    task_ds0['become_method'] = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds0, collection_list=dict())
    action, args, delegate_to = module_args_parser.parse()
    assert(action == 'shell')
    assert(args['_raw_params'] == "echo hi")

# Generated at 2022-06-25 03:51:43.194040
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import module_loader
    # Test case 1:
    # Test that delegate_to can overwrite the default specified in PlayContext.
    # Test using module 'copy'
    # Test that the following is valid syntax:
    # action: copy dest=foo src=/tmp/foo.txt delegate_to=bar.example.com
    # This is equivalent to
    # action: copy dest=foo src=/tmp/foo.txt delegate_to=bar.example.com

    # Setup
    hostvars = dict()
    hostvars['127.0.0.1'] = dict()

# Generated at 2022-06-25 03:51:57.535986
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print(ModuleArgsParser.parse.__name__)
    test_case_0()

if __name__ == '__main__':
  test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:51:59.928349
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Testing on method parse with parameter skip_action_validation set to False
    assert module_args_parser_0.parse() == (None, {}, Sentinel)


# Generated at 2022-06-25 03:52:10.579161
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with a dictionary type of thing

    assert ModuleArgsParser().parse({'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}) == ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert ModuleArgsParser().parse({'local_action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}) == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
    assert ModuleArgsParser().parse({'module': 'copy', 'src': 'a', 'dest': 'b'}) == ('copy', {'src': 'a', 'dest': 'b'}, None)

# Generated at 2022-06-25 03:52:12.433511
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    res = m.parse()
    assert(res == (None, {}, None))

# Generated at 2022-06-25 03:52:22.440325
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_parse_0 = ModuleArgsParser()
    # Things used to parse(self) method
    # Global Variables
    task_ds = dict()
    collection_list = dict()
    task_ds['action'] = dict()
    task_ds['action']['_raw_params'] = "echo hello"
    module_args_parser_parse_0.parse(skip_action_validation=False)

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:31.037913
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test that a module is detected if the key isn't in the task attributes list
    task_ds_0 = {
        'async': 1,
        'changed_when': 'changed',
        'connection': 'local',
        'fetch': 'yes',
        'first_available_file': '/some/file',
        'free_form': 'some string',
        'ignore_files': 'shell: true',
        'ignore_errors': 'yes',
        'loop_control': {
            'loop': 'inventory_hostname or groups',
        },
        'name': 'some_task'
    }


# Generated at 2022-06-25 03:52:37.735558
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Arrange
    module_args_parser_0 = ModuleArgsParser()
    # This case is passed in __init__ of ModuleArgsParser
    # assert "Key error: 'action' when parsing a task" in str(excinfo.value)

    # Act
    # test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    test_case_8()

    # Assert
    assert True

if __name__ == '__main__':

    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:44.887254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    testcase1_args={}
    testcase1_args['action']={}
    testcase1_args['action']={'command': 'pwd', 'args': {'chdir': '/tmp'}}

    parser_obj=ModuleArgsParser(testcase1_args)
    assert parser_obj.parse() == ('command', {'chdir': '/tmp'}, Sentinel)

    testcase2_args={}
    testcase2_args['action']={}
    testcase2_args['action']={'command': 'pwd', 'args': {'chdir': '/tmp', '_raw_params': 'ls', '_uses_shell': True}}

    parser_obj=ModuleArgsParser(testcase2_args)

# Generated at 2022-06-25 03:52:53.289513
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # test data format:
    #     task:
    #     -  module: "test.test"
    #        args:
    #          _raw_params: "echo '{{ path }}'"
    #          _uses_shell: true
    #     play:
    #     -  tasks:
    #        -  action: shell
    #             args:
    #               _raw_params: "echo '{{ path }}'"
    #               _uses_shell: true
    #               chdir: "/tmp"
    #     outcome:
    #     -  args:
    #             _variable_params: "echo '{{ path }}'"
    #          delegate_to: 'localhost'
    #          module: shell

# Generated at 2022-06-25 03:52:56.520117
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    try:
        task_ds = {}
        module_args_parser_0 = ModuleArgsParser(task_ds=task_ds)
        module_args_parser_0.parse()
    except Exception as e:
        print("Exception in test_case_0 exception: %s" % str(e))



# Generated at 2022-06-25 03:53:28.065250
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext

    module_args_parser = ModuleArgsParser()
    task_vars = {}
    play_context = PlayContext()
    result = module_args_parser.parse()
    assert result[0] == None
    assert result[1] == {}
    assert result[2] == None

    # test: {'action': 'shell echo hi'}
    task_ds = {'action': 'shell echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    task_vars = {}
    play_context = PlayContext()
    result = module_args_parser.parse()
    assert result[0] == 'shell'
    assert result[1] == {"_raw_params": "echo hi"}
    assert result[2] == None

    #

# Generated at 2022-06-25 03:53:35.413035
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    ds_1 = dict({'name': 'ansible', 'action': 'command echo hi'})
    assert(module_args_parser_0.parse(ds_1) == (None, {}, None))

    ds_2 = dict({'name': 'ansible', 'action': dict({'module': 'command echo hi'})})
    assert(module_args_parser_0.parse(ds_2) == (None, {}, None))

    ds_3 = dict({'name': 'ansible', 'action': dict({'module': 'command echo hi', 'chdir': '/tmp'})})
    assert(module_args_parser_0.parse(ds_3) == (None, {}, None))


# Generated at 2022-06-25 03:53:47.715839
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test case 1
    # test module_args_parser_1.parse() with
    # task_ds = {'action': 'shell echo hi'}

    # expected result
    expected_action_1 = 'shell'
    expected_args_1 = {'_raw_params': "echo hi"}
    expected_delegate_to_1 = None

    module_args_parser_1 = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    result_1 = module_args_parser_1.parse()
    action_1 = result_1[0]
    args_1 = result_1[1]
    delegate_to_1 = result_1[2]
    assert action_1 == expected_action_1
    assert args_1 == expected_args_1
    assert delegate_to_1 == expected

# Generated at 2022-06-25 03:53:58.511392
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    sample_task_ds = {
        'action': 'copy',
        'src': '/tmp/file1',
        'dest': '/tmp/file2'
    }
    module_args_parser_0 = ModuleArgsParser(sample_task_ds)
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == 'copy'
    assert args == {'src': '/tmp/file1', 'dest': '/tmp/file2'}
    assert delegate_to is None
    module_args_parser_0 = ModuleArgsParser({'action': 'shell', 'args': 'echo hello'})
    action, args, delegate_to = module_args_parser_0.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hello'}
    assert delegate

# Generated at 2022-06-25 03:54:08.031574
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    # test case 1
    task_ds_1a = {'action': 'shell echo hi'}
    action_1a, args_1a, delegate_to_1a = module_args_parser_1.parse(task_ds_1a)
    assert(action_1a == 'shell')
    assert(dict(args_1a) == dict({'_raw_params': 'echo hi', '_uses_shell': True}))
    assert(delegate_to_1a is None)
    # test case 2
    task_ds_1b = {'action': {'shell': 'echo hi'}}
    action_1b, args_1b, delegate_to_1b = module_args_parser_1.parse(task_ds_1b)
   

# Generated at 2022-06-25 03:54:16.424908
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:54:26.399124
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    test_hash_1 = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    module_args_parser_1._task_ds = test_hash_1
    module_args_parser_1.parse()

    test_hash_2 = {'module': 'copy', 'src': 'a', 'dest': 'b'}
    module_args_parser_1._task_ds = test_hash_2
    module_args_parser_1.parse()

    test_hash_3 = {'action': 'copy', 'src': 'a', 'dest': 'b'}
    module_args_parser_1._task_ds = test_hash_3
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:54:32.138443
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_args = [
        ("""
        - action: command echo hi
        """,
        'command', {'_raw_params': 'echo hi'})
    ]

    module_args_parser = ModuleArgsParser()
    for test_arg in test_args:
        action, args, delegate_to = module_args_parser.parse(test_arg[0])
        assert action == test_arg[1]
        assert args == test_arg[2]


# Generated at 2022-06-25 03:54:40.571024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    data = dict(action=dict(module='copy', dest='/tmp', src='test/test_module.py'))
    action, args, delegate_to = module_args_parser.parse(data)
    assert action == "copy"
    assert args == dict(dest='/tmp', src='test/test_module.py')
    assert delegate_to == None


# Generated at 2022-06-25 03:54:44.764058
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {}
    collection_list_1 = None
    module_args_parser_1.parse(skip_action_validation=False)


# Generated at 2022-06-25 03:55:04.545276
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    inp = """
    - name: this is my task
      ping:
      become: yes
    """
    task_ds = yaml.safe_load(inp)[0]
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    assert action == 'ping'
    assert args == dict()
    assert delegate_to is None


# Generated at 2022-06-25 03:55:09.791032
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(None, None)
    result = module_args_parser_0.parse(False)
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert result == (None, {}, None)


# Generated at 2022-06-25 03:55:17.008071
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = "command='pwd' args='chdir=/tmp'"
    expected_action, expected_args, _delegate_to = "command", {'args': 'chdir=/tmp'}, None
    task_ds = {'args': {'chdir': '/tmp'}, 'command': "pwd"}

    module_args_parser = ModuleArgsParser(task_ds, ["ansible_collections.ansible.builtin"])

    actual_action, actual_args, actual_delegate_to = module_args_parser.parse()

    assert expected_action == actual_action
    assert expected_args == actual_args
    assert actual_delegate_to is _delegate_to


# Generated at 2022-06-25 03:55:25.985708
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds_0 = {'action': {'src': 'a', 'dest': 'b'}}
    skip_action_validation_0 = None
    action_0, args_0, delegate_to_0 = module_args_parser._normalize_parameters(task_ds_0, False)
    print(action_0, args_0, delegate_to_0)
    action_1, args_1, delegate_to_1 = module_args_parser.parse()
    action_2, args_2, delegate_to_2 = module_args_parser._normalize_old_style_args(task_ds_0)
    # assert method parse of class ModuleArgsParser
    assert action_0 == action_1 == action_2
    assert args_0 == args_1

# Generated at 2022-06-25 03:55:37.443749
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = dict()
    task_ds_0["action"] = "copy"
    task_ds_0["args"] = dict()
    task_ds_0["args"]["src"] = "a"
    task_ds_0["args"]["dest"] = "b"
    # Test for at least one action parameter
    if module_args_parser_0.parse()[0] is None:
        raise AssertionError()
    # Test for at least one args parameter
    if module_args_parser_0.parse()[1] is None:
        raise AssertionError()
    # Test for at least one delegate_to parameter
    if module_args_parser_0.parse()[2] is None:
        raise AssertionError()

# Generated at 2022-06-25 03:55:45.448395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_test_case_0 = ModuleArgsParser()
    print("\nTEST 0: Expected output is (u'include', {'tasks': u'../tasks/main.yml'}, None)\n")
    print(module_args_parser_test_case_0.parse({'include': {'tasks': '../tasks/main.yml'}}))

test_case_0()
test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:55:54.377897
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # test set 1
    # local_action is specified in the task ds with a valid module name
    task_ds = {'local_action': 'shell echo hi'}
    action, args, delegate_to = module_args_parser.parse(task_ds=task_ds)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'

    # test set 2
    # local_action is specified in the task ds with valid module name and args
    task_ds = {'local_action': 'ec2 region=xyz'}
    action, args, delegate_to = module_args_parser.parse(task_ds=task_ds)
    assert action == 'ec2'
    assert args

# Generated at 2022-06-25 03:56:00.171480
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds={'name': 'test', 'action': {'module': 'ping'}})
    (action, args, delegate_to) = obj.parse()
    assert action == 'ping'
    assert args == {}
    assert delegate_to is None

    obj = ModuleArgsParser(task_ds={'name': 'test', 'action': {'ping': 'data'}})
    (action, args, delegate_to) = obj.parse()
    assert action == 'ping'
    assert args == {'ping': 'data'}
    assert delegate_to is None

    obj = ModuleArgsParser(task_ds={'name': 'test', 'action': 'ping'})
    (action, args, delegate_to) = obj.parse()
    assert action == 'ping'
    assert args == {}
   

# Generated at 2022-06-25 03:56:11.404785
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing with args as: {'action': 'copy', 'delegate_to': 'localhost', 'args': 'src=a', 'dest': 'b'}

    module_args_parser_0 = ModuleArgsParser()
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse(skip_action_validation=False)
    assert action_0 == 'copy'
    assert args_0 == {'dest': 'b', 'src': 'a'}
    assert delegate_to_0 == {'action': 'copy', 'delegate_to': 'localhost', 'args': 'src=a', 'dest': 'b'}


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:56:14.342283
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert (module_args_parser.parse()) is None

# Generated at 2022-06-25 03:56:57.252853
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Default test case
    module_args_parser_0 = ModuleArgsParser()
    try:
        module_args_parser_0.parse()
    except Exception:
        assert False, repr(Exception)


# Generated at 2022-06-25 03:57:04.478526
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_parse = ModuleArgsParser()
    assert module_args_parser_parse.parse({}) == (None, {}, None)
    assert module_args_parser_parse.parse({'module': 'shell'}) == (None, {}, None)
    assert module_args_parser_parse.parse({'action': {'module': 'shell'}}) == (None, {}, None)
    assert module_args_parser_parse.parse({'action': {'module': 'shell', 'args': 'echo hi'}}) == (None, {}, None)
    assert module_args_parser_parse.parse({'action': 'shell'}) == (None, {}, None)
    assert module_args_parser_parse.parse({'action': 'copy src=a dest=b'}) == (None, {}, None)


# Generated at 2022-06-25 03:57:09.317141
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()

    # module_args_parser.parse
    assert False, "test of ModuleArgsParser.parse not implemented"

# unit tests for module_args()
# Tests for module arguments parsing, can be run standalone with
#   python test/units/lib/ansible/modules/parser.py
import ansible.module_utils.six as six


# Generated at 2022-06-25 03:57:21.264640
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action = 'raw'
    delegate_to = None
    args = {'_raw_params': 'mkdir /tmp/myfiles', '_uses_shell': False}
    # Testing this case:
    # - module: 'raw'
    #   args: 'mkdir /tmp/myfiles'
    task_ds = {'module': action, 'args': args['_raw_params']}
    (action, args, delegate_to) = module_args_parser.parse(task_ds)
    assert action == action
    assert args == args
    assert delegate_to == delegate_to
    # Testing this case:
    # - module: 'raw'
    #   args:
    #     _raw_params: 'mkdir /tmp/myfiles'
    #     _uses

# Generated at 2022-06-25 03:57:29.180840
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parsed_action, parsed_args, parsed_delegate_to = ModuleArgsParser(task_ds={
        'action': {'module': 'wait_for', 'host': '192.168.0.1', 'port': 80},
    }).parse()
    assert parsed_action == 'wait_for'
    assert parsed_args == {'host': '192.168.0.1', 'port': 80}
    assert parsed_delegate_to is None
    parsed_action, parsed_args, parsed_delegate_to = ModuleArgsParser(task_ds={
        'action': 'wait_for host=192.168.0.1 port=80',
    }).parse()
    assert parsed_action == 'wait_for'
    assert parsed_args == {'host': '192.168.0.1', 'port': 80}

# Generated at 2022-06-25 03:57:37.742222
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    # Function parse has too many arguments (expected 0; got 1)
    #module_args_parser_1.parse()
    module_args_0 = { 'module': 'copy', 'src': 'a', 'dest': 'b' }
    skip_action_validation = False
    (action_0, args_0, delegate_to_0) = module_args_parser_1.parse(module_args_0, skip_action_validation)
    print(action_0)
    print(args_0)
    print(delegate_to_0)


# Generated at 2022-06-25 03:57:45.220825
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up mock arguments and context objects
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # Set up expected results
    expected_results = ()
    # Perform the test
    result = module_args_parser.parse()
    # Verify the results
    assert result == expected_results



# Generated at 2022-06-25 03:57:50.866370
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    skip_action_validation = True
    (action, args, delegate_to) = module_args_parser_0.parse(skip_action_validation=skip_action_validation)
    if action == 'echo':
        if args == {'_raw_params': 'hello world'}:
            rc = True
        else:
            rc = False
    else:
        rc = False
    if (rc and (delegate_to is None)):
        rc = True
    else:
        rc = False
    assert rc, 'ModuleArgsParser.parse failed'


# Generated at 2022-06-25 03:57:59.030254
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser(task_ds='{{test_var}}', collection_list=None)
    action, args, delegate_to = module_args_parser_1.parse(skip_action_validation=False)
    assert to_text(module_args_parser_1._task_ds) == '{{test_var}}'
    assert module_args_parser_1._collection_list == None
    action, args, delegate_to = module_args_parser_1.parse(skip_action_validation=True)
    assert action is None
    assert args == {'test_var': None}
    assert delegate_to is None


# Generated at 2022-06-25 03:58:05.442233
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    result = module_args_parser_0.parse()
    assert(result is not None)
    assert(len(result) == 3)
    assert(isinstance(result[0], str))
    assert(isinstance(result[1], dict))
    assert(result[2] is None)
    