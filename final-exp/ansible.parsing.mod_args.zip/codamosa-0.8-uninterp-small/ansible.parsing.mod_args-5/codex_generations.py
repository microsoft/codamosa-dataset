

# Generated at 2022-06-25 03:48:42.610001
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    task_dict = {'action': 'copy', 'copy': {'src': 'http://foo.org/file.tar.gz', 'dest': '/home/foo/file.tar.gz'}}

    module_args_parser = ModuleArgsParser(task_dict, collection_list=AnsibleCollectionLoader())

    (action, args, delegate_to) = module_args_parser.parse(skip_action_validation=True)
    assert action == 'copy'
    assert args['src'] == 'http://foo.org/file.tar.gz'
    assert args['dest'] == '/home/foo/file.tar.gz'
    assert delegate_to is None


# Generated at 2022-06-25 03:48:52.178980
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(
        action = 'ping',
        args = dict(
            free_form = True,
            data = 'pong'
        ),
    )
    result = ModuleArgsParser(task).parse()
    assert result == ('ping', dict(free_form=True, data='pong'), None)


task_0 = dict(
    action = dict(
        module = 'copy',
        src = 'a',
        dest = 'b',
    ),
)

task_1 = dict(
    action = 'copy dest=b src=a',
)

task_2 = dict(
    action = 'copy src=a dest=b',
    delegate_to = 'localhost',
)

task_3 = dict(
    local_action = 'copy src=a dest=b',
)

task_

# Generated at 2022-06-25 03:49:02.473930
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    test_ModuleArgsParser_parse
    """
    action_0 = 'include_tasks'
    args_0 = {'name': 'test_task.yml'}
    delegate_to_0 = None
    module_args_parser_0 = ModuleArgsParser()
    args_1, args_2, args_3 = module_args_parser_0.parse()
    assert args_1 ==  action_0
    assert args_2 ==  args_0
    assert args_3 ==  delegate_to_0


# Generated at 2022-06-25 03:49:08.210927
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    classify module invocations by the parameters they accept
    '''

    # (module, arg_type)
    arg_types_by_module = dict()

    for action in action_loader.all():
        # ensure we can load each module and get their parameters
        args = action_loader.get(action, class_only=True)._load_params(manager=None)

        # make sure we got results back
        if args is None:
            raise AnsibleError("module %s failed to load args" % action)

        # sort args into types to get a count for each type
        arg_types = dict()
        for arg in args:
            arg_type = 'plain'

# Generated at 2022-06-25 03:49:16.704622
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # set actions to valid values to clear error conditions
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser_0.parse(skip_action_validation=False)
    assert "no module/action detected in task." in str(excinfo.value)

    module_args_parser_1 = ModuleArgsParser(task_ds={"action":"test_action"}, collection_list=[])
    try:
        module_args_parser_1.parse(skip_action_validation=False)
    except:
        assert False
    else:
        assert True

    module_args_parser_2 = ModuleArgsParser(task_ds={'action': 'copy', 'src':'a', 'dest': 'b'}, collection_list=[])


# Generated at 2022-06-25 03:49:23.251638
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Test parse of class ModuleArgsParser
    """
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = dict()
    task_ds_0['action'] = 'ping'
    task_ds_0['async'] = 1000
    task_ds_0['poll'] = 10
    task_ds_0['args'] = '_raw_params='
    module_args_parser_0 = ModuleArgsParser(task_ds=task_ds_0)
    (action_0, args_0, delegate_to_0) = module_args_parser_0.parse()
    assert isinstance(action_0, basestring)
    assert action_0 == 'ping'
    assert args_0 == dict()
    assert delegate_to_0 == None
    task_ds_0 = dict()

# Generated at 2022-06-25 03:49:28.865397
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    skip_action_validation = False
    assert module_args_parser_1.parse(skip_action_validation=skip_action_validation) == (None, None, None)
    task_ds = dict(action={'module': 'copy', 'x': 1})
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser_1.parse(skip_action_validation=skip_action_validation) == (u'copy', {u'x': 1}, None)
    task_ds = dict(action='copy src=a dest=b')
    module_args_parser_1 = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-25 03:49:40.326718
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert_equal(module_args_parser_0.parse(),("","",""))
    assert_true(module_args_parser_0.parse(),("\n","\n","\n"))
    assert_not_equal(module_args_parser_0.parse(),("copy:","",""))
    assert_not_equal(module_args_parser_0.parse(),("","copy:",""))
    assert_not_equal(module_args_parser_0.parse(),("","","copy:"))
    assert_true(module_args_parser_0.parse(),("\n","\n","\n"))
    assert_true(module_args_parser_0.parse(),("\n","\n","\n"))

# Generated at 2022-06-25 03:49:45.505309
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    #
    # AnsibleModule(name, argument_spec, required_together=None, required_one_of=None,
    #               mutually_exclusive=None, required_if=None, required_by=None, bypass_checks=False, no_log=False)
    #

    module_args = dict(
        action=dict(type='str'),
        collection_list=dict(type='list'),
        task_ds=dict(type='dict')
    )

    argument_spec = dict()
    required_one_of = [
        ['action'],
        ['task_ds']
    ]

    module = AnsibleModule(
        argument_spec=argument_spec,
        module_args=module_args,
        required_one_of=required_one_of
    )

    action = module.params['action']


# Generated at 2022-06-25 03:49:55.698619
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:50:09.341926
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    dict_0 = dict()
    dict_0['action'] = 'echo hi'
    dict_1 = {'action': 'echo hi'}
    dict_2 = {}
    dict_2['action'] = 'sysctl name=kernel.shmmax value=1073741824'

    dict_3 = dict()
    dict_3['action'] = 'shell echo hi'

    dict_4 = dict()
    dict_4['action'] = ''

    dict_5 = dict()
    dict_5['action'] = {'module': 'copy', 'src': 'a', 'dest': 'b'}

    dict_6 = dict()
    dict_6['action'] = {'module': 'copy src=a dest=b'}

    dict_7 = dict()

# Generated at 2022-06-25 03:50:18.510244
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    # Execute the code to be tested
    result = module_args_parser.parse()
    assert isinstance(result, tuple)
    assert len(result) == 3
    # Check the results
    assert result[0] == None
    assert result[1] == None
    assert result[2] == None


# Generated at 2022-06-25 03:50:30.144703
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test input
    task_dict_0 = dict(action=dict(module='ec2', region='xyz'))
    task_dict_1 = dict(action='shell echo hi')
    task_dict_2 = dict(action='ec2 x=1 y=2')
    task_dict_3 = dict(action='command pwd', args=dict(chdir='/tmp'))
    task_dict_4 = dict(action='command pwd')

    # expected output
    expected_action_0 = 'ec2'
    expected_args_0 = dict(region='xyz')
    expected_delegate_to_0 = None

    expected_action_1 = 'shell'
    expected_args_1 = dict(_raw_params='echo hi')
    expected_delegate_to_1 = None

    expected_action_

# Generated at 2022-06-25 03:50:42.724966
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Setup test data
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.task_ds = {u'post_validate': {u'pip': u'pip3'}, u'region': u'us-east-1', u'name': u'python', u'with_items': u'{{ python_pkgs }}'}
    module_args_parser_1.collection_list = [u'ansible_collections.amazon.aws.plugins.module_utils.ec2', u'ansible_collections.amazon.aws.plugins.action.ec2']
    expected_result = (u'pip', {u'name': u'python', '_ansible_no_log': False, u'region': u'us-east-1'}, None)

    # Execute

# Generated at 2022-06-25 03:50:48.555357
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    test_task_ds = dict()
    test_task_ds['action'] = dict()
    test_task_ds['action']['module'] = 'shell'
    test_task_ds['action']['args'] = 'echo hi'
    assert module_args_parser_1.parse(test_task_ds) == ('shell', {'_raw_params': 'echo hi'}, None)


# Generated at 2022-06-25 03:51:00.665566
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test cases for class ModuleArgsParser

    # test case for ModuleArgsParser.parse method
    def test_ModuleArgsParser_parse_case_0(self):
        '''
        repeated
        '''

        # However, if we have both of these, then we have a problem
        self._task_ds = dict(
            delegate_to='test_parsed_playbook_tasks_ModuleArgsParser_parse_case_0',
            local_action='test_parsed_playbook_tasks_ModuleArgsParser_parse_case_0',
        )
        self.assertRaises(AnsibleParserError, ModuleArgsParser.parse, self)

        # local_action should imply delegate_to=localhost

# Generated at 2022-06-25 03:51:07.711969
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with and without setting verbosity
    ansiballz_module_utils.HAS_ANSIBLE_TEST_UTILS = False
    task_dict = {
        'action': 'test_module name=foo',
        'name': 'test_play',
        'args': {'x': 1, 'y': 2}
    }
    parser = ModuleArgsParser(task_dict=task_dict)
    action, args, delegate_to = parser.parse(skip_action_validation=True)

    assert(action == 'test_module')
    assert(isinstance(args, dict))
    assert(args == {'name': 'foo', 'x': 1, 'y': 2})
    assert(delegate_to is None)

    ###########################################################################
    # test delegate_to

# Generated at 2022-06-25 03:51:17.199148
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test complex args with string variable
    test_dict = {"args": "{{testvar}}", 'delegate_to': 'localhost'}
    test_result = ModuleArgsParser(test_dict).parse()
    assert test_result == ('', {'_variable_params': '{{testvar}}'}, 'localhost')

    # test complex args with dictionary
    test_dict = {"args": {"test": "{{testvar}}"}, 'delegate_to': 'localhost'}
    test_result = ModuleArgsParser(test_dict).parse()
    assert test_result == ('', {'test': '{{testvar}}'}, 'localhost')


# Generated at 2022-06-25 03:51:18.411098
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()


# Generated at 2022-06-25 03:51:28.181449
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create the object
    module_args_parser = ModuleArgsParser()
    # Parse the arguments for a task
    action, args, delegate_to = module_args_parser.parse({'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    # Check the parsed results
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == Sentinel
    # Parse the arguments for a task with local_action
    action, args, delegate_to = module_args_parser.parse({'local_action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    # Check the parsed results
    assert action == 'copy'

# Generated at 2022-06-25 03:51:53.084864
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test of parse method of class ModuleArgsParser
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None  # if the method parse return None, a problem could have been detected


# Generated at 2022-06-25 03:51:54.711389
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_case_0()

if __name__ == '__main__':
    test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:00.471999
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    es = [{'module': 'ec2', 'region': 'xyz'}, 'ec2 region=xyz', {'module': 'ec2', 'x': 1}]
    for e in es:
        module_args_parser = ModuleArgsParser()
        (action, args, delegate_to) = module_args_parser.parse(skip_action_validation=True)
        assert isinstance(action, six.string_types)
        assert isinstance(args, dict)
        assert isinstance(delegate_to, six.string_types)


# Generated at 2022-06-25 03:52:01.815891
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()


# Generated at 2022-06-25 03:52:12.866806
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    #
    # Instantiate a ModuleArgsParser object, then call its parse method
    # with some valid test data, then validate the results.
    #
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse(YAML_DOCS[0])
    assert action == 'ping'
    assert not args
    assert delegate_to == 'all'
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse(YAML_DOCS[1])
    assert action == 'command'
    assert args == {'chdir': '/tmp'}
    assert delegate_to is None
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser

# Generated at 2022-06-25 03:52:25.132309
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    task_data = {
        'include': {
            'tasks': 'deploy_tasks.yml'
        }
    }
    task_block = [
        Block(
            task_data=task_data,
            role=None,
            loop=None,
            loop_control=None
        )
    ]

    play_context = PlayContext()

    play = Play()
    play.name = 'test_case_0'
    play.context = play_context
    play.task_blocks = task_block

    module_args_parser_0 = ModuleArgsParser()

   

# Generated at 2022-06-25 03:52:30.433629
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()

    # Test without parameter 'skip_action_validation'
    # Call method
    result = module_args_parser_1.parse()

    # Check result
    assert result == (None, dict(), Sentinel)


# Generated at 2022-06-25 03:52:37.966799
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Setup
    module_args_parser_0 = ModuleArgsParser()

    #
    # Test - using no parameters (the standard YAML form for command-type modules).
    #

    # Invoke method
    #
    action_name_0, args_0, delegate_to_0 = module_args_parser_0.parse()

    # Verify results
    assert action_name_0 is None
    assert args_0 is None
    assert delegate_to_0 is None

    #
    # Test - using no parameters (the standard YAML form for command-type modules).
    #

    # Setup
    module_args_parser_1 = ModuleArgsParser()

    # Invoke method
    #
    action_name_1, args_1, delegate_to_1 = module_args_parser_1.parse()

    #

# Generated at 2022-06-25 03:52:42.735702
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True


# Generated at 2022-06-25 03:52:52.481854
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:53:18.021641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # build a test task for ModuleArgsParser
    task_ds = {}

    # call method parse of class ModuleArgsParser
    parse_results = ModuleArgsParser(task_ds=task_ds).parse()

    assert parse_results is not None, 'parse_results is None'
    assert len(parse_results) == 3, '3 elements are not returned'
    assert parse_results[0] is None, 'parse_results[0] is not None'
    assert parse_results[1] == {}, 'parse_results[1] is not {}'
    assert parse_results[2] == 'localhost', 'parse_results[2] is not localhost'


# Generated at 2022-06-25 03:53:29.707904
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser()
    # test_case_0
    mock_task_ds = {}
    module_parser._task_ds = mock_task_ds
    mock_collection_list = None
    module_parser._collection_list = mock_collection_list
    mock_skip_action_validation = False
    assert module_parser.parse() == (None, dict(), None)
    # test_case_1
    mock_task_ds = {'local_action': 'copy src=a dest=b'}
    module_parser._task_ds = mock_task_ds
    mock_collection_list = None
    module_parser._collection_list = mock_collection_list
    mock_skip_action_validation = False

# Generated at 2022-06-25 03:53:34.373641
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, None, None)
    assert module_args_parser_0.parse(False) == (None, None, None)

# Generated at 2022-06-25 03:53:47.108062
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:53:53.487745
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Check the calling of parse with the following input:
    #   skip_action_validation: False
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() == (None, {}, Sentinel)
    module_args_parser_2 = ModuleArgsParser(task_ds={'delegate_to': {'host': 'localhost', 'port': 22}, 'copy': {'src': 'a', 'dest': 'b'}})
    assert module_args_parser_2.parse() == ('copy', {'src': 'a', 'dest': 'b'}, {'host': 'localhost', 'port': 22})
    module_args_parser_3 = ModuleArgsParser(task_ds={'action': {'shell': 'echo hi'}})
    assert module_args_parser_3.parse

# Generated at 2022-06-25 03:53:58.825510
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test no module name
    test_dict0 = dict()
    module_args_parser0 = ModuleArgsParser(test_dict0)
    with pytest.raises(AnsibleParserError):
        module_args_parser0.parse()


# Generated at 2022-06-25 03:54:05.890600
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a dummy task to be parsed
    task_ds = {
        'name': 'test task',
        'action': 'copy src=a dest=b'
    }
    module_args_parser_0 = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser_0.parse(task_ds)
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}



# Generated at 2022-06-25 03:54:15.121652
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test simple case
    task_ds = { "module": "shell", "args": "echo hi" }
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse(task_ds)
    assert(result == ('shell', {}, None))

    # Test multiple correct module definitions
    task_ds = { "module": "shell", "args": "echo hi", "action": "echo hello" }
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse(task_ds)
    assert(result == ('shell', {'_raw_params': 'echo hello'}, None))

    # Test multiple and conflicting module definitions

# Generated at 2022-06-25 03:54:25.179010
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    #---------------------------------------
    # Test 1
    #---------------------------------------
    # Testcase 1
    #
    # Input data:
    #    action: copy src=a dest=b
    #
    # Expected result:
    #    ('copy', { 'src': 'a', 'dest': 'b' })
    #
    task_ds = dict(action='copy src=a dest=b')
    (action, args, delegate_to) = module_args_parser.parse()


# Generated at 2022-06-25 03:54:28.993396
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''module_args_parser_0 : ModuleArgsParser'''
    # perform test
    module_args_parser_0 = ModuleArgsParser()

    # attempt to parse
    action, args, delegate_to = module_args_parser_0.parse()

# Generated at 2022-06-25 03:55:18.029905
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    (action, args, delegate_to) = module_args_parser.parse()
    assert(action == None)
    assert(args == None)
    assert(delegate_to == None)


# Generated at 2022-06-25 03:55:30.198084
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """ModuleArgsParser: parse"""
    module_args_parser_1 = ModuleArgsParser()
    expected_result_1 = ('name', {'user': 'root'}, None)
    task_ds_1 = {'action': {'user': 'root'}}
    assert module_args_parser_1.parse(task_ds_1) == expected_result_1
    module_args_parser_2 = ModuleArgsParser()
    expected_result_2 = ('name', {}, None)
    task_ds_2 = {'action': ''}
    assert module_args_parser_2.parse(task_ds_2) == expected_result_2
    module_args_parser_3 = ModuleArgsParser()
    expected_result_3 = ('name', {'user': 'root'}, 'localhost')
    task_ds_3

# Generated at 2022-06-25 03:55:38.695279
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    act, arg, del_to = module_args_parser_1.parse({"action": {"module": "shell", "args": "echo foo"}})
    assert act == "shell"
    assert arg == {"args": "echo foo"}
    assert del_to == None
    #
    act, arg, del_to = module_args_parser_1.parse({"action": "shell echo foo"})
    assert act == "shell"
    assert arg == {"args": "echo foo"}
    assert del_to == None
    #
    act, arg, del_to = module_args_parser_1.parse({"module": "shell", "args": "echo foo"})
    assert act == "shell"
    assert arg == {"args": "echo foo"}

# Generated at 2022-06-25 03:55:47.116560
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # First case - Result of method parse() when the task is in the new style
    # (module: {...})
    task = dict(action=dict(module='debug', var='hello'))
    module_args_parser_new_style = ModuleArgsParser(task)
    # The result of this method must be a tuple of three elements
    assert isinstance(module_args_parser_new_style.parse(), tuple)
    assert len(module_args_parser_new_style.parse()) == 3

    # Second case - Result of method parse() when the task is in the old style
    # (action: {...})
    task = dict(action=dict(shell='echo hello'))
    module_args_parser_old_style = ModuleArgsParser(task)
    # The result of this method must be a tuple of three elements

# Generated at 2022-06-25 03:55:55.495596
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_0.parse()
    action_1, args_1, delegate_to_1 = module_args_parser_0.parse()



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:56:01.508383
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    print("Testing basic parse()")
    thing = None
    action = None
    delegate_to = module_args_parser_0._task_ds.get('delegate_to', Sentinel)
    args = dict()
    additional_args = module_args_parser_0._task_ds.get('args', dict())
    if 'action' in module_args_parser_0._task_ds:
        thing = module_args_parser_0._task_ds['action']
    elif 'local_action' in module_args_parser_0._task_ds:
        thing = module_args_parser_0._task_ds.get('local_action', '')
        delegate_to = 'localhost'

# Generated at 2022-06-25 03:56:09.874297
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'action': {'module': 'shell', 'args': 'whoami'},
               u'delegate_to': '',
               u'args': {'chdir': '/tmp'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    result = module_args_parser.parse(skip_action_validation=False)
    assert result == ('shell', {'chdir': '/tmp', '_raw_params': 'whoami'}, Sentinel)

# Generated at 2022-06-25 03:56:13.125201
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {}
    action_0, args_0, delegate_0 = module_args_parser_0.parse(skip_action_validation=False)
    assert action_0 is None
    assert args_0 == {}
    assert delegate_0 is None
    assert module_args_parser_0.resolved_action is None


# Generated at 2022-06-25 03:56:19.456552
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = '''{
        "action": "copy src=a dest=b",
        "delegate_to": "localhost",
        "args": {
            "chdir": "/tmp"
        }
    }'''

# Generated at 2022-06-25 03:56:31.145332
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    result = module_args_parser_0.parse()
    assert result[0] == 'copy'
    assert result[1] == {'src': 'a', 'dest': 'b'}
    assert result[2] is None

    module_args_parser_1 = ModuleArgsParser(task_ds={'action': 'copy: src=a dest=b'})
    result = module_args_parser_1.parse()
    assert result[0] == 'copy'
    assert result[1] == {'src': 'a', 'dest': 'b'}
    assert result[2] is None


# Generated at 2022-06-25 03:56:51.180604
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    # test case 0 of parse
    try:
        task_ds_0 = {}
        module_args_parser_0.parse()
        assert not "No exception raised"
    except AnsibleError as e:
        print("Exception raised: %s" % repr(e))


# Generated at 2022-06-25 03:57:02.479332
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    '''
    module_args_parser_2 = ModuleArgsParser()
    module_args_parser_3 = ModuleArgsParser()
    '''
    # parse with correct arguments
    try:
        test_action, test_args, test_delegate = module_args_parser_1.parse()
        assert (True)
    except:
        assert (False)
    # parse with wrong arguments
    try:
        test_action, test_args, test_delegate = module_args_parser_1.parse(skip_action_validation = 'skip_action_validation')
        assert (False)
    except:
        assert (True)

    # parse with missing arguments

# Generated at 2022-06-25 03:57:10.566081
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TestCase 1

    # [arg1, arg2]
    task_ds = {u'action': {u'module': u'ec2', u'key_name': u'xyz', u'instance_type': u'r3.xlarge', u'vpc_subnet_id': u'subnet-xyz', u'private_ip': u'10.0.0.2', u'group_id': [u'xyz'] }, u'name': u'launch instance'}

    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse(task_ds)

    # [arg1, arg2]

# Generated at 2022-06-25 03:57:21.785312
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_cases = [
        {
            'test_case': test_case_0,
            'comment': 'test_case_0',
        },
    ]

    skipped = 0
    failed = 0

    for test_case in test_cases:
        if not test_case.get('comment', None):
            test_case['comment'] = test_case['test_case'].__name__
        if not test_case.get('disabled', False):
            try:
                test_case['test_case']()
            except:
                print("Failed: %s" % test_case['comment'])
                failed += 1
                raise
        else:
            print("Skipped: %s" % test_case['comment'])
            skipped += 1
            continue

    if failed == 0 and skipped == 0:
        print

# Generated at 2022-06-25 03:57:31.307110
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Testing parse of class ModuleArgsParser")
    module_args_parser_parse = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_parse._normalize_parameters({'module': 'shell echo hi'}, 'shell', '')
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == ''
    module_args_parser_parse = ModuleArgsParser()
    action, args, delegate_to = module_args_parser_parse._normalize_parameters({'module': 'shell echo hi'}, 'shell', None)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == ''
    module_args_parser_parse = ModuleArgsParser()
    action,

# Generated at 2022-06-25 03:57:39.534764
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    module_args_parser_0 = ModuleArgsParser()

    # callbacks

    # callbacks | callback

    # delegations

    # delegations | delegation

    # delegation_facts_retriever
    module_args_parser_0.parse()

    # delegations | delegation | delegation_facts_retriever
    module_args_parser_0.parse()

    # delegate_to
    module_args_parser_0.parse()

    # delegations | delegate_to
    module_args_parser_0.parse()

    # delegations | delegation | delegate_to
    module_args_parser_0.parse()

    # force_handlers
    module_args_parser_0.parse()

    # delegations | force_handlers
   

# Generated at 2022-06-25 03:57:43.825295
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser_0 = ModuleArgsParser()
        action, args, delegate_to = module_args_parser_0.parse()
    assert excinfo.value.message == "no module/action detected in task."


# Generated at 2022-06-25 03:57:56.514859
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Initialize class object
    module_args_parser_0 = ModuleArgsParser()
    # Call method
    test_1_ret_value = module_args_parser_0.parse()
    assert module_args_parser_0 is not None
    assert module_args_parser_0 is not False
    assert module_args_parser_0 == 'None'
    assert module_args_parser_0 != 'False'
    assert module_args_parser_0 == '{}'
    assert module_args_parser_0 is not '{}'
    assert module_args_parser_0 != 'module_args_parser_0'
    assert module_args_parser_0 == 'parse'
    assert module_args_parser_0 == '0'
    assert module_args_parser_0 == '1'
    assert module_args_

# Generated at 2022-06-25 03:58:08.530754
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # All input parameters are valid
    module_args_parser = ModuleArgsParser(collection_list=None)
    action, args, delegate_to = module_args_parser.parse()
    assert_equal(action, None)
    assert_equal(args, {})
    assert_false(delegate_to)
    module_args_parser = ModuleArgsParser(collection_list=None, task_ds={'action': 'file_module'})
    action, args, delegate_to = module_args_parser.parse()
    assert_equal(action, 'file_module')
    assert_equal(args, {})
    assert_false(delegate_to)
    module_args_parser = ModuleArgsParser(collection_list=None, task_ds={'local_action': 'win_ping'})
    action, args, delegate_to