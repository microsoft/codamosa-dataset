

# Generated at 2022-06-25 03:48:44.032113
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a2 = ModuleArgsParser()
    d={ 'action': { 'module': 'copy', 'src': 'a', 'dest': 'b' }}
    b2,c2,d2 = a2.parse(d)
    print("b2,c2,d2")
    print(b2,c2,d2)
    assert b2 == 'copy'
    assert c2 == {'src': 'a', 'dest': 'b'}
    assert d2 is None


# Generated at 2022-06-25 03:48:51.789596
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Raw input
    x = dict()

    x["action"] = "ping"
    x["connection"] = "ssh"
    x["delegate_to"] = "sx2"
    x["gather_facts"] = "no"
    x["hosts"] = "sx"
    x["name"] = "test_ModuleArgsParser"
    x["sudo"] = None
    x["sudo_user"] = None
    x["tags"] = ["test"]
    x["tasks"] = [
        {
            "action": "ping"
        }
    ]
    x["register"] = "test_ModuleArgsParser"
    x["vars"] = dict()
    x["when"] = "test"

    # Expected output
    expected_action = "ping"
    expected_args = dict()
    expected_

# Generated at 2022-06-25 03:49:02.433521
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # generate message
    task_ds = {"name": "some_task", "action": {"module": "echo", "args": "some_arg=some_value"}, "delegate_to": "some_target"}

    module_args_parser_1 = ModuleArgsParser(task_ds)
    (action_1, args_1, delegate_to_1) = module_args_parser_1.parse()

    # compare outputs of function parse
    assert (action_1 == 'echo' and args_1 == {'some_arg': 'some_value'} and delegate_to_1 == 'some_target')



# Generated at 2022-06-25 03:49:12.933444
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n=== Test parse() method ===")
    module_args_parser_0 = ModuleArgsParser()

    # Test case 0
    print("\nTest case 0: ")
    print("Test expample 1:" )
    task_ds_0 = {'module': 'xx', 'action': 'yy', 'args': ""}
    ret_0 = module_args_parser_0.parse(task_ds_0)
    print("Returned value: ")
    print(ret_0)
    assert ret_0 == ('yy', {'_raw_params': 'xx'}, None)
    print("Successfully passed!")

    print("\nTest expample 2:" )
    task_ds_1 = "xx yy"
    ret_1 = module_args_parser_0.parse(task_ds_1)

# Generated at 2022-06-25 03:49:23.144718
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    task_ds_0 = {} # DUMMY
    skip_action_validation_0 = False # DUMMY
    ret_0 = module_args_parser_0.parse(task_ds_0, skip_action_validation=skip_action_validation_0)
    assert isinstance(ret_0, tuple) and (len(ret_0) == 3)
    action_0, args_0, delegate_to_0 = ret_0
    assert action_0 is None
    assert args_0 == {}
    assert delegate_to_0 is None

    module_args_parser_1 = ModuleArgsParser()
    task_ds_1 = {} # DUMMY
    task_ds_1['action'] = 'core_module_0' # DUMMY
   

# Generated at 2022-06-25 03:49:27.882870
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Case 0: no args, no local_action
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, dict(), Sentinel)


# Generated at 2022-06-25 03:49:33.667234
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    thing = None
    module_args_parser_1 = ModuleArgsParser()
    try:
        retval = module_args_parser_1.parse(thing)
    except Exception:
        retval = False

    assert retval == True, "Method parse of class ModuleArgsParser returned bad value"


# Generated at 2022-06-25 03:49:42.665166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() == (None, {}, Sentinel)
    module_args_parser_2 = ModuleArgsParser(task_ds={})
    assert module_args_parser_2.parse() == (None, {}, Sentinel)
    module_args_parser_3 = ModuleArgsParser(task_ds={"action":"shell echo hi"})
    assert module_args_parser_3.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)
    module_args_parser_4 = ModuleArgsParser(task_ds={"local_action":"shell echo hi"})
    assert module_args_parser_4.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')
    module_args_parser_

# Generated at 2022-06-25 03:49:43.478160
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 0
    assert test_case_0()

# Generated at 2022-06-25 03:49:54.563264
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    # invalid type for task_ds
    task_ds = []
    with pytest.raises(AnsibleAssertionError):
        module_args_parser.parse(task_ds)

    # form is like: { 'shell' : 'echo hi' }
    task_ds = { 'shell' : 'echo hi' }
    module_args = module_args_parser.parse(task_ds)
    action, args, delegate_to = module_args
    assert module_args == ('shell', {'_raw_params': 'echo hi'}, None)

    # form is like: { 'shell' : {'_raw_params': 'echo hi'} }
    task_ds = { 'shell' : {'_raw_params': 'echo hi'} }
    module_

# Generated at 2022-06-25 03:50:47.764169
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action, args, delegate_to = None, None, None
    #_task_ds = dict()

    # case 0
    _task_ds = {
        "name": "test",
        "action": "copy src=a dest=b"
    }
    action, args, delegate_to = ModuleArgsParser(_task_ds).parse()
    assert action == "copy"
    assert args == {'dest': 'b', 'src': 'a'}
    assert delegate_to is Sentinel



# Generated at 2022-06-25 03:51:00.271078
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    def test_case_0():
        # Input: args=[{'test': 'test_case_0'}]
        # Output: (None, None, None)
        action = 'test'
        args = {'test': 'test_case_0'}
        delegate_to = None
        result = module_args_parser_0.parse(args, action, delegate_to)
        assert type(result) == tuple and len(result) == 3

if __name__ == '__main__':
    # test_case_0()
    test_ModuleArgsParser_parse()
"""

"""
# main.py
#!/usr/bin/env python
# licensed under the Apache 2.0 License
# see LICENSE file in the root of the repo

# This is

# Generated at 2022-06-25 03:51:07.073129
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Make instance of items class
    data = {}
    data['action'] = "copy"
    data['args'] = {'dest': '/tmp/foo', 'src': '/tmp/bar'}
    data['delegate_to'] = "localhost"
    module_args_parser_0 = ModuleArgsParser(data)
    # Populate self.mapping_hash with execute_module
    module_args_parser_0.parse()
    assert module_args_parser_0._task_ds['action'] == "copy"
    assert module_args_parser_0._task_ds['delegate_to'] == "localhost"
    assert module_args_parser_0._task_ds['args'] == {'dest': '/tmp/foo', 'src': '/tmp/bar'}


# Generated at 2022-06-25 03:51:18.274336
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test case to check with no delegate_to and only action specified
    testcase_0 = {'action': 'copy', 'args': 'src=file.txt dest=file2.txt', 'changed': 'yes'}
    module_args_parser_0 = ModuleArgsParser(task_ds=testcase_0)
    action, args, delegate_to = module_args_parser_0.parse(skip_action_validation=True)
    assert action == 'copy'
    assert args == {'dest': 'file2.txt', 'src': 'file.txt'}
    assert delegate_to is Sentinel

    # Test case to check with delegate_to and action as a part of action statement

# Generated at 2022-06-25 03:51:25.392344
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-25 03:51:32.267981
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test input
    task_ds = {'action': '{{inventory_hostname}}'}
    additional_args = '{{inventory_hostname}}'

    # expected output
    exp_action = '{{inventory_hostname}}'

    obj = ModuleArgsParser()
    actual_action = obj.parse(task_ds, additional_args)

    assert actual_action == exp_action

# Generated at 2022-06-25 03:51:37.069850
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    t = parser._task_ds = {}
    t['action'] = 'ls'
    action, args, delegate_to = parser.parse()
    assert action == 'ls'
    assert delegate_to == None


# Generated at 2022-06-25 03:51:46.476936
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a = ModuleArgsParser()
    # Test case 0
    task_ds = {'action': 'debug', 'msg': "{{ ansible_hostname }}"}
    a.parse(task_ds)
    task_ds = {'action': {'debug': "{{ ansible_hostname }}"}}
    a.parse(task_ds)
    task_ds = {'action': {'debug': 'msg="{{ ansible_hostname }}"'}}
    a.parse(task_ds)
    task_ds = {'action': 'debug msg="{{ ansible_hostname }}"'}
    a.parse(task_ds)
    task_ds = {'action': 'debug msg="{{ ansible_hostname }}"', 'verbose': 'yes'}
    a.parse(task_ds)

# Generated at 2022-06-25 03:51:55.950964
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()

    task_ds = dict()
    # action: <module> and module: <module> are both valid and should
    # produce the same result
    task_ds['action'] = 'raw'
    task_ds['module'] = 'command'
    task_ds['args'] = {'_raw_params': 'pwd'}
    skip_action_validation = False
    actual_result = module_args_parser_0.parse(task_ds, skip_action_validation)

    expected_result = 'command', {'_raw_params': 'pwd'}, None
    assert  actual_result == expected_result

    # local_action: <module> is a valid form
    task_ds = dict()
    task_ds['local_action'] = 'raw'


# Generated at 2022-06-25 03:52:00.563498
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    test_case = {"action": "copy", "src": "a", "dest": "b"}
    (action, args, delegate_to) = module_args_parser_1.parse(test_case)
    assert action == "copy"
    assert args == {"src": "a", "dest": "b"}
    assert delegate_to is Sentinel


# Generated at 2022-06-25 03:52:44.382780
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import yaml

    # Read the YAML content
    yaml_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "..", "..", "test", "units", "lib", "ansible", "parsing", "yaml",
                             "task_parser.yaml")
    with open(yaml_path, "r") as yaml_file:
        tests = yaml.safe_load(yaml_file)

    def parse_test_case(test_name, test_case):
        module_args_parser = ModuleArgsParser(test_case, collection_list=test_case.get('collections'))
        action, args, delegate_to = module_args_parser.parse()


# Generated at 2022-06-25 03:52:48.487393
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # initialize
    module_args_parser_0 = ModuleArgsParser()
    # here we will test the "parse" method of ModuleArgsParser class
    # we will test with a dictionary
    task_ds = dict(action="aws_ec2")
    # we will do the parse with the function
    module_args_parser_0.parse(skip_action_validation=True)

# add a test case to the test suite
test_case_0()

# add a test case to the test suite
test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:53.097921
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    module_args_parser_0 = ModuleArgsParser()
    # Test case 0
    action_0, args_0, delegate_to_0 = module_args_parser_0.parse(skip_action_validation=False)

# Unit test main
test_case_0()
test_ModuleArgsParser_parse()

# Generated at 2022-06-25 03:52:54.580434
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("Testing ModuleArgsParser.parse")
    module_args_parser_0 = ModuleArgsParser()
    # TODO: add test cases for test_case_0

    print("Test has completed successfully")


# Generated at 2022-06-25 03:53:04.988253
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser(task_ds = {'action': 'include', 'args': {'task_file': '../../../ansible/test/test.yaml'}})
    module_args_parser_0.parse()

    module_args_parser_1 = ModuleArgsParser(task_ds = {'action': 'include', 'args': {'task_file': '../../../ansible/test/test.yaml'}, 'delegate_to': 'localhost'})
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:53:13.614234
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Test case for unhandled exception
    try:
        module_args_parser_0.parse()
    except Exception as e:
        assert type(e) == SystemExit
    # Test case for unhandled exception
    try:
        module_args_parser_0.parse(skip_action_validation=None)
    except Exception as e:
        assert type(e) == SystemExit
    # Test case for valid test case 0
    test_case_0()

# Test class for ModuleArgsParser

# Generated at 2022-06-25 03:53:15.829376
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1.parse() is None

# Generated at 2022-06-25 03:53:23.487960
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    skip_action_validation = True
    return_value = module_args_parser.parse(skip_action_validation)
    assert return_value == (None, {}, Sentinel)
    skip_action_validation = False
    return_value = module_args_parser.parse(skip_action_validation)
    assert return_value == (None, {}, Sentinel)


# Generated at 2022-06-25 03:53:26.191182
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert(module_args_parser is not None)


# Generated at 2022-06-25 03:53:35.040109
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}})
    expected_action, expected_args, expected_delegate_to = ('copy', {'src': 'a', 'dest': 'b'}, None)
    assert module_args_parser.parse() == (expected_action, expected_args, expected_delegate_to)

    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy', 'src': 'a', 'dest': 'b'})
    expected_action, expected_args, expected_delegate_to = ('copy', {'src': 'a', 'dest': 'b'}, None)

# Generated at 2022-06-25 03:54:29.584448
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    real_output = ModuleArgsParser()
    real_output.parse()
    desired_output = (None, [], None)
    assert real_output == desired_output


# test command line option: --diff

# Generated at 2022-06-25 03:54:31.902432
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Function call is skipped as it is not implemented in the class
    # module_args_parser_0.parse()



# Generated at 2022-06-25 03:54:37.745959
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None, None, None)

# Generated at 2022-06-25 03:54:45.469821
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # setup
    yaml_str = '''
    - name: test
      action: shell echo hi
      delegate_to: localhost
    '''
    task_ds = yaml.safe_load(yaml_str)
    collection_list = None
    module_args_parser_0 = ModuleArgsParser(task_ds, collection_list)
    ansible_module_path = 'ansible_module_path'

    # test
    action, args, delegate_to = module_args_parser_0.parse()

    # assert
    assert action == 'shell'
    assert args['_raw_params'] == "echo hi"
    assert delegate_to == 'localhost'


# Generated at 2022-06-25 03:54:54.730059
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()

    test_dict = {'test': 1}

    with pytest.raises(AnsibleParserError) as exec_info:
        module_args_parser._normalize_new_style_args(test_dict)
    assert 'unexpected parameter type in action' in str(exec_info.value)

    with pytest.raises(AnsibleParserError) as exec_info:
        module_args_parser._normalize_old_style_args(test_dict)
    assert 'unexpected parameter type in action' in str(exec_info.value)

    (test_action, test_args, test_delegate_to) = module_args_parser._normalize_parameters(test_dict)
    assert test_action is None
    assert test_args is None

# Generated at 2022-06-25 03:54:57.879132
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ModuleArgsParser_parse = ModuleArgsParser()
    result = ModuleArgsParser_parse.parse()
    assert result == (None, None, None)


# Generated at 2022-06-25 03:55:04.627010
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test when task_ds is None
    with pytest.raises(AnsibleAssertionError) as excinfo0:
        module_args_parser_1 = ModuleArgsParser()
        module_args_parser_1.parse()
    assert 'the type of \'task_ds\' should be a dict, but is a NoneType' in str(excinfo0.value)

    # Test when task_ds is dict
    with pytest.raises(AnsibleParserError) as excinfo0:
        module_args_parser_1 = ModuleArgsParser({})
        module_args_parser_1.parse()
    assert "no module/action detected in task." in str(excinfo0.value)

    # Test when action and local_action is specified

# Generated at 2022-06-25 03:55:09.497541
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser()
    with pytest.raises(AnsibleParserError):
        module_arg_parser.parse(skip_action_validation=True)


# Unit tests for function split_args

# Generated at 2022-06-25 03:55:11.701278
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    module_args_parser_1.parse()


# Generated at 2022-06-25 03:55:14.329227
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    assert module_args_parser_0.parse() == (None, dict(), None)


# Generated at 2022-06-25 03:56:27.808113
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("==============================")
    print("STARTING - test_ModuleArgsParser_parse")
    print("==============================")
    print("test_ModuleArgsParser_parse: test_case_0")
    test_case_0()
    print("==============================")
    print("COMPLETED - test_ModuleArgsParser_parse")
    print("==============================")
    print("")


# Generated at 2022-06-25 03:56:30.653551
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    module_args_parser_0.parse(skip_action_validation=False)

# Generated at 2022-06-25 03:56:40.335472
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Tests for ModuleArgsParser.parse

    # Task as string
    parse_task_args_string = ModuleArgsParser().parse('shell echo hi')
    assert parse_task_args_string == ('shell', {'_raw_params': 'echo hi'}, None)

    # Task as string with a delegate_to parameter
    parse_task_with_delegate_string = ModuleArgsParser().parse('shell echo hi', delegate_to='localhost')
    assert parse_task_with_delegate_string == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Task as string
    parse_task_args_dict = ModuleArgsParser().parse({'shell': 'echo hi'})
    assert parse_task_args_dict == ('shell', {'_raw_params': 'echo hi'}, None)

    # Task as

# Generated at 2022-06-25 03:56:48.953013
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Set up the context for our test
    # Setup the class instance
    module_args_parser_0 = ModuleArgsParser()

    # Setup the mock InputParameter.
    class MockInputParameter:
        pass

    mock_input_parameter_0 = MockInputParameter()

    # Setup the mock AnsibleError.
    class MockAnsibleError:
        pass

    mock_ansible_error_0 = MockAnsibleError()

    # Setup the fake data.
    fake_task_ds_0 = {'action': {'args': {'delegate_to': 'localhost', 'module': 'shell',
                                          'static': 'test_value_0'}}}

    with pytest.raises(AnsibleError):
        module_args_parser_0.parse()


# Generated at 2022-06-25 03:56:55.981885
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing to see if parse of class ModuleArgsParser returns (action, args, delegate_to)
    # where args is a dictionary of arguments
    module_args_parser_1 = ModuleArgsParser()
    value = module_args_parser_1.parse({"module": "shell", "args": {"_raw_params": "echo hello"}})
    assert value == ("shell", {"_raw_params": "echo hello"}, None)
    value = module_args_parser_1.parse({"module": "shell echo hello"})
    assert value == ("shell", {"_raw_params": "echo hello"}, None)
    value = module_args_parser_1.parse({"module": "shell", "args": "echo hello"})
    assert value == ("shell", {"_raw_params": "echo hello"}, None)
    value = module_args

# Generated at 2022-06-25 03:57:01.489696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_0 = ModuleArgsParser()
    # Call parse of ModuleArgsParser
    result = module_args_parser_0.parse()
    assert result == {}


# Generated at 2022-06-25 03:57:08.308977
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert None == module_args_parser_1.parse(skip_action_validation=False)

    module_args_parser_2 = ModuleArgsParser()
    assert None == module_args_parser_2.parse(skip_action_validation=True)

    module_args_parser_3 = ModuleArgsParser(task_ds={u'delegate_to': None, u'action': u'copy src=a dest=b', u'chdir': u'/tmp'})
    assert (u'copy', {u'dest': u'b', u'src': u'a'}, None) == module_args_parser_3.parse(skip_action_validation=False)


# Generated at 2022-06-25 03:57:15.513838
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_1 = ModuleArgsParser()
    assert module_args_parser_1

    # should accept various forms of dicts
    assert module_args_parser_1.parse('shell echo hi') == ('shell', dict(), None)
    assert module_args_parser_1.parse('shell foo: bar') == ('shell', dict(foo='bar'), None)
    assert module_args_parser_1.parse('shell foo=bar') == ('shell', dict(foo='bar'), None)
    assert module_args_parser_1.parse('shell foo: bar') == ('shell', dict(foo='bar'), None)
    assert module_args_parser_1.parse({}) == (None, dict(), None)

# Generated at 2022-06-25 03:57:25.068365
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("\n### Testing parse")

    action_0 = 'command'
    args_0 = 'test'
    delegate_to_0 = 'localhost'

    # task api:
    # task_module is module name of the action
    # task_action is the name of the action
    # task_args are the arguments of the action
    # task_delegate_to is the delegate_to value
    # task_ds is the contents of the task block

    # task_module, task_action, task_args, task_delegate_to, task_ds
    case0 = (action_0, args_0, delegate_to_0, {'action': 'command', 'args': 'test', 'delegate_to': 'localhost'})

# Generated at 2022-06-25 03:57:34.869461
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a test fixture
    parser = ModuleArgsParser()

    # Run a test
    (action, module_args, delegate_to) = parser.parse()
    assert module_args is not None
    assert action is not None
    assert delegate_to is not None

if __name__ == '__main__':
    test_case_0()
    test_ModuleArgsParser_parse()