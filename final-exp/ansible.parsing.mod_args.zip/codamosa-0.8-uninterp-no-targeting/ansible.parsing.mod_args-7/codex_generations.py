

# Generated at 2022-06-20 23:06:52.551573
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(
            action=dict(module='copy', args='src=a dest=b'),
            local_action='pwd',
            delegate_to='localhost'
            )
    parser = ModuleArgsParser(task_ds=ds, collection_list=None)
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')



# Generated at 2022-06-20 23:07:00.257528
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib

    # Create a Display object in order to call Display.display
    display = Display()

    # Create a VaultSecret object in order to call VaultSecret()
    vault_secret = VaultSecret()

    # Create a VaultLib object in order to call VaultLib()
    vault_lib = VaultLib()

    # Create a PlayContext object in order to call PlayContext()

# Generated at 2022-06-20 23:07:07.357294
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:07:16.394821
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:07:28.601220
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test with a valid "action" task
    task_ds = dict(action=dict(module="test", args="test arg"))
    test_map = ModuleArgsParser(task_ds=task_ds)
    assert test_map.parse() == ("test", dict(args="test arg"), None)
    # Test with a valid "delegate_to" task
    task_ds = dict(delegate_to="test host")

    # Test with an invalid task
    task_ds = dict()

# Generated at 2022-06-20 23:07:29.366220
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: construct object for testing
    pass

# Generated at 2022-06-20 23:07:36.814024
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    test_input = dict()

    test_input['action'] = dict(
        action='copy src=a dest=b'
    )
    test_input['action_item'] = dict(
        action=dict(
            module='copy src=a dest=b'
        )
    )
    test_input['action_args'] = dict(
        action=dict(
            module='copy',
            args='src=a dest=b'
        )
    )
    test_input['action_complex_args'] = dict(
        action=dict(
            module='copy',
            args=dict(
                src='a',
                dest='b'
            )
        )
    )
    test_input['module'] = dict(
        copy='src=a dest=b'
    )

# Generated at 2022-06-20 23:07:49.758221
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # verify ModuleArgsParser is able to deal with string inputs
    task_ds = {
        "action": "shell echo hi",
    }
    map = ModuleArgsParser(task_ds=task_ds)
    assert map.parse()[0] == 'shell'
    assert map.parse()[1] == {'_raw_params': 'echo hi'}
    assert map.parse()[2] is Sentinel

    # verify ModuleArgsParser is able to deal the new style of module invocation
    task_ds = {
        "shell": "echo hi",
    }
    map = ModuleArgsParser(task_ds=task_ds)
    assert map.parse()[0] == 'shell'
    assert map.parse()[1] == {'_raw_params': 'echo hi'}
    assert map.parse()[2] is Sentinel

# Generated at 2022-06-20 23:07:59.905893
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test 1, test old style args
    thing = 'shell echo hi'
    module_args = ModuleArgsParser(thing, collection_list=None)
    assert module_args._task_ds == {'action': 'shell echo hi'}
    assert module_args._collection_list is None
    assert module_args._task_attrs == frozenset(['delegate_to', 'name', 'loop', 'when', 'notify', 'register', 'tags', 'changed_when', 'failed_when', 'until', 'retries', 'delay', 'local_action', 'static', 'connect_timeout', 'remote_user'])

    # Test 2, test new style args
    thing = {'x': 1}
    module_args = ModuleArgsParser(thing, collection_list=None)

# Generated at 2022-06-20 23:08:06.326403
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:08:19.910106
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # We need to set task_ds and collection_list, but not defined here
    # so, they are defined in the next test
    parser = ModuleArgsParser()
    assert parser



# Generated at 2022-06-20 23:08:32.652151
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for the `TaskParser.parse` method
    '''
    module_arg_parser = TaskParser()

    def test_parse(task, expected_action, expected_args, expected_delegate_to):
        action, args, delegate_to = module_arg_parser.parse(task_ds=task)
        assert action == expected_action
        assert args == expected_args
        assert delegate_to == expected_delegate_to

    # Test for action != None and args != None
    task = {'action': 'shell echo hi'}
    expected_action = 'shell'
    expected_args = {'_raw_params': 'echo hi'}
    expected_delegate_to = None
    test_parse(task, expected_action, expected_args, expected_delegate_to)

    # Test for

# Generated at 2022-06-20 23:08:42.292745
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(task_ds={})
    assert 13 == len(m.parse())
    m = ModuleArgsParser(task_ds={'args': {}, u'_ansible_no_log': False, u'_ansible_verbosity': 0, u'_uses_shell': False, u'module_setup': True, u'_ansible_selinux_special_fs': [u'fuse', u'nfs', u'vboxsf', u'ramfs', u'9p', u'vfat'], u'_ansible_diff': False, u'_ansible_module_name': u'machine', u'_ansible_module_set': True})
    assert 14 == len(m.parse())

# Generated at 2022-06-20 23:08:54.353268
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test with an empty task dictionary
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, None, None)

    # Test with no module, just a dict of non-task attributes
    task_ds = {'name': 'Example'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, None, None)

    # Test with a module and no args
    task_ds = {'name': 'Example', 'command': 'ls'}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('command', {}, None)

    # Test with module and args in a string
    task_ds = {'name': 'Example', 'command': 'ls /tmp'}

# Generated at 2022-06-20 23:09:05.991506
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_loader.add_directory(path('lib/ansible/plugins/actions'))
    module_loader.add_directory(path('lib/ansible/modules'))
    module_loader.add_directory(path('lib/ansible/plugins/modules'))
    yaml_parser = YAMLWithError()
    task_ds = yaml_parser.load(dedent(u'''
        - name: "show the passphrase of the vault"
          debug:
            msg: '{{ lookup("password", vault_passphrase_file) }}'
    '''))[0]
    # get action, args, delegate_to from task_ds
    parser = ModuleArgsParser(task_ds=task_ds)
    parser.parse()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-20 23:09:16.984584
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser()
    assert m is not None

# Generated at 2022-06-20 23:09:28.042330
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    import ansible.playbook.task
    import ansible.playbook.handler

# Generated at 2022-06-20 23:09:40.729391
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    module_args_parser = ModuleArgsParser()

    # test passing an incorrect param type for task_ds
    with pytest.raises(AnsibleAssertionError) as excinfo:
        module_args_parser.parse(task_ds=1)
    result = excinfo.value.message
    assert result == "the type of 'task_ds' should be a dict, but is a <class 'int'>"

    # test with a valid task_ds, but where wrong params are passed
    with pytest.raises(AnsibleError) as excinfo:
        module_args_parser.parse(task_ds={'local_action': 'debug', 'delegate_to': 'local'})
    result = excinfo.value.message

# Generated at 2022-06-20 23:09:52.279994
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action_loader = ActionModuleLoader()
    module_loader = ModuleLoader(None, None)
    # Expected values
    expected_action = 'copy'
    expected_args = {'src': 'a', 'dest': 'b'}
    expected_delegate_to = 'localhost'

    # Instantiate the parser
    parser = ModuleArgsParser(action_loader=action_loader,
                              module_loader=module_loader)
    
    # Pre-define the task data structure    
    # TASK_DS = { 'module': 'copy src=a dest=b' }
    # Parse
    (action, args, delegate_to) = parser.parse(TASK_DS)
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to
    
   

# Generated at 2022-06-20 23:10:04.613625
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'local_action': {'module': 'shell', 'args': {'_uses_shell': False, 'chdir': '/', '_raw_params': 'ls'}}, 'delegate_to': 'localhost'}
    task_ds_copy = task_ds.copy()
    args = {'_raw_params': 'ls'}
    templar = Templar(loader=None)
    key, value = list(task_ds.items())[0]
    non_task_ds = dict((k, v) for k, v in iteritems(task_ds) if (k not in self._task_attrs) and (not k.startswith('with_')))
    for item, value in iteritems(non_task_ds):
        context = None
        is_action_candidate = False
       

# Generated at 2022-06-20 23:10:20.387226
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = None
    try:
        parser = ModuleArgsParser()
    except:
        assert False, 'Failed to instantiate the ModuleArgsParser.'

    assert isinstance(parser, ModuleArgsParser), 'parser is not an instance of ModuleArgsParser.'


# Unit tests for _split_module_string

# Generated at 2022-06-20 23:10:30.769588
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    ensures the ModuleArgsParser can parse module arguments.
    '''

    #given
    task_ds = dict(
        local_action='command echo -a',
        args=dict(chdir='/tmp', warn=False)
    )
    module_args_parser = ModuleArgsParser(task_ds)

    #when
    action, args, delegate_to = module_args_parser.parse()

    #then
    assert action == 'command'
    assert args == dict (_raw_params='echo -a', chdir='/tmp', warn=False)
    assert delegate_to == 'localhost'



# Generated at 2022-06-20 23:10:40.215191
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"name": "test", 
                "action": "sftp", 
                "args": {
                    "flatten_burst": True,
                    "rxdir": "/home/ansible/x",
                    "rmode": "-rw-r--r--",
                    "src": "/home/ansible/y",
                    "owner": "ansible",
                    "group": "admin"
                }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse(skip_action_validation=True)
    assert isinstance(args, dict)
    assert isinstance(delegate_to, Sentinel)

# --------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-20 23:10:52.063575
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(action='shell', _raw_params='echo "hello world"', delegate_to='localhost')
    args = data.pop('_raw_params')
    # Test action, args and delegate_to
    p = ModuleArgsParser(data)
    action, args, delegate_to = p.parse()
    assert action == "shell"
    assert args.get('_raw_params') == 'echo "hello world"'
    assert delegate_to == 'localhost'
    # Test action and args
    action, args, delegate_to = p.parse(skip_action_validation=True)
    assert action == "shell"
    assert args.get('_raw_params') == 'echo "hello world"'
    assert delegate_to is None
    # Test action, delegate_to and _raw_params

# Generated at 2022-06-20 23:11:03.589730
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': {'module': 'shell', 'echo': 'hi', 'do': 'this'}}


    obj = ModuleArgsParser(_task_ds)
    action, args, delegate_to = obj.parse()
    assert action == 'copy'
    assert args == {u'dest': 'b', u'src': 'a'}
    assert delegate_to == {'module': 'shell', 'echo': 'hi', 'do': 'this'}

    _task_ds = {'action': 'shell echo hi', 'delegate_to': {'module': 'shell', 'echo': 'hi', 'do': 'this'}}


    obj = ModuleArgsParser(_task_ds)
    action, args

# Generated at 2022-06-20 23:11:15.982005
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # NOTE: This is not a complete test, it just tests the function signature
    #  and some basic functionality

    # some of the tests below assume a collection is present
    collection_dir = os.path.join(os.path.expanduser('~'), '.ansible', 'collections')
    if not os.path.exists(collection_dir):
        os.makedirs(collection_dir)

    # common shorthand for local actions vs delegate_to
    module_args = 'shell echo hi'
    action = 'shell'
    result = ModuleArgsParser()._split_module_string(module_args)
    assert result[0] == action
    assert result[1] == 'echo hi'
    assert isinstance(result, tuple)
    assert len

# Generated at 2022-06-20 23:11:24.726457
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    first_task_ds = {'action': '{{pwd}}', 'delegate_to': 'localhost'}
    second_task_ds = {'action': '{{pwd}}', 'delegate_to': 'localhost'}
    # We want to use ModuleArgsParser.parse(task_ds=task_ds, collection_list=collection_list)
    # for this we need to instantiate ModuleArgsParser and then call parse method
    # 1. create ModuleArgsParser instance
    module_args_parser = ModuleArgsParser(task_ds=first_task_ds)
    # we need to call method parse of class ModuleArgsParser
    # 2. call parse method on instance of ModuleArgsParser
    # return_value_of_parse_method = module_args_

# Generated at 2022-06-20 23:11:38.760753
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test wrong type of task_ds
    try:
        ds = ModuleArgsParser(task_ds=123)
    except AnsibleAssertionError as e:
        assert 'dict' in to_text(e)
    else:
        assert False, 'Failed to catch wrong type of task_ds'

    # test _split_module_string
    ds = ModuleArgsParser(task_ds="")
    result = ds._split_module_string("shell echo hi")
    assert len(result) == 2
    assert result[0] == 'shell'
    assert result[1] == 'echo hi'

    # test _normalize_parameters
    result = ds._normalize_parameters(thing={'region': 'xyz'}, action='ec2')
    assert result[0] == 'ec2'
   

# Generated at 2022-06-20 23:11:49.894127
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-20 23:11:56.739803
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'something', 'delegate_to': '127.0.0.1'}
    map = ModuleArgsParser(task_ds)
    assert map._task_ds == task_ds
    assert map._task_attrs == frozenset(['action', 'local_action', 'static', 'delegate_to'])
    assert map._task_ds['action'] == 'something'
    assert map.resolved_action is None


# Generated at 2022-06-20 23:12:25.930425
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import collections
    import ansible.module_utils.six
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.splitter import parse_kv
    from ansible.module_utils._text import to_text

    parser = ModuleArgsParser(task_ds={'action': {'module':'shell echo hi'}})
    result = parser.parse()
    assert result == ('shell', {'_raw_params': u'echo hi', '_uses_shell': True}, None)

    parser = ModuleArgsParser(task_ds={'action': {'module':'ec2', 'x':1}})
    result = parser.parse()
    assert result == ('ec2', {'x': 1}, None)


# Generated at 2022-06-20 23:12:35.977693
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(action='copy', src='a', dest='b')
    parser = TaskModuleArgsParser(data)
    assert parser is not None
    assert parser._task_ds == data
    assert parser._task_attrs == set(['action', 'local_action', 'static'])

    with pytest.raises(AnsibleAssertionError) as exc:
        parser = TaskModuleArgsParser()
        assert parser is not None
        assert parser._task_ds is None
        assert parser._task_attrs is None
    assert str(exc.value) == "the type of 'task_ds' should be a dict, but is a NoneType"



# Generated at 2022-06-20 23:12:39.132352
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action=dict(module='setup', filters='ansible_distribution'))
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()



# Generated at 2022-06-20 23:12:45.706126
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    expected_action = 'do_ping'
    expected_args = {'_raw_params': '', '_uses_shell': True}
    expected_delegate_to = 'localhost'

    module_args_parser = ModuleArgsParser()
    action, args, delegate_to = module_args_parser.parse(
        {'action': {'module': 'ping'}, 'local_action': 'assert msg="foo"'})
    assert action == expected_action and args == expected_args and \
        delegate_to == expected_delegate_to

    expected_action = 'assert'
    expected_args = {'_raw_params': '', 'msg': 'foo'}
    expected_delegate_to = 'localhost'


# Generated at 2022-06-20 23:12:57.785979
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # From an action plugin
    module = ModuleArgsParser({'action': 'ping'}, collection_list=None).parse()
    assert (module[0], module[1]) == ('ping', {})

    # From an old style module args
    module = ModuleArgsParser({'action': {'module': 'shell', 'args': 'echo hello'}}, collection_list=None).parse()
    assert (module[0], module[1]) == ('shell', {'_raw_params': 'echo hello'})

    # From a new style module args
    module = ModuleArgsParser({'shell': 'echo hello'}, collection_list=None).parse()
    assert (module[0], module[1]) == ('shell', {'_raw_params': 'echo hello'})

    # From a new style module args, with a delegate_to clause
    module

# Generated at 2022-06-20 23:13:02.618215
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    myargs = {'action': 'shell', 'args': 'ls -l'}
    mytask = ModuleArgsParser(task_ds=myargs)
    action, arguments, delegate_to = mytask.parse()
    assert action == 'shell'
    assert arguments['_raw_params'] == 'ls -l'
    assert delegate_to is None

# Generated at 2022-06-20 23:13:10.954324
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # validate construction with 'task_ds'
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser._collection_list == None
    assert parser._task_attrs == frozenset(['local_action', 'static'])
    assert parser.resolved_action == None

    # validate construction with 'task_ds' and 'collection_list'
    task_ds = dict()
    collection_list = ['test_collection_list']
    parser = ModuleArgsParser(task_ds, collection_list)
    assert parser._task_ds == task_ds
    assert parser._collection_list == collection_list
    assert parser._task_attrs == frozenset(['local_action', 'static'])
    assert parser.resolved_action == None


# Generated at 2022-06-20 23:13:22.179677
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test_ModuleArgsParser_parse runs the parse method of ModuleArgsParser
    #   against several test cases and returns a report of the test run.

    print("\nTest ModuleArgsParser._parse()")
    print("==============================")

    # Initialize a ModuleArgsParser object
    test_task_ds = {}
    test_collection_list = None
    test_ModuleArgsParser_object = ModuleArgsParser(test_task_ds, test_collection_list)

    # Initialize a list o test cases

# Generated at 2022-06-20 23:13:28.897893
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = { 'action' : 'shell echo hi', 'delegate_to': 'localhost' }
    parser = ModuleArgsParser(task_ds=fake_task_ds)
    assert parser.parse() == (u'shell', {u'_raw_params': u'echo hi', '_uses_shell': True}, u'localhost')



# Generated at 2022-06-20 23:13:38.225459
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'shell echo hi',
        'args': "echo {{hello}}",
        'local_action': {'module': 'ec2', 'region': 'xyz'},
        'module': 'ec2',
        'delegate_to': 'localhost',

        'local_action2': "echo hi",
        'module2': "echo hi"
    }
    parser = ModuleArgsParser(task_ds)
    parse_result = parser.parse()
    assert parse_result[2] == 'localhost'



# Generated at 2022-06-20 23:14:02.494419
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:14:12.402659
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # task_ds is none, which is invalid
    with pytest.raises(AnsibleAssertionError):
        parser = ModuleArgsParser(task_ds=None, collection_list=None)

    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert not parser._task_ds
    assert not parser._task_attrs
    assert not parser._collection_list
    assert not parser.resolved_action

    assert parser._split_module_string("shell") == ('shell', '')
    assert parser._split_module_string("shell ") == ('shell', '')
    assert parser._split_module_string("shell param1=value1") == ('shell', 'param1=value1')

# Generated at 2022-06-20 23:14:24.880286
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(
        task_ds=dict(
            local_action="action_name a=1 b=2",
            delegate_to=None,
        ),
    )
    assert module_args_parser._task_ds == dict(
        local_action="action_name a=1 b=2",
        delegate_to=None,
    )
    assert module_args_parser._collection_list is None

# Generated at 2022-06-20 23:14:28.019941
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    for cls in (dict, string_types):
        assert cls is not None
    assert AnsibleParserError is not None
    assert ModuleArgsParser is not None


# Generated at 2022-06-20 23:14:31.609866
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    result = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'}, collection_list=None)
    assert result is not None

# Generated at 2022-06-20 23:14:35.815755
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'copy src=a dest=b', 'delegate_to': 'localhost', 'register': 'ansible_test'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser.resolved_action == None
    assert module_args_parser._collection_list == None
    assert isinstance(module_args_parser._task_attrs, frozenset)
    assert len(module_args_parser._task_attrs) == 41


# Generated at 2022-06-20 23:14:45.628745
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    collection_list = MockCollectionLoader(MODULE_PATH, '', '', '', '')

    # module takes no parameters
    ds = dict(action='ping')
    parser = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert args == dict()
    assert delegate_to is None

    # module takes string parameter
    ds = dict(action='shell ping')
    parser = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args == dict(arg='ping')
    assert delegate_to is None

    # module takes k=v parameters

# Generated at 2022-06-20 23:14:57.853532
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    my_task_ds = dict(
        name='my_task',
        action=dict(
            module='my_test',
            task_args=dict(
                arg1=1,
                arg2='2',
                arg3='{{example}}',
                arg4='/dir/{{ example }}/dir2/file',
            )
        ),
        delegate_to='localhost'
    )
    my_collection_list = collections.OrderedDict()

    parser = ModuleArgsParser(my_task_ds, my_collection_list)
    action, args, delegate_to = parser.parse()

    assert action == 'my_test'
    assert delegate_to == 'localhost'

# Generated at 2022-06-20 23:15:07.566213
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test_ModuleArgsParser function is only meant to test constructor of class ModuleArgsParser
    # Errors in the test function should not be considered as issues
    try:
        from ansible.playbook.task import Task
        from ansible.playbook.handler import Handler
        # store the valid Task/Handler attrs for quick access
        task_attrs = set(Task._valid_attrs.keys())
        task_attrs.update(set(Handler._valid_attrs.keys()))
        task_attrs = frozenset(task_attrs)
        assert isinstance(task_attrs, frozenset)
    except Exception as e:
        print("Exception raised while testing constructor of class ModuleArgsParser: %s" % e)

# Generated at 2022-06-20 23:15:12.389989
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = dict(action=dict(module='copy', dest='a', src='b'))
    parser = ModuleArgsParser(task_ds)
    parser.parse()

    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    parser.parse()

    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    parser.parse()

# Generated at 2022-06-20 23:16:11.091479
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def _task_ds_to_dict(task_ds):
        return {'action': task_ds}

    def _compare_result(task_ds, expected_action, expected_args, expected_delegate_to):
        actual_action, actual_args, actual_delegate_to = ModuleArgsParser(_task_ds_to_dict(task_ds)).parse()
        assert actual_action == expected_action
        assert actual_args == expected_args
        assert actual_delegate_to == expected_delegate_to

    # --------------------------
    # Argument description tests
    # --------------------------

    # Test module action without argument
    _compare_result(
        task_ds='test',
        expected_action='test',
        expected_args={},
        expected_delegate_to=Sentinel
    )

    #

# Generated at 2022-06-20 23:16:16.126792
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:16:26.811257
# Unit test for constructor of class ModuleArgsParser