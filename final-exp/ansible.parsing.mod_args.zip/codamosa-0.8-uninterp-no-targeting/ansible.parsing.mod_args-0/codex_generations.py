

# Generated at 2022-06-20 23:06:58.853408
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    loader = DictDataLoader(dict(
        playbook=dict(
            path='test.yml',
            basedir='/tmp',
        ),
    ))

    # The constructor accepts both a Task and a Play.
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=1)

    # Non-Task objects are rejected
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=dict(delegate_to='localhost'))

    task = Task()
    task.loader = loader
    task.action = 'setup'
    parser = ModuleArgsParser(task_ds=task)
    assert parser.resolved_action == 'setup'

    task.action = 'copy'

# Generated at 2022-06-20 23:07:05.815477
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args = dict()
    test_task_ds = {'action': 'user_name=openstack', 'delegate_to': '127.0.0.1'}
    map = ModuleArgsParser(test_task_ds)
    assert isinstance(map, ModuleArgsParser)
    expected_action = "user_name=openstack"
    expected_args = {'user_name': 'openstack'}
    expected_delegate_to = '127.0.0.1'
    (action, args, delegate_to) = map.parse()
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to


# Generated at 2022-06-20 23:07:06.732984
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None



# Generated at 2022-06-20 23:07:16.176081
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-20 23:07:28.380018
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds1 = {'action': dict(module='debug', msg='test')}
    task_ds2 = {'action': 'ping'}
    task_ds3 = {'module': 'ping'}
    task_ds4 = {'action': 'ping', 'delegate_to': 'localhost'}
    task_ds5 = {'action': dict(module='file', path='/tmp/foo')}
    task_ds6 = {'action': dict(module='replace', path='/tmp/foo', regexp='yes', state='absent', owner='bar')}
    task_ds7 = {'action': dict(module='replace', path='/tmp/foo', regexp='yes', state='absent', owner='bar', group='baz', mode='0777')}

# Generated at 2022-06-20 23:07:36.356744
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    task_ds = AnsibleMapping()
    task_ds.update({'_uuid': 'e82e9c7b-a83f-47e3-8b3f-7bd3532171c1',
                    'action': AnsibleUnsafeText('yum name=ntp state=latest'),
                    'delegate_to': 'localhost',
                    'loop': '{{ packages }}',
                    'loop_control': AnsibleMapping([(
                        'label',
                        '{{ item.name }} - {{ item.version }}')])})

# Generated at 2022-06-20 23:07:39.894444
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args_parser = ModuleArgsParser()
    assert isinstance(args_parser, ModuleArgsParser)
    assert args_parser is not None



# Generated at 2022-06-20 23:07:52.004699
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test when task_ds is not a dict
    # tets_ansible_module.TestAnsibleModule.test_parse_failure_task_ds_not_dict
    p = ModuleArgsParser(task_ds=2)
    with pytest.raises(AnsibleAssertionError) as execinfo:
        p.parse(skip_action_validation=False)
    assert 'the type of "task_ds" should be a dict' in to_native(execinfo.value)

    # Test when args is not a dict
    # tets_ansible_module.TestAnsibleModule.test_parse_failure_complex_args_is_not_dict
    p = ModuleArgsParser(task_ds={'module': 'copy', 'args': 2})

# Generated at 2022-06-20 23:07:58.997262
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict()
    ds['action'] = 'shell echo hi'
    ds['async'] = 1
    ds['poll'] = 3
    ds['delegate_to'] = 'test_host'
    ds['register'] = 'abc'
    ds['environment'] = 'prod'
    ds['local_action'] = 'shell echo'
    ds['with_subelements'] = 'subelement1'
    ds['module'] = 'shell echo'

    ModuleArgsParser(ds)



# Generated at 2022-06-20 23:08:10.549261
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testcases for class ModuleArgsParser
    module_args_parser = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError) as exec_info:
        module_args_parser.parse()
    assert "the type of 'task_ds' should be a dict, but is a NoneType" in str(exec_info.value)

    module_args_parser = ModuleArgsParser(task_ds={})
    with pytest.raises(AnsibleAssertionError) as exec_info:
        module_args_parser.parse()
    assert "the type of 'task_ds' should be a dict, but is a NoneType" in str(exec_info.value)

    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-20 23:08:39.319830
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    parser._task_ds = {"module" : "copy"}
    assert parser._split_module_string("copy")[0] == "copy"
    assert parser._split_module_string("copy")[1] == ""
    assert parser._split_module_string("copy src=a dest=b")[0] == "copy"
    assert parser._split_module_string("copy src=a dest=b")[1] == "src=a dest=b"

    assert parser._normalize_new_style_args("echo hi", "shell") == {"_raw_params" : "echo hi", "_uses_shell" : True}
    assert parser._normalize_new_style_args({"region" : "xyz"}, "ec2") == {"region" : "xyz"}
    assert parser._normalize

# Generated at 2022-06-20 23:08:51.332976
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C
    # all the constructors require a valid loader, so create a temporary one
    loader = AnsibleLoader(None, 'test', 'fake_basedir', 'fake_vault_password')

    include_ds = dict(
        name='fake_include',
        include=['foo',
                 dict(tasks='bar',
                      when=dict(var='inventory_hostname',
                                equals='localhost')),
                 dict(file='baz',
                      when=dict(ansible_distribution='Ubuntu'))]
    )

    include_ds['include'] = []
    del include_ds['name']

# Generated at 2022-06-20 23:08:55.371021
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': {'module': 'echo hi'}}
    module_args_parser_obj = ModuleArgsParser(task_ds)
    assert isinstance(module_args_parser_obj, ModuleArgsParser)



# Generated at 2022-06-20 23:09:06.777196
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser.resolved_action is None
    assert parser._task_attrs == frozenset(['local_action', 'static'])
    assert parser._split_module_string("debug msg='foo'") == ('debug', "msg='foo'")
    assert parser._split_module_string("debug msg=foo") == ('debug', "msg=foo")
    assert parser._normalize_parameters('debug msg=foo') == ('debug', {'_raw_params': 'msg=foo'})
    assert parser._normalize_new_style_args('msg=foo', 'debug') == {'_raw_params': 'msg=foo'}

# Generated at 2022-06-20 23:09:18.364665
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mp = ModuleArgsParser(task_ds={'action': {'module': 'copy'}})
    assert mp
    assert mp._task_ds == {'action': {'module': 'copy'}}
    assert mp._collection_list is None
    assert mp.resolved_action is None

    mp2 = ModuleArgsParser(task_ds='task_ds', collection_list='collections')
    assert mp2._task_ds == 'task_ds'
    assert mp2._collection_list == 'collections'
    # NOTE: resolved_action will be set during parsing, which is not done in the constructor
    assert mp2.resolved_action is None

    # Test __init__ with bad args

# Generated at 2022-06-20 23:09:24.532775
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser(task_ds={})
    assert m._task_ds == {}
    assert m._task_attrs == frozenset()
    assert m.resolved_action is None
    m = ModuleArgsParser(task_ds={'action' : 'shell echo hi'})
    assert m._task_ds == {'action' : 'shell echo hi'}


# Generated at 2022-06-20 23:09:37.016355
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:09:40.193243
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser()
    assert isinstance(m, ModuleArgsParser),  "__init__() has failed to create ModuleArgsParser class"


# Generated at 2022-06-20 23:09:42.149311
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'foo': 'bar'}
    map = ModuleArgsParser(task_ds)



# Generated at 2022-06-20 23:09:54.688402
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # ansible.utils.module_docs.ModuleDocs class module

    task_ds_1 = '/etc/ansible/roles/role_under_test/defaults/main.yml'
    collection_list_1 = None
    obj = ModuleArgsParser(task_ds_1, collection_list_1)
    result = obj.parse()
    assert result[0] == 'action' and result[1] == 'args' and result[2] == 'delegate_to'

    # ansible.utils.module_docs.ModuleDocs class module


# Generated at 2022-06-20 23:10:47.752610
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    assert(ModuleArgsParser({'yum': ['name=joe']}).parse() == \
           ('package', {'name': 'joe'}, None))

    assert(ModuleArgsParser({'yum': {'name': 'joe'}}).parse() == \
           ('package', {'name': 'joe'}, None))

    assert(ModuleArgsParser({'yum': 'name=joe'}).parse() == \
           ('package', {'name': 'joe'}, None))

    assert(ModuleArgsParser({'copy': ['src=/tmp/a', 'dest=/tmp/b']}).parse() == \
           ('copy', {'src': '/tmp/a', 'dest': '/tmp/b'}, None))


# Generated at 2022-06-20 23:10:54.764304
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    collection_list = [CollectionRequirement.from_string('my.test')]
    task = dict(
        action={'module': 'shell', 'args': 'echo hi'}
    )
    parser = ModuleArgsParser(task_ds=task, collection_list=collection_list)

    # Testing init
    assert parser._task_ds == task
    assert parser._collection_list == collection_list
    assert parser.resolved_action is None



# Generated at 2022-06-20 23:11:05.510057
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test example from the docs
    task_ds = {
        'action': {
            'module': 'shell',
            'executable': '/usr/bin/perl',
            'removes': '*.sw[op]',
            'creates': 'files.out',
            'chdir': '/path/to/workdir',
            'warn': False,
        }
    }
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert delegate_to is None

# Generated at 2022-06-20 23:11:09.037266
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'copy'
    }
    m = ModuleArgsParser(task_ds)
    assert m


# Generated at 2022-06-20 23:11:09.789348
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:11:21.178895
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds={'delegate_to': 'localhost', 'action': {'module': 'command', 'args': 'echo hello'}}, collection_list='test')
    result = obj.parse()
    assert result[1]['_variable_params'] == 'echo hello'
    assert result[2] == 'localhost'
    assert result[0] == 'command'
    obj = ModuleArgsParser(task_ds={'action': 'command echo hi', 'delegate_to': 'localhost'}, collection_list='test')
    result = obj.parse()
    assert result[1]['_raw_params'] == 'echo hi'
    assert result[2] == 'localhost'
    assert result[0] == 'command'

# Generated at 2022-06-20 23:11:33.971464
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class MockActionLoader(object):
        def get_plugin_list(self):
            return ['action_one', 'action_two']

    module_loader = MockActionLoader()

    task_ds = {'module': 'module_name', 'delegate_to': 'host'}
    mock_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert mock_parser.parse()[0] == 'module_name'
    assert mock_parser.parse()[1] == {}
    assert mock_parser.parse()[2] == 'host'

    task_ds = {'action': {'module_name': 'hi'}}
    mock_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)

# Generated at 2022-06-20 23:11:46.100893
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class TestModuleArgsParser(unittest.TestCase):
        def setUp(self):
            self.parser = ModuleArgsParser(task_ds=None, collection_list=None)

        def tearDown(self):
            pass

        def test_split_module_string(self):
            self.assertEqual(self.parser._split_module_string('shell echo hi'), ('shell', 'echo hi'))
            self.assertEqual(self.parser._split_module_string('copy src=a dest=b'), ('copy', 'src=a dest=b'))
            self.assertEqual(self.parser._split_module_string('copy src=a'), ('copy', 'src=a'))


# Generated at 2022-06-20 23:11:51.916717
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'debug': 'msg={{foo}}'}
    collection_list = ['a_collection', 'another_collection']
    assert ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # error test: task_ds should be a dict, not a str
    task_ds = "this is not a dict"
    assert_raises(AnsibleAssertionError, ModuleArgsParser, task_ds)


# Unit tests for parse()

# Generated at 2022-06-20 23:12:04.365209
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    task_ds = {}
    collection_list = {}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert parser is not None

    task_ds = {'action': 'script'}
    collection_list = {}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # Test the case that task_ds does not contain _raw_params, action is script
    (action, args, delegate_to) = parser.parse()
    assert action == 'script'
    assert args == {}
    assert delegate_to == Sentinel


# Generated at 2022-06-20 23:12:29.718779
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # constructor
    assert isinstance(ModuleArgsParser(), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds={}), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds={'module': 'copy'}), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds={'action': 'copy'}), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds={'action': {'module': 'copy'}}), ModuleArgsParser)
    assert isinstance(ModuleArgsParser(task_ds={'action': {'module': 'copy', 'args': {'src': 'a', 'dest': 'b'}}}), ModuleArgsParser)

# Generated at 2022-06-20 23:12:32.575912
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    ds = {'action': {'module': 'xyz', 'a': 1}}
    ModuleArgsParser(task_ds=ds)



# Generated at 2022-06-20 23:12:41.288190
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    task = dict(action='copy', src='a', dest='b')
    fail = dict(action='copy', src='a', dest='b', something='else')
    p = ModuleArgsParser(task)
    assert p.parse() == (u'copy', dict(src=u'a', dest=u'b'), None)
    p = ModuleArgsParser(task, TaskInclude._valid_attrs.keys())
    assert p.parse() == (u'copy', dict(src=u'a', dest=u'b'), None)
    p = ModuleArgsParser(fail)
    with pytest.raises(AnsibleParserError):
        p.parse()



# Generated at 2022-06-20 23:12:53.847466
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    # Ensure to_text works
    # Set up Python 2 StringIO for testing
    if PY2:
        reload(sys)
        sys.setdefaultencoding('utf-8')
        import __builtin__ as builtins
        builtins.unicode = unicode
        to_bytes = to_bytes
        StringIO = StringIO.StringIO

    # Set up Python 3 StringIO for testing
    else:
        to_bytes = to_bytes
        import builtins
        builtins.unicode = str
        from io import StringIO

    # Set up the env for testing
    set_ansible_mod

# Generated at 2022-06-20 23:13:04.579039
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    from units.compat.mock import patch, MagicMock
    import units.modules.utils
    from ansible.playbook.task import Task
    parser = ModuleArgsParser({'action': 'ping'})
    args = parser.parse()
    assert_equal(args, ('ping', [], None))

    # patch this in the the class so we don't call a real method
    with patch.object(ModuleArgsParser, '_normalize_parameters') as mock_normalize:
        mock_normalize.return_value = ['ping', []]
        parser = ModuleArgsParser({'action': 'ping'})
        args = parser.parse()
        assert_equal(args, ('ping', [], None))

        # test 'local_action'
        parser = ModuleArgs

# Generated at 2022-06-20 23:13:12.881245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.errors
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.playbook.become
    module_args = dict(
        action = "test",
        delegate_to = dict(test="test"),
        args = dict(test="test")
    )
    t = ansible.playbook.task.Task()
    t._valid_attrs = dict(test="test")
    t1 = ansible.playbook.handler.Handler()
    t1._valid_attrs = dict(test="test")
    b = ansible.playbook.become.Become()
    b._valid_attrs = dict(test="test")
    # This is not a correct test because it does not check whether the
    # exception is raised correctly.

# Generated at 2022-06-20 23:13:19.251791
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'local_action': 'shell echo hello world'}
    obj = ModuleArgsParser(task_ds=task_ds)
    assert obj._task_ds == task_ds
    assert obj._task_attrs == {'local_action', 'name', 'register', 'tags', 'when', 'static'}



# Generated at 2022-06-20 23:13:31.843521
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    def test_task(task_ds, collection_list=None):
        parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
        action, args, delegate_to = parser.parse()
        assert action is not None
        assert args is not None
        assert delegate_to is not None
        return (action, args, delegate_to)

    # complex args form, for passing structured data
    (action, args, delegate_to) = test_task({'copy':dict(src='a', dest='b')})
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    assert delegate_to is None

    # local_action

# Generated at 2022-06-20 23:13:37.007125
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action='copy src=a dest=b')
    parser = ModuleArgsParser(task_ds)
    module, args, delegate_to = parser.parse()
    assert module == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None



# Generated at 2022-06-20 23:13:45.037620
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser(task_ds={'delegate_to': None, 'example': {'module': 'shell', 'chdir': '/tmp', 'args': 'test'}, 'action': {'x': 1, 'y': 2}, 'local_action': {'module': 'shell', 'args': 'echo hi'}, 'with_items': ['a', 'b', 'c']}, collection_list=[])
    assert args_parser.parse() == ('example', {'args': 'test', 'chdir': '/tmp'}, None)

# Generated at 2022-06-20 23:13:58.342025
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(module_args_parser._task_attrs, frozenset)
    assert isinstance(module_args_parser._task_ds, dict)
    assert isinstance(module_args_parser._collection_list, list)



# Generated at 2022-06-20 23:14:00.103657
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert isinstance(ModuleArgsParser(), ModuleArgsParser)



# Generated at 2022-06-20 23:14:09.098371
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    ds = dict(
        connection="network_cli",
        gather_facts="no",
        name="test",
        host="{{inventory_hostname}}",
        provider=dict(ip="{{ip}}", username="cisco"),
        test="test",
        tasks=list(),
    )

    role = RoleDefinition.load(dict(name="test"), 
        loader=DataLoader(), variable_manager=None,
        use_task_defaults=True)

    parser = ModuleArgsParser(task_ds=ds, collection_list=None)
    # run parse
    result = parser.parse()
    # verify
    assert result[0] == "test"

# Generated at 2022-06-20 23:14:10.110546
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert True

# Generated at 2022-06-20 23:14:22.062861
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        action = 'shell',
        echo = 'echo hi',
        module = 'shell',
        args = dict(
            chdir = '/tmp',
            vim = 'emacs'
        ),
        delegate_to = 'localhost'
    )

    parser = ModuleArgsParser(task_ds)

    expected = dict(
        delegate_to = 'localhost',
        action = 'shell',
        args = dict(
            chdir = '/tmp',
            vim = 'emacs',
            _raw_params = 'echo hi'
        )
    )
    assert parser.parse()[1] == expected['args']

    # TODO: Need to check the output of 'parse' function
    #       The following test expects that `parse` returns a tuple.
    #       But `parse` returns a dict.


# Generated at 2022-06-20 23:14:34.597444
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:14:40.811876
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()

    assert module_args_parser._task_ds == {}
    assert module_args_parser._collection_list is None
    assert isinstance(module_args_parser._task_attrs, frozenset)
    assert isinstance(module_args_parser._task_attrs, set)
    assert module_args_parser._task_attrs == set(['notify', 'name', 'vars', 'args', 'retries', 'local_action', 'until', 'register', 'loop_control', 'connection', 'static', 'delegate_to', 'until_failed', 'run_once', 'include', 'ignore_errors', 'action', 'tags', 'when'])
    assert module_args_parser.resolved_action is None


# Generated at 2022-06-20 23:14:45.116344
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parse_param_action = ModuleArgsParser()
    pprint(module_parse_param_action.parse())

    # test with skip_action_validation
    module_parse_param_action_action = ModuleArgsParser()
    pprint(module_parse_param_action_action.parse(skip_action_validation=True))



# Generated at 2022-06-20 23:14:51.643395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test the new style module invocations with the action as a key in
    # the task yaml
    module_parser = ModuleArgsParser()

    module = 'shell'
    task_instance_ds = {'action': 'echo hi'}
    expected = ('shell', {}, None)
    actual = module_parser.parse()
    assert actual == expected, "Expected %s to be equal to actual %s" % (expected, actual)

    task_instance_ds = {'action': 'echo hi there'}
    expected = ('shell', {}, None)
    actual = module_parser.parse()
    assert actual == expected, "Expected %s to be equal to actual %s" % (expected, actual)

    task_instance_ds = {'action': 'echo hi there'}
    expected = ('shell', {}, None)


# Generated at 2022-06-20 23:14:53.812660
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # result = ModuleArgsParser().parse(  )
    assert False # TODO: implement your test here


# Generated at 2022-06-20 23:15:09.439665
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': {
            'module': 'ec2',
            'x': 1
        },
        'local_action': {
            'module': 'shell',
            'echo': 1
        },
        'delegate_to': 'server0',
        'args': {
            'region': 'cn-north-1'
        },
        'static': True
    }
    parser = ModuleArgsParser(task_ds)
    assert isinstance(parser._task_ds, dict)
    assert parser._task_ds == task_ds
    assert not parser._collection_list
    assert parser._task_ds.get('local_action') == {'module': 'shell', 'echo': 1}
    assert parser._task_ds.get('action') == {'module': 'ec2', 'x': 1}

# Generated at 2022-06-20 23:15:13.615720
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test by trying to create an instance of the class
    task_ds = {
        'a': 'b',
        'b': 'c',
        'c': 'd'
    }
    collection_list = [1, 2, 3, 4, 5]
    ModuleArgsParser(task_ds, collection_list)


# Generated at 2022-06-20 23:15:24.232727
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test case where task_ds is a dictionary
    thing = {
        'action': 'copy',
        'args': 'src=a dest=b',
    }
    task_ds = ModuleArgsParser(thing)
    assert isinstance(task_ds._task_ds, dict)
    action, args, delegate_to = task_ds.parse()
    assert action == u'copy'
    assert delegate_to == Sentinel
    assert isinstance(args, dict)

    # test case where task_ds is not a dictionary
    try:
        task_ds = ModuleArgsParser('shell')
    except AnsibleAssertionError:
        assert True
    else:
        assert False, "AnsibleAssertionError exception not raised"


# Generated at 2022-06-20 23:15:27.753673
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'test_parse'
    task = {}
    module_args_parser = ModuleArgsParser(task, collection_list=[])
    module_args_parser.parse()


# Generated at 2022-06-20 23:15:36.401220
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert ModuleArgsParser(task_ds={}).parse() == (None, dict(), None)
    assert ModuleArgsParser(task_ds={'args': {'a': 1}}).parse() == (None, {'a': 1}, None)
    assert ModuleArgsParser(task_ds={'delegate_to': 'local'}).parse() == (None, dict(), 'local')
    assert ModuleArgsParser(task_ds={'action': {'module': 'echo hi'}}).parse() == ('echo hi', dict(), None)
    assert ModuleArgsParser(task_ds={'action': {'module': 'echo hi', 'something_else': 'or_not'}}).parse() == ('echo hi', {'something_else': 'or_not'}, None)

# Generated at 2022-06-20 23:15:49.541502
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_loader_mock = MagicMock(**{
        'find_plugin_with_context.return_value.resolved': False
    })
    test_task_ds = {
        'args': {
            '_raw_params': None,
            'sudo': True,
            'warn': True,
            'user': 'root',
            'free_form': False,
            '_uses_shell': False,
            '_raw_params2': None
        },
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'name': 'dummy task'
    }
    test_collection_list = [
        'ansible.builtin',
        'ansible.posix'
    ]
    expected_action = 'shell'

# Generated at 2022-06-20 23:16:01.838269
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for module_args.ModuleArgsParser.parse()
    '''
    # Following are 4 test cases for each type of legal task instance:
    # 1. action + key=value pair
    # 2. action + dictionary
    # 3. action + key=value pair (containing a string with Jinja2 delimiters.
    # 4. action + dictionary (containing a string with Jinja2 delimiters.

# Generated at 2022-06-20 23:16:09.164282
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    ds = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    action, args, delegate_to = m.parse(ds)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == 'localhost'
    #
    m = ModuleArgsParser()
    ds = {'junk': 'shell echo hi'}
    with pytest.raises(AnsibleParserError):
        m.parse(ds)
    #
    m = ModuleArgsParser()
    ds = {'action': 'shell echo hi'}
    action, args, delegate_to = m.parse(ds)
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}

# Generated at 2022-06-20 23:16:21.587247
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Unit test for method parse of class ModuleArgsParser
    """
    print("Testing ModuleArgsParser_parse")
    task_ds = {'action': 'copy src=/tmp/foo dest=/tmp/bar', 'delegate_to': 'localhost'}
    collection_list = []
    ret = ModuleArgsParser(task_ds, collection_list).parse()
    assert ret == ('copy', {'src': '/tmp/foo', 'dest': '/tmp/bar'}, 'localhost')

    task_ds = {'action': 'copy', 'args': 'src=/tmp/foo dest=/tmp/bar', 'delegate_to': 'localhost'}
    collection_list = []
    ret = ModuleArgsParser(task_ds, collection_list).parse()