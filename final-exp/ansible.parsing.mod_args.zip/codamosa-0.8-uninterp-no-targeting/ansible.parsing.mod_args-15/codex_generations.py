

# Generated at 2022-06-20 23:07:16.608601
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': {
            'module': 'ping',
            'args': 'a=b c=d'
        }
    }

    obj = ModuleArgsParser(task_ds)
    assert isinstance(obj, ModuleArgsParser)
    assert obj._task_ds == {
        'action': {
            'module': 'ping',
            'args': 'a=b c=d'
        }
    }
    assert obj._collection_list is None

# Generated at 2022-06-20 23:07:26.366639
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = dict()
    mock_task_ds['action'] = 'shell echo hi'
    mock_task_ds['args'] = dict()
    mock_task_ds['args']['x'] = '{{a}}'
    module_args_parser = ModuleArgsParser(task_ds=mock_task_ds, collection_list=[])
    action,args,delegate_to = module_args_parser.parse(skip_action_validation=False)
    assert action == 'shell'
    assert args == {'_variable_params': 'echo hi'}
    assert delegate_to == None


# Generated at 2022-06-20 23:07:35.425606
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a = ModuleArgsParser({})
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))
    assert (a.parse() == (None, None))


# =============================================================================
# LINE:

# Generated at 2022-06-20 23:07:48.610478
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    arg_dict = {'name': 'test', 'arg2': 2, 'arg3': 3}
    mparser = ModuleArgsParser(arg_dict)
    assert mparser._task_ds == arg_dict
    assert mparser._task_attrs == frozenset(['remote_user', 'local_action', 'sudo', 'sudo_user', 'notify',
                                             'async', 'poll', 'static', 'delegate_to', 'delegate_facts',
                                             'become', 'become_user', 'become_method', 'tags', 'when', 'any_errors_fatal',
                                             'ignore_errors', 'register', 'ignore_unreachable', 'environment'])


# Generated at 2022-06-20 23:07:59.041485
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    loader = DataLoader()
    context = PlayContext()

# Generated at 2022-06-20 23:08:10.592956
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:08:13.378654
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args = dict(
        args = dict(a = "abcd"),
        delegate_to = 'localhost',
        action = dict(module='file')
    )

    parser = ModuleArgsParser(module_args)
    parser.parse()


# Generated at 2022-06-20 23:08:25.513626
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=dict(action='copy', src='a', dest='b'))
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds=dict(action='copy', src=dict(x='a'), dest='b'))
    assert parser.parse() == ('copy', {'src': {'x': 'a'}, 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds=dict(action='copy src=a dest=b'))
    assert parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds=dict(action='copy', args=dict(src='a', dest='b')))

# Generated at 2022-06-20 23:08:37.835384
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    def parse(task_ds, collection_list=None):
        m = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
        return m.parse()

    class MyCollection:
        def __init__(self, collection_name, collection_modules):
            self._collection_name = collection_name
            self._collection_modules = collection_modules

        def get_name(self):
            return self._collection_name

        def get_modules(self):
            return self._collection_modules


# Generated at 2022-06-20 23:08:49.099150
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    group_all = Group('all')
    group_all.vars = dict()
    group_all.vars['ansible_user_id'] = 'vagrant'
    group_all.vars['ansible_connection'] = 'ssh'
    group_all.vars['ansible_ssh_user'] = 'vagrant'
    group_all.vars['ansible_ssh_pass'] = 'vagrant'
    group_all.vars['ansible_port'] = '2200'

# Generated at 2022-06-20 23:09:08.455426
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class TestModuleArgsParser(ModuleArgsParser):
        def __init__(self, task_ds=None):
            ModuleArgsParser.__init__(self, task_ds)
    test_task = {
        'delegate_to': 'test',
        'local_action': 'some_action'
    }
    parser = TestModuleArgsParser(test_task)
    assert parser._task_ds == test_task
    assert parser.resolved_action == None



# Generated at 2022-06-20 23:09:20.746440
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(collection_loader.get_collection_paths("ansible_collections.test.collection_path.subcollections.sub.plugins.modules"))
    a = {
        'action': "subcollection_module_1",
    }
    b = ModuleArgsParser(task_ds=a, collection_list=["test.subcollections.sub"]).parse()
    assert b == ('subcollection_module_1', {}, None)

    a = {
        'action': 'collection_module_1',
    }
    b = ModuleArgsParser(task_ds=a, collection_list=["test.subcollections.sub"]).parse()
    assert b == ('collection_module_1', {}, None)


# Generated at 2022-06-20 23:09:29.830879
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:09:37.478998
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    thing = True
    action = True
    delegate_to = True
    args = True
    task_ds = {"action":"copy src=a dest=b"}
    collection_list = True
    instance = ModuleArgsParser(task_ds, collection_list)
    res = instance.parse(True)
    assert res[0] == "copy"
    assert res[1]['src'] == "a"
    assert res[1]['dest'] == "b"
    assert res[2] == True



# Generated at 2022-06-20 23:09:39.807734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert m.parse() == (None, None, Sentinel)



# Generated at 2022-06-20 23:09:41.374990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: consider adding some unit tests for this
    raise SkipTest


# Generated at 2022-06-20 23:09:45.295530
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {} 

    obj = ModuleArgsParser(task_ds=task_ds)
    #ModuleArgsParser.parse() relies on other methods, it's not easy to unit test it
    assert True

# Generated at 2022-06-20 23:09:50.149059
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    collection_list = list()
    skip_action_validation = False
    m = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert m.parse(skip_action_validation=skip_action_validation) == (None, dict(), None)

# Generated at 2022-06-20 23:10:01.886062
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test for 'action' and 'args' key in task
    task_ds = dict(action="shell", args=dict(chdir="/tmp"))
    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate) = parser.parse()
    assert action == "shell"
    assert delegate == Sentinel
    assert args == dict(chdir="/tmp")

    # Test for 'local_action' and 'args' key
    task_ds = dict(local_action="shell", args=dict(chdir="/tmp"))
    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate) = parser.parse()
    assert action == "shell"
    assert args == dict(chdir="/tmp")

    # Test for 'action' and 'args' key with normal-form task
   

# Generated at 2022-06-20 23:10:13.408851
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()

    # TEST: No argument
    with pytest.raises(AnsibleAssertionError) as excinfo:
        m = ModuleArgsParser()
    assert 'dict' in to_text(excinfo.value)
    assert 'task_ds' in to_text(excinfo.value)

    # TEST: task_ds is not a dict
    with pytest.raises(AnsibleAssertionError) as excinfo:
        m = ModuleArgsParser(task_ds="test")
    assert 'dict' in to_text(excinfo.value)
    assert 'task_ds' in to_text(excinfo.value)

    # TEST: task_ds is a dict
    m = ModuleArgsParser(task_ds=task_ds)
    assert m
    assert m._task_ds == task

# Generated at 2022-06-20 23:10:34.393951
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:10:47.252193
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='copy', src='/tmp', dest='/etc')
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert parser.parse() == ('copy', dict(src='/tmp', dest='/etc'), Sentinel)

    task_ds = dict(local_action='copy', src='/tmp', dest='/etc')
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    assert parser.parse() == ('copy', dict(src='/tmp', dest='/etc'), 'localhost')

    task_ds = dict(action='copy /tmp /etc')
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)

# Generated at 2022-06-20 23:10:51.052724
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'shell': 'echo hi'}}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'shell'
    assert delegate_to is None


# Generated at 2022-06-20 23:11:01.402922
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True == True  # this for now is to discard PEP8 warning with pytest
    # Create a Dict object for test
    test_dict = dict(action='action',
                     foo='bar',
                     args='args')
    # Create a ModuleArgsParser object
    obj_ModuleArgsParser = ModuleArgsParser(task_ds=test_dict)
    # Test the method parse of class ModuleArgsParser
    action, args, delegate_to = obj_ModuleArgsParser.parse()
    assert action == 'action'
    assert args == dict(foo='bar', args='args')
    assert delegate_to == Sentinel


# The class ModuleLoader is used to build the list of ansible modules
# and their path.

# Generated at 2022-06-20 23:11:10.868953
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.resolved_action is None
    # [ { action: { module: 'copy', src: 'a', dest: 'b' } } ]
    # [ { action: 'copy src=a dest=b' } ]
    # [ { action: 'echo hi', delegate_to: remote_server } ]
    # [ { local_action: 'echo hi' } ]
    # [ { local_action: { module: 'copy', src: 'a', dest: 'b' } } ]
    # [ { local_action: 'copy src=a dest=b' } ]
    # [ { command: 'pwd', args: { chdir: '~/ansible' } } ]
    # [ { command

# Generated at 2022-06-20 23:11:21.636279
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='ping', args=dict(path='/bin', test='example'))
    mod_args_parser = ModuleArgsParser(task_ds)
    assert mod_args_parser
    assert mod_args_parser._task_ds == task_ds
    assert mod_args_parser._collection_list is None
    assert mod_args_parser._task_attrs == frozenset(['register', 'ignore_errors', 'any_errors_fatal', 'always_run',
                                                     'delegate_to', 'loop', 'name', 'run_once', 'local_action', 'static',
                                                     'async_val', 'poll', 'tags', 'when'])
    assert mod_args_parser.resolved_action is None



# Generated at 2022-06-20 23:11:34.427182
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

    assert parser._task_ds is not None
    assert parser._task_attrs is not None
    assert parser.resolved_action is None

    assert parser._normalize_old_style_args(({"shell" : "echo hi"})) == ('shell', {'_raw_params': 'echo hi'})
    assert parser._normalize_old_style_args(("shell echo hi")) == ('shell', {'_raw_params': 'echo hi'})
    assert parser._normalize_old_style_args(({"module": "ec2", "x": 1})) == ('ec2', {'x': 1})

    assert parser._normalize_new_style_args('echo hi', action='shell') == {'_raw_params': 'echo hi'}
    assert parser._normalize_new_style_

# Generated at 2022-06-20 23:11:46.537051
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    PARSE_TASK_NONE = {
        'task': {}
    }

    PARSE_TASK_COMPLEX = {
        'task': {
            'action': {
                'module': 'ec2',
                'region': 'ap-southeast-1',
                'key': 'aliyun'
            },
            'delegate_to': 'localhost'
        }
    }

    PARSE_TASK_SIMPLE = {
        'task': {
            'action': 'ec2 region=ap-southeast-1 key=aliyun'
        }
    }

    TASKS = [
        PARSE_TASK_NONE,
        PARSE_TASK_COMPLEX,
        PARSE_TASK_SIMPLE
    ]


# Generated at 2022-06-20 23:11:55.592961
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mod_args_parser = ModuleArgsParser(task_ds={'action': 'copy', 'src': '/etc/hosts', 'dest': '/tmp/hosts',
                                                'newline': 'yes', 'delimiter': ':', 'backup': 'yes', 'remote_src': 'no'})
    action, args, delegate_to = mod_args_parser.parse()
    assert action == 'copy'
    assert args == {'src': '/etc/hosts', 'dest': '/tmp/hosts', 'newline': 'yes', 'delimiter': ':', 'backup': 'yes',
                     'remote_src': 'no'}
    assert delegate_to == None



# Generated at 2022-06-20 23:12:08.272186
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    assert ModuleArgsParser(task_ds=task_ds).parse() == (None, dict(), Sentinel)
    task_ds['action'] = dict()
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('action', dict(), Sentinel)
    task_ds = dict()
    task_ds['action'] = 'action'
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('action', dict(), Sentinel)
    task_ds['local_action'] = dict()
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('action', dict(), 'localhost')
    task_ds['local_action'] = 'local_action'
    assert ModuleArgsParser(task_ds=task_ds).parse() == ('action', dict(), 'localhost')
    task_ds

# Generated at 2022-06-20 23:12:24.862821
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds=dict(action='test', delegate_to=True, raw=True), collection_list=['ansible.builtin'])
    (action, args, delegate_to) = parser.parse()
    assert action == 'test'
    assert args == dict(raw=True)
    assert delegate_to is True



# Generated at 2022-06-20 23:12:30.462445
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    unit test for method parse of class ModuleArgsParser
    '''
    # Construct the expected result
    expected_action = 'abc'
    expected_args = {
        '_raw_params': 'def ghi',
        'jkl': 'mno',
        'pqr': 'stu'
    }
    expected_delegate_to = 'vwx'

    # Construct the test data
    test_dict = dict(
        module=expected_action + ' ' + expected_args['_raw_params'],
        args=dict(jkl=expected_args['jkl'], pqr=expected_args['pqr']),
        delegate_to=expected_delegate_to
    )
    task = dict()
    collection_list = list()

# Generated at 2022-06-20 23:12:34.381439
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ''' 
    @summary: Unit test for ModuleArgsParser class
    '''
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_ds == task_ds
    assert parser._collection_list == None
    assert set(parser._task_attrs) == {'async_jid', 'async_poll_interval', 'async_seconds', 'changed_when', 'failed_when', 'local_action', 'poll', 'register', 'retries', 'static', 'tags', 'when', 'until'}
    

# Generated at 2022-06-20 23:12:44.551635
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = "shell echo hi"
    collection_list = None
    result = ModuleArgsParser(task_ds, collection_list).parse()[0]
    assert result == 'shell'

    task_ds = "shell"
    collection_list = None
    result = ModuleArgsParser(task_ds, collection_list).parse()[0]
    assert result == 'shell'


# Generated at 2022-06-20 23:12:57.097424
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test None case
    module_arg_parser = ModuleArgsParser()
    assert {} == module_arg_parser._task_ds
    assert module_arg_parser.resolved_action is None

    # Test dict case
    test_task_ds = dict()
    module_arg_parser = ModuleArgsParser(test_task_ds)
    assert {} == module_arg_parser._task_ds
    assert module_arg_parser.resolved_action is None

    # Test non dict case
    test_task_ds = list()
    try:
        module_arg_parser = ModuleArgsParser(task_ds=test_task_ds)
    except AnsibleAssertionError as e:
        assert 'the type of \'task_ds\' should be a dict, but is a <class \'list\'>' in to_text(e)


# Generated at 2022-06-20 23:12:58.535941
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
        #TODO
        pass


# Generated at 2022-06-20 23:13:02.703303
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(a=1, b=2)
    result = ModuleArgsParser(args).parse()
    check_type_of_result(result, tuple)
    a1, a2, a3 = result
    assert a1 == 'a' and a2 == {'b': 2} and a3 is None

# Generated at 2022-06-20 23:13:11.111790
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    #
    # normal usage
    #

    # delegated action
    result = ModuleArgsParser(
        task_ds = dict(delegate_to='localhost', action='shell', args='echo hi')
    ).parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # delegated action
    result = ModuleArgsParser(
        task_ds = dict(delegate_to='localhost', local_action='shell', args={'_raw_params': 'echo hi', '_uses_shell': True})
    ).parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    # usual action

# Generated at 2022-06-20 23:13:12.964704
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    e = AnsibleException(123, 'exception 123')
    module_parser = ModuleArgsParser()
    assert module_parser.parse() == (None, None, None)

# Generated at 2022-06-20 23:13:17.143309
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert issubclass(ModuleArgsParser, AnsibleBaseYAMLObject)
    assert getattr(ModuleArgsParser, "load", None)



# Generated at 2022-06-20 23:13:42.585991
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'test_module'
    args = [{'ARG1': 'VALUE1', 'ARG2': ['V1', 'V2']}, {'ARG1': 'V1', 'ARG2': ['V2', 'V3']}]
    delegate_to = None
    task_ds = {'action': args[0]}
    collection_list = None
    expect = (action, args[0], delegate_to)
    instance = ModuleArgsParser(task_ds, collection_list)
    result = instance.parse()
    assert result == expect

    task_ds = {'module': ' '+action+' '+dict_to_kv(args[1])}
    expect = (action, args[1], delegate_to)
    instance = ModuleArgsParser(task_ds, collection_list)
    result

# Generated at 2022-06-20 23:13:53.201317
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task1 = {'action': {'module': 'shell', '_raw_params': '1', 'use_shell': 'True'}}
    task2 = {'action': 'shell echo hello'}
    task3 = {'action': 'shell', 'args': {'_raw_params': 'echo hello'}}
    task4 = {'action': 'shell', 'args': 'echo hello'}
    task5 = {'action': 'shell', 'args': 'echo hello', 'delegate_to': '127.0.0.1'}
    task6 = {'local_action': 'shell echo hello'}
    task7 = {'local_action': {'module': 'shell', '_raw_params': '1'}}

# Generated at 2022-06-20 23:13:59.157511
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = {'action': 'shell echo hi', 'delegate_to': 'localhost', 'args': 'shell ls', 'local_action': 'copy src=a dest=b'}
  parser = ModuleArgsParser(task_ds)
  action, _args, delegate_to = parser.parse()
  assert action == 'shell'
  assert delegate_to == 'localhost'


# Generated at 2022-06-20 23:14:09.277575
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''


    # Create the object under test
    obj = ModuleArgsParser()

    # We need to mock the return value of parse_kv
    def parse_kv_mock(args, check_raw=False):
        if args.startswith("server=1"):
            return {"server": "1"}
        if args.startswith("server=2"):
            return {"server": "2"}
        if args.startswith("server=3"):
            return {"server": "3"}
        return {}
    monkeypatch.setattr(ModuleArgsParser, "parse_kv", parse_kv_mock)

    # Test empty task
    task_ds = {}
    collection_list = None
    exp_action = None
    exp

# Generated at 2022-06-20 23:14:19.833489
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test the __init__ method
    _task_ds = {}
    _collection_list = None

    _module_args_parser = ModuleArgsParser(task_ds=_task_ds, collection_list=_collection_list)
    assert _module_args_parser._task_ds == _task_ds
    assert _module_args_parser._collection_list == _collection_list
    assert _module_args_parser._task_attrs == frozenset(['shell', 'async', 'register', 'free_form', 'no_log', 'local_action', 'static'])
    assert _module_args_parser.resolved_action is None


# Generated at 2022-06-20 23:14:20.535245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:14:23.682155
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  parser = ModuleArgsParser()
  task_ds = {'action': 'shell echo hi'}
  assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, Sentinel)
  assert parser.parse(**task_ds) == ('shell', {'_raw_params': 'echo hi'}, Sentinel)


# Generated at 2022-06-20 23:14:35.831619
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test ModuleArgsParser.parse() to raise AnsibleParserError with wrong action value
    task_ds = {"action": "something-nonexistent", "args": {"a": 1, "b": 2, "c": 3}}
    map = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError):
        map.parse()

    # Test ModuleArgsParser.parse() to raise AnsibleParserError with conflicting action statements
    task_ds = {"action": "something", "local_action": "something-else", "args": {"a": 1, "b": 2, "c": 3}}
    map = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError):
        map.parse()

    # Test ModuleArgsParser.parse() to raise

# Generated at 2022-06-20 23:14:45.679892
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "action": "command",
        "delegate_to": "localhost",
        "args": "echo hi"
    }
    task_ds = {
        "action": "command",
        "delegate_to": "localhost",
        "args": "echo hi"
    }
    # module_arg_spec = AnsibleModuleArgSpec()
    # module_arg_spec.args = [
    #     "name",
    #     "state",
    #     "config",
    #     "rules",
    #     "description",
    #     "disabled"
    # ]
    # module_arg_spec.name = "null"
    # module_arg_spec.supports_check_mode = True
    # module_arg_spec.optionals.extend([
    #     "

# Generated at 2022-06-20 23:14:56.208642
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser._task_ds == {}
    assert parser._collection_list is None
    assert parser._task_attrs == frozenset({'action', 'async_val', 'block', 'blocked_by', 'delegate_to', 'local_action', 'notify', 'register', 'rescue', 'static', 'tags', 'until', 'when', 'with_'})
    assert parser.resolved_action is None
    parser = ModuleArgsParser({})
    assert parser._task_ds == {}
    parser = ModuleArgsParser({}, collection_list=['test'])
    assert parser._collection_list == ['test']


# Generated at 2022-06-20 23:15:36.671813
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    def _check_args(task_ds, task_parse_results):
        parser = ModuleArgsParser(task_ds)
        results = parser.parse()
        assert results == task_parse_results


# Generated at 2022-06-20 23:15:49.770519
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test task with no module.
    module = 'no_module'
    args = {
        'action': 'a',
        'delegate_to': 'b',
        'args': 'c',
        'with_items': 'd',
    }
    parser = ModuleArgsParser(task_ds=args, collection_list=None)
    assert_raises_regexp(AnsibleParserError,
                         "no module/action detected in task.",
                         parser.parse)

    # Test task with incorrect module.
    args = {
        'task_module': 'shell task_args',
        'delegate_to': 'b',
        'args': 'c',
        'with_items': 'd',
    }
    parser = ModuleArgsParser(task_ds=args, collection_list=None)
    assert_

# Generated at 2022-06-20 23:16:02.046446
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test for legacy style
    parser = ModuleArgsParser({'action': 'shell echo hi'})
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    # Test for new style
    parser = ModuleArgsParser({'shell': 'echo hi'})
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    parser = ModuleArgsParser({'shell': 'echo hi', 'delegate_to': 'local'})
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'local')

    # Test for shell module with args

# Generated at 2022-06-20 23:16:09.299734
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test the ModuleArgsParser when the input is a dictionary
    assert ModuleArgsParser({'action': {'module': 'echo', 'args': 'test'}}).parse() == ('echo', {'args': 'test'})

    # Test the ModuleArgsParser when the input is a string
    assert ModuleArgsParser({'action': 'copy src=src dest=dest'}).parse() == ('copy', {'dest': 'dest', 'src': 'src'})

    # Test the ModuleArgsParser when the input is None
    assert ModuleArgsParser({'action': None}).parse() == ('shell', {'cmd': 'ping localhost -c 4'})

    # Test the ModuleArgsParser when the input is a string and the module is absent

# Generated at 2022-06-20 23:16:21.717067
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {
        'foo': 'bar',
        'include_vars': 'baz',
        'include_role': {'name': 'baz'},
        'start_at_task': 'mytask',
        'local_action': {'module': 'command', 'args': 'foo'},
        'block': {},
        'meta': {},
        'pre_tasks': [],
        'post_tasks': [],
        'rescue': [],
        'always': [],
        'when': 'always'
    }
    parser = ModuleArgsParser(task_ds)
    assert parser.module == 'command'

# Generated at 2022-06-20 23:16:26.617533
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    class_under_test = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = class_under_test.parse(skip_action_validation=False)
    assert action is None
