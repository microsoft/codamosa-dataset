

# Generated at 2022-06-20 23:07:04.260220
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test constructor
    assert 'action' in ModuleArgsParser(dict(action='test', a=1, b=2))._task_attrs
    assert 'task' not in ModuleArgsParser(dict(action='test', a=1, b=2))._task_attrs
    assert 'action' in ModuleArgsParser(dict(action='test', a=1, b=2))._task_ds
    assert 'task' not in ModuleArgsParser(dict(action='test', a=1, b=2))._task_ds
    # assert 'delegate_to' in ModuleArgsParser(dict(action='test', delegate_to='test'))._task_ds
    # assert 'delegate_to' in ModuleArgsParser(dict(action='test', delegate_to='test')).__init__()._task_ds
    # assert 'delegate

# Generated at 2022-06-20 23:07:15.175525
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # pylint: disable=too-many-locals,too-many-statements
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    d1 = dict(
        action=dict(
            module='copy',
            src='b',
            dest='c'
        )
    )
    d2 = dict(
        local_action=dict(
            module='copy',
            src='b',
            dest='c'
        )
    )
    d3 = dict(
        module='copy',
        src='b',
        dest='c'
    )
    d4 = dict(
        action='copy src=b dest=c'
    )
    d5 = dict(
        copy='src=b dest=c'
    )

# Generated at 2022-06-20 23:07:27.236872
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def _check_parsed_args(task_ds, expected_action, expected_args,
                           expected_delegate_to):
        parser = ModuleArgsParser(task_ds)
        (action, args, delegate_to) = parser.parse()
        assert action == expected_action
        assert args == expected_args
        assert delegate_to == expected_delegate_to

    def _check_parsed_args_skip_action_validation(task_ds,
                                                  expected_action,
                                                  expected_args,
                                                  expected_delegate_to):
        parser = ModuleArgsParser(task_ds)
        (action, args, delegate_to) = parser.parse(
            skip_action_validation=True)
        assert action == expected_action
        assert args == expected_args
        assert delegate

# Generated at 2022-06-20 23:07:35.877688
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {'module': 'echo hi', 'local_action': 'shell ls'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'shell'

    task_ds = {'module': 'echo hi', 'delegate_to': 'localhost'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser.resolved_action == 'echo'

    task_ds = {'action': 'echo hi', 'local_action': 'shell ls'}
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()

# Generated at 2022-06-20 23:07:49.081396
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # define args
    task_ds = {'roles': ['somedir.somefile'], 'shell': 'ls -ld /etc/su* /etc/sudo*', 'name': 'test'}
    collection_list = None
    args = True
    # instantiate class
    loader = TaskLoader()
    tasks = [t for t in loader.load_tasks([task_ds], collection_list) if t]
    task_ds = tasks[0].copy()
    parser = ModuleArgsParser(task_ds, collection_list)
    # check results
    assert parser.parse() == ('shell', {'_raw_params': 'ls -ld /etc/su* /etc/sudo*'}, None)
    assert parser.resolved_action == 'ansible.builtin.shell'
    
# -------------------------------------------------------------------------------------------------
# class

# Generated at 2022-06-20 23:07:59.427333
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test the first form of parse in class ModuleArgsParser
    task_ds_dict_1 = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    collection_list_1 = ['copy']
    moduleargs_parser_obj_1 = ModuleArgsParser(task_ds_dict_1, collection_list_1)
    (action_1, args_1, delegate_to_1) = moduleargs_parser_obj_1.parse()
    assert action_1 == 'copy'
    assert args_1 == {'src': 'a', 'dest': 'b'}
    assert delegate_to_1 is Sentinel

    # Test the second form of parse in class ModuleArgsParser
    task_ds_dict_2 = {'action': 'copy src=a dest=b'}
    collection_

# Generated at 2022-06-20 23:08:10.549288
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.vars import merge_hash
    from ansible.parsing.vault import VaultLib
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    config_manager = ConfigManager(ConfigData(parser=ConfigParser(), vault_secrets_only=True), 'ansible.cfg')
    vault_secrets = VaultLib(config_manager.config.get_config_value('vault_password_files', get_config=False, value_type='list', default=[]))
    lib = AnsibleModuleUtils(vault_secrets=vault_secrets)
    data = lib._load_params()
    assert isinstance(data, dict), "module args parser not returning a dictionary"



# Generated at 2022-06-20 23:08:17.670238
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_types = [
        {
            'in': 'string',
            'fail': True
        },
        {
            'in': {},
            'fail': True
        },
        {
            'in': None,
            'fail': True
        }
    ]
    for tt in test_types:
        if tt['fail']:
            with pytest.raises(AssertionError):
                map = ModuleArgsParser(tt['in'])
        else:
            map = ModuleArgsParser(tt['in'])
        assert isinstance(map, ModuleArgsParser)

# Generated at 2022-06-20 23:08:29.045351
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_native
    from ansible.plugins.loader import action_loader
    class args(object):
        one = '1'

    class action(object):
        pass
    action.args = args
    action.name = 'one'

    task_ds = {
            'delegate_to': 'localhost',
            'local_action': action
        }
    collection_list = []
    parser = ModuleArgsParser(task_ds, collection_list)
    parser.parse()
    print(to_native(parser.resolved_action))
    assert parser.resolved_action == 'ansible.module_utils.module_one.ActionModule.one'
    action_loader.find_plugin('one')

# Generated at 2022-06-20 23:08:35.051613
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''

    #call the method being tested
    parser = ModuleArgsParser({})
    action, args, delegate_to = parser.parse()

    #verify the method status
    assert action == None
    assert args == dict()
    assert delegate_to == Sentinel



# Generated at 2022-06-20 23:08:52.469074
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import datetime as date

# Generated at 2022-06-20 23:09:04.625490
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Basic task with a single module
    task_ds = dict(action=dict(shell='echo hi'))
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._normalize_old_style_args(task_ds['action']) == ('shell', {'_raw_params': 'echo hi'})

    # Basic task with a single module declared as a string and no vars
    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._normalize_old_style_args(task_ds['action']) == ('shell', {'_raw_params': 'echo hi'})

    # Basic task with a single module declared as a string and with vars
    task_ds = dict(action='shell {{ hi }}')

# Generated at 2022-06-20 23:09:14.562955
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Construct a mock of a task data structure
    task_ds = {
        "name": "Show version of application",
        "tags": ["version", "configuration"],
        "delegate_to": "localhost",
        "local_action": "{{package_manager}} version",
        "register": "shell_out"
    }
    # Construct a mock of a ModuleArgsParser-object
    moduleargs_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    # Call the parse-method of the mocked ModuleArgsParser-object
    action, args, delegate_to = moduleargs_parser.parse()

    print("Action: %s" % action)
    print("Args: %s" % args)
    print("Delegate to: %s" % delegate_to)
# Run the Unit test
test_

# Generated at 2022-06-20 23:09:26.753055
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    test_module_args_parser = ModuleArgsParser()
    test_module_args_parser._task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    assert test_module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    test_module_args_parser = ModuleArgsParser()
    test_module_args_parser._task_ds = {'action': 'copy src=a dest=b'}
    assert test_module_args_parser.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)

    test_module_args_parser = ModuleArgsParser()

# Generated at 2022-06-20 23:09:27.863166
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()



# Generated at 2022-06-20 23:09:30.226218
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser()
    assert module_parser



# Generated at 2022-06-20 23:09:38.084880
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'module': 'copy',
        'args': {
            '_raw_params': 'src="{{ s }}" dest="{{ d }}"',
            'src': '/tmp/a',
            'dest': '/tmp/b',
        },
        'changed_when': 'changed'
    }
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()
    assert module_args_parser.resolved_action is None

# Generated at 2022-06-20 23:09:50.150096
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test_boiler_plate():
        task_ds = dict()
        result = dict()
        # for some reason, this test fails if we do a dict(task_ds) here.
        # not sure why yet, but this appears to work.
        for thing in task_ds:
            result[thing] = task_ds[thing]
        return task_ds, result

    def test_action(task_ds, result):
        task_ds['action'] = dict(module='shell echo hi')
        result['action'] = dict(module='shell echo hi')
        return task_ds, result

    def test_local_action(task_ds, result):
        task_ds['local_action'] = dict(module='shell echo hi')
        result['local_action'] = dict(module='shell echo hi')
        return task_ds

# Generated at 2022-06-20 23:10:02.016183
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # case 1
    # testModuleArgsParser_parse_001()
    # case 2
    # testModuleArgsParser_parse_002()
    # case 3
    # testModuleArgsParser_parse_003()
    # case 4
    # testModuleArgsParser_parse_004()
    # case 5
    # testModuleArgsParser_parse_005()
    # case 6
    # testModuleArgsParser_parse_006()
    # case 7
    # testModuleArgsParser_parse_007()
    # case 8
    # testModuleArgsParser_parse_008()
    # case 9
    testModuleArgsParser_parse_009()
    # case 10
    # testModuleArgsParser_parse_010()
    # case 11
    # testModuleArgsParser_parse_011()
    # case 12
    # testModuleArgsParser_parse

# Generated at 2022-06-20 23:10:06.793015
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "delegate_to": "localhost",
        "local_action": "copy: src=a dest=b",
        "module": "copy",
        "args": "src=a dest=b",
    }
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', {}, 'localhost')

    task_ds = {
        "delegate_to": "localhost",
        "local_action": "copy: src=a dest=b",
        "args": "src=a dest=b",
    }
    result = ModuleArgsParser(task_ds).parse()
    assert result == ('copy', {}, 'localhost')


# Generated at 2022-06-20 23:10:18.755289
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'shell echo'
    }
    act = ModuleArgsParser(task_ds)

    assert act is not None


# Generated at 2022-06-20 23:10:31.287869
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = {
        'block': [
            {
                'block': [
                    {'fail': None}
                ],
                'always': None,
                'name': 'restart nginx',
                'rescue': []
            },
            {
                'block': [
                    {'fail': None}
                ],
                'always': None,
                'name': 'restart nginx',
                'rescue': []
            }
        ],
        'name': 'restart nginx and postgres'
    }
    try:
        ModuleArgsParser(data)
    except Exception as e:
        assert "the type of 'task_ds' should be a dict, but is a" in to_text(e)


# Generated at 2022-06-20 23:10:42.416054
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test each possible type of module declaration

    task_ds = {'action': 'shell echo hi'}
    task_ds2 = {'action': 'copy src=a dest=b'}
    task_ds3 = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    task_ds4 = {'action': {'region': 'xyz'}}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to is None

    parser = ModuleArgsParser(task_ds2)
    action, args, delegate_to = parser.parse()

    assert action == 'copy'


# Generated at 2022-06-20 23:10:54.328221
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from collections import Iterable
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-20 23:11:02.803503
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy', 'args': 'src=a dest=b', 'with_items': [1,2,3]}
    expected = ('copy', {'dest': 'b', 'src': 'a'}, None)
        
    p = ModuleArgsParser(task_ds=task_ds)
    ret = p.parse(skip_action_validation=True)

    assert ret == expected, "%s != %s" % (ret, expected)
    print('%s: OK' % inspect.stack()[0][3])


# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-20 23:11:05.311478
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    x = ModuleArgsParser({'foo': 'bar'})
    assert isinstance(x, ModuleArgsParser)

    with pytest.raises(AnsibleAssertionError):
        y = ModuleArgsParser('not a dict')


# Generated at 2022-06-20 23:11:18.335298
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class AnsibleModule:
        def __init__(self, config_file, module_path, task_ds, collection_list=None):
            self.config_file = config_file
            self.module_path = module_path
            self.task_ds = task_ds
            self.collection_list = collection_list
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import dict_merge

    # First, we test the case where we don't find any module or action
    # The test is made using a list of dictionaries, each one preserve the two dictionaries given to the constructor.
    # The dictionaries are given to the constructor, in order, by the function dict_merge in module combine_vars

# Generated at 2022-06-20 23:11:20.091129
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'local_action': {u'moudle': u'test'}}
    obj = ModuleArgsParser(task_ds=task_ds)
    obj.parse()

# --------------------------------------------------


# Generated at 2022-06-20 23:11:20.558420
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:11:33.210633
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module='copy', src='a dest=b'))
    map = ModuleArgsParser(task_ds)
    # The method parse will return a tuple of (action, args, delegate_to)
    map.parse()

    # test the case of action, and args is None

    task_ds2 = dict(action=None)
    map2 = ModuleArgsParser(task_ds2)
    map.parse()

    # The method parse will return a tuple of (action, args, delegate_to)
    map3 = ModuleArgsParser(task_ds)
    map3.parse()

    # The method parse will return a tuple of (action, args, delegate_to)
    task_ds4 = dict(action=dict(module='copy', src='a', dest='b'))
    map4 = Module

# Generated at 2022-06-20 23:11:45.626751
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # No args
    parser = ModuleArgsParser({})
    assert parser is not None

    # An empty args
    parser = ModuleArgsParser({}, [])
    assert parser is not None

    # An empty task_ds
    parser = ModuleArgsParser(None)
    assert parser is not None


# Generated at 2022-06-20 23:11:50.472395
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    result = module_args_parser.parse()
    assert result is not None
    assert len(result) == 3
    assert result[0] is None
    assert result[1] is None
    assert result[2] is None


# -----------------------------------------------

UNSAFE_ARG_TYPES = (list, dict)



# Generated at 2022-06-20 23:12:02.434108
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()
    yaml_data = '''
- name: "test_playbook_1"
  hosts: localhost
  gather_facts: false
  connection: local
  tasks:
    - name: "debug msg"
      debug:
        msg: "hello world"
    - name: "copy test"
      copy:
        content: "{{ lookup('url', 'https://raw.githubusercontent.com/ansible/ansible/devel/test/test_playbook_1.yml') }}"
        dest: "/tmp/test_playbook_1.yml"
'''
    values = AnsibleBaseYAM

# Generated at 2022-06-20 23:12:13.835922
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.modules.source_control.git import Git
    import ansible.plugins.loader as plugin_loader

    plugin_loader.add_directory("/tmp/ansible")
    plugin_loader.add_directory("/tmp/ansible_local")

    ####
    # Test the 'normal' case
    ####
    task_ds = {
        'action': 'my_test_module_source_control_git args={{test_variable}}'
    }

    module = ModuleArgsParser(task_ds).parse()[0]
    assert type(module) == Git

    ####
    # Test the 'dict' case
    ####
    task_ds = {
        'action': {
            'my_test_module_source_control_git': 'args={{test_variable}}'
        }
    }

# Generated at 2022-06-20 23:12:26.342003
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    mp = ModuleArgsParser({})
    assert mp
    assert isinstance(mp, ModuleArgsParser)
    mp = ModuleArgsParser(thing={})
    assert mp
    assert isinstance(mp, ModuleArgsParser)
    assert mp._collection_list is None
    assert mp._task_ds == {}

    mp = ModuleArgsParser(thing={}, collection_list=["foo", "bar"])
    assert mp
    assert isinstance(mp, ModuleArgsParser)
    assert mp._collection_list == ["foo", "bar"]
    assert mp._task_ds == {}
    assert mp._task_attrs == frozenset(['tags', 'static', 'local_action', 'block', 'become', 'become_user', 'name', 'ignore_errors', 'become_method', 'register', 'environment'])
    assert mp.res

# Generated at 2022-06-20 23:12:32.576891
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    test_parser = ModuleArgsParser({})
    assert len(test_parser._task_attrs) == len(Task._valid_attrs) + len(Handler._valid_attrs) + 2

# Unit tests for method _split_module_string() of class ModuleArgsParser

# Generated at 2022-06-20 23:12:39.863751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.validation import Validator
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # No underlying data structure
    task_ds = {}

    parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleAssertionError):
        result = parser.parse(skip_action_validation=False)

    # Invalid
    task_ds = None
    parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleAssertionError):
        result = parser.parse(skip_action_validation=False)

    task_ds = AnsibleBaseYAMLObject()
    parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:12:41.398963
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser({}, collection_list=[])
    assert type(parser) == ModuleArgsParser


# Generated at 2022-06-20 23:12:46.030541
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test to ensure that we don't have any exceptions while parsing empty dict as task.
    # Some tasks might be empty, so this test is added to check that.
    assert ModuleArgsParser({}).parse() == (None, dict(), Sentinel)



# Generated at 2022-06-20 23:12:58.394322
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    case_insensitive_task_dict = {'EC2': {'x': 1}}
    ma_gen = ModuleArgsParser(case_insensitive_task_dict)
    (action, args, delegate_to) = ma_gen.parse()
    assert action == 'ec2'
    assert args == {'x': 1}
    assert delegate_to is Sentinel

    task_dict_with_invalid_module = {'EC2': {'x': 1}, 'FOO': {'x': 1}}
    ma_gen = ModuleArgsParser(task_dict_with_invalid_module)
    with pytest.raises(AnsibleParserError) as execinfo:
        (action, args, delegate_to) = ma_gen.parse()
    assert 'module/action' in str(execinfo.value)

# Generated at 2022-06-20 23:13:21.616901
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    
    # TODO: Mock the task_ds argument
    
    # TODO: Mock the collection_list argument
    
    task_ds = {}
    collection_list = []
    
    # Initializing the ModuleArgsParser class with the mocked arguments
    parser_obj = ModuleArgsParser( task_ds,  collection_list )
    
    # Calling the parse method of the ModuleArgsParser class
    result = parser_obj.parse()

# Generated at 2022-06-20 23:13:34.775752
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Task without args
    task_ds = {'action': 'ping'}
    module_param_parser = ModuleArgsParser(task_ds)
    module_param = module_param_parser.parse()
    assert module_param == ('ping', {}, None), 'module_param should be ("ping", {}, None) but was %s' % (module_param,)

    # Task with args
    task_ds = {'action': 'ping', 'args': {'arg1': 'val1'}}
    module_param_parser = ModuleArgsParser(task_ds)
    module_param = module_param_parser.parse()

# Generated at 2022-06-20 23:13:43.759524
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test normalization of old style options
    task_ds = dict(shell='echo hi')
    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert args == dict(_raw_params='echo hi', _uses_shell=True), "args returned does not match expected. %s" % args
    assert delegate_to is None, "delegate_to returned does not match expected. %s" % delegate_to

    task_ds = dict(action='copy src=a dest=b')
    parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'

# Generated at 2022-06-20 23:13:47.994197
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: test doesn't work because of usage of global loader
    return
    task_ds = {'action': {
        'ec2': {
            'region': 'xyz',
            'x': 1
        }
    }}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'ec2'
    assert args == {'region': 'xyz', 'x': 1}
    assert delegate_to is Sentinel

# Generated at 2022-06-20 23:13:55.117792
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Fixture
    task_ds = dict(action=dict(module='ec2', x=1))

    # Action under test
    obj = ModuleArgsParser(task_ds=task_ds)
    actualresult = obj.parse()

    # Post-test checks
    assert actualresult == ('ec2', dict(x=1, ), None)



# Generated at 2022-06-20 23:14:05.901501
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean

    host = Mock()
    t = Task()
    h = Handler()
    b = Block()
    ds = dict(
        action='shell echo hi',
        local_action={'module': 'copy', 'src': '/tmp/file', 'dest': '/tmp/secondfile'},
        module={'module': 'copy', 'src': '/tmp/file', 'dest': '/tmp/secondfile'},
        delegate_to='localhost'
    )


# Generated at 2022-06-20 23:14:17.137916
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for module_utils.module_params_parser.ModuleArgsParser.parse
    '''
    # Test args and expected result.

# Generated at 2022-06-20 23:14:28.448373
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible import errors as ans_errors
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include
    import ansible.plugins.action as action_plugins
    import ansible.plugins.action.copy as copy
    import ansible.plugins.action.shell as shell
    import ansible.plugins.action.synchronize as synchronize
    import ansible.plugins.action.lineinfile as lineinfile
    import ansible.plugins.action.script as script

# Generated at 2022-06-20 23:14:31.609603
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor test
    moduleArgsParser = ModuleArgsParser()
    assert moduleArgsParser is not None


# Generated at 2022-06-20 23:14:41.919472
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test constructor to make sure it doesn't throw
    args_str = "this=that"
    task_ds = {"action": {"module": args_str}}
    args_parser = ModuleArgsParser([task_ds])
    assert args_parser

    # now create with an invalid task_ds
    task_ds = {"action": "this=that", "local_action": ["foo", "bar"]}
    with pytest.raises(AnsibleAssertionError):
        args_parser = ModuleArgsParser([task_ds])

    task_ds = {"action": {"module": args_str}}
    args_parser = ModuleArgsParser([task_ds])
    assert type(args_parser._task_ds) is dict

    # now assert that an exception is thrown for unsupported types as 'thing'

# Generated at 2022-06-20 23:14:58.054814
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

    module_string = 'copy src=a dest=b'
    tokens = parser._split_module_string(module_string)


# Generated at 2022-06-20 23:15:04.761394
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'command'
    args = {'chdir': '/tmp'}
    task_ds = {'command': 'pwd', 'args': {'chdir': '/tmp'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, parsed_args, delegate_to = module_args_parser.parse()
    assert action == module_name
    assert parsed_args == args

# Generated at 2022-06-20 23:15:13.206841
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test that the constructor works in the default case
    parser = ModuleArgsParser(task_ds=None)
    assert parser._task_ds == {}
    # test that the constructor works in the case with specified task_ds
    parser = ModuleArgsParser(task_ds={u'action': {u'module': u'ping'}})
    assert parser._task_ds == {u'action': {u'module': u'ping'}}

    # test that exception is raised when task_ds is not a dict
    with pytest.raises(AnsibleAssertionError) as excinfo:
        parser = ModuleArgsParser(task_ds=[{u'action': {u'module': u'ping'}}])
    assert 'the type of \'task_ds\' should be a dict' in excinfo.exconly()

# Unit

# Generated at 2022-06-20 23:15:24.689333
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    import ansible.utils.unsafe_proxy
    import ansible.module_utils.six
    import ansible.module_utils.network.common.config
    import ansible.module_utils.cloud
    import ansible.module_utils.network.common.utils
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.cloudservices
    parser = ModuleArgsParser(task_ds={'module': 'shell', '_ansible_no_log': False, '_ansible_verbosity': 0, '_ansible_selinux_special_fs': ['/sys/fs/selinux', '/selinux', '/dev/tty', '/dev/pts']}, collection_list=None)

# Generated at 2022-06-20 23:15:34.742594
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # Create a mock object of AnsibleFileLoader
    loader = AnsibleFileLoader(
        '',
        '',
        sources=None,
        collection_info=dict(
            roles=[],
            role_params=dict()
        )
    )

    # Create a mock object of ModuleLoader
    module_loader = ModuleLoader(
        '',
        '',
        '',
        loader=loader,
        collection_list=None
    )

    # Create a mock object of ActionLoader
    action_loader = ActionLoader(
        '',
        '',
        '',
        loader=loader,
        collection_list=None
    )

    # Create a mock object of ActionBase

# Generated at 2022-06-20 23:15:46.078150
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task = {'action': dict(x=1, y=2)}
    a = ModuleArgsParser(task_ds=task)
    assert a._task_ds['action'] == dict(x=1, y=2)
    assert a._task_attrs == frozenset(['connection', 'name', 'vars', 'local_action', 'block', 'meta', 'become', 'become_method', 'ignore_errors',
                                       'register', 'tags', 'delegate_to', 'retries', 'delay', 'environment', 'first_available_file', 'until', 'notify',
                                       'async_val', 'poll', 'when', 'static'])


# Generated at 2022-06-20 23:15:58.302709
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test basic behavior  with known arguments
    module_args_parser = ModuleArgsParser(task_ds={"arg1": 1, "arg2": "arg2", "arg3": 1.0},
                                          collection_list=None)
    action, args, delegate_to = module_args_parser.parse()
    assert action == "arg1"
    assert args == {"arg2": "arg2", "arg3": 1.0}
    assert delegate_to == Sentinel

    # Test delegation to localhost
    module_args_parser = ModuleArgsParser(task_ds={"local_action": "echo Hi", "delegate_to": "some_host"},
                                          collection_list=None)
    action, args, delegate_to = module_args_parser.parse()
    assert action == "echo"

# Generated at 2022-06-20 23:16:01.591027
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    action = None
    delegate_to = None
    args = None
    task_ds = {'action': 'copy src=a dest=b'}
    module_args_parser._task_ds = task_ds
    module_args_parser._collection_list = None
    module_args_parser._task_attrs = frozenset({'action', 'local_action', 'static'})
    result = module_args_parser.parse()
    assert result == (action, args, delegate_to)

# Generated at 2022-06-20 23:16:08.043499
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	task_ds = {u'notify': {u'content': u'state: started,msg: {{item}}', u'with_items': ['a', 'b', 'c']}}
	parser = ModuleArgsParser(task_ds=task_ds)
	parsed = parser.parse()
	assert_equals(parsed, (u'notify', {u'content': u'state: started,msg: {{item}}', u'with_items': ['a', 'b', 'c']}, None))
pass

# Generated at 2022-06-20 23:16:17.317007
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook.task

    task = ansible.playbook.task.Task()

    parser = ModuleArgsParser(task._ds)

    parsed = parser.parse()
    assert parsed == (None, None, None)

    task._ds = {'a': {'module': 'shell', '_raw_params': 'echo hi'}}
    parser = ModuleArgsParser(task._ds)
    parsed = parser.parse()

    assert parsed == ('shell', {'_raw_params': 'echo hi'}, None)


