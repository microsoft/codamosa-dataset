

# Generated at 2022-06-20 23:07:04.671175
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.splitter import parse_kv
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars

    # Normal workflow
    task_ds = dict(action='shell echo hi', delegate_to=None)
    collection_list = None
    expected_action = 'shell'
    expected_args = dict(_raw_params='echo hi', _uses_shell=True)
    expected_delegate_to = None

    task_parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    actual_action, actual_args, actual_delegate_to = task_parser.parse()

    assert actual_action == expected_action

# Generated at 2022-06-20 23:07:13.569526
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Test ModuleArgsParser constructor
    """
    output = ModuleArgsParser()
    assert '_task_ds' in vars(output)
    assert '_collection_list' in vars(output)
    assert '_task_attrs' in vars(output)
    assert 'resolved_action' in vars(output)
    assert isinstance(output._task_ds, dict)
    assert isinstance(output._collection_list, collections.Iterable)
    assert isinstance(output._task_attrs, frozenset)
    assert output.resolved_action is None


# Generated at 2022-06-20 23:07:23.060307
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args = ModuleArgsParser()
    # testing for __init__(self, task_ds=None, collection_list=None)
    assert(not isinstance(module_args, str))
    assert(not isinstance(module_args, list))
    # testing for __init__(self, task_ds=None, collection_list=None)
    assert(not isinstance(module_args, dict))
    assert(not isinstance(module_args, int))
    assert('test_task_ds' in module_args)
    assert('test_collection_list' in module_args)


# Generated at 2022-06-20 23:07:33.398054
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import io
    import sys
    from ansible.module_utils._text import to_bytes

    # Read in data for testing
    try:
        from tests.test_utils import read_data_file
    except (ImportError, AttributeError):
        from test.unit.callback_plugins.test_utils import read_data_file

    task_input = read_data_file(os.path.join('test/unit/module_args/test_inputs/',
                                             'ModuleArgsParser_parse_task_input.yml'))

    # Suppress any output produced by Ansible in the module
    sys.stdout = io.BytesIO()
    sys.stderr = io.BytesIO()

    task_ds_dict = yaml.safe_load(task_input)

    # Create a ModuleArgsParser object
   

# Generated at 2022-06-20 23:07:44.978963
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='copy', args='src=a dest=b')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

    plugin_loader = PluginLoader(None, 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_')
    plugin_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)

    module_name, args, delegate_to = module_args_parser.parse()

    assert module_name == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to == 'all'

if __name__ == "__main__":
    test_ModuleArgsParser()

# Generated at 2022-06-20 23:07:56.622598
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, host_list=['localhost'])

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'local',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{ ansible_date_time.iso8601 }}')))
            ]
        )

# Generated at 2022-06-20 23:08:08.143695
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:08:16.371552
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # dummy ds for constructor
    task_ds = {}
    # test with default ds
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._task_attrs == frozenset()
    assert module_args_parser.resolved_action is None
    # test with ds set with task attributes
    task_ds = get_default_task_data()
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:08:23.326387
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # constructor should accept no more than two arguments:
    # task_ds and collection_list
    a = ModuleArgsParser()

    b = ModuleArgsParser({})

    c = ModuleArgsParser({}, ["fake_collection"])

    d = ModuleArgsParser(task_ds={}, collection_list=["fake_collection"])
    d = ModuleArgsParser(collection_list=["fake_collection"], task_ds={})

# Generated at 2022-06-20 23:08:35.636897
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:08:51.844234
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    ModuleArgsParser(task_ds)
    task_ds = {'module': 'testmodule', 'testmodule': 'testmodule2', 'action': 'testmodule2'}
    try:
        ModuleArgsParser(task_ds)
        raise AssertionError('conflicting action statements not detected')
    except AnsibleParserError:
        pass
    task_ds = {'module': 'testmodule', 'testmodule': 'testmodule2'}
    try:
        ModuleArgsParser(task_ds)
        raise AssertionError('no module/action detected in task not detected')
    except AnsibleParserError:
        pass



# Generated at 2022-06-20 23:08:52.992910
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # TODO:
    pass


# Generated at 2022-06-20 23:09:05.143506
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  test_obj = ModuleArgsParser()
  task_ds = {
    'hosts': 'all',
    'args': dict(
      chdir='/tmp'
    ),
    'vars': dict(
      ansible_port='1234'
    ),
    'action': 'pwd',
    'delegate_to': 'delegate-host'
  }
  collection_list = []
  expected_action, expected_args, expected_delegate_to = 'pwd', {'_raw_params': '', 'chdir': '/tmp', '_ansible_verbosity': 0, '_ansible_version': '2.9.10'}, 'delegate-host'

# Generated at 2022-06-20 23:09:15.701957
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_with_action_dict = {"action": {"module": "copy", "src": "a", "dest": "b"}}
    task_ds_with_action_string = {"action": "shell echo hi"}
    task_ds_with_local_action_dict = {"local_action": {"module": "copy", "src": "a", "dest": "b"}}
    task_ds_with_local_action_string = {"local_action": "shell echo hi"}
    task_ds_with_action_key_value = {"copy": "src=a dest=b"}
    task_ds_with_action_key_dict = {"copy": {"src": "a", "dest": "b"}}

# Generated at 2022-06-20 23:09:27.356073
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(dict(action=dict(module='copy', src='a', dest='b')))
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel())
    obj = ModuleArgsParser(dict(action='copy src=a dest=b'))
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel())
    obj = ModuleArgsParser(dict(action='copy', args=dict(src='a', dest='b')))
    assert obj.parse() == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel())
    obj = ModuleArgsParser(dict(action='copy', src='a', dest='b'))

# Generated at 2022-06-20 23:09:33.682572
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mapper = ModuleArgsParser({'action': 'command /usr/bin/uptime'}, collection_list=None)

    ret = mapper.parse()

    # If a valid AnsibleAction object was returned, we return True
    assert ret == ('command', {u'_raw_params': u'/usr/bin/uptime', u'_uses_shell': True}, None)



# Generated at 2022-06-20 23:09:37.790143
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def validate_keys(task_ds):
        module_args_parser = ModuleArgsParser(task_ds)
        # store the valid Task/Handler attrs for quick access
        task_attrs = set(Task._valid_attrs.keys())
        task_attrs.update(set(Handler._valid_attrs.keys()))
        task_attrs.update(['local_action', 'static'])
        task_attrs = frozenset(task_attrs)
        # HACK: why are these not FieldAttributes on task with a post-validate to check usage?

# Generated at 2022-06-20 23:09:42.103314
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # test 1 - Old-style usage of action and module
    task = {'action': 'copy src=a dest=b', 'delegate_to': 'local'}
    parser = ModuleArgsParser(task)
    assert parser.parse() == ('copy', {u'dest': u'b', u'src': u'a'}, 'local')

    # test 2 - Old-style usage of action and module with a jinja2 template
    task = {'action': 'copy src={{foo}} dest={{bar}}', 'delegate_to': 'local'}
    parser = ModuleArgsParser(task)

# Generated at 2022-06-20 23:09:45.192795
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Unit test for method parse of class ModuleArgsParser
    # TODO(retr0h): Implement this test. For now, just skipping
    pass

# Generated at 2022-06-20 23:09:54.725156
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    parser = ModuleArgsParser(Task._valid_attrs)
    handler = Handler()
    assert parser._task_attrs == set(Task._valid_attrs.keys())
    assert parser._task_attrs == set(Handler._valid_attrs.keys())

# Generated at 2022-06-20 23:10:13.161528
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    parser = ModuleArgsParser()
    assert set(Task._valid_attrs.keys()) == parser._task_attrs, 'Task attrs not equal in ModuleArgsParser constructor'
    assert set(Handler._valid_attrs.keys()) == parser._task_attrs, 'Handler attrs not equal in ModuleArgsParser constructor'

# Generated at 2022-06-20 23:10:27.327365
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # store the valid Task/Handler attrs for quick access
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)

    thing = {'module': 'shell echo hi'}
    cls = ModuleArgsParser(thing)
    assert cls._task_ds == thing
    assert cls.resolved_action is None
    assert cls._collection_list is None
    assert cls._task_attrs == task_attrs


# Generated at 2022-06-20 23:10:32.199907
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: mock task_ds and _collection_list
    task_ds = Mock()
    collection_list = Mock()
    ModuleArgsParser(task_ds=task_ds, collection_list=collection_list).parse(skip_action_validation=True)

# Generated at 2022-06-20 23:10:43.998265
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # action: module_name: args=value
    ds = {}
    ds['action'] = 'command: /bin/foo'
    parser = ModuleArgsParser(task_ds=ds)
    module_name, name_args, delegate_to = parser.parse()
    assert module_name == 'command'
    assert name_args == {'args': '/bin/foo'}
    assert delegate_to is None

    # action: module_name
    ds = {}
    ds['action'] = 'command'
    parser = ModuleArgsParser(task_ds=ds)
    module_name, name_args, delegate_to = parser.parse()
    assert module_name == 'command'
    assert name_args == {}
    assert delegate_to is None

    # action: module_name args=value

# Generated at 2022-06-20 23:10:56.001002
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert m.parse() == ('', {},)
    assert m.parse(skip_action_validation=True) == ('', {},)

    a = {'echo': 'hi'}
    m = ModuleArgsParser(task_ds=a)
    assert m.parse() == ('echo', {'_raw_params': 'hi'})
    assert m.parse(skip_action_validation=True) == ('echo', {'_raw_params': 'hi'})

    a = {'shell': 'echo hi'}
    m = ModuleArgsParser(task_ds=a)
    assert m.parse() == ('shell', {'_raw_params': 'echo hi'})

# Generated at 2022-06-20 23:11:06.135168
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.splitter import parse_kv
    from ansible.executor import task_result_from_exception
    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.utils.vars import combine

# Generated at 2022-06-20 23:11:14.739751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test creation of a task object from the specified args
    test_action = 'test'
    test_task_ds = {'test': {'test_arg1': 'test_val1'}}
    parser = parse_parsers.ModuleArgsParser(test_task_ds)
    assert parser.parse()[0] == test_action
    assert parser.resolved_action == 'test_module.TestModule'
    return


# Test creation of task object with a different test task

# Generated at 2022-06-20 23:11:17.687258
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    collection_list = None
    p = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert p



# Generated at 2022-06-20 23:11:19.820505
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Class for parsing task arguments to template them correctly (for example
# booleans in loop terms should always be strings)

# Generated at 2022-06-20 23:11:26.752682
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    parser = ModuleArgsParser(task_ds=None, collection_list=None)

    ret = parser._split_module_string(module_string='bkp_image: image_name={{ image_name }}')
    assert ret == ('bkp_image', 'image_name={{ image_name }}')

    ret = parser._split_module_string(module_string='bkp_image:')
    assert ret == ('bkp_image', '')

    ret = parser._split_module_string(module_string='bkp_image')
    assert ret == ('bkp_image', '')

    ret = parser._normalize_parameters(thing='bkp_image', action=None, additional_args=None)

# Generated at 2022-06-20 23:11:52.747126
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser({'action': 'shell echo hi'}, collection_list=None)
    assert module_args_parser
    action, args, delegate_to = module_args_parser.parse(skip_action_validation=True)
    assert action and args and delegate_to is None

    module_args_parser = ModuleArgsParser({'shell': 'echo hi'}, collection_list=None)
    assert module_args_parser
    action, args, delegate_to = module_args_parser.parse(skip_action_validation=True)
    assert action and args and delegate_to is None

    module_args_parser = ModuleArgsParser({'shell': {'echo': 'hi'}}, collection_list=None)
    assert module_args_parser
    action, args, delegate_to = module_args_parser

# Generated at 2022-06-20 23:11:59.472855
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        action=dict(
            module='ping',
            args=dict(
                data='pong'
            )
        )
    )
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'ping'
    assert delegate_to is Sentinel
    assert args == dict(
        data='pong'
    )

# Generated at 2022-06-20 23:12:11.747398
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    expected_error = "unexpected parameter type in action: <class 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'>"

    # Test case 1
    # action: echo hi
    # simulate: {"action": "echo hi"}
    action = AnsibleUnsafeText('echo hi')
    task_ds = {'action': action}

    with pytest.raises(AnsibleParserError) as exec_info:
        ModuleArgsParser(task_ds)
    assert str(exec_info.value) == expected_error

    # Test case 2
    # action: {"module": "command", "cmd": "uptime"}
    # simulate: {"

# Generated at 2022-06-20 23:12:24.862191
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict(action = 'shell')
    parse = ModuleArgsParser(task_ds=ds).parse()
    assert parse == ('shell', dict(), None)
    ds = dict(action = 'shell echo')
    parse = ModuleArgsParser(task_ds=ds).parse()
    assert parse == ('shell', dict(args=dict()), None)
    ds = dict(action = 'shell echo')
    parse = ModuleArgsParser(task_ds=ds).parse()
    assert parse == ('shell', dict(args=dict()), None)
    ds = dict(action = 'shell echo')
    parse = ModuleArgsParser(task_ds=ds).parse()
    assert parse == ('shell', dict(args=dict()), None)
    ds = dict(action = 'shell', delegate_to = 'localhost')
    parse

# Generated at 2022-06-20 23:12:28.196769
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = {}
  map = ModuleArgsParser(task_ds=task_ds)
  print(map.parse())

test_ModuleArgsParser_parse()


# Generated at 2022-06-20 23:12:39.297331
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args = 'echo hi'
    ds = {'action': args}
    ModuleArgsParser(ds).parse()

    args = 'src=a dest=b'
    ds = {'action': 'copy ' + args}
    ModuleArgsParser(ds).parse()

    args = 'shell echo hi'
    ds = {'action': args}
    ModuleArgsParser(ds).parse()

    args = 'src=a dest=b'
    ds = {'action': 'copy ' + args}
    ModuleArgsParser(ds).parse()

    args = {'src': 'a', 'dest': 'b'}
    ds = {'action': args}
    ModuleArgsParser(ds).parse()


# Generated at 2022-06-20 23:12:40.248860
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    assert ModuleArgsParser()


# Generated at 2022-06-20 23:12:44.384375
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'apt', 'name': 'git'}

    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    print(action)
    print(args)


# Generated at 2022-06-20 23:12:49.165082
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = Task.load(dict(action='copy', src='a', dest='b'), collection_list=None)
    p = ModuleArgsParser(t)
    assert p.parse() == ('copy', {'src': 'a', 'dest': 'b'}, None)


# Generated at 2022-06-20 23:12:54.460436
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Common setup
    task_ds = {'action': 'shell', 'args': {}}
    collection_list = []

    mp = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    assert mp.parse(skip_action_validation=False) == ('shell', {}, None)


# Generated at 2022-06-20 23:13:28.380725
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    load_data = load_fixture('parser_module_args_parser_parse.yml')

    for data in load_data:
        skip_action_validation = data.get('skip_action_validation') or False
        task_ds = data.get('task_ds') or {}
        collection_list = data.get('collection_list') or []
        expect = data.get('expect') or {}

        module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
        actual = module_args_parser.parse(skip_action_validation=skip_action_validation)
        assert actual == expect



# Generated at 2022-06-20 23:13:34.287086
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = (1, 2)
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action = parser.parse()
    assert action[0] is None
    assert action[1] == {}
    assert action[2] == Sentinel



# Generated at 2022-06-20 23:13:43.471913
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:13:49.217766
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    testcase = dict(
        name = "Test",
        action = dict(
            module = "raw",
            args = dict(
                warn = True,
                unique_fact_namespace = "ansible_test_%(inventory_hostname)s"
            )
        ),
        delegate_to = "localhost"
    )
    map = ModuleArgsParser(task_ds=testcase)
    (action, args, delegate_to) = map.parse()
    assert action == "raw"
    assert args == dict(warn=True, unique_fact_namespace="ansible_test_%(inventory_hostname)s")
    assert delegate_to == "localhost"


# Generated at 2022-06-20 23:14:00.891356
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
            'action': 'ping',
            'args': {
            'data': '{{inventory_hostname}}'
            },
            'delegate_to': 'localhost',
            'register': 'my_result'
        }
    # create object
    parser = ModuleArgsParser(task_ds)

    # attempt to parse
    try:
        parser.parse()
    except Exception as err:
        assert False, "fail: parser.parse() should not raise this %s, %s" % (err.__class__.__name__, to_native(err))
        import traceback
        traceback.print_exc()
    else:
        assert True, "success: parser.parse() should not raised an exception"


# Generated at 2022-06-20 23:14:04.483977
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    with pytest.raises(AnsibleAssertionError) as exc:
        ModuleArgsParser(task_ds=None, collection_list=[])
    assert 'should be a dict' in to_text(exc)
    assert 'but is a' in to_text(exc)

# Generated at 2022-06-20 23:14:11.772819
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    result_tuple = args_parser.parse(skip_action_validation=False)
    assert result_tuple[0] == None
    assert result_tuple[1] == dict()
    assert result_tuple[2] == Sentinel
    result_tuple = args_parser.parse(skip_action_validation=False)
    assert result_tuple[0] == None
    assert result_tuple[1] == dict()
    assert result_tuple[2] == Sentinel
    result_tuple = args_parser.parse(skip_action_validation=False)
    assert result_tuple[0] == None
    assert result_tuple[1] == dict()
    assert result_tuple[2] == Sentinel


# Generated at 2022-06-20 23:14:23.920995
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # 123 is not an action parameter, so should be caught and raise an error
    module_args_parser = ModuleArgsParser(task_ds=dict(action=123))
    with pytest.raises(AnsibleParserError, match="unexpected parameter type in action: 'int'"):
        module_args_parser.parse()

    # module: echo hi, is an action parameter
    module_args_parser = ModuleArgsParser(task_ds=dict(action="echo hi"))
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'echo'
    assert args['_raw_params'] == 'hi'
    assert delegate_to is Sentinel

    # module: "{{ echo hello world }}", should pass

# Generated at 2022-06-20 23:14:36.050038
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test for cases below:
        # 1. skip_action_validation = False
        # 2. skip_action_validation = True
        # 3. in case of conflicting action statements
        # 4. case when module name is not found.
        # 5. non-task attributes like name, ignore_errors, async, poll, etc.
        # 6. the module is part of collection
        # 6. action and local_action are mutually exclusive

    # mockup data
    collection_list = ['some_collection', 'other_collection']
    task_ds = dict()
    args = dict()
    delegate_to = dict()
    module_args = dict()

    # 1. skip_action_validation = False
    task_ds = {'module': 'some_module', 'other_param': 'other_param_value'}
    module

# Generated at 2022-06-20 23:14:42.245067
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    # task_ds is an example task structure, with only action, module, and args specified
    task_ds = loader.load_from_file(os.path.join(FIXTURES_PATH, 'parse/task_ds_1.yml'))
    parser = ModuleArgsParser(task_ds=task_ds)
    # get tuple of (action, args, delegate_to) parser.parse()
    parser.parse()
    # test if the returned action is the expected one
    assert parser.action == 'copy'
    # test if the returned args is the expected one
    assert parser.args['src'] == 'A'
    # test if the returned delegate_to is the expected one
    assert parser.delegate_to == 'localhost'


# Generated at 2022-06-20 23:15:48.861696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME -- test this.  But this class is mostly used internally...
    pass

# Generated at 2022-06-20 23:15:50.704187
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    p = ModuleArgsParser()
    assert p is not None
    assert p._task_ds == {}


# Generated at 2022-06-20 23:15:56.686315
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mm = ModuleArgsParser()
    assert mm._task_ds == {}
    assert mm._collection_list == []
    assert 'local_action' in mm._task_attrs
    assert 'static' in mm._task_attrs
    assert 'debug' in mm._task_attrs
    assert 'environment' in mm._task_attrs


# Generated at 2022-06-20 23:16:03.754875
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser._task_attrs == frozenset(['name', 'action', 'local_action', 'args', 'delegate_to', 'with_*',
                                            'module', 'first_available_file', 'first_available_file_root',
                                            'loop', 'until', 'ignore_errors', 'register', 'async', 'poll', 'failed_when',
                                            'changed_when', 'static', 'notify', 'when', 'run_once'])

# Generated at 2022-06-20 23:16:10.325631
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_loader, lookup_loader, action_loader = \
        CachingLoader(), CachingLoader(), CachingLoader()

    module_loader.add_directory(DATA_PATH)
    action_loader.add_directory(DATA_PATH)
    lookup_loader.add_directory(DATA_PATH)

    # action: "ping"
    task_ds = {'action': 'ping'}
    module_arg_parser = ModuleArgsParser(task_ds=task_ds)
    result = module_arg_parser.parse()
    assert result == ('ping', {}, Sentinel)

    # action: "this_is_fake"
    task_ds = {'action': 'this_is_fake'}
    module_arg_parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:16:13.747918
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert_equal(module_args_parser, module_args_parser)


# Generated at 2022-06-20 23:16:17.175276
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(dict(), collection_list=None)
    result = parser.parse()
    assert result is not None
    assert result == ('pwd', {}, None)



# Generated at 2022-06-20 23:16:27.640473
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test "missing action"
    a0 = {'delegate_to': 'localhost'}
    mp0 = ModuleArgsParser(a0)
    assert mp0.parse() == (None, {}, 'localhost')
    # case 1
    a1 = {'action': 'first action',
          'delegate_to': 'localhost'}
    mp1 = ModuleArgsParser(a1)
    assert mp1.parse() == ('first action', {}, 'localhost')
    # case 2
    a2 = {'action': 'first action',
          'delegate_to': 'localhost',
          'with_items': [1, 2, 3]}
    mp2 = ModuleArgsParser(a2)
    assert mp2.parse() == ('first action', {}, 'localhost')
    # case 3