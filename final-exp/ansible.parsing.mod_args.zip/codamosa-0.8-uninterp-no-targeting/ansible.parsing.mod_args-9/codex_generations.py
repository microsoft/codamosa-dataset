

# Generated at 2022-06-20 23:07:12.320017
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(dict(shell='echo hi'), collection_list=['ansible.builtin'])
    assert parser.resolved_action == 'ansible.builtin.shell'
    assert parser.parse() == (u'shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None)

# Generated at 2022-06-20 23:07:25.263296
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DictDataLoader({
        "foo.yml": """
        - hosts: localhost
          tasks:
            - debug: msg={{ bar }}
            - shell: echo {{ bar }}
        """,
    })
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    variable_manager.set_vault_secrets(dict(vault_password='secret'))
    play_context = PlayContext()
    play

# Generated at 2022-06-20 23:07:34.788786
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Construct an object of class ModuleArgsParser
    map = ModuleArgsParser()

    # Test __init__ for class ModuleArgsParser
    assert '_task_ds' in map.__dict__
    assert '_collection_list' in map.__dict__
    assert '_task_attrs' in map.__dict__
    assert 'resolved_action' in map.__dict__

    # Test __init__ for class ModuleArgsParser with no arguments
    map = ModuleArgsParser()
    assert map._task_ds == {}

    # Test __init__ for class ModuleArgsParser with no task_ds
    map = ModuleArgsParser(collection_list=[1, 2, 3, 4])
    assert map._task_ds == {}
    assert map._collection_list == [1, 2, 3, 4]

    # Test __init__ for class Module

# Generated at 2022-06-20 23:07:48.097296
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  script_args = dict(
    action=dict(
      module='command',
      args=dict(
        _raw_params='{{ item.command }}',
        _uses_shell=True,
      ),
      chdir=None,
      creates=None,
      removes=None,
      warns=None,
      executable=None,
      stdin=None,
      stdin_add_newline=False,
      strip_empty_ends=True,
      shell=False,
    ),
    loop=dict(
      _raw_params='{{ command }}',
      _uses_shell=False,
    ),
  )

  script_args_parser = ModuleArgsParser(task_ds=script_args)
  parsed = script_args_parser.parse(skip_action_validation=False)

# Generated at 2022-06-20 23:07:48.871426
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass


# Generated at 2022-06-20 23:07:56.220534
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  task_ds = {
    'name': 'test_task',
    'module': 'stat',
    'args': {
      '_raw_params': '{{stat_path}}',
      'register': 'stat_result',
    },
  }
  parser = ModuleArgsParser(task_ds=task_ds, collection_list=[])
  result = parser.parse()
  # assert result == ('stat', {'register': 'stat_result', '_raw_params': '{{stat_path}}'}, None)
  assert result == ('stat', {'register': 'stat_result', '_raw_params': '{{stat_path}}'}, None)
  import json
  print(json.dumps(result, sort_keys=False, indent=2))

# =============================================================================
# FieldAttribute
# =============================================================================


# Generated at 2022-06-20 23:07:59.465562
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    p = ModuleArgsParser()
    assert isinstance(p, ModuleArgsParser)

    # This is run when the module is loaded, so make sure it is
    # imported properly
    assert isinstance(p, ModuleArgsParser)


# Generated at 2022-06-20 23:08:10.903428
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # pylint: disable=protected-access

    task = dict(action = dict(module = 'shell',
                              args = dict(chdir = '/tmp')))
    parser = ModuleArgsParser(task_ds=task)
    assert parser.resolved_action is None
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert args == dict(chdir = '/tmp')
    assert delegate_to is Sentinel
    assert parser.resolved_action == 'ansible.builtin.shell'

    task = dict(action = dict(module = 'shell',
                              args = dict(chdir = '/tmp',
                                          _raw_params = 'pwd')))
    parser = ModuleArgsParser(task_ds=task)
    action, args, delegate_to = parser.parse()
   

# Generated at 2022-06-20 23:08:12.004279
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert isinstance(parser, object)



# Generated at 2022-06-20 23:08:16.499068
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'echo hi'}, collection_list=None)
    module_args_parser.parse()
    assert module_args_parser._task_ds == {'action': 'echo hi'}
    assert module_args_parser.resolved_action is None


# Generated at 2022-06-20 23:08:26.971827
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass


# Generated at 2022-06-20 23:08:39.661108
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text.converters import to_bool
    from ansible.module_utils.six import PY3
    from .lookup_plugins.yaml_file import LookupModule

    def _find_local_action(mod_args_parser, action, collection_list=None):
        # pylint: disable=unused-argument
        if action == 'local_action_test':
            return 'unit_test_action_local'
        elif action == 'local_test_test':
            return 'unit_test_test_local'
        elif action == 'local_role_test':
            return 'unit_test_role_local'

# Generated at 2022-06-20 23:08:51.333685
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:09:00.375143
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Set up object instance for class ModuleArgsParser
    task_ds = {} # assumption: assuming this is the input
    collection_list = None # assumption: assuming this is the input
    module_args_parser_instance = ModuleArgsParser(task_ds, collection_list)

    # Call method parse of class ModuleArgsParser
    method_parse_output = module_args_parser_instance.parse()
    # Assert return value of method parse of class ModuleArgsParser
    method_parse_expected = ()
    assert method_parse_output == method_parse_expected
# END class ModuleArgsParser



# Generated at 2022-06-20 23:09:05.355932
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'copy src=a dest=b'}
    module_arg_parser = ModuleArgsParser(task_ds)
    module_arg_parser.parse()

if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main(["-k", __file__]))

# Generated at 2022-06-20 23:09:12.288146
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test cases:

    # 1. module name, note that the module name is specified
    # with "action"
    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    # (module_name, args, delegate_to) = parser.parse()
    assert parser.parse() == ('shell',
                              {'_raw_params': 'echo hi',
                               '_uses_shell': True},
                              None)

    # 2. delegate_to
    task_ds = dict(local_action='shell echo hi')
    parser = ModuleArgsParser(task_ds)
    # (module_name, args, delegate_to) = parser.parse()

# Generated at 2022-06-20 23:09:19.513193
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'name={{ x }}',
        'args': {'state': 'present'}}

    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'name'
    assert args['state'] == 'present'
    assert 'x' in args['_raw_params']
    assert delegate_to is Sentinel


# Generated at 2022-06-20 23:09:25.208657
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'shell echo hi'}
    task = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = task.parse()

    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel


# Generated at 2022-06-20 23:09:37.397670
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # create ModuleArgsParser object
    module_args_parser = ModuleArgsParser()

    # test the function _split_module_string()
    test_module_string = "copy src=a dest=b"
    split_module_string_result = ('copy', 'src=a dest=b')
    assert module_args_parser._split_module_string(test_module_string) == split_module_string_result

    # test the function _normalize_parameters()
    # test 1
    test_thing = "echo hi"
    test_action = 'shell'
    test_additional_args = "args='hi'"
    _, normalize_parameters_result = module_args_parser._normalize_parameters(test_thing, test_action, test_additional_args)
    assert normalize_parameters_result

# Generated at 2022-06-20 23:09:49.718659
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task

    parser = ModuleArgsParser(task_ds=None)
    assert isinstance(parser, ModuleArgsParser)

    parser = ModuleArgsParser()
    assert isinstance(parser, ModuleArgsParser)

    with pytest.raises(AnsibleAssertionError) as exc:
        parser = ModuleArgsParser(task_ds=[])
    assert to_text(exc.value) == "the type of 'task_ds' should be a dict, but is a <class 'list'>"

    parser = ModuleArgsParser()
    assert isinstance(parser._task_attrs, frozenset)
    for element in Task._valid_attrs:
        assert element in parser._task_attrs

    for element in set(['local_action', 'static']):
        assert element in parser._task_att

# Generated at 2022-06-20 23:10:08.515588
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {}
    obj = ModuleArgsParser(ds)
    assert ds == obj._task_ds
    assert obj._collection_list is None
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    assert obj._task_attrs == set(Task._valid_attrs.keys()).union(Handler._valid_attrs.keys()).union(['static', 'local_action'])

    ds = {'test': 'value'}
    obj = ModuleArgsParser(ds, ['collection_list'])
    assert ds == obj._task_ds
    assert obj._collection_list == ['collection_list']

# Generated at 2022-06-20 23:10:13.008073
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    actual = module_args_parser.parse()
    assert expected == actual
# test_ModuleArgsParser_parse()

# Generated at 2022-06-20 23:10:27.278659
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'delegate_to': 'localhost',
        'args': {'x': 'y'},
        'tags': ['tag1', 'tag2'],
        'local_action': 'shell echo hi',
        'when': 'true',
        'register': 'var',
        'with_items': ['a', 'b', 'c'],
        'with_dict': {'x': 'y'},
    }

    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    task_ds['local_action'] = 'shell'
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('shell', {}, 'localhost')


# Generated at 2022-06-20 23:10:36.924867
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(dict()).parse()

    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(dict(no_module='xyz')).parse()

    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(dict(action='xyz')).parse()

    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(dict(action='shell', local_action='xyz')).parse()

    assert ModuleArgsParser(dict(action='shell')).parse() == ('shell', {}, None)

    result = ModuleArgsParser(dict(action='shell', args=dict(no_log=True))).parse()
    assert result[0] == 'shell'

# Generated at 2022-06-20 23:10:49.437640
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    import os
    import tempfile
    import subprocess
    import traceback
    import sys
    import json

    # Generate test data
    loader, inventory, variable_manager = mock_loader()

    task_ds = dict()
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == dict()
    assert delegate_to is None

    task_ds = dict()
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

# Generated at 2022-06-20 23:10:54.087201
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # kwargs for class ModuleArgsParser
    task_ds = {}
    collection_list = None

    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    # from source
    try:
        res = obj.parse()
        raise AssertionError("No exception was raised")
    except AnsibleParserError as e:
        assert "no module/action detected in task." in to_native(e)
    # from source

    # kwargs for class ModuleArgsParser
    task_ds = {
        "action": "copy",
        "args": {"src": "a", "dest": "b"}
    }
    collection_list = None

    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    # from source
    res = obj

# Generated at 2022-06-20 23:11:03.411433
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Standard YAML form for command-type modules.
    testcase = {'args': {'chdir': '/tmp'}, 'command': 'pwd'}
    obj = ModuleArgsParser(task_ds=testcase)
    assert obj._task_ds == testcase
    assert obj._collection_list == None

    testcase_copy = {'copy': {'src': 'a', 'dest': 'b'}}
    obj_copy = ModuleArgsParser(task_ds=testcase_copy)
    assert obj_copy._task_ds == testcase_copy
    assert obj_copy._collection_list == None

    return True



# Generated at 2022-06-20 23:11:15.630269
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict()
    module_args_parser = ModuleArgsParser(task_ds=ds)

    ds = dict()
    ds['action'] = 'copy src=a dest=b'
    module_args_parser = ModuleArgsParser(task_ds=ds)

    ds = dict()
    ds['action'] = dict()
    ds['action']['module'] = 'copy src=a dest=b'
    module_args_parser = ModuleArgsParser(task_ds=ds)

    ds = dict()
    ds['action'] = dict()
    ds['action']['module'] = 'copy'
    ds['action']['args'] = dict()
    ds['action']['args']['src'] = 'a'

# Generated at 2022-06-20 23:11:24.506859
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test dict with delegated action
    ds = dict(action = dict(module = 'shell', args = 'echo hello'), delegate_to = 'remotehost')
    parser = ModuleArgsParser(task_ds = ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'shell'
    assert isinstance(args, dict)
    assert args['args'] == 'echo hello'
    assert delegate_to == 'remotehost'
    # test dict with action
    ds = dict(action = dict(module = 'ping'))
    parser = ModuleArgsParser(task_ds = ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert isinstance(args, dict)
    assert len(args) == 0
    assert delegate_to is None

# Generated at 2022-06-20 23:11:38.485928
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds0 = {"action": "shell echo hi"}
    ds1 = {"local_action": "shell echo hi"}
    ds2 = {"shell": "echo hi"}
    ds3 = {"module": "shell", "args": "echo hi"}
    ds4 = {"copy": {"src": "a", "dest": "b"}}
    ds5 = {"copy": "src=a dest=b"}
    ds6 = {"copy": None}
    ds7 = {"ec2": "region=xyz"}
    ds8 = {"ec2": {"region": "xyz"}}
    ds9 = {"ec2": None}
    ds10 = {"ec2": {"region": "xyz", "args": "instance_type=m1.xlarge"}}

# Generated at 2022-06-20 23:11:53.212842
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args_parser = ModuleArgsParser({'action': 'shell echo hi'})
    args = args_parser.parse(skip_action_validation=True)
    assert args == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    args_parser = ModuleArgsParser({'action': 'shell', 'args': 'echo hi'})
    args = args_parser.parse(skip_action_validation=True)
    assert args == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    args_parser = ModuleArgsParser({'action': '', 'args': 'echo hi'})
    args = args_parser.parse(skip_action_validation=True)

# Generated at 2022-06-20 23:12:04.135152
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test for the constructor of class ModuleArgsParser.
    '''

    with pytest.raises(AnsibleAssertionError) as excinfo:
        mp = ModuleArgsParser(task_ds=None)
    assert 'dict' in to_native(excinfo.value)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        mp = ModuleArgsParser(task_ds=1)
    assert 'dict' in to_native(excinfo.value)

# Unit tests for the _split_module_string method of class ModuleArgsParser

# Generated at 2022-06-20 23:12:14.905081
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    action, args, delegate_to = parser.parse({'action': 'shell', 'args': 'ls'})
    assert action == 'shell'
    assert args == {'args': 'ls'}
    assert delegate_to is 'None'

    action, args, delegate_to = parser.parse({'action': {'module': 'shell', 'args': 'ls'}})
    assert action == 'shell'
    assert args == {'args': 'ls'}
    assert delegate_to is 'None'

    action, args, delegate_to = parser.parse({'action': 'shell ls'})
    assert action == 'shell'
    assert args == {'args': 'ls'}
    assert delegate_to is 'None'


# Generated at 2022-06-20 23:12:27.473072
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    parser = ModuleArgsParser(dict(action=dict(module='shell', args='echo hi'), delegate_to='localhost'))
    assert parser.parse() == ('shell', dict(args='echo hi', _raw_params='echo hi'), 'localhost')
    parser = ModuleArgsParser(dict(action=dict(module='shell', args='echo hi')))
    assert parser.parse() == ('shell', dict(args='echo hi', _raw_params='echo hi'), None)
    parser = ModuleArgsParser(dict(action='shell echo hi'))
    assert parser.parse() == ('shell', dict(_raw_params='echo hi'), None)

# Generated at 2022-06-20 23:12:35.977009
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Just test that the class can be constructed (and nothing else)
    ansible_module_argument_spec = dict(
        name=dict(type='str', required=True),
        new=dict(type='bool', required=True, default=False)
    )
    module_name_or_path = 'FooModule'
    module_args = 'my_arg=1'

    args_parser = ModuleArgsParser(ansible_module_argument_spec, module_name_or_path, module_args)
    assert isinstance(args_parser, ModuleArgsParser)


# Generated at 2022-06-20 23:12:39.612613
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser({"local_action": "shell echo hi"}, collection_list=None)
    result = m.parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')



# Generated at 2022-06-20 23:12:43.298870
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'local_action':'copy src=a dest=b', 'delegate_to':'localhost'}
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()
    assert action == 'copy'
    assert args == {'src': 'a', 'dest': 'b'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-20 23:12:55.655595
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def get_test_obj(task_ds):
        return ModuleArgsParser(task_ds).parse(skip_action_validation=True)

    # ds with just action name
    task_ds = dict(action='debug')
    res = get_test_obj(task_ds)
    assert res == ('debug', {}, Sentinel)

    # ds with module name and args
    task_ds = dict(action=dict(module='debug', msg='Hello'))
    res = get_test_obj(task_ds)
    assert res == ('debug', dict(msg='Hello'), Sentinel)

    task_ds = dict(action='shell echo hi')
    res = get_test_obj(task_ds)
    assert res == ('shell', dict(_raw_params='echo hi'), Sentinel)


# Generated at 2022-06-20 23:13:03.082880
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # should not raise AnsibleAssertionError
    parser = TaskResultInclude()

    # should raise AnsibleAssertionError if task_ds is not a dict
    task_ds = "a string type"
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds)

# Generated at 2022-06-20 23:13:11.501663
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Basic function
    task_ds = dict(action=dict(module='test', args='test'))
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('test', {}, None)
    task_ds = dict(action='test test')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('test', {}, None)
    task_ds = dict(test='test')
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('test', {}, None)
    task_ds = dict()
    parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError) as exc:
        parser.parse()
    assert exc.value.message

# Generated at 2022-06-20 23:13:17.430010
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Simple test, constructor
    p = ModuleArgsParser()
    assert p is not None

# Generated at 2022-06-20 23:13:30.591227
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test case 1
    t = ModuleArgsParser({'action': 'shell echo hi'})
    assert t.parse() == ('shell', {u'_raw_params': u'echo hi'}, Sentinel)
    assert t.resolved_action is None

    # test case 2
    test_case = {'action': 'unknown_plugin arg'}
    t = ModuleArgsParser(test_case)
    try:
        t.parse()
    except AnsibleParserError as e:
        expected = "couldn't resolve module/action 'unknown_plugin'. This often indicates a misspelling, missing collection, or incorrect module path."
        assert str(e) == expected
    else:
        assert False

    # test case 3

# Generated at 2022-06-20 23:13:41.499017
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    loader = DataLoader()
    # Test canonicalization of simple args form with module name
    for inp in ('pwd', {'module': 'pwd'}):
        result = ModuleArgsParser(task_ds=inp).parse()
        assert result == ('command', {}, None), "canonicalized [%s] to [%s]" % (inp, result)
    # Test canonicalization of simple args form without module name
    inp = 'shell pwd'
    result = ModuleArgsParser(task_ds=inp).parse()
    assert result == ('shell', {'_raw_params': 'pwd'}, None), "canonicalized [%s] to [%s]" % (inp, result)

    # Test canonicalization of simple args form with '_raw_params' and module name

# Generated at 2022-06-20 23:13:42.720616
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser().parse(skip_action_validation=False)
    assert not result


# Generated at 2022-06-20 23:13:44.629075
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    p = ModuleArgsParser()
    assert p


# Generated at 2022-06-20 23:13:45.727498
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser()
    assert module_parser


# Generated at 2022-06-20 23:13:57.706628
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args = dict(
        {'package': 'tmux'},
        state='latest',
        name='tmux'
    )
    assert ModuleArgsParser._normalize_new_style_args(module_args, 'package') == dict(
        {'package': 'tmux'},
        state='latest',
        name='tmux'
    ) is not None

    assert ModuleArgsParser._normalize_new_style_args(dict(
        module='command chdir=/home/user',
    ), 'command') == dict(
        args='chdir=/home/user'
    ) is not None

    assert ModuleArgsParser._normalize_new_style_args(dict(
        module='command chdir=/home/user',
    ), 'command') == dict(
        args='chdir=/home/user'
    )

# Generated at 2022-06-20 23:14:02.449560
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    obj = ModuleArgsParser(
        task_ds=task_ds,
        collection_list=collection_list
    )

    # ModuleArgsParser._parse is private method, can't call it
    # res = obj._parse()
    # assert False

# Generated at 2022-06-20 23:14:10.665625
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test for parse w/o arg, check if returns correctly
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    parser = ModuleArgsParser(task_ds={})
    assert parser.parse() == (None, {}, None), 'parse() should return (None, {}, None)'

    # Test for parse with module: <stuff>, action conflict
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task_ds = dict(module='test_module')
    parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:14:22.944422
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task

    # There is no delegate_to in task_ds
    task_ds = {'action': {'module': 'shell', 'args': 'echo hello'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {'args': 'echo hello'}, None)

    # There is no delegate_to in task_ds
    task_ds = {'action': {'module': 'command', 'args': 'pwd'}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('command', {'args': 'pwd'}, None)

    # delegate_to is in task_ds

# Generated at 2022-06-20 23:14:39.429609
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert isinstance(module_args_parser, ModuleArgsParser)



# Generated at 2022-06-20 23:14:45.395923
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    task_ds = {
        'action': {
            'module': 'command',
            'args': 'whoami'
        }
    }
    module_args_parser = ModuleArgsParser(loader, task_ds, collection_list=None)
    assert module_args_parser is not None
    module_args_parser = ModuleArgsParser(loader, task_ds, collection_list=None)
    assert module_args_parser is not None


# Unit tests for parse() function

# Generated at 2022-06-20 23:14:51.770260
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    plugin_path = os.path.join(os.path.dirname(__file__), 'action_plugins')
    module_path = os.path.join(os.path.dirname(__file__), 'modules')
    action_loader.add_directory(plugin_path)
    module_loader.add_directory(module_path)

    task_ds = {
        'name': 'test',
        'action': 'my_test_module param1=var1,param2=var2',
        'args': {'param3': 'var3'},
        'register': 'v1',
        'with_items': 'list'
    }
    action, args, delegate_to = ModuleArgsParser(task_ds).parse()

    assert action == 'my_test_module'

# Generated at 2022-06-20 23:15:03.976706
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:15:12.705215
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils import to_bytes

    # Create a test class to mock 'ansible.module_utils.common.collections.ImmutableDict'
    # and 'ansible.utils.to_bytes'
    class MockClass():
        pass

    mock_ImmutableDict = MockClass()
    mock_ImmutableDict.return_value = {}

    mock_to_bytes = MockClass()
    mock_to_bytes.return_value = b'bytes'

    # Save the original implementations
    orig_ImmutableDict = ansible.module_utils.common.collections.ImmutableDict
    orig_to_bytes = ansible.utils.to_bytes

    # Mock the methods
    ansible.module_utils.common.collections

# Generated at 2022-06-20 23:15:16.842928
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # we have to have an initialized config to test this in
    init_config()
    p = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    thing = p.parse()[0]
    assert thing == 'shell'

# Generated at 2022-06-20 23:15:28.239446
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser({'action': 'ec2 x=1 y=2'})
    assert parser._task_ds == {'action': 'ec2 x=1 y=2'}
    assert parser._collection_list is None

    # action and local_action are mutually exclusive
    parser = ModuleArgsParser({'action': 'shell', 'local_action': 'shell'})
    raises(AnsibleParserError, 'parser._normalize_old_style_args(parser._task_ds)', globals(), locals())
    raises(AnsibleParserError, 'parser._normalize_new_style_args(parser._task_ds.get("local_action"), "shell")', globals(), locals())

    # only one of action, module, or local_action is allowed

# Generated at 2022-06-20 23:15:36.728139
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # test raw=True
    task_ds_dict = { "template": "this is a 'raw' string" }
    expected_action = "template"
    expected_args = { "src": "'this is a 'raw' string'", "raw": True }
    expected_delegate_to = None
    actual_action, actual_args, actual_delegate_to = ModuleArgsParser(task_ds=task_ds_dict).parse()
    assert actual_action == expected_action
    assert actual_args == expected_args
    assert actual_delegate_to == expected_delegate_to

    # test raw=False
    task_ds_dict = { "template": "src=this is not a 'raw' string" }
    expected_action = "template"

# Generated at 2022-06-20 23:15:49.813312
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    mod_args_parser = ModuleArgsParser()

    # tests for action: string
    assert (mod_args_parser._normalize_old_style_args("copy src=a dest=b") == ('copy', dict(src='a', dest='b')))

    # tests for action: dict
    assert (mod_args_parser._normalize_old_style_args(dict(copy=dict(src='a', dest='b'))) == ('copy', dict(src='a', dest='b')))

# Generated at 2022-06-20 23:15:59.665046
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from collections import namedtuple
    Module = namedtuple('Module', 'name')

    module_loader = Mock()
    module_loader.find_plugin.return_value = Module('yum')
    action_loader = Mock()
    action_loader.find_plugin.return_value = None
    loader = Mock()
    loader.action_loader = action_loader
    loader.module_loader = module_loader
    module_parser = ModuleArgsParser(task_ds={'shell': 'ls'})
    module_parser.parse()
    assert_equal(module_loader.find_plugin.call_count, 1)
