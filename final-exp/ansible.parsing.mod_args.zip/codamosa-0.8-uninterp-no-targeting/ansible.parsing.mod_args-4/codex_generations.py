

# Generated at 2022-06-20 23:06:58.842442
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    config = dict(
        action=dict(
            local_action=dict(
                module=dict(
                    _raw_params='echo hi'), _uses_shell=True, _raw_params='echo hi', _uses_shell=True),
            module=dict(
                _raw_params='echo hi', _uses_shell=True)),
        delegate_to=Sentinel,
        args=dict())
    task_ds = dict()
    module_args_parser = ModuleArgsParser(config)
    action, args, delegate_to = module_args_parser.parse()
    assert (action == 'echo')
    assert (isinstance(args, dict))
    assert (delegate_to == 'localhost')

# Generated at 2022-06-20 23:07:09.783348
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m_parser = ModuleArgsParser()
    ###############################################
    # The task_ds dictionary is parsed as follows: #
    #                                              #
    # The 'normal' form: task:                      #
    #                                              #
    #   X:                                         #
    #     module: cmd                              #
    #     args:                                    #
    #       arg1: value1                           #
    #                                              #
    # This is equivalent to:                       #
    #                                              #
    #   X:                                         #
    #     cmd arg1=value1                          #
    #                                              #
    #                                              #
    # Another equivalent form:                     #
    #                                              #
    #   X:                                         #
    #     cmd:                                     #
    #       arg1: value

# Generated at 2022-06-20 23:07:14.614727
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:07:26.885822
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # FIXME: re-write parameterized tests for new parsing
    raise SkipTest
    # These are the examples from the comment docstring for the parse() method
    # of the ModuleArgsParser class

# Generated at 2022-06-20 23:07:35.733258
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_host_string = 'testhost'
    test_unreachable_host_string = 'testhost'
    test_module_name = 'test_module_name'
    test_ds = {
        '_ansible_verbosity': 0,
        '_raw_params': 'test_raw_params',
        '_uses_shell': True,
        '_ansible_no_log': False,
        'action': 'testaction',
        'local_action': 'testlocalaction',
        'local_action': 'testlocalaction'
    }

    # parse() raises AnsibleParserError
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(task_ds=dict()).parse()

    # parse() raises AnsibleParserError with invalid module name

# Generated at 2022-06-20 23:07:48.973319
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    importer = TestAnsibleModuleImporter()

    with importer:
        task_ds = dict(action=dict(module='setup', fact_path='/tmp'), local_action='shell echo hi')
        parser = ModuleArgsParser(task_ds=task_ds)
        assert parser.parse() == ('setup', dict(fact_path='/tmp'), 'localhost')

        task_ds = dict(action=dict(module='setup', fact_path='/tmp'), local_action='shell echo hi')
        parser = ModuleArgsParser(task_ds=task_ds)
        assert parser.parse() == ('setup', dict(fact_path='/tmp'), 'localhost')

        task_ds = dict(action=dict(module='shell', echo='hello', when='test'))
        parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:07:59.340890
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    This is a unit test for the constructor of class ModuleArgsParser.
    It tests the following cases:
    - task_ds is None.  Should raise AnsibleAssertionError.
    - task_ds is not a dictionary.  Should raise AnsibleAssertionError.
    """
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    # test task_ds is None
    with pytest.raises(AnsibleAssertionError) as excinfo:
        ModuleArgsParser(task_ds=None)
    assert to_text(excinfo.value).startswith("the type of 'task_ds' should be a dict")

    # test task_ds is not a dictionary

# Generated at 2022-06-20 23:08:08.464782
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module = "win_license"
    task_ds = {
            module: "src={{license_file}} state={{license_state}}",
            "delegate_to": "localhost",
            "register": "license_result"
            }

    # create ModuleArgsParser instance and invoke method parse
    args = ModuleArgsParser(task_ds=task_ds).parse()
    assert args[0] == module
    assert args[1]['state'] == '{{license_state}}'
    assert args[1]['src'] == '{{license_file}}'
    assert args[2] == 'localhost'


# Generated at 2022-06-20 23:08:09.575779
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module = ModuleArgsParser()
    assert module

# Generated at 2022-06-20 23:08:17.095471
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:08:40.799779
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser != None
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert module_args_parser != None
    module_args_parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert module_args_parser != None
    module_args_parser = ModuleArgsParser(task_ds={}, collection_list=['ansible.builtin'])
    assert module_args_parser != None
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert module_args_parser != None
    module_args_parser = ModuleArgsParser(task_ds={'action': 'shell echo hi', 'local_action': 'shell echo hi'})
   

# Generated at 2022-06-20 23:08:41.883555
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert(True)


# Generated at 2022-06-20 23:08:53.968220
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    # TODO: make this a unit test
    """
    thing = {'action': {'module': 'one', 'x': '1'}}
    x = ModuleArgsParser(thing)
    action, args, delegate_to = x.parse()
    assert action == 'one'
    assert args == dict(x='1')
    assert delegate_to is None
    assert x.resolved_action is None

    thing = {'action': 'one {{x}}'}
    x = ModuleArgsParser(thing)
    action, args, delegate_to = x.parse()
    assert action == 'one'
    assert args == dict(_variable_params='{{x}}')
    assert delegate_to is None
    assert x.resolved_action is None


# Generated at 2022-06-20 23:09:05.682179
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    # empty task, no local_action, no action
    task_ds = {'name': 'test'}
    my_task_include = TaskInclude()
    my_task_include.args = {'task': task_ds}
    my_task_include.vars = {}
    my_task_include.defaults = {}
    my_task_include.post_validate(templar=None, shared_loader_obj=None)
    my_module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = my_module_args_parser.parse()
    assert action is None
    assert args is None
    assert delegate_to == Sentinel
    # no local_action, no action, parameter set to

# Generated at 2022-06-20 23:09:16.995824
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    local_action = {
        'local_action': 'command whoami'
    }

    action = {
        'action': 'command whoami'
    }

    module = {
        'shell': 'echo "foo"'
    }

    # Test that ModuleArgsParser() raises
    # AnsibleAssertionError with non-dict value
    with pytest.raises(AnsibleAssertionError):
        p = ModuleArgsParser(task_ds="not-a-dict")

    # Test that ModuleArgsParser() raises
    # AnsibleParserError with invalid action
    with pytest.raises(AnsibleParserError):
        p = ModuleArgsParser(task_ds=local_action)

    # Test that ModuleArgsParser() raises
    # AnsibleParserError with invalid action

# Generated at 2022-06-20 23:09:18.364319
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-20 23:09:28.697864
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {'name': 'test1', 'module': 'file', 'args': {'path': '/tmp/test1', 'state': 'directory'}}
    parser = ModuleArgsParser(ds)
    action, args, delegate_to = parser.parse()
    assert_equal(action, 'file')
    assert_equal(args, {'path': '/tmp/test1', 'state': 'directory'})
    assert_equal(delegate_to, None)

    ds = {'name': 'test2', 'module': 'command', 'args': {'_raw_params': 'uname -a'}}
    parser = ModuleArgsParser(ds)
    action, args, delegate_to = parser.parse()
    assert_equal(action, 'command')

# Generated at 2022-06-20 23:09:36.108265
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # ARRANGE
    ds = {
        "action": {
            "module": "fireball",
            "with_right_hand": "-3.0"
        },
        "with_left_hand": "0.0",
    }

    # ACT
    obj = ModuleArgsParser(ds)

    # ASSERT
    assert obj._task_ds == ds
    assert obj._collection_list is None



# Generated at 2022-06-20 23:09:48.595753
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(
        module='shell',
        args=dict(
            creates=['/path/foo.txt', '/path/bar.txt']
        )
    )
    parser = ModuleArgsParser(task_ds, collection_list=None)
    result = parser.parse()
    assert result == ('shell', {'creates': ['/path/foo.txt', '/path/bar.txt']}, None), (result, ('shell', {'creates': ['/path/foo.txt', '/path/bar.txt']}, None))

    task_ds = dict(
        action='copy',
        args={'src': 'a', 'dest': 'b'}
    )
    parser = ModuleArgsParser(task_ds, collection_list=None)
    result = parser.parse()

# Generated at 2022-06-20 23:09:56.275822
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert ModuleArgsParser(task_ds={'action': 'echo hi'}).parse()[0] == 'echo'
    assert ModuleArgsParser(task_ds={'action': 'shell echo hi'}).parse()[0] == 'shell'
    assert ModuleArgsParser(task_ds={'myaction': 'echo hi'}).parse()[0] == 'myaction'
    assert ModuleArgsParser(task_ds={'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}).parse()[0] == 'copy'
    assert ModuleArgsParser(task_ds={'action': {'module': 'shell', 'args': 'echo hi'}}).parse()[0] == 'shell'

# Generated at 2022-06-20 23:10:07.899906
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    tp = TaskInclude(None)
    tp._task = dict()
    tap = ModuleArgsParser(tp._task)
    # TODO
    pass

# Generated at 2022-06-20 23:10:18.825694
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import sys
    import inspect
    import os

    from ansible.errors import AnsibleParserError
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import RESERVED_TASK_VARS

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.plugins.loader import action_loader

# Generated at 2022-06-20 23:10:23.389642
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_lookup = dict(action=dict(module='shell', args="echo foo"), delegate_to='localhost', register='register_result')
    parser = ModuleArgsParser(task_ds=test_lookup)
    assert parser is not None


# Generated at 2022-06-20 23:10:30.406317
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'shell echo hi',
        'delegate_to': 'localhost',
        'args': {
            'chdir': '/tmp'
        }
    }

    obj = ModuleArgsParser(task_ds)
    assert obj is not None
    assert obj._task_ds
    assert obj._task_attrs
    assert obj.resolved_action is None


# Generated at 2022-06-20 23:10:38.354620
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'},
               'args': {'src': 'a', 'dest': 'b'}}
    module_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_parser.parse()
    assert action == 'copy'
    assert args  == {'src': 'a', 'dest': 'b'}
    assert delegate_to == None

    task_ds = {'action': 'copy src=a dest=b'}
    module_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_parser.parse()
    assert action == 'copy'

# Generated at 2022-06-20 23:10:43.293503
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor without params
    parser = ModuleArgsParser()
    assert parser._task_attrs is not None

    # Constructor with params
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser._task_attrs is not None



# Generated at 2022-06-20 23:10:47.306527
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # make sure constructor takes only task_ds as a parameter
    with pytest.raises(TypeError):
        ModuleArgsParser(task_ds=None, collection_list=None, something_else=None)

# Generated at 2022-06-20 23:10:58.755789
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()
    # Test the constructor of class ModuleArgsParser
    obj_ModuleArgsParser = ModuleArgsParser(task_ds)
    assert isinstance(obj_ModuleArgsParser, ModuleArgsParser)
    assert hasattr(obj_ModuleArgsParser, '_task_ds')
    assert obj_ModuleArgsParser._task_ds == dict()
    assert not hasattr(obj_ModuleArgsParser, '_collection_list')

    obj_ModuleArgsParser = ModuleArgsParser(task_ds, collection_list=['name1', 'name2'])
    assert hasattr(obj_ModuleArgsParser, '_collection_list')
    assert obj_ModuleArgsParser._collection_list == ['name1', 'name2']

    # Test whether the constructor of ModuleArgsParser raises the correct exception

# Generated at 2022-06-20 23:11:02.548537
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert isinstance(parser._task_ds, dict)
    assert isinstance(parser._task_attrs, frozenset)
    assert isinstance(parser._collection_list, (list, type(None)))

# Generated at 2022-06-20 23:11:13.795604
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ################################################################################
    # This tests the ability to parse out the information but does not test the
    # ability to actually execute the task against a host.
    ################################################################################
    # Create a local copy of argv
    argv = sys.argv
    sys.argv = [argv[0]]
    # Create a local copy of the environment variable
    old_ANSIBLE_NOCOLOR = os.environ.get('ANSIBLE_NOCOLOR', None)
    if old_ANSIBLE_NOCOLOR:
        del os.environ['ANSIBLE_NOCOLOR']
    # Create a local copy of the ansible config file
    old_ANSIBLE_CONFIG = os.environ.get('ANSIBLE_CONFIG', None)
    if old_ANSIBLE_CONFIG:
        del os

# Generated at 2022-06-20 23:11:34.127732
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test case 1: valid type of input
    '''
    task_ds = {}
    m = ModuleArgsParser(task_ds)
    assert m is not None, "Construction of the class ModuleArgsParser failed"

    '''
    Test case 2: invalid type of input
    '''
    try:
        task_ds = []
        m = ModuleArgsParser(task_ds)
    except AnsibleAssertionError as e:
        assert "the type of 'task_ds' should be a dict, but is a " in str(e), "Error message is expected"
    else:
        assert False, "AnsibleAssertionError is expected"

    '''
    Test case 3: normalize_parameters with invalid type of thing
    '''

# Generated at 2022-06-20 23:11:46.262956
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    task_ds = {
        'meta': {},
        'task': 'task1',
        'name': 'task1',
        'action': 'command',
        'args': {'chdir': '/tmp'}
    }
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = parser.parse()
    assert action == 'command'
    assert args['chdir'] == '/tmp'
    assert delegate_to == Sentinel

    # form is like: {'module': 'ec2', 'x': 1}
    task_ds['action'] = {'module': 'ec2', 'x': 1}
    action, args, delegate_to = parser.parse()
    assert action == 'ec2'
   

# Generated at 2022-06-20 23:11:49.265495
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    result = { 'action': None, 'args': {}, 'delegate_to': None }
    assert module_args_parser.parse() == result


# Generated at 2022-06-20 23:12:00.918888
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # no valid task_ds
    args_list = [
        [[], None],
        [{}, None],
        [{'action': None}, None],
        [{'action': []}, None],
        [{'action': ''}, None],
        [{'action': {}}, None],
        [{'delegate_to': None}, None],
        [{'delegate_to': []}, None],
        [{'delegate_to': ''}, None],
        [{'delegate_to': {}}, None],
        [{'action': 'test'}, None],
        [{'delegate_to': 'test'}, None],
    ]

    obj = ModuleArgsParser()

# Generated at 2022-06-20 23:12:03.807244
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor of ModuleArgsParser
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None



# Generated at 2022-06-20 23:12:14.690129
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parse = ModuleArgsParser().parse

# Generated at 2022-06-20 23:12:21.953999
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    p = ModuleArgsParser({'action': 'shell echo hi'})
    assert p._task_ds == {'action': 'shell echo hi'}
    assert p._collection_list is None

    p = ModuleArgsParser({'action': 'shell echo hi'}, collection_list=['a', 'b'])
    assert p._task_ds == {'action': 'shell echo hi'}
    assert p._collection_list == ['a', 'b']

# Generated at 2022-06-20 23:12:24.417709
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    try:
        ModuleArgsParser()
    except Exception as e:
        pytest.fail("constructor ModuleArgsParser failed: " + to_native(e))

# Generated at 2022-06-20 23:12:27.301857
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = ModuleArgsParser(task_ds="test")
    module_args.parse()
    assert True == False


# Generated at 2022-06-20 23:12:38.437530
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': '{{ ds }}', 'args': {'b': 1}, 'delegate_to': '{{ o }}'}, collection_list=[])
    assert parser.parse() == ('{{ ds }}', {'b': 1}, '{{ o }}')

    parser = ModuleArgsParser(task_ds={'action': '{{ ds }}', 'args':  '{{ o }}'}, collection_list=[])
    assert parser.parse() == ('{{ ds }}', {'_variable_params': '{{ o }}'}, None)
    parser = ModuleArgsParser(task_ds={'action': {'module': '{{ ds }}', 'b': 1}, 'args':  '{{ o }}'}, collection_list=[])

# Generated at 2022-06-20 23:13:03.196974
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext

    res = None
    task = AnsibleMapping()

    # Testing with empty task
    parser = ModuleArgsParser(task.items(), None)
    res = parser.parse()
    assert res == ('', dict(), Sentinel), 'Expected: (\'\', {}, {}), Got: %s' % str(res)

    # Testing with task without action
    task.update({'some_key': 'some_value'})
    parser = ModuleArgsParser(task.items(), None)

# Generated at 2022-06-20 23:13:11.614313
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg_parser = ModuleArgsParser(dict(action=dict(module='debug', var='hi'), delegate_to='localhost'))
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'debug'
    assert args == dict(var='hi')
    assert delegate_to == 'localhost'

    module_arg_parser = ModuleArgsParser(dict(action='debug var=hi'))
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'debug'
    assert args == dict(var='hi')
    assert delegate_to is None

    module_arg_parser = ModuleArgsParser(dict(action='debug', var='hi'))
    action, args, delegate_to = module_arg_parser.parse()
    assert action == 'debug'
    assert args

# Generated at 2022-06-20 23:13:16.489899
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'name': 'test task', 'action': 'copy', 'args': {'src': '/tmp/test', 'dest': '/tmp/test2'}}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'src': '/tmp/test', 'dest': '/tmp/test2'}, None), \
        "Expected: ('copy', {'src': '/tmp/test', 'dest': '/tmp/test2'}, None), Got: (%s, %s, %s)" % (
            str(parser.parse()[0]), str(parser.parse()[1]), str(parser.parse()[2]))

    task_ds = {'name': 'test task', 'action': 'shell', 'args': 'cat /tmp/test'}

# Generated at 2022-06-20 23:13:29.893512
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    t = \
    {
        "action": { "module": "shell", "args": "echo hi" },
        "delegate_to": "xyz"
    }

    expected = ('shell', { 'args': 'echo hi' }, 'xyz')
    result = ModuleArgsParser(task_ds=t).parse()
    assert result == expected

    t = \
    {
        "action": "shell echo hi",
        "delegate_to": "xyz"
    }

    expected = ('shell', { 'args': 'echo hi' }, 'xyz')
    result = ModuleArgsParser(task_ds=t).parse()
    assert result == expected


# Generated at 2022-06-20 23:13:31.223371
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass # TODO: implement your test here


# Generated at 2022-06-20 23:13:41.831749
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler


# Generated at 2022-06-20 23:13:48.503488
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method ModuleArgsParser.parse
    '''
    ds = dict()
    ds['action'] = 'copy'
    ds['args'] = 'src=/tmp/hosts dest=/etc/hosts'
    ds['delegate_to'] = 'localhost'
    task = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = task.parse()
    assert action == 'copy'
    assert args == {'src': '/tmp/hosts', 'dest': '/etc/hosts'}
    assert delegate_to == 'localhost'


# Generated at 2022-06-20 23:13:58.282773
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(action="copy source=/tmp/foo dest=/tmp/bar",
              delegate_to="localhost",
              with_items="{{ servers }}",
              local_action="shell echo hi",
              when="ansible_distribution == 'Ubuntu'",
              become=True,
              become_method="sudo",
              become_user="root")

    # create object and call parse()
    instance = ModuleArgsParser(ds)
    result = instance.parse()

    # assert
    assert result == ("copy", dict(src="/tmp/foo", dest="/tmp/bar"), "localhost")



# Generated at 2022-06-20 23:14:07.965861
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:14:20.328962
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    def _dict_from_str(str):
        return literal_eval(str)

    def _run_test(ds, res, col_list=None):
        (action, args, delegate_to) = ModuleArgsParser(ds, col_list=col_list).parse()
        assert (action, args, delegate_to) == res, "failed for: %s" % ds

    # legacy/old style forms
    _run_test(_dict_from_str("{ 'action': 'shell echo hi' }"),
              ('shell', {'_raw_params': 'echo hi'}, None))
    _run_test(_dict_from_str("{ 'action': { 'module': 'shell', 'args': 'echo hi' } }"),
              ('shell', {'_raw_params': 'echo hi'}, None))
    _run

# Generated at 2022-06-20 23:14:38.384754
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing with an object of type dict
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    obj = ModuleArgsParser(task_ds=task_ds)
    assert obj.parse()[0] == 'copy'
    task_ds = {'action': 'copy src=a dest=b'}
    obj = ModuleArgsParser(task_ds=task_ds)
    assert obj.parse()[0] == 'copy'
    task_ds = {'module': 'copy src=a dest=b'}
    obj = ModuleArgsParser(task_ds=task_ds)
    assert obj.parse()[0] == 'copy'
    task_ds = {'local_action': 'copy src=a dest=b'}

# Generated at 2022-06-20 23:14:39.279891
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass

# Generated at 2022-06-20 23:14:45.502052
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test constructor with empty incoming dict
    parser = ModuleArgsParser(task_ds={})
    assert parser._task_ds == {}
    assert parser._task_attrs == frozenset(['tags', 'local_action', 'become', 'become_user',
                                            'become_method', 'check_mode', 'become_flags', 'when', 'static', 'register',
                                            'run_once'])
    assert parser.resolved_action is None



# Generated at 2022-06-20 23:14:51.807568
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Positive using string
    task_ds = 'shell echo hi'
    assert ModuleArgsParser(task_ds)
    task_ds = "shell echo hi"
    assert ModuleArgsParser(task_ds)

    # Positive using dictionary
    task_ds = {'action': 'shell echo hi'}
    assert ModuleArgsParser(task_ds)
    task_ds = {'action': "shell echo hi"}
    assert ModuleArgsParser(task_ds)

    # Negative using string
    task_ds = {'action': {'shell': "echo hi"}}
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds)

    # Negative using dictionary
    task_ds = {'action': {'shell echo hi': True}}

# Generated at 2022-06-20 23:14:53.012938
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()

    # a task with freeform args, i.e. no module specified at all
    parser.parse_raw("this is a freeform task")


# Generated at 2022-06-20 23:15:00.883574
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"action":"copy","local_action": "abc","delegate_to": "abc","args": "abc"}
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, args, delegate_to = obj.parse(skip_action_validation=False)
    assert action == "copy"
    assert args == {}
    assert delegate_to == "abc"

if __name__ == "__main__":
    test_ModuleArgsParser_parse()

# Generated at 2022-06-20 23:15:10.896281
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = dict(
        local_action=dict(
            module='copy',
            args=dict(src='./foo.conf', dest='/etc/foo.conf', force=True, mode='0755', remote_src=True, validate='md5')
        )
    )
    args, kwargs = ModuleArgsParser(ds).parse()
    assert args == ('copy', dict(force=True, mode='0755', remote_src=True, validate='md5', src='./foo.conf', dest='/etc/foo.conf'), 'localhost')
    assert kwargs == dict()

# Generated at 2022-06-20 23:15:18.585121
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds            = {
                            'action': {
                              'module': 'copy',
                              'x': 1
                            }
                        }
    collection_list    = None
    test_object        = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    expected_result    = ('copy', {'x': 1}, None)
    actual_result      = test_object.parse()

    assert actual_result == expected_result, "Actual result does not match with expected result"

# Generated at 2022-06-20 23:15:22.439839
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(
        task_ds=dict(
            delegate_to='localhost',
            local_action='echo hi',
        ),
    )
    module_args_parser.parse()

# Generated at 2022-06-20 23:15:25.617921
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={'foo': 'bar'}, collection_list=None)
    assert {'foo': 'bar'} == module_args_parser._task_ds


# Generated at 2022-06-20 23:15:38.437053
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a1 = dict(
        action=dict(module='shell', _raw_params='echo hi'),
        delegate_to='localhost'
    )
    a2 = dict(
        action='shell echo hi',
        delegate_to='localhost'
    )
    a3 = dict(
        action='shell',
        args=dict(echo='hi', other='1'),
        delegate_to='localhost'
    )
    a4 = dict(
        local_action=dict(module='shell', _raw_params='echo hi'),
    )
    a5 = dict(
        local_action='shell echo hi',
    )
    a6 = dict(
        local_action='shell',
        args=dict(echo='hi', other='1')
    )

# Generated at 2022-06-20 23:15:51.109942
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  d = dict(module='shell',chdir='/tmp')
  parser = ModuleArgsParser(task_ds=d)
  action, args, delegate_to = parser.parse()
  assert action == 'shell'
  assert args == dict(_raw_params='chdir=/tmp')
  assert delegate_to is None

  d = dict(module='empty')
  parser = ModuleArgsParser(task_ds=d)
  action, args, delegate_to = parser.parse()
  assert action == 'empty'
  assert args == dict()
  assert delegate_to is None

  d = dict(module='ping')
  parser = ModuleArgsParser(task_ds=d)
  action, args, delegate_to = parser.parse()
  assert action == 'ping'
  assert args == dict()
  assert delegate_to is None

 

# Generated at 2022-06-20 23:16:03.314653
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    _task_attrs = set(Task._valid_attrs.keys())
    _task_attrs.update(set(Handler._valid_attrs.keys()))
    _task_attrs = frozenset(_task_attrs)

    task_ds = {
        "delegate_to": "{{ remote_machine }}"
    }

    non_task_ds = dict((k, v) for k, v in iteritems(task_ds) if (k not in _task_attrs) and (not k.startswith('with_')))
    print(non_task_ds)


if __name__ == '__main__':
    test_ModuleArgsParser

# Generated at 2022-06-20 23:16:14.707765
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.action import ActionBase
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.loader import action_loader

    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../plugins/action'))

    def assert_equal(x, y):
        if x != y:
            raise AssertionError(
                "\n\n  {!r}\n!= {!r}\n".format(x, y)
            )


# Generated at 2022-06-20 23:16:15.392838
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    pass


# Generated at 2022-06-20 23:16:26.252822
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None

    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    obj.resolved_action = None
    obj._task_attrs = frozenset(['_task_attrs'])

    # Standard YAML form for command-type modules
    # In this case, the args specified will act as 'defaults' and will
    # be overridden by any args specified in one of the other formats
    # (complex args under the action, or parsed from the k=v string
    obj._task_ds['args'] = dict(chdir='/tmp')
    action, args, delegate_to = obj.parse(skip_action_validation=False)

    assert action == 'copy'
   