

# Generated at 2022-06-20 23:06:59.941771
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    arg = dict()
    arg['action'] = 'shell echo hi'
    m = ModuleArgsParser()
    assert m._task_ds == {}
    assert m.parse(skip_action_validation=True) == ('shell', {'_raw_params': 'echo hi'}, None)

# Generated at 2022-06-20 23:07:07.167293
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task_ds = dict()
    collection_list = None

    test_obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)

    with pytest.raises(Exception): # Ensure Exception is raised when no parameters are provided
        test_obj.parse(skip_action_validation=False)

    task_ds = {'action': 'hello'}
    test_obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert test_obj.parse(skip_action_validation=False) == ('hello', dict(), None)

    task_ds = {'action': 'hello', 'args': dict(), 'delegate_to': 'test'}
    test_obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)


# Generated at 2022-06-20 23:07:16.316697
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    collection_list = None
    task_ds = {'action': 'shell echo hi'}
    args_parser = ModuleArgsParser(task_ds, collection_list)
    assert args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'module': 'shell echo hi'}
    args_parser = ModuleArgsParser(task_ds, collection_list)
    assert args_parser.parse() == ('shell', {'_raw_params': 'echo hi'}, None)
    task_ds = {'action': {'module': 'echo hi'}}
    args_parser = ModuleArgsParser(task_ds, collection_list)
    assert args_parser.parse() == ('echo', {'_raw_params': 'hi'}, None)

# Generated at 2022-06-20 23:07:28.549340
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test number of arguments
    assert ModuleArgsParser._parse.__code__.co_argcount == 4

    # Test normal arguments
    args = {'local_action': 'shell echo hi'}
    collection_list = None
    assert ModuleArgsParser(args, collection_list).parse() == ('shell', {}, 'localhost')

    # Test normal arguments
    args = {'local_action': {'module': 'shell', '_raw_params': 'echo hi'}}
    collection_list = None
    assert ModuleArgsParser(args, collection_list).parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost')

    # Test normal arguments
    args = {'local_action': {'module': 'shell', '_raw_params': 'echo {{testvar}}'}}
    collection_list = None
   

# Generated at 2022-06-20 23:07:41.184408
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  import yaml
  from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
  class Task(AnsibleBaseYAMLObject):
    yaml_loader = yaml.SafeLoader
    yaml_tag = u'!Task'

    def __init__(self, value):
      super(Task, self).__init__(value)
      self.task_ds = value

    @staticmethod
    def to_yaml(dumper, data):
      # TODO: following line related to `ansible.parsing.yaml.objects.AnsibleMapping`
      # but `ansible.parsing.yaml.objects.AnsibleMapping` only exists in ansible/2.x
      # task = AnsibleMapping(data)
      task = dict(data)
     

# Generated at 2022-06-20 23:07:44.930411
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    item, value, delegate_to = module_args_parser.parse()
    assert item == None
    assert value == None
    assert delegate_to == None


# Class: ModuleUtility

# Generated at 2022-06-20 23:07:51.453822
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(
        action='copy',
        local_action='copy src=a dest=b'
    )
    arg_parser = ModuleArgsParser(task_ds=ds)
    args = arg_parser.parse()
    assert args == ('copy', {'_raw_params': 'src=a dest=b'}, 'localhost')
    assert arg_parser.resolved_action is None

# Generated at 2022-06-20 23:08:01.243004
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_instance = ModuleArgsParser()
    # Test arguments and expected return values
    #
    # 1. Test that parsing of old-style arguments succeeds:
    #    parse({action: 'asdf'}) => ('asdf', None, None)
    #
    # 2. Test that parsing of old-style arguments succeeds:
    #    parse({module: 'asdf'}) => ('asdf', {}, None)
    #
    # 3. Test that parsing of new-style arguments succeeds:
    #    parse({asdf: {arg1: 'val1', arg2: 'val2'}}) => ('asdf', {arg1: 'val1', arg2: 'val2'}, None)
    #
    # 4. Test that parsing of old-style arguments succeeds:
    #    parse({action: {module: '

# Generated at 2022-06-20 23:08:12.008329
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    delegate_to = 'localhost'
    args = 'echo hi'
    params = [args, action]
    #
    # shuffle params to test each possible case
    #
    for param in params:
        #
        # build the task dictionary
        #
        task_dict = {}
        # pylint: disable=bad-format-string
        task_str = "{}:{}".format(action, args)
        action_str = action
        # pylint: enable=bad-format-string
        if param == action_str:
            task_dict['action'] = task_str
        else:
            expected_action, expected_args = task_str.split(':', 1)
            task_dict[expected_action] = expected_args
            task_dict['delegate_to'] = delegate

# Generated at 2022-06-20 23:08:23.596024
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module=dict(matched_keyword=dict(module_name="module1", module_args=dict()))))
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    expected = ['module1', dict(), Sentinel]
    actual = module_args_parser.parse()
    assert actual == expected, "Expected {0}, but got {1}".format(expected, actual)
    task_ds = dict(action=dict(module=dict(matched_keyword=dict(module_name="module1", module_args="args1"))))
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    expected = ['module1', dict(args1=''), Sentinel]
    actual = module_args_parser.parse()

# Generated at 2022-06-20 23:08:43.458142
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None


# Generated at 2022-06-20 23:08:55.602704
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # input is an array
    def test_array():
        try:
            ModuleArgsParser(task_ds=["shell", "echo 'hi'"])
            assert False
        except AnsibleAssertionError as e:
            assert "should be a dict" in str(e)

    # input is a number
    def test_number():
        try:
            ModuleArgsParser(task_ds=5)
            assert False
        except AnsibleAssertionError as e:
            assert "should be a dict" in str(e)

    # input is a string
    def test_string():
        try:
            ModuleArgsParser(task_ds="shell echo 'hi'")
            assert False
        except AnsibleAssertionError as e:
            assert "should be a dict" in str(e)

    # input is a tuple


# Generated at 2022-06-20 23:09:06.973497
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {}
    collection_list = None
    module_args_parser_test_class = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    module_args_parser_test_class_return_value = module_args_parser_test_class.parse(skip_action_validation=False)
    assert isinstance(module_args_parser_test_class_return_value, tuple)
    assert isinstance(module_args_parser_test_class._task_ds, dict)
    assert isinstance(module_args_parser_test_class._collection_list, (list, None))

# Generated at 2022-06-20 23:09:17.530514
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    args = {
        'package_name': 'nginx',
        'state': 'installed'
    }
    task_ds = {'delegate_to': 'localhost', 'args': args}
    assert module_args_parser.parse() == (None, None, Sentinel)
    assert module_args_parser.parse(skip_action_validation=True) == (None, None, Sentinel)
    assert module_args_parser.parse(task_ds=task_ds) == ("package", args, "localhost")
    assert module_args_parser.parse(task_ds=task_ds, skip_action_validation=True) == ("package", args, "localhost")


# Generated at 2022-06-20 23:09:28.272275
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # test instantiation
    try:
        ModuleArgsParser()
        raise AssertionError("ansible.playbook.become._TaskExecutionVars constructor should have failed with no arguments")
    except TypeError:
        pass

    # test instantiation with valid argument
    try:
        ModuleArgsParser(task_ds=dict())
    except TypeError:
        raise AssertionError("ansible.playbook.become._TaskExecutionVars constructor should succeed with a dict as its 'task_ds' argument")

    # test instantiation with invalid argument

# Generated at 2022-06-20 23:09:33.361208
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    simple_task = {'shell': 'echo hi'}
    task_ds = {'action': simple_task}
    module_args_parser = ModuleArgsParser(task_ds)
    assert isinstance(module_args_parser, ModuleArgsParser)



# Generated at 2022-06-20 23:09:41.216038
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    #
    # Check that ModuleArgsParser takes dict as parameter
    #
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser("str")

    #
    # Check that ModuleArgsParser takes dict as parameter
    #
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser({"action": "shell", "args": "echo hi"})



# Generated at 2022-06-20 23:09:48.923539
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_parser = ModuleArgsParser(task_ds={'tocken':'tocken','uri':'uri','region':'region','state':'state','register':'register'},collection_list=None)
    result = module_parser.parse()
    assert result == ('ec2_vpc_dhcp_options',{'tocken': 'tocken', 'uri': 'uri', 'region': 'region', 'state': 'state', 'register': 'register'},None)



# Generated at 2022-06-20 23:09:50.011098
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "Test not implemented"


# Generated at 2022-06-20 23:10:01.699698
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import ansible.playbook

    data = {
        'action': 'copy src=a dest=b',
        'register': 'somevar'
    }
    ds = {
        'action': 'copy src=a dest=b',
        'register': 'somevar'
    }
    # default parameters
    parser = ansible.playbook.ModuleArgsParser(task_ds=ds)

    with pytest.raises(AssertionError) as error:
        parser.parse()

    assert "the type of 'task_ds' should be a dict, but is a <class 'str'>" in str(error.value)

    # test with defined parameters
    parser = ansible.playbook.ModuleArgsParser(task_ds=data)
    result = parser.parse()


# Generated at 2022-06-20 23:10:18.484542
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # 1st test case: Unsupported argument type (empty string, which is not a valid task)
    test_case_name = "Unsupported argument type, empty string"
    try:
        test_parser = ModuleArgsParser(task_ds='')
    except AnsibleAssertionError as err:
        assert test_case_name in err.args[0]
    else:
        pytest.fail("%s: testing failed, should have failed with AnsibleAssertionError" % test_case_name)

    # 2nd test case: expected argument type (a task)
    test_case_name = "Expected argument type, a task"

# Generated at 2022-06-20 23:10:31.877184
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Unrecognized argument
    task_ds = dict(action=dict(module='foobar', baz=123))
    try:
        ModuleArgsParser(task_ds=task_ds).parse()
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert "conflicting action statements" in str(e)

    # Unrecognized argument
    task_ds = dict(action=dict(module='foobar', baz=123))
    try:
        ModuleArgsParser(task_ds=task_ds).parse()
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert "conflicting action statements" in str(e)

    # Unrecognized argument
    task_ds = dict(action='foobar', baz=123)

# Generated at 2022-06-20 23:10:38.960049
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    task_ds = dict(action=AnsibleUnsafeText('set_fact'), a=1, b=2)

    task_ds2 = dict(action=AnsibleUnsafeText('set_fact'), set_fact=dict(a=1, b=2))


# Generated at 2022-06-20 23:10:49.437098
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  ModArP = ModuleArgsParser(task_ds={'action': 'shell echo hi'}, collection_list="test")
  assert ModArP._task_ds == {'action': 'shell echo hi'}, 'ModuleArgsParser._task_ds is not the same'
  assert ModArP.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True, 'executable': ''}, Sentinel), 'ModuleArgsParser._task_ds is not the same'
  print("ModuleArgsParser OK")
# Testing ModuleArgsParser
test_ModuleArgsParser_parse()

# unit test for method _handle_action of class Task

# Generated at 2022-06-20 23:10:56.398083
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test the ModuleArgsParser.__init__ method
    class_ = ModuleArgsParser
    obj = class_()
    assert hasattr(obj, '_split_module_string')
    assert hasattr(obj, '_normalize_parameters')
    assert hasattr(obj, '_normalize_new_style_args')
    assert hasattr(obj, '_normalize_old_style_args')
    assert hasattr(obj, 'parse')


# Generated at 2022-06-20 23:11:03.318784
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fixture_data = load_fixture('ModuleArgsParser_parse_fixture.json')
    fixture_data_len = len(fixture_data)

    for idx, fixture in enumerate(fixture_data):
        print("\n%d/%d" % (idx+1, fixture_data_len))
        module_arg_parser = ModuleArgsParser(fixture['given'])
        result = module_arg_parser.parse()
        assert result == fixture['expected']

# Generated at 2022-06-20 23:11:15.517960
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    def _test_ModuleArgsParser_parse_inner(collection_list=None, skip_action_validation=False, **kwargs_task_ds):
        parser = ModuleArgsParser(task_ds=kwargs_task_ds, collection_list=collection_list)
        action, args, delegate_to = parser.parse(skip_action_validation=skip_action_validation)

        expected = kwargs_task_ds.get('expected_action', None)
        assert action == expected

        expected = kwargs_task_ds.get('expected_args', {})
        assert args == expected

        expected = kwargs_task_ds.get('expected_delegate_to', None)
        assert delegate_to == expected


# Generated at 2022-06-20 23:11:18.750614
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module='shell', args='pwd'))
    m = ModuleArgsParser(task_ds)
    assert m.parse() == ('shell', dict(), None)


# Generated at 2022-06-20 23:11:28.134763
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_utils.HAS_PWB_IN_IMPORTS = False
    task_ds = {'action': 'ping', 'args': {'data': 'hello world'}}
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser._task_attrs == frozenset(['_variables', 'action', 'local_action', 'vars', 'when', 'notify', 'register', 'delegate_to', 'loop', 'loop_args', 'always_run', 'pause_before', 'pause_after', 'tags', 'run_once', 'static'])
    assert parser.resolved_action is None

    # not used in the constructor
    assert parser._collection_list is None


# Generated at 2022-06-20 23:11:41.048745
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:11:53.881750
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    params = {"action": {
            "ec2": "region=us-west-2 name=test-ami"
        },
        "delegate_to": "localhost"
    }
    args = dict()
    action = "ec2"
    delegate_to = params["delegate_to"]
    mod_args = ModuleArgsParser(params)
    ret = mod_args.parse()
    assert ret[0] == action
    assert ret[1] == args
    assert ret[2] == delegate_to
    test_params = {"action": {
            "shell": "echo 'yeah'"
        }
    }
    mod_args1 = ModuleArgsParser(test_params)
    ret = mod_args1.parse()
    assert ret[0] == "shell"

# Generated at 2022-06-20 23:11:55.538284
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parsed_output = ModuleArgsParser()



# Generated at 2022-06-20 23:12:08.218432
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test module_args_parser
    test_task_ds = dict()
    test_task_ds['action'] = 'shell echo "hello"'
    test_task_ds['local_action'] = 'shell echo "hello"'
    test_task_ds['debug'] = dict()
    test_task_ds['debug']['msg'] = "hello"
    test_task_ds['delegate_to'] = 'localhost'
    test_task_ds['args'] = dict()
    test_task_ds['args']['x'] = 3

    module_args_parser = ModuleArgsParser(test_task_ds, collection_list=None)
    (actual_action, actual_args, actual_delegate_to) = module_args_parser.parse()

    # Check let's see if we get the expected results
    expected_

# Generated at 2022-06-20 23:12:13.750730
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  import pytest
  # Fails with AssertionError
  with pytest.raises(AssertionError):
    ModuleArgsParser(task_ds=None, collection_list=None).parse(skip_action_validation=False)
  # Passes
  ModuleArgsParser(task_ds={}, collection_list=None).parse(skip_action_validation=False)


# Generated at 2022-06-20 23:12:26.276211
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # HACK: generate self._task_attrs
    # NOTE: cannot use a static variable as it's shared between class instances
    #not a real test.  needs to be phased out.
    #self._task_attrs = set(Task._valid_attrs.keys())
    task_ds = {'action': {'module': 'copy'}, 'args': '', 'delegate_to':''}
    # HACK: generate self._task_attrs
    # NOTE: cannot use a static variable as it's shared between class instances
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    # store the valid Task/Handler attrs for quick access
    self._task_attrs = set(Task._valid_attrs.keys())

# Generated at 2022-06-20 23:12:37.683919
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    T = Task()
    t = {'action': 'abc', 'delegate_to': 'xyz', 'first_arg': '1', 'second_arg': '2', 'args': {'a1': '1', 'a2': '2'}}
    T.vars = flexmock()
    T.vars.template_ds = t
    pars = ModuleArgsParser(t)
    assert pars.parse() == ('abc', {'a1': '1', 'a2': '2'}, 'xyz')

# Generated at 2022-06-20 23:12:49.612961
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': None, 'delegate_to': None, 'args': None}
    m = ModuleArgsParser(task_ds)
    result = m.parse()
    assert result == (None, None, None)


# class TaskExecutor(object):
#
#     '''
#     This is the primary class for executing tasks, invoked from
#     ansible-playbook.  It is primarily responsible for the following:
#
#     * iterating over hosts in play, handling any specified serial amount
#     * creating the proper iterator to use for handling the hosts
#     * setting/clearing the failed_when and changed_when expressions, if used
#     * loading the callback class specified by the user, if any
#     * setting up the environment variables to use for the task execution
#     * creating the shared loader object to use for

# Generated at 2022-06-20 23:13:01.482111
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {}
    ds['hosts'] = 'test'
    ds['name'] = 'test_name'
    ds['action'] = 'test_action'
    ds['become'] = True
    ds['become_user'] = 'test_become_user'
    ds['become_flags'] = 'test_become_flags'
    ds['environment'] = {'env_var':'env_val'}

    # first test: recreate args using ds_without_module
    ds_without_module = ds.copy()
    ds_without_module.pop('action')

    obj = ModuleArgsParser(ds_without_module)

    assert obj._task_ds == ds_without_module

# Generated at 2022-06-20 23:13:10.016331
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode

    task_ds = TaskInclude.load(dict(name="test1", tasks='foo.yml'), load_tags=set(['always']), play_context=PlayContext(), parent_block=Block(None, load_tags=set(['always'])))
    task_ds._parent = Block(None, load_tags=set(['always']))
    collection_list = AnsibleCollectionRef('')

    # test without action
    m = ModuleArgsParser(task_ds, collection_list)
    assert m.parse() == (None, {}, Sentinel)

    # test

# Generated at 2022-06-20 23:13:11.710302
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_str = 'extract path="/my/path" dest="/dest/dir"'

    parser = ModuleArgsParser()
    print(parser._split_module_string(module_str))



# Generated at 2022-06-20 23:13:17.772000
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

# Generated at 2022-06-20 23:13:30.884770
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test fixture
    task_ds = {}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    # Test scenario #1
    with pytest.raises(AnsibleAssertionError):
        module_args_parser.parse()
    # Test scenario #2
    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    expected_results = ('copy', {'dest': 'b', 'src': 'a'}, Sentinel)
    actual_results = module_args_parser.parse()
    assert actual_results == expected_results
    # Test scenario #3

# Generated at 2022-06-20 23:13:37.056509
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    thing1 = ModuleArgsParser(dict(action = 'user=xyz'))
    thing2 = ModuleArgsParser(dict(action = dict(user='xyz')))
    thing3 = ModuleArgsParser(dict(action = 'user=xyz'))
    thing4 = ModuleArgsParser(dict(action = 'user=xyz'))
    assert True


# Generated at 2022-06-20 23:13:42.416387
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var

    def test_parse(task_ds=None, collection_list=None):
        task_ds = {} if task_ds is None else task_ds
        task_args = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list).parse()

# Generated at 2022-06-20 23:13:50.050757
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.parsing.vault import VaultLib

    # test the expected output of parse(self) method, where self is an object of ModuleArgsParser class
    assert isinstance(ModuleArgsParser().parse(skip_action_validation=True), tuple), "parse(self) should return an instance of tuple"

    # test the expected output of parse(self) method, where self is an object of ModuleArgsParser
    # class, with skip_action_validation True
    assert isinstance(ModuleArgsParser().parse(skip_action_validation=True), tuple), "parse(self) should return an instance of tuple"

    # test the expected output of parse(self) method, where self is an object of ModuleArgsParser
    # class, with skip_action_validation False

# Generated at 2022-06-20 23:14:00.600526
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    ds = {}
    for key, value in iteritems(dict(action='a', local_action='b', module='c', args='d', delegate_to='e', with_items='f')):
        if key not in BUILTIN_TASKS:
            ds[key] = value
    ds.update(dict(args={'a': 'b', 'c': 'd'}))
    m = ModuleArgsParser(task_ds=ds)
    action, args, delegate_to = m.parse()
    assert ((action, args, delegate_to) == ('a', {}, 'e'))
    assert (m.resolved_action == None)


# Generated at 2022-06-20 23:14:09.298241
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # valid
    ModuleArgsParser(task_ds={'module': 'ec2', 'region': 'xyz'}, collection_list=None)
    ModuleArgsParser(task_ds={'local_action': 'command ls'}, collection_list=None)
    ModuleArgsParser(task_ds={'action': 'ec2', 'region': 'xyz'}, collection_list=None)

    # invalid
    try:
        ModuleArgsParser(task_ds='ec2', collection_list=None)
        assert False, "should have thrown an error"
    except:
        pass

    try:
        ModuleArgsParser(task_ds=['ec2'], collection_list=None)
        assert False, "should have thrown an error"
    except:
        pass


# Generated at 2022-06-20 23:14:21.449147
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(
        task_ds={
            'action': 'copy',
            'args': 'src=test dest=/tmp mode=644',
            #'delegate_to': 'localhost'
        },
        collection_list=[
            [
                {
                    'action': 'copy',
                    'module': 'core',
                    'name': 'copy',
                    '_original_path': 'core/copy',
                    '_load_name': 'core.copy',
                    'doc': 'Copies files to remote locations.'
                }
            ]
        ]
    )

# Generated at 2022-06-20 23:14:34.028672
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing for method of class ModuleArgsParser parse
    # Setup test environment
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    exec_environment = dict(
        ansible_version={
            'full': 'v2.8.0.0',
            'major': 2,
            'minor': 8,
            'revision': 0,
            'string': '2.8.0.0'
        },
        ansible_python_version='2.7.15 (default, Aug  7 2019, 17:28:10) [GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]',
        ansible_user_id='admin',
    )
    #

# Generated at 2022-06-20 23:14:43.975322
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins import module_loader

    # Test various command actions.
    task_ds = {'action': 'echo hi'}
    assert ModuleArgsParser(task_ds).parse() == ('command', {'_raw_params': 'echo hi'}, None)
    assert ModuleArgsParser({'action': 'echo "hi"'}).parse() == ('command', {'_raw_params': 'echo "hi"'}, None)
    assert ModuleArgsParser({'action': 'echo \'hi\''}).parse() == ('command', {'_raw_params': 'echo \'hi\''}, None)
    assert ModuleArgsParser({'action': 'echo \'hi\''}).parse() == ('command', {'_raw_params': 'echo \'hi\''}, None)

# Generated at 2022-06-20 23:15:00.079036
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    loader = None
    p = Playbook()
    t = Task()
    t._play = p
    # t._role = Role()
    t.vars = dict()
    t.action = "ping"
    t.module_args = {}
    t.args = {}
    m = ModuleArgsParser(task_ds=t.args)
    assert m is not None
    assert m.parse(skip_action_validation=True) == ("ping", {}, None)


# Generated at 2022-06-20 23:15:01.509722
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mod = ModuleArgsParser()
    assert mod is not None



# Generated at 2022-06-20 23:15:11.411189
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    parser = ModuleArgsParser({})
    assert parser._task_ds == {}
    assert parser._task_attrs == Task._valid_attrs.keys()
    assert parser.resolved_action == None

    parser = ModuleArgsParser({'action': {'setup': 'hostname'}})
    assert parser._task_ds == {'action': {'setup': 'hostname'}}
    assert parser._task_attrs == Task._valid_attrs.keys()
    assert parser.resolved_action == None

    parser = ModuleArgsParser(action={'setup': 'hostname'})
    assert parser._task_ds == {'action': {'setup': 'hostname'}}
    assert parser._task_attrs == Task._valid_attrs.keys()
    assert parser.resolved_action == None


# Generated at 2022-06-20 23:15:22.969167
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    module_loader.add_directory('./lib')
    action_loader.add_directory('./lib')

    task_ds = {
        'name': 'test',
        'incorrect_action': 'copy src=a dest=b'
    }
    parser = ModuleArgsParser(task_ds=task_ds)
    parser.parse(skip_action_validation=True)
    # assert parser.resolved_action == 'ansible.builtin.copy'
    # assert parser.resolved_action == 'ansible.actions.copy'

    task_ds = {
        'name': 'test',
        'incorrect_action': 'shell echo hi'
    }

# Generated at 2022-06-20 23:15:29.152874
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {'action': 'shell echo hi',
            'delegate_to': 'localhost'}
    module_arg_parser = ModuleArgsParser(args, collection_list=None)
    res = module_arg_parser.parse()
    assert res[0] == 'shell'
    assert res[1] == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert res[2] == 'localhost'



# Generated at 2022-06-20 23:15:34.815209
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'module': 'copy',
        'src': 'a',
        'dest': 'b'
    }
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action, args, delegate_to = parser.parse()
    assert action == 'copy'
    assert args == {'dest': 'b', 'src': 'a'}
    assert delegate_to is None



# Generated at 2022-06-20 23:15:39.859437
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(
        dict(action={'module': 'copy', 'x': 2, 'y': 3})
    )
    assert module_args_parser.parse() == ('copy', {'y': 3, 'x': 2}, Sentinel)

# Generated at 2022-06-20 23:15:52.801763
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test parse method of ModuleArgsParser
    '''
    # Test call to parse method of class ModuleArgsParser
    # FIXME: parameter loader not defined
    # FIXME: parameter search_path not defined
    # FIXME: parameter variable_manager not defined
    # FIXME: parameter loader_basedir not defined

    # FIXME: Parameter 'playbook_vars' is not defined

    # FIXME: Parameter 'play_context' is not defined
    # FIXME: Parameter 'task_vars' is not defined
    # FIXME: Parameter 'task' is not defined
    task_ds = dict(
        module='setup',
        args=dict(
            gather_subset=['!all'],
            filter='ansible_distribution'
        )
    )

# Generated at 2022-06-20 23:15:57.568250
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    AnsibleModuleArgs constructor provides no public interface, so
    we just make sure it doesn't blow up
    '''
    class TestModuleArgsParser():

        def test_init(self):
            m = ModuleArgsParser()
            assert m is not None
    return TestModuleArgsParser()


# Generated at 2022-06-20 23:15:58.308669
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser is not None
