

# Generated at 2022-06-20 23:07:10.661748
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:07:17.637916
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser({
        'action': 'shell echo hi',
        'delegate_to': 'localhost'
    })
    args = parser.parse()
    assert args[0] == 'shell'
    assert args[1] == {'_uses_shell': True, '_raw_params': 'echo hi'}
    assert args[2] == 'localhost'
    parser = ModuleArgsParser({
        'local_action': 'shell echo hi'
    })
    args = parser.parse()
    assert args[0] == 'shell'
    assert args[1] == {'_uses_shell': True, '_raw_params': 'echo hi'}
    assert args[2] == 'localhost'
    parser = ModuleArgsParser({
        'shell': 'echo hi'
    })
    args = parser.parse()


# Generated at 2022-06-20 23:07:29.645622
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'shell echo hi'}
    assert ModuleArgsParser(task_ds).parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None)
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    assert ModuleArgsParser(task_ds).parse() == ('copy', {u'src': u'a', u'dest': u'b'}, None)
    task_ds = {'local_action': 'shell echo hi'}
    assert ModuleArgsParser(task_ds).parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, 'localhost')

# Generated at 2022-06-20 23:07:42.568725
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert m.parse() == (None, dict(), None)
    assert m.parse({'action': 'copy', 'src': "a", 'dest': 'b'}) == ('copy', {'src': "a", 'dest': 'b'}, None)
    assert m.parse({'local_action': 'copy', 'src': "a", 'dest': 'b'}) == ('copy', {'src': "a", 'dest': 'b'}, 'localhost')
    assert m.parse({'action': 'copy src=a dest=b'}) == ('copy', {'src': "a", 'dest': 'b'}, None)

# Generated at 2022-06-20 23:07:43.633324
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result = ModuleArgsParser().parse()
    assert result is None
# END-UNITTEST


# Generated at 2022-06-20 23:07:49.187619
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'arg1': 'var1', 'arg2': 'var2'}
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result[0] == 'arg1'
    assert result[1] == {'arg2': 'var2'}
    assert result[2] is None

# Generated at 2022-06-20 23:07:59.507898
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task = dict(action=dict(setup=dict(
        filter='ansible_date_time.date',
        # date_time:
        #   date: "YYYY-MM-DD ddd"
        #   time: "HH:MM:SS"
        #   timezone: "Etc/GMT+5"
        validate='date_time.date == "2020-08-20 Thu" and date_time.time == "13:37:00" and date_time.timezone == "Etc/GMT+5"'
    )))
    module_arg_parser = ModuleArgsParser(task_ds=task)

# Generated at 2022-06-20 23:08:03.825162
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ansible_vars = {'var1': 'this is var1', 'var2': 'this is var2'}
    task_ds = {'action': {'module': 'shell', '_raw_params': 'ls', 'args': '-l', 'var1': '{{var1}}', 'var2': '{{var2}}'}, 'delegate_to': 'localhost'}
    module_parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = module_parser.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'ls', 'var1': 'this is var1', 'var2': 'this is var2'}
    assert delegate_to == 'localhost'

# Generated at 2022-06-20 23:08:13.825273
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser(task_ds={'action': 'shell', 'conf': 'val2', 'args': {'conf1': 'val1', 'conf2': 'val2'}})
    assert obj.parse() == ('shell', {'_raw_params': '', 'conf1': 'val1', 'conf2': 'val2'}, Sentinel)

    obj = ModuleArgsParser(task_ds={'module': 'shell', 'conf': 'val2', 'args': {'conf1': 'val1', 'conf2': 'val2'}})
    assert obj.parse() == ('shell', {'conf': 'val2', 'conf1': 'val1', 'conf2': 'val2'}, Sentinel)


# Generated at 2022-06-20 23:08:26.023210
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'ping'
    }
    module_args_parser = ModuleArgsParser( task_ds, None )
    assert module_args_parser is not None
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'ping'
    assert args is None
    assert delegate_to is None
    
    task_ds = {
        'action': {
            'ping': 'ping'
        }
    }
    module_args_parser = ModuleArgsParser( task_ds, None )
    assert module_args_parser is not None
    action, args, delegate_to = module_args_parser.parse()
    assert action == 'ping'
    assert args == {}
    assert delegate_to is None
    

# Generated at 2022-06-20 23:08:42.773676
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict(action=dict(module="yum", name="vim", state="installed"))
    module = ModuleArgsParser(task_ds=task_ds)
    module.resolved_action = None
    result = module.parse()
    assert result == ('yum', {'name': 'vim', 'state': 'installed'}, None)

    task_ds = dict(action="shell echo 'hi'")
    module = ModuleArgsParser(task_ds=task_ds)
    module.resolved_action = None
    result = module.parse(skip_action_validation=True)
    assert result == ('shell', {'_raw_params': "echo 'hi'"}, None)

    task_ds = dict(action=dict(_raw_params="echo 'hi'"))

# Generated at 2022-06-20 23:08:54.859207
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds={'action': 'shell', 'jeykll': 'jekyll'}
    collection_list=None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result==('shell', {}, None)
    # # space in action name
    task_ds={'action': 'test condition', 'jeykll': 'jekyll'}
    collection_list=None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_args_parser.parse()
    assert result==('test', {'condition': None}, None)
    # # module in action name
    task_ds={'action': 'test-condition', 'jeykll': 'jekyll'}
    collection

# Generated at 2022-06-20 23:09:01.527058
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_obj = tasks.ModuleArgsParser({}, collection_list=[])
    assert {
            'action': 'shell',
            'args': {
                '_raw_params': 'echo hi',
                '_uses_shell': True
                },
            'delegate_to': 'localhost'
            } == module_args_parser_obj._split_module_string('shell echo hi')



# Generated at 2022-06-20 23:09:05.175122
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    task_ds=dict()
    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()


# Generated at 2022-06-20 23:09:12.223946
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    if module_args_parser.parse() != (None, {}, Sentinel):
        raise AssertionError('Failed parse with no args')
    task_ds = {'args': {'test': 'foo'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    if module_args_parser.parse() != (None, {}, Sentinel):
        raise AssertionError('Failed parse with args')
    task_ds = {'action': {'test': 'foo'}}
    module_args_parser = ModuleArgsParser(task_ds=task_ds)

# Generated at 2022-06-20 23:09:24.884556
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    # duplicate unit tests from ansible/playbook/__init__.py
    # TODO: allow these to be skipped

    # test with a non-dict input
    module_args_parser = ModuleArgsParser(task_ds=1)
    with pytest.raises(AnsibleAssertionError):
        module_args_parser.parse()
    del module_args_parser

    # test with dict but incorrect keys
    module_args_parser = ModuleArgsParser(task_ds={'incorrect_key': 'value'})
    with pytest.raises(AnsibleParserError):
        module_args_parser.parse()
    del module_args_parser

    # test if action is not specified
    module_args_parser = ModuleArgsParser

# Generated at 2022-06-20 23:09:37.259086
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    args_parser = ModuleArgsParser()
    test1 = {'shell': 'echo hi'}
    action_module, action_args, delegate_to = args_parser.parse(thing=test1)
    assert action_module == 'shell'
    assert action_args == {}
    assert delegate_to is None

    test2 = {'local_action': {'shell' : 'echo hi'}}
    action_module, action_args, delegate_to = args_parser.parse(thing=test2)
    assert action_module == 'shell'
    assert action_args == {}
    assert delegate_to == 'localhost'

    test3 = {'action': 'shell echo hi'}
    action_module, action_args, delegate_to = args_parser.parse(thing=test3)
    assert action_module == 'shell'


# Generated at 2022-06-20 23:09:49.620136
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {
        'a': { 'b': 'c' },
        'action': { 'module': 'copy', 'src': 'a', 'dest': 'b' },
        'module': 'copy',
        'arg1': 1,
        'arg2': 2
    }
    parser = ModuleArgsParser(ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'
    assert args['src'] == 'a' and args['dest'] == 'b' and args['arg1'] == 1 and args['arg2'] == 2
    parser = ModuleArgsParser({'action': 'echo hi', 'args': 'test1=1 test2=2'})
    (action, args, delegate_to) = parser.parse()

# Generated at 2022-06-20 23:10:00.556239
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    Implementation for the unit test of ModuleArgsParser.parse
    """

    action, args, delegate_to = ModuleArgsParser({'shell': 'echo hi'}).parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi'}
    assert delegate_to == Sentinel

    action, args, delegate_to = ModuleArgsParser({'command': 'pwd', 'args': {'chdir': '/tmp'}}).parse()
    assert action == 'command'
    assert args == {'chdir': '/tmp'}
    assert delegate_to == Sentinel

    action, args, delegate_to = ModuleArgsParser({'action': 'echo hi'}).parse()
    assert action == 'action'
    assert args == {'_raw_params': 'echo hi'}

# Generated at 2022-06-20 23:10:12.741855
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:10:18.683144
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Ensure constructor does not raise exception
    ModuleArgsParser()

# Generated at 2022-06-20 23:10:32.016246
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-20 23:10:37.900312
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    input = dict(
        action = "copy dest=/tmp/src=a",
    )
    import pprint
    pprint.pprint(input)

    parser = ModuleArgsParser(task_ds=input)
    (action, args, delegate_to) = parser.parse()
    print(action, args, delegate_to)


# Generated at 2022-06-20 23:10:50.565164
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.collection_loader import add_collection_dir
    from ansible.utils.collection_loader import get_collection_dirs
    import os
    import shutil
    import tempfile

    # create a test collection dir
    test_dir = tempfile.mkdtemp()
    test_collection_dir = os.path.join(test_dir, 'test_collections')
    os.makedirs(os.path.join(test_collection_dir, 'test_namespace', 'test_collection'))
    init_file = os.path.join(test_collection_dir, 'test_namespace', 'test_collection', '__init__.py')
    with open(init_file, 'w') as f:
        f.write('# collection init file')

    # ensure the test collection dir is in the ans

# Generated at 2022-06-20 23:10:54.732298
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor with invalid type of task_ds
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds="test")
    # Constructor with valid type of task_ds
    ModuleArgsParser(task_ds={})


# Generated at 2022-06-20 23:11:05.473052
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_set1 = dict(action='echo hi')
    test_set2 = dict(local_action='echo hi')
    test_set3 = dict(action=dict(module='echo hi'))
    test_set4 = dict(action='echo hi', args=dict(foo='bar'))
    test_set5 = dict(action='shell echo hi')
    test_set6 = dict(action=dict(module='shell echo hi', foo='bar'))

    parser = ModuleArgsParser(task_ds=test_set1)
    action, args, delegate_to = parser.parse()
    assert action == 'echo'
    assert '_raw_params' in args
    assert delegate_to is None

    parser = ModuleArgsParser(task_ds=test_set2)
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-20 23:11:18.523828
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:11:28.070578
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    with pytest.raises(AssertionError):
        # task_ds is empty, but type is not dict
        ModuleArgsParser(task_ds='')
    with pytest.raises(AnsibleAssertionError):
        # task_ds is a dict, but collection_list is not a list
        ModuleArgsParser(task_ds={}, collection_list='')
    with pytest.raises(AnsibleAssertionError):
        # task_ds is a dict, but collection_list is a list and contains string
        ModuleArgsParser(task_ds={}, collection_list=['test'])

# Generated at 2022-06-20 23:11:40.994554
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # standard attrs
    assert(set(Task._valid_attrs.keys()) - set(Handler._valid_attrs.keys()) == set(['action', 'local_action', 'args', 'module']))

    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    assert(set(['local_action', 'static']) <= set(Task._valid_attrs.keys()))

    # test good case with no args
    test_task = {'action': 'copy', 'args': {'test': 'arg'}}
    assert(ModuleArgsParser(test_task).parse() == ('copy', {'test': 'arg'}, Sentinel))

    # test good case with a couple of args specified

# Generated at 2022-06-20 23:11:48.484649
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    print ("test_ModuleArgsParser_parse")
    task_ds = {
        "shell": "uptime",
        "local_action": "shell echo hi",
        "action": "shell echo ho",
        "module": "shell echo he",
        "args": "echo ha",
    }

    module_args_parser = ModuleArgsParser(task_ds)
    module_args_parser.parse()



# Generated at 2022-06-20 23:11:55.483380
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert issubclass(ModuleArgsParser, object)
    assert ModuleArgsParser != object



# Generated at 2022-06-20 23:12:08.164426
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    This is a unit test for class ModuleArgsParser.
    '''

    def _assert_invalid_param_error(data):
        ''' validate that we properly raise the error for invalid task args '''
        try:
            mapper = ModuleArgsParser()
            mapper.parse(task_ds=data)
            assert False, "Expected error was not raised"
        except AnsibleError as e:
            assert 'invalid parameter' in e.message, 'Expected error was not raised'

    def _assert_invalid_type(data):
        ''' validate that we properly raise the error for invalid payload args '''

# Generated at 2022-06-20 23:12:17.025287
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test 1.
    task_ds = {}
    module_args_parser = ModuleArgsParser(task_ds)

# Generated at 2022-06-20 23:12:21.147093
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    module_args = parser.parse(skip_action_validation=False)
    assert module_args == ('ec2')



# Generated at 2022-06-20 23:12:33.356210
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  from mock import MagicMock
  from ansible.parsing.task_ds import TaskData
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.handler_task_include import HandlerTaskInclude
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 23:12:42.332296
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:12:43.652180
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "Unit Test not implemented"

# Generated at 2022-06-20 23:12:49.389650
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': {
            'module': 'copy',
            'args': {
                'src': 'a',
                'dest': 'b'
            },
        }
    }
    # This method should be called without any exceptions
    b = ModuleArgsParser(task_ds, collection_list=None)



# Generated at 2022-06-20 23:12:54.274282
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    tmp_args = {}
    data = Task()
    data.args = tmp_args
    test_obj = ModuleArgsParser(data._ds)
    assert test_obj is not None, "test_obj should not be none"


# Generated at 2022-06-20 23:13:04.875889
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """Test module parsing"""
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    def _test(task_ds, action, args, delegate_to):
        """Create a module, test"""
        parser = ModuleArgsParser(loader=loader, task_ds=task_ds)
        (test_action, test_args, test_delegate_to) = parser.parse()
        assert action == test_action, "action wrong: a=%s t=%s" % (action, test_action)

        if delegate_to is not Sentinel:
            assert delegate_to == test_delegate_to

# Generated at 2022-06-20 23:13:27.777653
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-20 23:13:30.681669
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser({
        'action': {
            'module': 'shell',
            'args': 'pwd'
        }
    })
    assert parser._task_ds == {'action': {'module': 'shell', 'args': 'pwd'}}
    assert parser._task_attrs == frozenset(['action'])



# Generated at 2022-06-20 23:13:37.420468
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'with_items': ['127.0.0.1'], 'name': 'Add the host {{item}} in /etc/hosts', 'action': {'key': 'value'}}
    obj = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleParserError):
        obj.parse()
    #TODO



# Generated at 2022-06-20 23:13:45.007504
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_args = [
        (
            # test no-arg constructor
            {},
            {},
            None,
        ),
        (
            # test constructor with  action_plugin_config
            {'action_plugin_config': {'test': 'abc'}},
            {'action_plugin_config': {'test': 'abc'}},
            None,
        ),
    ]
    for test_input, expected, expected_exception in test_args:
        if expected_exception:
            with pytest.raises(expected_exception):
                ModuleArgsParser(task_ds=test_input)
        else:
            test_object = ModuleArgsParser(task_ds=test_input)
            assert test_object._task_ds == expected



# Generated at 2022-06-20 23:13:46.552701
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()

    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser


# Generated at 2022-06-20 23:13:47.301052
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:13:59.660268
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # create original task data structure
    task_ds = dict(
        name="test",
        action=dict(module="test")
    )
    # initialize parser
    parser = ModuleArgsParser(task_ds)
    # get the parse result of the given task data structure
    parser.parse()
    # assert the result is correct
    assert parser.resolved_action == "test"

    # given task data structure is empty
    task_ds = dict()
    # initialize parser
    parser = ModuleArgsParser(task_ds)
    # expect to raise an exception
    with pytest.raises(Exception) as excinfo:
        # get the parse result of the given task data structure
        parser.parse()
    assert "the type of 'task_ds' should be a dict" in str(excinfo.value)



# Generated at 2022-06-20 23:14:02.644698
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert module_args_parser.parse(skip_action_validation=False) == (None, None, None)

# Generated at 2022-06-20 23:14:10.779233
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Unit test for method parse of class ModuleArgsParser
    '''
    module_args_parser = ModuleArgsParser()
    module_args_parser.parse()
    # AssertionError if _task_ds is not a dictionary
    with pytest.raises(AnsibleAssertionError) as excinfo:
        module_args_parser = ModuleArgsParser('')
        module_args_parser._split_module_string('')
        module_args_parser._normalize_parameters('')
        module_args_parser._normalize_new_style_args('')
        module_args_parser._normalize_old_style_args('')
        module_args_parser.parse()
        # ParseError

# Generated at 2022-06-20 23:14:14.309964
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert ModuleArgsParser(task_ds={})
    assert ModuleArgsParser(task_ds={}, collection_list=['a.b'])

# Generated at 2022-06-20 23:14:35.325146
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    _task_ds = {'delegate_to': 'localhost', 'action': 'shell echo hi'}
    ap = ModuleArgsParser(_task_ds)
    assert(ap.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost'))

    _task_ds = {'delegate_to': 'localhost', 'local_action': 'shell echo hi'}
    ap = ModuleArgsParser(_task_ds)
    assert(ap.parse() == ('shell', {'_raw_params': 'echo hi'}, 'localhost'))

    _task_ds = {'delegate_to': 'localhost', 'action': {'shell': 'echo hi'}}
    ap = ModuleArgsParser(_task_ds)

# Generated at 2022-06-20 23:14:45.245802
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test parse() using an action with the 'command' module
    # from ansible-base/test/units/modules/test_command.py
    # test case:
    #     def test_command_exits_with_rc(self, connection):
    #         module_args = {"creates": "/tmp/test.txt"}
    #         set_module_args(module_args)
    #
    #         command_output = []
    #         if sys.platform.startswith("win"):
    #             command_output.append("")
    #         command_output.append("changed")
    #         self.connection.get_output.return_value = command_output
    #         self.connection.run.return_value = 0
    #
    #         self.execute_module(changed=True)

    task_

# Generated at 2022-06-20 23:14:57.246038
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestModuleArgsParser():
        def __init__(self, task_ds=None, collection_list=None):
            self.task_ds = task_ds
            self.collection_list = collection_list
            self.resolved_action = None

    # test for normal case
    task_ds = {'local_action': 'shell echo hi'}
    obj = TestModuleArgsParser(task_ds)
    target_obj = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = target_obj.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True, '_raw_params_expanded': 'echo hi'}
    assert delegate_to == 'localhost'
    assert obj.resolved_action is None

   

# Generated at 2022-06-20 23:14:57.967216
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:15:08.175043
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    arg_data = dict(
        action="command",
        local_action="command",
        module="command",
        _raw_params="command",
        _uses_shell="command",
        args=dict(
            _raw_params="command",
            _uses_shell="command"
        )
    )
    parser = ModuleArgsParser(arg_data)
    action, args, delegate_to = parser.parse()
    print('action: %s' % action)
    print('args: %s' % args)
    print('delegate_to: %s' % delegate_to)

if __name__ == "__main__":
    test_ModuleArgsParser_parse()

# Generated at 2022-06-20 23:15:13.171013
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': 'shell echo hi',
               'with_items': 'hi',
               'with_dict': {'a': {'b': 'c'}, 'd': 'e' },
               }
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser._task_attrs == frozenset(['with_items', 'action', 'with_dict', 'local_action', 'static'])


# Generated at 2022-06-20 23:15:17.986950
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    module_arg_parser = ModuleArgsParser(Task()._valid_attrs, Handler()._valid_attrs, collection_list=None)
    assert isinstance(module_arg_parser, ModuleArgsParser)

# Generated at 2022-06-20 23:15:26.394677
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_cases = [
        {
            'module_name': "shell",
            'module_arguments': "'echo hi'",
        },
        {
            'module_name': "shell",
            'module_arguments': "{'chdir': '/tmp'}",
        },
    ]
    for test_case in test_cases:
        module_argument_parser = ModuleArgsParser(task_ds=test_case['module_arguments'])
        (action, args, delegate_to) = module_argument_parser.split()
        assert action == test_case['module_name']



# Generated at 2022-06-20 23:15:35.697503
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    play_context = PlayContext()
    role_definition = RoleDefinition.load('my_role')
    myblock = Block(dict(task=dict(test=dict(test=1))))

    mytask = RoleInclude()
    mytask.load({'name': 'myrole', 'tasks': [myblock.serialize()]})

    print(mytask.serialize())

    module_args_parser = ModuleArgsParser(mytask._task.copy(), collection_list=None)
    print(module_args_parser.parse())


# Generated at 2022-06-20 23:15:41.155186
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # basic no module form is valid
    ds = dict(when='success')
    ModuleArgsParser(task_ds=ds)
    # basic module form is valid
    ds = dict(action='ping')
    ModuleArgsParser(task_ds=ds)


# Generated at 2022-06-20 23:16:20.571841
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    action = 'action'
    arguments = dict(a=1, b=2)
    delegate_to = 'localhost'
    module_name = 'module'
    task_ds = dict()
    task_ds[action] = {module_name: arguments}
    task_ds['delegate_to'] = delegate_to
    module_args_parser = ModuleArgsParser(task_ds)
    assert_equal(module_args_parser._task_ds, task_ds)
    assert_equal(module_args_parser._collection_list, None)
    assert_equal(module_args_parser._task_attrs, frozenset(['delegate_to']))
    assert_equal(module_args_parser.resolved_action, None)

    # test _split_module_string()
    module_string = 'shell'
