

# Generated at 2022-06-20 23:06:49.983929
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test when the type of the task data structure is None.
    parser = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError):
        parser.parse()


# Generated at 2022-06-20 23:06:58.276542
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition, TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.utils.collection_loader import AnsibleCollectionRef
    collection = AnsibleCollectionRef.from_string('os_cloud.openstack')

    # tests the 'action' parameter

# Generated at 2022-06-20 23:07:08.831507
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """
    ModuleArgsParser parse()
    """
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.utils.sentinel import Sentinel
    from collections import MutableMapping
    from ansible.errors import AnsibleAssertionError, AnsibleParserError, AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableSequence, Iterable, Mapping, MutableMapping
    from ansible.module_utils.common.dict_transformations import split_args

# Generated at 2022-06-20 23:07:10.613398
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = Mock(spec={})
    collection_list = Mock()
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    assert module_args_parser
    assert module_args_parser.parse()


# Generated at 2022-06-20 23:07:15.353167
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_arg_parser = ModuleArgsParser({'shell': 'echo hi'})
    assert module_arg_parser.parse() == ('shell', {}, Sentinel)
    module_arg_parser = ModuleArgsParser({'shell': {'args': 'echo hi'}})
    assert module_arg_parser.parse() == ('shell', {'args': 'echo hi'}, Sentinel)
    module_arg_parser = ModuleArgsParser({'action': 'shell echo hi'})
    assert module_arg_parser.parse() == ('shell', {}, Sentinel)
    module_arg_parser = ModuleArgsParser({'action': {'shell': 'echo hi'}})
    assert module_arg_parser.parse() == ('shell', {}, Sentinel)
    module_arg_parser = ModuleArgsParser({'local_action': 'shell echo hi'})

# Generated at 2022-06-20 23:07:27.576344
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class DummySrc(object):
        pass
    class DummyContext(object):
        pass
    class DummyTarget(object):
        pass
    src = DummySrc()
    target = DummyTarget()
    context = DummyContext()
    context.resolved = False
    context.redirect_list = []
    thing = None
    action = None
    delegate_to = None
    args = dict()
    additional_args = dict()
    thing = dict()
    args = dict()
    thing = 'echo hi'
    action = 'shell'
    args = dict()
    additional_args = dict()
    # Additional test to test 'action and additional_args are mutually exclusive'
    thing = dict()
    action = 'shell'
    args = dict()
    additional_args = dict()
    # Additional

# Generated at 2022-06-20 23:07:35.960343
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._set_task_and_variable_override('shell', 'command', 'echo hi')
    play_context.become = 'root'
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

    class FakePlay(Play):
        def __init__(self):
            self._ds = dict(
                name='test_play',
                hosts=['localhost'],
                gather_facts='no',
                tasks=[
                    dict(
                        name='test_task',
                        action=dict(module='shell', args='echo hi'),
                    ),
                ]
            )
            self.play_context = play

# Generated at 2022-06-20 23:07:49.242899
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    skip_action_validation=False
    thing = None
    action = None
    delegate_to = None
    args = dict()
    additional_args = None
    extra_vars = dict()
    task_ds = dict()

# Generated at 2022-06-20 23:07:59.548689
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ############################################################################
    # When a Task with a 'raw' module is parsed, the task should succeed and
    # the fields in the output should be identical to the input
    ############################################################################

    def test_parsing_raw_arguments():
        ############################################################################
        # Test with a raw module task in a playbook
        ############################################################################

        # Create the task and playbook to be parsed
        raw_action = {'raw': 'ls -la'}
        task_ds = Task().load(raw_action, task_ds=dict(), variable_manager=play_context.variable_manager, loader=play_context.loader)
        return_data = ModuleArgsParser(task_ds).parse()
        assert(return_data[0] == 'raw')

# Generated at 2022-06-20 23:08:06.120437
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test the case where the task is in one of the supported forms, parses and returns the action, arguments, and delegate_to values for the task,
    # dealing with all sorts of levels of fuzziness.
    from ansible.errors import AnsibleError, AnsibleParserError, AnsibleAssertionError
    module_string = "shell echo hi"
    task_ds = {'shell': module_string}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert module_args_parser.parse() == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    # test the case where the task is empty, should throw an error
    task_ds = {}
    module_args_parser = ModuleArgs

# Generated at 2022-06-20 23:08:31.734196
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_manager = ModuleManager(None)
    temp_task_ds = dict(
        action="shell echo hi",
    )
    module = ModuleArgsParser(temp_task_ds, None)
    action, args, delegate_to = module.parse()
    assert action == 'shell'
    assert args ==  {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to == None
    temp_task_ds = dict(
        delegate_to="localhost",
        action="shell echo hi",
    )
    module = ModuleArgsParser(temp_task_ds, None)
    action, args, delegate_to = module.parse()
    assert action == 'shell'
    assert args == {'_raw_params': 'echo hi', '_uses_shell': True}
    assert delegate_to

# Generated at 2022-06-20 23:08:41.800711
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var

    task_ds = {'action': {'src': '/tmp/b', 'dest': '/tmp/a'}}
    p = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = p.parse()
    assert action == 'copy'
    assert args == {'src': '/tmp/b', 'dest': '/tmp/a'}
    assert delegate_to is Sentinel

    task_ds = {'action': {'src': '/tmp/b', 'dest': '/tmp/a'}, 'delegate_to': 'localhost'}
    p = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = p.parse()

# Generated at 2022-06-20 23:08:53.914577
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test 1
    task_ds = """
      - name: "Test module args parser"
        shell: "ls /tmp"
    """
    # expected results
    action = 'shell'
    args = 'ls /tmp'
    delegate_to = Sentinel

    # actual results
    task_ds = load_yaml(task_ds)
    task_ds = task_ds[0]
    map = ModuleArgsParser(task_ds=task_ds)
    actual_results = map.parse()
    # compare expected and actual results
    assert actual_results == (action, args, delegate_to)
    # Test 2
    task_ds = """
      - name: "Test module args parser"
        command: "pwd"
        args:
            chdir: "/tmp"
    """
    # expected results

# Generated at 2022-06-20 23:09:01.478581
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'action': 'echo foo',
                                                   'delegate_to': 'localhost',
                                                   'run_once': True,
                                                   'when': 'False'})

    assert module_args_parser._task_ds == {'action': 'echo foo',
                                           'delegate_to': 'localhost',
                                           'run_once': True,
                                           'when': 'False'}


# Generated at 2022-06-20 23:09:07.432995
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={'a': 'b'}, collection_list=None)
    assert module_args_parser._task_ds['a'] == 'b'
    assert module_args_parser._task_attrs == frozenset(Task._valid_attrs.keys())
    assert module_args_parser.resolved_action == None



# Generated at 2022-06-20 23:09:13.215327
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    t = dict(dummy_task={'local_action':'dummy_module'})
    t2 = dict(dummy_task={'action':'dummy_module'})
    args = dict(role_path=dict(default="roles", type='path'))
    task = TaskInclude.load(t, play=Role(), task_vars=dict(), defs=args)
    task2 = TaskInclude.load(t2, play=Role(), task_vars=dict(), defs=args)

    parser = ModuleArgsParser(task_ds=t)
    (action, args, delegate_to) = parser.parse()
    parser2 = ModuleArgsParser(task_ds=t2)


# Generated at 2022-06-20 23:09:25.744866
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import copy

# Generated at 2022-06-20 23:09:26.595502
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:09:35.351351
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    for task_ds in [
        'string_action',
        {'action': 'string_action'},
        {'local_action': 'string_action'}
    ]:
        task_executor = TaskExecutor(task_ds)

        assert_equal(task_executor._task_ds, task_ds)
        assert_equal(task_executor._task_attrs, frozenset(['action', 'local_action']))

# Unit tests for _split_module_string() of class ModuleArgsParser

# Generated at 2022-06-20 23:09:47.492059
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Example Parse results
    # test 1
    # input
    task_ds = {
        'action': 'copy src=a dest=b'
    }

    # expected result
    module_args = {
        'src': 'a',
        'dest': 'b'
    }

    # test 2
    # input
    task_ds_2 = {
        'action': {
            'module': 'copy',
            'src': 'a',
            'dest': 'b'
        }
    }

    # expected result
    module_args_2 = {
        'src': 'a',
        'dest': 'b'
    }

    # test 3
    # input

# Generated at 2022-06-20 23:10:05.896738
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """ unit testing for method parse of class ModuleArgsParser """

    test_ansible_local_action_arg_validator = AnsibleModuleArgValidator()
    test_ansible_local_action_arg_validator.validate_args("local_action: command jinja2 {{search_base}}")
    test_ansible_local_action_arg_validator.validate_args("local_action: command {{search_base}} '-h'")

    test_ansible_local_action_arg_validator.validate_args("local_action: command 'hello {{search_base}}'")
    test_ansible_local_action_arg_validator.validate_args("local_action: command 'hello \"{{search_base}}\"'")

    test_ansible_local_action_arg_validator.validate_

# Generated at 2022-06-20 23:10:15.330956
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_name = 'setup'

# Generated at 2022-06-20 23:10:29.030171
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()
    ds = dict()

    # Constructor of class ModuleArgsParser
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert parser



# Generated at 2022-06-20 23:10:37.756423
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:10:50.424244
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Testing the parse method of the class ModuleArgsParser"""
    from ansible.errors import AnsibleError, AnsibleParserError, AnsibleAssertionError
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.hashing import md5s
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-20 23:11:01.952935
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:11:02.802714
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: implement unit test
    pass


# Generated at 2022-06-20 23:11:04.671609
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Basic usage
    module = ModuleArgsParser()

    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds='test')

# Generated at 2022-06-20 23:11:17.586901
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	from collections import MutableMapping

	from ansible.errors import AnsibleAssertionError, AnsibleError, AnsibleParserError
	from ansible.module_utils.six import string_types
	from ansible.template import Templar
	from ansible.utils.vars import combine_vars, isidentifier

	from ansible.playbook.block import Block
	from ansible.playbook.task import Task
	from ansible.playbook.play_context import PlayContext


	assert isinstance(True, bool) and isinstance(False, bool)

	assert isinstance(dict(), MutableMapping) and isinstance(list(), MutableMapping)

	assert issubclass(AnsibleAssertionError, Exception) and isinstance(AnsibleAssertionError(), AnsibleAssertionError)

# Generated at 2022-06-20 23:11:25.520315
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test with invalid task_ds
    obj = ModuleArgsParser(task_ds=1234)
    with pytest.raises(AnsibleAssertionError):
        obj.parse()

    # test with valid task_ds
    task_ds = dict(
        action=dict(module='ec2', region='xyz'),
        delegate_to='localhost',
        args=dict(x=1),
    )
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    action, arguments, delegate_to = obj.parse()
    assert action == 'ec2'
    assert arguments == dict(region='xyz', x=1)
    assert delegate_to == 'localhost'


# Generated at 2022-06-20 23:11:42.798755
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    result = ModuleArgsParser(task_ds={'action': 'shell', 'args': {'chdir': '/tmp'}}).parse()
    assert result[0] == 'shell'
    assert result[1] == {'_raw_params': '', 'chdir': '/tmp'}
    assert result[2] is Sentinel
    result = ModuleArgsParser(task_ds={'action': {'module': 'shell', 'args': 'whoami'}, 'args': {'chdir': '/tmp'}}).parse()
    assert result[0] == 'shell'
    assert result[1] == {'_raw_params': 'whoami', 'chdir': '/tmp'}
    assert result[2] is Sentinel

# Generated at 2022-06-20 23:11:53.881751
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = '''{
  "test": {
    "test_arg": "test_arg_value",
    "test_arg_with_ansible_prefix": "test_arg_with_ansible_prefix_value",
    "test_dict_arg": {
      "test_subarg": "test_subarg_value"
    }
  },
  "args": {
    "_raw_params": "a"
  }
}'''
    task_ds = json.loads(task_ds)
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert 'test_subarg' in args['test_dict_arg']

# Generated at 2022-06-20 23:12:07.104541
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = None
    delegate_to = None
    args = dict()
    # initialize ModuleArgsParser class object
    map_obj = ModuleArgsParser()
    assert isinstance(map_obj._task_ds, dict)
    assert map_obj._collection_list is None
    assert isinstance(map_obj._task_attrs, frozenset)
    assert map_obj.resolved_action is None

    assert map_obj._split_module_string('shell echo hi') == ('shell', 'echo hi')
    assert map_obj._split_module_string('copy src=a dest=b') == ('copy', 'src=a dest=b')

    # invalid task_ds

# Generated at 2022-06-20 23:12:16.422417
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='shell echo hi')
    TaskActionProcessor(task_ds).run()

    task_ds = dict(action="shell", args='echo hi')
    TaskActionProcessor(task_ds).run()

    task_ds = dict(action="shell", args=dict(echo='hi'))
    TaskActionProcessor(task_ds).run()

    task_ds = dict(action="shell", args='echo hi')
    TaskActionProcessor(task_ds).run()

    task_ds = dict(action="shell")
    TaskActionProcessor(task_ds).run()

    task_ds = dict(action=dict(module="shell", echo="hi"))
    TaskActionProcessor(task_ds).run()

    task_ds = dict(shell="echo", hi='hi')
    TaskActionProcess

# Generated at 2022-06-20 23:12:27.649490
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'echo hi', 'delegate_to': 'localhost', 'args': 'a='}
    obj = ModuleArgsParser(task_ds)
    act, args, delegate_to = obj.parse()
    assert act == 'echo'
    assert args == {'a': 'hi'}
    assert delegate_to == 'localhost'

    task_ds = {'module': 'ansible.builtin.get_url'}
    obj = ModuleArgsParser(task_ds)

# ==============================================================
# TaskQueueManager
#
# This is only needed for the api function 'run' but we want to hide
# the internals somewhat from the code using the api
# ==============================================================


# Generated at 2022-06-20 23:12:31.436677
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    t = parse_kv('x=1 y=2 z=3')
    #print t
    assert t == dict(x='1', y='2', z='3')



# Generated at 2022-06-20 23:12:41.252922
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Case 1: The module name is not specified, and one of the keyword args is specified
    module_args_parser = ModuleArgsParser({'shell':'echo hello'})
    assert module_args_parser.parse().__eq__(('shell', {'_raw_params': 'echo hello', '_uses_shell': True}, None))
    # Case 2: None of the args are specified
    module_args_parser = ModuleArgsParser({})
    with pytest.raises(AnsibleParserError) as excinfo:
        module_args_parser.parse()
    assert 'no module/action detected in task' in str(excinfo.value)
    # Case 3: Invalid key is specified
    module_args_parser = ModuleArgsParser({'key':'value'})

# Generated at 2022-06-20 23:12:55.091304
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': {'copy': {'src': 'a', 'dest': 'b'}}}, collection_list=[])
    assert parser._task_ds == {'action': {'copy': {'src': 'a', 'dest': 'b'}}}

    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)  # None means 'Sentinel'
    assert parser.parse() == expected

    # Exception handling - 1
    parser = ModuleArgsParser(task_ds={'action': {'copy': {'src': 'a', 'dest': 'b'}}, 'local_action': ''}, collection_list=[])

# Generated at 2022-06-20 23:12:57.401370
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={})
    assert module_args_parser is not None

# Generated at 2022-06-20 23:13:06.229621
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DataLoader()
    task_ds1 = {"delegate_to": "localhost",
                "action": "copy src=a dest=b"}
    expected1 = ('copy', {'src': 'a', 'dest': 'b'}, 'localhost')
    map1 = ModuleArgsParser(task_ds1).parse()
    assert map1 == expected1
    task_ds2 = {"action": {"module": "copy src=a dest=b"}}
    expected2 = ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    map2 = ModuleArgsParser(task_ds2).parse()
    assert map2 == expected2
    task_ds3 = {"action": {"module": "copy",
                           "src": "a",
                           "dest": "b"}}

# Generated at 2022-06-20 23:13:22.114771
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import json
    import pytest

    @pytest.fixture
    def module_args_parser():
        return ModuleArgsParser()

    @pytest.fixture
    def task_ds():
        return {}

    @pytest.fixture
    def ansible_module():
        return AnsibleModule(argument_spec=dict(host=dict(type='str')))

    def test_ModuleArgsParser_parse_action_good_action(module_args_parser, ansible_module):
        '''
        Tests the ModuleArgsParser.parse method when the task has a good action
        '''
        task_ds = dict(action='command echo hi')
        module_args_parser._task_ds = task_ds
        assert module_args_parser.parse() == ('command', dict(), None)

# Generated at 2022-06-20 23:13:28.852561
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    This method tests the constructor of class ModuleArgsParser
    """
    task_ds = dict()
    collection_list = [ "/test/path" ]

    # Execute code to be tested
    try:
        ModuleArgsParser(task_ds, collection_list)
    except Exception:
        raise AssertionError('Constructor of ModuleArgsParser failed')


# Generated at 2022-06-20 23:13:36.377031
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Create a new instance of the object to test
    parser = ModuleArgsParser()
    # Create some expected values to compare against
    expected_action = None
    expected_args = dict()
    expected_delegate_to = None
    # Call the method we want to test with some input
    result = parser.parse(skip_action_validation=False)
    # Check the values returned
    assert result == (expected_action, expected_args, expected_delegate_to)

# Generated at 2022-06-20 23:13:41.290166
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_task_ds = {}
    expected_action = ''
    expected_args = ""
    expected_delegate_to = Sentinel
    obj = ModuleArgsParser(fake_task_ds)
    action, args, delegate_to = obj.parse()
    assert action == expected_action
    assert args == expected_args
    assert delegate_to == expected_delegate_to


# Dummy test for class ModuleArgsParser

# Generated at 2022-06-20 23:13:47.292461
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:13:48.803339
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert isinstance(ModuleArgsParser()._task_ds, dict)



# Generated at 2022-06-20 23:13:51.622203
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(None, None)
    assert parser is not None



# Generated at 2022-06-20 23:13:56.897193
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Create a dict to use as the task dict (ds)
    ds = {}
    # Create a list of collections
    collection_list = []
    # Create an instance of class ModuleArgsParser
    test = ModuleArgsParser(ds, collection_list)
    # Check an attribute of test
    assert hasattr(test, '_task_attrs')

# Generated at 2022-06-20 23:14:05.771167
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # First test of valid input type
    ds = dict(a='a', b='b', c=dict(x='x', y='y', z=dict(t='t')))
    collection_list = [collection_finder.CollectionRequirement(name='my_collection', version='1.2.3'),
                       collection_finder.CollectionRequirement(name='other_collection', version='9.8.7')]
    parser = ModuleArgsParser(ds, collection_list=collection_list)

    # Now test invalid input types
    ds = list(['a', 'b', 'c'])
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(ds)

# Generated at 2022-06-20 23:14:16.916888
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser(task_ds=None, collection_list=None)
    # Test with copy action.  Should return copy and f={'src': 'dest'}
    (action, args, delegate_to) = module_args_parser.parse(skip_action_validation=True)
    assert (action, args, delegate_to) == (None, {}, Sentinel)
    module_args_parser = ModuleArgsParser(task_ds={'action': 'copy', 'src': 'a', 'dest': 'b'}, collection_list=None)
    (action, args, delegate_to) = module_args_parser.parse(skip_action_validation=True)
    assert (action, args, delegate_to) == ('copy', {'src': 'a', 'dest': 'b'}, Sentinel)
    module

# Generated at 2022-06-20 23:14:42.456435
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'}, collection_list=None)
    assert parser._task_ds == {'action': 'copy src=a dest=b'}
    assert parser._collection_list is None

# Generated at 2022-06-20 23:14:54.888437
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:15:06.534902
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_0= {'action': {'vlan': '{{ vlan_id }}', 'name': '{{ vlan_name }}', 'state': 'present', 'interface': '{{ vlan_interface }}'}}
    collection_list_0 = None
    testobj = ModuleArgsParser(task_ds_0, collection_list_0)
    testobj._task_ds = task_ds_0
    testobj._collection_list = collection_list_0
    result = testobj.parse()
    assert result == ('vlan', {'vlan': '{{ vlan_id }}', 'name': '{{ vlan_name }}', 'state': 'present', 'interface': '{{ vlan_interface }}'}, None)

# Generated at 2022-06-20 23:15:14.163744
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:15:25.200962
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('Test parse:')
    # task_ds = None
    task_ds = {
        'module': 'copy',
        'module_args': 'src=a dest=b',
        'delegate_to': 'somehost'
    }
    task_ds_1 = {
        'arg1': 'echo',
        'arg2': 'hi'
    }
    task_ds_1_1 = dict()
    task_ds_2 = dict(
        module='copy',
        module_args='src=a dest=b',
        delegate_to='somehost'
    )
    task_ds_3 = 'copy src=a dest=b'
    task_ds_4 = dict(
        action='copy',
        module_args='src=a dest=b',
    )
    task_ds_5

# Generated at 2022-06-20 23:15:35.128427
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    M = ModuleArgsParser

    # test_new_style_args
    assert({'x': '1', 'y': '2'} ==
           M._normalize_new_style_args({'x': '1', 'y': '2'}, 'shell'))
    assert({'_raw_params': 'echo hi'} ==
           M._normalize_new_style_args('echo hi', 'shell'))
    assert({'xyz': 'echo hi'} ==
           M._normalize_new_style_args('xyz=echo hi', 'copy'))
    assert(({'_raw_params': 'echo hi', 'foo': 'bar'} ==
           M._normalize_new_style_args('echo hi foo=bar', 'shell')))

    # test_old_style_args

# Generated at 2022-06-20 23:15:45.300027
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # setup parametes used to call method parse
    task_ds = dict()

    class TestModuleArgsParser(ModuleArgsParser):
        pass
    obj = TestModuleArgsParser(task_ds=task_ds)
    skip_action_validation = False

    # attempt to call method parse
    try:
        ret = obj.parse(skip_action_validation=skip_action_validation)

    # catch and print exceptions
    except Exception as e:
        print('EXCEPTION from ansible.module_utils.common.module_common:ModuleArgsParser.parse: ', str(e))

# Generated at 2022-06-20 23:15:57.339038
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args = dict(
        action = dict(
            module = 'slurp',
            args = dict(
                src = '/tmp/1.txt',
                dest = '/tmp/2.txt',
            )
        )
    )

# Generated at 2022-06-20 23:15:59.515187
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {}
    modules_parser = ModuleArgsParser()
    assert modules_parser is not None


# Generated at 2022-06-20 23:16:07.428722
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import assertRegex
    arg_data = {
        'action': 'example.py arg1=1 arg2=2',
        'args': {
            'arg3': '3',
            'arg4': 4,
            'arg5': '5'
        }
    }
    module_args_parser = ModuleArgsParser(arg_data)
    # Call method
    result = module_args_parser.parse()
    # Verify result
    assert len(result) == 3
    assert result[0] == 'example.py'