

# Generated at 2022-06-20 23:06:53.036272
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict()
    test = ModuleArgsParser(task_ds)
    assert test._task_ds == task_ds
    assert test._collection_list is None
    assert test.resolved_action is None


# Generated at 2022-06-20 23:06:56.975696
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    for thing in [u'echo hi',
                  {u'shell': u'echo hi'},
                  u'shell echo hi']:
        result = ModuleArgsParser(thing).parse()
        assert result == (u'shell', {u'_raw_params': u'echo hi'}, Sentinel)
    return True


# Generated at 2022-06-20 23:07:05.522701
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # empty task
    task = {}
    parser = ModuleArgsParser(task)
    # no required parameter 'action'
    assert parser.parse()[0] is None

    # unsupported task
    task = {'action1': 'action1'}
    parser = ModuleArgsParser(task)
    # no required parameter 'action'
    assert parser.parse()[0] is None

    # old style task
    task = {'action': 'command'}
    parser = ModuleArgsParser(task)
    # no required parameter 'action'
    assert parser.parse()[0] is None

    # normal style task
    task = {'action': 'command', 'args': {'arg1': 'arg1'}}
    parser = ModuleArgsParser(task)
    # no required parameter 'action'

# Generated at 2022-06-20 23:07:06.706725
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mp1 = ModuleArgsParser()
    assert False
    mp2 = ModuleArgsParser()
    assert False

# Generated at 2022-06-20 23:07:16.116380
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test constructor of class ModuleArgsParser with empty task_ds
    parser = ModuleArgsParser()
    assert parser
    assert parser._task_ds == {}
    assert parser._task_attrs == frozenset(['name',
                                            'ignore_errors',
                                            'become', 'become_method',
                                            'become_user', 'become_flags',
                                            'register', 'environment',
                                            'when', 'async_val', 'poll', 'until',
                                            'changed_when', 'failed_when', 'delegate_to',
                                            'local_action', 'static'])
    assert parser.resolved_action is None
    # Test constructor of class ModuleArgsParser with task_ds

# Generated at 2022-06-20 23:07:28.322660
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    def test_module_args_parser_parse(action, local_action, module, args, delegate_to, expected_action, expected_args, expected_delegate_to):

        if not isinstance(expected_args, list):
            expected_args = [expected_args]
        if not isinstance(expected_delegate_to, list):
            expected_delegate_to = [expected_delegate_to]

        for index, args_val in enumerate(args):
            args_args = args_val.copy()
            args = args_args.pop('args')
            expected_args_args = expected_args[index].copy()
            expected_args = expected_args_args.pop('args')


# Generated at 2022-06-20 23:07:29.020195
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert True



# Generated at 2022-06-20 23:07:29.729990
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass



# Generated at 2022-06-20 23:07:42.572816
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    raw_task_ds = {"name": "test"}
    parser = ModuleArgsParser(raw_task_ds, collection_list=[])
    assert parser.resolved_action is None

# Unit tests for _split_module_string, _normalize_parameters, _normalize_old_style_args, _normalize_new_style_args, parse

# Generated at 2022-06-20 23:07:47.083222
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    """
    Validate that the ModuleArgsParser class exists and can be initialized.
    """
    task_ds = {}
    collection_list = None
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    assert parser is not None


# Generated at 2022-06-20 23:08:12.161130
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ''' test ModuleArgsParser class '''

    # a valid task with 'action'
    task = {'action':'shell echo hi', 'delegate_to': 'localhost'}
    args_parser = ModuleArgsParser(task)
    assert args_parser.parse()[0] == 'shell'

    # a valid task with 'local_action'
    task = {'local_action':'shell echo hi'}
    args_parser = ModuleArgsParser(task)
    assert args_parser.parse()[0] == 'shell'

    # a valid task with 'module'
    task = {'module': 'copy src=a dest=b'}
    args_parser = ModuleArgsParser(task)
    action, args, delegate_to = args_parser.parse()
    assert action == 'copy'

# Generated at 2022-06-20 23:08:18.609855
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_bytes
    task_ds = {'module': 'test_module', 'param1': 'value1'}
    collection_list = ansible_collections
    module_arg_parser = ModuleArgsParser(task_ds, collection_list)
    result = module_arg_parser.parse()
    assert result[0] == 'test_module'
    assert result[1] == {'param1': 'value1'}

# Generated at 2022-06-20 23:08:24.837747
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds  = dict(a="b", c="d")
    expected = ('c', dict(a="b",c="d"), None)
    ml = ModuleArgsParser()
    actual = ml.parse(task_ds)
    assert_equal(expected, actual)


# Generated at 2022-06-20 23:08:29.519247
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # case 1: action: copy src=a dest=b
    ds = dict(action='copy src=a dest=b')
    # Act
    args_parser = ModuleArgsParser(task_ds=ds)
    # Assert
    assert ds == args_parser._task_ds

# Generated at 2022-06-20 23:08:40.682778
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': 'bar', 'args': {'_raw_params': '1 2 3'}}
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser._collection_list is None
    assert parser._task_attrs == frozenset(['local_action', 'action', 'delegate_to', 'static', 'loop', 'delegate_facts', 'ignore_errors', 'async', 'poll', 'register', 'arguments', 'when', 'failed_when', 'always_run', 'run_once', 'retries', 'delay', 'until', 'tags', 'check_mode', 'notify', 'environment'])
    assert parser.resolved_

# Generated at 2022-06-20 23:08:52.470006
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:09:04.626022
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    source = dict(action='shell echo hi')
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    result = ModuleArgsParser(source).parse()
    assert result == expected_result

    source = dict(action=dict(module='shell echo hi'))
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    result = ModuleArgsParser(source).parse()
    assert result == expected_result

    source = dict(action={'module': 'shell echo hi'})
    expected_result = ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)
    result = ModuleArgsParser(source).parse()
    assert result == expected_result


# Generated at 2022-06-20 23:09:14.563258
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {'b': '{{b}}', 'a': '{{a}}'}
    action = 'action'
    delegate_to = 'delegate_to'
    action_functions_map = {'action': 'action_function'}
    skip_action_validation = True
    task_ds = {'b': '{{b}}', 'a': '{{a}}', 'action': 'action', 'delegate_to': 'delegate_to'}

# Generated at 2022-06-20 23:09:26.710479
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    for _task_ds in [{'action': 'shell echo hi', 'delegate_to': 'localhost'},
                     {'action': 'shell', 'args': 'echo hi',  'delegate_to': 'localhost'},
                     {'action': 'shell', 'args': dict(echo='hi'), 'delegate_to': 'localhost'}]:
        assert ModuleArgsParser(_task_ds).parse() == (u'shell', dict(echo='hi'), 'localhost')


# Generated at 2022-06-20 23:09:39.357806
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    def _load_task_data(file_name, task_data):
        task_data_file = os.path.join(TEST_DIR, file_name)
        with open(task_data_file) as f:
            data = yaml.safe_load(f)
            assert data is not None, "Expected to load yaml data"
            task_data.extend(data)

    task_data = []
    _load_task_data('test_ansible_module_args.yml', task_data)

    for entries in task_data:
        for data in entries['data']:
            parser = ModuleArgsParser(data)
            action, args, delegate_to = parser.parse()

# Generated at 2022-06-20 23:09:55.603467
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test with only module name
    task_ds = {'module': 'ping'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args = module_args_parser.parse()
    assert action == 'ping'
    assert args == {}

    # test with module and args
    task_ds = {'module': 'ping', 'extra_args': '-c 2'}
    module_args_parser = ModuleArgsParser(task_ds)
    action, args = module_args_parser.parse()
    assert action == 'ping'
    assert args == {'extra_args': '-c 2'}

    # test with module action as a string
    task_ds = {'module': 'ping extra_args=-c 2'}
    module_args_parser = ModuleArgsParser(task_ds)


# Generated at 2022-06-20 23:10:08.870370
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # test with no tasks
    task = {}
    module_parser = ModuleArgsParser(task)
    (action, args, delegate_to) = module_parser.parse()
    assert action is None
    assert args is None
    assert delegate_to is None

    # test with no known action
    task = { 'foo': 'bar' }
    module_parser = ModuleArgsParser(task)
    with pytest.raises(AnsibleParserError):
        (action, args, delegate_to) = module_parser.parse()

    # test with a known action in args
    task = { 'foo': 'bar', 'args': {'baz': 'bam'} }
    module_parser = ModuleArgsParser(task)
    (action, args, delegate_to) = module_parser.parse()
    assert action == 'foo'

# Generated at 2022-06-20 23:10:21.001197
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test basic usage
    kwargs = { 'action' : 'shell echo hi' }
    result = ModuleArgsParser(task_ds=kwargs).parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, None)

    kwargs = { 'local_action' : 'shell echo hi' }
    result = ModuleArgsParser(task_ds=kwargs).parse()
    assert result == ('shell', {'_raw_params': 'echo hi', '_uses_shell': True}, 'localhost')

    kwargs = { 'action' : {'module': 'copy', 'src': 'a', 'dest': 'b'} }
    result = ModuleArgsParser(task_ds=kwargs).parse()

# Generated at 2022-06-20 23:10:33.427388
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.role.include import Include
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    # set up a fake loader from which we can retrieve the action plugin
    fake_loader = DictDataLoader({})
    fake_loader.set_basedir('')
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action'))

    # set up a mock inventory with a fake host
    fake_inventory = MagicMock()
    fake_inventory.get_hosts.return_value = ['127.0.0.1']
    fake_inventory.get_host.return_value = MagicMock()
   

# Generated at 2022-06-20 23:10:46.281729
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test to create a new ModuleArgsParser object
    task_ds = dict(
        action = dict(
            module = 'command',
            args = 'echo "{{inventory_hostname}}"'
        )
    )
    result = ModuleArgsParser(task_ds)

    # test to evaluate the type of ModuleArgsParser
    assert isinstance(result, ModuleArgsParser)

    # test to evaluate the type of task_ds
    assert isinstance(result._task_ds, dict)

    # test to check the value of result._task_ds
    assert result._task_ds == task_ds

    # test to evaluate the type of result._task_attrs
    assert isinstance(result._task_attrs, frozenset)

    # test to evaluate the result._task_attrs

# Generated at 2022-06-20 23:10:58.080350
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    action_args_dict = dict(name='test', test='test_arg')
    test_ModuleArgs = ModuleArgsParser(action_args_dict)
    assert test_ModuleArgs._task_ds == action_args_dict
    assert not test_ModuleArgs._collection_list
    assert test_ModuleArgs.resolved_action is None

# Generated at 2022-06-20 23:11:07.214929
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test basic task
    task = dict(
        action=dict(module='testmodule', foo='bar', bam='baz')
    )
    parser = ModuleArgsParser(task)
    action, args, delegate_to = parser.parse()
    assert action == 'testmodule'
    assert args == dict(foo='bar', bam='baz')
    assert delegate_to is None

    # Test basic task with args
    task = dict(
        action=dict(module='testmodule', foo='bar', bam='baz'),
        args=dict(one=1, two=2)
    )
    parser = ModuleArgsParser(task)
    action, args, delegate_to = parser.parse()
    assert action == 'testmodule'

# Generated at 2022-06-20 23:11:19.376178
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import merge_hash
    import ansible.constants as C
    from ansible.module_utils.six import integer_types
    import sys

    # Basic use case of ModuleArgsParser class
    module_args_parser = ModuleArgsParser(task_ds=dict())
    assert type(module_args_parser._task_ds) == dict
    assert module_args_parser._task_ds == {}
    assert type(module_args_parser._task_attrs) == set
    assert type(module_args_parser._task_attrs) == type

# Generated at 2022-06-20 23:11:30.312505
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test basic instantiation
    module_args_parser = ModuleArgsParser()
    assert hasattr(module_args_parser, 'resolved_action')
    assert module_args_parser.resolved_action is None

    # test all supported instantiation forms
    module_args_parser = ModuleArgsParser(task_ds={'a': 1})
    assert module_args_parser._task_ds == {'a': 1}
    assert hasattr(module_args_parser, 'resolved_action')
    assert module_args_parser.resolved_action is None

    module_args_parser = ModuleArgsParser(collection_list=['a', 'b'])
    assert module_args_parser._collection_list == ['a', 'b']
    assert hasattr(module_args_parser, 'resolved_action')
    assert module_args

# Generated at 2022-06-20 23:11:34.293160
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    d = dict(a='ansible', b='rocks')
    parser = ModuleArgsParser(dict(a='ansible', b='rocks'))
    assert d is parser._task_ds


# Generated at 2022-06-20 23:11:49.476904
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six import PY3

    task_ds = {
        'action': 'shell',
        'delegate_to': 'localhost',
        'args': 'shell echo hi'
    }

    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    assert result == ('shell', {'shell': 'echo hi'}, 'localhost')

    task_ds = {
        'action': {
            'module': 'shell',
            'delegate_to': 'localhost',
            'args': 'echo hi'
        }
    }

    module_args_parser = ModuleArgsParser(task_ds)
    result = module_args_parser.parse()
    assert result == ('shell', {'echo': 'hi'}, 'localhost')

    task_

# Generated at 2022-06-20 23:12:01.264533
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:12:09.820747
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {'action': 'copy src=a dest=b'}
    with pytest.raises(AnsibleAssertionError):
        # The type of 'task_ds' should be a dict
        ModuleArgsParser('task_ds')
    with pytest.raises(AnsibleParserError) as e:
        ModuleArgsParser(ds, collection_list=None).parse()
    assert "unexpected parameter type in action: %s" % type("src=a dest=b") in to_text(e)


# Generated at 2022-06-20 23:12:19.378701
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = None
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    assert obj.parse(skip_action_validation) == (None, {}, None)

    task_ds = {}
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    assert obj.parse(skip_action_validation) == (None, {}, None)

    task_ds = 'somethingreallywrong'
    collection_list = None
    obj = ModuleArgsParser(task_ds, collection_list)
    skip_action_validation = False
    with pytest.raises(AnsibleAssertionError):
        obj.parse(skip_action_validation)

   

# Generated at 2022-06-20 23:12:32.264437
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:12:41.651911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils import basic
    from ansible.module_utils.six import string_types

    fake_loader = DictDataLoader({
        "test": """---
- hosts: test
  tasks:
    - name: "simple usage"
      test_module:
        param1: ok
        param2: ok
    - name: "complex usage"
      test_module:
        param1: ok
        param2: ok
    - name: "complex usage"
      test_module:
        param1: ok
        param2: ok
"""
        })
    fake_play = Play()
    fake_play._loader = fake_loader
    fake_play._variable_manager = VariableManager()
    fake_play_ds = yaml.load(fake_loader.get("test"))

# Generated at 2022-06-20 23:12:54.034426
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # default constructor
    obj = ModuleArgsParser()
    assert obj.resolved_action is None

    # constructor with valid parameters should always pass
    collection_list = []
    task_ds = {}
    obj = ModuleArgsParser(collection_list=collection_list, task_ds=task_ds)
    assert obj.resolved_action is None

    # constructor with wrong parameters should always fail
    collection_list = {}
    task_ds = []
    with pytest.raises(AnsibleAssertionError):
        obj = ModuleArgsParser(collection_list=collection_list, task_ds=task_ds)
    with pytest.raises(AnsibleAssertionError):
        obj = ModuleArgsParser(collection_list=None, task_ds=task_ds)



# Generated at 2022-06-20 23:12:59.682206
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    adhock = {}
    adhock['action'] = 'shell'
    adhock['shell'] = 'echo hi'

    map = ModuleArgsParser(adhock)
    assert map.parse() == ('shell', {u'_raw_params': u'echo hi', u'_uses_shell': True}, None)



# Generated at 2022-06-20 23:13:07.232413
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.sentinel import Sentinel
    task_ds = {'action': 'shell echo hi'}
    mpa = ModuleArgsParser(task_ds=task_ds)
    assert mpa._split_module_string(task_ds['action']) == ('shell', 'echo hi')
    assert mpa._normalize_old_style_args(task_ds) == ('shell', {'echo': True, 'hi': True})
    assert mpa._normalize_new_style_args(task_ds) == {'echo': True, 'hi': True}
    assert mpa._normalize_parameters(task_ds) == ('shell', {'echo': True, 'hi': True})

# Generated at 2022-06-20 23:13:08.158097
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO
    pass


# Generated at 2022-06-20 23:13:18.360275
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser_instance = ModuleArgsParser()
    id_ = module_args_parser_instance.id
    assert id_ == 'a79d632b3d8937e46a0c638f40e45e67'
    del module_args_parser_instance


# Generated at 2022-06-20 23:13:31.268052
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print("starting %s" % inspect.currentframe().f_code.co_name)

# Generated at 2022-06-20 23:13:40.833456
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    args = {'_raw_params': "echo hi", '_uses_shell': 'True'}
    delegate_to = 'localhost'
    task_ds = {'local_action': "shell echo hi"}
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    action_result, args_result, delegate_to_result = module_args_parser.parse()
    print(action, args, delegate_to)
    print(action_result, args_result, delegate_to_result)

# Generated at 2022-06-20 23:13:49.262112
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'action': 'ping',
        'args': {
            'data': 'pong',
        }
    }
    ModuleArgsParser(task_ds)

    # 'args' must be a dictionary, not a string
    task_ds['args'] = 'pong'
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(task_ds)

    # 'action' can't be a dictionary
    task_ds['action'] = {'data': 'pong'}
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(task_ds)

    # 'local_action' can't be a dictionary either
    task_ds = {'local_action': {'data': 'pong'}}

# Generated at 2022-06-20 23:13:58.212757
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils._text import to_bytes, to_text
    # test textual input as input
    with pytest.raises(AnsibleAssertionError) as e:
        ModuleArgsParser('test_task_ds')
    assert to_text(e.value.args[0]) == "the type of 'task_ds' should be a dict, but is a %s" % type('test_task_ds')

    # test dict input as input
    ModuleArgsParser(common_play_ds)



# Generated at 2022-06-20 23:14:03.042968
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """ Unit test for method parse of class ModuleArgsParser
    """

    # Arrange

    # Act
    # Assert
    task_ds = {'action': None}
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()
    assert result is not None
    assert len(result) == 3



# Generated at 2022-06-20 23:14:10.703111
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    fake_ds = {'local_action': u'pwd', 'delegate_to': 'localhost'}
    fake_collection_list = ['<module name>']
    fake_task = module_common.ModuleArgsParser(fake_ds, fake_collection_list)
    fake_thing = {u'_uses_shell': False, u'_raw_params': u'pwd'}
    fake_action = 'command'
    fake_skip_action_validation = False

    fake_result = fake_task.parse(fake_skip_action_validation)

    assert fake_result == (fake_action, fake_thing, 'localhost')

# Generated at 2022-06-20 23:14:15.551527
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    a = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        a.parse()
    assert 'the type of ' in str(excinfo.value)


# Generated at 2022-06-20 23:14:19.089241
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None
    args_parser = ModuleArgsParser(task_ds, collection_list)
    assert args_parser.parse() == ('', {}, None)



# Generated at 2022-06-20 23:14:24.345633
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {"action": "shell echo hi"}
    parser = ModuleArgsParser(task_ds)
    #Test with optional parameters
    result = parser.parse(skip_action_validation=True)
    assert result[0] == "shell" and result[1] == {"_raw_params": "echo hi"} and result[2] is None

# Generated at 2022-06-20 23:14:41.829144
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    task_ds = {}
    assert isinstance(task_ds, dict)
    assert isinstance(task_ds, object)

    collection_list = None
    assert collection_list is None
    assert collection_list == None

    # store the valid Task/Handler attrs for quick access
    task_valid_attrs = set(Task._valid_attrs.keys())
    task_valid_attrs.update(set(Handler._valid_attrs.keys()))

    # HACK: why are these not FieldAttributes on task with a post-validate to check usage?
    task_valid_attrs.update(['local_action', 'static'])
    task_valid_attrs = frozenset(task_valid_attrs)



# Generated at 2022-06-20 23:14:47.481643
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    root = ModuleArgsParser()
    with pytest.raises(AnsibleAssertionError):
        root = ModuleArgsParser(task_ds=None, collection_list="test")
    with pytest.raises(AnsibleAssertionError):
        root = ModuleArgsParser(task_ds=None, collection_list=dict())
    with pytest.raises(AnsibleAssertionError):
        root = ModuleArgsParser(task_ds=None, collection_list=None)



# Generated at 2022-06-20 23:15:00.354934
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_processor = TaskProcessor(task_ds=dict(action=dict(module='ec2', name='hello'), delegate_to='127.0.0.1'))

    assert task_processor.parse() == ('ec2', {'name': 'hello'}, '127.0.0.1')

    task_processor = TaskProcessor(task_ds=dict(action=dict(module='copy', src='{{ src_file }}', dest='{{ dest_file }}')))
    assert task_processor.parse() == ('copy', {'src': '{{ src_file }}', 'dest': '{{ dest_file }}'}, Sentinel)

    task_processor = TaskProcessor(task_ds=dict(action='copy src={{ src_file }} dest={{ dest_file }}'))

# Generated at 2022-06-20 23:15:10.482892
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils import context_objects as co

    this_module = sys.modules[__name__]
    this_dir = os.path.dirname(os.path.realpath(this_module.__file__))
    dummy_host = Host(name='dummy_host')

    def _is_task_with_args(task, expected_args):
        task_ds = task._ds
        parser = ModuleArgsParser(task_ds=task_ds)
        action, args = parser.parse()
        assert args == expected_args


# Generated at 2022-06-20 23:15:13.460083
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Ensure ModuleArgsParser is calling its super constructor.
    '''

    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=None)


# Generated at 2022-06-20 23:15:25.059076
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    object1 = {"action": "shell echo hi", "resolved_action": "command"}
    object2 = {"action": "shell echo hi", "resolved_action": "command"}
    object3 = {"action": "shell echo hi", "resolved_action": "command"}
    object4 = {"action": "shell echo hi", "resolved_action": "command"}
    object5 = {"action": "shell echo hi", "resolved_action": "command"}
    object6 = {"action": "shell echo hi", "resolved_action": "command"}
    object7 = {"action": "shell echo hi", "resolved_action": "command"}
    object8 = {"action": "shell echo hi", "resolved_action": "command"}
    object9 = {"action": "shell echo hi", "resolved_action": "command"}
   

# Generated at 2022-06-20 23:15:35.031545
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.compat.tests import unittest

    class TestModuleArgsParser(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_ctor_empty(self):
            module_args_parser = ModuleArgsParser({})
            self.assertEqual(module_args_parser._task_ds, {})
            self.assertEqual(module_args_parser._collection_list, None)
            self.assertEqual(module_args_parser.resolved_action, None)

        def test_ctor_task_ds_not_dict(self):
            # Test a non-dict element in task_ds.
            self.assertRaises(AnsibleAssertionError, ModuleArgsParser, [])

    def main():
        unittest.main()


# Generated at 2022-06-20 23:15:37.971970
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    actionobj = ModuleArgsParser()
    assert 'action' == actionobj.parse(actionobj)

# Class TaskExecutor

# Generated at 2022-06-20 23:15:41.627523
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    action_parser = ActionModuleParser(task_ds={'action': 'shell echo hi'}, collection_list=None)
    assert action_parser is not None


# Generated at 2022-06-20 23:15:54.760144
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

    d = {'action': {'module': 'ec2', 'args': {'region': 'xyz'}}}
    (action, args, delegate_to) = parser.parse(d)
    assert action == 'ec2'
    assert args['region'] == 'xyz'
    assert delegate_to is None

    d = {'action': {'module': 'ec2', 'region': 'xyz'}}
    (action, args, delegate_to) = parser.parse(d)
    assert action == 'ec2'
    assert args['region'] == 'xyz'
    assert delegate_to is None

    d = {'action': {'module': 'ec2 region=xyz'}}
    (action, args, delegate_to) = parser.parse(d)

# Generated at 2022-06-20 23:16:22.051724
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds=dict(action=dict(module='copy', src='a', dest='b')))
    action, args, _ = parser.parse()
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    parser = ModuleArgsParser(task_ds=dict(action=dict(shell='echo hi')))
    action, args, _ = parser.parse()
    assert action == 'shell'
    assert args['_raw_params'] == 'echo hi'
    parser = ModuleArgsParser(task_ds=dict(action='shell echo hi'))
    action, args, _ = parser.parse()
    assert action == 'shell'
    assert args['_raw_params'] == 'echo hi'