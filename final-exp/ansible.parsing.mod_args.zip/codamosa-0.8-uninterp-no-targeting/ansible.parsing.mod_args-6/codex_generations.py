

# Generated at 2022-06-20 23:07:05.909921
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # This test is to see if the value of '_raw_params' is correct
    # when creating a new task using the old style of command parameters.
    # The other tests in this class are covered by test_get_action_args.py
    # which is a more generic test.
    task_ds = dict(action='shell', args='ls', _raw_params='ls')
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert args.get('_raw_params') == 'ls' and action == 'shell'


# Generated at 2022-06-20 23:07:07.216834
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    m = ModuleArgsParser()
    if not isinstance(m, ModuleArgsParser):
        raise AssertionError("Failed to Initialize")

# Generated at 2022-06-20 23:07:16.342662
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_input = '''
    - name: test module name
      shell: foo bar
      args:
        ignore_errors: yes
        executable: /bin/bar
    '''

    tasks = yaml.load(task_input)
    assert isinstance(tasks, list)
    assert len(tasks) == 1

    task = ModuleArgsParser(task_ds=tasks[0]).parse()
    assert isinstance(task, tuple)

    assert task[0] == 'shell'
    assert task[2] is None or task[2] is Sentinel
    assert task[1]['cmd'].strip() == 'foo bar'
    assert task[1]['executable'].strip() == '/bin/bar'
    assert task[1]['ignore_errors'] is True


# Generated at 2022-06-20 23:07:28.549701
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test ModuleArgsParser constructor and its interface.
    '''

    # Test constructor
    try:
        # Test the error condition
        ModuleArgsParser({"action": test_dict})
    except AnsibleAssertionError as e:
        assert "dict" in to_text(e), "Expected dict in exception message; got: %s" % to_text(e)

    assert ModuleArgsParser({"action": {"module": "test_module"}}), \
        "Expected constructor to return `True`"

    module_args_parser = ModuleArgsParser({"action": {"module": "test_module"}})
    assert (module_args_parser._task_ds["action"]["module"] == "test_module"), \
        "Expected task_ds to contain specified action correctly"

    assert module_args_parser

# Generated at 2022-06-20 23:07:41.184743
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # valid ds, no collection
    ds = {'action': {'local_action': {'shell': 'command'}}}
    x = ModuleArgsParser(ds)
    (action, args, delegate_to) = x.parse()
    assert action == 'shell'
    assert args == {}

    # valid ds, with collection
    ds = {'action': {'local_action': {'my.collection.shell': 'command'}}}
    x = ModuleArgsParser(ds, collection_list=['my.collection'])
    (action, args, delegate_to) = x.parse()
    assert action == 'shell'
    assert args == {}

    # valid ds, with module
    ds = {'action': {'my.collection.shell': 'command'}}

# Generated at 2022-06-20 23:07:46.396654
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = dict(
        action=dict(
            delegate_to=None,
            args=dict(
                _raw_params=None,
                key=None,
                _uses_shell=False,
                _raw_params_expanded=None
            ),
            module_version_str=None,
            module_lang=None,
            module_name=None,
            _ansible_parsed=True,
            __ansible_argspec=None,
            _ansible_no_log=False,
            _ansible_debug=False,
            _ansible_diff=False,
            _ansible_check_mode=False,
            _ansible_select_params=None
        ),
        name='test'
    )

    parser = ModuleArgsParser()

# Generated at 2022-06-20 23:07:57.910062
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.basic import AnsibleModule
    import json
    dummy_task = {'name': 'dummy task'}
    parser = ModuleArgsParser(task_ds=dummy_task)
    module_name, args, delegate_to = parser.parse()
    assert module_name == 'dummy task'
    assert args == {}
    assert delegate_to == None
    dummy_task = {'name': 'dummy task', 'args': {'arg1': 'arg1'}}
    parser = ModuleArgsParser(task_ds=dummy_task)
    module_name, args, delegate_to = parser.parse()
    assert module_name == 'dummy task'
    assert args == {'arg1': 'arg1'}
    assert delegate_to == None

# Generated at 2022-06-20 23:08:09.657667
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    '''
    Test module args parse
    '''

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._json_compat import json
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleScalar
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO

    # The test case values can be either a string or a Python dictionary
    # data.

# Generated at 2022-06-20 23:08:17.147321
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():  # pylint: disable=too-many-statements
    """
    This is a unit test for constructor of class ModuleArgsParser.
    """
    from ansible.playbook.task import Task

    # test old style of tasks that use 'action' with string args
    data1 = dict(action='ping', delegate_to='xyz')
    parser1 = ModuleArgsParser(task_ds=data1)
    res1 = parser1.parse()
    assert res1 == ('ping', {}, 'xyz')

    data2 = dict(action='ping')
    parser2 = ModuleArgsParser(task_ds=data2)
    res2 = parser2.parse()
    assert res2 == ('ping', {}, None)

    data3 = dict(action='ping', delegate_to='', args='-v')
    parser3 = ModuleArgs

# Generated at 2022-06-20 23:08:29.759989
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:08:56.900141
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    data = """
    - name: Check for changed file for X.1
      stat:
        path: /tmp/X.1
        register: output
      tags: [ 'debug' ]
    - debug:
        msg: "X.1 has changed"
      when: output.stat.exists
      tags: [ 'debug' ]
    """
    tasks = preprocess_data(data)
    results = []
    for task in tasks:
        test_parser = ModuleArgsParser(task_ds=task)
        results.append(test_parser.parse())

# Generated at 2022-06-20 23:08:58.148436
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    result1 = {}
    ma1 = ModuleArgsParser(task_ds=result1)
    ma1.parse()
    assert result1 == {}


# Generated at 2022-06-20 23:09:02.718758
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg_parser = ModuleArgsParser(
        task_ds={'module': 'copy', 'src': '/src/file', 'dest': '/dest/directory', 'mode': '0777'}
    )
    module_arg_parser.parse()


# Generated at 2022-06-20 23:09:10.893875
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    cases = [
        dict(
            task_ds=dict(action='shell', args=dict(chdir='/tmp')),
            action='shell',
            args=dict(chdir='/tmp'),
            delegate_to=None,
        ),
        dict(
            task_ds=dict(module='shell', args=dict(chdir='/tmp')),
            action='shell',
            args=dict(chdir='/tmp'),
            delegate_to=None,
        ),
        dict(
            task_ds=dict(action='shell', args=dict(chdir='/tmp'), delegate_to='localhost'),
            action='shell',
            args=dict(chdir='/tmp'),
            delegate_to='localhost',
        ),
    ]

# Generated at 2022-06-20 23:09:23.419264
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds1 = {'action': 'shell echo hi'}
    collection_list1 = None

# Generated at 2022-06-20 23:09:25.832393
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser_instance = ModuleArgsParser()
    assert isinstance(module_args_parser_instance, ModuleArgsParser)

# Generated at 2022-06-20 23:09:39.321548
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    items = ({'action': {'module': 'shell echo hi'}, 'delegate_to': 'localhost'},
             {'action': {'module': 'copy src=a dest=b'}, 'delegate_to': 'localhost'},
             {'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}, 'delegate_to': 'localhost'},
             {'action': {'module': ''}})

    for test_item in items:
        test_parser = ModuleArgsParser(test_item, collection_list=None)
        (action, args, delegate_to) = test_parser.parse()
        print("action: %s, delegate_to: %s, args: %s" % (action, delegate_to, args))


# Generated at 2022-06-20 23:09:43.914505
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils._text import to_text, to_bytes
    ds = dict(
        copy=dict(
            src='a',
            dest='b',
        ),
        ping=dict(),
    )

    for action, arg_dict in iteritems(ds):
        with pytest.raises(AnsibleError):
            args = ModuleArgsParser(ds[action]).parse()

    ds = {'action': 'copy src=a dest=b'}
    args = ModuleArgsParser(ds).parse()

    assert args == ('copy', {'dest': 'b', 'src': 'a'})

    ds = 'copy src=a dest=b'
    args = ModuleArgsParser(ds).parse()

    assert args == ('copy', {'dest': 'b', 'src': 'a'})



# Generated at 2022-06-20 23:09:54.687739
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import os
    import tempfile
    import yaml

    def _read_vars(path):
        if not os.path.exists(path):
            return None
        with open(path, 'rb') as f:
            return yaml.safe_load(f)

    def _get_tempfile_path(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'wb') as tmp:
            tmp.write(to_bytes(content))
        return path

    c = ModuleArgsParser._normalize_old_style_args('copy src=a dest=b')
    assert c == ('copy', {'src': 'a', 'dest': 'b'})

    c = ModuleArgsParser._normalize_old_style_args('copy  src=a   dest=b')

# Generated at 2022-06-20 23:10:07.792965
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # check all possible inputs
    my_parser = get_parser(task_ds={'action': {'module': 'abc', 'xyz': 'abc'}}, collection_list=[])
    module, args, delegate_to = my_parser.parse()
    assert module == 'abc'
    assert args == {'xyz': 'abc'}
    assert delegate_to == Sentinel

    my_parser = get_parser(task_ds={'action': 'module'}, collection_list=[])
    module, args, delegate_to = my_parser.parse()
    assert module == 'module'
    assert args == {}
    assert delegate_to == Sentinel

    my_parser = get_parser(task_ds={'action': 'module cmd1=a cmd2=b'}, collection_list=[])
    module, args, delegate_to = my

# Generated at 2022-06-20 23:10:30.014444
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser()
    assert m.parse({'action': 'echo hi'}) == ('echo', {'_raw_params': u'hi'}, None)
    assert m.parse({'cmd': 'echo hi'}) == ('echo', {'_raw_params': u'hi'}, None)
    assert m.parse({'echo': 'hi'}) == ('echo', {'_raw_params': u'hi'}, None)
    assert m.parse({'action': {'module': 'shell', 'args': 'a b'}}) == ('shell', {'a': 'b'}, None)
    assert m.parse({'action': {'shell': 'a b'}}) == ('shell', {'a': 'b'}, None)

# Generated at 2022-06-20 23:10:38.192528
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    task_ds = {'action_1': 'action_1', 'action_2': 'action_2'}
    collection_list = ['collection_1', 'collection_2']

    m = ModuleArgsParser(task_ds, collection_list)
    assert m._task_ds == task_ds
    assert m._collection_list == collection_list

# Generated at 2022-06-20 23:10:50.861500
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    assert parser.parse(skip_action_validation=True) == (None, {}, Sentinel)

    parser = ModuleArgsParser({'delegate_to': 'localhost'})
    assert parser.parse(skip_action_validation=True) == (None, {}, 'localhost')

    parser = ModuleArgsParser({'args': {'a': 'b', 'c': 'd'}})
    assert parser.parse(skip_action_validation=True) == (None, {'a': 'b', 'c': 'd'}, Sentinel)

    parser = ModuleArgsParser({'action': 'shell abc=123 cd=y'})
    assert parser.parse(skip_action_validation=True) == ('shell', {'abc': '123', 'cd': 'y'}, Sentinel)

    parser = Module

# Generated at 2022-06-20 23:10:55.537842
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.cli.adhoc import TaskOptions

    def assert_empty_args(task_ds):
        parser = ModuleArgsParser(task_ds=task_ds, collection_list=[])
        (action, args, delegate_to) = parser.parse()
        assert action == None
        assert args == {}
        assert delegate_to == None

    # task_ds is empty dict
    assert_empty_args({})

    # task_ds is string
    assert_empty_args("task_ds")

    # task_ds is a integer
    assert_empty_args(123)

    # task_ds is a list
    assert_empty_args([])

    # task_ds is a tuple
    assert_empty_args(())

# Generated at 2022-06-20 23:11:05.886934
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import tempfile

    # Create a temporary file for testing
    fd, tmp_path = tempfile.mkstemp()

    # Read in the test file
    with open(tmp_path,'w') as f:
        f.write("""
- hosts: localhost
  tasks:
    - name: test
      action:
        module: shell echo hi
        args:
          b: 2
      delegate_to: localhost
      """)

    # Load the test file as a task list
    task_list = TaskList.load(tmp_path)

    # Get the first task of the test file
    task = task_list[0]

    # Create a ModuleArgsParser object to parse the task
    ma = ModuleArgsParser(task_ds=task._ds, collection_list=None)

    # Call the parse method

# Generated at 2022-06-20 23:11:11.694753
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    task_ds = {}
    collection_list = None
    module_args_parser.__init__(task_ds, collection_list)
    with pytest.raises(AnsibleAssertionError):
        module_args_parser.parse()


# Generated at 2022-06-20 23:11:22.511428
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(
        task_ds={'action': 'command', 'args': {'warn': True, 'executable': '/bin/sh'}},
        collection_list=None)
    assert "ModuleArgsParser" == module_args_parser.__class__.__name__

    # noinspection PyDictCreation
    with pytest.raises(AnsibleAssertionError):
        module_args_parser = ModuleArgsParser(
            task_ds='dict_problem',
            collection_list=None)

    # noinspection PyRedundantParentheses
    with pytest.raises(AnsibleParserError):
        module_args_parser._normalize_new_style_args(
            thing=('complex record', 'complex value'),
            action='complex action')


# Generated at 2022-06-20 23:11:36.017364
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:11:47.683025
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    ds = {}
    collection_list = None
    task_attrs = set(Task._valid_attrs.keys())
    task_attrs.update(set(Handler._valid_attrs.keys()))
    task_attrs.update(['local_action', 'static'])
    task_attrs = frozenset(task_attrs)
    args_parser = ModuleArgsParser(task_ds=ds, collection_list=collection_list)
    assert args_parser._task_ds == ds
    assert args_parser._collection_list == collection_list
    assert args_parser._task_attrs == task_attrs
    assert args_parser.resolved_action == None


# Generated at 2022-06-20 23:11:58.759468
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test the normal case
    task_ds = dict(
        action=dict(shell='echo hi', chdir='/tmp'),
        delegate_to='localhost',
        any_other='junk',
    )
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell' and args == {'chdir': '/tmp', '_raw_params': 'echo hi'} and delegate_to == 'localhost'

    # test the old style
    task_ds = dict(
        action='shell chdir=/tmp echo hi',
        delegate_to='localhost',
        any_other='junk',
    )
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()

# Generated at 2022-06-20 23:12:15.049328
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Should raise an error
    task_ds = {
        "action": "shell this_is_a_command_with_no_module"
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    with pytest.raises(AnsibleParserError) as e:
        module_args_parser.parse()
    assert str(e.value) == "unexpected parameter type in action: <class 'str'>"

    # Should return 3 values
    task_ds = {
        "action": {
            "local_action": "command"
        },
        "delegate_to": "localhost"
    }
    collection_list = None
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    module_args, args, delegate

# Generated at 2022-06-20 23:12:23.734238
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg_parser = ModuleArgsParser()

    # The constructor should not raise any exception when all the required parameters are passed
    assert module_arg_parser is not None
    assert module_arg_parser._task_ds is not None
    assert module_arg_parser._task_attrs is not None
    assert module_arg_parser._collection_list is not None
    assert module_arg_parser.resolved_action is None


# Generated at 2022-06-20 23:12:35.721718
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    collection_list = None

    parser = ModuleArgsParser(task_ds, collection_list)
    # Test 1:
    parser.resolved_action = None
    action, args, delegate_to = parser.parse()
    assert (action == None)
    assert(args == {})
    assert(delegate_to == 'local')
    assert(parser.resolved_action == None)

    # Test 2:
    task_ds = {'action': 'shell echo hi'}
    collection_list = None

    parser = ModuleArgsParser(task_ds, collection_list)
    parser.resolved_action = None
    action, args, delegate_to = parser.parse()
    assert(action == 'shell')
    assert(args == {'_raw_params': 'echo hi'})

# Generated at 2022-06-20 23:12:43.760799
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    try:
        # Invalid input type for ModuleArgsParser
        ModuleArgsParser(None)
        raise

    except AnsibleAssertionError:
        pass

    # Setting task_ds argument to dict type
    parser = ModuleArgsParser({})


# Generated at 2022-06-20 23:12:48.149214
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
	pass

################################################################################
#
#             All functions above will be called from run_playbook.
#
#             All functions below are for data structure conversion.
#             They will be called from run_playbook.
#
################################################################################

# Generated at 2022-06-20 23:12:55.091162
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    utp = UnitTestParser()
    utp.load_task_dataset()
    for tds in utp.task_ds_list:
        action, args, delegate_to = ModuleArgsParser(tds).parse()

# Generated at 2022-06-20 23:13:01.079962
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mp = ModuleArgsParser({'action': {'module': 'slurp', 'content': 'hi'}}, None)
    assert (mp.parse()) == ('slurp', {'content': 'hi'}, None)
    mp = ModuleArgsParser({'action': {'module': 'slurp', 'content': 'hi', 'args': 'here=there'}}, None)
    assert (mp.parse()) == ('slurp', {'args': 'here=there', 'content': 'hi'}, None)
    mp = ModuleArgsParser({'action': {'module': 'slurp', 'content': 'hi'}, 'args': 'here=there'}, None)
    assert (mp.parse()) == ('slurp', {'args': 'here=there', 'content': 'hi'}, None)
    mp = ModuleArgs

# Generated at 2022-06-20 23:13:09.557175
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(shell='echo hi', delegate_to='foo')

    parser = ModuleArgsParser(task_ds=task_ds)
    args = parser._normalize_old_style_args(task_ds)
    assert args == ('shell', 'echo hi')

    task_ds = dict(action=dict(module='shell', args='echo hi'))
    parser = ModuleArgsParser(task_ds=task_ds)
    args = parser._normalize_old_style_args(task_ds)
    assert 'action' in task_ds
    assert args == ('shell', 'echo hi')

    task_ds = dict(action='shell echo hi')
    parser = ModuleArgsParser(task_ds=task_ds)
    args = parser._normalize_old_style_args(task_ds)

# Generated at 2022-06-20 23:13:18.964670
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    def test_exception(input_val, exception):
        try:
            ModuleArgsParser(input_val).parse(skip_action_validation=True)
        except exception as ex:
            pass
        except Exception as ex:
            pytest.fail("Unexcepted exception: {}".format(ex))
        else:
            pytest.fail("Expected exception but none thrown!")

    def test_parse(input_val, output_val):
        assert ModuleArgsParser(input_val).parse(skip_action_validation=True) == output_val

    # test exception
    input_val = {'action': {'shell': 'echo hi'}}
    test_exception(input_val, AnsibleParserError)

    input_val = {'action': 'shell'}

# Generated at 2022-06-20 23:13:31.547466
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()

    # case 1: action with complex args
    task_ds = dict(action="copy", args=dict(src="a", dest="b"))
    parser = ModuleArgsParser(task_ds, collection_loader=collection_loader)
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')

    # case 2: action with string args
    task_ds = dict(action="copy src=a dest=b")
    parser = ModuleArgsParser(task_ds, collection_loader=collection_loader)
    (action, args, delegate_to) = parser.parse()
    assert action == 'copy'

# Generated at 2022-06-20 23:13:43.265901
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:13:46.478606
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    temp_instance = ModuleArgsParser(task_ds={"module": "copy",
                                              "args": "src='a' dest='b'",
                                              "name": "mytask"},
                                     collection_list=[])
    temp_instance.parse()



# Generated at 2022-06-20 23:13:54.892330
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test the ModuleArgsParser class constructor
    '''
    the_task_ds = {'action': 'copy src=a dest=b'}
    the_collection_list = [('my_role', 'my_role', 'my_task'), ('my_collection', 'my_collection', 'my_task')]

    parser = ModuleArgsParser(the_task_ds, the_collection_list)

    assert parser._task_ds == the_task_ds
    assert parser._collection_list == the_collection_list



# Generated at 2022-06-20 23:13:57.545706
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task

    m = MagicMock(spec=Task)

    mp = ModuleArgsParser(m)


# Generated at 2022-06-20 23:14:07.929265
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:14:10.408576
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_arg_parser = ModuleArgsParser()
    assert isinstance(module_arg_parser, ModuleArgsParser)


# Generated at 2022-06-20 23:14:22.619363
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(
        delegate_to='localhost',
        action='testmodule name=testmodule args=testmoduleargs',
        args=dict(
            chdir='/root',
            executable='/bin/bash'
        )
    )
    mapi = ModuleArgsParser(ds)
    assert isinstance(mapi, ModuleArgsParser)
    assert isinstance(mapi._task_ds, dict)
    assert isinstance(mapi._task_attrs, frozenset)
    assert isinstance(mapi._collection_list, list)
    assert mapi.resolved_action is None
    with pytest.raises(AnsibleAssertionError):
        mapi = ModuleArgsParser(dict())

# Generated at 2022-06-20 23:14:33.389802
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # action:  'copy: src=a dest=b'
    # additional_args: 'xyz=abc'
    action = 'copy'
    thing = 'src=a dest=b'
    additional_args = 'xyz=abc'
    delegate_to = None
    args = {'src': 'a', 'dest': 'b'}
    expected = (action, args, delegate_to)

    task_ds = dict(action=thing, args=additional_args)
    # run ModuleArgsParser#parse
    parser = ModuleArgsParser(task_ds)
    result = parser.parse()

    assert result == expected

# Class definition for AnsibleTask object

# Generated at 2022-06-20 23:14:34.457028
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()

# Generated at 2022-06-20 23:14:44.334691
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {
        'delegate_to': 'localhost',
        'shell': 'echo hi',
        'action': 'ping',
        'args': {'chdir': '/tmp'}
    }
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('ping', {'chdir': '/tmp'}, 'localhost')

    task_ds = {'shell': 'echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert module_args_parser.parse() == ('shell', {}, None)
    assert module_args_parser.resolved_action == 'ansible.builtin.shell'

    task_ds = {'command': 'echo hi'}
    module_args_parser = ModuleArgsParser(task_ds)


# Generated at 2022-06-20 23:14:56.325043
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Make sure the constructor asserts on its input
    with pytest.raises(AssertionError):
        m = ModuleArgsParser(None)  # "task_ds" must be a dictionary

    # Make sure the constructor works when a valid input is passed
    m = ModuleArgsParser({})
    assert isinstance(m, ModuleArgsParser)


# Generated at 2022-06-20 23:15:07.343484
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    loader = DictDataLoader({
        'test.yml': """
        - shell: echo a
        - shell: echo b
        - shell: echo c""",
    })

    tpl_finder = PluginLoader('LookupModule', 'lookup_plugins', C.DEFAULT_LOOKUP_PLUGIN_WHITELIST, 'lookup', 'lookup')
    tsk_finder = PluginLoader('ActionModule', 'action_plugins', C.DEFAULT_ACTION_PLUGIN_WHITELIST, 'action', 'action')
    var_mgr = VariableManager()
    inv_loader = InventoryLoader(loader=loader, variable_manager=var_mgr)
    inv = Inventory(loader=inv_loader, variable_manager=var_mgr, host_list=[])
    play_source = loader.load_from_

# Generated at 2022-06-20 23:15:16.843825
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Tests added for proper handling of unexpected args in ansible-playbook
    # Playback
    task_ds_input = {
        "name": "test/test.yml",
        "action": "copy src=a dest=b"
    }
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(task_ds=task_ds_input).parse()

    # Playback
    task_ds_input = {
        "name": "test/test.yml",
        "action": "run_action echo hi"
    }
    with pytest.raises(AnsibleParserError):
        ModuleArgsParser(task_ds=task_ds_input).parse()

    # Playback

# Generated at 2022-06-20 23:15:23.454192
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_dict = {'action': 'test'}
    test_mock = [('setup', [{'action': 'test'}])]
    args, kwargs = mock_module_args(test_dict, test_mock)
    obj = create_ansible_module(args, kwargs)
    obj.parse()
    obj.exit_json()


# Generated at 2022-06-20 23:15:33.747679
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    """Test method parse of class ModuleArgsParser"""
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # Input data
    task_ds = {
"action": {
        "module": "shell",
        "args": {
            "arguments": AnsibleUnsafeText("echo hi", False),
            "_raw_params": "echo hi",
            "_uses_shell": True
        },
        "delegate_to": "localhost"
    }
}
    expected_result = (
# expected result after parsing
        'shell',
        {
            'arguments': AnsibleUnsafeText("echo hi", False),
            '_raw_params': 'echo hi',
            '_uses_shell': True
        },
        'localhost'
    )
    # Create instance of class ModuleArgsParser and parse module arguments

# Generated at 2022-06-20 23:15:46.356043
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    """
    Given a task in one of the supported forms, parses and returns
    returns the action, arguments, and delegate_to values for the
    task, dealing with all sorts of levels of fuzziness.
    """

    USES_SHELL_MODULES = ['command', 'shell', 'script']

    # The following tests use the ModuleArgsParser module, with the
    # following inputs:
    #
    # module_name: the name of the module to which the arguments apply.
    #
    # task_args: the dictionary of arguments specified in the task.
    #
    # expected_result: the dictionary of the arguments after parsing.


# Generated at 2022-06-20 23:15:58.608180
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # 1. base case
    ds = dict(action=dict(module='ping', localhost=True))
    parser = ModuleArgsParser(ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert args == dict(localhost=True)
    assert delegate_to == Sentinel

    # 2. local action
    ds = dict(local_action=dict(module='ping', localhost=True))
    parser = ModuleArgsParser(ds)
    (action, args, delegate_to) = parser.parse()
    assert action == 'ping'
    assert args == dict(localhost=True)
    assert delegate_to == 'localhost'

    # 3. duplicate action specified

# Generated at 2022-06-20 23:16:07.604341
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_args_parser = ModuleArgsParser()
    action = "shell"
    args = dict()
    delegate_to = module_args_parser._task_ds.get('delegate_to', Sentinel)
    additional_args = module_args_parser._task_ds.get('args', dict())

    #test parse with 'action' in module_args_parser._task_ds
    module_args_parser._task_ds = {"action":"echo hi"}
    module_args_parser._task_ds = {"local_action":"echo hi"}

    #test parse with 'local_action' in module_args_parser._task_ds
    module_args_parser._task_ds = {"local_action":"echo hi"}

    #test parse with 'module' in module_args_parser._task_ds
    module_args_parser._task_ds

# Generated at 2022-06-20 23:16:12.986301
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    # basic test of constructing a task via a dictionary
    ds = dict(action=dict(module='testmod', args=dict(key='val')))
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'testvar': 'testval'}
    variable_manager._options_vars = {'testoptvar': 'testoptval'}
    ds = TaskInclude.load(ds, loader=loader, variable_manager=variable_manager, use_handlers=True)
    assert type(ds) is TaskInclude
    assert ds._use_handlers == True
    assert 'testvar' in ds._variable_manager._extra_

# Generated at 2022-06-20 23:16:20.842372
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args = {
        "type": "oneshot",
        "name": "date -u",
        "action": [
            "date",
            "-u"
        ],
        "autorestart": "false",
        "startsecs": "0"
    }
    obj = ModuleArgsParser(**module_args)
    assert obj is not None
    action, args, delegate_to = obj.parse()
    assert obj.resolved_action is None
    assert action == "date -u"
    assert delegate_to is None
