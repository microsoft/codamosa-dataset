

# Generated at 2022-06-20 23:07:15.599497
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # test no module
    with pytest.raises(AnsibleParserError, match="no module/action detected in task"):
        ModuleArgsParser({}).parse()
    # test module with unknown extra param
    with pytest.raises(AnsibleParserError,
                       match="this task 'copy' has extra params, which is only allowed in the following modules: "):
        ModuleArgsParser({'copy': 'src=a dest=b extra_param=c'}).parse()
    # test module with known extra param

# Generated at 2022-06-20 23:07:22.606660
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    data = dict(a=1,
                b=2,
                action=dict(module='echo',
                            args="hell world"),
                local_action=dict(module='echo',
                                  args="hell world"),
                delegate_to='localhost')

    parser = ModuleArgsParser(data)
    (action, args, delegate_to) = parser.parse()

    assert action is not None
    assert args is not None
    assert delegate_to is not None

# Generated at 2022-06-20 23:07:33.090545
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = dict(
        # one of action, local_action, or module should be specified
        action = "copy",
        local_action = "copy",
        module = "copy",

        args = dict(
            raw_params = "copy",
            delegate_to = "copy"
        )
    )

    # _split_module_string
    obj = ModuleArgsParser(args)
    assert obj._split_module_string("shell echo hi") == ('shell', 'echo hi')

    # _normalize_parameters
    obj = ModuleArgsParser(args)
    assert obj._normalize_parameters(args) == ('copy', {'delegate_to': 'copy'})

    # _normalize_new_style_args
    obj = ModuleArgsParser(args)

# Generated at 2022-06-20 23:07:34.723991
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # TODO: mock ansible_module_generated.py
    pass

# Generated at 2022-06-20 23:07:46.947769
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': 'action = <%= ansible_managed %>',
        'local_action': 'local_action = <%= ansible_managed %>',
        'module': 'module = <%= ansible_managed %>',
        'with_items': "with_items = <%= ansible_managed %>",
        'with_dict': "with_dict = <%= ansible_managed %>",
        'with_first_found': "with_first_found = <%= ansible_managed %>",
        '_ansible_rst_locals': {
            'ansible_managed': 'test'
        }
    }
    # Test no exception is raised by method parse
    assert ModuleArgsParser(task_ds).parse()

# Generated at 2022-06-20 23:07:58.263846
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Simple test with no args specified
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == (None, dict(), Sentinel)

    # Test case with only the `action` specified
    task_ds = dict(action='echo hello')
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {'msg': 'hello'}, Sentinel)

    # Test case with only the `local_action` specified
    task_ds = dict(local_action='echo hello')
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('echo', {'msg': 'hello'}, 'localhost')

    # Test case with only the `module` specified
    task_ds = dict(module='echo msg=hello')

# Generated at 2022-06-20 23:08:00.954463
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert isinstance(module_args_parser, ModuleArgsParser)



# Generated at 2022-06-20 23:08:11.716965
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:08:13.833558
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = dict()
    obj = ModuleArgsParser(task_ds)
    assert isinstance(obj.parse(), (tuple, list))


# endregion

# Generated at 2022-06-20 23:08:25.650925
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # constructor
    module_parser = ModuleArgsParser(task_ds={}, collection_list=None)

    # using old-style module invocation form
    (action, args, delegate_to) = module_parser._normalize_parameters(thing={'shell': 'echo hi'}, action='shell')
    assert action == 'shell'
    assert delegate_to is None
    assert args == {'_raw_params': 'echo hi'}

    # using new-style module invocation form
    (action, args, delegate_to) = module_parser._normalize_parameters(thing=dict(shell='echo hi'), action='shell')
    assert action == 'shell'
    assert delegate_to is None
    assert args == {'_raw_params': 'echo hi'}



# Generated at 2022-06-20 23:08:59.153935
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Task
    task_ds = {}
    collection_list = None
    a = ModuleArgsParser(task_ds, collection_list)
    assert isinstance(a, ModuleArgsParser)
    assert a._task_ds == task_ds
    assert a._collection_list == collection_list
    assert a.resolved_action is None

# Generated at 2022-06-20 23:09:07.940842
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    test_parser = ModuleArgsParser( {} )

    assert_raises(AnsibleAssertionError, ModuleArgsParser, None)
    assert_raises(AnsibleAssertionError, ModuleArgsParser, True)
    assert_raises(AnsibleAssertionError, ModuleArgsParser, False)

    assert_raises(AnsibleParserError, test_parser.parse, { 'action': { 'shell': 'echo hi' } }, True)
    #assert_raises(AnsibleParserError, test_parser.parse, { 'action': { 'shell': 'echo hi' } }, True)
# End of unit test for method parse of class ModuleArgsParser


# Generated at 2022-06-20 23:09:19.867593
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    print('')
    print('Testing ModuleArgsParser.parse')

    # Prep
    loader_mock = Mock()
    loader_mock.all.return_value = ['check_command', 'check_file', 'check_file_exists']

    no_collection_list = None
    collection_list = ['ice_cream', 'penguins', 'pythons']

    # Test variables

# Generated at 2022-06-20 23:09:29.461109
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:09:41.429333
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-20 23:09:45.761624
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'action': {u"shell": u"/usr/sbin/ntpstat"}}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (u'shell', {}, None)

# Generated at 2022-06-20 23:09:55.043132
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # check use with an empty action
    check_task = None
    pap = ModuleArgsParser(task_ds=check_task)
    assert pap._task_ds == {}
    assert isinstance(pap._task_attrs, frozenset)
    assert len(pap._task_attrs) == 8

    # check use with ordinary action
    check_task = dict(action=dict(module='shell', args='whoami'))
    pap = ModuleArgsParser(task_ds=check_task)
    assert pap._task_ds == check_task
    assert isinstance(pap._task_attrs, frozenset)
    assert len(pap._task_attrs) == 8

    # check use with broken action
    check_task = 'shell'

# Generated at 2022-06-20 23:10:08.215399
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(
        action=dict(module='copy', src='/tmp/test.txt', dest='/tmp/test2.txt', mode='777'),
    )
    mp = ModuleArgsParser(ds, collection_list=[])
    action, args, delegate_to = mp.parse()
    assert action == 'copy'
    assert args == {'src': '/tmp/test.txt', 'dest': '/tmp/test2.txt', 'mode': '777'}
    assert delegate_to is None


    ds = dict(
        local_action=dict(module='copy', src='/tmp/test.txt', dest='/tmp/test2.txt', mode='777'),
    )
    mp = ModuleArgsParser(ds, collection_list=[])
    action, args, delegate_to = mp.parse()

# Generated at 2022-06-20 23:10:16.353292
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # passing it a None
    try:
        x = ModuleArgsParser(task_ds=None)
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)
        assert str(e) == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"

    # passing it a str
    try:
        x = ModuleArgsParser(task_ds='some string')
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)
        assert str(e) == "the type of 'task_ds' should be a dict, but is a <class 'str'>"

    # passing it some random object

# Generated at 2022-06-20 23:10:29.912835
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.errors import AnsibleError, AnsibleParserError, AnsibleAssertionError
    from ansible.module_utils._text import to_text
    import pytest

    module = ModuleArgsParser()
    obj = mock.MagicMock()
    obj.__class__ = AnsibleError
    obj.module_name = 'module'
    obj.module_args = 'module'
    obj.message = 'message'
    obj.exception = Exception('test exception')
    templar = mock.MagicMock()
    templar.is_template.side_effect = [True, False]
    templar.__class__ = str
    templar.__repr__.return_value = 'repr'
    templar.__str__.return_value = 'str'
    templar.__

# Generated at 2022-06-20 23:10:53.338439
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    print(parser.parse({'thing': {'a':{'b':'c'}} }))  # args missing
    #print parser.parse({'thing': 'a=b c=d' }))
    print(parser.parse({'thing': {'a':'b'} }))
    #print parser.parse({'thing': ['a=b', 'c=d'] } ))
    #print parser.parse({'thing': 'action: copy src=a dest=b' }))
    #print parser.parse({'thing': 'copy src=a dest=b' }))
    print(parser.parse({'thing': 'thing src=a dest=b' }))
    #print parser.parse({'thing': {'thing': {'a': 'b', 'c': 'd'} }

# Generated at 2022-06-20 23:10:54.998938
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass
# END Unit test for method parse of class ModuleArgsParser


# Generated at 2022-06-20 23:11:05.658259
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Basic unit test for constructor of class ModuleArgsParser
    '''

    class TestModuleArgsParser(unittest.TestCase):
        '''
        Unit test class for ModuleArgsParser class
        '''

        def test_module_args_parser(self):
            '''
            Test ModuleArgsParser
            '''

            test_task_ds = {}

            if not isinstance(test_task_ds, dict):
                raise AssertionError("the type of 'test_task_ds' should be a dict, but is a %s" % type(test_task_ds))

            module_args_parser_instance = ModuleArgsParser(test_task_ds)


# Generated at 2022-06-20 23:11:18.710516
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:11:24.303927
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    This method is used to test the constructor of the class
    :return: Nothing
    '''
    parser = ModuleArgsParser(task_ds=None, collection_list=None)
    assert parser is not None
    assert isinstance(parser, ModuleArgsParser)
    assert parser._task_attrs == frozenset({'run_once', 'static', 'free_form', 'handlers', 'block', 'meta', 'tags', 'register', 'with_items', 'async', 'when', 'local_action'})
    assert parser.resolved_action is None



# Generated at 2022-06-20 23:11:26.512731
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # no test currently: nothing really to check in the constructor
    pass



# Generated at 2022-06-20 23:11:39.671159
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'delegate_to': None,
               'module': 'command echo hi',
               'register': None}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    print(parser.parse())

    task_ds = {'delegate_to': None,
               'local_action': 'command echo hi',
               'register': None}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    print(parser.parse())

    task_ds = {'delegate_to': None,
               'action': 'command echo hi',
               'register': None}
    parser = ModuleArgsParser(task_ds=task_ds, collection_list=None)
    print(parser.parse())


# Generated at 2022-06-20 23:11:50.592326
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Constructor test
    task_ds = {'action': 'ping'}
    args_parser = ModuleArgsParser(task_ds=task_ds)
    assert args_parser._task_ds == task_ds
    assert args_parser._collection_list is None

    # All inputs are None
    try:
        args_parser = ModuleArgsParser()
    except AnsibleAssertionError as e:
        assert e.args[0] == "the type of 'task_ds' should be a dict, but is a <class 'NoneType'>"

    # Constructor with a string
    task_ds = 'ping'

# Generated at 2022-06-20 23:12:02.491516
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six.moves import UserDict
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.collection import CollectionLoader
    config = {"DEFAULT_ANSIBLE_MODULE_ARGS": {}}
    plugin_loader.add_directory(DEFAULT_MODULE_PATH)
    cl = CollectionLoader()
    loader = DataLoader()
    module_name

# Generated at 2022-06-20 23:12:07.789919
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = {}
    mock_collection_list = []
    module_args_parser_parse = ModuleArgsParser(task_ds=mock_task_ds, collection_list=mock_collection_list)
    assert module_args_parser_parse.parse() == (None, dict(), None)

# Generated at 2022-06-20 23:12:25.357650
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    action = 'shell'
    delegate_to = 'localhost'
    args = {'_raw_params': 'echo hi'}
    obj = {'action': 'shell echo hi', 'delegate_to': 'localhost'}
    runner = ModuleArgsParser(task_ds=obj)
    answer = runner.parse()
    assert (answer == (action, args, delegate_to))

test_ModuleArgsParser_parse()



# Generated at 2022-06-20 23:12:37.195034
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mytask = dict(action=dict(module='shell', shell='/bin/false', creates='/tmp/file1'))
    mytask2 = dict(action=dict(module='shell', shell='/bin/false', creates='/tmp/file1'),
                  delegate_to='localhost', ignore_errors=True)
    mytask3 = dict(action=dict(module='shell', shell='/bin/false', creates='/tmp/file1'),
                  delegate_to='localhost', ignore_errors=True, args='ignore_errors=true')
    mytask4 = dict(action='shell echo hi', delegate_to='localhost', ignore_errors=True, args='ignore_errors=true')
    mytask5 = dict(action='shell', shell='/bin/false', creates='/tmp/file1')

# Generated at 2022-06-20 23:12:48.942310
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.module_utils.common.collections import ImmutableDict
    from collections import Mapping
    from ansible.errors import AnsibleParserError
    from ansible.parsing.utils.addresses import parse_address

    # Without _hosts in task_ds
    # When task_ds is empty
    assert ModuleArgsParser(task_ds={}).parse() == ('ping', {}, Sentinel)
    # When task_ds is not empty
    assert ModuleArgsParser(task_ds={'ping': 'pong'}).parse() == ('ping', {}, Sentinel)

    # With _hosts in task_ds
    # When task_ds is empty
    assert ModuleArgsParser(task_ds={'_hosts': parse_address('127.0.0.1')}).parse() == ('ping', {}, Sentinel)


# Generated at 2022-06-20 23:12:54.272458
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {}
    loader = None
    collection_list = ['ansible.builtin', 'community.general']
    module_args_parser = ModuleArgsParser(task_ds=task_ds,collection_list=collection_list)
    assert module_args_parser.parse() == ('', {}, Sentinel)

# Generated at 2022-06-20 23:13:04.843104
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test the main logic which can be executed as a unit test
    # with the following command:
    #   python -m unittest test_utils_module_args_parser
    #
    # The following command will run all the unit tests in the test directory:
    #   python -m unittest discover
    #
    # The following command will test a single unit test:
    #   python -m unittest test_utils_module_args_parser.ModuleArgsParserTestCase.test_parse_local_action_complex_args
    #
    # See: https://docs.python.org/3/library/unittest.html#command-line-options
    # for more unittest command line options
    #
    import json
    from ansible.errors import AnsibleError

# Generated at 2022-06-20 23:13:12.058993
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task = dict(
        name="this is a name",
        action=dict(
            module="include_tasks",
            args=dict(
                file="test_include.yml",
                static=True,
                name="this is a name"
            )
        )
    )
    module_args_parser = ModuleArgsParser(task_ds=task)
    action, args, delegate_to = module_args_parser.parse()
    assert action == "include_tasks"
    assert args["file"] == "test_include.yml"
    assert args["static"] is True
    assert args["name"] == "this is a name"
    assert delegate_to is None

# Generated at 2022-06-20 23:13:16.862605
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    class MockPlayContext(object):
        def __init__(self):
            self.remote_addr = 'localhost'
            self.remote_user = 'user'

    assert_raises(AnsibleAssertionError, ModuleArgsParser, task_ds=None)
    assert_raises(AnsibleAssertionError, ModuleArgsParser, task_ds=['a', 'b'])
    assert_raises(AnsibleAssertionError, ModuleArgsParser, task_ds={'a': 'b'}).validate()
    assert_raises(AnsibleError, ModuleArgsParser(task_ds={'local_action': 'ping'}).parse, skip_action_validation=True)

# Generated at 2022-06-20 23:13:23.597087
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'a': 'b'}
    collection_list = None
    x = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = x.parse(skip_action_validation=False)
    assert action == 'a'
    assert args == 'b'
    assert delegate_to == None

# end class ModuleArgsParser



# Generated at 2022-06-20 23:13:26.377990
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(task_ds={})
    assert isinstance(module_args_parser, ModuleArgsParser)


# Generated at 2022-06-20 23:13:38.180541
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_data = {
        'action': 'shell echo this is a test',
        'not_action': 'shell echo this is a test',
    }

    # Basic verification
    task = ModuleArgsParser(task_ds=test_data)

    assert task.parse()[0] == 'shell'
    assert task.parse()[1]['_raw_params'] == 'echo this is a test'

    # Verify that we can handle multiple modules used in the same task
    test_data = {
        'action': 'shell echo this is a test',
        'not_action': 'shell echo this is a test',
        'shell': 'echo this is another test'
    }

    task = ModuleArgsParser(task_ds=test_data)
    task.parse()

# Generated at 2022-06-20 23:14:00.552738
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test creation of ModuleArgsParser class
    task_ds = dict()
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds
    assert parser.resolved_action is None
    assert parser._collection_list is None



# Generated at 2022-06-20 23:14:03.042562
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action=dict(module='ping', args=dict(data='pong')))
    m = ModuleArgsParser(task_ds)
    assert m



# Generated at 2022-06-20 23:14:09.306636
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        'action': {
            'module': 'copy',
            'src': 'a',
            'dest': 'b'
        }
    }
    collection_list = ['ansible.builtin']
    obj = ModuleArgsParser(task_ds=task_ds, collection_list=collection_list)
    (action, args, delegate_to) = obj.parse()

    assert action == 'copy'
    assert delegate_to is None
    assert args == {'src': 'a', 'dest': 'b'}


# Generated at 2022-06-20 23:14:21.450600
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test that an error is raised when the task is not a dictionary
    test_task_ds = "something"
    try:
        parser = ModuleArgsParser(task_ds=test_task_ds)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("Expected AnsibleAssertionError to be raised")

    # Test that an error is raised when the task is not a dictionary
    test_task_ds = "something"
    try:
        parser = ModuleArgsParser(task_ds=test_task_ds)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("Expected AnsibleAssertionError to be raised")

    # Test that no error is raised when the task is a dictionary
    test_task_ds = {"a": 1}

# Generated at 2022-06-20 23:14:33.977841
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    # Test name: TestModuleArgsParserParse
    parser = ModuleArgsParser({ 'name': 'shell'}, [])
    # assert parser.parse(True) == ['shell', {}, None]
    assert parser.parse(False) == ['shell', {}, None]

    # Test name: TestModuleArgsParserParseAction
    parser = ModuleArgsParser({ 'action': 'shell'}, [])
    assert parser.parse(False) == ['shell', {}, None]

    # Test name: TestModuleArgsParserParseActionLocalAction
    parser = ModuleArgsParser({ 'action': 'shell', 'local_action': 'shell'}, [])
    # assert parser.parse(False) == ['shell', {}, 'localhost']
    assert parser.parse(True) == ['shell', {}, 'localhost']
    # assert parser.parse(False) == ['

# Generated at 2022-06-20 23:14:43.931210
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Arrange
    module_string = 'copy src=a dest=b'
    modules = [
        {
            "raw_params": 'echo hi',
            "uses_shell": True
        },
        {
            "region": 'xyz'
        },
        {
            "_raw_params": '',
            "arg1": '',
            "arg2": '',
            "arg3": ''
        }
    ]
    module_name = 'shell'
    args = [
        [
            "echo hi",
            "shell"
        ],
        [
            {
                "region": 'xyz'
            },
            'ec2'
        ],
        ["copy src=a dest=b", None]
    ]
    expected_results = ['copy', 'ec2', 'shell']


# Generated at 2022-06-20 23:14:47.973163
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test the case that task_ds is a dictionary
    assert ModuleArgsParser(task_ds={})
    assert ModuleArgsParser(task_ds={'test': 1}, collection_list="test")

    # Test the case that task_ds is not a dictionary
    try:
        ModuleArgsParser(task_ds=1)
    except AnsibleAssertionError:
        pass


# Generated at 2022-06-20 23:14:52.340542
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Test to verify ModuleArgsParser class constructor
    '''
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds="")



# Generated at 2022-06-20 23:15:04.486213
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    m = ModuleArgsParser(dict(name="test"))
    assert m.parse(True) == (None, {}, None)

    m = ModuleArgsParser(dict(action=dict(shell="echo hi")))
    assert m.parse() == ('shell', {}, None)

    m = ModuleArgsParser(dict(action="shell echo hi"))
    assert m.parse() == ('shell', {}, None)

    m = ModuleArgsParser(dict(action=dict(module="copy src=dest")))
    assert m.parse() == ('copy', {'src': 'dest'}, None)

    m = ModuleArgsParser(dict(action="copy src=dest"))
    assert m.parse() == ('copy', {'src': 'dest'}, None)

    # this is the normal 'new style' of passing args

# Generated at 2022-06-20 23:15:13.034639
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # FIXME: This test is not currently exercised by any of the tests.
    #        We need to add a test which involves the loading of a plugin and
    #        we should add a test which uses the PluginLoader.find_plugin_with_context()
    #        method to return an error when a plugin can not be found.
    #
    # Set up the environment
    h = {}
    h['shell'] = 'echo hi'
    h['module'] = 'ec2'
    h['args'] = {'x': 1}
    h['copy'] = 'src=a dest=b'
    h['action'] = 'copy src=a dest=b'
    h['local_action'] = 'shell echo hi'
    h['ec2'] = {'region': 'xyz'}

# Generated at 2022-06-20 23:15:44.092424
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:15:56.438996
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    
    task_ds = {
        'action1': 'shell echo hi', 
        'action2': 'echo hi',
        'action3': {'module': 'echo hi'},
        'action4': {'module': 'shell echo hi'},
        'action5': {'shell': 'echo hi'},
        'action6': {'arg4': 'echo hi'},
        'action7': {'arg5': {'module': 'echo hi'}}
    }
    expected_version = '1.2.3'
    expected_resolved_action = 'ansible.builtin.shell'
    expected = (expected_version, expected_resolved_action)

    # Ensure that we are not missing any task or handler

# Generated at 2022-06-20 23:16:06.297992
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser(dict())
    assert isinstance(module_args_parser._task_ds, dict)
    assert module_args_parser._task_ds == {}
    assert module_args_parser._collection_list == None

# Generated at 2022-06-20 23:16:12.083906
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert(ModuleArgsParser(task_ds=dict(action="copy", module=dict(src="a", dest="b"))) is not None)
    assert(ModuleArgsParser(task_ds=dict(action="copy", module=dict(src="a", dest="b"))) is not None)
    assert(ModuleArgsParser(task_ds=dict(action=dict(module="copy", src="a", dest="b"))) is not None)
    assert(ModuleArgsParser(task_ds=dict(action=dict(module=dict(src="a", dest="b")))) is not None)
    assert(ModuleArgsParser(task_ds=dict(module=dict(src="a", dest="b"))) is not None)

# Generated at 2022-06-20 23:16:23.455705
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    args_parser = ModuleArgsParser()
    assert args_parser._task_ds == {}
    assert args_parser._task_attrs == frozenset()
    assert args_parser._collection_list == None
    assert args_parser.resolved_action == None

    args_parser = ModuleArgsParser(task_ds={'delegate_to': None}, collection_list=[{'name': 'my_collection'}])
    assert args_parser._task_ds == {'delegate_to': None}
    assert args_parser._task_attrs == frozenset()
    assert args_parser._collection_list == [{'name': 'my_collection'}]
    assert args_parser.resolved_action == None

    # We are using this to test that the constructor fails when we pass in an object which isn't a list.
    #