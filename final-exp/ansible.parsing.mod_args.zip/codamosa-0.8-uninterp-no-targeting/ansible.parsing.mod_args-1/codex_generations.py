

# Generated at 2022-06-20 23:06:49.595766
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {u'region': u'xyz', u'local_action': {'module': 'ec2', 'x': 1} }
    obj = ModuleArgsParser(task_ds)
    result = obj.parse()
    assert result == ('ec2', {'x': 1}, 'localhost')

    task_ds = {u'region': u'xyz', u'local_action': {'module': 'ec2', 'x': 1} }
    obj = ModuleArgsParser(task_ds)
    result = obj.parse()
    assert result == ('ec2', {'x': 1}, 'localhost')

    task_ds = {u'region': u'xyz', u'local_action': 'ec2 x=1'}
    obj = ModuleArgsParser(task_ds)
    result = obj.parse

# Generated at 2022-06-20 23:06:53.924040
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    import pytest
    uut = ModuleArgsParser()
    # This line raises an exception as long as the parse method is not implemented.
    uut.parse()
    # TODO: Write unit tests for this method and convert to test-kitchen
    # TODO: Add pytest decorator for each unit test.




# Generated at 2022-06-20 23:07:01.187449
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # TODO: Move these tests to a proper unit test class
    module_parser = ModuleArgsParser(task_ds={'action': 'copy src=a dest=b'})
    (action, args, delegate_to) = module_parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None

    module_parser = ModuleArgsParser(task_ds={'action': {'copy': 'src=a dest=b'}})
    (action, args, delegate_to) = module_parser.parse()
    assert action == 'copy'
    assert args == dict(src='a', dest='b')
    assert delegate_to is None


# Generated at 2022-06-20 23:07:07.626308
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser()
    class_params = {'task_ds': {'raw_params': 'echo hi'}, 'collection_list': None}  # create a dictionary of parameters and arguments
    result1 = parser.parse(**class_params)
    assert result1 == ('raw_params', {'_raw_params': 'echo hi'}, None), "Unit test result: test_ModuleArgsParser_parse()"

# Generated at 2022-06-20 23:07:16.492885
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # https://docs.python.org/2/library/unittest.html
    from ansible.parsing.splitter import parse_kv
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play_context import PlayContext
    import sys
    import inspect
    #import ansible.playbook
    #import ansible.playbook.play

    # Get function parameters

# Generated at 2022-06-20 23:07:23.425583
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    args = {"module": "copy", "src": "a", "dest": "b"}
    action = None
    module_parser = ModuleArgsParser("copy", args)
    action, args, delegate_to = module_parser.parse(skip_action_validation=True)

    assert action == "copy"
    assert args == {"src": "a", "dest": "b"}


# Generated at 2022-06-20 23:07:25.521632
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None


# Generated at 2022-06-20 23:07:27.081502
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser()
    assert module_parser



# Generated at 2022-06-20 23:07:35.849551
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    # Test a task with no 'action' specified
    task_ds = dict()
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = module_args_parser.parse()

    assert action is None
    assert len(args) == 0
    assert delegate_to is None

    # Test a task  with 'action' specified, but nothing else
    task_ds = dict(action='something')
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    (action, args, delegate_to) = module_args_parser.parse()

    assert action == 'something'
    assert len(args) == 0
    assert delegate_to is None

    # Test a task  with 'action' specified, but nothing else, but local_action also specified


# Generated at 2022-06-20 23:07:49.082060
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play_context import DEFAULT_SUDO_PASS

    #
    # Test initialization with valid data
    #

    task_ds = {
        'name': 'task1',
        'local_action': 'test1',
        'args': {'a': 1, 'b': '2'},
        'delegate_to': 'localhost',
        'something': 'else'
    }
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    assert module_args_parser.parse() == (
        'test1', {'a': 1, 'b': '2', '_raw_params': ''}, 'localhost')


# Generated at 2022-06-20 23:07:58.560199
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    pass

# Generated at 2022-06-20 23:08:09.970138
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test case 1.1. Test parse() function
    # The input data is a task which contains 'action' field of action-module
    # Test if action and args are parsed correctly
    task_data_1 = {'action': 'copy src=a dest=b'}
    parser_1 = ModuleArgsParser(task_data_1)
    (action, args, delegate_to) = parser_1.parse()
    assert action == 'copy'
    assert args['src'] == 'a'
    assert args['dest'] == 'b'
    assert delegate_to is None

    # Test case 1.2. Test parse() function
    # The input data is a task which contains 'action' field of action-module
    # array
    # Test if action and args are parsed correctly

# Generated at 2022-06-20 23:08:15.321291
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {
        "name": "ec2 discover",
        "lambda": "us-west-1",
        "filters": {"instance-state-name": "running"}
    }
    collection_list = None

    args_parser = ModuleArgsParser(task_ds, collection_list)
    args = args_parser.parse()

    assert args == ('discovery', {'lambda': 'us-west-1', 'filters': {'instance-state-name': 'running'}}, None)



# Generated at 2022-06-20 23:08:19.182968
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(task_ds={'action': 'shell echo hi'})
    assert parser.parse() == ('shell', {'_raw_params': u'echo hi', '_uses_shell': True}, None)


# Generated at 2022-06-20 23:08:32.052242
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    '''
    Make sure we return the correct values in args and delegate_to
    '''

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.role.definition import compile_role_vars
    from ansible.template import Templar

    def test_get_action_and_args(test_string):
        return ModuleArgsParser(test_string).parse()

    # check argument normalization
    test_input_ds = {'action': 'ping'}
    assert test_get_action_and_args(test_input_ds) == ('ping', {}, None)

    test_input_ds = {'action': {'ping': None}}
    assert test_get_action_and_args(test_input_ds) == ('ping', {}, None)


# Generated at 2022-06-20 23:08:41.981059
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    print("testing ModuleArgsParser")

    # test case 1: no module
    task_ds_1 = {'sudo':True}
    mp_1 = ModuleArgsParser(task_ds_1)
    action_1, args_1, delegate_to_1 = mp_1.parse()
    assert action_1 is None
    assert args_1 == {}
    assert delegate_to_1 is None

    # test case 2: old style with one module
    task_ds_2 = {'sudo':False,
                 'action': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    mp_2 = ModuleArgsParser(task_ds_2)
    action_2, args_2, delegate_to_2 = mp_2.parse()
    assert action_2 == 'copy'
    assert args_

# Generated at 2022-06-20 23:08:54.076907
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    input = {"action": {"module": "copy", "src": "a", "dest": "b"}}
    expected = ('copy', {'src': 'a', 'dest': 'b'}, None)
    parser = ModuleArgsParser(task_ds=input)
    p = parser.parse()
    #pass
    assert expected == p
    #pass
    assert __name__ == '__main__'
# end class ModuleArgsParser


# Generated at 2022-06-20 23:08:58.396251
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  module_args=dict(action=dict(module='copy', src='a', dest='b'))
  obj = ModuleArgsParser(module_args)
  print(obj.parse())
test_ModuleArgsParser_parse()


# Generated at 2022-06-20 23:09:08.659712
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleParserError
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import plugin_loader, module_loader

    t = dict(
        action='copy',
        src='module_data.py',
        dest='/etc/ansible/module_data.py'
    )
    a = dict(
        action='copy',
        src='module_data.py',
        dest='/etc/ansible/module_data.py'
    )
    task_ds = dict(
        action=dict(
            module='copy',
            src='module_data.py',
            dest='/etc/ansible/module_data.py'
        )
    )


# Generated at 2022-06-20 23:09:11.639989
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser(task_ds={}, collection_list=None)
    assert parser is not None
    assert parser.resolved_action is None


# Generated at 2022-06-20 23:09:27.823238
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:09:40.462000
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    parser = ModuleArgsParser(load_collections=False)
    task_ds = {'action': 'echo hi', 'args': 'a=1', 'delegate_to': 'test_value'}
    res = parser.parse(task_ds)
    assert res[0] == 'echo'
    assert res[1] == {'a': '1'}
    assert res[2] == 'test_value'

    parser = ModuleArgsParser(load_collections=False)
    task_ds = {'action': 'echo hi', 'args': 'a=1', 'delegate_to': 'test_value'}
    res = parser.parse(task_ds)
    assert res[0] == 'echo'
    assert res[1] == {'a': '1'}

# Generated at 2022-06-20 23:09:42.003177
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    assert False, "No test_ModuleArgsParser_parse"


# Generated at 2022-06-20 23:09:51.935249
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    task_ds = {'action': 'shell', 'delegate_to': 'some hostname'}
    parser = ModuleArgsParser(task_ds=task_ds)
    valid_attrs = set(Task._valid_attrs.keys())
    valid_attrs.update(set(Handler._valid_attrs.keys()))
    valid_attrs.update(['local_action', 'static'])
    valid_attrs = frozenset(valid_attrs)
    assert parser._task_attrs == valid_attrs

# Generated at 2022-06-20 23:09:55.529526
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser
    assert parser._task_ds == {}
    assert parser.resolved_action is None
    assert isinstance(parser._task_attrs, frozenset)
    assert isinstance(parser._collection_list, frozenset)


# Generated at 2022-06-20 23:10:07.952795
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test with exception when task_ds is not a dict
    task_ds = 'string_value'
    parser = ModuleArgsParser(task_ds=task_ds)
    with pytest.raises(AnsibleAssertionError):
        parser.parse()
    # Test with module string and no args passed, which is None
    task_ds = {'module': 'shell', 'shell': 'pwd'}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == ('shell', {}, None)
    # Test with no module names specified
    task_ds = {}
    parser = ModuleArgsParser(task_ds=task_ds)
    assert parser.parse() == (None, {}, None)



# Generated at 2022-06-20 23:10:18.891337
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    module_loader, modules = module_loader_loader.all_candidate_objects()
    action_loader, actions = action_loader_loader.all_candidate_objects()
    global DEFAULT_HASH_BEHAVIOUR
    DEFAULT_HASH_BEHAVIOUR = 'replace'

# Generated at 2022-06-20 23:10:32.153987
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': {'module': 'copy', 'src': 'a', 'dest': 'b' }}
    collection_list = ['ansible.builtin.copy']
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse(True) == ('copy', {}, None),  "Returned: %s" % obj.parse(True)

    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = ['ansible.builtin.copy']
    obj = ModuleArgsParser(task_ds, collection_list)
    assert obj.parse(True) == ('copy', {'dest': 'b', 'src': 'a'}, None),  "Returned: %s" % obj.parse(True)


# Generated at 2022-06-20 23:10:34.597271
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    obj = ModuleArgsParser()
    assert(isinstance(obj._task_attrs, frozenset))
    assert(obj.resolved_action is None)



# Generated at 2022-06-20 23:10:47.470947
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    task = {'include_tasks': 'somewhere/ntp.yml', 'register': 'ntp'}
    parser = ModuleArgsParser(task)
    result = parser.parse()
    assert result == ('include_tasks', {'task_path': 'somewhere/ntp.yml', 'register': 'ntp'}, None)

    task = {'action': 'copy src=a dest=b'}
    parser = ModuleArgsParser(task)
    result = parser.parse()
    assert result == ('copy', {'src': 'a', 'dest': 'b'}, None)

    task = {'action': 'local_action: shell echo hi'}
    parser = ModuleArgsParser(task)
    result = parser.parse()

# Generated at 2022-06-20 23:10:58.023946
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser.parse() == (None,None,None)

# Generated at 2022-06-20 23:11:07.187945
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.common.collections import ImmutableDict
    # empty case
    task_ds = {}
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action is None
    assert args == {}
    assert delegate_to is None

    # local action
    task_ds = ImmutableDict({'local_action': 'shell echo hi'})
    parser = ModuleArgsParser(task_ds)
    action, args, delegate_to = parser.parse()
    assert action == 'shell'
    assert isinstance(args, dict)
    assert args['_raw_params'] == 'echo hi'
    assert delegate_to == 'localhost'

    # local action variant

# Generated at 2022-06-20 23:11:11.370470
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser([{'action': 'echo 1', 'delegate_to': 'localhost'}])
    assert module_args_parser.parse() == ('echo', {'_raw_params': '1'}, 'localhost')

# Generated at 2022-06-20 23:11:20.308955
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = {'shell': 'ls'}
    module_args_parser = ModuleArgsParser(task_ds)
    assert isinstance(module_args_parser._task_attrs, frozenset), "The type of '_task_attrs' should be frozenset"
    assert isinstance(module_args_parser._task_ds, dict)
    assert module_args_parser._task_ds == task_ds
    assert module_args_parser._collection_list == None
    assert module_args_parser.resolved_action == None

# Unit tests for real usage of the class ModuleArgsParser

# Generated at 2022-06-20 23:11:32.765034
# Unit test for method parse of class ModuleArgsParser

# Generated at 2022-06-20 23:11:34.805750
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  '''
  Unit test for the ModuleArgsParser method parse()
  '''
  pass

# Generated at 2022-06-20 23:11:36.088245
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    module_args_parser = ModuleArgsParser()
    results = module_args_parser.parse()
    assert not results, results


# -----------------------------------------------------------------------------
# utility methods for plugins
# -----------------------------------------------------------------------------


# Generated at 2022-06-20 23:11:37.659544
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_parser = ModuleArgsParser(task_ds=None)


# Generated at 2022-06-20 23:11:49.050123
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = dict(action='net_put', dest='.', key_filename='/test',
              src='test.zip', recursive=True, exclude='test',
              use_ssh_args=True, validate_certs=False, force=True,
              src_format='zip', dest_format='json',
              provider=dict(host='localhost', username='test',
                            password='test'))

# Generated at 2022-06-20 23:12:00.642864
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # test_task_ds_type_not_dict()
    test_task_ds = None
    with pytest.raises(AnsibleAssertionError) as cm:
        test_ModuleArgsParser_instance = ModuleArgsParser(task_ds=test_task_ds)
    assert "should be a dict" in str(cm)
    test_task_ds = [1,2,3]
    with pytest.raises(AnsibleAssertionError) as cm:
        test_ModuleArgsParser_instance = ModuleArgsParser(task_ds=test_task_ds)
    assert "should be a dict" in str(cm)
    test_task_ds = "abc"

# Generated at 2022-06-20 23:12:10.181423
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    assert ModuleArgsParser()

# Generated at 2022-06-20 23:12:12.833345
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Constructor should not accept non-dict
    with pytest.raises(AnsibleAssertionError):
        ModuleArgsParser(task_ds=None)


# Generated at 2022-06-20 23:12:19.305485
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common.collections import is_iterable
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    module_path = '/home/travis/virtualenv/python3.6.5/bin/ansible-playbook'
    ds = dict(action='command', register='result')
    obj = ModuleArgsParser(ds)
    obj._task_ds = dict(action='command', register='result')
    obj._collection_list = None
    obj._task_attrs = frozenset(['register'])
    args = dict()
    action, args,

# Generated at 2022-06-20 23:12:24.152509
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  parser = ModuleArgsParser( task_ds=None, collection_list=None )
  assert parser.parse().__class__ == tuple


# Generated at 2022-06-20 23:12:36.130102
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args = dict(
        shell='ls -al /tmp',
        args='chdir=/tmp'
    )
    task = dict(
        action=module_args
    )
    task_ds = Task()
    task_ds.update(task)
    module_args_parser = ModuleArgsParser(task_ds=task_ds)
    action, args, delegate_to = module_args_parser.parse()
    assert(action == 'shell')
    assert(delegate_to is None)
    assert(args == {u'chdir': u'/tmp', u'_raw_params': u'ls -al /tmp'})

    module_args = dict(
        yum='name=httpd state=latest'
    )

# Generated at 2022-06-20 23:12:47.374101
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    parser = ModuleArgsParser()
    assert parser._task_ds == {}
    assert parser._task_attrs == frozenset(['debug', 'changed_when', 'notify', 'local_action', 'register', 'when',
                                            'async', 'any_errors_fatal', 'failed_when', 'until', 'ignore_errors', 'first_available_file',
                                            'pause', 'with_items', 'retries', 'run_once', 'delay', 'loop_control',
                                            'errors_that_disable_module_execution', 'failed_when_result', 'tags', 'loop', 'static'])
    assert parser._collection_list == None

    ds = dict(key='value')
    parser = ModuleArgsParser(ds, False)
    assert parser._task_ds == ds

# Generated at 2022-06-20 23:12:59.540490
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    # Test standard YAML form
    task_ds = {'command': 'echo hi', 'args': {'chdir': '/tmp'}}
    task = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = task.parse()
    assert action == 'command'
    assert args == {'chdir': '/tmp'}
    assert delegate_to == Sentinel

    # Test standard YAML form with unknown var
    task_ds = {'command': 'echo hi', 'args': {'unknown_var': '/tmp'}}
    task = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = task.parse()
    assert action == 'command'
    assert args == {'unknown_var': '/tmp'}
    assert delegate_to == Sentinel

    # Test complex args form, for

# Generated at 2022-06-20 23:13:06.386428
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.playbook.play_context import PlayContext
    task_ds = {}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    print(action, args, delegate_to)

    task_ds = {'action': 'copy src=a dest=b'}
    collection_list = []
    module_args_parser = ModuleArgsParser(task_ds, collection_list)
    action, args, delegate_to = module_args_parser.parse()
    print(action, args, delegate_to)


# Generated at 2022-06-20 23:13:08.029951
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()
    assert module_args_parser is not None


# Generated at 2022-06-20 23:13:15.030978
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    ds = {'action': 'copy', 'local_action': 'command', 'action1': 'copy', 'args':{'chdir':'/tmp'}}
    ModuleArgsParser(ds)
    ds = {'action': 'copy', 'local_action': 'command', 'action1': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    ModuleArgsParser(ds)
    ds = {'action': 'copy src=a dest=b', 'local_action': 'command', 'action1': {'module': 'copy', 'src': 'a', 'dest': 'b'}}
    ModuleArgsParser(ds)

# Generated at 2022-06-20 23:13:28.488409
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    obj = ModuleArgsParser()
    assert True

# Generated at 2022-06-20 23:13:31.999135
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds = {'action': 'copy', 'y': 2}
    parser = ModuleArgsParser(task_ds)
    assert parser.parse() == ('copy', {'y': 2}, None)



# Generated at 2022-06-20 23:13:39.703326
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    expected_error_message = "the type of 'task_ds' should be a dict, but is a <class 'str'>"
    module_args_parser = None
    try:
        module_args_parser = ModuleArgsParser(task_ds=b"foo")
        assert(False)
    except Exception as e:
        assert(e.args[0] == expected_error_message)

    module_args_parser = ModuleArgsParser(task_ds={"foo": "bar"})
    assert(module_args_parser is not None)


# Generated at 2022-06-20 23:13:40.172234
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  pass

# Generated at 2022-06-20 23:13:48.019043
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-20 23:14:00.553293
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    class TestTask(unittest.TestCase):
        def setUp(self):
            self.test_task = ModuleArgsParser()

        def test_parse_args_dict(self):
            task_ds = dict()
            task_ds['args'] = dict()
            task_ds['args']['region'] = 'xyz'
            result = self.test_task.parse(task_ds)
            expected = ('region', {'region': 'xyz'}, None)
            self.assertEqual(result, expected)

        def test_parse_args_string(self):
            task_ds = dict()
            task_ds['args'] = 'region=xyz'
            result = self.test_task.parse(task_ds)
            expected = ('region', {'region': 'xyz'}, None)
           

# Generated at 2022-06-20 23:14:09.407840
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Test the successful case
    task_ds = dict(
        action='copy', 
        src=dict(
            name='/opt', 
            state='directory'), 
        delegate_to='localhost', 
        dest=dict(
            name='/tmp', 
            state='directory'))
    parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = parser.parse(skip_action_validation=True)
    assert action == 'copy'
    assert args == {'src': {'name': '/opt', 'state': 'directory'}, 'dest': {'name': '/tmp', 'state': 'directory'}}
    assert delegate_to == 'localhost'

    # Test the error case

# Generated at 2022-06-20 23:14:21.578826
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    mock_task_ds = {"action": "shell echo hi"}
    mock_collection_list = []
    mock_skip_action_validation = True
    mock_action_loader = ActionModuleLoader()
    mock_module_loader = ModuleLoader()
    mock_action_loader.find_plugin_with_context = MagicMock(return_value=mock_module_loader.find_plugin_with_context(module_name="shell"))
    mock_module_loader.find_plugin_with_context = MagicMock(return_value=mock_module_loader.find_plugin_with_context(module_name="shell"))
    obj1 = ModuleArgsParser(mock_task_ds, mock_collection_list, mock_skip_action_validation)

# Generated at 2022-06-20 23:14:34.123168
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    task_ds_dict_obj = dict(task1 = dict(action = 'shell', delegate_to = 'localhost', args = 'echo hi'))
    task_ds_dict_obj_1 = dict(task1 = dict(action = 'shell', args = 'echo hi'))
    task_ds_dict_obj_2 = dict(task1 = dict(local_action = 'shell', args = 'echo hi'))
    task_ds_dict_obj_3 = dict(task1 = dict(module = 'shell', args = 'echo hi'))
    assert ModuleArgsParser(task_ds_dict_obj).parse() == (u'shell', {u'args': u'echo hi', u'_raw_params': u'echo hi'}, u'localhost')
    assert ModuleArgsParser(task_ds_dict_obj_1).parse()

# Generated at 2022-06-20 23:14:35.502391
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    module_args_parser = ModuleArgsParser()



# Generated at 2022-06-20 23:14:56.143539
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    # Testing both the supported and unsupported type of 'thing' is not feasible due to the
    # return `action, args, delegate_to`
    _test_ds = {'action': 'command'}
    _my_ansible_test = ModuleArgsParser(_test_ds)
    _action, _args = _my_ansible_test._normalize_new_style_args(None, 'command')
    assert _action == 'command'
    assert _args == None

    _test_ds = {'action': 'command'}
    _my_ansible_test = ModuleArgsParser(_test_ds)
    _action, _args = _my_ansible_test._normalize_old_style_args('command')
    assert _action == 'command'
    assert _args == None
# FIXME: find out why the following test is

# Generated at 2022-06-20 23:15:08.174327
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    test_task_data = {
        'name': 'test_task',
        'include_role': {
            'name': 'test_role',
            'tasks_from': 'tasks/main.yml',
            'vars': {
                'test_variable': 'foo'
            }
        }
    }

    test_task_data_with_shell_command = {
        'name': 'test_task',
        'shell': 'ls -la /'
    }


# Generated at 2022-06-20 23:15:18.167882
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():

    ds = {}
    actual = ModuleArgsParser(ds).parse()
    assert actual == (None, dict(), None)

    ds = dict(a=1)
    actual = ModuleArgsParser(ds).parse()
    assert actual == (None, dict(), None)

    ds = dict(action='a')
    actual = ModuleArgsParser(ds).parse()
    assert actual == (None, dict(), None)

    ds = dict(a=1, action='a')
    actual = ModuleArgsParser(ds).parse()
    assert actual == (None, dict(), None)

    ds = dict(action='a', a=1)
    actual = ModuleArgsParser(ds).parse()
    assert actual == (None, dict(), None)

    ds = dict(delegate_to='a')

# Generated at 2022-06-20 23:15:20.696450
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    task_ds = dict(action='setup', delegate_to='localhost')
    parser = ModuleArgsParser(task_ds)
    assert parser._task_ds == task_ds


# Generated at 2022-06-20 23:15:32.140866
# Unit test for constructor of class ModuleArgsParser

# Generated at 2022-06-20 23:15:33.648475
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():

    module_parser = ModuleArgsParser()
    module_parser.parse()
    return module_parser

# Generated at 2022-06-20 23:15:38.307194
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    test_data = {"ansible_play_hosts_all": "1,2,3,4,5"}
    parser = ModuleArgsParser(test_data, collection_list=None)
    assert_equal(parser._task_ds, test_data)

# Unit tests for _split_module_string

# Generated at 2022-06-20 23:15:44.261983
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
  _task_ds = {}
  _collection_list = None
  parser = ModuleArgsParser(_task_ds, _collection_list)
  thing = None
  action = 'debug'
  delegate_to = AnsibleUndefined
  args = dict()
  assert parser.parse() == ('debug', args, 'localhost')

# Generated at 2022-06-20 23:15:44.824462
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    mp = ModuleArgsParser()

# Generated at 2022-06-20 23:15:56.874487
# Unit test for constructor of class ModuleArgsParser
def test_ModuleArgsParser():
    from ansible.utils import context_objects as co
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader
    co._init_context()


# Generated at 2022-06-20 23:16:25.835911
# Unit test for method parse of class ModuleArgsParser
def test_ModuleArgsParser_parse():
    d = {'action': 'command echo'}
    assert ModuleArgsParser().parse(d) == ('command', {u'_raw_params': u'echo'}, None)
    d = {'action': 'copy src=a dest=b'}
    assert ModuleArgsParser().parse(d) == ('copy', {u'src': u'a', u'dest': u'b'}, None)
    d = {'action': {'module': 'copy src=a dest=b'}}
    assert ModuleArgsParser().parse(d) == ('copy', {u'src': u'a', u'dest': u'b'}, None)
    d = {'action': {'module': 'copy src=a dest=b', 'foo': 'bar'}}