

# Generated at 2022-06-20 20:58:35.838761
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-20 20:58:37.522265
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemExit(1)
    except Exception:
        e = get_exception()

    return e

# Generated at 2022-06-20 20:58:39.811613
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException()
    except Exception:
        e = get_exception()
        assert isinstance(e, TestException)



# Generated at 2022-06-20 20:58:45.019171
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo bar')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo bar'

    # Make sure we don't generate a new exception here
    assert e is get_exception()

# Generated at 2022-06-20 20:58:52.454637
# Unit test for function get_exception
def test_get_exception():
    # This is an intentionally very bad exception class.  It doesn't have any
    # of the attributes an exception should have.  It isn't even derived from
    # Exception.  It is however very easy to make a copy of.
    class BadExceptionClass(object):
        pass
    def func():
        try:
            raise BadExceptionClass()
        except:
            e = get_exception()
            return e
    e = func()
    assert isinstance(e, BadExceptionClass)


# Generated at 2022-06-20 20:59:07.761328
# Unit test for function get_exception
def test_get_exception():
    # Test function matches Python 3.x behavior
    try:
        1 / 0
    except:
        e = get_exception()
    else:
        assert False, 'Exception not raised'
    assert isinstance(e, ZeroDivisionError)

    # Test function matches Python 2.x behavior
    try:
        1 / 0
    except:
        e = get_exception()
    else:
        assert False, 'Exception not raised'
    assert isinstance(e, ZeroDivisionError)

    # Test exception
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    else:
        assert False, 'Exception not raised'
    assert isinstance(e, Exception)
    assert str(e) == 'foo'

# Generated at 2022-06-20 20:59:09.428686
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()

    assert type(e) == ZeroDivisionError



# Generated at 2022-06-20 20:59:11.386940
# Unit test for function get_exception
def test_get_exception():
    import pytest
    class Foo(object):
        pass
    e = Foo()
    try:
        raise e
    except Foo:
        assert get_exception() is e


# Generated at 2022-06-20 20:59:14.363454
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError:
        assert 'foo' == str(get_exception())


# Generated at 2022-06-20 20:59:18.767269
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception('test')

    try:
        foo()
    except:
        try:
            raise
        except Exception as e:
            assert e == get_exception()

# Generated at 2022-06-20 20:59:40.045558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
    assert e.args[0] == "Test exception"

# Generated at 2022-06-20 20:59:44.619401
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'
    assert e.__class__ == RuntimeError

# Generated at 2022-06-20 20:59:50.379948
# Unit test for function get_exception
def test_get_exception():
    some_error_occurred = False
    try:
        try:
            raise ValueError('Error message')
        except Exception:
            e = get_exception()
    except ValueError:
        some_error_occurred = True
    assert some_error_occurred

# Generated at 2022-06-20 20:59:55.614426
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'
test_get_exception()

# Generated at 2022-06-20 21:00:00.476858
# Unit test for function get_exception
def test_get_exception():
    try:  # Python 2.x
        raise Exception('Spam')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'Spam'

    try:
        1 / 0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-20 21:00:02.484553
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test message')
    except:
        # Use two spaces to setup the indentation
        assert str(get_exception()) == 'test message'

# Generated at 2022-06-20 21:00:05.580418
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:00:07.084344
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        assert get_exception().args[0] == 'test'

# Generated at 2022-06-20 21:00:17.606839
# Unit test for function get_exception
def test_get_exception():
    exception_str = "get_exception() called while no exception is being handled"
    try:
        get_exception()
    except RuntimeError as e:
        assert e.message == exception_str
    else:
        assert False, 'get_exception() did not raise RuntimeError'

    try:
        raise ValueError('get_exception() was able to retrieve this exception')
    except ValueError as e:
        assert e.args[0] == 'get_exception() was able to retrieve this exception'
        got_exception = get_exception()
        assert got_exception.args[0] == 'get_exception() was able to retrieve this exception'
    else:
        assert False, 'get_exception() was not able to retrieve the ValueError exception'



# Generated at 2022-06-20 21:00:18.645056
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception()



# Generated at 2022-06-20 21:00:53.414354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        e2 = get_exception()

    if e != e2:
        raise Exception("get_exception() returned the wrong exception")

# Generated at 2022-06-20 21:00:56.166956
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()
        assert(str(e) == "foo")



# Generated at 2022-06-20 21:00:58.712838
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException("test")
    except MyException:
        e = get_exception()
        assert e.args[0] == "test"

# Generated at 2022-06-20 21:01:03.354530
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('a',)


# Generated at 2022-06-20 21:01:15.652278
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ZeroDivisionError('testing 1 2 3')

    try:
        foo()
        assert False, 'foo() should have raised an exception'
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), 'Expected a ZeroDivisionError, got %r' % e

    try:
        foo()
        assert False, 'foo() should have raised an exception'
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), 'Expected a ZeroDivisionError, got %r' % e

# Generated at 2022-06-20 21:01:17.478688
# Unit test for function get_exception

# Generated at 2022-06-20 21:01:23.331536
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert 'foo' in str(e)
        assert e.__class__ == Exception
    else:
        raise AssertionError('get_exception failed')



# Generated at 2022-06-20 21:01:28.066326
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except Exception:
        e = get_exception()
        print(e)

    try:
        raise ValueError('Test exception')
    except Exception:
        e = get_exception()
        print(e)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:01:31.174069
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('test')
    except TestException:
        exc = get_exception()
    assert exc.args[0] == 'test'


# Generated at 2022-06-20 21:01:35.294767
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert type(e) == type(Exception())
        assert 'Exception' in str(e)

# Generated at 2022-06-20 21:02:45.051272
# Unit test for function get_exception

# Generated at 2022-06-20 21:02:49.789310
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u"\xa9")
    except Exception:
        e = get_exception()
        assert unicode(e) == u"\xa9"


# Generated at 2022-06-20 21:02:54.867212
# Unit test for function get_exception

# Generated at 2022-06-20 21:02:59.097505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError as e:
        returned = get_exception()
        assert returned == e, "get_exception should return the exception that is currently being handled"

# Generated at 2022-06-20 21:03:02.514782
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception")
    except Exception:
        e = get_exception()
        assert str(e) == "An exception"

# Generated at 2022-06-20 21:03:04.987559
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert 'foo' in str(e)


# Generated at 2022-06-20 21:03:07.143182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-20 21:03:09.715831
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("foo")
    except TypeError:
        e = get_exception()

    assert str(e) == 'foo'


# Generated at 2022-06-20 21:03:13.655447
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass
    try:
        raise CustomException()
    except Exception as e:
        assert e.__class__ == CustomException
        assert get_exception().__class__ == CustomException


# Generated at 2022-06-20 21:03:17.251003
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
        print('%s: %s' % (e.__class__.__name__, e))
        assert isinstance(e, RuntimeError)



# Generated at 2022-06-20 21:05:51.606245
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    def func():
        raise TestException('foo')

    try:
        func()
    except:
        e = get_exception()
        assert isinstance(e, TestException)
        assert str(e) == 'foo'
        assert e.args == ('foo',)

# Generated at 2022-06-20 21:05:55.550565
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        assert id(get_exception()) == id(sys.exc_info()[1])


# Generated at 2022-06-20 21:06:01.020321
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    try:
        1 / 0
    except:
        e = get_exception()
        assert type(e) == ZeroDivisionError
    # pylint: enable=bare-except

# Generated at 2022-06-20 21:06:07.817819
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-argument
    def foo():
        try:
            try:
                raise ValueError('bar')
            except Exception:
                e = get_exception()
        finally:
            return e

    def bar(e):
        return e

    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)
    assert foo().args == ('bar',)
    assert bar(e).args == ('foo',)

# Generated at 2022-06-20 21:06:12.629195
# Unit test for function get_exception
def test_get_exception():
    import traceback
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert traceback.format_exc() == traceback.format_exc(e)



# Generated at 2022-06-20 21:06:15.395676
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test")
    except Exception:
        assert Exception("Test") == get_exception()

# Generated at 2022-06-20 21:06:19.323847
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'test exception'

# Generated at 2022-06-20 21:06:21.315682
# Unit test for function get_exception

# Generated at 2022-06-20 21:06:28.340462
# Unit test for function get_exception
def test_get_exception():
    import traceback

    class TestException(Exception):
        pass

    try:
        raise TestException('This is a test exception')
    except TestException:
        exc_type, exc, _ = sys.exc_info()
        test_exc = get_exception()
        exc_name = exc.__class__.__name__
        test_exc_name = test_exc.__class__.__name__
        if exc_name != test_exc_name:
            raise TestException('Got wrong exception type: %s vs %s' % (exc_name, test_exc_name))
        if exc.message != test_exc.message:
            raise TestException('Got wrong exception message: %s vs %s' % (exc.message, test_exc.message))

# Generated at 2022-06-20 21:06:31.090547
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        assert get_exception()