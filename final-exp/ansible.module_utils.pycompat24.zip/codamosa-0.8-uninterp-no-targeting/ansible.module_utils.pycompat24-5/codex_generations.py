

# Generated at 2022-06-20 20:58:43.383454
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is an exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'this is an exception', e.args



# Generated at 2022-06-20 20:58:46.260798
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert get_exception().__str__() == 'Test exception'


# Generated at 2022-06-20 20:58:55.876527
# Unit test for function get_exception
def test_get_exception():
    def f1():
        return 1+2
    def f2():
        raise ValueError('TK')
    def f3():
        return f1()
    def f4():
        return f2()
    def f5():
        try:
            return f1()
        except:
            return get_exception()

    assert f1() == 3
    assert f2().args[0] == 'TK'
    assert f3() == 3
    assert f4().args[0] == 'TK'
    assert f5().args[0] == 'TK'



# Generated at 2022-06-20 20:59:03.032077
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works in various versions of Python.

    This function doesn't actually do much testing.  It only runs to make sure
    that we can put python 3.x compatible syntax into this module and still have
    it run in python 2.x.  The __future__ import above is the essential part of
    this dance.
    """
    try:
        1 / 0
    except:
        if get_exception() is not ZeroDivisionError:
            raise ValueError("get_exception() didn't return the exception")



# Generated at 2022-06-20 20:59:06.208433
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('unit test')
    except:
        err = get_exception()
    assert 'unit test' in str(err)

# Generated at 2022-06-20 20:59:08.021452
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Some error text')
    except ValueError as e:
        assert str(e) == str(get_exception())

# Generated at 2022-06-20 20:59:17.504663
# Unit test for function get_exception
def test_get_exception():
    test_text = u"This is a text"

    # Works with a custom exception
    try:
        raise Exception("Exception message")
    except:
        exc_info = get_exception()
        assert "Exception message" in exc_info.message

    # Works with a UnicodeDecodeError
    try:
        test_text.decode("ascii")
    except:
        exc_info = get_exception()
        assert isinstance(exc_info, UnicodeDecodeError)

    # Works with a UnicodeEncodeError
    try:
        test_text.encode("ascii")
    except:
        exc_info = get_exception()
        assert isinstance(exc_info, UnicodeEncodeError)

# Generated at 2022-06-20 20:59:20.846793
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert e.args[0] == 'test'

# Generated at 2022-06-20 20:59:24.009796
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-20 20:59:30.465448
# Unit test for function get_exception
def test_get_exception():
    def raise_value_error():
        raise ValueError("Ansible is too awesome")
    try:
        raise_value_error()
    except ValueError:
        e = get_exception()
        assert "Ansible is too awesome" in str(e)
        assert type(e) == ValueError


# Generated at 2022-06-20 20:59:42.828774
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError()
    except ValueError:
        e = get_exception()

    assert e.__class__ == ValueError



# Generated at 2022-06-20 20:59:46.240497
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-20 20:59:48.271000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Invoked exception')
    except Exception:
        e = get_exception()
        assert(str(e) == 'Invoked exception')

# Generated at 2022-06-20 20:59:49.407282
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('ho hum')
    except Exception as e:
        assert e is get_exception()

# Generated at 2022-06-20 21:00:01.349864
# Unit test for function get_exception
def test_get_exception():
    def check_exception(exception):
        """Helper function that makes sure we have a sane exception."""
        try:
            raise exception
        except Exception:
            exception = get_exception()
            if not hasattr(exception, 'args'):
                raise Exception('exception does not have an args attribute')
            if not isinstance(exception.args, tuple):
                raise Exception('exception.args is not a tuple')
            if exception.args != (exception.message,):
                raise Exception('exception.args is not a singleton tuple with exception.message')
            if exception.args[0] != exception.message:
                raise Exception('exception.args[0] is not exception.message')
            if str(exception) != exception.message:
                raise Exception('str(exception) != exception.message')
           

# Generated at 2022-06-20 21:00:05.737254
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert e.args == ('test exception',)



# Generated at 2022-06-20 21:00:12.784782
# Unit test for function get_exception
def test_get_exception():
    # This test is meant to be run in an debugger with breakpoints set on the
    # first line of the try and on the exception call below to verify that the
    # current exception is being returned.
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()

    assert 'test' in str(e)

# Generated at 2022-06-20 21:00:15.763157
# Unit test for function get_exception
def test_get_exception():
    """Test that we can get the exception object no matter what version of Python is running"""
    try:
        raise Exception
    except:
        exception = get_exception()
    assert exception is not None
    assert isinstance(exception, Exception)

# Generated at 2022-06-20 21:00:19.060609
# Unit test for function get_exception
def test_get_exception():
    try:
        raise_me = NameError
        raise raise_me
    except Exception:
        e = get_exception()
        assert NameError == e.__class__
        assert type('') == type(e.message)
        assert 'raise_me' == e.args[0]



# Generated at 2022-06-20 21:00:21.890906
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)



# Generated at 2022-06-20 21:00:36.352970
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.__class__.__name__ == 'ValueError'
    else:
        raise AssertionError("get_exception() didn't capture the exception")


# Generated at 2022-06-20 21:00:43.280368
# Unit test for function get_exception
def test_get_exception():
    def func():
        try:
            1 / 0
        except Exception as e:
            raise Exception('exception should be caught above')
        else:
            return 'correct'
    try:
        func()
    except Exception as e:
        e
    else:
        raise Exception('func should have raised an exception')



# Generated at 2022-06-20 21:00:53.469979
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("TEST EXCEPTION")
    except RuntimeError as exc:
        got_exc = get_exception()
        if got_exc is not exc:
            raise AssertionError("Did not get the exception we just raised.  Expected=%s Got=%s" % (exc, got_exc))

    try:
        raise RuntimeError("TEST EXCEPTION")
    except RuntimeError:
        got_exc = get_exception()
        if str(got_exc) != 'TEST EXCEPTION':
            raise AssertionError("Did not get the exception we just raised.  Got=%s" % (got_exc))



# Generated at 2022-06-20 21:01:02.021247
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args[0] == 'foo'

if __name__ == '__main__':
    import unittest

    class TestLiteralEval(unittest.TestCase):
        def test_str(self):
            result = literal_eval('"foo"')
            assert result == 'foo'

        def test_unicode(self):
            result = literal_eval(u'"foo"')
            assert result == u'foo'

        def test_int(self):
            result = literal_eval('1')
            assert result == 1

        def test_long(self):
            result = literal_eval('1L')
            assert result == 1

       

# Generated at 2022-06-20 21:01:05.427552
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'test'

# Generated at 2022-06-20 21:01:18.343453
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info[0] < 3:
        # on Python 2, this will be a string
        # because we need to support python 2.4 we cannot reraise the
        # exception correctly
        msg = 'this is a test message'
        try:
            raise RuntimeError(msg)
        except RuntimeError:
            e = get_exception()
        if e.__class__.__name__ == 'str' and e == msg:
            # python 2.4
            pass
        else:
            assert e.__class__ is RuntimeError
            assert e.args == (msg,)

# Generated at 2022-06-20 21:01:25.410025
# Unit test for function get_exception
def test_get_exception():
    """Make sure that get_exception returns the current exception and that it
    works.

    This test is the simplest way to demonstrate the code working.  More
    advanced Python tests are covered by the unit tests for the
    ansible.module_utils functions.
    """
    try:
        raise ValueError('Current Exception')
    except ValueError:
        assert get_exception().args[0] == 'Current Exception'

# Generated at 2022-06-20 21:01:29.416239
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except ValueError:
        value = get_exception()
        assert value.args == ('testing',)

# Generated at 2022-06-20 21:01:32.834829
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foobar')
    except RuntimeError as e:
        assert get_exception() == e



# Generated at 2022-06-20 21:01:35.409608
# Unit test for function get_exception
def test_get_exception():
    try:
        e = None
        raise Exception("foo")
    except:
        e = get_exception()
    assert "foo" in str(e)

# Generated at 2022-06-20 21:01:56.647050
# Unit test for function get_exception
def test_get_exception():
    class Example(Exception):
        pass

    try:
        raise Example
    except: # pylint: disable=bare-except
        e = get_exception()
    assert isinstance(e, Example)

# Generated at 2022-06-20 21:02:00.040249
# Unit test for function get_exception
def test_get_exception():
    # Set up exception
    try:
        raise RuntimeError("This is a test of get_exception")
    except RuntimeError:
        # Make sure the exception we get is the same as the current exception
        assert(get_exception() is sys.exc_info()[1])

# Generated at 2022-06-20 21:02:02.320650
# Unit test for function get_exception

# Generated at 2022-06-20 21:02:08.434264
# Unit test for function get_exception
def test_get_exception():
    try:
        # When you're checking for code coverage, the code will work
        # differently because the traceback will go back to the caller
        # of the function rather than the caller of get_exception.
        # Double check that we'll succeed in those cases
        raise ValueError('Test exception: get_exception')
    except ValueError as e:
        assert e == get_exception(), 'Failed to retrieve the correct exception'

# Generated at 2022-06-20 21:02:12.407412
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-20 21:02:14.683892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-20 21:02:16.691918
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-20 21:02:19.734797
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception as e:
        ex = get_exception()
        assert ex == e



# Generated at 2022-06-20 21:02:22.090792
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException("some message")
    except TestException as e: # pylint: disable=unused-variable
        assert get_exception() is e


# Generated at 2022-06-20 21:02:24.744905
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        e = get_exception()
        assert str(e) == '', 'Uncaught exception makes test fail'


# Generated at 2022-06-20 21:03:03.237509
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert str(get_exception()) == 'foo'

test_get_exception()

# Generated at 2022-06-20 21:03:06.205837
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except:
        res = get_exception()
        assert str(res) == "Test exception", "get_exception() raised the wrong exception %s" % res

# Generated at 2022-06-20 21:03:10.039827
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-20 21:03:15.588425
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e == get_exception()
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-20 21:03:20.109160
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('This is a type error')
    except:
        e = get_exception()
        assert isinstance(e, TypeError)
        assert 'This is a type error' in str(e)

# Generated at 2022-06-20 21:03:22.947075
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Exception message")
    except Exception:
        e = get_exception()
        assert e.args[0] == "Exception message"

# Generated at 2022-06-20 21:03:25.318613
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-20 21:03:29.554762
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 21:03:33.839547
# Unit test for function get_exception
def test_get_exception():
    '''Unit test for function get_exception'''
    try:
        raise ValueError
    except:
        assert get_exception() is not None



# Generated at 2022-06-20 21:03:37.215938
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-20 21:04:58.564740
# Unit test for function get_exception
def test_get_exception():
    def raises():
        raise RuntimeError("test")

    try:
        raises()
    except RuntimeError as e:
        if get_exception() is not e:
            raise

    try:
        raises()
    except RuntimeError:
        e = get_exception()
        if str(e) != "test":
            raise

    try:
        raises()
    except RuntimeError:
        e = get_exception()
        if repr(e) != "RuntimeError('test',)":
            raise


# Generated at 2022-06-20 21:05:02.010165
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Whoops!")
    except Exception:
        e = get_exception()
        if str(e) != "Whoops!":
            raise AssertionError("Wrong exception: %s" % str(e))



# Generated at 2022-06-20 21:05:07.093206
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Another Banana')
    except: # pylint: disable=bare-except
        e = get_exception()
        assert str(e) == 'Another Banana'
        assert isinstance(e, Exception)


# Generated at 2022-06-20 21:05:10.688022
# Unit test for function get_exception

# Generated at 2022-06-20 21:05:16.001448
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=broad-except,try-except-raise,unused-variable

    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'test exception'

# Generated at 2022-06-20 21:05:20.721177
# Unit test for function get_exception
def test_get_exception():
    def some_function():
        try:
            blah
            error = None
        except NameError:
            error = get_exception()
        return error

    e = some_function()
    assert isinstance(e, NameError)
    assert str(e) == "global name 'blah' is not defined"



# Generated at 2022-06-20 21:05:23.646573
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-20 21:05:25.879546
# Unit test for function get_exception
def test_get_exception():
    __tracebackhide__ = True
    try:
        1/0
    except:
        assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-20 21:05:31.165116
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except ValueError:
        exc = get_exception()
    assert exc is not None
    assert isinstance(exc, ValueError)
    assert str(exc) == 'Test'

# Generated at 2022-06-20 21:05:36.987464
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception')
    except ValueError:
        exc = get_exception()
        assert exc.args == ('Testing get_exception',)
    else:
        assert False, "Didn't raise exception"

