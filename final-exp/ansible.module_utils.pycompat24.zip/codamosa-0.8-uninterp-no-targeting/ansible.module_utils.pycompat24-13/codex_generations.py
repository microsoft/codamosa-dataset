

# Generated at 2022-06-20 20:58:40.632548
# Unit test for function get_exception
def test_get_exception():
    def testfunc():
        raise ValueError
    try:
        testfunc()
    except Exception as e:
        assert get_exception() == e

# Generated at 2022-06-20 20:58:43.877233
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test get_exception')
    except:
        e = get_exception()
        assert str(e) == 'Test get_exception', e

test_get_exception()

# Generated at 2022-06-20 20:58:48.865080
# Unit test for function get_exception
def test_get_exception():
    '''
    Test function get_exception
    '''

    def test_func():
        '''
        Test function for get_exception
        '''
        try:
            raise RuntimeError("Test message for get_exception")
        except Exception:
            exc = get_exception()

        assert exc is not None
        assert str(exc) == "Test message for get_exception"

    test_func()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 20:58:54.184850
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing exception!')
    except ValueError:
        exception = get_exception()

    if exception is None:
        sys.stderr.write("Tests failed, exception was not passed through")
        exit(1)


# Generated at 2022-06-20 20:58:57.189321
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    try:
        raise NameError("xxxxx")
    except:
        nameerror = get_exception()

    assert isinstance(nameerror, NameError)

# Generated at 2022-06-20 20:59:01.607695
# Unit test for function get_exception
def test_get_exception():

    def do_except():
        try:
            raise Exception('foo')
        except Exception:
            return get_exception()

    assert isinstance(do_except(), Exception)
    assert do_except().args[0] == 'foo'


# Unit test.

# Generated at 2022-06-20 20:59:05.760487
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('that is an error')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'that is an error', "got unexpected exception string: %s" % str(e)



# Generated at 2022-06-20 20:59:08.657551
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        ex = get_exception()
    assert str(ex) == "test"


# Generated at 2022-06-20 20:59:12.936851
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.message == 'foo'



# Generated at 2022-06-20 20:59:16.687249
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'test'



# Generated at 2022-06-20 20:59:26.095727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-20 20:59:27.324699
# Unit test for function get_exception
def test_get_exception():
    # There are many ways to test this.  This shows one that's pretty general
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
    assert e.args == ('foobar',), e.args


# Generated at 2022-06-20 20:59:30.017276
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Unit tests for function literal_eval

# Generated at 2022-06-20 20:59:32.990359
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-20 20:59:36.126122
# Unit test for function get_exception
def test_get_exception():
    # Test that we can get the current exception
    try:
        raise ValueError('a test exception')
    except ValueError:
        assert get_exception()
    else:
        raise AssertionError('get_exception was not able to retrieve the current exception')

# Generated at 2022-06-20 20:59:39.900758
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hi')
    except Exception:
        e = get_exception()

    assert 'hi' == str(e)

# Generated at 2022-06-20 20:59:43.816381
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception() is not None
        assert str(get_exception()) == 'foo'

# Generated at 2022-06-20 20:59:56.173807
# Unit test for function get_exception
def test_get_exception():
    '''
    Run through some tests to ensure that we're getting the correct exceptions
    out of the function
    '''
    def raise_exc1():
        raise Exception('Test exception')

    def raise_exc2():
        try:
            raise_exc1()
        except Exception:
            raise Exception('Test exception')

    def raise_exc3():
        try:
            raise_exc2()
        except Exception:
            raise Exception('Test exception')

    # Verify that we get the base exception
    try:
        raise_exc1()
        assert False
    except Exception:
        exc = get_exception()
        assert str(exc) == 'Test exception'

    # Verify that we get the same exception when handling one exception
    try:
        raise_exc2()
        assert False
    except Exception:
        exc = get_

# Generated at 2022-06-20 20:59:59.304391
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except:
        # This is the line that actually checks to make sure that the function works
        if not isinstance(get_exception(), TypeError):
            raise AssertionError

# Generated at 2022-06-20 21:00:03.292428
# Unit test for function get_exception

# Generated at 2022-06-20 21:00:14.760925
# Unit test for function get_exception
def test_get_exception():
    ''' Test get_exception()'''
    try:
        raise ValueError("Hello")
    except ValueError:
        e = get_exception()

    assert e.args[0] == "Hello"

# Generated at 2022-06-20 21:00:29.663363
# Unit test for function get_exception
def test_get_exception():
    import inspect
    from ansible.module_utils.six import PY2

    # Make sure that get_exception works in isolation
    def whoops():
        raise RuntimeError('Stuff happened')
    try:
        whoops()
    except:
        e = get_exception()
        assert e.args[0] == 'Stuff happened'

    # Make sure that get_exception works within a function that calls it.
    if PY2:
        frame = inspect.currentframe().f_back
    else:
        frame = inspect.currentframe()

    def oops():
        try:
            whoops()
        except:
            e = get_exception()
            return e
    e = oops()
    assert e.args[0] == 'Stuff happened'
    assert frame is not None
    del frame

# Generated at 2022-06-20 21:00:34.206732
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        e = get_exception()
    assert e.args[0] == "test"


# Generated at 2022-06-20 21:00:36.199453
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except:
        exc = get_exception()
    assert isinstance(exc, RuntimeError)

# Generated at 2022-06-20 21:00:43.733883
# Unit test for function get_exception
def test_get_exception():
    # Function get_exception defined in this module does not raise exceptions
    # If it does, we will catch it and re-raise, so we can see the
    # original exception
    try:
        get_exception()
    except Exception as e:
        raise e
    try:
        get_exception(1, 2)
    except Exception as e:
        raise e


# Generated at 2022-06-20 21:00:50.828231
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        exc = get_exception()
        assert type(exc) == ZeroDivisionError
        assert exc.args == (('integer division or modulo by zero',),)
    else:
        assert False, 'No exception raised'


# Generated at 2022-06-20 21:00:53.392723
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('shazam')
    except Exception:
        e = get_exception()
        assert type(e) is Exception
        assert unicode(e) == u'shazam'

# Generated at 2022-06-20 21:00:58.713139
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('test message')
    except Exception:
        e = get_exception()
        assert e.__class__ == TestException
        assert str(e) == 'test message'

    try:
        raise ValueError('test message')
    except Exception:
        e = get_exception()
        assert e.__class__ == ValueError
        assert str(e) == 'test message'

# Generated at 2022-06-20 21:01:04.074534
# Unit test for function get_exception
def test_get_exception():
    # We can't use "try: except Exception as e:" on Python 2.4-2.5, or
    # even "except Exception, e:" on Python 3.x.  We must use
    # "except Exception: e = get_exception()" instead.
    # See PEP-3110 """
    try:
        raise Exception('foo')
    except:
        result = get_exception()
    assert result.args == ('foo',)
test_get_exception()

# Generated at 2022-06-20 21:01:07.396068
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-20 21:01:30.773158
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('get_exception() unit test.')
    except: # pylint: disable=bare-except
        e = get_exception()
        assert isinstance(e, Exception)
        assert 'get_exception() unit test.' in str(e)
        assert not hasattr(e, '__traceback__')  # must be stored as a sys attribute instead of an attribute of the exception
        assert 'sys._getframe()' in repr(e)  # if we have the traceback, the repr will give us a hint about where the exception was raised


# Generated at 2022-06-20 21:01:35.531410
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('This is a type error')
    except TypeError:
        assert TypeError == get_exception().__class__
        assert 'This is a type error' == str(get_exception())

# Generated at 2022-06-20 21:01:38.160746
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-20 21:01:46.217077
# Unit test for function get_exception
def test_get_exception():
    """
    Check that get_exception() works

    :returns: ``True`` if ``get_exception()`` works or ``False`` if not
    :rtype: ``bool``
    """
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        return str(e) == "Test exception"


# Generated at 2022-06-20 21:01:50.672764
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is an error message')
    except RuntimeError:
        exc = get_exception()
        assert exc.args[0] == 'This is an error message'



# Generated at 2022-06-20 21:01:58.089787
# Unit test for function get_exception
def test_get_exception():
    def test_exception():
        try:
            raise ValueError('foo')
        except:
            return get_exception()

    e = test_exception()
    assert e.args == ('foo',)


# vim: set expandtab: tabstop=4: shiftwidth=4: softtabstop=4

# Generated at 2022-06-20 21:02:00.418189
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)

# Generated at 2022-06-20 21:02:03.146579
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-20 21:02:07.098156
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()

    # Make sure that it actually is the same exception that runtimeerror
    # reported.
    assert e.args == ('test',)

# Generated at 2022-06-20 21:02:18.905017
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-variable
    """
    Test ast.literal_eval().

    When 'ast.literal_eval' is available, the function should behave like 'ast.literal_eval',
    otherwise it should behave like a rough replacement.
    """
    from ansible.module_utils.six import PY2, PY3

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Capture stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()

    # Test on Python 2.x
    if PY2:
        five = None
        e = None

# Generated at 2022-06-20 21:02:57.375382
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()

    assert e.args == ('foo',)



# Generated at 2022-06-20 21:03:01.866786
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test exception'



# Generated at 2022-06-20 21:03:05.869260
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 21:03:09.074445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e == sys.exc_info()[1]

# Generated at 2022-06-20 21:03:13.578182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is the error message')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'this is the error message'

# Generated at 2022-06-20 21:03:23.767453
# Unit test for function get_exception
def test_get_exception():
    # Test to make sure that get_exception works with exception chaining.
    try:
        raise Exception('Test exception')
    except Exception as e:
        try:
            raise Exception('Test exception 2')
        except Exception as e2:
            e1 = get_exception()
            e2 = get_exception()
            assert e1.args == ('Test exception',)
            assert e2.args == ('Test exception 2',)

# Generated at 2022-06-20 21:03:29.812797
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception returns the correct exception"""
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e).startswith('integer division or modulo by zero')

# Generated at 2022-06-20 21:03:40.264375
# Unit test for function get_exception
def test_get_exception():
    def test_exception():
        try:
            2 / 0
        # Python 2.4 doesn't raise ZeroDivisionError here, so we have to be
        # generic
        except:
            return get_exception()

    # one way to get the test to pass is to change the return value of
    # get_exception() to zero.  Obviously, this shouldn't happen in a real
    # system.
    zero = test_exception()
    assert zero == zero.__class__(zero)

# Generated at 2022-06-20 21:03:51.277050
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:53.893524
# Unit test for function get_exception
def test_get_exception():

    try:
        raise Exception("Testing get_exception")
    except Exception:
        assert get_exception().args[0] == "Testing get_exception"

# Generated at 2022-06-20 21:05:10.924603
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        return 1 / 0

    try:
        test_func()
    except Exception as e:
        assert e == get_exception()
    # Test that the code doesn't throw an exception
    get_exception()


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:05:12.808007
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=missing-docstring
    try:
        raise ValueError(42)
    except Exception:
        assert get_exception().args == (42,)


# Generated at 2022-06-20 21:05:17.845009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This exception is the answer')
    except RuntimeError as e:
        e_value = get_exception()
        assert len(e_value.args) == 1
        assert e_value.args[0] == 'This exception is the answer'

# Generated at 2022-06-20 21:05:20.417313
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
    except:
        raise            # pragma: no cover


# Generated at 2022-06-20 21:05:22.668147
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)



# Generated at 2022-06-20 21:05:37.654997
# Unit test for function get_exception
def test_get_exception():

    def tester(fn, args, expected):
        try:
            fn(*args)
            assert False
        except:
            assert str(get_exception()) == str(expected)

    tester(lambda: 1 + None, (), TypeError('unsupported operand type(s) for +: \'int\' and \'NoneType\''))
    tester(lambda: None.foo(), (), AttributeError('\'NoneType\' object has no attribute \'foo\''))
    tester(lambda x: 1 + x, (None,), TypeError('unsupported operand type(s) for +: \'int\' and \'NoneType\''))
    tester(lambda x: None.foo(x), (None,), AttributeError('\'NoneType\' object has no attribute \'foo\''))

# Generated at 2022-06-20 21:05:45.775427
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError) and str(exc) == 'test exception'
    try:
        raise ValueError('test exception') from exc
    except Exception:
        newexc = get_exception()
        assert isinstance(newexc, ValueError) and str(newexc) == 'test exception'
        assert newexc.__cause__ is exc
        assert newexc.__suppress_context__
    try:
        raise ValueError('test exception')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError) and str(exc) == 'test exception'

# Generated at 2022-06-20 21:05:50.751321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'
    assert repr(e)
    assert len(e) == 3


# Generated at 2022-06-20 21:05:54.550132
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Foo!")
    except Exception:
        e = get_exception()

    assert str(e) == "Foo!"


# Generated at 2022-06-20 21:06:01.875604
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception()."""
    try:
        raise Exception('Dummy exception')
    except Exception as e:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'Dummy exception'

if __name__ == '__main__':
    test_get_exception()