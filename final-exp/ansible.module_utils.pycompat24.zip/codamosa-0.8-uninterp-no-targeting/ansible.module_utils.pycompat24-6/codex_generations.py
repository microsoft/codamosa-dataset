

# Generated at 2022-06-20 20:58:39.178802
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        assert get_exception()


# Generated at 2022-06-20 20:58:41.692615
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'testing'


# Generated at 2022-06-20 20:58:53.320959
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        # Python 2.4 - 2.6: sys.exc_info() returns (type, value, traceback)
        # Python 3.x: sys.exc_info() returns (type, value, traceback)
        _, value, _ = sys.exc_info()
        if value.args[0] != 'test exception':
            raise AssertionError("value.args[0] is %r (expected 'test exception')"
                                 % value.args[0])
        if not issubclass(value.__class__, Exception):
            raise AssertionError("value.__class__ is %r (expected a subclass of Exception)"
                                 % value.__class__)
    # Python 2.4 - 2.6: exception type is in global name space
    #

# Generated at 2022-06-20 20:58:55.824398
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyboardInterrupt
    except Exception:
        assert get_exception() is KeyboardInterrupt
    else:
        assert False

# Generated at 2022-06-20 20:58:59.674917
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'Test exception'

# Generated at 2022-06-20 20:59:02.183339
# Unit test for function get_exception
def test_get_exception():

    def test():
        1/0

    try:
        test()
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-20 20:59:07.942210
# Unit test for function get_exception
def test_get_exception():
    '''Unit test for get_exception'''
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == 'foo'



# Generated at 2022-06-20 20:59:09.837103
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this message')
    except:
        excep = get_exception()
    assert str(excep) == 'this message'

# Generated at 2022-06-20 20:59:20.531022
# Unit test for function get_exception
def test_get_exception():
    """
    Unit test for function get_exception
        Tests with no exception
        Tests with raise
        Tests with raise exception

    """
    def test_no_exception():
        """
        No Exception Test
        """
        try:
            pass
        except:
            assert False
        else:
            assert True

    def test_with_raise():
        """
        Exception Test
        """
        try:
            raise Exception("Testing")
        except Exception:
            assert True
        else:
            assert False

    def test_with_exception():
        """
        Exception Test
        """
        try:
            raise ArithmeticError("Testing ArithmeticError")
        except Exception as err:
            assert err.__class__.__name__ == "ArithmeticError"
        else:
            assert False

    test_no_ex

# Generated at 2022-06-20 20:59:29.995696
# Unit test for function get_exception
def test_get_exception():
    # works on jython
    try:
        raise ValueError("moo")
    except ValueError:
        e = get_exception()
        assert str(e) == "moo"
        assert type(e) is ValueError
    # works on py3k
    try:
        raise ValueError("moo")
    except ValueError:
        e = get_exception()
        assert str(e) == "moo"
        assert type(e) is ValueError



# Generated at 2022-06-20 20:59:41.318281
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        try:
            get_exception().args[0] == 'integer division or modulo by zero'
        except AttributeError:
            assert get_exception().args[0] == 'integer division or modulo by zero'


# Generated at 2022-06-20 20:59:45.933158
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test error")
    except RuntimeError:
        e = get_exception()
    assert "This is a test error" == str(e)


# Generated at 2022-06-20 20:59:49.593738
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise KeyError('hello')
    except KeyError as e:
        assert get_exception() is e
    else:
        assert False

    try:
        raise KeyError('hello')
    except KeyError:
        assert isinstance(get_exception(), KeyError)
    else:
        assert False



# Generated at 2022-06-20 20:59:55.056219
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1/0
        assert False, 'should not get here'
    except ZeroDivisionError:
        e = get_exception()

    assert e.__class__ is ZeroDivisionError



# Generated at 2022-06-20 20:59:57.901180
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        exc = get_exception()
        assert exc.args == ('test exception',)

# Generated at 2022-06-20 21:00:05.734433
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        def __init__(self, message):
            self.message = message

    def function_1():
        raise MyException('test')

    def function_2():
        try:
            raise MyException('test')
        except:
            e = get_exception()
        return e

    try:
        function_1()
    except:
        result = get_exception()

    assert isinstance(result, MyException)
    assert result.message == 'test'

    result = function_2()
    assert isinstance(result, MyException)
    assert result.message == 'test'


# Generated at 2022-06-20 21:00:16.676337
# Unit test for function get_exception
def test_get_exception():
    """test_get_exception - Simple test of the get_exception function"""
    class MyException(Exception):
        """Exception for testing get_exception"""

    class MyPython3Exception(Exception):
        """Exception for testing get_exception"""

        def __init__(self, a, b):
            pass  # pylint: disable=unnecessary-pass

    try:
        raise MyException(123)
    except MyException:
        exc_info = get_exception()
        assert exc_info.args == (123, ), "Can't retrieve the arguments for an exception on Python 2"
    try:
        raise MyPython3Exception(123, 456)
    except MyPython3Exception:
        exc_info = get_exception()

# Generated at 2022-06-20 21:00:18.323481
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError as e:
        _e = get_exception()

    assert e == _e


# Generated at 2022-06-20 21:00:22.726652
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-20 21:00:25.028111
# Unit test for function get_exception
def test_get_exception():
    """
    This test function is all we can do because of the nature of get_exception
    it is not possible to throw an exception within get_exception and expect
    to get that exception.
    """
    try:
        1/0
    except:
        assert type(get_exception()) is ZeroDivisionError
    else:
        assert False

# Generated at 2022-06-20 21:00:45.489255
# Unit test for function get_exception
def test_get_exception():
    """Test to ensure that get_exception always returns a value"""
    try:
        raise IOError()
    except IOError:
        exc = get_exception()
    assert isinstance(exc, IOError)

# Generated at 2022-06-20 21:00:49.785552
# Unit test for function get_exception
def test_get_exception():

    def test_function():
        try:
            raise Exception
        except Exception:
            e = get_exception()
        return e

    assert test_function() is not None, 'Test function get_exception failed'


# Generated at 2022-06-20 21:00:51.373811
# Unit test for function get_exception
def test_get_exception():
    #TODO: unit test
    pass

# Generated at 2022-06-20 21:00:53.237184
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-20 21:01:00.421670
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception as e:
        assert e is get_exception()
        assert isinstance(get_exception(), Exception)
        assert str(get_exception()) == 'Test'
        assert get_exception().args == ('Test',)

    try:
        raise Exception('Test', 'Arg1')
    except Exception as e:
        assert e is get_exception()
        assert isinstance(get_exception(), Exception)
        assert str(get_exception()) == 'Test'
        assert get_exception().args == ('Test', 'Arg1')

test_get_exception()

# Generated at 2022-06-20 21:01:05.018997
# Unit test for function get_exception
def test_get_exception():
    def divide(x, y):
        return x / y
    try:
        divide(1, 0)
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-20 21:01:06.358431
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("It's dead, Jim")
    except RuntimeError as e:
        assert str(e) == get_exception()



# Generated at 2022-06-20 21:01:08.314658
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError()
    except KeyError:
        e = get_exception()
        assert isinstance(e, KeyError)

# Generated at 2022-06-20 21:01:12.929364
# Unit test for function get_exception

# Generated at 2022-06-20 21:01:16.836860
# Unit test for function get_exception
def test_get_exception():
    """Get the current exception.

    This code needs to work on Python 2.4 through 3.x, so we cannot use
    "except Exception, e:" (SyntaxError on Python 3.x) nor
    "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    Instead we must use ::

        except Exception:
            e = get_exception()
    """

    try:
        raise Exception('testing exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'testing exception'

# Generated at 2022-06-20 21:01:53.603625
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception() # pylint: disable=bare-except
        assert str(e) == 'foo'
        assert type(e) == ValueError

# Generated at 2022-06-20 21:01:56.845540
# Unit test for function get_exception
def test_get_exception():
    def raises():
        raise ZeroDivisionError('foo')
    try:
        raises()
    except ZeroDivisionError as e:
        assert get_exception() is e
    else:
        assert False, "ZeroDivisionError didn't raise"


# Unit tests for literal_eval

# Generated at 2022-06-20 21:01:58.683528
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('dummy')
    except:
        exc = get_exception()
    assert exc.args == ('dummy',)



# Generated at 2022-06-20 21:02:00.558499
# Unit test for function get_exception
def test_get_exception():
    def get():
        try:
            1/0
        except ZeroDivisionError:
            return get_exception()
    exception = get()
    assert isinstance(exception, ZeroDivisionError)

# Generated at 2022-06-20 21:02:02.125211
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Should be caught')
    except Exception:
        pass
    e = get_exception()
    assert 'Should be caught' in str(e)


# Generated at 2022-06-20 21:02:06.855292
# Unit test for function get_exception
def test_get_exception():
    def function():
        def inner():
            raise Exception('foo')
        inner()
    try:
        function()
        assert False
    except Exception:
        assert('foo' == str(get_exception()))


# Generated at 2022-06-20 21:02:09.663262
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Something failed")
    except ValueError:
        e = get_exception()
        assert e.args[0] == "Something failed"


# Generated at 2022-06-20 21:02:11.936800
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('dummy error')
    except:
        e = get_exception()
        if str(e) != 'dummy error':
            raise AssertionError('Unexpected exception text: %s' % str(e))

# Generated at 2022-06-20 21:02:15.105178
# Unit test for function get_exception
def test_get_exception():
    def raise_it():
        raise Exception('boo!')
    try:
        raise_it()
    except Exception:
        e = get_exception()
    assert e.args == ('boo!', )

# Generated at 2022-06-20 21:02:17.047065
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-20 21:03:36.823939
# Unit test for function get_exception
def test_get_exception():
    import traceback

    try:
        yield 1
    except:
        e = get_exception()
        f = sys.exc_info()[1]
        y = 1
        while y < 7:
            s = traceback.format_tb(sys.exc_info()[2])[y]
            y = y + 0
        tb = sys.exc_info()[2]
        yield e
        yield f
        yield s
        yield tb

    g = get_exception()
    assert g is None


# Generated at 2022-06-20 21:03:40.038018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert sys.exc_info() == sys.exc_info()


# Generated at 2022-06-20 21:03:42.368079
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('silly test')
    except Exception:
        assert get_exception().args[0] == 'silly test'

# Generated at 2022-06-20 21:03:44.986403
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-20 21:03:47.058061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        assert get_exception() == sys.exc_info()[1]



# Generated at 2022-06-20 21:03:51.361892
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise Exception('Test Exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert 'Test Exception' == str(e)

# Generated at 2022-06-20 21:04:02.582174
# Unit test for function get_exception
def test_get_exception():
    # Ensure the code works for various versions of python
    # Calling get_exception() outside of an exception context
    #  results in an AttributeError being thrown
    try:
        get_exception()
    except AttributeError:
        pass
    else:
        raise AssertionError("Ensuring get_exception works when there is no exception raised")

    # Ensure that get_exception actually returns the exception
    try:
        raise AssertionError("This is an assertion error raised to check that get_exception works")
    except Exception as e:
        e_raised = e
    try:
        raise AssertionError("This is a second assertion error raised to check that get_exception works")
    except Exception:
        e_retrieved = get_exception()

# Generated at 2022-06-20 21:04:04.602341
# Unit test for function get_exception
def test_get_exception():
    try:
        foo
    except NameError:
        e = get_exception()
    assert e.__class__ == NameError



# Generated at 2022-06-20 21:04:10.994596
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception.

    This is a test function that can be run to make sure that get_exception
    works on both python2 and python3.
    """
    # pylint: disable=bare-except
    try:
        raise ValueError("Hello")
    except:
        e = get_exception()
        assert e.args[0] == "Hello"

# Generated at 2022-06-20 21:04:16.120881
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'NameError'
    assert str(e) == 'foo'


# Generated at 2022-06-20 21:07:06.888461
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except ValueError:
        e = get_exception()
        assert unicode(e) == u'test_get_exception'

# Generated at 2022-06-20 21:07:10.338123
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 21:07:14.917136
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('msg')
    except ValueError:
        e = get_exception()

    assert e.args == ('msg',)
    assert str(e) == 'msg'

# Generated at 2022-06-20 21:07:19.877036
# Unit test for function get_exception
def test_get_exception():
    '''
    This tests that we are getting the exception correctly.
    '''
    # Make sure that get_exception() returns something
    # that behaves like an exception
    try:
        raise Exception
    except Exception:
        got_exc = get_exception()
    assert isinstance(got_exc, Exception)
    assert isinstance(got_exc, Exception)



# Generated at 2022-06-20 21:07:29.383971
# Unit test for function get_exception

# Generated at 2022-06-20 21:07:31.973557
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("get_exception test")
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == "get_exception test"



# Generated at 2022-06-20 21:07:47.288626
# Unit test for function get_exception
def test_get_exception():
    # A function that we can call that raises an exception
    def test_raise(err):
        raise err

    try:
        test_raise(Exception('Default test exception with no special attributes'))
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Default test exception with no special attributes', \
            'get_exception() fails in when getting a "normal" exception instance'
        assert not hasattr(e, 'foo'), 'get_exception() fails when getting a "normal" exception instance'

    # A test exception class with a custom attribute
    class TestException(Exception):
        def __init__(self):
            self.foo = 'bar'

    try:
        test_raise(TestException())
    except Exception:
        e = get_exception()

# Generated at 2022-06-20 21:07:53.291086
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except:
        e = get_exception()
        if str(e) != 'test_get_exception':
            raise ValueError("test_get_exception failed to capture exception")

# Generated at 2022-06-20 21:07:58.478878
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-20 21:08:03.681694
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except Exception:
        e = get_exception()
        assert 'ValueError' in str(e)
        assert 'This is a test' in str(e)