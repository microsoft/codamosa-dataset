

# Generated at 2022-06-20 20:58:43.581088
# Unit test for function get_exception
def test_get_exception():
    def raises():
        raise ValueError

    try:
        raises()
    except ValueError:
        exc = get_exception()
        assert ValueError == type(exc)



# Generated at 2022-06-20 20:58:46.452661
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()



# Generated at 2022-06-20 20:58:52.200297
# Unit test for function get_exception

# Generated at 2022-06-20 20:58:55.761312
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 20:58:59.631151
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        exc = get_exception()
    assert exc.__class__ is ZeroDivisionError


# Generated at 2022-06-20 20:59:03.462093
# Unit test for function get_exception
def test_get_exception():
    """Tests for get_exception()

    :returns: None

    """
    # Placeholder for when we add actual unit tests
    return None



# Generated at 2022-06-20 20:59:06.694154
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert exc.message == 'foo'



# Generated at 2022-06-20 20:59:10.990096
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 20:59:14.631243
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'test'


# Generated at 2022-06-20 20:59:17.276318
# Unit test for function get_exception

# Generated at 2022-06-20 20:59:37.777841
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("bar")
    except Exception as e:
        e1 = get_exception()


# Generated at 2022-06-20 20:59:43.507129
# Unit test for function get_exception
def test_get_exception():
    def test_it():
        raise ValueError('testing testing')

    try:
        test_it()
    except:
        exc = get_exception()
        assert exc.__class__.__name__ == 'ValueError'
        assert str(exc) == 'testing testing'

# Generated at 2022-06-20 20:59:46.239864
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e is not None

# Generated at 2022-06-20 20:59:54.977225
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Exception Example 1')
    except Exception as e:
        assert get_exception() is e
        assert get_exception() is not e

    try:
        raise ValueError('Exception Example 2')
    except Exception:
        e = get_exception()
        assert str(e) == 'Exception Example 2'
        assert get_exception() is e
        assert get_exception() is not e

# Generated at 2022-06-20 20:59:57.817492
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
        assert e.args == ('foobar', )


# Generated at 2022-06-20 21:00:00.052095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
    assert e.args == ('test',)

# Generated at 2022-06-20 21:00:05.541152
# Unit test for function get_exception
def test_get_exception(): # pragma: no cover
    def raise_exception(message):
        class MyException(Exception):
            def __init__(self, message):
                self.message = message
        raise MyException(message)

    try:
        raise_exception('foo')
    except:
        exc = get_exception()
        print(exc.message)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:00:11.454961
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise Exception('foobar')
        except Exception:
            e = get_exception()
        return e

    if test().args[0] != 'foobar':
        raise AssertionError('test for get_exception failed')

# Generated at 2022-06-20 21:00:15.725946
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception gets the exception correctly"""
    class SomeError(Exception):
        pass

    try:
        raise SomeError('foo')
    except SomeError as e:
        assert get_exception() == e
    except:
        assert False, 'Failed to set the exception'

# Generated at 2022-06-20 21:00:17.555730
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo')
    except ValueError as e:
        got_exception = get_exception()
    assert e is got_exception


# Generated at 2022-06-20 21:00:59.004337
# Unit test for function get_exception
def test_get_exception():


    # Get the current exception
    try:
        raise Exception('foo') # pylint: disable=redefined-outer-name
    except Exception:
        e = get_exception()

    # Empty the exception
    try:
        pass
    except Exception: # pylint: disable=redefined-outer-name
        pass

    # Get the latest exception
    try:
        raise Exception('bar') # pylint: disable=redefined-outer-name
    except Exception:
        e2 = get_exception()

    # Check that we got the latest exception and not the one from before
    assert str(e) == 'foo'
    assert str(e2) == 'bar'



# Generated at 2022-06-20 21:01:13.864426
# Unit test for function get_exception
def test_get_exception():
    import pytest
    def raise_exc(exc):
        try:
            raise exc
        except exc.__class__:
            return get_exception()
        else:
            raise ValueError("should have raised")

    assert isinstance(raise_exc(ValueError("foo")), ValueError)
    assert isinstance(raise_exc(IOError("foo")), IOError)
    assert isinstance(raise_exc(TypeError("foo")), TypeError)
    assert isinstance(raise_exc(Exception()), Exception)
    assert raise_exc(None) is None
    with pytest.raises(ValueError):
        raise_exc(ValueError("foo"))
    with pytest.raises(IOError):
        raise_exc(IOError("foo"))

# Generated at 2022-06-20 21:01:17.014670
# Unit test for function get_exception
def test_get_exception():
    def toplevel():
        try:
            raise Exception()
        except Exception:
            return get_exception()

    assert isinstance(toplevel(), Exception)

# Generated at 2022-06-20 21:01:20.476133
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert repr(e) == "ZeroDivisionError('integer division or modulo by zero',)"


# Generated at 2022-06-20 21:01:25.976467
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function

    The test is just to see that we can run it, and that it returns something
    we expect (in this case, the built in TypeError).
    """

# Generated at 2022-06-20 21:01:31.208500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'



# Generated at 2022-06-20 21:01:33.898541
# Unit test for function get_exception
def test_get_exception():
    '''Test get_exception function'''
    try:
        raise RuntimeError('Stuff')
    except Exception:
        e = get_exception()
        assert str(e) == 'Stuff'

# Unit tests for function literal_eval.
import unittest


# Generated at 2022-06-20 21:01:39.807249
# Unit test for function get_exception
def test_get_exception():
    """Test whether or not get_exception returns the current exception."""

    try:
        raise ValueError('This is a test.')
    except ValueError:
        got_exception = get_exception()
    assert isinstance(got_exception, ValueError)
    assert got_exception.args == ('This is a test.', )
    assert got_exception.message == 'This is a test.'



# Generated at 2022-06-20 21:01:42.290316
# Unit test for function get_exception
def test_get_exception():
    import sys
    import traceback

    try:
        1/0
    except:
        exc = get_exception()
    tb = sys.exc_info()[2]
    formatted_exception = traceback.format_exception(*sys.exc_info())
    assert str(exc) in str(formatted_exception)

# Generated at 2022-06-20 21:01:43.574780
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing')
    except Exception:
        e = get_exception()
        assert(str(e) == 'Testing')



# Generated at 2022-06-20 21:02:20.680208
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('error')
    except NameError as e:
        assert get_exception() == e
        try:
            raise TypeError('error')
        except TypeError as e1:
            assert get_exception() == e1



# Generated at 2022-06-20 21:02:27.092999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing exceptions with get_exception')
    except: # pylint: disable=bare-except
        e = get_exception()

    assert 'testing exceptions with get_exception' == str(e)
    assert 'get_exception' in e.args[0]



# Generated at 2022-06-20 21:02:32.902880
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Exception")
    except Exception as e:
        test_e = e

    def check_exception(exc):
        assert get_exception() is exc
        try:
            raise exc
        except Exception as e:
            assert get_exception() is e
            return

    if sys.version_info < (3,):
        assert get_exception() is None
        check_exception(test_e)
        check_exception(SyntaxError("SyntaxError"))
        check_exception(ZeroDivisionError("ZeroDivisionError"))

# Generated at 2022-06-20 21:02:34.459705
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        assert get_exception().args[0] == 'test'

# Generated at 2022-06-20 21:02:37.956961
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-20 21:02:46.562031
# Unit test for function get_exception

# Generated at 2022-06-20 21:02:50.001921
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        exc = get_exception()
        assert exc.args == ("Test exception",)

# Generated at 2022-06-20 21:02:52.888460
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except:
        assert 'foo' in str(get_exception())

# Generated at 2022-06-20 21:03:02.830064
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        assert get_exception()

# None of the following python versions have the ast module in the stdlib.
# But we don't want to require the user to install it.
if sys.version_info[:2] in ((2, 4), (2, 5), (2, 6), (3, 1), (3, 2)):
    def test_literal_eval():
        assert literal_eval('A Test') == 'A Test'
        assert literal_eval(u'1.2') == 1.2
        assert literal_eval('[1, 2, 3]') == [1, 2, 3]
        assert literal_eval('(1, 2, 3)') == (1, 2, 3)
        assert literal_eval('{1: 2, 3: 4}')

# Generated at 2022-06-20 21:03:08.196578
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        pass

    try:
        raise ValueError('bar')
    except ValueError:
        value = get_exception()

    assert value.args == ('bar',)

# Generated at 2022-06-20 21:04:22.912987
# Unit test for function get_exception
def test_get_exception():
    def test_exception():
        return get_exception()

    def test_exception_with_no_exception():
        return get_exception()

    try:
        raise ValueError("Useful info")
    except ValueError as err:
        assert (test_exception() == err)

    assert (test_exception_with_no_exception() is None)

# Generated at 2022-06-20 21:04:28.144006
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
        assert exc.args[0] == "foo"

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-20 21:04:40.494586
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import iteritems

    def f1():
        try:
            1 / 0
        except ZeroDivisionError:
            return get_exception()

    def f2():
        try:
            1 / 0
        except ZeroDivisionError:
            raise ValueError('foo')

    for func in f1, f2:
        try:
            res = func()
        except ZeroDivisionError:
            pass
        except ValueError:
            res = get_exception()
        assert isinstance(res, ZeroDivisionError)
        assert res.args == ()

    def f3():
        try:
            1 / 0
        except ZeroDivisionError:
            raise ValueError('foo', 1, 2, 3)


# Generated at 2022-06-20 21:04:47.258387
# Unit test for function get_exception
def test_get_exception():
    def _test():
        raise RuntimeError('test exception message')
    try:
        _test()
    except Exception:
        exc = get_exception()
        assert type(exc) == RuntimeError
        assert str(exc) == 'test exception message'
        assert exc.args == ('test exception message',)


# Generated at 2022-06-20 21:04:52.270901
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("I'm an exception")
    except RuntimeError:
        exc = get_exception()
        assert "I'm an exception" in str(exc)
    else:
        assert False


# Generated at 2022-06-20 21:04:57.428275
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Expected exception')
    except:
        exc = get_exception()
        assert str(exc) == 'Expected exception'

# Generated at 2022-06-20 21:05:00.467524
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        if get_exception().args != e.args:
            raise AssertionError()
    else:
        raise AssertionError()

# Generated at 2022-06-20 21:05:04.096997
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Foo")
    except Exception:
        e = get_exception()
        assert e.message == "Foo"
    else:
        assert 0

# Generated at 2022-06-20 21:05:19.904428
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys

    class AssertRaisesContext:
        """The __exit__ method in this context manager throws an AssertionError
        with the passed in string if the passed in block of code does not raise
        an exception.  If the passed in block of code does raise an exception, the
        exception is returned in context.exception so that tests can make
        further assertions about it.
        """
        def __init__(self, expected_string):
            self.expected_string = expected_string

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, tb):
            if exc_type is None:
                try:
                    failure_exception(self.expected_string)
                except AssertionError:
                    return
            self.exception = exc

# Generated at 2022-06-20 21:05:23.277294
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception().args == ('foo',)


# Generated at 2022-06-20 21:06:54.134275
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Foo bar.')
    except:
        e = get_exception()
        assert isinstance(e, TypeError)
        assert e.args == ('Foo bar.',)

# Generated at 2022-06-20 21:06:57.966776
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 21:07:07.406081
# Unit test for function get_exception
def test_get_exception():

    def inner():
        try:
            # Let's get the current exception
            e = get_exception()
            assert e.args == ('out',)

            # We should also be able to catch further exceptions
            try:
                raise RuntimeError('foo')
            except:
                e2 = get_exception()
            assert e2.args == ('foo',)

        except:
            e3 = get_exception()
        assert e3.args == ('inner',)

    try:
        raise RuntimeError('out')
    except:
        inner()

# Generated at 2022-06-20 21:07:15.065433
# Unit test for function get_exception
def test_get_exception():
    import nose
    import ansible.module_utils.six as six
    from ansible.module_utils.test_get_exception import test_get_exception_class

    try:
        try:
            raise test_get_exception_class('This is the error message')
        except Exception:
            exc = get_exception()
            nose.tools.assert_equal(exc.args[0], 'This is the error message')
    finally:
        del sys.modules['ansible.module_utils.test_get_exception']


# Generated at 2022-06-20 21:07:18.426530
# Unit test for function get_exception
def test_get_exception():
    ''' Test function get_exception
    '''
    class SomeClass(object):
        pass
    try:
        SomeClass()[1]
    except:
        e = get_exception()
    assert isinstance(e, TypeError)

# Generated at 2022-06-20 21:07:23.229245
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert(str(e) == 'foo')
    try:
        raise Exception(u'bar')
    except:
        e = get_exception()
    assert(str(e) == 'bar')

# Generated at 2022-06-20 21:07:27.136660
# Unit test for function get_exception
def test_get_exception():
    def _raiser():
        raise Exception('foo')

    try:
        _raiser()
    except:
        tb = get_exception()

    assert isinstance(tb, Exception)
    assert tb.args == ('foo',)


# Generated at 2022-06-20 21:07:29.679121
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-20 21:07:33.248053
# Unit test for function get_exception
def test_get_exception():
    def throw(e=Exception, message='Test exception'):
        raise e(message)


# Generated at 2022-06-20 21:07:36.970368
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hi')
    except Exception:
        e = get_exception()
        assert(e.args[0] == 'hi')