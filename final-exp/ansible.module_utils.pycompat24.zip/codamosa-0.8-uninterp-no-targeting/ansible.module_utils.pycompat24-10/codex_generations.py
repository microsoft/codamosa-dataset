

# Generated at 2022-06-20 20:58:41.784623
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def test(exception):
        try:
            raise exception
        except Exception as e:
            # Grab the current exception
            my_e = get_exception()
            # Make sure get_exception doesn't alter the exception
            try:
                raise e
            except Exception as f:
                assert f == exception
                assert my_e == exception
                return
        pytest.fail('should not get here')

    # Test all the exceptions that are available on python2.7.
    # TODO: Add other specific exceptions that may appear on newer pythons.
    test(Exception())
    test(SystemExit())
    test(KeyboardInterrupt())

    test(GeneratorExit())
    test(StopIteration())
    test(ArithmeticError())
    test(FloatingPointError())

# Generated at 2022-06-20 20:58:51.387053
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('I am testing a RuntimeError')
    except RuntimeError as e:
        assert e is get_exception()

    try:
        raise ValueError('I am testing a ValueError')
    except ValueError as e:
        assert e is get_exception()
    except RuntimeError as e:
        assert False

    try:
        raise ImportError('I am testing an ImportError')
    except ImportError as e:
        assert e is get_exception()


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 20:58:55.773257
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0 # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 20:58:58.059328
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'testing'


# Generated at 2022-06-20 20:59:02.420167
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    def raises_exception():
        raise Exception

    try:
        raises_exception()
    except Exception:
        e = get_exception()

    if not isinstance(e, Exception):
        raise AssertionError("wrong exception instance")

# Generated at 2022-06-20 20:59:08.758019
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        real_exc_info = sys.exc_info()
        real_exception = real_exc_info[1]
        assert(real_exc_info[0] == get_exception().__class__)
        assert(real_exc_info[1] == get_exception())
        assert(real_exc_info[0] == real_exception.__class__)


# Generated at 2022-06-20 20:59:17.779550
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    # pylint: disable=wildcard-import,unused-wildcard-import
    from ansible.module_utils.six import PY2, PY3
    try:
        raise ValueError('test')
    except ValueError:
        exc = get_exception()
    if PY2:
        assert str(exc) == 'test'
    elif PY3:
        assert str(exc) == 'test'
    else:
        raise Exception('Test works only on Python 2 and Python 3.')

# Generated at 2022-06-20 20:59:21.781270
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception
        except Exception:
            return get_exception()

    e = f()
    assert isinstance(e, Exception)

# Generated at 2022-06-20 20:59:27.158591
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception()

    def bar():
        try:
            foo()
        except:
            return get_exception()
    res = bar()
    assert isinstance(res, Exception), "get_exception doesn't return the exception"



# Generated at 2022-06-20 20:59:29.610404
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Sample error message')
    except Exception as e:
        result = e
    assert result == get_exception()


# Generated at 2022-06-20 20:59:44.225479
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()
        ee = sys.exc_info()[1]  # The proper way to get the current exception
        assert e is ee
    else:
        assert False, 'should have thrown ZeroDivisionError'

# Generated at 2022-06-20 20:59:56.343885
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class CatchMe(Exception):
        """Exception to catch"""
        def __init__(self, foo):
            super(CatchMe, self).__init__()
            self.foo = foo

    class TestGetException(unittest.TestCase):
        """Unit test for function get_exception"""

        def test_exception_unused(self):
            """Catch an exception and do nothing with it.

            This is a test case that triggers the pylint warning:
            "Raised but not handled"

            This is an intentional pylint error that we want to trigger
            for the purposes of the unit test.  The pylint error message
            indicates that the problem is that the exception is never
            handled (will never get raised).  We're testing that this
            code doesn't trigger that error.
            """

# Generated at 2022-06-20 20:59:59.422646
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError as e:
        e2 = get_exception()
        assert(e == e2)
        assert(e is e2)


# Generated at 2022-06-20 21:00:01.496892
# Unit test for function get_exception
def test_get_exception():
    '''Test to ensure that get_exception returns the proper exception'''
    try:
        raise TypeError
    except Exception:
        assert isinstance(get_exception(), TypeError)

# Generated at 2022-06-20 21:00:05.816923
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception('hello')
    except Exception:
        e = get_exception()
    assert e is not None


# Generated at 2022-06-20 21:00:09.842530
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-20 21:00:12.242637
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("A test exception")
    except RuntimeError as e:
        assert e == get_exception()

# Generated at 2022-06-20 21:00:15.018146
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except: # pylint: disable=bare-except
        e = get_exception()
    return isinstance(e, RuntimeError)

# Generated at 2022-06-20 21:00:19.919483
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ValueError('message')
    try:
        foo()
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'message' in str(e)

# Generated at 2022-06-20 21:00:21.572025
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Error!")
    except ValueError:
        e = get_exception()
        assert e.args[0] == "Error!"

# Generated at 2022-06-20 21:00:39.800168
# Unit test for function get_exception
def test_get_exception():
    # Test that if we raise an exception and get_exception, it has the same info
    class TestException(Exception):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return repr(self.value)
    e1 = TestException('test_value')
    try:
        raise e1
    except Exception:
        e2 = get_exception()
    assert e1.value == e2.value

# Ansible's module_utils/six.py has been renamed to module_utils/six/__init__.py
# It should be importable via 'from ansible.module_utils.six import *'
# Caveats:
# * The other files in module_utils/six/* are not importable via this mechanism
# * This will not work in Python 2.4


# Generated at 2022-06-20 21:00:42.392002
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('xyz')
    except ValueError:
        e = get_exception()
    assert e.args == ('xyz',)



# Generated at 2022-06-20 21:00:45.242197
# Unit test for function get_exception

# Generated at 2022-06-20 21:00:56.378156
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import traceback
    from ansible.module_utils.six.moves import StringIO

    class ExceptionTest(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise Exception("foo")
            except Exception:
                exc = get_exception()
                self.assertEqual("Exception: foo", traceback.format_exc(exc))

            try:
                raise Exception("foo")
            except Exception:
                exc = get_exception()
                self.assertEqual("Exception: foo", traceback.format_exc(exc))

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(ExceptionTest))
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-20 21:00:58.278682
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except:
        e = get_exception()
    assert type(e) is ZeroDivisionError

# Generated at 2022-06-20 21:01:02.864309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)
    else:
        assert False, 'Not reached'

# Generated at 2022-06-20 21:01:16.362823
# Unit test for function get_exception
def test_get_exception():
    # Python 2.x
    try:
        1 / 0
    except:
        assert get_exception().__class__ == ZeroDivisionError
    # Python 3.x
    try:
        1 / 0
    except:
        assert get_exception().__class__ == ZeroDivisionError
    # Python 2.x
    try:
        1 / 0
    except:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError
    # Python 3.x
    try:
        1 / 0
    except:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError



# Generated at 2022-06-20 21:01:20.600778
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        assert str(get_exception()) == "foo"
    try:
        1/0
    except:
        assert str(get_exception()).find('by zero') > 0


# Generated at 2022-06-20 21:01:24.904169
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-20 21:01:33.644594
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            {}['test']
        except KeyError:
            e = get_exception()
            assert e is not None, "No exception found"
            assert isinstance(e, KeyError), "Exception is not a KeyError"
            assert str(e) == "'test'", "KeyError is not for key 'test'"
    raise_exception()

# Generated at 2022-06-20 21:01:51.133478
# Unit test for function get_exception
def test_get_exception():
    # NOTE: You cannot trigger an exception on python 2.4 to run this test because
    # there's no way to compare the exception.  You can at least exercise the code
    # in the function.
    get_exception()

# Generated at 2022-06-20 21:01:52.874400
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)

# Generated at 2022-06-20 21:01:54.959175
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:01:56.403906
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        pass
    assert get_exception() is not None

# Generated at 2022-06-20 21:01:59.031224
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        print(e.__class__.__name__)
        print(str(e))
        assert e.__class__.__name__ == 'ZeroDivisionError'



# Generated at 2022-06-20 21:02:00.619549
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('catch me')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'catch me'

# Generated at 2022-06-20 21:02:04.850685
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        e = get_exception()
        assert e.args == ("Test exception",), "get_exception doesn't work"


# Generated at 2022-06-20 21:02:12.677157
# Unit test for function get_exception
def test_get_exception():
    r"""Unit test for the get_exception function.

    Raise, catch and re-raise an exception to check that all the parts of an
    exception are preserved
    """
    try:
        raise Exception('foo', 'bar')
    except Exception as e:
        assert 'foo' == e.args[0]
        assert 'bar' == e.args[1]
        e2 = get_exceptio

# Generated at 2022-06-20 21:02:15.010359
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)


# Generated at 2022-06-20 21:02:21.768845
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestException(Exception):
        def __init__(self, message, value):
            self.value = value
            super(TestException, self).__init__(message)

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise TestException("This is a test exception", 42)
            except:
                exc = get_exception()
            self.assertEqual(exc.value, 42)
            self.assertTrue(isinstance(exc, TestException))

    unittest.main()

# Generated at 2022-06-20 21:02:59.722529
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        exception = get_exception()
        assert exception.args == ('foo',)
        assert isinstance(exception, ValueError)
        assert str(exception) == 'foo'


# Generated at 2022-06-20 21:03:04.534743
# Unit test for function get_exception
def test_get_exception():
    '''
    A method to test the get_exception method
    '''
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert 'test' in str(e)



# Generated at 2022-06-20 21:03:06.253424
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('boo')
    except Exception:
        assert get_exception()



# Generated at 2022-06-20 21:03:14.925687
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception returns the current exception.

    This code needs to work on Python 2.4 through 3.x, so we cannot use
    "except Exception, e:" (SyntaxError on Python 3.x) nor
    "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    Instead we must use ::

        try:
            raise Exception('test')
        except Exception:
            e = get_exception()

    """
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'test'

# Generated at 2022-06-20 21:03:17.570477
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == 'test'
    assert str(e) == 'test'

# Generated at 2022-06-20 21:03:20.412343
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        exc = get_exception()
    assert str(exc) == 'test exception'
    assert type(exc) == RuntimeError

# Generated at 2022-06-20 21:03:25.248786
# Unit test for function get_exception
def test_get_exception():
    """Test that the get_exception function works as expected

    This is not a complete test.  We just need to make sure that the code
    path is exercised for a test that will work on 2.4 through 2.6 and 3.x
    """
    try:
        int('Spam')
    except Exception:
        ex = get_exception()
        assert(str(ex) == "invalid literal for int() with base 10: 'Spam'")
        assert(isinstance(ex, ValueError))

# Generated at 2022-06-20 21:03:37.294127
# Unit test for function get_exception
def test_get_exception():
    """In python 2.4, sys.exc_info()[1] is None until you raise an exception.

    In python 2.5 and 2.6, sys.exc_info()[1] is None until you execute the
    except clause.  It is an error to refer to it in an except clause without
    raising an exception.  This unit test is to make sure that the
    get_exception() function does nothing to make that an error.
    """
    try:
        raise Exception('something broke')
    except:
        assert get_exception().args == ('something broke',)

# Generated at 2022-06-20 21:03:42.288812
# Unit test for function get_exception
def test_get_exception():
    """Test the ability of get_exception to return the exception."""
    try:
        raise Exception()
    except Exception:
        exc1 = get_exception()
        assert True
    try:
        raise Exception()
    except Exception as exc2:
        assert True

    assert exc1 == exc2

# Generated at 2022-06-20 21:03:45.491831
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a unit test for get_exception')
    except:
        assert ('This is a unit test for get_exception' == get_exception().args[0])

# Generated at 2022-06-20 21:05:01.539842
# Unit test for function get_exception
def test_get_exception():
    try:
        int('asdf')
    except Exception:
        exc = get_exception()

    # We don't know what kind of exception this is going to be, but we do know
    # that it should be an exception
    assert isinstance(exc, Exception)

    # This is a bare except statement, so we should be able to check the type
    # of the exception
    assert isinstance(exc, ValueError)

    # Python will return the same instance for the same exception in the same
    # place.  It does this by caching a pointer to the last exception used by
    # the get_exception() function.
    try:
        int('asdf')
    except Exception:
        exc2 = get_exception()
    assert exc is exc2

    # We don't know what kind of exception this is going to be, but we do

# Generated at 2022-06-20 21:05:15.057887
# Unit test for function get_exception
def test_get_exception():
    def return_exception():
        try:
            raise ValueError('Test error')
        except ValueError as e:
            if sys.version_info[0] >= 3:
                # Python >3 doesn't allow us to use the exception as a return value
                # without assigning it to a variable first.
                ee = e
                return ee
            else:
                return e

    exc = return_exception()
    assert exc.args == ('Test error',)
    assert exc.args[0] == 'Test error'
    e = get_exception()
    assert e.args == ('Test error',)
    assert e.args[0] == 'Test error'

# Generated at 2022-06-20 21:05:23.529454
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=unused-variable
    """Unit test for get_exception"""
    try:
        raise RuntimeError('Test exception')
    except:   # pylint: disable=bare-except
        e = get_exception()
        assert str(e) == 'Test exception'
        assert isinstance(e, RuntimeError)



# Generated at 2022-06-20 21:05:25.776784
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'test exception'


# Generated at 2022-06-20 21:05:29.763234
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'



# Generated at 2022-06-20 21:05:33.188418
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError as e:
        assert get_exception() == e


# Generated at 2022-06-20 21:05:38.035238
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.basic
    try:
        ansible.module_utils.basic.literal_eval('1+1')
    except Exception:
        e = get_exception()
    assert type(e) == ValueError

# Generated at 2022-06-20 21:05:41.635929
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("oops")
    except:
        e = get_exception()
        assert e.args[0] == 'oops'

# Generated at 2022-06-20 21:05:43.373381
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise RuntimeError("test exception")
        except Exception:
            e = get_exception()
            assert str(e) == "test exception"

    foo()


# Generated at 2022-06-20 21:05:54.331878
# Unit test for function get_exception
def test_get_exception():
    import pytest

    # pylint: disable=bare-except

    # Test when there isn't an exception though we should be able to get None
    assert get_exception() is None

    try:
        # Test when there is an exception
        try:
            raise ValueError('foo')
        except:
            exception = get_exception()
            assert exception is not None
            assert isinstance(exception, ValueError)
            assert str(exception) == 'foo'
    except:
        pytest.fail('Received an exception when none should be raised')
