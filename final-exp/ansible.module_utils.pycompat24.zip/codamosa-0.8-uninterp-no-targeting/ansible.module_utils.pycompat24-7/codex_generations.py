

# Generated at 2022-06-20 20:58:39.352122
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert str(e) == "foo"



# Generated at 2022-06-20 20:58:40.918249
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except ValueError:
        e = get_exception()
        assert str(e) == 'Test'

# Generated at 2022-06-20 20:58:43.358624
# Unit test for function get_exception
def test_get_exception():
    def do_raise(message):
        class CustomException(Exception):
            pass
        raise CustomException(message)

    try:
        do_raise('hello')
    except:
        e = get_exception()
        assert 'hello' in repr(e)


# Generated at 2022-06-20 20:58:46.199082
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('howdy')
    except RuntimeError as e:
        exc = get_exception()
    assert exc is e

# Generated at 2022-06-20 20:58:47.504085
# Unit test for function get_exception
def test_get_exception():
    import doctest

    doctest.testmod()

# Generated at 2022-06-20 20:58:50.928419
# Unit test for function get_exception
def test_get_exception():
    try:
        __import__('nonexistentmodule')
    except ImportError:
        exc = get_exception()
        assert isinstance(exc, ImportError)


# Generated at 2022-06-20 20:58:56.079692
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        e = get_exception()
    e1 = str(e)
    try:
        raise e
    except:
        e2 = str(get_exception())
    assert e1 == e2

# Generated at 2022-06-20 20:58:58.750414
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except Exception:
        e = get_exception()
        assert isinstance(e, MyException)

# Generated at 2022-06-20 20:59:02.218376
# Unit test for function get_exception
def test_get_exception():

    foo = 'bar'
    try:
        raise RuntimeError('Failed to do something')
    except:
        pass
    e = get_exception()
    assert e.args[0] == 'Failed to do something'

# Generated at 2022-06-20 20:59:05.392829
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-20 20:59:25.154942
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError:
        pass

    assert isinstance(get_exception(), NameError)

# Generated at 2022-06-20 20:59:29.994921
# Unit test for function get_exception
def test_get_exception():
    def foo():
        return get_exception()
    assert foo() is None
    try:
        raise Exception('This should catch')
    except Exception:
        assert str(foo()) == 'This should catch'
    assert foo() is None

# Generated at 2022-06-20 20:59:34.715973
# Unit test for function get_exception
def test_get_exception():
    """
    Executes the function get_exception()
    """
    try:
        1 / 0
        assert False
    except ZeroDivisionError:
        e = get_exception()
        pass
    assert str(e) == "integer division or modulo by zero"


# Generated at 2022-06-20 20:59:39.560910
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        ex = get_exception()
    assert ex.args[0] == 'test exception'
    assert isinstance(ex, ValueError)

# Generated at 2022-06-20 20:59:43.506849
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('blah')
    except Exception:
        (e) = get_exception()
        assert str(e) == 'blah'

# Generated at 2022-06-20 20:59:44.868950
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-20 20:59:45.958088
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-20 20:59:47.057090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        return get_exception()

# Generated at 2022-06-20 20:59:51.586848
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    try:
        raise Exception("test")
    except Exception:
        e = get_exception()
        assert str(e) == "test"

# Generated at 2022-06-20 20:59:56.293585
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test")
    except:
        e = get_exception()
        assert "Test" in str(e)

# Generated at 2022-06-20 21:00:34.521144
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        assert get_exception() is sys.exc_info()[1]
    try:
        raise ValueError('Test exception')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-20 21:00:39.253510
# Unit test for function get_exception
def test_get_exception():
    try:
        a=5/0
    except TypeError:
        e = get_exception()
        assert type(e) == ZeroDivisionError
    except ZeroDivisionError:
        e = get_exception()
        assert type(e) == ZeroDivisionError
    else:
        assert False, "Expected exception"

# Unit tests for function literal_eval

# Generated at 2022-06-20 21:00:42.270764
# Unit test for function get_exception
def test_get_exception():
    err_msg = "I'm an error"
    try:
        raise Exception(err_msg)
    except Exception:
        err = get_exception()
    assert err.args[0] == err_msg

# Generated at 2022-06-20 21:00:47.599555
# Unit test for function get_exception
def test_get_exception():
    try:
        # Trigger an exception
        test_dict = {}
        test_dict['test']
    except:
        # Get the exception
        e = get_exception()
    # Now make sure we got an exception
    assert e



# Generated at 2022-06-20 21:00:54.928235
# Unit test for function get_exception
def test_get_exception():

    def foo():
        print('foo')
        raise RuntimeError("Exception from foo")

    def bar():
        print('bar')
        foo()

    # Calling bar() will raise a RuntimeError as expected
    # Calling bar() will just return it's return value
    return_value = bar()

    # Now we can check the return value of bar()
    # It should be a RuntimeError
    if isinstance(return_value, RuntimeError):
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-20 21:00:57.820329
# Unit test for function get_exception
def test_get_exception():
    def foo(a):
        b = bar(a)
        return b * 2

    def bar(c):
        return c + 1

    try:
        foo('a')
    except TypeError as e:
        assert e == get_exception()

# Generated at 2022-06-20 21:01:01.370958
# Unit test for function get_exception
def test_get_exception():
    """
    Fire up various exceptions and then capture them to make sure all the data
    flow is correct.
    """
    try:
        raise Exception('Test Exception')
    except Exception:
        exc = get_exception()

    assert exc.__class__ is Exception
    assert str(exc) == 'Test Exception'



# Generated at 2022-06-20 21:01:06.783173
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
        assert e.__class__ == Exception, e.__class__
        assert e.args == (u'foobar',), repr(e.args)
        assert str(e) == 'foobar'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:01:09.442892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Testing 1 2 3")
    except Exception:
        result = get_exception()

    assert isinstance(result, Exception)
    assert str(result) == "Testing 1 2 3"


# Generated at 2022-06-20 21:01:12.035137
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("SomeValueError")
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ("SomeValueError",)


# Generated at 2022-06-20 21:01:47.382143
# Unit test for function get_exception
def test_get_exception():
    """Function to test get_exception"""
    try:
        int('not an int')
    except Exception:
        e = get_exception()
    assert str(e) == "invalid literal for int() with base 10: 'not an int'"

# Generated at 2022-06-20 21:01:50.784779
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-20 21:01:52.836914
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception!')
    except:
        newexception = get_exception()
    assert newexception.args[0] == 'Test exception!'

# Generated at 2022-06-20 21:01:55.847872
# Unit test for function get_exception
def test_get_exception():
    """Check that we are able to get the current exception"""
    try:
        raise Exception('Woot')
    except Exception:
        exc = get_exception()
    assert 'Woot' in str(exc)



# Generated at 2022-06-20 21:01:59.765459
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('whatever')
    except Exception:
        e = get_exception()

    assert str(e) == 'whatever'


# Generated at 2022-06-20 21:02:02.038245
# Unit test for function get_exception
def test_get_exception():
    '''Test code for function get_exception'''
    def inner_func():
        try:
            raise Exception('test exception')
        except Exception:
            return get_exception()

    assert 'test exception' in str(inner_func())


# Generated at 2022-06-20 21:02:03.713300
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:02:05.795916
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except:
        assert isinstance(get_exception(), TypeError)

# Generated at 2022-06-20 21:02:17.983489
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable,expression-not-assigned,pointless-string-statement

    # Test no exceptions
    try:
        e1 = get_exception()
        'should not get here'
    except AttributeError:
        pass

    # Test standard exception
    try:
        raise ValueError('test')
    except ValueError:
        e2 = get_exception()

    assert isinstance(e2, ValueError)
    assert 'test' in str(e2)  # pylint: disable=redundant-unittest-assert

    # Test SystemExit exception
    try:
        raise SystemExit(2)
    except SystemExit:
        e3 = get_exception()

    assert isinstance(e3, SystemExit)
    assert '2' in str(e3) 

# Generated at 2022-06-20 21:02:19.993098
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-20 21:03:00.924821
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    def dev_div_zero():
        e = 1
        f = 0
        g = e / f
        # pylint: enable=unused-variable
    try:
        dev_div_zero()
    except:
        maybe_exc = get_exception()

    if not isinstance(maybe_exc, ZeroDivisionError):
        raise AssertionError("get_exception() didn't return the exception")

# Generated at 2022-06-20 21:03:04.451387
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        if str(e) != 'Exception':
            raise AssertionError('Test for get_exception() failed!')

# Generated at 2022-06-20 21:03:07.589592
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()

    # make sure the original exception has the same type and message
    assert isinstance(e, ValueError)
    assert e.args == ('foo',)

# Generated at 2022-06-20 21:03:13.204705
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is my error message")
    except Exception:
        e = get_exception()
        if not isinstance(e, Exception):
            raise AssertionError("get_exception() should return an exception")



# Generated at 2022-06-20 21:03:17.459095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert type(e) == ValueError
    assert e.args == ('test',)


# Generated at 2022-06-20 21:03:20.624931
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is for test_get_exception')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'This is for test_get_exception'



# Generated at 2022-06-20 21:03:23.877533
# Unit test for function get_exception
def test_get_exception():
    exc = get_exception()
    assert exc is None

    try:
        1/0
    except Exception:
        exc = get_exception()

    assert isinstance(exc, ZeroDivisionError)
    assert exc.args == ('integer division or modulo by zero',)

# Generated at 2022-06-20 21:03:29.491721
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:36.284641
# Unit test for function get_exception
def test_get_exception():
    import pytest

    class CustomException(Exception):
        pass

    def f():
        try:
            raise CustomException('test')
        except Exception:
            e = get_exception()
            assert isinstance(e, CustomException)
            assert e.args == ('test',)

    f()

# Generated at 2022-06-20 21:03:40.869407
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(u'test')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert u'test' == e.message


# Generated at 2022-06-20 21:04:55.502338
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass


# Generated at 2022-06-20 21:04:56.453042
# Unit test for function get_exception
def test_get_exception():
    pass

# Generated at 2022-06-20 21:05:04.193050
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SyntaxError('some message')
    except SyntaxError:
        e = get_exception()
        assert e.args == ('some message',), e.args  # pylint: disable=no-member
        assert type(e) == SyntaxError
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert e.args == (), e.args  # pylint: disable=no-member
        assert type(e) == ValueError
    try:
        raise AssertionError('some message')
    except AssertionError:
        e = get_exception()
        assert e.args == ('some message',), e.args  # pylint: disable=no-member
        assert type(e) == AssertionError

# Generated at 2022-06-20 21:05:08.080000
# Unit test for function get_exception
def test_get_exception():

    # Test that get_exception works in general
    try:
        raise Exception("Test exception")
    except:
        assert str(get_exception()) == "Test exception"

# Generated at 2022-06-20 21:05:11.868392
# Unit test for function get_exception
def test_get_exception():
    def raises():
        raise RuntimeError('expected')
    try:
        raises()
    except RuntimeError:
        exc = get_exception()
    assert isinstance(exc, RuntimeError)
    assert str(exc) == 'expected'



# Generated at 2022-06-20 21:05:13.669788
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        e = get_exception()
        assert e.message == 'This is a test exception'

# Generated at 2022-06-20 21:05:17.971259
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hello')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'hello'

# Generated at 2022-06-20 21:05:21.414023
# Unit test for function get_exception
def test_get_exception():
    class UserException(Exception):
        pass
    def raise_exception():
        try:
            raise UserException
        except UserException:
            e = get_exception()
            return e
    e = raise_exception()
    assert isinstance(e, UserException)

# Unit tests for function literal_eval

# Generated at 2022-06-20 21:05:25.724743
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is a test exception')
    except Exception:
        e = get_exception()

    assert(e.message == 'this is a test exception')


# Generated at 2022-06-20 21:05:38.384584
# Unit test for function get_exception
def test_get_exception():
    # Suppress a warning about unused imports
    # pylint: disable=unused-import
    import pytest  # noqa

    def get_exception_helper():
        """Helper function to test get_exception()."""
        try:
            1/0  # pylint: disable=pointless-statement
        except ZeroDivisionError:
            e = get_exception()
            return e

    expected = ZeroDivisionError()
    actual = get_exception_helper()

    assert isinstance(actual, ZeroDivisionError)
    assert str(actual) == str(expected)


# pytest unit tests for function literal_eval

# Generated at 2022-06-20 21:07:05.445408
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception."""
    try:
        raise Exception('Test Exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test Exception'

# Generated at 2022-06-20 21:07:08.450893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 21:07:11.059018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        new_exc = get_exception()
        assert str(new_exc) == 'foo'

# Generated at 2022-06-20 21:07:15.672060
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('msg')
    except Exception as e:
        e = get_exception()
    assert type(e) == Exception
    assert str(e) == 'msg'



# Generated at 2022-06-20 21:07:20.119611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is a test')
    except:
        e = get_exception()
    assert e.message == 'this is a test'


# Generated at 2022-06-20 21:07:27.137130
# Unit test for function get_exception
def test_get_exception():

    def foo():
        raise ValueError()

    try:
        foo()
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e is sys.exc_info()[1]


# Generated at 2022-06-20 21:07:30.351447
# Unit test for function get_exception
def test_get_exception():
    def test_function():
        try:
            raise AssertionError('this should be the exception returned')
        except Exception:
            return get_exception()

    assert test_function().args[0] == 'this should be the exception returned'



# Generated at 2022-06-20 21:07:37.818611
# Unit test for function get_exception
def test_get_exception():
    # The following raises NameError for Python 3.x and UnboundLocalError for Python 2.x
    #pylint: disable=unused-variable
    try:
        s = t
    except Exception:
        e = get_exception()

    assert isinstance(e, NameError) or isinstance(e, UnboundLocalError)



# Generated at 2022-06-20 21:07:43.234158
# Unit test for function get_exception

# Generated at 2022-06-20 21:07:47.851116
# Unit test for function get_exception
def test_get_exception():
    try:
        print(f)
    except Exception:
        e = get_exception()
        assert e.args[0] == 'global name \'f\' is not defined'


if __name__ == '__main__':
    # Run the unit tests
    import pytest
    pytest.main([__file__])