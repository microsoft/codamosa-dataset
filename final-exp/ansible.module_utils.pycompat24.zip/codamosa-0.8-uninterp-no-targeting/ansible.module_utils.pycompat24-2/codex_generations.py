

# Generated at 2022-06-20 20:58:43.647604
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-20 20:58:47.029283
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Some exception")
    except Exception:
        exc1 = get_exception()
        assert exc1.args == ("Some exception",)


# Generated at 2022-06-20 20:58:50.884216
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        e = get_exception()

    assert(isinstance(e, ValueError))
    assert(e.args == ('test exception',))

# Generated at 2022-06-20 20:58:55.623545
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception('foo')
        except Exception:
            return get_exception()

    e = f()
    assert str(e) == 'foo'
    assert e.__class__ == Exception


# Generated at 2022-06-20 20:59:03.203275
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('caught exception')
    except Exception:
        assert str(get_exception()) == 'caught exception'
        assert repr(get_exception()) == 'Exception(\'caught exception\',)'
        assert isinstance(get_exception(), Exception)


# Generated at 2022-06-20 20:59:06.653010
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Hi')
    except ValueError:
        e = get_exception()
    assert 'Hi' in str(e)


# Generated at 2022-06-20 20:59:09.325457
# Unit test for function get_exception
def test_get_exception():
    def throws():
        try:
            raise RuntimeError('frob')
        except RuntimeError as e:
            return e

    try:
        throws()
    except RuntimeError as e:
        assert (e == get_exception())


# Generated at 2022-06-20 20:59:11.296568
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise RuntimeError('Test error')
    except:
        e = get_exception()
    assert e.args == ('Test error',)


# Generated at 2022-06-20 20:59:14.659269
# Unit test for function get_exception
def test_get_exception():
    class TestError(Exception):
        pass

    try:
        raise TestError("foo")
    except TestError:
        exc = get_exception()
        assert exc.message == "foo"



# Generated at 2022-06-20 20:59:29.584830
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys

    class MyException(Exception):
        '''Throwable test exception'''

        def __init__(self, value='somestring'):
            self.value = value

        def __str__(self):
            return repr(self.value)

    class GetExceptionTestCase(unittest.TestCase):
        def setUp(self):
            self.old_exc_info = sys.exc_info()

        def tearDown(self):
            sys.exc_info(*self.old_exc_info)

        def test_no_exception(self):
            self.assertEqual(None, get_exception())

        def test_exception(self):
            my_exception = MyException('somestring')

# Generated at 2022-06-20 20:59:40.102974
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        exc = get_exception()
    assert exc.__class__ is ZeroDivisionError
    assert exc.__str__() == 'integer division or modulo by zero'

# Generated at 2022-06-20 20:59:44.562986
# Unit test for function get_exception
def test_get_exception():
    # We'll expect this to succeed
    try:
        1/0
        print('Succeeded: 1/0 failed to raise an exception')
        sys.exit(1)
    except:
        assert get_exception() is not None
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 20:59:46.031414
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo bar')
    except:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args[0] == 'foo bar'



# Generated at 2022-06-20 20:59:48.345953
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "test"


# Generated at 2022-06-20 20:59:49.713039
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except:
        exception = get_exception()
    assert exception.args == ('test exception', )

# Generated at 2022-06-20 20:59:55.474850
# Unit test for function get_exception
def test_get_exception():
    def raise_(exception):
        raise exception
    try:
        raise_(RuntimeError('foo'))
    except RuntimeError:
        exc = get_exception()
        assert type(exc) is RuntimeError
        assert str(exc) == 'foo'

# Generated at 2022-06-20 20:59:58.658200
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u'foo')
    except Exception:
        e = get_exception()

    assert str(e) == 'foo'
    assert unicode(e) == u'foo'



# Generated at 2022-06-20 21:00:10.156346
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        exc = get_exception()
        expected = ZeroDivisionError('integer division or modulo by zero')

# Generated at 2022-06-20 21:00:13.697800
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is a test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'this is a test exception'



# Generated at 2022-06-20 21:00:16.869701
# Unit test for function get_exception
def test_get_exception():
    def func():
        raise RuntimeError('Some Message')

    try:
        func()
    except:
        the_exception = get_exception()
    assert isinstance(the_exception, RuntimeError)
    assert the_exception.message == 'Some Message'



# Generated at 2022-06-20 21:00:38.425432
# Unit test for function get_exception
def test_get_exception():
    # This code returns the equivalent of a traceback.print_stack() call
    # Useful to run in a debugger to see what's going on.
    import traceback
    exc_info = sys.exc_info()
    if exc_info is None:
        exc_info = sys.exc_info()
    traceback.print_exception(*exc_info)
    del exc_info

# Generated at 2022-06-20 21:00:41.664552
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
        assert str(e) == 'test exception'

# Generated at 2022-06-20 21:00:45.114540
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ('foo',)



# Generated at 2022-06-20 21:00:49.372776
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('An exception',)
    assert str(e) == 'An exception'

# Generated at 2022-06-20 21:00:53.893700
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'foo'


# Generated at 2022-06-20 21:00:55.449932
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-20 21:00:57.975420
# Unit test for function get_exception
def test_get_exception():
    """Test for function get_exception"""
    try:
        1/0
    except ZeroDivisionError as ex:
        assert ex == get_exception()


# Unit tests for literal_eval()

# Generated at 2022-06-20 21:01:00.338685
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception as e:
        exception = get_exception()
        assert e.args[0] == exception.args[0]


# Generated at 2022-06-20 21:01:09.992997
# Unit test for function get_exception
def test_get_exception():
    # I'd like to be able to call get_exception() inside of a try:except block
    # but I don't see a way to do it without writing a syntax error.  So, we
    # need to try it elsewhere.
    try:
        raise ValueError("get_exception test")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('get_exception test', )

# Generated at 2022-06-20 21:01:12.384615
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert e.__str__() == "test"
    assert str(e) == "test"


# Generated at 2022-06-20 21:01:50.013754
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'test exception'

# Generated at 2022-06-20 21:01:57.190560
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception'''

    try:
        raise ValueError()
    except Exception:
        get_exception()

    try:
        raise ValueError('a')
    except Exception:
        val = get_exception()
    assert val.args == ('a',)

    try:
        raise ValueError('a', 'b')
    except Exception:
        val = get_exception()
    assert val.args == ('a', 'b')



# Generated at 2022-06-20 21:02:00.588445
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except MyException:
        exc = get_exception()
        assert isinstance(exc, MyException)
    else:
        assert False, 'Expected exception not raised'

# Generated at 2022-06-20 21:02:02.305110
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()

    assert True == isinstance(e, Exception)


# Generated at 2022-06-20 21:02:08.684587
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
        assert e.__class__.__name__ == 'Exception'
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert str(e) == ''
        assert e.__class__.__name__ == 'Exception'



# Generated at 2022-06-20 21:02:13.360777
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing get_exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Testing get_exception', 'get_exception did not return the raised exception'


# Generated at 2022-06-20 21:02:16.090076
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
    assert str(exc) == 'foo'



# Generated at 2022-06-20 21:02:20.405290
# Unit test for function get_exception
def test_get_exception():
    try:
        int('asdf')
    except:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError()
    else:
        raise AssertionError()

# Generated at 2022-06-20 21:02:23.903371
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'this is a test'

# Generated at 2022-06-20 21:02:27.552302
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        got = get_exception()
        assert type(got) is ZeroDivisionError

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 21:03:40.347165
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        print(type(e), str(e))

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:03:43.661895
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except:
        e = get_exception()
        assert e.args
        assert 'test_get_exception' in str(e)
        assert repr(e)


# Generated at 2022-06-20 21:03:46.662822
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert get_exception().args[0] == 'integer division or modulo by zero'



# Generated at 2022-06-20 21:03:51.318926
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('Test')
    except Exception:
        result = get_exception()

    assert isinstance(result, MyException)
    assert str(result) == 'Test'

# Generated at 2022-06-20 21:03:57.009019
# Unit test for function get_exception
def test_get_exception():
    # This should always work no matter what.
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)

    # This is the python 2.4 way of catching Exceptions

# Generated at 2022-06-20 21:04:04.556686
# Unit test for function get_exception
def test_get_exception():
    error_raised = False
    err = None
    try:
        raise Exception('Not an error')
    except Exception:
        error_raised = True
        err = get_exception()
    assert error_raised, "An exception should have been raised"
    assert err, "get_exception should have returned something"
    assert isinstance(err, Exception), "The return from get_exception should be an exception"
    assert err.args[0] == "Not an error", 'args should be preserved'

# Generated at 2022-06-20 21:04:07.558369
# Unit test for function get_exception
def test_get_exception():
    try:
        open('foo')
    except Exception:
        e = get_exception()
        assert type(e) == IOError

# Generated at 2022-06-20 21:04:20.597495
# Unit test for function get_exception
def test_get_exception():
#pylint: disable=protected-access
    import unittest

    class A(object):
        def __init__(self):
            self.x = 5

        def __eq__(self, other):
            return self.x == other.x

    class TestGetException(unittest.TestCase):
        def test_exception_status(self):
            try:
                raise Exception('TestException')
            except Exception:
                test_exception = get_exception()
            self.assertIsInstance(test_exception, Exception)

        def test_exception_value(self):
            try:
                raise Exception('TestException')
            except Exception:
                test_exception = get_exception()
            self.assertEqual(test_exception.args[0], 'TestException')


# Generated at 2022-06-20 21:04:24.299959
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-20 21:04:28.378759
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('test')
    except NameError:
        e = get_exception()
    assert e.args[0] == 'test'

# Generated at 2022-06-20 21:07:22.572607
# Unit test for function get_exception
def test_get_exception():
    """Confirm we're getting an exception out"""
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
        if str(e) != 'Test':
            raise AssertionError('Get exception did not return the passed in exception')

# Generated at 2022-06-20 21:07:26.896658
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('My exception to raise')
    except ValueError as e:
        pass

    exception = get_exception()

    if e is not exception:
        raise AssertionError('get_exception() did not return the exception that we raised')

# Generated at 2022-06-20 21:07:28.764890
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Error!")
    except:
        e = get_exception()
        assert e is not None
        assert str(e) == "Error!"

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-20 21:07:31.244097
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('HiThere')
    except:
        exc = get_exception()
        assert isinstance(exc, NameError)
        assert exc.args == ('HiThere',)

# Generated at 2022-06-20 21:07:44.595750
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except:
        # Python 2.4 compatible way to check that we caught the right exception
        assert isinstance(get_exception(), RuntimeError)
        assert isinstance(get_exception(), Exception)
        assert str(get_exception()) == 'test exception'

    try:
        raise ValueError('test exception')
    except:
        # Python 2.4 compatible way to check that we caught the right exception
        assert isinstance(get_exception(), ValueError)
        assert isinstance(get_exception(), Exception)
        assert str(get_exception()) == 'test exception'

# Generated at 2022-06-20 21:07:48.295595
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works and returns the current exception"""
    try:
        raise Exception('Current Exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Current Exception', 'Unable to fetch the current exception: %s' % e

# Generated at 2022-06-20 21:07:54.648742
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a fake exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args[0] == 'This is a fake exception'

# Generated at 2022-06-20 21:07:55.659229
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-20 21:07:59.140582
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert str(e) == "foo"

# Generated at 2022-06-20 21:08:03.601745
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except: # pylint: disable=bare-except
        e = get_exception()
    assert str(e) == "Test exception"