

# Generated at 2022-06-20 20:58:41.937866
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except ValueError:
        e = get_exception()
    assert str(e) == 'testing'
    assert type(e) == ValueError


# Generated at 2022-06-20 20:58:46.287549
# Unit test for function get_exception
def test_get_exception():
    try:
        print(token)
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError)
        assert isinstance(e.args, tuple)
        assert len(e.args) >= 1
        assert isinstance(e.args[0], str)

# Generated at 2022-06-20 20:58:49.601773
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 20:58:55.324530
# Unit test for function get_exception
def test_get_exception():
    """get_exception() should return the active exception
    """
    def div(n, d):
        return n/d

    try:
        div(1, 0)
    except ZeroDivisionError:
        e = get_exception()

    assert ZeroDivisionError == e.__class__



# Generated at 2022-06-20 20:58:57.776908
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        exc = get_exception()
    assert isinstance(exc, ValueError)


# Generated at 2022-06-20 20:59:00.926812
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'

# Generated at 2022-06-20 20:59:09.174904
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        e = get_exception()
        assert e.args == ('Test exception',)
        assert str(e) == 'Test exception'

if __name__ == '__main__':
    for func in __all__:
        if func.startswith('test_'):
            print("%s:" % func)
            try:
                globals()[func]()
                print("  ok")
            except Exception: # pylint: disable=broad-except
                import traceback
                traceback.print_exc()
                print("  ERROR")

# Generated at 2022-06-20 20:59:11.818668
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError()
    except TypeError:
        pass
    assert get_exception() is not None

# Generated at 2022-06-20 20:59:15.355565
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as exc:
        assert get_exception() == exc
    try:
        raise ValueError('foo')
    except ValueError:
        assert get_exception().args[0] == 'foo'



# Generated at 2022-06-20 20:59:19.725190
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except:
        result = get_exception()
        assert isinstance(result, TestException)




# Generated at 2022-06-20 20:59:41.961567
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e == get_exception()
    try:
        1/0
    except ZeroDivisionError as e:
        assert e == get_exception()

# Generated at 2022-06-20 20:59:47.160121
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()
    else:
        assert False, 'Exception not raised'

__all__ = ('get_exception', 'literal_eval')

# Generated at 2022-06-20 20:59:49.916415
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'

# Generated at 2022-06-20 20:59:54.497496
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Oops')
    except TypeError:
        assert get_exception().args[0] == 'Oops'



# Generated at 2022-06-20 20:59:58.409610
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is the error")
    except Exception:
        e = get_exception()
        assert e.args == ('This is the error',), e.args

# Generated at 2022-06-20 21:00:04.875727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        if get_exception() is not e:
            raise AssertionError("e is not get_exception()")
    else:
        raise AssertionError("ValueError not raised")


# Generated at 2022-06-20 21:00:08.894673
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("oops")
    except ValueError:
        e = get_exception()
        assert(e.args[0] == "oops")

# Generated at 2022-06-20 21:00:12.090464
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException
    except Exception:
        e = get_exception()
        assert isinstance(e, TestException)

# Generated at 2022-06-20 21:00:15.319575
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise Exception
        except Exception:
            e = get_exception()
            assert e is not None
            raise
    try:
        foo()
    except:
        e = get_exception()
        assert e is not None


# Generated at 2022-06-20 21:00:20.817701
# Unit test for function get_exception
def test_get_exception():
    """
    unit test for function get_exception, test if function can get exception
    """
    try:
        raise Exception("blah blah blah")
    except Exception:
        e = get_exception()
        assert e.message == 'blah blah blah'

# Generated at 2022-06-20 21:00:57.300288
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except Exception:
        e = get_exception()

    assert str(e) == 'integer division or modulo by zero'



# Generated at 2022-06-20 21:01:01.862802
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "Test exception"

# Generated at 2022-06-20 21:01:05.903965
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-20 21:01:10.535195
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=no-self-use
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert(str(e) == 'foo')
        return

# Generated at 2022-06-20 21:01:16.977184
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == "integer division or modulo by zero"


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:01:20.034387
# Unit test for function get_exception
def test_get_exception():
    try:
        [][5]
    except IndexError as e:
        assert get_exception() == e
    else:
        assert False, "Shouldn't get here"

# Generated at 2022-06-20 21:01:22.221497
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        assert get_exception().args[0] == "foo"

# Generated at 2022-06-20 21:01:25.760763
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        exc = get_exception()
        assert exc.args == ('foo', )
        assert exc.__str__() == 'foo'

# Generated at 2022-06-20 21:01:39.617315
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import ansible.module_utils.six

    class TestException(Exception):
        pass

    class GetExceptionTester(unittest.TestCase):

        def test_get_exception(self):
            '''
            get_exception() retrieves the current exception (if any) or raises an exception
            if no exception is being handled.
            '''
            if ansible.module_utils.six.PY3:
                # py3's pyunit raises the exception
                self.assertRaises(AssertionError, get_exception)
            else:
                # py2's pyunit doesn't reraise an exception
                self.assertRaises(AssertionError, get_exception)

            try:
                raise TestException('testing')
            except:  # noqa
                e = get_ex

# Generated at 2022-06-20 21:01:44.811941
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise Exception('bar')
        except Exception:
            e = get_exception()
            return e
    e = foo()
    assert e.args[0] == 'bar'

# Generated at 2022-06-20 21:02:57.863237
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert text_type(e) == 'foobar'

# Generated at 2022-06-20 21:03:01.948115
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-20 21:03:17.177067
# Unit test for function get_exception
def test_get_exception():
    # Test where an exception is triggered
    try:
        raise ValueError('test exception')
    except ValueError as e:
        ret = get_exception()
    print(type(ret))
    print(ret)
    assert ret == e
    assert type(ret) == type(e)
    assert ret.args[0] == e.args[0]

    # Test where there isn't an exception
    def increment(num):
        return num + 1
    ret = increment(5)
    print(ret)
    assert ret == 6

    ret = get_exception()
    print(ret)
    assert ret is None

    # Test that the function runs when imported using 'import *'
    ret = get_exception_test
    print(ret)
    assert ret is get_exception_test

    # Test that the function

# Generated at 2022-06-20 21:03:23.767222
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except Exception:
        # Python 2.4 raises ValueError directly, while 2.5 and 2.6 raise
        # RuntimeError: maximum recursion depth exceeded while calling a Python
        # object
        exc = get_exception()
        assert 'testing' in str(exc)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:03:29.024031
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Testing get_exception()")
    except Exception as e:
        if get_exception() is not e:
            raise Exception("get_exception did not return the current exception")


# Generated at 2022-06-20 21:03:42.093644
# Unit test for function get_exception
def test_get_exception():
    def throw_exception(exception_type):
        if exception_type == 'Exception':
            raise Exception()
        elif exception_type == 'AssertionError':
            assert False

    # Test that a regular Exception is handled properly
    try:
        throw_exception('Exception')
        assert False
    except Exception:
        e = get_exception()
        assert type(e) is Exception

    # Test that an AssertionError is handled properly even though it's a subclass
    # of Exception
    try:
        throw_exception('AssertionError')
        assert False
    except Exception:
        e = get_exception()
        assert type(e) is AssertionError



# Generated at 2022-06-20 21:03:45.601286
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise ValueError('foo')
    except:
        ex = get_exception()
    assert isinstance(ex, ValueError)
    assert str(ex) == 'foo'

# Generated at 2022-06-20 21:03:49.982450
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('an error')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'an error'

# Generated at 2022-06-20 21:03:57.765231
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        1/0

    try:
        test_func()
    except:
        exception = get_exception()

    assert isinstance(exception, ZeroDivisionError)


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(
        argument_spec=dict(
            value=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )
    try:
        value = literal_eval(m.params['value'])
        m.exit_json(changed=True, value=value)
    except ValueError as e:
        m.fail_json(msg=str(e))

# Generated at 2022-06-20 21:04:00.894975
# Unit test for function get_exception
def test_get_exception():
    # Test that it works for all versions of python
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
        assert(str(e) == 'test')

# Generated at 2022-06-20 21:06:50.490254
# Unit test for function get_exception
def test_get_exception():
    ''' test_get_exception: ensure get_exception pulls the current exception.'''
    try:
        1/0
    except:
        e = get_exception()
    assert type(e)==ZeroDivisionError, 'Exception %s(%s) is not ZeroDivisionError' % (e.__class__.__name__, e)


# Generated at 2022-06-20 21:06:55.024581
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'foo'


# Generated at 2022-06-20 21:07:05.136241
# Unit test for function get_exception
def test_get_exception():
    # Normal use-case
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'This is an exception'

    # No exception raised
    e = get_exception()
    assert e is None

    # No exception type specified
    try:
        raise
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert e is None

# Generated at 2022-06-20 21:07:12.964257
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(exc):
        raise exc  # pylint: disable=misplaced-bare-raise
    try:
        raise_exception(Exception('1'))
    except:
        assert get_exception().args[0] == '1'
    try:
        raise_exception(Exception(('2','a','b', 1, 5, [1,2,3])))
    except:
        assert get_exception().args[0][3] == 1

# Unit tests for function literal_eval

# Generated at 2022-06-20 21:07:17.159309
# Unit test for function get_exception
def test_get_exception():
    class E(Exception):
        pass

    try:
        raise E('msg')
    except Exception:
        e = get_exception()
    assert isinstance(e, E)
    assert e.args == ('msg',)

# Generated at 2022-06-20 21:07:22.042381
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=missing-docstring
    try:
        raise ValueError('test')
    except ValueError:
        error = get_exception()
        assert error.args == ('test',)

# Generated at 2022-06-20 21:07:26.257853
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'foo'
    assert repr(exc) == 'Exception(\'foo\',)'

# Generated at 2022-06-20 21:07:28.138397
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError('Fake error')
    except AttributeError as e:
        assert e is get_exception()

# Generated at 2022-06-20 21:07:31.276893
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name
    assert get_exception() is None
    try:
        1/0
    except:
        exc = get_exception()
    assert exc is not None
    # pylint: enable=invalid-name


# Generated at 2022-06-20 21:07:35.687950
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is an error')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'This is an error'