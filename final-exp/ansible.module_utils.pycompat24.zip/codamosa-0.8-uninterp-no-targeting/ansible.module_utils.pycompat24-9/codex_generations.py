

# Generated at 2022-06-20 20:58:40.804814
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        bar = get_exception()
    assert bar.args[0] == "foo"

# Generated at 2022-06-20 20:58:44.040830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert str(e) == "Test exception", "Incorrect exception text: %s" % str(e)

# Generated at 2022-06-20 20:58:46.243878
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-20 20:58:57.735956
# Unit test for function get_exception
def test_get_exception():
    x = 42
    try:
        try:
            raise ValueError
        except:
            e1 = get_exception()

        try:
            raise TypeError
        except:
            e2 = get_exception()
    except:
        e3 = get_exception()

    if ValueError != e1:
        print("AssertionError: e1 doesn't match ValueError")
        sys.exit(1)
    elif TypeError != e2:
        print("AssertionError: e2 doesn't match TypeError")
        sys.exit(1)
    elif NameError != e3:
        print("AssertionError: e3 doesn't match NameError")
        sys.exit(1)



# Generated at 2022-06-20 20:59:01.850158
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        e = get_exception()
    assert e.args == ('This is a test exception',)
    assert e.__class__ == ValueError


# Generated at 2022-06-20 20:59:05.968847
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Testing get_exception")
    except Exception:
        e = get_exception()
    assert "Testing get_exception" in str(e), "%s does not contain 'Testing get_exception'" % str(e)

# Generated at 2022-06-20 20:59:09.417684
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test!")
    except RuntimeError:
        e = get_exception()
    assert("This is a test!" == str(e))



# Generated at 2022-06-20 20:59:12.528805
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        foo = e
        found = get_exception()
        assert foo is found

# Generated at 2022-06-20 20:59:22.883166
# Unit test for function get_exception
def test_get_exception():
    def raise_ex(e):
        raise e

    try:
        raise_ex(RuntimeError('test'))
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError), 'get_exception() did not return an Exception'
        assert str(e) == 'test', 'get_exception() did not return an Exception with the correct message'

    try:
        raise_ex(Exception('test'))
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception), 'get_exception() did not return an Exception'
        assert str(e) == 'test', 'get_exception() did not return an Exception with the correct message'

# Unit tests for function literal_eval

# Generated at 2022-06-20 20:59:29.610203
# Unit test for function get_exception
def test_get_exception():

    def helper(func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception:
            return get_exception()
        else:
            return False

    assert helper(int, 'asdf')
    assert helper(int, 'asdf', base=2)
    assert helper(dict)
    assert helper(test_get_exception)

# Generated at 2022-06-20 20:59:48.270382
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exc = get_exception()
    assert isinstance(exc, ZeroDivisionError)



# Generated at 2022-06-20 20:59:49.857182
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # pylint: disable=pointless-statement
    except Exception:
        assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-20 20:59:55.117920
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is a test')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'this is a test'


# Generated at 2022-06-20 20:59:57.940670
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert str(e) == 'foo'



# Generated at 2022-06-20 21:00:00.476306
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Testing get_exception")
    except ValueError:
        assert ValueError("Testing get_exception") == get_exception()

# Generated at 2022-06-20 21:00:07.008006
# Unit test for function get_exception
def test_get_exception():
    """Test that we are really getting the exception out of the current scope the
    way we think we are"""
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        exc = get_exception()
        assert exc.args == ('This is a test exception',)
    try:
        raise ValueError('This is another test exception', 'With multiple args')
    except ValueError:
        exc = get_exception()
        assert exc.args == ('This is another test exception', 'With multiple args')


# Generated at 2022-06-20 21:00:12.091440
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('fake exception')
    except ValueError as e:
        assert(get_exception() is e)
        # This is the expected path
        return
    raise AssertionError('ValueError exception was not raised')



# Generated at 2022-06-20 21:00:16.476970
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test error')
    except ValueError as e:
        if get_exception() != e:
            print("get_exception() != e")
    except Exception:
        print("Should have excepted on a ValueError")
    else:
        print("Should have excepted on a ValueError")



# Generated at 2022-06-20 21:00:18.546770
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 21:00:22.365168
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An exception')
    except ValueError:
        e = get_exception()
        print(e)
        assert e == 'An exception'

# Generated at 2022-06-20 21:00:57.664167
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
        assert e.__class__ == TypeError
        assert isinstance(e, TypeError)



# Generated at 2022-06-20 21:01:00.064376
# Unit test for function get_exception
def test_get_exception():
    def testfunc():
        raise RuntimeError('foo')

    try:
        testfunc()
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:01:06.063348
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=no-init,unused-argument
    class TestException(Exception):
        pass

    try:
        raise TestException
    except TestException:
        e = get_exception()

    assert e is not None
    assert isinstance(e, TestException)

# Generated at 2022-06-20 21:01:10.073462
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)

# Unit tests for function literal_eval

# Generated at 2022-06-20 21:01:18.625096
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('one')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'one'
        try:
            raise ValueError('two') from get_exception()
        except ValueError as e2:
            assert str(e2) == 'two'
            assert str(getattr(e2, '__cause__', None)) == 'one'
            assert getattr(e2, '__suppress_context__', None) is True
        else:
            raise AssertionError('Did not raise')

# Generated at 2022-06-20 21:01:23.331108
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('error message')
    except:
        e = get_exception()
    assert str(e) == 'error message'

if __name__ == '__main__':
    sys.exit(test_get_exception())

# Generated at 2022-06-20 21:01:26.771228
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    try:
        raise ValueError('Something happened')
    except Exception:
        e = get_exception()
        assert e.args == ('Something happened', )



# Generated at 2022-06-20 21:01:31.807108
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a message')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'This is a message'



# Generated at 2022-06-20 21:01:38.359605
# Unit test for function get_exception
def test_get_exception():
    # Verify that get_exception works on both types of exceptions
    try:
        raise Exception('Foo')
    except:
        exc = get_exception()
    assert str(exc) == 'Foo'

    try:
        raise OSError('Bar')
    except:
        exc = get_exception()
    assert str(exc) == 'Bar'


# Generated at 2022-06-20 21:01:50.187948
# Unit test for function get_exception
def test_get_exception():
    failed = False
    name = 'supercalifragilisticexpialidocious'

    # Python3 uses 'NameError' as the class name for exception objects
    # Python2 uses 'name 'NameError' as the class name for exception objects
    name_error_class = NameError.__name__
    name_error_class2 = name_error_class + ' ' + name_error_class

    try:
        print(name)
        failed = True
    except NameError as e:
        actual = e.__class__.__name__
        if actual != name_error_class:
            print('Unit test for get_exception: Name of exception in except clause has incorrect value (%s) [expected: %s]' % (actual, name_error_class))
            failed = True
        e2 = get_exception()
        actual

# Generated at 2022-06-20 21:03:02.850896
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        exception = get_exception()

    assert isinstance(exception, ValueError)
    assert str(exception) == 'test exception', 'exception passed to get_exception is not the exception that was originally raised'

# Generated at 2022-06-20 21:03:07.506611
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        raise Exception('message')
    try:
        raise_exc()
    except:
        assert get_exception().args[0] == 'message'



# Generated at 2022-06-20 21:03:14.400900
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception: # pylint: disable=broad-except
        exc = get_exception()

    assert type(exc) == Exception
    if sys.version_info < (3,):
        assert type(exc[0]) == str
    else:
        assert type(exc[0]) == bytes
    assert type(exc[1]) == Exception
    assert exc[2] is None or type(exc[2]) == tuple

# Generated at 2022-06-20 21:03:16.331286
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:19.460430
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        pass
    assert str(get_exception()) == 'test'

# Generated at 2022-06-20 21:03:21.168232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        assert get_exception().args[0] == 'foobar'

# Generated at 2022-06-20 21:03:23.767607
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "test"

# Generated at 2022-06-20 21:03:35.138934
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring,unused-variable,invalid-name

    # This is not a complete unit test, but we're somewhat limited in what we
    # can do here.

    # Failures with syntax errors are not caught and are raised at the top
    # level
    try:
        try:
            raise SyntaxError()
        except Exception:
            e = get_exception()

        assert(isinstance(e, SyntaxError))
    except SyntaxError:
        pass
    else:
        assert(False)

    # Re-raising exceptions is caught
    try:
        try:
            raise SyntaxError()
        except Exception:
            raise
    except Exception:
        e = get_exception()

    assert(isinstance(e, SyntaxError))

    # Failing to get the exception

# Generated at 2022-06-20 21:03:44.948169
# Unit test for function get_exception
def test_get_exception():
    ''' Verify that get_exception() works correctly '''
    exception = None
    try:
        raise Exception('Test exception')
    except Exception:
        exception = get_exception()

    assert exception is not None
    assert str(exception) == 'Test exception'
    assert type(exception) == Exception

try:
    from ansible.module_utils.six import PY3
except ImportError:
    PY3 = sys.version_info[0] == 3

if PY3:
    import builtins
else:
    import __builtin__ as builtins


# Generated at 2022-06-20 21:03:55.955393
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError:
        exc_info_top = sys.exc_info()
        exc_info_other = sys.exc_info()
        assert exc_info_top == exc_info_other  # pylint: disable=no-member
        assert exc_info_top[2] == exc_info_other[2]
        assert exc_info_top[1] == exc_info_other[1]
        assert exc_info_top[0] == exc_info_other[0]
        assert exc_info_top is exc_info_other  # pylint: disable=no-member
        assert exc_info_top[0] == NameError
        assert exc_info_top[1] is None
        assert exc_info_top[2] is None
        e = get_ex

# Generated at 2022-06-20 21:06:40.978263
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=too-many-branches
    try:
        raise RuntimeError('Test error')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)
        assert exc.message == 'Test error'

    # Doesn't work on python 2.4, _asynci0 is not defined
    #try:
    #    __import__('__asynci0')
    #except Exception:
    #    exc = get_exception()
    #    assert isinstance(exc, ImportError)
    #    assert exc.message == "No module named __asynci0"

# Generated at 2022-06-20 21:06:47.221238
# Unit test for function get_exception
def test_get_exception():
    """
    Test that the get_exception function is getting the exception
    """
    try:
        raise ValueError('This is a test')
    except Exception: # pylint: disable=W0703
        e = get_exception()
        assert e.args[0] == 'This is a test'
        assert isinstance(e, ValueError)
        return
    assert False, "This should never be reached"

if __name__ == "__main__":
    pytest.main([os.path.basename(__file__), "-v"])

# Generated at 2022-06-20 21:06:53.574325
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        got_exc = get_exception()
    except:
        assert False, "get_exception() didn't get our exception"
    assert got_exc, "get_exception() didn't return an exception"
    assert got_exc.args[0] == 'foo', "get_exception() didn't return the right exception"

# Generated at 2022-06-20 21:07:07.109038
# Unit test for function get_exception
def test_get_exception():
    try:
        # setup exception
        sys.modules['module'] = module = type(sys)('module')
        module.version = '1.23'
        del sys.modules['module']
        raise ValueError(
            'this is a really long exception message to trick the wrapper into '
            'shortening things at the wrong place.  It should be wrapped at '
            'around seventy characters but do it in the middle of a word so '
            'that we make sure the wrapping works properly'
        )
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        formatted_lines = str(e).splitlines()
        assert len(formatted_lines) == 1, formatted_lines


# Generated at 2022-06-20 21:07:10.539517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        ex = get_exception()
    assert ex is sys.exc_info()[1]



# Generated at 2022-06-20 21:07:17.922502
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError)
        # Try to suppress the original stacktrace
        try:
            raise NameError
        except NameError:
            e = get_exception()
            assert isinstance(e, NameError)

# Generated at 2022-06-20 21:07:21.331000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is the error')
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert 'this is the error' in str(e)



# Generated at 2022-06-20 21:07:25.892032
# Unit test for function get_exception
def test_get_exception():
    import os
    try:
        # This module exists, no exception
        __import__('os')

        e = get_exception()
        assert e is None
    except:
        # Modules that don't exist throw exception
        __import__('this_module_doesnt_exist')

        e = get_exception()
        assert isinstance(e, ImportError)



# Generated at 2022-06-20 21:07:28.804985
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('Test exception')
    except TestException:
        e = get_exception()
        assert str(e) == 'Test exception'
        assert isinstance(e, TestException)

# Generated at 2022-06-20 21:07:32.299084
# Unit test for function get_exception
def test_get_exception():
    def _test(exception_type):
        try:
            raise exception_type('Testing')
        except exception_type:
            return get_exception()

    assert isinstance(_test(ValueError), ValueError)
    assert isinstance(_test(SyntaxError), SyntaxError)
    assert isinstance(_test(IndexError), IndexError)