

# Generated at 2022-06-20 20:58:36.597645
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'
        assert e.args == ('Test exception',)
        assert type(e) is RuntimeError



# Generated at 2022-06-20 20:58:39.178251
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('This is a test exception')
    except TypeError:
        e = get_exception()
    assert str(e) == 'This is a test exception'

# Generated at 2022-06-20 20:58:42.205146
# Unit test for function get_exception
def test_get_exception():
    """Make sure that get_exception works"""
    class ExceptionTest(Exception):
        pass

    try:
        raise ExceptionTest("Test message")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, ExceptionTest), "get_exception didn't retrieve the exception: %s" % exc


# Generated at 2022-06-20 20:58:45.962766
# Unit test for function get_exception
def test_get_exception():
    try:
        foo
    except:
        assert get_exception() is sys.exc_info()[1]

    try:
        raise RuntimeError()
    except:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 20:58:50.305866
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        ex = get_exception()
        if not isinstance(ex, Exception):
            raise AssertionError('get_exception() should have returned the exception instance, got %r instead' % ex)

# Generated at 2022-06-20 20:58:53.505232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
    assert isinstance(e, Exception)

# Generated at 2022-06-20 20:58:58.400822
# Unit test for function get_exception
def test_get_exception():
    """Test for function get_exception"""
    try:
        raise Exception('A test exception')
    except Exception:
        e = get_exception()
        assert e.args == ('A test exception',)
    try:
        raise Exception('Another test exception')
    except Exception:
        e = get_exception()
        assert e.args == ('Another test exception',)

# Generated at 2022-06-20 20:59:02.452950
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NotImplementedError
    except NotImplementedError:
        e = get_exception()
    if not isinstance(e, NotImplementedError):
        raise AssertionError("Didn't get the exception back: %r" % e)



# Generated at 2022-06-20 20:59:05.897320
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)


# Generated at 2022-06-20 20:59:08.681885
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import reraise
    try:
        raise Exception('this is my exceptional exception')
    except Exception:
        e = get_exception()
        reraise(type(e), e, sys.exc_info()[2])

# Generated at 2022-06-20 20:59:22.726268
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise ValueError('foo')
        except ValueError:
            return get_exception()
    e = raise_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'



# Generated at 2022-06-20 20:59:26.075957
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        assert get_exception() == e


# Generated at 2022-06-20 20:59:28.300274
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError as e:
        assert e == get_exception()

# Generated at 2022-06-20 20:59:32.952820
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-variable
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-20 20:59:35.805039
# Unit test for function get_exception
def test_get_exception():
    class GetExceptionTestException(Exception):
        pass
    try:
        raise GetExceptionTestException()
    except:
        e = get_exception()
        assert isinstance(e, GetExceptionTestException)


# Generated at 2022-06-20 20:59:40.718874
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except Exception:
        e = get_exception()
    assert type(e) == MyException



# Generated at 2022-06-20 20:59:44.697561
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-20 20:59:48.617800
# Unit test for function get_exception
def test_get_exception():
    import traceback
    try:
        raise ValueError('testing')
    except:
        e = get_exception()
    assert e.args == ('testing', )



# Generated at 2022-06-20 20:59:53.051840
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('Gah!')
    except:
        e = get_exception()
    assert e.args[0] == 'Gah!'
    assert e.__class__ is NameError



# Generated at 2022-06-20 20:59:55.340548
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except:
        e = get_exception()
    assert "Test Exception" in e.args



# Generated at 2022-06-20 21:00:15.221582
# Unit test for function get_exception
def test_get_exception():
    def divzero():
        return 1/0

    try:
        divzero()
    except Exception:
        e = get_exception()
        assert 'ZeroDivisionError' in repr(e)



# Generated at 2022-06-20 21:00:18.370072
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hello')
    except ValueError:
        e = get_exception()
    assert str(e) == 'hello'

# Generated at 2022-06-20 21:00:20.256813
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is an error')
    except ValueError as exc:
        exc2 = get_exception()

    assert exc is exc2


# Generated at 2022-06-20 21:00:23.277808
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Testing exception'
    assert e.__class__ == RuntimeError
    assert isinstance(e, RuntimeError)


# Generated at 2022-06-20 21:00:28.827271
# Unit test for function get_exception
def test_get_exception():
    """Test that we can get an exception"""
    try:
        raise RuntimeError("Test Message")
    except Exception:
        err = get_exception()
        assert err.__class__.__name__ == "RuntimeError"
        assert str(err) == "Test Message"

# unit test for function literal_eval

# Generated at 2022-06-20 21:00:33.708258
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('%s' % 'foo')
    except Exception as e:
        e_type, e_value, e_traceback = sys.exc_info()
        assert e is e_value
        assert e_value is get_exception()

# Generated at 2022-06-20 21:00:39.442926
# Unit test for function get_exception
def test_get_exception():
    def gen1():
        try:
            raise IOError()
        except IOError:
            return get_exception()


# Generated at 2022-06-20 21:00:42.101561
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)


# unit test for function literal_eval

# Generated at 2022-06-20 21:00:45.609338
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)



# Generated at 2022-06-20 21:00:48.893911
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('the message')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'the message'

# Generated at 2022-06-20 21:01:10.306385
# Unit test for function get_exception
def test_get_exception():
    class Foo(Exception):
        pass

    try:
        raise Foo('bar')
    except:
        e = get_exception()
    assert isinstance(e, Foo)
    assert str(e) == 'bar'


# Generated at 2022-06-20 21:01:15.246575
# Unit test for function get_exception
def test_get_exception():
    # http://stackoverflow.com/a/13151299
    try:
        1 / 0
    except:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 21:01:17.713702
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is the exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'This is the exception'


# Generated at 2022-06-20 21:01:20.559948
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        assert str(get_exception()) == 'test exception'



# Generated at 2022-06-20 21:01:24.903701
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Some error')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == 'Some error'

# Generated at 2022-06-20 21:01:39.491608
# Unit test for function get_exception
def test_get_exception():
    # Check that it works on a variety of exceptions
    def raise_exception(e):
        '''A function that takes a single arg and raises it as an exception'''
        raise e
    # If a string is passed in, it should raise a TypeError
    try:
        raise_exception('blah')
    except Exception as e:
        assert type(e) == TypeError
        assert e.args == ('blah',)

    # If a non-exception object is passed in, it should raise a TypeError
    # with the message 'exceptions must be old-style classes or derived from BaseException, not str'
    try:
        raise_exception(['blah'])
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-20 21:01:43.549780
# Unit test for function get_exception
def test_get_exception():
    try:
        foo = 1 / 0
    except Exception as e:
        assert e == get_exception()
    else:
        raise AssertionError('Should not get here')


# Generated at 2022-06-20 21:01:48.036083
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('oops')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'oops'



# Generated at 2022-06-20 21:01:52.325690
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test_get_exception')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('test_get_exception',)



# Generated at 2022-06-20 21:01:57.368768
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise ValueError('Foo')

    try:
        test()
    except Exception:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == 'Foo'
        assert repr(e) == 'ValueError("Foo",)'

# Generated at 2022-06-20 21:02:37.857292
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bork')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception), '{0} is not an exception'.format(e)
        assert str(e) == 'bork', '{0} != "bork"'.format(e)
        assert e.__class__.__name__ == 'Exception'
        assert e.__class__.__module__ == 'exceptions'

# Generated at 2022-06-20 21:02:42.114242
# Unit test for function get_exception
def test_get_exception():
    '''ensure the exception is returned correctly'''
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
    assert type(e) == ValueError
    assert e.args == ("test",)

# Generated at 2022-06-20 21:02:50.589990
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'

# This is the test setup code.  This is a hack but we need the tests to be able
# to be run on Python 2.4.
try:
    from unittest import TestCase
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24
    class MyTestCase(TestCase):
        def runTest(self):
            raise Exception('Should have used the setUp() and tearDown() methods')
        pass
except ImportError:
    from ansible.module_utils.pycompat24 import TestCase
    import ansible.module_utils.pycompat24


# Generated at 2022-06-20 21:02:56.942218
# Unit test for function get_exception
def test_get_exception():

    # Test getting the most recent exception
    # Note that because of the wide range of python versions we need to support,
    # this test needs to be relatively simple: We can't do much more than use
    # pytest to verify that get_exception returns the same exception as is in
    # the global sys.exc_info() tuple
    class Testme(Exception):
        pass

    try:
        raise Testme('bar')
    except:
        exc_info = sys.exc_info()
        assert exc_info[1] == get_exception()



# Generated at 2022-06-20 21:03:04.364447
# Unit test for function get_exception
def test_get_exception():
    try:
        int('not a number')
        assert False, 'Expected an exception'
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError), 'Expecting ValueError, got %s' % type(e)
        assert str(e) == "invalid literal for int() with base 10: 'not a number'", "Bad exception: %s" % e



# Generated at 2022-06-20 21:03:06.833168
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 21:03:10.998752
# Unit test for function get_exception
def test_get_exception():
    """
    >>> test_get_exception()
    """
    try:
        raise SystemExit('exit')
    except Exception:
        e = get_exception()
        if str(e) != 'exit':
            raise Exception("get_exception didn't correctly return the current exception")


# Generated at 2022-06-20 21:03:13.651533
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception()



# Generated at 2022-06-20 21:03:17.866531
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except:
        # If we don't catch the exception then this test will raise an exception
        # which will cause all of the other tests to be skipped
        e = get_exception()
        assert e.args == ('foobar',)
        assert str(e) == "foobar"

# Generated at 2022-06-20 21:03:20.869374
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test error')
    except Exception:
        e = get_exception()
        errtext = str(e)
    assert errtext == 'test error'


# Test for function literal_eval

# Generated at 2022-06-20 21:04:31.149382
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ('Test exception',)

# Generated at 2022-06-20 21:04:34.247602
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise RuntimeError('test error')
        except Exception:
            return get_exception()

    assert foo().args == ('test error', )



# Generated at 2022-06-20 21:04:35.586398
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError)


# Generated at 2022-06-20 21:04:39.697365
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('The error message')
    except RuntimeError:
        exc = get_exception()
    assert exc.args == ('The error message',)


# Generated at 2022-06-20 21:04:43.900217
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    def f():
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == "test"
    try:
        raise ValueError("test")
    except ValueError:
        f()


# Generated at 2022-06-20 21:04:45.808611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        exception = get_exception()
    assert str(exception) == 'test'



# Generated at 2022-06-20 21:04:50.817353
# Unit test for function get_exception
def test_get_exception():
    try:
        raise b'123'  # Ouch!
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == (b'123',)


# Generated at 2022-06-20 21:04:54.093645
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' == e.args[0]

# Generated at 2022-06-20 21:05:03.317601
# Unit test for function get_exception
def test_get_exception():
    import sys

    try:
        raise ValueError('testing')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('testing',)

    try:
        raise ValueError('testing')
    except ValueError:
        e = sys.exc_info()[1]
    assert isinstance(e, ValueError)
    assert e.args == ('testing',)

    try:
        raise ValueError('testing')
    except ValueError:
        raise RuntimeError('bogus')
    except RuntimeError:
        e = sys.exc_info()[1]
    assert isinstance(e, RuntimeError)
    assert e.args == ('bogus',)

test_get_exception()

# Generated at 2022-06-20 21:05:08.465556
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Expected exception')
    except:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ('Expected exception',)



# Generated at 2022-06-20 21:08:06.259075
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Fake exception!')
    except Exception:
        e = get_exception()

    assert e.args == ('Fake exception!',)



# Generated at 2022-06-20 21:08:09.365117
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.args[0] == 'foo'


# Generated at 2022-06-20 21:08:15.455957
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise Exception("Unit test exception")
        except Exception:
            return get_exception()

    exception = raise_exception()
    assert exception.args == ("Unit test exception",)

    exception = raise_exception()
    assert exception.args == ("Unit test exception",)

# Generated at 2022-06-20 21:08:23.586505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise (Exception("foo"))
    except Exception as e:
        # Python 2.6+
        foo = e
    except:
        # Python 2.4, 2.5
        foo = get_exception()
    assert foo.args[0] == 'foo'

