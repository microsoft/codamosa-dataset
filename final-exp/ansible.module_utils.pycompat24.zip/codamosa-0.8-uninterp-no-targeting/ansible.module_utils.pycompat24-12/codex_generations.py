

# Generated at 2022-06-20 20:58:39.178906
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except MyException:
        e = get_exception()
    assert isinstance(e, MyException)



# Generated at 2022-06-20 20:58:44.039135
# Unit test for function get_exception
def test_get_exception():
    import inspect
    import sys

    try:
        raise Exception('Foo')
    except:
        e = get_exception()
        if e.args != ('Foo',):
            print("%s: Did not extract exception arguments correctly" % inspect.stack()[0][3])
        if str(e) != 'Foo':
            print("%s: Did not convert exception correctly" % inspect.stack()[0][3])
        if sys.exc_info()[1] is not e:
            print("%s: Did not maintain reference to exception in sys.exc_info()" % inspect.stack()[0][3])

# Generated at 2022-06-20 20:58:47.710112
# Unit test for function get_exception
def test_get_exception():
    def cause_exception():
        raise ValueError("This is the exception that was expected")

    try:
        cause_exception()
    except ValueError:
        e = get_exception()
        assert str(e) == "This is the exception that was expected"
        return
    assert False, 'Did not get expected exception'



# Generated at 2022-06-20 20:58:52.942431
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('This is an exception',)



# Generated at 2022-06-20 20:59:00.798603
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     1/0
    ... except:
    ...     e = get_exception()
    >>> type(e)
    <type 'exceptions.ZeroDivisionError'>
    >>> e
    ZeroDivisionError('integer division or modulo by zero',)
    >>> try:
    ...     1/'foo'
    ... except:
    ...     e = get_exception()
    >>> type(e)
    <type 'exceptions.TypeError'>
    >>> e
    TypeError("unsupported operand type(s) for /: 'int' and 'str'",)
    """
    pass

# Generated at 2022-06-20 20:59:05.547868
# Unit test for function get_exception
def test_get_exception():
    # This test runs inside a function in order to be able to catch
    # exceptions
    def _test_get_exception():
        try:
            raise Exception('test')
        except Exception:
            return get_exception()
    assert str(_test_get_exception()) == 'test'



# Generated at 2022-06-20 20:59:07.759055
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-20 20:59:15.315898
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except RuntimeError as e:
        assert get_exception() is e
        raise AssertionError('AssertionError should not be raised')
    except AssertionError as e:
        assert get_exception() is e
        return
    raise AssertionError('No exception raised')


# Generated at 2022-06-20 20:59:19.140920
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-20 20:59:23.585212
# Unit test for function get_exception
def test_get_exception():
    class MyError(Exception):
        pass

    try:
        raise MyError('Test')
    except MyError:
        exc = get_exception()
    assert exc.message == 'Test'

# Generated at 2022-06-20 20:59:36.685027
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise ValueError('Test exception')
    except:
        exception = get_exception()
    assert isinstance(exception, ValueError)
    assert str(exception) == 'Test exception'
    try:
        literal_eval('invalid')
    except:
        exception = get_exception()
    assert isinstance(exception, ValueError)
    assert str(exception) == 'malformed string'

# Generated at 2022-06-20 20:59:41.181234
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Sample exception")
    except:
        # Test that it works with str() and repr() called on the result
        assert repr(get_exception()) == repr("Sample exception")



# Generated at 2022-06-20 20:59:46.472034
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('this is a KeyError exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, KeyError)
        assert 'this is a KeyError exception' in str(e)


# Generated at 2022-06-20 20:59:49.849525
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Foo")
    except RuntimeError as e:
        assert e == get_exception()


# Generated at 2022-06-20 20:59:51.810476
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        assert get_exception()


# Generated at 2022-06-20 20:59:57.260295
# Unit test for function get_exception
def test_get_exception():
    try:
        func1()
    except Exception:
        e = get_exception()
        if str(e) == "func1 not defined":
            pass
        else:
            raise


# Generated at 2022-06-20 21:00:00.166780
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception(':-(')

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert str(e) == ':-('

# Generated at 2022-06-20 21:00:08.560830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'This is a test exception'


# Generated at 2022-06-20 21:00:13.208977
# Unit test for function get_exception
def test_get_exception():

    def foo():
        raise Exception('foo')

    def bar():
        try:
            foo()
        except:
            return get_exception()

    assert(str(bar()) == 'foo')
    assert(type(bar()) == Exception)

# Generated at 2022-06-20 21:00:15.521160
# Unit test for function get_exception

# Generated at 2022-06-20 21:00:33.843893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 21:00:37.531596
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Just testing")
    except RuntimeError:
        exc_rv = get_exception()
    assert isinstance(exc_rv, RuntimeError)
    assert str(exc_rv) == "Just testing"

# Generated at 2022-06-20 21:00:42.148445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing...')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args[0] == 'Testing...'



# Generated at 2022-06-20 21:00:46.918377
# Unit test for function get_exception
def test_get_exception():
    # The simplest way to test this code is to just call it from within
    # an except block and verify that it returns the exception we're
    # hitting
    try:
        raise RuntimeError('Testing')
    except RuntimeError:
        ret = get_exception()
    assert ret.args[0] == 'Testing'



# Generated at 2022-06-20 21:00:55.324528
# Unit test for function get_exception
def test_get_exception():
    def test(function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except:
            # Catch and store the exception that get_exception() would report
            e = get_exception()
            if e is not None:
                raise e
            else:
                raise Exception("get_exception() doesn't return an exception on %s" % repr(function))
    class MyException(Exception):
        pass
    try:
        raise MyException("Test Exception")
    except:
        test(get_exception)



# Generated at 2022-06-20 21:00:58.516528
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is the error')
    except Exception:
        exc = get_exception()
        assert exc.message == 'This is the error'

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-20 21:01:03.710307
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name,undefined-variable
    try:
        raise ValueError('foo')
    except Exception as e:
        if e is not None:
            print('Got %s as an exception' % e)
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        if e is not None:
            print('Got %s as an exception' % e)



# Generated at 2022-06-20 21:01:08.435625
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception")
    except:
        e = get_exception()
    assert e.args[0] == "This is a test exception"


# Generated at 2022-06-20 21:01:12.406816
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 21:01:14.969979
# Unit test for function get_exception
def test_get_exception():
    def get_exception_in_fn():
        try:
            raise ValueError('boom')
        except Exception:
            return get_exception()
    e = get_exception_in_fn()
    assert isinstance(e, ValueError)
    assert str(e) == 'boom'

# Generated at 2022-06-20 21:01:41.428781
# Unit test for function get_exception
def test_get_exception():
    def raise_exc(exc, exc_args=None):
        if exc_args is None:
            exc_args = ()

        try:
            raise exc(*exc_args)
        except exc:
            return get_exception()

    try:
        raise_exc(Exception)
    except Exception:
        exc = get_exception()
        assert exc is not None

    try:
        raise_exc(Exception, (1,2))
    except Exception:
        exc = get_exception()
        assert exc is not None
        assert exc.args == (1,2)

    try:
        raise_exc(Exception, (1,Exception(3)))
    except Exception:
        exc = get_exception()
        assert exc is not None
        assert exc.args[0] == 1
        assert exc.args[1]

# Generated at 2022-06-20 21:01:49.767856
# Unit test for function get_exception
def test_get_exception():
    '''
    This test needs to be able to raise an exception inside an
    except clause to test get_exception.  This means it can't be
    written as a unittest because a unittest will catch the raised
    exception.

    The concept here is if we raise an exception from within an
    except block, the exception information will be propagated out
    We can catch this information and compare it to what get_exception
    returns. If they are the same object, then get_exception works as
    expected.
    '''
    e = Exception('test exception')
    try:
        raise e
    except Exception:
        try:
            raise Exception('exception in an except clause')
        except Exception:
            found_exception = get_exception()


# Generated at 2022-06-20 21:01:51.219658
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError as e:
        assert e == get_exception()

# Generated at 2022-06-20 21:01:54.555128
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        e = get_exception()
    return e.args[0] == 'test exception'

if __name__ == '__main__':
    print(test_get_exception())

# Generated at 2022-06-20 21:01:56.592656
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except:
        exc = get_exception()
    assert exc.args[0] == 'Test'


# Generated at 2022-06-20 21:01:58.419930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'test', e



# Generated at 2022-06-20 21:01:59.829630
# Unit test for function get_exception
def test_get_exception():
    try:
        raise LookupError
    except LookupError:
        e = get_exception()
    assert isinstance(e, LookupError)

# Generated at 2022-06-20 21:02:02.574433
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() is e
    try:
        class Exc(object):
            def __str__(self):
                raise RuntimeError('bar')
        raise Exc()
    except RuntimeError as e:
        assert get_exception() is e

# Generated at 2022-06-20 21:02:07.094684
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        assert get_exception()



# Generated at 2022-06-20 21:02:09.588201
# Unit test for function get_exception
def test_get_exception():
    # Success case is tested in code above.
    try:
        raise Exception()
    except Exception:
        assert get_exception()

# Generated at 2022-06-20 21:02:48.031386
# Unit test for function get_exception
def test_get_exception():
    def fail(msg):
        raise Exception(msg)
    try:
        fail('TEST MESSAGE 1')
    except Exception:
        e = get_exception()
        assert str(e) == 'TEST MESSAGE 1'



# Generated at 2022-06-20 21:03:00.312905
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("get_exception test exception")
    except:
        if sys.version_info[0] == 2:
            import traceback
            try:
                traceback.print_exc()
            except:
                pass
        exc = get_exception()
        if isinstance(exc, RuntimeError) and str(exc) == "get_exception test exception":
            return

        import sys
        print(sys.version)
        print(sys.exc_info()[0])
        print(exc)
        raise RuntimeError("get_exception test failed")

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:03:04.783268
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise TypeError('A reason')
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert str(e) == 'A reason'

# Generated at 2022-06-20 21:03:07.269774
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'



# Generated at 2022-06-20 21:03:13.234374
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except:
        e = get_exception()
        assert e.args[0] == "foo"
    try:
        raise RuntimeError("foo", "bar")
    except:
        e = get_exception()
        assert e.args[0] == "foo"
        assert e.args[1] == "bar"
    assert True

# Generated at 2022-06-20 21:03:16.691638
# Unit test for function get_exception
def test_get_exception():
    import unittest
    try:
        raise Exception('Test exception')
    except:
        e = get_exception()
        assert str(e) == 'Test exception'
    unittest.TestCase().assertRaises(Exception, get_exception)
    return True



# Generated at 2022-06-20 21:03:22.441893
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception()."""
    import sys
    import pytest

    try:
        raise ValueError('test message')
    except ValueError as e1:
        e = get_exception()
        assert e is e1
        assert str(e) == 'test message'
        e = get_exception()
        assert e is e1
        assert str(e) == 'test message'
    else:
        pytest.fail('ValueError exception should have been raised')

# Generated at 2022-06-20 21:03:24.894334
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('abc')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('abc',)


# Generated at 2022-06-20 21:03:29.859229
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)
        assert str(e) == 'foo'


# Generated at 2022-06-20 21:03:32.021056
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except Exception:
        exception = get_exception()
    assert isinstance(exception, RuntimeError)



# Generated at 2022-06-20 21:04:42.469208
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception returns the current exception
    def foo():
        try:
            raise Exception('This is an exception')
        except:
            return get_exception()
    assert foo()

# Generated at 2022-06-20 21:04:47.923188
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('The first exception')
    except Exception:
        first_ex = get_exception()

    try:
        raise Exception('The second exception')
    except Exception:
        second_ex = get_exception()

    assert ('The first exception' == str(first_ex))
    assert ('The second exception' == str(second_ex))
    assert (first_ex is not second_ex)


# Generated at 2022-06-20 21:04:49.089965
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        pass
    e = get_exception()
    assert(str(e))

# Generated at 2022-06-20 21:04:51.748281
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foobar")
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == "foobar"

# Generated at 2022-06-20 21:04:57.195235
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise ValueError('Testing')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args[0] == 'Testing'

# Generated at 2022-06-20 21:04:59.543676
# Unit test for function get_exception
def test_get_exception():
    # Smoke test
    try:
        int('not a number')
    except Exception:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-20 21:05:02.161885
# Unit test for function get_exception
def test_get_exception():
    """Try to figure out the exception
    """
    try:
        int('hello')
    except:
        e = get_exception()
        assert True

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:05:13.699712
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=too-many-statements
    class MyException(Exception):
        pass

    exception = MyException('test exception')
    try:
        raise exception
    except MyException as e:
        exc = get_exception()
        assert exc is exception
        assert str(exc) == str(e)
        assert isinstance(exc, MyException)
        assert isinstance(exc, Exception)
        assert type(exc) is type(exception)
        assert type(exc) is type(e)
    else:
        assert False, 'Expected exception'

    # `get_exception` should also work with other exception types
    exception = IOError('test exception')
    try:
        raise exception
    except IOError as e:
        exc = get_exception()
        assert exc is exception

# Generated at 2022-06-20 21:05:17.609965
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise ValueError('testing')

    try:
        f()
    except Exception:
        assert get_exception().message == 'testing'

# Generated at 2022-06-20 21:05:21.382423
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'
        assert str(e) == 'This is a test'
    else:
        assert False, 'Exception was not raised'


# Generated at 2022-06-20 21:08:10.494488
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise ValueError("Some exception")
    except ValueError as e:
        assert e is get_exception()
    else:
        assert False, "There should have been an exception raised"


# Generated at 2022-06-20 21:08:13.531922
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'invalid literal for int() with base 10: \'a\''

# Generated at 2022-06-20 21:08:22.216783
# Unit test for function get_exception
def test_get_exception():
    """Verify that get_exception() returns current exception.

    This is a unit test for get_exception() function.

    :returns: Returns True when the test passes, False otherwise.
    :rtype: bool
    """
    try:
        raise Exception
    except Exception:
        return get_exception() is sys.exc_info()[1]
