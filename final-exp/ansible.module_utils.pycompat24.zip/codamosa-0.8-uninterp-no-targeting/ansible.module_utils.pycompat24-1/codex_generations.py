

# Generated at 2022-06-20 20:58:40.454542
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils import basic

    try:
        ansible_fail(msg='exception message')
    except Exception as e:
        pass
    assert e.args[0] == 'exception message'
    try:
        ansible_fail(msg='exception message')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'exception message'

# Generated at 2022-06-20 20:58:43.717052
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'foo' in str(e)

# Generated at 2022-06-20 20:58:47.469064
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError('foo')
        except:
            e = get_exception()
            return e

    inner.__name__ = 'inner'

    e = inner()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'


# Generated at 2022-06-20 20:58:51.602923
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TestException('get_exception')
    except:
        e = get_exception()
        assert isinstance(e, TestException)
        assert text_type(e) == 'get_exception'


# Generated at 2022-06-20 20:58:56.729418
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('testing')
    except TestException:
        exc_info = get_exception()
        assert 'testing' in str(exc_info)
        assert exc_info.__class__ == TestException

# Generated at 2022-06-20 20:58:59.901349
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'test exception'

# Generated at 2022-06-20 20:59:02.353047
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException()
    except:
        e = get_exception()
    assert isinstance(e, MyException)



# Generated at 2022-06-20 20:59:05.548332
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test")
    except Exception:
        e = get_exception()
        assert e.args[0] == "Test"

# Generated at 2022-06-20 20:59:14.012554
# Unit test for function get_exception
def test_get_exception():
    """Check that we get the correct exception returned"""

    # Test for correct exception that we're expecting
    try:
        raise RuntimeError('testing error')
    except Exception:
        assert get_exception().__class__.__name__ == 'RuntimeError'

    # Test for correct exception when one is not raised
    try:
        pass
    except Exception:
        assert get_exception() is None



# Generated at 2022-06-20 20:59:28.910301
# Unit test for function get_exception
def test_get_exception():
    """Function to test get_exception for all exception types
    """
    # Invalid Syntax
    try:
        exec("foo bar")
    except:
        assert get_exception().__class__ is SyntaxError

    # Name Error
    try:
        exec("undeclared_variable")
    except:
        assert get_exception().__class__ is NameError

    # Type Error
    try:
        1 + "foo"
    except:
        assert get_exception().__class__ is TypeError

    # Key Error
    try:
        {}['foo']
    except:
        assert get_exception().__class__ is KeyError

    # Value Error
    try:
        int("foo")
    except:
        assert get_exception().__class__ is ValueError

    # Attribute Error

# Generated at 2022-06-20 20:59:48.116814
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)
    assert str(e) == 'foo'

# Generated at 2022-06-20 20:59:50.948772
# Unit test for function get_exception
def test_get_exception():
    """Test for function get_exception"""
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-20 20:59:57.216697
# Unit test for function get_exception
def test_get_exception():
    try:
        keyerror()
    except Exception:
        e = get_exception()
    assert e.__class__.__name__ == 'NameError'
    assert e.args[0] == "global name 'keyerror' is not defined"

# Generated at 2022-06-20 20:59:59.109669
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Testing")
    except:
        assert get_exception()


# Generated at 2022-06-20 21:00:03.696021
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a value')
    except ValueError:
        exc = get_exception()
    assert str(exc) == 'a value'

# Generated at 2022-06-20 21:00:13.832054
# Unit test for function get_exception

# Generated at 2022-06-20 21:00:15.723768
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        x = get_exception()
        assert x


# Generated at 2022-06-20 21:00:18.331429
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('test')
    except TestException:
        e = get_exception()
    assert type(e) == TestException
    assert str(e) == 'test'



# Generated at 2022-06-20 21:00:20.723172
# Unit test for function get_exception
def test_get_exception():

    # raise an exception to catch
    try:
        raise Exception("test_exception")
    except Exception:
        # catch the exception and get the value
        e = get_exception()
        assert e.message == "test_exception"

# Generated at 2022-06-20 21:00:26.298464
# Unit test for function get_exception
def test_get_exception():
    import unittest

    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
    try:
        raise DeprecationWarning()
    except DeprecationWarning:
        e = get_exception()
        assert isinstance(e, DeprecationWarning)


# Generated at 2022-06-20 21:01:11.797071
# Unit test for function get_exception
def test_get_exception():
    # Test normal exception
    try:
        raise ValueError('normal')
    except ValueError:
        pass
    assert get_exception() is not None

    # Test exception when exception not raised
    try:
        pass
    except ValueError:
        assert get_exception() is not None
    else:
        assert get_exception() is None

    # Test exception when exception not raised
    try:
        raise ValueError('not handled')
    except TypeError:
        assert get_exception() is not None
    else:
        assert get_exception() is None



# Generated at 2022-06-20 21:01:14.428766
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        try:
            raise RuntimeError('Sample error')
        except:
            e = get_exception()
            if str(e) == 'Sample error':
                return 'PASS'
            else:
                return 'FAIL'
    assert test_func() == 'PASS'

# Generated at 2022-06-20 21:01:22.180247
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A test exception')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert repr(e) == repr('A test exception')
        assert str(e) == 'A test exception'
    try:
        raise ValueError
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert repr(e) == 'ValueError()'


# Generated at 2022-06-20 21:01:31.948131
# Unit test for function get_exception
def test_get_exception():
    def raise_error():
        raise ValueError('Error raised')
    try:
        raise_error()
    except Exception:
        exc = get_exception()
    assert str(exc) == 'Error raised', exc
    return exc
# This code is part of Ansible, but is an independent component.
# This particular file snippet, and this file snippet only, is BSD licensed.
# Modules you write using this snippet, which is embedded dynamically by Ansible
# still belong to the author of the module, and may assign their own license
# to the complete work.
#
# Copyright (c) 2016, Toshio Kuratomi <tkuratomi@ansible.com>
# Copyright (c) 2016, Tomasz Klim <tomek@klim.name>
#
# Redistribution and use in source and binary forms, with or without modification,


# Generated at 2022-06-20 21:01:35.305517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'test exception'

if __name__ == '__main__':
    import pytest
    pytest.main('-v')

# Generated at 2022-06-20 21:01:39.254285
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError

if __name__ == "__main__":
    # Run the unit tests
    test_get_exception()

# Generated at 2022-06-20 21:01:47.104688
# Unit test for function get_exception
def test_get_exception():
    #
    # Test that we can get the exception in a nested try block
    #
    try:
        try:
            raise RuntimeError()
        except RuntimeError:
            exc = get_exception()
            assert exc.__class__ is RuntimeError
    except Exception:
        # Should never be called.  If it is, it means get_exception()
        # failed to propagate the exception
        raise RuntimeError()


# Generated at 2022-06-20 21:01:52.020352
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-argument
    def foo():
        try:
            raise TypeError('Gah')
        except:
            return get_exception()

    my_exception = foo()
    assert isinstance(my_exception, TypeError)
    assert my_exception.args[0] == 'Gah'



# Generated at 2022-06-20 21:01:54.913318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-20 21:02:02.435250
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("this is a message")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('this is a message',)

    try:
        # py3k compat
        try:
            raise Exception("this is a message")
        except Exception as e:
            raise
    except:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('this is a message',)



# Generated at 2022-06-20 21:03:15.056988
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except:
        exc = get_exception()
    assert exc.args == ('test',)



# Generated at 2022-06-20 21:03:19.688007
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-20 21:03:24.950306
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise ValueError('foo')
        except Exception:
            e = get_exception()
            assert e.__class__ == ValueError
            assert str(e) == 'foo'
    except:
        if 'pytest' in sys.modules:
            raise
        else:
            assert False, 'Cannot run unit test under %s' % sys.executable


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:03:41.195065
# Unit test for function get_exception
def test_get_exception():
    import random
    import string
    try:
        raise AssertionError('This is only a test.')
    except AssertionError:
        # Test that exception is available when we get it directly
        assert str(get_exception()) == 'This is only a test.'
        # Test that exception is available when we get it indirectly
        exc = sys.exc_info()[1]
        assert str(exc) == 'This is only a test.'


if __name__ == '__main__':
    # Unit test for function literal_eval
    test_get_exception()

    #test_string = "hello"
    #test_string = "'hello'"
    #test_string = '"hello"'
    #test_string = "abcd"
    #test_string = "'hello'"
    #test_string = '"hello

# Generated at 2022-06-20 21:03:41.772385
# Unit test for function get_exception
def test_get_exception():
    get_exception()

# Generated at 2022-06-20 21:03:43.698992
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert type(e) is ZeroDivisionError


# Generated at 2022-06-20 21:03:52.991565
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        value_err = get_exception()
        import errno
        assert value_err.errno == errno.ENOENT, "errno should not be set"
    try:
        from glob import iglob
        iglob("foobarbaz")
    except EnvironmentError:
        env_err = get_exception()
        import errno
        assert env_err.errno == errno.ENOENT, "errno should be set"

# Generated at 2022-06-20 21:03:56.209085
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works as expected."""
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'testing get_exception'


# Generated at 2022-06-20 21:03:58.933316
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'Foo'

# Generated at 2022-06-20 21:04:01.858957
# Unit test for function get_exception

# Generated at 2022-06-20 21:06:58.866542
# Unit test for function get_exception
def test_get_exception():
    import sys
    try:
        raise ArithmeticError
    except Exception:
        e = get_exception()
        assert isinstance(e, ArithmeticError), str(e)
    try:
        raise ValueError
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError), str(e)
    if sys.version_info < (3,):
        # In py3, all exceptions are of type 'Exception'
        assert isinstance(e, Exception), str(e)
    else:
        assert not isinstance(e, Exception), str(e)


# Generated at 2022-06-20 21:07:03.441216
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        e = get_exception()
    assert str(e) == 'boom'



# Generated at 2022-06-20 21:07:10.563495
# Unit test for function get_exception
def test_get_exception():
    import io
    import pytest
    from ansible.module_utils.six import text_type

    with pytest.raises(Exception) as e:
        a = text_type('a')
        text_type(42, encoding='ascii', errors='strict')
    if isinstance(e.value, AttributeError):
        # Older Python 2.4-2.6 does not include the __traceback__ attribute on
        # the exception object
        test_exc = e.value
    else:
        test_exc = get_exception()
        assert e.value == test_exc
    assert test_exc.args == ('coercing to Unicode: need string or buffer, int found',)
    assert test_exc.__class__.__name__ == 'TypeError'
    assert test_exc.__class__.__module

# Generated at 2022-06-20 21:07:14.536303
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('answer')
    except:
        e = get_exception()
        assert e.args[0] == 'answer'



# Generated at 2022-06-20 21:07:20.181850
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 21:07:29.810968
# Unit test for function get_exception
def test_get_exception():
    """Check that all of the function's code paths are hit."""
    module_name = 'ansible.module_utils.six'

    def assertRaises(code, exception):
        try:
            code()
        except exception:
            return
        raise AssertionError('%r did not raise %r' % (code, exception))

    def test_code():
        get_exception()

    # Before anything else, this should raise an AssertionError
    assertRaises(test_code, AssertionError)

    def test_code():
        try:
            raise Exception()
        except Exception:
            get_exception()

    # Make sure that the function works inside of a try/except block
    test_code()

    def test_code():
        try:
            raise Exception()
        finally:
            get_ex

# Generated at 2022-06-20 21:07:32.903596
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

    try:
        raise Exception('foo', 'bar')
    except Exception:
        e = get_exception()
        assert e.args == ('foo', 'bar')



# Generated at 2022-06-20 21:07:39.228105
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(42)
    except:
        e = get_exception()
    if isinstance(e, ValueError) and e.args[0] == 42:
        print('OK')
    else:
        print('Failed:', e)

# Generated at 2022-06-20 21:07:44.678394
# Unit test for function get_exception

# Generated at 2022-06-20 21:07:47.143268
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert "foo" in str(e)