

# Generated at 2022-06-20 20:58:41.145717
# Unit test for function get_exception
def test_get_exception():

    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()

    assert str(e) == 'foo'


# Generated at 2022-06-20 20:58:42.455523
# Unit test for function get_exception

# Generated at 2022-06-20 20:58:46.836271
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=redefined-outer-name
    try:
        1 / 0
    except:  # pylint: disable=bare-except
        error = get_exception()
    assert isinstance(error, ZeroDivisionError)

# Generated at 2022-06-20 20:58:52.354749
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Incorrect value")
    except Exception:
        e = get_exception()
    if str(e) != "Incorrect value":
        raise AssertionError("get_exception did not return the string from the last exception: %s" % e)

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-20 20:58:59.393524
# Unit test for function get_exception
def test_get_exception():
    """
    >>> def foo():
    ...     try:
    ...         raise ValueError("foo")
    ...     except:
    ...         return get_exception()
    ...
    >>> e = foo()
    >>> type(e)
    <class 'exceptions.ValueError'>
    >>> e.args[0]
    'foo'
    """



# Generated at 2022-06-20 20:59:02.567144
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() == e



# Generated at 2022-06-20 20:59:06.828155
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert repr(e) == repr(Exception('test'))

# Unit tests for function literal_eval

# Generated at 2022-06-20 20:59:19.299908
# Unit test for function get_exception
def test_get_exception():
    """Test for function get_exception"""
    import types
    try:
        1/0
    except Exception as e:
        # Test if it's possible to modify the name of a function returned by
        # get_exception.  This is a way to ensure that we get a function and
        # not a proxy method that is not possible to modify.
        # If this test fails, it means we got a proxy method instead of a
        # function.  If so, use the 'try' clause in get_exception instead of
        # the 'except' clause.
        fun = get_exception
        fun.__name__ = 'new_name'
        if fun.__name__ != 'new_name':
            raise AssertionError("get_exception function is not really a function")

# Generated at 2022-06-20 20:59:26.055783
# Unit test for function get_exception
def test_get_exception():
    # The function is based on an example from: http://stackoverflow.com/a/12331114/257052
    try:
        raise KeyError('foo')
    except KeyError:
        exception = get_exception()
    assert type(exception) is KeyError
    assert str(exception) == 'foo'



# Generated at 2022-06-20 20:59:28.643818
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-20 20:59:42.030916
# Unit test for function get_exception
def test_get_exception():
    def outter_func(in1, in2):
        try:
            inner_func(in1, in2)
        except Exception:
            e = get_exception()
            return str(e)

    def inner_func(in1, in2):
        if in1 == in2:
            raise ValueError("The two arguments are the same")
        else:
            raise TypeError("The two arguments are not the same type")

    assert outter_func('foo', 'foo') == 'The two arguments are the same'
    assert outter_func('foo', 4) == 'The two arguments are not the same type'

# Generated at 2022-06-20 20:59:49.070599
# Unit test for function get_exception
def test_get_exception():
    raise ValueError('This is a test')

try:
    test_get_exception()
except ValueError as e:
    if not e == get_exception():
        raise AssertionError('get_exception returned the wrong exception.  Expected: %s.  Received: %s' % (e, get_exception()))

# Generated at 2022-06-20 20:59:51.198290
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foobar'

# Generated at 2022-06-20 20:59:56.237728
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hello world')
    except:
        e = get_exception()
        assert str(e) == 'hello world'

# Generated at 2022-06-20 21:00:00.892044
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('hello')
    except Exception:
        e = get_exception()
        if e.__str__().find('hello') == -1:
            raise AssertionError()
    else:
        raise AssertionError()

# Use the function to test itself
test_get_exception()

# Generated at 2022-06-20 21:00:05.502367
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Unit test exception")
    except:
        e = get_exception()
    assert "Unit test exception" in str(e)



# Generated at 2022-06-20 21:00:09.532667
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test get_exception")
    except Exception:
        assert get_exception().args[0] == "Test get_exception"


# Generated at 2022-06-20 21:00:11.939781
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        assert get_exception() is sys.exc_info()[1]



# Generated at 2022-06-20 21:00:15.061356
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-20 21:00:19.993005
# Unit test for function get_exception
def test_get_exception():
    try:
        int('one')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "invalid literal for int() with base 10: 'one'"



# Generated at 2022-06-20 21:00:31.583099
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("my exception")
    except RuntimeError as e:
        assert e == get_exception()


# Generated at 2022-06-20 21:00:36.201109
# Unit test for function get_exception
def test_get_exception():
    # f -> _test_get_exception
    # pylint: disable=unused-variable
    try:
        raise ValueError('a test')
    except ValueError:
        e = get_exception()
    assert 'a test' in str(e)
    assert isinstance(e, ValueError)



# Generated at 2022-06-20 21:00:39.683542
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        exc = get_exception()
        if isinstance(exc, ZeroDivisionError):
            pass
        else:
            raise AssertionError("get_exception() should return "
                    "the current exception.")

# Generated at 2022-06-20 21:00:45.324619
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException
    except:
        e = get_exception()
    assert isinstance(e, MyException)
    class OldStyleException:
        pass
    try:
        raise OldStyleException
    except:
        e = get_exception()
    assert isinstance(e, OldStyleException)



# Generated at 2022-06-20 21:00:51.035201
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
    assert e.__str__() == ''
    try:
        raise Exception('foobar')
    except:
        e = get_exception()
    assert e.__str__() == 'foobar'



# Generated at 2022-06-20 21:00:54.307529
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise RuntimeError('test')
        except Exception:
            e = get_exception()
            print(e.args[0])
            if e.args[0] != 'test':
                raise ValueError

    f()

# Generated at 2022-06-20 21:01:00.459287
# Unit test for function get_exception
def test_get_exception():
    """
    Unit test for function get_exception.

    >>> test_get_exception()
    """
    try:
        1 / 0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

    try:
        1 + 'eggs'
    except:
        e = get_exception()
        assert isinstance(e, TypeError)

    try:
        raise ZeroDivisionError
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-20 21:01:04.476718
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        e = get_exception()

    assert isinstance(e, TestException)

# Generated at 2022-06-20 21:01:07.396674
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-20 21:01:09.248032
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('unit test')
    except Exception:
        exception = get_exception()
    assert isinstance(exception, RuntimeError)



# Generated at 2022-06-20 21:01:29.870483
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test Exception')
    except:
        e = get_exception()

    assert str(e) == 'Test Exception'

# Generated at 2022-06-20 21:01:40.921806
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception"""
    import re
    import inspect
    result = get_exception()
    assert result is None, 'expected None from get_exception() when no exception is raised'
    try:
        raise Exception('hello world')
    except Exception:
        result = get_exception()
    assert 'hello world' == result.args[0], 'expected "hello world" from get_exception() when Exception("hello world") is raised'
    if sys.version_info >= (3,):
        func_code = """def fa_da_ta(self):
        raise Exception('hello world')
"""
    else:
        func_code = """def fa_da_ta(self):
    raise Exception('hello world')
"""

# Generated at 2022-06-20 21:01:46.940970
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=missing-docstring
    try:
        raise ValueError("This is a test exception")
    except ValueError:
        e = get_exception()
        assert str(e) == "This is a test exception", \
                "get_exception() didn't return the exception that was raised"


# Generated at 2022-06-20 21:01:50.450656
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-20 21:01:54.913323
# Unit test for function get_exception
def test_get_exception():
    def get_exception_test():
        raise Exception('Test Exception')

    try:
        get_exception_test()
    except Exception:
        exception_value = get_exception()
        assert isinstance(exception_value, Exception)
        assert exception_value.args == ('Test Exception',)



# Generated at 2022-06-20 21:01:56.950893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test ValueError')
    except:
        e = get_exception()

    assert e.args[0] == 'Test ValueError'

# Generated at 2022-06-20 21:02:03.916118
# Unit test for function get_exception
def test_get_exception():
    # Python2.x and python3.x have different behavior regarding
    # the return value of sys.exc_info()[1] if the exception is not
    # set.  This works on both 2.x and 3.x
    try:
        raise ValueError('foo')
    except ValueError as e:
        try:
            raise TypeError('bar')
        except TypeError as e1:
            # In 2.x and 3.x Python, sys.exc_info()[1] == e1 since
            # "e1 = get_exception()" sets e1 and then sets
            # sys.exc_info()[1]
            e2 = get_exception()
            assert e1 == e2
            assert e1 != e

# Generated at 2022-06-20 21:02:08.804897
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('passed')
    except RuntimeError:
        assert str(get_exception()) == 'passed'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:02:13.813082
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'
    assert e.args == tuple('foo')


# Generated at 2022-06-20 21:02:16.494156
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('testing get_exception()')
    except RuntimeError as e:
        g = get_exception()

    assert e is g


# Generated at 2022-06-20 21:02:57.440979
# Unit test for function get_exception
def test_get_exception():
    def raise_(): raise Exception('Hello World')

    try:
        raise_()
        assert False, "Should've raised an exception"
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Hello World', "get_exception() did not return the right exception"



# Generated at 2022-06-20 21:03:00.335952
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except:
        return get_exception().args == ('foo',)


# Generated at 2022-06-20 21:03:03.723690
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:06.458959
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:10.871344
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert type(e).__name__ == 'ValueError'
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:03:16.209737
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    # On Py3k, this won't be an instanceof TestException but it will still be a
    # TestException
    try:
        raise TestException('testing get_exception')
    except:
        e = get_exception()
        _type, value, traceback = sys.exc_info()
        assert e is value



# Generated at 2022-06-20 21:03:20.413067
# Unit test for function get_exception

# Generated at 2022-06-20 21:03:28.196094
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetException(unittest.TestCase):

        def test_simple(self):
            import copy
            import random
            import sys
            import time

            def msg_generator():
                """Generate a random message for testing."""
                return "The quick brown fox jumped over the lazy dog. Sleeps %s." \
                    % random.random()

            # Generate a random message.
            orig_msg = msg_generator()
            orig_exc = Exception(orig_msg)
            # Save away the original exception so we can test that we're getting
            # a copy
            orig_exc_id = id(orig_exc)

            # A function that raises an exception
            def raise_exc():
                raise orig_exc
            # A function that saves the exception
            def save_exc():
                e

# Generated at 2022-06-20 21:03:30.685526
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert 'Test exception' == str(e)

# Generated at 2022-06-20 21:03:44.050317
# Unit test for function get_exception
def test_get_exception():
    # Simple exception
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'This is an exception'

    # Chained exception
    try:
        try:
            raise Exception('This is an exception')
        except:
            raise
    except Exception:
        e = get_exception()
        assert str(e) == 'This is an exception'

    # Test that the wrapper raises exceptions cleanly
    import sys

    try:
        raise Exception("This is an exception")
    except:
        try:
            raise
        except Exception:
            _, e, _ = sys.exc_info()
    assert str(e) == 'This is an exception'

# Generated at 2022-06-20 21:04:58.313499
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-argument
    try:
        raise Exception('Test Exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('Test Exception',)

# Generated at 2022-06-20 21:05:05.001471
# Unit test for function get_exception
def test_get_exception():
    """Perform unit tests for function get_exception from this module.
    :return: Tuple: (Int: Number of errors, Int: Number of tests run)
    """
    import os
    import tempfile
    import shutil

    import ansible.module_utils.basic
    errors = 0
    num_tests = 0

    (tmp_fd, tmp_file) = tempfile.mkstemp(prefix='ansible-test-get_exception')
    old_cwd = os.getcwd()
    old_umask = os.umask(0o077)
    new_cwd = None

# Generated at 2022-06-20 21:05:18.066962
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
    assert type(e) is ZeroDivisionError
    # Unit tests for literal_eval
    tests = [
        ('1', 1),
        ('[1, 2, 3]', [1, 2, 3]),
        ('{ "foo": "bar", "ham": "eggs" }', {"foo": "bar", "ham": "eggs"}),
    ]
    for t in tests:
        result = literal_eval(t[0])
        assert result == t[1], "Literal evaluation failed; expected %s got %s" % (t[1], result)

# Generated at 2022-06-20 21:05:21.474257
# Unit test for function get_exception
def test_get_exception():
    class FakeException(RuntimeError):
        pass

    try:
        # pylint: disable=undefined-variable
        raise FakeException('foo')
    except FakeException:
        e = get_exception()
    assert e.args == ('foo',)
    assert isinstance(e, FakeException)


# Generated at 2022-06-20 21:05:25.796554
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError('bar')
    except Exception:
        e = get_exception()
        assert isinstance(e, AttributeError)
        assert e.args == ('bar',)

# Generated at 2022-06-20 21:05:29.261387
# Unit test for function get_exception
def test_get_exception():
    try:
        # py3
        raise Exception()
    except Exception as e:
        assert e is get_exception()

    try:
        # py2
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-20 21:05:33.266515
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test')
    except Exception:
        e = get_exception()
        assert(str(e) == 'This is a test')

# Generated at 2022-06-20 21:05:37.810907
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        ret = get_exception()
        assert isinstance(ret, ValueError)
    return ret


# Generated at 2022-06-20 21:05:41.205725
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
    except Exception:
        e = get_exception()
    assert e.__class__.__name__ == 'ValueError'
    assert str(e) == "invalid literal for int() with base 10: 'foo'"


# Generated at 2022-06-20 21:05:47.038273
# Unit test for function get_exception
def test_get_exception():
    class SomeException(Exception):
        pass