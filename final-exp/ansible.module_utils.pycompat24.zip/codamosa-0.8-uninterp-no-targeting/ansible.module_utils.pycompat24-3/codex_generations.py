

# Generated at 2022-06-20 20:58:43.514869
# Unit test for function get_exception
def test_get_exception():
    def func():
        raise Exception("A message")
    try:
        func()
    except Exception:
        result = get_exception()
    assert result.args[0] == 'A message'



# Generated at 2022-06-20 20:58:47.483443
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert e is not None
    assert isinstance(e, ValueError)



# Generated at 2022-06-20 20:58:54.132935
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u"\u2019")
    except Exception:
        exc = get_exception()
        if not isinstance(exc, Exception) or exc.message != u"\u2019":
            raise AssertionError(
                    "get_exception() didn't return the right exception: %r" % exc)

# Generated at 2022-06-20 20:58:56.379096
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert e is not None
    return True

# Generated at 2022-06-20 20:58:59.541794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        ex = get_exception()
        assert isinstance(ex, ValueError)



# Generated at 2022-06-20 20:59:03.893023
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert exc is not None
        assert sys.exc_info()[1] is exc


# Generated at 2022-06-20 20:59:07.052584
# Unit test for function get_exception
def test_get_exception():
    exception_raised = None
    try:
        int('spam')
    except ValueError:
        exception_raised = get_exception()

    assert isinstance(exception_raised, ValueError)


# Generated at 2022-06-20 20:59:12.362662
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError('abc')
        except Exception:
            e = get_exception()
            assert type(e) is ValueError
            assert e.args == ('abc',)

    inner()

# Generated at 2022-06-20 20:59:16.518752
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        exception = get_exception()
        assert isinstance(exception, RuntimeError)
        assert exception.message == 'Test exception'

# Generated at 2022-06-20 20:59:20.334638
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        assert sys.exc_info()[1].args[0] == get_exception().args[0]



# Generated at 2022-06-20 20:59:52.549657
# Unit test for function get_exception
def test_get_exception():
    # Basic case
    try:
        raise RuntimeError("Expected exception")
    except RuntimeError:
        e = get_exception()
        assert e.args == ("Expected exception",)

    # Test with wrapper exception
    try:
        try:
            raise ValueError("Wrong exception")
        except ValueError:
            raise RuntimeError("Expected exception")
    except RuntimeError:
        e = get_exception()
        assert e.args == ("Expected exception",)

    # Test with wrapper exception and finally clause
    try:
        try:
            raise ValueError("Wrong exception")
        except ValueError:
            raise RuntimeError("Expected exception")
        finally:
            pass
    except RuntimeError:
        e = get_exception()
        assert e.args == ("Expected exception",)

    # Test with

# Generated at 2022-06-20 20:59:56.921225
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)



# Generated at 2022-06-20 21:00:00.476421
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('yo')
    except RuntimeError as e:
        if get_exception() is e:
            print('normal exception')
        else:
            print('failed to get exception')
    else:
        print('Should have had an exception')

# Generated at 2022-06-20 21:00:02.417831
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=anomalous-backslash-in-string
    def test():
        try:
            raise SyntaxError('Test')
        except Exception:
            e = get_exception()
            assert isinstance(e, SyntaxError)
            assert str(e) == 'Test'
    test()

# Generated at 2022-06-20 21:00:05.266493
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        assert sys.exc_info()[1] == get_exception()

# Generated at 2022-06-20 21:00:09.385285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)



# Generated at 2022-06-20 21:00:18.838548
# Unit test for function get_exception
def test_get_exception():
    # Testing for compatibility with try/except blocks
    def get_exception_test_1():
        try:
            raise RuntimeError('test exception')
        except RuntimeError:
            return get_exception()
    test_1_exception = get_exception_test_1()
    assert test_1_exception.args == ('test exception',), \
        'Exception in get_exception_test_1() was not caught'

    # Testing for compatibility with function decorators, which use functions
    # with a different calling sequence than exceptions.
    def get_exception_test_2():
        def raise_exception(exception_type, exception_args):
            raise exception_type(*exception_args)

# Generated at 2022-06-20 21:00:23.289648
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('some error')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('some error',)



# Generated at 2022-06-20 21:00:27.427394
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foobar")
    except Exception:
        e = get_exception()
        assert str(e) == "foobar"



# Generated at 2022-06-20 21:00:38.541735
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import mock

    class GetExceptionTests(unittest.TestCase):
        def test_exception(self):
            with self.assertRaises(ZeroDivisionError):
                1 / 0

            try:
                1 / 0
            except Exception:
                self.assertEqual(get_exception().__class__, ZeroDivisionError)

        @mock.patch('sys.exc_info')
        def test_exc_info(self, mock_exc_info):
            mock_exc_info.return_value = (ZeroDivisionError, ZeroDivisionError('a'), None)
            self.assertEqual(get_exception().__class__, ZeroDivisionError)

    suite = unittest.TestLoader().loadTestsFromTestCase(GetExceptionTests)
    unittest.Text

# Generated at 2022-06-20 21:00:57.001033
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except:
        assert str(get_exception()) == "Test exception"


# Generated at 2022-06-20 21:00:59.201902
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ()



# Generated at 2022-06-20 21:01:07.025149
# Unit test for function get_exception

# Generated at 2022-06-20 21:01:09.759076
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception as e:
        assert get_exception() == e

# Generated at 2022-06-20 21:01:16.645980
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is the error text")
    # pylint: disable=bare-except
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("This is the error text",)
    assert str(e) == 'This is the error text'

# Generated at 2022-06-20 21:01:18.123998
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(1)
    except ValueError:
        assert get_exception().args == (1,)

# Generated at 2022-06-20 21:01:26.566858
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTester(unittest.TestCase):
        """Test that get_exception() returns the correct exception"""
        def test_exception(self):
            try:
                # pylint: disable=pointless-statement
                1 / 0
            except ZeroDivisionError:
                self.assertIsInstance(get_exception(), ZeroDivisionError)
            else:
                self.fail('ZeroDivisionError should have been thrown')

    return unittest.TestLoader().loadTestsFromTestCase(GetExceptionTester)

# Generated at 2022-06-20 21:01:34.201422
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 0 / 0
    except ZeroDivisionError as e:
        e1 = e
    except Exception as e:
        e1 = e

    try:
        a = 0 / 0
    except Exception:
        e2 = get_exception()

    assert e1.__class__ == e2.__class__

# Generated at 2022-06-20 21:01:38.000310
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        raise Exception('test')

    try:
        test_func()
    except Exception:
        e = get_exception()
    assert e.args[0] == 'test'

# Generated at 2022-06-20 21:01:40.075558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()

    assert type(e) == ValueError
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:02:18.581779
# Unit test for function get_exception
def test_get_exception():
    class FooException(Exception):
        pass
    try:
        raise FooException()
    except:
        import traceback
        exc_info = sys.exc_info()
        assert exc_info == sys.exc_info()
        exc = get_exception()
        exc_type, exc_value, exc_traceback = exc_info
        assert exc is exc_value
        traceback.print_exception(*exc_info)

# Generated at 2022-06-20 21:02:20.738844
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)


# Generated at 2022-06-20 21:02:22.824812
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert type(get_exception()) == ZeroDivisionError


# Generated at 2022-06-20 21:02:28.775898
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('1: foo')
    except:
        assert get_exception() is not None
        e = get_exception()
    assert str(e) == '1: foo'

literal_eval_str = literal_eval
if hasattr(literal_eval, '__text_signature__'):
    # Python 3.3+, but 2.6-3.2 need this function to be named 'literal_eval'
    literal_eval = lambda x: literal_eval_str(x, mode='eval')


# Generated at 2022-06-20 21:02:33.814714
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(e):
        raise e

    try:
        raise_exception(ValueError())
    except Exception as e:
        assert e is get_exception()
    except:
        assert False, "Did not get an exception"



# Generated at 2022-06-20 21:02:39.180084
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo bar')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert 'Foo bar' == str(e)



# Generated at 2022-06-20 21:02:44.862981
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception function.
    This test fails if get_exception raises an exception or if it returns
    something that isn't an exception.
    """
    try:
        raise KeyError('Test exception')
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert isinstance(e, KeyError)
    assert e.args == ('Test exception',)

# Generated at 2022-06-20 21:02:47.735098
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception() is not None


# Generated at 2022-06-20 21:02:56.345135
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule

    try:
        raise Exception('bork')
    except Exception as e:
        assert e is get_exception()
    try:
        raise Exception('bork')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'bork'
        assert 'bork' in str(e)

# Generated at 2022-06-20 21:02:58.365607
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError
    except AssertionError:
        if get_exception() is not sys.exc_info()[1]:
            raise Exception('get_exception() doesn\'t work!')

# Generated at 2022-06-20 21:04:09.187039
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise ValueError("Testing get_exception")

    try:
        f()
    except:
        v = get_exception()
    assert isinstance(v, ValueError)
    assert v.args == ("Testing get_exception",)

# Generated at 2022-06-20 21:04:13.188295
# Unit test for function get_exception

# Generated at 2022-06-20 21:04:15.531238
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert 'division by zero' in str(e)
    else:
        raise Exception('expected an exception')

# EOF

# Generated at 2022-06-20 21:04:24.760629
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError('I hope you did not intend to divide by zero!')
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), 'Exception is of the wrong type'
        assert str(e) == 'I hope you did not intend to divide by zero!', 'Unexpected exception text'


# Generated at 2022-06-20 21:04:29.480096
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("dummy")
    except RuntimeError:
        e1 = get_exception()
        e2 = sys.exc_info()[1]
        assert e1 is e2

# Generated at 2022-06-20 21:04:34.072880
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except:
        exc = get_exception()
    assert exc.args == ('This is a test',), exc.args



# Generated at 2022-06-20 21:04:35.665266
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except RuntimeError:
        exc = get_exception()
        assert exc.args[0] == 'this is a test'

# Generated at 2022-06-20 21:04:40.194595
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception')
    except:
        e = get_exception()
    assert e.args[0] == 'Testing get_exception'


# Generated at 2022-06-20 21:04:46.376265
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('NameError raised')
    except NameError as e:
        e2 = get_exception()
        # Check that the two exceptions are the same object
        assert e is e2
        # Check that the exception is a NameError
        assert isinstance(e2, NameError)


# Generated at 2022-06-20 21:04:50.743517
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name
    e = None
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    return e is not None


# Generated at 2022-06-20 21:07:41.370203
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-20 21:07:50.389297
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=redefined-outer-name
    def f(x, y):
        return x / y

    try:
        print('{0} / {1} = {2}'.format(10, 0, f(10, 0)))  # This will raise an error
    except Exception:  # pylint: disable=broad-except
        e = get_exception()
        if isinstance(e, ZeroDivisionError):
            print('Handled error correctly')
        else:
            print('Error: {0} was raised when expecting ZeroDivisionError'.format(type(e).__name__))
            sys.exit(1)



# Generated at 2022-06-20 21:07:51.935532
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as zde:
        assert zde is get_exception()



# Generated at 2022-06-20 21:08:07.379515
# Unit test for function get_exception
def test_get_exception():
    import traceback

    # Make sure that all exception types are caught by this function,
    # and that exception args are accessible by calling it
    exception_types = [None, int, float, str, unicode, KeyError, SyntaxError, ValueError]

# Generated at 2022-06-20 21:08:09.681830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Boom")
    except Exception:
        e = get_exception()

    assert(str(e))

# Generated at 2022-06-20 21:08:11.778256
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)
    assert e.__class__ == Exception

# Generated at 2022-06-20 21:08:14.439540
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        err = get_exception()
    assert err.args[0] == 'test'
test_get_exception()



# Generated at 2022-06-20 21:08:15.703028
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-20 21:08:21.170919
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing RuntimeError')
    except Exception:
        e = get_exception()
        assert 'Testing RuntimeError' in str(e)
        assert e.__class__ == RuntimeError

# Generated at 2022-06-20 21:08:25.916593
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError('foo')
        except:
            return get_exception()
    assert inner().args == ('foo',)