

# Generated at 2022-06-20 20:58:41.782711
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(42)
    except Exception:
        e = get_exception()
    assert e.args[0] == 42
    try:
        raise ValueError('test_get_exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'test_get_exception'

# Generated at 2022-06-20 20:58:47.639235
# Unit test for function get_exception
def test_get_exception():
    __tracebackhide__ = True


# Generated at 2022-06-20 20:58:57.817006
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> try:
    ...     raise Exception('something else')
    ... except:
    ...     e = get_exception()
    ...     print(type(e))
    ...     print(e)
    <type 'exceptions.Exception'>
    something else

    >>> try:
    ...     raise StopIteration
    ... except:
    ...     e = get_exception()
    ...     print(type(e))
    ...     print(e)
    <type 'exceptions.StopIteration'>
    '''

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 20:59:01.931961
# Unit test for function get_exception
def test_get_exception():
    """Make sure we get the current exception when we call get_exception"""
    try:
        1/0
    except Exception:
        assert get_exception()

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 20:59:09.225037
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception() function."""
    try:
        raise RuntimeError('test')
    except RuntimeError:
        exc_info = sys.exc_info()
        e = get_exception()
        assert exc_info[1] == e
        # Check id() and type() in addition to == so that we're sure it's the *same* exception
        assert id(exc_info[1]) == id(e)
        assert type(exc_info[1]) == type(e)
        return
    assert False, 'Should only get here through an exception'

# Generated at 2022-06-20 20:59:12.847072
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IOError()
    except IOError:
        e = get_exception()
    assert isinstance(e, IOError)
    assert e.__class__ == IOError


# Generated at 2022-06-20 20:59:17.273210
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass
    try:
        raise CustomException('Test')
    except:
        e = get_exception()
        assert isinstance(e, CustomException)
        assert e.args == ('Test',)

# Generated at 2022-06-20 20:59:26.952583
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=too-few-public-methods
    class TestException(Exception):
        pass
    test_get_exception._raised_exception = None # pylint: disable=protected-access
    try:
        raise TestException('Testing')
    except TestException as e:
        test_get_exception._raised_exception = get_exception() # pylint: disable=protected-access
    assert test_get_exception._raised_exception == e # pylint: disable=protected-access

# Generated at 2022-06-20 20:59:34.728352
# Unit test for function get_exception
def test_get_exception():
    # Try the happy path where all works
    try:
        2 / 0
    except:
        e = get_exception()
    assert(e, ZeroDivisionError)
    e = None
    # Now try the raising exception in an except: block
    try:
        1 / 0
    except ZeroDivisionError:
        try:
            2/0
        except:
            try:
                e = get_exception()
            except:
                pass
    assert(e, ZeroDivisionError)

    # Now try it in a function
    def test_func():
        try:
            2 / 0
        except ZeroDivisionError:
            try:
                e = get_exception()
            except:
                pass
    test_func()
    assert(e, ZeroDivisionError)

# Generated at 2022-06-20 20:59:36.741462
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = sys.exc_info()[1]
        assert sys.exc_info()[1] == exc
        assert get_exception() == exc
        assert get_exception() != ValueError('bar')

# Generated at 2022-06-20 20:59:48.636881
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception"""
    def function():
        """Dummy function to test get_exception"""
        try:
            raise RuntimeError("foo")
        except RuntimeError:
            return get_exception()

    assert function().args == ("foo",)

# Generated at 2022-06-20 20:59:53.220684
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('this is the error message')
    except TestException:
        e = get_exception()

    assert e.__class__.__name__ == 'TestException'
    assert str(e) == 'this is the error message'

# Generated at 2022-06-20 20:59:56.625333
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        assert get_exception() is sys.exc_info()[1]



# Generated at 2022-06-20 21:00:01.758044
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    try:
        raise ValueError("This is a test")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("This is a test",)
    mod.exit_json(changed=False)


# Unit Test for function literal_eval

# Generated at 2022-06-20 21:00:04.716953
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('some exception')
    except ValueError as e:
        assert e is get_exception()

# Generated at 2022-06-20 21:00:15.710148
# Unit test for function get_exception
def test_get_exception():
    global get_exception  # pylint:disable=global-statement

    class Failed(Exception):
        '''Exception used to denote a test has failed'''
        pass

    try:
        raise ValueError('This is text')
    except ValueError:
        # Get the actual exception
        exception = get_exception()

    # Check that the exception was returned
    if exception is None:
        raise Failed('Did not get the exception')
    # Check that the exception is the correct one
    if not isinstance(exception, ValueError):
        raise Failed('Retrieved the wrong type of exception')
    # Check that the exception text is correct
    if str(exception) != 'This is text':
        raise Failed('Retrieved the wrong exception text')

    # The exception was retrieved properly


# Generated at 2022-06-20 21:00:19.874114
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception()

    get_exception() should return the same exception if called outside of an
    exception or inside an exception.
    """
    try:
        raise OSError('test')
    except OSError:
        e = get_exception()
        assert str(e) == 'test'
    e = OSError('test')
    assert str(e) == 'test'

# Generated at 2022-06-20 21:00:24.820578
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A')
    except ValueError:
        e = get_exception()
        assert(isinstance(e, ValueError))
        assert(str(e) == 'A')



# Generated at 2022-06-20 21:00:27.320339
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IndexError('test error')
    except IndexError as e:
        assert e == get_exception()

# Generated at 2022-06-20 21:00:29.451593
# Unit test for function get_exception

# Generated at 2022-06-20 21:00:41.409092
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('oops!')
    except:
        e = get_exception()
    assert e.message == 'oops!'



# Generated at 2022-06-20 21:00:49.790618
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'

# Generated at 2022-06-20 21:00:54.800318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert exc.args[0] == 'foo' # pylint: disable=len-as-condition,no-member
        assert exc.args[1:] == () # pylint: disable=len-as-condition,no-member



# Generated at 2022-06-20 21:00:57.002412
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except Exception as e:
        assert str(e) == str(get_exception())

# Unit testing for literal_eval

# Generated at 2022-06-20 21:01:00.422214
# Unit test for function get_exception
def test_get_exception():
    def get_exc(exc):
        try:
            raise exc
        except:
            return get_exception()

    for exc in [RuntimeError, TypeError, ValueError, ZeroDivisionError('Error')]:
        assert get_exc(exc) == exc
        assert get_exc(exc('msg')) != exc

# Generated at 2022-06-20 21:01:05.496749
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    try:
        1/0
    except:
        err = get_exception()
        print(err)
        print(repr(err))
        assert repr(err) == 'ZeroDivisionError("integer division or modulo by zero",)'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:01:09.591546
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            g()
        except Exception:
            e = get_exception()
            return type(e), str(e)
    def g():
        raise Exception("foo")
    assert f() == (Exception, "foo")
    print("get_exception() works")

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-20 21:01:11.161341
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        assert isinstance(get_exception(), Exception)



# Generated at 2022-06-20 21:01:15.897821
# Unit test for function get_exception
def test_get_exception():
    # Import this module only in the unit test
    import unittest2
    class TestGetException(unittest2.TestCase):
        def test_simple(self):
            try: raise Exception("This is a test exception")
            except:
                e = get_exception()
            self.assertEqual("This is a test exception", str(e))

    suite = unittest2.TestLoader().loadTestsFromTestCase(TestGetException)
    unittest2.TextTestRunner(verbosity=5).run(suite)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-20 21:01:20.560475
# Unit test for function get_exception
def test_get_exception():
    def f():
        pass

    def g():
        try:
            raise Exception("foo")
        except Exception:
            ex = get_exception()
            return (ex, type(ex))

    assert g() == (Exception("foo"), Exception)
    assert f() is None

# Generated at 2022-06-20 21:01:39.715839
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Testing get_exception")
    except RuntimeError:
        e = get_exception()
        assert str(e) == "Testing get_exception"


# Generated at 2022-06-20 21:01:41.061981
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.message == 'foo'



# Generated at 2022-06-20 21:01:42.594218
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foo')
    except TestException as e:
        assert get_exception() is e


# Generated at 2022-06-20 21:01:44.981323
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise ValueError('bogus')

    try:
        f()
    except ValueError:
        if not get_exception().args[0] == 'bogus':
            raise ValueError('test_get_exception failed')
    else:
        raise ValueError('test_get_exception failed')

# Generated at 2022-06-20 21:01:48.302544
# Unit test for function get_exception
def test_get_exception():
    """Check if get_exception() actually gets the exception"""
    try:
        raise ValueError('This is test exception')
    except:
        e = get_exception()
        if e.__str__() != 'This is test exception':
            raise AssertionError('Unexpected exception value returned')

# Generated at 2022-06-20 21:01:50.371019
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError:
        assert str(get_exception()) == "foo"

# Generated at 2022-06-20 21:01:54.912817
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is an exception")
    except ValueError as e:
        e1 = e
    e2 = get_exception()
    assert e1 == e2
    # Check that it doesn't raise an exception
    get_exception()



# Generated at 2022-06-20 21:01:59.026882
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError('Test exception')
    except AttributeError:
        return get_exception()


# Generated at 2022-06-20 21:02:01.799915
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-20 21:02:03.501214
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-20 21:02:44.686501
# Unit test for function get_exception
def test_get_exception():
    def fail():
        raise ValueError("This is a test of get_exception")

    try:
        fail()
    except:
        exc_info = get_exception()
    assert 'ValueError' == exc_info.__class__.__name__
    assert "This is a test of get_exception" == str(exc_info)



# Generated at 2022-06-20 21:02:53.177258
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        x = get_exception()
    assert x.__class__ is Exception
    assert str(x) == 'Exception()'
    try:
        raise ValueError
    except ValueError:
        x = get_exception()
    assert x.__class__ is ValueError
    assert str(x) == 'ValueError()'



# Generated at 2022-06-20 21:02:55.564148
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('unit test')
    except ValueError as e:
        assert e == get_exception()



# Generated at 2022-06-20 21:02:59.947628
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test of the get_exception function')
    except:
        e = get_exception()
        assert e.args[0] == 'This is a test of the get_exception function'


# Generated at 2022-06-20 21:03:05.072567
# Unit test for function get_exception
def test_get_exception():
    # Test inner/outer exception handling
    try:
        try:
            raise NameError('Fake error')
        except NameError as e:
            raise TypeError('Fake error') from e
    except TypeError as e:
        assert get_exception() == e


# Generated at 2022-06-20 21:03:09.601532
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise ValueError("this is an error")

    try:
        raise_exception()
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == "this is an error"

# Unit tests for function literal_eval

# Generated at 2022-06-20 21:03:16.959147
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError', 'Got wrong exception: %s' % e

if __name__ == '__main__':
    for func in (test_get_exception,):
        print('Testing %s' % func)
        func()

# Generated at 2022-06-20 21:03:20.474905
# Unit test for function get_exception
def test_get_exception():
    def outer(b):
        try:
            inner(b)
        except ValueError as e:
            assert e is get_exception()
            return
        raise AssertionError('ValueError should be raised')

    def inner(b):
        if b:
            raise ValueError
        else:
            raise TypeError

    outer(True)

# Generated at 2022-06-20 21:03:24.247564
# Unit test for function get_exception
def test_get_exception():
    # Works in both 2.x and 3.x
    try:
        1/0
    except:
        exc = get_exception()
        if isinstance(exc, ZeroDivisionError):
            pass
        else:
            raise AssertionError('Expected ZeroDivisionError.  Got: {0}'.format(exc))

# Generated at 2022-06-20 21:03:25.497891
# Unit test for function get_exception

# Generated at 2022-06-20 21:04:40.804684
# Unit test for function get_exception
def test_get_exception():
    class AnException(Exception):
        def __init__(self, arg):
            self.arg = arg
    try:
        raise AnException('An argument')
    except AnException:
        e = get_exception()
        assert e.arg == 'An argument'


# Generated at 2022-06-20 21:04:47.627358
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    def raise_test_exception():
        raise TestException("An exception")

    try:
        raise_test_exception()
    except Exception:
        e = get_exception()

    assert isinstance(e, TestException)
    assert str(e) == "An exception"

# Generated at 2022-06-20 21:04:51.428063
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except Exception:
        e = get_exception()
    assert e.message == 'Test exception'


# Generated at 2022-06-20 21:04:59.999751
# Unit test for function get_exception
def test_get_exception():
    # This function is imported early when using get_exception
    # because it's needed to create the get_exception function.
    import traceback
    def testfunc():
        try:
            raise RuntimeError('test exception')
        except:
            # This is what we're testing:  We have to pull the exception out
            # of sys.
            e = get_exception()
            raise
    try:
        testfunc()
    except RuntimeError as e:
        assert 'test exception' == str(e), \
            "Could not pull exception out of sys.exc_info()"
    except Exception:
        assert False, \
            "Should only have received the exception raised by testfunc()"

# Generated at 2022-06-20 21:05:03.583479
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Exception 1")
    except Exception:
        e = get_exception()
        assert str(e) == "Exception 1"


# Generated at 2022-06-20 21:05:10.018589
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
    else:
        assert False, 'Division by zero should have raised an exception'
    assert isinstance(e, ZeroDivisionError)
    assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-20 21:05:11.091185
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing')
    except RuntimeError:
        pass

    assert get_exception().args == ('Testing',)

# Generated at 2022-06-20 21:05:13.731154
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        if get_exception() is not e:
            raise AssertionError("Expected %r, got %r" % (e, get_exception()))


# Generated at 2022-06-20 21:05:17.659552
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)


# Generated at 2022-06-20 21:05:20.514883
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Show me!')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('Show me!',)


# Generated at 2022-06-20 21:08:21.549973
# Unit test for function get_exception

# Generated at 2022-06-20 21:08:28.048498
# Unit test for function get_exception
def test_get_exception():
    try:
        def will_raise():
            raise ValueError('foo')
        will_raise()
        assert False
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert 'foo' in str(e)