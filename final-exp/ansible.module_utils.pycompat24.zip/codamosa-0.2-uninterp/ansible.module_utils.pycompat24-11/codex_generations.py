

# Generated at 2022-06-17 03:39:29.006443
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:39:30.485055
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('test',)


# Generated at 2022-06-17 03:39:33.095761
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:39:35.617113
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:39:40.251524
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-17 03:39:42.718045
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:39:44.811993
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-17 03:39:47.069913
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()


# Generated at 2022-06-17 03:39:50.120025
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:39:52.216298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:14.748223
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:40:20.842373
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:40:26.649781
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:29.986432
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'
    assert isinstance(e, ValueError)

# Generated at 2022-06-17 03:40:31.207000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-17 03:40:35.898165
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:40:38.397260
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:40:40.050272
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:40:41.932799
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)



# Generated at 2022-06-17 03:40:44.365372
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'test'


# Generated at 2022-06-17 03:41:30.174927
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:41:33.597279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:41:34.752854
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-17 03:41:37.222304
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert e.args == ('test',)


# Generated at 2022-06-17 03:41:40.070611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:41:43.676680
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert str(e) == 'test'


# Generated at 2022-06-17 03:41:46.296957
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:41:48.590057
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'

# Generated at 2022-06-17 03:41:50.951000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:41:54.129248
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:43:17.465849
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args == ('test',)

# Generated at 2022-06-17 03:43:19.208748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:43:21.090780
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'test exception'


# Generated at 2022-06-17 03:43:26.535053
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert e.args == ('test',)


# Generated at 2022-06-17 03:43:28.222531
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:43:29.942192
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-17 03:43:31.701090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:43:36.343424
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-17 03:43:39.156021
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:43:41.709603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:46:32.770471
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-17 03:46:35.464941
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:46:39.803560
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:46:41.796433
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:46:48.138947
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:46:53.285719
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
    assert str(e) == "Test exception"


# Generated at 2022-06-17 03:46:55.770777
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:46:57.688254
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:47:02.026644
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()

# Generated at 2022-06-17 03:47:07.193054
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)