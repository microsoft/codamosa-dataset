

# Generated at 2022-06-17 03:39:28.848407
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:39:31.688999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:39:34.414655
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:39:36.846327
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-17 03:39:39.130283
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-17 03:39:41.790499
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:39:45.628763
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-17 03:39:48.899329
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'test'


# Generated at 2022-06-17 03:39:51.195756
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:39:53.814064
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:13.263601
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:15.647111
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:40:19.435911
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except Exception:
        e = get_exception()
        assert e.args[0] == "This is a test"


# Generated at 2022-06-17 03:40:21.819223
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)



# Generated at 2022-06-17 03:40:26.912492
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:30.467820
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:40:32.605577
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:40:34.359203
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:40:36.853923
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:40:39.219041
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:41:25.285323
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:41:27.747505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:41:30.526572
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:41:33.544817
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:41:36.012383
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:41:38.686131
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:41:41.952206
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:41:44.595967
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:41:46.965669
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-17 03:41:49.104421
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-17 03:43:14.548044
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:43:17.880755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-17 03:43:19.413264
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:43:25.351805
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'This is a test'


# Generated at 2022-06-17 03:43:27.193249
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:43:29.244413
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:43:30.990489
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:43:35.235108
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-17 03:43:37.881555
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:43:40.258332
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:46:36.378605
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-17 03:46:39.990328
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'


# Generated at 2022-06-17 03:46:42.517716
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'test'


# Generated at 2022-06-17 03:46:48.213183
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:46:53.024079
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-17 03:46:54.851108
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-17 03:46:57.229246
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)
        assert str(e) == 'foo'


# Generated at 2022-06-17 03:47:02.703469
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-17 03:47:04.333117
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-17 03:47:08.183291
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'