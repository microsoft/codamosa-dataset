

# Generated at 2022-06-25 01:39:01.881463
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_0 = get_exception()



# Generated at 2022-06-25 01:39:04.080688
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
        assert False
    except Exception as e:
        assert len(e) == 0, "'get_exception' failed with 'e' = '{}'".format(e)



# Generated at 2022-06-25 01:39:06.272716
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if e == get_exception():
            assert True
        else:
            assert False


__all__ = ('get_exception', 'literal_eval')

# Generated at 2022-06-25 01:39:10.434339
# Unit test for function get_exception
def test_get_exception():
    try:
        assert test_case_0.__name__ == 'test_case_0'
        raise Exception()
    except Exception as e:
        assert e.__name__ == 'Exception'
        assert e.args == ()

# Generated at 2022-06-25 01:39:17.445372
# Unit test for function get_exception
def test_get_exception():
    print("IN TEST")
    try:
        raise NameError("Hi there")
    except NameError:
        result = get_exception()
        assert result.args[0] == "Hi there"



# Generated at 2022-06-25 01:39:20.925343
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert type(e) is NameError



# Generated at 2022-06-25 01:39:24.948712
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert get_exception() == e



# Generated at 2022-06-25 01:39:26.424450
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()



# Generated at 2022-06-25 01:39:27.555127
# Unit test for function get_exception
def test_get_exception():
    # assert func_0 works correctly
    try:
        var_0 = test_case_0()
    except:
        var_0 = get_exception()
    assert True is not var_0



# Generated at 2022-06-25 01:39:30.991914
# Unit test for function get_exception
def test_get_exception():
    my_int = 2
    try:
        assert(my_int == 3)
    except Exception:
        e = get_exception()

    assert(e.args[0] == "assert 2 == 3")


# Generated at 2022-06-25 01:39:40.791968
# Unit test for function get_exception
def test_get_exception():
    try:
        raise
    except:
        e = get_exception()
        assert(str(e) == "")


# Generated at 2022-06-25 01:39:45.197259
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        var_0 = get_exception()
    assert var_0.args[0] == 'test'



# Generated at 2022-06-25 01:39:46.071881
# Unit test for function get_exception
def test_get_exception():
    test_case_0()



# Generated at 2022-06-25 01:39:54.359836
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleAssertionError
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    ## fail
    # we do not use assert_raises here because it will catch the
    # exceptions raised by mark slices in py

# Generated at 2022-06-25 01:39:58.798037
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception("Foo")
    except:
        e = get_exception()

    assert isinstance(e, Exception)
    assert e.args == ("Foo",)
    assert str(e) == "Foo"


# Generated at 2022-06-25 01:40:00.595884
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        try:
            assert isinstance(get_exception(), Exception)
        except AssertionError:
            raise AssertionError()


# Generated at 2022-06-25 01:40:04.031888
# Unit test for function get_exception
def test_get_exception():

    # Run the task with a couple different module parameters and make sure we get
    # expected results
    with pytest.raises(Exception):
        test_case_0()

    # Make sure that the exception is passed back and isn't swallowed
    assert var_0 is not None
    assert isinstance(var_0, Exception)


# Generated at 2022-06-25 01:40:05.875833
# Unit test for function get_exception
def test_get_exception():
    # Ensure exception is raised for parameters out of valid range
    with pytest.raises(ValueError):
        test_case_0()
        assert True # no Exception thrown, so we pass

# Generated at 2022-06-25 01:40:11.299904
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass
    except Exception:
        print(
            "Raised exception as expected:\n{}".format(
                get_exception()
            )
        )
    test_case_0()



# Generated at 2022-06-25 01:40:13.876482
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import _test_exception

    try:
        test_case_0()
    except:
        actual = get_exception()
    expected = _test_exception

    assert actual == expected


# Generated at 2022-06-25 01:40:29.136954
# Unit test for function get_exception
def test_get_exception():
    import sys, os.path
    import ansible.utils
    import ansible.utils.template

    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(test_dir, 'lib'))
    from test_utils import *

    test_case_0()


# Generated at 2022-06-25 01:40:29.673662
# Unit test for function get_exception
def test_get_exception():
    x = get_exception()


# Generated at 2022-06-25 01:40:31.973287
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()
        print(e) # python3's print is a function
        print(str(e))

# Generated at 2022-06-25 01:40:34.559836
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        try:
            assert(var_0 == e)
        except ImportError as e:
            pass

var_1 = literal_eval('True')


# Generated at 2022-06-25 01:40:39.540622
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if not isinstance(e, AssertionError) and not isinstance(e, TypeError) and not isinstance(e, NameError):
            raise e
    else:
        raise AssertionError

if __name__ == '__main__':
    try:
        test_get_exception()
    except Exception as e:
        if not isinstance(e, AssertionError) and not isinstance(e, TypeError) and not isinstance(e, NameError):
            raise e
    else:
        raise AssertionError

# Generated at 2022-06-25 01:40:41.645432
# Unit test for function get_exception
def test_get_exception():
    try:
        print('running test_case_0')
        test_case_0()
    except Exception as exc:
        print('Exception: ', exc)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:40:43.499871
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0

# Generated at 2022-06-25 01:40:47.598747
# Unit test for function get_exception
def test_get_exception():
    # Try this
    try:
        test_case_0()
    # Catch that exception
    except:
        got = get_exception()
        if type(got) is not NameError:
            raise AssertionError("get_exception got: %s expected: %s" % (type(got), type(NameError)))

# Generated at 2022-06-25 01:40:48.550307
# Unit test for function get_exception
def test_get_exception():
    assert False # This function cannot be tested easily


# Generated at 2022-06-25 01:40:50.447956
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None


# Generated at 2022-06-25 01:41:09.901058
# Unit test for function get_exception
def test_get_exception():
  assert test_case_0() == None

# Generated at 2022-06-25 01:41:14.441883
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        (e) = get_exception()

        # Check type of the returned object
        assert type(e) == NameError

        # Check value of the returned object
        assert e.args[0] == 'global name \'get_exception\' is not defined'

# Generated at 2022-06-25 01:41:17.231203
# Unit test for function get_exception
def test_get_exception():
    # Define some inputs
    try:
        raise TypeError
    except TypeError:
        get_exception()
        e = get_exception()
        assert True
    return


# Generated at 2022-06-25 01:41:18.420255
# Unit test for function get_exception
def test_get_exception():
    assert 0 == test_case_0()


# Generated at 2022-06-25 01:41:20.694840
# Unit test for function get_exception
def test_get_exception():
    try:
      raise Exception
    except Exception:
      e = get_exception()

    assert type(e) == Exception


# Generated at 2022-06-25 01:41:21.232838
# Unit test for function get_exception
def test_get_exception():
    assert True

# Generated at 2022-06-25 01:41:22.295936
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        raise AssertionError('get_exception() failed')
    else:
        pass



# Generated at 2022-06-25 01:41:25.003877
# Unit test for function get_exception
def test_get_exception():
    for input_value in [0, 1, 2]:
        for output_value in [0, 1, 2]:
            assert (test_case_0(input_value) == output_value)
            print("Test case passed!")


# Generated at 2022-06-25 01:41:26.938045
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError()
    except TypeError:
        x = get_exception()
    assert isinstance(x, TypeError)


# Generated at 2022-06-25 01:41:27.960643
# Unit test for function get_exception
def test_get_exception():
    pass
        # AssertionError: No exception thrown


# Generated at 2022-06-25 01:42:03.993331
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception")
    except Exception:
        var_1 = get_exception()
    assert var_1.message == "test exception"
    assert type(var_1) is Exception

# Test for literal_eval

# Generated at 2022-06-25 01:42:04.622095
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert True

# Generated at 2022-06-25 01:42:05.417261
# Unit test for function get_exception
def test_get_exception():
    assert('get_exception' in globals())

# Generated at 2022-06-25 01:42:07.700530
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert(e != None)
    else:
        assert(False)


# Generated at 2022-06-25 01:42:14.366877
# Unit test for function get_exception

# Generated at 2022-06-25 01:42:23.096770
# Unit test for function get_exception
def test_get_exception():
    try:
        # Unknown exception
        raise Exception('Some Exception')
    except Exception:
        ex = get_exception()
    if ex:
        assert isinstance(ex, Exception)
        assert ex.message == 'Some Exception'
        assert str(ex) == 'Some Exception'

    assert literal_eval('[1,2,3]') == [1,2,3]
    assert literal_eval('[1, [2,3]]') == [1, [2,3]]
    assert literal_eval('{1:2, 3:4}') == {1:2, 3:4}
    assert literal_eval('{1:2, 3: {4:5}}') == {1:2, 3: {4:5}}

# Generated at 2022-06-25 01:42:23.864624
# Unit test for function get_exception
def test_get_exception():
    pass

# Generated at 2022-06-25 01:42:25.942026
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        ret_0 = get_exception()
    assert ret_0 == var_0



# Generated at 2022-06-25 01:42:27.511222
# Unit test for function get_exception
def test_get_exception():

    # Test function with no arguments
    assert get_exception() is None

# Generated at 2022-06-25 01:42:34.410780
# Unit test for function get_exception
def test_get_exception():

    # Run test case 0
    try:
        1 / 0
    except Exception:
        var_0 = get_exception()
        assert type(var_0) == ZeroDivisionError, 'unexpected type: {0}'.format(type(var_0))

    # Run test case 1
    try:
        var_0 = text_type(1)
        1 / 0
    except Exception:
        var_0 = get_exception()
        assert type(var_0) == ZeroDivisionError, 'unexpected type: {0}'.format(type(var_0))


# Generated at 2022-06-25 01:43:49.182460
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert e.message == "global name 'test_case_0' is not defined"

# Generated at 2022-06-25 01:43:54.321669
# Unit test for function get_exception
def test_get_exception():
    var_0 = 1 + 2
    try:
        raise Exception('test')
    except:
        var_0 = get_exception()
    assert isinstance(var_0, Exception)
    assert var_0.args[0] == 'test'



# Generated at 2022-06-25 01:43:55.477196
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(NameError): test_case_0()


# Generated at 2022-06-25 01:43:58.424526
# Unit test for function get_exception
def test_get_exception():
    try:
        test_func()
    except Exception:
        test_var = get_exception()

    assert len(test_var) > 0



# Generated at 2022-06-25 01:44:01.894872
# Unit test for function get_exception
def test_get_exception():
    # Given the argument var_0
    var_0 = 0
    # When we call the function with arguments var_0
    try:
        test_case_0(var_0)
    except:
        var_ret = get_exception()
        # Then var_ret == "blah"
        assert var_ret == "blah"


# Generated at 2022-06-25 01:44:09.615193
# Unit test for function get_exception
def test_get_exception():
    assert not get_exception(), "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"
    assert not get_exception(), "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"
    assert not get_exception(), "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"
    assert get_exception() == None, "Failed: get_exception()"

# Generated at 2022-06-25 01:44:13.764425
# Unit test for function get_exception
def test_get_exception():
    # FIXME: Implement a unit test
    assert True == True


# Generated at 2022-06-25 01:44:16.464106
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        var_0 = get_exception()
        assert type(var_0) == type(Exception('test exception'))
        assert var_0.__str__() == 'test exception'



# Generated at 2022-06-25 01:44:19.223491
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert get_exception() is e


# Generated at 2022-06-25 01:44:20.661283
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    print(var_0)


# Generated at 2022-06-25 01:47:24.826097
# Unit test for function get_exception
def test_get_exception():
    try:
        pass

    except:
        assert_equal(var_0, var_0)


# Generated at 2022-06-25 01:47:29.363828
# Unit test for function get_exception
def test_get_exception():
    test_case = {
        'name': '0',
        'inputs': [],
        'want': None
    }

    res = test_case_0()
    got = literal_eval(res)
    assert got == test_case['want'], 'Test Failed: expected {}, got {}'.format(test_case['want'], got)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:47:33.443614
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as exc:
        assert exc.__class__.__name__ == 'AssertionError'
    else:
        assert False


# Generated at 2022-06-25 01:47:34.654497
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = get_exception()
    except e:
        var_0 = e


# Generated at 2022-06-25 01:47:37.273779
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0

# Generated at 2022-06-25 01:47:39.688340
# Unit test for function get_exception
def test_get_exception():
    # Run assertion checks
    try:
        raise Exception('123')
    except Exception:
        var_0 = get_exception()
        assert str(var_0) == '123'


# Generated at 2022-06-25 01:47:41.378918
# Unit test for function get_exception
def test_get_exception():
    var_1 = True
    try:
        test_case_0()
        var_1 = False
    except Exception:
        var_0 = get_exception()


# Generated at 2022-06-25 01:47:45.173560
# Unit test for function get_exception
def test_get_exception():
    try:
        literal_eval(1)
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-25 01:47:47.160783
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:   # pylint: disable=broad-except
        assert e.args == ()


# Generated at 2022-06-25 01:47:49.841565
# Unit test for function get_exception
def test_get_exception():
    # Test with default args
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, AssertionError)
