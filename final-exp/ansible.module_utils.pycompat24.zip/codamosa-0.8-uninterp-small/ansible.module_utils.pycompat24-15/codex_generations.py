

# Generated at 2022-06-25 01:38:57.622400
# Unit test for function get_exception
def test_get_exception():
    
    assert literal_eval('True') is True
    assert literal_eval('False') is False
    assert literal_eval('1') == 1
    assert literal_eval('1.0') == 1.0
    assert literal_eval('1j') == 1j
    assert literal_eval('"a"') == "a"
    assert literal_eval("'a'") == "a"
    assert literal_eval("u'a'") == "a"
    assert literal_eval('"\\u00e9"'.decode('unicode_escape')) == "\u00e9"
    assert literal_eval('u"\\u00e9"') == "\u00e9"
    assert literal_eval('"foo" "bar"') == "foobar"

# Generated at 2022-06-25 01:38:58.492355
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except AttributeError:
        pass



# Generated at 2022-06-25 01:39:06.220226
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        e_0 = e
    var_0 = get_exception()
    if isinstance(e_0, var_0.__class__):
        r_0 = True
    else:
        r_0 = False
    return r_0


# Generated at 2022-06-25 01:39:09.853248
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert get_exception() is not None
    else:      
        assert False


# Generated at 2022-06-25 01:39:12.510620
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert e.__class__.__name__ == 'NameError'
        assert e.__str__() == "global name 'test_case_0' is not defined"


# Generated at 2022-06-25 01:39:15.412285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        var_0 = get_exception()
    assert True



# Generated at 2022-06-25 01:39:17.419819
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()



# Generated at 2022-06-25 01:39:22.525409
# Unit test for function get_exception
def test_get_exception():
    try:
        result = get_exception()
    except Exception as e:
        print("Caught error: {0}".format(e))
        print("Failed!")
        raise e
    else:
        print("Success!")
        return result


# Generated at 2022-06-25 01:39:25.367359
# Unit test for function get_exception

# Generated at 2022-06-25 01:39:30.578510
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
        print(var_0.__class__.__name__)



# Generated at 2022-06-25 01:39:51.720370
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        e = get_exception()
        try:
            assert e.message == 'test_case_0'
            assert e.args == ('test_case_0',)
        except NameError: # Python 3
            assert str(e) == 'test_case_0'
            assert e.args == ('test_case_0',)



# Generated at 2022-06-25 01:39:55.344339
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass
    else:
        assert False



# Generated at 2022-06-25 01:39:56.476643
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
        assert var_0 is None
    except:
        var_0 = get_exception()
        raise var_0



# Generated at 2022-06-25 01:39:59.065056
# Unit test for function get_exception
def test_get_exception():
    # Create an instance of the class
    var_0 = get_exception()
    try:
        1/0
    except:
        assert var_0 == get_exception()



# Generated at 2022-06-25 01:40:00.422404
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except AssertionError as e:
        print (e)


# Generated at 2022-06-25 01:40:03.013208
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exc_type, exc_val, exc_tb = sys.exc_info()
        assert type(get_exception()) is type(exc_val)


# Generated at 2022-06-25 01:40:04.913477
# Unit test for function get_exception
def test_get_exception():
    # Check that calling the get_exception function is supported
    try:
        test_case_0()
    except NameError:
        pass



# Generated at 2022-06-25 01:40:15.341559
# Unit test for function get_exception
def test_get_exception():
    var_1 = literal_eval('none')
    var_2 = get_exception()
    var_3 = var_1
    var_4 = var_1
    var_5 = get_exception()
    var_6 = var_1
    var_7 = get_exception()
    test_case_0()
    test_1 = var_1
    test_2 = var_2
    test_3 = var_3
    test_4 = var_4
    test_5 = var_5
    test_6 = var_6
    test_7 = var_7
    
    
    
    
    

if __name__ == "__main__":

    test_get_exception()

    print('Success: test_get_exception')


# pylint: disable=too-many-

# Generated at 2022-06-25 01:40:16.184600
# Unit test for function get_exception
def test_get_exception():
    assert True


# Generated at 2022-06-25 01:40:17.904834
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = get_exception()
    except NameError:
        var_0 = get_exception()



# Generated at 2022-06-25 01:40:35.938306
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        var_1 = e
    
    assert var_1.__class__.__name__ == 'NameError'

# Generated at 2022-06-25 01:40:41.353001
# Unit test for function get_exception
def test_get_exception():
    # Testing for Exception
    try:
        test_case_0()
    except:
        e = get_exception()
        # Make sure we got an Exception
        assert(str(type(e)) == "<class 'Exception'>")

# Generated at 2022-06-25 01:40:44.856776
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    # Raise the exception again
    raise var_0


# Generated at 2022-06-25 01:40:49.246918
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(Exception) as exc_info:
        raise ValueError('test_get_exception__value_error')
    assert exc_info.value.args[0] == 'test_get_exception__value_error'
    value = get_exception()
    assert isinstance(value, ValueError)
    assert value.args[0] == 'test_get_exception__value_error'
    assert value.message == 'test_get_exception__value_error'



# Generated at 2022-06-25 01:40:52.698353
# Unit test for function get_exception
def test_get_exception():
    # Setup test case
    try:
        test_case_0()
    except NotImplementedError:
        pass

    # Verify results
    raise NotImplementedError()

# Generated at 2022-06-25 01:40:58.875571
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()
        print(str(e.__class__))
        print(str(e))
        print(str(get_exception()))


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:41:01.246952
# Unit test for function get_exception
def test_get_exception():
    """Mock test"""
    print('Running tests for feature get_exception')
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    assert "No tests available for feature get_exception" in str(excinfo.value)

# Generated at 2022-06-25 01:41:07.432591
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('hi')
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == 'hi'
    assert sys.exc_info()[1] is e


# Generated at 2022-06-25 01:41:09.974852
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:41:16.413425
# Unit test for function get_exception
def test_get_exception():
    var_0 = 1
    var_1 = 1
    try:
        var_1 = 1/0
    except ZeroDivisionError:
        var_0 = get_exception()
    if var_0.__class__.__name__ != 'ZeroDivisionError' or var_0.args != ('integer division or modulo by zero',):
        raise AssertionError("result of get_exception() call did not match the expected declaration")
    if var_1 != 1:
        raise AssertionError("result of get_exception() call did not match the expected declaration")


# Generated at 2022-06-25 01:42:00.447219
# Unit test for function get_exception
def test_get_exception():
    try:
        assert literal_eval(None) == None
    except AssertionError:
        return False
    try:
        assert literal_eval(True) == True
    except AssertionError:
        return False
    try:
        assert literal_eval(False) == False
    except AssertionError:
        return False
    try:
        assert literal_eval(1) == 1
    except AssertionError:
        return False
    try:
        assert literal_eval(1.0) == 1.0
    except AssertionError:
        return False
    try:
        assert literal_eval(1j) == 1j
    except AssertionError:
        return False
    try:
        assert literal_eval(2**256) == 2**256
    except AssertionError:
        return False


# Generated at 2022-06-25 01:42:02.212824
# Unit test for function get_exception
def test_get_exception():
    # Inject an exception, catch it and make sure it's in str form
    try:
        raise ValueError('test')
    except:
        test_case_0()


# Generated at 2022-06-25 01:42:04.727091
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        exception_0 = get_exception()
        assert(str(exception_0) == "name 'get_exception' is not defined")


# Generated at 2022-06-25 01:42:07.025450
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as var_0:
        assert '<class \'Exception\'>' == repr(var_0)



# Generated at 2022-06-25 01:42:12.572229
# Unit test for function get_exception
def test_get_exception():
    # Make sure we can catch the exception
    try:
        test_case_0()
    except:
        # Make sure that the exception is the same
        return True
    # If we don't catch the exception then it is wrong
    return False



# Generated at 2022-06-25 01:42:19.206855
# Unit test for function get_exception

# Generated at 2022-06-25 01:42:21.655907
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()



# Generated at 2022-06-25 01:42:26.876761
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        pass
    var_0 = get_exception()
    assert isinstance(var_0, ValueError)
    pass



# Generated at 2022-06-25 01:42:27.839895
# Unit test for function get_exception
def test_get_exception():
    assert None == get_exception()



# Generated at 2022-06-25 01:42:32.876214
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exc_type, exc_value, traceback = sys.exc_info()
        print("\x1b[1;31mUnhandled exception:\x1b[0m")
        print("Type: \t%s" % exc_type)
        print("Value: \t%s" % exc_value)
        print("Traceback:")
        import traceback
        print("".join(traceback.format_tb(traceback)))



# Generated at 2022-06-25 01:43:52.852014
# Unit test for function get_exception

# Generated at 2022-06-25 01:43:55.474288
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
        assert repr(e) == 'RuntimeError(\'foo\',)'
        assert e.__doc__ == 'No detailed description available.'


# Generated at 2022-06-25 01:43:56.919412
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()



# Generated at 2022-06-25 01:43:58.191100
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception() for correct output for various inputs"""
    test_case_0()


# Generated at 2022-06-25 01:43:59.351627
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:44:01.894560
# Unit test for function get_exception
def test_get_exception():

    try:
        test_case_0()
    except Exception as e:
        # We accept the exception being a string as documentation indicates it can be
        assert e == 'This is an exception' or e == 'This is a warning'
    except KeyboardInterrupt:
        pass


# Generated at 2022-06-25 01:44:07.911806
# Unit test for function get_exception
def test_get_exception():
    import sys
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    path = ['/path/to/ansible', '/mock', '/module/utils']
    for p in path:
        sys.path.insert(0, p)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import missing_required_lib

    import ansible.module_utils.pycompat24

    if missing_required_lib('test_utils', 'test_get_exception'):
        try:
            raise Exception("pip install -U test_utils")
        except:
            pass


# Generated at 2022-06-25 01:44:12.974360
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        # exc_info will be the tuple (exception_type, exception, traceback)
        # for the exception that was raised
        exc_info = get_exception()



# Generated at 2022-06-25 01:44:16.125501
# Unit test for function get_exception
def test_get_exception():
    # Place your test here
    a_1 = (test_case_0, literal_eval)

    # This is a pretty weak test -- so weak, in fact, it doesn't really
    # test anything.  find a better way to test this
    assert a_1[0]() == None

# Generated at 2022-06-25 01:44:18.319098
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(AttributeError, message='test with exception') as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == AttributeError


# Generated at 2022-06-25 01:47:21.895063
# Unit test for function get_exception

# Generated at 2022-06-25 01:47:24.188537
# Unit test for function get_exception
def test_get_exception():
    try:
        # Test function call with different arguments:
        var_0 = get_exception()
        assert var_0 is None
    except:
        assert False, "Unexpected error!"


# Generated at 2022-06-25 01:47:25.414221
# Unit test for function get_exception
def test_get_exception():
    assert_equal(test_case_0(), ())


# Generated at 2022-06-25 01:47:33.973212
# Unit test for function get_exception
def test_get_exception():
    try:
        foo1 = open("foo1.txt")
    except:
        var_0 = get_exception()
        var_1 = "var_1"
        var_2 = "var_2"
        var_3 = "var_3"
        var_4 = "var_4"
        var_5 = "var_5"
        var_6 = "var_6"
        var_7 = "var_7"
        var_8 = "var_8"
        var_9 = "var_9"
        var_10 = "var_10"
        var_11 = "var_11"
        var_12 = "var_12"
        var_13 = "var_13"
        var_14 = "var_14"
        var_15 = "var_15"
        var_

# Generated at 2022-06-25 01:47:37.003197
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()



# Generated at 2022-06-25 01:47:38.406075
# Unit test for function get_exception
def test_get_exception():
    var_1 = test_case_0()
    return var_1



# Generated at 2022-06-25 01:47:41.112432
# Unit test for function get_exception
def test_get_exception():
    print("IN TEST")
    try:
        test_case_0()
    except:
        print("IN EXCEPT")
        var_0 = get_exception()

        for k, v in var_0.__dict__.items():
            print("%s: %s", (k, v))
        print("finished")



# Generated at 2022-06-25 01:47:44.944259
# Unit test for function get_exception

# Generated at 2022-06-25 01:47:46.681870
# Unit test for function get_exception
def test_get_exception():
    expected_result = RuntimeError()
    assert expected_result == var_0
    assert expected_result == actual_result


# Generated at 2022-06-25 01:47:48.825235
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert var_0 == e
