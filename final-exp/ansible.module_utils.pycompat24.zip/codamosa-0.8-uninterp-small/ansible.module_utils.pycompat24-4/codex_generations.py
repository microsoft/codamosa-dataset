

# Generated at 2022-06-25 01:39:02.066463
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-25 01:39:08.493039
# Unit test for function get_exception
def test_get_exception():
    try:
        assert (get_exception(var_0) is None), "The expression did not evaluate to True : test_get_exception"
    except UnboundLocalError as e:
        # What happens if we try to access an undefined variable?
        print (e)
    except LookupError as e:
        # What happens if we try to access a non-existant key in a dictionary?
        print (e)
    except TypeError as e:
        # What happens if we try to access a non-existant attribute in a class?
        print (e)
    except NameError as e:
        # What happens if we try to access a non-existant function?
        print (e)

# Generated at 2022-06-25 01:39:10.684185
# Unit test for function get_exception
def test_get_exception():
    # Test function get_exception
    try:
        test_case_0()
    except Exception:
        e = get_exception()
    assert e is not None
    assert isinstance(e, Exception)


# Generated at 2022-06-25 01:39:12.742996
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
        assert var_0 is not None


# Generated at 2022-06-25 01:39:13.715910
# Unit test for function get_exception
def test_get_exception():
    var_1 = get_exception()


# Generated at 2022-06-25 01:39:15.515140
# Unit test for function get_exception
def test_get_exception():
    # Test with the arguments given above for get_exception
    test_case_0()



# Generated at 2022-06-25 01:39:18.656942
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert e.__class__ is RuntimeError
    assert str(e) == 'test'


# Generated at 2022-06-25 01:39:23.561410
# Unit test for function get_exception
def test_get_exception():
    # this will raise a NameError because b does not exist
    try:
        print(b)
    except:
        e = get_exception()
        assert e.__class__.__name__ == 'NameError'
        assert str(e) == "name 'b' is not defined"



# Generated at 2022-06-25 01:39:24.927884
# Unit test for function get_exception
def test_get_exception():
    # Test case
    test_case_1()

    # Test case
    test_case_0()

# Generated at 2022-06-25 01:39:33.101130
# Unit test for function get_exception
def test_get_exception():
    func_ret_val = None

    try:
        test_case_0()
    except:
        func_ret_val = get_exception()
    finally:
        assert func_ret_val is not None, 'get_exception() returned None, expected exception'
        assert type(func_ret_val) is NameError, 'get_exception() returned %s, expected NameError' % type(func_ret_val)
        assert func_ret_val.message == 'global name \'test_case_0\' is not defined', 'get_exception() returned exception with message %s, expected exception with message \'global name \'test_case_0\' is not defined\'' % func_ret_val.message



# Generated at 2022-06-25 01:39:51.641246
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
        assert False
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-25 01:39:57.036260
# Unit test for function get_exception
def test_get_exception():
    # Given an exception
    # When a function is called
    # Then the exception should be returned
    try:
        test_case_0()
    except:
        pass


# Generated at 2022-06-25 01:39:58.937209
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass


# Generated at 2022-06-25 01:40:01.489922
# Unit test for function get_exception

# Generated at 2022-06-25 01:40:12.583191
# Unit test for function get_exception
def test_get_exception():
    # Define a class
    class test_exception(Exception):
        pass
    # Assign exception to local variable
    try:
        raise test_exception
    except test_exception:
        exc = get_exception()

    # Check attributes
    assert isinstance(exc, test_exception)
    assert exc.args == ()

    # Check that the exception hasn't been cleared out of sys.exc_info()
    assert isinstance(sys.exc_info()[1], test_exception)
    assert sys.exc_info()[1].args == ()

    # Check that we can assign to the exception and clear it from sys.exc_info()
    try:
        raise test_exception
    except test_exception:
        exc = get_exception()
        # Do something with the exception

# Generated at 2022-06-25 01:40:14.267676
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()
    assert e is not None


# Generated at 2022-06-25 01:40:17.183590
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
        result_0 = True
    except NameError:
        result_0 = False
    assert result_0 == False, "func `get_exception` did not catch exception"


# Generated at 2022-06-25 01:40:19.549253
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_0 = e

    if isinstance(var_0, Exception):
        print("Success")
    else:
        print("Exception fail")


# Generated at 2022-06-25 01:40:20.684344
# Unit test for function get_exception
def test_get_exception():

    assert(isinstance(get_exception(), Exception))


# Generated at 2022-06-25 01:40:26.197712
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        var_0 = get_exception()
        assert(str(var_0.__class__) == '<class \'ZeroDivisionError\'>')


# Generated at 2022-06-25 01:41:01.079614
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert(e.args == ())

# Generated at 2022-06-25 01:41:05.721173
# Unit test for function get_exception
def test_get_exception():
    test_exception_class = Exception

# Generated at 2022-06-25 01:41:07.842696
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_1 = get_exception()



# Generated at 2022-06-25 01:41:11.237902
# Unit test for function get_exception
def test_get_exception():
    assert 1 == 1
    assert 1 != 2
    assert test_case_0() == None


# Generated at 2022-06-25 01:41:14.558459
# Unit test for function get_exception
def test_get_exception():

# Test function get_exception

    pass


# Generated at 2022-06-25 01:41:16.985031
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0=5/0
    except Exception:
        var_1 = get_exception()
    if var_1:
        return True


# Generated at 2022-06-25 01:41:19.612124
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Can't do that")
    except:
        var_0 = get_exception()
    finally:
        assert var_0 == var_0


# Generated at 2022-06-25 01:41:22.080881
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-25 01:41:24.419341
# Unit test for function get_exception
def test_get_exception():
    if (__name__ == '__main__'):
        test_case_0()


# Generated at 2022-06-25 01:41:27.744556
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass


# Generated at 2022-06-25 01:42:08.132251
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert e.args[0] == "global name 'variable_that_does_not_exist_0' is not defined"
        assert e.__class__.__name__ == "NameError"
    except Exception as e:
        pytest.fail("Wrong exception was raised, expected {0} but got {1}".format("NameError", e.__class__.__name__))
    else:
        pytest.fail("No exception was raised, but there should have been")


# Generated at 2022-06-25 01:42:12.401517
# Unit test for function get_exception
def test_get_exception():
    var_1 = ''
    try:
        test_case_0()
    except:
        var_1 = get_exception()
    assert type(var_1) == ValueError


# Generated at 2022-06-25 01:42:17.551222
# Unit test for function get_exception

# Generated at 2022-06-25 01:42:22.918541
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'test'


# Generated at 2022-06-25 01:42:26.549788
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except AssertionError as ae:
        print('AssertionError: %s' % str(ae))
        raise ae
    except BaseException as be:
        print('BaseException: %s' % str(be))
        raise be
    else:
        print('No exception raised')


# Generated at 2022-06-25 01:42:28.669224
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = 1.0 / 0.0
    except Exception:
        exc_0 = get_exception()
        assert exc_0 is not None


# Generated at 2022-06-25 01:42:34.738264
# Unit test for function get_exception
def test_get_exception():
    # Test for negative int
    try:
        test_case_0()
    except Exception as e:
        assert e is not None



# Generated at 2022-06-25 01:42:35.764854
# Unit test for function get_exception
def test_get_exception():
    print('test_get_exception')
    test_case_0()

# Generated at 2022-06-25 01:42:36.593333
# Unit test for function get_exception
def test_get_exception():
    pass


# Generated at 2022-06-25 01:42:41.249401
# Unit test for function get_exception
def test_get_exception():
    # Test function get_exception
    try:
        test_case_0()
    except ZeroDivisionError:
        e = get_exception()
        assert e.args == ('integer division or modulo by zero',)



# Generated at 2022-06-25 01:43:57.580464
# Unit test for function get_exception
def test_get_exception():
    assert 1 == 1


# Generated at 2022-06-25 01:43:59.352222
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()
        assert e.args == ()


# Generated at 2022-06-25 01:44:00.329627
# Unit test for function get_exception
def test_get_exception():
    pass



# Generated at 2022-06-25 01:44:03.899777
# Unit test for function get_exception

# Generated at 2022-06-25 01:44:05.012178
# Unit test for function get_exception
def test_get_exception():
    # get_exception() return value is undefined
    assert test_case_0() == None


# Generated at 2022-06-25 01:44:06.886530
# Unit test for function get_exception
def test_get_exception():
    var_1 = get_exception()

    # Tested on python2.7
    assert var_1 is None, "Expected None but saw {0}".format(var_1)


# Generated at 2022-06-25 01:44:09.753584
# Unit test for function get_exception
def test_get_exception():
    # Use function 'get_exception' to get the current exception
    assert test_case_0() == NameError



# Generated at 2022-06-25 01:44:17.867104
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        var_0 = get_exception()
        assert(isinstance(var_0, RuntimeError))
    try:
        raise NotImplementedError
    except NotImplementedError:
        var_0 = get_exception()
        assert(isinstance(var_0, NotImplementedError))
    try:
        raise ZeroDivisionError
    except ZeroDivisionError:
        var_0 = get_exception()
        assert(isinstance(var_0, ZeroDivisionError))


# Generated at 2022-06-25 01:44:19.080142
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils import basic

    assert test_case_0() == None


# Generated at 2022-06-25 01:44:20.749609
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        _err = get_exception()
    assert _err



# Generated at 2022-06-25 01:47:25.888525
# Unit test for function get_exception
def test_get_exception():
    assert False

super_power = literal_eval


# Generated at 2022-06-25 01:47:28.019280
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        test_case_result = get_exception()
    assert test_case_result.code == 1


# Generated at 2022-06-25 01:47:30.202816
# Unit test for function get_exception
def test_get_exception():
    var_1 = None
    try:
        test_case_0()
    except Exception:
        var_1 = get_exception()
    finally:
        assert var_1



# Generated at 2022-06-25 01:47:32.468659
# Unit test for function get_exception

# Generated at 2022-06-25 01:47:35.019462
# Unit test for function get_exception
def test_get_exception():
    # Assert if get_exception returns an exception
    try:
        test_case_0()
    except ValueError as e:
        assert e


# Generated at 2022-06-25 01:47:39.085051
# Unit test for function get_exception
def test_get_exception():

    # Test case 0
    if True == True:
        var_0 = test_case_0()
        assert var_0 == None
    var_0 = get_exception()
    assert var_0 == None



# Generated at 2022-06-25 01:47:43.848428
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_1 = type(e)
        if var_1 is not AssertionError:
            print("Expected AssertionError. Got: " + repr(var_1))
            raise e


# Generated at 2022-06-25 01:47:45.515633
# Unit test for function get_exception
def test_get_exception():

    # Check the return value of function get_exception
    assert not test_case_0()


# Generated at 2022-06-25 01:47:50.249326
# Unit test for function get_exception
def test_get_exception():
    try:
        var_1 = get_exception()
    except NameError:
        # This test is spitting out warnings because we're ignoring the exception
        # being raised until Python 3.x has a better way of testing for the presence
        # of warnings.  In the meantime, a successful test of get_exception will
        # look like::

        # $ python2.7 test_get_exception.py
        # .
        # ----------------------------------------------------------------------
        # Ran 1 test in 0.000s
        #
        # OK
        pass


# Generated at 2022-06-25 01:47:56.035677
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise IndexError()
        except IndexError:
            exception = get_exception()
            assert(isinstance(exception, IndexError))
    except:
        exception = get_exception()
        assert(isinstance(exception, AssertionError))
