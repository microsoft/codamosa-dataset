

# Generated at 2022-06-25 01:38:56.468349
# Unit test for function get_exception
def test_get_exception():
    """Compares returned object with object returned by sys.exc_info()
    """
    test_case_0()
    assert literal_eval((var_0)) == literal_eval(sys.exc_info()[1])


# Generated at 2022-06-25 01:39:02.761879
# Unit test for function get_exception
def test_get_exception():
    # Test with bogus input
    try:
        var_0 = get_exception()
    except:
        try:
            assert False
        except AssertionError:
            pass
    else:
        raise AssertionError('ExpectedError')


# Generated at 2022-06-25 01:39:09.144521
# Unit test for function get_exception
def test_get_exception():
    import unittest2 as unittest
    from ansible.module_utils import module_dist_utils

# Generated at 2022-06-25 01:39:11.408134
# Unit test for function get_exception
def test_get_exception():
    # AssertionError raised
    try:
        test_case_0()
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-25 01:39:18.152187
# Unit test for function get_exception
def test_get_exception():
    # Try to get the current exception using get_exception

    ##
    # 

    try:
        # call to user-supplied function or class
        var_1 = test_case_0()
    except:
        var_1 = get_exception()

    assert var_1 is not None

# Generated at 2022-06-25 01:39:20.419554
# Unit test for function get_exception
def test_get_exception():
    # No test case so far
    pass


# Generated at 2022-06-25 01:39:24.922486
# Unit test for function get_exception
def test_get_exception():
    
    try:
        test_case_0()
    except:
        assert get_exception()
    

# Generated at 2022-06-25 01:39:26.379026
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None


# Generated at 2022-06-25 01:39:27.612415
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert True


# Generated at 2022-06-25 01:39:28.509314
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except:
        test_case_0()



# Generated at 2022-06-25 01:39:38.965873
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()

# Generated at 2022-06-25 01:39:40.757911
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()



# Generated at 2022-06-25 01:39:46.194454
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
    assert var_0.args[0] == "name 'test_case_0' is not defined", "Test case 0 failed on function 'get_exception'."


# Generated at 2022-06-25 01:39:47.052832
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == 1

# Generated at 2022-06-25 01:39:49.024280
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    return


# Generated at 2022-06-25 01:39:49.909051
# Unit test for function get_exception
def test_get_exception():
    pass


# Generated at 2022-06-25 01:39:53.662094
# Unit test for function get_exception
def test_get_exception():
    # raises an error, so we can capture the exception
    try:
        test_case_0()
    except NameError as e:
        var_0 = e

    assert var_0.args == ("name 'var_0' is not defined",)



# Generated at 2022-06-25 01:39:58.251993
# Unit test for function get_exception
def test_get_exception():
    func_arg_0 = test_case_0()
    assert func_arg_0 == None

test_case_1 = literal_eval('[1,2,3]')


# Generated at 2022-06-25 01:40:00.486663
# Unit test for function get_exception
def test_get_exception():
    try:
        var_1 = test_case_0()
    except Exception:
        var_1 = get_exception()
    assert isinstance(var_1, Exception), 'Expected Exception, got {0}'.format(type(var_1))


# Generated at 2022-06-25 01:40:01.564101
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    return var_0



# Generated at 2022-06-25 01:40:20.459949
# Unit test for function get_exception
def test_get_exception():
    try:
        print('\nTESTING: get_exception\n')
        test_case_0()
        print('PASSED: get_exception')
    except SystemExit:
        print('FAILED: get_exception')


# Generated at 2022-06-25 01:40:22.526587
# Unit test for function get_exception
def test_get_exception():
    try:
        literal_eval('{a:1}')
    except Exception as e:
        e = get_exception()
        assert True
    else:
        assert False, "Should have raised"


# Generated at 2022-06-25 01:40:30.173393
# Unit test for function get_exception
def test_get_exception():
    try:
        # Test function call
        test_case_0()
    except NameError as e:
        assert e.args[0] == "'test_case_0' is not defined!", "NameError exception not raised"
        assert e.__class__.__name__ == 'NameError', "NameError exception not raised"
    assert literal_eval("['b', 'c']") == ['b', 'c'], "Literal evaluation failed"

test_get_exception()

# Generated at 2022-06-25 01:40:33.038845
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bogus')
        assert False
    except:
        assert True
    var_1 = get_exception()
    assert var_1.args == ('bogus',)


# Generated at 2022-06-25 01:40:34.714382
# Unit test for function get_exception
def test_get_exception():
    var_1 = test_case_0()
    assert var_1 == None, "AssertionError: var_1 == None"


# Generated at 2022-06-25 01:40:37.634319
# Unit test for function get_exception
def test_get_exception():
    var_0 = None
    try:
        test_case_0()
    except:
        var_0 = get_exception()
    
    if var_0 is None:
        raise Exception("Expected an exception from function test_case_0.")


# Generated at 2022-06-25 01:40:42.107147
# Unit test for function get_exception
def test_get_exception():
    # Test with expected exception raised
    try:
        var_0 = get_exception()
        raise Exception('ExpectedException')
    except:
        pass
    assert True

    # Test with no exception raised
    var_0 = get_exception()
    assert var_0 is None
    assert True



# Generated at 2022-06-25 01:40:46.802795
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("bad")
    except Exception as e:
        assert e.args == ('bad',)
        assert literal_eval(repr(e)) == ('bad',)

    try:
        raise Exception("bad", "nesting")
    except Exception as e:
        assert e.args == ('bad', 'nesting')
        assert literal_eval(repr(e)) == ('bad', 'nesting')
        assert str(e) == "bad"
        try:
            raise Exception("really bad")
        except Exception as f:
            assert literal_eval(repr(f)) == ('really bad',)
            assert str(e) == "bad"
            try:
                raise Exception("even worse")
            except Exception as g:
                assert literal_eval(repr(g)) == ('even worse',)
               

# Generated at 2022-06-25 01:40:50.816588
# Unit test for function get_exception
def test_get_exception():
    """Compute the sum of a sequence of numbers."""
    var_0 = get_exception()
    assert var_0, 'no exception was raised'
    assert isinstance(var_0, ValueError), 'a ValueError was not raised'



# Generated at 2022-06-25 01:40:53.311004
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(NameError) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == NameError



# Generated at 2022-06-25 01:41:29.313554
# Unit test for function get_exception
def test_get_exception():
    var_0 = None
    try:
        test_case_0()
    except:
        var_0 = get_exception()
    assert var_0 is None



# Generated at 2022-06-25 01:41:30.320908
# Unit test for function get_exception
def test_get_exception():
    # Test for 0 parameters
    assert test_case_0() == 'Exception'

# Generated at 2022-06-25 01:41:32.330814
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass



# Generated at 2022-06-25 01:41:36.285487
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("Error message")
    except TypeError as e:
        assert get_exception() is e
    try:
        test_case_0()
    except TypeError as e:
        assert get_exception() is e



# Generated at 2022-06-25 01:41:37.309158
# Unit test for function get_exception
def test_get_exception():
    test_case_0()


# Generated at 2022-06-25 01:41:45.612134
# Unit test for function get_exception
def test_get_exception():
    # This all assumes that the running python version is the same as the
    # python version that the unit tests are being run with.
    #
    # This is a problem if the unit tests are being run in a set of virtualenvs
    # created to test many versions of Python.  In that case, we just skip this
    # test.
    if sys.version_info[0] != 2:
        raise AssertionError('Unicode error in python 2 only')
    # Test with a Unicode error on python 2.
    try:
        u'abc' + b'abc'
    except UnicodeError:
        e = get_exception()
        if not isinstance(e, UnicodeError):
            raise AssertionError('Unicode error in python 2 only')

# Generated at 2022-06-25 01:41:47.310644
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exc_info = get_exception()
    print(exc_info)


# Generated at 2022-06-25 01:41:48.069094
# Unit test for function get_exception
def test_get_exception():
    assert True


# Generated at 2022-06-25 01:41:52.412324
# Unit test for function get_exception
def test_get_exception():
    print("Testing get_exception()")

    class TestException(Exception):
        pass

    try:
        1/0
    except:
        exc = get_exception()

    assert exc.__class__ == ZeroDivisionError

    try:
        raise TestException("Test")
    except:
        exc = get_exception()

    assert exc.__class__ == TestException

    print("Success.")


# Generated at 2022-06-25 01:41:54.300841
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        test_case_0()
        try:
            raise Exception()
        except Exception as e:
            assert get_exception().args[0] == e.args[0]

# Generated at 2022-06-25 01:43:08.150908
# Unit test for function get_exception
def test_get_exception():
    # Test with argument var_0 = get_exception()
    var_0 = get_exception()
    assert var_0 == 'get_exception() missing 1 required positional argument: \'var_0\'', 'Returned: {0}'.format(var_0)



# Generated at 2022-06-25 01:43:12.768818
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        exception_not_raised = False
    else:
        exception_not_raised = True
    assert not exception_not_raised

test_get_exception()

# Generated at 2022-06-25 01:43:21.367159
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
        raise AssertionError("AssertionError")
    except AssertionError:
        pass
    except TypeError:
        pass
    except ValueError:
        pass
    except ImportError:
        pass
    except RuntimeError:
        pass
    except NotImplementedError:
        pass
    except NameError:
        pass
    except AttributeError:
        pass
    except SyntaxError:
        pass
    except IndexError:
        pass
    except KeyError:
        pass
    except IOError:
        pass
    except TabError:
        pass
    except UnicodeError:
        pass
    except UnicodeDecodeError:
        pass
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-25 01:43:26.457501
# Unit test for function get_exception
def test_get_exception():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    # Set up mock values
    mock_var_0 = "foo"

    with patch.object(sys, 'exc_info', return_value=mock_var_0):
        # Execute the function
        result_0 = get_exception()

    # Assert return values
    assert result_0 == mock_var_0



# Generated at 2022-06-25 01:43:30.520538
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception throws a SyntaxError if used incorrectly"""
    try:
        SyntaxError
    except SyntaxError:
        test_case_0()


# Generated at 2022-06-25 01:43:37.627398
# Unit test for function get_exception
def test_get_exception():
    """Assert that the function works properly."""
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-25 01:43:44.804790
# Unit test for function get_exception
def test_get_exception():
    var_0 = 'test'
    try:
        var_1 = literal_eval(var_0)
        var_2 = var_1
    except ValueError:
        var_2 = var_1
    var_1 = test_case_0
    var_2()


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:43:47.580061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError as e:
        assert get_exception() == e



# Generated at 2022-06-25 01:43:52.095798
# Unit test for function get_exception
def test_get_exception():

    try:
        test_case_0()


    except Exception as e:  # noqa: F841
        pass



# Generated at 2022-06-25 01:43:54.042265
# Unit test for function get_exception
def test_get_exception():
    try:
      test_case_0()
    except ValueError:
      assert True
    else:
      assert False

# Generated at 2022-06-25 01:46:44.840507
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert True



# Generated at 2022-06-25 01:46:49.807661
# Unit test for function get_exception
def test_get_exception():
    test_case(test_case_0)
# END unit test for get_exception



# Generated at 2022-06-25 01:46:52.646794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is an error message")
    except RuntimeError as e:
        assert get_exception() == e
        assert get_exception() == e
    except:
        assert 0, "Sanity check to make sure the right type of error is raised"


# Generated at 2022-06-25 01:46:57.531107
# Unit test for function get_exception
def test_get_exception():
    # TODO: add test for parameter e_exception_name
    # TODO: add test for parameter module
    # TODO: add test for parameter with_traceback
    # TODO: add test for parameter e
    # TODO: add test for parameter tb
    # TODO: add test for parameter e_exception
    # TODO: add test for parameter tb_traceback
    # TODO: add test for parameter e_msg
    # TODO: add test for parameter traceback
    var_0 = get_exception()



# Generated at 2022-06-25 01:46:59.496489
# Unit test for function get_exception
def test_get_exception():
    print('=' * 80)
    test_case_0()


# Generated at 2022-06-25 01:47:00.209159
# Unit test for function get_exception
def test_get_exception():
    pass

    # AssertionError: None

# Generated at 2022-06-25 01:47:01.117352
# Unit test for function get_exception
def test_get_exception():
    raise Exception



# Generated at 2022-06-25 01:47:04.109646
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except AssertionError:
        print('AssertionError raised in test_case_0.')
    except Exception as e:
        print('An exception has been raised in test_case_0.')
        print(e)

# Call function get_exception
test_get_exception()
# xxxxxxxxxx End of function get_exception xxxxxxxxxx

# Generated at 2022-06-25 01:47:09.315761
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as ex:
        if hasattr(ex, '__traceback__'):
            exc = ex.__traceback__
            if hasattr(exc, 'tb_lineno'):
                assert exc.tb_lineno == 12
            else:
                assert False, "No tb_lineno available"
        else:
            assert False, "No __traceback__ available"



# Generated at 2022-06-25 01:47:12.358038
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'
