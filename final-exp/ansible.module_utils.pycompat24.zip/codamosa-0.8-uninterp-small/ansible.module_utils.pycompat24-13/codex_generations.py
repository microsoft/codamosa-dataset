

# Generated at 2022-06-25 01:39:08.929547
# Unit test for function get_exception
def test_get_exception():
    try:
        from ansible.module_utils._text import _get_exception

    except:
        assert 0, "from ansible.module_utils._text import get_exception failed"

    try:
        assert _get_exception() is None, "assertion error in get_exception at line 18"
    finally: pass

    try:
        raise ValueError("")

    except:
        exception_0 = get_exception()

    try:
        assert str(exception_0) == "", "assertion error in get_exception at line 26"
    finally: pass

    try:
        test_case_0()
    except:
        exception_0 = get_exception()


# Generated at 2022-06-25 01:39:10.877318
# Unit test for function get_exception
def test_get_exception():
    this_var = None
    try:
        test_case_0()
    except NameError as this_var:
        pass
    assert isinstance(this_var, NameError)


# Generated at 2022-06-25 01:39:11.734138
# Unit test for function get_exception
def test_get_exception():
    result = get_exception()
    assert result is None


# Generated at 2022-06-25 01:39:23.408435
# Unit test for function get_exception
def test_get_exception():
    # Test function call
    try:
        # Test function call
        raise Exception()
    except Exception:
        var_1 = get_exception()
        assert(var_1.__class__.__name__ == 'Exception')
        assert(var_1.args == ())
    # Test function call
    try:
        # Test function call
        raise Exception()
    except Exception:
        var_2 = get_exception()
        assert(var_1.__class__.__name__ == 'Exception')
        assert(var_1.args == ())
    # Test function call
    try:
        # Test function call
        raise Exception()
    except Exception:
        var_3 = get_exception()
        assert(var_1.__class__.__name__ == 'Exception')

# Generated at 2022-06-25 01:39:25.115858
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert get_exception() == e



# Generated at 2022-06-25 01:39:30.323216
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exception = get_exception()
        assert str(exception) == "var_0 is not defined"


# Generated at 2022-06-25 01:39:35.884357
# Unit test for function get_exception
def test_get_exception():
    assert (test_case_0()[1] is None or test_case_0()[1] == '')


# Generated at 2022-06-25 01:39:37.915840
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_0 = get_exception()
        assert var_0 == e

# Generated at 2022-06-25 01:39:39.060891
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)
    else:
        assert False, 'Exception should have been raised'


# Generated at 2022-06-25 01:39:41.364197
# Unit test for function get_exception
def test_get_exception():
    global var_0
    try:
        test_case_0()
    except:
        var_0 = get_exception()
    assert True == isinstance(var_0, ValueError)


# Generated at 2022-06-25 01:40:00.422629
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert e is var_0
    except:
        assert False, 'Unexpected exception'
    else:
        assert False, 'Expected exception not raised'



# Generated at 2022-06-25 01:40:02.342661
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(NameError):
        test_case_0()


# Generated at 2022-06-25 01:40:04.828695
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e.args[0] == "get_exception() got an unexpected keyword argument 'exc_info'"
    except:
        raise


# Generated at 2022-06-25 01:40:07.667911
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Badness!')
    except:
        exc1 = get_exception()
        assert exc1.args[0] == 'Badness!'



# Generated at 2022-06-25 01:40:11.010770
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
        assert False
    except:
        e = get_exception()
        assert True

# Generated at 2022-06-25 01:40:12.985057
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if type(e) is not None:
            raise Exception('ExpectedException')


# Generated at 2022-06-25 01:40:14.955831
# Unit test for function get_exception

# Generated at 2022-06-25 01:40:18.500562
# Unit test for function get_exception
def test_get_exception():
    try:
        module.fail_json(msg="Hello world")
    except Exception:
        var_0 = get_exception()

    e = get_exception()
    res = (str(e) == "module.fail_json(msg='Hello world')")
    assert res, "Testcase 0 failed"



# Generated at 2022-06-25 01:40:20.500063
# Unit test for function get_exception

# Generated at 2022-06-25 01:40:21.680826
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert var_0 == e


# Generated at 2022-06-25 01:40:55.078880
# Unit test for function get_exception
def test_get_exception():
    test_case_0()



# Generated at 2022-06-25 01:41:00.052290
# Unit test for function get_exception
def test_get_exception():
    pass

    # Assign parameter 'optional_args_0' a value for testing
    optional_args_0 = 'test'

    # Call function 'get_exception' with the appropriate arguments
    get_exception(optional_args_0)


# Generated at 2022-06-25 01:41:03.589147
# Unit test for function get_exception
def test_get_exception():
    # test case 0
    try:
        test_case_0()
    except:
        result = get_exception()
        assert result
        assert isinstance(result, Exception)
    else:
        raise Exception("Expected exception")


if __name__ == '__main__':
    # test_get_exception()
    sys.exit(0)

# Generated at 2022-06-25 01:41:06.686414
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        test_case_0()
        assert False
    except AssertionError:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        assert exc_value.message == 'malformed string'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:41:09.939151
# Unit test for function get_exception
def test_get_exception():
    assert True == True


# Generated at 2022-06-25 01:41:13.978708
# Unit test for function get_exception
def test_get_exception():
    args = []
    if __name__ == '__main__':
        for arg in sys.argv[1:]:
            args.append(arg)

    unittest.main()

# vim: et ts=4 sw=4

# Generated at 2022-06-25 01:41:14.441672
# Unit test for function get_exception
def test_get_exception():
    pass

# Generated at 2022-06-25 01:41:19.288758
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import PY2
    try:
        test_case_0()
    except Exception:
        if PY2:
            assert sys.exc_info()[1] is var_0
        else:
            assert sys.exc_info()[1] == var_0

if __name__ == '__main__':
    test_get_exception()



# Generated at 2022-06-25 01:41:22.080460
# Unit test for function get_exception
def test_get_exception():
    """Test for the module get_exception"""
    import sys
    import pytest
    from ast import literal_eval

    with pytest.raises(AttributeError):
        test_case_0()


# Generated at 2022-06-25 01:41:25.720833
# Unit test for function get_exception
def test_get_exception():
    my_exception = None
    try:
        raise Exception("This is my exception text")
    except:
        my_exception = get_exception()

    assert my_exception is not None, "Exception was not created"
    assert my_exception.message == "This is my exception text", "Exception text did not match"


# Generated at 2022-06-25 01:42:01.398891
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()



# Generated at 2022-06-25 01:42:02.624187
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    var_0 = get_exception()


# Generated at 2022-06-25 01:42:06.346858
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except ValueError:
        exception = get_exception()
    assert isinstance(exception, ValueError)



# Generated at 2022-06-25 01:42:10.355602
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None



# Generated at 2022-06-25 01:42:16.314020
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        # Python 2.6+
        assert isinstance(var_0, Exception)
        assert str(var_0) == 'test_case_0() takes no arguments (1 given)'
        assert var_0.args == ('test_case_0() takes no arguments (1 given)',)
    except:
        # Python 2.4-2.5
        assert isinstance(var_0, TypeError)
        assert str(var_0) == 'test_case_0() takes no arguments (1 given)'
        assert var_0.args == ('test_case_0() takes no arguments (1 given)',)


# Generated at 2022-06-25 01:42:18.878209
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        result = get_exception()
        assert result == 'variable does not exist'



# Generated at 2022-06-25 01:42:22.776722
# Unit test for function get_exception
def test_get_exception():
    # test exception handling
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
        assert ex.args == ('foo',)



# Generated at 2022-06-25 01:42:28.101374
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('HiThere')
    except NameError:
        var_0 = get_exception()
        assert isinstance(var_0, NameError)
    try:
        raise ValueError('HiThere')
    except ValueError:
        var_0 = get_exception()
        assert isinstance(var_0, ValueError)
    try:
        print(open('does_not_exist', 'rb'))
    except IOError:
        var_0 = get_exception()
        assert isinstance(var_0, IOError)


# Generated at 2022-06-25 01:42:32.294424
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        #assert True
        assert False


# Generated at 2022-06-25 01:42:35.664280
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        if e == 'global name \'a\' is not defined':
            return True
        else:
            return e
    else:
        return False


# Generated at 2022-06-25 01:43:52.612501
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:43:54.562126
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        exception = e
        print(type(e))
      

# Generated at 2022-06-25 01:43:56.330901
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test.')
    except ValueError as e:
        assert e == get_exception()


# Generated at 2022-06-25 01:43:58.097932
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    assert(isinstance(var_0, BaseException))


# Generated at 2022-06-25 01:43:58.924257
# Unit test for function get_exception
def test_get_exception():
    # run test case
    test_case_0()

# Generated at 2022-06-25 01:44:00.534259
# Unit test for function get_exception
def test_get_exception():
    # No exceptions thrown
    test_case_0()


# Generated at 2022-06-25 01:44:01.692402
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == None



# Generated at 2022-06-25 01:44:02.652040
# Unit test for function get_exception
def test_get_exception():
    # call function
    test_case_0()

    # result
    assert True

# Generated at 2022-06-25 01:44:10.224290
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except ValueError:
        var_0 = get_exception()

    var_0 = str(var_0)

    assert var_0 == "invalid literal for int() with base 10: 'a'"


# Generated at 2022-06-25 01:44:12.955630
# Unit test for function get_exception
def test_get_exception():
    # Test with no exception
    try:
        var_0 = get_exception()
        print('should not have been reached')
    except:
        print('should not have been reached')
    # Test with exception
    try:
        raise ValueError('oh noes')
    except:
        var_1 = get_exception()



# Generated at 2022-06-25 01:47:18.584907
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
    except Exception:
        var_0 = get_exception()


# Generated at 2022-06-25 01:47:19.842090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("There's an error")
    except Exception as e:
        var_0 = get_exception()
    assert var_0 == e



# Generated at 2022-06-25 01:47:21.330035
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None


# Generated at 2022-06-25 01:47:22.465974
# Unit test for function get_exception
def test_get_exception():
    var_0 = sys.exc_info()[1]


# Generated at 2022-06-25 01:47:26.239172
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if str(e) == 'NoneType':
            print('Test case passed')
        else:
            print('Test case failed: got {} instead of NoneType'.format(e))


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:47:28.312923
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except ValueError as e:
        assert True
    else:
        assert False, 'No error raised'



# Generated at 2022-06-25 01:47:36.612384
# Unit test for function get_exception
def test_get_exception():
    #  EAFP
    try:
        #  call some code that raises an exception
        test_case_0()
    except NameError as e:
        #  no exception, continue normally
        pass
    except:
        #  exception, handle it
        e = get_exception()

# Generated at 2022-06-25 01:47:41.316796
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('var test_case_0')
    except KeyError as e:
        e = get_exception()
    assert repr(e) == repr(KeyError('var test_case_0'))

# Generated at 2022-06-25 01:47:50.528299
# Unit test for function get_exception
def test_get_exception():
    # 1 test case
	#Test case 0
	try:
	    var_0 = 1 / 0.0
	except:
	    assert get_exception() is not None

	try:
	    var_0 = 1 / 0.0
	except:
	    e = get_exception()
	    assert getattr(e, '__name__') == 'ZeroDivisionError'

	try:
	    var_0 = 1 / 0.0
	except:
	    e = get_exception()
	    assert e.__name__ == 'ZeroDivisionError'

	try:
	    var_0 = 1 / 0.0
	except:
	    e = get_exception()
	    assert getattr(e, 'args') == ('float division by zero',)


# Generated at 2022-06-25 01:47:52.421690
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert 'var_0' in e.message