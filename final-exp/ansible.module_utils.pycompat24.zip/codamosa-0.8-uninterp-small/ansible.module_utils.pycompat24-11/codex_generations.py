

# Generated at 2022-06-25 01:39:01.122572
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:39:06.165471
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(NameError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert 'var_0' in str(the_exception)

# Generated at 2022-06-25 01:39:09.501143
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        exc = get_exception()

    assert exc == e



# Generated at 2022-06-25 01:39:11.591558
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert var_0 == None, "get_exception() should have returned None"



# Generated at 2022-06-25 01:39:14.016591
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1/0
    except:
        result = get_exception()
    assert result.args[0] == 'integer division or modulo by zero' == result.message


# Generated at 2022-06-25 01:39:21.904259
# Unit test for function get_exception
def test_get_exception():

    # Needs to be here to get the exception
    try:
        test_case_0()
    except:
        var_0 = get_exception()

    assert var_0 is not None
    assert var_0 is not False
    if not var_0:
        raise Exception("Failed to assert that %s is not None or False" % var_0)
    # Unit test for function literal_eval

# Generated at 2022-06-25 01:39:25.202219
# Unit test for function get_exception
def test_get_exception():
    # Make sure the function fails with a TypeError exception
    # with incorrect number of parameters
    with pytest.raises(TypeError):
        get_exception(1, 2)


# Generated at 2022-06-25 01:39:30.047239
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0, "The exception should be equal to the one caught"

# Generated at 2022-06-25 01:39:35.813815
# Unit test for function get_exception
def test_get_exception():
    result = get_exception()
    assert type(result)== type(Exception()), 'Unexpected result from function get_exception'



# Generated at 2022-06-25 01:39:38.497109
# Unit test for function get_exception
def test_get_exception():
    """
    Test the return value and type of function get_exception
    """
    try:
        test_case_0()
    except Exception as e:
        if (type(e) != type(get_exception())):
            raise AssertionError("Expected {0}, got {1}".format(type(get_exception()), type(e)))


# Generated at 2022-06-25 01:39:50.577076
# Unit test for function get_exception
def test_get_exception():
    # Verify expected exception raised
    try:
        # Call to function that causes exception
        test_case_0()
    except Exception as e:
        assert e == get_exception()
        return None

    raise Exception("Expected exception, not test exception")


# Generated at 2022-06-25 01:40:00.640936
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        try:
            raise RuntimeError('foo')
        except RuntimeError as e1:
            assert e1.args == ('foo', )
            try:
                raise ValueError('bar')
            except ValueError as e2:
                assert e2.args == ('bar', )
    except RuntimeError:
        assert e1.args == ('foo', )
        e = get_exception()
    assert type(e) is ValueError
    assert e.args == ('bar', )
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert type(e) is ValueError
    assert e.args == ('foo', )


# Generated at 2022-06-25 01:40:02.640887
# Unit test for function get_exception
def test_get_exception():
    # Test of 'Exception'
    try:
        test_case_0()
    except Exception as e:
        assert type(e) == type(Exception())


# Generated at 2022-06-25 01:40:04.634924
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    if True:
        assert True
    else:
        raise AssertionError



# Generated at 2022-06-25 01:40:06.407746
# Unit test for function get_exception
def test_get_exception():
    var_1 = get_exception()

    assert(var_1 != None)

    var_2 = get_exception()
    assert(var_2 == None)


# Generated at 2022-06-25 01:40:13.314942
# Unit test for function get_exception
def test_get_exception():
    # Test 0 - Run function w/o exception
    try:
        test_case_0()
    except:
        assert 0, 'Test case 0 failed'

    # Test 1 - Run function w/exception
    try:
        raise Exception("Test exception")
    except:
        e = get_exception()
        assert (e.args[0] == "Test exception")
        assert 1, 'Test case 1 passed'


# Generated at 2022-06-25 01:40:14.417317
# Unit test for function get_exception
def test_get_exception():
    argspec = (0)
    assert test_case_0(*argspec) == None

# Generated at 2022-06-25 01:40:15.487730
# Unit test for function get_exception
def test_get_exception():
    assert True


# Generated at 2022-06-25 01:40:18.728994
# Unit test for function get_exception
def test_get_exception():
    # Test with exception
    try:
        test_case_0()
    except IndexError as e0:
        assert e0.args[0] == 'list index out of range'
    # Test with no exception
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 01:40:21.585991
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_1 = get_exception()
        if var_1 is None:
            raise AssertionError("The variable var_1 should be set to the exception thrown by test_case_0, got None instead")

# Generated at 2022-06-25 01:40:34.637283
# Unit test for function get_exception
def test_get_exception():
    # Check that the function returns the correct exception for a
    # zero divide.
    try:
        raise ZeroDivisionError("Should be the exception")
    except ZeroDivisionError:
        assert get_exception().message == "Should be the exception"

try:
    literal_eval('__import__("sys").exit(1)')
except ValueError as e:
    assert isinstance(e.message, (text_type, binary_type))


# Generated at 2022-06-25 01:40:38.443391
# Unit test for function get_exception
def test_get_exception():
    # Verify the module's functionality
    sys.exc_info = lambda : (NameError, NameError('foo'), NameError(None))
    assert test_case_0() == NameError('foo')
    # Replace the module's functionality
    sys.exc_info = lambda : (NameError, NameError('foo'), NameError(None))
    # Verify that the module's functionality has been replaced
    assert test_case_0() == NameError('foo')



# Generated at 2022-06-25 01:40:39.689470
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == None


# Generated at 2022-06-25 01:40:41.780634
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except ValueError:
        var_1 = get_exception()
        assert isinstance(var_1, ValueError)

test_get_exception()


# Generated at 2022-06-25 01:40:44.535148
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError("This is a test")
    except KeyError:
        e = get_exception()
        assert e.message == "This is a test"


# Generated at 2022-06-25 01:40:46.260818
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
    except:
        var_0 = get_exception()


# Generated at 2022-06-25 01:40:47.780869
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()
        assert str(e) == 'missing required positional argument: self'



# Generated at 2022-06-25 01:40:49.365661
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        var_1 = get_exception()
    assert var_1

# Generated at 2022-06-25 01:40:52.700252
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        assert True, 'Unhandled exception.'
    else:
        assert False, 'Should have raised an exception.'


# Generated at 2022-06-25 01:40:57.872465
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
        exception = get_exception()
        assert exception.__name__ == 'ValueError'
    except:
        pass



# Generated at 2022-06-25 01:41:14.727508
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0, 'unexpected exception'


# unit test for function literal_eval

# Generated at 2022-06-25 01:41:16.435686
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e


# Generated at 2022-06-25 01:41:17.484083
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Some error")
    except RuntimeError:
        assert isinstance(get_exception(), RuntimeError)
        return True


# Generated at 2022-06-25 01:41:20.410309
# Unit test for function get_exception
def test_get_exception():
    var_1 = None
    try:
        test_case_0()
    except:
        var_1 = get_exception()
    assert isinstance(var_1, Exception)


# Generated at 2022-06-25 01:41:25.677004
# Unit test for function get_exception
def test_get_exception():
    test_values = [
        ('test_case_0', 'var_0', ['test_get_exception()'], 'test_case_0()'),
        ('test_case_1', 'var_1', ['test_case_1()'], 'test_case_1()'),
    ]
    for case_name, expected, stack, call_path in test_values:
        case_globals = globals()
        case_locals = locals()

# Generated at 2022-06-25 01:41:26.502434
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert get_exception != None



# Generated at 2022-06-25 01:41:27.746953
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert var_0 == None



# Generated at 2022-06-25 01:41:28.679198
# Unit test for function get_exception
def test_get_exception():
    assert(get_exception() == None)


# Generated at 2022-06-25 01:41:33.386883
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        # Caught an exception, use get_exception() to get it
        try:
            ansible_assert(get_exception().message == "global name 'ansible_assert' is not defined")
        except:
            # Caught an exception, use get_exception() to get it
            ansible_fail(get_exception())



# Generated at 2022-06-25 01:41:40.591155
# Unit test for function get_exception
def test_get_exception():
    # First, we set up a context for testing.  In this case, we want to test
    # that get_exception correctly stores a running exception, so we first
    # trigger an exception and then run the code that gets the exception.
    try:
        # Next, we trigger the exception that we're interested in testing.
        raise RuntimeError("Foo")
    except:
        # Now we run the code that we're testing.
        var_0 = get_exception()
    # Finally, we test the value of the variable to see if it contains the
    # exception that we set.
    assert(str(var_0) == "Foo")



# Generated at 2022-06-25 01:42:16.846333
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(ZeroDivisionError):
        test_case_0()



# Generated at 2022-06-25 01:42:19.619030
# Unit test for function get_exception
def test_get_exception():
    print('Test 1 of get_exception')
    try:
        test_case_0()
    except Exception as e:
        if e == get_exception():
            return True
    return False


# Generated at 2022-06-25 01:42:21.440285
# Unit test for function get_exception
def test_get_exception():
    print("test_get_exception")
    assert True == True


# Generated at 2022-06-25 01:42:27.699214
# Unit test for function get_exception
def test_get_exception():
    # Skipping for Python 2.4, which is missing the Exception class
    if sys.version_info[:2] <= (2, 4):
        return
    try:
        test_case_0()
    # Catch exception if the test run failed
    except Exception as exc:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        # Extract unittest.TestCase exception
        cause = exc_value
        # Verify if the exception raised by the test is the expected one
        assert cause.__name__ == 'TypeError'

# unit test for function literal_eval

# Generated at 2022-06-25 01:42:33.999129
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils._text import to_text

    try:
        try:
            raise ValueError("To be or not to be, that is the question")
        except ValueError:
            e = get_exception()
    except NameError:
        # This is what we want to happen
        pass
    else:
        # We don't want this to occur
        assert False, "get_exception() function works without except clause"

    try:
        raise ValueError("To be or not to be, that is the question")
    except ValueError:
        e = get_exception()

    assert e is not None, "get_exception() uses sys.exc_info()[1] for unpacking"

# Generated at 2022-06-25 01:42:35.014514
# Unit test for function get_exception
def test_get_exception():
    result = get_exception()
    assert True


# Generated at 2022-06-25 01:42:36.409776
# Unit test for function get_exception
def test_get_exception():
    # Test the function get_exception with correct arguments -> correct results
    pass


# Generated at 2022-06-25 01:42:41.482386
# Unit test for function get_exception
def test_get_exception():
    # Test with and without an exception
    try:
        test_case_0()
    except Exception as e:
        var_0 = e

        var_1 = get_exception()

        var_1 = ast.dump(var_0)



# Generated at 2022-06-25 01:42:45.614249
# Unit test for function get_exception

# Generated at 2022-06-25 01:42:47.746296
# Unit test for function get_exception
def test_get_exception():
    try:
        # Make sure the function throws an exception
        assert type(get_exception()) == Exception
        assert False
    except Exception:
        pass

# Test for literal_eval

# Generated at 2022-06-25 01:44:01.115298
# Unit test for function get_exception
def test_get_exception():
    assert var_0 == get_exception()


var_1 = literal_eval('')


# Generated at 2022-06-25 01:44:02.809662
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exc = get_exception()
        assert str(exc) == "test exception"


# Generated at 2022-06-25 01:44:09.753649
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        exc = get_exception()
    assert exc is not None
    assert isinstance(exc, Exception)


# Generated at 2022-06-25 01:44:14.142350
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        print(get_exception())

# Generated at 2022-06-25 01:44:16.058963
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = 1
        var_0 = var_0 / 0
    except Exception:
        raise Exception(get_exception())
    return True



# Generated at 2022-06-25 01:44:19.009913
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert e is get_exception()



# Generated at 2022-06-25 01:44:20.732055
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    assert var_0 is None, 'Expected None to be returned'



# Generated at 2022-06-25 01:44:24.071908
# Unit test for function get_exception
def test_get_exception():
    # TODO:
    # We currently have no way of testing an actual exception case
    assert True


# Generated at 2022-06-25 01:44:26.566126
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        test_case_0()


# Generated at 2022-06-25 01:44:30.953139
# Unit test for function get_exception

# Generated at 2022-06-25 01:47:27.450058
# Unit test for function get_exception
def test_get_exception():
  print("Test: get_exception")

  var_0 = test_case_0()

  # Test for correct output.
  return


# Generated at 2022-06-25 01:47:33.286600
# Unit test for function get_exception
def test_get_exception():
    # Try to raise an exception
    try:
        test_case_0()
    # If there's an exception, make sure it's what we expect
    except Exception as e:
        assert False



# Generated at 2022-06-25 01:47:36.577947
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    try:
        test_case_0()
    except Exception as inst:
        var_1 = get_exception()
        if var_1 != inst:
            raise Exception('Raised exception is not get_exception!')
        else:
            pass


# Generated at 2022-06-25 01:47:40.548752
# Unit test for function get_exception
def test_get_exception():
    # Assert if not raises
    try:
        raise RuntimeError()

    except RuntimeError:
        test_case_0()



# Generated at 2022-06-25 01:47:44.757068
# Unit test for function get_exception
def test_get_exception():
    try:
        # test case 0:
        test_case_0()
    except:  # noqa
        exception = get_exception()
        # Ensure that the exception is actually an exception
        assert isinstance(exception, Exception)
        # Ensure that the exception has the right type
        assert isinstance(exception, AssertionError)
        # Ensure that the exception has a message
        assert str(exception) == 'expected tuple of 2 items, got 1'



# Generated at 2022-06-25 01:47:45.892264
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == None


# Generated at 2022-06-25 01:47:47.155565
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()

    assert isinstance(e, BaseException), "Argument is not of type 'BaseException'"
    return True



# Generated at 2022-06-25 01:47:49.841612
# Unit test for function get_exception
def test_get_exception():
    print('Testing get_exception')
    try:
        test_case_0()
    except:
        assert get_exception()
    print('Test Successful')



# Generated at 2022-06-25 01:47:54.880490
# Unit test for function get_exception
def test_get_exception():
    # Try to call the function
    try:
        test_case_0()
    # If there is an exception, keep the Exception in the variable named `exc`
    except Exception as exc:
        # Try to compare the Exception with the value named `exc`
        assert exc is not None


# Generated at 2022-06-25 01:47:57.918862
# Unit test for function get_exception
def test_get_exception():
    var_0 = 'too many values to unpack'
    var_1 = literal_eval(var_0)

    print(var_1)
    assert var_1 == 'too many values to unpack'

