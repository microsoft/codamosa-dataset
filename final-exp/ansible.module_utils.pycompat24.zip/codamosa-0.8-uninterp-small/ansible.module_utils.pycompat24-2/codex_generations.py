

# Generated at 2022-06-25 01:39:01.718746
# Unit test for function get_exception
def test_get_exception():
    #TODO: Define a exception case
    #TODO: Define a normal case
    try:
        raise Exception('')
    except Exception:
        try:
            var_0 = get_exception()
        except:
            var_0 = 'exception'
    assert var_0 != 'exception', "Test case failed!"


# Generated at 2022-06-25 01:39:02.883003
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert True


# Generated at 2022-06-25 01:39:09.027847
# Unit test for function get_exception
def test_get_exception():
    try:
        # Call the function
        result = get_exception()
        assert type(result) is type(Exception(""))
    except:
        # Some exception occurred
        # Get the call stack
        import traceback
        call_stack = traceback.extract_stack()
        # Extract this function's name
        caller_name = call_stack[len(call_stack)-2][2]
        print("A failure occured when calling %s() from %s: %s" % (caller_name, test_get_exception.__name__, sys.exc_info()[1]))
        raise
    else:
        # No exception occurred
        print("Successfully ran %s()." % test_get_exception.__name__)



# Generated at 2022-06-25 01:39:10.272515
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert var_0 is None


# Generated at 2022-06-25 01:39:14.365293
# Unit test for function get_exception
def test_get_exception():
    assert True


# Generated at 2022-06-25 01:39:17.495514
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        if AssertionError:
            assert(False)



# Generated at 2022-06-25 01:39:24.189585
# Unit test for function get_exception
def test_get_exception():
    # Test only if we're not being called as a module (so not 'if __name__ == "__main__":')
    if sys.argv[0].find('py.test') != -1:
        try:
            raise Exception('a problem')
        except:
            ex = get_exception()

        # Make sure that get_exception got the exception
        assert ex.args[0] == 'a problem'


# Generated at 2022-06-25 01:39:28.897899
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
    try:
        raise Exception('message')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.message == 'message'


# Generated at 2022-06-25 01:39:30.516518
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        assert(e.message == var_0.message)

# Generated at 2022-06-25 01:39:36.975533
# Unit test for function get_exception
def test_get_exception():
    my_var = "my_var"
    if my_var == "my_var":
        raise Exception("my exception")
    # test for return type
    assert isinstance(get_exception(), Exception)


# Generated at 2022-06-25 01:39:46.764824
# Unit test for function get_exception
def test_get_exception():
    # No exception to retrieve
    assert test_case_0() is None



# Generated at 2022-06-25 01:39:49.824659
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        test_var_0 = get_exception()
    assert test_var_0 is not None



# Generated at 2022-06-25 01:39:51.641337
# Unit test for function get_exception
def test_get_exception():
    var_1 = "test_case_0"
    literal_eval(var_1)

test_get_exception()

# Generated at 2022-06-25 01:39:54.213836
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-25 01:39:58.714354
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert var_0 == None, "Test case 0 failed"
    # unit test for function literal_eval
    # test case for function literal_eval


# Generated at 2022-06-25 01:40:00.047621
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e is get_exception()



# Generated at 2022-06-25 01:40:01.725497
# Unit test for function get_exception
def test_get_exception():
    try:
        var_1 = 1 / 0
    except:
        var_2 = get_exception()



# Generated at 2022-06-25 01:40:03.962512
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if e is not var_0:
            raise Exception("Expected {}, got {}".format(var_0, e))


# Generated at 2022-06-25 01:40:05.819553
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except ZeroDivisionError as e:
        pass
    assert e is not None, 'Failed to catch an exception'

# Generated at 2022-06-25 01:40:07.473502
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        if get_exception():
            return False
    else:
        return False
    return True


# Generated at 2022-06-25 01:40:28.748041
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        # Get the expected exception
        exception = get_exception()
        assert exception is not None
        assert isinstance(exception, NameError)
    else:
        raise AssertionError('No exception raised')



# Generated at 2022-06-25 01:40:32.236486
# Unit test for function get_exception
def test_get_exception():
    try:
        # this can generate a NameError
        test_case_0()
    except:
        # pylint: disable=bare-except
        assert type(get_exception()) == NameError
        assert get_exception().__str__() == "global name 'var_0' is not defined"



# Generated at 2022-06-25 01:40:34.830553
# Unit test for function get_exception

# Generated at 2022-06-25 01:40:41.448533
# Unit test for function get_exception
def test_get_exception():
    # Load the tests as a Python module
    tests = load_module_from_name('ansible.module_utils.basic.__init__',
                                  basic_utils_path)

    # Add the module to the module path so that we can import
    # get_exception
    sys.modules['ansible.module_utils.basic'] = tests
    sys.modules['ansible.module_utils.basic.get_exception'] = tests.get_exception

    # Set up our mock environment
    mod = imp.new_module('test_get_exception')
    mod.__file__ = 'test_get_exception.py'
    sys.modules['test_get_exception'] = mod

# Generated at 2022-06-25 01:40:45.924898
# Unit test for function get_exception
def test_get_exception():
    """
    Function to test get_exception
    Parameters:

    """
    # Test case 0
    try:
        var_0 = get_exception()
    except BaseException:
        return

# Generated at 2022-06-25 01:40:48.978698
# Unit test for function get_exception
def test_get_exception():

    try:
        literal_eval(1)
    except:
        var_0 = get_exception()

# Generated at 2022-06-25 01:40:51.199788
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_1 = get_exception()

# Generated at 2022-06-25 01:41:01.398616
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_1 = get_exception()
    assert str(type(var_1)) == "<type 'exceptions.NameError'>"
    assert str(var_1) == "global name 'test_case_0' is not defined"
    assert literal_eval("''") == ''
    assert literal_eval("'1'") == '1'
    assert literal_eval("1") == 1
    assert literal_eval("1.0") == 1.0
    assert literal_eval("1.0+1.0j") == 1.0+1.0j
    assert literal_eval("True") == True
    assert literal_eval("False") == False
    assert literal_eval("None") == None

# Generated at 2022-06-25 01:41:07.178838
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as var_1:
        assert 'var_1' in vars()
        assert isinstance(var_1, NameError)


# Generated at 2022-06-25 01:41:14.336505
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()

    # Check if isinstance(var_0, )
    # assert isinstance(var_0, None)
    # Check if var_0.args ==
    # assert var_0.args == 
    # Check if str(var_0) ==
    # assert str(var_0) == 



# Generated at 2022-06-25 01:41:56.259758
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        actual = get_exception()
        assert actual == exc_value, "actual={}, exc_value={}".format(actual, exc_value)



# Generated at 2022-06-25 01:42:00.348512
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
        assert False
    except AssertionError:
        assert False
        print('AssertionError raised')
    except NameError:
        print ('NameError raised')
    except TypeError:
        print ('TypeError raised')
    except SyntaxError:
        print ('SyntaxError raised')
    except:
        print ('An exception was raised, but not the expected one')


# Generated at 2022-06-25 01:42:05.446959
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test error')
    except Exception:
        var_0 = get_exception()
        print("Got string", var_0.args[0])
        print("Got convertable to dict", dict(var_0.args))
        assert var_0.args[0] == 'Test error'


# Generated at 2022-06-25 01:42:06.644128
# Unit test for function get_exception
def test_get_exception():
    # Input parameters
    # Output parameters

    # Execute function
    test_case_0()


# Generated at 2022-06-25 01:42:12.259430
# Unit test for function get_exception
def test_get_exception():
    print('Testing get_exception()')
    try:
        test_case_0()
    except Exception as e:
        assert get_exception() == e
    print('Passed')


# Generated at 2022-06-25 01:42:19.207555
# Unit test for function get_exception
def test_get_exception():
    # Try to assign to a non-existent variable
    try:
        test_case_0()
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError)
    assert str(e) == "name 'NameError' is not defined"



# Generated at 2022-06-25 01:42:21.463462
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        # If we got here, get_exception must have worked
        pass
    else:
        # We should have caught this case
        assert False


# Generated at 2022-06-25 01:42:25.338520
# Unit test for function get_exception
def test_get_exception():
    """ Function to test get_exception()
    :return: Nothing
    """

    # Check if exception is raised
    try:
        assert not test_case_0()
    except AssertionError:
        return


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-25 01:42:28.537355
# Unit test for function get_exception
def test_get_exception():

    try:
        var_1 = test_case_0()
    except Exception:
        var_1 = get_exception()

    assert var_1


# Generated at 2022-06-25 01:42:34.700909
# Unit test for function get_exception
def test_get_exception():

    # 3:
    var_0 = get_exception()

    # 4:
    assert var_0 == None



# Generated at 2022-06-25 01:43:57.660144
# Unit test for function get_exception
def test_get_exception():
    # Test with no exception
    test_case_0()
    try:
        int('abc')
    except ValueError:
        var_0 = get_exception()
        assert True
    else:
        assert False
    # Test with a real exception
    assert var_0.__class__ == ValueError



# Generated at 2022-06-25 01:44:01.652382
# Unit test for function get_exception
def test_get_exception():
    '''
    Test: get_exception
    '''
    # test_case_0
    try:
        test_case_0()
    except AssertionError as e:
        if 'Exception' in str(e):
            pass  # exception was raised
        else:
            raise



# Generated at 2022-06-25 01:44:02.840704
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert isinstance(var_0, Exception)


# Generated at 2022-06-25 01:44:14.223504
# Unit test for function get_exception
def test_get_exception():
    try:
        # Test no parameters and no raises
        var_0 = get_exception()
        assert var_0 == None
    except:
        # Test no parameters and raises
        try:
           var_0 = get_exception()
           assert var_0 == None
        except:
            pass
    try:
        # Test no parameters and no raises
        var_0 = get_exception()
        assert var_0 == None
    except:
        # Test no parameters and raises
        try:
           var_0 = get_exception()
           assert var_0 == None
        except:
            pass

# Generated at 2022-06-25 01:44:16.887713
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:44:23.209136
# Unit test for function get_exception
def test_get_exception():
    # Raise an exception
    try:
        raise ValueError('Fail')
    # Verify that the exception is the ValueError we raised
    except ValueError:
        assert isinstance(get_exception(), ValueError)
    # The exception should be gone now
    assert get_exception() is None


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception, literal_eval

    def test_case_1():
        # Load args
        module = AnsibleModule(
            argument_spec=dict(
                test=dict(type='bool', require=True),
                test_arg=dict(type='str', require=True),
            )
        )
        params = module.params
        # Call function
       

# Generated at 2022-06-25 01:44:29.121497
# Unit test for function get_exception
def test_get_exception():
    # Testing basic functionality
    if 'get_exception' not in globals():
        raise AssertionError("get_exception was not defined")
    if '__all__' not in globals():
        raise AssertionError("__all__ was not defined")
    if 'literal_eval' not in globals():
        raise AssertionError("literal_eval was not defined")
    try:
        test_case_0()
    except:
        pass
    else:
        raise AssertionError("get_exception did not raise an exception")

# Generated at 2022-06-25 01:44:33.138249
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()
    try:
        assert(isinstance(e, Exception))
    except AssertionError as e:
        raise AssertionError(str(e) + '\n expected:Exception')


# Generated at 2022-06-25 01:44:38.960873
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        var_0 = e
    else:
        try:
            test_case_0()
        except NameError as e:
            var_0 = e
    finally:
        try:
            assert type(var_0) == type(get_exception())
        except AssertionError as e:
            raise AssertionError(str(e)+'\n'+"expected type '"+str(type(get_exception()))+"', got '"+str(type(var_0))+"'.")
        finally:
            assert type(var_0) == type(get_exception())



# Generated at 2022-06-25 01:44:41.247608
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        # We do not know what kind of exception to expect
        # so we let unittest decide.
        assert False, 'Uncaught exception.'

test_get_exception()

# Generated at 2022-06-25 01:47:46.117604
# Unit test for function get_exception
def test_get_exception():
    # check for None
    try:
        test_case_0()
    except:
        # Throws an error because there is no error to get
        e = get_exception()
        assert e is not None
    else:
        raise AssertionError()


# Generated at 2022-06-25 01:47:48.304067
# Unit test for function get_exception
def test_get_exception():
    print("test get_exception")
    try:
        raise Exception('catch me')
    except:
        result = get_exception()
    assert isinstance(result, Exception)


# Generated at 2022-06-25 01:47:58.206316
# Unit test for function get_exception
def test_get_exception():
    # check that the 'get_exception' function accepts no parameters
    assert len(get_exception.__code__.co_varnames) == 0
    # check that no exceptions were thrown
    assert get_exception() == None
    try:
        x = 1 / 0
    except:
        # check that the get_exception function returns the correct exception type
        assert isinstance(get_exception(), ZeroDivisionError)
    try:
        raise Exception("foo")
    except:
        # check that the get_exception function returns the correct exception type
        assert isinstance(get_exception(), Exception)
    # check that exceptions not in the list are not caught
    try:
        raise KeyError("bar")
    except:
        assert False


# Generated at 2022-06-25 01:47:59.006288
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None



# Generated at 2022-06-25 01:48:00.901387
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert False


from ansible.module_utils.six import string_types, text_type

# Generated at 2022-06-25 01:48:07.314884
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError as e:
        if not e == var_0:
            print("get_exception() test failed!")
        else:
            print("get_exception() test passed!")

try:
    # Python 2.6+
    from ast import literal_eval
except ImportError:
    # a replacement for literal_eval that works with python 2.4. from:
    # https://mail.python.org/pipermail/python-list/2009-September/551880.html
    # which is essentially a cut/paste from an earlier (2.6) version of python's
    # ast.py
    from compiler import ast, parse
    from ansible.module_utils.six import binary_type, integer_types, string_types, text_type

# Generated at 2022-06-25 01:48:08.415786
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        check_exception_str(str(e))


# Generated at 2022-06-25 01:48:14.199190
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(KeyError) as e:
        var_0 = get_exception()
    assert str(e.value) == 'get_exception(): exception at 0x12398e0'



# Generated at 2022-06-25 01:48:19.717923
# Unit test for function get_exception

# Generated at 2022-06-25 01:48:23.193289
# Unit test for function get_exception
def test_get_exception():
    var_0 = None
    try:
        test_case_0()
    except:
        var_0 = get_exception()
    assert isinstance(var_0, NameError)
    assert var_0.message == "global name 'NameError' is not defined"
    assert var_0.args == ("global name 'NameError' is not defined",)

