

# Generated at 2022-06-25 01:38:55.821811
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()

    if (var_0 is not None):
        assert False


# Generated at 2022-06-25 01:38:58.999101
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = get_exception()
    except ValueError:
        var_0 = get_exception()


# Generated at 2022-06-25 01:39:09.468844
# Unit test for function get_exception
def test_get_exception():
    # Define a class for the test
    class CustomException(Exception):
        pass
    var_0 = None
    try:
        var_0 = get_exception()
    except NameError:
        pass
    assert var_0 is None
    var_1 = None
    try:
        test_case_0()
    except NameError:
        var_1 = get_exception()
    assert type(var_1).__name__ == 'NameError'
    var_2 = None
    try:
        raise CustomException('testing')
    except CustomException:
        var_2 = get_exception()
    assert var_2.message == 'testing'
    var_3 = None
    try:
        raise Exception('testing')
    except:
        var_3 = get_exception()
    assert var_3

# Generated at 2022-06-25 01:39:11.100155
# Unit test for function get_exception
def test_get_exception():
    # Make sure the function throws an exception
    failed = False
    try:
        test_case_0()
    except Exception:
        failed = True

    assert failed


# Generated at 2022-06-25 01:39:15.595338
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as exc:
        exception = get_exception()
        assert exception == exc



# Generated at 2022-06-25 01:39:19.116077
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == var_0



# Generated at 2022-06-25 01:39:23.049006
# Unit test for function get_exception
def test_get_exception():
    # Access global var defined in try
    global var_0
    try:
        test_case_0()
    except Exception:
        e = get_exception()
        assert var_0 == e.args[0]

# Generated at 2022-06-25 01:39:25.265212
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        assert get_exception().__class__.__name__ == 'ValueError'


# Generated at 2022-06-25 01:39:30.321117
# Unit test for function get_exception
def test_get_exception():
    """
    This test case asserts that for a known set of inputs
    get_exception returns the expected values.
    """
    var_0 = get_exception()



# Generated at 2022-06-25 01:39:41.834969
# Unit test for function get_exception
def test_get_exception():
    # Make sure there is no exception raised and the function returns expected value
    try:
        test_case_0()
    except Exception as err:
        assert False, f'Expected: no exception thrown. Actual: {err} thrown.'
    # Make sure an exception is raised and the function does not return any value
    try:
        raise Exception('Error thrown')
    except Exception as err:
        assert err == get_exception(), f'Expected: same exception object. Actual: different exception object.'
    # Make sure an exception is raised and the function does not return any value
    try:
        raise Exception('Error thrown')
    except Exception as err:
        try:
            get_exception()
            assert False, 'Expected: exception thrown. Actual: no exception thrown.'
        except Exception:
            assert True


# Generated at 2022-06-25 01:39:56.950170
# Unit test for function get_exception
def test_get_exception():
    # for function get_exception
    try:
        # usage of get_exception
        var_0 = get_exception()
    except:
        var_0 = get_exception()
    assert 'AnsibleModule' in str(var_0), "AnsibleModule must be part of error message"



# Generated at 2022-06-25 01:39:59.771026
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
        raise Exception('get_exception return value: ' + repr(var_0)) from var_0
    else:
        raise Exception('unreachable')


# Generated at 2022-06-25 01:40:02.376883
# Unit test for function get_exception
def test_get_exception():
    '''
    Test if the function get_exception is working correctly
    '''
    try:
        test_case_0()
    except:
        e = get_exception()
        assert isinstance(e, Exception)


# Generated at 2022-06-25 01:40:10.902969
# Unit test for function get_exception

# Generated at 2022-06-25 01:40:12.288413
# Unit test for function get_exception
def test_get_exception():
    test_cases = [test_case_0]
    for test in test_cases:
        test()


# Generated at 2022-06-25 01:40:15.148701
# Unit test for function get_exception
def test_get_exception():
    """
    Unit test for the get_exception function
    """
    try:
        test_case_0()
    except:
        exc = get_exception()
    assert exc.__class__.__name__ == 'TypeError'



# Generated at 2022-06-25 01:40:17.790693
# Unit test for function get_exception
def test_get_exception():
    var_1 = None
    var_2 = get_exception()
    assert var_2 == var_1, 'assert value expected: %s, actual: %s' % ('var_1', 'var_2')


# Generated at 2022-06-25 01:40:18.575304
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

# Generated at 2022-06-25 01:40:21.159610
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        if __name__ == '__main__':
            from ansible.module_utils.six import Exception
            raise Exception("Error running test_case_0")



# Generated at 2022-06-25 01:40:29.406513
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError as e:
        assert str(get_exception()) == 'foo'
    try:
        raise SyntaxError("invalid syntax")
    except SyntaxError as e:
        assert str(get_exception()) == "invalid syntax"
    try:
        raise Exception("blah blah blah")
    except Exception as e:
        assert str(get_exception()) == 'blah blah blah'



# Generated at 2022-06-25 01:40:48.948671
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_exception")
    except:
        assert get_exception() is not None



# Generated at 2022-06-25 01:40:50.904969
# Unit test for function get_exception
def test_get_exception():
    # make sure that it can handle the basic case
    assert test_case_0() == None

# Generated at 2022-06-25 01:40:52.432996
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except NameError:
        pass


# Generated at 2022-06-25 01:40:58.433868
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
        print(var_0)
        print('test_case_0 complete')


# Unit test
if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:41:04.228861
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test error')
    except RuntimeError as e:
        var_1 = get_exception()
        var_2 = get_exception()
        var_3 = get_exception()
        var_4 = get_exception()
        var_5 = get_exception()
        var_6 = get_exception()
        var_7 = get_exception()
        var_8 = get_exception()
        var_9 = get_exception()
        var_10 = get_exception()
        var_11 = get_exception()
        var_12 = get_exception()
        var_13 = get_exception()
        var_14 = get_exception()
        var_15 = get_exception()
        var_16 = get_exception()

# Generated at 2022-06-25 01:41:08.995926
# Unit test for function get_exception
def test_get_exception():
    var_0 = literal_eval("['hello', 'world']")
    assert var_0 == ['hello', 'world']
    var_1 = literal_eval("('foo', 'bar')")
    assert var_1 == ('foo', 'bar')
    var_2 = literal_eval("{'foo': 'bar', 'baz': 'qux'}")
    assert var_2 == {'foo': 'bar', 'baz': 'qux'}
    var_3 = literal_eval("'foo'")
    assert var_3 == 'foo'
    var_4 = literal_eval("u'foo'")
    assert var_4 == u'foo'
    var_5 = literal_eval("b'foo'")
    assert var_5 == b'foo'

# Generated at 2022-06-25 01:41:13.941229
# Unit test for function get_exception
def test_get_exception():
    import pytest

    # Call function
    try:
        test_case_0()
    except:
        pass

    # Check if test1 worked
    with pytest.raises(NameError):
        literal_eval("test1")

    # Check if test2 worked
    assert literal_eval("True") == True

# Generated at 2022-06-25 01:41:16.399518
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SyntaxError("Error")
    except SyntaxError:
        e = get_exception()
        assert e.args[0] == 'Error'

# Generated at 2022-06-25 01:41:18.174751
# Unit test for function get_exception
def test_get_exception():
    # No error should occur
    try:
        test_case_0()
    except Exception:
        assert False, 'An error occurred'

# Generated at 2022-06-25 01:41:19.493125
# Unit test for function get_exception
def test_get_exception():
    result = get_exception()
    assert result == None


# Generated at 2022-06-25 01:41:56.039968
# Unit test for function get_exception
def test_get_exception():
    # Unit test for function get_exception
    try:
        test_case_0()
    except:
        exception = get_exception()
    pass



# Generated at 2022-06-25 01:41:58.496582
# Unit test for function get_exception
def test_get_exception():
    # Test function get_exception

    assert isinstance(get_exception(), Exception)
    try:
        test_case_0()
        assert False
    except Exception as ex:  # NOQA
        assert isinstance(get_exception(), Exception)

# Generated at 2022-06-25 01:42:08.820385
# Unit test for function get_exception
def test_get_exception():
    # if no exception is raised, get_exception should return None
    assert test_case_0() is None, "get_exception should return None if no exception is raised"
    # if an exception is raised, get_exception should return that exception
    try:
        # raises a NameError because there is a reference to a non-existant variable
        literal_eval('a')
    except NameError:
        # raises a ValueError because the object passed to get_exception is not an exception
        # object
        try:
            get_exception(5)
        except ValueError as e:
            assert str(e) == "invalid exception object", "get_exception should raise proper ValueError"
        else:
            assert False, "get_exception should raise error when invalid object passed"

# Generated at 2022-06-25 01:42:10.322254
# Unit test for function get_exception
def test_get_exception():
    pass


# Generated at 2022-06-25 01:42:12.710712
# Unit test for function get_exception
def test_get_exception():

    try:
        test_case_0()
    except Exception as e:
        if e.args[0] == 'malformed string':
            raise Exception('test_case_0() raise malformed string')
        else:
            print(e)
            raise

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-25 01:42:16.924422
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()
    assert var_0 == 'e'



# Generated at 2022-06-25 01:42:19.415554
# Unit test for function get_exception
def test_get_exception():
    # Unit test for function get_exception
    # Exception messages may vary, so let's not actually try to raise an
    # exception.
    pass


# Generated at 2022-06-25 01:42:22.516647
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(Exception) as e:
        test_case_0()
    assert e == get_exception()


# Generated at 2022-06-25 01:42:24.106358
# Unit test for function get_exception
def test_get_exception():
    # No needs tests for get_exception
    pass

    # Unit test for function literal_eval


# Generated at 2022-06-25 01:42:26.381304
# Unit test for function get_exception
def test_get_exception():
    # Testing if get_exception() raises SyntaxError
    # Testing if get_exception() raises NameError
    # Testing if get_exception() raises ValueError
    pass


# Generated at 2022-06-25 01:43:47.580387
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("NameError")
    except NameError:
        assert get_exception()


# Generated at 2022-06-25 01:43:52.419258
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()

        raises(Exception, get_exception)
    except:
        answer = get_exception()
        assert True


# Generated at 2022-06-25 01:43:53.721001
# Unit test for function get_exception
def test_get_exception():
    # Set up test inputs
    var_0 = None



# Generated at 2022-06-25 01:43:54.884472
# Unit test for function get_exception
def test_get_exception():
    # I assume the test should pass -- this is just a stub
    assert True


# Generated at 2022-06-25 01:43:58.484464
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        exception = get_exception()
        assert exception.args == ('test',)
    else:
        assert False, 'did not catch exception'


# Generated at 2022-06-25 01:43:59.889739
# Unit test for function get_exception
def test_get_exception():

    # the exception will not be thrown until the test_case_0 returns
    test_case_0()



# Generated at 2022-06-25 01:44:01.036720
# Unit test for function get_exception
def test_get_exception():
    # Perform basic sanity checking on the AnsibleModule object
    assert test_case_0()

# Generated at 2022-06-25 01:44:01.710200
# Unit test for function get_exception
def test_get_exception():
    assert not literal_eval("test_case_0()")

# Generated at 2022-06-25 01:44:04.548903
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Assert Exception")
    except Exception as e:
        assert literal_eval(str(e)) == "Assert Exception"


# Generated at 2022-06-25 01:44:06.692834
# Unit test for function get_exception
def test_get_exception():
    # If a function raises an exception, then `get_exception()` should return it.
    try:
        raise Exception('something happened')
    except:
        pytest.raises(Exception, test_case_0)


# Generated at 2022-06-25 01:47:13.021065
# Unit test for function get_exception
def test_get_exception():
    input = 'test_data'
    result = get_exception(input)
    assert result == 'expected result'


# Generated at 2022-06-25 01:47:16.137127
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        exception = get_exception()
    assert exception is not None, "Value of exception is none"


# Generated at 2022-06-25 01:47:25.062217
# Unit test for function get_exception
def test_get_exception():
    var_0 = literal_eval("1")
    assert var_0 == 1
    var_1 = literal_eval("'str'")
    assert var_1 == 'str'
    var_2 = literal_eval("{}")
    assert var_2 == {}
    var_3 = literal_eval("[]")
    assert var_3 == []
    var_4 = literal_eval("()")
    assert var_4 == ()
    var_5 = literal_eval("True")
    assert var_5 == True
    var_6 = literal_eval("False")
    assert var_6 == False
    var_7 = literal_eval("[str(x) for x in range(10)]")

# Generated at 2022-06-25 01:47:27.828523
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except TypeError as got:
        assert got.args[0] == 'get_exception() takes no arguments (1 given)', \
            'Expected Different Error Message'


# Generated at 2022-06-25 01:47:34.382067
# Unit test for function get_exception
def test_get_exception():
    # Test protocol 2
    try:
        pass
    except Exception as e:
        test_case_0()
    # Test protocol 3
    try:
        pass
    except Exception as e:
        test_case_0()
    # Test protocol 4
    try:
        pass
    except Exception as e:
        test_case_0()


# Generated at 2022-06-25 01:47:39.835791
# Unit test for function get_exception
def test_get_exception():
    # Tests the fallback get_exception() function
    try:
        test_case_0()
        assert False, "Expected an assertion error of some kind.  Python version: {}".format(sys.version_info)
    except AssertionError as e:
        assert not e.args[1] == "Expected an assertion error of some kind.  Python version: {}".format(sys.version_info)


# Generated at 2022-06-25 01:47:48.870702
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as ex:
        if ex is not var_0:
            raise ex

try:
    from ansible.module_utils.six import u
    UnicodeType = type(u(''))
except ImportError:
    UnicodeType = type('')

if sys.version_info[0] > 2:
    string_types = str
    integer_types = int
    class_types = type
    text_type = str
    binary_type = bytes
    long = int
else:
    string_types = basestring
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_type = unicode
    binary_type = str
    long = long

# Generated at 2022-06-25 01:47:50.444745
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    assert var_0 == None, "Invalid return value for function get_exception"


# Generated at 2022-06-25 01:47:53.702891
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as expected:
        assert expected == var_0
    else:
        assert False


# Generated at 2022-06-25 01:47:56.801059
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        print(repr(get_exception()))
