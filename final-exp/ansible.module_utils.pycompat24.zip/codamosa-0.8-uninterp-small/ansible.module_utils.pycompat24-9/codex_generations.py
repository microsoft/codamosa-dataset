

# Generated at 2022-06-25 01:39:02.252581
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-25 01:39:03.925445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('pwr')
    except Exception:
        e = get_exception()

    assert e.message == 'pwr'


# Generated at 2022-06-25 01:39:05.331305
# Unit test for function get_exception
def test_get_exception():
    # assert get_exception() == 'this is a test'
    var_0 = get_exception()


# Generated at 2022-06-25 01:39:12.866606
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        test_exception = get_exception()
    assert test_exception is None


test_value_0 = 'abc123'
test_value_1 = '"abc123"'
test_value_2 = 1
test_value_3 = '1'
test_value_4 = ['abc', '123']
test_value_5 = '["abc", "123"]'
test_value_6 = {'abc': 123}
test_value_7 = '{"abc": 123}'

# Generated at 2022-06-25 01:39:14.107065
# Unit test for function get_exception
def test_get_exception():
    var_1 = []
    assert test_case_0() == var_1


# Generated at 2022-06-25 01:39:26.553766
# Unit test for function get_exception
def test_get_exception():
    fp = open("test/unit/module_utils/basic.py")
    ast_tree = ast.parse(fp.read())
    fp.close()
    # Generate list of calls.
    calls = [node.value for node in ast.walk(ast_tree) if isinstance(node, ast.Call)]
    # Get the call we are interested in.
    test_case_0_call = [call for call in calls if call.func.id == "get_exception"][0]
    # Get the line number.
    test_case_0_lineno = test_case_0_call.lineno
    # Get the error causing line.

# Generated at 2022-06-25 01:39:29.732660
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test exception')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'This is a test exception'
    else:
        raise AssertionError('expected exception')



# Generated at 2022-06-25 01:39:31.100852
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() != None


# Generated at 2022-06-25 01:39:38.546374
# Unit test for function get_exception
def test_get_exception():
    # Test creating a class
    cls_0 = test_case_0()
    # Test calling a class's method
    cls_0.test_get_exception()
    # Test accessing an attribute of a class
    cls_0.var_0
    # Test accessing an element of a class's attribute (which is a list)
    cls_0.var_0[0]


# Generated at 2022-06-25 01:39:41.103828
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as test_exception:
        if test_exception is not None:
            print('Exception: ' + str(test_exception))
            return False
    return True



# Generated at 2022-06-25 01:39:50.077027
# Unit test for function get_exception
def test_get_exception():
    pass


# Generated at 2022-06-25 01:39:50.764499
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None

# Generated at 2022-06-25 01:39:52.641934
# Unit test for function get_exception
def test_get_exception():
    # Assert that function get_exception returns something
    assert get_exception()


# Generated at 2022-06-25 01:39:57.546791
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        if str(e) == 'This is an exception':
            pass
        else:
            raise e


# Generated at 2022-06-25 01:40:02.722640
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info < (2, 6):
        try:
            test_case_0()
        except IndexError as e:
            assert e == get_exception()
        except ValueError:
            assert e == get_exception()
    else:
        try:
            test_case_0()
        except ValueError as e:
            assert e == get_exception()


KNOWN_TYPES = (int, float, bool, list, tuple, set, frozenset, dict, text_type, binary_type)



# Generated at 2022-06-25 01:40:04.054913
# Unit test for function get_exception
def test_get_exception():

    # Set mock attributes:
    exception = test_case_0()

    # Begin tests



# Generated at 2022-06-25 01:40:10.265214
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            test_case_0()
        except ValueError:
            e = get_exception()
    except:
        # This is to prevent pylint from complaining that we don't have a
        # "except:" that catches BaseException.  This code should never
        # execute.
        assert True == False



# Generated at 2022-06-25 01:40:12.839318
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = 0 / 0
    except:
        var_1 = get_exception()
        if isinstance(var_1, ZeroDivisionError):
            assert True
        else:
            assert False



# Generated at 2022-06-25 01:40:16.640679
# Unit test for function get_exception
def test_get_exception():
    print ("Test :: test_get_exception")
    try:
        test_case_0()
    except:  # noqa
        exception = get_exception()
        assert isinstance(exception, TypeError)
        assert exception.args == (
            'get_exception() takes no arguments (1 given)',)



# Generated at 2022-06-25 01:40:19.552465
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()

    if not isinstance(e, Exception):
        raise AssertionError("expected Exception type, but got: %s" % type(e))



# Generated at 2022-06-25 01:40:29.757991
# Unit test for function get_exception
def test_get_exception():
    # Test with positional arguments
    args = ('arg1', 'arg2')
    assert test_case_0() == get_exception(*args)



# Generated at 2022-06-25 01:40:37.435451
# Unit test for function get_exception
def test_get_exception():
    # Creating global var_1
    global var_1
    # Creating global var_2
    global var_2
    # Creating global var_3
    global var_3
    # Creating global var_4
    global var_4
    # Creating global var_5
    global var_5
    # Creating global var_6
    global var_6
    # Creating global var_7
    global var_7
    # Creating global result
    global result
    # Creating global exception
    global exception

# Generated at 2022-06-25 01:40:39.027932
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
    except:
        var_1 = get_exception()
        print(var_1)


# Generated at 2022-06-25 01:40:41.737172
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        e = get_exception()

    # FIXME: check that e is a valid exception object
    # FIXME: check that it is the exception we threw above



# Generated at 2022-06-25 01:40:42.967188
# Unit test for function get_exception
def test_get_exception():
    assert var_0 != None



# Generated at 2022-06-25 01:40:44.920618
# Unit test for function get_exception
def test_get_exception():
    with_exception = False
    try:
        test_case_0()
    except Exception:
        with_exception = True
    assert with_exception is False


# Generated at 2022-06-25 01:40:45.864208
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == None

# Generated at 2022-06-25 01:40:48.044148
# Unit test for function get_exception
def test_get_exception():
    raise Exception()



# Generated at 2022-06-25 01:40:49.557980
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        ret_0 = get_exception()


# Generated at 2022-06-25 01:40:52.169660
# Unit test for function get_exception
def test_get_exception():
    e = get_exception()
    assert (e is None)



# Generated at 2022-06-25 01:41:11.980699
# Unit test for function get_exception
def test_get_exception():
    try:
        do_something_that_might_raise_an_exception()
    except Exception:
        e = get_exception()


# Generated at 2022-06-25 01:41:15.701877
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except:
        exception = get_exception()
    assert exception.__class__ == RuntimeError


# Generated at 2022-06-25 01:41:18.058384
# Unit test for function get_exception
def test_get_exception():
    try:
        var_1 = test_case_0()
    except RuntimeError as var_2:
        var_3 = var_2
    assert(var_3 is
        var_0)


# Generated at 2022-06-25 01:41:19.694691
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == get_exception()
    assert literal_eval("2+2") == 4

# Generated at 2022-06-25 01:41:21.515560
# Unit test for function get_exception
def test_get_exception():
    assert callable(get_exception)
    assert isinstance(get_exception(), object)


# Generated at 2022-06-25 01:41:25.191529
# Unit test for function get_exception
def test_get_exception():
    test_case_0()

test_case_0.__name__ = 'test_case_0'

if __name__ == '__main__':
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_get_exception))
    unittest.main()

# Generated at 2022-06-25 01:41:26.494218
# Unit test for function get_exception
def test_get_exception():
    func = lambda: (1/0)
    try:
        func()
    except ZeroDivisionError:
        assert(type(get_exception()) == type((1/0)))


# Generated at 2022-06-25 01:41:28.334978
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()

    except Exception as e:
        var_1 = get_exception()

        if not isinstance(var_1, var_1):
            raise AssertionError()

# Generated at 2022-06-25 01:41:31.092219
# Unit test for function get_exception
def test_get_exception():
    # Arrange
    var_0 = None
    var_1 = None

    # Act
    try:
        test_case_0()
    except NameError as var_1:
        var_0 = var_1

    # Assert
    assert(type(var_0) == NameError)
    assert(var_0 == var_1)


# Generated at 2022-06-25 01:41:32.330751
# Unit test for function get_exception
def test_get_exception():
  assert(test_case_0() == None)


# Generated at 2022-06-25 01:42:08.003165
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        var_0 = get_exception()

    # The next line allows the exception to propagate up the stack.
    raise var_0

# Generated at 2022-06-25 01:42:11.346430
# Unit test for function get_exception
def test_get_exception():
    try:
        get_exception()
    except:
        TypeError('unsupported type')

# Generated at 2022-06-25 01:42:14.334754
# Unit test for function get_exception
def test_get_exception():
    try:
        # Tested function will raise the following error
        raise NotImplementedError
    except Exception:
        var_0 = get_exception()
    # Check if the exception message is the same as the one raised
    assert var_0.args[0] == "NotImplementedError"


# Generated at 2022-06-25 01:42:18.622600
# Unit test for function get_exception
def test_get_exception():
    # Tests for function get_exception
    try:
        var_0 = int('test')
    except Exception:
        # expected syntax error
        var_0 = get_exception()
    assert isinstance(var_0, ValueError)

# Generated at 2022-06-25 01:42:21.331705
# Unit test for function get_exception
def test_get_exception():
    var_1 = get_exception()



# Generated at 2022-06-25 01:42:23.785047
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-25 01:42:25.147392
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        assert True



# Generated at 2022-06-25 01:42:28.373130
# Unit test for function get_exception
def test_get_exception():
    variable_0 = get_exception()
    variable_0 = literal_eval(variable_0)
    variable_0 = variable_0.__name__
    variable_1 = test_case_0(variable_0)
    variable_1 = variable_0.__name__
    variable_1 = variable_0.__name__

# Generated at 2022-06-25 01:42:31.884844
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None


# Generated at 2022-06-25 01:42:34.166615
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        pass



# Generated at 2022-06-25 01:43:48.899142
# Unit test for function get_exception
def test_get_exception():
    assert len(get_exception()) == len(test_case_0())


# Generated at 2022-06-25 01:43:53.230825
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_1 = get_exception()
        raise Exception(var_1)

 # Unit test for function literal_eval

# Generated at 2022-06-25 01:43:54.743493
# Unit test for function get_exception
def test_get_exception():
    try:
        # Test no exception case
        assert test_case_0() == None

    except AssertionError:
        # Test for exception case
        assert False

# Generated at 2022-06-25 01:43:56.212827
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
    assert 1 == 1


# Generated at 2022-06-25 01:43:58.924309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test_get_exception')
    except RuntimeError:
        caught_exc = get_exception()
    assert caught_exc.args[0] == 'test_get_exception'



# Generated at 2022-06-25 01:44:00.213995
# Unit test for function get_exception
def test_get_exception():
    test_case_0()


# Generated at 2022-06-25 01:44:04.348547
# Unit test for function get_exception
def test_get_exception():
    case_0 = (
        "No exception",
        "int",
        test_case_0()
    )

    tests = [case_0]
    for test in tests:
        assert test[-1] == test[-2]


# Generated at 2022-06-25 01:44:07.362907
# Unit test for function get_exception
def test_get_exception():
    with pytest.raises(AttributeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    the_exception_msg = str(the_exception)
    print(the_exception_msg)
    assert "module '__main__' has no attribute 'get_exception'" in the_exception_msg
#

# Generated at 2022-06-25 01:44:08.426569
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()

# Generated at 2022-06-25 01:44:10.078583
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        e = get_exception()

    assertTrue(isinstance(e, RuntimeError))
    assertEqual(str(e), "TEST")



# Generated at 2022-06-25 01:47:13.514397
# Unit test for function get_exception
def test_get_exception():
    """
    Function:  get_exception()
    Tests basic functionality.  Exercises the except block.
    """
    try:
        test_case_0()
    except: # NOQA
        e = get_exception()
    assert e, 'Unable to get current exception.'


# Generated at 2022-06-25 01:47:15.683933
# Unit test for function get_exception
def test_get_exception():
    # No exceptions were thrown
    assert test_get_exception.__assertions__ == 0


# Generated at 2022-06-25 01:47:16.960281
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:47:18.041419
# Unit test for function get_exception
def test_get_exception():
    var_0 = test_case_0()
    assert var_0 is None


# Generated at 2022-06-25 01:47:25.347399
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        _e = get_exception()
        print("get_exception():", _e)
        print("str(get_exception()):", str(_e))
        if get_exception() is not _e:
            raise AssertionError("get_exception() value mismatch")
        if str(get_exception()) != str(_e):
            raise AssertionError("str(get_exception()) mismatch")
    else:
        raise AssertionError("get_exception() test properly failed")


# Generated at 2022-06-25 01:47:33.935149
# Unit test for function get_exception
def test_get_exception():
    print("Testing get_exception")
    tr = TypeRegister()

# Generated at 2022-06-25 01:47:37.509256
# Unit test for function get_exception
def test_get_exception():
    try:
        var_1 = test_case_0()
    except Exception:
        var_1 = get_exception()
    finally:
        assert var_1 == sys.exc_info()[1]



# Generated at 2022-06-25 01:47:39.658278
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() == None
    assert get_exception() == None
    assert get_exception() == None
    assert get_exception() == None


# Generated at 2022-06-25 01:47:45.591817
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
    except:
        var_0 = get_exception()
    if str(type(var_0)) != "<type 'exceptions.NameError'>":
        raise AssertionError("Unexpected type for get_exception, expected <type 'exceptions.NameError'>, but got: " + str(type(var_0)))


# Generated at 2022-06-25 01:47:46.463785
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        assert True
    else:
        assert False

