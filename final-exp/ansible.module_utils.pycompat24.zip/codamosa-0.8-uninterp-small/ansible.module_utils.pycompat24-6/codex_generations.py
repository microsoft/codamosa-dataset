

# Generated at 2022-06-25 01:39:05.602238
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 5*5
        print("heya")
    except:
        e_val = get_exception()
        print("e_val:", e_val)
        print("type(e_val):", type(e_val))
        assert(e_val.args[0] == "heya")


test_get_exception()

# Generated at 2022-06-25 01:39:09.833240
# Unit test for function get_exception
def test_get_exception():
    # test main
    try:
      test_case_0()
    except Exception:
      ansible_0 = get_exception()
      assert ansible_0 == unittest.SkipTest


# Generated at 2022-06-25 01:39:13.341167
# Unit test for function get_exception
def test_get_exception():
    """
    Test if the function get_exception returns the current exception.

    """
    try:
        raise ValueError("fake ValueError exception")
    except ValueError:
        try:
            test_case_0()
        except:
            var_0 = get_exception()
        assert var_0.args[0] == "fake ValueError exception"



# Generated at 2022-06-25 01:39:21.162907
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0
    else:
        assert False
    try:
        test_case_0()
    except 2 as e:
        assert e == var_0
    else:
        assert False
    try:
        test_case_0()
    except TypeError as e:
        assert e == var_0
    else:
        assert False
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0
    else:
        assert False
    try:
        test_case_0()
    except TypeError as e:
        assert e == var_0
    else:
        assert False



# Generated at 2022-06-25 01:39:24.977727
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        print("An exception occurred")


# Generated at 2022-06-25 01:39:26.769806
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()


# Generated at 2022-06-25 01:39:31.581788
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()
        assert var_0.message == '"test_case_0()" not defined', var_0.message
    var_0 = literal_eval('2+2')
    assert var_0 == '2+2', var_0

# Generated at 2022-06-25 01:39:32.248914
# Unit test for function get_exception
def test_get_exception():
    assert literal_eval('1') == 1

# Generated at 2022-06-25 01:39:37.881873
# Unit test for function get_exception
def test_get_exception():
    """
    Call ``get_exception`` to ensure it returns what you expect.
    """
    try:
        1/0
    except:
        var_0 = get_exception()

    assert var_0.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-25 01:39:39.621000
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        if get_exception() is None:
            assert False
        else:
            assert True



# Generated at 2022-06-25 01:39:58.484345
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        err = sys.exc_info()[1]
        exception = get_exception()
        assert exception == err


# Generated at 2022-06-25 01:39:59.818818
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        result = get_exception()
        assert result == None


# Generated at 2022-06-25 01:40:00.606861
# Unit test for function get_exception
def test_get_exception():
    test_case_0()

# Generated at 2022-06-25 01:40:07.683629
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except:
        var_0 = get_exception()

    var_1 = literal_eval('False')
    var_2 = literal_eval('True')
    var_3 = literal_eval('None')
    var_4 = literal_eval('[]')
    var_5 = literal_eval('{}')
    var_6 = literal_eval('{"a": 1}')
    var_7 = literal_eval('1.1')
    var_8 = literal_eval('1')
    var_9 = literal_eval('1L')
    var_10 = literal_eval('1.0')
    var_11 = literal_eval('1j')
    var_12 = literal_eval('var_3')
    var_13 = literal_eval('(1, 2)')

# Generated at 2022-06-25 01:40:10.713309
# Unit test for function get_exception
def test_get_exception():
    # Raises SyntaxError due to invalid syntax
    # literal_eval('{"key": "value",}')
    pass

# Generated at 2022-06-25 01:40:12.034530
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        var_0 = get_exception()
    assert isinstance(var_0, ZeroDivisionError)


# Generated at 2022-06-25 01:40:12.839850
# Unit test for function get_exception
def test_get_exception():
    test_case_0()



# Generated at 2022-06-25 01:40:15.754394
# Unit test for function get_exception
def test_get_exception():

    try:
        test_case_0()
    except Exception as e:
        if e != get_exception():
            print("get_exception() Error")


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-25 01:40:17.802169
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as exc:
        retval = type(exc)


        assert retval == AttributeError



# Generated at 2022-06-25 01:40:19.519800
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        assert get_exception() is not None


# Generated at 2022-06-25 01:40:37.199619
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("msg")
    except ValueError:
        ex = get_exception()
        assert ex.args[0] == "msg"



# Generated at 2022-06-25 01:40:41.773710
# Unit test for function get_exception
def test_get_exception():
    """generate a simple exception"""
    try:
        test_case_0()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
    else:
        assert False, 'Expected an exception'


# Generated at 2022-06-25 01:40:43.003916
# Unit test for function get_exception
def test_get_exception():
    test_case_0()

# Generated at 2022-06-25 01:40:43.790357
# Unit test for function get_exception
def test_get_exception():
    pass



# Generated at 2022-06-25 01:40:47.112424
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        result = get_exception()
        expected = Exception('Test exception')
        assert result == expected
    else:
        raise Exception('Exception did not get raised')


# Generated at 2022-06-25 01:40:48.120994
# Unit test for function get_exception
def test_get_exception():
    var_0 = get_exception()



# Generated at 2022-06-25 01:40:50.457171
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception:
        ex = get_exception()
        # Assertion 'isinstance(ex, Exception)' failed (AttributeError)
        assert isinstance(ex, Exception)


# Generated at 2022-06-25 01:40:56.777799
# Unit test for function get_exception

# Generated at 2022-06-25 01:41:01.431020
# Unit test for function get_exception
def test_get_exception():
    try:
        call_function_with_type_checking(test_case_0, )
    except NameError as e:
        # Display the exception message
        print(str(e))



# Generated at 2022-06-25 01:41:09.296347
# Unit test for function get_exception
def test_get_exception():

    # unit test to test the case where no exception occurs
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 failed.")
        sys.exit(1)
    # unit test to test the case where an exception occurs
    try:
        raise Exception()
    except Exception as e:
        if e != get_exception():
            print("Test case 1 failed.")
            sys.exit(1)
    print("All tests passed.")
    sys.exit(0)



# Generated at 2022-06-25 01:41:50.084603
# Unit test for function get_exception
def test_get_exception():
    """
    Test that get_exception() returns the current exception in Python 2 and 3.
    """
    try:
        raise RuntimeError("Exception handling test")
    except:
        test_get_exception_exception = get_exception()
    if test_get_exception_exception != RuntimeError("Exception handling test"):
        raise AssertionError

    #
    # Test with Python 3.x to make sure that the get_exception function works for
    # Python 3.x
    #
    try:
        raise RuntimeError("Exception handling test")
    except:
        test_get_exception_exception_0 = get_exception()
    if test_get_exception_exception_0 != RuntimeError("Exception handling test"):
        raise AssertionError


# Generated at 2022-06-25 01:41:57.451575
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as error:
        assert type(error) is AssertionError, \
            "Expected AssertionError, got {0} instead".format(type(error))
    try:
        test_case_0()
    except Exception as exception:
        assert type(exception) is AssertionError, \
            "Expected AssertionError, got {0} instead".format(type(exception))
    else:
        assert False, "Expected Exception"


# Generated at 2022-06-25 01:42:03.680373
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1/0
    except:
        var_0 = get_exception()
        msg = "get_exception returned %s - expecting ZeroDivisionError" % var_0
        assert var_0.__class__.__name__ == "ZeroDivisionError", msg



# Generated at 2022-06-25 01:42:05.651864
# Unit test for function get_exception
def test_get_exception():
   get_exception()



# Generated at 2022-06-25 01:42:08.194196
# Unit test for function get_exception
def test_get_exception():
    test_case_0()
    try:
        a.b
    except:
        e = get_exception()
        assert e.__str__() == 'global name \'a\' is not defined'


# Generated at 2022-06-25 01:42:09.129139
# Unit test for function get_exception
def test_get_exception():
    assert test_case_0() == 0

test_get_exception()


# Generated at 2022-06-25 01:42:10.905336
# Unit test for function get_exception
def test_get_exception():
    try:
        sys.argv[1]
    except:
        e = get_exception()
        assert e.__class__.__name__ == IndexError.__name__



# Generated at 2022-06-25 01:42:13.239951
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        var_0 = get_exception()
    assert type(var_0) == type(test_case_0())

# Generated at 2022-06-25 01:42:17.619995
# Unit test for function get_exception

# Generated at 2022-06-25 01:42:22.967573
# Unit test for function get_exception
def test_get_exception():
    """
    Test :func:`ansible.module_utils.basic.get_exception`
    """
    try:
        test_case_0()
    except:
        get_exception()

# Generated at 2022-06-25 01:43:36.155108
# Unit test for function get_exception
def test_get_exception():
    pass



# Generated at 2022-06-25 01:43:37.754556
# Unit test for function get_exception
def test_get_exception():
    # Raises an exception
    # what was the exception, and was it expected?
    # exception
    try:
        test_case_0()
    except:
        e = get_exception()



# Generated at 2022-06-25 01:43:44.257583
# Unit test for function get_exception
def test_get_exception():
    foo = 'bar'
    try:
        2 + foo
    except:
        ex = get_exception()

    assert ex.args[0] == 'unsupported operand type(s) for +: \'int\' and \'str\''



# Generated at 2022-06-25 01:43:45.158843
# Unit test for function get_exception
def test_get_exception():
    assert var_0 == None


# Generated at 2022-06-25 01:43:46.178882
# Unit test for function get_exception
def test_get_exception():
    output = test_case_0()
    assert output == None


# Generated at 2022-06-25 01:43:48.400948
# Unit test for function get_exception
def test_get_exception():
    assert get_exception(test_case_0)


# Generated at 2022-06-25 01:43:52.417668
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        assert e == var_0


# Generated at 2022-06-25 01:43:53.721264
# Unit test for function get_exception
def test_get_exception():
    except_0 = get_exception()



# Generated at 2022-06-25 01:43:58.965104
# Unit test for function get_exception
def test_get_exception():
    # raise error to be captured
    try:
        raise RuntimeError("Test error for get_exception")
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == "Test error for get_exception"
    # test that gets the exception from the stack
    try:
        test_case_0()
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError)


# unit test for function literal_eval

# Generated at 2022-06-25 01:44:01.885302
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e:
        # Is the exception type message a string?
        assert isinstance(e.message, string_types)

# Generated at 2022-06-25 01:47:01.234254
# Unit test for function get_exception
def test_get_exception():
    # remove the following 'pass' statement when you write the test
    pass



# Generated at 2022-06-25 01:47:01.698039
# Unit test for function get_exception
def test_get_exception():
  var_0 = get_exception()



# Generated at 2022-06-25 01:47:07.434752
# Unit test for function get_exception
def test_get_exception():
    # Test for correct results.
    # Test for correct results (with exception raised)
    var_0 = get_exception()
    # Test for correct results (with failed assertion)
    var_1 = get_exception()


# Generated at 2022-06-25 01:47:10.374834
# Unit test for function get_exception
def test_get_exception():
    try:
        var_0 = test_case_0()
    except:
        var_0 = get_exception()
        assert var_0.args[0] == "global name 'test_case_0' is not defined"


# Generated at 2022-06-25 01:47:14.165823
# Unit test for function get_exception
def test_get_exception():
    # Evaluate the line above.
    try:
        test_case_0()
    except:
        # Evaluate the line below.
        var_0 = get_exception()
    else:
        assert 0, 'Test #0 failed'
    assert True


# Generated at 2022-06-25 01:47:18.236420
# Unit test for function get_exception
def test_get_exception():
    on_pass = "PASS"
    on_fail = "FAIL"

    try:
        test_case_0()
    except Exception:
        # Expected exception
        pass
    else:
        # Did not get expected exception
        return on_fail

    return on_pass


# Generated at 2022-06-25 01:47:21.135785
# Unit test for function get_exception
def test_get_exception():
    try:
        test_case_0()
    except Exception as e_0:
        e = get_exception()



# Generated at 2022-06-25 01:47:24.476776
# Unit test for function get_exception

# Generated at 2022-06-25 01:47:32.503061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Error')
    except RuntimeError:
        exc = get_exception()
        if exc.__class__ != RuntimeError:
            raise AssertionError('Failed to assert that raised exception is the same as saved exception')
        if exc.message != 'Error':
            raise AssertionError('Failed to assert that raised exception message is the same as saved exception message')
    try:
        raise AssertionError
    except AssertionError:
        exc = get_exception()
        if exc.__class__ != AssertionError:
            raise AssertionError('Failed to assert that raised exception is the same as saved exception')
        if exc.message is not None:
            raise AssertionError('Failed to assert that raised exception message is the same as saved exception message')



# Generated at 2022-06-25 01:47:37.420675
# Unit test for function get_exception
def test_get_exception():
    try:
        # Function to test get_exception
        var_0 = None
        return var_0
    except Exception:
        var_0 = get_exception()
        assert isinstance(var_0, Exception) == True
        assert str(get_exception()) == "<class 'Exception'>"
        assert "<class 'Exception'>" == "<class 'Exception'>"
        assert str(var_0) == "<class 'Exception'>"

