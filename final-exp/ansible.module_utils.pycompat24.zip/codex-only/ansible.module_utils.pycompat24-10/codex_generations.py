

# Generated at 2022-06-23 02:45:03.703932
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass

    try:
        raise CustomException('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, CustomException)
    assert e.args == ('foo',)



# Generated at 2022-06-23 02:45:11.998278
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {}, supports_check_mode=True)

    try:
        raise ValueError("Foo")
    except ValueError as e:
        assert get_exception() == e
        assert e == get_exception()
    else:
        assert False, "Should have raised an exception"

    try:
        raise ValueError("Foo")
    except ValueError:
        exc = get_exception()
        assert exc == ValueError("Foo")
    else:
        assert False, "Should have raised an exception"

# Generated at 2022-06-23 02:45:14.103701
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        exc = get_exception()
    assert 'test' in str(exc)

# Generated at 2022-06-23 02:45:25.054968
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import ansible.module_utils.six as six

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise RuntimeError('foo')
            except RuntimeError:
                ex = get_exception()
                self.assertEqual(RuntimeError, type(ex))
                if six.PY3:
                    self.assertEqual('foo', str(ex))
                else:
                    self.assertEqual('foo', ex.message)
            else:
                self.fail('Exception not raised')

# Generated at 2022-06-23 02:45:35.525976
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("Foo")
    except NameError as e:
        e2 = get_exception()
        assert e == e2

    try:
        raise NameError("Bar")
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError)
        assert e.args[0] == "Bar"

try:
    unicode
except NameError:
    # Python 3
    unicode = str

# older jython doesn't have this
if not hasattr(unicode, 'decode'):
    unicode.decode = lambda self, *args, **kwargs: self

if sys.version_info[0] == 2 and hasattr(unicode, 'maketrans'):
    # Python 2
    str = unicode
    bytes = str


# Generated at 2022-06-23 02:45:39.173621
# Unit test for function get_exception
def test_get_exception():
    """Unit test function for function get_exception"""
    import unittest

    try:
        raise ValueError("This is an exception")
    except:
        exc = get_exception()
    assert(exc)



# Generated at 2022-06-23 02:45:43.071734
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        exc_info = get_exception()
        assert exc_info.args == ('foo',), exc_info
    else:
        raise AssertionError('Failed to raise an exception')



# Generated at 2022-06-23 02:45:52.617527
# Unit test for function get_exception
def test_get_exception():
    import nose.tools

    # Ensure we can get an exception out of just except:
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        nose.tools.eq_(get_exception(), RuntimeError('Test exception'))
    except:
        raise AssertionError('Needed to catch RuntimeError in test_get_exception')

    # Ensure we can get an exception out of except Exception
    try:
        raise RuntimeError('Test exception')
    except Exception:
        nose.tools.eq_(get_exception(), RuntimeError('Test exception'))
    except:
        raise AssertionError('Needed to catch RuntimeError in test_get_exception')

    # Ensure the exception we get back isn't garbage collected
    try:
        raise RuntimeError('Test exception')
    except Exception:
        exc = get_ex

# Generated at 2022-06-23 02:45:55.420017
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert type(e) is ValueError



# Generated at 2022-06-23 02:45:57.931194
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:46:03.326845
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except RuntimeError:
        exc = get_exception()
        assert str(exc) == "Test exception", "Exception text is wrong: %r" % (str(exc),)

# Generated at 2022-06-23 02:46:06.404779
# Unit test for function get_exception
def test_get_exception():
    def testfunc():
        try:
            raise Exception('Hello world!')
        except Exception:
            return get_exception()
    assert testfunc().args == ('Hello world!',)



# Generated at 2022-06-23 02:46:11.715346
# Unit test for function get_exception
def test_get_exception():
    try:
        foo = 42
        raise ValueError("test_get_exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('test_get_exception',)


# Generated at 2022-06-23 02:46:14.364433
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        exc = e
    assert exc == get_exception()


# Generated at 2022-06-23 02:46:19.866877
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test Exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        if sys.version_info >= (3, 0):
            assert e.args == ('Test Exception',)
        else:
            assert e.args == ('Test Exception', None)


# Generated at 2022-06-23 02:46:23.641165
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except:
        e = get_exception()

    assert isinstance(e, MyException)


# Generated at 2022-06-23 02:46:25.847025
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("some error")
    except RuntimeError as e:
        e2 = get_exception()

    assert e == e2

# Generated at 2022-06-23 02:46:31.683751
# Unit test for function get_exception
def test_get_exception():
    # There's no way to automatically test this other than in an exception handler.
    # Do it as a function so we can test it.
    #
    # This code needs to work on Python 2.4 through 3.x, so we cannot use
    # "except Exception, e:" (SyntaxError on Python 3.x) nor
    # "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    # Instead we must use ::
    #
    #     except Exception:
    #         e = get_exception()
    def foo():
        raise Exception()
    try:
        foo()
    except Exception:
        assert isinstance(get_exception(), Exception)

# Generated at 2022-06-23 02:46:34.701914
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        exc = get_exception()
    assert exc.args[0] == "test"


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:41.309459
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError()
        except ValueError:
            return get_exception()
        except:  # noqa
            return None
    assert isinstance(f(), ValueError)

    def f():
        try:
            raise ValueError()
        except ValueError:
            e = get_exception()
            return type(e), e.args
        except:  # noqa
            return None
    e = f()
    assert isinstance(e, tuple)
    assert len(e) == 2
    assert e[0] is ValueError
    assert not e[1]


# Generated at 2022-06-23 02:46:46.905179
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('exc')
    except ValueError as e:
        assert e is get_exception()

    # Make sure the pytest capture of the exception result doesn't affect our
    # exception result
    try:
        raise ValueError('exc')
    except ValueError as e:
        pass
    assert e is not get_exception()



# Generated at 2022-06-23 02:46:49.560429
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'


# Generated at 2022-06-23 02:46:53.550748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemError('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, SystemError)
    assert str(e) == 'test'


# Test literal_eval

# Generated at 2022-06-23 02:46:55.691623
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
        assert e.args[0] == 'test exception'

# Generated at 2022-06-23 02:46:57.782555
# Unit test for function get_exception
def test_get_exception():
    def raises(): raise Exception()
    try:
        raises()
    except Exception:
        e = get_exception()
    return e

# Generated at 2022-06-23 02:47:01.004350
# Unit test for function get_exception
def test_get_exception():
    try:
        blah
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError)
    except Exception:
        assert False, "Expected NameError, got something else"



# Generated at 2022-06-23 02:47:02.588542
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        assert get_exception()

# Generated at 2022-06-23 02:47:04.389663
# Unit test for function get_exception

# Generated at 2022-06-23 02:47:07.999342
# Unit test for function get_exception
def test_get_exception():
    e_msg = 'testing get_exception'

    try:
        raise Exception(e_msg)
    except Exception:
        e = get_exception()
        assert e.message == e_msg
        assert repr(e) == repr(Exception(e_msg))
        assert str(e) == str(Exception(e_msg))


# Generated at 2022-06-23 02:47:10.343229
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert(e.args[0] == 'foo')

# Generated at 2022-06-23 02:47:15.141833
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'test'
        return
    assert False, "did not raise exception"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:19.447567
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert 1/0 == e
        assert 'integer division or modulo by zero' == str(e)

# Generated at 2022-06-23 02:47:23.062813
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foobar')
    except RuntimeError:
        exc = get_exception()
    assert isinstance(exc, RuntimeError)
    assert str(exc) == 'foobar'


# Generated at 2022-06-23 02:47:25.594789
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(42)
    except ValueError:
        e = get_exception()
        assert e.args == (42,)



# Generated at 2022-06-23 02:47:30.005572
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
    else:
        raise Exception("test failed: expected exception")



# Generated at 2022-06-23 02:47:32.710128
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except:
        e = get_exception()
        assert e.args[0] == 'test'

# Generated at 2022-06-23 02:47:38.563310
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    def testfunc():
        try:
            raise ValueError('foo')
        except ValueError:
            e = get_exception()
        return e

    assert isinstance(testfunc(), ValueError)
    assert testfunc().args[0] == 'foo'

# Generated at 2022-06-23 02:47:41.420359
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('dummy')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'dummy'

# Generated at 2022-06-23 02:47:44.477546
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test of get_exception')
    except:
        e = get_exception()
        assert e
        assert e.args == ('Test of get_exception',)


# Generated at 2022-06-23 02:47:53.993326
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=undefined-variable

        # Check that we can handle a NameError (builtin exception)
        raise NameError("UnboundLocalError example")
    except Exception:
        e = get_exception()
        if type(e) is not NameError:
            raise AssertionError("get_exception() returned wrong exception type")
        if str(e) != "UnboundLocalError example":
            raise AssertionError("get_exception() returned wrong exception message")

    try:
        # Check that we can handle a KeyError (subclass of builtin exception)
        raise KeyError("KeyError example")
    except Exception:
        e = get_exception()
        if type(e) is not KeyError:
            raise AssertionError("get_exception() returned wrong exception type")


# Generated at 2022-06-23 02:47:56.731352
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:00.105343
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)
test_get_exception()

# Generated at 2022-06-23 02:48:03.391024
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is a test')
    except ValueError as exc:
        # This should have the same exception as the one that was raised
        assert get_exception() is exc



# Generated at 2022-06-23 02:48:06.262325
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
    assert type(e) == ValueError
    assert str(e) == 'test'

# Generated at 2022-06-23 02:48:08.175213
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('dummy')
    except TypeError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:48:17.518612
# Unit test for function get_exception
def test_get_exception():
    def test_exception(e):
        try:
            raise e
        except:
            return get_exception()

    class TestException(Exception):
        pass

    assert test_exception(TestException) is not None
    assert test_exception(TestException).__class__ == TestException
    assert test_exception(TestException).__class__.__name__ == TestException.__name__
    assert test_exception(TestException).message == "No message"
    assert test_exception(TestException("Test message")).message == "Test message"

if __name__ == '__main__':
    import sys
    import doctest
    module = sys.modules[__name__]
    failed, total = doctest.testmod(module)
    sys.exit(failed)

# Generated at 2022-06-23 02:48:20.921309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    return exc.args[0] == 'foo'


# Generated at 2022-06-23 02:48:35.838771
# Unit test for function get_exception
def test_get_exception():
    # First: Try to trigger a real exception and make sure it works
    def divbyzero():
        raise ValueError('Cannot divide by zero')

# Generated at 2022-06-23 02:48:40.348591
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        e2 = get_exception()
    assert e == e2

    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:48:47.661717
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        exc = get_exception()

    # The message for the ZeroDivisionError is different between python 2 and
    # python 3.  This is the pattern that the exception message starts with
    assert str(exc).startswith('integer division or modulo by zero')


# Generated at 2022-06-23 02:48:53.063701
# Unit test for function get_exception
def test_get_exception():
    # no exception, should return None
    ret = get_exception()
    assert ret is None

    def cause_exception():
        # Raise an exception, get_exception should return it
        try:
            raise ValueError
        except Exception:
            return get_exception()
    ret = cause_exception()
    assert isinstance(ret, ValueError)


# Generated at 2022-06-23 02:48:56.442843
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        exc = get_exception()
    assert(exc.args[0] == 'test exception')


# Generated at 2022-06-23 02:49:01.300330
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hello world')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.message == 'hello world'


# Generated at 2022-06-23 02:49:03.137279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        assert get_exception().args == ('foo', )

# Generated at 2022-06-23 02:49:06.164221
# Unit test for function get_exception
def test_get_exception():
    def excepting_fn(val):
        try:
            raise ValueError(val)
        except Exception:
            return get_exception()
    assert ValueError(1) == excepting_fn(1)

# Generated at 2022-06-23 02:49:10.904910
# Unit test for function get_exception
def test_get_exception():
    # This test doesn't actually test anything.  Because of how get_exception
    # works, it can only be tested by using the function in an except block.
    # This test just makes sure that using get_exception in a try:except: block
    # doesn't throw any exceptions itself.
    try:
        raise Exception('This exception should not be raised.')
    except Exception:
        get_exception()

# Generated at 2022-06-23 02:49:13.798485
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is an exception")
    except Exception:
        e = get_exception()
        assert e.args[0] == "This is an exception"

# Generated at 2022-06-23 02:49:18.595190
# Unit test for function get_exception
def test_get_exception():

    class MyException(Exception):
        pass

    try:
        raise MyException('some_message')
    except Exception:
        e = get_exception()
        assert str(e) == 'some_message'
        assert isinstance(e, MyException)

# Generated at 2022-06-23 02:49:21.162603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        assert 'Test exception' in repr(get_exception())

# Generated at 2022-06-23 02:49:24.061285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing get_exception()')
    except Exception:
        assert str(get_exception()) == 'testing get_exception()'



# Generated at 2022-06-23 02:49:28.265914
# Unit test for function get_exception
def test_get_exception():
    def foo(x):
        raise ValueError('foo was called')
    try:
        foo(1)
    except:
        e = get_exception()
    assert type(e) == type(ValueError('foo was called'))
    assert str(e) == 'foo was called'


# Generated at 2022-06-23 02:49:32.914198
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise TypeError('test')

    try:
        foo()
    except TypeError:
        e = get_exception()
        assert str(e) == 'test'
    else:
        raise TypeError('test')


# Generated at 2022-06-23 02:49:36.482968
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:40.061827
# Unit test for function get_exception
def test_get_exception():
    import pytest

    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:49:43.367158
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception for its role in exception handling."""
    try:
        raise Exception("The message")
    except Exception:
        result = get_exception()

    assert isinstance(result, Exception)
    assert result.args == ("The message",)
    assert str(result) == "The message"


# Generated at 2022-06-23 02:49:46.281389
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        assert 'test exception' == get_exception()

# Generated at 2022-06-23 02:49:50.013447
# Unit test for function get_exception
def test_get_exception():
    # test normal exception handling
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.__class__.__name__ == 'Exception'



# Generated at 2022-06-23 02:49:59.742518
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-argument
    def raise_ValueError(a):
        raise ValueError

    def raise_TypeError(a):
        raise TypeError

    def raise_FlavorError(a):
        class FlavorError(Exception):
            pass
        raise FlavorError

    def test_function(function, *args):
        # Python 2.6, 2.7, 3.2+
        try:
            function(*args)
            assert False, 'Expected an Exception to be raised'
        except Exception:
            # get_exception() will have been called in the "except" block
            assert e.__class__ is ValueError, 'Unexpected Exception type caught: %s' % e

        # Python 2.4, 2.5

# Generated at 2022-06-23 02:50:03.717307
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('A key error')
    except KeyError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:50:08.302390
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("No tea.")
    except Exception:
        e = get_exception()
        assert e.args == ("No tea.",)
    try:
        raise Exception("No tea.", "No coffe, either.")
    except Exception:
        e = get_exception()
        assert e.args == ("No tea.", "No coffe, either.")
    # All done!

# Generated at 2022-06-23 02:50:11.434525
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test error")
    except RuntimeError:
        assert isinstance(get_exception(), RuntimeError)



# Generated at 2022-06-23 02:50:16.577609
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils._text import to_native
    try:
        # Force SyntaxError to be raised
        ast.parse("1 + + 1")
    except Exception:
        e = get_exception()
    assert isinstance(e, SyntaxError)
    assert to_native(e) == 'invalid syntax'



# Generated at 2022-06-23 02:50:19.797094
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_get_exception")
    except Exception:
        e = get_exception()
    assert str(e) == "test_get_exception"

#  vim: set et sw=4 ts=4 sts=4 tw=0:

# Generated at 2022-06-23 02:50:26.973754
# Unit test for function get_exception
def test_get_exception():
    def get_exception_test(exception_class, exception_obj):
        try:
            raise exception_obj
        except exception_class:
            return get_exception()

    class TestException(Exception):
        pass

    # Test that an exception returns itself
    e = get_exception_test(Exception, Exception())
    assert isinstance(e, Exception)

    # Test that an exception of a class that is a subclass of the
    # Excepted class still returns itself
    e = get_exception_test(Exception, TestException())
    assert isinstance(e, TestException)

# Generated at 2022-06-23 02:50:29.726229
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A Test Exception')
    except ValueError:
        e = get_exception()
        assert e.args == ('A Test Exception',)
    print('test_get_exception passed')

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:50:33.436551
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test Exception")
    except RuntimeError as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:50:35.929160
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-23 02:50:37.788745
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert e is get_exception()



# Generated at 2022-06-23 02:50:41.766511
# Unit test for function get_exception
def test_get_exception():
    # Test exception handling
    try:
        raise RuntimeError('test failure')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ('test failure',)
        assert str(e) == 'test failure'

# Generated at 2022-06-23 02:50:49.372581
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception() returns the last exception raised."""
    class FooException(Exception):
        pass
    class BarException(Exception):
        pass
    try:
        raise FooException('foo')
        raise Exception('Should not be raised')
    except FooException:
        e = get_exception()
        if str(e) != 'foo':
            raise AssertionError("FooException is not the last exception raised")
    try:
        raise BarException('bar')
        raise Exception('Should not be raised')
    except BarException:
        e = get_exception()
        if str(e) != 'bar':
            raise AssertionError("BarException is not the last exception raised")



# Generated at 2022-06-23 02:50:56.024633
# Unit test for function get_exception
def test_get_exception():

    def raise_exception():
        raise KeyError('test exception')
    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, KeyError)
        assert str(e) == 'test exception'


# Generated at 2022-06-23 02:51:00.805067
# Unit test for function get_exception
def test_get_exception():
    exc = None
    try:
        raise RuntimeError("message")
    except RuntimeError:
        exc = get_exception()

    assert isinstance(exc, RuntimeError)
    assert str(exc) == "message"



# Generated at 2022-06-23 02:51:03.032684
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        exc = get_exception()
    return exc


# Generated at 2022-06-23 02:51:07.317097
# Unit test for function get_exception
def test_get_exception():
    def do_exception():
        try:
            raise ValueError('Test error')
        except ValueError:
            e = get_exception()
            if e.__class__ != ValueError or str(e) != 'Test error':
                raise ValueError('Unexpected exception state')
    do_exception()

# Generated at 2022-06-23 02:51:09.505371
# Unit test for function get_exception
def test_get_exception():
    try:
        {}['foo']
    except KeyError as e:
        assert get_exception() is e
        return
    assert False


# Generated at 2022-06-23 02:51:12.079502
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_get_exception: test exception")
    except Exception:
        e = get_exception()
        assert e.args[0] == "test_get_exception: test exception"

# Generated at 2022-06-23 02:51:15.100679
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e

# Generated at 2022-06-23 02:51:18.246940
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception occurred')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'An exception occurred'



# Generated at 2022-06-23 02:51:20.522822
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:51:26.474216
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def foo():
        try:
            raise RuntimeError()
        except:
            e = get_exception()
        return e

    def bar():
        try:
            raise ValueError()
        except:
            e = get_exception()
        return e

    e = foo()
    e2 = bar()

    assert e.__class__ == RuntimeError
    assert e2.__class__ == ValueError

# Generated at 2022-06-23 02:51:34.350262
# Unit test for function get_exception
def test_get_exception():
    try:
        exec("1/0")
    except Exception:
        e = get_exception()
    if not isinstance(e, ZeroDivisionError):
        raise Exception("Expected ZeroDivisionError, got %s" % repr(e))


# Generated at 2022-06-23 02:51:39.723353
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except Exception as e:
        # Python 3 exceptions have a __traceback__ attribute
        # Python 2 exceptions have a __traceback__ attribute but it's None
        assert e.__traceback__ is None
        e2 = get_exception()
        assert e2 is e or (e2.__traceback__ is None and e.__traceback__ is None)

    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:51:45.555284
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('TEST')
    except:
        e = get_exception()
        assert e.__str__() == 'TEST'

from ansible.module_utils.six.moves import cPickle as pickle

from ansible.module_utils._text import to_bytes, to_text

from ansible.module_utils.six import PY2

from ansible.module_utils.common._collections_compat import MutableMapping

from ansible.module_utils.parsing.convert_bool import boolean



# Generated at 2022-06-23 02:51:54.469090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is the error message.')
    except ValueError as e:
        tb = sys.exc_info()[2]
        assert e is get_exception()  # No exception should have been raised
        assert e.args == ('This is the error message.',)
        del tb  # No dangling references
    try:
        raise ValueError('This is the error message.')
    except ValueError:
        e = get_exception()
        assert e.args == ('This is the error message.',)

# Generated at 2022-06-23 02:51:56.964279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
    assert e.args == ('Test exception',)

# Generated at 2022-06-23 02:52:04.955479
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('String')
    except (TypeError, AttributeError):
        e = get_exception()
        if isinstance(e, TypeError) and e.args[0] == 'String':
            pass
        else:
            raise Exception(
                "get_exception failed to correctly get the current exception.  Expected a TypeError('String')"
                " but got {0}".format(e)
            )



# Generated at 2022-06-23 02:52:08.152326
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Catch me.')
    except Exception:
        assert sys.exc_info()[1].args[0] == get_exception().args[0]

# Generated at 2022-06-23 02:52:11.238240
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError:
        exc = get_exception()
        assert str(exc) == 'foo', 'expected exception message to match'


# Generated at 2022-06-23 02:52:13.434090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert(e == get_exception())


# Generated at 2022-06-23 02:52:20.949267
# Unit test for function get_exception
def test_get_exception():
    # Are we in Python 2.x or Python 3.x?
    PY3 = sys.version_info[0] >= 3

    try:
        raise Exception('An exception')
    except Exception:
        e = get_exception()
        # Ensure we have the right exception
        assert e.args == ('An exception',)

        # If we're in Python 2, the exception should be a string
        if not PY3:
            assert isinstance(e, str)
        else:
            assert isinstance(e, Exception)

# Generated at 2022-06-23 02:52:25.012570
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:52:31.444857
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        try:
            raise SyntaxError('bar')
        except SyntaxError as f:
            if get_exception() is not f:
                raise AssertionError('Exception from get_exception() is not the exception that was raised')
            if get_exception() != f:
                raise AssertionError('Exception from get_exception() does not compare equal to the exception that was raised')

# Generated at 2022-06-23 02:52:34.181980
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise AssertionError()
        except AssertionError:
            e = get_exception()
            return e

    assert isinstance(test(), AssertionError)

# Generated at 2022-06-23 02:52:36.202375
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('fail')
    except RuntimeError as exception:
        if get_exception() != exception:
            raise AssertionError('get_exception() did not return the current exception')

# Generated at 2022-06-23 02:52:41.498835
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        if str(e) != "Test exception":
            raise AssertionError("get_exception() did not return the test exception")

# Generated at 2022-06-23 02:52:45.337474
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError as e:
        if not e == get_exception():
            raise Exception('get_exception() did not return the right exception')

# Generated at 2022-06-23 02:52:48.363071
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        assert get_exception().args[0] == 'test'
    else:
        assert False, "This should not have executed"


# Generated at 2022-06-23 02:52:54.306856
# Unit test for function get_exception
def test_get_exception():
    """Test that the get_exception function works like we expect it to."""
    from ansible.compat.tests import unittest

    class GetExceptionTestCase(unittest.TestCase):
        """Test case for get_exception function."""

        def test_get_exception(self):
            """Test that get_exception works as expected."""
            try:
                raise Exception('test')
            except Exception:
                exc = get_exception()
            self.assertEqual(exc.args[0], 'test')

# Generated at 2022-06-23 02:52:59.533614
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestAnsibleModuleUtilsExceptions(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise RuntimeError()
            except:
                actual_exception = get_exception()
            self.assertTrue(isinstance(actual_exception, RuntimeError))

# Generated at 2022-06-23 02:53:02.318201
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:53:05.795020
# Unit test for function get_exception
def test_get_exception():

    # Check if the function works when called inside an exception
    try:
        raise Exception('Test exception')
    except:
        ret = get_exception()

    assert isinstance(ret, Exception)
    assert str(ret) == 'Test exception'



# Generated at 2022-06-23 02:53:07.287299
# Unit test for function get_exception
def test_get_exception():
    raise Exception('Howdy')


# Generated at 2022-06-23 02:53:11.980556
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except ValueError:
        got_exception = get_exception()
    assert isinstance(got_exception, ValueError)
    assert got_exception.args == ('Test',)
    assert got_exception == ValueError('Test')


# Generated at 2022-06-23 02:53:14.568068
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert ValueError in e.__class__.__mro__


# Generated at 2022-06-23 02:53:16.670580
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        assert get_exception().args[0] == 'test exception'

# Generated at 2022-06-23 02:53:20.506865
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception"""
    try:
        raise Exception("Test message")
    except:
        e = get_exception()
    assert str(e) == "Test message"

# Generated at 2022-06-23 02:53:26.076862
# Unit test for function get_exception
def test_get_exception():
    # Test exception
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

    # Test no exception
    try:
        pass
    except:
        e = get_exception()
    assert e is None


# Generated at 2022-06-23 02:53:28.372607
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert(e.__class__ == ZeroDivisionError)

# Generated at 2022-06-23 02:53:31.044641
# Unit test for function get_exception
def test_get_exception():

    def func():
        raise RuntimeError("Test exception")

    try:
        func()
    except:
        assert str(get_exception()) == "Test exception"

# Generated at 2022-06-23 02:53:33.779956
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()

    assert type(e) == Exception and e.args[0] == 'test exception'

# Generated at 2022-06-23 02:53:42.818759
# Unit test for function get_exception
def test_get_exception():
    import unittest

    TEST_EXCEPTION = Exception('Test exception')

    class TestException(unittest.TestCase):

        def test_exception_raised(self):
            try:
                raise TEST_EXCEPTION
            except Exception:
                self.exception = get_exception()

        def test_exception_type(self):
            self.assertEqual(Exception, type(self.exception))

        def test_exception_value(self):
            self.assertEqual(str(TEST_EXCEPTION), str(self.exception))

    # run unit tests
    unittest.main()


if __name__ == '__main__':
    # unit test when executing this module directly
    test_get_exception()

# Generated at 2022-06-23 02:53:45.730284
# Unit test for function get_exception
def test_get_exception():
    try:
        class TestException(Exception):
            pass

        raise TestException("test exception")
    except:
        e = get_exception()
    assert type(e).__name__ == 'TestException', e
    assert repr(e) == 'test exception', repr(e)

# Generated at 2022-06-23 02:53:49.359197
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        exc = get_exception()
        assert exc is not None
        assert isinstance(exc, Exception)
        return True


# Generated at 2022-06-23 02:53:53.583695
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("test")
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == "test"

# Generated at 2022-06-23 02:53:54.624344
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:00.078154
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:05.338755
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise Exception('Test Exception')
    except Exception:
        test_exception = get_exception()
    assert test_exception.args[0] == 'Test Exception'


# Generated at 2022-06-23 02:54:08.473465
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test")
    except ValueError:
        e = get_exception()
        assert str(e) == "Test"


# Generated at 2022-06-23 02:54:13.923290
# Unit test for function get_exception
def test_get_exception():
    def foo(exception):
        try:
            raise exception
        except Exception:
            assert get_exception() is exception

    foo(KeyboardInterrupt())
    foo(IOError())
    foo(RuntimeError())
    foo(ValueError())
    foo(Exception())



# Generated at 2022-06-23 02:54:17.922548
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:54:21.427435
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0   # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-23 02:54:24.185218
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        exc = get_exception()
        assert exc.args[0] == 'This is a test'

# Generated at 2022-06-23 02:54:27.436162
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Some error')
    except ValueError:
        e = get_exception()
    assert(isinstance(e, ValueError))
    assert e.args[0] == 'Some error'

# Generated at 2022-06-23 02:54:32.915629
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("A test exception")
    except Exception:
        ex = get_exception()
    assert ex.args[0] == "A test exception"

    try:
        raise Exception("A test exception with a tuple", (1, 2))
    except Exception:
        ex = get_exception()
    assert ex.args[0] == "A test exception with a tuple"
    assert ex.args[1] == (1, 2)

# Generated at 2022-06-23 02:54:37.424279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("ha ha")
    except Exception:
        e = get_exception()

    if str(e) != "ha ha":
        raise AssertionError("Unexpected value for exception: %s" % e)

# Generated at 2022-06-23 02:54:44.934763
# Unit test for function get_exception
def test_get_exception():
    # Python 2 and Python 3 have different exception handling
    try:
        a = {}
        a[4]
    except KeyError:
        e = get_exception()
        assert(e.__class__ == KeyError)
    else:
        assert(0)
    try:
        a = {}
        a['foo']
    except KeyError:
        e = get_exception()
        assert(e.__class__ == KeyError)
    else:
        assert(0)

# Generated at 2022-06-23 02:54:48.267708
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u"test exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == (u"test exception",)


# Generated at 2022-06-23 02:54:51.266738
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'testing'
    assert str(e) == 'testing'


# Generated at 2022-06-23 02:54:56.508794
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1/0  # pylint: disable=unused-variable
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:55:00.683354
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        raise ValueError('foo')

    try:
        raise_exc()
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:55:08.616250
# Unit test for function get_exception